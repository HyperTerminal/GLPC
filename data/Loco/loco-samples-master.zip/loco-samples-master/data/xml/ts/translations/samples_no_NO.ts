<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE TS>
<!--
 Loco xml export: Qt framework TS file
 Project: Samples
 Release: Working copy
 Locale: no_NO, Norwegian
 Exported by: Tim Whitlock
 Exported at: Sat, 15 Mar 2014 14:39:51 +0000 
--> 
<TS version="2.0" language="no_NO"> 
    <context>
        <name>main</name> 
        <message>
            <source>Goodbye</source> 
            <translation>Farvel</translation> 
        </message> 
        <message>
            <source>Hello World</source> 
            <translation>Hallo Verden</translation> 
        </message> 
    </context> 
</TS>
