<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE TS>
<!--
 Loco xml export: Qt framework TS file
 Project: Samples
 Release: Working copy
 Locale: de_DE, German
 Exported by: Tim Whitlock
 Exported at: Sat, 15 Mar 2014 14:39:51 +0000 
--> 
<TS version="2.0" language="de_DE"> 
    <context>
        <name>main</name> 
        <message>
            <source>Goodbye</source> 
            <translation>Auf Wiedersehen</translation> 
        </message> 
        <message>
            <source>Hello World</source> 
            <translation>Hallo Welt</translation> 
        </message> 
    </context> 
</TS>
