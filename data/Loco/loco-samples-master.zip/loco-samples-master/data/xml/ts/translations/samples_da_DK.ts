<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE TS>
<!--
 Loco xml export: Qt framework TS file
 Project: Samples
 Release: Working copy
 Locale: da_DK, Danish
 Exported by: Tim Whitlock
 Exported at: Sat, 15 Mar 2014 14:39:51 +0000 
--> 
<TS version="2.0" language="da_DK"> 
    <context>
        <name>main</name> 
        <message>
            <source>Goodbye</source> 
            <translation>Farvel</translation> 
        </message> 
        <message>
            <source>Hello World</source> 
            <translation>Hej Verden</translation> 
        </message> 
    </context> 
</TS>
