<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE TS>
<!--
 Loco xml export: Qt framework TS file
 Project: Samples
 Release: Working copy
 Locale: fr_FR, French
 Exported by: Tim Whitlock
 Exported at: Sat, 15 Mar 2014 14:39:50 +0000 
--> 
<TS version="2.0" language="fr_FR"> 
    <context>
        <name>main</name> 
        <message>
            <source>Goodbye</source> 
            <translation>Au revoir</translation> 
        </message> 
        <message>
            <source>Hello World</source> 
            <translation>Bonjour tout le monde</translation> 
        </message> 
    </context> 
</TS>
