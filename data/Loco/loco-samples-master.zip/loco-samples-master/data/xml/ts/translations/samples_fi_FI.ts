<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE TS>
<!--
 Loco xml export: Qt framework TS file
 Project: Samples
 Release: Working copy
 Locale: fi_FI, Finnish
 Exported by: Tim Whitlock
 Exported at: Sat, 15 Mar 2014 14:39:51 +0000 
--> 
<TS version="2.0" language="fi_FI"> 
    <context>
        <name>main</name> 
        <message>
            <source>Goodbye</source> 
            <translation>Näkemiin</translation> 
        </message> 
        <message>
            <source>Hello World</source> 
            <translation>Hei Maailma</translation> 
        </message> 
    </context> 
</TS>
