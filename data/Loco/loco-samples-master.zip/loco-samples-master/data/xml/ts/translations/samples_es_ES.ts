<?xml version="1.0" encoding="utf-8"?> 
<!DOCTYPE TS>
<!--
 Loco xml export: Qt framework TS file
 Project: Samples
 Release: Working copy
 Locale: es_ES, Spanish
 Exported by: Tim Whitlock
 Exported at: Sat, 15 Mar 2014 14:39:51 +0000 
--> 
<TS version="2.0" language="es_ES"> 
    <context>
        <name>main</name> 
        <message>
            <source>Goodbye</source> 
            <translation>Adiós</translation> 
        </message> 
        <message>
            <source>Hello World</source> 
            <translation>Hola mundo</translation> 
        </message> 
    </context> 
</TS>
