<?php 
/**
 * Loco php export: Zend (PHP array)
 * Project: Samples
 * Release: Working copy
 * Locale: sv_SE, Swedish
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:00 +0000 
 */
return array (
  'goodbye' => 'Adjö',
  'hello-world' => 'Hallå Världen',
);
