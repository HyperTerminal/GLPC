<?php 
/**
 * Loco php export: Zend (PHP array)
 * Project: Samples
 * Release: Working copy
 * Locale: es_ES, Spanish
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:00 +0000 
 */
return array (
  'goodbye' => 'Adiós',
  'hello-world' => 'Hola mundo',
);
