<?php 
/**
 * Loco php export: Code Igniter ($lang array)
 * Project: Samples
 * Release: Working copy
 * Locale: en_GB, English (UK)
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:01 +0000 
 */
$lang['samples_goodbye'] = 'Goodbye';
$lang['samples_hello_world'] = 'Hello World';
