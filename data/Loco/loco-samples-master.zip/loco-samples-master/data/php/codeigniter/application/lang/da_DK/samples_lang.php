<?php 
/**
 * Loco php export: Code Igniter ($lang array)
 * Project: Samples
 * Release: Working copy
 * Locale: da_DK, Danish
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:02 +0000 
 */
$lang['samples_goodbye'] = 'Farvel';
$lang['samples_hello_world'] = 'Hej Verden';
