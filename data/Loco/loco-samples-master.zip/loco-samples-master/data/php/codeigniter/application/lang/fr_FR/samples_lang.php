<?php 
/**
 * Loco php export: Code Igniter ($lang array)
 * Project: Samples
 * Release: Working copy
 * Locale: fr_FR, French
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:01 +0000 
 */
$lang['samples_goodbye'] = 'Au revoir';
$lang['samples_hello_world'] = 'Bonjour tout le monde';
