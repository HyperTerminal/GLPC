<?php 
/**
 * Loco php export: Code Igniter ($lang array)
 * Project: Samples
 * Release: Working copy
 * Locale: it_IT, Italian
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:02 +0000 
 */
$lang['samples_goodbye'] = 'Arrivederci';
$lang['samples_hello_world'] = 'Ciao a tutti';
