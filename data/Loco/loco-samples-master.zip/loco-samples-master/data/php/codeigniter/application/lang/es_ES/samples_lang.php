<?php 
/**
 * Loco php export: Code Igniter ($lang array)
 * Project: Samples
 * Release: Working copy
 * Locale: es_ES, Spanish
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:02 +0000 
 */
$lang['samples_goodbye'] = 'Adiós';
$lang['samples_hello_world'] = 'Hola mundo';
