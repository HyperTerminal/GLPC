<?php 
/**
 * Loco php export: Constants
 * Project: Samples
 * Release: Working copy
 * Locale: fi_FI, Finnish
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:03 +0000 
 */

/* @const string goodbye */
define('SAMPLES_GOODBYE', 'Näkemiin');

/* @const string hello-world */
define('SAMPLES_HELLO_WORLD', 'Hei Maailma');
