<?php 
/**
 * Loco php export: Symfony (PHP array)
 * Project: Samples
 * Release: Working copy
 * Locale: da_DK, Danish
 * Exported by: Tim Whitlock
 * Exported at: Sat, 15 Mar 2014 14:40:01 +0000 
 */
return array (
  'goodbye' => 'Farvel',
  'hello-world' => 'Hej Verden',
);
