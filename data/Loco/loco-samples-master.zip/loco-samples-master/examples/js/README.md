# Loco JavaScript example code

## Hello World
* index.html - Basic example of <code>t()</code> function

