# Loco PHP example code

## Hello World
* simple.php - Simple array format
* gettext.php - Gettext PO file
* tmx.php - Translation Memory eXchange
* yaml.php - Simple YAML file


