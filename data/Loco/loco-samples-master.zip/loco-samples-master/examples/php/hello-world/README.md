# PHP Hello World examples

These are framework-free examples of using various langauge pack formats in PHP.

These examples can be seen in action under http://localise.biz/samples/examples/php/
