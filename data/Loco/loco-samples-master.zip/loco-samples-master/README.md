# Loco Samples

Sample langauge packs and example code for localisation management system "Loco" - http://localise.biz


* **data/**  
  Sample language files in numerous standard, and non-standard formats  
  
* **examples/**  
  Code examples using the sample data files

If you'd like to contribute to sample code for your language/platform, please get in touch via Github.  
Code examples required for Java, Python, Ruby and C#.