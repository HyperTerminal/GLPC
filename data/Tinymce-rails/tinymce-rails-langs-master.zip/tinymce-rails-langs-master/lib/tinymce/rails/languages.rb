module TinyMCE::Rails
  class Languages < ::Rails::Engine
  end
end
