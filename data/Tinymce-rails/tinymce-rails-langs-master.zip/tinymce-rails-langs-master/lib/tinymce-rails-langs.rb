require "tinymce/rails"
require "tinymce/rails/languages"
