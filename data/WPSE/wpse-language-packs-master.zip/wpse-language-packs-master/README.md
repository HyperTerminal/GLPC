WordPress Sverige Language Packs (sv_SE)
===================

Svenska språkfiler (sv_SE) för WordPress, bbPress, BuddyPress och teman/tillägg
