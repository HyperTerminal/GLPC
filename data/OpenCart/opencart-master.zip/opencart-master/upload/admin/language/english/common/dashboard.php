<?php
// Heading
$_['heading_title']                = 'Dashboard';

// Text
$_['text_welcome']                 = 'Welcome back <strong>%s</strong>!';
$_['text_new_order']               = 'New Orders';
$_['text_new_customer']            = 'New Customers';
$_['text_total_sale']              = 'Total Sales';
$_['text_analytics']               = 'Sales Analytics';
$_['text_online']                  = 'People Online';
$_['text_activity']                = 'Recent Activity';
$_['text_last_order']              = 'Last 5 Orders';
$_['text_order']                   = 'Orders';
$_['text_customer']                = 'Customers';
$_['text_day']                     = 'Today';
$_['text_week']                    = 'Week';
$_['text_month']                   = 'Month';
$_['text_year']                    = 'Year';
$_['text_customer_address_add']    = '<a href="customer_id=%d">%s</a> added a new address.';
$_['text_customer_address_edit']   = '<a href="customer_id=%d">%s</a> updated their address.';
$_['text_customer_address_delete'] = '<a href="customer_id=%d">%s</a> deleted one of their address.';
$_['text_customer_edit']           = '<a href="customer_id=%d">%s</a> updated their account details.';
$_['text_customer_fogotten']       = '<a href="customer_id=%d">%s</a> has requested a new password.';
$_['text_customer_login']          = '<a href="customer_id=%d">%s</a> logged in.';
$_['text_customer_password']       = '<a href="customer_id=%d">%s</a> updated their account password.';
$_['text_customer_register']       = '<a href="customer_id=%d">%s</a> registered a new account.';
$_['text_customer_return_accout']  = '<a href="customer_id=%d">%s</a> submitted a product return.';
$_['text_customer_return_guest']   = '%s submitted a product return.';
$_['text_customer_order_account']  = '<a href="customer_id=%d">%s</a> created a <a href="order_id=%d">new order</a>.';
$_['text_customer_order_guest']    = '%s created a <a href="order_id=%d">new order</a>.';
$_['text_affiliate_edit']          = '<a href="affiliate_id=%d">%s</a> updated their account details.';
$_['text_affiliate_fogotten']      = '<a href="affiliate_id=%d">%s</a> requested a new password.';
$_['text_affiliate_login']         = '<a href="affiliate_id=%d">%s</a> logged in.';
$_['text_affiliate_password']      = '<a href="affiliate_id=%d">%s</a> updated their account password.';
$_['text_affiliate_payment']       = '<a href="affiliate_id=%d">%s</a> updated their payment details.';
$_['text_affiliate_register']      = '<a href="affiliate_id=%d">%s</a> registered for a new account.';

// Column
$_['column_order_id']              = 'Order ID';
$_['column_customer']              = 'Customer';
$_['column_status']                = 'Status';
$_['column_total']                 = 'Total';
$_['column_date_added']            = 'Date Added';
$_['column_action']                = 'Action';

// Error
$_['error_install']                = 'Warning: Install folder still exists and should be deleted for security reasons!';