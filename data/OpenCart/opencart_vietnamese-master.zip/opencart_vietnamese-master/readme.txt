Step 1: Upload upload folder on your server

Step 2: Go Administrator > System > Localisation > Languages > Insert:

a. Language name: Vietnamese
b. Code: vi
c. Locale: vi_VN.UTF-8,vi_VN,vi-vn,vietnamese
d. Image: vn.png
e. Directory: vietnamese
f. Filename: vietnamese
> Save

Step 3: Go Administrator > System > Settings > Your Store > Edit > Local: 
a. Language: Vietnamese
b. Administration language: Vietnamese

> Save.

Step 4: when you get any bug relative to this language pack, please report it:
https://github.com/fanha99/opencart_vietnamese/issues