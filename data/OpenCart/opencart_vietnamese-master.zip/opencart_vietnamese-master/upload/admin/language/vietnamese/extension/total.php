<?php
// Heading
$_['heading_title']     = 'Tổng đơn hàng';

// Text
$_['text_install']      = 'Cài đặt';
$_['text_uninstall']    = 'Gỡ bỏ';

// Column
$_['column_name']       = 'Tổng đơn hàng';
$_['column_status']     = 'Trạng thái';
$_['column_sort_order'] = 'Thứ tự';
$_['column_action']     = 'Thao tác';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền sửa đổi tổng đơn hàng!';
?>