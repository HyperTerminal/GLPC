<?php
// Heading
$_['heading_title']     = 'Báo cáo khách hàng Online';

// Text 
$_['text_guest']        = 'Khách';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Khách hàng';
$_['column_url']        = 'Trang truy cập cuối';
$_['column_referer']    = 'Referer';
$_['column_date_added'] = 'Last Click';
$_['column_action']     = 'Thao tác';
?>