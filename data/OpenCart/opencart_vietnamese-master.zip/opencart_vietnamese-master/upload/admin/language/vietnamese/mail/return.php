<?php
// Text
$_['text_subject']       = '%s - Quay trở lại Cập nhật %s';
$_['text_return_id']     = ' ID Quay trở lại:';
$_['text_date_added']    = 'Ngày trở lại:';
$_['text_return_status'] = 'Sự trở lại của bạn đã được cập nhật vào tình trạng dưới đây:';
$_['text_comment']       = 'Các ý kiến ​​cho sự trở lại của bạn:';
$_['text_footer']        = 'Xin vui lòng trả lời email này nếu bạn có bất kỳ câu hỏi.';
?>