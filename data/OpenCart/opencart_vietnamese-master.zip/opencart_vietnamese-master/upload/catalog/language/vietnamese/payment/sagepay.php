<?php
// Text
$_['text_title']       = 'Thẻ Tín Dụng / Thẻ Ghi Nợ (SagePay)';
$_['text_description'] = 'Items on %s Order No: %s';
?>