<?php
// Heading 
$_['heading_title']  = 'Cham s�c kh�ch h�ng';
?>