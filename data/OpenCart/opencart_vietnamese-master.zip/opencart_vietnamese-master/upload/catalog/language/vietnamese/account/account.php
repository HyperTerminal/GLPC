<?php
// Heading 
$_['heading_title']      = 'Quản lý tài khoản';

// Text
$_['text_account']       = 'Quản lý tài khoản';
$_['text_my_account']    = 'Thông tin tài khoản';
$_['text_my_orders']     = 'Đơn hàng của tôi';
$_['text_my_newsletter'] = 'Nhận tin';
$_['text_edit']          = 'Thông tin cá nhân';
$_['text_password']      = 'Thay đổi mật khẩu';
$_['text_address']       = 'Thay đổi sổ địa chỉ';
$_['text_wishlist']      = 'Sản phẩm ưa thích';
$_['text_order']         = 'Xem lịch sử đơn hàng';
$_['text_download']      = 'Tải về';
$_['text_reward']        = 'Điểm Thưởng'; 
$_['text_return']        = 'Yêu cầu trả hàng'; 
$_['text_transaction']   = 'Giao dịch của bạn'; 
$_['text_newsletter']    = 'Đăng ký / Hủy đăng ký nhận tin';
?>