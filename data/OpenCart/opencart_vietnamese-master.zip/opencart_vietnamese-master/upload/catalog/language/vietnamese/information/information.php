<?php
// Text
$_['text_error'] = 'Không tìm thấy trang này!';
?>