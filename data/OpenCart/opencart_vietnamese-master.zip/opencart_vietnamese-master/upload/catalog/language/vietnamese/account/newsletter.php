<?php
// Heading
$_['heading_title']    = 'Đăng ký nhận tin';

// Text
$_['text_account']     = 'Tài khoản';
$_['text_newsletter']  = 'Thay đổi nhận tin';
$_['text_success']     = 'Thành công: Bạn đã đăng kí nhận thư thông báo!';

// Entry
$_['entry_newsletter'] = 'Báo cho tôi khi có tin mới:';
?>
