<?php
// Heading
$_['heading_title']   = 'Quản lý tải về';

// Text
$_['text_account']    = 'Tài khoản';
$_['text_downloads']  = 'Tải về';
$_['text_order']      = 'Mã đơn hàng:';
$_['text_date_added'] = 'Ngày tạo:';
$_['text_name']       = 'Tên:';
$_['text_remaining']  = 'Còn lại:';
$_['text_size']       = 'Kích thước:';
$_['text_empty']      = 'Bạn không có đơn hàng nào có thể tải về!';
?>