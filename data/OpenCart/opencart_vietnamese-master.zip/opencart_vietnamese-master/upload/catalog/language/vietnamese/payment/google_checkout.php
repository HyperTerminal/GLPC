<?php
// Entry
$_['text_title'] = 'Credit Card / Debit Card (Google Checkout)';
$_['entry_postcode'] = 'Mã Bưu Điện:';
$_['entry_country']  = 'Quốc Gia:';
$_['entry_zone']     = 'Vùng / Tiểu Bang:';
?>