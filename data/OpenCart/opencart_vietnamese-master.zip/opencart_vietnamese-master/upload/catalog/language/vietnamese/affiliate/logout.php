<?php
// Heading 
$_['heading_title'] = 'Đăng xuất tài khoản';

// Text
$_['text_message']  = '<p>Bạn đã đăng xuất tài khoản. Bạn có thể rời khỏi máy tính.</p><p>Giỏ hàng của bạn đã được lưu, sản phẩm trong giỏ sẽ được giữ lại khi bạn đăng nhập lại.</p>';
$_['text_account']  = 'Tài khoản';
$_['text_logout']   = 'Đăng xuất';
?>