<?php
$_['text_sub_total'] = 'Thành tiền:';
?>