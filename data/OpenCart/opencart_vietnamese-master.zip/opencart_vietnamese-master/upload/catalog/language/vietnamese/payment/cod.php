<?php
// Text
$_['text_title'] = 'Thu tiền khi giao hàng';
?>