<?php
// Text
$_['text_title']  = 'Vận chuyển dựa trên trọng lượng';
$_['text_weight'] = 'Trọng lượng:'; 
?>