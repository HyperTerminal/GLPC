<?php
// Heading 
$_['heading_title'] = 'Sản phẩm nổi bật';

// Text
$_['text_reviews']  = 'Dựa trên %s đánh giá.'; 
?>