<?php
$_['text_handling'] = 'Phí xử lý:';
?>