<?php
// Text
$_['text_subject']  = '%s - Mật khẩu mới';
$_['text_greeting'] = 'Yêu cầu mật khẩu mới được gửi từ %s.';
$_['text_password'] = 'Mật khẩu mới của bạn được cấp ở dưới đây, hãy đăng nhập và đổi lại mật khẩu theo ý của bạn:';
?>