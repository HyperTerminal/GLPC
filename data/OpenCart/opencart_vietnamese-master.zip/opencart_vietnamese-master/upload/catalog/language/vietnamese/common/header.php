<?php
// Text
$_['text_home']           = 'Trang chủ';
$_['text_wishlist']       = 'Yêu thích (%s)';
$_['text_shopping_cart']  = 'Giỏ hàng';
$_['text_search']         = 'Tìm kiếm';
$_['text_welcome']        = 'Xin chào, bạn có thể <a href="%s">đăng nhập</a> hoặc <a href="%s">tạo tài khoản</a>.';
$_['text_logged']         = 'Bạn đăng nhập với tên <a href="%s">%s</a> <b>(</b> <a href="%s">Thoát ra</a> <b>)</b>';
$_['text_account']        = 'Tài khoản';
$_['text_checkout']       = 'Thanh toán';
?>