<?php
// Heading 
$_['heading_title'] = 'Giỏ hàng';

// Text
$_['text_items']    = '%s sản phẩm(s) - %s';
$_['text_empty']    = 'Giỏ hàng đang trống!';

$_['text_cart']     = 'Xem giỏ hàng';

$_['text_checkout'] = 'Thanh toán';
?>