<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'LÝ DO';
$_['text_testmode']	= 'Cảnh báo: The Payment Gateway is in \'Sandbox Mode\'. Your account will not be charged.';
$_['text_total']	= 'Vận chuyển, Xử lý, Giảm giá và Thuế';
?>