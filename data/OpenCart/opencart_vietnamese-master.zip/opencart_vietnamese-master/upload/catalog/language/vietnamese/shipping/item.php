<?php
// Text
$_['text_title']       = 'Mỗi sản phẩm';
$_['text_description'] = 'Giá trên mỗi sản phẩm';
?>