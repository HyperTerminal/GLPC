Bước 1: Tải thư mục upload lên trên host của bạn

Bước 2: Đăng nhập Administrator > System > Localisation > Languages > Insert:

a. Language name: Vietnamese
b. Code: vi
c. Locale: vi_VN.UTF-8,vi_VN,vi-vn,vietnamese
d. Image: vn.png
e. Directory: vietnamese
f. Filename: vietnamese
> Save

Bước 3: Đăng nhập Administrator > System > Settings > Your Store > Edit > Local: 
a. Language: Vietnamese
b. Administration language: Vietnamese

> Save.

Bước 4: Khi bạn gặp bất kỳ vấn đề nào liên quan tới gói ngôn ngữ này, vui lòng trao đổi tại:
https://github.com/fanha99/opencart_vietnamese/issues