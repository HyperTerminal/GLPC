opencart-1.5.3.1-spanish-language-pack
======================================

##Description
This is a Opencart spanish language pack for 1.5.3.1 version and it is **free**!!!!!!!!!!

##Structure
* upload folder
    * admin folder
        * language folder
            * spanish folder
    * catalog folder
        * language folder
            * spanish folder

##Install Instructions
    1. Copy the spanish folders according to Structure in your opencart installation
    2. Go to Opencart administration Panel
    3. Go to System -> localization -> languages
    3. Create one with the next features
        Language Name: Español
        Code: es
        Locale: es_ES.UTF-8,es_ES,Spanish
        Image: es.png
        Folder: spanish
        Filename: spanish
        Status: Activo

##Change language Image
    1. Go to Administrator
    2. Go to System -> localization ->languages
    3. Click the 'edit' link for the Language you want to change the image.
    4. Search the field Image, and put the new image (example: us.png, mx.png)
