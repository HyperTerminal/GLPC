<?php
// Heading 
$_['heading_title']    = 'Seguimiento de afiliados';

// Text
$_['text_account']     = 'Cuenta';
$_['text_description'] = 'Para asegurarte de que es pagado por las referencias que envías necesitamos un código de seguimiento en la url para rastrear el enlace hacia nosotros. Puedes usar las herramientas que se encuentran más abajo para generar enlaces al sitio web %.';
$_['text_code']        = '<b>Tu código de seguimiento:</b>';
$_['text_generator']   = '<b>Generador enlaces de seguimiento</b><br />ntroduce el nombre de un producto que quieras enlanzar:';
$_['text_link']        = '<b>Enlace de segumiento:</b>';
?>