<?php
// Text
$_['text_error'] = 'Página de información no encontrada!';
?>