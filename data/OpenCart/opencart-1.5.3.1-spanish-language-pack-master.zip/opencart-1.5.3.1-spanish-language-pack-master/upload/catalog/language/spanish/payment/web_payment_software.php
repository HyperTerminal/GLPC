<?php
// Text
$_['text_title']           = 'Tarjeta Crédito / Tarjeta de Debito (Software de pago vía web)';
$_['text_credit_card']     = 'Detalles de la Tarjeta de Crédito';
$_['text_wait']            = 'Por favor espera!';

// Entry
$_['entry_cc_owner']       = 'Dueño de la Tarjeta:';
$_['entry_cc_number']      = 'Número de la Tarjeta:';
$_['entry_cc_expire_date'] = 'Fecha de expiración de la Tarjeta:';
$_['entry_cc_cvv2']        = 'Código de seguridad de la tarjeta (CVV2):';
?>