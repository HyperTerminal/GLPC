<?php
// Text
$_['text_subject']  = '%s - Nueva contraseña';
$_['text_greeting'] = 'Una nueva contraseña fue pedida desde %s.';
$_['text_password'] = 'Tu nueva contraseña es:';
?>
?>