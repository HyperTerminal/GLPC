<?php
// Text
$_['text_title']       = 'Cheque / Instrucciones de giro postal';
$_['text_instruction'] = 'Cheque / Giro postal';
$_['text_payable']     = 'Hacer pagable a: ';
$_['text_address']     = 'Enviar a: ';
$_['text_payment']     = 'Tu pedido no se enviará hasta que se reciba el pago.';
?>