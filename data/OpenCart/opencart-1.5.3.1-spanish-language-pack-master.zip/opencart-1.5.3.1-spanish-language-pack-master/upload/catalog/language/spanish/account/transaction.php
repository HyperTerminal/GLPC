<?php
// Heading 
$_['heading_title']      = 'Tus transacciones';

// Column
$_['column_date_added']  = 'Fecha de alta';
$_['column_description'] = 'Descripción';
$_['column_amount']      = 'Cantidad (%s)';

// Text
$_['text_account']       = 'Cuenta';
$_['text_transaction']   = 'Tus transacciones';
$_['text_total']         = 'Tu balance actual es:';
$_['text_empty']         = 'No tienes ninguna transacción!';
?>