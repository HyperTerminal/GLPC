<?php
// Entry
$_['text_title'] = 'Trajeta de Crédito / Tarjeta de Debito (Google Checkout)';
?>