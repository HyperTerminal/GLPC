<?php
// Heading 
$_['heading_title']        = 'Mi cuenta de afiliado';

// Text
$_['text_account']         = 'Cuenta';
$_['text_my_account']      = 'Mi cuenta de afiliado';
$_['text_my_tracking']     = 'Mi información de seguimiento';
$_['text_my_transactions'] = 'Mis transacciones';
$_['text_edit']            = 'Editar tu información de cuenta';
$_['text_password']        = 'Cambia tu contraseña';
$_['text_payment']         = 'Cambia tus preferencias de pago';
$_['text_tracking']        = 'Código de seguimiento personal de afiliados';
$_['text_transaction']     = 'Ver tu historial de transacciones';
?>