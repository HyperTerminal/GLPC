<?php
// Heading 
$_['heading_title'] = 'Selecciona una tienda';

// Text
$_['text_default']  = 'Por defecto';
$_['text_store']    = 'Por favor selecciona la tienda que desées visitar.';
?>