<?php
// Text
$_['text_title']       = 'Recoger en Tienda';
$_['text_description'] = 'Recoger en Tienda';
?>