<?php
// Text
$_['text_title'] = 'PayPal Express (incluyendo tarjeta de crédito y tarjeta de débito)';