<?php
// Heading 
$_['heading_title']      = 'Tus puntos de recompensa';

// Column
$_['column_date_added']  = 'Fecha de alta';
$_['column_description'] = 'Descripción';
$_['column_points']      = 'Puntos';

// Text
$_['text_account']       = 'Cuenta';
$_['text_reward']        = 'Puntos de recompensa';
$_['text_total']         = 'El total de tus puntos de recompensa es:';
$_['text_empty']         = 'o tienes ningún punto de recompensa!';
?>