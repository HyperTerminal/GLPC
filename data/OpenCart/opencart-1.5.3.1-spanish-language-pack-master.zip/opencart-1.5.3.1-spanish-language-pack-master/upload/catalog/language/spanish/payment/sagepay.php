<?php
// Text
$_['text_title']       = 'Tarjeta de crédito / Tarjeta de débito (SagePay)';
$_['text_description'] = 'Items en %s pedido No: %s';
?>