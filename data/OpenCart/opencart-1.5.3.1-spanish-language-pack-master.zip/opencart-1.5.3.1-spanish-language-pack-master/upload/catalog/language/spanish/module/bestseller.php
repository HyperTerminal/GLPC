<?php
// Heading 
$_['heading_title'] = 'Más vendidos';

// Text
$_['text_reviews']  = 'Basado en %s opiniones.';  
?>