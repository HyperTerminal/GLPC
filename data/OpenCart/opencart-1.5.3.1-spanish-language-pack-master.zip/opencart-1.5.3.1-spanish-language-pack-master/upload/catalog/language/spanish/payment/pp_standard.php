<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'Razón';
$_['text_testmode']	= 'Cuidado: El método de pago está en \'Sandbox Mode\' (modo pruebas). No se cargará en tu cuenta.';
$_['text_total']	= 'Envío, manipulación, descuentos & impuestos';
?>