<?php
// Text
$_['text_subject']  = 'Te han enviado un Vale de regalo de %s';
$_['text_greeting'] = 'Enhorabuena, has recibido un vale de regalo por un valor de %s';
$_['text_from']     = 'Este vale de regalo te lo ha enviado  %s';
$_['text_message']  = 'Con el siguiente mensaje';
$_['text_redeem']   = 'Para utilizar este vale de regalo, escribe el código del vale que es <b>%s</b> luego haz click en el enlace inferior y compra el producto en el que desees utilizar este vale. Puedes utilizar este código de vale en la cesta de la compra antes de realizar la compra.';
$_['text_footer']   =  'Por favor contesta este correo si tienes alguna duda.';
?>