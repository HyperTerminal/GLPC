<?php
// Text
$_['text_title']       = 'Tarifa fija';
$_['text_description'] = 'Enviío de tarifa fija';
?>