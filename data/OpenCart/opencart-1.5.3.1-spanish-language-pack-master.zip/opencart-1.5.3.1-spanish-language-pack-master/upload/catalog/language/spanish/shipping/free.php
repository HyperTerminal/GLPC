<?php
// Text
$_['text_title']       = 'Envío grauito';
$_['text_description'] = 'Envío grauito';
?>