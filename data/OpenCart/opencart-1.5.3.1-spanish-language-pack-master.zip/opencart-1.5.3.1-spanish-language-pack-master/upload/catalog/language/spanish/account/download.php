<?php
// Heading 
$_['heading_title']   = 'Cuenta de Descargas';

// Text
$_['text_account']    = 'Cuenta';
$_['text_downloads']  = 'Descargas';
$_['text_order']      = 'ID del pedido:';
$_['text_date_added'] = 'Fecha de alta:';
$_['text_name']       = 'Nombre:';
$_['text_remaining']  = 'Restantes:';
$_['text_size']       = 'Tamaño:';
$_['text_empty']      = 'No has hecho pedidos de descarga con anterioridad!';
?>