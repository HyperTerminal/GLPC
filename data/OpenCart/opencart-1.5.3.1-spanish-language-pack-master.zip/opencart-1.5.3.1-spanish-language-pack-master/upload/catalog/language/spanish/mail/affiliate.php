<?php
// Text
$_['text_subject']  = '%s - Programa de afiliados';
$_['text_welcome']  = 'Gracias por unirte al programa de afiliados %s!';
$_['text_approval'] = 'Tu cuenta debe ser aprobada antes de que puedas entrar. Una vez aprobada puedes entrar usando tu dirección de email y tu contraseña a través de nuestra web o de la siguiente dirección:';
$_['text_services'] = 'Una vez identificado, podrás generar códigos de seguimiento, seguir el pago de comisiones y editar la información de tu cuenta.';
$_['text_thanks']   = 'Gracias,';
?>