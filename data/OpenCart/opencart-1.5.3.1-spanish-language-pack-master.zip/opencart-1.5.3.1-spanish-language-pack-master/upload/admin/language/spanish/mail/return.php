<?php
// Text
$_['text_subject']       = '%s - Actualización de devolución %s';
$_['text_return_id']     = 'ID de devolución:';
$_['text_date_added']    = 'Fecha de devolución:';
$_['text_return_status'] = 'YTu devolución ha sido actualizado al siguiente estado:';
$_['text_comment']       = 'Los comentarios para tu devolución son:';
$_['text_footer']        = 'Por favor contesta a este email si tienes alguna duda.';
?>
