<?php
// Text
$_['text_approve_subject']      = '%s - Tu cuenta de afiliado ha sido activada!';
$_['text_approve_welcome']      = 'Bienvenido y gracias por registrarte en %s!!';
$_['text_approve_login']        = 'Tu cuenta ha sido creada, ya puedes entrar usando tu dirección de email y tu contraseña a través de la siguiente dirección:';
$_['text_approve_services']     = 'Una vez conectado podrás crear códigos de seguimiento, localizar pagos de comisiones y editar la información de tu cuenta.';
$_['text_approve_thanks']       = 'Gracias,';
$_['text_transaction_subject']  = '%s - Comisión de afiliados';
$_['text_transaction_received'] = 'Has recibido %s comisiones!';
$_['text_transaction_total']    = 'La cantidad total de comisiones es %s.';
?>
