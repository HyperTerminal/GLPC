<?php
// Heading
$_['heading_title']     = 'Métodos de pago';

// Text
$_['text_install']      = 'Instalar';
$_['text_uninstall']    = 'Destinstalar';

// Column
$_['column_name']       = 'Método de pago';
$_['column_status']     = 'Estatus';
$_['column_sort_order'] = 'Orden de aparición';
$_['column_action']     = 'Acción';

// Error
$_['error_permission']  = 'Cuidado: No tienes permisos para modificar métodos de pago';
?>
