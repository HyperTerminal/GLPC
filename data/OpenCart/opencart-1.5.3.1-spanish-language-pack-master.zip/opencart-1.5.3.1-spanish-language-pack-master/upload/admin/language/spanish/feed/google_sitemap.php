<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Feeds del Producto';
$_['text_success']     = 'Éxito: has modificado el feed de Google Sitemap!!';

// Entry
$_['entry_status']     = 'Estatus:';
$_['entry_data_feed']  = 'Url feed de datos:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el feed de Google Sitemap!';
?>
