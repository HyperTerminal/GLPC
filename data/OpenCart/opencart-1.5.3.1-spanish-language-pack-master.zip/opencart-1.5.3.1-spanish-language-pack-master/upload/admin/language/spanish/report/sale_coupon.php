<?php
// Heading
$_['heading_title']    = 'Reporte de Cupones';

// Column
$_['column_name']      = 'Nombre del Cupón';
$_['column_code']      = 'Códig';
$_['column_orders']    = 'Pedidos';
$_['column_total']     = 'Total';
$_['column_action']    = 'Acción';

// Entry
$_['entry_date_start'] = 'Fecha de Inicio:';
$_['entry_date_end']   = 'Fecha de Terminación:';
?>
