<?php
// Heading
$_['heading_title']         = 'Informe de los Pedidos de los clientes';

// Text
$_['text_all_status']       = 'Todos los Estados';

// Column
$_['column_customer']       = 'Nombre del Cliente';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Grupo de clientes';
$_['column_status']         = 'Estado';
$_['column_orders']         = 'No. de Pedidos';
$_['column_products']       = 'No. de Productos';
$_['column_total']          = 'Total';
$_['column_action']         = 'Acción';

// Entry
$_['entry_date_start']      = 'Fecha de Inicio:';
$_['entry_date_end']        = 'Fecha de Terminación:';
$_['entry_status']          = 'Estado del Pedido:';
?>
