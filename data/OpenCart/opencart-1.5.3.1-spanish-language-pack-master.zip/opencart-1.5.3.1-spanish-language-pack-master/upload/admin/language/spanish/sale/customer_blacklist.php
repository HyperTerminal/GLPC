<?php
// Heading
$_['heading_title']    = 'Lista negra de IP\'s de Clientes';

// Text
$_['text_success']     = 'Éxito:: has modificado Lista negra de IP\'s de Clientes!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Clientes';
$_['column_action']    = 'Acción';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = 'Cuidado:: No tienes permisos suficientes para modificar la lista negra!';
$_['error_ip']         = 'IP debe tener entre 1 y 15 carácteres!';
?>
