<?php
// Heading
$_['heading_title']    = 'Priežiūra';

// Text
$_['text_maintenance'] = 'Maintenance';
$_['text_message']     = '<h1 style="text-align:center;">Šiuo metu vyksta planuota techninė priežiūra. <br/>Mes stengiamės sugrįžti kuo greičiau. Prašome apsilankykite vėliau.</h1>';
?>