<?php
// Text
$_['text_home']           = 'Pradžia';
$_['text_wishlist']       = 'Trokštamos prekės (%s)';
$_['text_shopping_cart']  = 'Pirkinių krepšelis';
$_['text_search']         = 'Paieška';
$_['text_welcome']        = 'Sveiki! <a href="%s">Prisijunkite</a> arba <a href="%s">užsiregistruokite</a>.';
$_['text_logged']         = 'Jūs prisijungėte kaip <a href="%s">%s</a> <b>(</b> <a href="%s">atsijungti</a> <b>)</b>';
$_['text_account']        = 'Mano paskyra';
$_['text_checkout']       = 'Pateikti užsakymą';
?>