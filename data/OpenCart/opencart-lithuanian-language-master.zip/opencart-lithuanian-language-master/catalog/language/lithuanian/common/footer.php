<?php
// Text
$_['text_information']  = 'Informacija';
$_['text_service']      = 'Klientų aptarnavimas';
$_['text_extra']        = 'Papildomai';
$_['text_contact']      = 'Susisiekite su mumis';
$_['text_return']       = 'Prekių grąžinimas';
$_['text_sitemap']      = 'Tinklalapio struktūra';
$_['text_manufacturer'] = 'Prekiniai ženklai';
$_['text_voucher']      = 'Dovanų čekiai';
$_['text_affiliate']    = 'Partnerystė';
$_['text_special']      = 'Specialūs pasiūlymai';
$_['text_account']      = 'Paskyra';
$_['text_order']        = 'Užsakymų istorija';
$_['text_wishlist']     = 'Trokštamos prekės';
$_['text_newsletter']   = 'Naujienlaiškis';
$_['text_powered']      = '%s &copy; %s<br />Veikia su <a href="http://www.opencart.com">OpenCart</a>';
?>