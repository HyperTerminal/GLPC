<?php
// Heading 
$_['heading_title'] = 'Informacija';

// Text
$_['text_contact']  = 'Susisiekite su mumis';
$_['text_sitemap']  = 'Tinklalapio struktūra';
?>