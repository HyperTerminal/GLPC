<?php
// Heading 
$_['heading_title']    = 'Paskyra';

// Text
$_['text_register']    = 'Registruotis';
$_['text_login']       = 'Prisijungti';
$_['text_logout']      = 'Atsijungti';
$_['text_forgotten']   = 'Slaptažodžio priminimas';
$_['text_account']     = 'Paskyra';
$_['text_edit']        = 'Redaguoti paskyrą';
$_['text_password']    = 'Slaptažodis';
$_['text_address']     = 'Adresų knygelė';
$_['text_wishlist']    = 'Trokštamų pirkinių sąrasas';
$_['text_order']       = 'Užsakymų istorija';
$_['text_download']    = 'Parsisiuntimai';
$_['text_return']      = 'Grąžinimo prašymai';
$_['text_transaction'] = 'Transakcijos';
$_['text_newsletter']  = 'Naujienlaiškiai';
?>
