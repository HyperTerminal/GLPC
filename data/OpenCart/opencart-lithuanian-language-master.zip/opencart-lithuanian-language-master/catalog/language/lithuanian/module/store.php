<?php
// Heading 
$_['heading_title'] = 'Pasirinkite parduotuvę';

// Text
$_['text_default']  = 'Numatytoji';
$_['text_store']    = 'Prašome pasirinkite parduotuvę, kurią norite aplankyti.';
?>