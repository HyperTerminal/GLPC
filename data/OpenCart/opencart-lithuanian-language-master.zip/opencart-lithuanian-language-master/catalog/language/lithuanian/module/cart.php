<?php
// Heading 
$_['heading_title'] = 'Pirkinių krepšelis';

// Text
$_['text_items']    = 'Prekių: %s (%s)';
$_['text_empty']    = 'Jūsų pirkinių krepšelis yra tuščias.';
$_['text_cart']     = 'Peržiūrėti krepšelį';
$_['text_checkout'] = 'Pateikti užsakymą';
?>