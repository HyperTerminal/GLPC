<?php
// Heading 
$_['heading_title'] = 'Specialūs pasiūlymai';

// Text
$_['text_reviews']  = 'Remiantis %s atsiliepimų.'; 
?>