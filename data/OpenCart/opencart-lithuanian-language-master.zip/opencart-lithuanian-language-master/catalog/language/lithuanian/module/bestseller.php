<?php
// Heading 
$_['heading_title'] = 'Perkamiausios prekės';

// Text
$_['text_reviews']  = 'Remiantis %s atsiliepimų.'; 
?>