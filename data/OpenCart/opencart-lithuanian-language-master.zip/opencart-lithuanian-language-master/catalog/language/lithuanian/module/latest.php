<?php
// Heading 
$_['heading_title'] = 'Naujausios';

// Text
$_['text_reviews']  = 'Remiantis %s atsiliepimų.'; 
?>