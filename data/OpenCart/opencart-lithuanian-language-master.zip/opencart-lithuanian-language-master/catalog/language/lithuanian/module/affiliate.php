<?php
// Heading 
$_['heading_title']    = 'Partnerystė';

// Text
$_['text_register']    = 'Registruotis';
$_['text_login']       = 'Prisijungti';
$_['text_logout']      = 'Atsijungti';
$_['text_forgotten']   = 'Slaptažodžio priminimas';
$_['text_account']     = 'Paskyra';
$_['text_edit']        = 'Redaguoti paskyrą';
$_['text_password']    = 'Slaptažodis';
$_['text_payment']     = 'Mokėjimo būdai';
$_['text_tracking']    = 'Partnerio sekimo kodas';
$_['text_transaction'] = 'Transakcijos';
?>
