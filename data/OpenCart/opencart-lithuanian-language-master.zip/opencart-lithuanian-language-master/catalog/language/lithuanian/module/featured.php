<?php
// Heading 
$_['heading_title'] = 'Rekomenduoja';

// Text
$_['text_reviews']  = 'Remiantis %s atsiliepimų.'; 
?>