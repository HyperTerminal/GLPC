<?php
// Heading 
$_['heading_title']    = 'Partnerio sekimas';

// Text
$_['text_account']     = 'Paskyra';
$_['text_description'] = 'To make sure you get paid for referrals you send to us we need to track the referral by placing a tracking code in the URL\'s linking to us. You can use the tools below to generate links to the %s web site.';
$_['text_code']        = '<b>Jūsų sekimas kodas:</b>';
$_['text_generator']   = '<b>Sekimo nuorodos generatorius</b><br />Įrašykite prekės pavadinimą partnerio nuorodai gauti:';
$_['text_link']        = '<b>Sekimo nuoroda:</b>';
?>