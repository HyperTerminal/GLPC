<?php
// Heading 
$_['heading_title'] = 'Atsijungti';

// Text
$_['text_message']  = '<p>Jūs atsijungėte nuo partnerio paskyros.</p>';
$_['text_account']  = 'Paskyra';
$_['text_logout']   = 'Atsijungti';
?>