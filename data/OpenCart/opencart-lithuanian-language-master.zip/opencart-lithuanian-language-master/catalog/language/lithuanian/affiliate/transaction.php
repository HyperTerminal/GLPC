<?php
// Heading 
$_['heading_title']      = 'Transakcijos';

// Column
$_['column_date_added']  = 'Data';
$_['column_description'] = 'Aprašymas';
$_['column_amount']      = 'Suma (%s)';

// Text
$_['text_account']       = 'Paskyra';
$_['text_transaction']   = 'Transakcijos';
$_['text_balance']       = 'Jūsų dabartinis balansas yra:';
$_['text_empty']         = 'Jūs neturite transakcijų.';
?>