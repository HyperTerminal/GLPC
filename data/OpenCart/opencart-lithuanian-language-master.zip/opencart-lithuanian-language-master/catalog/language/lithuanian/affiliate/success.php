<?php
// Heading
$_['heading_title'] = 'Jūsų partnerio paskyra sukurta!';

// Text 
$_['text_approval'] = '<p>Dėkojame už partnerio registraciją parduotuvėje %s!</p><p>Jums bus pranešta elektroniniu paštu, kai jūsų paskyra buvo aktyvuota parduotuvės savininku.</p><p>Jei turite klausimų dėl šios partnerystės sistemos, prašome <a href="%s">kreiptis į parduotuvės savininką</a>.</p>';
$_['text_account']  = 'Paskyra';
$_['text_success']  = 'Sukurta';
?>