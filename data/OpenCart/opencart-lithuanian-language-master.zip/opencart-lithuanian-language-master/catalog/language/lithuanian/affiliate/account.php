<?php
// Heading 
$_['heading_title']        = 'Partnerio paskyra';

// Text
$_['text_account']         = 'Paskyra';
$_['text_my_account']      = 'Paskyra';
$_['text_my_tracking']     = 'Sekimo informacija';
$_['text_my_transactions'] = 'Transakcijos';
$_['text_edit']            = 'Redaguoti paskyros informaciją';
$_['text_password']        = 'Slaptažodžio keitimas';
$_['text_payment']         = 'Mokėjimo būdo keitimas';
$_['text_tracking']        = 'Partnerio sekimo kodas';
$_['text_transaction']     = 'Transakcijų istorija';
?>