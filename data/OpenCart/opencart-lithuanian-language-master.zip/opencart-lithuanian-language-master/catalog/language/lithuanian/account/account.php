<?php
// Heading 
$_['heading_title']      = 'Paskyra';

// Text
$_['text_account']       = 'Paskyra';
$_['text_my_account']    = 'Mano paskyra';
$_['text_my_orders']     = 'Mano užsakymai';
$_['text_my_newsletter'] = 'Naujienlaiškis';
$_['text_edit']          = 'Redaguoti paskyros informaciją';
$_['text_password']      = 'Slaptažodžio keitimas';
$_['text_address']       = 'Redaguoti adresų knygelės įrašus';
$_['text_wishlist']      = 'Redaguoti trokštamų pirkinių sąrasą';
$_['text_order']         = 'Peržiūrėti užsakymų istoriją';
$_['text_download']      = 'Parsisiuntimai';
$_['text_reward']        = 'Lojalumo taškai'; 
$_['text_return']        = 'Peržiūrėti grąžinimo prašymus'; 
$_['text_transaction']   = 'Transakcijos'; 
$_['text_newsletter']    = 'Užsisakyti / atsisakyti naujienlaiškių';
?>