<?php
// Heading 
$_['heading_title']    = 'Naujienlaiškių užsakymas';

// Text
$_['text_account']     = 'Paskyra';
$_['text_newsletter']  = 'Naujienlaiškiai';
$_['text_success']     = 'Atlikta: naujienlaiškių užsakymas atnaujintas.';

// Entry
$_['entry_newsletter'] = 'Gauti:';
?>
