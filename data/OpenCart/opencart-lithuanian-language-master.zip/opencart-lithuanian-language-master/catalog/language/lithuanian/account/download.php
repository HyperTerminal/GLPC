<?php
// Heading 
$_['heading_title']   = 'Parsisiuntimai';

// Text
$_['text_account']    = 'Paskyra';
$_['text_downloads']  = 'Parsisiuntimai';
$_['text_order']      = 'Užsakymo Nr.:';
$_['text_date_added'] = 'Data:';
$_['text_name']       = 'Pavadinimas:';
$_['text_remaining']  = 'Liko:';
$_['text_size']       = 'Dydis:';
$_['text_empty']      = 'Jūs dar neturite užsakymų su parsisiuntimais.';
?>