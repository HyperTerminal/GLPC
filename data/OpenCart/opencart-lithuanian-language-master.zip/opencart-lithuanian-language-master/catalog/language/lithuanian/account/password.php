<?php
// Heading 
$_['heading_title']  = 'Slaptažodžio keitimas';

// Text
$_['text_account']   = 'Paskyra';
$_['text_password']  = 'Jūsų slaptažodis';
$_['text_success']   = 'Atlikta: slaptažodis atnaujintas.';

// Entry
$_['entry_password'] = 'Slaptažodis:';
$_['entry_confirm']  = 'Pakartokite slaptažodį:';

// Error
$_['error_password'] = 'Slaptažodis turi būti nuo 4 iki 20 simbolių.';
$_['error_confirm']  = 'Slaptažodžiai nesutampa.';
?>