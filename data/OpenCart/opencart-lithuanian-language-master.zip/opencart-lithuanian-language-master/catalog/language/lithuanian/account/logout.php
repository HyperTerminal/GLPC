<?php
// Heading 
$_['heading_title'] = 'Atsijungti';

// Text
$_['text_message']  = '<p>Jūs atsijungėte nuo savo paskyros. Dabar galite saugiai palikti kompiuterį.</p><p>Jūsų pirkinių krepšelis buvo išsaugotas ir jo turinys bus sugrąžintas, kai vėl prisijungsite prie savo paskyros.</p>';
$_['text_account']  = 'Paskyra';
$_['text_logout']   = 'Atsijungti';
?>