<?php
// Heading 
$_['heading_title']   = 'Pamiršote savo slaptažodį?';

// Text
$_['text_account']    = 'Paskyra';
$_['text_forgotten']  = 'Slaptažodžio priminimas';
$_['text_your_email'] = 'Jūsų el. pašto adresas';
$_['text_email']      = 'Įveskite savo el. pašto adresą, susietą su jūsų paskyrą. Paspauskite tęsti ir slaptažodis buvo išsiųstas jūsų el. pašto adresu.';
$_['text_success']    = 'Atlikta: naujas slaptažodis buvo išsiųstas jūsų el. pašto adresu.';

// Entry
$_['entry_email']     = 'El. pašto adresas:';

// Error
$_['error_email']     = 'Dėmesio: šis el. pašto adresas nebuvo registruotas.';
?>