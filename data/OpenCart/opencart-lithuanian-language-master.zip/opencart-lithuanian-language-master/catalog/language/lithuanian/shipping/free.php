<?php
// Text
$_['text_title']       = 'Nemokamas pristatymas';
$_['text_description'] = 'Nemokamas pristatymas';
?>