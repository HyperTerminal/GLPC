<?php
// Heading
$_['heading_title'] = 'Puslapis nerastas';

// Text
$_['text_error']    = 'Puslapis nerastas.';
?>