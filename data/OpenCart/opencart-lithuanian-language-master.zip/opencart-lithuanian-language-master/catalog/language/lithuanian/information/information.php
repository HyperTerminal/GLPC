<?php
// Text
$_['text_error'] = 'Informacijos puslapis nerastas.';
?>