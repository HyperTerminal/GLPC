<?php
// Heading
$_['heading_title']    = 'Tinklalapio struktūra';
 
// Text
$_['text_special']     = 'Specialūs pasiūlymai';
$_['text_account']     = 'Paskyra';
$_['text_edit']        = 'Paskyros informacija';
$_['text_password']    = 'Slaptažodis';
$_['text_address']     = 'Adresų knyga';
$_['text_history']     = 'Užsakymų istorija';
$_['text_download']    = 'Parsisiuntimai';
$_['text_cart']        = 'Pirkinių krepšelis';
$_['text_checkout']    = 'Pateikti užsakymą';
$_['text_search']      = 'Paieška';
$_['text_information'] = 'Informacija';
$_['text_contact']     = 'Susisiekite su mumis';
?>
