<?php
// Text
$_['text_subject']  = '%s - Naujas slaptažodis';
$_['text_greeting'] = '%s prašė naujo slaptažodžio.';
$_['text_password'] = 'Jūsų naujas slaptažodis:';
?>