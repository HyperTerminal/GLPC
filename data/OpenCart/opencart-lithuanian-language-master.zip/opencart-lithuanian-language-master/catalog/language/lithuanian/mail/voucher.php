<?php
// Text
$_['text_subject']  = '%s išsiuntė jums dovanų čekį';
$_['text_greeting'] = 'Sveikiname, jūs gavote dovanų čekį kurio vertė %s';
$_['text_from']     = 'Šį dovanų čekį jums atsiuntė %s';
$_['text_message']  = 'Su pranešimu';
$_['text_redeem']   = 'Norėdami panaudoti šį dovanų čekį, užrašykite išpirkimo kodą, kuris yra <b>%s</b>, tada paspauskite žemiau esančią nuorodą ir panaudokite šį dovanų čekį perkant norimą prekę. Jūs galite įrašyti dovanų čekio kodą krepšelio puslapyje prieš užsakymo pateikimą.';
$_['text_footer']   = 'Jei turite kokių nors klausimų, prašome atsakykite į šį laišką.';
?>