<?php
// Text
$_['text_subject']  = '%s - Partnerystės programa';
$_['text_welcome']  = 'Dėkojame už partnerio registraciją parduotuvėje %s!';
$_['text_approval'] = 'Jūsų paskyra turi būti patvirtinta, kad galėtumėte prisijungti. Patvirtinus paskyrą, galėsite prisijungti naudojant savo elektroninio pašto adresą ir slaptažodį, apsilankius tinklalapyje arba paspaudus nuorodą:';
$_['text_services'] = 'Po prisijungimo jūs galėsite sukurti sekimo nuorodas, sekti komisinius mokėjimus ir redaguoti savo paskyros informaciją.';
$_['text_thanks']   = 'Ačiū,';
?>