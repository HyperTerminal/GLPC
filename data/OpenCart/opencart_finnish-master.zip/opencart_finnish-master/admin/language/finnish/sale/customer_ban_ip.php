<?php
// Heading
$_['heading_title']    = 'Customer Ban IP';

// Text
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Column
$_['column_ip']        = 'IP';
$_['column_customer']  = 'Asiakkaat';
$_['column_action']    = 'Toimenpide';

// Entry
$_['entry_ip']         = 'IP:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_ip']         = 'IP must be between 1 and 15 characters!';
?>