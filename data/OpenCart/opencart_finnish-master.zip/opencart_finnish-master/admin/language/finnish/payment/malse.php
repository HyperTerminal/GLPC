<?php
// Text
$_['text_title'] = 'Luottokortti / Pankkikortti (Mal\'s e-commerce)';
?>