<?php
// Heading
$_['heading_title']      = 'Maksutavat';

// Text
$_['text_install']       = 'Asenna';
$_['text_uninstall']     = 'Poista';

// Column
$_['column_name']        = 'Maksutapa';
$_['column_status']      = 'Tila';
$_['column_sort_order']  = 'J&auml;rjestys';
$_['column_action']      = 'Toimenpide';
$_['column_development'] = 'Kehityksen tila';

?>