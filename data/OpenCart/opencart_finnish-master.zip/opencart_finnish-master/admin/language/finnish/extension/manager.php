<?php
// Heading 
$_['heading_title']    = 'Laajennusosien hallinta';

// Text
$_['text_success']     = 'Suorite: You have installed your extension!';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_upload']     = 'Tiedoston lautaus on pakollinen!';
$_['error_filetype']   = 'Varoitus: Tiedostotyyppi ei kelpaa!';
?>