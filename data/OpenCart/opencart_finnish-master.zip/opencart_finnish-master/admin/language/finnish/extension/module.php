<?php
// Heading
$_['heading_title']      = 'Moduulit';

// Text
$_['text_install']       = 'Asenna';
$_['text_uninstall']     = 'Poista';
$_['text_left']          = 'Vasemmalla';
$_['text_right']         = 'Oikealla';

// Column
$_['column_name']        = 'Moduulin nimi';
$_['column_position']    = 'Sijainti';
$_['column_status']      = 'Tila';
$_['column_sort_order']  = 'J&auml;rjestys';
$_['column_action']      = 'Toimenpide';
?>