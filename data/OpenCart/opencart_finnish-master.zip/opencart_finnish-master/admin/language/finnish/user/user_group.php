<?php
// Heading
$_['heading_title']    = 'K&auml;ytt&auml;j&auml;ryhm&auml;t';

// Text
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Column
$_['column_name']      = 'K&auml;ytt&auml;j&auml;ryhm&auml;n nimi';
$_['column_action']    = 'Toimenpide';

// Entry
$_['entry_name']       = 'K&auml;ytt&auml;j&auml;ryhm&auml;n nimi:';
$_['entry_access']     = 'P&auml;&auml;syoikeudet:';
$_['entry_modify']     = 'Muokkausoikeudet:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name']       = 'K&auml;ytt&auml;j&auml;ryhm&auml;n nimi -sy&ouml;tteen on oltava 3-64 merkki&auml; pitk&auml;!';
$_['error_user']       = 'Varoitus: Valittua k&auml;ytt&auml;j&auml;ryhm&auml;&auml; ei voi poistaa, koska se on liitetty %s k&auml;ytt&auml;j&auml;lle!';
?>
