<?php
$_['lang_title']                    = 'OpenBay Pro for eBay';
$_['lang_heading']                  = 'eBay Overview';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Asetukset';
$_['lang_heading_sync']             = 'Synkronoi';
$_['lang_heading_account']          = 'My Account';
$_['lang_heading_links']            = 'Item links';
$_['lang_heading_stock_report']     = 'Stock report';
$_['lang_heading_item_import']      = 'Import items';
$_['lang_heading_order_import']     = 'Import orders';
$_['lang_heading_adds']             = 'Installed add-ons';
$_['lang_heading_summary']          = 'eBay summary';
$_['lang_heading_profile']          = 'Profiles';
$_['lang_heading_template']         = 'Templates';
$_['lang_heading_ebayacc']          = 'eBay account';
$_['lang_heading_register']         = 'Register here';
