<?php
$_['lang_openbay']              = 'OpenBay Pro';
$_['lang_page_title']           = 'OpenBay Pro for eBay';
$_['lang_ebay']                 = 'eBay';
$_['lang_heading']              = 'Lis&auml;paketit';
$_['lang_addon_desc']           = 'Lis&auml;paketit ovat moduuleita, jotka lis&auml;&auml;v&auml;t k&auml;ytett&auml;vyytt&auml; OpenBay Pro.';
$_['lang_addon_name']           = 'Lis&auml;paketin nimi';
$_['lang_addon_version']        = 'Versio';
$_['lang_addon_none']           = 'Lis&auml;paketteja ei ole asennettu';
$_['lang_error_validation']     = 'Rekister&ouml; API merkki ja k&auml;ytt&ouml;&ouml;nota moduuli.';
$_['lang_btn_return']           = 'Palauta';

?>
