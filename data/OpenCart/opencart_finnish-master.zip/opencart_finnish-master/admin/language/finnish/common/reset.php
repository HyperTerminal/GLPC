<?php

$_['heading_title'] = 'Resetoi salasana';
$_['text_reset'] = 'Resetoi salasanasi!';
$_['text_password'] = 'Anna uusi salasana jota haluat k&auml;ytt&auml;&auml;.';
$_['text_success'] = 'Suorite: Salasanasi on onnistuneesti resetoitu.';
$_['entry_password'] = 'Salasana:';
$_['entry_confirm'] = 'Vahvista salasana:';
$_['error_password'] = 'Salasanan on oltava 5 - 20 merkki&auml; pitk&auml;!';
$_['error_confirm'] = 'Salasanan vahvistus ei vastaa salasanaa!';

?>