<?php
// header
$_['heading_title']  = 'Yll&auml;pito';

// Text
$_['text_heading']   = 'Yll&auml;pito';
$_['text_login']     = 'Kirjaudu yll&auml;pitoon.';

// Entry
$_['entry_username'] = 'K&auml;ytt&auml;j&auml;nimi:';
$_['entry_password'] = 'Salasana:';

// Button
$_['button_login']   = 'Kirjaudu sis&auml;&auml;n';

// Error
$_['error_login']    = 'K&auml;ytt&auml;j&auml;nimi ja/tai salasana ei kelpaa.';
$_['error_token']    = 'V&auml;&auml;r&auml; istunto. Kirjaudu uudestaan.';
?>
