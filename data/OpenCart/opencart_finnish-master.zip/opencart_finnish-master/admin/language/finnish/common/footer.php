<?php
// Text
$_['text_footer'] = '<a href="http://www.opencart.com">OpenCart</a> &copy; Kaikki oikeudet pid&auml;tet&auml;&auml;n.<br />Versio %s';
?>