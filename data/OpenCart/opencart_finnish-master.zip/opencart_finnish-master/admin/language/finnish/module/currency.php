<?php
// Heading
$_['heading_title']    = 'Valuutta';

// Text
$_['text_module']      = 'Moduulit';
$_['text_success']     = 'Suorite: Moduulin Valuutta muokkaaminen tehty!';
$_['text_left']        = 'Vasemmalla';
$_['text_right']       = 'Oikealla';

// Entry
$_['entry_position']   = 'Sijainti:';
$_['entry_status']     = 'Tila:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>