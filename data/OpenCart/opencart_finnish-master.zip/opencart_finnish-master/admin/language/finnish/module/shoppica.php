<?php
// Heading
$_['heading_title']    = 'Shoppica Theme CP';

// Text
$_['text_module']      = 'Moduulit';
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';
$_['text_left']        = 'Vasen';
$_['text_right']       = 'Oikea';

// Entry
$_['entry_position']   = 'Sijainti:';
$_['entry_status']     = 'Tila:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';

$_['entry_footer_info_title'] = 'Title:';
$_['entry_footer_info_text']  = 'Text:';
$_['entry_twitter_username']  = 'K&auml;ytt&auml;j&auml;tunnus:';
$_['entry_facebook_id']       = 'ID:';
$_['entry_skypename']         = 'Skype';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>