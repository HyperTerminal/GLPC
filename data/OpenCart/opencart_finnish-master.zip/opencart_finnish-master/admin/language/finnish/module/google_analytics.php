<?php
// Heading
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_module']      = 'Moduulit';
$_['text_success']     = 'Suorite: Moduulin Google Analytics muokkaaminen tehty!';

// Entry
$_['entry_code']       = 'Analytics koodi:<br /><span class="help">Kirjaudu <a onclick="window.open(\'http://www.google.com/analytics/\');"><u>Google Analytics</u></a> tilille ja sivustoprofiilin luonnin j&auml;lkeen kopioi ja liit&auml; t&auml;h&auml;n koodi.</span>';
$_['entry_status']     = 'Tila:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_code']       = 'Analytics koodi on pakollinen tieto';
?>