<?php

$_['button_add_folder'] = 'Add New Folder';
$_['button_add_language'] = 'Add New Language';
$_['button_cancel'] = 'Keskeyt&auml;';
$_['button_edit_backend'] = 'Edit Back End';
$_['button_edit_frontend'] = 'Edit Front End';
$_['button_remove'] = 'Poista';
$_['button_save'] = 'Tallenna';
$_['entry_field_type'] = 'Edit Field:';
$_['entry_folder'] = 'Folder: ';
$_['entry_language'] = 'Language: ';
$_['entry_rows'] = 'Rows: ';
$_['entry_status'] = 'Tila:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['heading_title'] = 'Language Editor';
$_['tab_backend'] = 'Back End';
$_['tab_frontend'] = 'Front End';
$_['text_disabled'] = 'Ei k&auml;yt&ouml;ss&auml;';
$_['text_enabled'] = 'K&auml;yt&ouml;ss&auml;';
$_['text_folder_list'] = 'List of Folders';
$_['text_home'] = 'Etusivu';
$_['text_input'] = 'input';
$_['text_language_list'] = 'List of Languages';
$_['text_module'] = 'Moduulit';
$_['text_select'] = 'Valitse';
$_['text_success'] = 'Suorite: Asetukset on tallennettu onnistuneesti!';
$_['text_textarea'] = 'textarea';

?>