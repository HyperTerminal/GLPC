<?php
// Heading
$_['heading_title']    = 'Quick Info';

// Text
$_['text_module']      = 'Moduulit';
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Entry
$_['entry_status']     = 'Tila:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>