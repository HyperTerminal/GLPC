<?php

$_['heading_title'] = 'Asiakkaan palkintopiste raportti';
$_['column_customer'] = 'Asiakkaan nimi';
$_['column_email'] = 'S&auml;hk&ouml;postiosoite';
$_['column_customer_group'] = 'Asiakasryhm&auml;';
$_['column_status'] = 'Tila';
$_['column_points'] = 'Pisteet';
$_['column_orders'] = 'Tilaukset';
$_['column_total'] = 'Yhteens&auml;';
$_['column_action'] = 'Toiminta';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';

?>