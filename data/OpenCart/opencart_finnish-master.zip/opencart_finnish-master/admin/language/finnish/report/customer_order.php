<?php

$_['heading_title'] = 'Asiakkaan tilausraportti';
$_['text_all_status'] = 'Kaikki tilat';
$_['column_customer'] = 'Asiakkaan nimi';
$_['column_email'] = 'S&auml;hk&ouml;postiosoite';
$_['column_customer_group'] = 'Asiakasryhm&auml;';
$_['column_status'] = 'Tila';
$_['column_orders'] = 'Tilaukset';
$_['column_products'] = 'No. Tuotteet';
$_['column_total'] = 'Yhteens&auml;';
$_['column_action'] = 'Toimenpide';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';
$_['entry_status'] = 'Tilauksen tilanne:';

?>