<?php

$_['heading_title'] = 'Kuponki raportti';
$_['column_name'] = 'Kupongin nimi';
$_['column_code'] = 'Koodi';
$_['column_orders'] = 'Tilaukset';
$_['column_total'] = 'Yhteens&auml;';
$_['column_action'] = 'Toiminta';
$_['entry_date_start']    = 'Alkaen (pvm):';
$_['entry_date_end']      = 'Asti (pvm):';

?>