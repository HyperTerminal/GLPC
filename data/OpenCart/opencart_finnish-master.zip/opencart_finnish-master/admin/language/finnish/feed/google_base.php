<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text 
$_['text_feed']        = 'Product Feeds';
$_['text_success']     = 'Suorite: You have modified Google Base feed!';

// Entry
$_['entry_status']     = 'Tila:';
$_['entry_data_feed']  = 'Data Feed Url:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>