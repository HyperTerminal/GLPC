<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = 'Product Feeds';
$_['text_success']     = 'Suorite: You have modified Google Sitemap feed!';

// Entry
$_['entry_status']     = 'Tila:';
$_['entry_data_feed']  = 'Data Feed Url:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>