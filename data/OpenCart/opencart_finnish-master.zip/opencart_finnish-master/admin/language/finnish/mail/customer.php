<?php
// Text
$_['text_subject']  = '%s - tili on aktivoitu!';
$_['text_welcome']  = '%s kiitt&auml;&auml; rekister&ouml;itymisest&auml;!';
$_['text_login']    = 'K&auml;ytt&auml;j&auml;tunnussi on nyt aktivoitu ja voit kirjautua sis&auml;&auml;n osoitteessa:';
$_['text_services'] = 'Kirjautumisen j&auml;lkeen voit mm. tarkastella tilaushistoriaa tai muokata tilin tietoja.';
$_['text_thanks']   = 'Terveisin,';
?>