<?php

$_['text_subject'] = '%s - Palautus p&auml;ivitys %s';
$_['text_return_id'] = 'Palautus ID:';
$_['text_date_added'] = 'Palautus Pvm:';
$_['text_return_status'] = 'Palautuksesi on p&auml;ivitetty seuraavaan tilaan:';
$_['text_comment'] = 'Kommentit palautuksellesi ovat seuraavanlaiset:';
$_['text_footer'] = 'Vastaa t&auml;h&auml;n viestiin jos sinulla on kysytt&auml;v&auml;&auml;.';

?>