<?php

$_['text_subject'] = '%s - Sopimuusasiakkuus';
$_['text_welcome'] = 'Kiitos kun liityit %s Yhteist&ouml; ohjelmaan!';
$_['text_approval'] = 'K&auml;ytt&auml;j&auml;tunnussi pit&auml;&auml; hyv&auml;ksy&auml; ennen kuin voit kirjautua sis&auml;&auml;n. Kun tilisi on hyv&auml;ksytty voit kirjautua k&auml;ytt&auml;m&auml;ll&auml; s&auml;hk&ouml;postiosoitettasi ja salasanaasi vierailemalla seuraavassa osoitteessa:';
$_['text_services'] = 'Kun kirjaudut sis&auml;&auml;n, voit luoda seurantakoodeja,hallita kommissioiden maksamista ja muokata tilisi tietoja.';
$_['text_thanks'] = 'Kiitos,';

?>