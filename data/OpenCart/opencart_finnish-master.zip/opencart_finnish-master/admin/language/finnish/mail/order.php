<?php

$_['text_subject'] = '%s - tilauksen tilannetieto, tilausnumero %s';
$_['text_order'] = 'Tilausnumero:';
$_['text_date_added'] = 'Tilauspvm:';
$_['text_order_status'] = 'Tilauksen tilanne:';
$_['text_comment'] = 'Kommentit:';
$_['text_invoice'] = 'N&auml;hd&auml;ksesi tilauksen, klikkaa alla olevaa linkki&auml;:';
$_['text_footer'] = 'Vastaa t&auml;h&auml;n viestiin, jos sinulla ilmenee kysytt&auml;v&auml;&auml;.';

?>