<?php

$_['heading_title'] = 'Verokannat';
$_['text_percent'] = 'Prosenttim&auml;&auml;r&auml;';
$_['text_amount'] = 'Korjattu m&auml;&auml;r&auml;';
$_['text_success'] = 'Suorite: Muokkasit verokantoja!';
$_['column_name'] = 'Veron nimi';
$_['column_rate'] = 'Veroprosentti';
$_['column_type'] = 'Tyyppi';
$_['column_geo_zone'] = 'Geo Zone';
$_['column_date_added'] = 'Pvm lis&auml;tty';
$_['column_date_modified'] = 'Pvm muokattu';
$_['column_action'] = 'Toiminta';
$_['entry_name'] = 'Veron nimi:';
$_['entry_rate'] = 'Veroprosentti:';
$_['entry_type'] = 'Tyyppi';
$_['entry_customer_group'] = 'Asiakasryhm&auml;:';
$_['entry_geo_zone'] = 'Maanosa:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_tax_rule'] = 'Varoitus: Valittua veron m&auml;&auml;r&auml;&auml; ei voi poistaa koska se on k&auml;yt&ouml;ss&auml; %s veroluokassa!';
$_['error_name'] = 'Veron nimi -sy&ouml;te on oltava 3-32 merkki&auml; pitk&auml;!';
$_['error_rate'] = 'Veroprosentti -sy&ouml;te on pakollinen!';

?>