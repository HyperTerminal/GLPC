<?php
// Heading
$_['heading_title']    = 'Saatavuudet';

// Text
$_['text_success'] = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Column
$_['column_name']      = 'Saatavuuden nimi';
$_['column_action']    = 'Toimenpide';

// Entry
$_['entry_name']       = 'Saatavuuden nimi:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name']       = 'Saatavuuden nimi -sy&ouml;te on oltava 3-32 merkki&auml; pitk&auml;!';
$_['error_product']    = 'Varoitus: Valittua saatavuutta ei voi poistaa, koska se on liitetty %s tuotteeseen!';
$_['error_default']    = 'Varoitus: Valittua saatavuutta ei voi poistaa, koska se on asetettu verkkokaupan oletuarvoksi!';
?>
