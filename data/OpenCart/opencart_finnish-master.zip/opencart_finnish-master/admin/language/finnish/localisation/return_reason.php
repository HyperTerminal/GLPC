<?php

$_['heading_title'] = 'Palautuksien syyt';
$_['text_success'] = 'Suorite: Olet muokannut palautuksien syit&auml;!';
$_['column_name'] = 'Palautuksien syy nimi:';
$_['column_action'] = 'Toimenpide';
$_['entry_name'] = 'Palautuksen syy nimi:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Return Reason Name must be between 3 and 32 characters!';
$_['error_return'] = 'Warning: This return reason cannot be deleted as it is currently assigned to %s returned products!';

?>