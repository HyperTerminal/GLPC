<?php
// Heading
$_['heading_title']    = 'Etusetelit';

// Text
$_['text_total']       = 'Maksusuorite';
$_['text_success']     = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Entry
$_['entry_status']     = 'Tila:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';

// Error
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
?>