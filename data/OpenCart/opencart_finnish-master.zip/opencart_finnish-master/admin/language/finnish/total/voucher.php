<?php

$_['heading_title'] = 'K&auml;yt&auml; lahjakortti';
$_['text_voucher'] = 'Lahjakortti(%s)';
$_['text_success'] = 'Suorite: Lahjakortin alennus on huomioitu tilauksessa!';
$_['entry_voucher'] = 'Anna lahjakortin koodi t&auml;h&auml;n:';
$_['error_voucher'] = 'Varoitus: Lahjakorttitunnus on v&auml;&auml;r&auml; tai -tunnus on jo k&auml;ytetty!';

?>