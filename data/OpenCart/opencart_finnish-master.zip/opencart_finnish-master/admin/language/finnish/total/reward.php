<?php

$_['heading_title'] = 'K&auml;yt&auml; palkintopisteit&auml;(K&auml;ytett&auml;viss&auml;%s)';
$_['text_reward'] = 'Palkintopisteet(%s)';
$_['text_order_id'] = 'Tilaus ID: #%s';
$_['text_success'] = 'Suorite: Palkintopisteiden antama alennus on huomioitu tilauksessa!';
$_['entry_reward'] = 'Kuinka monta pistett&auml; voi k&auml;ytt&auml;&auml; (Maksimissaan %s):';
$_['error_empty'] = 'Warning: Please enter the amount of points you wish to use!';
$_['error_points'] = 'Warning: You don\'t have %s reward points!';
$_['error_maximum'] = 'Warning: The maximum number of points that can be applied is %s!';

?>