<?php

$_['heading_title'] = 'Sivustonlaajuiset alennukset';
$_['text_total'] = 'Tilaus tekee yhteens&auml;';
$_['text_success'] = 'Suorite: Asetukset on tallennettu onnistuneesti!';
$_['entry_total'] = 'Minimi tilausm&auml;&auml;r&auml;n summa:<span class="help">The minimum order value before discount is applied.</span>';
$_['entry_amount'] = 'Alennuksen m&auml;&auml;r&auml;:';
$_['entry_type'] = 'Alennuksen tyyppi:';
$_['entry_date_start'] = 'Alkaen (pvm):<span class="help">Alkaen p&auml;iv&auml;m&auml;&auml;r&auml; jolloin tarjous on voimassa.</span>';
$_['entry_date_end'] = 'Asti (pvm):<span class="help">Asti p&auml;iv&auml;m&auml;&auml;r&auml; jolloin tarjous p&auml;&auml;ttyy.</span>';
$_['entry_status'] = 'Tila:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';

?>