<?php
// Heading
$_['heading_title'] = 'Sivua ei l&ouml;ytynyt!';
// Text
$_['text_not_found'] = 'Sivua ei l&ouml;dy! Ota yhteys yll&auml;pit&auml;j&auml;&auml;n, jos ongelma jatkuu.';
?>