<?php
// Heading
$_['heading_title'] = 'P&auml;&auml;sy kielletty!';
// Text
$_['text_permission'] = 'Sinulla ei ole oikeuksia t&auml;lle sivulle. Ota yhteys yll&auml;pitoon.';
?>
