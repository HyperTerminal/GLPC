<?php
$_['lang_title']                    = 'OpenBay Pro for Amazon';
$_['lang_heading']                  = 'Amazon Yleiskatsaus';
$_['lang_overview']                 = 'Amazon Yleiskatsaus';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Asetukset';
$_['lang_heading_account']          = 'My Account';
$_['lang_heading_links']            = 'Nimikelinkkit';
$_['lang_heading_register']         = 'Rekister&ouml;i';
$_['lang_heading_stock_updates']    = 'Osakep&auml;ivitykset';
$_['lang_heading_saved_listings']   = 'Tallennettu listaan';