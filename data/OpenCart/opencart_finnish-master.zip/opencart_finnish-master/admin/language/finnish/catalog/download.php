<?php

$_['heading_title'] = 'Lataukset';
$_['text_success'] = 'Suorite: Latauksien muokkaaminen tehty!';
$_['column_name'] = 'Latauksen nimi';
$_['column_remaining'] = 'Sallittujen latausten m&auml;&auml;r&auml;';
$_['column_action'] = 'Toimenpide';
$_['entry_name'] = 'Latauksen nimi:';
$_['entry_filename'] = 'Tiedoston nimi:';
$_['entry_mask'] = 'Peite:';
$_['entry_remaining'] = 'Sallittujen latausten m&auml;&auml;r&auml;:';
$_['entry_update'] = 'Jakele jo ostaneille:<br /><span class="help">Jo ostaneet asiakkaat saavat uuden version.</span>';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Nimi -sy&ouml;tteen on oltava 3-64 merkki&auml; pitk&auml;!';
$_['error_filename'] = 'Tiedoston nimi -sy&ouml;tteen on oltava 3-128 merkki&auml; pitk&auml;!';
$_['error_filetype'] = 'Varoitus: Tiedostotyyppi ei kelpaa!';
$_['error_product'] = 'Varoitus: Valittua latausta ei voi poistaa, koska se on liitetty %s tuotteeseen!';

?>