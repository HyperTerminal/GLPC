<?php

$_['heading_title'] = 'Tuotealueet';
$_['text_success'] = 'Suorite: Tuotealueiden muuttaminen tehty!';
$_['text_default'] = 'Oletus';
$_['text_image_manager'] = 'Kuvien hallinta';
$_['column_name'] = 'Tuotealueen nimi';
$_['column_sort_order'] = 'J&auml;rjestys';
$_['column_action'] = 'Toimenpide';
$_['entry_name'] = 'Tuotealueen nimi:';
$_['entry_meta_keywords'] = 'Meta avainsanat:';
$_['entry_meta_description'] = 'Metatiedot:';
$_['entry_description'] = 'Kuvaus:';
$_['entry_status'] = 'Tila:';
$_['entry_category'] = 'Emotuotealue:';
$_['entry_store'] = 'Kaupat, joissa k&#228;yt&#246;ss&#228;:';
$_['entry_keyword'] = 'Hakukone-optimoitu avainsana:';
$_['entry_image'] = 'Kuva:';
$_['entry_sort_order'] = 'J&auml;rjestysnumero:';
$_['error_permission'] = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_name'] = 'Tuotealueen nimi -sy&ouml;tteen on oltava 2-32 merkki&auml; pitk&auml;!';
$_['error_required_data'] = 'Sy&ouml;t&auml; tarvittavat tiedot!';
$_['entry_meta_keyword'] = 'Meta-avainsanat:';
$_['entry_parent'] = 'Is&aumlnt&auml kategoria:';
$_['entry_top'] = 'N&aumlkyvyys p&auml&aumlvalikossa:';
$_['entry_column'] = 'Kolumni:';
$_['text_browse'] = 'Selaa';
$_['text_clear'] = 'Tyhjenn&auml';
$_['entry_layout'] = 'Layout';
?>