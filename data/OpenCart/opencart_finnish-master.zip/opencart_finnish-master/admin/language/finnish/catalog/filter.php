<?php
// Heading
$_['heading_title']     = 'Suodattimet';

// Text
$_['text_success']      = 'Suorite: Asetukset on tallennettu onnistuneesti!';

// Column
$_['column_group']      = 'Suodin ryhm&auml;';
$_['column_sort_order'] = 'J&auml;rjestys';
$_['column_action']     = 'Toimenpide';

// Entry
$_['entry_group']       = 'Ryhm&auml;n nimi:';
$_['entry_name']        = 'Nimi:';
$_['entry_sort_order']  = 'J&auml;rjestysnumero:';

// Error
$_['error_permission']  = 'Varoitus: Sinulla ei ole vaadittavia oikeuksia suorittaa toimintoa!';
$_['error_group']       = 'Suodin ryhm&auml;n nimi -sy&ouml;tteen on oltava 1-64 merkki&auml; pitk&auml;!';
$_['error_name']        = 'Nimi -sy&ouml;tteen on oltava 1-64 merkki&auml; pitk&auml;!';
?>