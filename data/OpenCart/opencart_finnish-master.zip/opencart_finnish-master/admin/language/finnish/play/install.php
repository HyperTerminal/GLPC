<?php
$_['heading_title']                     = 'Play.com (Europe)';
$_['text_edit']                         = 'Muokkaa';
$_['text_install']                      = 'Asenna';
$_['text_uninstall']                    = 'Poista';
$_['text_enabled']                      = 'K&auml;yt&ouml;ss&auml;';
$_['text_disabled']                     = 'Ei k&auml;yt&ouml;ss&auml;';
$_['lang_text_success']                 = 'You have saved your changes to the Play.com extension';