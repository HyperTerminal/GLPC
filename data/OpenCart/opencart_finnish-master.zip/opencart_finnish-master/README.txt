Instruction

Installation of a language pack is usually as simple as dropping the new language folder into the 'catalog/language' and 'admin/language' directories on your sites ftp. 

1. Goto Admin->Configuration->Localisation->Language
2. Click on Insert
3. Enter the following:

Language Name: Finnish
Code: fi
Locale: fi_FI.UTF-8,fi_FI,fi-FI,finnish
Image: fi.png
Directory: finnish
Filename: finnish
Status: Enabled
Sort Order: 2 (for example)