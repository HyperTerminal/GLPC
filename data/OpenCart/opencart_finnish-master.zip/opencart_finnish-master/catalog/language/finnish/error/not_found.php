<?php
// Heading
$_['heading_title'] = 'Haettua sivua ei löytynyt!';

// Text
$_['text_error']    = 'Haettua sivua ei löytynyt.';
?>