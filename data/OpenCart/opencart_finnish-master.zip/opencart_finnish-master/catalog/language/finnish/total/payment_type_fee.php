<?php
$_['text_payment_type'] = 'Maksutapa maksu';
?>