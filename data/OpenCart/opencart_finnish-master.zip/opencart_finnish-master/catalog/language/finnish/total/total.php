<?php
$_['text_total'] = 'Yhteens&auml;';
?>