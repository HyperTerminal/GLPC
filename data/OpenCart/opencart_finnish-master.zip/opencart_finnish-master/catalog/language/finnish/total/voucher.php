<?php
// Heading 
$_['heading_title'] = 'K&auml;yt&auml; lahjakortti';

// Text
$_['text_voucher']  = 'Lahjakortti(%s)';
$_['text_success']  = 'Onnistui: Lahjakortin summa on huomioitu!';

// Entry
$_['entry_voucher'] = 'Kirjoita lahjakortin koodi t&auml;h&auml;n:';

// Error
$_['error_voucher'] = 'Virhe: Lahjakortti on virheellinen tai se on jo k&auml;ytetty!';
?>