<?php
// Heading 
$_['heading_title'] = 'K&auml;yt&auml; tarjouskoodi';

// Text
$_['text_coupon']   = 'Tarjous(%s)';
$_['text_success']  = 'Vahvistus: Tarjouskoodi on huomioitu!';

// Entry
$_['entry_coupon']  = 'Kirjoita tarjouskoodi:';

// Error
$_['error_coupon']  = 'Huomautus: Tarjouskoodi on virheellinen tai se on jo k&auml;ytetty!';
?>