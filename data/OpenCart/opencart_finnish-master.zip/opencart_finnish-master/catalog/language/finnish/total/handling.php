<?php
$_['text_handling'] = 'K&auml;sittelykulut';
?>