<?php
// Heading 
$_['heading_title'] = 'K&auml;yt&auml; palkintopisteit&auml; (K&auml;ytett&auml;viss&auml; %s)';

// Text
$_['text_reward']   = 'Palkintopisteet(%s)';
$_['text_order_id'] = 'Tilausnumero: #%s';
$_['text_success']  = 'Onnistui: Palkintopisteet on huomioitu!';

// Entry
$_['entry_reward']  = 'Pisteit&auml; k&auml;ytett&auml;viss&auml; (Max %s):';

// Error
$_['error_empty']   = 'Huomautus: Kirjoita pistem&auml;&auml;r&auml; jonka haluat k&auml;ytt&auml;&auml;!';
$_['error_points']  = 'Huomautus: Palkintopisteet %s eiv&auml;t riit&auml;!';
$_['error_maximum'] = 'Huomautus: Suurin k&auml;ytett&auml;v&auml; pistem&auml;&auml;r&auml; on %s!';
?>