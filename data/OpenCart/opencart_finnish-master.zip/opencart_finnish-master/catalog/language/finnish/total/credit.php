<?php
$_['text_credit']   = 'Saldo';
$_['text_order_id'] = 'Tilausnumero: #%s';
?>