<?php
// Heading 
$_['heading_title']     = 'Kyselyn tulokset';

// Text
$_['text_error']	= 'Kyselyn tulossivua ei l&uml;ytynyt!';
$_['text_no_votes']     = 'Ei vastauksia!';
$_['text_poll_results'] = 'Kyselyn tulokset';
$_['text_percent']      = '%';
$_['text_answer']       = 'Vastaus';
$_['text_total_votes']  = '<strong>Vastauksia yhteens&auml;:</strong> ';
?>