<?php
// Heading 
$_['heading_title']   = 'Uutiset';

// Text
$_['text_error']      = 'Ei uutisia!';
$_['text_read_more']  = 'lue lis&auml;&auml;';
$_['text_date_added'] = '<strong>Lis&auml;tty:</strong>&nbsp;';

// Buttons
$_['button_news']     = 'Otsikot';
?>