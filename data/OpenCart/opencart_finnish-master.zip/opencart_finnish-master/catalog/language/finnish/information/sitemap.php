<?php
// Heading
$_['heading_title']    = 'Sivukartta';
 
// Text
$_['text_special']     = 'Tarjoukset';
$_['text_account']     = 'Asiakastili';
$_['text_edit']        = 'Asiakasilitiedot';
$_['text_password']    = 'Salasana';
$_['text_address']     = 'Osoitekirja';
$_['text_history']     = 'Tilaus historia';
$_['text_download']    = 'Lataukset';
$_['text_cart']        = 'Ostoskori';
$_['text_checkout']    = 'Kassa';
$_['text_search']      = 'Haku';
$_['text_information'] = 'Tietoa';
$_['text_contact']     = 'Yhteydenotto';
?>
