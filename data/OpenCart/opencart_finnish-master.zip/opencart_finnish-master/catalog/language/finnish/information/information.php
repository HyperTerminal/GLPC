<?php
// Text
$_['text_error'] = 'Tietosivua ei l&ouml;ytynyt!';
?>