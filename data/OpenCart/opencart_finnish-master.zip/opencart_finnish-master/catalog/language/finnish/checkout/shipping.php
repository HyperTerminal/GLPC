<?php
// Heading
$_['heading_title']         = 'Toimitus';

// Text 
$_['text_basket']           = 'Ostoskori';
$_['text_shipping']         = 'Toimitus';
$_['text_shipping_to']      = 'Valitse osoitekirjasta toimitusosoite.';
$_['text_shipping_address'] = 'Toimitusosoite';
$_['text_shipping_method']  = 'Toimitustapa';
$_['text_shipping_methods'] = 'Valitse haluttu toimitustapa.';
$_['text_comments']         = 'Anna lis&auml;tietoja';

// Error
$_['error_shipping']        = 'Huomautus: Valitse toimitustapa!';
$_['error_no_shipping']     = 'Huomautus: Toimitustapa ei ole k&auml;yt&ouml;ss&auml;. Ota <a href="index.php?route=information/contact">yhtett&auml;</a> jatkaaksesi!';
?>