<?php
// Heading 
$_['heading_title'] = 'Huomautus';

// Text
$_['text_basket']   = 'Ostoskori';
$_['text_shipping'] = 'Toimitus';
$_['text_payment']  = 'Maksu';
$_['text_failure']  = 'Virhe';
$_['text_message']  = '<p>Tilauksen k&auml;sittelyss&auml; ilmeni ongelma!</p><p>Jos ongelma ei poistu, valitse toinen maksutapa tai ole yhteydess&auml; verkkokaupan omistajaan <a href="%s">klikkaamalla t&auml;ss&auml;</a>.';
?>
