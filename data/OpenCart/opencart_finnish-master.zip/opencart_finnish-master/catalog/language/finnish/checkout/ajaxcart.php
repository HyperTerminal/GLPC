<?php
// Text
$_['text_confirm_i']  = 'Haluatko varmasti poistaa valitun kohteen?';
$_['text_confirm_v']  = 'Haluatko varmasti poistaa valitun lahjakortin?';
?>
