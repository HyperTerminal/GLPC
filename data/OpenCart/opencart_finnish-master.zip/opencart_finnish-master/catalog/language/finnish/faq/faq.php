<?php
// Heading
$_['heading_title']     = 'Usein kysytty&auml;';

// Text
$_['text_search']    = 'Etsi:';
$_['text_resetSearch']    = 'Tyhjenn&auml; haku';
$_['text_results']    = 'Tulokset';
$_['text_noResults']    = 'Ei hakutuloksia...';
$_['text_descriptionNoResults']    = 'Ei hakutuloksia m&auml;&auml;ritetylle haulle...';
$_['text_categoryEmpty']    = 'Kategoria on tyhjä...';

?>
