<?php
// Heading 
$_['heading_title']      = 'Rahansiirrot';

// Column
$_['column_date_added']  = 'Lis&auml;tty';
$_['column_description'] = 'Kuvaus';
$_['column_amount']      = 'M&auml;&auml;r&auml; (%s)';

// Text
$_['text_account']       = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_transaction']   = 'Rahansiirrot';
$_['text_total']         = 'Saldo:';
$_['text_empty']         = 'Et ole siirt&auml;nyt rahaa!';
?>