<?php
// Heading 
$_['heading_title']   = 'Lataukset';

// Text
$_['text_account']    = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_downloads']  = 'Lataukset';
$_['text_order']      = 'Tilausnumero:';
$_['text_date_added'] = 'Lis&auml;tty:';
$_['text_name']       = 'Nimi:';
$_['text_remaining']  = 'J&auml;ljell&auml;:';
$_['text_size']       = 'Koko:';
$_['text_download']   = 'Lataa';
$_['text_empty']      = 'Et ole ostanut ladattavia tuotteita!';
?>