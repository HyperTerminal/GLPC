<?php
// Heading 
$_['heading_title']   = 'Tilaushistoria';

// Text
$_['text_account']    = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_history']    = 'Tilaushistoria';
$_['text_order']      = 'Tilausnumero:';
$_['text_status']     = 'Tila:';
$_['text_date_added'] = 'Lis&auml;tty:';
$_['text_customer']   = 'Asiakas:';
$_['text_products']   = 'Tuotteet:';
$_['text_total']      = 'Yhteens&auml;:';
$_['text_error']      = 'Et ole tehnyt tilauksia!';
?>
