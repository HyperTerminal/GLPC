<?php
// Heading 
$_['heading_title'] = 'Kirjaudu ulos';

// Text
$_['text_message']  = '<p>Olet kirjautunut ulos verkkokaupasta.</p><p>Ostoskorisi sis&auml;lt&ouml; on tallennettu ja sen sis&auml;lt&ouml; on k&auml;ytett&auml;viss&auml; kun uudelleen kirjaudut verkkokauppaan.</p>';
$_['text_account']  = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_logout']   = 'Kirjaudu ulos';
?>