<?php
// Heading
$_['heading_title'] = 'Asiakastili on luotu!';

// Text
$_['text_message']  = '<p>Asiakastilisi on nyt luotu.</p> <p>Nyt voit hy&ouml;dynt&auml;&auml; verkkokauppamme ominaisuuksia.</p> <p>Jos sinulla on kysytt&auml;v&auml;&auml; ota yhteytt&auml; asiakaspalveluume</p> <p>Vahvistus on l&auml;hetetty antamaasi s&auml;hk&ouml;postiosoitteeseen. Jos et ole saanut sit&auml; tunnin kuluessa, <a href="%s">ota yhteytt&auml;</a>.</p>';
$_['text_approval'] = '<p>Kiitos rekister&ouml;itymisest&auml; %s kauppaan!</p><p>Sinulle ilmoitetaan s&auml;hk&ouml;postitse, kun asiakastilisi on aktivoitu.</p><p>Jos sinulle tulee jotakin kysytt&auml;v&auml;&auml; verkkokaupastamme, <a href="%s">ota yhteytt&auml;</a>.</p>';
$_['text_account']  = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_success']  = 'Onnistui';
?>