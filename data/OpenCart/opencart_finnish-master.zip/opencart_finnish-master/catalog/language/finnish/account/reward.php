<?php
// Heading 
$_['heading_title']      = 'Palkintopisteesi';

// Column
$_['column_date_added']  = 'P&auml;iv&auml;tty';
$_['column_description'] = 'Kuvaus';
$_['column_points']      = 'Pisteet';

// Text
$_['text_account']       = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_reward']        = 'Palkintopisteet';
$_['text_total']         = 'Sinulla on yhteens&auml; pisteit&auml;:';
$_['text_empty']         = 'Sinulla ei ole yht&auml;&auml;n palkintopisteit&auml;!';
?>