<?php

$_['heading_title'] = 'Asiakastili';
$_['text_account'] = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_my_account'] = 'Asiakastili';
$_['text_my_orders'] = 'Tilaukset';
$_['text_my_newsletter'] = 'Uutiskirje';
$_['text_edit'] = 'Muokkaa tietoja';
$_['text_password'] = 'Vaihda salasana';
$_['text_address'] = 'Muokkaa osoitekirjaa';
$_['text_wishlist'] = 'Muokkaa ostoslistaa';
$_['text_order'] = 'N&auml;yt&auml; tilaushistoria';
$_['text_download'] = 'Lataukset';
$_['text_reward'] = 'Palkintopisteet';
$_['text_return'] = 'N&auml;yt&auml; palautukset';
$_['text_transaction'] = 'Rahansiirrot';
$_['text_newsletter'] = 'Tilaa / peru uutiskirje';

?>