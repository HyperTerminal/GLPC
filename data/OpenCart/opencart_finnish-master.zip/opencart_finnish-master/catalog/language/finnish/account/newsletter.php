<?php
// Heading 
$_['heading_title']    = 'Uutiskirjeen tilaaminen';

// Text
$_['text_account']     = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_newsletter']  = 'Uutiskirje';
$_['text_success']     = 'Vahvistus: Uutiskirjetilaus on suoritettu!';

// Entry
$_['entry_newsletter'] = 'Tilaa:';
?>
