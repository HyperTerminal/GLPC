<?php
// Heading 
$_['heading_title']			= 'Kirjaudu';

// Entry
$_['entry_email_address']		= 'S&auml;hk&ouml;postiosoite:';
$_['entry_password']			= 'Salasana:';

// Buttons
$_['button_logout']			= 'Kirjaudu ulos';
$_['button_create']			= 'Luo k&auml;ytt&auml;j&auml;tunnus';
?>