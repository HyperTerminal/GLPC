<?php
// Heading
$_['heading_title']	= 'K&auml;vij&auml;laskuri';

// Texts
$_['text_today']	= 'T&auml;n&auml;&auml;n';
$_['text_week']		= 'Viikossa';
$_['text_month']	= 'Kuukaudessa';
$_['text_year']		= 'Vuodessa';
$_['text_all']		= 'Yhteens&auml;';
$_['text_online']	= 'Kirjautuneena';
?>