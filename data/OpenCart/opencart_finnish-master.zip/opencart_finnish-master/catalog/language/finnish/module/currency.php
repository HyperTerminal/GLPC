<?php
// Heading
$_['heading_title']  = 'Valuutta';

// Entry
$_['entry_currency'] = 'Valuutta:';
?>