<?php
// Heading 
$_['heading_title'] = 'Suositut ostokset';

// Text
$_['text_reviews']  = 'Perustuu %s arvosteluun.'; 
?>