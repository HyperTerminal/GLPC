<?php
// Heading 
$_['heading_title'] = 'Tarjoukset';

// Text
$_['text_reviews']  = 'Perustuu %s arvosteluun.';
$_['text_yousave']      = 'S&auml&aumlst&aumlt:';
$_['text_or_percent']   = 'tai'; 
?>