<?php
// Heading 
$_['heading_title']  = 'Uutiset';

// Text
$_['text_read_more'] = 'lue lis&auml;&auml;';
?>