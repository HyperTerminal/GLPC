<?php

	$_['text_close'] = 'sulje';
	
?>