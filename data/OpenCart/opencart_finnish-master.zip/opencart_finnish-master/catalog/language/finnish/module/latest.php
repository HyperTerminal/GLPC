<?php
// Heading 
$_['heading_title'] = 'Uusimmat';

// Text
$_['text_reviews']  = 'Perustuu %s arvosteluun.'; 
$_['text_yousave']      = 'S&auml;&auml;stit:';
$_['text_or_percent']   = 'tai';
?>