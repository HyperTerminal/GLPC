<?php
// Heading 
$_['heading_title']  = 'My HTML Module';
?>
