<?php
// Heading 
$_['heading_title']    = 'Asiakastiedot';

// Text
$_['text_register']    = 'Rekister&ouml;idy';
$_['text_login']       = 'Kirjaudu sis&auml;&auml;n';
$_['text_logout']      = 'Kirjaudu ulos';
$_['text_forgotten']   = 'Pyyd&auml; uusi salasana';
$_['text_account']     = 'K&auml;ytt&auml;j&auml;tiedot';
$_['text_address']     = 'Osoitetiedot';
$_['text_edit']        = 'Muokkaa asiakastili&auml;';
$_['text_password']    = 'Salasana';
$_['text_wishlist']    = 'Ostoslista';
$_['text_order']       = 'Tilaushistoria';
$_['text_download']    = 'Lataukset';
$_['text_return']      = 'Palautukset';
$_['text_transaction'] = 'Siirrot';
$_['text_newsletter']  = 'Uutiskirje';
$_['text_recurring']   = 'Toistot';
?>
