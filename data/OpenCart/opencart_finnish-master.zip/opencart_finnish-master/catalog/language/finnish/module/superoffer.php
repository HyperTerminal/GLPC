<?php
// Heading 
$_['heading_title'] = 'Viikon tarjous';

// Text
$_['text_reviews']  = 'Perustuu %s arvosteluun.'; 
?>