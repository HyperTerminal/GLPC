<?php
// Heading 
$_['heading_title']  = 'Youtube-video';
$_['youtube_extension']  = '&hl=en_US&fs=1&';
?>