<?php
// Heading 
$_['heading_title']  = '';
$_['viewall']  = 'Kaikki tuotteet';

?>