<?php
// Heading 
$_['heading_title'] = 'Suosituimmat';

// Text
$_['text_reviews']  = 'Perustuu %s arvosteluun.'; 
$_['text_yousave']      = 'S&auml;&auml;st&ouml;:';
$_['text_or_percent']   = 'tai';
?>