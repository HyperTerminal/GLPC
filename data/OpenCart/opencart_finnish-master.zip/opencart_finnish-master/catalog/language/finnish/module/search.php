<?php
// Heading 
$_['heading_title'] = 'Pikahaku';

// Text
$_['text_keywords'] = 'Hakusanat';
$_['text_advanced'] = 'Tarkennettu haku';
?>