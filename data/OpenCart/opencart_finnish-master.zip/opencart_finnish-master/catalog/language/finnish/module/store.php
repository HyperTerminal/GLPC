<?php
// Heading 
$_['heading_title'] = 'Valitse verkkokauppa';

// Text
$_['text_default']  = 'Oletus';
$_['text_store']    = 'Valitse verkkokauppa jossa haluat vierailla.';
?>