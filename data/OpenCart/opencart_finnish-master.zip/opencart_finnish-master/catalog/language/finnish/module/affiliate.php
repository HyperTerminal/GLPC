<?php
// Heading 
$_['heading_title']    = 'Sopimusasiakas';

// Text
$_['text_register']    = 'Rekister&ouml;idy';
$_['text_login']       = 'Kirjaudu';
$_['text_logout']      = 'Kirjaudu ulos';
$_['text_forgetten']   = 'Tilaa uusi salasana';
$_['text_account']     = 'Asiakastili';
$_['text_edit']        = 'Muokkaa asiakastili&auml;';
$_['text_password']    = 'Salasana';
$_['text_payment']     = 'Maksuvaihtoehdot';
$_['text_tracking']    = 'Seuranta';
$_['text_transaction'] = 'Tapahtumat';
?>
