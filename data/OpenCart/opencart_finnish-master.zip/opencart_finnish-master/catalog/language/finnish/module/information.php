<?php
// Heading 
$_['heading_title'] = 'Tietoja';

// Text
$_['text_contact']  = 'Ota yhteytt&auml;';
$_['text_sitemap']  = 'Sivukartta';
?>