<?php
// Heading 
$_['heading_title']     = 'Kysely';

// Text
$_['text_vote']         = 'Vastaa';
$_['text_total_votes']  = 'Vastauksia yhteens&auml;: ';
$_['text_no_poll']      = 'T&auml;ll&auml; hetkell&auml; ei ole kysely&auml; aktiivisena';
$_['text_no_votes']     = 'Ei vastauksia!';
$_['text_poll_results'] = 'N&auml;yt&auml; kyselyn tulokset';
$_['text_percent']      = '%';
$_['text_answer']       = 'Vastaus';
?>