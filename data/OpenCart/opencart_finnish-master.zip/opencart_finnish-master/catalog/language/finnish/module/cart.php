<?php
// Heading
$_['heading_title'] = 'Ostoskori';

// Text 
$_['text_subtotal'] = 'V&auml;lisumma:';
$_['text_items'] = '%s tuote(tta) - %s';
$_['text_empty']    = 'Tyhj&auml;';
$_['text_confirm']  = 'Oletko varma?';
$_['text_remove']   = 'Poista';
$_['text_view']  	  = 'N&auml;yt&auml; ostoskori';
$_['text_checkout'] = 'Kassalle';
$_['text_clear']    = 'Tyhjenn&auml;';
?>