<?php
$_['heading_title'] = 'Tervetuloa %s';
?>