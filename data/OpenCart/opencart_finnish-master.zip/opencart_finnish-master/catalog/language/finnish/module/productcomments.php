<?php

$_['text_post_comment']  = 'L&auml;het&auml; tuotepalautetta';
$_['text_name']          = 'Nimi';
$_['text_note']          = '<span style="color: #FF0000;">Huomautus:</span> HTML-koodia ei k&auml;&auml;nnet&auml;!';
$_['text_email']         = 'S&auml;hk&ouml;postiosoite';
$_['text_comment']      = 'Tuotepalaute';
$_['button_continue']    = 'L&auml;het&auml;';

$_['tab_comments']     = 'Tuotepalautteet';
$_['text_wait']         = 'Ole hyvä ja odota!';

$_['error_name']        = 'Huomautus: Nimen on oltava v&auml;hint&auml;&auml;n 3 ja enint&auml;&auml;n 25 merkki&auml; pitk&auml;!';
$_['error_text_long']   = 'Huomautus: Kommentti on liian pitk&auml;!';
$_['error_email_long']  = 'Huomautus: S&auml;hk&ouml;postiosoite liian pitk&auml;!';
$_['error_text_empty']  = 'Huomautus: Kommenttiruutu ei voi olla tyhj&auml!';
$_['error_captcha']     = 'Huomautus: Turvakoodi ei vastaa kuvan numeroa!';
$_['text_success']      = 'Kiitos kommentista.';
$_['entry_captcha']     = 'Anna koodi alla olevaan laatikoon:';

$_['text_no_comments_yet'] = 'Ei kommentteja';

?>