<?php

// Dialog
$_['dialog_title'] = 'Lyhyesti';
$_['dialog_button_add_to_cart'] = 'Lis&auml;&auml; ostoskoriin';
$_['dialog_button_view_details'] = 'N&auml;yt&auml; lis&auml;tiedot';
$_['dialog_button_close'] = 'Sulje';

?>