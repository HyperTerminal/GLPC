<?php
// Heading 
$_['heading_title'] = 'Online tuki!';

?>