<?php
// Heading 
$_['heading_title']  = 'Kieli';

// Entry
$_['entry_language'] = 'Kieli:';
?>