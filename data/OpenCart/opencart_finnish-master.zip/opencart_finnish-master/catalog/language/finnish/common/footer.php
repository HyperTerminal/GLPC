<?php
// Text
$_['text_information']  = 'Tietoa';
$_['text_service']      = 'Asiakaspalvelu';
$_['text_extra']        = 'Verkkokauppa';
$_['text_contact']      = 'Palaute';
$_['text_return']       = 'Tuotepalautus';
$_['text_sitemap']      = 'Sivustokartta';
$_['text_manufacturer'] = 'Tuotemerkit';
$_['text_voucher']      = 'Lahjakortti';
$_['text_affiliate']    = 'Sopimusasiakkaat';
$_['text_special']      = 'Tarjoukset';
$_['text_account']      = 'Asiakastili';
$_['text_order']        = 'Tilaushistoria';
$_['text_wishlist']     = 'Ostoslista';
$_['text_newsletter']   = 'Uutiskirje';
$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
?>