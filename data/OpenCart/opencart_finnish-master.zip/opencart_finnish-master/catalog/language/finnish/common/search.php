<?php
// Heading 
$_['heading_title'] = 'Haku';

// Text
$_['text_keywords'] = 'Hakusanat';
$_['text_advanced'] = 'Tarkennettu haku';
?>
