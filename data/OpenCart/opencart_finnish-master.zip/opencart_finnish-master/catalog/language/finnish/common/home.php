<?php
// Heading 
$_['heading_title'] = '%s';

// Text
$_['text_latest']   = 'Uusimmat tuotteet';
?>