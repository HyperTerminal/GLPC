<?php
// Heading
$_['heading_title']     = 'Huolto';

// Text
$_['text_maintenance']  = 'Huolto';
$_['text_message']      = '<h1 style="text-align:center;">Suoritamme parhaillaan verkkokaupassamme suunniteltuja huoltotoimenpiteit&auml;.<br/>Avaamme kaupan mahdollisiman pian.<br/>Tervetuloa my&ouml;hemmin uudelleen.</h1>';
?>