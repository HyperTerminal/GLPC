<?php
// Text
$_['text_home']     = 'Etusivu';
$_['text_wishlist'] = 'Ostoslista (%s)';
$_['text_cart']     = 'Ostoskori';
$_['text_items']    = '%s tuote(tta) - %s';
$_['text_shopping_cart'] = "Ostoskori";
$_['text_search']   = 'Haku';
$_['text_welcome']  = '<a href="%s">Kirjaudu</a> | <a href="%s">Rekister&ouml;idy</a>.';
$_['text_logged']   = 'Olet kirjautuneena <a href="%s">%s</a> <b>(</b> <a href="%s">Kirjaudu ulos</a> <b>)</b>';
$_['text_account']  = 'Asiakastili';
$_['text_checkout'] = 'Kassa';
$_['text_language'] = 'Kieli';
$_['text_languages'] = 'Kielet';
$_['text_currency'] = 'Valuutta';
?>