<?php
// Heading 
$_['heading_title']        = 'Sopimusasiakastili';

// Text
$_['text_account']         = 'K&auml;ytt&auml;j&auml;tili';
$_['text_my_account']      = 'Sopimusasiakastili';
$_['text_my_tracking']     = 'My Tracking Information';
$_['text_my_transactions'] = 'My Transactions';
$_['text_edit']            = 'Edit your account information';
$_['text_password']        = 'Change your password';
$_['text_payment']         = 'Change your payment preferences';
$_['text_tracking']        = 'Custom Affiliate Tracking Code';
$_['text_transaction']     = 'View your transaction history';
?>