<?php
// Heading 
$_['heading_title']      = 'Tapahtumat';

// Column
$_['column_date_added']  = 'Lis&auml;tty';
$_['column_description'] = 'Kuvaus';
$_['column_amount']      = 'M&auml;&auml;r&auml; (%s)';

// Text
$_['text_account']       = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_transaction']   = 'Tapahtumat';
$_['text_balance']       = 'Saldo:';
$_['text_empty']         = 'Teill&auml; ei ole kirjattuja tapahtumia!';
?>