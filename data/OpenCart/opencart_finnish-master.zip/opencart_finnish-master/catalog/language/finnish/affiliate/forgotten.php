<?php
// Heading 
$_['heading_title']   = 'Tilaa uusi salasana';

// Text
$_['text_account']    = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_forgotten']  = 'Salasana';
$_['text_your_email'] = 'S&auml;hk&ouml;postiosoite';
$_['text_email']      = 'Sy&ouml;t&auml; register&ouml;im&auml;si s&auml;hk&ouml;postiosoite ja paina l&auml;het&auml; uusi salasana s&auml;hk&ouml;postilla.';
$_['text_success']    = 'Vahvistus: Uusi salasana on l&auml;hetetty s&auml;hk&ouml;postiosoitteeseen.';

// Entry
$_['entry_email']     = 'S&auml;hk&ouml;postiosoite:';

// Error
$_['error_email']     = 'Huomatus: S&auml;hk&ouml;postiosoite ei l&ouml;ytynyt j&auml;rjestelm&auml;st&auml;. Yrit&auml; uudelleen!';
?>