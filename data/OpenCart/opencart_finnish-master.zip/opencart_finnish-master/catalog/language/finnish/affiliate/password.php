<?php
// Heading 
$_['heading_title']  = 'Vaihda salasana';

// Text
$_['text_account']   = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_password']  = 'Salasana';
$_['text_success']   = 'Vahvistus: Salasana on p&auml;ivitetty onnistuneesti.';

// Entry
$_['entry_password'] = 'Salasana:';
$_['entry_confirm']  = 'Vahvista salasana:';

// Error
$_['error_password'] = 'Huomautus: Salasanan on oltava v&auml;hint&auml;&auml;n 4 ja enint&auml;&auml;n 20 merkki&auml; pitk&auml;!';
$_['error_confirm']  = 'Huomautus: Salasanan vahvistus ei vastaa salasanaa!';
?>