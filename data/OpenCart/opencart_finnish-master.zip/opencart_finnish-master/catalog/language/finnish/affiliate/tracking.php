<?php
// Heading 
$_['heading_title']    = 'Sopimusasiakkaan seuranta';

// Text
$_['text_account']     = 'K&auml;ytt&auml;j&auml;tunnus';
$_['text_description'] = 'K&auml;ytt&ouml;&ouml;notettuihin URL linkkeihin t&auml;ytyy lis&auml;t&auml; seurantakoodi, jotta voidaan varmistaa että saat etujesi mukaisen hyvityksen. Voit käyttää alla olevia työkaluja linkkien generoimiseen %s verkkosivulle';
$_['text_code']        = '<b>Seurantatunnus:</b>';
$_['text_generator']   = '<b>Seurantalinkin generointi</b><br />Sy&ouml;t&auml; tuotteen nimi, jonka haluat linkitt&auml;&auml;:';
$_['text_link']        = '<b>Seurantalinkki:</b>';
?>

