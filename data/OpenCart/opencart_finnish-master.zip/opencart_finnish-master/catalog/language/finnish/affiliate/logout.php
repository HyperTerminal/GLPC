<?php
// Heading 
$_['heading_title'] = 'Kirjaudu ulos';

// Text
$_['text_message']  = '<p>Olet kirjautunut ulos verkkokaupasta.</p><p>Ostoskorisi on tallennettu ja sen sis&auml;lt&ouml; on k&auml;ytett&auml;viss&auml; kun kirjaudut takaisin verkkokauppaan.</p>';
$_['text_account']  = 'K&auml;ytt&auml;jatunnus';
$_['text_logout']   = 'Poistu';
?>