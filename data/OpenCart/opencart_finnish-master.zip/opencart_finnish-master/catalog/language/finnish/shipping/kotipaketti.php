<?php
// Text
$_['text_title']       = '<a href="http://www.posti.fi/paketit/kotimaanpaketit/kotipaketti.html" target=_blank>Kotipaketti</a>';
$_['text_description'] = 'Kotipaketti';
?>