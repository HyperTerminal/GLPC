<?php
// Text
$_['text_title']  = '<a href="http://www.posti.fi/paketit/kotimaanpaketit/ovelle-paketti.html" target=_blank>Ovelle-paketti</a>';
$_['text_ovellepaketti'] = 'Ovelle-paketti:'; 
?>