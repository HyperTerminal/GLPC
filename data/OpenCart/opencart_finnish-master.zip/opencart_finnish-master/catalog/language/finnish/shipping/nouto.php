<?php

// Text
$_['text_title']       = 'Nouto';
$_['text_description'] = 'Nouto kaupasta';
?>