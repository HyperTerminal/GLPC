<?php
// Text
$_['text_title']       = 'Nouto myym&auml;l&auml;st&auml;';
$_['text_description'] = 'Nouto myym&auml;l&auml;st&auml;';
?>