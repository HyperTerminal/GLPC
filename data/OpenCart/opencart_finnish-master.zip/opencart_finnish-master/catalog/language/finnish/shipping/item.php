<?php
// Text
$_['text_title']       = 'Tuotekohtainen toimitus';
$_['text_description'] = 'Tuotekohtaiset toimituskulut';
?>