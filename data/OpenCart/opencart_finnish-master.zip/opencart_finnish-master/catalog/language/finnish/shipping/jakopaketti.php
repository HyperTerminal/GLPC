<?php
// Text
$_['text_title']  = '<a href="http://www.matkahuolto.fi/fi/pakettipalvelut_yksityisille/laheta_paketti/jakopaketti/" target=_blank>Jakopaketti</a>';
$_['text_jakopaketti'] = 'Jakopaketti:'; 
?>