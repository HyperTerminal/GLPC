<?php
// Text
$_['text_title']  = '<a href="http://www.matkahuolto.fi/fi/pakettipalvelut_yksityisille/laheta_paketti/pikapaketti/" target=_blank>Pikapaketti</a>';
$_['text_pikapaketti'] = 'Pikapaketti:'; 
?>