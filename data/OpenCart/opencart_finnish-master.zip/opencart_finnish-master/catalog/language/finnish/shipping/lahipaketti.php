<?php
// Text
$_['text_title']       = '<a href="http://www.matkahuolto.fi/fi/pakettipalvelut_yksityisille/laheta_paketti/lahi_paketti/" target=_blank>L&auml;hi-paketti</a>';
$_['text_description'] = 'L&auml;hi-paketti';
?>