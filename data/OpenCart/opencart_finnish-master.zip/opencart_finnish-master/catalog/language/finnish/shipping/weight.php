<?php
// Text
$_['text_title']  = 'Painoon perustuva toimitus';
$_['text_weight'] = 'Paino:'; 
?>