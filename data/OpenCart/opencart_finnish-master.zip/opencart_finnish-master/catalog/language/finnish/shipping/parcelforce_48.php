<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Paino:'; 
$_['text_insurance']   = 'Vakuutettu:';   
$_['text_time']        = 'Arvioituaikka: 48 tuntia'; 
?>