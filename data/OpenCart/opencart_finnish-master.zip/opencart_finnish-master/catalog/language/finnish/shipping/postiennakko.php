<?php
// Text
$_['text_title']       = 'Postiennakko';
$_['text_description'] = 'Postiennakkomaksu on 3.70 ja lahetyskulut 5-20 tuotteen koosta riippuen.';
?>