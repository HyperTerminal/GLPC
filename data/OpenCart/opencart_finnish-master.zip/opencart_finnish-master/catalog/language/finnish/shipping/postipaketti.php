<?php
// Text
$_['text_title']  = '<a href="http://www.posti.fi/paketit/kotimaanpaketit/postipaketti.html" target=_blank>Postipaketti</a>';
$_['text_postipaketti'] = 'Postipaketti:'; 
?>