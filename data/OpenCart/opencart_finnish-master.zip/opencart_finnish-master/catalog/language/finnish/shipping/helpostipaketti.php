<?php
// Text
$_['text_title']       = '<a href="http://www.posti.fi/paketit/kotimaanpaketit/helposti-paketti.html" target=_blank>Helposti-paketti</a>';
$_['text_description'] = 'Helposti-paketti';
?>