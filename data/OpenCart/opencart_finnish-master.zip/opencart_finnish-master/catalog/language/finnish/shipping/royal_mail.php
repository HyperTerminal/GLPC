<?php
// Text
$_['text_title']                = 'Royal Mail';
$_['text_weight']               = 'Paino:';
$_['text_insurance']            = 'Vakuutettu:';
$_['text_eta']                  = 'Arvioituaika:';
$_['text_1st_class_standard']   = '1. luokka';
$_['text_1st_class_recorded']   = 'Kirjattu 1. luokka';
$_['text_2nd_class_standard']   = '2. luokka';
$_['text_2nd_class_recorded']   = 'Kirjattu 2. luokka';
$_['text_standard_parcels']     = 'Tavallinen paketti';
$_['text_airmail']              = 'Lentoposti';
$_['text_international_signed'] = 'Kansainvälisestikirjattu';
$_['text_airsure']              = 'Kirjattu lentopostina';
$_['text_surface']              = 'Maateitse';
?>