<?php
// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'Paino:';
$_['text_eta']    = 'Arvioitu toimitusaika:';
?>