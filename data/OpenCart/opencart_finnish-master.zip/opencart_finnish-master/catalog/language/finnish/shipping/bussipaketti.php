<?php
// Text
$_['text_title']  = '<a href="http://www.matkahuolto.fi/fi/pakettipalvelut_yksityisille/laheta_paketti/bussipaketti/" target=_blank>Bussipaketti</a>';
$_['text_bussipaketti'] = 'Bussipaketti:'; 
?>