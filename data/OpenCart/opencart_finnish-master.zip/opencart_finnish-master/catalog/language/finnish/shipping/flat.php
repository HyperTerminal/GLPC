<?php
// Text
$_['text_title']       = 'Kiinte&auml; hintainen toimitus';
$_['text_description'] = 'Kiinte&auml; hintainen toimitus';
?>