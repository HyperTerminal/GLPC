<?php
// Heading
$_['heading_title']     = 'Tuote hinnasto';

// Header Bar Title
$_['text_all_products'] = 'Kaikki tuotteet';

// Text
$_['text_limit']        = 'Tuotteita sivulla:';
$_['text_empty']        = 'Ei ole tuoteita.';
$_['text_stars']        = '%s / 5 t&auml;hte&auml;!';
$_['text_catagory']     = 'Ryhm&auml;t:';
$_['text_sort']         = 'Lajiteltu:';
$_['text_name_asc']     = 'Tuottenimet A - Z';
$_['text_name_desc']    = 'Tuotenimet Z - A';
$_['text_price_asc']    = 'Edullisin tuote ensin';
$_['text_price_desc']   = 'Kallein tuote ensin';
$_['text_rating_asc']   = 'Alhaisin luokitus ensin';
$_['text_rating_desc']  = 'Ylin luokitus ensin';
$_['text_qty']          = 'M&auml;&auml;r&auml;: ';
$_['text_addcart']      = 'Lis&auml;&auml; astoskoriin';
$_['text_print']        = 'Tulosta';
$_['text_notfound']     = 'Tuotetta ei l&ouml;ydy!';
$_['text_pricelist']    = 'Tuote hinnasto';
?>