<?php
// Text
$_['text_title']       = 'Tilisiirto';
$_['text_instruction'] = 'Tilisiirto ohje';
$_['text_description'] = 'Maksakaa loppusumma tilinumerolle: ';
$_['text_payment']     = 'Tilaus toimitetaan vasta kun maksusuoritus n&auml;kyy tilill&auml;mme.';
?>