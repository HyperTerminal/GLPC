<?php
// Text
$_['text_title']           = 'Luottokortti / Pankkikortti (SagePay)';
$_['text_credit_card']     = 'Luottokortin tiedot';
$_['text_wait']            = 'Odota ole hyv&auml;!';

// Entry
$_['entry_cc_owner']       = 'Kortin omistaja:';
$_['entry_cc_number']      = 'Kortin numero:';
$_['entry_cc_expire_date'] = 'Vaimassa pvm:';
$_['entry_cc_cvv2']        = 'Turvatunnus (CVV2):';
?>