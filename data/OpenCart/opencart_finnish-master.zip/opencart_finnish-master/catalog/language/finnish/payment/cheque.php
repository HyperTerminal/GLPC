<?php
// Text
$_['text_title']       = 'Sekki / Maksuosoitusohjeet';
$_['text_instruction'] = 'Sekki / Maksuosoitus';
$_['text_payable']     = 'Maksetaan:';
$_['text_address']     = 'Vastaanottaja:';
$_['text_payment']     = 'Tilausta toimitetaan kun maksusuorite on vahvistettu.';
?>