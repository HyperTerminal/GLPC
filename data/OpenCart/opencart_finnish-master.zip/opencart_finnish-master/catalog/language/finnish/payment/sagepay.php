<?php
// Text
$_['text_title']       = 'Luottokortti / Pankkikortti (SagePay)';
$_['text_description'] = 'Nimikkeet %s Tilausnumero: %s';
?>