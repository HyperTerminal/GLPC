<?php
// Text
$_['text_title'] = 'Pankki/luottokortti (Checkout)';
?>