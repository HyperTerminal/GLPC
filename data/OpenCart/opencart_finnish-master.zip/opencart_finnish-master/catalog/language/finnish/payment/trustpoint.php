<?php
// Text
$_['text_title']           = 'Lasku (Trust-laskutus)';
$_['text_credit_card']     = 'Kortin tiedot';
$_['text_wait']            = 'Ole hyvä ja odota!';

// Entry
$_['entry_cc_owner']       = 'Kortin omistaja:';
$_['entry_cc_number']      = 'Kortin numero:';
$_['entry_cc_expire_date'] = 'Voimassa (pvm):';
$_['entry_cc_cvv2']        = 'Turvatunnus (CVV2):';
?>