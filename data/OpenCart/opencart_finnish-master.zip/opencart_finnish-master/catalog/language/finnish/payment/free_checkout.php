<?php
// Text
$_['text_title'] = 'Kassalle';
?>