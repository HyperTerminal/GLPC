<?php
// Text
$_['text_title']           = 'Luottokortti / Pankkikortti (Authorize.Net)';
$_['text_credit_card']     = 'Luottokortin tiedot';
$_['text_wait']            = 'Ole hyv&auml; ja odota!';

// Entry
$_['entry_cc_owner']       = 'Kortin omistaja:';
$_['entry_cc_number']      = 'Kortin numero:';
$_['entry_cc_expire_date'] = 'Kortin viimeinen voimassaolopäivä:';
$_['entry_cc_cvv2']        = 'Kortin turvakoodi (CVV2):';
?>