<?php
// Text
$_['text_title'] = 'Luottokortti / Pankkikortti (Suomen Verkkomaksut)';
?>