<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'Peruste/Tiedoksi';
$_['text_testmode']	= 'Huomautus: Maksupalvelu on \'Sandbox\'-tilassa. Asiakasta ei veloiteta.';
$_['text_total']	= 'Toimitus- ja k&auml;sittelykulut, alennukset ja verot';
?>