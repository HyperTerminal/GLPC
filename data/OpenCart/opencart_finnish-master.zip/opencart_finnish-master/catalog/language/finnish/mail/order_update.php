<?php
// Mail
$_['text_subject']      = '%s - tilauksen tilannetieto, tilausnumero %s';
$_['text_order']        = 'Tilausnumero:';
$_['text_date_added']   = 'Tilauspvm:';
$_['text_order_status'] = 'Tilauksen tila:';
$_['text_comment']      = 'Tilauksen lis&auml;tiedot:';
$_['text_invoice']      = 'Tarkistaaksesi tilauksesi, klikkaa alla olevaa linkki&auml;:';
$_['text_footer']       = 'Vastaa t&auml;h&auml;n viestiin, jos sinulla ilmenee kysytt&auml;v&auml;&auml;.';
$_['text_link'] = 'Voit tarkistaa tilauksesi t&auml&aumllt&auml:';
?>