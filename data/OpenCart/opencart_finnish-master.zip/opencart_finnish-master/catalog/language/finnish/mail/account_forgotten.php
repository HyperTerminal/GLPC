<?php
// Mail
$_['text_subject']  = '%s - Uusi salasana';
$_['text_greeting'] = 'Olet pyyt&auml;nyt uuden salasanan osoitteessa %s.';
$_['text_password'] = 'Uusi salasanasi on:';
?>