<?php
// Text
$_['text_subject']  = '%s - Kiitos rekister&ouml;itymisest&auml;';
$_['text_welcome']  = 'Tervetuloa %s:n asiakkaaksi!';
$_['text_login']    = 'K&auml;ytt&auml;j&auml;tunnus on luotu. Kirjaudu sis&auml;&auml;n k&auml;ytt&auml;m&auml;ll&auml; s&auml;hk&ouml;postiosoitetta ja salasanaa verkkokauppaan:';
$_['text_approval'] = 'K&auml;ytt&auml;j&auml;tunnus on vahvistettava ennen kuin voit kirjautua verkkokauppaan:';
$_['text_services'] = 'Kirjautuneena voit mm. selata tilaushistoriaa, tulostaa laskuja tai muuttaa asiakastilitietoja.';
$_['text_thanks']   = 'Terveisin,';
?>