<?php
// Text
$_['text_subject']  = '%s - Uusi salasana';
$_['text_greeting'] = 'Olet tilannut uuden salasanan osoitteesta %s.';
$_['text_password'] = 'Uusi salasanasi:';
?>