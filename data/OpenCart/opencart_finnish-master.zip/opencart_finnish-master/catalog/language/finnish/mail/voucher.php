<?php
// Text
$_['text_subject']  = 'Olet l&auml;hett&auml;nyt %s -lahjakortin';
$_['text_greeting'] = 'Onneksi olkoon, olet saanut %s arvoisen lahjakortin';
$_['text_from']     = 'Lahjakortin on l&auml;hett&auml;nyt sinulle %s -k&auml;ytt&auml;j&auml;';
$_['text_message']  = 'Liitetty viesti';
$_['text_redeem']   = 'Lunastaaksesi lahjakortin, kirjoita yl&ouml;s lahjakortin <b>%s</b>-lunastustunnus ja valitse siihen liitetty linkki. Tilaa haluamasi tuote ja liit&auml; lahjakortin lunastustunnus tilaukseesi. Voit halutessasi sy&ouml;tt&auml;&auml; lahjakortin lunastustunnuksen suoraan ostoskori-sivulla ennen kuin olet suorittamassa tilausta.';
$_['text_footer']   = 'Vastaa s&auml;hk&ouml;postiin, jos sinulla on jotain kysytt&auml;v&auml;&auml;.';
?>