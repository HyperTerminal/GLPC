<?php
// Text
$_['text_subject']  = '%s - rekister&ouml;ityminen';
$_['text_welcome']  = 'Tervetuloa %s, verkkokaupan asiakkaaksi!';
$_['text_login']    = 'Voit nyt kirjautua verkkokauppaan osoitteessa:';
$_['text_approval'] = 'Register&ouml;ytyminen on vahvistettava ennen kuin voit kirjautua verkkokauppaan osoitteessa:';
$_['text_services'] = 'Kirjautuneena voit mm. selata tilaushistoriaa, tulostaa laskuja tai muuttaa asiakastilitietoja.';
$_['text_thanks']   = 'Terveisin,';
?>