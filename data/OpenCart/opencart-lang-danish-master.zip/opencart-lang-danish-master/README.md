Opencart Language pack - Danish
===============================

Translation not ready yet
