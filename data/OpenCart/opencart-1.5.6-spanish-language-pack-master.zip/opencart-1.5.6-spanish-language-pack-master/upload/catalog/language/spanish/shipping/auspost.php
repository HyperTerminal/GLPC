<?php
// Text
$_['text_title']    = 'Australia Post';
$_['text_express']  = 'Expreso';
$_['text_standard'] = 'Estándar';
$_['text_eta']      = 'días';
?>
