<?php
// Text
$_['text_title']                               = 'Fedex';
$_['text_weight']                              = 'Peso:';
$_['text_eta']                                 = 'Tiempo estimado:';
$_['text_europe_first_international_priority'] = 'Europa primera prioridad internacional';
$_['text_fedex_1_day_freight']                 = 'Fedex 1 día de cargo';
$_['text_fedex_2_day']                         = 'Fedex 2 día';
$_['text_fedex_2_day_am']                      = 'Fedex 2 día AM';
$_['text_fedex_2_day_freight']                 = 'Fedex 2 día de cargo';
$_['text_fedex_3_day_freight']                 = 'Fedex 3 día de cargo';
$_['text_fedex_express_saver']                 = 'Fedex ahorro expreso';
$_['text_fedex_first_freight']                 = 'Fedex Primer cargo';
$_['text_fedex_freight_economy']               = 'Fedex Cargo por Economia';
$_['text_fedex_freight_priority']              = 'Fedex Cargo por Prioridad';
$_['text_fedex_ground']                        = 'Fedex Tierra';
$_['text_first_overnight']                     = 'Primero durante la noche';
$_['text_ground_home_delivery']                = 'Entrega a domicilio por tierra';
$_['text_international_economy']               = 'Economia Internacional';
$_['text_international_economy_freight']       = 'Cargo de economia Internacional';
$_['text_international_first']                 = 'Primero Internacional';
$_['text_international_priority']              = 'Prioridad Itnernacional';
$_['text_international_priority_freight']      = 'Cargo de Prioridad Internacional';
$_['text_priority_overnight']                  = 'Prioridad durante la noche';
$_['text_smart_post']                          = 'Envío Inteligente';
$_['text_standard_overnight']                  = 'Estándar Standard Overnight';
?>
