<?php
$_['text_handling'] = 'Gestión de Gastos';
?>