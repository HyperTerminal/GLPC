<?php
// Heading
$_['heading_title'] = 'No se encontró la página solicitada!';

// Text
$_['text_error']    = 'No se encontró la página solicitada!';
?>