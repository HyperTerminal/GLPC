<?php
$_['title']         = 'Enlace del reporte de OpenBay Pro';
$_['help']          = 'Click aquí para soporte';