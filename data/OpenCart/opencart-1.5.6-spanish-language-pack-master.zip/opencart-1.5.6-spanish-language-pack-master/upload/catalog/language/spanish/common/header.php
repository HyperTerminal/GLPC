<?php
// Text
$_['text_home']           = 'Inicio';
$_['text_wishlist']       = 'Lista de deseos (%s)';
$_['text_shopping_cart']  = 'Carrito de Compras';
$_['text_search']         = 'Buscar';
$_['text_welcome']        = '¡Bienvenido, usted puede <a href="%s">Iniciar sesión</a> o <a href="%s">Crear una</a>.';
$_['text_logged']         = 'Usted inicio sesión como <a href="%s">%s</a> <b>(</b> <a href="%s">Salir</a> <b>)</b>';
$_['text_account']        = 'Mi Cuenta';
$_['text_checkout']       = 'Realizar Pedido';
?>
