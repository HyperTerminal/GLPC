<?php
// Heading 
$_['heading_title'] = 'Lo más nuevo';

// Text
$_['text_reviews']  = 'Basado en %s valoraciones.';  
?>