<?php
// Text
$_['text_title']           = 'Tarjeta de crédito / Tarjeta de débito (Authorize.Net)';
$_['text_credit_card']     = 'Detalles de la tarjeta de crédito';
$_['text_wait']            = 'Por favor espera!';

// Entry
$_['entry_cc_owner']       = 'Dueño de la Tarjeta:';
$_['entry_cc_number']      = 'Número de la tarjeta:';
$_['entry_cc_expire_date'] = 'Fecha de expiración de la tarjeta:';
$_['entry_cc_cvv2']        = 'Código de seguridad de la tarjeta (CVV2):';
?>