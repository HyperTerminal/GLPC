<?php
// Text
$_['text_title']  = 'Envío basado en el peso';
$_['text_weight'] = 'Peso:'; 
?>