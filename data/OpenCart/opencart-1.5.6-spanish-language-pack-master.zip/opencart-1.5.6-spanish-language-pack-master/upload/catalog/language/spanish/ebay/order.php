<?php
$_['lang_shipping']     = 'Envios';
$_['lang_discount']     = 'Descuentos';
$_['lang_tax']          = 'Impuesto';
$_['lang_subtotal']     = 'Sub-total';
$_['lang_total']        = 'Total';
