<?php
// Heading 
$_['heading_title'] = 'Especiales';

// Text
$_['text_reviews']  = 'Basado en %s valoraciones.'; 
?>