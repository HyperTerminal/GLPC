<?php
// Heading
$_['heading_title']    = 'En mantenimiento';

// Text
$_['text_maintenance'] = 'En mantenimiento';
$_['text_message']     = '<h1 style="text-align:center;">Actualmente estamos realizando tareas de mantenimiento. <br/>Volveremos lo antes posible. Por favor regresa en breve!.</h1>';
?>