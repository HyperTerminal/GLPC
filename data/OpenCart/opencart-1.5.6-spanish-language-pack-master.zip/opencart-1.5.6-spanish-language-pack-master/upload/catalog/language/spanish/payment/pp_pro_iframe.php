<?php
// Text
$_['text_title'] = 'Tarjeta de credito o Debito';
$_['text_secure_connection'] = 'Creando una conexión segura...';

//Errors
$_['error_connection'] = "No pudimos conectar con PayPal. Por favor contactar con el administrador para asistencia o para obterner un metodo diferente de pago.";
?>