<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Peso:'; 
$_['text_insurance']   = 'Asegurado hasta:';   
$_['text_time']        = 'Tiempo estimado:  en 48 horas'; 
?>