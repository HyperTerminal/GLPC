<?php
$_['text_credit']   = 'Crédito de la Tienda';
$_['text_order_id'] = 'ID del Pedido ID: #%s';
?>