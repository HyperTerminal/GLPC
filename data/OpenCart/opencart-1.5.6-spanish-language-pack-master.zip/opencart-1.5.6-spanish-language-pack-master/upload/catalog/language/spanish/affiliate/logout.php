<?php
// Heading 
$_['heading_title'] = 'Salir de la cuenta';

// Text
$_['text_message']  = '<p>Has salido de tu cuenta de afiliados.</p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Salir';
?>