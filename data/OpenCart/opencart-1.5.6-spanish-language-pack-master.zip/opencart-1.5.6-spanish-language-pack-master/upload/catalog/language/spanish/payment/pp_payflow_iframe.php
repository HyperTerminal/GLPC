<?php
// Text
$_['text_title'] = 'Tarjeta de Credito o Debito PAYFLOW';
$_['text_secure_connection'] = 'Creando una conexión segura...';

//Errors
$_['error_connection'] = "No pudimos conectar con PayPal. Por favor contacta con el administrador de la tienda para asistencia o para seleccionar un metodo de pagod diferente.";
?>