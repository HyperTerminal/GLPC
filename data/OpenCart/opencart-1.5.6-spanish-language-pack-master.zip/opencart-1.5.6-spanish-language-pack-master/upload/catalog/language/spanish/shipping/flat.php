<?php
// Text
$_['text_title']       = 'Tarifa fija';
$_['text_description'] = 'Envío de tarifa fija';
?>
