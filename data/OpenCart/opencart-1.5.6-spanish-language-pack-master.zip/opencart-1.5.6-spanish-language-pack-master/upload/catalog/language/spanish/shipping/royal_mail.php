<?php
// Text
$_['text_title']                 = 'Royal Mail';
$_['text_weight']                = 'Peso:';
$_['text_insurance']             = 'Asegurado hasta:';
$_['text_1st_class_standard']    = 'Envío Estandar de Primera clase';
$_['text_1st_class_recorded']    = 'Envío Registrado de Primera clase';
$_['text_2nd_class_standard']    = 'Envío Estandar de segunda clase';
$_['text_2nd_class_recorded']    = 'Envío Registrado de segunda clase';
$_['text_special_delivery_500']  = 'Entrega Especial del Siguiente Día (&pound;500)';
$_['text_special_delivery_1000'] = 'Entrega Especial del Siguiente Díay (&pound;1000)';
$_['text_special_delivery_2500'] = 'Entrega Especial del Siguiente Díay (&pound;2500)';
$_['text_standard_parcels']      = 'Paquetes estándar';
$_['text_airmail']               = 'Airmail';
$_['text_international_signed']  = 'International Signed';
$_['text_airsure']               = 'Airsure';
$_['text_surface']               = 'Surface';
?>