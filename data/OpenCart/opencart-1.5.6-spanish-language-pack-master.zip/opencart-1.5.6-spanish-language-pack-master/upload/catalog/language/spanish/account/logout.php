<?php
// Heading 
$_['heading_title'] = 'Salir';

// Text
$_['text_message']  = '<p>Has cerrado sesión. Ahora puedes abandonar el ordenador.</p><p>Tu carrito  ha sido guardado, los items en la cesta se restaurarán cuando inicies sesión de nuevo con tu cuenta.</p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Salir';
?>