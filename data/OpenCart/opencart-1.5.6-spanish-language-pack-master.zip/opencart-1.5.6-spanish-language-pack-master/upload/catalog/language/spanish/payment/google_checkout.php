<?php
// Entry
$_['text_title'] = 'Trajeta de Crédito / Tarjeta de Debito (Google Checkout)';

// Error
$_['error_shipping'] = 'Cuidado: El metodo de envío es obligatorios!';
?>
