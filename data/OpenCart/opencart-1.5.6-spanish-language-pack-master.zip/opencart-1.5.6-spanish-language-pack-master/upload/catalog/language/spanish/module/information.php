<?php
// Heading 
$_['heading_title'] = 'Información';

// Text
$_['text_contact']  = 'Contáctanos';
$_['text_sitemap']  = 'Mapa del sitio';
?>