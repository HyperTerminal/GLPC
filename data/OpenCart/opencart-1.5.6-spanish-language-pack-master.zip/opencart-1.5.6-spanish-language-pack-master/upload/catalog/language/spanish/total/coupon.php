<?php
// Text
$_['text_coupon'] = 'Cupón(%s)';
?>