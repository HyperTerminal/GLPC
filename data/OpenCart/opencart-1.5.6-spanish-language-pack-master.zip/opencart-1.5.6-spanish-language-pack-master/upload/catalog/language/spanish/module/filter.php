<?php
// Heading
$_['heading_title'] = 'Redefinir Busqueda';
?>
