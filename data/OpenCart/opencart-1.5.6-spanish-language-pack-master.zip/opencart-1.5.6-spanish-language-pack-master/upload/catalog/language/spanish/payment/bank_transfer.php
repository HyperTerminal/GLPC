<?php
// Text
$_['text_title']       = 'Transferencia bancaria';
$_['text_instruction'] = 'Instrucciones de transferencia bancaria';
$_['text_description'] = 'Por favor transfiere la cantidad total a la siguiente cuenta bancaria.';
$_['text_payment']     = 'Tu pedido no se enviará hasta recibir el pago.';
?>