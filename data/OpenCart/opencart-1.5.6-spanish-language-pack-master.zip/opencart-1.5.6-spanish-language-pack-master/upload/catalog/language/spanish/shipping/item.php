<?php
// Text
$_['text_title']       = 'Por ítem';
$_['text_description'] = 'arifa de envío por ítem';
?>