<?php
// Text
$_['text_title']  = 'Servicio Postal de Estados Unidos';
$_['text_weight'] = 'Peso:';
$_['text_eta']    = 'Tiempo estimado:';
?>