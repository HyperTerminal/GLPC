<?php
// Text
$_['text_title'] = 'Tarjeta de Credito / Tarjeta de Debito (Payza)';
?>
