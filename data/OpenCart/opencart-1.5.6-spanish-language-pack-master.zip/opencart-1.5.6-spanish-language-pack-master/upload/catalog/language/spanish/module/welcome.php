<?php
$_['heading_title'] = 'Bienvenido a %s';
?>