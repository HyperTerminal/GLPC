<?php
// Text
$_['text_reward']   = 'Puntos de recompensa(%s)';
$_['text_order_id'] = 'ID del pedido: #%s';
?>