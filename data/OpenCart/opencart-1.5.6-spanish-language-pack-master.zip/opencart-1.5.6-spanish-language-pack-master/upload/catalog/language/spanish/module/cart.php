<?php
// Heading 
$_['heading_title'] = 'Carrito de Compras';

// Text
$_['text_items']    = '%s item(s) - %s';
$_['text_empty']    = 'Tu carrito de compras esta vacío!';
$_['text_cart']     = 'Ver carrito';
$_['text_checkout'] = 'Comprar';

$_['text_payment_profile'] = 'Perfil de pago';
?>