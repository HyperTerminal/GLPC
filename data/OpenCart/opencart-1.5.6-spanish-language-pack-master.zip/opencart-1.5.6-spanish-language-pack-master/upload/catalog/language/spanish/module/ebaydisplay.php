<?php
$_['heading_title']     = 'En tu tienda de eBay';
