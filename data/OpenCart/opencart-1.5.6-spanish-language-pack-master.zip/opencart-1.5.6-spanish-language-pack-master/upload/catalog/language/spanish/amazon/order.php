<?php

$_['paid_on_amazon_text'] = 'Pagado en Amazon';
$_['shipping_text'] = 'Enviando';
$_['shipping_tax_text'] = 'Impuesto del Envío';
$_['gift_wrap_text'] = 'Envoltura del regalo';
$_['gift_wrap_tax_text'] = 'Impuesto de la envoltura del regalo';
$_['sub_total_text'] = 'Sub-Total';
$_['tax_text'] = 'Impuesto';
$_['total_text'] = 'Total'; 