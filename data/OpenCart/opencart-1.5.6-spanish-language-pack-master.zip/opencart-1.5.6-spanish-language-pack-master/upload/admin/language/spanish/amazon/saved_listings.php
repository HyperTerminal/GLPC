<?php
$_['lang_title']                    = 'OpenBay Pro para Amazon | Listas Guardadas';
$_['lang_saved_listings']           = 'Listas Guardadas';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_overview']                 = 'Resumen Amazon';
$_['lang_btn_return']               = 'Cancelar';
$_['lang_description']              = 'Esta es la lista de productos que estan guardados localmente y listos para subir a Amazon. Click en subir a la entrada.';
$_['lang_actions_edit']             = 'Editar';
$_['lang_actions_remove']           = 'Remover';
$_['lang_btn_upload']               = 'Subir';
$_['lang_name_column']              = 'Nombre';
$_['lang_model_column']             = 'Modelo';
$_['lang_sku_column']               = 'SKU';
$_['lang_amazon_sku_column']        = 'SKU del artículo de Amazon';
$_['lang_actions_column']           = 'Acción';
$_['lang_uploaded_alert']           = 'Lista(s) subida(s) guradada(s)!';
$_['lang_delete_confirm']           = '¿Estas seguro?';