<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro para eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Importancia del Pedido';
$_['lang_btn_return']                   = 'Devolución';
$_['lang_sync_orders']                  = 'Pedidos';
$_['lang_sync_pull_orders']             = 'Tirar nuevos pedidos';
$_['lang_sync_pull_orders_text']        = 'Tirar Pedidos';
$_['lang_ajax_load_error']              = 'Perdon, NO pudimos obtener una conección';
$_['lang_error_validation']             = 'Tenecistas registrar tu API del token y habilitar el modulo.';
$_['lang_sync_pull_notice']             = 'Esto jalara nuevos pedidos desde el ultimo chequeo automatizado. Si tu solo lo has instalado sera activado por defualt dentro de 24 horas.';
$_['lang_ajax_orders_import']           = 'Cualquier pedido nuevo, debería aparecer dentro de un par de minutos';