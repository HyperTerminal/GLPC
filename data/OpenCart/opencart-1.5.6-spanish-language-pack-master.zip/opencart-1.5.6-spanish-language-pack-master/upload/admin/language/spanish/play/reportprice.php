<?php
$_['lang_cancel']                           = 'Cancelar';
$_['lang_page_title']                       = 'Reporte comparador de precios';
$_['lang_column_name']                      = 'Nombre';
$_['lang_column_dispatchto']                = 'Dispachar a';
$_['lang_column_price_uk']                  = 'Tu Precio (UK)';
$_['lang_column_price_cheap_uk']            = 'El precio mas barato (UK)';
$_['lang_column_price_euro']                = 'Tu precio (Europa)';
$_['lang_column_price_cheap_euro']          = 'El precio mas barato(Europa)';
$_['lang_column_stock']                     = 'Stock';
$_['lang_column_product_id']                = 'ID';
$_['lang_column_product_type']              = 'Tipo de ID';
$_['lang_no_data_found']                    = 'Datos sobre el precio no fueron encontrados';
$_['lang_created']                          = 'Reporte creado: ';