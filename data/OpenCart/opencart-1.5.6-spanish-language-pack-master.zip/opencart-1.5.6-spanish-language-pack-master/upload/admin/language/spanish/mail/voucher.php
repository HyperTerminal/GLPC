<?php
// Text
$_['text_subject']  = 'Has enviado un vale de regalo desde %s';
$_['text_greeting'] = 'Enhorabuena, ha recibido un Vale de regalo por %s';
$_['text_from']     = 'Este certificado de regalo ha sido enviado por %s';
$_['text_message']  = 'Con un mensaje que dice';
$_['text_redeem']   = 'Para usar este vale regalo, anote el código de la redención que es <b>%s</b> y luego haga click en el siguiente enlace para adquirir el producto que desee usando este vale de regalo. Tambien puede introducir el código en la página del carrito antes de proceder al pago.';
$_['text_footer']   = 'Por favor responda a este email si tiene alguna duda.';
?>
