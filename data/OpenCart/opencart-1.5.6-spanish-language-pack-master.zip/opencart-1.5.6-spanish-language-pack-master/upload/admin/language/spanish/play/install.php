<?php
$_['heading_title']                     = 'Play.com (Europa)';
$_['text_edit']                         = 'Editar';
$_['text_install']                      = 'Instalar';
$_['text_uninstall']                    = 'Desinstalar';
$_['text_enabled']                      = 'Habilitado';
$_['text_disabled']                     = 'No Habilitado';
$_['lang_text_success']                 = 'Has guardado tus cmabios en la extensión de Play.com';