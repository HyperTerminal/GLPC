<?php
// Heading
$_['heading_title'] = 'Boton para pagos de Amazon';

$_['text_module'] = 'Modulos';
$_['text_success'] = 'Exito: Has modificado el modulo de Pagos de Amazon!';
$_['text_content_top'] = 'Contenido Superior';
$_['text_content_bottom'] = 'Boton de contenido';
$_['text_column_left'] = 'Columna Izquierda';
$_['text_column_right'] = 'Columna Derecha';

$_['entry_layout'] = 'Disposición:';
$_['entry_position'] = 'Posición:';
$_['entry_status'] = 'Estatus:';
$_['entry_sort_order'] = 'Orden de Aparición:';

$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el modulo de Pagos de Amazon!';