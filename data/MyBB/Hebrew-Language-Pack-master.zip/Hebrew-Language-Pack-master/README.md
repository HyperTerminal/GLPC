Hebrew-Language-Pack
====================

A hebrew language pack for MyBB 1.x