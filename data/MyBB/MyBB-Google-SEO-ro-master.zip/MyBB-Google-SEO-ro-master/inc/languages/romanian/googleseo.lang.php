<?php

$l['googleseo_404_notfound'] = "404 Nu s-a gãsit";
$l['googleseo_404_widget'] = "<script type=\"text/javascript\">\nvar GOOG_FIXURL_LANG = 'en';\nvar GOOG_FIXURL_SITE = '{1}';\n</script>\n<script type=\"text/javascript\" src=\"http://linkhelp.clients.google.com/tbproxy/lh/wm/fixurl.js\"></script>";
$l['googleseo_404_wol'] = "Seeing an <a href=\"{1}\">Error Page</a>";
$l['googleseo_meta_page'] = "Paginã";
$l['googleseo_sitemap_disabledorinvalid'] = "Sitem disabled or invalid.";
$l['googleseo_sitemap_emptyorinvalid'] = "Sitemap empty or invalid page.";
$l['googleseo_sitemap_pageinvalid'] = "Sitemap page invalid.";
$l['googleseo_sitemap_wol'] = "Browsing the <a href=\"{1}\">XML Sitemap</a>";

?>
