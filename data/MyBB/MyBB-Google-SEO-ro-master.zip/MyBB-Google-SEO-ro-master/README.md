MyBB-Google-SEO-ro
==================

MyBB-Google-SEO-romanian-language-pack

This package contains only the romanian language pack

You can get complete plugin here: http://mods.mybb.com/view/google-seo

======================================================================

Pachetul de limba pentru MyBB-Google-SEO
