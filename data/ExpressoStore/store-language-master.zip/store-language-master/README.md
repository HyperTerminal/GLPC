# Store Language Pack

Want to translate Expresso Store into your native tounge? You're in the right place!

This repository contains the language files for our flagship [ExpressionEngine e-commerce](https://exp-resso.com/store) product. If you have
translated Store, please feel free to submit a pull request, and we will include your translation in our next release.

All language files are licensed under a [Creative Commons Attribution](http://creativecommons.org/licenses/by/3.0/) license.
