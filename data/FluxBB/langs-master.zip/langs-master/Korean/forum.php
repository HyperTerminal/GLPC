<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'새 글타래 올리기',
'Views'			=>	'읽음',
'Moved'			=>	'옮김:',
'Sticky'		=>	'붙임:',
'Closed'		=>	'닫힘:',
'Empty forum'	=>	'포럼이 비었다.',
'Mod controls'	=>	'지킴이 다룸판',
'Is subscribed'	=>	'너는 지금 이 포럼을 받아보고 있다',
'Unsubscribe'	=>	'받아보지 않기',
'Subscribe'		=>	'이 포럼을 받아보기'

);
