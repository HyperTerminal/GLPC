<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'신고를 읽은 것으로 표시했다. Redirecting …',
'New reports head'			=>	'새로운 신고',
'Deleted user'				=>	'회원을 지웠음',
'Deleted'					=>	'지웠음',
'Post ID'					=>	'글 #%s',
'Report subhead'			=>	'신고날짜: %s',
'Reported by'				=>	'신고자: %s',
'Reason'					=>	'신고 이유',
'Zap'						=>	'읽은 것으로 표시',
'No new reports'			=>	'새로운 신고가 없다.',
'Last 10 head'				=>	'마지막 읽은 10 개의 신고',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'%2$s가 %1$s에 읽은 것으로 표시했다',
'No zapped reports'			=>	'읽은 신고가 없다.',

);
