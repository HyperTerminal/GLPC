<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'글 지우기',
'Warning'				=>	'이 글을 완전히 지우려고 한다.',
'Topic warning'			=>	'경고! 이것은 글타래의 첫 글이어서 글타래가 통째로 완전히 지워질 것이다.',
'Delete info'			=>	'처리하기에 앞서서 지우려는 글을 다시 살피기위해 아래에 놓여져 있다.',
'Reply by'				=>	'%s의 댓글 - %s',
'Topic by'				=>	'%s가 시작한 글타래 - %s',
'Delete'				=>	'지우기', // The submit button
'Post del redirect'		=>	'글을 지웠다. Redirecting …',
'Topic del redirect'	=>	'글타래를 지웠다. Redirecting …'

);
