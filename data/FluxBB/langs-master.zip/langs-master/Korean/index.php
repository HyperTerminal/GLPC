<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'		=>	'글타래',
'Link to'		=>	'링크:', // As in "Link to: http://fluxbb.org/"
'Empty board'	=>	'게시판이 비었다.',
'Newest user'	=>	'최근 가입한 회원: %s',
'Users online'	=>	'접속한 회원: %s',
'Guests online'	=>	'접속한 손님: %s',
'No of users'	=>	'전체 회원: %s',
'No of topics'	=>	'전체 글타래: %s',
'No of posts'	=>	'전체 글: %s',
'Online'		=>	'접속자:', // As in "Online: User A, User B etc."
'Board info'	=>	'게시판 정보',
'Board stats'	=>	'게시판 통계',
'User info'		=>	'회원 정보'

);
