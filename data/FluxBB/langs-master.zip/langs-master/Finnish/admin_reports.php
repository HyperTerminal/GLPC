<?php

// Language definitions used in admin_reports.php
// Finnish translation by Pauligrinder
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Raportti merkitty luetuksi. Siirrytään …',
'New reports head'			=>	'Uudet raportit',
'Deleted user'				=>	'Poistettu käyttäjä',
'Deleted'					=>	'Poistettu',
'Post ID'					=>	'Kirjoitus #%s',
'Report subhead'			=>	'Raportoi %s',
'Reported by'				=>	'Raportin lähetti %s',
'Reason'					=>	'Syy',
'Zap'						=>	'Merkkaa luetuksi',
'No new reports'			=>	'Ei ole uusia raportteja.',
'Last 10 head'				=>	'10 viimeksi luettua raporttia',
'NA'						=>	'Tyhjä',
'Zapped subhead'			=>	'Merkattu luetuksi %s %s:n toimesta',
'No zapped reports'			=>	'Ei ole luettuja raportteja.',

);
