<?php

// Language definitions used in userlist.php
// Finnish translation by Pauligrinder
$lang_ul = array(

'User find legend'	=>	'Etsi ja lajittele käyttäjiä',
'User search info'	=>	'Anna hakusana.',
'User sort info'	=>	'Lajittele käyttäjät nimen, rekisteröitymisajan tai kirjoitusten määrän mukaan, nousevassa tai laskevassa järjestyksessä.',
'User group'		=>	'Käyttäjäryhmä',
'No of posts'		=>	'Kirjoitusten määrä',
'All users'			=>	'Kaikki'

);
