<?php

// Language definitions used in viewforum.php
// Finnish translation by Pauligrinder
$lang_forum = array(

'Post topic'		=>	'Aloita uusi otsikko.',
'Views'             =>	'Katsottu',
'Moved'             =>	'Siirretty:',
'Sticky'            =>	'Liimattu:',
'Closed'            =>	'Suljettu:',
'Empty forum'		=>	'Forumi on tyhjä.',
'Mod controls'		=>	'Moderaattorin asetukset',
'Is subscribed'		=>	'Seuraat tällä hetkellä tätä forumia',
'Unsubscribe'		=>	'Lopeta seuranta',
'Subscribe'         =>	'Seuraa tätä forumia'

);
