<?php

// Language definitions used in delete.php
// Finnish translation by Pauligrinder
$lang_delete = array(

'Delete post'			=>	'Poista kirjoitus.',
'Warning'               =>	'Olet poistamassa tämän otsikon pysyvästi.',
'Topic warning'			=>	'Varoitus! Tämä on otsikon ensimmäinen kirjoitus, joten koko otsikko poistetaan jos poistat tämän!',
'Delete info'			=>	'Lukaise vielä kirjoitus läpi ennen poistamista.',
'Reply by'              =>	'%s vastasi - %s',
'Topic by'              =>	'Otsikon aloitti %s - %s',
'Delete'                =>	'Poista', // The submit button
'Post del redirect'		=>	'Kirjoitus poistettu. Siirrytään …',
'Topic del redirect'	=>	'Otsikko poistettu. Siirrytään …'

);
