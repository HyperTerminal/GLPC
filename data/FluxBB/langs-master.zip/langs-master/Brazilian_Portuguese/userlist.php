<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'	=>	'Encontrar e ordenar usuários',
'User search info'	=>	'Digite um nome de usuário a ser pesquisado e/ou um grupo de usuário a filtrar. O campo de nome de usuário pode ser deixado em branco. Use o caractere curinga * para combinações parciais.',
'User sort info'	=>	'Ordenar usuários por nome, data de registro ou número de mensagens em ordem ascendente/decrescente.',
'User group'		=>	'Grupo de usuário',
'No of posts'		=>	'Número de mensagens',
'All users'			=>	'Todos'

);
