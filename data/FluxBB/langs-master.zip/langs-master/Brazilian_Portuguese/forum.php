<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Criar novo tópico',
'Views'			=>	'Visualizações',
'Moved'			=>	'Movido:',
'Sticky'		=>	'Fixado:',
'Closed'		=>	'Fechado:',
'Empty forum'	=>	'O fórum está vazio.',
'Mod controls'	=>	'Controles de moderação',
'Is subscribed'	=>	'Você está atualmente inscrito neste fórum',
'Unsubscribe'	=>	'Cancelar inscrição',
'Subscribe'		=>	'Inscrever-me neste fórum'

);
