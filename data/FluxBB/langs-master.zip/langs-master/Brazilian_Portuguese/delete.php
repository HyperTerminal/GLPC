<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Excluir mensagem',
'Warning'				=>	'Você está prestes a excluir permanentemente esta mensagem.',
'Topic warning'			=>	'Aviso! Este é a primeira mensagem do tópico, portanto, o tópico inteiro será excluído permanentemente.',
'Delete info'			=>	'A mensagem que você escolheu excluir está exibida abaixo para que você a revise antes de prosseguir.',
'Reply by'				=>	'Resposta por %s - %s',
'Topic by'				=>	'Tópico iniciado por %s - %s',
'Delete'				=>	'Excluir', // The submit button
'Post del redirect'		=>	'Mensagem excluída. Redirecionando …',
'Topic del redirect'	=>	'Tópico excluído. Redirecionando …'

);
