<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'		=>	'Tópicos',
'Link to'		=>	'Link para:', // As in "Link to: http://fluxbb.org/"
'Empty board'	=>	'O site está vazio.',
'Newest user'	=>	'Último usuário registrado: %s',
'Users online'	=>	'Usuários registrados online: %s',
'Guests online'	=>	'Visitantes online: %s',
'No of users'	=>	'Total de usuários registrados: %s',
'No of topics'	=>	'Total de tópicos: %s',
'No of posts'	=>	'Total de mensagens: %s',
'Online'		=>	'Online:', // As in "Online: User A, User B etc."
'Board info'	=>	'Informações do site',
'Board stats'	=>	'Estatísticas do site',
'User info'		=>	'Informações de usuários'

);
