<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Relatório marcado como lido. Redirecionando …',
'New reports head'			=>	'Novos relatórios',
'Deleted user'				=>	'Usuário excluído',
'Deleted'					=>	'Excluído',
'Post ID'					=>	'Mensagem #%s',
'Report subhead'			=>	'Denunciado %s',
'Reported by'				=>	'Denunciado por %s',
'Reason'					=>	'Razão',
'Zap'						=>	'Marcar como lido',
'No new reports'			=>	'Não há novos relatórios.',
'Last 10 head'				=>	'Últimos 10 relatórios lidos',
'NA'						=>	'N/D',
'Zapped subhead'			=>	'Marcado como lido %s por %s',
'No zapped reports'			=>	'Não há relatórios lidos.',

);
