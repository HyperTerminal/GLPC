<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nέο θέμα',
'Views'			=>	'Προβολές',
'Moved'			=>	'Μετακινήθηκε:',
'Sticky'		=>	'Μόνιμο:',
'Closed'		=>	'Κλειδωμένο:',
'Empty forum'	=>	'Η δημόσια συζήτηση είναι κενή.',
'Mod controls'	=>	'Διαχείρηση Συντονιστή',
'Is subscribed'	=>	'Αυτή τη στιγμή είστε συνδρομητής σε αυτή την κοινότητα',
'Unsubscribe'	=>	'Διαγραφή εγγραφής',
'Subscribe'		=>	'Εγγραφή σε αυτή τη δημόσια συζήτηση'

);
