<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'H αναφορά σημάνθηκε ως αναγνωσμένη. Ανακατεύθυνση...',
'New reports head'			=>	'Νέες αναφορές',
'Deleted user'				=>	'Διαγραμμένος χρήστης',
'Deleted'					=>	'Διαγράθηκε',
'Post ID'					=>	'Δημοσίευση #%s',
'Report subhead'			=>	'Aναφέρθηκε %s',
'Reported by'				=>	'Aναφέρθηκε από %s',
'Reason'					=>	'Λόγος',
'Zap'						=>	'Σήμανση ως αναγνωσμένη',
'No new reports'			=>	'Δεν υπάρχουν νέες αναφορές.',
'Last 10 head'				=>	'Οι 10 τελευταίες αναγνωσμένες αναφορές',
'NA'						=>	'Μη διαθέσιμο',
'Zapped subhead'			=>	'Σήμανση ως αναγνωσμένη %s από %s',
'No zapped reports'			=>	'Δεν υπάρχουν αναγνωσμένες αναφορές.',

);
