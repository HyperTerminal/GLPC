<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Απάντηση',
'Topic closed'		=>	'Κλειδωμένο θέμα',
'From'				=>	'Από:', // User location
'IP address logged'	=>	'Καταγεγραμμένη διεύθυνση ΙΡ',
'Note'				=>	'Σημείωση:', // Admin note
'Posts'				=>	'Δημοσιεύσεις:',
'Registered'		=>	'Εγγραφή:',
'Replies'			=>	'Απαντήσεις:',
'Website'			=>	'Ιστοσελίδα',
'Guest'				=>	'Επισκέπτης',
'Online'			=>	'Συνδεδεμένος',
'Offline'			=>	'Εκτός σύνδεσης',
'Last edit'			=>	'Τελευταία επεξεργασία από',
'Report'			=>	'Αναφορά',
'Delete'			=>	'Διαγραφή',
'Edit'				=>	'Επεξεργασία',
'Quote'				=>	'Παράθεση',
'Is subscribed'		=>	'Είστε συνδρομητής σε αυτό το θέμα',
'Unsubscribe'		=>	'Διαγραφή συνδρομής',
'Subscribe'			=>	'Εγγραφή σε αυτό το θέμα',
'Quick post'		=>	'Γρήγορη απάντηση',
'Mod controls'		=>	'Έλεγχος Συντονιστή',
'New icon'			=>	'Νέο εικονίδιο',
'Re'				=>	'Απ:',
'Preview'			=>	'Προεπισκόπηση'

);
