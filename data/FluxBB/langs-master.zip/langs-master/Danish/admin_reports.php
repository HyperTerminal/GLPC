<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Rapporter markeret som læst. Omdirigere …',
'New reports head'			=>	'Nye rapporter',
'Deleted user'				=>	'Slettede bruger',
'Deleted'					=>	'slettet',
'Post ID'					=>	'Indlæg #%s',
'Report subhead'			=>	'Rapporteret %s',
'Reported by'				=>	'Rapporteret af %s',
'Reason'					=>	'Grundet',
'Zap'						=>	'Marker som læst',
'No new reports'			=>	'Der er ingen nye rapporter.',
'Last 10 head'				=>	'10 sidst læste rapporter',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'Maker som læst %s af %s',
'No zapped reports'			=>	'Der er ingen læste rapporter.',

);
