<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Svar på indlæg',
'Topic closed'		=>	'Emnet er lukket',
'From'				=>	'Fra:', // User location
'IP address logged'	=>	'IP adresse logget',
'Note'				=>	'Bemærk:', // Admin note
'Posts'				=>	'Indlæg:',
'Registered'		=>	'Registreret:',
'Replies'			=>	'Svar:',
'Website'			=>	'Webside',
'Guest'				=>	'Gæst',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Sidst redigeret af:',
'Report'			=>	'Anmeld',
'Delete'			=>	'Slet',
'Edit'				=>	'Redigér',
'Quote'				=>	'Citér',
'Is subscribed'		=>	'Du abonnerer til dette emne.',
'Unsubscribe'		=>	'Frmeld abonnement',
'Subscribe'			=>	'Abonnér på dette emne',
'Quick post'		=>	'Hurtig indlæg',
'Mod controls'		=>	'Moderator kontrollerer',
'New icon'			=>	'Nyt indlæg',
'Re'				=>	'Re:',
'Preview'			=>	'Forhåndsvisning'

);
