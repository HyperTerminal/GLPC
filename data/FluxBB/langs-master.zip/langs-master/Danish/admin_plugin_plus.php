<?php

// Language definitions used in example Plugin
$lang_admin_plugin_plus = array(

'Pages in database'			=>	'Static Pages in database',
'Title'		=>	'Title',
'Edit'			=>	'Edit',
'Delete'			=>	'Delete',
'Alert'			=>	'<strong>CKEditor requires JavaScript to run</strong>. In a browser with no JavaScript support, like yours, you should still see the contents (HTML data) and you should be able to edit it normally, without a rich editor interface.',
'Submit'		=>	'Submit',
'Update'		=>	'Update',
'New page'			=>	'New page',
'Editing'			=>	'Content to edit',
'Deleting'			=>	'Content to delete',
'Create new page'			=>	'Create new page',
'Edit page'			=>	'Editing of page',
'Delete page'			=>	'Deleting of page',
'Create success'			=>	'Page created with success.',
'Update success'			=>	'Page updated with success.',
'Delete success'			=>	'Page deleted with success.',

);
