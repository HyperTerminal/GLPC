<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Slet indlæg',
'Warning'				=>	'Du er ved at slette dette indlæg.',
'Topic warning'			=>	'Advarsel! Dette er det første indlæg i emnet, vil hele emnet blive slettet permanent.',
'Delete info'			=>	'Det indlæg, du har valgt at slette, er angivet nedenfor for dig at gennemgå, før du fortsætter.',
'Reply by'				=>	'Svar til %s - %s',
'Topic by'				=>	'Emne startet af %s - %s',
'Delete'				=>	'Slet', // The submit button
'Post del redirect'		=>	'Indlæg slettet. Omdirigere …',
'Topic del redirect'	=>	'Emne slettet. Omdirigere …'

);
