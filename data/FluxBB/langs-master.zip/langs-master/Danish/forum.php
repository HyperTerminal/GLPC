<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Poster nyt emne',
'Views'			=>	'Visninger',
'Moved'			=>	'Flyttet:',
'Sticky'		=>	'Sticky:',
'Closed'		=>	'Lukket:',
'Empty forum'	=>	'Forumet er tomt.',
'Mod controls'	=>	'Moderator panel',
'Is subscribed'	=>	'Du har i øjeblikket afmeldt abonnering på dette forum',
'Unsubscribe'	=>	'Afmeld abonnement',
'Subscribe'		=>	'Abonner på dette forum'

);
