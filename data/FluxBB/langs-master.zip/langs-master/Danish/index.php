<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'		=>	'Emner',
'Link to'		=>	'Link til:', // As in "Link to: http://fluxbb.org/"
'Empty board'	=>	'Boardet er tomt.',
'Newest user'	=>	'Nyeste registrerede bruger: %s',
'Users online'	=>	'Registrerede brugere online: %s',
'Guests online'	=>	'Gæster online: %s',
'No of users'	=>	'Totale antal registrerede brugere: %s',
'No of topics'	=>	'Totale antal emner: %s',
'No of posts'	=>	'Totale antal posteringer: %s',
'Online'		=>	'Online:', // As in "Online: User A, User B etc."
'Board info'	=>	'Board information',
'Board stats'	=>	'Board statistik',
'User info'		=>	'Bruger information'

);
