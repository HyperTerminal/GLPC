<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'	=>	'Find og sortér brugere',
'User search info'	=>	'Indtast et brugernavn at søge efter og/eller en brugergruppe at filtrere efter. Brugernavns feltet kan blive ladet være blankt. Brug jokertegnet * for at finde delvise resultater.',
'User sort info'	=>	'Sortér brugere efter navn, dato registreret eller antal af indlæg og i stigende/faldende orden.',
'User group'		=>	'Brugergruppe',
'No of posts'		=>	'Antal af indlæg',
'All users'			=>	'Alle'

);
