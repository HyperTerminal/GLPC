<?php

// Sprachdefinitionen, die in delete.php verwendet werden
$lang_delete = array(

'Delete post'			=>	'Beitrag löschen',
'Warning'				=>	'Sie sind dabei, diesen Beitrag unwiderruflich zu löschen.',
'Topic warning'			=>	'Achtung! Dies ist der erste Beitrag in diesem Thema: Das ganze Thema wird unwiderruflich gelöscht.',
'Delete info'			=>	'Unten finden Sie den zu löschenden Beitrag.',
'Reply by'				=>	'Antwort von %s - %s',
'Topic by'				=>	'Thema erstellt von %s - %s',
'Delete'				=>	'Löschen', // Beschriftung des Absende-Buttons
'Post del redirect'		=>	'Beitrag gelöscht. Leite weiter …',
'Topic del redirect'	=>	'Thema gelöscht. Leite weiter …'

);
