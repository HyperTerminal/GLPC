<?php

// Sprachdefinitionen, die viewtopic.php verwendet werden
$lang_topic = array(

'Post reply'		=>	'Beitrag schreiben',
'Topic closed'		=>	'Thema geschlossen',
'From'				=>	'Ort:', // Mitglieds-Wohnort
'IP address logged'	=>	'IP-Adresse',
'Note'				=>	'Notiz:', // Administratoren-Notiz
'Posts'				=>	'Beiträge:',
'Registered'		=>	'Registriert:',
'Replies'			=>	'Antworten:',
'Website'			=>	'Webseite',
'Guest'				=>	'Gast',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Beitrag geändert von',
'Report'			=>	'Melden',
'Delete'			=>	'Löschen',
'Edit'				=>	'Bearbeiten',
'Quote'				=>	'Zitieren',
'Is subscribed'		=>	'Sie haben dieses Thema abonniert',
'Unsubscribe'		=>	'Abonnement abbestellen',
'Subscribe'			=>	'Dieses Thema abonnieren',
'Quick post'		=>	'Schnellantwort auf dieses Thema',
'Mod controls'		=>	'Moderatorkontrollen',
'New icon'			=>	'Neuer Beitrag',
'Re'				=>	'Re:',
'Preview'			=>	'Vorschau'

);
