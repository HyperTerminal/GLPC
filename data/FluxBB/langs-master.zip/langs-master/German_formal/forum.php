<?php

// Sprachdefinitionen, die in viewforum.php verwendet werden
$lang_forum = array(

'Post topic'	=>	'Neues Thema erstellen',
'Views'			=>	'Aufrufe',
'Moved'			=>	'Verschoben:',
'Sticky'		=>	'Fixiert:',
'Closed'		=>	'Geschlossen:',
'Empty forum'	=>	'Das Forum enthält noch keine Themen.',
'Mod controls'	=>	'Moderationsfunktionen',
'Is subscribed'	=>	'Sie haben dieses Forum abonniert',
'Unsubscribe'	=>	'Abonnement abbestellen',
'Subscribe'		=>	'Dieses Forum abonnieren'

);
