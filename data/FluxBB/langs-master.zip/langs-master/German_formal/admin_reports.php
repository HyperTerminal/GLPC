<?php

// Sprachdefinitionen, die in admin_reports.php verwendet werden
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Meldung als gelesen markiert. Leite weiter …',
'New reports head'			=>	'Neue Meldungen',
'Deleted user'				=>	'Gelöschtes Mitglied',
'Deleted'					=>	'Gelöscht',
'Post ID'					=>	'Beitrag #%s',
'Report subhead'			=>	'Gemeldet %s',
'Reported by'				=>	'Gemeldet von %s',
'Reason'					=>	'Grund',
'Zap'						=>	'Als gelesen markieren',
'No new reports'			=>	'Derzeit gibt es keine neuen Meldungen.',
'Last 10 head'				=>	'Die zehn letzten gelesenen Meldungen',
'NA'						=>	'Keine Daten verfügbar',
'Zapped subhead'			=>	'Gelöscht %s von %s',
'No zapped reports'			=>	'Derzeit gibt es keine ungelesenen Meldungen.',

);
