<?php

// Language definitions used in delete.php
$lang_delete = array(
 
'Delete post'			=>	'Supprimer le message',
'Warning'			=>	'Vous êtes sur le point de supprimer définitivement ce message&#160;!',
'Topic warning'			=>	'Attention&#160;! Ceci est le premier message de cette discussion, toute la discussion sera définitivement supprimée.',
'Delete info'			=>	'Le message que vous souhaitez supprimer vous est présenté ci-dessous afin que vous puissiez le revoir avant de continuer.',
'Reply by'			=>	'Réponse de %s - %s',
'Topic by'			=>	'Discussion démarrée par %s - %s',
'Delete'			=>	'Supprimer',	// The submit button
'Post del redirect'		=>	'Message supprimé. Redirection&#160;…',
'Topic del redirect'		=>	'Discussion supprimée. Redirection&#160;…'
 
);