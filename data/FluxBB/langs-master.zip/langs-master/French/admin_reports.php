<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'		=>	'Signalement traité. Redirection&#160;…',
'New reports head'			=>	'Nouveaux signalements',
'Deleted user'				=>	'Utilisateur supprimé',
'Deleted'				=>	'Supprimé',
'Post ID'                               =>      'Message n°%s',
'Report subhead'			=>	'Signalé&#160;: %s',
'Reported by'				=>	'Signalé par %s',
'Reason'				=>	'Motif',
'Zap'					=>	'Marquer comme traité',
'No new reports'			=>	'Aucun nouveau signalement pour l\'instant.',
'Last 10 head'				=>	'10 derniers signalements traités',
'NA'					=>	'N/A',
'Zapped subhead'			=>	'Traité le %s par %s',
'No zapped reports'			=>	'Aucun signalement traité pour le moment.',

);