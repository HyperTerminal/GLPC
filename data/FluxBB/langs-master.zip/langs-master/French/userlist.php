<?php

// Language definitions used in userlist.php
$lang_ul = array(
 
'User find legend'		=>	'Chercher et trier les utilisateurs',
'User search info'		=>	'Saisissez un nom d\'utilisateur pour le rechercher et/ou un groupe d\'utilisateurs pour filtrer les résultats. Le champ «&#160;Nom d\'utilisateur&#160;» peut rester vide. Utilisez le joker * pour des recherches sur une partie du nom.',
'User sort info'		=>	'Triez les utilisateurs par nom, date d\'inscription ou nombre de messages et dans l\'ordre croissant ou décroissant.',
'User group'			=>	'Groupe d\'utilisateurs',
'No of posts'			=>	'Nombre de messages',
'All users'			=>	'Tous les utilisateurs'
 
);