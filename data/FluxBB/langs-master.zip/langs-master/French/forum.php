<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nouvelle discussion',
'Views'		=>	'Vues',
'Moved'		=>	'Déplacée&#160;:',
'Sticky'	=>	'Épinglée&#160;:',
'Closed'	=>	'Fermée&#160;:',
'Empty forum'	=>	'Le forum ne contient aucune discussion.',
'Mod controls'	=>	'Interventions pour modérateurs',
'Is subscribed'	=>	'Vous suivez ce forum',
'Unsubscribe'	=>	'Ne plus suivre',
'Subscribe'	=>	'Suivre ce forum'
);
