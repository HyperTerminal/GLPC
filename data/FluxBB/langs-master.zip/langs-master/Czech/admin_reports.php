<?php

// Language definitions used in admin_reports.php
// Untranslated: 0
// Czech (UTF-8 v1.4.5): MartinR [martin.ruzicka.cz(at)gmail.com]
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Hlášení označeno za přečtené. Přesměrování…',
'New reports head'			=>	'Nová hlášení',
'Deleted user'				=>	'Odstraněno uživatelem',
'Deleted'					=>	'Odstraněno',
'Post ID'					=>	'Příspěvek #%s',
'Report subhead'			=>	'Ohlášeno %s',
'Reported by'				=>	'Od %s',
'Reason'					=>	'Důvod',
'Zap'						=>	'Označit za přečtené',
'No new reports'			=>	'Nejsou zde žádná hlášení.',
'Last 10 head'				=>	'Posledních 10&nbsp;hlášení, označených za přečtené',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'Označeno za přečtené %s uživatelem %s',
'No zapped reports'			=>	'Nejsou zde žádná hlášení.',

);
