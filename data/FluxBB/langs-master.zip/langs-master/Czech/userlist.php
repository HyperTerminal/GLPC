<?php

// Language definitions used in userlist.php
// Untranslated: 0
// Czech (UTF-8 v1.4.5): MartinR [martin.ruzicka.cz(at)gmail.com]
$lang_ul = array(

'User find legend'		=>	'Najít a seřadit uživatele',
'User search info'		=>	'Zadejte jméno hledaného uživatele nebo skupinu uživatelů, podle které filtrovat. Textové pole jméno uživatele může zůstat prázdné. Použijte znak * pro vyhledávání podle části jména.',
'User sort info'		=>	'Uživatelé budou seřazeni podle jména, data registrace, nebo počtu příspěvků vzestupně/sestupně.',
'User group'			=>	'Uživatelské skupiny',
'No of posts'			=>	'Počet příspěvků',
'All users'				=>	'Všichni'

);
