<?php

// Language definitions used in delete.php
// Untranslated: 0
// Czech (UTF-8 v1.4.5): MartinR [martin.ruzicka.cz(at)gmail.com]
$lang_delete = array(

'Delete post'			=>	'Odstranit příspěvek',
'Warning'				=>	'Chystáte se trvale odstranit tento příspěvek.',
'Topic warning'			=>	'Upozornění! To je první příspěvek v tématu, celé téma bude trvale odstraněno.',
'Delete info'			=>	'Rozhodli jste se odstranit níže uvedený příspěvek, ujistěte se před pokračováním.',
'Reply by'				=>	'Odpověď od %s - %s',
'Topic by'				=>	'Téma založil %s - %s',
'Delete'				=>	'Odstranit', // The submit button
'Post del redirect'		=>	'Příspěvek odstraněn. Přesměrovávání…',
'Topic del redirect'	=>	'Téma odstraněno. Přesměrovávání…'

);
