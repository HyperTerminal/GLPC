<?php

// Language definitions used in viewtopic.php
// Untranslated: 0
// Czech (UTF-8 v1.4.5): MartinR [martin.ruzicka.cz(at)gmail.com]
$lang_topic = array(

'Post reply'		=>	'Odpovědět',
'Topic closed'		=>	'Téma zavřeno',
'From'				=>	'Místo:', // User location
'IP address logged'	=>	'IP adresa zaznamenána',
'Note'				=>	'Poznámka:', // Admin note
'Posts'				=>	'Příspěvky:',
'Registered'		=>	'Registrován:',
'Replies'			=>	'Odpovědi:',
'Website'			=>	'Web',
'Guest'				=>	'Host',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Upravil',
'Report'			=>	'Nahlásit',
'Delete'			=>	'Odstranit',
'Edit'				=>	'Upravit',
'Quote'				=>	'Citovat',
'Is subscribed'		=>	'Nyní jste přihlášeni k odběru příspěvků v tomto tématu',
'Unsubscribe'		=>	'Odhlásit z odběru',
'Subscribe'			=>	'Přihlásit k odběru příspěvků v tomto tématu',
'Quick post'		=>	'Rychlá odpověď',
'Mod controls'		=>	'Moderátorské ovládání',
'New icon'			=>	'Nový příspěvek',
'Re'				=>	'Re:',
'Preview'			=>	'Náhled'

);
