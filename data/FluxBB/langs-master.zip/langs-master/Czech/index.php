<?php

// Language definitions used in index.php
// Untranslated: 0
// Czech (UTF-8 v1.4.5): MartinR [martin.ruzicka.cz(at)gmail.com]
$lang_index = array(

'Topics'		=>	'Témata',
'Link to'		=>	'Odkaz na:', // As in "Link to: http://fluxbb.org/"
'Empty board'	=>	'Fórum je prázdné',
'Newest user'	=>	'Nejnovější registrovaný uživatel: %s',
'Users online'	=>	'Registrovaných uživatelů online: %s',
'Guests online'	=>	'Hostů online: %s',
'No of users'	=>	'Celkový počet registrovaných uživatelů: %s',
'No of topics'	=>	'Celkový počet témat: %s',
'No of posts'	=>	'Celkový počet příspěvků: %s',
'Online'		=>	'Online:', // As in "Online: User A, User B etc."
'Board info'	=>	'Informace o fóru',
'Board stats'	=>	'Statistika fóra',
'User info'		=>	'Informace o uživateli'

);
