<?php

// Language definitions used in viewforum.php
// Untranslated: 1
// Czech (UTF-8 v1.4.5): MartinR [martin.ruzicka.cz(at)gmail.com]
$lang_forum = array(

'Post topic'	=>	'Založit nové téma',
'Views'			=>	'Zobrazení',
'Moved'			=>	'Přesunuto:',
'Sticky'		=>	'Připnuto:',
'Closed'		=>	'Zavřeno:',
'Empty forum'	=>	'Fórum je prázdné.',
'Mod controls'			=>	'Moderator controls',
'Is subscribed'	=>	'Nyní sledujete toto fórum',
'Unsubscribe'	=>	'Nesledovat',
'Subscribe'		=>	'Sledovat toto fórum'

);
