<?php

// Sprachdefinitionen, die in index.php verwendet werden
$lang_index = array(

'Topics'		=>	'Themen',
'Link to'		=>	'Link zu:', // Wie zum Beispiel "Link zu: http://fluxbb.org/"
'Empty board'	=>	'Das Board ist leer.',
'Newest user'	=>	'Das neueste Mitglied ist: %s',
'Users online'	=>	'Registrierte Mitglieder online: %s',
'Guests online'	=>	'Gäste online: %s',
'No of users'	=>	'Anzahl der registrierten Mitglieder: %s',
'No of topics'	=>	'Anzahl der Themen: %s',
'No of posts'	=>	'Anzahl der Beiträge: %s',
'Online'		=>	'Gerade online:', // Wie zum Beispiel "Online: Mitglied A, Mitglied B etc."
'Board info'	=>	'Board-Informationen',
'Board stats'	=>	'Board-Statistik',
'User info'		=>	'Mitglieder-Information'

);
