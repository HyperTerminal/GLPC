<?php

// Sprachdefinitionen, die in delete.php verwendet werden
$lang_delete = array(

'Delete post'			=>	'Beitrag löschen',
'Warning'				=>	'Du bist dabei, diesen Beitrag unwiderruflich zu löschen.',
'Topic warning'			=>	'Achtung! Dies ist der erste Beitrag in diesem Thema, das ganze Thema wird unwiderruflich gelöscht.',
'Delete info'			=>	'Unterhalb findest du den zu löschenden Beitrag.',
'Reply by'				=>	'Antwort von %s - %s',
'Topic by'				=>	'Thema erstellt von %s - %s',
'Delete'				=>	'Löschen', // Beschriftung des Absende-Buttons
'Post del redirect'		=>	'Beitrag gelöscht. Leite weiter …',
'Topic del redirect'	=>	'Thema gelöscht. Leite weiter …'

);
