<?php

// Sprachdefinitionen, die in admin_reports.php verwendet werden
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Meldung als gelesen markiert. Leite weiter …',
'New reports head'			=>	'Neue Meldungen',
'Deleted user'				=>	'Gelöschtes Mitglied',
'Deleted'					=>	'Gelöscht',
'Post ID'					=>	'Beitrag #%s',
'Report subhead'			=>	'Gemeldet %s',
'Reported by'				=>	'Gemeldet von %s',
'Reason'					=>	'Grund',
'Zap'						=>	'Als gelesen markieren',
'No new reports'			=>	'Aktuell gibt es keine neuen Meldungen.',
'Last 10 head'				=>	'Die 10 letzten gelesenen Meldungen',
'NA'						=>	'Keine Daten verfügbar',
'Zapped subhead'			=>	'Gelöscht %s von %s',
'No zapped reports'			=>	'Aktuell gibt es keine ungelesenen Meldungen.',

);
