<?php

// Sprachdefinitionen, die in userlist.php verwendet werden
$lang_ul = array(

'User find legend'	=>	'Mitglieder suchen und sortieren',
'User search info'	=>	'Gib einen Mitgliedsnamen und/oder eine Mitgliedergruppe ein, nach der gefiltert werden soll. Der Mitgliedsname kann leer bleiben. Benutze Wildcards (*) für eine Suche nach Teilbegriffen. Sortiere die Mitglieder nach Namen, Registrierungsdatum oder Anzahl von Beiträgen und in auf-/absteigender Reihenfolge.',
'User sort info'	=>	'Sortiere Mitglieder nach Name, Registrierungsdatum oder Anzahl der Beiträge in aufsteigender oder absteigender Reihenfolge.',
'User group'		=>	'Mitgliedergruppe',
'No of posts'		=>	'Anzahl der Beiträge',
'All users'			=>	'Alle'

);
