<?php

// Definizioni di lingua usate in example Plugin
/* Traduzione di: Oscon.it */

/* $lang_admin_plugin_example = array(

'No text'				=>	'Ma come? Non hai scritto nulla! Come pu&ograve; funzionare il plugin? :) ',
'Example plugin title'	=>	'Esempio di plugin',
'You said'				=>	'Hai detto "%s". Eh gi&agrave;!',
'Explanation 1'			=>	'Questo plugin non fa nulla di utile. Per questo il nome "Esempio"!',
'Explanation 2'			=>	'Questo &egrave; un bel posto nel quale parlare del tuo plugin. Descrivere ci&ograve; che fa e come dovrebbe essere utilizato. Sii conciso, ma chiaro.',
'Example form title'	=>	'Modulo di esempio',
'Legend text'			=>	'Inserisci un testo e premi "Elabora testo"!',
'Text to show'			=>	'Testo da elaborare',
'Show text button'		=>	'Elabora testo',
'Input content'			=>	'Il testo da elaborare.',

);

*/