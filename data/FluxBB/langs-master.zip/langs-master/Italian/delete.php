<?php

// Definizioni di lingua usate in delete.php
/* Traduzione di: Oscon.it */

$lang_delete = array(

'Delete post'			=>	'Cancella messaggio',
'Warning'				=>	'Il messaggio verr&agrave; cancellato definitivamente.',
'Topic warning'			=>	'Attenzione! Questo &egrave; il primo messaggio della discussione: l\'intera discussione sar&agrave; quindi cancellata definitivamente.',
'Delete info'			=>	'Il messaggio da cancellare &egrave; riportato di seguito per rileggerlo prima di procedere con la cancellazione.',
'Reply by'				=>	'Risposta di %s - %s',
'Topic by'				=>	'Discussione iniziata da %s - %s',
'Delete'				=>	'Cancella', // Pulsante di invio
'Post del redirect'		=>	'Messaggio cancellato. Reindirizzamento &hellip;',
'Topic del redirect'	=>	'Discussione cancellata. Reindirizzamento &hellip;'

);