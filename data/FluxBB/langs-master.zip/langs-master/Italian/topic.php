<?php

// Definizioni di lingua usate in viewtopic.php
/* Traduzione di: Oscon.it */

$lang_topic = array(

'Post reply'		=>	'Rispondi',
'Topic closed'		=>	'Discussione chiusa',
'From'				=>	'Da',				// Provenienza dell'utente
'IP address logged'	=>	'Indirizzo IP registrato',
'Note'				=>	'Nota',				// Nota dell'amministratore
'Posts'				=>	'Messaggi:',
'Registered'		=>	'Registrato:',
'Replies'			=>	'Risposte:',
'Website'			=>	'Sito web',
'Guest'				=>	'Ospite',
'Online'			=>	'In linea',
'Offline'			=>	'Non in linea',
'Last edit'			=>	'Ultima modifica di',
'Report'			=>	'Segnala',
'Delete'			=>	'Cancella',
'Edit'				=>	'Modifica',
'Quote'				=>	'Cita',
'Is subscribed'		=>	'Sei iscritto alla discussione',
'Unsubscribe'		=>	'Disiscrizione',
'Subscribe'			=>	'Avvertimi in caso di risposta!',
'Quick post'		=>	'Risposta rapida',
'Mod controls'		=>	'Controlli moderatore',
'New icon'			=>	'Nuovo messaggio',
'Re'				=>	'Re:',
'Preview'           =>  'Anteprima',

);
