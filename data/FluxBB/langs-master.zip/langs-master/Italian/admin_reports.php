<?php

// Definizioni di lingua usate in admin_reports.php
/* Traduzione di: Oscon.it */

$lang_admin_reports = array(

'Report zapped redirect'	=>	'Segnalazione archiviata. Reindirizzamento &hellip;',
'New reports head'			=>	'Nuove segnalazioni',
'Deleted user'				=>	'Utente cancellato',
'Deleted'					=>	'Cancellata',
'Post ID'                   =>  'Messaggio n. %s',
'Report subhead'			=>	'Segnalata %s',
'Reported by'				=>	'Segnalata da %s',
'Reason'					=>	'Motivo',
'Zap'						=>	'Archivia',
'No new reports'			=>	'Non sono presenti nuove segnalazioni.',
'Last 10 head'				=>	'Ultime 10 segnalazioni',
'NA'						=>	'Non disponibile',
'Zapped subhead'			=>	'Archiviata: %s da %s',
'No zapped reports'			=>	'Non ci sono segnalazioni archiviate.',

);