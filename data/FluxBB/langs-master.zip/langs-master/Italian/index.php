<?php

// Definizioni di lingua usate in index.php
/* Traduzione di: Oscon.it */

$lang_index = array(

'Topics'		=>	'Discussioni',
'Link to'		=>	'Collegamento a:', // Es: "Collegamento a: http://fluxbb.org/"
'Empty board'	=>	'Forum vuoto!',
'Newest user'	=>	'Benvenuto a: %s !', // Utente pi� recente:
'Users online'	=>	'Utenti in linea: %s',
'Guests online'	=>	'Ospiti in linea: %s',
'No of users'	=>	'Utenti totali: %s',
'No of topics'	=>	'Discussioni totali: %s',
'No of posts'	=>	'Messaggi totali: %s',
'Online'		=>	'In linea:', // Es: "In linea: Pippo, Pluto, Paperino", ecc.
'Board info'	=>	'Informazioni forum',
'Board stats'	=>	'Statistiche forum',
'User info'		=>	'Informazioni utente'

);
