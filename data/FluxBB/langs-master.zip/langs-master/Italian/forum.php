<?php

// Definizioni di lingua usate in viewforum.php
/* Traduzione di: Oscon.it */

$lang_forum = array(

'Post topic'	=>	'Nuova discussione',
'Views'			=>	'Visite',
'Moved'			=>	'Spostata:',
'Sticky'		=>	'In evidenza:',
'Closed'		=>	'Chiusa:',
'Empty forum'	=>	'Il forum &egrave; vuoto!',
'Mod controls'	=>	'Controlli moderatore',
'Is subscribed' =>  'Sei iscritto al forum',
'Unsubscribe'   =>  'Disiscrizione',
'Subscribe'     =>  'Avvertimi in caso di nuove discussioni!',

);
