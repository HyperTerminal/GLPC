<?php

// Definizioni di lingua usate in userlist.php
/* Traduzione di: Oscon.it */

$lang_ul = array(

'User find legend'	=>	'Cerca utenti',
'User search info'	=>	'Inserire un nome utente e/o un gruppo utenti come filtro. Il carattere jolly * &egrave; accettato.',
'User sort info'	=>	'Ordina risultati per nome, data di registrazione, numero di messaggi, ordine ascendente o discendente.',
'User group'		=>	'Gruppo',
'No of posts'		=>	'Numero di messaggi',
'All users'			=>	'Tutti'

);
