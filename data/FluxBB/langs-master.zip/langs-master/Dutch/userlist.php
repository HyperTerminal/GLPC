<?php

// Taaldefinities gebruikt in userlist.php
$lang_ul = array(

'User find legend'	=>	'Zoek en sorteer gebruikers',
'User search info'	=>	'Geef een gebruikersnaam op om naar te zoeken en/of een gebruikersgroep in op te filteren. Het gebruikersnaam veld kan worden leeg gelaten.',
'User sort info'	=>	'Sorteer gebruikers op naam, datum van registratie of aantal posts en op- of aflopend.',
'User group'		=>	'Gebruikersgroep',
'No of posts'		=>	'Aantal posts',
'All users'			=>	'Alle'

);
