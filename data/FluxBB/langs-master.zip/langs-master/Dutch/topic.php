<?php

// Taaldefinities gebruikt in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Reageren',
'Topic closed'		=>	'Topic gesloten',
'From'				=>	'Van:',
'IP address logged'	=>	'IP adres opgeslagen',
'Note'				=>	'Nota:',
'Posts'				=>	'Posts:',
'Registered'		=>	'Geregistreerd:',
'Replies'			=>	'Reacties:',
'Website'			=>	'Website',
'Guest'				=>	'Gast',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Laatst bewerkt door',
'Report'			=>	'Rapporteren',
'Delete'			=>	'Verwijderen',
'Edit'				=>	'Bewerken',
'Quote'				=>	'Quote',
'Is subscribed'		=>	'Je bent geabonneerd op dit topic',
'Unsubscribe'		=>	'Beëindig abonnement',
'Subscribe'			=>	'Abonneer op dit topic',
'Quick post'		=>	'Snel reageren',
'Mod controls'		=>	'Mod opties',
'New icon'			=>	'Nieuwe post',
'Re'				=>	'Re:',
'Preview'			=>	'Voorbeeld'

);
