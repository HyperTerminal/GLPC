<?php

// Taaldefinities gebruikt in index.php
$lang_index = array(

'Topics'		=>	'Topics',
'Link to'		=>	'Linkt naar:',
'Empty board'	=>	'Forum is leeg.',
'Newest user'	=>	'Nieuwste gebruiker: %s',
'Users online'	=>	'Geregistreerde gebruikers online: %s',
'Guests online'	=>	'Gasten online: %s',
'No of users'	=>	'Totaal aantal geregistreerde gebruikers: %s',
'No of topics'	=>	'Totaal aantal topics: %s',
'No of posts'	=>	'Totaal aantal posts: %s',
'Online'		=>	'Online:',
'Board info'	=>	'Informatie',
'Board stats'	=>	'Statistieken',
'User info'		=>	'Gebruikers informatie'

);
