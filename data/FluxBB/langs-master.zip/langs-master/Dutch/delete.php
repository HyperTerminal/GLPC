<?php

// Taaldefinities gebruikt in delete.php
$lang_delete = array(

'Delete post'			=>	'Verwijder post',
'Warning'				=>	'Je gaat deze post permanent verwijderen.',
'Topic warning'			=>	'Waarschuwing! Dit is de eerste post in dit topic, hiermee wordt dit hele topic verwijderd.',
'Delete info'			=>	'De post die je wilt verwijderen vraagt om een review voordat je hem kan verwijderen.',
'Reply by'				=>	'Gereageerd door %s - %s',
'Topic by'				=>	'Topic gestard door %s - %s',
'Delete'				=>	'Verwijderen',
'Post del redirect'		=>	'Post verwijderd. Doorverwijzen …',
'Topic del redirect'	=>	'Topic verwijderd. Doorverwijzen …'

);
