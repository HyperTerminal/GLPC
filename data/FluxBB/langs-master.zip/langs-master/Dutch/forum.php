<?php

// Taaldefinities gebruikt in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Nieuw topic',
'Views'			=>	'Views',
'Moved'			=>	'Verplaatst:',
'Sticky'		=>	'Sticky:',
'Closed'		=>	'Gesloten:',
'Empty forum'	=>	'Leeg forum.',
'Mod controls'	=>	'Moderator paneel',
'Is subscribed'	=>	'Je bent geabonneerd op dit forum',
'Unsubscribe'	=>	'Beëindig abonnement',
'Subscribe'		=>	'Abonneer op dit forum'

);
