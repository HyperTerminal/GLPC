<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'新規トピック',
'Views'			=>	'閲覧',
'Moved'			=>	'移動:',
'Sticky'		=>	'注目:',
'Closed'		=>	'閉鎖:',
'Empty forum'	=>	'フォーラムは空です。',
'Mod controls'	=>	'モデレータ管理セクション',
'Is subscribed'	=>	'現在このフォーラムを購読しています。',
'Unsubscribe'	=>	'フォーラムの購読をやめる',
'Subscribe'		=>	'フォーラムを購読'

);
