<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'	=>	'ユーザーの検索と並び替え',
'User search info'	=>	'検索するユーザー名またはグループを指定します。ユーザー名は省略できます。ワイルドカード(*)も指定できます。',
'User sort info'	=>	'ユーザー名、登録日、投稿数を対象に昇順または降順で並び替えます。',
'User group'		=>	'グループ',
'No of posts'		=>	'投稿数',
'All users'			=>	'すべて'

);
