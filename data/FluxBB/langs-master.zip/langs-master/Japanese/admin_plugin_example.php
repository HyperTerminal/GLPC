<?php

// Language definitions used in example Plugin
$lang_admin_plugin_example = array(

'No text'				=>	'テキストが入力されていません。',
'Example plugin title'	=>	'プラグインサンプル',
'You said'				=>	'"%s" が入力されました。ありがとう。',
'Explanation 1'			=>	'このプラグインはプラグインの例で特に機能はありません。',
'Explanation 2'			=>	'あなたが作ったプラグインに関する簡単な説明をここに表示します。プラグインの挙動や使用方法についての情報を簡潔かつ有益に説明してください。',
'Example form title'	=>	'フォームの例',
'Legend text'			=>	'簡単なテキストを入力し、"表示"ボタンをクリック！',
'Text to show'			=>	'表示テキスト',
'Show text button'		=>	'表示',
'Input content'			=>	'表示したいテキストを入力します。',

);
