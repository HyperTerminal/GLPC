<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'投稿の削除',
'Warning'				=>	'この投稿は完全に削除されます。',
'Topic warning'			=>	'警告！ これはトピックの最初の投稿です。トピックごと完全に削除されます。',
'Delete info'			=>	'削除しようとしている内容は以下です。確認の上、削除してください。',
'Reply by'				=>	'投稿者 %s - %s',
'Topic by'				=>	'トピック作成者 %s - %s',
'Delete'				=>	'削除', // The submit button
'Post del redirect'		=>	'投稿が削除されました。リダイレクト中 …',
'Topic del redirect'	=>	'トピックが削除されました。リダイレクト中 …'

);