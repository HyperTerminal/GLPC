<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'返信',
'Topic closed'		=>	'閉鎖トピック',
'From'				=>	'From:', // User location
'IP address logged'	=>	'IPアドレス',
'Note'				=>	'メモ:', // Admin note
'Posts'				=>	'投稿:',
'Registered'		=>	'登録日:',
'Replies'			=>	'返信:',
'Website'			=>	'ウェブサイト',
'Guest'				=>	'ゲスト',
'Online'			=>	'オンライン',
'Offline'			=>	'オフライン',
'Last edit'			=>	'編集者',
'Report'			=>	'通報',
'Delete'			=>	'削除',
'Edit'				=>	'編集',
'Quote'				=>	'引用',
'Is subscribed'		=>	'現在このトピックを購読しています。',
'Unsubscribe'		=>	'トピックの購読をやめる',
'Subscribe'			=>	'トピックを購読',
'Quick post'		=>	'クィック投稿',
'Mod controls'		=>	'モデレータ管理セクション',
'New icon'			=>	'新しい投稿',
'Re'				=>	'Re:',
'Preview'			=>	'プレビュー'

);
