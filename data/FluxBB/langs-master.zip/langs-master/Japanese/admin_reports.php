<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'通報を既読にしました。リダイレクト中 …',
'New reports head'			=>	'新しい通報',
'Deleted user'				=>	'削除されたユーザー',
'Deleted'					=>	'削除済み',
'Report subhead'			=>	'%s の通報',
'Reported by'				=>	'%s から',
'Reason'					=>	'理由',
'Zap'						=>	'既読にする',
'No new reports'			=>	'新しい通報はありません。',
'Last 10 head'				=>	'既読の通報（最新10件）',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'%s %s が既読にしました。',
'No zapped reports'			=>	'既読の通報はありません。',

);
