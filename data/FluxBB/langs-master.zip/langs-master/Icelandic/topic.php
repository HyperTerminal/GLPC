<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Svara pósti',
'Topic closed'		=>	'Þræði lokað',
'From'				=>	'Frá:', // User location
'IP address logged'	=>	'IP tala skráð',
'Note'				=>	'Ath:', // Admin note
'Posts'				=>	'Póstar:',
'Registered'		=>	'Skráð:',
'Replies'			=>	'Svör:',
'Website'			=>	'Vefsíða',
'Guest'				=>	'Gestur',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Síðast breytt af',
'Report'			=>	'Tilkynna',
'Delete'			=>	'Eyða',
'Edit'				=>	'Breyta',
'Quote'				=>	'Tilvitnun',
'Is subscribed'		=>	'Þú ert í áskrift að þessum þræði',
'Unsubscribe'		=>	'Afpanta áskrift',
'Subscribe'			=>	'Skrá þennan þráð í áskrift',
'Quick post'		=>	'Flýtipóstur',
'Mod controls'		=>	'Stjórnendatól',
'New icon'			=>	'Nýr póstur',
'Re'				=>	'Vegna:'

);