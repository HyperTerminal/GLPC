<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'	=>	'Finndu og raðaðu notendum',
'User search info'	=>	'Sláðu inn notendanafn til að leita að og/eða notendahóp tli að sía út eftir. Notendanafnið má vera autt. Notaðu * (wildcard) til að leita að orðabútum. Raða notendum eftir nafni, skráningardagsetningu eða fjölda pósta og í hækkandi/lækkandi röð.',
'User sort info'	=>	'Raðaðu notendum eftir nafni, skráningardegi eða fjölda pósta í hækkandi/lækkandi röð.',
'User group'		=>	'Notendahópur',
'No of posts'		=>	'Fjöldi pósta',
'All users'			=>	'Allir'

);