<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Tilkynning afgreidd. Áframsendi …',
'New reports head'			=>	'Nýjar tilkynningar',
'Deleted user'				=>	'Eyddur notandi',
'Deleted'					=>	'Eyddur',
'Report subhead'			=>	'Tilkynnt %s',
'Reported by'				=>	'Tilkynnt af %s',
'Reason'					=>	'Ástæða',
'Zap'						=>	'Afgreiða',
'No new reports'			=>	'Það eru engar nýjar tilkynningar.',
'Last 10 head'				=>	'10 síðustu afgreiddu tilkynningar',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'Afgreitt %s af %s',
'No zapped reports'			=>	'Engar afgreiddar tilkynningar.',

);