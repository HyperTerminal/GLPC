<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'		=>	'Þræðir',
'Link to'		=>	'Tengill til:', // As in "Link to: http://fluxbb.org/"
'Empty board'	=>	'Tómt spjallborð.',
'Newest user'	=>	'Nýjasti skráði notandinn: %s',
'Users online'	=>	'Innskráðir notendur: %s',
'Guests online'	=>	'Gestir: %s',
'No of users'	=>	'Fjöldi skráðra notanda: %s',
'No of topics'	=>	'Fjöldi þráða: %s',
'No of posts'	=>	'Fjöldi pósta: %s',
'Online'		=>	'Innskráðir:', // As in "Online: User A, User B etc."
'Board info'	=>	'Upplýsingar um spjallborðið',
'Board stats'	=>	'Tölfræði spjallborðsins',
'User info'		=>	'Notendaupplýsingar'

);