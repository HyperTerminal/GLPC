<?php

// Language definitions used in admin_ranks.php
$lang_admin_ranks = array(

'Must be integer message'	=>	'Lágmarks póstar verður að jákvæð heiltala.',
'Dupe min posts message'	=>	'Það er nú þegar til staða með lágmarks póstfjölda: %s.',
'Must enter title message'	=>	'Þú þarft að slá inn titil stöðu.',
'Rank added redirect'		=>	'Stöðu bætt við. Áframsendi …',
'Rank updated redirect'		=>	'Staða uppfærð. Áframsendi …',
'Rank removed redirect'		=>	'Staða fjarlægð. Áframsendi …',
'Ranks head'				=>	'Stöður',
'Add rank subhead'			=>	'Bæta við stöðu',
'Add rank info'				=>	'Sláðu inn stöðu og lágmarksfjölda pósta sem notandi þarf að hafa til að ná stöðunni. Mismunandi stöður geta ekki haft sama gildið fyrir lágmarksfjölda pósta. Ef notandi er með titil þá birtist hann í staðinn fyrir stöðuna.',
'Ranks enabled'				=>	'<strong>Staða notanda er leyfð í %s.</strong>',
'Ranks disabled'			=>	'<strong>Staða notanda er ekki leyfð í %s.</strong>',
'Rank title label'			=>	'Titill stöðu',
'Minimum posts label'		=>	'Lágmarks póstar',
'Actions label'				=>	'Aðgerðir',
'Edit remove subhead'		=>	'Breyta/fjarlægja stöðu',
'No ranks in list'			=>	'Engar stöður á listanum',

);


