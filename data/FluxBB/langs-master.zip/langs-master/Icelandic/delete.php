<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Eyða pósti',
'Warning'				=>	'Þú ert við það að eyða þessum pósti endanlega!',
'Topic warning'			=>	'Viðvörðun! Ef þetta er fyrsti pósturinn í þræðinum þá verður öllum þræðinum eytt.',
'Delete info'			=>	'Pósturinn sem þú hefur valið að eyða er birtur hér fyrir neðan til að þú getir séð hann áður en þú heldur áfram.',
'Reply by'				=>	'Svarað af %s - %s',
'Topic by'				=>	'Þráður stofnaður af %s - %s',
'Delete'				=>	'Eyða', // The submit button
'Post del redirect'		=>	'Pósti eytt. Áframsendi …',
'Topic del redirect'	=>	'Þræði eytt. Áframsendi …'

);
