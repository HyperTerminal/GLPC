<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Pósta nýjum þræði',
'Views'			=>	'Sýnir',
'Moved'			=>	'Fært:',
'Sticky'		=>	'Klístrað:',
'Closed'		=>	'Lokað:',
'Empty forum'	=>	'Spjallborð er tómt.',
'Mod controls'	=>	'Stjórnendatól'

);