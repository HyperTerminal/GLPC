<?php

// Language definitions used in example Plugin
$lang_admin_plugin_example = array(

'No text'				=>	'Þú skrifaðir ekki neitt!',
'Example plugin title'	=>	'Dæmi um viðbót',
'You said'				=>	'Þú sagðir: "%s". Frábært, tungulipur.',
'Explanation 1'			=>	'Þessi viðbót gerir ekkert gagnlegt. Þess vegna hetiri hún "Dæmi um viðbót".',
'Explanation 2'			=>	'Þetta væri góður staður til að ræða aðeins um viðbótina þína. Vinsamlegast lýstu því hvað hún gerir og hvernig hún er notuð. Hafðu lýsinguna stutta en hnitmiðaða..',
'Example form title'	=>	'Dæmaform',
'Legend text'			=>	'Sláðu inn texta og smelltu á "Sýna texta"!',
'Text to show'			=>	'Texti sem á að sýna',
'Show text button'		=>	'Sýna texta',
'Input content'			=>	'Textinn sem þú vilt sýna.',

);


