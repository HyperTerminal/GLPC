<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Informe marcat com a llegit. Redireccionant …',
'New reports head'			=>	'Nous informes',
'Deleted user'				=>	'Eliminar usuari',
'Deleted'					=>	'Eliminat',
'Post ID'					=>	'Missatge #%s',
'Report subhead'			=>	'Informat %s',
'Reported by'				=>	'Informat per %s',
'Reason'					=>	'Motiu',
'Zap'						=>	'Eliminar',
'No new reports'			=>	'No hi ha nous informes.',
'Last 10 head'				=>	'Últims 10 informes eliminats',
'NA'						=>	'N/D',
'Zapped subhead'			=>	'Eliminat %s per %s',
'No zapped reports'			=>	'No hi ha informes eliminats.',

);
