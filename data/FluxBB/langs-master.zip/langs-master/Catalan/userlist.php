<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'	=>	'Cercar i ordenar usuaris',
'User search info'	=>	'Introdueix un nom d\'usuari i/o un grup d\'usuaris per a filtrar la cerca. El camp "Usuari" pot deixar-se en blanc. Utilitza el caracter comodí * per a coincidències parcials.',
'User sort info'	=>	'Ordena els usuaris pel nom, data de registre o nombre de missatges i en ordre ascendent/descendent.',
'User group'		=>	'Grup',
'No of posts'		=>	'Nombre de temes',
'All users'			=>	'Tots'

);
