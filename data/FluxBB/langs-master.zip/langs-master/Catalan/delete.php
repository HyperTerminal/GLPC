<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Eliminar missatge',
'Warning'				=>	'Estàs a punt d\'eliminar pernamentment aquest missatge.',
'Topic warning'			=>	'Atenció! Aquest és el primer missatge del tema. La resta del tema s\'esborrarà permanentment.',
'Delete info'			=>	'El missatge que has optat per esborrar figura a continuació per a què ho revisis abans de continuar.',
'Reply by'				=>	'Resposta per %s - %s',
'Topic by'				=>	'Tema iniciat per %s - %s',
'Delete'				=>	'Eliminar', // The submit button
'Post del redirect'		=>	'Missatge eliminat. Redirigint …',
'Topic del redirect'	=>	'Tema eliminat. Redirigint …'

);
