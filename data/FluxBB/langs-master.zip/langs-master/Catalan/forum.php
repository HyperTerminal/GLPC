<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Crea un nou tema',
'Views'			=>	'Visites',
'Moved'			=>	'Mogut:',
'Sticky'		=>	'Ancorat:',
'Closed'		=>	'Tancat:',
'Empty forum'	=>	'Fòrum buit.',
'Mod controls'	=>	'Controls del moderador',
'Is subscribed'	=>	'Estàs subscrit a aquest fòrum',
'Unsubscribe'	=>	'Donar-se de baixa',
'Subscribe'		=>	'Subscriu-te a aquest fòrum'

);
