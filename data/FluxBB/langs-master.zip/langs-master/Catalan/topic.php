<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Respondre',
'Topic closed'		=>	'Tema tancat',
'From'				=>	'Des de:', // User location
'IP address logged'	=>	'Adreça IP registrada',
'Note'				=>	'Nota:', // Admin note
'Posts'				=>	'Missatges:',
'Registered'		=>	'Registrat:',
'Replies'			=>	'Respostes:',
'Website'			=>	'Pàgina Web',
'Guest'				=>	'Convidat',
'Online'			=>	'En línea',
'Offline'			=>	'Desconnectat',
'Last edit'			=>	'Última edició per',
'Report'			=>	'Reportar',
'Delete'			=>	'Eliminar',
'Edit'				=>	'Editar',
'Quote'				=>	'Citar',
'Is subscribed'		=>	'Estàs subscrit a aquest tema',
'Unsubscribe'		=>	'Donar-se de baixa',
'Subscribe'			=>	'Subscriure\'s a aquest tema',
'Quick post'		=>	'Resposta ràpida',
'Mod controls'		=>	'Controls Moderador',
'New icon'			=>	'Nou tema',
'Re'				=>	'Re:',
'Preview'			=>	'Vista prèvia'

);
