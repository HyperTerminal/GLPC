<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'		=>	'מצא ומיין משתמשים',
'User search info'		=>	'הזן שם משתמש לחיפוש ו/או קבוצת משתמשים כדי לסנן לפיה. שדה שם המשתמש ניתן להשאיר ריק. השתמש בתו * עבור התאמה חלקית.',
'User sort info'	=>	'מיין משתמשים לפי שם, תאריך הרשמה או כמות הודעות ובסדר עולה/יורד.',
'User group'			=>	'קבוצת משתמשים',
'No of posts'			=>	'כמות הודעות',
'All users'			=>	'הכל'

);
