<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'מחק הודעה',
'Warning'				=>	'הינך עומד למחוק את ההודעה לצמיתות.', 
'Topic Warning'		=>	'אזהרה! זוהי ההודעה הראשונה בנושא, כל הנושא יימחק לצמיתות יחד עם ההודעות שבתוכו.',
'Delete info'			=>	'ההודעה שבחרת למחוק סומנה בשבילך לקריאה לפני המשך התהליך.',
'Reply by'				=>	'תגובה מאת %s - %s',
'Topic by'				=>	'הנושא נוצר ע"י %s - %s', 
'Delete'				=>	'מחק',	// The submit button
'Post del redirect'		=>	'הודעה נמחקה. מעביר &hellip;',
'Topic del redirect'	=>	'נושא נמחק. מעביר &hellip;'

);
