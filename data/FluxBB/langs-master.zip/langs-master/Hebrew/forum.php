<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'פרסם נושא חדש',
'Views'			=>	'צפיות',
'Moved'			=>	'הועבר:',
'Sticky'		=>	'נעוץ:',
'Closed'		=>	'נעול:',
'Empty forum'	=>	'הפורום ריק.',
'Mod controls'	=>	'לוח בקרת מנהל',
'Is subscribed'	=>	'הינך רשום כרגע לקבלת עדכונים מפורום זה',
'Unsubscribe'	=>	'בטל קבלת עדכונים',
'Subscribe'		=>	'הירשם לקבלת עדכונים מפורום זה'

);