<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'הדיווח סומן כנקרא. מעביר &hellip;',
'New reports head'			=>	'דיווחים חדשים',
'Deleted user'				=>	'משתמש מחוק',
'Deleted'					=>	'נמחק',
'Report subhead'			=>	'דווח %s',
'Reported by'				=>	'דווח ע"י %s',
'Reason'					=>	'סיבה',
'Zap'						=>	'סמן כנקרא',
'No new reports'			=>	'לא נמצאו דיווחים חדשים.',
'Last 10 head'				=>	'10 הדיווחים האחרונים שנקראו',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'סומן כנקרא %s ע"י %s',
'No zapped reports'			=>	'לא נמצאו דיווחים שנקראו.',

);
