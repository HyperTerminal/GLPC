<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'				=>  'נושאים',
'Link to'				=>	'קישור ל',	// As in "Link to http://fluxbb.org/"
'Empty board'			=>	'הפורום ריק.',
'Newest user'			=>	'המשתמש החדש ביותר: %s',
'Users online'			=>	'משתמשים מחוברים כרגע: %s',
'Guests online'			=>	'אורחים בפורום כרגע: %s',
'No of users'			=>	'סה"כ משתמשים רשומים: %s',
'No of topics'			=>	'סה"כ נושאים: %s',
'No of posts'			=>	'סה"כ הודעות: %s',
'Online'				=>	'מחוברים:',	// As in "Online: User A, User B etc."
'Board info'			=>	'מידע על הפורום',
'Board stats'			=>	'סטטיסטיקות הפורום',
'User info'				=>	'מידע על משתמש'

);
