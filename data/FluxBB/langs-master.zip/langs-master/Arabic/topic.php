<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'أدخل رد',
'Topic closed'		=>	'الموضوع مغلق',
'From'				=>	'من',				// User location
'IP address logged'			=>	'عنوان الشبكة المسجل',
'Note'				=>	'ملاحظة',				// Admin note
'Posts'			=>	'المداخلات:',
'Registered'	=>	'مسجل في:',
'Replies'		=>	'الردود:',
'Website'			=>	'الموقع',
'Guest'				=>	'زائر',
'Online'			=>	'متواجد',
'Offline'			=>	'غير متواجد',
'Last edit'			=>	'آخر تعديل بـ',
'Report'			=>	'شكوى',
'Delete'			=>	'حذف',
'Edit'				=>	'تعديل',
'Quote'				=>	'اقتباس',
'Is subscribed'		=>	'أنت مشترك في هذا الموضوع',
'Unsubscribe'		=>	'إلغاء الاشتراك',
'Subscribe'			=>	'اشترك في هذا الموضوع',
'Quick post'		=>	'مداخلة سريعة',
'Mod controls'	=>	'أدوات الإشراف',
'New icon'		=>	'مداخلة جديدة',
'Re'			=>	'رد:',
'Preview'			=>	'معينة'

);