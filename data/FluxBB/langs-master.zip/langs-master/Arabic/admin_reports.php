<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'تمت تسوية الشكوى. توجيه …',
'New reports head'			=>	'شكاوى جديدة',
'Deleted user'				=>	'مستخدم محذوف',
'Deleted'					=>	'محذوف',
'Post ID'					=>	'المداخلة #%s',
'Report subhead'			=>	'شكاوى %s',
'Reported by'				=>	'مرسلة بواسطة %s',
'Reason'					=>	'السبب',
'Zap'						=>	'اجعلها مقروءة',
'No new reports'			=>	'لا يوجد أي شكوى.',
'Last 10 head'				=>	'آخر 10 شكاوى تم قراءتها',
'NA'						=>	'N/A',
'Zapped subhead'			=>	'تم قراءتها في %s بواسطة %s',
'No zapped reports'			=>	'لا يوجد شكاوى تم قراءتها.',

);