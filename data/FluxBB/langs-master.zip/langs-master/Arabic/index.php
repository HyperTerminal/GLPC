<?php

// Language definitions used in index.php
$lang_index = array(

'Topics'		=>	'المواضيع',
'Link to'		=>	'رابط إلى:', // As in "Link to: http://fluxbb.org/"
'Empty board'	=>	'المنتدى فارغ.',
'Newest user'	=>	'أحدث المستخدمين المسجلين: %s',
'Users online'	=>	'المستخدمين المتواجدين: %s',
'Guests online'	=>	'الزوار المتواجدين: %s',
'No of users'	=>	'إجمالي عدد المستخدمين المسجلين: %s',
'No of topics'	=>	'إجمالي عدد المواضيع: %s',
'No of posts'	=>	'إجمالي عدد المداخلات: %s',
'Online'		=>	'متواجد:', // As in "Online: User A, User B etc."
'Board info'	=>	'معلومات المنتدى',
'Board stats'	=>	'إحصائيات المنتدى',
'User info'		=>	'معلومات المستخدم'

);
