<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'حذف المداخلة',
'Warning'				=>	'تحذير! إذا كانت هذه أول مداخلة في الموضوع، فكامل الموضوع سوف يحذف.',
'Topic warning'			=>	'تحذير! هذه أول مداخلة في هذا الموضوع, كامل الموضوع سوف يتم حذفه بشكل نهائي.',
'Delete info'			=>	'المداخلة المراد حذفها قد تم إظهارها في الأسفل لمراجعتها قبل المتابعة.',
'Reply by'				=>	'رد المداخلة %s - %s',
'Topic by'				=>	'الموضوع أنشىء بـ %s - %s',
'Delete'				=>	'حذف',	// The submit button
'Post del redirect'		=>	'تم حذف المداخلة. توجيه …',
'Topic del redirect'	=>	'حذف الموضوع. توجيه …'

);