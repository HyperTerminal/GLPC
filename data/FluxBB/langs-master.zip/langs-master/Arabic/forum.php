<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'أضف موضوعاً جديدا',
'Views'			=>	'المشاهدات',
'Moved'			=>	'منقول:',
'Sticky'		=>	'مثبت:',
'Closed'		=>	'مغلق:',
'Empty forum'	=>	'المنتدى فارغ.',
'Mod controls'	=>	'أدوات الإشراف',
'Is subscribed'	=>	'لقد اشتركت للتو في هذا المنتدى',
'Unsubscribe'	=>	'إلغاء الاشتراك',
'Subscribe'		=>	'اشترك في هذا المنتدى'

);