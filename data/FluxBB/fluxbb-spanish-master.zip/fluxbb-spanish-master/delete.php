<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Eliminar mensaje',
'Warning'				=>	'Estás a punto de eliminar permanentemente este mensaje.',
'Topic warning'			=>	'¡Advertencia! Este es el primer mensaje en este tema, todo el tema completo será permanentemente eliminado!',
'Delete info'			=>	'El mensaje que has decidido eliminar se muestra a continuación para que lo revises antes de proceder.',
'Reply by'				=>	'Respuesta de %s - %s',
'Topic by'				=>	'Tema iniciado por %s - %s',
'Delete'				=>	'Eliminar', // The submit button
'Post del redirect'		=>	'Mensaje eliminado. Redirigiendo…',
'Topic del redirect'	=>	'Tema eliminado. Redirigiendo…'

);
