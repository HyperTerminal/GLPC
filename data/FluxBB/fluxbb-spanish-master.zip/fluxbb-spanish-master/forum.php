<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Publicar nuevo tema',
'Views'			=>	'Vistas',
'Moved'			=>	'Movido:',
'Sticky'		=>	'Importante:',
'Closed'		=>	'Cerrado:',
'Empty forum'	=>	'Foro vacío.',
'Mod controls'	=>	'Controles de moderación',
'Is subscribed'	=>	'Actualmente estás suscrito a este foro',
'Unsubscribe'	=>	'Eliminar suscripción',
'Subscribe'		=>	'Suscribirse'

);
