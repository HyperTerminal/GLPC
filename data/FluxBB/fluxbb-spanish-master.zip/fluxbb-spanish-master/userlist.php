<?php

// Language definitions used in userlist.php
$lang_ul = array(

'User find legend'	=>	'Encuentra y ordena usuarios',
'User search info'	=>	'Introduce un nombre de usuario para buscar y/o un grupo de usuarios para filtrar. El campo de nombre de usuario no puede quedar vacío. Utiliza un carácter comodín (*) para coincidencias parciales.',
'User sort info'	=>	'Ordena a los usuarios por nombre, fecha de registro o número de mensajes, y en orden ascendente/descendente.',
'User group'		=>	'Grupo de usuarios',
'No of posts'		=>	'Número de mensajes',
'All users'			=>	'Todos'

);
