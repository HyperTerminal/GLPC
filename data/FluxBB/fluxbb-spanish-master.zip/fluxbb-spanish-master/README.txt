** Spanish language pack for FluxBB v1.5.2
** Copyright (C) 2013.
** This package is distributed under the same license as FluxBB.

The public repository is located at https://github.com/alpha-omega/fluxbb-spanish
