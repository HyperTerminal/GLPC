<?php

// Language definitions used in admin_reports.php
$lang_admin_reports = array(

'Report zapped redirect'	=>	'Reportes marcados como leídos. Redirigiendo…',
'New reports head'			=>	'Nuevos reportes',
'Deleted user'				=>	'Usuario eliminado',
'Deleted'					=>	'Eliminado',
'Post ID'					=>	'Mensaje #%s',
'Report subhead'			=>	'Reportado %s',
'Reported by'				=>	'Reportado por %s',
'Reason'					=>	'Razón',
'Zap'						=>	'Marcar como leído',
'No new reports'			=>	'No hay nuevos reportes.',
'Last 10 head'				=>	'Últimos 10 reportes leídos',
'NA'						=>	'No disponible',
'Zapped subhead'			=>	'Marcado como leído %s por %s',
'No zapped reports'			=>	'No hay reportes leídos.',

);
