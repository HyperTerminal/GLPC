# Spanish language pack for [FluxBB](http://fluxbb.org/)

## Download
**Using Git**  
Clone the Git repository:

    git clone git://github.com/alpha-omega/fluxbb-spanish.git Spanish

**Getting the tarball**  
Download the [latest tag](https://github.com/alpha-omega/fluxbb-spanish/tags) (versioning follows FluxBB's releases). And rename the directory to "Spanish".

## Installation
Upload the folder to the correct location on your server.

    path-to-fluxbb/lang/Spanish

<br>

---
_This project is not related to the Spanish language pack provided at [FluxBB.org](http://fluxbb.org/resources/translations/)._
