<?php
// $Id: manifest.php,v 0.20 2009/01/06 20:26:58 vastag Exp $
// manifest file for information regarding application of new code
$manifest = array(
        // only install on the following regex sugar versions (if empty, no check)
    'acceptable_sugar_versions' =>
    array (
                'exact_matches' => array (
                ),
                'regex_matches' => array (
                        '5\.2\.0[a-z]?'
                ),
    ),
    'acceptable_sugar_flavors' =>
    array (
        0 => 'CE',
        1 => 'PRO',
        2 => 'ENT',
    ),

    // name of new code
    'name' => 'Hungarian Language Pack - hunglish ',

    // description of new code
    'description' => 'Hungarian (HU) Language Pack - hunglish. Based on the traslation by Nagy Laszlo Zsolt, Zoltan Paulovics',

    // author of new code
    'author' => 'Vastag Laszlo',

    // date published
    'published_date' => '2009/01/06',

    // version of code
    'version' => '5.2.0',

    // type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',

    // icon for displaying in UI (path to graphic contained within zip package)
    'icon' => 'include/images/flag-hu_HU.gif',

    'is_uninstallable' => TRUE,

);



$installdefs = array(
        'id'=> 'hu_hu',
/*
   // This seems unnecessary:
   'copy' => array(
                                                array('from'=> '<basepath>/LEEME-i18n.txt',
                                                          'to'=> 'LEEME-i18n.txt',
                                                          ),
                                                array('from'=> '<basepath>/include',
                                                          'to'=> 'jscalendar',
                                                          ),
                                                array('from'=> '<basepath>/modules',
                                                          'to'=> 'jscalendar',
                                                          ),
                                                array('from'=> '<basepath>/modules',
                                                          'to'=> 'modules',
                                                          ),
                                        ), */
        );
?>
