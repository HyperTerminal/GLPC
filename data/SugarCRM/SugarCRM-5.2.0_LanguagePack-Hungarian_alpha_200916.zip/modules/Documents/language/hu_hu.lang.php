<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.51
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
'LBL_MODULE_NAME' => 'Dokumentumok',
'LBL_MODULE_TITLE' => 'Dokumentumok: Home',
'LNK_NEW_DOCUMENT' => 'Dokumentum létrehozása',
'LNK_DOCUMENT_LIST' => 'Dokumentumok listázása',
'LBL_DOC_REV_HEADER' => 'Dokumentum javítások',
'LBL_SEARCH_FORM_TITLE' => 'Dokumentum keresése',
	//vardef labels
'LBL_DOCUMENT_ID' => 'Dokumentum ID',
'LBL_NAME' => 'Dokumentum neve',
'LBL_DESCRIPTION' => 'Leírás',
'LBL_CATEGORY' => 'Kategória',
'LBL_SUBCATEGORY' => 'Alkategória',
'LBL_STATUS' => 'Állapot',
'LBL_CREATED_BY' => 'Tulajdonos',
'LBL_DATE_ENTERED' => 'Létrehozás dátuma',
'LBL_DATE_MODIFIED' => 'Módosítás dátuma',
'LBL_DELETED' => 'Törölt',
'LBL_MODIFIED' => 'Módosítótt',
'LBL_MODIFIED_USER' => 'Módosítótta',
'LBL_CREATED' => 'Létrehozva',
	'LBL_REVISIONS'=>'Revisions',
'LBL_RELATED_DOCUMENT_ID' => 'Kapcsolódó dokumentum ID',
'LBL_RELATED_DOCUMENT_REVISION_ID' => 'Kapcsolódó dokumentum revízió ID',
'LBL_IS_TEMPLATE' => 'Ez egy Template?',
'LBL_TEMPLATE_TYPE' => 'Dokumentum típusa',
	'LBL_ASSIGNED_TO_NAME'=>'Assigned to:',
'LBL_REVISION_NAME' => 'Javítási (revíziós) szám',
'LBL_MIME' => 'Mime típus',
'LBL_REVISION' => 'Revízió',
'LBL_DOCUMENT' => 'Kapcsolódó dokumentum',
'LBL_LATEST_REVISION' => 'Utolsó revízió',
'LBL_CHANGE_LOG' => 'Változtatási napló',
'LBL_ACTIVE_DATE' => 'Publikálás dátuma',
'LBL_EXPIRATION_DATE' => 'Lejárat dátuma',
'LBL_FILE_EXTENSION' => 'Kiterjesztés',

'LBL_CAT_OR_SUBCAT_UNSPEC' => 'Nincs',
	//quick search
	'LBL_NEW_FORM_TITLE' => 'New Document',
	//document edit and detail view
'LBL_DOC_NAME' => 'Dokumentum neve:',
'LBL_FILENAME' => 'Állomány neve:',
'LBL_DOC_VERSION' => 'Revízió:',
'LBL_CATEGORY_VALUE' => 'Kategória:',
'LBL_SUBCATEGORY_VALUE' => 'Alkategória:',
'LBL_DOC_STATUS' => 'Állapot:',
'LBL_LAST_REV_CREATOR' => 'Lektorálta:',
'LBL_LAST_REV_DATE' => 'Revízió dátuma:',
'LBL_DOWNNLOAD_FILE' => 'Állomány letöltése:',
'LBL_DET_RELATED_DOCUMENT' => 'Kapcsolódó dokumentum:',
'LBL_DET_RELATED_DOCUMENT_VERSION' => 'Kapcsolódó dokumentum revíziója:',
'LBL_DET_IS_TEMPLATE' => 'Template? :',
'LBL_DET_TEMPLATE_TYPE' => 'Dokumentum típusa:',



'LBL_DOC_DESCRIPTION' => 'Leírás:',
'LBL_DOC_ACTIVE_DATE' => 'Publikálás dátuma:',
'LBL_DOC_EXP_DATE' => 'Lejárat dátuma:',

	//document list view.
'LBL_LIST_FORM_TITLE' => 'Dokumentumlista',
'LBL_LIST_DOCUMENT' => 'Dokumentum',
'LBL_LIST_CATEGORY' => 'Kategória',
'LBL_LIST_SUBCATEGORY' => 'Alkategória',
'LBL_LIST_REVISION' => 'Revízió',
'LBL_LIST_LAST_REV_CREATOR' => 'Publikálta',
'LBL_LIST_LAST_REV_DATE' => 'Revízió dátuma',
'LBL_LIST_VIEW_DOCUMENT' => 'Nézet',
'LBL_LIST_DOWNLOAD' => 'Letöltés',
'LBL_LIST_ACTIVE_DATE' => 'Publikálás dátuma',
'LBL_LIST_EXP_DATE' => 'Lejárat dátuma',
'LBL_LIST_STATUS' => 'Status',

	//document search form.
'LBL_SF_DOCUMENT' => 'Dokumentum neve:',
'LBL_SF_CATEGORY' => 'Kategória:',
'LBL_SF_SUBCATEGORY' => 'Alkategória:',
'LBL_SF_ACTIVE_DATE' => 'Publikálás dátuma:',
'LBL_SF_EXP_DATE' => 'Lejárat dátuma:',

'DEF_CREATE_LOG' => 'Dokumentum létrehozva',

	//error messages
'ERR_DOC_NAME' => 'Dokumentum neve',
'ERR_DOC_ACTIVE_DATE' => 'Publikálás dátuma',
'ERR_DOC_EXP_DATE' => 'Lejárat dátuma',
'ERR_FILENAME' => 'Állománynév',
'ERR_DOC_VERSION' => 'Dokumentum verzió',
'ERR_DELETE_CONFIRM' => 'Törölni akarja ezt a revíziót?',
'ERR_DELETE_LATEST_VERSION' => 'Az utolsó revíziót nem törölheti.',
'LNK_NEW_MAIL_MERGE' => 'Levél összefésülés',
'LBL_MAIL_MERGE_DOCUMENT' => 'Levél összefésülés template:',

'LBL_TREE_TITLE' => 'Dokumentumok',
	//sub-panel vardefs.
'LBL_LIST_DOCUMENT_NAME' => 'Dokumentum neve',
'LBL_CONTRACT_NAME' => 'Kapcsolat neve:',
'LBL_LIST_IS_TEMPLATE' => 'Template?',
'LBL_LIST_TEMPLATE_TYPE' => 'Dokumentum típusa',
'LBL_LIST_SELECTED_REVISION' => 'Kiválasztott verzió',
'LBL_LIST_LATEST_REVISION' => 'Utolsó verzió',
'LBL_CONTRACTS_SUBPANEL_TITLE' => 'Kapcsolódó Szerződések',
'LBL_LAST_REV_CREATE_DATE' => 'Utolsó revízió létrehozásának dátuma',
    //'LNK_DOCUMENT_CAT'=>'Document Categories',
'LBL_CONTRACTS' => 'Contracts',
'LBL_CREATED_USER' => 'Created User',
    'LBL_OPPORTUNITY'=>'Opportunity',
);


?>
