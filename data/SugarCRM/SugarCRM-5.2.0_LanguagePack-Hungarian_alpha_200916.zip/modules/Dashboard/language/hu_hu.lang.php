<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.51
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Műszerfal',
'LBL_MODULE_TITLE' => 'Műszerfal: Home',
'LNK_NEW_ACCOUNT' => 'Cég létrehozása',
'LNK_NEW_CALL' => 'Hívás beütemezése',
'LNK_NEW_CASE' => 'Eset létrehozása',
'LNK_NEW_CONTACT' => 'Kapcsolat létrehozása',
'LNK_NEW_ISSUE' => 'Hiba jelentése',
'LNK_NEW_LEAD' => 'Megkeresés létrehozása',
'LNK_NEW_MEETING' => 'Találkozó beütemezése',
'LNK_NEW_NOTE' => 'Feljegyzés vagy csatolmány létrehozása',
'LNK_NEW_OPPORTUNITY' => 'Lehetőség létrehozása',
'LNK_NEW_QUOTE' => 'Ajánlat létrehozása',
'LNK_NEW_TASK' => 'Feladat létrehozása',

'LBL_ADD_A_CHART' => 'Diagram hozzáadása',
'LBL_DELETE_FROM_DASHBOARD' => 'Törlés a műszerfalról',
'LBL_MOVE_DOWN' => 'Fölfelé mozgat',
'LBL_MOVE_UP' => 'Lefelé mozgat',
'LBL_BASIC_CHARTS' => '-- Alapvető Diagramok --',
'LBL_PUBLISHED_REPORTS' => '-- Publikált Jelentések --',
'LBL_MY_REPORTS' => '-- Saját mentett jelentéseim --',
'LBL_TEAM_REPORTS' => '-- Saját csapatom jelentései --',
'LBL_REPORT_NO_CHART' => 'Ehhez a jelentéshez nincsenek diagramok',
'LBL_MOVE_CHARTS' => '(Kattintson a grafikonra, ha át kívánja mozgatni)',
  	
  	'LBL_DASHBOARD_PAGE_1' => 'Dashboard Home',
  	'LBL_DASHBOARD_PAGE_2' => 'Sales Dashboard',
);


?>
