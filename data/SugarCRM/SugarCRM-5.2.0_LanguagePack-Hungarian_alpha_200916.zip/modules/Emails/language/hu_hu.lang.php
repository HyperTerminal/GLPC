<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.52
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_FW'					=> 'FW:',
	'LBL_RE'					=> 'RE:',

	'LBL_BUTTON_CREATE'					=> 'Create',
	'LBL_BUTTON_EDIT'					=> 'Edit',
	'LBL_QS_DISABLED'                   => '(QuickSearch is not availible for this module. Please use the select button.)',
	'LBL_SIGNATURE_PREPEND'				=> 'Signature above reply?',
    'LBL_EMAIL_DEFAULT_DESCRIPTION' 	=> 'Here is the quote you requested (You can change this text)',
'LBL_EMAIL_QUOTE_FOR' => 'Quote for: ',
'LBL_QUOTE_LAYOUT_DOES_NOT_EXIST_ERROR' => 'quote layout file does not exist: $layout',
'LBL_QUOTE_LAYOUT_REGISTERED_ERROR' => 'quote layout is not registered in modules/Quotes/Layouts.php',


'LBL_CONFIRM_DELETE' => 'Tényleg törölni akarja ezt a mappát?',







'ERR_ARCHIVE_EMAIL' => 'Hiba: Jelőlje ki az arhíválandó emaileket.',
'ERR_DATE_START' => 'Kezdés dátuma',
'ERR_DELETE_RECORD' => 'A cég törléséhez meg kell adni egy rekordot.',
'ERR_NOT_ADDRESSED' => 'Az email-ben lennie kell egy To, CC vagy BCC címének',
'ERR_TIME_START' => 'Kezdés idő',
'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Cégek',
'LBL_ADD_ANOTHER_FILE' => 'Új állomány hozzáadása',
'LBL_ADD_DASHLETS' => 'Dashlet-ek hozzáadása',
'LBL_ADD_DOCUMENT' => 'Sugar dokumentum hozzáadása',
	'LBL_ADD_ENTRIES'           => 'Add Entries',
'LBL_ADD_FILE' => 'Állomány hozzáadása',
'LBL_ARCHIVED_EMAIL' => 'Archívált email',
'LBL_ARCHIVED_MODULE_NAME' => 'Archivált emailek létrehozása',
'LBL_ATTACHMENTS' => 'Melléklet:',
'LBL_BCC' => 'Bcc:',
'LBL_BODY' => 'Törzs:',
'LBL_BUGS_SUBPANEL_TITLE' => 'Hibák',
'LBL_CC' => 'Cc:',
'LBL_COLON' => ':',
'LBL_COMPOSE_MODULE_NAME' => 'Email létrehozása',
'LBL_CONTACT_FIRST_NAME' => 'Kapcsolat keresztnév',
'LBL_CONTACT_LAST_NAME' => 'Kapcsolat vezetéknév',
'LBL_CONTACT_NAME' => 'Kapcsolat:',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kapcsolatok',
'LBL_CREATED_BY' => 'Tulajdonos',
'LBL_DATE_AND_TIME' => 'Küldés időpontja:',
'LBL_DATE_SENT' => 'Küldés dátuma:',
'LBL_DATE' => 'Küldés dátuma:',
'LBL_DELETE_FROM_SERVER' => 'Delete message from server',
'LBL_DESCRIPTION' => 'Leírás',
'LBL_EDIT_ALT_TEXT' => 'Alt szerkesztése',
'LBL_EDIT_MY_SETTINGS' => 'Saját beállításaim szerkesztése',
'LBL_EMAIL_ATTACHMENT' => 'Email melléklet',
'LBL_EMAIL_EDITOR_OPTION' => 'HTML email küldése',
'LBL_EMAIL_SELECTOR' => 'Választás',
'LBL_EMAIL' => 'Email:',
'LBL_EMAILS_ACCOUNTS_REL' => 'Emails:Cégek',
'LBL_EMAILS_BUGS_REL' => 'Emails:Hibák',
'LBL_EMAILS_CASES_REL' => 'Emails:Esetek',
'LBL_EMAILS_CONTACTS_REL' => 'Emails:Kapcsolatok',
'LBL_EMAILS_LEADS_REL' => 'Emails:Megkeresések',
'LBL_EMAILS_OPPORTUNITIES_REL' => 'Emails:Lehetőségek',
'LBL_EMAILS_NOTES_REL' => 'Emails:Megjegyzések',
'LBL_EMAILS_PROJECT_REL' => 'Emails:Projektek',
'LBL_EMAILS_PROJECT_TASK_REL' => 'Emails:ProjektFeladatok',
'LBL_EMAILS_PROSPECT_REL' => 'Emails:Prospect',
'LBL_EMAILS_TASKS_REL' => 'Emails:Feladatok',
'LBL_EMAILS_USERS_REL' => 'Emails:Felhasználók',
'LBL_ERROR_SENDING_EMAIL' => 'Hiba az email küldéskor',
'LBL_FORWARD_HEADER' => 'Továbbított levél fejléce:',
'LBL_FROM_NAME' => 'Küldő neve',
'LBL_FROM' => 'Küldő:',
	'LBL_REPLY_TO'				=> 'Reply To:',
'LBL_HTML_BODY' => 'HTML Törzs',
'LBL_INVITEE' => 'Címzettek',
'LBL_LEADS_SUBPANEL_TITLE' => 'Megkeresések',
'LBL_MESSAGE_SENT' => 'Elküldve',
'LBL_MODIFIED_BY' => 'Módosította',
'LBL_MODULE_NAME_NEW' => 'Email Archiválása',
'LBL_MODULE_NAME' => 'Emailek',
'LBL_MODULE_TITLE' => 'Emailek: ',
'LBL_NEW_FORM_TITLE' => 'Email archiválása',
	'LBL_NONE'                  => 'None',
'LBL_NOT_SENT' => 'Küldési hiba',
'LBL_NOTE_SEMICOLON' => 'Megjegyzés: használjon pontosvesszőt több email cím elválasztásához.',
'LBL_NOTES_SUBPANEL_TITLE' => 'Csatolt állományok',
'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Lehetőségek',
'LBL_PROJECT_SUBPANEL_TITLE' => 'Projektek',
'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Projekt Tasks',
'LBL_RAW' => 'Nyers Email',
'LBL_SAVE_AS_DRAFT_BUTTON_KEY' => 'R',
'LBL_SAVE_AS_DRAFT_BUTTON_LABEL' => 'Piszkozat mentése',
'LBL_SAVE_AS_DRAFT_BUTTON_TITLE' => 'Piszkozat mentése [Alt+R]',
'LBL_SEARCH_FORM_DRAFTS_TITLE' => 'Piszkozatok keresése',
'LBL_SEARCH_FORM_SENT_TITLE' => 'Elküldött levelek keresése',
'LBL_SEARCH_FORM_TITLE' => 'Email keresés',
'LBL_SEND_ANYWAYS' => 'Nincs a tárgy kitöltve. Biztosan elküldi/menti?',
'LBL_SEND_BUTTON_KEY' => 'S',
'LBL_SEND_BUTTON_LABEL' => 'Küld',
'LBL_SEND_BUTTON_TITLE' => 'Küld [Alt+S]',
'LBL_SEND' => 'KÜLD',
'LBL_SENT_MODULE_NAME' => 'Elküldött levelet',
'LBL_SHOW_ALT_TEXT' => 'Alt szöveg mutatása',
'LBL_SIGNATURE' => 'Aláírás',
'LBL_SUBJECT' => 'Tárgy:',
'LBL_TEXT_BODY' => 'Szövegtörzs',
'LBL_TIME' => 'Küldés ideje:',
'LBL_TO_ADDRS' => 'To',
'LBL_USE_TEMPLATE' => 'Sablon használata:',
'LBL_USERS_SUBPANEL_TITLE' => 'Felhasználók',
'LBL_USERS' => 'Felhasználók',

'LNK_ALL_EMAIL_LIST' => 'Minden email',
'LNK_ARCHIVED_EMAIL_LIST' => 'Archivált emailek',
'LNK_CALL_LIST' => 'Hívások',
'LNK_DRAFTS_EMAIL_LIST' => 'Minden piszkozat',
'LNK_EMAIL_LIST' => 'Emailek',
	'LBL_EMAIL_RELATE'          => 'Relate To',
'LNK_EMAIL_TEMPLATE_LIST' => 'Email sablonok',
'LNK_MEETING_LIST' => 'Találkozók',
'LNK_NEW_ARCHIVE_EMAIL' => 'Archivált email létrehozása',
'LNK_NEW_CALL' => 'Hívás ütemezés',
'LNK_NEW_EMAIL_TEMPLATE' => 'Email létrehozása',
'LNK_NEW_EMAIL' => 'Archivált email',
'LNK_NEW_MEETING' => 'Találkozó ütemezése',
'LNK_NEW_NOTE' => 'Feljegyzés létrehozása',
'LNK_NEW_SEND_EMAIL' => 'Email létrehozása',
'LNK_NEW_TASK' => 'Feladat létrehozása',
'LNK_NOTE_LIST' => 'Feljegyzések',
'LNK_SENT_EMAIL_LIST' => 'Elküldött emailek',
'LNK_TASK_LIST' => 'Feladatok',
'LNK_VIEW_CALENDAR' => 'Ma',

'LBL_LIST_ASSIGNED' => 'Hozzárendelve',
'LBL_LIST_CONTACT_NAME' => 'Kapcsolat neve',
'LBL_LIST_CREATED' => 'Létrehozva',
'LBL_LIST_DATE_SENT' => 'Küldés dátuma',
'LBL_LIST_DATE' => 'Küldés dátuma',
'LBL_LIST_FORM_DRAFTS_TITLE' => 'Piszkozat',
'LBL_LIST_FORM_SENT_TITLE' => 'Elküldött emailek',
'LBL_LIST_FORM_TITLE' => 'Email lista',
'LBL_LIST_FROM_ADDR' => 'From',
'LBL_LIST_RELATED_TO' => 'Kapcsolatban áll',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_TIME' => 'Küldés ideje',
'LBL_LIST_TO_ADDR' => 'To',
'LBL_LIST_TYPE' => 'Típus',

'NTC_REMOVE_INVITEE' => 'Biztos benne, hogy eltávolítja ezt a címzettet az email-ből?',
'WARNING_SETTINGS_NOT_CONF' => 'Figyelem: az ön beállításai úgy vannak konfigurálva, hogy nem tud levelet küldeni.',
'WARNING_NO_UPLOAD_DIR' => 'A csatolási hibát okozhat: Nincs érvényes "upload_tmp_dir" mappa.  Kérem, korrigálja a php.ini file-ben a megfelelő beállítást.',
'WARNING_UPLOAD_DIR_NOT_WRITABLE' => 'A csatolási hibát okozhat: Nem megfelelő "upload_tmp_dir" mappa. Kérem, korrigálja a php.ini file-ben a megfelelő beállítást.',

    // for All emails
'LBL_BUTTON_RAW_TITLE' => 'Mutassa a nyers üzenetet [Alt+E]',
'LBL_BUTTON_RAW_KEY' => 'e',
'LBL_BUTTON_RAW_LABEL' => 'Show Raw',
'LBL_BUTTON_RAW_LABEL_HIDE' => 'Hide Raw',

	// for InboundEmail
'LBL_BUTTON_CHECK' => 'Emailek?',
'LBL_BUTTON_CHECK_TITLE' => 'Új Emailek? [Alt+C]',
'LBL_BUTTON_CHECK_KEY' => 'c',
'LBL_BUTTON_FORWARD' => 'Továbbküld',
'LBL_BUTTON_FORWARD_TITLE' => 'Továbbküldi az emailt [Alt+F]',
'LBL_BUTTON_FORWARD_KEY' => 'f',
'LBL_BUTTON_REPLY_KEY' => 'r',
'LBL_BUTTON_REPLY_TITLE' => 'Válaszol [Alt+R]',
'LBL_BUTTON_REPLY' => 'Válaszol',
'LBL_CASES_SUBPANEL_TITLE' => 'Esetek',
'LBL_INBOUND_TITLE' => 'Bejövő email',
'LBL_INTENT' => 'Szándék',
'LBL_MESSAGE_ID' => 'Üzenet ID',
'LBL_REPLY_HEADER_1' => 'On ',
'LBL_REPLY_HEADER_2' => 'irta: ',
'LBL_REPLY_TO_ADDRESS' => 'Reply-to cím',
'LBL_REPLY_TO_NAME' => 'Reply-to név',

'LBL_LIST_BUG' => 'Hibák',
'LBL_LIST_CASE' => 'Esetek',
'LBL_LIST_CONTACT' => 'Kapcsolatok',
'LBL_LIST_LEAD' => 'Megkeresések',
'LBL_LIST_TASK' => 'Feladatok',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',

	// for Inbox
'LBL_ALL' => 'Mind',
'LBL_ASSIGN_WARN' => 'Győződjön meg, hogy mind a három opció be van jelölve.',
'LBL_BACK_TO_GROUP' => 'Vissza a Csoport Inbox-ba',
'LBL_BUTTON_DISTRIBUTE_KEY' => 'a',
'LBL_BUTTON_DISTRIBUTE_TITLE' => 'Hozzárendel [Alt+A]',
'LBL_BUTTON_DISTRIBUTE' => 'Hozzárendel',
'LBL_BUTTON_GRAB_KEY' => 't',
'LBL_BUTTON_GRAB_TITLE' => 'Csoportból kiszed [Alt+T]',
'LBL_BUTTON_GRAB' => 'Csoportból kiszed',
'LBL_CREATE_BUG' => 'Hibajelentés',
'LBL_CREATE_CASE' => 'Eset létrehozása',
'LBL_CREATE_CONTACT' => 'Kapcsolat létrehozása',
'LBL_CREATE_LEAD' => 'Megkeresés létrehozása',
'LBL_CREATE_TASK' => 'Feladat létrehozása',
'LBL_DIST_TITLE' => 'Hozzárendelés',
'LBL_LOCK_FAIL_DESC' => 'A választott elem jelenleg nem elérhető.',
'LBL_LOCK_FAIL_USER' => ' birtokba vette.',
'LBL_MASS_DELETE_ERROR' => 'Nem voltak törlésre kijelölt elemek.',
'LBL_NEW' => 'Új',
'LBL_NEXT_EMAIL' => 'Következő',
'LBL_NO_GRAB_DESC' => 'Nem voltak elérhető elemek. Később próbálja újra .',
'LBL_QUICK_REPLY' => 'Válasz',
'LBL_REPLIED' => '--',
'LBL_SELECT_TEAM' => 'Csapatok kiválasztása',
'LBL_TAKE_ONE_TITLE' => 'Címz.',
'LBL_TITLE_SEARCH_RESULTS' => 'A keresés eredménye',
'LBL_TO' => 'To: ',
'LBL_TOGGLE_ALL' => 'Mindent negál',
'LBL_UNKNOWN' => 'Ismeretlen',
'LBL_UNREAD_HOME' => 'Olvasatlan emailek',
'LBL_UNREAD' => 'Olvasatlan',
'LBL_USE_ALL' => 'Összes találat',
'LBL_USE_CHECKED' => 'Csak a választott',
'LBL_USE_MAILBOX_INFO' => 'Postafiók email használata',
'LBL_USE' => 'Hozzárendel:',
	'LBL_ASSIGN_SELECTED_RESULTS_TO' => 'Assign Selected Results To: ',
'LBL_USER_SELECT' => 'Felhasználók választása',
'LBL_USING_RULES' => 'Szabályok használata:',
'LBL_WARN_NO_DIST' => 'Nincs választva szétosztási metódus',
'LBL_WARN_NO_USERS' => 'Nincsenek választva felhasználók',

'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_TITLE_GROUP_INBOX' => 'Csoport Inbox',
'LBL_LIST_TITLE_MY_DRAFTS' => 'Saját piszkozataim',
'LBL_LIST_TITLE_MY_INBOX' => 'Saját Inbox (beérkező leveleim)',
'LBL_LIST_TITLE_MY_SENT' => 'Elküldött leveleim',
'LBL_LIST_TITLE_MY_ARCHIVES' => 'Arhívált Emailek',

'LNK_CHECK_MY_INBOX' => 'Inbox',
'LNK_DATE_SENT' => 'Küldés dátuma',
'LNK_GROUP_INBOX' => 'Group Inbox',
'LNK_MY_DRAFTS' => 'Piszkozatok',
'LNK_MY_INBOX' => 'Saját Inbox',
'LNK_QUICK_REPLY' => 'Válaszol',
'LNK_MY_ARCHIVED_LIST' => 'Arhívum',

	// advanced search
'LBL_ASSIGNED_TO' => 'Hozzárendelve:',
'LBL_MEMBER_OF' => 'Szülő',
'LBL_QUICK_CREATE' => 'Gyors létrehozás',
'LBL_STATUS' => 'Email állapot:',
	'LBL_EMAIL_FLAGGED'			=> 'Flagged:',
	'LBL_EMAIL_REPLY_TO_STATUS'	=> 'Reply To Status:',
'LBL_TYPE' => 'Típus:',
	//#20680 EmialTemplate Ext.Message.show;
	'LBL_EMAILTEMPLATE_MESSAGE_SHOW_TITLE' => 'Please check!',
	'LBL_EMAILTEMPLATE_MESSAGE_SHOW_MSG' => 'Selecting this template will overwrite any data already entered within the email body. Do you wish to continue?',
'LBL_ASSIGNED_TO' => 'Hozzárendelve:',
);
