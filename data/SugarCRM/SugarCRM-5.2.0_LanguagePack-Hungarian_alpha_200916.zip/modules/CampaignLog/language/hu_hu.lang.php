<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.50
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'LBL_LIST_ID' => 'Lehetséges vevő Lista ID',
'LBL_ID' => 'ID',
'LBL_TARGET_TRACKER_KEY' => 'Cél Követő Kulcs',
'LBL_TARGET_ID' => 'Cél ID',
'LBL_TARGET_TYPE' => 'Cél típus',
'LBL_ACTIVITY_TYPE' => 'Tevékenység Típus',
'LBL_ACTIVITY_DATE' => 'Tevékenység Dátum',
'LBL_RELATED_ID' => 'Összefüggés Id',
'LBL_RELATED_TYPE' => 'Összefüggés Típus',
'LBL_DELETED' => 'Törölt',
'LBL_MODULE_NAME' => 'Kampány Napló',
'LBL_LIST_RECIPIENT_EMAIL' => 'Címzett EMail',
'LBL_LIST_RECIPIENT_NAME' => 'Címzett Név',
'LBL_ARCHIVED' => 'Archivált',
'LBL_HITS' => 'Találatok',
	
'LBL_CAMPAIGN_NAME' => 'Név:',
'LBL_CAMPAIGN' => 'Kampány:',
'LBL_NAME' => 'Név: ',
'LBL_INVITEE' => 'Kapcsolatok',
'LBL_LIST_CAMPAIGN_NAME' => 'Kampány',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_TYPE' => 'Típus',
'LBL_LIST_END_DATE' => 'Vég dátum',
'LBL_DATE_ENTERED' => 'Beírt dátum',
'LBL_DATE_MODIFIED' => 'Módosított dátum',
'LBL_MODIFIED' => 'Módosító: ',
'LBL_CREATED' => 'Létrehozó: ',
'LBL_TEAM' => 'Csapat: ',
'LBL_ASSIGNED_TO' => 'Hozzárendelve: ',
'LBL_CAMPAIGN_START_DATE' => 'Kezdés dátuma: ',
'LBL_CAMPAIGN_END_DATE' => 'Befejezés dátuma: ',
'LBL_CAMPAIGN_STATUS' => 'Állapot: ',
'LBL_CAMPAIGN_BUDGET' => 'Büdzsé: ',
'LBL_CAMPAIGN_EXPECTED_COST' => 'Várható költség: ',
'LBL_CAMPAIGN_ACTUAL_COST' => 'Valós költség: ',
'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Várható bevétel: ',
'LBL_CAMPAIGN_TYPE' => 'Típus: ',
'LBL_CAMPAIGN_OBJECTIVE' => 'Cél: ',
'LBL_CAMPAIGN_CONTENT' => 'Leírás: ',
'LBL_CREATED_LEAD' => 'Created Lead',
'LBL_CREATED_CONTACT' => 'Created Contact',
'LBL_LIST_FORM_TITLE' => 'Célzott Kampányok',
'LBL_LIST_ACTIVITY_DATE' => 'Aktivitás dátuma',
'LBL_LIST_CAMPAIGN_OBJECTIVE' => 'Kampány célja',
'LBL_RELATED' => 'Összefüggés',
'LBL_CLICKED_URL_KEY' => 'Meghívott URL Key',
'LBL_URL_CLICKED' => 'Meghívott URL',
'LBL_MORE_INFO' => 'További információk',
    
'LBL_CAMPAIGNS' => 'Campaigns',
);
?>
