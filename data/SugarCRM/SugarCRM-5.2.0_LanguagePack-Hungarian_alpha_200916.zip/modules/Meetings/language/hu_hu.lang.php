<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.55
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'ERR_DELETE_RECORD' => 'A találkozó törléséhez meg kell adnia egy rekordsorszámot.',
	
'LBL_ACCEPT_THIS' => 'Elfogadja?',
'LBL_ADD_BUTTON' => 'Hozzáad',
'LBL_ADD_INVITEE' => 'Meghívottak hozzáadása',
'LBL_COLON' => ':',
'LBL_CONTACT_NAME' => 'Kapcsolat:',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kapcsolatok',
'LBL_CREATED_BY' => 'Létrehozó',
'LBL_DATE_END' => 'Végdátum',
'LBL_DATE_TIME' => 'Kezdési időpont:',
'LBL_DATE' => 'Kezdés dátuma:',
'LBL_DEFAULT_STATUS' => 'Tervezett',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Találkozók',
'LBL_DEL' => 'Töröl',
'LBL_DESCRIPTION_INFORMATION' => 'Leírás',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_DURATION_HOURS' => 'Hossza órák:',
'LBL_DURATION_MINUTES' => 'Hossza percek:',
'LBL_DURATION' => 'Hossza:',
'LBL_EMAIL' => 'Email',
'LBL_FIRST_NAME' => 'Keresztnév',
'LBL_HISTORY_SUBPANEL_TITLE' => 'Feljegyzések',
'LBL_HOURS_ABBREV' => 'ó',
'LBL_HOURS_MINS' => '(órák/percek)',
'LBL_INVITEE' => 'Meghívottak',
'LBL_LAST_NAME' => 'Vezetéknév',
	'LBL_ASSIGNED_TO_NAME'=>'Assigned to:',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',
'LBL_LIST_CLOSE' => 'Bezár',
'LBL_LIST_CONTACT' => 'Kapcsolat',
'LBL_LIST_DATE_MODIFIED' => 'Módosítva',
'LBL_LIST_DATE' => 'Kezdés dátuma',
'LBL_LIST_DUE_DATE' => 'Határidó',
'LBL_LIST_FORM_TITLE' => 'Találkozók lista',
'LBL_LIST_MY_MEETINGS' => 'Találkozóim',
'LBL_LIST_RELATED_TO' => 'Kapcsolódó',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_TIME' => 'Kezdés ideje',
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads',
'LBL_LOCATION' => 'Helyszín:',
'LBL_MEETING' => 'Megbeszélés:',
'LBL_MINSS_ABBREV' => 'p',
'LBL_MODIFIED_BY' => 'Módosító',
'LBL_MODULE_NAME' => 'Találkozók',
'LBL_MODULE_TITLE' => 'Találkozók: Home',
'LBL_NAME' => 'Név',
'LBL_NEW_FORM_TITLE' => 'Találkozók ütemezése',
'LBL_OUTLOOK_ID' => 'Outlook ID',
'LBL_PHONE' => 'Irodai Telefon:',
'LBL_REMINDER_TIME' => 'Emlékeztető ideje',
'LBL_REMINDER' => 'Emlékeztető:',
'LBL_SCHEDULING_FORM_TITLE' => 'Ütemezés',
'LBL_SEARCH_BUTTON' => 'Keresés',
'LBL_SEARCH_FORM_TITLE' => 'Találkozók keresése',
'LBL_SEND_BUTTON_KEY' => 'I',
'LBL_SEND_BUTTON_LABEL' => 'Meghívók küldése',
'LBL_SEND_BUTTON_TITLE' => 'Meghívók küldése [Alt+I]',
'LBL_STATUS' => 'Állapot:',
'LBL_SUBJECT' => 'Tárgy:',
'LBL_TIME' => 'Kezdés ideje:',
'LBL_USERS_SUBPANEL_TITLE' => 'Felhasználók',
	
'LNK_CALL_LIST' => 'Hívások',
'LNK_EMAIL_LIST' => 'Emailek',
'LNK_MEETING_LIST' => 'Találkozók',
'LNK_NEW_APPOINTMENT' => 'Megbeszélés létrehozása',
'LNK_NEW_CALL' => 'Hívások ütemezése',
'LNK_NEW_EMAIL' => 'Email archiválása',
'LNK_NEW_MEETING' => 'Találkozók ütemezése',
'LNK_NEW_NOTE' => 'Feljegyzés vagy csatolmány létrehozása',
'LNK_NEW_TASK' => 'Feladat létrehozása',
'LNK_NOTE_LIST' => 'Feljegyzések',
'LNK_TASK_LIST' => 'Feladatok',
'LNK_VIEW_CALENDAR' => 'Ma',
	
'NTC_REMOVE_INVITEE' => 'Biztos benne, hogy törli ezt a meghívottat a találkozóból?',
'LBL_CREATED_USER' => 'Created User',
'LBL_MODIFIED_USER' => 'Modified User',
'NOTICE_DURATION_TIME' => 'Duration time must be greater than 0',
    'LBL_ASSIGNED_TO' => 'Assigned to:',
);
?>
