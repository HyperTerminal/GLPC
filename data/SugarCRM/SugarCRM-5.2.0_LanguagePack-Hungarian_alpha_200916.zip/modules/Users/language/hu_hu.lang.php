<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.58
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:	Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
















'ERR_DELETE_RECORD' => 'A bejegyzés törléséhez meg kell adni egy rekordsorszámot.',
'ERR_EMAIL_NO_OPTS' => 'Nem talál optumum beállításokat az Inbound Email-hez.',
'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Kérem adja meg az új jelszó megerősítését.',
'ERR_ENTER_NEW_PASSWORD' => 'Kérem adja meg az új jelszavát.',
'ERR_ENTER_OLD_PASSWORD' => 'Kérem adja meg a régi jelszavát.',
'ERR_IE_FAILURE1' => '[Vissza]',
'ERR_IE_FAILURE2' => 'Hibás kapcsolat az Email Account-hoz.  Ellenőrízze a beállításokat és próbálja újra.',
'ERR_IE_MISSING_REQUIRED' => 'Inbound Email settings are missing required information. Please check your settings and try again. If you are not setting up Inbound Email, please clear all fields in that section.',
'ERR_INVALID_PASSWORD' => 'Érvényes felhasználói nevet és jelszót kell megadnia.',
	'ERR_NO_LOGIN_MOBILE'				=> 'Your first login to this application must be completed with a non-mobile browser or in normal mode. Please return with a full browser or click on the normal link below. We apologize for any inconvenience.',
'ERR_LAST_ADMIN_1' => 'A felhasználói név "',
'ERR_LAST_ADMIN_2' => '" az utolsó adminisztrátori jogokkal rendelkező felhasználó. Legalább egy felhasználó adminisztrátor kell, hogy legyen.',
'ERR_PASSWORD_CHANGE_FAILED_1' => 'Jelszóváltás:',
'ERR_PASSWORD_CHANGE_FAILED_2' => ' sikertelen.  Az új jelszót be kell állítani.',
'ERR_PASSWORD_INCORRECT_OLD_1' => 'Érvénytelen régi jelszó a(z) ',
'ERR_PASSWORD_INCORRECT_OLD_2' => 'felhasználóhoz. Kérem adja meg újra a jelszavakat.',
'ERR_PASSWORD_MISMATCH' => 'A beírt jelszavak nem azonosak.',
'ERR_REENTER_PASSWORDS' => 'Kérem adja meg a jelszavakat újra.  Az "új jelszó" és a "jelszó megerősítése" értékek nem egyeznek.',
'ERR_REPORT_LOOP' => 'A rendszer jelentési kört észlelt. Egy felhasználó nem tehet jelentés magának, illetve a saját menedzsere sem tehet jelentést neki.',
'ERR_USER_NAME_EXISTS_1' => 'A felhasználói név ',
'ERR_USER_NAME_EXISTS_2' => ' már létezik.  A duplikált felhasználói nevek nem megengedettek. Válasszon egyedi felhasználói nevet.',

'LBL_ADDRESS_CITY' => 'Cím Város:',
'LBL_ADDRESS_COUNTRY' => 'Cím Ország:',
'LBL_ADDRESS_INFORMATION' => 'Cím Információ',
'LBL_ADDRESS_POSTALCODE' => 'Cím Irányítószám:',
'LBL_ADDRESS_STATE' => 'Cím Állam:',
'LBL_ADDRESS_STREET' => 'Cím Utca:',
'LBL_ADDRESS' => 'Cím:',
'LBL_ADMIN_TEXT' => 'Adminisztrátori jogokat ad ennek a felhasználónak',
'LBL_ADMIN' => 'Adminisztrátor:',
'LBL_ANY_EMAIL' => 'Általános Email:',
'LBL_ANY_PHONE' => 'Általános Telefon:',
'LBL_BUTTON_CREATE' => 'Új',
'LBL_BUTTON_EDIT' => 'Módosítás',
'LBL_CALENDAR_OPTIONS' => 'Naptár beállítások',
'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Jelszó változtatás',
'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Jelszó változtatás [Alt+P]',
'LBL_CHANGE_PASSWORD' => 'Jelszó változtatás',
'LBL_CHOOSE_A_KEY' => 'Válasszon egy kulcsot, hogy elkerülje a személyes naptárjának illetéktelen publikációját',
'LBL_CHOOSE_WHICH' => 'Válassza ki az elérhető füleket',
'LBL_CITY' => 'Város:',

'LBL_CLEAR_BUTTON_TITLE' => 'Törlés',


'LBL_CONFIRM_PASSWORD' => 'Jelszó megerősítése:',
'LBL_COUNTRY' => 'Ország:',
'LBL_CURRENCY_TEXT' => 'Alapértelmezett pénznem választása',
'LBL_CURRENCY' => 'Pénznem:',
'LBL_CURRENCY_EXAMPLE' => 'Currency Display Example',
'LBL_CURRENCY_SIG_DIGITS' => 'Currency Significant Digits',
'LBL_CURRENCY_SIG_DIGITS_DESC' => 'Number of decimal places to show for currency',
'LBL_NUMBER_GROUPING_SEP' => '1000-es szeparátor',
'LBL_NUMBER_GROUPING_SEP_TEXT' => 'Ezres szeparátor karakter',
'LBL_DECIMAL_SEP' => 'Tizedesjel',
'LBL_DECIMAL_SEP_TEXT' => 'Tizedesjel karakter',
'LBL_DATE_FORMAT_TEXT' => 'Dátumok formátumának megadása',
'LBL_DATE_FORMAT' => 'Dátum formátum:',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Felhasználók',
'LBL_DEPARTMENT' => 'Részleg:',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_DISPLAY_TABS' => 'Mutatott fülek',
'LBL_DST_INSTRUCTIONS' => '(+DST) jelzi, hogy a téli/nyári időszámítás figyelés be van kapcsolva',
'LBL_EDIT_TABS' => 'Fülek szerkesztése',
'LBL_EDIT' => 'Módosítás',
'LBL_EMAIL_OTHER' => 'Email 2:',
'LBL_EMAIL' => 'Email:',
'LBL_EMAIL_CHARSET' => 'Kimenő Levelek Karakterkészlete',
'LBL_EMAIL_EDITOR_OPTION' => 'Formátum létrehozása',
	'LBL_EMAIL_GMAIL_DEFAULTS'			=> 'Prefill Gmail Defaults',
'LBL_EMAIL_LINK_TYPE' => 'Email kliens',
'LBL_EMAIL_SHOW_COUNTS' => 'Mutassa az email-ek számát?',
'LBL_EMAIL_SIGNATURE_ERROR1' => 'Ehhez az aláíráshoz meg kell adni a nevet.',
	'LBL_EMAIL_SMTP_SSL'				=> 'Enable SMTP over SSL',
'LBL_EMPLOYEE_STATUS' => 'Alkalmazotti Állapot:',
'LBL_ERROR' => 'Hiba:',
'LBL_EXPORT_CHARSET' => 'Import/Export Karakterkészlet',
'LBL_EXPORT_CHARSET_DESC' => 'Choose the character set used in your locale. This property will be used for data imports, outbound emails, .csv exports, PDF generation, and for vCard generation.',
'LBL_EXPORT_DELIMITER' => 'Export határolójel',
'LBL_EXPORT_DELIMITER_DESC' => 'Specify the character(s) used to delimit exported data.',
'LBL_FAX_PHONE' => 'Fax:',
'LBL_FAX' => 'Fax:',
'LBL_FIRST_NAME' => 'Keresztnév:',
'LBL_GRIDLINE_TEXT' => 'Rácsok vezérlése a részlet nézetekben',
'LBL_GRIDLINE' => 'Rácsok mutatása a táblázatokban:',
'LBL_GROUP_DESC' => 'Csoport felhasználó. Ez a felhasználó nem tud bejelentkezni a Sugar Suite web felületen keresztül. Ez a felhasználó csak arra használható, hogy hozzárendeljen elemeket egy csoporthoz a Bejövő Email funkciók segítségével.',
'LBL_GROUP_USER_STATUS' => 'Csoport Felhasználó',
'LBL_GROUP' => 'Csoport Felhasználó:',
'LBL_HIDE_TABS' => 'Rejtett fülek',
'LBL_HOME_PHONE' => 'Otthoni Telefon:',
'LBL_INBOUND_TITLE' => 'Fiók információk',
'LBL_IS_ADMIN' => 'Adminisztrátor',
'LBL_LANGUAGE' => 'Nyelv:',
'LBL_LAST_NAME' => 'Vezetéknév:',
'LBL_LAYOUT_OPTIONS' => 'Elrendezés Beállítások',
'LBL_LIST_ACCEPT_STATUS' => 'Status elfogadva',
'LBL_LIST_ADMIN' => 'Admin',
'LBL_LIST_DEPARTMENT' => 'Részleg',
'LBL_LIST_EMAIL' => 'Email',
'LBL_LIST_FORM_TITLE' => 'Felhasználók',
'LBL_LIST_GROUP' => 'Csoport',
'LBL_LIST_LAST_NAME' => 'Vezetéknév',
'LBL_LIST_MEMBERSHIP' => 'Szervezeti tagság',
'LBL_LIST_NAME' => 'Név',
'LBL_LIST_PRIMARY_PHONE' => 'Elsődleges telefon',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_TITLE' => 'Cím',
'LBL_LIST_USER_NAME' => 'Felhasználó név',
'LBL_LOCALE_DEFAULT_NAME_FORMAT' => 'Name Display Format',
'LBL_LOCALE_DESC_FIRST' => '[First]',
'LBL_LOCALE_DESC_LAST' => '[Last]',
'LBL_LOCALE_DESC_SALUTATION' => '[Salutation]',
	'LBL_LOCALE_DESC_TITLE'				=> '[Title]',
'LBL_LOCALE_EXAMPLE_NAME_FORMAT' => 'Example',
'LBL_LOCALE_NAME_FORMAT_DESC' => 'Set how names will be displayed.',
'LBL_LOCALE_NAME_FORMAT_DESC_2' => '<i>"s" Salutation<br>"f" First Name<br>"l" Last Name</i>',
'LBL_SAVED_SEARCH' => 'Saved Search & Layout',
	// LOGIN PAGE STRINGS
'LBL_LOGIN_BUTTON_KEY' => 'L',
'LBL_LOGIN_BUTTON_LABEL' => 'Bejelentkezés',
'LBL_LOGIN_BUTTON_TITLE' => 'Bejelentkezés [Alt+L]',
'LBL_LOGIN_WELCOME_TO' => 'Üdvözöljük',
'LBL_LOGIN_OPTIONS' => 'Beállítások',
'LBL_LOGIN_FORGOT_PASSWORD' => 'Forgot Password?',
'LBL_LOGIN_EMAIL_TEMP_PWD' => 'Email Temporary Password',
	// END LOGIN PAGE STRINGS
'LBL_MAIL_FROMADDRESS' => '"From" Cím:',
'LBL_MAIL_FROMNAME' => '"From" Név:',
'LBL_MAIL_OPTIONS_TITLE' => 'E-mail Beállítások',
'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
'LBL_MAIL_SMTPAUTH_REQ' => 'SMTP azonosítás használata?',
'LBL_MAIL_SMTPPASS' => 'SMTP Jelszó:',
'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
'LBL_MAIL_SMTPSERVER' => 'SMTP Szerver:',
'LBL_MAIL_SMTPUSER' => 'SMTP Login név:',
'LBL_MAILMERGE_TEXT' => 'Levél Összefésülés Engedélyezése (A levelek összefésülését ezen kívül a rendszeradminisztrátornak is engedélyeznie kell a Beállítások részben.)',
'LBL_MAILMERGE' => 'Levél Összefésülés:',
'LBL_MAX_TAB' => 'Kijelzett fülek száma:',
'LBL_MAX_TAB_DESCRIPTION' => 'Number of tabs shown at the top of the page before an overflow menu appears.',
'LBL_MAX_SUBTAB' => 'Number of subtabs',
'LBL_MAX_SUBTAB_DESCRIPTION' => 'Number of subtabs shown per tab before an overflow menu appears.',
'LBL_MESSENGER_ID' => 'IM Név:',
'LBL_MESSENGER_TYPE' => 'IM Típus:',
'LBL_MOBILE_PHONE' => 'Mobil:',
	'LBL_MODIFIED_BY'                  =>'Modified By',
'LBL_MODIFIED_BY_ID' => 'Modified By ID',
'LBL_MODULE_NAME' => 'Felhasználók',
'LBL_MODULE_TITLE' => 'Felhasználók: Home',
'LBL_NAME' => 'Név:',
'LBL_NAVIGATION_PARADIGM' => 'Navigation Paradigm',
'LBL_NAVIGATION_PARADIGM_DESCRIPTION' => 'Use grouped tabs instead of module tabs.',
'LBL_NEW_FORM_TITLE' => 'Új Felhasználó',
'LBL_NEW_PASSWORD' => 'Új Jelszó:',
'LBL_NEW_PASSWORD1' => 'Jelszó',
'LBL_NEW_PASSWORD2' => 'Jelszó megerősítése',
'LBL_NEW_USER_BUTTON_KEY' => 'N',
'LBL_NEW_USER_BUTTON_LABEL' => 'Új felhasználó',
'LBL_NEW_USER_BUTTON_TITLE' => 'Új felhasználó [Alt+N]',
	'LBL_NORMAL_LOGIN'					=> 'Switch to Normal View',
'LBL_NOTES' => 'Feljegyzések:',
'LBL_OFFICE_PHONE' => 'Irodai Telefon:',
'LBL_OLD_PASSWORD' => 'Régi Jelszó:',
'LBL_OTHER_EMAIL' => 'Egyéb Email:',
'LBL_OTHER_PHONE' => 'Egyéb Telefon:',
'LBL_OTHER' => 'Egyéb:',
'LBL_PASSWORD' => 'Jelszó:',
'LBL_PHONE' => 'Telefon:',
'LBL_PICK_TZ_WELCOME' => 'Köszöntjük a SUGAR rendszerben',
'LBL_PICK_TZ_DESCRIPTION' => 'Kérem adja meg az időzónáját. Ezt az üzenetablakot csak egyszer fogja látni. Később az időzónát a "Saját fiók" beállításaiban módosíthatja.',
'LBL_PORTAL_ONLY_TEXT' => 'Portál felhasználó. Ez a felhasználó nem tud bejelentkezni a Sugar Suite web felületen keresztül. Csak a portál web szolgáltatásokat használhatja. A normál felhasználókat nem lehet használni a portál web szolgáltatásokhoz.',
'LBL_PORTAL_ONLY' => 'Portál-Only Felhasználó:',
'LBL_POSTAL_CODE' => 'Irányítószám:',
'LBL_PRIMARY_ADDRESS' => 'Elsődleges cím:',
'LBL_PROMPT_TIMEZONE_TEXT' => 'Ha ezt bejelöli, akkor a rendszer rákérdez a felhasználó időzónájára az első bejelentkezéskor.',
'LBL_PROMPT_TIMEZONE' => 'Rákérdezés időzónára:',
'LBL_PUBLISH_KEY' => 'Kulcs publikálása:',
'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'E-mail értesítő küldése amikor Önhöz rendelnek egy rekordot.',
'LBL_RECEIVE_NOTIFICATIONS' => 'Hozzárendelési értesítés:',
	'LBL_REGISTER'                      => 'New user? Please register',
'LBL_REMINDER_TEXT' => 'Alapértelmezett idő egy közelgő hívásra vagy találkozóra való emlékeztetéséhez',
'LBL_REMINDER' => 'Alapértelmezett emlékeztető:',
'LBL_REMOVED_TABS' => 'Admin Eltávolított Fülek',
'LBL_REPORTS_TO_NAME' => 'Jelentést tesz:',
'LBL_REPORTS_TO' => 'Jelentést tesz:',
'LBL_REPORTS_TO_ID' => 'Reports to ID:',
	'LBL_RESET_TO_DEFAULT'				=> 'Reset to Default',
'LBL_RESET_PREFERENCES' => 'Alapértelmezett beállítások visszaállítása',
'LBL_RESET_PREFERENCES_WARNING' => 'Are you sure you want reset all of your preferences?',
'LBL_RESET_HOMEPAGE' => 'Reset To Default Homepage',
'LBL_RESET_DASHBOARD' => 'Dashboard',
'LBL_RESET_HOMEPAGE_WARNING' => 'Are you sure you want reset your Homepage?',
'LBL_RESET_DASHBOARD_WARNING' => 'Are you sure you want reset your Dashboard?',
	'LBL_SALUTATION'                    => 'Salutation',
'LBL_ROLES_SUBPANEL_TITLE' => 'Szerepkörök',
'LBL_SEARCH_FORM_TITLE' => 'Felhasználó Keresés',
'LBL_SEARCH_URL' => 'Keresési hely:',
'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Ellenőrzött felhasználók kiválasztása',
'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Ellenőrzött felhasználók kiválasztása',
'LBL_SETTINGS_URL_DESC' => 'Használja ezt az URL-t amikor bejelentkezési paramétereket ad meg a Sugar for Microsoft Outlook és a Sugar for Microsoft Word beépülő modulokban.',
'LBL_SETTINGS_URL' => 'URL:',
'LBL_SIGNATURE' => 'Aláírás',
'LBL_SIGNATURE_HTML' => 'HTML aláírás',
'LBL_SIGNATURE_DEFAULT' => 'Használja az Aláírás?',
'LBL_SIGNATURE_PREPEND' => 'Signature above reply?',
'LBL_SIGNATURES' => 'Signatures:',
'LBL_STATE' => 'Állam:',
'LBL_STATUS' => 'Állapot:',
'LBL_SUBPANEL_LINKS' => 'Subpanel Links',
'LBL_SUBPANEL_LINKS_DESCRIPTION' => 'In Detail Views, display a row of Subpanel shortcut links.',
'LBL_SUBPANEL_TABS' => 'Subpanel Tabs',
'LBL_SUBPANEL_TABS_DESCRIPTION' => 'In Detail Views, group Subpanels into tabs and display one tab at a time.',
'LBL_SUGAR_LOGIN' => 'Is Sugar User',
'LBL_SUPPORTED_THEME_ONLY' => 'Only affects themes that support this option.',
'LBL_SWAP_LAST_VIEWED_DESCRIPTION' => 'Display the Last Viewed bar on the side if checked. Otherwise it goes on top.',
'LBL_SWAP_SHORTCUT_DESCRIPTION' => 'Display the Shortcuts bar on top if checked. Otherwise it goes on the side.',
'LBL_SWAP_LAST_VIEWED_POSITION' => 'Last Viewed on side',
'LBL_SWAP_SHORTCUT_POSITION' => 'Shortcuts on top',
'LBL_TAB_TITLE_EMAIL' => 'Email beállítások',
'LBL_TAB_TITLE_USER' => 'Felhasználói beállítások',
'LBL_THEME' => 'Téma:',
'LBL_TIME_FORMAT_TEXT' => 'Időpontok formátumának megadása',
'LBL_TIME_FORMAT' => 'Idő formátum:',
'LBL_TIMEZONE_DST_TEXT' => 'Téli/Nyári időszámítás észlelése',
'LBL_TIMEZONE_DST' => 'Téli/Nyári időszámítás:',
'LBL_TIMEZONE_TEXT' => 'Aktuális időzóna beállítása',
'LBL_TIMEZONE' => 'Időzóna:',
'LBL_TITLE' => 'Titulus:',
'LBL_USE_REAL_NAMES' => 'Show Full Name',
'LBL_USE_REAL_NAMES_DESC' => 'Display an User\'s full name instead of their login name',
'LBL_USER_INFORMATION' => 'Felhasználói Információ',
'LBL_USER_LOCALE' => 'Locale Settings',
'LBL_USER_NAME' => 'Felhasználó név:',
'LBL_USER_SETTINGS' => 'Felhasználói beállítások',
'LBL_USER' => 'Felhasználók:',
'LBL_WORK_PHONE' => 'Munkahelyi Telefon:',
'LBL_YOUR_PUBLISH_URL' => 'Publikálás az én helyemen:',
'LBL_YOUR_QUERY_URL' => 'Az Ön lekérdező URL-je:',
'LNK_NEW_USER' => 'Felhasználó létrehozása',
'LNK_USER_LIST' => 'Felhasználók',
	'LNK_REASSIGN_RECORDS'				=> 'Reassign Records',
    'LBL_PROSPECT_LIST'                 => 'Prospect List',


















































// INBOUND EMAIL STRINGS
'LBL_APPLY_OPTIMUMS' => 'Optimumok alkalmazása',
'LBL_ASSIGN_TO_USER' => 'Felhasználó megadása',
'LBL_BASIC' => 'Inbound Beállítás',
'LBL_CERT_DESC' => 'Kényszerítse a mail szerver Tanúsítványának validálását - ne használd, ha self-signing.',
'LBL_CERT' => 'Tanúsítvány validáslása',
'LBL_FIND_OPTIMUM_KEY' => 'f',
'LBL_FIND_OPTIMUM_MSG' => '<br>Keresd az optimum kapcsolat változóit.',
'LBL_FIND_OPTIMUM_TITLE' => 'Optimum Konfiguráció keresése',
'LBL_FORCE' => 'Negatív kényszerítése',
'LBL_FORCE_DESC' => 'Egyes IMAP/POP3 szerverek speciális switch-ket igényelnek. Ellenőr a kapcsolatot a negatív switch-ek kényszerítése érdekében (pl., /notls)',
'LBL_FOUND_OPTIMUM_MSG' => '<br>Talált optimum beállításokat.	Az alábbi gomb megnyomásával alkalmazza a Mailbox-hoz.',
'LBL_EMAIL_INBOUND_TITLE' => 'Inbound Email Beállítások',
'LBL_EMAIL_OUTBOUND_TITLE' => 'Outbound Email Beállítások',
'LBL_LOGIN' => 'Felhasználó név',
'LBL_MAILBOX_DEFAULT' => 'INBOX',
'LBL_MAILBOX_SSL_DESC' => 'SSL használata a kapcsolathoz. Ha nem működik, ellenőrizze a PHP tartalmazza-e a "--with-imap-ssl" a konfigurációban.',
'LBL_MAILBOX' => 'Monitorozott mappa',
'LBL_MAILBOX_TYPE' => 'Lehetséges akciók',
'LBL_MARK_READ_NO' => 'Email törölése az import után',
'LBL_MARK_READ_YES' => 'Email megőrzése a szerveren import után',
'LBL_MARK_READ_DESC' => 'Importálja és olvasottra állítja a mailket a szerveren; ne töröld.',
'LBL_MARK_READ' => 'Email megőrzése a szerveren',
'LBL_ONLY_SINCE_NO' => 'Nem. Ellenőrizd minden email-nél a szerveren.',
'LBL_ONLY_SINCE_YES' => 'Igen.',
'LBL_ONLY_SINCE_DESC' => 'PHP nem érzékeli az Olvasatlan maile-ket, ha POP3-at használunk.	Ellenőrizze a beállítást, mivel jelentősen befolyásolja a mail szerver teljesítményét.',
'LBL_ONLY_SINCE' => 'Import az utolsó ellenőrzéstől',
'LBL_PORT' => 'Mail szerver port',
'LBL_SERVER_OPTIONS' => 'Összetett beállítások',
'LBL_SERVER_TYPE' => 'Mail szerver protokol',
'LBL_SERVER_URL' => 'Mail szerver címe',
'LBL_SSL' => 'SSL alkalmazása',
'LBL_SSL_DESC' => 'Secure Socket Layer alkalmazása a mail szerver kapcsolathoz.',
'LBL_TEST_BUTTON_KEY' => 't',
'LBL_TEST_BUTTON_TITLE' => 'Teszt [Alt+T]',
'LBL_TEST_SETTINGS' => 'Beállítások tesztelése',
'LBL_TEST_SUCCESSFUL' => 'A kapcsolat sikeresen létrejött.',
'LBL_TLS_DESC' => 'Transport Layer Security alkalmazása a mail szerver kapcsolathoz - csak akkor alkalmazza, ha a szerver támogatja a protocolt.',
'LBL_TLS' => 'TLS alkalmazása',
'LBL_TOGGLE_ADV' => 'Haladok üzemmód',
'LBL_OWN_OPPS' => 'No opportunities',
'LBL_OWN_OPPS_DESC' => 'Set this to true if this user will not be assigned opportunities. You should ignore this flag for users, who are not managers,and, not involved in sales activites. Used by forecasting module.',
// END INBOUND EMAIL STRINGS
'LBL_LDAP_ERROR' => 'LDAP Error: Please contact an Admin',
'LBL_LDAP_EXTENSION_ERROR' => 'LDAP Error: Extensions not loaded',

// PROJECT RESOURCES STRINGS	
	'LBL_USER_HOLIDAY_SUBPANEL_TITLE' => 'User Holidays',
	'LBL_RESOURCE_NAME' => 'Name',
	'LBL_RESOURCE_TYPE' => 'Type',









); // END STRINGS DEFS

?>
