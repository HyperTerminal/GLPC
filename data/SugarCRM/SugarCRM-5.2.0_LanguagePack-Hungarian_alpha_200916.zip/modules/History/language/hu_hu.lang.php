<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * English language file for History
 *
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.54
 *
 * ------------------------------------------------------------------------------
 */
 


$mod_strings = array (
'LBL_MODULE_NAME' => 'Előzmények',
'LBL_MODULE_TITLE' => 'Előzmények: Home',
'LBL_SEARCH_FORM_TITLE' => 'Előzmények keresése',
'LBL_LIST_FORM_TITLE' => 'Előzmények',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_CONTACT' => 'Kapcsolat',
'LBL_LIST_RELATED_TO' => 'Összefüggésben',
'LBL_LIST_DATE' => 'Dátum',
'LBL_LIST_TIME' => 'Kezdési idő',
'LBL_LIST_CLOSE' => 'Bezár',
'LBL_SUBJECT' => 'Tárgy:',
'LBL_STATUS' => '�?llapot:',
'LBL_LOCATION' => 'Helyszín:',
'LBL_DATE_TIME' => 'Kezdési időpont:',
'LBL_DATE' => 'Kezdési dátum:',
'LBL_TIME' => 'Kezdési idő:',
'LBL_DURATION' => 'Hossz:',
'LBL_HOURS_MINS' => '(órák/percek)',
'LBL_CONTACT_NAME' => 'Kapcsolat neve: ',
'LBL_MEETING' => 'Találkozó:',
'LBL_DESCRIPTION_INFORMATION' => 'Leíró jellegű információ',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_COLON' => ':',
'LBL_DEFAULT_STATUS' => 'Tervezett',
'LNK_NEW_CALL' => 'Hívás beütemezése',
'LNK_NEW_MEETING' => 'Találkozó beütemezése',
'LNK_NEW_TASK' => 'Feladat létrehozása',
'LNK_NEW_NOTE' => 'Feljegyzés vagy csatolmány létrehozása',
'LNK_NEW_EMAIL' => 'Email Archiválása',
'LNK_CALL_LIST' => 'Hívások',
'LNK_MEETING_LIST' => 'Találkozók',
'LNK_TASK_LIST' => 'Feladatok',
'LNK_NOTE_LIST' => 'Feljegyzések',
'LNK_EMAIL_LIST' => 'Email-ek',
'ERR_DELETE_RECORD' => 'A cég törléséhez meg kell adni egy rekord azonosítót.',
'NTC_REMOVE_INVITEE' => 'Biztos benne, hogy eltávolítja ezt a meghívottat a találkozóból?',
'LBL_INVITEE' => 'Meghívottak',
'LBL_LIST_DIRECTION' => 'Irány',
'LBL_DIRECTION' => 'Irány',
'LNK_NEW_APPOINTMENT' => 'Új megbeszélés',
'LNK_VIEW_CALENDAR' => 'Ma',
'LBL_OPEN_ACTIVITIES' => 'Nyitott tevékenységek',
'LBL_HISTORY' => 'Előzmények',
'LBL_UPCOMING' => 'Közeli megbeszélések',
'LBL_TODAY' => 'through ',
'LBL_NEW_TASK_BUTTON_TITLE' => 'Feladat létrehozása [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY' => 'N',
'LBL_NEW_TASK_BUTTON_LABEL' => 'Feladat létrehozása',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Találkozó beütemezése [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Találkozó beütemezése',
'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Hívás beütemezése [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Hívás beütemezése',
'LBL_NEW_NOTE_BUTTON_TITLE' => 'Feljegyzés vagy csatolmány létrehozása [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
'LBL_NEW_NOTE_BUTTON_LABEL' => 'Feljegyzés vagy csatolmány létrehozása',
'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Email archiválása [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Email archiválása',
'LBL_LIST_STATUS' => '�?llapot',
'LBL_LIST_DUE_DATE' => 'Határidő',
'LBL_LIST_LAST_MODIFIED' => 'Utoljára módosítva',
'NTC_NONE_SCHEDULED' => 'Nincs ütemezve.',
'appointment_filter_dom' => array (
'today' => 'ma',
  	'tomorrow' => 'tomorrow'
  	,'this Saturday' => 'this week'
  	,'next Saturday' => 'next week'
  	,'last this_month' => 'this month'
  	,'last next_month' => 'next month'
  ),
'LNK_IMPORT_NOTES' => 'Feljegyzések importálása',
'NTC_NONE' => 'Nincs',
'LBL_ACCEPT_THIS' => 'Elfogadja?',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Előzmények',
);

?>
