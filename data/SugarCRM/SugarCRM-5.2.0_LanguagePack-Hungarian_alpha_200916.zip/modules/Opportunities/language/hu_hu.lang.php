<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.56
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Lehetőségek',
'LBL_MODULE_TITLE' => 'Lehetőségek: Home',
'LBL_SEARCH_FORM_TITLE' => 'Lehetőségek keresése',
'LBL_VIEW_FORM_TITLE' => 'Lehetőségek Nézet',
'LBL_LIST_FORM_TITLE' => 'Lehetőségek listázás',
'LBL_OPPORTUNITY_NAME' => 'Lehetőség neve:',
'LBL_OPPORTUNITY' => 'Lehetőség:',
'LBL_NAME' => 'Lehetőség neve',
'LBL_INVITEE' => 'Kapcsolatok',
'LBL_LIST_OPPORTUNITY_NAME' => 'Lehetőség',
'LBL_LIST_ACCOUNT_NAME' => 'Cégnév',
'LBL_LIST_AMOUNT' => 'Összeg',
'LBL_LIST_DATE_CLOSED' => 'Bezár',
'LBL_LIST_SALES_STAGE' => 'Eladási fázis',
'LBL_ACCOUNT_ID' => 'Cég ID',
'LBL_CURRENCY_ID' => 'Pénznem ID',
'LBL_CURRENCY_NAME' => 'Currency Name',
'LBL_CURRENCY_SYMBOL' => 'Currency Symbol',



//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
'UPDATE' => 'Lehetőség - Pénznem frissítése',
'UPDATE_DOLLARAMOUNTS' => 'US Dollár összegek frissítése',
'UPDATE_VERIFY' => 'Összegek ellenőrzése',
'UPDATE_VERIFY_TXT' => 'Ellenőrzi, hogy a megadott összeg értékek érvényes decimális számok-e, amik kizárólag számjegyet (0-9) és tizedespontot (.) tartalmaznak.',
'UPDATE_FIX' => 'Összegek javítása',
'UPDATE_FIX_TXT' => 'Megpróbálja megjavítani az érvénytelen összegeket úgy, hogy készít egy érvényes értéket az aktuális összeghez. Ez a művelet elmenti az összes módosított összeget egy adatbázis mezőbe aminek amount_backup a neve. Ha a művelet végrehajtásakor hibákat tapasztal, akkor ne futtassa újra addig, amíg vissza nem állította a mentett értékeket. Ha ezt nem teszi meg, akkor a mentési amount_backup mezőbe új, érvénytelen adatok kerülhetnek.',
'UPDATE_DOLLARAMOUNTS_TXT' => 'Frissíti az US Dollár összegeket az egyes lehetőségekhez, az éppen aktuális átváltási arányok alapján. Ezt a frissített értéket a diagramok létrehozásához használja a rendszer.',
'UPDATE_CREATE_CURRENCY' => 'Új pénznem létrehozása:',
'UPDATE_VERIFY_FAIL' => 'A rekord ellenőrzése sikertelen volt:',
'UPDATE_VERIFY_CURAMOUNT' => 'Aktuális érték:',
'UPDATE_VERIFY_FIX' => 'A javítás futtatása után',
'UPDATE_INCLUDE_CLOSE' => 'Vegye figyelembe a lezárt rekordokat is',
'UPDATE_VERIFY_NEWAMOUNT' => 'Új összeg:',
'UPDATE_VERIFY_NEWCURRENCY' => 'Új pénznem:',
'UPDATE_DONE' => 'Kész',
'UPDATE_BUG_COUNT' => 'Hibák megtalálva, megoldás megpróbálva:',
'UPDATE_BUGFOUND_COUNT' => 'Hibák megtalálva:',
'UPDATE_COUNT' => 'Módosított rekordok:',
'UPDATE_RESTORE_COUNT' => 'Rekord összegek visszaállítva:',
'UPDATE_RESTORE' => 'Összegek visszaállítása',
'UPDATE_RESTORE_TXT' => 'Visszaállítja a javítás során mentett összegeket',
'UPDATE_FAIL' => 'Nem lehetett frissíteni - ',
'UPDATE_NULL_VALUE' => 'Az összeg üres, 0-ra állítva -',
'UPDATE_MERGE' => 'Pénznemek összefésülése',
'UPDATE_MERGE_TXT' => 'Összefésüli a pénznemeket egyetlen pénznemmé. Ha azt veszi észre, hogy több pénznem rekord van ugyan ahhoz a pénznemhez, akkor összefésülheti őket. Ez a művelet összefésüli a más modulokban található pénznemeket is.',
'LBL_ACCOUNT_NAME' => 'Cég név:',
'LBL_AMOUNT' => 'Cég:',
'LBL_AMOUNT_USDOLLAR' => 'Amount USD:',
'LBL_CURRENCY' => 'Pénznem:',
'LBL_DATE_CLOSED' => 'Befejezés várható dátuma:',
'LBL_TYPE' => 'Típus:',
'LBL_CAMPAIGN' => 'Kampány:',
'LBL_NEXT_STEP' => 'Következő lépés:',
'LBL_LEAD_SOURCE' => 'Megkeresés forrás:',
'LBL_SALES_STAGE' => 'Eladási fázis:',
'LBL_PROBABILITY' => 'Valószínűség (%):',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_DUPLICATE' => 'Lehetséges Lehetőség duplikáció',
'MSG_DUPLICATE' => 'A lehetőség létrehozása lehetséges, hogy duplikációt okoz. Kiválaszhat egy lehetőséget az alábbi listából, vagy megnyomhatja a "Lehetőség létrehozása" gombot, hogy létrehozza a lehetőséges a korábban megadott adatokkal.',
'LBL_NEW_FORM_TITLE' => 'Lehetőség létrehozása',
'LNK_NEW_OPPORTUNITY' => 'Lehetőség létrehozása',



'LNK_OPPORTUNITY_LIST' => 'Lehetőségek',
'ERR_DELETE_RECORD' => 'A lehetőség törléséhez meg kell adnia egy rekordsorszámot.',
'LBL_TOP_OPPORTUNITIES' => 'Legjobb lehetőségeim',
'NTC_REMOVE_OPP_CONFIRMATION' => 'Biztos benne, hogy eltávolítja ezt a kapcsolatot a lehetőségből?',
'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Biztos benne, hogy eltávolítja ezt a lehetőséget a projekből?',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Lehetőségek',
'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Tevékenységek',
'LBL_HISTORY_SUBPANEL_TITLE' => 'Előzmények',
'LBL_RAW_AMOUNT' => 'Nyers összeg',
	
'LBL_LEADS_SUBPANEL_TITLE' => 'Megkeresések',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kapcsolatok',



'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projektek',
'LBL_ASSIGNED_TO_NAME' => 'Felelős:',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',




'LBL_LIST_SALES_STAGE' => 'Eladási fázis',
'LBL_MY_CLOSED_OPPORTUNITIES' => 'My Closed Opportunities',
'LBL_TOTAL_OPPORTUNITIES' => 'Total Opportunities',
'LBL_CLOSED_WON_OPPORTUNITIES' => 'Closed Won Opportunities',
'LBL_ASSIGNED_TO_ID' => 'Assigned to ID',
'LBL_CREATED_ID' => 'Created by ID',
'LBL_MODIFIED_ID' => 'Modified by ID',
'LBL_MODIFIED_NAME' => 'Modified by User Name',
'LBL_CREATED_USER' => 'Created User',
'LBL_MODIFIED_USER' => 'Modified User',
	
);

?>
