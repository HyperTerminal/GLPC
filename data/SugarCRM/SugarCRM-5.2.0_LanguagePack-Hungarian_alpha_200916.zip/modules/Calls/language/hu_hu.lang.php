<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.50
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_BLANK'	=> ' ',

'LBL_MODULE_NAME' => 'Hívások',
'LBL_MODULE_TITLE' => 'Hívások: Home',
'LBL_SEARCH_FORM_TITLE' => 'Hívások keresése',
'LBL_LIST_FORM_TITLE' => 'Híváslista',
'LBL_NEW_FORM_TITLE' => 'Hívások ütemezése',
'LBL_LIST_CLOSE' => 'Bezár',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_CONTACT' => 'Kapcsolat',
'LBL_LIST_RELATED_TO' => 'Összefüggésben ',
'LBL_LIST_RELATED_TO_ID' => 'Related to ID',
'LBL_LIST_DATE' => 'Kezdés dátuma',
'LBL_LIST_TIME' => 'Kezdés ideje',
'LBL_LIST_DURATION' => 'Hossza',
'LBL_LIST_DIRECTION' => 'Iránya',
'LBL_SUBJECT' => 'Tárgy:',
'LBL_REMINDER' => 'Emlékeztető:',
'LBL_CONTACT_NAME' => 'Kapcsolat:',
'LBL_DESCRIPTION_INFORMATION' => 'Leírás',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_STATUS' => 'Állapot:',
'LBL_DIRECTION' => 'Irány:',
'LBL_DATE' => 'Kezdés dátuma:',
'LBL_DURATION' => 'Hossza:',
'LBL_DURATION_HOURS' => 'Hossza órák:',
'LBL_DURATION_MINUTES' => 'Hossza percek:',
'LBL_HOURS_MINUTES' => '(órák/percek)',
'LBL_CALL' => 'Hívás:',
'LBL_DATE_TIME' => 'Kezdési dátum és idő:',
'LBL_TIME' => 'Kezdés ideje:',
'LBL_HOURS_ABBREV' => 'ó',
'LBL_MINSS_ABBREV' => 'p',
'LBL_COLON' => ':',
'LBL_DEFAULT_STATUS' => 'Tervezett',
'LNK_NEW_CALL' => 'Hívások ütemezése',
'LNK_NEW_MEETING' => 'Találkozók ütemezése',
'LNK_NEW_TASK' => 'Feladat létrehozása',
'LNK_NEW_NOTE' => 'Feljegyzés létrehozása',
'LNK_NEW_EMAIL' => 'Email Archiválása',
'LNK_CALL_LIST' => 'Hívások',
'LNK_MEETING_LIST' => 'Találkozók',
'LNK_TASK_LIST' => 'Feladatok',
'LNK_NOTE_LIST' => 'Feljegyzések',
'LNK_EMAIL_LIST' => 'Email-ek',
'LNK_VIEW_CALENDAR' => 'Ma',
'ERR_DELETE_RECORD' => 'A cég törléséhez meg kell adnia a rekordszámot.',
'NTC_REMOVE_INVITEE' => 'Biztos benne, hogy kitörli ezt a meghívottat a hívásból?',
'LBL_INVITEE' => 'Meghívottak',
'LBL_RELATED_TO' => 'Kapcsolódó:',
'LNK_NEW_APPOINTMENT' => 'Megbeszélés létrehozása',
'LBL_SCHEDULING_FORM_TITLE' => 'Ütemezés',
'LBL_ADD_INVITEE' => 'Meghívottak hozzáadása',
'LBL_NAME' => 'Név',
'LBL_FIRST_NAME' => 'Keresztnév',
'LBL_LAST_NAME' => 'Vezetéknév',
'LBL_EMAIL' => 'Email',
'LBL_PHONE' => 'Telefon',
'LBL_REMINDER' => 'Emlékeztető:',
'LBL_SEND_BUTTON_TITLE' => 'Meghívók küldése [Alt+I]',
'LBL_SEND_BUTTON_KEY' => 'I',
'LBL_SEND_BUTTON_LABEL' => 'Meghívók küldése',
'LBL_DATE_END' => 'Befejezés dátuma',
'LBL_TIME_END' => 'Befejezés ideje',
'LBL_REMINDER_TIME' => 'Emlékeztetés ideje',
'LBL_SEARCH_BUTTON' => 'Keresés',
'LBL_ADD_BUTTON' => 'Hozzáadás',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Hívások',
'LBL_LOG_CALL' => 'Hívás naplózása',
'LNK_SELECT_ACCOUNT' => 'Cég választása',
'LNK_NEW_ACCOUNT' => 'Új cég',
'LNK_NEW_OPPORTUNITY' => 'Új lehetőség',
'LBL_DEL' => 'Törlés',
'LBL_LEADS_SUBPANEL_TITLE' => 'Leads',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kapcsolatok',
'LBL_USERS_SUBPANEL_TITLE' => 'Felhasználók',
'LBL_OUTLOOK_ID' => 'Outlook ID',
'LBL_MEMBER_OF' => 'Tagság',
'LBL_HISTORY_SUBPANEL_TITLE' => 'Feljegyzések',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',
'LBL_LIST_MY_CALLS' => 'Hívásaim',
'LBL_SELECT_FROM_DROPDOWN' => 'Kérem válasszon a \"Kapcsolódó\" lenyíló listából.',
	'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
	'LBL_ASSIGNED_TO_ID' => 'Assigned User',
'NOTICE_DURATION_TIME' => 'Duration time must be greater than 0',
    'LBL_ASSIGNED_TO' => 'Assigned to:',
    'LBL_PARENT_TYPE' => 'Parent Type',
   );


?>
