<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.56
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Rekordok Egyesítése',
'LBL_MODULE_TITLE' => 'Rekordok Egyesítése: Home',
'LBL_SEARCH_FORM_TITLE' => 'Egyesítés Keresés',
'LBL_LIST_FORM_TITLE' => 'Egyesítés Lista',

'LBL_LBL_MERGE_RECORDS_STEP_1' => 'Step 1: Find Search Records to Merge With',
'LBL_AVAIL_FIELDS' => 'Elérhető Mezők',
'LBL_FILTER_COND' => 'Filter Condition',
'LBL_SELECTED_FIELDS' => 'Kiválasztott Mezők',
'LBL_MERGE_RECORDS_WITH' => 'Rekordok Egyesítése',
'LBL_MERGE_VALUE_OVER' => 'Merge value over',

'LBL_NEXT_STEP_TITLE' => 'Ugrás a Következő Lépésre[Ctrl+N]',
'LBL_NEXT_STEP_BUTTON_KEY' => 'N',
'LBL_NEXT_STEP_BUTTON_LABEL' => 'Következő Lépés >',

'LBL_PERFORM_MERGE_BUTTON_TITLE' => 'Egyesítés Végrahajtása[Ctrl+P]',
'LBL_PERFORM_MERGE_BUTTON_KEY' => 'P',
'LBL_PERFORM_MERGE_BUTTON_LABEL' => 'Egyesítés Végrahajtása',

'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE' => 'Egyesítés Mentése[Ctrl+S]',
'LBL_SAVE_MERGED_RECORD_BUTTON_KEY' => 'S',
'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL' => 'Egyesítés Mentése',

'LBL_STEP2_FORM_TITLE' => 'Records Found To Merge With:',
'LBL_SELECT_ERROR' => 'A folytatáshoz választania kell.',
'LBL_SELECT_PRIMARY' => 'Válasszon elsődleges rekordot az egyesítéshez.',
'LBL_CHANGE_PARENT' => 'Elsődlegesnek jelöl',
'LBL_REMOVE_FROM_MERGE' => 'Eltávolítás',
'LBL_DIFF_COL_VALUES' => 'Azon oszlopok, melyek értéke nem egyezik meg az elsődleges és az egyesítendő sorokban:',
'LBL_SAME_COL_VALUES' => 'Azon oszlopok, melyek értéke hasonló minden sorban.',
'ERR_EXCEEDS_MAX' => 'You are only allowed to merge a maximum of 5 records. Records exceeding the limit were ignored.',
'LBL_DELETE_MESSAGE' => 'Ez a tevékenység törli a következő rekordo(ka)t:',
'LBL_PROCEED' => 'Folytatja?',
);


?>
