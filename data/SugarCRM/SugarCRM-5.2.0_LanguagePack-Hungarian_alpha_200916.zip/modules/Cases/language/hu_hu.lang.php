<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.51
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'ERR_DELETE_RECORD' => 'A cég törléséhez meg kell adni a rekordszámot.',

'LBL_ACCOUNT_ID' => 'Ügyfélszám',
'LBL_ACCOUNT_NAME' => 'Cégnév:',
	'LBL_ACCOUNTS_SUBPANEL_TITLE'		=> 'Accounts',
'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Tevékenységek',
	'LBL_ATTACH_NOTE' 					=> 'Attach Note',
'LBL_BUGS_SUBPANEL_TITLE' => 'Hibák',
'LBL_CASE_NUMBER' => 'Esetszám:',
'LBL_CASE_SUBJECT' => 'Eset tárgya:',
'LBL_CASE' => 'Eset:',
'LBL_CONTACT_CASE_TITLE' => 'Kapcsolat-Eset:',
'LBL_CONTACT_NAME' => 'Kapcsolat neve:',
'LBL_CONTACT_ROLE' => 'Szerepkör:',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kapcsolatok',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Esetek',
'LBL_DESCRIPTION' => 'Leírás:',
	'LBL_FILENANE_ATTACHMENT' 			=> 'File Attachment',	
'LBL_HISTORY_SUBPANEL_TITLE' => 'Előzmények',
'LBL_INVITEE' => 'Kapcsoaltok',
'LBL_MEMBER_OF' => 'Cég',
'LBL_MODULE_NAME' => 'Esetek',
'LBL_MODULE_TITLE' => 'Esetek: Home',
'LBL_NEW_FORM_TITLE' => 'Új eset',
'LBL_NUMBER' => 'Szám:',
'LBL_PRIORITY' => 'Prioritás:',
	'LBL_PROJECTS_SUBPANEL_TITLE' 		=> 'Projects',
'LBL_RESOLUTION' => 'Megoldás:',
'LBL_SEARCH_FORM_TITLE' => 'Esetek Keresése',
'LBL_STATUS' => 'Állapot:',
'LBL_SUBJECT' => 'Tárgy:',
'LBL_SYSTEM_ID' => 'Azonosító',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',
'LBL_LIST_ACCOUNT_NAME' => 'Cég neve',
'LBL_LIST_ASSIGNED' => 'Felelős',
'LBL_LIST_CLOSE' => 'Bezár',
'LBL_LIST_FORM_TITLE' => 'Esetlista',
'LBL_LIST_LAST_MODIFIED' => 'Utoljára módosítva',
'LBL_LIST_MY_CASES' => 'Nyitott eseteim',
'LBL_LIST_NUMBER' => 'Num.',
'LBL_LIST_PRIORITY' => 'Prioritás',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',

'LNK_CASE_LIST' => 'Esetek',
'LNK_NEW_CASE' => 'Eset létrehozása',
'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Biztos benne, hogy el akarja távolítani ezt az esetet a hibából?',
'NTC_REMOVE_INVITEE' => 'Biztos benne, hogy eltávolítja ezt a kapcsolatot az esetből?',
'LBL_LIST_DATE_CREATED' => 'Létrehozás dátuma',
	'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
	'LBL_TYPE'=>'Type',
	'LBL_WORK_LOG'=>'Work Log',







'LBL_CREATED_USER' => 'Created User',
'LBL_MODIFIED_USER' => 'Modified User',
);


?>
