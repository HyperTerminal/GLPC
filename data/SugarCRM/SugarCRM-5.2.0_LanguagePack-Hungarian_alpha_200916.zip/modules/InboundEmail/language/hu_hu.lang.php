<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.55
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  TODO: To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array(



	'LBL_RE'					=> 'RE:',

'ERR_BAD_LOGIN_PASSWORD' => 'Felhasználónév, vagy a jelszó incorrekt',
'ERR_BODY_TOO_LONG' => 'rBody text too long to capture FULL email. Trimmed.',
'ERR_INI_ZLIB' => 'Could not turn off Zlib compression temporarily. "Test Settings" may fail.',
'ERR_MAILBOX_FAIL' => 'Nem találtam egyetlen postafiókot sem.',
'ERR_NO_IMAP' => 'Nem talál IMAP könyvtárat. Javítandó, mielőtt tovább folytatja a munkát',
'ERR_NO_OPTS_SAVED' => 'Az InboundEmail mailbox beállítása hiányzik.  Ellenőrízze a beállításokat.',
'ERR_TEST_MAILBOX' => 'Kérem ellenőrizze a beállításokat és próbálja újra.',

'LBL_APPLY_OPTIMUMS' => 'Optimumok alkalmazása',
'LBL_ASSIGN_TO_USER' => 'Felhasználó beállítása',
'LBL_AUTOREPLY_OPTIONS' => 'Autmatikus válasz beállításai',
'LBL_AUTOREPLY' => 'Automatikus válasz sablon',
'LBL_BASIC' => 'Alapvető beállítások',
'LBL_CASE_MACRO' => 'Eset Makró',
'LBL_CASE_MACRO_DESC' => 'Set the macro which will be parsed and used to link imported email to a Case.',
'LBL_CASE_MACRO_DESC2' => 'Set this to any value, but preserve the "%1".',
'LBL_CERT_DESC' => 'Kikényszeríti a szerver biztonsági tanúsítványának ellenőrzését Security Certificate - ne használja, ha levelező szerver tanúsítványa nem megbízható (pl. self-signed).',
'LBL_CERT' => 'Tanúsítvány ellenőrzése',
'LBL_CLOSE_POPUP' => 'Ablak bezárása',
'LBL_CREATE_NEW_GROUP' => '--Postaláda csoport létrehozása mentéskor--',
'LBL_CREATE_TEMPLATE' => 'Létrehoz',
	'LBL_SUBSCRIBE_FOLDERS'	=> 'Subscribe Folders',
'LBL_DEFAULT_FROM_ADDR' => 'Alapértelmezett: ',
'LBL_DEFAULT_FROM_NAME' => 'Alapértelmezett: ',
'LBL_DELETE_SEEN' => 'Olvasott email-ek törlése importálás után',
'LBL_EDIT_TEMPLATE' => 'Szerkeszt',
'LBL_EMAIL_OPTIONS' => 'Email Kezelési Beállítások',
'LBL_FILTER_DOMAIN_DESC' => 'Ne küldj Auto-replies erre a domain-re.',
	'LBL_ASSIGN_TO_GROUP_FOLDER_DESC'=> 'Assigning a mail account to a group folder enables automatic import of the emails.',
	'LBL_POSSIBLE_ACTION_DESC'		=> 'For the Create Case option, a Group Folder must be selected',
'LBL_FILTER_DOMAIN' => 'Nem küld Auto-reply-t a domain-re',
'LBL_FIND_OPTIMUM_KEY' => 'f',
'LBL_FIND_OPTIMUM_MSG' => '<br>Finding optimum connection variables.',
'LBL_FIND_OPTIMUM_TITLE' => 'Keress Optimum Configurációt',
'LBL_FIND_SSL_WARN' => '<br>Az SSL ellenőrzése hosszabb időt vehet igénybe.<br>',
'LBL_FORCE_DESC' => 'Egyes IMAP/POP3 szerverek speciális kapcsolást igényelnek. Ellenőrízze az ellentétes kapcsoló kényszerítését a kapcsolódáskor (pl., /notls)',
'LBL_FORCE' => 'Negatív Kényszerítése',
'LBL_FOUND_MAILBOXES' => 'A következő postafiókokat találtam:',
'LBL_FOUND_OPTIMUM_MSG' => '<br>Találtunk optimum beállításokat.  Nyomja meg az alábbi gombot, ha alkalmazza a Mailbox-hoz.',
'LBL_FROM_ADDR' => '"From" cím',
'LBL_FROM_NAME_ADDR' => 'Válasz Név/Email:',
'LBL_FROM_NAME' => '"From" név',
'LBL_GROUP_QUEUE' => 'Hozzárendelés csoporthoz',
'LBL_HOME' => 'Home',
'LBL_LIST_MAILBOX_TYPE' => 'Postaláda Használat',
'LBL_LIST_NAME' => 'Név:',
	'LBL_LIST_GLOBAL_PERSONAL'			=> 'Group/Personal',
'LBL_LIST_SERVER_URL' => 'Mail Szerver:',
'LBL_LIST_STATUS' => 'Állapot:',
'LBL_LOGIN' => 'Bejelentkezési név',
'LBL_MAILBOX_DEFAULT' => 'INBOX',
'LBL_MAILBOX_SSL_DESC' => 'SSL használata a kapcsolódáshoz. Ha ez nem működik, akkor ellenőrizze hogy az ön PHP fordításakor meg lett-e adva a "--with-imap-ssl".',
'LBL_MAILBOX_SSL' => 'SSL használata',
'LBL_MAILBOX_TYPE' => 'Lehetséges műveletek',
	'LBL_DISTRIBUTION_METHOD' => 'Distribution Method',
	'LBL_CREATE_CASE_REPLY_TEMPLATE' => 'Create Case Reply Template',
'LBL_MAILBOX' => 'Monitorozott mappa',
	'LBL_TRASH_FOLDER'		=> 'Trash Folder',
	'LBL_GET_TRASH_FOLDER'	=> 'Get Trash Folder',
	'LBL_SENT_FOLDER'		=> 'Sent Folder',
	'LBL_GET_SENT_FOLDER'	=> 'Get Sent Folder',
	'LBL_SELECT'				=> 'Select',
'LBL_MARK_READ_DESC' => 'Az importálás során jelölje olvasottnak a leveleket, de ne törölje őket.',
'LBL_MARK_READ_NO' => 'Importálás után a levelek törölnek lesznek jelölve.',
'LBL_MARK_READ_YES' => 'Importálás után a levelek a szerveren maradnak.',
'LBL_MARK_READ' => 'Hagyja az üzeneteket a szerveren',
	'LBL_MAX_AUTO_REPLIES'	=> 'Number of Auto-responses',
	'LBL_MAX_AUTO_REPLIES_DESC'	=> 'Set the maximum number of auto-responses to send to a unique email address during a period of 24 hours.',
'LBL_MODULE_NAME' => 'Bejövő Email Beállítása',
'LBL_MODULE_TITLE' => 'Inbound Email',
'LBL_NAME' => 'Név',
'LBL_NONE' => 'None',
'LBL_NO_OPTIMUMS' => 'Nem talált optimumot.  Ellenőrízze a beállításokat és próbálja újra.',
'LBL_ONLY_SINCE_DESC' => 'POP3 használata esetén a PHP nem tudja megszűrni az új/olvasatlan leveleket. Ez a beállítás lehetővé teszi olyan kérelmek elküldését, amelyek csak azokat a leveleket adják vissza, amik az utolsó ellenőrzés óta érkeztek. Így jelentősen növelhető a teljesítmény akkor is, ha a levelező szerver nem támogatja az IMAP protokolt.',
'LBL_ONLY_SINCE_NO' => 'Nem. A levelező szerver minden email-jének ellenőrzése.',
'LBL_ONLY_SINCE_YES' => 'Igen.',
'LBL_ONLY_SINCE' => 'Importálás csak az utolsó ellnőrzéstől:',
	'LBL_OUTBOUND_SERVER'	=> 'Outgoing Mail Server',
'LBL_PASSWORD_CHECK' => 'Jelszó ellenőrzés',
'LBL_PASSWORD' => 'Jelszó',
'LBL_POP3_SUCCESS' => 'A POP3 teszt kapcsolat sikeres volt.',
'LBL_POPUP_FAILURE' => 'A kapcsolódás sikertelen volt. A hiba leírása alább található.',
'LBL_POPUP_SUCCESS' => 'A kapcsolódás sikeres volt. Az ön beállításai működnek.',
'LBL_POPUP_TITLE' => 'Beállítások tesztelése',
	'LBL_GETTING_FOLDERS_LIST' 		=> 'Getting Folders List',
	'LBL_SELECT_SUBSCRIBED_FOLDERS' 		=> 'Select Subscribed Folder(s)',
	'LBL_SELECT_TRASH_FOLDERS' 		=> 'Select Trash Folder',
	'LBL_SELECT_SENT_FOLDERS' 		=> 'Select Sent Folder',
	'LBL_DELETED_FOLDERS_LIST' 		=> 'The following folder(s) %s either does not exist or has been deleted from server',
'LBL_PORT' => 'Mail Szerver Port',
'LBL_QUEUE' => 'Postaláda sor',
	'LBL_REPLY_NAME_ADDR'	=> 'Reply Name/Email',
	'LBL_REPLY_TO_NAME'		=> '"Reply-to" Name',
	'LBL_REPLY_TO_ADDR'		=> '"Reply-to" Address',
	'LBL_SAME_AS_ABOVE'		=> 'Using From Name/Address',
'LBL_SAVE_RAW' => 'Nyers forrás mentése',
'LBL_SAVE_RAW_DESC_1' => 'Válassza az \"Igen\"-t, ha szeretné megtartani a nyers forrást minden importált email-hez',
'LBL_SAVE_RAW_DESC_2' => 'Nagy csatolt fájlok problémát okozhatnak a pontatlanul beállított adatbázisokban.',
'LBL_SERVER_OPTIONS' => 'Mail Szerver Beállítások',
'LBL_SERVER_TYPE' => 'Mail Szerver Protokol',
'LBL_SERVER_URL' => 'Bejövő Mail Szerver',
'LBL_SSL_DESC' => 'Ha a mail szerver támogatja a secure socket kapcsolódást, engedélyezze, hogy az SSL kapcsolódást használja az email-k importálásakor.',
	'LBL_ASSIGN_TO_TEAM_DESC' => 'The selected team has access to the mail account. If a Group Folder is selected, the team assigned to the Group Folder overrides the selected team.',
'LBL_SSL' => 'SSL beállítása',
'LBL_STATUS' => 'Állapot',
'LBL_SYSTEM_DEFAULT' => 'Rendszer alapértelmezett',
'LBL_TEST_BUTTON_KEY' => 't',
'LBL_TEST_BUTTON_TITLE' => 'Teszt [Alt+T]',
'LBL_TEST_SETTINGS' => 'Beállítások tesztlése',
'LBL_TEST_SUCCESSFUL' => 'A kapcsolat sikeresen létrejött.',
'LBL_TEST_WAIT_MESSAGE' => 'Kérem várjon...',
'LBL_TLS_DESC' => 'Transport Layer Security használata a kapcsolódáshoz. Csak akkor használja, ha a levelező szervere támogatja ezt a protokolt.',
'LBL_TLS' => 'TLS használata',
'LBL_WARN_IMAP_TITLE' => 'IMAP figyelmeztetés',
'LBL_WARN_IMAP' => 'Figyelmeztetések:',
'LBL_WARN_NO_IMAP' => 'Ezen a rendszeren az IMAP c-client könyvtárak nem elérhetők, vagy nincsenek befordítva egy PHP modulba (--with-imap=/path/to/imap_c-client-library). A probléma megoldásához kérem vegye föl a kapcsolatot a rendszergazdával.',

'LNK_CREATE_GROUP' => 'Új csoport létrehozása',
'LNK_LIST_CREATE_NEW' => 'Új postaláda monitorozása',
'LNK_LIST_MAILBOXES' => 'Minden postaláda',
'LNK_LIST_QUEUES' => 'Összes sor',
'LNK_LIST_SCHEDULER' => 'Ütemezők',
'LNK_LIST_TEST_IMPORT' => 'Teszt Email Import',
'LNK_NEW_QUEUES' => 'Új sor létrehozása',
'LNK_SEED_QUEUES' => 'Sorok beültetése a csapatokból',
'LBL_IS_PERSONAL' => 'personal',
	'LBL_GROUPFOLDER_ID'	=> 'Group Folder Id',
	'LBL_ASSIGN_TO_GROUP_FOLDER' => 'Assign To Group Folder',

'LBL_STATUS_ACTIVE' => 'Active',
'LBL_STATUS_INACTIVE' => 'Inactive',
'LBL_IS_PERSONAL' => 'personal',
'LBL_IS_GROUP' => 'group',
);

?>
