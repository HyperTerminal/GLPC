<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.51
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	/*'ADMIN_EXPORT_ONLY'=>'Admin export only',*/
'ADVANCED' => 'Haladóknak',
	'CAPTCHA'=>'Captcha Validation',
	'CAPTCHA_PRIVATE_KEY'=>'Captcha private Key',
	'CAPTCHA_PUBLIC_KEY'=>'Captcha public Key',
'CURRENT_LOGO' => 'Aktuálisan használt logo',
'DEFAULT_CURRENCY_ISO4217' => 'ISO 4217 devizanemkód',
'DEFAULT_CURRENCY_NAME' => 'Devizanem neve',
'DEFAULT_CURRENCY_SYMBOL' => 'Devizanem szimbólum',
'DEFAULT_CURRENCY' => 'Default devizanem',
'DEFAULT_DATE_FORMAT' => 'Dátum formátum',
'DEFAULT_DECIMAL_SEP' => 'Tizedesjel',
'DEFAULT_LANGUAGE' => 'Default nyelvbeállítás',
'DEFAULT_NUMBER_GROUPING_SEP' => '1000s elválasztó',
'DEFAULT_SYSTEM_SETTINGS' => 'Felhasználói interfész',
'DEFAULT_THEME' => 'Default theme',
'DEFAULT_TIME_FORMAT' => 'Idő formátum',
/*	'DISABLE_EXPORT'=>'Disable export',*/
'DISPLAY_LOGIN_NAV' => 'A fületek megjelenése a bejelentkezési oldalon',
'DISPLAY_RESPONSE_TIME' => 'A szerver responce time megjelenítése',
	'ENABLE_CAPTCHA'=>'Enable Captcha validations to prevent automated form submissions?',
	/*'EXPORT'=>'Export',
'EXPORT_CHARSET' => 'Alapértelmezett Export Karakterkészlet',
'EXPORT_DELIMITER' => 'Export határolójel', */
'IMAGES' => 'Logok',
'LBL_CONFIGURE_SETTINGS_TITLE' => 'Rendszer beállítások',
'LBL_ENABLE_MAILMERGE' => 'Engedélyezi a mail merge-t?',
'LBL_LOGVIEW' => 'Log beállítások konfigurálása',
'LBL_MAIL_SMTPAUTH_REQ' => 'Engedélyezi az SMTP jogosúltság-ellenőrzést?',
'LBL_MAIL_SMTPPASS' => 'SMTP jelszó:',
'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
'LBL_MAIL_SMTPSERVER' => 'SMTP Szerver:',
'LBL_MAIL_SMTPUSER' => 'SMTP felhasználó:',
'LBL_MAILMERGE_DESC' => 'Ezt a kapcsolót csak akkor kell ellenőrizni, ha a Microsoft&reg; Word&reg; Plug-in-t használjuk.',
'LBL_MAILMERGE' => 'Mail Merge',
'LBL_MODULE_NAME' => 'Rendszer beállítások',
'LBL_MODULE_ID' => 'Configurator',
'LBL_MODULE_TITLE' => 'Felhasználói interfész',
'LBL_NOTIFY_FROMADDRESS' => '"From" email-cím:',
'LBL_NOTIFY_SUBJECT' => 'Email tárgya:',
'LBL_PORTAL_ON_DESC' => 'Megengedi az Estek, Jegyzetek és egyéb a külső ügyfelekhez köthető adatok "self-service portal" portál használatát.',
'LBL_PORTAL_ON' => 'Self-service portal integrálás engedélyezése?',
'LBL_PORTAL_TITLE' => 'Customer Self-Service Portal',
'LBL_PROXY_AUTH' => 'Jogosultság-ellenőrzés?',
'LBL_PROXY_HOST' => 'Proxy Host',
'LBL_PROXY_ON_DESC' => 'Proxy server címének és jogosultság-ellenőrzése konfigurálását',
'LBL_PROXY_ON' => 'Használ proxy szervert?',
'LBL_PROXY_PASSWORD' => 'Jelszó',
'LBL_PROXY_PORT' => 'Port',
'LBL_PROXY_TITLE' => 'Proxy beállítások',
'LBL_PROXY_USERNAME' => 'Felhasználó neve',
'LBL_RESTORE_BUTTON_LABEL' => 'Visszatöltés',
'LBL_SKYPEOUT_ON_DESC' => 'Engedélyezi, hogy a felhasználó a SkypeOut&reg;-n hívást kezdeményezzen a telefonszámra való klikkelléssel. Ehhez a telefonszámot megfelelően formattálni kell, mégpedig: "+" kell kezdődjön,  "országkód" "hívószám" formátomban, például: +36 (1) 123-4567. További információkért lásd a Skype FAQ a <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a> webcímen	',
'LBL_SKYPEOUT_ON' => 'Engedélyezi SkypeOut&reg; integrációt?',
'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
'LBL_USE_REAL_NAMES' => '',
'LIST_ENTRIES_PER_LISTVIEW' => 'Listázott sorok száma laponként',
'LIST_ENTRIES_PER_SUBPANEL' => 'Panelek száma laponként',




'LOG_MEMORY_USAGE' => 'Memoria használat logja',
'LOG_SLOW_QUERIES' => 'Lassú adatbázis-lekérdezések logja',
    'LOCK_HOMEPAGE_HELP'=>'This setting is to prevent<BR> 1) the addition of new home pages in the Home module, and <BR>2) customization of dashlet placement in the home pages by dragging and dropping.',
'NEW_LOGO' => 'Új logo feltöltése (212x40)',
'NEW_LOGO_HELP' => 'The image file format can be either .png or .jpg.<BR>The recommended size is 212x40 px.',
'NEW_QUOTE_LOGO' => 'Új ajánlati logo feltöltése (867x74)',
'NEW_QUOTE_LOGO_HELP' => 'The required image file format is .jpg.<BR>The recommended size is 867x74 px.',
'QUOTES_CURRENT_LOGO' => 'Az ajánlathoz használt Logo',
'SLOW_QUERY_TIME_MSEC' => 'Lassú adatbázis-lekérdezések időkorlát(msec)',
'STACK_TRACE_ERRORS' => 'Display stack trace of errors',
'UPLOAD_MAX_SIZE' => 'Maximum feltölthető fileméret',
'VERIFY_CLIENT_IP' => 'IP cím validálás',
'LOCK_HOMEPAGE' => 'Prevent user customizable Homepage layout',
'LOCK_SUBPANELS' => 'Prevent user customizable subpanel layout',
'MAX_DASHLETS' => 'Maximum number of Dashlets on Homepage',
'SYSTEM_NAME' => 'System Name',







'LBL_LDAP_TITLE' => 'LDAP Authentication Support',
'LBL_LDAP_ENABLE' => 'Enable LDAP',
'LBL_LDAP_SERVER_HOSTNAME' => 'Server:',
'LBL_LDAP_SERVER_PORT' => 'Port Number:',
'LBL_LDAP_ADMIN_USER' => 'Authenticated User:',
'LBL_LDAP_ADMIN_USER_DESC' => 'Used to search for the sugar user. [May need to be fully qualified]',
'LBL_LDAP_ADMIN_PASSWORD' => 'Authenticated Password:',
'LBL_LDAP_AUTO_CREATE_USERS' => 'Auto Create Users:',
'LBL_LDAP_BASE_DN' => 'Base DN:',
'LBL_LDAP_LOGIN_ATTRIBUTE' => 'Login Attribute:',
'LBL_LDAP_BIND_ATTRIBUTE' => 'Bind Attribute:',
'LBL_LDAP_BIND_ATTRIBUTE_DESC' => 'For Binding the LDAP User Examples:[AD: userPrincipalName] [openLDAP: userPrincipalName] [Mac OS X: uid] ',
'LBL_LDAP_LOGIN_ATTRIBUTE_DESC' => 'For searching for the LDAP User Examples:[AD: userPrincipalName] [openLDAP: dn] [Mac OS X: dn] ',
'LBL_LDAP_SERVER_HOSTNAME_DESC' => 'Example: ldap.example.com',
'LBL_LDAP_SERVER_PORT_DESC' => 'Example: 389',
'LBL_LDAP_BASE_DN_DESC' => 'Example: DC=SugarCRM,DC=com',
'LBL_LDAP_AUTO_CREATE_USERS_DESC' => 'If an authenticated user does not exist one will be created in Sugar.',
'LBL_LDAP_ENC_KEY' => 'Encryption Key:',
'DEVELOPER_MODE' => 'Developer Mode',
'LBL_LDAP_ENC_KEY_DESC' => 'For SOAP authentication when using ldap.',
'LDAP_ENC_KEY_NO_FUNC_DESC' => 'The php_mcrypt extension must be enabled in your php.ini file.',
'LBL_ALL' => 'All',
'LBL_MARK_POINT' => 'Mark Point',
'LBL_NEXT_' => 'Next>>',
'LBL_REFRESH_FROM_MARK' => 'Refresh From Mark',
'LBL_SEARCH' => 'Search:',
'LBL_REG_EXP' => 'Reg Exp:',
'LBL_IGNORE_SELF' => 'Ignore Self:',
'LBL_MARKING_WHERE_START_LOGGING' => 'Marking Where To Start Logging From',
'LBL_DISPLAYING_LOG' => 'Displaying Log',
'LBL_YOUR_PROCESS_ID' => 'Your process ID',
'LBL_YOUR_IP_ADDRESS' => 'Your IP Address is',
'LBL_IT_WILL_BE_IGNORED' => ' It will be ignored ',
'LBL_LOG_NOT_CHANGED' => 'Log has not changed',
'LBL_ALERT_JPG_IMAGE' => 'The file format of the image must be JPEG.  Upload a new file with the file extension .jpg.',
'LBL_ALERT_TYPE_IMAGE' => 'The file format of the image must be JPEG or PNG.  Upload a new file with the file extension .jpg or .png.',
'LBL_ALERT_SIZE_RATIO' => 'The aspect ratio of the image should be between 1:1 and 10:1.  The image will be resized.',
'LBL_ALERT_SIZE_RATIO_QUOTES' => 'The aspect ratio of the image must be between 3:1 and 20:1.  Upload a new file with this ratio.',
'ERR_ALERT_FILE_UPLOAD' => 'Error during the upload of the image.',
'LBL_LOGGER' => 'Logger Settings',
	'LBL_LOGGER_FILENAME'=>'Log File Name',
	'LBL_LOGGER_FILE_EXTENSION'=>'Extension',
	'LBL_LOGGER_MAX_LOG_SIZE'=>'Maximum log size',
	'LBL_LOGGER_DEFAULT_DATE_FORMAT'=>'Default date format',
	'LBL_LOGGER_LOG_LEVEL'=>'Log Level',
	'LBL_LOGGER_MAX_LOGS'=>'Maximum number of logs (before rolling)',
	'LBL_LOGGER_FILENAME_SUFFIX' =>'Append after filename',



















);


?>
