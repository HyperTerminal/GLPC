<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.55
 *
 * ------------------------------------------------------------------------------
********************************************************************************/
/*********************************************************************************

* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributor(s): ______________________________________..
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
    'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',

    //END DON'T CONVERT
'ERR_DELETE_RECORD' => 'A megkeresés törléséhez meg kell adnia egy rekordszámot.',
'LBL_ACCOUNT_DESCRIPTION' => 'Cég leírás',
'LBL_ACCOUNT_ID' => 'Cég ID',
'LBL_ACCOUNT_NAME' => 'Cég név:',
'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Elfoglaltságok',
'LBL_ADD_BUSINESSCARD' => 'Névjegykártya hozzáadása',
'LBL_ADDRESS_INFORMATION' => 'Cím információ',
'LBL_ALT_ADDRESS_CITY' => 'Egyéb cím Váris',
'LBL_ALT_ADDRESS_COUNTRY' => 'Egyéb cím Ország',
'LBL_ALT_ADDRESS_POSTALCODE' => 'Egyéb cím Irányítószám',
'LBL_ALT_ADDRESS_STATE' => 'Egyéb cím Állam',
'LBL_ALT_ADDRESS_STREET_2' => 'Egyéb cím Utca 2',
'LBL_ALT_ADDRESS_STREET_3' => 'Egyéb cím Utca 3',
'LBL_ALT_ADDRESS_STREET' => 'Egyéb cím Street',
'LBL_ALTERNATE_ADDRESS' => 'Egyéb cím:',
'LBL_ANY_ADDRESS' => 'Általános Cím:',
'LBL_ANY_EMAIL' => 'Általános Email:',
'LBL_ANY_PHONE' => 'Általános Telefon:',
'LBL_ASSIGNED_TO_NAME' => 'Névhez rendelve',
'LBL_ASSIGNED_TO_ID' => 'Assigned User:',
'LBL_BACKTOLEADS' => 'Vissza a megkeresésekhez',
'LBL_BUSINESSCARD' => 'Megkeresés Konvertálása',
'LBL_CITY' => 'Város:',
'LBL_CONTACT_ID' => 'Kapcsolat ID',
'LBL_CONTACT_INFORMATION' => 'Megkeresés információ',
'LBL_CONTACT_NAME' => 'Megkeresés Név:',
'LBL_CONTACT_OPP_FORM_TITLE' => 'Megkeresés-Lehetőség:',
'LBL_CONTACT_ROLE' => 'Szerepkör:',
'LBL_CONTACT' => 'Megkeresés:',
'LBL_CONVERTED_ACCOUNT' => 'Konvertált cég:',
'LBL_CONVERTED_CONTACT' => 'Konvertált kapcsolat:',
'LBL_CONVERTED_OPP' => 'Konvertált lehetőség:',
'LBL_CONVERTED' => 'Kovertálva',
'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
'LBL_CONVERTLEAD_TITLE' => 'Megkeresés konvertálása [Alt+V]',
'LBL_CONVERTLEAD' => 'Megkeresés Konvertálása',
'LBL_COUNTRY' => 'Ország:',
'LBL_CREATED_ACCOUNT' => 'Új cég létrehozva',
'LBL_CREATED_CALL' => 'Új hívás létrehozva',
'LBL_CREATED_CONTACT' => 'Új kapcsolat létrehozva',
'LBL_CREATED_MEETING' => 'Új találkozó létrehozva',
'LBL_CREATED_OPPORTUNITY' => 'Új lehetőség létrehozva',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Megkeresések',
'LBL_DEPARTMENT' => 'Részleg:',
'LBL_DESCRIPTION_INFORMATION' => 'Leíró jellegű információ',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_DO_NOT_CALL' => 'Nem szabad hívni:',
'LBL_DUPLICATE' => 'Hasonló Megkeresések',
'LBL_EMAIL_ADDRESS' => 'Email:',
'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
'LBL_EXISTING_ACCOUNT' => 'Már létező céget használt',
'LBL_EXISTING_CONTACT' => 'Már létező kapcsolatot használt',
'LBL_EXISTING_OPPORTUNITY' => 'Már létező lehetőséget használt',
'LBL_FAX_PHONE' => 'Fax:',
'LBL_FIRST_NAME' => 'Keresztnév:',
'LBL_FULL_NAME' => 'Teljes név:',
'LBL_HISTORY_SUBPANEL_TITLE' => 'Előzmények',
'LBL_HOME_PHONE' => 'Otthoni telefon:',
'LBL_IMPORT_VCARD' => 'vCard Importálása',
'LBL_VCARD' => 'vCard',
'LBL_IMPORT_VCARDTEXT' => 'Automatikusan létrehoz egy új kapcsolatot egy vCard állomány importálásával az Ön állományrendszerén',
'LBL_INVALID_EMAIL' => 'Érvénytelen Email:',
'LBL_INVITEE' => 'Direkt Jelentések',
'LBL_LAST_NAME' => 'Vezetéknév:',
'LBL_LEAD_SOURCE_DESCRIPTION' => 'Megkeresés Forrás Leírása:',
'LBL_LEAD_SOURCE' => 'Megkeresés Forrás:',
'LBL_LIST_ACCEPT_STATUS' => 'Accept Status',
'LBL_LIST_ACCOUNT_NAME' => 'Cég név',
'LBL_LIST_CONTACT_NAME' => 'Megkeresés neve',
'LBL_LIST_CONTACT_ROLE' => 'Szerepkör',
'LBL_LIST_DATE_ENTERED' => 'Létrehozva',
'LBL_LIST_EMAIL_ADDRESS' => 'Email',
'LBL_LIST_FIRST_NAME' => 'Keresztnév',
'LBL_VIEW_FORM_TITLE' => 'Megkeresési nézet',
'LBL_LIST_FORM_TITLE' => 'Megkeresési lista',
'LBL_LIST_LAST_NAME' => 'Vezetéknév',
'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Megkeresés forrás leírása',
'LBL_LIST_LEAD_SOURCE' => 'Megkeresés forrás',
'LBL_LIST_MY_LEADS' => 'Saját megkeresések',
'LBL_LIST_NAME' => 'Név',
'LBL_LIST_PHONE' => 'Irodai telefon',
'LBL_LIST_REFERED_BY' => 'Rá hivatkozott',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_TITLE' => 'Titulus',
'LBL_MOBILE_PHONE' => 'Mobil:',
'LBL_MODULE_NAME' => 'Megkeresések',
'LBL_MODULE_TITLE' => 'Megkeresések: Home',
'LBL_NAME' => 'Név:',
'LBL_NEW_FORM_TITLE' => 'Új megkeresés',
'LBL_NEW_PORTAL_PASSWORD' => 'Új portál jelszó:',
'LBL_OFFICE_PHONE' => 'Irodai telefon:',
'LBL_OPP_NAME' => 'Lehetőség név:',
'LBL_OPPORTUNITY_AMOUNT' => 'Lehetőség érték:',
'LBL_OPPORTUNITY_ID' => 'Lehetőség ID',
'LBL_OPPORTUNITY_NAME' => 'Lehetőség név:',
'LBL_OTHER_EMAIL_ADDRESS' => 'Egyéb email:',
'LBL_OTHER_PHONE' => 'Egyéb Telefon:',
'LBL_PHONE' => 'Telefon:',
'LBL_PORTAL_ACTIVE' => 'Portál aktív:',
'LBL_PORTAL_APP' => 'Portál alkalmazás',
'LBL_PORTAL_INFORMATION' => 'Portál információ',
'LBL_PORTAL_NAME' => 'Portál név:',
'LBL_PORTAL_PASSWORD_ISSET' => 'Portál jelszó beállítva:',
'LBL_POSTAL_CODE' => 'Irányítószám:',
'LBL_PRIMARY_ADDRESS_CITY' => 'Elsődleges cím City',
'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Elsődleges cím Ország',
'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Elsődleges cím Irányítószám',
'LBL_PRIMARY_ADDRESS_STATE' => 'Elsődleges cím állam',
'LBL_PRIMARY_ADDRESS_STREET_2' => 'Elsődleges cím utca 2',
'LBL_PRIMARY_ADDRESS_STREET_3' => 'Elsődleges cím utca 3',
'LBL_PRIMARY_ADDRESS_STREET' => 'Elsődleges cím utca',
'LBL_PRIMARY_ADDRESS' => 'Elsődleges cím:',
'LBL_REFERED_BY' => 'Rá hivatkozott:',
'LBL_REPORTS_TO_ID' => 'Jelentést tesz ID',
'LBL_REPORTS_TO' => 'Jelentést tesz:',
'LBL_SALUTATION' => 'Üdvözlés',
'LBL_MODIFIED' => 'Modified By',
	'LBL_MODIFIED_ID'=>'Modified By Id',
	'LBL_CREATED'=>'Created By',
	'LBL_CREATED_ID'=>'Created By Id',    
'LBL_SEARCH_FORM_TITLE' => 'Megkeresés keresés',
'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Ellenőrzött megkeresések kiválasztása',
'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Ellenőrzött megkeresések kiválasztása',
'LBL_STATE' => 'Állapot:',
'LBL_STATUS_DESCRIPTION' => 'Állapotleírás:',
'LBL_STATUS' => 'Állapot:',
'LBL_TITLE' => 'Titulus:',
'LNK_IMPORT_VCARD' => 'Létrehozás vCard-ból',
'LNK_LEAD_LIST' => 'Megkeresések',
'LNK_NEW_ACCOUNT' => 'Cég létrehozása',
'LNK_NEW_APPOINTMENT' => 'Megbeszélés létrehozása',
'LNK_NEW_CONTACT' => 'Kapcsolat létrehozása',
'LNK_NEW_LEAD' => 'Megkeresés létrehozása',
'LNK_NEW_NOTE' => 'Feljegyzés vagy csatolmány létrehozása',
'LNK_NEW_OPPORTUNITY' => 'Lehetőség létrehozása',
'LNK_SELECT_ACCOUNT' => 'Cég választás',
'MSG_DUPLICATE' => 'Hasonló Megkereséseket találtam. Kérem pipálja ki azokat a Megkereséseket amiket össze akar rendelni azokkal rekorodokkal, amelyek a konverzió során jönnek létre. Amikor ezzel készen van, válassza a következőt.',
'NTC_COPY_ALTERNATE_ADDRESS' => 'Egyéb cím másolása az elsődleges címbe',
'NTC_COPY_PRIMARY_ADDRESS' => 'Elsődleges cím másolása az egyéb címbe',
'NTC_DELETE_CONFIRMATION' => 'Biztos benne, hogy törli ezt a rekordot?',
'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Egy lehetőség létrehozásához meg kell adnia egy céget.n Kérem hozzon létre egy céget, vagy adjon meg egy létezőt.',
'NTC_REMOVE_CONFIRMATION' => 'Biztos benne, hogy eltávolítja ezt a Megkeresést az esetből?',
'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Biztos benne, hogy eltávolítja ezt a rekordot mint direkt jelentést?',
'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE' => 'Kampányok',
'LBL_TARGET_OF_CAMPAIGNS' => 'Sikere kampány:',
'LBL_TARGET_BUTTON_LABEL' => 'Célozva',
'LBL_TARGET_BUTTON_TITLE' => 'Célozva',
'LBL_TARGET_BUTTON_KEY' => 'T',
'LBL_CAMPAIGN_ID' => 'Kampány ID',
'LBL_CAMPAIGN' => 'Kampány:',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',
    'LBL_PROSPECT_LIST' => 'Prospect List',
    'LBL_CAMPAIGN_LEAD' => 'Lead',



'LBL_THANKS_FOR_SUBMITTING_LEAD' => 'Thank You For Your Submission.',
'LBL_SERVER_IS_CURRENTLY_UNAVAILABLE' => 'A szerver jelenleg nem elérhető, kérem próbálja meg később.',
'LBL_ASSISTANT_PHONE' => 'Assistant Phone',
'LBL_ASSISTANT' => 'Assistant',
'LBL_REGISTRATION' => 'Registration',
'LBL_MESSAGE' => 'Please enter your information below. Information and/or an account will be created for you pending approval.',
'LBL_SAVED' => 'Thank you for registering. Your account will be created and someone will contact you shortly.',
'LBL_CLICK_TO_RETURN' => 'Return to Portal',
'LBL_CREATED_USER' => 'Created User',
'LBL_MODIFIED_USER' => 'Modified User',
'LBL_CAMPAIGNS' => 'Campaigns',
    'LBL_ASSIGNED_TO' => 'Assigned to:',
);


?>
