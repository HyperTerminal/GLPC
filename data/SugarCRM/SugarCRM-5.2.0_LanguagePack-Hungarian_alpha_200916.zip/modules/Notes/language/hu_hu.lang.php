<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.56
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'ERR_DELETE_RECORD' => 'A bejegyzés törléséhez meg kell adnia a rekordsorszámot.',
'LBL_ACCOUNT_ID' => 'Cég ID:',
'LBL_CASE_ID' => 'Eset ID:',
'LBL_CLOSE' => 'Bezár:',
'LBL_COLON' => ':',
'LBL_CONTACT_ID' => 'Kapcsolat ID:',
'LBL_CONTACT_NAME' => 'Kapcsolat:',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Feljegyzések',
'LBL_DESCRIPTION' => 'Leírás',
'LBL_EMAIL_ADDRESS' => 'Emailcím:',
'LBL_EMAIL_ATTACHMENT' => 'Email Attachment',
'LBL_FILE_MIME_TYPE' => 'Mime típus',
'LBL_FILE_URL' => 'File URL',
'LBL_FILENAME' => 'Csatolmány:',
'LBL_LEAD_ID' => 'Megkeresés ID:',
'LBL_LIST_CONTACT_NAME' => 'Kapcsolat',
'LBL_LIST_DATE_MODIFIED' => 'Utoljára módosítva',
'LBL_LIST_FILENAME' => 'Csatolmány',
'LBL_LIST_FORM_TITLE' => 'Feljegyzés lista',
'LBL_LIST_RELATED_TO' => 'Összefüggésben',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_LIST_CONTACT' => 'Kapcsolat',
'LBL_MODULE_NAME' => 'Feljegyzések',
'LBL_MODULE_TITLE' => 'Feljegyzések: Home',
'LBL_NEW_FORM_TITLE' => 'Feljegyzés vagy csatolmány hozzáadása',
'LBL_NOTE_STATUS' => 'Feljegyzés',
'LBL_NOTE_SUBJECT' => 'Feljegyzés tárgya:',
'LBL_NOTES_SUBPANEL_TITLE' => 'Csatolt állományok',
'LBL_NOTE' => 'Feljegyzés:',
'LBL_OPPORTUNITY_ID' => 'Lehetőség ID:',
'LBL_PARENT_ID' => 'Szülő ID:',
'LBL_PARENT_TYPE' => 'Szülő típus',
'LBL_PHONE' => 'Telefon:',
'LBL_PORTAL_FLAG' => 'Megjelenítés portálon?',
'LBL_EMBED_FLAG' => 'Email-ba ágyazza?',
'LBL_PRODUCT_ID' => 'Termék ID:',
'LBL_QUOTE_ID' => 'Ajánlat ID:',
'LBL_RELATED_TO' => 'Összefüggésben:',
'LBL_SEARCH_FORM_TITLE' => 'Feljegyzés keresése',
'LBL_STATUS' => 'Állapot',
'LBL_SUBJECT' => 'Tárgy:',
'LNK_CALL_LIST' => 'Hívások',
'LNK_EMAIL_LIST' => 'Emailek',
'LNK_IMPORT_NOTES' => 'Feljegyzések importálása',
'LNK_MEETING_LIST' => 'Találkozók',
'LNK_NEW_CALL' => 'Hívás beütemezése',
'LNK_NEW_EMAIL' => 'Email Archiválása',
'LNK_NEW_MEETING' => 'Találkozó beütemezése',
'LNK_NEW_NOTE' => 'Feljegyzés vagy csatolmány létrehozása',
'LNK_NEW_TASK' => 'Feladat létrehozása',
'LNK_NOTE_LIST' => 'Feljegyzések',
'LNK_TASK_LIST' => 'Feladatok',
'LNK_VIEW_CALENDAR' => 'Ma',
'LBL_MEMBER_OF' => 'Ezeknek tagja:',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',





'LBL_REMOVING_ATTACHMENT' => 'Csatolt állomány eltávolítása...',
'ERR_REMOVING_ATTACHMENT' => 'Csatolt állomány eltávolítása sikertelen...',
'LBL_CREATED_BY' => 'Created By',
'LBL_MODIFIED_BY' => 'Modified By',
'LBL_SEND_ANYWAYS' => 'This email has no subject.  Send/save anyway?',
	'LBL_LIST_EDIT_BUTTON' => 'Edit',
	'LBL_DATE_ENTERED' => 'Date Created:',
    'LBL_DATE_MODIFIED' => 'Last Modified:',
);

?>
