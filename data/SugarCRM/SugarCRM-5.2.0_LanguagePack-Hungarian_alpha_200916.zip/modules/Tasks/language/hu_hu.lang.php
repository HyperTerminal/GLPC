<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2008 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 *
 * ------------------------------------------------------------------------------
 *
 *  Vastag László     vastag@openbi.hu       2009-01-06-19.12.58
 *
 * ------------------------------------------------------------------------------
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Feladatok',
'LBL_TASK' => 'Feladatok: ',
'LBL_MODULE_TITLE' => ' Feladatok: Home',
'LBL_SEARCH_FORM_TITLE' => 'Feladat keresés',
'LBL_LIST_FORM_TITLE' => ' Feladatlista',
'LBL_NEW_FORM_TITLE' => ' Feladat létrehozása',
'LBL_NEW_FORM_SUBJECT' => 'Tárgy:',
'LBL_NEW_FORM_DUE_DATE' => 'Határidő dátum:',
'LBL_NEW_FORM_DUE_TIME' => 'Határidő idő:',
'LBL_NEW_TIME_FORMAT' => '(24:00)',
'LBL_LIST_CLOSE' => 'Bezár',
'LBL_LIST_SUBJECT' => 'Tárgy',
'LBL_LIST_CONTACT' => 'Kapcsolat',
'LBL_LIST_PRIORITY' => 'Prioritás',
'LBL_LIST_RELATED_TO' => 'Összefüggésben',
'LBL_LIST_DUE_DATE' => 'Határidő dátum',
'LBL_LIST_DUE_TIME' => 'Határidő idő',
'LBL_SUBJECT' => 'Tárgy:',
'LBL_STATUS' => 'Állapot:',
'LBL_DUE_DATE' => 'Határidő dátum:',
'LBL_DUE_TIME' => 'Határidő idő:',
'LBL_PRIORITY' => 'Prioritás:',
'LBL_COLON' => ':',
'LBL_DUE_DATE_AND_TIME' => 'Határidő:',
'LBL_START_DATE_AND_TIME' => 'Kezdés időpont:',
'LBL_START_DATE' => 'Kezdés dátum:',
'LBL_LIST_START_DATE' => 'Kezdés dátum:',
'LBL_START_TIME' => 'Kezdés idő:',
'LBL_LIST_START_TIME' => 'Kezdés idő:',
'DATE_FORMAT' => '(éééé-hh-mm)',
'LBL_NONE' => 'Nincs',
'LBL_CONTACT' => 'Kapcsolat:',
'LBL_EMAIL_ADDRESS' => 'Email Address:',
'LBL_PHONE' => 'Telefon:',
'LBL_EMAIL' => 'Email:',
'LBL_DESCRIPTION_INFORMATION' => 'Leírás',
'LBL_DESCRIPTION' => 'Leírás:',
'LBL_NAME' => 'Név:',
'LBL_CONTACT_NAME' => 'Kapcsolat neve: ',
'LBL_LIST_COMPLETE' => 'Kész:',
'LBL_LIST_STATUS' => 'Állapot',
'LBL_DATE_DUE_FLAG' => 'Nincs határidő',
'LBL_DATE_START_FLAG' => 'Nincs kezdési időpont',
'ERR_DELETE_RECORD' => 'A kapcsolat törléséhez meg kell adnia egy rekordsorszámot.',
'ERR_INVALID_HOUR' => 'Kérem adjon meg egy időpontot 0 és 24 óra között.',
'LBL_DEFAULT_STATUS' => 'Felvett',
'LBL_DEFAULT_PRIORITY' => 'Közepes',
'LBL_LIST_MY_TASKS' => 'Nyitott feladatok',
'LNK_NEW_CALL' => 'Hívások ütemezése',
'LNK_NEW_MEETING' => 'Találkozók ütemezése',
'LNK_NEW_TASK' => 'Feladat létrehozása',
'LNK_NEW_NOTE' => 'Feljegyzés létrehozása',
'LNK_NEW_EMAIL' => 'Email archiválása',
'LNK_CALL_LIST' => 'Hívások',
'LNK_MEETING_LIST' => 'Találkozók',
'LNK_TASK_LIST' => 'Feladatok',
'LNK_NOTE_LIST' => 'Feljegyzések',
'LNK_EMAIL_LIST' => 'Email',
'LNK_VIEW_CALENDAR' => 'Ma',
'LBL_CONTACT_FIRST_NAME' => 'Kapcsolat keresztneve',
'LBL_CONTACT_LAST_NAME' => 'Kapcsolat vezetékneve',
'LBL_LIST_ASSIGNED_TO_NAME' => 'Felelős',
'LBL_ASSIGNED_TO_NAME' => 'Assigned to:',
'LBL_LIST_DATE_MODIFIED' => 'Date Modified',
'LBL_CONTACT_ID' => 'Contact ID:',
'LBL_PARENT_ID' => 'Parent ID:',
'LBL_CONTACT_PHONE' => 'Contact Phone:',
'LBL_PARENT_NAME' => 'Parent Type:',
  'LBL_ASSIGNED_TO' => 'Assigned to:',
);


?>
