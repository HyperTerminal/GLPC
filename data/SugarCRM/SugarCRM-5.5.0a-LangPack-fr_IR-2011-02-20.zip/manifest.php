<?php
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * $Header: /cvsroot/francais/francais/fr_IR_55/fr_IR_landmark/manifest.php,v 1.7 2010/03/10 14:42:32 lougaou Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - admin@landmarksem.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/


// manifest file for information regarding application of new code
$manifest = array(

    // only install on the following sugar versions (if empty, no check)
    array (
        'exact_matches' => array (
        ),
        'regex_matches' => array (
            0 => '5\.5\.0'
        ),
    ),

    // Version for which this langpack can work
    'acceptable_sugar_flavors' => array (
        0 => 'CE',
        1 => 'PRO',
        2 => 'ENT',
    ),

    // Name of the Pack
    'name' => 'landmarksem - persian IR',

    'id'=> 'landmark_IR',

    'lang_file_suffix' => 'fr_IR',

    // Description of new code
    'description' => 'Persian Language pack For sugar 5.5.0 Authors Arash dehghani & AmirReza Mashalian',

    // Author of new code
    'author' => 'landmarksem.com',

    // Date published
    'published_date' => '2011/02/30',

    // Version of code
    'version' => '550-100310',

    // Type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',

    // Icon for displaying in UI (path to graphic contained within zip package)
    'icon' => '',

    // Uninstall is allowed
    'is_uninstallable' => true,
);
?>