<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * portal/modules/KBDocuments/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'BCDocuments',
    'LBL_MODULE_TITLE' => 'Articles',
    'LNK_NEW_KBDOCUMENT' => 'Créer Document',
    'LNK_KBDOCUMENT_LIST' => 'Liste des Documents',
    'LBL_DOC_REV_HEADER' => 'Versions des Documents',
    'LBL_SEARCH_FORM_TITLE' => 'Recherche Document',
    'LBL_KBDOC_TAGS' => 'Tags Document:',
    'LBL_KBDOC_BODY' => 'Corps Document:',
    'LBL_KBDOC_APPROVED_BY' => 'Approuvé par:',
    'LBL_KBDOC_ATTACHMENT' => 'BC Pièce Jointe',
    'LBL_KBDOC_ATTS_TITLE' => 'Télécharger les Pièces Jointes:',
    'LBL_KBDOCUMENT_ID' => 'ID Document',
    'LBL_NAME' => 'Nom du Document',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_CATEGORY' => 'Catégorie',
    'LBL_SUBCATEGORY' => 'Sous-Catégorie',
    'LBL_STATUS' => 'Statut',
    'LBL_CREATED_BY' => 'Créé par',
    'LBL_DATE_ENTERED' => 'Date de Création',
    'LBL_DATE_MODIFIED' => 'Date de modification',
    'LBL_DELETED' => 'Supprimé',
    'LBL_MODIFIED' => 'Modifié par (ID)',
    'LBL_MODIFIED_USER' => 'Modifié par',
    'LBL_CREATED' => 'Créé par',
    'LBL_RELATED_DOCUMENT_ID' => 'Lié au Document ID',
    'LBL_RELATED_DOCUMENT_REVISION_ID' => 'Lié à la version ID',
    'LBL_IS_TEMPLATE' => 'Modèle',
    'LBL_TEMPLATE_TYPE' => 'Type de Document',
    'LBL_REVISION_NAME' => 'Numéro de Version',
    'LBL_MIME' => 'Type Mime',
    'LBL_REVISION' => 'Version',
    'LBL_DOCUMENT' => 'Document Lié',
    'LBL_LATEST_REVISION' => 'Dernière Version',
    'LBL_CHANGE_LOG' => 'log de Modifications',
    'LBL_ACTIVE_DATE' => 'Date de Publication',
    'LBL_EXPIRATION_DATE' => 'Date d&#39;expiration',
    'LBL_FILE_EXTENSION' => 'Extension du fichier',
    'LBL_CAT_OR_SUBCAT_UNSPEC' => 'Nom précisé',
    'LBL_DOC_NAME' => 'Nom du Document:',
    'LBL_FILENAME' => 'Nom du Fichier:',
    'LBL_DOC_VERSION' => 'Version:',
    'LBL_CATEGORY_VALUE' => 'Catégorie:',
    'LBL_SUBCATEGORY_VALUE' => 'Sous-Catégorie:',
    'LBL_DOC_STATUS' => 'Statut:',
    'LBL_LAST_REV_CREATOR' => 'Version créée par:',
    'LBL_LAST_REV_DATE' => 'Date de la Version:',
    'LBL_DOWNNLOAD_FILE' => 'Télécharger un fichier:',
    'LBL_DET_RELATED_DOCUMENT' => 'Document lié:',
    'LBL_DET_RELATED_DOCUMENT_VERSION' => 'Version du Documenty lié:',
    'LBL_DET_IS_TEMPLATE' => 'Modèle? :',
    'LBL_DET_TEMPLATE_TYPE' => 'Type du Document:',
    'LBL_TEAM' => 'Equipe:',
    'LBL_DOC_DESCRIPTION' => 'Description:',
    'LBL_KBDOC_SUBJECT' => 'Sujet:',
    'LBL_DOC_ACTIVE_DATE' => 'Date de Publication:',
    'LBL_DOC_EXP_DATE' => 'Date d&#39;Expiration:',
    'LBL_LIST_FORM_TITLE' => 'Liste des Documents',
    'LBL_LIST_DOCUMENT' => 'Document',
    'LBL_LIST_CATEGORY' => 'Catégorie',
    'LBL_LIST_SUBCATEGORY' => 'Sous-Catégorie',
    'LBL_LIST_REVISION' => 'Version',
    'LBL_LIST_LAST_REV_CREATOR' => 'Publié par',
    'LBL_LIST_LAST_REV_DATE' => 'Date de la Version',
    'LBL_LIST_VIEW_DOCUMENT' => 'Voir',
    'LBL_LIST_DOWNLOAD' => 'Télécharger',
    'LBL_LIST_ACTIVE_DATE' => 'Date de Publication',
    'LBL_LIST_EXP_DATE' => 'Date d&#39;Expiration',
    'LBL_LIST_STATUS' => 'Statut',
    'LBL_LIST_MOST_VIEWED' => 'Articles les plus vus',
    'LBL_LIST_MOST_RECENT' => 'Articles les plus récents',
    'LBL_SF_DOCUMENT' => 'Nom du Document:',
    'LBL_SF_CATEGORY' => 'Catégorie:',
    'LBL_SF_SUBCATEGORY' => 'Sous-Catégorie:',
    'LBL_SF_ACTIVE_DATE' => 'Date de Publication:',
    'LBL_SF_EXP_DATE' => 'Date d&#39;Expiration:',
    'DEF_CREATE_LOG' => 'Document Créés',
    'LBL_MENU_FTS' => 'Recherche Texte Intégral',
    'ERR_DOC_NAME' => 'Nom du Document',
    'ERR_DOC_ACTIVE_DATE' => 'Date de Publication',
    'ERR_DOC_EXP_DATE' => 'Date d&#39;Expiration',
    'ERR_FILENAME' => 'Nom du fichier',
    'ERR_DOC_VERSION' => 'Version du Document',
    'ERR_DELETE_CONFIRM' => 'voulez vous supprimer cette version?',
    'ERR_DELETE_LATEST_VERSION' => 'Vous ne pouvez pas supprimer la dernière version du document.',
    'LNK_NEW_MAIL_MERGE' => 'Fusion de Mail',
    'LBL_MAIL_MERGE_DOCUMENT' => 'Modèle de Fusion de Mail:',
    'LBL_TREE_TITLE' => 'Documents',
    'LBL_LIST_DOCUMENT_NAME' => 'Nom du Document',
    'LBL_CONTRACT_NAME' => 'Nom du Contrat:',
    'LBL_LIST_IS_TEMPLATE' => 'Modèle?',
    'LBL_LIST_TEMPLATE_TYPE' => 'Type du Document',
    'LBL_LIST_SELECTED_REVISION' => 'Version sélectionnée',
    'LBL_LIST_LATEST_REVISION' => 'Dernière Version',
    'LBL_CONTRACTS_SUBPANEL_TITLE' => 'Contrats liés',
    'LBL_LAST_REV_CREATE_DATE' => 'Date de création de la dernière version'
);

?>