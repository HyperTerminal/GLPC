<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/Bugs/language/fr_FR.lang.php,v 1.3 2009/12/18 07:20:40 lougaou Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Suivi Bugs',
    'LBL_MODULE_TITLE' => 'Suivi de Bugs',
    'LBL_MODULE_ID' => 'Bugs',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher un Bug',
    'LBL_LIST_FORM_TITLE' => 'Liste des Bugs',
    'LBL_NEW_FORM_TITLE' => 'Nouveau Bug',
    'LBL_CONTACT_BUG_TITLE' => 'Contact-Bug:',
    'LBL_SUBJECT' => 'Sujet:',
    'LBL_BUG' => 'Bug:',
    'LBL_BUG_NUMBER' => 'Numéro de bug:',
    'LBL_NUMBER' => 'Numéro:',
    'LBL_STATUS' => 'Statut:',
    'LBL_PRIORITY' => 'Priorité:',
    'LBL_DESCRIPTION' => 'Description:',
    'LBL_CONTACT_NAME' => 'Nom du Contact:',
    'LBL_BUG_SUBJECT' => 'Sujet du Bug:',
    'LBL_CONTACT_ROLE' => 'Rôle:',
    'LBL_LIST_NUMBER' => 'Num.',
    'LBL_LIST_SUBJECT' => 'Sujet',
    'LBL_LIST_STATUS' => 'Statut',
    'LBL_LIST_PRIORITY' => 'Priorité',
    'LBL_LIST_RELEASE' => 'Version',
    'LBL_LIST_RESOLUTION' => 'Etat',
    'LBL_LIST_LAST_MODIFIED' => 'Date de modification',
    'LBL_INVITEE' => 'Contacts',
    'LBL_TYPE' => 'Type:',
    'LBL_LIST_TYPE' => 'Type',
    'LBL_RESOLUTION' => 'Etat:',
    'LBL_RELEASE' => 'Version:',
    'LNK_NEW_BUG' => 'Signaler Bug',
    'LNK_BUG_LIST' => 'Bugs',
    'NTC_REMOVE_INVITEE' => 'Etes-vous sûr(e) de vouloir supprimer ce Contact du Bug ?',
    'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Etes-vous sûr(e) de vouloir supprimer ce Bug de ce Compte ?',
    'ERR_DELETE_RECORD' => 'un numéro d&#39;enregistrement doit être spécifié pour toute suppression.',
    'LBL_LIST_MY_BUGS' => 'Mes Bugs',
    'LBL_FOUND_IN_RELEASE' => 'Trouvé en Release:',
    'LBL_FIXED_IN_RELEASE' => 'Fixé en Release:',
    'LBL_LIST_FIXED_IN_RELEASE' => 'Fixé en Release',
    'LBL_WORK_LOG' => 'Réflexion menée:',
    'LBL_SOURCE' => 'Source:',
    'LBL_PRODUCT_CATEGORY' => 'Catégorie',
    'LBL_CREATED_BY' => 'Créé par:',
    'LBL_DATE_CREATED' => 'Date de création:',
    'LBL_MODIFIED_BY' => 'Modifié par:',
    'LBL_DATE_LAST_MODIFIED' => 'Date de modification:',
    'LBL_LIST_EMAIL_ADDRESS' => 'Adresse Email',
    'LBL_LIST_CONTACT_NAME' => 'Nom Contact',
    'LBL_LIST_ACCOUNT_NAME' => 'Nom Compte',
    'LBL_LIST_PHONE' => 'Téléphone',
    'NTC_DELETE_CONFIRMATION' => 'Etes-vous sûr(e) de vouloir supprimer ce Contact du Bug ?',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Suivi Bugs',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activités à Réaliser',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'Historique et Activités terminées',
    'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contacts',
    'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Comptes',
    'LBL_CASES_SUBPANEL_TITLE' => 'Tickets',
    'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projets',
    'LBL_SYSTEM_ID' => 'ID Système',
    'LBL_LIST_ASSIGNED_TO_NAME' => 'Assigné à',
    'LBL_ASSIGNED_TO_NAME' => 'Assigné à',
    'LBL_ASSIGNED_TO_ID' => 'Assigné à',
    'LNK_BUG_REPORTS' => 'Rapports de Bugs',
    'LBL_SHOW_IN_PORTAL' => 'Voir dans le portail'
);

?>