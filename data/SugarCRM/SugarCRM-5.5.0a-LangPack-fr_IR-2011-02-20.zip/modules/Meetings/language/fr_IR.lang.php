<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/Meetings/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'ERR_DELETE_RECORD' => 'Un numéro d&#39;enregistrement doit être spécifié pour toute suppression.',
    'LBL_ACCEPT_THIS' => 'Accepter ?',
    'LBL_ADD_BUTTON' => 'Ajouter',
    'LBL_ADD_INVITEE' => 'Ajouter des participants',
    'LBL_BLANK' => '&nbsp;',
    'LBL_COLON' => ':',
    'LBL_CONTACT_NAME' => 'Contact:',
    'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contacts',
    'LBL_CREATED_BY' => 'Créé par',
    'LBL_DATE_END' => 'Date de fin',
    'LBL_DATE_TIME' => 'Date et Heure début:',
    'LBL_DATE' => 'Date de début:',
    'LBL_DEFAULT_STATUS' => 'Planned',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Réunions',
    'LBL_DEL' => 'Sup',
    'LBL_DESCRIPTION_INFORMATION' => 'Description',
    'LBL_DESCRIPTION' => 'Description:',
    'LBL_DURATION_HOURS' => 'Durée en Heures:',
    'LBL_DURATION_MINUTES' => 'Durée en Minutes:',
    'LBL_DURATION' => 'Durée:',
    'LBL_EMAIL' => 'Email',
    'LBL_FIRST_NAME' => 'Prénom',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'Notes',
    'LBL_HOURS_ABBREV' => 'h',
    'LBL_HOURS_MINS' => '(heures/minutes)',
    'LBL_INVITEE' => 'Participants',
    'LBL_LAST_NAME' => 'Nom',
    'LBL_ASSIGNED_TO_NAME' => 'Assigné à :',
    'LBL_LIST_ASSIGNED_TO_NAME' => 'Assigné à',
    'LBL_LIST_CLOSE' => 'Fermer',
    'LBL_LIST_CONTACT' => 'Contact',
    'LBL_LIST_DATE_MODIFIED' => 'Date de modification',
    'LBL_LIST_DATE' => 'Date de début',
    'LBL_LIST_DUE_DATE' => 'Date prévue',
    'LBL_LIST_FORM_TITLE' => 'Liste des Réunions',
    'LBL_LIST_MY_MEETINGS' => 'Mes Rendez-vous',
    'LBL_LIST_RELATED_TO' => 'Relatif à',
    'LBL_LIST_STATUS' => 'Statut',
    'LBL_LIST_SUBJECT' => 'Sujet',
    'LBL_LIST_TIME' => 'Heure début',
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads',
    'LBL_LOCATION' => 'Localisation:',
    'LBL_MEETING' => 'Réunion:',
    'LBL_MINSS_ABBREV' => 'm',
    'LBL_MODIFIED_BY' => 'Modifié par',
    'LBL_MODULE_NAME' => 'Réunions',
    'LBL_MODULE_TITLE' => 'Réunions',
    'LBL_NAME' => 'Nom',
    'LBL_NEW_FORM_TITLE' => 'Planifier Réunion',
    'LBL_OUTLOOK_ID' => 'Outlook ID',
    'LBL_PHONE' => 'Téléphone:',
    'LBL_REMINDER_TIME' => 'Heure de la notification',
    'LBL_REMINDER' => 'Notification:',
    'LBL_SCHEDULING_FORM_TITLE' => 'Planification',
    'LBL_SEARCH_BUTTON' => 'Rechercher',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher une Réunion',
    'LBL_SEND_BUTTON_KEY' => 'I',
    'LBL_SEND_BUTTON_LABEL' => 'Envoyer Invitations',
    'LBL_SEND_BUTTON_TITLE' => 'Envoyer les invitations [Alt+I]',
    'LBL_STATUS' => 'Statut:',
    'LBL_SUBJECT' => 'Sujet:',
    'LBL_TIME' => 'Heure de début:',
    'LBL_USERS_SUBPANEL_TITLE' => 'Utilisateurs',
    'LBL_ACTIVITIES_REPORTS' => 'Rapport d&#39;activités',
    'LNK_CALL_LIST' => 'Appels',
    'LNK_EMAIL_LIST' => 'Emails',
    'LNK_MEETING_LIST' => 'Réunions',
    'LNK_NEW_APPOINTMENT' => 'Planifier Rendez-vous',
    'LNK_NEW_CALL' => 'Planifier Appel',
    'LNK_NEW_EMAIL' => 'Archiver Email',
    'LNK_NEW_MEETING' => 'Planifier Réunion',
    'LNK_NEW_NOTE' => 'Créer Note',
    'LNK_NEW_TASK' => 'Créer Tâche',
    'LNK_NOTE_LIST' => 'Notes',
    'LNK_TASK_LIST' => 'Tâches',
    'LNK_VIEW_CALENDAR' => 'Aujourd&#39;hui',
    'NTC_REMOVE_INVITEE' => 'Etes-vous sûr(e) de vouloir supprimer ce participant de la réunion ?',
    'LBL_ASSIGNED_TO_ID' => 'Assigné à (ID)',
    'LBL_CREATED_USER' => 'Créé par',
    'LBL_MODIFIED_USER' => 'Modifié par',
    'NOTICE_DURATION_TIME' => 'La durée doit être supérieur à 0',
    'LBL_ASSIGNED_TO' => 'Assigné à:',
);

?>