<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/Relationships/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_ID' => 'Id Relation',
    'LBL_RELATIONSHIP_NAME' => 'Nom Relation',
    'LBL_LHS_MODULE' => 'Nom Module LHS',
    'LBL_LHS_TABLE' => 'Nom Table LHS',
    'LBL_LHS_KEY' => 'Nom Clé LHS',
    'LBL_RHS_MODULE' => 'Nom Module RHS',
    'LBL_RHS_TABLE' => 'Nom Table RHS',
    'LBL_RHS_KEY' => 'Nom Clé RHS',
    'LBL_JOIN_TABLE' => 'Nom table Jointe',
    'LBL_JOIN_KEY_LHS' => 'Clé LHS Jointe',
    'LBL_JOIN_KEY_RHS' => 'Clé RHS Jointe',
    'LBL_RELATIONSHIP_TYPE' => 'Type de relation',
    'LBL_RELATIONSHIP_ROLE_COLUMN' => 'Nom Colonne Rôle de la Relation',
    'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE' => 'Valeur Colonne Rôle de la Relation',
    'LBL_REVERSE' => 'Inverser',
    'LBL_DELETED' => 'Supprimé'
);

?>