<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/Expressions/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Expressions',
    'LBL_MODULE_TITLE' => 'Déclencheurs WorkFlow',
    'LBL_SEARCH_FORM_TITLE' => 'Déclencheurs WorkFlow: Rechercher',
    'LBL_LIST_FORM_TITLE' => 'Liste d&#39;Actions',
    'LBL_NEW_FORM_TITLE' => 'Créer un Déclencheur',
    'LBL_LIST_NAME' => 'Nom du Déclencheur:',
    'LBL_LIST_TYPE' => 'Type:',
    'LBL_LIST_EVAL' => 'Eval:',
    'LBL_LIST_FIELD' => 'Champ:',
    'LBL_NAME' => 'Nom du Déclencheur:',
    'LBL_FIELD' => 'Champ:',
    'LBL_TYPE' => 'Type:',
    'LBL_EVAL' => 'Evaluation du Déclencheur:',
    'LBL_SHOW_PAST' => 'Modifier Ancienne Valeur:',
    'LNK_NEW_TRIGGER' => 'Créer un Déclencheur',
    'LNK_TRIGGER' => 'Déclencheur WorkFlow',
    'LBL_TIME_PAST' => 'avant',
    'LBL_TIME_FUTURE' => 'à partir de',
    'LBL_ACTION_UPDATE' => 'Mettre à jour des champs déclenchés  ',
    'LBL_ACTION_UPDATE_REL' => 'Mettre à jour des champs associé à  ',
    'LBL_ACTION_NEW' => 'Créer un/une nouveau ',
    'LBL_RECORD' => 'Enregistrement',
    'LBL_NEXT_BUTTON' => 'Suivant',
    'LBL_PREVIOUS_BUTTON' => 'Précédent',
    'LBL_LIST_ACTION_DESCRIPTION' => 'Actions à exécuter:',
    'LBL_PLEASE_SELECT' => 'Veuillez Choisir',
    'LBL_TIME_INT' => 'pour au moins',
    'LBL_REL1' => 'Module Associé: ',
    'LBL_REL2' => 'Module associé au Module Associé: ',
    'LBL_PLEASE_SEL_TARGET' => 'Veuillez sélectionner un module cible',
    'LBL_ASSOCIATED_WITH' => ' associé avec le module relatif à '
);

?>