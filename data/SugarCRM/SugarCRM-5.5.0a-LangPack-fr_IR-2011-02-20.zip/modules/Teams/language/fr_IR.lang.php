<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/Teams/language/fr_FR.lang.php,v 1.4 2009/12/18 07:20:40 lougaou Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'ERR_ADD_RECORD' => 'Un numéro d&#39;enregistrement doit être spécifié pour ajouter un utilisateur à cette équipe.',
    'ERR_DELETE_RECORD' => 'Un numéro d&#39;enregistrement doit être spécifié pour toute suppression.',
    'ERR_INVALID_TEAM_REASSIGNMENT' => 'Erreur. L&#39;équipe sélectionnée <b>({0})</b> est l&#39;équipe que vous avez choisi pour être supprimée. Veuillez sélectionner une autre équipe.',

    'LBL_DESCRIPTION' => 'Description:',
    'LBL_GLOBAL_TEAM_DESC' => 'Equipe comprenant tous les utilisateurs',
    'LBL_INVITEE' => 'Membres de &#39;équipe',
    'LBL_LIST_DEPARTMENT' => 'Service',
    'LBL_LIST_DESCRIPTION' => 'Description',
    'LBL_LIST_FORM_TITLE' => 'Equipes',
    'LBL_LIST_NAME' => 'Nom',
    'LBL_FIRST_NAME' => 'Prénom :',
    'LBL_LAST_NAME' => 'Nom de famille :',
    'LBL_LIST_REPORTS_TO' => 'Rend compte à',
    'LBL_LIST_TITLE' => 'Fonction',
    'LBL_MODULE_NAME' => 'Equipes',
    'LBL_MODULE_TITLE' => 'Equipes',
    'LBL_NAME' => 'Nom de l&#39;équipe:',
    'LBL_NAME_2' => 'Nom de l&#39;équipe(2):',
    'LBL_PRIMARY_TEAM_NAME' => 'Nom de l&#39;équipe principale',
    'LBL_NEW_FORM_TITLE' => 'Nouvelle équipe',
    'LBL_PRIVATE' => 'Privée',
    'LBL_PRIVATE_TEAM_FOR' => 'Equipe privée de ',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher une équipe',
    'LBL_TEAM_MEMBERS' => 'Membres de &#39;équipe',
    'LBL_TEAM' => 'Equipes:',
    'LBL_USERS_SUBPANEL_TITLE' => 'Membres',
    'LBL_USERS' => 'Membres',

    'LBL_REASSIGN_TEAM_TITLE' => 'Il y a des enregistrements assignés à l&#39;équipe suivante : <b>{0}</b><br>Avant de supprimer ce(s) équipe(s), vous devez au préalable réassigner ces enregistrements à une nouvellle équipe. Sélectionner une équipe à utiliser en remplacement.',   
    'LBL_REASSIGN_TEAM_BUTTON_KEY' => 'R',
    'LBL_REASSIGN_TEAM_BUTTON_LABEL' => 'Réassigner',
    'LBL_REASSIGN_TEAM_BUTTON_TITLE' => 'Réassigner [Alt+R]',	
    'LBL_CONFIRM_REASSIGN_TEAM_LABEL' => 'Etes-vous sûr(e) de vouloir mettre à jour les enregistrements sélectionnés afin d&#39;utiliser cette nouvelle équipe ?',
    'LBL_REASSIGN_TABLE_INFO' => 'Table mise à jour {0}',
    'LBL_REASSIGN_TEAM_COMPLETED' => 'L&#39;opération a été réalisée avec succès.',    

    'LNK_LIST_TEAM' => 'Equipes',
    'LNK_LIST_TEAMNOTICE' => 'Notification aux équipes',
    'LNK_NEW_TEAM' => 'Nouvelle équipe',
    'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => 'Etes-vous sûr(e) de vouloir enlever cet utilisateur de l\'équipe?'
);

?>