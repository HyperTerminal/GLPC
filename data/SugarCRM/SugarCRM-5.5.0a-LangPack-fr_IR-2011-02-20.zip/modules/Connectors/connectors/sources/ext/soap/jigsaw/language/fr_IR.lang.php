<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/**********************************************************************************
 * modules/Connectors/connectors/sources/ext/soap/jigsaw/language/fr_FR.lang.php,v 1.1 2009/12/11 13:49:06 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/
$connector_strings = array (
    //licensing information shown in config screen
    'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><td valign="top" width="35%" class="dataLabel"><image src="http://www.jigsaw.com/images/cornerstone/header/jigsawLogo.jpg" border="0"></td><td width="65%" class="dataLabel">' .
                            'Jigsaw&#169; fournit des données à jour gratuitement sur les sociétés pour les utilisateurs des produits SugarCRM – aucun enregistrement requis! ' .
                            'Les membre enregistrés peuvent utilisé le répertoire de Jigsaw&#169; contenant plus de 10 million de contacts profésionnel, ' .
                            ' avec les noms, titre, emai et numéro de téléphone. ' .
                            'Enregistrez-vous sur <a style="cursor:pointer" href="http://www.jigsaw.com" target="_blank">http://www.jigsaw.com</a>.</td></tr>',

    //vardef labels
	'LBL_ID' => 'Société ID',
	'LBL_COMPANY_NAME' => 'Nom de Société',
	'LBL_CITY' => 'Ville',
	'LBL_STREET' => 'Adresse',
	'LBL_STATE' => 'Etat',
	'LBL_COUNTRY' => 'Pays',
	'LBL_PHONE' => 'Téléphone',
	'LBL_SIC_CODE' => 'Code SIC',
	'LBL_REVENUE' => 'CA Annuel',
	'LBL_REVENUE_RANGE' => 'CA Annuel Estimé',
	'LBL_OWNERSHIP' => 'Propriétaire',
	'LBL_WEBSITE' => 'Site Internet',
	'LBL_LINKED_IN_JIGSAW' => 'Site Internet Jigsaw&#169;',
	'LBL_INDUSTRY1' => 'Industrie Primaire',
	'LBL_STOCK_SYMBOL' => 'Stock Symbol',
	'LBL_STOCK_EXCHANGE' => 'Stock Exchange',
	'LBL_CREATED_ON' => 'Date Profile Created',
	'LBL_EMPLOYEE_COUNT' => 'Nombdre d&#39;employées',
	'LBL_EMPLOYEE_RANGE' => 'Headcount Range',
	
	//Error messages
	'ERROR_API_CALL' => 'Erreur : ',
	
	//Configuration labels
	'range_end' => 'Nombre maximum de résultat dans la liste',
	'jigsaw_wsdl' => 'WSDL URL',
	'jigsaw_api_key' => 'API Key',
);

?>
