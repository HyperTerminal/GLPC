<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/ProductTypes/language/fr_FR.lang.php,v 1.3 2009/12/11 16:40:03 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Types de Produit',
    'LBL_MODULE_TITLE' => 'Types',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher un Type de Produit',
    'LBL_LIST_FORM_TITLE' => '&nbsp;',
    'LBL_PRODUCTTYPE' => 'Type:',
    'LBL_LIST_NAME' => 'Type',
    'LBL_LIST_DESCRIPTION' => 'Description',
    'LBL_NAME' => 'Type:',
    'LBL_DESCRIPTION' => 'Description:',
    'LBL_LIST_LIST_ORDER' => 'Ordre',
    'LBL_LIST_ORDER' => 'Ordre:',
    'LNK_PRODUCT_LIST' => 'Catalogue Produits',
    'LNK_NEW_PRODUCT' => 'Nouveau produit',
    'LNK_NEW_MANUFACTURER' => 'Fabricants',
    'LNK_NEW_SHIPPER' => 'Transporteurs',
    'LNK_NEW_PRODUCT_CATEGORY' => 'Catégories de produits',
    'LNK_NEW_PRODUCT_TYPE' => 'Types',
    'NTC_DELETE_CONFIRMATION' => 'Etes-vous sûr(e) de vouloir supprimer cet enregistrement ?',
    'ERR_DELETE_RECORD' => 'Un numéro d&#39;enregistrement doit être spécifié pour toute suppression.',
    'NTC_LIST_ORDER' => 'Sélectionnez l&#39;ordre dans lequel ce Type apparaîtra dans la liste de choix',
    'LNK_IMPORT_PRODUCT_TYPES' => 'Importer Types',
    'LBL_CREATED_BY' => 'Créé par'
);

?>