<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/CustomQueries/language/fr_FR.lang.php,v 1.3 2009/12/11 16:40:03 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Requêtes personnalisées',
    'LBL_MODULE_TITLE' => 'Requêtes personnalisées',
    'LBL_SEARCH_FORM_TITLE' => 'Recherche Type de Produit',
    'LBL_LIST_FORM_TITLE' => 'Liste des Requêtes personnalisées',
    'LBL_CUSTOMQUERY' => 'Requête personnalisée:',
    'LBL_QUERY_TYPE' => 'Type de requête:',
    'LBL_LIST_NAME' => 'Nom Requête',
    'LBL_LIST_DESCRIPTION' => 'Description',
    'LBL_NAME' => 'Nom Requête:',
    'LBL_DESCRIPTION' => 'Description:',
    'LBL_LIST_LIST_ORDER' => 'Tri',
    'LBL_LIST_ORDER' => 'Ordre:',
    'LBL_QUERY_LOCKED' => 'Verrouiller requête:',
    'LBL_LIST_VALID' => 'Valider la requête?',
    'LNK_PRODUCT_LIST' => 'Catalogue Produits',
    'LNK_REPORT_MAKER' => 'Générateur de Rapport',
    'LNK_NEW_SHIPPER' => 'Transporteurs',
    'LBL_RUN_QUERY' => 'Lancer la requête',
    'LNK_LIST_REPORTMAKER' => 'Liste des Rapports Entreprise',
    'LNK_NEW_REPORTMAKER' => 'Créer Rapport',
    'LNK_LIST_DATASET' => 'Liste des formats de données',
    'LNK_NEW_DATASET' => 'Créer le format de données',
    'LNK_NEW_CUSTOMQUERY' => 'Créer requête personnalisée',
    'LNK_CUSTOMQUERIES' => 'Requêtes personnalisées',
    'LNK_NEW_QUERYBUILDER' => 'Créer Requête',
    'LNK_QUERYBUILDER' => 'Générateur de requêtes',
    'LBL_ALL_REPORTS' => 'Tous les Rapports',
    'LNK_NEW_PRODUCT_TYPE' => 'Types de Produit',
    'NTC_DELETE_CONFIRMATION' => 'Etes vous sûr de vouloir supprimer cet enregistrement ?',
    'ERR_DELETE_RECORD' => 'Un numéro d&#39;enregistrement doit être spécifié pour toute suppression.',
    'NTC_LIST_ORDER' => 'Determiner l&#39;ordre dans lequel cette catégorie apparaitra dans la liste déroulante des catégories de produits',
    'LNK_IMPORT_PRODUCT_CATEGORIES' => 'Importer Catégories de Produits',
    'DUPBLANK_ERROR_MSG' => 'Vous avez un nom de colonne non renseigné ou dupliqué',
    'QUERY_ERROR_MSG' => 'Cette requête n&#39;est pas valide.',
    'LBL_REPAIR_BUTTON_TITLE' => 'Réparer la requête [Alt+R]',
    'LBL_REPAIR_BUTTON_KEY' => 'R',
    'LBL_REPAIR_BUTTON_LABEL' => 'Réparer la requête',
    'LBL_JSCRIPT_MULTI_MAP_ERROR' => 'Des colonnes multiples ont étés définies avec le même nom de champ.',
    'LBL_REMOVE_LAYOUT_DATA' => 'Supprimer la disposition des données',
    'CHILD_ERROR_MSG' => 'Cette requête est uniquement accessible depuis le format de données &#39;parent&#39;',
    'ERROR_RESULT_MSG' => 'Cette requête n&#39;est pas valide.',
    'CHILD_RESULT_MSG' => 'Cette requête ne peut être executée indépendamment',
    'LBL_QUERYRESULT' => 'Résultat',
);

?>