<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/WorkFlow/language/fr_FR.lang.php,v 1.3 2009/12/18 07:20:40 lougaou Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Définitions du Workflow:',
    'LBL_MODULE_ID' => 'WorkFlow',
    'LBL_MODULE_TITLE' => 'Workflow',
    'LBL_SEARCH_FORM_TITLE' => 'Recherche Workflow',
    'LBL_LIST_FORM_TITLE' => 'Liste de Workflow',
    'LBL_NEW_FORM_TITLE' => 'Créer un Workflow',
    'LBL_LIST_NAME' => 'Nom',
    'LBL_LIST_TYPE' => 'L&#39;Exécution se fait:',
    'LBL_LIST_BASE_MODULE' => 'Module cible:',
    'LBL_LIST_STATUS' => 'Statut',
    'LBL_NAME' => 'Nom:',
    'LBL_DESCRIPTION' => 'Description:',
    'LBL_TYPE' => 'Actions effectuées:',
    'LBL_STATUS' => 'Statut:',
    'LBL_BASE_MODULE' => 'Module cible:',
    'LBL_LIST_ORDER' => 'Ordre d&#39;exécution:',
    'LBL_FROM_NAME' => '"From" Nom:',
    'LBL_FROM_ADDRESS' => '"From" Email:',
    'LNK_NEW_WORKFLOW' => 'Créer un Workflow',
    'LNK_WORKFLOW' => 'Liste des Workflows ',
    'LBL_ALERT_TEMPLATES' => 'Modèles d&#39;Alerte',
    'LBL_CREATE_ALERT_TEMPLATE' => 'Créer un modèle d&#39;Alerte:',
    'LBL_SUBJECT' => 'Sujet:',
    'LBL_RECORD_TYPE' => 'S&#39;applique aux:',
    'LBL_RELATED_MODULE' => 'Module Associé:',
    'LBL_PROCESS_LIST' => 'Ordonnancement du Workflow',
    'LNK_ALERT_TEMPLATES' => 'Modèles d&#39;Alerte email',
    'LNK_PROCESS_VIEW' => 'Ordonnancement du Workflow',
    'LBL_PROCESS_SELECT' => 'Veuillez sélectionner un module:',
    'LBL_LACK_OF_TRIGGER_ALERT' => 'Attention: Vous devez créer un déclencheur pour que ce Workflow fonctionne',
    'LBL_LACK_OF_NOTIFICATIONS_ON' => 'Attention: Vous devez activer les Notifications dans le panneau d&#39;administration et paramétrer l&#39;envoi des mails système > Paramètres Emails pour envoyer des Alertes',
    'LBL_FIRE_ORDER' => 'Ordre du Process:',
    'LBL_RECIPIENTS' => 'Destinataires',
    'LBL_INVITEES' => 'Participants',
    'LBL_INVITEE_NOTICE' => 'Attention, vous devez sélectionner au moins un invité pour créer ce ',
    'NTC_REMOVE_ALERT' => 'Etes-vous sûr(e) de vouloir supprimer ce Workflow?',
    'LBL_EDIT_ALT_TEXT' => 'Texte Alternatif',
    'LBL_INSERT' => 'Insérer',
    'LBL_SELECT_OPTION' => 'Merci de choisir une option.',
    'LBL_SELECT_VALUE' => 'Vous devez choisir une valeur.',
    'LBL_SELECT_MODULE' => 'Merci de sélectionner un module lié.',
    'LBL_SELECT_FILTER' => 'Vous devez choisir un champ pour filtrer le module lié.',
    'LBL_LIST_UP' => 'monter',
    'LBL_LIST_DN' => 'descendre',
    'LBL_SET' => 'Positionner',
    'LBL_AS' => 'comme',
    'LBL_SHOW' => 'Voir',
    'LBL_HIDE' => 'Cacher',
    'LBL_SPECIFIC_FIELD' => 'champ spcécifique',
    'LBL_ANY_FIELD' => 'tous les champs',
    'LBL_LINK_RECORD' => 'Liée à un enregistrement',
    'LBL_INVITE_LINK' => 'Réunion/Lien pour inviter à la conversation',
    'LBL_PLEASE_SELECT' => 'Veuillez sélectionner',
    'LBL_BODY' => 'Corps :',
    'LBL__S'=>' informations de ',
    'LBL_ALERT_SUBJECT'=>'ALERTE WORKFLOW',
    'LBL_PLEASE_SELECT' => 'Sélectionnez',
);

?>