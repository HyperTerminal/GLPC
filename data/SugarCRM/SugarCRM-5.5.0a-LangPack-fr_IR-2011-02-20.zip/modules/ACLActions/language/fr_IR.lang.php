<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/ACLActions/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_ACCESS_ALL' => 'Tous',
    'LBL_ACCESS_NONE' => 'Aucun',
    'LBL_ACCESS_OWNER' => 'Assigné',
    'LBL_ACCESS_NORMAL' => 'Normal',
    'LBL_ACCESS_ADMIN' => 'Admin',
    'LBL_ACCESS_ENABLED' => 'Activé',
    'LBL_ACCESS_DISABLED' => 'Désactivé',
    'LBL_ACCESS_DEV'=>'Développeur',
    'LBL_ACCESS_ADMIN_DEV'=>'Admin & Développeur',
    'LBL_NAME' => 'Nom',
    'LBL_DESCRIPTION' => 'Description',
    'LIST_ROLES' => 'Liste des Rôles',
    'LBL_USERS_SUBPANEL_TITLE' => 'Utilisateurs',
    'LIST_ROLES_BY_USER' => 'Liste des Rôles par Utilisateur',
    'LBL_ROLES_SUBPANEL_TITLE' => 'Rôles des Utilisateurs',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher',
    'LBL_ACTION_VIEW' => 'Afficher',
    'LBL_ACTION_EDIT' => 'Editer',
    'LBL_ACTION_DELETE' => 'Supprimer',
    'LBL_ACTION_IMPORT' => 'Import',
    'LBL_ACTION_EXPORT' => 'Export',
    'LBL_ACTION_LIST' => 'Listing',
    'LBL_ACTION_ACCESS' => 'Accès',
    'LBL_ACTION_ADMIN' => 'Type d&#39;accès',
    'LBL_ACCESS_DEFAULT' => 'Défaut'
);

?>