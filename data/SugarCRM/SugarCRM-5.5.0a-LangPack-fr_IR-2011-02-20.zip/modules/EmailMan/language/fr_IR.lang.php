<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/EmailMan/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/
global $sugar_config;
    $mod_strings = array (
    'LBL_SEND_DATE_TIME' => 'Envoyé à partir de',
    'LBL_IN_QUEUE' => 'En cours',
    'LBL_IN_QUEUE_DATE' => 'Date d&#39;entrée dans la file',
    'ERR_INT_ONLY_EMAIL_PER_RUN' => 'Seulement de valeurs numériques entiers sont autorisées pour les Emails Per Run',
    'LBL_ATTACHMENT_AUDIT' => ' a été envoyé. Il n&#39;a pas été dupliqué localement pour conserver l&#39;utilisation du disque.',
    'LBL_CONFIGURE_SETTINGS' => '',
    'LBL_CUSTOM_LOCATION' => 'Defini par l&#39;Utilisateur',
    'LBL_DEFAULT_LOCATION' => 'Defaut',
    'LBL_DISCLOSURE_TITLE' => 'Ajouter un pied de page à tous les emails',
    'LBL_DISCLOSURE_TEXT_TITLE' => 'Contenu du pied de page',
    'LBL_DISCLOSURE_TEXT_SAMPLE' => 'NOTICE: Ce message email est à utilisation uniquement des destinataires prévus et peut contenir das données confidentielle et privilégiée. Toutes visualisation, utilisation ou distribution est formellement interdire. Si vous n&#39;etes pas un des destinataires prévus, veuillez détruire toutes les copies de ce message et en informer l&#39;expéditeur afin que notre listing d&#39;adresse soit corrigé. Merci.',
    'LBL_EMAIL_DEFAULT_CHARSET' => 'Encodage par défaut des emails envoyés',
    'LBL_EMAIL_DEFAULT_CLIENT' => 'Format par défaut des emails envoyés  (B)',
    'LBL_EMAIL_DEFAULT_EDITOR' => 'Client email utilisé par défaut',
    'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS' => 'Lors de la suppression d&#39;un email, supprimer les pièces jointes et Notes qui lui sont rattachées.',
    'LBL_EMAIL_GMAIL_DEFAULTS' => 'Gmail',
    'LBL_EMAIL_PER_RUN_REQ' => 'Nombre d&#39;emails envoyés dans chaque lot:',
    'LBL_EMAIL_SMTP_SSL' => 'Activer "SMTP over SSL"',
    'LBL_EMAIL_USER_TITLE' => 'Préférences par défaut',
    'LBL_EMAILS_PER_RUN' => 'Nombre d&#39;emails envoyés par batch:',
    'LBL_ID' => 'ID',
    'LBL_LIST_CAMPAIGN' => 'Campagne',
    'LBL_LIST_FORM_PROCESSED_TITLE' => 'Traité',
    'LBL_LIST_FORM_TITLE' => 'File d&#39;attente',
    'LBL_LIST_FROM_EMAIL' => 'Email de',
    'LBL_LIST_FROM_NAME' => 'Nom de',
    'LBL_LIST_IN_QUEUE' => 'En cours',
    'LBL_LIST_MESSAGE_NAME' => 'Message ',
    'LBL_LIST_RECIPIENT_EMAIL' => 'Email du destinataire',
    'LBL_LIST_RECIPIENT_NAME' => 'Nom du destinataire',
    'LBL_LIST_SEND_ATTEMPTS' => 'Tentative(s) d&#39;envoi',
    'LBL_LIST_SEND_DATE_TIME' => 'Envoyé à partir de',
    'LBL_LIST_USER_NAME' => 'Nom Utilisateur',
    'LBL_LOCATION_ONLY' => 'Localisation',
    'LBL_LOCATION_TRACK' => 'Localisation du "tracker" (campaign_tracker.php)',
    'LBL_CAMP_MESSAGE_COPY' => 'Garder une copie des messages envoyés via les Campagnes:',
    'LBL_CAMP_MESSAGE_COPY_DESC' => 'Voulez-vous stocker une copie complète de <bold>CHAQUE</bold> email envoyé durant toutes les campagnes ?  <bold>La valeur par défaut qui est aussi notre recommandation est Non</bold>. En chosissant Non, seul le modèle du mail envoyé sera stocké et les variables seront donc nécessaires pour re-construire les messages.',
    'LBL_MAIL_SENDTYPE' => '</td></tr><tr><th class="dataLabel" align="left" colspan="4"><h4 class="dataLabel" style="padding-bottom:5px;">Serveur utilisé par le Système pour envoyer emails</h4></td></tr><tr><td class="dataLabel" width="20%">Agent de Transfert de Mail:',
    'LBL_MAIL_SMTPAUTH_REQ' => 'Utlisez l&#39;authentification&nbsp;SMTP?',
    'LBL_MAIL_SMTPPASS' => 'Mot de Passe SMTP:',
    'LBL_MAIL_SMTPPORT' => 'Port SMTP:',
    'LBL_MAIL_SMTPSERVER' => 'Serveur SMTP:',
    'LBL_MAIL_SMTPUSER' => 'Identifiant SMTP:',
    'LBL_MARKETING_ID' => 'ID Marketing',
    'LBL_MODULE_ID' => 'EmailMan',
    'LBL_MODULE_NAME' => 'Paramètrages liés aux emails',
    'LBL_CAMP_MODULE_NAME' => 'Paramètres liés aux Campagnes de type "Emails"',
    'LBL_MODULE_TITLE' => 'Gestion de la file d&#39;attente des "Envois en Masse" (Campagnes de Type Email ou Newsletter)',
    'LBL_NOTIFICATION_ON_DESC' => 'Envoyer un email de notification lorsque un enregistrement est assigné.',
    'LBL_NOTIFY_FROMADDRESS' => 'Adresse email de l&#39;expéditeur des emails envoyés par le Système (Attention: peut parfois être surchargé par votre serveur d&#39;envoi):',
    'LBL_NOTIFY_FROMNAME' => 'Nom de l&#39;expéditeur des emails envoyés par Système:',
    'LBL_NOTIFY_ON' => 'Activer les Notifications',
    'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Envoyer un email de bienvenue au nouveaux utilisateurs (B)',
    'LBL_NOTIFY_TITLE' => 'Paramètres liés aux envois de mails par le Système (Notification et Campagnes de type Email ou Newsletter)</h4><br><i>Une notification est un email envoyé à un utilisateur lorsqu&#39;un autre utilisateur lui assigne un enregistrement.</i><br>&nbsp;',
    'LBL_OLD_ID' => 'Ancien Id',
    'LBL_OUTBOUND_EMAIL_TITLE' => '',
    'LBL_RELATED_ID' => 'Enregistrement lié (ID)',
    'LBL_RELATED_TYPE' => 'Enregistrement de l&#39;enregistrement lié',
    'LBL_SAVE_OUTBOUND_RAW' => 'Sauvegarder les entêtes des Emails Sortants',
    'LBL_SEARCH_FORM_PROCESSED_TITLE' => 'Rechercher dans les traités',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher dans la file d&#39;attente',
    'LBL_VIEW_PROCESSED_EMAILS' => 'Afficher les Emails traités',
    'LBL_VIEW_QUEUED_EMAILS' => 'File d&#39;attente',
    'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE' => $sugar_config['site_url'],
    'TXT_REMOVE_ME_ALT' => 'Pour vous retirer de cette liste d&#39;email ',
    'TXT_REMOVE_ME_CLICK' => 'cliquez ici',
    'TXT_REMOVE_ME' => 'Si vous ne souhaitez plus recevoir d&#39;email de notre part ',
    'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER' => 'L&#39;expéditeur des Notifications est l&#39;utilisateur qui assigne (B)',
    'LBL_SECURITY_TITLE' => 'Sécurité',
    'LBL_SECURITY_DESC' => 'Les tags sélectionnés dans la liste ci-dessous ne seront PAS acceptés ni affichés dans les Emails entrants ou dans le module "Emails".',
    'LBL_SECURITY_APPLET' => '',
    'LBL_SECURITY_BASE' => '',
    'LBL_SECURITY_EMBED' => '',
    'LBL_SECURITY_FORM' => '',
    'LBL_SECURITY_FRAME' => '',
    'LBL_SECURITY_FRAMESET' => '',
    'LBL_SECURITY_IFRAME' => '',
    'LBL_SECURITY_IMPORT' => '',
    'LBL_SECURITY_LAYER' => '',
    'LBL_SECURITY_LINK' => '',
    'LBL_SECURITY_OBJECT' => '',
    'LBL_SECURITY_OUTLOOK_DEFAULTS' => 'Sélectionner les options de sécurité minimum d&#39;après Outlook.',
    'LBL_SECURITY_PRESERVE_RAW' => 'Conserver l&#39;email brut dans la base de données (incluant donc un contenu potentiellement dangereux). L&#39;interface SugarCRM ne présentera que le contenu FILTRÉ même si cette option est sélectionnée.<br /><span class="error">Attention un contenu volontairement nuisible pourra toujours potentiellement compromettre votre application.</span>',
    'LBL_SECURITY_SCRIPT' => '',
    'LBL_SECURITY_STYLE' => '',
    'LBL_SECURITY_TOGGLE_ALL' => 'Sélectionner/Désélectionner toutes les options',
    'LBL_SECURITY_XMP' => '',
    'LBL_YES' => 'Oui',
    'LBL_NO' => 'Non',
    'LBL_PREPEND_TEST' => '[Test]: ',
    'LBL_SEND_ATTEMPTS'	=> 'Tentatives d&#39;envois',

);

?>