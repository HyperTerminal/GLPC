<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/WorkFlowActions/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Déclencheurs',
    'LBL_MODULE_TITLE' => 'Déclencheurs de Workflow',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher',
    'LBL_LIST_FORM_TITLE' => 'Liste des Déclencheurs',
    'LBL_NEW_FORM_TITLE' => 'Créer un Déclencheur',
    'LBL_LIST_NAME' => 'Nom du Déclencheur:',
    'LBL_LIST_TRIGGER_TYPE' => 'Type:',
    'LBL_LIST_LEFT_FIELD' => 'Champ:',
    'LBL_LIST_OPERATOR' => 'Opération:',
    'LBL_LIST_RIGHT_VALUE' => 'Valeur:',
    'LBL_NAME' => 'Nom du Déclencheur:',
    'LBL_LEFT_FIELD' => 'Champ:',
    'LBL_DESCRIPTION' => 'Description:',
    'LBL_TYPE' => 'Type:',
    'LBL_STATUS' => 'Statut:',
    'LBL_BASE_MODULE' => 'Module principal:',
    'LNK_NEW_TRIGGER' => 'Créer un Déclencheur',
    'LNK_TRIGGER' => 'Déclencheurs de Workflow ',
    'LBL_TIME_INT' => 'pour au moins ',
    'LBL_SET' => 'A Positionner',
    'LBL_AS' => 'comme',
    'LBL_TITLE' => 'Positionner la valeur à :',
    'LBL_FROM' => 'de',
    'LBL_SHOW' => 'Voir',
    'LBL_MODIFY_FIELD' => 'Modifier le champs :',
    'LNK_LIST_REPORTMAKER' => 'Liste de Rapports',
    'LNK_NEW_REPORTMAKER' => 'Créer un nouveau Rapport',
    'LNK_LIST_DATASET' => 'Liste de Jeux de données',
    'LNK_NEW_DATASET' => 'Créer un jeu de données',
    'LNK_NEW_QUERYBUILDER' => 'Créer Requête',
    'LNK_QUERYBUILDER' => 'Générateur de requêtes',
    'LBL_ALL_REPORTS' => 'Tous les Rapports',
    'NTC_DELETE_CONFIRMATION' => 'Etes vous sûr de vouloir supprimer cet enregistrement ?',
    'ERR_DELETE_RECORD' => 'Un numéro d&#39;enregistrement doit être spécifié pour toute suppression.',
    'LBL_ADD_COLUMN _BUTTON_TITLE' => 'Ajouter [Alt+C]',
    'LBL_ADD_COLUMN_BUTTON_KEY' => 'C',
    'LBL_ADD_COLUMN_BUTTON_LABEL' => 'Ajouter une colonne',
    'LBL_ADD_GROUPBY_BUTTON_LABEL' => 'Ajouter un regroupement',
    'LBL_ADD_GROUPBY _BUTTON_TITLE' => 'Ajouter [Alt+G]',
    'LBL_ADD_GROUPBY_BUTTON_KEY' => 'G',
    'LBL_NEW_BUTTON_TITLE' => 'Ajouter [Alt+N]',
    'LBL_NEW_BUTTON_KEY' => 'N',
    'LBL_NEW_BUTTON_LABEL' => 'Créer nouveau',
    'LBL_DETAILS_BUTTON_TITLE' => 'Details du rapport[Alt+D]',
    'LBL_DETAILS_BUTTON_KEY' => 'D',
    'LBL_DETAILS_BUTTON_LABEL' => 'Details du rapport',
    'LBL_EDIT_BUTTON_TITLE' => 'Editer Rapport [Alt+E]',
    'LBL_EDIT_BUTTON_KEY' => 'N',
    'LBL_EDIT_BUTTON_LABEL' => 'Editer Rapport',
    'LBL_RUN_BUTTON_TITLE' => 'Lancer le Rapport [Alt+R]',
    'LBL_RUN_BUTTON_KEY' => 'R',
    'LBL_RUN_BUTTON_LABEL' => 'Lancer le Rapport'
);

?>