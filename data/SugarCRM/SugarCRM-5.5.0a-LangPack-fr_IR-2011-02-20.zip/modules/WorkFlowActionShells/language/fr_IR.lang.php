<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/WorkFlowActionShells/language/fr_FR.lang.php,v 1.2 2009/12/11 16:28:22 vince Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Actions',
    'LBL_MODULE_TITLE' => 'Déclencheurs de Workflow',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher',
    'LBL_LIST_FORM_TITLE' => 'Liste d&#39;Actions',
    'LBL_NEW_FORM_TITLE' => 'Créer un Déclencheur',
    'LBL_LIST_NAME' => 'Nom du Déclencheur:',
    'LBL_LIST_TYPE' => 'Type:',
    'LBL_LIST_EVAL' => 'Eval:',
    'LBL_LIST_FIELD' => 'Champ:',
    'LBL_NAME' => 'Nom du Déclencheur:',
    'LBL_FIELD' => 'Champ:',
    'LBL_TYPE' => 'Type:',
    'LBL_EVAL' => 'Evaluation du Déclencheur:',
    'LBL_SHOW_PAST' => 'Modifier Ancienne Valeur:',
    'LNK_NEW_TRIGGER' => 'Créer un Déclencheur',
    'LNK_TRIGGER' => 'Déclencheurs de Workflow ',
    'NTC_REMOVE_ACTION' => 'Etes vous sûr de vouloir supprimer cette Action ?',
    'LBL_ACTION_UPDATE_TITLE' => 'Mise à jour de champs dans le module cible',
    'LBL_ACTION_UPDATE_REL_TITLE' => 'Mise à jour de champs dans un module associé',
    'LBL_ACTION_NEW_TITLE' => 'Créer un enregistrement dans un module associé au module cible',
    'LBL_LIST_STATEMENT' => 'Description de l&#39;évenement:',
    'LBL_ACTION_UPDATE' => 'Mise à jour du(des) champs dans la cible ',
    'LBL_ACTION_UPDATE_REL' => 'Mise à jour du(des) champs dans un module associé',
    'LBL_ACTION_UPDATE_REL_PART2' => 'tous',
    'LBL_ACTION_UPDATE_REL_PART3' => 'associé',
    'LBL_ACTION_NEW' => 'Créer un nouvel enregistrement dans ',
    'LBL_RECORD' => 'enregistrement',
    'LBL_ACTION_NEW_REL' => 'Créer un nouvel enregistrement dans ',
    'LBL_ACTION_NEW_REL_TITLE' => 'Créer un enregistrement rattaché dans un module associé au module cible',
    'LBL_RELATED_RECORD' => 'enregistrement',
    'LBL_NEXT_BUTTON' => 'Suivant',
    'LBL_PREVIOUS_BUTTON' => 'Précédent',
    'LBL_LIST_ACTION_DESCRIPTION' => 'Actions à exécuter:',
    'LBL_INVITEES' => 'Participants',
    'LBL_DETAILS' => 'Details',
    'LBL_SELECT_VALUE' => 'Vous devez sélectionner une valeur valide.',
    'LBL_SELECT_MODULE' => 'Vous devez sélectionner un module.',
    'LBL_SELECT_RELATED_MODULE' => 'Vous devez sélectionner un module lié.',
    'LBL_SELECT_CHECKED_FIELDS' => 'Vous devez choisir une valeur pour tous les champs sélectionnés',
    'LBL_SET' => 'Positionner',
    'LBL_AS' => 'comme',
    'LBL_SHOW' => 'Voir',
    'LBL_TITLE_ADVANCED' => 'Module avancé de gestion des options liées',
    'LBL_BY' => 'par',
    'LBL__S' => '',
    'LBL_FILTER_RELATED' => 'Filtre liée',
    'LBL_ASSOCIATED_WITH' => ' associé avec lien '
);

?>