<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.; All Rights Reserved.
 *
 * Portions created by LandMarkSEM are Copyright (C) 2004-2007 LandMarkSEM. You do not
 * have the right to remove LandMarkSEM copyrights from the source code or user
 * interface.
 *
 * All Rights Reserved. For more information and to sublicense, resell,rent,
 * lease, redistribute, assign or otherwise transfer Your rights to the Software
 * contact LandMarkSEM at admin@landmarksem.com
***********************************************************************************/
/**********************************************************************************
 * modules/EditCustomFields/language/fr_FR.lang.php,v 1.3 2010/01/27 16:27:33 lougaou Exp $
 * The Original Code is:    SugarCRM French translation by LandMarkSEM
 *                          www.landmarksem.com - sugar@LandMarkSEM.com
 * Contributor(s):          ______________________________________.
 * Description :            ______________________________________.
 **********************************************************************************/

    $mod_strings = array (
    'LBL_MODULE_NAME' => 'Editer champs personnalisés',
    'LBL_ADD_FIELD' => 'Ajouter un champ:',
    'LBL_MODULE_TITLE' => 'Editer champs personnalisés',
    'LBL_MODULE_SELECT' => 'Module à Editer',
    'LBL_SEARCH_FORM_TITLE' => 'Rechercher un Module',
    'COLUMN_TITLE_NAME' => 'Nom du Champ',
    'COLUMN_TITLE_DISPLAY_LABEL' => 'Libellé Affiché',
    'COLUMN_TITLE_LABEL_VALUE' => 'Valeur du Libellé',
    'COLUMN_TITLE_LABEL' => 'Libellé Système',
    'COLUMN_TITLE_DATA_TYPE' => 'Type de donnée',
    'COLUMN_TITLE_MAX_SIZE' => 'Taille Max',
    'COLUMN_TITLE_HELP_TEXT' => 'Aide',
    'COLUMN_TITLE_COMMENT_TEXT' => 'Commentaires',
    'COLUMN_TITLE_REQUIRED_OPTION' => 'Champ obligatoire',
    'COLUMN_TITLE_DEFAULT_VALUE' => 'Valeur par défaut',
    'COLUMN_TITLE_DEFAULT_EMAIL' => 'Valeur par défaut',
    'COLUMN_TITLE_EXT1' => 'Extra Meta Champ 1',
    'COLUMN_TITLE_EXT2' => 'Extra Meta Champ 2',
    'COLUMN_TITLE_EXT3' => 'Extra Meta Champ 3',
	'COLUMN_TITLE_FRAME_HEIGHT' => 'Hauteur I-frame',
    'COLUMN_TITLE_HTML_CONTENT' => 'HTML',
    'COLUMN_TITLE_URL' => 'URL par défault',
    'COLUMN_TITLE_AUDIT' => 'Champ audité',
    'COLUMN_TITLE_REPORTABLE' => 'Utilisable dans Rapport',
    'COLUMN_TITLE_MIN_VALUE' => 'Valeur Min',
    'COLUMN_TITLE_MAX_VALUE' => 'Valeur Max',
    'COLUMN_TITLE_DISPLAYED_ITEM_COUNT' => '# éléments affichés',
    'COLUMN_DISABLE_NUMBER_FORMAT' => 'Désactiver le format des nombres',
    'LBL_DROP_DOWN_LIST' => 'Liste déroulante',
    'LBL_RADIO_FIELDS' => 'Champs Radio',
    'LBL_MULTI_SELECT_LIST' => 'Liste de déroulante à choix multiple',
    'COLUMN_TITLE_PRECISION' => 'Précision',
    'MSG_DELETE_CONFIRM' => 'Etes vous sûr de vouloir supprimer cet élément?',
    'POPUP_INSERT_HEADER_TITLE' => 'Ajouter champ personnalisé',
    'POPUP_EDIT_HEADER_TITLE' => 'Editer champ personnalisé',
    'LNK_SELECT_CUSTOM_FIELD' => 'Sélectionner champ personnalisé',
    'LNK_REPAIR_CUSTOM_FIELD' => 'Réparer les Champs Utilisateur',
    'LBL_MODULE' => 'Module',
    'COLUMN_TITLE_MASS_UPDATE' => 'Mise à jour globale',
    'COLUMN_TITLE_IMPORTABLE'=>'Imports',
    'COLUMN_TITLE_DUPLICATE_MERGE' => 'Doublon (fusion)',
    'LBL_LABEL' => 'Label',
    'LBL_DATA_TYPE' => 'Type de donnée',
    'LBL_DEFAULT_VALUE' => 'Valeur par défaut',
    'LBL_AUDITED' => 'Audité',
    'LBL_REPORTABLE' => 'Utilisable dans les rapports',
    'ERR_RESERVED_FIELD_NAME' => 'Mot-clé réservé',
    'ERR_SELECT_FIELD_TYPE' => 'Veuillez sélectionner un type de champs',
    'LBL_BTN_ADD' => 'Ajouter',
    'LBL_BTN_EDIT' => 'Editer',
    'LBL_GENERATE_URL' => 'URL construite',
    'LBL_DEPENDENT_CHECKBOX' => 'Dépendant',
    'LBL_DEPENDENT_TRIGGER' => 'Déclencheur',
    'LBL_BTN_EDIT_VISIBILITY' => 'Modifier la visibilité',
);

?>