sugarcrm-lang-pack-jp
=====================

Japanese Language Pack for SugarCRM
