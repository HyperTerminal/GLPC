<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD' => 'Ke smazání účtu je potřeba jeho ID.',
	'LBL_ACCOUNT_ID' => 'ID účtu:',
	'LBL_CASE_ID' => 'ID případu:',
	'LBL_CLOSE' => 'Zavřeno:',
	'LBL_COLON' => ':',
	'LBL_CONTACT_ID' => 'ID konktaktu:',
	'LBL_CONTACT_NAME' => 'Kontakt:',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Poznámky',
	'LBL_DESCRIPTION' => 'Popis',
	'LBL_EMAIL_ADDRESS' => 'Emailové adresy:',
	'LBL_FILE_MIME_TYPE' => 'Mime Type',
	'LBL_FILE_URL' => 'URL souboru',
	'LBL_FILENAME' => 'Příloha:',
	'LBL_LEAD_ID' => 'Lead ID:',
	'LBL_LIST_CONTACT_NAME' => 'Kontakt',
	'LBL_LIST_DATE_MODIFIED' => 'Poslední změny',
	'LBL_LIST_FILENAME' => 'Příloha',
	'LBL_LIST_FORM_TITLE' => 'Zeznam poznámek',
	'LBL_LIST_RELATED_TO' => 'Váže se k',
	'LBL_LIST_SUBJECT' => 'Předmět',
	'LBL_LIST_STATUS' => 'Stav',
	'LBL_LIST_CONTACT' => 'Kontakt',
	'LBL_MODULE_NAME' => 'Poznámky',
	'LBL_MODULE_TITLE' => 'Poznámky: Home',
	'LBL_NEW_FORM_TITLE' => 'Vytvořit poznámku nebo přílohu',
	'LBL_NOTE_STATUS' => 'Poznámka',
	'LBL_NOTE_SUBJECT' => 'Předmět poznámky:',
	'LBL_NOTES_SUBPANEL_TITLE' => 'Přílohy',
	'LBL_NOTE' => 'Poznámka:',
	'LBL_OPPORTUNITY_ID' => 'Příležitost ID:',
	'LBL_PARENT_ID' => 'Rodič ID:',
	'LBL_PARENT_TYPE' => 'Druh rodiče',
	'LBL_PHONE' => 'Telefon:',
	'LBL_PORTAL_FLAG' => 'Zobrazovat v portálu?',
	'LBL_EMBED_FLAG' => 'Vložit k emailu?',
	'LBL_PRODUCT_ID' => 'Produkt ID:',
	'LBL_QUOTE_ID' => 'Akcie ID:',
	'LBL_RELATED_TO' => 'Vztahuje se k:',
	'LBL_SEARCH_FORM_TITLE' => 'Hledat poznámku',
	'LBL_STATUS' => 'Stav',
	'LBL_SUBJECT' => 'Předmět:',
	'LNK_CALL_LIST' => 'Telefonáty',
	'LNK_EMAIL_LIST' => 'Emaily',
	'LNK_IMPORT_NOTES' => 'Importovat poznámky',
	'LNK_MEETING_LIST' => 'Meetingy',
	'LNK_NEW_CALL' => 'Naplánovat telefonát',
	'LNK_NEW_EMAIL' => 'Archivovat email',
	'LNK_NEW_MEETING' => 'Naplánovat meeting',
	'LNK_NEW_NOTE' => 'Vytvořit poznámku nebo přílohu',
	'LNK_NEW_TASK' => 'Vytvřit úkol',
	'LNK_NOTE_LIST' => 'Poznámky',
	'LNK_TASK_LIST' => 'Úkoly',
	'LNK_VIEW_CALENDAR' => 'Dnes',
	'LBL_MEMBER_OF' => 'Členem v:',
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Přiřazený uživatel',



    'LBL_REMOVING_ATTACHMENT'=>'Odebírá se příloha...',
    'ERR_REMOVING_ATTACHMENT'=>'Chyba při odebírání přílohy...',
);

?>
