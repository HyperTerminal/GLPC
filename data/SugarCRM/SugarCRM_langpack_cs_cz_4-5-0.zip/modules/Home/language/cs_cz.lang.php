<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Nový kontakt',
  'LBL_FIRST_NAME' => 'Jméno:',
  'LBL_LAST_NAME' => 'Příjmení:',
  'LBL_LIST_LAST_NAME' => 'Příjmení',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'Mé zásluhy',
  'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'Kampaň ROI',
  'LNK_NEW_CONTACT' => 'Vytvořit kontakt',
  'LNK_NEW_ACCOUNT' => 'Vytvořit účet',
  'LNK_NEW_OPPORTUNITY' => 'Vytvořit příležitost',



  'LNK_NEW_LEAD' => 'Vytvořit iniciativu',
  'LNK_NEW_CASE' => 'Vytvořit případ',
  'LNK_NEW_NOTE' => 'Vytvořit poznámku nebo přílohu',
  'LNK_NEW_CALL' => 'Naplánovat telefonát',
  'LNK_NEW_EMAIL' => 'Archivovat email',
  'LNK_COMPOSE_EMAIL' => 'Vytvořit email',
  'LNK_NEW_MEETING' => 'Naplánovat meeting',
  'LNK_NEW_TASK' => 'Vytvořit úlohu',
  'LNK_NEW_BUG' => 'Ohlásit bug',
  'LBL_ADD_BUSINESSCARD' => 'Vložit vizitku',
  'ERR_ONE_CHAR' => 'Prosím vložte alespoň jedno písmeno nebo číslo pro hledání ...',
  'LBL_OPEN_TASKS' => 'Moje otevřené úkoly',
  'LBL_SEARCH_RESULTS' => 'Výsledky hledání',
  'LBL_SEARCH_RESULTS_IN' => 'v', 
  'LNK_NEW_SEND_EMAIL' => 'Vytvořit email',
  'LBL_NO_RESULTS_IN_MODULE' => '-- Bez výsledku --',
  'LBL_NO_RESULTS' => '<h2>Nebyly nalezeny žádné výsledky. Prosím zopakujte hledání.</h2><br>',
  'LBL_NO_RESULTS_TIPS' => '<h3>Tipy k hledání:</h3><ul><li>Make sure you have the proper categories selected above.</li><li>Broaden your search criteria.</li><li>If you still cannot find any results try the advanced search of that module.</li></ul>',
  
  'LBL_RELOAD_PAGE' => 'Prosím <a href="javascript: window.location.reload()">přenačti okno</a> pro použití této nástěnky.',
  'LBL_ADD_DASHLETS' => 'Přidat nástěnky',
  'LBL_CLOSE_DASHLETS' => 'Zavřít',
  'LBL_OPTIONS' => 'Možnosti', 
  // dashlet search fields
  'LBL_TODAY'=>'Dnes',
  'LBL_YESTERDAY' => 'Včera', 
  'LBL_TOMORROW'=>'Zítra',
  'LBL_LAST_WEEK'=>'Minulý týden',
  'LBL_NEXT_WEEK'=>'Další týden',
  'LBL_LAST_7_DAYS'=>'Posledních 7 dní',
  'LBL_NEXT_7_DAYS'=>'Následujících 7 dní',
  'LBL_LAST_MONTH'=>'Minulý měsíc',
  'LBL_NEXT_MONTH'=>'Příští měsíc',
  'LBL_LAST_QUARTER'=>'Minulý kvartál',
  'LBL_THIS_QUARTER'=>'Tento kvartál',
  'LBL_LAST_YEAR'=>'Minulý rok',
  'LBL_NEXT_YEAR'=>'Přístí rok',
  'LBL_THIS_MONTH' => 'Tento měsíc',
  'LBL_THIS_YEAR' => 'Tento rok',
  'LBL_LAST_30_DAYS' => 'Posledních 30 dní',
  'LBL_NEXT_30_DAYS' => 'Následujících 30 dní',
  'LBL_THIS_MONTH' => 'Tento měsíc',
  'LBL_THIS_YEAR' => 'Tento rok',
  'LBL_LAST_30_DAYS' => 'Posledních 30 dní',
  'LBL_NEXT_30_DAYS' => 'Následujících 30 dní',
  
  // Dashlet Categories
  'dashlet_categories_dom' => array(
      'Module Views' => 'Module Views',
      'Portal' => 'Portal',
      'Charts' => 'Charts',
      'Tools' => 'Tools',
      'Miscellaneous' => 'Miscellaneous'),
  'LBL_MAX_DASHLETS_REACHED' => 'You have reached the maximum number of dashlets your adminstrator has set. Please remove a dashlet to add more.',
  'LBL_ADDING_DASHLET' => 'Přidávám nástěnku ...',
  'LBL_ADDED_DASHLET' => 'Dashlet Added',
  'LBL_REMOVE_DASHLET_CONFIRM' => 'Are you sure you want to remove the Dashlet?',
  'LBL_REMOVING_DASHLET' => 'Removing Dashlet ...',
  'LBL_REMOVED_DASHLET' => 'Dashlet Removed',
  'LBL_DASHLET_CONFIGURE_GENERAL' => 'General',
  'LBL_DASHLET_CONFIGURE_FILTERS' => 'Filters',
  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'My Items Only',
  'LBL_DASHLET_CONFIGURE_TITLE' => 'Title',
  'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Display Rows',
//  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'My Items Only',

  'LBL_TRAINING_TITLE' => 'Training',
  
  
);


?>
