<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Nov� kontakt',
  'LBL_FIRST_NAME' => 'Jm�no:',
  'LBL_LAST_NAME' => 'P��jmen�:',
  'LBL_LIST_LAST_NAME' => 'P��jmen�',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'M� z�sluhy',
  'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'Kampa� ROI',
  'LNK_NEW_CONTACT' => 'Vytvo�it kontakt',
  'LNK_NEW_ACCOUNT' => 'Vytvo�it ��et',
  'LNK_NEW_OPPORTUNITY' => 'Vytvo�it p��le�itost',



  'LNK_NEW_LEAD' => 'Vytvo�it iniciativu',
  'LNK_NEW_CASE' => 'Vytvo�it p��pad',
  'LNK_NEW_NOTE' => 'Vytvo�it pozn�mku nebo p��lohu',
  'LNK_NEW_CALL' => 'Napl�novat telefon�t',
  'LNK_NEW_EMAIL' => 'Archivovat email',
  'LNK_COMPOSE_EMAIL' => 'Vytvo�it email',
  'LNK_NEW_MEETING' => 'Napl�novat meeting',
  'LNK_NEW_TASK' => 'Vytvo�it �lohu',
  'LNK_NEW_BUG' => 'Ohl�sit bug',
  'LBL_ADD_BUSINESSCARD' => 'Vlo�it vizitku',
  'ERR_ONE_CHAR' => 'Pros�m vlo�te alespo� jedno p�smeno nebo ��slo pro hled�n� ...',
  'LBL_OPEN_TASKS' => 'Moje otev�en� �koly',
  'LBL_SEARCH_RESULTS' => 'V�sledky hled�n�',
  'LBL_SEARCH_RESULTS_IN' => 'v', 
  'LNK_NEW_SEND_EMAIL' => 'Vytvo�it email',
  'LBL_NO_RESULTS_IN_MODULE' => '-- Bez v�sledku --',
  'LBL_NO_RESULTS' => '<h2>Nebyly nalezeny ��dn� v�sledky. Pros�m zopakujte hled�n�.</h2><br>',
  'LBL_NO_RESULTS_TIPS' => '<h3>Tipy k hled�n�:</h3><ul><li>Make sure you have the proper categories selected above.</li><li>Broaden your search criteria.</li><li>If you still cannot find any results try the advanced search of that module.</li></ul>',
  
  'LBL_RELOAD_PAGE' => 'Pros�m <a href="javascript: window.location.reload()">p�ena�ti okno</a> pro pou�it� t�to n�st�nky.',
  'LBL_ADD_DASHLETS' => 'P�idat n�st�nky',
  'LBL_CLOSE_DASHLETS' => 'Zav��t',
  'LBL_OPTIONS' => 'Mo�nosti', 
  // dashlet search fields
  'LBL_TODAY'=>'Dnes',
  'LBL_YESTERDAY' => 'V�era', 
  'LBL_TOMORROW'=>'Z�tra',
  'LBL_LAST_WEEK'=>'Minul� t�den',
  'LBL_NEXT_WEEK'=>'Dal�� t�den',
  'LBL_LAST_7_DAYS'=>'Posledn�ch 7 dn�',
  'LBL_NEXT_7_DAYS'=>'N�sleduj�c�ch 7 dn�',
  'LBL_LAST_MONTH'=>'Minul� m�s�c',
  'LBL_NEXT_MONTH'=>'P��t� m�s�c',
  'LBL_LAST_QUARTER'=>'Minul� kvart�l',
  'LBL_THIS_QUARTER'=>'Tento kvart�l',
  'LBL_LAST_YEAR'=>'Minul� rok',
  'LBL_NEXT_YEAR'=>'P��st� rok',
  'LBL_THIS_MONTH' => 'Tento m�s�c',
  'LBL_THIS_YEAR' => 'Tento rok',
  'LBL_LAST_30_DAYS' => 'Posledn�ch 30 dn�',
  'LBL_NEXT_30_DAYS' => 'N�sleduj�c�ch 30 dn�',
  'LBL_THIS_MONTH' => 'Tento m�s�c',
  'LBL_THIS_YEAR' => 'Tento rok',
  'LBL_LAST_30_DAYS' => 'Posledn�ch 30 dn�',
  'LBL_NEXT_30_DAYS' => 'N�sleduj�c�ch 30 dn�',
  
  // Dashlet Categories
  'dashlet_categories_dom' => array(
      'Module Views' => 'Module Views',
      'Portal' => 'Portal',
      'Charts' => 'Charts',
      'Tools' => 'Tools',
      'Miscellaneous' => 'Miscellaneous'),
  'LBL_MAX_DASHLETS_REACHED' => 'You have reached the maximum number of dashlets your adminstrator has set. Please remove a dashlet to add more.',
  'LBL_ADDING_DASHLET' => 'P�id�v�m n�st�nku ...',
  'LBL_ADDED_DASHLET' => 'Dashlet Added',
  'LBL_REMOVE_DASHLET_CONFIRM' => 'Are you sure you want to remove the Dashlet?',
  'LBL_REMOVING_DASHLET' => 'Removing Dashlet ...',
  'LBL_REMOVED_DASHLET' => 'Dashlet Removed',
  'LBL_DASHLET_CONFIGURE_GENERAL' => 'General',
  'LBL_DASHLET_CONFIGURE_FILTERS' => 'Filters',
  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'My Items Only',
  'LBL_DASHLET_CONFIGURE_TITLE' => 'Title',
  'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Display Rows',
//  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'My Items Only',

  'LBL_TRAINING_TITLE' => 'Training',
  
  
);


?>
