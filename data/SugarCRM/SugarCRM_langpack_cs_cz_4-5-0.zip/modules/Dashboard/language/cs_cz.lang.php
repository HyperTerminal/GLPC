<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
    'LBL_MODULE_NAME' => 'Vývěska',
    'LBL_MODULE_TITLE' => 'Vývěska: Home',
    'LNK_NEW_ACCOUNT' => 'Vytvořit účet',
    'LNK_NEW_CALL' => 'Naplánovat telefonát',
    'LNK_NEW_CASE' => 'Vytvořit případ',
    'LNK_NEW_CONTACT' => 'Vytvořit kontakt',
    'LNK_NEW_ISSUE' => 'Reportovat bug',
    'LNK_NEW_LEAD' => 'Vytvořit iniciativu',
    'LNK_NEW_MEETING' => 'Naplánovat meeting',
    'LNK_NEW_NOTE' => 'Vytvořit poznámku nebo přílohu',
    'LNK_NEW_OPPORTUNITY' => 'Vytvořit příležitost',
    'LNK_NEW_QUOTE' => 'Vytvořit akcie',
    'LNK_NEW_TASK' => 'Vytvořit úkol',

	'LBL_ADD_A_CHART' => 'Přidat graf',
	'LBL_DELETE_FROM_DASHBOARD' => 'Vymazat z vývěsek',
	'LBL_MOVE_DOWN' => 'Posunout nahoru',
	'LBL_MOVE_UP' => 'Posunout dolu',
	'LBL_BASIC_CHARTS' => '-- Základní grafy --',
	'LBL_PUBLISHED_REPORTS' => '-- Celkové reporty týmu --',
	'LBL_MY_REPORTS' => '-- Mé uložené reporty --',
	'LBL_TEAM_REPORTS' => '-- Mé týmové reporty --',
  	'LBL_REPORT_NO_CHART' => 'Tento report nemá graf',
  	'LBL_MOVE_CHARTS' => '(Klikněte na jméno grafu k jeho přesunutí na jinou pozici)',
);


?>
