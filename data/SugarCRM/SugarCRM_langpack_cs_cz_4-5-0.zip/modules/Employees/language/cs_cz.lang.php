<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Zaměstnanci',
  'LBL_MODULE_TITLE' => 'Zaměstnanci: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Vyhledávání zaměstnance',
  'LBL_LIST_FORM_TITLE' => 'Zaměstnanci',
  'LBL_NEW_FORM_TITLE' => 'Nový zaměstnanec',
  'LBL_EMPLOYEE' => 'Zaměstnanci:',
  'LBL_LOGIN' => 'Přihlásit',
  'LBL_RESET_PREFERENCES' => 'Obnovit výchozí nastavení',
  'LBL_TIME_FORMAT' => 'Formát času:',
  'LBL_DATE_FORMAT' => 'Formát data:',
  'LBL_TIMEZONE' => 'aktiální čas:',
  'LBL_CURRENCY' => 'Měna:',
  'LBL_LIST_NAME' => 'Jméno',
  'LBL_LIST_LAST_NAME' => 'Přijmení',
  'LBL_LIST_EMPLOYEE_NAME' => 'Jméno zaměstnance',
  'LBL_LIST_DEPARTMENT' => 'Oddělení',
  'LBL_LIST_REPORTS_TO_NAME' => 'Nadřízený',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Hlavní telefon',
  'LBL_LIST_USER_NAME' => 'Uživatelské jméno',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Nový zaměstnanec [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Nový zaměstnanec',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Chyba:',
  'LBL_PASSWORD' => 'Heslo:',
  'LBL_EMPLOYEE_NAME' => 'Jméno zaměstnance:',
  'LBL_USER_NAME' => 'Uživatelské jméno:',
  'LBL_FIRST_NAME' => 'Jméno:',
  'LBL_LAST_NAME' => 'Přijmení:',
  'LBL_EMPLOYEE_SETTINGS' => 'Nastavení zaměstnance',
  'LBL_THEME' => 'Téma:',
  'LBL_LANGUAGE' => 'Jazyk:',
  'LBL_ADMIN' => 'Administrátor:',
  'LBL_EMPLOYEE_INFORMATION' => 'Informace o zaměstnanci',
  'LBL_OFFICE_PHONE' => 'Telefon do zaměstnání:',
  'LBL_REPORTS_TO' => 'Nadřízený:',
  'LBL_OTHER_PHONE' => 'Další:',
  'LBL_OTHER_EMAIL' => 'Další email:',
  'LBL_NOTES' => 'Poznámky:',
  'LBL_DEPARTMENT' => 'Oddělení:',
  'LBL_TITLE' => 'titul:',
  'LBL_ANY_PHONE' => 'Nějaký telefon:',
  'LBL_ANY_EMAIL' => 'Nějaký email:',
  'LBL_ADDRESS' => 'Adresa:',
  'LBL_CITY' => 'Město:',
  'LBL_STATE' => 'Stát:',
  'LBL_POSTAL_CODE' => 'PSČ:',
  'LBL_COUNTRY' => 'Země:',
  'LBL_NAME' => 'Jméno:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_OTHER' => 'Další:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Telefon domů:',
  'LBL_ADDRESS_INFORMATION' => 'Informace o adrese',
  'LBL_EMPLOYEE_STATUS' => 'Stav zaměstnance:',
  'LBL_PRIMARY_ADDRESS' => 'Hlavní adresa:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Vytvořit uživatele [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Vytvořit uživatele',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Oblíbená barva:',
  'LBL_MESSENGER_ID' => 'Jméno v IM:',
  'LBL_MESSENGER_TYPE' => 'Typ IM:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Zaměstnanec jménem ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' již existuje. Duplicitní jména zaměstnanců nejsou povolena. Změňte jméno zaměstnance tak, aby bylo jedinečné.',
  'ERR_LAST_ADMIN_1' => 'Zaměstnanec jménem "',
  'ERR_LAST_ADMIN_2' => '" je poslední zaměstnanec s administrátorským přístupem. Alespoň jeden musí být administrátor.',
  'LNK_NEW_EMPLOYEE' => 'Vytvořit zaměstnance',
  'LNK_EMPLOYEE_LIST' => 'Zaměstnanci',
  'ERR_DELETE_RECORD' => 'Musíte specifikovat číslo záznamu ke smazání účtu..',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Stav',

);


?>
