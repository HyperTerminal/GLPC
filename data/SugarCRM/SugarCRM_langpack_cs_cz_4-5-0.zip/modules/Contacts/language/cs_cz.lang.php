<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
********************************************************************************/
/*********************************************************************************

* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributor(s): ______________________________________..
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
    //END DON'T CONVERT



    'ERR_DELETE_RECORD' => 'Musíte určit císlo kontaktu pro jeho smazání.',
    'LBL_ACCOUNT_ID' => 'Účet ID:',
    'LBL_ACCOUNT_NAME' => 'Jméno účtu:',
    'LBL_CAMPAIGN'     => 'Kampaň:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivity',
    'LBL_ADD_BUSINESSCARD' => 'Vložit vizitku',
    'LBL_ADDMORE_BUSINESSCARD' => 'Přidat další vizitku',
    'LBL_ADDRESS_INFORMATION' => 'Informace o adrese',
    'LBL_ALT_ADDRESS_CITY' => 'Alternativní město:',
    'LBL_ALT_ADDRESS_COUNTRY' => 'Alternativní země:',
    'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternativní PSČ:',
    'LBL_ALT_ADDRESS_STATE' => 'Alternativní stát:',
    'LBL_ALT_ADDRESS_STREET_2' => 'Alternate Address Street 2:',
    'LBL_ALT_ADDRESS_STREET_3' => 'Alternate Address Street 3:',
    'LBL_ALT_ADDRESS_STREET' => 'Alternativní ulice:',
    'LBL_ALTERNATE_ADDRESS' => 'Další adresa:',
    'LBL_ANY_ADDRESS' => 'Any Address:',
    'LBL_ANY_EMAIL' => 'Any Email:',
    'LBL_ANY_PHONE' => 'Any Phone:',
    'LBL_ASSIGNED_TO_NAME' => 'Přiřazeno uživateli:',
    'LBL_ASSISTANT_PHONE' => 'Telefon na asistenta:',
    'LBL_ASSISTANT' => 'Asistent:',
    'LBL_BIRTHDATE' => 'Narození:',
    'LBL_BUSINESSCARD' => 'Vizitka',
    'LBL_CITY' => 'Město:',
    'LBL_CAMPAIGN_ID' => 'Kampaň ID',
    'LBL_CONTACT_INFORMATION' => 'Kontaktní informace',
    'LBL_CONTACT_NAME' => 'Jméno kontaktu:',
    'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakt-Příležitost:',
    'LBL_CONTACT_ROLE' => 'Role:',
    'LBL_CONTACT' => 'Kontakt:',
    'LBL_COUNTRY' => 'Země:',
    'LBL_CREATED_ACCOUNT' => 'Vytvořen nový účet',
    'LBL_CREATED_CALL' => 'Vytvořen nový telefonát',
    'LBL_CREATED_CONTACT' => 'Vytvřen nvý kontakt',
    'LBL_CREATED_MEETING' => 'Vytvořena nová schůzka',
    'LBL_CREATED_OPPORTUNITY' =>'Vytvořena nová příležitost',
    'LBL_DATE_MODIFIED' => 'Datum změny:',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kontakty',
    'LBL_DEPARTMENT' => 'Oddělení:',
    'LBL_DESCRIPTION_INFORMATION' => 'Další informace',
    'LBL_DESCRIPTION' => 'Popis:',
    'LBL_DIRECT_REPORTS_SUBPANEL_TITLE'=>'Direct Reports',
    'LBL_DO_NOT_CALL' => 'Nevolat:',
    'LBL_DUPLICATE' => 'Možný duplicitní kontakt',
    'LBL_EMAIL_ADDRESS' => 'Email:',
    'LBL_EMAIL_OPT_OUT' => 'Nezasílat email:',
    'LBL_EXISTING_ACCOUNT' => 'Použit existující účet',
    'LBL_EXISTING_CONTACT' => 'Použit existující kontakt',
    'LBL_EXISTING_OPPORTUNITY'=> 'Použita existující příležitost',
    'LBL_FAX_PHONE' => 'Fax:',
    'LBL_FIRST_NAME' => 'Jméno:',
    'LBL_FULL_NAME' => 'Celé jméno:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
    'LBL_HOME_PHONE' => 'Telefon domů:',
    'LBL_ID' => 'ID:',
    'LBL_IMPORT_VCARD' => 'Vložit vCard',
    'LBL_IMPORT_VCARDTEXT' => 'Automaticky vytvořit nový kontakt vložením vCard z vašeho file systému.',
    'LBL_INVALID_EMAIL'=>'Nefunkční email:',
    'LBL_INVITEE' => 'Direct Reports',
    'LBL_LAST_NAME' => 'Příjmení:',
    'LBL_LEAD_SOURCE' => 'Lead Source:',
    'LBL_LIST_ACCEPT_STATUS' => 'Accept Status',
    'LBL_LIST_ACCOUNT_NAME' => 'Jméno účtu',
    'LBL_LIST_CONTACT_NAME' => 'Jméno kontaktu',
    'LBL_LIST_CONTACT_ROLE' => 'Role',
    'LBL_LIST_EMAIL_ADDRESS' => 'Email',
    'LBL_LIST_FIRST_NAME' => 'Jméno',
    'LBL_LIST_FORM_TITLE' => 'Seznam kontaktů',
    'LBL_VIEW_FORM_TITLE' => 'Kontakt View',
    'LBL_LIST_LAST_NAME' => 'Příjmení',
    'LBL_LIST_NAME' => 'Jméno',
    'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Další email',
    'LBL_LIST_PHONE' => 'Telefon do kanceláře',
    'LBL_LIST_TITLE' => 'Titul:',
    'LBL_MOBILE_PHONE' => 'Mobil:',
    'LBL_MODIFIED' => 'Změněno uživatelem ID:',
    'LBL_MODULE_NAME' => 'Kontakty',
    'LBL_MODULE_TITLE' => 'Kontakty: Home',
    'LBL_NAME' => 'Jméno:',
    'LBL_NEW_FORM_TITLE' => 'Nový kontakt',
    'LBL_NEW_PORTAL_PASSWORD' => 'New Portal Password:',
    'LBL_NOTE_SUBJECT' =>'Poznámka předmětu',
    'LBL_OFFICE_PHONE' => 'Telefon do konceláře:',
    'LBL_OPP_NAME' => 'Jméno příležitost:',
    'LBL_OPPORTUNITY_ROLE_ID'=>'Opportunity Role ID:',
    'LBL_OPPORTUNITY_ROLE'=>'Opportunity Role',
    'LBL_OTHER_EMAIL_ADDRESS' => 'Jiný Email:',
    'LBL_OTHER_PHONE' => 'Jiný Telefon:',
    'LBL_PHONE' => 'Telefon:',
    'LBL_PORTAL_ACTIVE' => 'Aktivní potál:',
    'LBL_PORTAL_APP'=>'Portal Application:',
    'LBL_PORTAL_INFORMATION' => 'Portal Information',
    'LBL_PORTAL_NAME' => 'Jméno portálu:',
    'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Password Is Set:',
    'LBL_POSTAL_CODE' => 'PSČ:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Primary Address City:',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Primary Address Postal Code:',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Primary Address State:',
    'LBL_PRIMARY_ADDRESS_STREET_2' => 'Primary Address Street 2:',
    'LBL_PRIMARY_ADDRESS_STREET_3' => 'Primary Address Street 3:',
    'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Address Street:',
    'LBL_PRIMARY_ADDRESS' => 'Hlanví Address:',
    'LBL_PRODUCTS_TITLE'=>'Produkty',
    'LBL_RELATED_CONTACTS_TITLE'=>'Související kontakty',
    'LBL_REPORTS_TO_ID'=>'Reports to ID:',
    'LBL_REPORTS_TO' => 'Nadřízený:',
    'LBL_SALUTATION' => 'Oslovení:',
    'LBL_SAVE_CONTACT' => 'Uložit kontakt',
    'LBL_SEARCH_FORM_TITLE' => 'Hledat kontakt',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Vybrat označené kontakty',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Vybrat označené kontakty',
    'LBL_STATE' => 'Stát:',
    'LBL_SYNC_CONTACT' => 'Synchronizovat s Outlook&reg;:',
    'LBL_TEAM_ID' => 'Team ID:',
    'LBL_TITLE' => 'Titul:',
    'LNK_CONTACT_LIST' => 'Kontakty',
    'LNK_IMPORT_VCARD' => 'Vytvořit kontakt z vCard',
    'LNK_NEW_ACCOUNT' => 'Vytvořit účet',
    'LNK_NEW_APPOINTMENT' => 'Vytvořit schůzku',
    'LNK_NEW_CALL' => 'Naplánvat telefonát',
    'LNK_NEW_CASE' => 'Vytvořit případ',
    'LNK_NEW_CONTACT' => 'Vytvořit kontakt',
    'LNK_NEW_EMAIL' => 'Archive Email',
    'LNK_NEW_MEETING' => 'Naplánvat meeting',
    'LNK_NEW_NOTE' => 'Vytvořit poznámku',
    'LNK_NEW_OPPORTUNITY' => 'Vytvořit příležitost',
    'LNK_NEW_TASK' => 'Vytvořit úkol',
    'LNK_SELECT_ACCOUNT' => "Vybrat účet",
    'MSG_DUPLICATE' => 'Creating this contact may potentially create a duplicate contact. You may either select a contact from the list below or you may click on Save to continue creating a new contact with the previously entered data.',
    'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentially create a duplicate contact. You may either click on Save to continue creating this new contact with the previously entered data or you may click Cancel.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Překopírovat alternativní adresu do hlavní',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Překopírovat hlavní adresu do alternativní',
    'NTC_DELETE_CONFIRMATION' => 'Jste si jisti, že chte smazat tento záznam?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Vytvoření příležitosti vyaduje účet.\n Prosím vyberte již existující účet.',
    'NTC_REMOVE_CONFIRMATION' => 'Jste si jisti, že chcete odebrat kontakt od tohoto případu?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Jste si jisti, že chcete odebrat tento záznam od direct report?',

	'LBL_USER_PASSWORD' => 'Heslo:',

	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Příležitosti',




	'LBL_CASES_SUBPANEL_TITLE' => 'Případy',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Bugy',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekty',
	'LBL_COPY_ADDRESS_CHECKED' => 'Zkopírovat adresu do označeného kontaktu',
	'LBL_TARGET_OF_CAMPAIGNS' => 'Kampaně (Cíle.. ) :',
	'LBL_CAMPAIGNS'	=>	'Kampaně',
	'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Záznam kampaně',
	'LBL_LIST_CITY' => 'Město',
	'LBL_LIST_STATE' => 'Stát',
	'LBL_HOMEPAGE_TITLE' => 'Moje kontakty',





)
?>
