<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aktivity',
  'LBL_MODULE_TITLE' => 'Aktivity: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Hledání aktivit',
  'LBL_LIST_FORM_TITLE' => 'Seznam aktivit',
  'LBL_LIST_SUBJECT' => 'Předmět',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Vztahuje se k',
  'LBL_LIST_DATE' => 'Datum',
  'LBL_LIST_TIME' => 'Čas začátku',
  'LBL_LIST_CLOSE' => 'Zavřeno',
  'LBL_SUBJECT' => 'Předmět:',
  'LBL_STATUS' => 'Stav:',
  'LBL_LOCATION' => 'Umístění:',
  'LBL_DATE_TIME' => 'Datum začátku & Čas:',
  'LBL_DATE' => 'Datum začátku:',
  'LBL_TIME' => 'Čas začátku:',
  'LBL_DURATION' => 'Doba trvání:',
  'LBL_HOURS_MINS' => '(hodiny-minuty)',
  'LBL_CONTACT_NAME' => 'Kontaktní jméno: ',
  'LBL_MEETING' => 'Meeting:',
  'LBL_DESCRIPTION_INFORMATION' => 'Poppisující informace',
  'LBL_DESCRIPTION' => 'Popis:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Plánováno',
  'LNK_NEW_CALL' => 'Naplánovat telefonát',
  'LNK_NEW_MEETING' => 'Naplánovat meeting',
  'LNK_NEW_TASK' => 'Vytvořit úkol',
  'LNK_NEW_NOTE' => 'Vytvořit poznámku/přílohu',
  'LNK_NEW_EMAIL' => 'Vytvořit email',
  'LNK_CALL_LIST' => 'Telefonáty',
  'LNK_MEETING_LIST' => 'Meetingy',
  'LNK_TASK_LIST' => 'Úkoly',
  'LNK_NOTE_LIST' => 'Poznámky',
  'LNK_EMAIL_LIST' => 'Emaily',
  'ERR_DELETE_RECORD' => 'Ke smazání učtu je potřeba jeho ID.',
  'NTC_REMOVE_INVITEE' => 'Jste si jisti, že chcete odebrat tohoto pozvaného z meetingu?',
  'LBL_INVITEE' => 'Přizvaní',
  'LBL_LIST_DIRECTION' => 'Direction',
  'LBL_DIRECTION' => 'Direction',
  'LNK_NEW_APPOINTMENT' => 'Nová schůzka',
  'LNK_VIEW_CALENDAR' => 'Dnes',
  'LBL_OPEN_ACTIVITIES' => 'Otevřené aktivity',
  'LBL_HISTORY' => 'Historie',
  'LBL_UPCOMING' => 'Mé nadcházející schůzky',
  'LBL_TODAY' => 'skrz ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Vytvořit úkol [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Vytvořit úkol',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Naplánovat Meeting [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Naplánovat Meeting',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Naplánovat telefonát [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Naplánovat telefonát',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Vytvořit poznámku nebo přílohu [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Vytvořit poznámku nebo přílohu',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archivovat email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Archivovat email',
  'LBL_LIST_STATUS' => 'Stav',
  'LBL_LIST_DUE_DATE' => 'Do data',
  'LBL_LIST_LAST_MODIFIED' => 'Poslední změny',
  'NTC_NONE_SCHEDULED' => 'Nic není plánováno.',
  'appointment_filter_dom' => array(
  	 'today' => 'dnes'
  	,'tomorrow' => 'zítra'
  	,'this Saturday' => 'tento týden'
  	,'next Saturday' => 'příští týden'
  	,'last this_month' => 'tento měsíc'
  	,'last next_month' => 'příští měsíc'
  ),
  'LNK_IMPORT_NOTES'=>'Importovat poznámky',
  'NTC_NONE'=>'Nic',
	'LBL_ACCEPT_THIS'=>'Akceptovat?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Otevřené aktivity',
   'LBL_LIST_ASSIGNED_TO_NAME' => 'Přiřazený uživatel',
);


?>
