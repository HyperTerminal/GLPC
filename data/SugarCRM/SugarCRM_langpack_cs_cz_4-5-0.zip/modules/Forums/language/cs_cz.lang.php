<?php

$mod_strings = array (
	'LBL_MODULE_NAME'=>'Fóra',
	'LBL_MODULE_TITLE'=>'Fóra: Home',
	'LBL_ID' => 'Forum ID',
	'LBL_DATE_ENTERED'=>'Datum vytvoření',
	'LBL_CREATED_BY'=>'Vytvořil(a)',
	'LBL_DATE_MODIFIED'=>'Datum změny',
	'LBL_MODIFIED_USER_ID'=>'Modifikoval(a)',
	'LBL_DELETED'=>'Smazáno',
	'LBL_TITLE'=>'Název',
    'LBL_DESCRIPTION'=>'Popis',
  'LNK_NEW_FORUM' => 'Vytvořit forum',
  'LNK_FORUM_LIST' => 'Fóra',
  'LNK_THREAD_LIST' => 'Vlánka',
  'LBL_CREATE_THREAD' => 'Vytvořit nové vlákno',
	'LBL_DEFAULT_SUBPANEL_TITLE'=>'Fóra',
	'LBL_LIST_FORM_TITLE' => 'Seznam fór',
  'LBL_SEARCH_FORM_TITLE' => 'Vyhledat',
  'LBL_THREADS_SUBPANEL_TITLE' => 'Vlákna',
  'LBL_LAST_POST_TIME' => 'Čas odeslání',
  'LBL_RECENT_THREAD_TITLE' => 'Poslední vlákno',
  'LBL_RECENT_THREAD_MODIFIED_NAME' => 'Zaslal(a)',
  'LBL_THREAD_COUNT' => 'Vlákna',
  'LBL_POST_COUNT' => 'Příspěvky',
  'LBL_CATEGORY' => 'Téma',
  'LBL_CATEGORY_RANKING' => 'Pozice támatu',
  'LBL_CONFIG_TITLE' => 'Nastavení fóra',



  'LBL_FORUM_SEARCH_RESULTS' => 'Výsledek hledání ve vláknech-fórech',
  'ERR_ONE_CHAR' => 'Pro vyhledávání prosím zadejte alespoň jeden znak nebo číslici...',
  'LBL_FORUM_SEARCH_HEADER' => 'Vyhledávání ve fórech:',
  'LBL_THREAD_SEARCH_TITLE' => 'Název:',
  'LBL_THREAD_SEARCH_BODY' => 'Tělo:',
  'LBL_THREAD_SEARCH_USER' => 'Uživatel:',
  'LBL_NO_FORUMS' => 'Není zdé žádné fórum k zobrazení.',
  'LBL_CREATE_FORUM_TOPIC' => 'Vytvořit nové téma',
  'MSG_CREATE_FORUM_TOPIC' => 'Před vytvořením fóra prosím vytvořte téma.',
);


?>
