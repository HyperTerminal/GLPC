<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Úkoly',
  'LBL_TASK' => 'Úkoly: ',
  'LBL_MODULE_TITLE' => ' Úkoly: Home',
  'LBL_SEARCH_FORM_TITLE' => ' Úkoly Vyhledávání',
  'LBL_LIST_FORM_TITLE' => ' Úkoly Seznam',
  'LBL_NEW_FORM_TITLE' => ' Vytvořit úkol',
  'LBL_NEW_FORM_SUBJECT' => 'Předmět:',
  'LBL_NEW_FORM_DUE_DATE' => 'Do Data:',
  'LBL_NEW_FORM_DUE_TIME' => 'Do času:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Zavřít',
  'LBL_LIST_SUBJECT' => 'Předmět',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_PRIORITY' => 'Priorita',
  'LBL_LIST_RELATED_TO' => 'Váže se k',
  'LBL_LIST_DUE_DATE' => 'Do data',
  'LBL_LIST_DUE_TIME' => 'Do času',
  'LBL_SUBJECT' => 'Předmět:',
  'LBL_STATUS' => 'Status:',
  'LBL_DUE_DATE' => 'Do data:',
  'LBL_DUE_TIME' => 'Do času:',
  'LBL_PRIORITY' => 'Priorita:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Do data & času:',
  'LBL_START_DATE_AND_TIME' => 'Datum & Čas začátku:',
  'LBL_START_DATE' => 'Datum začátku:',
  'LBL_LIST_START_DATE' => 'Datum začátku',
  'LBL_START_TIME' => 'Čas začátku:',
  'LBL_LIST_START_TIME' => 'Čas začátku',  
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'Žádný',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Popisující informace',
  'LBL_DESCRIPTION' => 'Popis:',
  'LBL_NAME' => 'Jméno:',
  'LBL_CONTACT_NAME' => 'Kontaktní jméno: ',
  'LBL_LIST_COMPLETE' => 'Kompletní:',
  'LBL_LIST_STATUS' => 'Stav',
  'LBL_DATE_DUE_FLAG' => 'No Due Date',
  'LBL_DATE_START_FLAG' => 'No Start Date',
  'ERR_DELETE_RECORD' => 'Ke smazání kontaktu je potřeba specifikovat jeho ID.',
  'ERR_INVALID_HOUR' => 'Prosím vložte hodinu mezi 0 a 24',
  'LBL_DEFAULT_STATUS' => 'Nezačato',
  'LBL_DEFAULT_PRIORITY' => 'Střední',
  'LBL_LIST_MY_TASKS' => 'Moje otevřené úkoly',
  'LNK_NEW_CALL' => 'Naplánovat zavolání',
  'LNK_NEW_MEETING' => 'Naplánovat Meeting',
  'LNK_NEW_TASK' => 'Vytvořit úkol',
  'LNK_NEW_NOTE' => 'Vytvořit poznámku nebo přílohu',
  'LNK_NEW_EMAIL' => 'Archivuj Email',
  'LNK_CALL_LIST' => 'Hovory',
  'LNK_MEETING_LIST' => 'Meetingy',
  'LNK_TASK_LIST' => 'Úkoly',
  'LNK_NOTE_LIST' => 'Poznámky',
  'LNK_EMAIL_LIST' => 'Emaily',
  'LNK_VIEW_CALENDAR' => 'Dnes',
  'LBL_CONTACT_FIRST_NAME'=>'Kontakt jméno',
  'LBL_CONTACT_LAST_NAME'=>'Kontakt příjmení',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Přiřazený uživatel',

);


?>
