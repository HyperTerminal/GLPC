<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Default English language strings
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */



$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projekty',
	'LBL_MODULE_TITLE' => 'Projekty: Home',
	'LBL_SEARCH_FORM_TITLE' => 'Najít projekt',
    'LBL_LIST_FORM_TITLE' => 'Seznam projektů',
    'LBL_HISTORY_TITLE' => 'Historie',

	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Datum vložení:',
	'LBL_DATE_MODIFIED' => 'Datum změny:',
	'LBL_ASSIGNED_USER_ID' => 'Přiřazeno uživateli:',
	'LBL_MODIFIED_USER_ID' => 'Změněno uživatelem Id:',
	'LBL_CREATED_BY' => 'Vytvořeno kým:',
	'LBL_TEAM_ID' => 'Tým:',
	'LBL_NAME' => 'Jméno:',
	'LBL_DESCRIPTION' => 'Popis:',
	'LBL_DELETED' => 'Smazáno:',

	'LBL_TOTAL_ESTIMATED_EFFORT' => 'Celkový odhadovaný počet hodin:',
	'LBL_TOTAL_ACTUAL_EFFORT' => 'Celkový aktuální počet hodin:',

	'LBL_LIST_NAME' => 'Jméno',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Přiřazeno uživateli',
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Celkový odhadovaný počet hodin',
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Celkový aktuální počet hodin',

	'LBL_PROJECT_SUBPANEL_TITLE' => 'Projekty',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Úkol projektu',
	'LBL_CONTACT_SUBPANEL_TITLE' => 'Kontakty',
	'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Účty',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Příležitosti',
	'LBL_QUOTE_SUBPANEL_TITLE' => 'Akcie',

	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Jste si jistí, že chcete odstranit tento kontakt z tohoto projektu?',
	
	'LNK_NEW_PROJECT'	=> 'Vytvořit projekt',
	'LNK_PROJECT_LIST'	=> 'Výpis projektů',
	'LNK_NEW_PROJECT_TASK'	=> 'Vytvořit úkol k projektu',
	'LNK_PROJECT_TASK_LIST'	=> 'Úkoly projektu',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projekty',
	'LBL_ACTIVITIES_TITLE'=>'Aktivity',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivity',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
	'LBL_QUICK_NEW_PROJECT'	=> 'Nový projekt',
	
	'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Úkoly projektů',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakty',
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Účty',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Příležitosti',



);
?>
