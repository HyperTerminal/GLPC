<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Default English language strings
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */



$mod_strings = array (
	'LBL_MODULE_NAME' => 'Úkol projektu',
	'LBL_MODULE_TITLE' => 'Úkol projektu: Home',
	'LBL_SEARCH_FORM_TITLE' => 'Úkol projektu Vyhledávání',
	'LBL_LIST_FORM_TITLE'=> 'Úkoly projektu',
	
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Datum vložení:',
	'LBL_DATE_MODIFIED' => 'Datum změny:',
	'LBL_ASSIGNED_USER_ID' => 'Přiřazeno k:',
	'LBL_MODIFIED_USER_ID' => 'Změněno uživtelem Id:',
	'LBL_CREATED_BY' => 'Vytvořeno kým:',
	'LBL_TEAM_ID' => 'Tým:',
	'LBL_NAME' => 'Jméno:',
	'LBL_STATUS' => 'Stav:',
	'LBL_DATE_DUE' => 'Do data:',
	'LBL_TIME_DUE' => 'Do času:',
	'LBL_DATE_START' => 'Datum začátku:',
	'LBL_TIME_START' => 'Čas začátku:',
	'LBL_PARENT_ID' => 'Projekt:',
	'LBL_PRIORITY' => 'Priorita:',
	'LBL_DESCRIPTION' => 'Popis:',
	'LBL_ORDER_NUMBER' => 'Pořadí:',
	'LBL_TASK_NUMBER' => 'Číslo úkolu:',
	'LBL_DEPENDS_ON_ID' => 'Závisí na:',
	'LBL_MILESTONE_FLAG' => 'Milník:',
	'LBL_ESTIMATED_EFFORT' => 'Odhadovaný čás práce (hodiny):',
	'LBL_ACTUAL_EFFORT' => 'Aktuální čas práce (hodiny):',
	'LBL_UTILIZATION' => 'Vytížení (%):',
	'LBL_PERCENT_COMPLETE' => 'Průběh (%):',
	'LBL_DELETED' => 'Smazáno:',

	'LBL_LIST_ORDER_NUMBER' => 'Pořadí',
	'LBL_LIST_NAME' => 'Jméno',
	'LBL_LIST_PARENT_NAME' => 'Projekt',
	'LBL_LIST_PERCENT_COMPLETE' => 'Průběh (%)',
	'LBL_LIST_STATUS' => 'Stav',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Přiřazeno k',
	'LBL_LIST_DATE_DUE' => 'Do data',
	'LBL_LIST_DATE_START' => 'Datum začátku',
	'LBL_LIST_PRIORITY' => 'Priorita',
	'LBL_LIST_CLOSE' => 'Zavřít',
	'LBL_PROJECT_NAME' => 'Jméno projektu',

	'LNK_NEW_PROJECT'	=> 'Vytvořit projekt',
	'LNK_PROJECT_LIST'	=> 'Seznam projektů',
	'LNK_NEW_PROJECT_TASK'	=> 'Vytvořit úkol projektu',
	'LNK_PROJECT_TASK_LIST'	=> 'Úkol projektu',
	
	'LBL_LIST_MY_PROJECT_TASKS' => 'Moje otevřené úkoly projektu',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Úkoly projektu',
	'LBL_NEW_FORM_TITLE' => 'Nový úkol projektu',

	'LBL_ACTIVITIES_TITLE'=>'Aktivity',
	'LBL_HISTORY_TITLE'=>'Historie',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivity',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie', 
	'DATE_JS_ERROR' => 'Prosím vložte datum odpovídající vloženému času.',
);
?>
