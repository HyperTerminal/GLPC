<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'language_pack_name' => 'Česky',
  'moduleList' =>
  array (
    'Home' => 'Home',
    'Dashboard' => 'Nástěnka',
    'Contacts' => 'Kontakty',
    'Accounts' => 'Účty',
    'Opportunities' => 'Příležitosti',
    'Cases' => 'Případy',
    'Notes' => 'Poznámky',
    'Calls' => 'Telefonáty',
    'Emails' => 'Emaily',
    'Meetings' => 'Meetingy',
    'Tasks' => 'Úkoly',
    'Calendar' => 'Kalendář',
    'Leads' => 'Iniciativy',
    'Activities' => 'Akce',
    'Bugs' => 'Bugy',
    'Feeds' => 'RSS',
    'iFrames'=>'Můj portál',
    'TimePeriods'=>'Časové periody',
    'Project'=>'Projekty',
    'ProjectTask'=>'Úkoly projektů',
    'Campaigns'=>'Kampaně',
    'Documents'=>'Dokumenty',
    'Sync'=>'Synchronizace',
    'Users' => 'Uživatelé',
    'Releases' => 'Vydání',    
    'Prospects' => 'Cíle',
    'Queues' => 'Fronty',
    'EmailMarketing' => 'Email Marketing',
    'EmailTemplates' => 'Emailové vzory',
    'ProspectLists' => 'Seznam cílů',
    'SavedSearch' => 'Uložená hledání',
        ),

  'moduleListSingular' =>
  array (
    'Home' => 'Home',
    'Dashboard' => 'Nástěnka',
    'Contacts' => 'Kontakt',
    'Accounts' => 'Účet',
    'Opportunities' => 'Příležitost',
    'Cases' => 'Případ',
    'Notes' => 'Poznámka',
    'Calls' => 'Telefonát',
    'Emails' => 'Email',
    'Meetings' => 'Schůzka',
    'Tasks' => 'Úloha',
    'Calendar' => 'Kalendář',
    'Leads' => 'Iniciativa',
    'Activities' => 'Akce',
    'Bugs' => 'Bug Tracker',
    'Feeds' => 'RSS',
    'iFrames'=>'Můj portál',
    'TimePeriods'=>'Časová perioda',
    'Project'=>'Projekt',
    'ProjectTask'=>'Úkol projektu',
    'Campaigns'=>'Kampaň',
    'Documents'=>'Dokument',
    'Sync'=>'Synchronizace',
    'Users' => 'Uživatel'
        ),        

  'checkbox_dom'=> array(
  	''=>'',
  	'1'=>'Ano',
  	'2'=>'Ne',
  ),
          
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' =>
  array (
    '' => '',
    'Analyst' => 'Analityk',
    'Competitor' => 'Soutěžící',
    'Customer' => 'Zákazník',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Tisk',
    'Prospect' => 'Prospect',
    'Reseller' => 'Prodejce',
    'Other' => 'Jiný',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' =>
  array (
    '' => '',
    'Apparel' => 'Oďevy',
    'Banking' => 'Banka',
    'Biotechnology' => 'Biotechnologie',
    'Chemicals' => 'Chemikálie',
    'Communications' => 'Komunikace',
    'Construction' => 'Stavebnictví',
    'Consulting' => 'Konzultace',
    'Education' => 'Vzděláni',
    'Electronics' => 'Elektronika',
    'Energy' => 'Energie',
    'Engineering' => 'Strojírenství',
    'Entertainment' => 'Zábava',
    'Environmental' => 'Životní prostředí',
    'Finance' => 'Finance',
    'Government' => 'Vláda',
    'Healthcare' => 'Zdravotnictví',
    'Hospitality' => 'Služby',
    'Insurance' => 'Pojišťovna',
    'Machinery' => 'Strojní',
    'Manufacturing' => 'Manufaktura',
    'Media' => 'Media',
    'Not For Profit' => 'Neziskový',
    'Recreation' => 'Rekreace',
    'Retail' => 'Prodej',
    'Shipping' => 'Expedice',
    'Technology' => 'Výroba',
    'Telecommunications' => 'Telekomunikace',
    'Transportation' => 'Přeprava',
    'Utilities' => 'Pomůcky',
    'Other' => 'Jiné',
  ),
  'source_default_key' => 'Vlastní',
  'lead_source_dom' =>
  array (
    '' => '',
    'Cold Call' => 'Studený vztah',
    'Existing Customer' => 'Existující zákazník',
    'Self Generated' => 'Vlastní',
    'Employee' => 'Zaměstnanec',
    'Partner' => 'Partner',
    'Public Relations' => 'Mluvčí',
    'Direct Mail' => 'Přímý email',
    'Conference' => 'Konference',
    'Trade Show' => 'Obchodní výstava',
    'Web Site' => 'Webová stránka',
    'Word of mouth' => 'Ústní dohoda',
    'Email' => 'Email',
    'Campaign'=>'Kampaň',
    'Other' => 'Jiný',
  ),
  'opportunity_type_dom' =>
  array (
    '' => '',
    'Existing Business' => 'Existující obchod',
    'New Business' => 'Nový obchod',
  ),
  'roi_type_dom' =>
    array (
    'Revenue' => 'Příjem',
    'Investment'=>'Investice',
    'Expected_Revenue'=>'Předpokládaný příjem',
    'Budget'=>'Rozpočet',
       
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Hlavní rozhodující',
  'opportunity_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Hlavní rozhodující',
    'Business Decision Maker' => 'Business Decision Maker',
    'Business Evaluator' => 'Obchodní odhadce',
    'Technical Decision Maker' => 'Technický rozhodující',
    'Technical Evaluator' => 'Technický poradce',
    'Executive Sponsor' => 'Provádějící sponzor',
    'Influencer' => 'Vlivný',
    'Other' => 'Jiný',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Hlavní kontakt',
  'case_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Contact' => 'Hlavní kontakt',
    'Alternate Contact' => 'Alternativní kontakt',
  ),
  'payment_terms' =>
  array (
  	'' => '', 
	'Net 15' => 'Net 15',
	'Net 30' => 'Net 30',
  ),  
  'sales_stage_default_key' => 'Prosperující',
  'sales_stage_dom' =>
  array (
    'Prospecting' => 'Prosperující',
    'Qualification' => 'S výhradami',
    'Needs Analysis' => 'Nutná analýza',
    'Value Proposition' => 'Významná nabídka',
    'Id. Decision Makers' => 'Id. Decision Makers',
    'Perception Analysis' => 'Perception Analysis',
    'Proposal/Price Quote' => 'Návrh/Cena akcie',
    'Negotiation/Review' => 'Dojednávávní/Posuzování',
    'Closed Won' => 'Blízká výhra',
    'Closed Lost' => 'Blízká prohra',
  ),
  'sales_probability_dom' => // keys must be the same as sales_stage_dom
  array (
    'Prospecting' => '10',
    'Qualification' => '20',
    'Needs Analysis' => '25',
    'Value Proposition' => '30',
    'Id. Decision Makers' => '40',
    'Perception Analysis' => '50',
    'Proposal/Price Quote' => '65',
    'Negotiation/Review' => '80',
    'Closed Won' => '100',
    'Closed Lost' => '0',
  ),
  'activity_dom' =>
  array (
    'Call' => 'Telefonát',
    'Meeting' => 'Schůzka',
    'Task' => 'Úkol',
    'Email' => 'Email',
    'Note' => 'Poznámka',
  ),
  'salutation_dom' =>
	  array (
	    '' => '',
	    'Mr.' => 'p.',
	    'Ms.' => 'sl.',
	    'Mrs.' => 'pí.',
	    'Dr.' => 'Dr.',
	    'Prof.' => 'Prof.',
	  ),
  //time is in seconds; the greater the time the longer it takes;
  'reminder_max_time'=>3600,
  'reminder_time_options' => array( 60=> '1 minutu předem',
  								  300=> '5 minut předem',
  								  600=> '10 minut předem',
  								  900=> '15 minut předem',
  								  1800=> '30 minut předem',
  								  3600=> '1 hodinu předem',
								 ),

  'task_priority_default' => 'Střední',
  'task_priority_dom' =>
  array (
    'High' => 'Vysoká',
    'Medium' => 'Střední',
    'Low' => 'Nízká',
  ),
  'task_status_default' => 'Nezačal',
  'task_status_dom' =>
  array (
    'Not Started' => 'Nezačal',
    'In Progress' => 'Probíhá',
    'Completed' => 'Kompletní',
    'Pending Input' => 'Čeká na vstup',
    'Deferred' => 'Odloženo',
  ),
  'meeting_status_default' => 'Plánováno',
  'meeting_status_dom' =>
  array (
    'Planned' => 'Plánováno',
    'Held' => 'Uskutečněno',
    'Not Held' => 'Neuskutečněno',
  ),
  'call_status_default' => 'Plánován',
  'call_status_dom' =>
  array (
    'Planned' => 'Plánován',
    'Held' => 'Uskutečněn',
    'Not Held' => 'Neuskutečněn',
  ),
  'call_direction_default' => 'Odchozí',
  'call_direction_dom' =>
  array (
    'Inbound' => 'Příchozí',
    'Outbound' => 'Odchozí',
  ),
  'lead_status_dom' =>
  array (
    '' => '',
    'New' => 'Nový',
    'Assigned' => 'Přiřazený',
    'In Process' => 'Probíhá',
    'Converted' => 'Převedený',
    'Recycled' => 'Obnovený',
    'Dead' => 'Mrtvý',
  ),
  'lead_status_noblank_dom' =>
  array (
    'New' => 'Nový',
    'Assigned' => 'Přiřazený',
    'In Process' => 'Probíhá',
    'Converted' => 'Převedený',
    'Recycled' => 'Obnovený',
    'Dead' => 'Mrtvý',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'Nový',
  'case_status_dom' =>
  array (
    'New' => 'Nový',
    'Assigned' => 'Přiřazen',
    'Closed' => 'Uzavřen',
    'Pending Input' => 'Čeká na vstup',
    'Rejected' => 'Odmítnut',
    'Duplicate' => 'Duplicitní',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' =>
  array (
    'P1' => 'Vysoká',
    'P2' => 'Střední',
    'P3' => 'Nízká',
  ),
  'user_status_dom' =>
  array (
    'Active' => 'Aktivní',
    'Inactive' => 'Nektivní',
  ),
  'employee_status_dom' =>
  array (
    'Active' => 'Aktivní',
    'Terminated' => 'Odešel',
    'Leave of Absence' => 'Vynechání docházky',
  ),
  'messenger_type_dom' =>
  array (
    '' => '',
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
    'AOL' => 'AOL',
    'ICQ' => 'ICQ',
    'Jabber' => 'Jabber',
  ),

	'project_task_priority_options' => array (
		'High' => 'Vysoká',
		'Medium' => 'Střední',
		'Low' => 'Nízká',
	),
	'project_task_status_options' => array (
		'Not Started' => 'Nezačal',
		'In Progress' => 'Probíhá',
		'Completed' => 'Kompletní',
		'Pending Input' => 'Čeká na vstup',
		'Deferred' => 'Odložený',
	),
	'project_task_utilization_options' => array (
		'0' => 'zádná',
		'25' => '25',
		'50' => '50',
		'75' => '75',
		'100' => '100',
	),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Účet',
  'record_type_display' =>
  array (
    '' => '',
    'Accounts' => 'Účet',
    'Opportunities' => 'Příležitost',
    'Cases' => 'Případ',
    'Leads' => 'Lead',
    'Contacts' => 'Kontakty', // cn (11/22/2005) added to support Emails




    'Bugs' => 'Bug',
    'Project' => 'Projekt',



    'ProjectTask' => 'Úkol projektu',
    'Tasks' => 'Úkol',
    'Prospects' => 'Vyhlídka (šance)',
  ),

  'record_type_display_notes' =>
  array (
    'Accounts' => 'Účet',
	'Contacts' => 'Kontakt',
    'Opportunities' => 'Příležitost',
    'Cases' => 'Případ',
    'Leads' => 'Lead',






    'Bugs' => 'Bug',
    'Emails' => 'Email',
    'Project' => 'Projekt',
    'ProjectTask' => 'Úloha projektu',
    'Meetings' => 'Meeting',
    'Calls' => 'Telefonát'
  ),


	
  'quote_type_dom' =>
  array (
    'Quotes' => 'Quote',
    'Orders' => 'Order',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' =>
  array (
    'Draft' => 'Draft',
    'Negotiation' => 'Dohodnuto',
    'Delivered' => 'Doručeno',
    'On Hold' => 'Vyčkávání',
    'Confirmed' => 'Potvrzeno',
    'Closed Accepted' => 'Uzavřeno akceptováno',
    'Closed Lost' => 'Uzavřeno ztraceno',
    'Closed Dead' => 'Uzavřeno mrtvé',
  ),
  'default_order_stage_key' => 'Probíhá',
  'order_stage_dom' =>
  array (
    'Pending' => 'Probíhá',
    'Confirmed' => 'Potvrzena',
    'On Hold' => 'Právě probíhá',
    'Shipped' => 'Posláno',
    'Cancelled' => 'Zrušeno',
  ),

//Note:  do not translate quote_relationship_type_default_key
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Primary Decision Maker',
    'Business Decision Maker' => 'Business Decision Maker',
    'Business Evaluator' => 'Business Evaluator',
    'Technical Decision Maker' => 'Technical Decision Maker',
    'Technical Evaluator' => 'Technical Evaluator',
    'Executive Sponsor' => 'Executive Sponsor',
    'Influencer' => 'Influencer',
    'Other' => 'Other',
  ),
  'layouts_dom' =>
  array (
    'Standard' => 'Nabídka',
    'Invoice' => 'Faktura',
    'Terms' => 'Termíny splátek'
  ),

  'bug_priority_default_key' => 'Střední',
  'bug_priority_dom' =>
  array (
    'Urgent' => 'Urgentní',
    'High' => 'Vysoká',
    'Medium' => 'Střední',
    'Low' => 'Nízká',
  ),
   'bug_resolution_default_key' => '',
  'bug_resolution_dom' =>
  array (
  	'' => '',
  	'Accepted' => 'Akceptován',
    'Duplicate' => 'Duplicitní',
    'Fixed' => 'Opraven',
    'Out of Date' => 'Zastaralý',
    'Invalid' => 'Špatný',
    'Later' => 'Později',
  ),
  'bug_status_default_key' => 'Nový',
  'bug_status_dom' =>
  array (
    'New' => 'Nový',
    'Assigned' => 'Přiřazen',
    'Closed' => 'Uzavřen',
    'Pending' => 'Řeší se',
    'Rejected' => 'Odmítnut',
  ),
   'bug_type_default_key' => 'Bug',
  'bug_type_dom' =>
  array (
    'Defect' => 'Chyba',
    'Feature' => 'Vyhytávka',
  ),

  'source_default_key' => '',
  'source_dom' =>
  array (
	'' => '',
  	'Internal' => 'Vnitřní',
  	'Forum' => 'Forum',
  	'Web' => 'Web',
  	'InboundEmail' => 'Email'
  ),

  'product_category_default_key' => '',
  'product_category_dom' =>
  array (
	'' => '',
  	'Accounts' => 'Účty',
  	'Activities' => 'Akce',
  	'Bug Tracker' => 'Bug Tracker',
  	'Calendar' => 'Kalendář',
  	'Calls' => 'Telefonáty',
  	'Campaigns' => 'Kampaně',  	
  	'Cases' => 'Případy',
  	'Contacts' => 'Kontakty',
  	'Currencies' => 'Měny',
  	'Dashboard' => 'Nástěnka',
  	'Documents' => 'Dokumenty',
  	'Emails' => 'Emaily',
  	'Feeds' => 'RSS',
  	'Forecasts' => 'Předpovědi',  	
  	'Help' => 'Pomoc',
  	'Home' => 'Home',
  	'Leads' => 'Leads',
  	'Meetings' => 'Meetingy',
  	'Notes' => 'Poznámky',
  	'Opportunities' => 'Příležitosti',
  	'Outlook Plugin' => 'Outlook Plugin',
  	'Product Catalog' => 'Katalog produktů',  	
  	'Products' => 'Produkty',  	
  	'Projects' => 'Projekty',  	
  	'Quotes' => 'Akcie',
  	'Releases' => 'Uvolnění',
  	'RSS' => 'RSS',
  	'Studio' => 'Studio',
  	'Upgrade' => 'Upgrade',
  	'Users' => 'Uživatelé',
  ),

  /*Added entries 'Queued' and 'Sending' for 4.0 release..*/
  'campaign_status_dom' =>
  array (
    	'' => '',
        'Planning' => 'Plánována',
        'Active' => 'Aktivní',
        'Inactive' => 'Neaktivní',
        'Complete' => 'Kompletní',
        'In Queue' => 'Ve frontě',
        'Sending'=> 'Odesílá se',
  ),
  'campaign_type_dom' =>
  array (
        '' => '',
        'Telesales' => 'Po telefonu',
        'Mail' => 'Pošta',
        'Email' => 'Email',
        'Print' => 'Tisk',
        'Web' => 'Web',
        'Radio' => 'Rádio',
        'Television' => 'Televize',
        'NewsLetter' => 'Noviny',
        ),

  'newsletter_frequency_dom' =>
  array (
        '' => '',
        'Weekly' => 'Týdně',
        'Monthly' => 'Měsíčne',
        'Quarterly' => 'Kvartál',
        'Annually' => 'Každoročně',
        ),


  'notifymail_sendtype' =>
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => array('-12'=>'(GMT - 12) International Date Line West',
  							'-11'=>'(GMT - 11) Midway Island, Samoa',
  							'-10'=>'(GMT - 10) Hawaii',
  							'-9'=>'(GMT - 9) Alaska',
  							'-8'=>'(GMT - 8) San Francisco',
  							'-7'=>'(GMT - 7) Phoenix',
  							'-6'=>'(GMT - 6) Saskatchewan',
  							'-5'=>'(GMT - 5) New York',
  							'-4'=>'(GMT - 4) Santiago',
  							'-3'=>'(GMT - 3) Buenos Aires',
  							'-2'=>'(GMT - 2) Mid-Atlantic',
  							'-1'=>'(GMT - 1) Azores',
  							'0'=>'(GMT)',
  							'1'=>'(GMT + 1) Madrid',
  							'2'=>'(GMT + 2) Athens',
  							'3'=>'(GMT + 3) Moscow',
  							'4'=>'(GMT + 4) Kabul',
  							'5'=>'(GMT + 5) Ekaterinburg',
  							'6'=>'(GMT + 6) Astana',
  							'7'=>'(GMT + 7) Bangkok',
  							'8'=>'(GMT + 8) Perth',
  							'9'=>'(GMT + 9) Seol',
  							'10'=>'(GMT + 10) Brisbane',
  							'11'=>'(GMT + 11) Solomone Is.',
  							'12'=>'(GMT + 12) Auckland',
  							),
      'dom_cal_month_long'=>array(
                '0'=>"",
                '1'=>"Leden",
                '2'=>"Únor",
                '3'=>"Březen",
                '4'=>"Duben",
                '5'=>"Květen",
                '6'=>"Červen",
                '7'=>"Červenec",
                '8'=>"Srpen",
                '9'=>"Září",
                '10'=>"Říjen",
                '11'=>"Listopad",
                '12'=>"Prosinec",
        ),
    'dom_meridiem_lowercase'=>array(
                'am'=>"dop.",
                'pm'=>"odp."
        ),
    'dom_meridiem_uppercase'=>array(
                 'AM'=>'DOP',
                 'PM'=>'ODP'
        ),  
    'dom_report_types'=>array(
                'tabular'=>'Řádky a sloupce',
                'summary'=>'Souhrn',
                'detailed_summary'=>'Souhrn s detaily',
        ),
	'dom_email_types'=> array(
		'out'		=> 'Odeslán',
		'archived'	=> 'Archivován',
		'draft'		=> 'Koncept',
		'inbound'	=> 'Příchozí',
        'campaign'  => 'Campaign'
	),
	'dom_email_status' => array (
		'archived'	=> 'Archivván',
		'closed'	=> 'Zavřen',
		'draft'		=> 'V šablonách',
		'read'		=> 'Přečten',
		'replied'	=> 'Odpovězeno',
		'sent'		=> 'Odeslán',
		'send_error'=> 'Chyba odeslání',
		'unread'	=> 'Nepřečten',
	),
		
	'dom_email_server_type' => array(	''			=> '--None--',
										'imap'		=> 'IMAP',
										'pop3'		=> 'POP3',
	),
	'dom_mailbox_type'		=> array(/*''			=> '--None Specified--',*/
									 'pick'		=> 'Vytvořit [cokoli]',
									 'bug'		=> 'Vytvořit bug',
					 				 'support'	=> 'Vytvořit případ',
					 				 'contact'  => 'Vytvořit kontakt',
					 				 'sales'	=> 'Vytvořit iniciativu',
					 				 'task'		=> 'Vytvořit úlohu',
					 				 'bounce'	=> 'Bounce Handling',
	),
	'dom_email_distribution'=> array(''				=> '--None--',
									 'direct'		=> 'Přímé přiřazení',
									 'roundRobin'	=> 'Round-Robin',
									 'leastBusy'	=> 'Nejméně zatížený',
	),
	'dom_email_errors'		=> array(1 => 'Smíte označit pouze jednoho uživatele u přímeho přiřazení položky.',
									 2 => 'You must assign Only Checked Items when Direct Assigning items.',
	),
	'dom_email_bool'		=> array('bool_true' => 'Ano',
								 	 'bool_false' => 'Ne',
	),
	'dom_int_bool'			=> array(1 => 'Ano',
								 	 0 => 'Ne',
	),
	'dom_switch_bool'		=> array ('on' => 'Ano',
										'off' => 'Ne',
										'' => 'Ne', ),
	'dom_email_link_type'	=> array(	''			=> 'Základní emailový program',
										'sugar'		=> 'SugarCRM Mail Client',
										'mailto'	=> 'Externí emailový program'),

	'dom_email_editor_option'=> array(	''			=> 'Zakldní formát emailu',
										'html'		=> 'HTML formát',
										'plain'		=> 'Čistý text'),

	
	'schedulers_times_dom'	=> array(	'not run'		=> 'Past Run Time, Not Executed',
										'ready'			=> 'Připraven',
										'in progress'	=> 'Probíhá',
										'failed'		=> 'Chybný',
										'completed'		=> 'Kompletní',
										'no curl'		=> 'Nespuštěn: CURL není dostupné',
	),

	'forecast_schedule_status_dom' =>
  	array (
    'Active' => 'Aktivní',
    'Inactive' => 'Neaktivní',
  ),
	'forecast_type_dom' =>
  	array (
    'Direct' => 'Direct',
    'Rollup' => 'Rollup',
  ),  
	
	'document_category_dom' =>
  	array (
  	'' => '',
    'Marketing' => 'Marketing',
    'Knowledege Base' => 'Znalostní báze',
    'Sales' => 'Prodej',    
  ),  

	'document_subcategory_dom' =>
  	array (
  	'' => '',
    'Marketing Collateral' => 'Zaruční zpráva',
    'Product Brochures' => 'Produktové brožury',
	'FAQ' => 'FAQ',
  ),  
  
	'document_status_dom' =>
  	array (
    'Active' => 'Aktivní',
    'Draft' => 'Vzor',
	'FAQ' => 'FAQ',
	'Expired' => 'Prošlý',
	'Under Review' => 'Pod dohledem',
	'Pending' => 'Probíhá',
  ),
  'document_template_type_dom' =>
  array(
  	''=>'',
  	'mailmerge'=>'Mail Merge',
  	'eula'=>'EULA',
  	'nda'=>'NDA',
  	'license'=>'License Agreement',
  ),
	'dom_meeting_accept_options' =>
  	array (
	'accept' => 'Přijat',
	'decline' => 'Odmítnut',
	'tentative' => 'Váhám',
  ),
	'dom_meeting_accept_status' =>
  	array (
	'accept' => 'Přijat',
	'decline' => 'Odmítnut',
	'tentative' => 'Váhám',
	'none'		=> 'Nezadáno',
  ),


// deferred
/*// QUEUES MODULE DOMs
'queue_type_dom' => array(
	'Users' => 'Users',



	'Mailbox' => 'Mailbox',
),		   
*/

//prospect list type dom
  'prospect_list_type_dom' =>
  array (
    'default' => 'Default',
    'seed' => 'Seed',
    'exempt_domain' => 'Suppression List - By Domain',
    'exempt_address' => 'Suppression List - By Email Address',
    'exempt' => 'Suppression List - By Id',
    'test' => 'Test',
  ),
  
  'email_marketing_status_dom' => 
  array (
  	'' => '',
  	'active'=>'Aktivní',
  	'inactive'=>'Neaktivní'
  ),

  'campainglog_activity_type_dom' =>
  array (
  	''=>'',
    'targeted' => 'Zpráva odeslána/pokusil se',
    'send error'=>'Vracející se zpráva,Jiné',
    'invalid email'=>'Vracejícíse zpráva,špatný email',
    'link'=>'Odkaz',
    'viewed'=>'Shlédnutá zpráva',
    'removed'=>'Vyvolená',
    'lead'=>'Leads Created',
    'contact'=>'Kontakty vytvořeny',        
  ),

  'campainglog_target_type_dom' =>
  array (
    'Contacts' => 'Kontakty',
    'Users'=>'Uživatelé',
    'Prospects'=>'Cíle',
    'Leads'=>'Leads',
  ),
  
  'merge_operators_dom' => array (
    'like'=>'Obsahuje',
    'exact'=>'Přesně',
    'start'=>'Začíná s',
  ),

  'custom_fields_merge_dup_dom'=> array (
        0=>'Znepřístupněno',
        1=>'Zpřístupněno',





  ),
   
  'navigation_paradigms' => array(
        'm'=>'Moduly',
        'gm'=>'Seskupené moduly',
  ),
  

	'projects_priority_options' => array (
		'high' 		=> 'Vysoká',
		'medium' 	=> 'Střední',
		'low' 		=> 'Nízká',
	),
	
	'projects_status_options' => array (
		'notstarted' 	=> 'Nezačal',
		'inprogress' 	=> 'Probíhá',
		'completed' 	=> 'Kompletní',
	),
);

$app_strings = array (
	
	'ERR_CREATING_FIELDS' => 'Chyba plnění dodatečných detailů položek: ',
	'ERR_CREATING_TABLE' => 'Chyba vytváření tabulek: ',
	'ERR_DELETE_RECORD' => 'Pro smazání kontaktu musíte uvést číslo záznamu.',
	'ERR_EXPORT_DISABLED' => 'Exportování zmepřístupněno.',
	'ERR_EXPORT_TYPE' => 'Chyba exportování ',
	'ERR_INVALID_AMOUNT' => 'Prozím zadejte platnou částku.',
	'ERR_INVALID_DATE_FORMAT' => 'Formát datumu nusí být: ',
	'ERR_INVALID_DATE' => 'Prosím adejte platné datum.',
	'ERR_INVALID_DAY' => 'Prosím zadejte platný den.',
	'ERR_INVALID_EMAIL_ADDRESS' => 'neplatná emailová adresa.',
	'ERR_INVALID_FILE_REFERENCE' => 'Invalid File Reference',
	'ERR_INVALID_HOUR' => 'Prosím zadejte platnou hodinu.',
	'ERR_INVALID_MONTH' => 'Prosím zadejte platný měsíc.',
	'ERR_INVALID_TIME' => 'Prosím zadejte platný čas.',
	'ERR_INVALID_YEAR' => 'Prosím zadejte 4-ciferný rok.',
	'ERR_NEED_ACTIVE_SESSION' => 'Pro export obsahu potřebujete platné sezení.',
	'ERR_NOT_ADMIN' => "Neautorizovaný přístup do administrace.",
	'ERR_MISSING_REQUIRED_FIELDS' => 'Chybějící požadovaná pole:',
	'ERR_INVALID_VALUE' => 'Špatná hodnota:',
	'ERR_NO_SUCH_FILE' =>'Soubor v systému neexistuje',
	'ERR_NO_SINGLE_QUOTE' => 'Nemohu použít jednoduché uvozovky pro ',
	'ERR_NOTHING_SELECTED' =>'Please make a selection before proceeding.',
	'ERR_OPPORTUNITY_NAME_DUPE' => 'An opportunity with the name %s already exists.  Please enter another name below.',
	'ERR_OPPORTUNITY_NAME_MISSING' => 'An opportunity name was not entered.  Please enter an opportunity name below.',
	'ERR_POTENTIAL_SEGFAULT' => 'A potential Apache segmentation fault was detected.  Please notify your system administrator to confirm this problem and have her/him report it to SugarCRM.',
	'ERR_SELF_REPORTING' => 'User cannot report to him or herself.',
	'ERR_SINGLE_QUOTE'	=> 'Using the single quote is not supported for this field.  Please change the value.',
	'ERR_SQS_NO_MATCH_FIELD' => 'No match for field: ',
	'ERR_SQS_NO_MATCH' =>'Není shoda',
	
	
	'LBL_ACCOUNT'=>'Účet',
	'LBL_ACCOUNTS'=>'Účty',
	'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
	'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Zobrazit přehled',
	'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'Zobrazit přehled [Alt+H]',
	'LBL_ADD_BUTTON_KEY' => 'A',
	'LBL_ADD_BUTTON_TITLE' => 'Přidat [Alt+A]',
	'LBL_ADD_BUTTON' => 'Přidat',
	'LBL_ADD_DOCUMENT' => 'Přidat dokument',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'Add To Target List',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE' => 'Add To Target List',
	'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'Click to Close',
	'LBL_ADDITIONAL_DETAILS_CLOSE' => 'Zavřít',
	'LBL_ADDITIONAL_DETAILS' => 'Další detaily',
	'LBL_ADMIN' => 'Admin',
	'LBL_ALT_HOT_KEY' => 'Alt+',
	'LBL_ARCHIVE' => 'Archive',
	'LBL_ASSIGNED_TO_USER'=>'Přiazeno uživateli',
	'LBL_ASSIGNED_TO' => 'Přiřazeno k:',
	'LBL_BACK' => 'Zpět',
	'LBL_BILL_TO_ACCOUNT'=>'Platba na účet',
	'LBL_BILL_TO_CONTACT'=>'Platba na kontakt',
	'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
	'LBL_BUGS'=>'Bugy',
	'LBL_BY' => 'by',
	'LBL_CALLS'=>'Telefonáty',
	'LBL_CAMPAIGNS_SEND_QUEUED' => 'Send Queued Campaign Emails',
	'LBL_CANCEL_BUTTON_KEY' => 'X',
	'LBL_CANCEL_BUTTON_LABEL' => 'Zrušit',
	'LBL_CANCEL_BUTTON_TITLE' => 'Zrušit [Alt+X]',
	'LBL_CASE'=>'Případ',
	'LBL_CASES'=>'Případy',
	'LBL_CHANGE_BUTTON_KEY' => 'G',
	'LBL_CHANGE_BUTTON_LABEL' => 'Změnit',
	'LBL_CHANGE_BUTTON_TITLE' => 'Zmenit [Alt+G]',
	'LBL_CHARSET' => 'UTF-8',
	'LBL_CHECKALL' => 'Zaškrtnout vše',
	'LBL_CLEAR_BUTTON_KEY' => 'C',
	'LBL_CLEAR_BUTTON_LABEL' => 'Vyčistit',
	'LBL_CLEAR_BUTTON_TITLE' => 'Vyčistit [Alt+C]',
	'LBL_CLEARALL' => 'Vyčistit vše',
	'LBL_CLOSE_WINDOW'=>'Zavřít okno',
	'LBL_CLOSEALL_BUTTON_KEY' => 'Q',
	'LBL_CLOSEALL_BUTTON_LABEL' => 'Zavřít vše',
	'LBL_CLOSEALL_BUTTON_TITLE' => 'Zavřít vše [Alt+I]',
    'LBL_CLOSE_AND_CREATE_BUTTON_LABEL' => 'Zavřít a vytvořit nový',
    'LBL_CLOSE_AND_CREATE_BUTTON_TITLE' => 'Zavřít a vytvořit nový [Alt+C]',
    'LBL_CLOSE_AND_CREATE_BUTTON_KEY' => 'C',    
	'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
	'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Napsat email',
	'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Napsat email [Alt+L]',
	'LBL_CONTACT_LIST' => 'Seznam kontaktů',
	'LBL_CONTACT'=>'Kontakt',
	'LBL_CONTACTS'=>'Kontakty',
	'LBL_CREATE_BUTTON_LABEL' => 'Vytvořit',
	'LBL_CREATED_BY_USER'=>'Vytvořen uživatelem',
	'LBL_CREATED' => 'Vytvořen',
	'LBL_CURRENT_USER_FILTER' => 'Pouze mé položky:',
	'LBL_DATE_ENTERED' => 'Zatum vytvoření:',
	'LBL_DATE_MODIFIED' => 'Poslední úprava:',
	'LBL_DELETE_BUTTON_KEY' => 'D',
	'LBL_DELETE_BUTTON_LABEL' => 'Smazat',
	'LBL_DELETE_BUTTON_TITLE' => 'Zmazat [Alt+D]',
	'LBL_DELETE_BUTTON' => 'Smazat',
	'LBL_DELETE' => 'Smazat',
	'LBL_DELETED'=>'Smazáno',
	'LBL_DIRECT_REPORTS'=>'Direct Reports',
	'LBL_DONE_BUTTON_KEY' => 'X',
	'LBL_DONE_BUTTON_LABEL' => 'Hotovo',
	'LBL_DONE_BUTTON_TITLE' => 'Hotovo [Alt+X]',
	'LBL_DST_NEEDS_FIXIN' => 'The application requires a Daylight Saving Time fix to be applied.  Please go to the <a href="index.php?module=Administration&action=DstFix">Repair</a> link in the Admin console and apply the Daylight Saving Time fix.',
	'LBL_DUPLICATE_BUTTON_KEY' => 'U',
	'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplicitní',
	'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplicitní [Alt+U]',
	'LBL_DUPLICATE_BUTTON' => 'Duplicitní',
	'LBL_EDIT_BUTTON_KEY' => 'E',
	'LBL_EDIT_BUTTON_LABEL' => 'Upravit',
	'LBL_EDIT_BUTTON_TITLE' => 'Upravit [Alt+E]',
	'LBL_EDIT_BUTTON' => 'Upravit',
	'LBL_VIEW_BUTTON_KEY' => 'V',
	'LBL_VIEW_BUTTON_LABEL' => 'Zobrazit',
	'LBL_VIEW_BUTTON_TITLE' => 'Zobrazit [Alt+V]',
	'LBL_VIEW_BUTTON' => 'Zobrazit',
	'LBL_EMAIL_PDF_BUTTON_KEY' => 'M',
	'LBL_EMAIL_PDF_BUTTON_LABEL' => 'Email jako PDF',
	'LBL_EMAIL_PDF_BUTTON_TITLE' => 'Email jako PDF [Alt+M]',
	'LBL_EMAILS'=>'Emaily',
	'LBL_EMPLOYEES' => 'Zaměstnanci',
	'LBL_ENTER_DATE' => 'Vložit datum',
	'LBL_EXPORT_ALL' => 'Exportovat vše',
	'LBL_EXPORT' => 'Export',
    'LBL_GO_BUTTON_LABEL' => 'Jdi',
	'LBL_HIDE'=>'Skrýt',
	'LBL_ID'=>'ID',
	'LBL_IMPORT_PROSPECTS'=>'Import Targets',
	'LBL_IMPORT' => 'Import',
    'LBL_IMPORT_STARTED' => 'Import Started: ',    
    'LBL_MISSING_CUSTOM_DELIMITER' => 'Must specify a custom delimiter.',    
	'LBL_LAST_VIEWED' => 'Poslední zobrazení',
	'LBL_LEADS'=>'Leads',
	'LBL_CAMPAIGN' => 'Kampaň:',
	'LBL_CAMPAIGN_ID'=>'campaign_id',
	
	'LBL_LIST_ACCOUNT_NAME' => 'Jméno účtu',
	'LBL_LIST_ASSIGNED_USER' => 'Uživatel',
	'LBL_LIST_CONTACT_NAME' => 'Jméno kontaktu',
	'LBL_LIST_CONTACT_ROLE' => 'Role kontaktu',
	'LBL_LIST_EMAIL' => 'Email',
	'LBL_LIST_NAME' => 'Jméno',
	'LBL_LIST_OF' => 'of',
	'LBL_LIST_PHONE' => 'Telefon',
	'LBL_LIST_USER_NAME' => 'Uživatelské jméno',
	'LBL_LISTVIEW_MASS_UPDATE_CONFIRM' => 'Are you sure you want to update the entire list?',
	'LBL_LISTVIEW_NO_SELECTED' => 'Please select at least 1 record to proceed.',
    'LBL_LISTVIEW_TWO_REQUIRED' => 'Please select at least 2 records to proceed.',    
	'LBL_LISTVIEW_OPTION_CURRENT' => 'Aktuální stránka',
	'LBL_LISTVIEW_OPTION_ENTIRE' => 'Kompletní seznam',
	'LBL_LISTVIEW_OPTION_SELECTED' => 'Vybrané záznamy',
	'LBL_LISTVIEW_SELECTED_OBJECTS' => 'Vybráno: ',
	
	'LBL_LOCALE_NAME_EXAMPLE_FIRST' => 'Jan',
	'LBL_LOCALE_NAME_EXAMPLE_LAST' => 'Novák',
	'LBL_LOCALE_NAME_EXAMPLE_SALUTATION' => 'p.',
	'LBL_LOGOUT' => 'Odhlásit',
	'LBL_MAILMERGE_KEY' => 'M',
	'LBL_MAILMERGE' => 'Mail Merge',
	'LBL_MASS_UPDATE' => 'Mass Update',
	'LBL_MEETINGS'=>'Meetingy',
	'LBL_MEMBERS'=>'Členi',
	'LBL_MODIFIED_BY_USER'=>'Změněno uživatelem',
	'LBL_MODIFIED' => 'Změněno',
	'LBL_MY_ACCOUNT' => 'Můj učet',
	'LBL_NAME' => 'Jméno',
	'LBL_NEW_BUTTON_KEY' => 'N',
	'LBL_NEW_BUTTON_LABEL' => 'Vytvořit',
	'LBL_NEW_BUTTON_TITLE' => 'Vytvořit [Alt+N]',
	'LBL_NEXT_BUTTON_LABEL' => 'Další',
	'LBL_NONE' => '--Nic--',
	'LBL_NOTES'=>'Poznámky',
	'LBL_OPENALL_BUTTON_KEY' => 'O',
	'LBL_OPENALL_BUTTON_LABEL' => 'Otevřít vše',
	'LBL_OPENALL_BUTTON_TITLE' => 'Otevřít vše [Alt+O]',
	'LBL_OPENTO_BUTTON_KEY' => 'T',
	'LBL_OPENTO_BUTTON_LABEL' => 'Otevřít k: ',
	'LBL_OPENTO_BUTTON_TITLE' => 'Otevřít k: [Alt+T]',
	'LBL_OPPORTUNITIES'=>'Příležitosti',
	'LBL_OPPORTUNITY_NAME' => 'Název příležitosti',
	'LBL_OPPORTUNITY'=>'Příležitost',
	'LBL_OR' => 'NEBO',
	'LBL_PERCENTAGE_SYMBOL' => '%',
	'LBL_PRODUCT_BUNDLES'=>'Produktový balík',
	'LBL_PRODUCTS'=>'Produkty',
	'LBL_PROJECT_TASKS'=>'Úkoly projektu',
	'LBL_PROJECTS'=>'Projekty',
	'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
	'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Vytvořit příležitost z nabídnuté ceny',
	'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Vytvořit příležitost z nabídnuté ceny [Alt+O]',
	'LBL_QUOTES_SHIP_TO'=>'Nabídky doručit na',
	'LBL_QUOTES'=>'Nabídky',
	'LBL_RELATED_RECORDS' => 'Související záznamy',
	'LBL_REMOVE' => 'Odebrat',
	'LBL_REQUIRED_SYMBOL' => '*',
	'LBL_SAVE_BUTTON_KEY' => 'S',
	'LBL_SAVE_BUTTON_LABEL' => 'Uložit',
	'LBL_SAVE_BUTTON_TITLE' => 'Uložit [Alt+S]',
    'LBL_SAVE_AS_BUTTON_KEY' => 'A',
    'LBL_SAVE_AS_BUTTON_LABEL' => 'Uložit jako',
    'LBL_SAVE_AS_BUTTON_TITLE' => 'Uložit jako [Alt+A]',
    'LBL_FULL_FORM_BUTTON_KEY' => 'F',
    'LBL_FULL_FORM_BUTTON_LABEL' => 'Celý formulář',
    'LBL_FULL_FORM_BUTTON_TITLE' => 'Celý formulář [Alt+F]',
	'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
	'LBL_SAVE_NEW_BUTTON_LABEL' => 'Uložit & Vytvořit nový',
	'LBL_SAVE_NEW_BUTTON_TITLE' => 'Uložit a vytvořit nový [Alt+V]',
	'LBL_SEARCH_BUTTON_KEY' => 'Q',
	'LBL_SEARCH_BUTTON_LABEL' => 'Vyhledat',
	'LBL_SEARCH_BUTTON_TITLE' => 'Vyhledat [Alt+Q]',
	'LBL_SEARCH' => 'Search',
	'LBL_SELECT_BUTTON_KEY' => 'T',
	'LBL_SELECT_BUTTON_LABEL' => 'Vybrat',
	'LBL_SELECT_BUTTON_TITLE' => 'Vybrat [Alt+T]',
	'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
	'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Vybrat kontakt',
	'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Vybrat kontakt [Alt+T]',
    'LBL_GRID_SELECTED_FILE' => 'vybrané soubory',
    'LBL_GRID_SELECTED_FILES' => 'vybrané soubory',
	'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'Select from Reports',
	'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'Select Reports',
	'LBL_SELECT_USER_BUTTON_KEY' => 'U',
	'LBL_SELECT_USER_BUTTON_LABEL' => 'Vybrat uživatele',
	'LBL_SELECT_USER_BUTTON_TITLE' => 'Vybrat uživatele [Alt+U]',
	'LBL_SERVER_RESPONSE_RESOURCES' => 'Zdroje použité pro tuto stránku (dotazy, soubory)',
	'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'vteřin.',
	'LBL_SERVER_RESPONSE_TIME' => 'Server odpověděl za:',
	'LBL_SHIP_TO_ACCOUNT'=>'Dopravit na účet',
	'LBL_SHIP_TO_CONTACT'=>'Dopravit na kontakt',
	'LBL_SHORTCUTS' => 'Zkratky',
	'LBL_SHOW'=>'Ukázat',
	'LBL_SQS_INDICATOR' => '',
	'LBL_STATUS_UPDATED'=>'Tvůj stav pro tuto událost byl aktualizován!',
	'LBL_STATUS'=>'Stav:',
	'LBL_SUBJECT' => 'Předmět',
	'LBL_SYNC' => 'Synchnonizovat',
    'LBL_TABGROUP_ALL' => 'Vše',
    'LBL_TABGROUP_ACTIVITIES' => 'Aktivity',
    'LBL_TABGROUP_COLLABORATION' => 'Spolupráce',
    'LBL_TABGROUP_HOME' => 'Home',
    'LBL_TABGROUP_MARKETING' => 'Marketing',
    'LBL_TABGROUP_MY_PORTALS' => 'Mé portály',
    'LBL_TABGROUP_OTHER' => 'Jiné',
    'LBL_TABGROUP_REPORTS' => 'Reporty',
    'LBL_TABGROUP_SALES' => 'Prodej',
    'LBL_TABGROUP_SUPPORT' => 'Podpora',
    'LBL_TABGROUP_TOOLS' => 'Pomůcky',
	'LBL_TASKS'=>'Úkoly',
	'LBL_TEAMS_LINK'=>'Tým',
	'LBL_THOUSANDS_SYMBOL' => 'K',
	'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
	'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Achiv email',
	'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archive Email [Alt+K]',
	'LBL_UNAUTH_ADMIN' => 'Neautorizovaný přístup do administrace',
	'LBL_UNDELETE_BUTTON_LABEL' => 'Undelete',
	'LBL_UNDELETE_BUTTON_TITLE' => 'Undelete [Alt+D]',
	'LBL_UNDELETE_BUTTON' => 'Undelete',
	'LBL_UNDELETE' => 'Undelete',
	'LBL_UNSYNC' => 'Unsync',
	'LBL_UPDATE' => 'Update',
	'LBL_USER_LIST' => 'Seznam uživatelů',
	'LBL_USERS_SYNC'=>'Users Sync',
	'LBL_USERS'=>'Uživatelé',
	'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
	'LBL_VIEW_PDF_BUTTON_LABEL' => 'Tisk do PDF',
	'LBL_VIEW_PDF_BUTTON_TITLE' => 'Tisk do PDF [Alt+P]',
	
	'LNK_ABOUT' => 'O aplikaci',
	'LNK_ADVANCED_SEARCH' => 'Rozšířené hledání',
	'LNK_BASIC_SEARCH' => 'Základní hledání',
    'LNK_SAVED_VIEWS' => 'Uložená hledání & Vzhled',
	'LNK_DELETE_ALL' => 'smazat vše', 
	'LNK_DELETE' => 'smazat',
	'LNK_EDIT' => 'upravit',
	'LNK_GET_LATEST'=>'Dej nejpozdější',
	'LNK_GET_LATEST_TOOLTIP'=>'Nahradit poslední verzí',
	'LNK_HELP' => 'Nápověda',
	'LNK_LIST_END' => 'Konec',
	'LNK_LIST_NEXT' => 'Další',
	'LNK_LIST_PREVIOUS' => 'Předchozí',
	'LNK_LIST_RETURN' => 'Zpět na seznam',
	'LNK_LIST_START' => 'Start',
	'LNK_LOAD_SIGNED'=>'Podpis',
	'LNK_LOAD_SIGNED_TOOLTIP'=>'Replace with signed document',
	'LNK_PRINT' => 'Tisk',
	'LNK_REMOVE' => 'rem',
	'LNK_RESUME' => 'Resume',
	'LNK_VIEW_CHANGE_LOG' => 'Zobrazit seznam změn',
    
	
	'NTC_CLICK_BACK' => 'Prosím stiskněte v prohlížeči ZPĚT a opravte chybu.',
	'NTC_DATE_FORMAT' => '(rrrr-mm-dd)',
	'NTC_DATE_TIME_FORMAT' => '(rrrr-mm-dd 24:00)',
	'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Jste si jisti, že chcete smazat vybrané záznam(y)?',
	'NTC_DELETE_CONFIRMATION' => 'Jste si jisti, že chcete smazat tento záznam?',
	'NTC_LOGIN_MESSAGE' => 'Prosím zadejte uživatelské jméno a heslo.',
	'NTC_NO_ITEMS_DISPLAY' => 'nic',
	'NTC_REMOVE_CONFIRMATION' => 'Are you sure you want to remove this relationship?',
	'NTC_REQUIRED' => 'Indicates required field',
	'NTC_SUPPORT_SUGARCRM' => 'Support the SugarCRM open source project with a donation through PayPal - it\'s fast, free and secure!',
	'NTC_TIME_FORMAT' => '(24:00)',
	'NTC_WELCOME' => 'Vítej',
	'NTC_YEAR_FORMAT' => '(yyyy)',
	'LOGIN_LOGO_ERROR'=> 'Prosím nahraďte SugarCRM loga.',
	'ERROR_FULLY_EXPIRED'=> "Your company's license for SugarCRM has expired for more than 30 days and needs to be brought up to date. Only admins may login.",
	'ERROR_LICENSE_EXPIRED'=> "Your company's license for SugarCRM needs to be updated. Only admins may login",
	'ERROR_LICENSE_VALIDATION'=> "Your company's license for SugarCRM needs to be validated. Only admins may login",
	'ERROR_NO_RECORD' => 'Error retrieving record.  This record may be deleted or you may not be authorized to view it.',
	'LBL_DUP_MERGE'=>'Najít duplicity',
    'LBL_MANAGE_SUBSCRIPTIONS'=>'Manage Subscriptions',
    'LBL_MANAGE_SUBSCRIPTIONS_FOR'=>'Manage Subscriptions for ',
    'LBL_SUBSCRIBE'=>'Přihlásit k odběru',
    'LBL_UNSUBSCRIBE'=>'Odhlásit z odběru',
	// Ajax status strings
	'LBL_LOADING' => 'Načítám ...',
	'LBL_SAVING_LAYOUT' => 'Ukládám vzhled ...',
    'LBL_SAVED_LAYOUT' => 'Vzhled uložen.',
    'LBL_SAVED' => 'Uloženo',
    'LBL_SAVING' => 'Ukládání',
    'LBL_FAILED' => 'Selhalo!',
    'LBL_DISPLAY_COLUMNS' => 'Zobrazit sloupce',
    'LBL_HIDE_COLUMNS' => 'Skrýt sloupce',
    'LBL_SEARCH_CRITERIA' => 'Vyhledávací kritéria',
    'LBL_SAVED_VIEWS' => 'Saved Views',
    'LBL_PROCESSING_REQUEST'=>'Zpracovávám...',
    'LBL_REQUEST_PROCESSED'=>'Hotovo',





    'LBL_MERGE_DUPLICATES'  => 'Porovnat duplicity',
    'LBL_SAVED_SEARCH_SHORTCUT' => 'Uložená hledání',
    'LBL_SEARCH_POPULATE_ONLY'=> 'Upřesněte vyhledávání pouzitím vyhledávacího formuláře výše',
    'LBL_DETAILVIEW'=>'Detailní zobrazení', 
    'LBL_LISTVIEW'=>'Seznam zobrazení', 
    'LBL_EDITVIEW'=>'Upravit zobrazení',
    'LBL_SEARCHFORM'=>'Vyhledávací formulář',
    'LBL_SAVED_SEARCH_ERROR' => 'Prosím poskytněte jméno pro toto zobrazení.',
	'LBL_DISPLAY_LOG' => 'Zobrazit záznam',
	'ERROR_JS_ALERT_SYSTEM_CLASS' => 'Systém',
	'ERROR_JS_ALERT_TIMEOUT_TITLE' => 'Sezení vypršelo',
	'ERROR_JS_ALERT_TIMEOUT_MSG_1' => 'Vaše sezení přibližně za 2 minuty vypší. Prosím uložte vaši práci.',
	'ERROR_JS_ALERT_TIMEOUT_MSG_2' =>'Vaše sezení vypršelo.',
	'MSG_JS_ALERT_MTG_REMINDER_AGENDA' => "\nAgenda: ",
	'MSG_JS_ALERT_MTG_REMINDER_MEETING' => 'Meeting',
	'MSG_JS_ALERT_MTG_REMINDER_CALL' => 'Telefonát',
	'MSG_JS_ALERT_MTG_REMINDER_TIME' => 'Čas: ',
	'MSG_JS_ALERT_MTG_REMINDER_LOC' => 'Umístění: ',
	'MSG_JS_ALERT_MTG_REMINDER_DESC' => 'Popis: ',
	'MSG_JS_ALERT_MTG_REMINDER_MSG' => "\nKlikněte na OK pro zobrazení meetingu nebo klikněte na Zrušit pro ignorování.",
    // contextMenu strings    
    'LBL_ADD_TO_FAVORITES' => 'Přidat do mých oblíbených',
    'LBL_CREATE_CONTACT' => 'Vytvořit kontakt',
    'LBL_CREATE_CASE' => 'Vytvořit případ',
    'LBL_CREATE_NOTE' => 'Vytvořit poznámku',
    'LBL_CREATE_OPPORTUNITY' => 'Vytvořit příležitost',
    'LBL_SCHEDULE_CALL' => 'Naplánovat telefonát',
    'LBL_SCHEDULE_MEETING' => 'Naplánovat meeting',
    'LBL_CREATE_TASK' => 'Vytvořit úkol',
    'LBL_REMOVE_FROM_FAVORITES' => 'Odstranit z oblíbených',
    //web to lead
    'LBL_GENERATE_WEB_TO_LEAD_FORM' => 'Generovat formulář', 
    'LBL_SAVE_WEB_TO_LEAD_FORM' =>'Save Web To Lead Form',     
    
	'LBL_PLEASE_SELECT' => 'Prosím vyberte',          
	'LBL_REDIRECT_URL'=>'Přesměrovaná URL',
    'LBL_RELATED_CAMPAIGN' =>'Související kampaň',  
    'LBL_ADD_ALL_LEAD_FIELDS' => 'Přidat všechna pole',
    'LBL_REMOVE_ALL_LEAD_FIELDS' => 'Odebrat všechna pole',
    'LBL_ONLY_IMAGE_ATTACHMENT' => 'Only image type attachment can be embedded',
	'LBL_TRAINING' => 'Výcvik',
);
?>
