<?php
/**
 * インストールの最後に呼ばれる関数
 */
function post_install(){
	//テーブルスキーマの変更
	if (!field_exists('contacts', 'furigana'))
		add_field('contacts', 'furigana', 'VARCHAR(64) NULL');
	
	//ロジックフックの追加
	check_logic_hook_file(
		"Contacts",
		"before_save",
		array(1, 'adjust_fields', 'include/JapaneseExtensionPack/logic_hooks.php', 'JEPContactLogicHook', 'adjustFieldsBeforeSave')
	);
}

/**
 * フィールドの存在確認
 */
function field_exists($table, $field){
	$query = "SHOW COLUMNS FROM $table";
	$result = $GLOBALS['db']->query($query,true);
	while ($row = $GLOBALS['db']->fetchByAssoc($result))
		if ($row['Field'] == $field)
			return true;
	
	return false;
}

/**
 * テーブルにフィールドを追加
 */
function add_field($table, $field, $option){
	$query = "ALTER TABLE $table ADD $field $option";
	$result = $GLOBALS['db']->query($query,true);
}
?>