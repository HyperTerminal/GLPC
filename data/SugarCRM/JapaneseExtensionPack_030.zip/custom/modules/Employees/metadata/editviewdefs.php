<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
$viewdefs['Employees']['EditView'] = array(
    'templateMeta' => array('maxColumns' => '2', 
                            'widths' => array(
                                            array('label' => '10', 'field' => '30'), 
                                            array('label' => '10', 'field' => '30')
                                            ),
                            ),
 'panels' =>array (

  ''=>array (
	    array (
	      'employee_status',
	    ),
	    array (
    		#JEP
	      array(
	      	'name'=>'name',
	      	'label' => 'LBL_NAME',
	      	'customCode' => '<input name="last_name" size="8" maxlength="25" type="text" value="{$fields.last_name.value}"> <input name="first_name" size="8" maxlength="25" type="text" value="{$fields.first_name.value}">',
	      	'displayParams'=>array('required'=>true),
	      ),
	      #/JEP
	    ),
	    array (
	      'title',
	      array('name'=>'phone_work','label'=>'LBL_OFFICE_PHONE'),
	    ),
	    array (
	      'department',
	      'phone_mobile',
	    ),
	    array (
	      'reports_to_name',
	      'phone_other',
	    ),
	    array (
	      '',
	      array('name'=>'phone_fax', 'label'=>'LBL_FAX'),
	    ),
	    array (
	      '',
	      'phone_home',
	    ),
	    array (
	      'messenger_type',
	    ),
	    array (
	      'messenger_id',
	    ),
	    array (
	      array('name'=>'description', 'label'=>'LBL_NOTES'),
	    ),
	    array (
	    	#JEP
				array (
					'name' => 'address',
					'label' => 'LBL_ADDRESS',
					'customCode' => '
						<table>
							<tr><td>郵便番号:</td><td>〒 <input name="address_postalcode" size="8" maxlength="8" type="text" value="{$fields.address_postalcode.value}"></td></tr>
							<tr><td>都道府県:</td><td><input name="address_state" size="8" maxlength="4" type="text" value="{$fields.address_state.value}"></td></tr>
							<tr><td>市区町村:</td><td><input name="address_city" size="30" maxlength="100" type="text" value="{$fields.address_city.value}"></td></tr>
							<tr><td>番地建物:</td><td><input name="address_street" size="30" maxlength="150" type="text" value="{$fields.address_street.value}"></td></tr>
						</table>
						',
				),
				#/JEP
        array (
          'name' => 'email1',
          'label' => 'LBL_EMAIL',
        ),
	    ),
  ),
),

);
?>
