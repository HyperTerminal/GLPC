<?php
$metafiles['Contacts'] = array(
	'detailviewdefs'     => 	'custom/modules/Contacts/metadata/detailviewdefs.php', 	
	'editviewdefs'       => 	'custom/modules/Contacts/metadata/editviewdefs.php',
 	'listviewdefs'       => 	'custom/modules/Contacts/metadata/listviewdefs.php',
 	'searchdefs'         =>  'custom/modules/Contacts/metadata/searchdefs.php',
 	'popupdefs'	         =>  'custom/modules/Contacts/metadata/popupdefs.php',
 	'searchfields'	     =>  'custom/modules/Contacts/metadata/SearchFields.php',
//'sidecreateviewdefs' =>  'custom/modules/Contacts/metadata/sidecreateviewdefs.php',//metafiles.phpに現バージョンでは未対応
//'quickcreatedefs'	   =>  'custom/modules/Contacts/metadata/quickcreatedefs.php',//metafiles.phpに現バージョンでは未対応
);
?>
