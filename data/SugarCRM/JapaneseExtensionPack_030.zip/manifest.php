<?php

$manifest = array (
	'acceptable_sugar_versions' => array (
		'regex_matches' => array (
			"5\.1\.0.*",
		),
	),
	'acceptable_sugar_flavors' => array (
		'CE',
	),
	'author' => 'CogniTom Academic Design & Tsutomu Kawamura',
	'name' => 'JapaneseExtensionPack',
	'description' => 'Japanese Extension Pack',
	'readme'=>'',
	'is_uninstallable' => true,
	'published_date' => '2008-05-18',
	'type' => 'module',
	'version' => '0.3.0',
	'icon' => 'resources/images/flag-ja_jp.gif'
);

$installdefs = array (
  'id' => 'JEP',//Japanese Extension Pack
  'vardefs'=> array(
		array(
			'from'=> '<basepath>/resources/vardefs/Calls_vardefs.php',
			'to_module'=> 'Calls',
		),
		array(
			'from'=> '<basepath>/resources/vardefs/Contacts_vardefs.php',
			'to_module'=> 'Contacts',
		),
		array(
			'from'=> '<basepath>/resources/vardefs/DocumentRevisions_vardefs.php',
			'to_module'=> 'DocumentRevisions',
		),
		array(
			'from'=> '<basepath>/resources/vardefs/Meetings_vardefs.php',
			'to_module'=> 'Meetings',
		),
		array(
			'from'=> '<basepath>/resources/vardefs/Tasks_vardefs.php',
			'to_module'=> 'Tasks',
		),
		array(
			'from'=> '<basepath>/resources/vardefs/Users_vardefs.php',
			'to_module'=> 'Users',
		),
	),
  'layoutdefs' => array (
  ),
  'relationships' => array (
  ),
  'copy' => array (
    array (
      'from' => '<basepath>/custom',
      'to' => 'custom',
    ),
    array (
      'from' => '<basepath>/include',
      'to' => 'include',
    ),
    array (
      'from' => '<basepath>/themes',
      'to' => 'themes',
    ),
  ),
  'language' => array (
    array(
      'from'=> '<basepath>/resources/language/ja.Contacts.php',
      'to_module'=> 'Contacts',
      'language'=>'ja'
    ),
    array(
      'from'=> '<basepath>/resources/language/en_us.Contacts.php',
      'to_module'=> 'Contacts',
      'language'=>'en_us'
    ),
  ),
);