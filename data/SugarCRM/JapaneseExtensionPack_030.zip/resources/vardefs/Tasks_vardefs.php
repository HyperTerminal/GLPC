<?php
#JLP
$dictionary["Task"]["fields"]["contact_name"] = array (
  'name' => 'contact_name',
  'rname'=>'last_name',
  'db_concat_fields'=> array(0=>'last_name', 1=>'first_name'),
	'source' => 'non-db',
  'len' => '510',
  'group'=>'contact_name',
  'vname' => 'LBL_CONTACT_NAME',
  'reportable'=>false,
  'id_name' => 'contact_id',
  'join_name' => 'contacts',
  'type' => 'relate',
  'module' => 'Contacts',
  'link'=>'contacts',
);
#/JLP
?>