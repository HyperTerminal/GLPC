<?php
#JLP
$dictionary["Call"]["fields"]["contact_name"] = array (
  'name' => 'contact_name',
  'rname' => 'last_name',
  'db_concat_fields'=> array(0=>'last_name', 1=>'first_name'),
  'id_name' => 'contact_id',
  'massupdate' => false,
  'vname' => 'LBL_CONTACT_NAME',
  'type' => 'relate',
  'link'=>'contacts',
  'table' => 'contacts',
  'isnull' => 'true',
  'module' => 'Contacts',
  'join_name' => 'contacts',
  'dbType' => 'varchar',
  'source'=>'non-db',
  'len' => 36,
  'Importable' => 'false',
);
#/JLP
?>