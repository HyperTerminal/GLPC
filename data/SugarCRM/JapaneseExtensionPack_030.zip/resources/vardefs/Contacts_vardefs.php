<?php
#JLP
$dictionary["Contact"]["fields"]["furigana"] = array (
	'name' => 'furigana',
	'vname' => 'LBL_FURIGANA',
	'type' => 'varchar',
	'len' => '255',
	'comment' => '姓名の振り仮名'
);
#/JLP
?>