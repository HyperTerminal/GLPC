<?php
#JLP
$dictionary["DocumentRevision"]["fields"]["created_by_name"] = array (
  'name' => 'created_by_name',
  'rname' => 'user_name',
	'db_concat_fields'=> array(0=>'last_name', 1=>'first_name'),
	'id_name' => 'created_by',
  'vname' => 'LBL_CREATED_BY_NAME',
  'type' => 'relate',
  'table' => 'users',
  'isnull' => 'true',
  'module' => 'Users',
  'dbType' => 'varchar',
  'link'=>'created_by_link',
  'len' => '255',
 	'source'=>'non-db',
);
#/JLP
?>