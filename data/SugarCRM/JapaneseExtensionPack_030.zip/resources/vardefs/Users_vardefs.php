<?php
#JLP
$dictionary["User"]["fields"]["full_name"] = array (
  'name' => 'full_name',
  'rname' => 'full_name',
  'vname' => 'LBL_NAME',
  'type' => 'name',
  'fields' => array('first_name','last_name') ,
  'source' => 'non-db',
  'sort_on' => 'last_name',
  'sort_on2' => 'first_name',
	'db_concat_fields'=> array(0=>'last_name', 1=>'first_name'),
	'len' => '510',
);
$dictionary["User"]["fields"]["name"] = array (
  'name' => 'name',
  'rname' => 'name',
  'vname' => 'LBL_NAME',
  'type' => 'varchar',
  'source' => 'non-db',
  'len' => '510',
	'db_concat_fields'=> array(0=>'last_name', 1=>'first_name'),
	'Importable' => 'false',
);
#/JLP
?>