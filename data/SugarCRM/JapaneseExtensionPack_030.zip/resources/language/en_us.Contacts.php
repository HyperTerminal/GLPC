<?php
$mod_strings = array (
  'LBL_FURIGANA' => 'Hiragana',
  'LBL_LIST_FURIGANA' => 'Hiragana',
	'LBL_LOCALE_DESC_FIRST' => '[f]',
	'LBL_LOCALE_DESC_LAST' => '[l]',
	'LBL_LOCALE_DESC_SALUTATION' => '[s]',
);
?>