<?php
$mod_strings = array (
  'LBL_FURIGANA' => 'ふりがな',
  'LBL_LIST_FURIGANA' => 'ふりがな',
  'LBL_LOCALE_DESC_FIRST' => '[名]' ,
  'LBL_LOCALE_DESC_LAST' => '[姓]' ,
  'LBL_LOCALE_DESC_SALUTATION' => '[敬称]' ,
);
?>