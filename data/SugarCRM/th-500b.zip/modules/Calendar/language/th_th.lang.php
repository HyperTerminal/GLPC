<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'=>'Calendar',
  'LBL_MODULE_TITLE'=>'ปฏิทิน',
  'LNK_NEW_CALL' => 'Schedule Call',
  'LNK_NEW_MEETING' => 'Schedule Meeting',
  'LNK_NEW_APPOINTMENT' => 'Create Appointment',
  'LNK_NEW_TASK' => 'Create Task',
  'LNK_CALL_LIST' => 'Calls',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Tasks',
  'LNK_VIEW_CALENDAR' => 'วันนี้',
  'LBL_MONTH' => 'เดือน',
  'LBL_DAY' => 'วัน',
  'LBL_YEAR' => 'ปี',
  'LBL_WEEK' => 'สัปดาห์',
  'LBL_PREVIOUS_MONTH' => 'เดือนที่แล้ว',
  'LBL_PREVIOUS_DAY' => 'วันที่แล้ว',
  'LBL_PREVIOUS_YEAR' => 'ปีที่แล้ว',
  'LBL_PREVIOUS_WEEK' => 'สัปดาห์ที่แล้ว',
  'LBL_NEXT_MONTH' => 'เดือนถัดไป',
  'LBL_NEXT_DAY' => 'วันถัดไป',
  'LBL_NEXT_YEAR' => 'ปีถัดไป',
  'LBL_NEXT_WEEK' => 'สัปดาห์ถัดไป',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Scheduled',
  'LBL_BUSY' => 'ไม่ว่าง',
  'LBL_CONFLICT' => 'Conflict',
  'LBL_USER_CALENDARS' => 'User Calendars',
  'LBL_SHARED' => 'Shared',
  'LBL_PREVIOUS_SHARED' => 'ย้อนกลับ',
  'LBL_NEXT_SHARED' => 'ถัดไป',
  'LBL_SHARED_CAL_TITLE' => 'Shared Calendar',
  'LBL_USERS' => 'User',
  'LBL_REFRESH' => 'Refresh',
  'LBL_EDIT' => 'Edit',
  'LBL_SELECT_USERS' => 'Select users for calendar display',
  'LBL_FILTER_BY_TEAM' => 'Filter user list by team:',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"อา",
"จ.",
"อัง.",
"พ.",
"พฤ.",
"ศ.",
"ส.",
),
'dom_cal_weekdays_long'=>array(
"อาทิตย์",
"จันทร์",
"อังคาร",
"พุธ",
"พฤหัส",
"ศุกร์",
"เสาร์",
),
'dom_cal_month'=>array(
"",
"ม.ค.",
"ก.พ.",
"มี.ค.",
"เม.ย.",
"พ.ค.",
"มิ.ย.",
"ก.ค.",
"ส.ค.",
"ก.ย.",
"ต.ค.",
"พ.ย.",
"ธ.ค.",
),
'dom_cal_month_long'=>array(
"",
"มกราคม",
"กุมภาพันธ์",
"มีนาคม",
"เมษายน",
"พฤษภาคม",
"มิถุนายน",
"กรกฎาคม",
"สิงหาคม",
"กันยายน",
"ตุลาคม",
"พฤศจิกายน",
"ธันวาคม",
)
);
?>
