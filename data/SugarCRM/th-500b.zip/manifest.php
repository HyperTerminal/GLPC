<?PHP 
$manifest = array( 
	'name' => 'Thai',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'description' 		=> 'Thai Language Pack 5.0.0b',
	'author' 			=> 'Boonyaluck Chaweewongwiwat',
	'published_date'	=> '25/03/2008',
	'version' 			=> '5.0.0b',		
	'acceptable_sugar_flavors' => array (),
	'acceptable_sugar_versions' => array (),
);

$installdefs = array(
	'id'=> 'th_th',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/jscalendar','to'=> 'jscalendar',),
	array('from'=> '<basepath>/install','to'=> 'install',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>
