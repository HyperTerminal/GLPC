<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.21 12:07 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Vendita' ,
	'LBL_MODULE_TITLE' => 'Vendite: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Ricerca Vendita' ,
	'LBL_VIEW_FORM_TITLE' => 'Mostra Vendita' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Vendite' ,
	'LBL_SALE_NAME' => 'Nome Vendita:' ,
	'LBL_SALE' => 'Vendita:' ,
	'LBL_NAME' => 'Nome Vendita' ,
	'LBL_LIST_SALE_NAME' => 'Nome' ,
	'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda' ,
	'LBL_LIST_AMOUNT' => 'Totale' ,
	'LBL_LIST_DATE_CLOSED' => 'Chiudi' ,
	'LBL_LIST_SALE_STAGE' => 'Stage Vendite' ,
	'LBL_ACCOUNT_ID' => 'ID Azienda' ,
	'LBL_CURRENCY_ID' => 'ID Valuta' ,
	'db_sales_stage' => 'LBL_LIST_SALES_STAGE' ,
	'db_name' => 'LBL_NAME' ,
	'db_amount' => 'LBL_LIST_AMOUNT' ,
	'db_date_closed' => 'LBL_LIST_DATE_CLOSED' ,
	'UPDATE' => 'Vendite - Aggiorna Valuta' ,
	'UPDATE_DOLLARAMOUNTS' => 'Aggiorna U.S. Dollar Totali' ,
	'UPDATE_VERIFY' => 'Verifica Totali' ,
	'UPDATE_VERIFY_TXT' => 'Verifica che i valori totali delle venidte siano numeri decimali validi di soli caratteri numerici(0-9) e decimali(.)' ,
	'UPDATE_FIX' => 'Fix Totali' ,
	'UPDATE_FIX_TXT' => 'Attempts to fix any invalid amounts by creating a valid decimal from the current amount. Any modified amount is backed up in the amount_backup database field. If you run this and notice bugs, do not rerun it without restoring from the backup as it may overwrite the backup with new invalid data.' ,
	'UPDATE_DOLLARAMOUNTS_TXT' => 'Update the U.S. Dollar amounts for sales based on the current set currency rates. This value is used to calculate Graphs and List View Currency Amounts.' ,
	'UPDATE_CREATE_CURRENCY' => 'Crea Nuova Valuta:' ,
	'UPDATE_VERIFY_FAIL' => 'Verifica del Dato Fallita:' ,
	'UPDATE_VERIFY_CURAMOUNT' => 'Totale Corrente:' ,
	'UPDATE_VERIFY_FIX' => 'Running Fix would give' ,
	'UPDATE_INCLUDE_CLOSE' => 'Include Closed Records' ,
	'UPDATE_VERIFY_NEWAMOUNT' => 'Nuovo Totale:' ,
	'UPDATE_VERIFY_NEWCURRENCY' => 'Nuova Valuta:' ,
	'UPDATE_DONE' => 'Fatto' ,
	'UPDATE_BUG_COUNT' => 'Sono stati trovati dei Bugs che si cerca di risolvere:' ,
	'UPDATE_BUGFOUND_COUNT' => 'Trovati dei Bugs:' ,
	'UPDATE_COUNT' => 'Dato Aggiornato:' ,
	'UPDATE_RESTORE_COUNT' => 'Totale Records Recuperati:' ,
	'UPDATE_RESTORE' => 'Recupera Totali' ,
	'UPDATE_RESTORE_TXT' => 'recupera i valori dai backups creati durante il fix.' ,
	'UPDATE_FAIL' => 'Non posso aggiornare -' ,
	'UPDATE_NULL_VALUE' => 'Il Totale &#232; NULL impostalo a 0 -' ,
	'UPDATE_MERGE' => 'Unisci Valute' ,
	'UPDATE_MERGE_TXT' => 'Merge multiple currencies into a single currency. If there are multiple currency records for the same currency, you merge them together. This will also merge the currencies for all other modules.' ,
	'LBL_ACCOUNT_NAME' => 'Nome Azienda:' ,
	'LBL_AMOUNT' => 'Totale:' ,
	'LBL_AMOUNT_USDOLLAR' => 'Totale USD:' ,
	'LBL_CURRENCY' => 'Valuta:' ,
	'LBL_DATE_CLOSED' => 'Data Chiusura prospettata:' ,
	'LBL_TYPE' => 'Tipo:' ,
	'LBL_CAMPAIGN' => 'Campagna:' ,
	'LBL_NEXT_STEP' => 'Prossimo Step:' ,
	'LBL_LEAD_SOURCE' => 'Sorgente Lead:' ,
	'LBL_SALES_STAGE' => 'Stage Vendite:' ,
	'LBL_PROBABILITY' => 'Probabilit&#224; (%):' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_DUPLICATE' => 'Possibile Vendita Duplicata' ,
	'MSG_DUPLICATE' => 'The Sale record you are about to create might be a duplicate of a sale record that already exists. Sale records containing similar names are listed below.<br>Click Save to continue creating this new Sale, or click Cancel to return to the module without creating the sale.' ,
	'LBL_NEW_FORM_TITLE' => 'Crea Vendita' ,
	'LNK_NEW_SALE' => 'Crea Vendita' ,
	'LNK_SALE_LIST' => 'Vendita' ,
	'ERR_DELETE_RECORD' => 'Un numero di record deve essre specificato per rimuovere la vendita.' ,
	'LBL_TOP_SALES' => 'Le Mie Migliori Vendite Aperte' ,
	'NTC_REMOVE_OPP_CONFIRMATION' => 'Sei sicuro di volere rimuovere questo contatto dalla vendita?' ,
	'SALE_REMOVE_PROJECT_CONFIRM' => 'Sei sicuro di volere rimuovere questa vendita dal progetto?' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Vendita' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia' ,
	'LBL_RAW_AMOUNT' => 'Raw Amount' ,
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Progetti' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a:' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Assegnato all&#39;Utente' ,
	'LBL_MY_CLOSED_SALES' => 'Le Mie Vendite Chiuse' ,
	'LBL_TOTAL_SALES' => 'Totale Vendite' ,
	'LBL_CLOSED_WON_SALES' => 'Vendite Vinte Chiuse' ,
	'LBL_ASSIGNED_TO_ID' => 'Asseganto a ID' ,
	'LBL_CREATED_ID' => 'Creato da ID' ,
	'LBL_MODIFIED_ID' => 'Modificato da ID' ,
	'LBL_MODIFIED_NAME' => 'Modificato dall&#39;Utente' ,
	'LBL_SALE_INFORMATION' => 'Informazioni Vendite' ,

);


 


?>