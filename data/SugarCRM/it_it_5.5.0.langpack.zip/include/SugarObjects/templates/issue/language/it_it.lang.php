<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.21 12:03 
$mod_strings = array(
	'LBL_NAME' => 'Nome' ,
	'LBL_NUMBER' => 'Numero:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_PRIORITY' => 'Priorit&#224;:' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_RESOLUTION' => 'Soluzione:' ,
	'LBL_LAST_MODIFIED' => 'Ultima modifica' ,
	'LBL_ASSIGNED_TO_ID' => 'Assegnato a:' ,
	'LBL_ASSIGNED_TO_NAME' => 'Utente assegnato:' ,
	'LBL_WORK_LOG' => 'Registro lavoro:' ,
	'LBL_CREATED_BY' => 'Creato da:' ,
	'LBL_DATE_CREATED' => 'Creato il:' ,
	'LBL_DATE_ENTERED' => 'Inserito il:' ,
	'LBL_DATE_MODIFIED' => 'Modificato il:' ,
	'LBL_MODIFIED_BY' => 'Ultima modifica di:' ,
	'LBL_ASSIGNED_USER' => 'Utente assegnato:' ,
	'LBL_SYSTEM_ID' => 'Codice del Sistema:' ,
	'LBL_TEAM_NAME' => 'Nome Team:' ,
	'LBL_TYPE' => 'Tipo:' ,
	'LBL_SUBJECT' => 'Soggetto:' ,

);


 


?>