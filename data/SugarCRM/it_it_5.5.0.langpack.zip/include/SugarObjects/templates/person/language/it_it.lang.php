<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.21 12:04 
$mod_strings = array(
	'LBL_SALUTATION' => 'Titolo professionale' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_FIRST_NAME' => 'Nome' ,
	'LBL_LAST_NAME' => 'Cognome' ,
	'LBL_TITLE' => 'Titolo' ,
	'LBL_DEPARTMENT' => 'Dipartimento' ,
	'LBL_DO_NOT_CALL' => 'Non chiamare' ,
	'LBL_HOME_PHONE' => 'Tel Casa' ,
	'LBL_MOBILE_PHONE' => 'Tel Mobile' ,
	'LBL_OFFICE_PHONE' => 'Tel Lavoro' ,
	'LBL_OTHER_PHONE' => 'Altro Telefono' ,
	'LBL_FAX_PHONE' => 'Fax' ,
	'LBL_EMAIL_ADDRESS' => 'Indirizzo/i Email' ,
	'LBL_PRIMARY_ADDRESS' => 'Indirizzo Primario' ,
	'LBL_PRIMARY_ADDRESS_STREET' => 'Indirizzo Primario' ,
	'LBL_PRIMARY_ADDRESS_STREET_2' => 'Indirizzo Primario Via 2:' ,
	'LBL_PRIMARY_ADDRESS_STREET_3' => 'Indirizzo Primario Via 3:' ,
	'LBL_PRIMARY_ADDRESS_CITY' => 'Comune' ,
	'LBL_PRIMARY_ADDRESS_STATE' => 'Provincia' ,
	'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'CAP' ,
	'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Nazione indirizzo primario:' ,
	'LBL_ALT_ADDRESS_STREET' => 'Altro indirizzo' ,
	'LBL_ALT_ADDRESS_STREET_2' => 'Altro indirizzo Via 2:' ,
	'LBL_ALT_ADDRESS_STREET_3' => 'Altro indirizzo Via 3:' ,
	'LBL_ALT_ADDRESS_CITY' => 'Comune' ,
	'LBL_ALT_ADDRESS_STATE' => 'Provincia' ,
	'LBL_ALT_ADDRESS_POSTALCODE' => 'CAP' ,
	'LBL_ALT_ADDRESS_COUNTRY' => 'Nazione' ,
	'LBL_COUNTRY' => 'Nazione' ,
	'LBL_STREET' => 'Altro Indirizzo' ,
	'LBL_CITY' => 'Comune' ,
	'LBL_STATE' => 'Provincia' ,
	'LBL_POSTALCODE' => 'CAP' ,
	'LBL_POSTAL_CODE' => 'CAP' ,
	'LBL_CONTACT_INFORMATION' => 'Informazioni Contatto' ,
	'LBL_ADDRESS_INFORMATION' => 'Indirizzo/i' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a' ,
	'LBL_ASSISTANT' => 'Assistente' ,
	'LBL_ASSISTANT_PHONE' => 'Tel Assistente' ,
	'LBL_WORK_PHONE' => 'Tel Lavoro' ,
	'LNK_IMPORT_VCARD' => 'Crea da vCard' ,

);


 


?>