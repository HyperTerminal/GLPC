<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.21 12:02 
$mod_strings = array(
	'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Sicuro di voler rimuovere questo utente dal progetto ?' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_ACCOUNT_NAME' => 'Nome Azienda:' ,
	'LBL_ACCOUNT' => 'Azienda:' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_ADDRESS_INFORMATION' => 'Informazioni Indirizzo' ,
	'LBL_ANNUAL_REVENUE' => 'Fatturato Annuo:' ,
	'LBL_ANY_ADDRESS' => 'Indirizzo:' ,
	'LBL_ANY_EMAIL' => 'Email:' ,
	'LBL_ANY_PHONE' => 'Telefono:' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a:' ,
	'LBL_RATING' => 'Rating' ,
	'LBL_ASSIGNED_USER' => 'Assegnato a:' ,
	'LBL_ASSIGNED_TO_ID' => 'Assegnato a:' ,
	'LBL_BILLING_ADDRESS_CITY' => 'Fatturazione, Comune:' ,
	'LBL_BILLING_ADDRESS_COUNTRY' => 'Fatturazione, Nazione:' ,
	'LBL_BILLING_ADDRESS_POSTALCODE' => 'Fatturazione, CAP:' ,
	'LBL_BILLING_ADDRESS_STATE' => 'Fatturazione, Regione:' ,
	'LBL_BILLING_ADDRESS_STREET_2' => 'Fatturazione, Indirizzo (2)' ,
	'LBL_BILLING_ADDRESS_STREET_3' => 'Fatturazione, Indirizzo (3)' ,
	'LBL_BILLING_ADDRESS_STREET_4' => 'Fatturazione, Indirizzo (4)' ,
	'LBL_BILLING_ADDRESS_STREET' => 'Fatturazione, Indirizzo:' ,
	'LBL_BILLING_ADDRESS' => 'Indirizzo di Fatturazione:' ,
	'LBL_ACCOUNT_INFORMATION' => 'Informazioni Azienda' ,
	'LBL_CITY' => 'Comune:' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_COUNTRY' => 'Nazione:' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento:' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica:' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Aziende' ,
	'LBL_DESCRIPTION_INFORMATION' => 'Informazioni Descrizione' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_DUPLICATE' => 'Possibile Azienda Duplicata' ,
	'LBL_EMAIL' => 'Email:' ,
	'LBL_EMPLOYEES' => 'Impiegati:' ,
	'LBL_FAX' => 'Fax:' ,
	'LBL_INDUSTRY' => 'Industria:' ,
	'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda' ,
	'LBL_LIST_CITY' => 'Comune' ,
	'LBL_LIST_EMAIL_ADDRESS' => 'Indirizzo Email' ,
	'LBL_LIST_PHONE' => 'Telefono' ,
	'LBL_LIST_STATE' => 'Provincia' ,
	'LBL_LIST_WEBSITE' => 'Sito web' ,
	'LBL_MEMBER_OF' => 'Membro di:' ,
	'LBL_MEMBER_ORG_FORM_TITLE' => 'Organizzazioni membro' ,
	'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Organizzazioni membro' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_OTHER_EMAIL_ADDRESS' => 'Altro Email:' ,
	'LBL_OTHER_PHONE' => 'Altro Telefono:' ,
	'LBL_OWNERSHIP' => 'Propriet&#224;:' ,
	'LBL_PARENT_ACCOUNT_ID' => 'Codice Azienda &quot;genitore&quot;' ,
	'LBL_PHONE_ALT' => 'Telefono alternativo:' ,
	'LBL_PHONE_FAX' => 'Numero Fax:' ,
	'LBL_PHONE_OFFICE' => 'Telefono Ufficio:' ,
	'LBL_PHONE' => 'Telefono:' ,
	'LBL_POSTAL_CODE' => 'CAP:' ,
	'LBL_PUSH_BILLING' => 'Push Billing' ,
	'LBL_PUSH_SHIPPING' => 'Push Shipping' ,
	'LBL_SAVE_ACCOUNT' => 'Salva Azienda' ,
	'LBL_SHIPPING_ADDRESS_CITY' => 'Spedizione, Comune:' ,
	'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Spedizione, Nazione:' ,
	'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Spedizione, CAP:' ,
	'LBL_SHIPPING_ADDRESS_STATE' => 'Spedizione, Regione:' ,
	'LBL_SHIPPING_ADDRESS_STREET_2' => 'Spedizione, Indirizzo 2' ,
	'LBL_SHIPPING_ADDRESS_STREET_3' => 'Spedizione, Indirizzo 3' ,
	'LBL_SHIPPING_ADDRESS_STREET_4' => 'Spedizione, Indirizzo 4' ,
	'LBL_SHIPPING_ADDRESS_STREET' => 'Spedizione, Indirizzo' ,
	'LBL_SHIPPING_ADDRESS' => 'Indirizzo per la Spedizione:' ,
	'LBL_STATE' => 'Provincia:' ,
	'LBL_TEAMS_LINK' => 'I Team' ,
	'LBL_TICKER_SYMBOL' => 'Codice Azionario:' ,
	'LBL_TYPE' => 'Tipo:' ,
	'LBL_USERS_ASSIGNED_LINK' => 'Utenti Assegnati' ,
	'LBL_USERS_CREATED_LINK' => 'Creato dagli Utenti' ,
	'LBL_USERS_MODIFIED_LINK' => 'Utenti Modificati' ,
	'LBL_VIEW_FORM_TITLE' => 'Vista Azienda' ,
	'LBL_WEBSITE' => 'Sito web:' ,
	'LNK_ACCOUNT_LIST' => 'Aziende' ,
	'LNK_NEW_ACCOUNT' => 'Nuova Azienda' ,
	'MSG_DUPLICATE' => 'La creazione di questa azienda potrebbe produrre un doppione. Puoi in alternativa selezionare un&#39;azienda dalla lista seguente o cliccare Salva per continuare con l&#39;inserimento di una nuova azienda con i dati gi&#224; inseriti.' ,
	'MSG_SHOW_DUPLICATES' => 'La creazione di questa azienda potrebbe produrre un doppione. Puoi cliccare Salva per continuare con l&#39;inserimento di una nuova azienda con i dati gi&#224; inseriti oppure premere Annulla.' ,
	'NTC_COPY_BILLING_ADDRESS' => 'Copia l&#39;indirizzo di fatturazione in quello di spedizione' ,
	'NTC_COPY_BILLING_ADDRESS2' => 'Copia su spedizione' ,
	'NTC_COPY_SHIPPING_ADDRESS' => 'Copia l&#39;indirizzo di spedizione in quello di fatturazione' ,
	'NTC_COPY_SHIPPING_ADDRESS2' => 'Copia su fatturazione' ,
	'NTC_DELETE_CONFIRMATION' => 'Confermi la cancellazione di questo dato ?' ,
	'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Confermi la rimozione di questo dato ?' ,
	'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Sei sicuro di voler eliminare questa informazione ?' ,

);


 


?>