<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 21:33 
$mod_strings = array(
	'LBL_TEAM' => 'Team' ,
	'LBL_TEAM_ID' => 'Team Id' ,
	'LBL_ASSIGNED_TO_ID' => 'Id Utente Assegnato' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a' ,
	'LBL_ID' => 'ID' ,
	'LBL_DATE_ENTERED' => 'Data Creazione' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica' ,
	'LBL_MODIFIED' => 'Modificato Da' ,
	'LBL_MODIFIED_ID' => 'Modificato Da Id' ,
	'LBL_MODIFIED_NAME' => 'Modificato Da Name' ,
	'LBL_CREATED' => 'Creato Da' ,
	'LBL_CREATED_ID' => 'Creato Da Id' ,
	'LBL_DESCRIPTION' => 'Descrizione' ,
	'LBL_DELETED' => 'Cancellato' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_SAVING' => 'Salvataggio...' ,
	'LBL_SAVED' => 'Salvato' ,
	'LBL_CREATED_USER' => 'Creato da' ,
	'LBL_MODIFIED_USER' => 'Modificato da' ,
	'LBL_LIST_FORM_TITLE' => 'Sugar Feed List' ,
	'LBL_MODULE_NAME' => 'Sugar Feed' ,
	'LBL_MODULE_TITLE' => 'Sugar Feed' ,
	'LBL_DASHLET_DISABLED' => 'Attenzione: Il sistema degli Sugar Feed &#232; disabilitato, nessun nuovo feed sar&#224; quindi postato' ,
	'LBL_ADMIN_SETTINGS' => 'Impostazioni Sugar Feed' ,
	'LBL_RECORDS_DELETED' => 'Tutti i precedenti Sugar Feed sono stati rimossi, se il sistema Sugar Feed &#232; abilitato, nuove voci saranno generate in automatico.' ,
	'LBL_CONFIRM_DELETE_RECORDS' => 'Sei sicuro di volere cancellare tutti i Sugar Feed?' ,
	'LBL_FLUSH_RECORDS' => 'Cancella Feed' ,
	'LBL_ENABLE_FEED' => 'Abilita Sugar Feed' ,
	'LBL_ENABLE_MODULE_LIST' => 'Attiva Feeds per' ,
	'LBL_HOMEPAGE_TITLE' => 'I Miei Sugar Feed' ,
	'LNK_NEW_RECORD' => 'Crea Sugar Feed' ,
	'LNK_LIST' => 'Sugar Feed' ,
	'LBL_SEARCH_FORM_TITLE' => 'Ricerca Sugar Feed' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Visualizza History' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_SUGAR_FEED_SUBPANEL_TITLE' => 'Sugar Feed' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Sugar Feed' ,
	'LBL_ALL' => 'All' ,
	'LBL_USER_FEED' => 'Feed Utente' ,
	'LBL_ENABLE_USER_FEED' => 'Attiva Feed Utente' ,
	'LBL_TO' => 'Invia a' ,
	'LBL_IS' => '&#232;' ,
	'LBL_DONE' => 'Fatto' ,
	'LBL_TITLE' => 'Titolo' ,
	'LBL_ROWS' => 'Righe' ,
	'LBL_CATEGORIES' => 'Moduli' ,
	'LBL_TIME_LAST_WEEK' => 'Ultima settimana' ,
	'LBL_TIME_WEEKS' => 'Settimane' ,
	'LBL_TIME_DAYS' => 'Giorni' ,
	'LBL_TIME_YESTERDAY' => 'Ieri' ,
	'LBL_TIME_HOURS' => 'Ore' ,
	'LBL_TIME_HOUR' => 'Ore' ,
	'LBL_TIME_MINUTES' => 'Minuti' ,
	'LBL_TIME_MINUTE' => 'Minuto' ,
	'LBL_TIME_SECONDS' => 'Secondi' ,
	'LBL_TIME_SECOND' => 'Secondo' ,
	'LBL_TIME_AGO' => 'fa' ,
	'CREATED_CONTACT' => 'creato un <b>NUOVO</b> contatto' ,
	'CREATED_OPPORTUNITY' => 'creata una <b>NUOVA</b> opportunit&#224;' ,
	'CREATED_CASE' => 'creato un <b>NUOVO</b> case' ,
	'CREATED_LEAD' => 'creato un <b>NUOVO</b> lead' ,
	'FOR' => 'per' ,
	'CLOSED_CASE' => '<b>CHIUDI</b> un case' ,
	'CONVERTED_LEAD' => '<b>CONVERTI</b> un lead' ,
	'WON_OPPORTUNITY' => 'ha <b>VINTO</b> un opportunit&#224;' ,
	'WITH' => 'con' ,
	'LBL_LINK_TYPE_Link' => 'Link' ,
	'LBL_LINK_TYPE_Image' => 'Immagine' ,
	'LBL_LINK_TYPE_YouTube' => 'YouTube�' ,
	'LBL_SELECT' => 'Seleziona' ,
	'LBL_POST' => 'Invia' ,

);


 


?>