<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 13:35 
$mod_strings = array(
	'LBL_ALLOW_ALL' => 'Tutti' ,
	'LBL_ALLOW_NONE' => 'Nessuno' ,
	'LBL_ALLOW_OWNER' => 'Proprietario' ,
	'LBL_ROLE' => 'Ruolo' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_DESCRIPTION' => 'Descrizione' ,
	'LIST_ROLES' => 'Lista Ruoli' ,
	'LBL_USERS_SUBPANEL_TITLE' => 'Utenti' ,
	'LIST_ROLES_BY_USER' => 'Elenca Ruoli per Utente' ,
	'LBL_ROLES_SUBPANEL_TITLE' => 'Ruoli Utente' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca' ,
	'LBL_NO_ACCESS' => 'Non hai accesso a quest&#39;area. Se necessiti dell&#39;accesso contatta l&#39;amministratore del Crm.' ,
	'LBL_ADDING' => 'Aggiunta per' ,

);


 


?>