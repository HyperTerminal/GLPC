<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 20:14 
$mod_strings = array(
	'LBL_ID' => 'Codice Relazione' ,
	'LBL_RELATIONSHIP_NAME' => 'Nome Relazione' ,
	'LBL_LHS_MODULE' => 'Nome Modulo LHS' ,
	'LBL_LHS_TABLE' => 'Nome Tabella LHS' ,
	'LBL_LHS_KEY' => 'Nome Chiave LHS' ,
	'LBL_RHS_MODULE' => 'Nome Modulo RHS' ,
	'LBL_RHS_TABLE' => 'Nome Tabella RHS' ,
	'LBL_RHS_KEY' => 'Nome Chiave RHS' ,
	'LBL_JOIN_TABLE' => 'Nome Tabella per il Join' ,
	'LBL_JOIN_KEY_LHS' => 'Join a Sinistra' ,
	'LBL_JOIN_KEY_RHS' => 'Join a Destra' ,
	'LBL_RELATIONSHIP_TYPE' => 'Tipo Relazione' ,
	'LBL_RELATIONSHIP_ROLE_COLUMN' => 'Relationship Role Column Name' ,
	'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE' => 'Relationship Role Column Value' ,
	'LBL_REVERSE' => 'Inverti' ,
	'LBL_DELETED' => 'Eliminato' ,

);


 


?>