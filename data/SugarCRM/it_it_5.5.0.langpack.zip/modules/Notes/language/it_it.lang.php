<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:58 
$mod_strings = array(
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_ACCOUNT_ID' => 'Cod. Azienda:' ,
	'LBL_CASE_ID' => 'Cod. Ticket Supporto:' ,
	'LBL_CLOSE' => 'Chiudi:' ,
	'LBL_COLON' => ':' ,
	'LBL_CONTACT_ID' => 'Cod. Contatto:' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Note' ,
	'LBL_DESCRIPTION' => 'Descrizione' ,
	'LBL_EMAIL_ADDRESS' => 'Indirizzo Email:' ,
	'LBL_EMAIL_ATTACHMENT' => 'Allegato Email' ,
	'LBL_FILE_MIME_TYPE' => 'Tipo MIME' ,
	'LBL_FILE_URL' => 'URL del File' ,
	'LBL_FILENAME' => 'Allegato:' ,
	'LBL_LEAD_ID' => 'Cod. Lead:' ,
	'LBL_LIST_CONTACT_NAME' => 'Nome Contatto' ,
	'LBL_LIST_DATE_MODIFIED' => 'Ultima Modifica' ,
	'LBL_LIST_FILENAME' => 'Allegato' ,
	'LBL_LIST_FORM_TITLE' => 'Elenca Note' ,
	'LBL_LIST_RELATED_TO' => 'Relativo a' ,
	'LBL_LIST_SUBJECT' => 'Soggetto' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_CONTACT' => 'Contatto' ,
	'LBL_MODULE_NAME' => 'Note' ,
	'LBL_MODULE_TITLE' => 'Note: Home' ,
	'LBL_NEW_FORM_TITLE' => 'Nuova Nota' ,
	'LBL_NOTE_STATUS' => 'Nota' ,
	'LBL_NOTE_SUBJECT' => 'Soggetto della Nota:' ,
	'LBL_NOTES_SUBPANEL_TITLE' => 'Allegati' ,
	'LBL_NOTE' => 'Nota:' ,
	'LBL_OPPORTUNITY_ID' => 'Cod. Opportunit&#224;:' ,
	'LBL_PARENT_ID' => 'Cod. Genitore:' ,
	'LBL_PARENT_TYPE' => 'Tipo Genitore' ,
	'LBL_PHONE' => 'Telefono:' ,
	'LBL_PORTAL_FLAG' => 'Mostra nel Portale ?' ,
	'LBL_EMBED_FLAG' => 'Includi nella mail?' ,
	'LBL_PRODUCT_ID' => 'Cod. Prodotto:' ,
	'LBL_QUOTE_ID' => 'Cod. Offerta:' ,
	'LBL_RELATED_TO' => 'Relativo a' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Nota' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_SUBJECT' => 'Soggetto:' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_EMAIL_LIST' => 'Lista Email' ,
	'LNK_IMPORT_NOTES' => 'Importa Note' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_EMAIL' => 'Nuova Email' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LNK_NOTE_LIST' => 'Note' ,
	'LNK_TASK_LIST' => 'Compiti' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'LBL_MEMBER_OF' => 'Membro di:' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,
	'LBL_REMOVING_ATTACHMENT' => 'Rimozione allegato...' ,
	'ERR_REMOVING_ATTACHMENT' => 'Rimozione fallita...' ,
	'LBL_CREATED_BY' => 'Creato da' ,
	'LBL_MODIFIED_BY' => 'Modificato da' ,
	'LBL_SEND_ANYWAYS' => 'Il messaggio &#232; senza oggetto. Inviare/Salvare lo stesso ?' ,
	'LBL_LIST_EDIT_BUTTON' => 'Modifica' ,
	'LBL_ACTIVITIES_REPORTS' => 'Report Attivit&#224;' ,

);


 


?>