<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 21:32 
$mod_strings = array(
	'LBL_EDIT_LAYOUT' => 'Modifica Maschera' ,
	'LBL_EDIT_ROWS' => 'Modifica Righe' ,
	'LBL_EDIT_COLUMNS' => 'Modifica Colonne' ,
	'LBL_EDIT_LABELS' => 'Modifica Etichette' ,
	'LBL_EDIT_FIELDS' => 'Modifica Campi Personalizzati' ,
	'LBL_ADD_FIELDS' => 'Aggiungi Campi Personalizzati' ,
	'LBL_DISPLAY_HTML' => 'Mostra Codice HTML' ,
	'LBL_SELECT_FILE' => 'Scegli File' ,
	'LBL_SAVE_LAYOUT' => 'Salva Maschera' ,
	'LBL_SELECT_A_SUBPANEL' => 'Scegli un pannello' ,
	'LBL_SELECT_SUBPANEL' => 'Scegli pannello' ,
	'LBL_MODULE_TITLE' => 'Studio' ,
	'LBL_TOOLBOX' => 'Strumenti' ,
	'LBL_STAGING_AREA' => 'Area di Lavoro (trascina qui gli oggetti)' ,
	'LBL_SUGAR_FIELDS_STAGE' => 'Campi (clicca gli oggetti per aggiungerli all&#39;area di lavoro)' ,
	'LBL_SUGAR_BIN_STAGE' => 'Cestino (clicca gli oggetti per aggiungerli all&#39;area di lavoro)' ,
	'LBL_VIEW_SUGAR_FIELDS' => 'Mostra i campi del CRM' ,
	'LBL_VIEW_SUGAR_BIN' => 'Mostra il Cestino' ,
	'LBL_FAILED_TO_SAVE' => 'Impossibile Salvare' ,
	'LBL_CONFIRM_UNSAVE' => 'Le modifiche andranno perse. Sicuro di voler continuare ?' ,
	'LBL_PUBLISHING' => 'Pubblicazione ...' ,
	'LBL_PUBLISHED' => 'Pubblicato' ,
	'LBL_FAILED_PUBLISHED' => 'Impossibile Pubblicare' ,
	'LBL_DROP_HERE' => '[Trascina Qui]' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_LABEL' => 'Etichetta' ,
	'LBL_MASS_UPDATE' => 'Aggiornamento Multiplo' ,
	'LBL_AUDITED' => 'Monitora' ,
	'LBL_CUSTOM_MODULE' => 'Modulo' ,
	'LBL_DEFAULT_VALUE' => 'Valore Predefinito' ,
	'LBL_REQUIRED' => 'Richiesto' ,
	'LBL_DATA_TYPE' => 'Tipo' ,
	'LBL_HISTORY' => 'Cronologia' ,
	'LBL_SW_WELCOME' => '<h2>Benvenuto in Studio!</h2><br> Cosa desideri fare ?<br><b> Scegli tra le opzioni seguenti.</b>' ,
	'LBL_SW_EDIT_MODULE' => 'Modifica un Modulo' ,
	'LBL_SW_EDIT_DROPDOWNS' => 'Modifica un Lista Valori' ,
	'LBL_SW_EDIT_TABS' => 'Configura Sezioni' ,
	'LBL_SW_RENAME_TABS' => 'Rinomina Sezioni' ,
	'LBL_SW_EDIT_GROUPTABS' => 'Configura Gruppo Sezioni' ,
	'LBL_SW_EDIT_PORTAL' => 'Modifica Portale' ,
	'LBL_SW_EDIT_WORKFLOW' => 'Modifica Flusso di Lavoro' ,
	'LBL_SW_REPAIR_CUSTOMFIELDS' => 'Ripara Campi Personalizzati' ,
	'LBL_SW_MIGRATE_CUSTOMFIELDS' => 'Migrazione Campi Personalizzati' ,
	'LBL_SMW_WELCOME' => '<h2>Benvenuto in Studio!</h2><br><b>Scegli un modulo tra i seguenti.' ,
	'LBL_SMA_WELCOME' => '<h2>Modifica un Modulo</h2>Cosa vuoi fare con questo modulo ?<br><b>Scegli l&#39;azione che desideri eseguire.' ,
	'LBL_SMA_EDIT_CUSTOMFIELDS' => 'Modifica Campi Personalizzati' ,
	'LBL_SMA_EDIT_LAYOUT' => 'Modifica Maschera' ,
	'LBL_SMA_EDIT_LABELS' => 'Modifica Etichette' ,
	'LBL_MB_PREVIEW' => 'Anteprima' ,
	'LBL_MB_RESTORE' => 'Ripristina' ,
	'LBL_MB_DELETE' => 'Elimina' ,
	'LBL_MB_COMPARE' => 'Confronta' ,
	'LBL_MB_WELCOME' => '<h2>Cronologia</h2><br> La Cronologia ti permette di vedere edizioni precedenti del file su cui stai lavorando. Puoi confrontare e ripristinare versioni precedenti. Se ripristini il file questo andr&#224; a sostituire il file su cui stai lavorando. Dovrai pubblicarlo prima che qualcuno possa vederlo.<br> Cosa desideri fare ?<br><b> Scegli tra le opzioni seguenti.</b>' ,
	'LBL_ED_CREATE_DROPDOWN' => 'Nuova Lista' ,
	'LBL_ED_WELCOME' => '<h2>Editor di Liste</h2><br><b>Puoi creare una lista gi&#224; esistente oppure crearne una nuova.' ,
	'LBL_DROPDOWN_NAME' => 'Nome della lista valori' ,
	'LBL_DROPDOWN_LANGUAGE' => 'Lingua della lista valori' ,
	'LBL_TABGROUP_LANGUAGE' => 'Lingua Sezione di Gruppo' ,
	'LBL_EC_WELCOME' => '<h2>Editor Campi Personalizzati</h2><br><b>Puoi vedere e modificare campi personalizzati esistenti, crearne uno nuovo, o pulire la cache di un campo personalizzato.' ,
	'LBL_EC_VIEW_CUSTOMFIELDS' => 'Mostra Campi Personalizzati' ,
	'LBL_EC_CREATE_CUSTOMFIELD' => 'Nuovo Campo Personalizzato' ,
	'LBL_EC_CLEAR_CACHE' => 'Pulisci Cache' ,
	'LBL_SM_WELCOME' => '<h2>Cronologia</h2><br><b>Scegli il file che vuoi vedere.</b>' ,
	'LBL_DD_DISPALYVALUE' => 'Valore Visualizzato' ,
	'LBL_DD_DATABASEVALUE' => 'Valore da database' ,
	'LBL_DD_ALL' => 'Tutto' ,
	'LBL_BTN_SAVE' => 'Salva' ,
	'LBL_BTN_SAVEPUBLISH' => 'Salva & Pubblica' ,
	'LBL_BTN_HISTORY' => 'Cronologia' ,
	'LBL_BTN_NEXT' => 'Avanti' ,
	'LBL_BTN_BACK' => 'Indietro' ,
	'LBL_BTN_ADDCOLS' => 'Aggiungi Colonne' ,
	'LBL_BTN_ADDROWS' => 'Aggiungi Righe' ,
	'LBL_BTN_UNDO' => 'Annulla' ,
	'LBL_BTN_REDO' => 'Ripeti' ,
	'LBL_BTN_ADDCUSTOMFIELD' => 'Aggiungi Campo Personalizzato' ,
	'LBL_BTN_TABINDEX' => 'Modifica Ordine Sezioni' ,
	'LBL_TAB_SUBTABS' => 'Sotto-Sezioni' ,
	'LBL_MODULES' => 'Moduli' ,
	'LBL_MODULE_NAME' => 'Amministrazione' ,
	'LBL_CONFIGURE_GROUP_TABS' => 'Configura i Gruppi di Sezioni' ,
	'LBL_GROUP_TAB_WELCOME' => 'Il modello di Gruppo Sezioni seguente verr&#224; usato quando l&#39;utente sceglie la visualizzazione per Gruppi al posto di quella tradizionale per Moduli.' ,
	'LBL_RENAME_TAB_WELCOME' => 'Clicca sul Valore Visualizzato di una sezione per rinominarla' ,
	'LBL_DELETE_MODULE' => 'Elimina Modulo' ,
	'LBL_DISPLAY_OTHER_TAB_HELP' => 'Seleziona per mostrare la sezione &quot;Altro&quot; nella barra di navigazione. Per default, la sezione &quot;Altro&quot; mostra qualsiasi modulo non incluso in altri gruppi.' ,
	'LBL_TAB_GROUP_LANGUAGE_HELP' => 'Per impostare l&#39;etichetta dalla scheda del gruppo per altri lingue disponibili, seleziona una langua, modifica l&#39;etichetta a clicca Salva & Pubblica per applicare le modifiche per quella lingua.' ,
	'LBL_ADD_GROUP' => 'Aggiungi Gruppo' ,
	'LBL_NEW_GROUP' => 'Nuovo Gruppo' ,
	'LBL_RENAME_TABS' => 'Rinomina Sezioni' ,
	'LBL_DISPLAY_OTHER_TAB' => 'Mostra la sezione &#39;Altro&#39;' ,
	'LBL_DEFAULT' => 'Predefinito' ,
	'LBL_ADDITIONAL' => 'Addizionale' ,
	'LBL_AVAILABLE' => 'Disponibile' ,
	'LBL_LISTVIEW_DESCRIPTION' => 'Ci sono tre colonne mostrate. La &#39;colonna dei campi predefiniti&#39; contiene i campi mostrati normalmente in una lista, la &#39;colonna dei campi addizionali&#39; contiene i campi che un utente pu&#242; scegliere per la creazione di una vista personalizzata, e le colonne disponibili sono colonne che puoi, come amministratore, aggiungere sia alla colonna dei campi predefiniti che addizionali per l&#39;uso futuro degli utenti, campi che al momento non sono in uso.' ,
	'LBL_LISTVIEW_EDIT' => 'Modifica Vista Elenco' ,
	'ERROR_ALREADY_EXISTS' => 'Errore: Il Campo esiste gi&#224;' ,
	'ERROR_INVALID_KEY_VALUE' => 'Errore: Valore-chiave non valido: [&#39;]' ,
	'LBL_SW_SUGARPORTAL' => 'Portale del CRM' ,
	'LBL_SMP_WELCOME' => 'Scegli dalla lista seguente il modulo che desideri modificare' ,
	'LBL_SP_WELCOME' => 'Benvenuto nello Studio del CRM. Qui puoi modificare i moduli o sincronizzare l&#39;applicativo con un&#39;istanza esterna.<br>Scegli dalla lista seguente.' ,
	'LBL_SP_SYNC' => 'Sinc Portale' ,
	'LBL_SYNCP_WELCOME' => 'Inserisci l&#39;URL del portale che desideri aggiornare.<br>Ti verr&#224; richiesto il nome utente e la password.<br>Inserisci i dati richiesti e premi il bottone Inizia Sincronizzazione.' ,
	'LBL_LISTVIEWP_DESCRIPTION' => 'Di seguito ci sono due colonne: &#39;Predefinito&#39; che contiene le colonne da mostrare e &#39;Disponibile&#39; con i campi che non verranno visualizzati, ma che sono disponibili per la visualizzazione. Puoi cambiare le liste e riordinare i campi trascinandoli con il mouse.' ,
	'LBL_SP_STYLESHEET' => 'Carica un Foglio di Stile' ,
	'LBL_SP_UPLOADSTYLE' => 'Clicca il bottone Sfoglia e scegli un file di stile dal tuo computer per l&#39;upload.<br>Il file verr&#224; usato durante la prossima sincronizzazione.' ,
	'LBL_SP_UPLOADED' => 'Caricato' ,
	'ERROR_SP_UPLOADED' => 'Assicurati di caricare un foglio di stile CSS.' ,
	'LBL_SP_PREVIEW' => 'Ecco un&#39;anteprima di come apparir&#224; il tuo foglio di stile' ,

);


 


?>