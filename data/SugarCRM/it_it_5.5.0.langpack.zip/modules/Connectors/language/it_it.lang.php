<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 17:37 
$mod_strings = array(
	'LBL_ADD_MODULE' => 'Aggiungere' ,
	'LBL_ADDRCITY' => 'Citt&#224;' ,
	'LBL_ADDRCOUNTRY' => 'Paese' ,
	'LBL_ADDRCOUNTRY_ID' => 'Paese Id' ,
	'LBL_ADDRSTATEPROV' => 'Stato' ,
	'LBL_ADMINISTRATION' => 'Amministrazione dei Connettori' ,
	'LBL_ADMINISTRATION_MAIN' => 'Impostazioni Connettore' ,
	'LBL_AVAILABLE' => 'Disponibile' ,
	'LBL_BACK' => '< Indietro' ,
	'LBL_COMPANY_ID' => 'Cod. Azienda' ,
	'LBL_CONFIRM_CONTINUE_SAVE' => 'Qualche campo obbligatorio &#232; stato lasciato vuoto. Procedere con il salvataggio ?' ,
	'LBL_CONNECTOR' => 'Connettore' ,
	'LBL_CONNECTOR_FIELDS' => 'Campi del Connettore' ,
	'LBL_DATA' => 'Data' ,
	'LBL_DEFAULT' => 'Default' ,
	'LBL_DELETE_MAPPING_ENTRY' => 'Si &#232; sicuri di volere cancellare questo record?' ,
	'LBL_DISABLED' => 'Disabilita' ,
	'LBL_DUNS' => 'DUNS' ,
	'LBL_EMPTY_BEANS' => 'Nessuna corrispondenza trovata per il criterio di ricerca usato.' ,
	'LBL_ENABLED' => 'Abilita' ,
	'LBL_FINSALES' => 'Finsales' ,
	'LBL_MARKET_CAP' => 'Market Cap' ,
	'LBL_MERGE' => 'Unisci' ,
	'LBL_MODIFY_DISPLAY_TITLE' => 'Attiva i Connettori' ,
	'LBL_MODIFY_DISPLAY_DESC' => 'Seleziona i moduli da abilitare per ogni connettore.' ,
	'LBL_MODIFY_DISPLAY_PAGE_TITLE' => 'Impostazioni Connettore: Attiva i Connettori' ,
	'LBL_MODULE_FIELDS' => 'Campi dei Moduli' ,
	'LBL_MODIFY_MAPPING_TITLE' => 'Corrispondenze dei campi dei Connettori' ,
	'LBL_MODIFY_MAPPING_DESC' => 'Crea una corrispondenza dei campi del connettore con i campi del modulo per determinare quali dati del connettore possono essere visti ed uniti con i dati del modulo.' ,
	'LBL_MODIFY_MAPPING_PAGE_TITLE' => 'Impostazioni Connettore: Corrispondenza dei campi' ,
	'LBL_MODIFY_PROPERTIES_TITLE' => 'Impostazione Parametri del Connettore' ,
	'LBL_MODIFY_PROPERTIES_DESC' => 'Configura i parametri per ogni Connettore, inclusi URLs e API keys.' ,
	'LBL_MODIFY_PROPERTIES_PAGE_TITLE' => 'Impostazioni Connettore: Imposta i parametri del Connettore' ,
	'LBL_MODIFY_SEARCH_TITLE' => 'Gestione della Ricerca del Connettore' ,
	'LBL_MODIFY_SEARCH' => 'Ricerca' ,
	'LBL_MODIFY_SEARCH_DESC' => 'Seleziona i campi del connettore da usare per la ricerca dei dati in ogni modulo.' ,
	'LBL_MODIFY_SEARCH_PAGE_TITLE' => 'Impostazioni Connettore: Gestione dei parametri di ricerca' ,
	'LBL_MODULE_NAME' => 'Connettori' ,
	'LBL_NO_PROPERTIES' => 'Non ci sono parametri configurabili per questo connettore.' ,
	'LBL_PARENT_DUNS' => 'Parent DUNS' ,
	'LBL_PREVIOUS' => '< Indietro' ,
	'LBL_QUOTE' => 'Quote' ,
	'LBL_RECNAME' => 'Nome dell&#39;Azienda' ,
	'LBL_RESET_TO_DEFAULT' => 'Reset to Default' ,
	'LBL_RESET_TO_DEFAULT_CONFIRM' => 'Si &#232; sicuri di volere ritornare alla configurazione di default?' ,
	'LBL_RESET_BUTTON_TITLE' => 'Reset [Alt+R]' ,
	'LBL_RESULT_LIST' => 'Lista dei dati' ,
	'LBL_RUN_WIZARD' => 'Lancia il Wizard' ,
	'LBL_SAVE' => 'Salva' ,
	'LBL_SEARCHING_BUTTON_LABEL' => 'Ricerca...' ,
	'LBL_SHOW_IN_LISTVIEW' => 'Mostra nella lista unita' ,
	'LBL_SMART_COPY' => 'Copia intelligente' ,
	'LBL_SUMMARY' => 'Sommario' ,
	'LBL_STEP1' => 'Ricerca e Visualizza Dati' ,
	'LBL_STEP2' => 'Unisci i records con' ,
	'LBL_TEST_SOURCE' => 'Test del Connettore' ,
	'LBL_TEST_SOURCE_FAILED' => 'Test Fallito' ,
	'LBL_TEST_SOURCE_RUNNING' => 'Test in corso...' ,
	'LBL_TEST_SOURCE_SUCCESS' => 'Test riuscito' ,
	'LBL_TITLE' => 'Unione dei dati' ,
	'LBL_ULTIMATE_PARENT_DUNS' => 'Ultimate Parent DUNS' ,
	'ERROR_RECORD_NOT_SELECTED' => 'Errore: selezionare un record dalla lista prima di procedere.' ,
	'ERROR_EMPTY_WRAPPER' => 'Errore : non &#232; possibile  recuperare i campi disponibili della sorgente []' ,
	'ERROR_EMPTY_SOURCE_ID' => 'Errore : Id sorgente non specificato o vuoto.' ,
	'ERROR_EMPTY_RECORD_ID' => 'Errore : Id del record non specificato o vuoto.' ,
	'ERROR_NO_ADDITIONAL_DETAIL' => 'Errore : Non sono stati trovati ulteriori dettagli per il record.' ,
	'ERROR_NO_SEARCHDEFS_DEFINED' => 'Nessun modulo &#232; stato abilitato per questo connettore. Selezionare un modulo per questo connettore dalla pagina Attiva i Connettori.' ,
	'ERROR_NO_SOURCEDEFS_FILE' => 'Errore : Impossible trovar il file sourcedefs.php.' ,
	'ERROR_NO_SOURCEDEFS_SPECIFIED' => 'Errore : Non &#232; stata specificata la sorgente da cui recuperare i dati.' ,
	'ERROR_NO_CONNECTOR_DISPLAY_CONFIG_FILE' => 'Errore : non ci sono connettori corrispondenti a questo modulo.' ,
	'ERROR_NO_SEARCHDEFS_MAPPING' => 'Errore : non ci sono criteri di ricerca definiti per il modulo ed il connettore. Contattare il vostro amministratore di sistema.' ,
	'ERROR_NO_FIELDS_MAPPED' => 'Errore : Occorre definire almeno una corrispondenza tra un campo del Connettore ed un campo del modulo per ognuno dei moduli.' ,
	'ERROR_NO_DISPLAYABLE_MAPPED_FIELDS' => 'Errore : Non ci sono campi di modulo definiti per la visualizzazione dei risultati. Contattare il vostro amministratore di sistema.' ,

);


 


?>