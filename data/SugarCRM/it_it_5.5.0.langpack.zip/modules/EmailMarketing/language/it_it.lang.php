<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 22:17 
$mod_strings = array(
	'LBL_REPLY_ADDR' => 'Indirizzo per risposte:' ,
	'LBL_REPLY_NAME' => 'Nome per risposte:' ,
	'LBL_MODULE_NAME' => 'Email Marketing' ,
	'LBL_MODULE_TITLE' => 'Email Marketing: Home' ,
	'LBL_LIST_FORM_TITLE' => 'Campagne Email Marketing' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_FROM_ADDR' => 'Email Mittente' ,
	'LBL_LIST_DATE_START' => 'Data Inizio' ,
	'LBL_LIST_TEMPLATE_NAME' => 'Modello Email' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_STATUS' => 'Stato' ,
	'LBL_STATUS_TEXT' => 'Stato:' ,
	'LBL_TEMPLATE_NAME' => 'Nome modello' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica' ,
	'LBL_MODIFIED' => 'Modificato da:' ,
	'LBL_CREATED' => 'Creato da:' ,
	'LBL_MESSAGE_FOR' => 'Invia il Messaggio A:' ,
	'LBL_MESSAGE_FOR_ID' => 'Messaggio Per' ,
	'LBL_FROM_NAME' => 'Nome Mittente:' ,
	'LBL_FROM_ADDR' => 'Indirizzo Email Mittente:' ,
	'LBL_DATE_START' => 'Data Inizio' ,
	'LBL_TIME_START' => 'Ora Inizio' ,
	'LBL_START_DATE_TIME' => 'Data e Ora Inizio:' ,
	'LBL_TEMPLATE' => 'Modello Email:' ,
	'LBL_MODIFIED_BY' => 'Modificato da:' ,
	'LBL_CREATED_BY' => 'Creato da:' ,
	'LBL_DATE_CREATED' => 'Data Creazione:' ,
	'LBL_DATE_LAST_MODIFIED' => 'Data Modifica:' ,
	'LNK_NEW_CAMPAIGN' => 'Nuova Campagna' ,
	'LNK_CAMPAIGN_LIST' => 'Campagne' ,
	'LNK_NEW_PROSPECT_LIST' => 'Nuova Lista Obiettivi' ,
	'LNK_PROSPECT_LIST_LIST' => 'Liste Obiettivi' ,
	'LNK_NEW_PROSPECT' => 'Nuovo Obiettivo' ,
	'LNK_PROSPECT_LIST' => 'Obiettivi' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Email Marketing' ,
	'LBL_CREATE_EMAIL_TEMPLATE' => 'Nuovo' ,
	'LBL_EDIT_EMAIL_TEMPLATE' => 'Modifica' ,
	'LBL_FROM_MAILBOX' => 'Dalla Casella' ,
	'LBL_FROM_MAILBOX_NAME' => 'Utilizza Casella:' ,
	'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => 'Liste Obiettivo' ,
	'LBL_ALL_PROSPECT_LISTS' => 'Scegli per selezionare tutte le Liste Obiettivo nella Campagna.' ,
	'LBL_RELATED_PROSPECT_LISTS' => 'Tutte le Liste Obiettivo collegate al messaggio.' ,
	'LBL_PROSPECT_LIST_NAME' => 'Nome:' ,
	'LBL_LIST_PROSPECT_LIST_NAME' => 'Liste Obiettivo' ,
	'LBL_MODULE_SEND_TEST' => 'Campagna: Invia Test' ,
	'LBL_MODULE_SEND_EMAILS' => 'Campagna: Invia Messaggi' ,
	'LBL_SCHEDULE_MESSAGE_TEST' => 'Seleziona i messaggi della campagna che vuoi inviare come test' ,
	'LBL_SCHEDULE_MESSAGE_EMAILS' => 'Seleziona i messaggi della campagna che vuoi programmare per l&#39;invio' ,
	'LBL_SCHEDULE_BUTTON_TITLE' => 'Invia' ,
	'LBL_SCHEDULE_BUTTON_LABEL' => 'Invia' ,
	'LBL_SCHEDULE_BUTTON_KEY' => 'T' ,

);


 


?>