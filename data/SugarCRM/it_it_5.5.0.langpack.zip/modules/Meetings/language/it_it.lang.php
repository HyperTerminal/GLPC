<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:52 
$mod_strings = array(
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_ACCEPT_THIS' => 'Accetti ?' ,
	'LBL_ADD_BUTTON' => 'Aggiungi' ,
	'LBL_ADD_INVITEE' => 'Aggiungi Invitati' ,
	'LBL_COLON' => ':' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_CREATED_BY' => 'Creato da' ,
	'LBL_DATE_END' => 'Data di Fine' ,
	'LBL_DATE_TIME' => 'Data & Ora di inizio:' ,
	'LBL_DATE' => 'Data d&#39;inizio:' ,
	'LBL_DEFAULT_STATUS' => 'Pianificata' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Riunioni' ,
	'LBL_DEL' => 'Canc' ,
	'LBL_DESCRIPTION_INFORMATION' => 'Descrizione' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_DURATION_HOURS' => 'Ore di Durata:' ,
	'LBL_DURATION_MINUTES' => 'Minuti di Durata:' ,
	'LBL_DURATION' => 'Durata:' ,
	'LBL_EMAIL' => 'Email' ,
	'LBL_FIRST_NAME' => 'Nome' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Note' ,
	'LBL_HOURS_ABBREV' => 'h' ,
	'LBL_HOURS_MINS' => '(ore/minuti)' ,
	'LBL_INVITEE' => 'Invitati' ,
	'LBL_LAST_NAME' => 'Cognome' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a:' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,
	'LBL_LIST_CLOSE' => 'Chiudi' ,
	'LBL_LIST_CONTACT' => 'Nome Contatto' ,
	'LBL_LIST_DATE_MODIFIED' => 'Data Modifica' ,
	'LBL_LIST_DATE' => 'Data d&#39;inizio' ,
	'LBL_LIST_DUE_DATE' => 'Data Scadenza' ,
	'LBL_LIST_FORM_TITLE' => 'Elenco Riunioni' ,
	'LBL_LIST_MY_MEETINGS' => 'Le Mie Riunioni' ,
	'LBL_LIST_RELATED_TO' => 'Relativo a' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_SUBJECT' => 'Soggetto' ,
	'LBL_LIST_TIME' => 'Ora d&#39;inizio' ,
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads' ,
	'LBL_LOCATION' => 'Locazione :' ,
	'LBL_MEETING' => 'Riunione:' ,
	'LBL_MINSS_ABBREV' => 'm' ,
	'LBL_MODIFIED_BY' => 'Modificato da' ,
	'LBL_MODULE_NAME' => 'Riunioni' ,
	'LBL_MODULE_TITLE' => 'Riunioni: Home' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_NEW_FORM_TITLE' => 'Inserisci appuntamento' ,
	'LBL_OUTLOOK_ID' => 'Cod. Outlook' ,
	'LBL_PHONE' => 'Telefono' ,
	'LBL_REMINDER_TIME' => 'Tempo di Avviso' ,
	'LBL_REMINDER' => 'Ricorda:' ,
	'LBL_SCHEDULING_FORM_TITLE' => 'Pianificazione' ,
	'LBL_SEARCH_BUTTON' => 'Cerca' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Riunione' ,
	'LBL_SEND_BUTTON_KEY' => 'I' ,
	'LBL_SEND_BUTTON_LABEL' => 'Invia Inviti' ,
	'LBL_SEND_BUTTON_TITLE' => 'Invia Inviti [Alt+I]' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_SUBJECT' => 'soggetto:' ,
	'LBL_TIME' => 'Ora d&#39;inizio:' ,
	'LBL_USERS_SUBPANEL_TITLE' => 'Utenti' ,
	'LBL_ACTIVITIES_REPORTS' => 'Report Attivit&#224;' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_EMAIL_LIST' => 'Lista Email' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_NEW_APPOINTMENT' => 'Nuovo Appuntamento' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_EMAIL' => 'Nuova Email' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LNK_NOTE_LIST' => 'Note' ,
	'LNK_TASK_LIST' => 'Compiti' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler rimuovere questo invitato dalla riunione?' ,
	'LBL_CREATED_USER' => 'Creato da' ,
	'LBL_MODIFIED_USER' => 'Modificato da' ,
	'NOTICE_DURATION_TIME' => 'La durata deve essere superiore a 0' ,

);


 


?>