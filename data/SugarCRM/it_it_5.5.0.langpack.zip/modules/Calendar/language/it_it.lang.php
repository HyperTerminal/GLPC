<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.20 16:16 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Calendario' ,
	'LBL_MODULE_TITLE' => 'Calendario' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_APPOINTMENT' => 'Nuovo Appuntamento' ,
	'LNK_NEW_TASK' => 'Nuova Attivit&#224;' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_TASK_LIST' => 'Attivit&#224;' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'LNK_IMPORT_CALLS' => 'Importa le Chiamate' ,
	'LNK_IMPORT_MEETINGS' => 'Importa le Riunioni' ,
	'LNK_IMPORT_TASKS' => 'Importa le Attivit&#224;' ,
	'LBL_MONTH' => 'Mese' ,
	'LBL_DAY' => 'Giorno' ,
	'LBL_YEAR' => 'Anno' ,
	'LBL_WEEK' => 'Settimana' ,
	'LBL_PREVIOUS_MONTH' => 'Mese Precedente' ,
	'LBL_PREVIOUS_DAY' => 'Giorno Precedente' ,
	'LBL_PREVIOUS_YEAR' => 'Anno Precedente' ,
	'LBL_PREVIOUS_WEEK' => 'Settimana Precedente' ,
	'LBL_NEXT_MONTH' => 'Mese Successivo' ,
	'LBL_NEXT_DAY' => 'Giorno Successivo' ,
	'LBL_NEXT_YEAR' => 'Anno Successivo' ,
	'LBL_NEXT_WEEK' => 'Settimana Successiva' ,
	'LBL_AM' => 'AM' ,
	'LBL_PM' => 'PM' ,
	'LBL_SCHEDULED' => 'Pianificato' ,
	'LBL_BUSY' => 'Occupato' ,
	'LBL_CONFLICT' => 'Conflitto' ,
	'LBL_USER_CALENDARS' => 'Calendari Utente' ,
	'LBL_SHARED' => 'Condiviso' ,
	'LBL_PREVIOUS_SHARED' => 'Precedente' ,
	'LBL_NEXT_SHARED' => 'Prossimo' ,
	'LBL_SHARED_CAL_TITLE' => 'Calendario Condiviso' ,
	'LBL_USERS' => 'Utente' ,
	'LBL_REFRESH' => 'Aggiorna' ,
	'LBL_EDIT' => 'Modifica' ,
	'LBL_SELECT_USERS' => 'Scegli utenti per il calendario' ,
	'LBL_FILTER_BY_TEAM' => 'Filtra utenti per team:' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a' ,
	'LBL_DATE' => 'Data ed ora di inizio' ,

);

$mod_list_strings = array(
	'dom_cal_weekdays' => array (
			'0' => 'Dom' ,
			'1' => 'Lun' ,
			'2' => 'Mar' ,
			'3' => 'Mer' ,
			'4' => 'Gio' ,
			'5' => 'Ven' ,
			'6' => 'Sab' ,
	),
	'dom_cal_weekdays_long' => array (
			'0' => 'Domenica' ,
			'1' => 'Luned&#236;' ,
			'2' => 'Marted&#236;' ,
			'3' => 'Mercoled&#236;' ,
			'4' => 'Gioved&#236;' ,
			'5' => 'Venerd&#236;' ,
			'6' => 'Sabato' ,
	),
	'dom_cal_month' => array (
			'0' => '' ,
			'1' => 'Gen' ,
			'2' => 'Feb' ,
			'3' => 'Mar' ,
			'4' => 'Apr' ,
			'5' => 'Mag' ,
			'6' => 'Giu' ,
			'7' => 'Lug' ,
			'8' => 'Ago' ,
			'9' => 'Sett' ,
			'10' => 'Ott' ,
			'11' => 'Nov' ,
			'12' => 'Dec' ,
	),
	'dom_cal_month_long' => array (
			'0' => '' ,
			'1' => 'Gennaio' ,
			'2' => 'Febbraio' ,
			'3' => 'Marzo' ,
			'4' => 'Aprile' ,
			'5' => 'Maggio' ,
			'6' => 'Giugno' ,
			'7' => 'Luglio' ,
			'8' => 'Agosto' ,
			'9' => 'Settembre' ,
			'10' => 'Ottobre' ,
			'11' => 'Novembre' ,
			'12' => 'Dicembre' ,
	),

);

 


?>