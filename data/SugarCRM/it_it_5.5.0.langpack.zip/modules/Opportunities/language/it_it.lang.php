<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 19:08 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Opportunit&#224;' ,
	'LBL_MODULE_TITLE' => 'Opportunit&#224; : Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Opportunit&#224;' ,
	'LBL_VIEW_FORM_TITLE' => 'Vista Opportunit&#224;' ,
	'LBL_LIST_FORM_TITLE' => 'Elenco Opportunit&#224;' ,
	'LBL_OPPORTUNITY_NAME' => 'Nome Opportunit&#224; :' ,
	'LBL_OPPORTUNITY' => 'Opportunit&#224; :' ,
	'LBL_NAME' => 'Nome Opportunit&#224;' ,
	'LBL_INVITEE' => 'Contatti' ,
	'LBL_CURRENCIES' => 'Valute' ,
	'LBL_LIST_OPPORTUNITY_NAME' => 'Nome' ,
	'LBL_LIST_ACCOUNT_NAME' => 'Azienda' ,
	'LBL_LIST_AMOUNT' => 'Valore' ,
	'LBL_LIST_DATE_CLOSED' => 'Data di Chiusura' ,
	'LBL_LIST_SALES_STAGE' => 'Fase di Vendita' ,
	'LBL_ACCOUNT_ID' => 'Cod. Azienda' ,
	'LBL_CURRENCY_ID' => 'Cod. Valuta' ,
	'LBL_CURRENCY_NAME' => 'Nome Valuta' ,
	'LBL_CURRENCY_SYMBOL' => 'Simbolo Valuta' ,
	'db_sales_stage' => 'LBL_LIST_SALES_STAGE' ,
	'db_name' => 'LBL_NAME' ,
	'db_amount' => 'LBL_LIST_AMOUNT' ,
	'db_date_closed' => 'LBL_LIST_DATE_CLOSED' ,
	'UPDATE' => 'Opportunit&#224; - Aggiorna Valute' ,
	'UPDATE_DOLLARAMOUNTS' => 'Aggiorna Importi Dollari USA' ,
	'UPDATE_VERIFY' => 'Verifica Importi' ,
	'UPDATE_VERIFY_TXT' => 'Verifica che gli importi nelle opportunit&#224; siano numeri decimali validi con i soli caratteri numerici (0-9) e il separatore dei decimali (.)' ,
	'UPDATE_FIX' => 'Correggi Importi' ,
	'UPDATE_FIX_TXT' => 'Prova a correggere gli importi non validi a partire dai valori correnti. Verr&#224; creata una copia di riserva in un campo &quot;amount_backup&quot;. Se esegui la correzione e noti degli errori ripristina i valori precedenti prima di effettuare altre correzioni, altrimenti perderai  i valori memorizzati nella copia di riserva.' ,
	'UPDATE_DOLLARAMOUNTS_TXT' => 'Aggiorna gli importi in Dollari USA per le opportunit&#224; basandosi sul cambio corrente. Questo valore viene utilizzato per calcolare i Grafici e gli importi nelle viste.' ,
	'UPDATE_CREATE_CURRENCY' => 'Creazione Nuova Valuta:' ,
	'UPDATE_VERIFY_FAIL' => 'Dati con Verifica Fallita:' ,
	'UPDATE_VERIFY_CURAMOUNT' => 'Importo Corrente:' ,
	'UPDATE_VERIFY_FIX' => 'La correzione restituirebbe' ,
	'UPDATE_INCLUDE_CLOSE' => 'Includi Dati Chiusi' ,
	'UPDATE_VERIFY_NEWAMOUNT' => 'Nuovo Importo:' ,
	'UPDATE_VERIFY_NEWCURRENCY' => 'Nuova Valuta:' ,
	'UPDATE_DONE' => 'Fatto' ,
	'UPDATE_BUG_COUNT' => 'Errori Trovati con Tentata Soluzione:' ,
	'UPDATE_BUGFOUND_COUNT' => 'Errori Trovati:' ,
	'UPDATE_COUNT' => 'Dati Aggiornati:' ,
	'UPDATE_RESTORE_COUNT' => 'Importi Ripristinati:' ,
	'UPDATE_RESTORE' => 'Ripristina Importi' ,
	'UPDATE_RESTORE_TXT' => 'Ripristina gli importi dalla copia di sicurezza creata durante la correzione.' ,
	'UPDATE_FAIL' => 'Impossibile aggiornare -' ,
	'UPDATE_NULL_VALUE' => 'L&#39;importo &#232; NULLO, lo imposto a 0 -' ,
	'UPDATE_MERGE' => 'Unisci Valute' ,
	'UPDATE_MERGE_TXT' => 'Unisci pi&#249; valute in un&#39;unica valuta. Se noti che la stessa valuta si ripete pi&#249; volte puoi scegliere di unirle assieme. Questa operazione unir&#224; le valute anche per tutte le altre sezioni.' ,
	'LBL_ACCOUNT_NAME' => 'Nome Azienda:' ,
	'LBL_AMOUNT' => 'Valore:' ,
	'LBL_AMOUNT_USDOLLAR' => 'Valore USD:' ,
	'LBL_CURRENCY' => 'Valuta:' ,
	'LBL_DATE_CLOSED' => 'data chiusura:' ,
	'LBL_TYPE' => 'Tipo:' ,
	'LBL_CAMPAIGN' => 'Campagna:' ,
	'LBL_NEXT_STEP' => 'prossimo passo:' ,
	'LBL_LEAD_SOURCE' => 'Origine del Lead:' ,
	'LBL_SALES_STAGE' => 'Fase di Vendita:' ,
	'LBL_PROBABILITY' => 'Probabilit&#224; (%):' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_DUPLICATE' => 'Possibile Opportunit&#224; Duplicata' ,
	'MSG_DUPLICATE' => 'La creazione di questa opportunit&#224; potrebbe generare un duplicato. Di seguito trovi una lista di opportunit&#224; con un nome simile.<br>Clicca Salva per continuare con la creazione oppure Annulla per tornare al modulo senza creare questa opportunit&#224;.' ,
	'LBL_NEW_FORM_TITLE' => 'Nuova Opportunit&#224;' ,
	'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunit&#224;' ,
	'LNK_OPPORTUNITY_LIST' => 'Opportunit&#224;' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_TOP_OPPORTUNITIES' => 'Migliori Opportunit&#224; Aperte' ,
	'NTC_REMOVE_OPP_CONFIRMATION' => 'Sicuro di voler rimuovere questo contatto dall&#39;opportunti&#224; ?' ,
	'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Sicuro di voler rimuovere questa opportunit&#224; dal progetto ?' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Opportunit&#224;' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia' ,
	'LBL_RAW_AMOUNT' => 'Importo Grezzo' ,
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Progetti' ,
	'LBL_ASSIGNED_TO_NAME' => 'Nome Utente Assegnato:' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,
	'LBL_MY_CLOSED_OPPORTUNITIES' => 'Le mie Opportunit&#224; Chiuse' ,
	'LBL_TOTAL_OPPORTUNITIES' => 'Totale Opportunit&#224;' ,
	'LBL_CLOSED_WON_OPPORTUNITIES' => 'Opportunit&#224; Chiuse Vinte' ,
	'LBL_ASSIGNED_TO_ID' => 'Assegnata a Cod.' ,
	'LBL_CREATED_ID' => 'Creata da Cod.' ,
	'LBL_MODIFIED_ID' => 'Modificata da Cod.' ,
	'LBL_MODIFIED_NAME' => 'Modificata dall&#39;Utente' ,
	'LBL_CREATED_USER' => 'Creato da' ,
	'LBL_MODIFIED_USER' => 'Modificato da' ,
	'LBL_CAMPAIGN_OPPORTUNITY' => 'Campagna' ,
	'LBL_PROJECT_SUBPANEL_TITLE' => 'Progetti' ,

);


 


?>