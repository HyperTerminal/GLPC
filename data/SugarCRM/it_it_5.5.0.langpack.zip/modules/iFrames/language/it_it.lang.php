<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.20 16:20 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Portale' ,
	'LBL_MODULE_ID' => 'iFrames' ,
	'LBL_MODULE_TITLE' => 'Portale: Home' ,
	'LBL_LIST_STATUS' => 'Visibile' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_URL' => 'Sito Web' ,
	'LBL_LIST_TYPE' => 'Tipo' ,
	'LBL_LIST_CREATED_BY' => 'Creato da' ,
	'LBL_LIST_PLACEMENT' => 'Disposizione' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Portali' ,
	'LBL_ADD_SITE' => 'Aggiungi Sito' ,
	'LBL_LIST_SITES' => 'Lista Siti' ,
	'LBL_ID' => 'Codice' ,
	'LBL_CHECKED' => 'selezionato' ,
	'DEFAULT_URL' => 'http://www.witcom.com' ,
	'DROPDOWN_PLACEMENT' => array (
			'all' => 'Menu Sezioni e Menu Scorciatoie' ,
			'tab' => 'Menu Sezioni' ,
			'shortcut' => 'Menu Scorciatorie' ,
	),
	'DROPDOWN_TYPE' => array (
			'personal' => 'Personale' ,
			'global' => 'Globale' ,
	),
	'LBL_DASHLET_TITLE' => 'Il mio Portale' ,
	'LBL_DASHLET_OPT_TITLE' => 'Titolo' ,
	'LBL_DASHLET_OPT_URL' => 'WebSite URL' ,
	'LBL_DASHLET_OPT_HEIGHT' => 'Altezza Dashlet (in pixels)' ,
	'LBL_DASHLET_SUGAR_NEWS' => 'Sugar News' ,
	'LBL_DASHLET_DISCOVER_SUGAR_PRO' => 'Scopri Sugar Professional' ,

);


 


?>