<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 13:44 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Errori' ,
	'LBL_MODULE_TITLE' => 'Gestione Errori: Home' ,
	'LBL_MODULE_ID' => 'Errori' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Errore' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Errori' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Errore' ,
	'LBL_CONTACT_BUG_TITLE' => 'Contatto:' ,
	'LBL_SUBJECT' => 'Oggetto:' ,
	'LBL_BUG' => 'Errore:' ,
	'LBL_BUG_NUMBER' => 'Numero Errore:' ,
	'LBL_NUMBER' => 'Numero:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_PRIORITY' => 'Priorit&#224;:' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_BUG_SUBJECT' => 'Oggetto Errore:' ,
	'LBL_CONTACT_ROLE' => 'Ruolo:' ,
	'LBL_LIST_NUMBER' => 'Num.' ,
	'LBL_LIST_SUBJECT' => 'Oggetto' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_PRIORITY' => 'Priorit&#224;' ,
	'LBL_LIST_RELEASE' => 'Versione' ,
	'LBL_LIST_RESOLUTION' => 'Soluzione' ,
	'LBL_LIST_LAST_MODIFIED' => 'Ultima Modifica' ,
	'LBL_INVITEE' => 'Contatti' ,
	'LBL_TYPE' => 'Tipo:' ,
	'LBL_LIST_TYPE' => 'Tipo' ,
	'LBL_RESOLUTION' => 'Soluzione:' ,
	'LBL_RELEASE' => 'Versione:' ,
	'LNK_NEW_BUG' => 'Segnala Errore' ,
	'LNK_BUG_LIST' => 'Errori' ,
	'NTC_REMOVE_INVITEE' => 'Sicuro di voler rimuovere questo contatti dall&#39;errore ?' ,
	'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Sicuro di voler rimuovere questo errore dall&#39;azienda ?' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_LIST_MY_BUGS' => 'Errori a me Assegnati' ,
	'LBL_FOUND_IN_RELEASE' => 'Trovato nella Versione:' ,
	'LBL_FIXED_IN_RELEASE' => 'Risolto nella Versione:' ,
	'LBL_LIST_FIXED_IN_RELEASE' => 'Risolto nella Versione' ,
	'LBL_WORK_LOG' => 'Registro Operazioni:' ,
	'LBL_SOURCE' => 'Sorgente:' ,
	'LBL_PRODUCT_CATEGORY' => 'Categoria:' ,
	'LBL_CREATED_BY' => 'Creato da:' ,
	'LBL_DATE_CREATED' => 'Data Creazione:' ,
	'LBL_MODIFIED_BY' => 'Ultima Modifica di:' ,
	'LBL_DATE_LAST_MODIFIED' => 'Data Modifica:' ,
	'LBL_LIST_EMAIL_ADDRESS' => 'Indirizzo Email' ,
	'LBL_LIST_CONTACT_NAME' => 'Nome Contatto' ,
	'LBL_LIST_ACCOUNT_NAME' => 'Azienda' ,
	'LBL_LIST_PHONE' => 'Telefono' ,
	'NTC_DELETE_CONFIRMATION' => 'Sicuro di voler rimuovere questo contatto da questo errore ?' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Gestione degli Errori' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Aziende' ,
	'LBL_CASES_SUBPANEL_TITLE' => 'Tickets Supporto' ,
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Progetti' ,
	'LBL_SYSTEM_ID' => 'Codice del Sistema' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a' ,

);


 


?>