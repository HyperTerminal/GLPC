<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 15:13 
$mod_strings = array(
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_ACCOUNT_ID' => 'Cod. Azienda' ,
	'LBL_ACCOUNT_NAME' => 'Nome Azienda:' ,
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Aziende' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_ATTACH_NOTE' => 'Aggiungi Nota' ,
	'LBL_BUGS_SUBPANEL_TITLE' => 'Errori' ,
	'LBL_CASE_NUMBER' => 'Ticket Numero:' ,
	'LBL_CASE_SUBJECT' => 'Soggetto del Ticket:' ,
	'LBL_CASE' => 'Ticket:' ,
	'LBL_CONTACT_CASE_TITLE' => 'Contatto Ticket:' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_CONTACT_ROLE' => 'Ruolo:' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Tickets supporto' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_FILENANE_ATTACHMENT' => 'Allegato' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia' ,
	'LBL_INVITEE' => 'Contatti' ,
	'LBL_MEMBER_OF' => 'Azienda' ,
	'LBL_MODULE_NAME' => 'Ticket Supporto' ,
	'LBL_MODULE_TITLE' => 'Ticket: Home' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Ticket' ,
	'LBL_NUMBER' => 'Numero:' ,
	'LBL_PRIORITY' => 'Priorit&#224;:' ,
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Progetti' ,
	'LBL_RESOLUTION' => 'Soluzione:' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Ticket' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_SUBJECT' => 'Soggetto:' ,
	'LBL_SYSTEM_ID' => 'Codice Sistema' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,
	'LBL_LIST_ACCOUNT_NAME' => 'Azienda' ,
	'LBL_LIST_ASSIGNED' => 'Assegnato a' ,
	'LBL_LIST_CLOSE' => 'Chiudi' ,
	'LBL_LIST_FORM_TITLE' => 'Elenco Ticket' ,
	'LBL_LIST_LAST_MODIFIED' => 'Ultima Modifica' ,
	'LBL_LIST_MY_CASES' => 'Ticket Supporto Aperti' ,
	'LBL_LIST_NUMBER' => 'Num.' ,
	'LBL_LIST_PRIORITY' => 'Priorit&#224;' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_SUBJECT' => 'Soggetto' ,
	'LNK_CASE_LIST' => 'Lista Ticket' ,
	'LNK_NEW_CASE' => 'Nuovo Ticket Supporto' ,
	'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Sicuro di voler togliere questo ticket da questo errore ?' ,
	'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler rimuovere questo contatto dal ticket?' ,
	'LBL_LIST_DATE_CREATED' => 'Data Creazione' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a' ,
	'LBL_TYPE' => 'Tipo' ,
	'LBL_WORK_LOG' => 'Registro lavoro' ,
	'LBL_CREATED_USER' => 'Creato da' ,
	'LBL_MODIFIED_USER' => 'Modificato da' ,
	'LBL_PROJECT_SUBPANEL_TITLE' => 'Progetti' ,

);


 


?>