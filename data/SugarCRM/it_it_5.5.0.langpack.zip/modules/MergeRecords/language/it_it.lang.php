<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:52 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Unione Dati' ,
	'LBL_MODULE_TITLE' => 'Unione Dati: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Ricerca Unione' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Unioni' ,
	'LBL_LBL_MERGE_RECORDS_STEP_1' => 'Step 1: Trova records da unire con' ,
	'LBL_AVAIL_FIELDS' => 'Campi Disponibili' ,
	'LBL_FILTER_COND' => 'Condizione Filtro' ,
	'LBL_SELECTED_FIELDS' => 'Campi Selezionati' ,
	'LBL_MERGE_RECORDS_WITH' => 'Unisci Dati Con' ,
	'LBL_MERGE_VALUE_OVER' => 'Unisci Valori Su' ,
	'LBL_NEXT_STEP_TITLE' => 'Passa al Passo Successivo [Ctrl+N]' ,
	'LBL_NEXT_STEP_BUTTON_KEY' => 'N' ,
	'LBL_NEXT_STEP_BUTTON_LABEL' => 'Passo Successivo >' ,
	'LBL_PERFORM_MERGE_BUTTON_TITLE' => 'Esegui Unione[Ctrl+P]' ,
	'LBL_PERFORM_MERGE_BUTTON_KEY' => 'P' ,
	'LBL_PERFORM_MERGE_BUTTON_LABEL' => 'Esegui Unione' ,
	'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE' => 'Salva Unione[Ctrl+S]' ,
	'LBL_SAVE_MERGED_RECORD_BUTTON_KEY' => 'S' ,
	'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL' => 'Salva Unione' ,
	'LBL_STEP2_FORM_TITLE' => 'Dati trovati per l&#39;Unione:' ,
	'LBL_SELECT_ERROR' => 'Devi fare una scelta prima di procedere.' ,
	'LBL_SELECT_PRIMARY' => 'Scegli il dato principale per l&#39;unione.' ,
	'LBL_CHANGE_PARENT' => 'Imposta come principale' ,
	'LBL_REMOVE_FROM_MERGE' => 'Rimuovi' ,
	'LBL_DIFF_COL_VALUES' => 'Colonne i cui valori nel dato principale sono diversi rispetto ai valori con cui eseguire l&#39;unione:' ,
	'LBL_SAME_COL_VALUES' => 'Valori simili in tutti i dati:' ,
	'ERR_EXCEEDS_MAX' => 'Puoi unire un massimo di 5 dati. I dati in eccesso sono stati ignorati.' ,
	'LBL_DELETE_MESSAGE' => 'L&#39;azione eliminer&#224; i seguenti dati:' ,
	'LBL_PROCEED' => 'Procedo ?' ,

);


 


?>