<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 14:32 
$mod_strings = array(
	'LBL_LIST_ID' => 'Cod. Lista Prospettive' ,
	'LBL_ID' => 'Codice' ,
	'LBL_TARGET_TRACKER_KEY' => 'Chiave Tracker Obiettivo' ,
	'LBL_TARGET_ID' => 'Cod. Obiettivo' ,
	'LBL_TARGET_TYPE' => 'Tipo Obiettivo' ,
	'LBL_ACTIVITY_TYPE' => 'Tipo Attivit&#224;' ,
	'LBL_ACTIVITY_DATE' => 'Data Attivit&#224;' ,
	'LBL_RELATED_ID' => 'Id Correlato' ,
	'LBL_RELATED_TYPE' => 'Tipo Correlato' ,
	'LBL_DELETED' => 'Cancellato' ,
	'LBL_MODULE_NAME' => 'Registro Campagna' ,
	'LBL_LIST_RECIPIENT_EMAIL' => 'Email Destinatario' ,
	'LBL_LIST_RECIPIENT_NAME' => 'Nome Destinatario' ,
	'LBL_ARCHIVED' => 'Archiviate' ,
	'LBL_HITS' => 'Visite' ,
	'LBL_CAMPAIGN_NAME' => 'Nome:' ,
	'LBL_CAMPAIGN' => 'Campagna:' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_INVITEE' => 'Contatti' ,
	'LBL_LIST_CAMPAIGN_NAME' => 'Campagna' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_TYPE' => 'Tipo' ,
	'LBL_LIST_END_DATE' => 'Data Fine' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica' ,
	'LBL_MODIFIED' => 'Modificato da:' ,
	'LBL_CREATED' => 'Creato da:' ,
	'LBL_TEAM' => 'Team:' ,
	'LBL_ASSIGNED_TO' => 'Assegnato A:' ,
	'LBL_CAMPAIGN_START_DATE' => 'Data Inizio:' ,
	'LBL_CAMPAIGN_END_DATE' => 'Data Fine:' ,
	'LBL_CAMPAIGN_STATUS' => 'Stato:' ,
	'LBL_CAMPAIGN_BUDGET' => 'Budget:' ,
	'LBL_CAMPAIGN_EXPECTED_COST' => 'Costo Atteso:' ,
	'LBL_CAMPAIGN_ACTUAL_COST' => 'Costo Attuale:' ,
	'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Ritorno Atteso:' ,
	'LBL_CAMPAIGN_TYPE' => 'Tipo:' ,
	'LBL_CAMPAIGN_OBJECTIVE' => 'Obiettivo:' ,
	'LBL_CAMPAIGN_CONTENT' => 'Descrizione:' ,
	'LBL_CREATED_LEAD' => 'lead creato' ,
	'LBL_CREATED_CONTACT' => 'contatto creato' ,
	'LBL_LIST_FORM_TITLE' => 'Campagne Obiettivo' ,
	'LBL_LIST_ACTIVITY_DATE' => 'Data Attivit&#224;' ,
	'LBL_LIST_CAMPAIGN_OBJECTIVE' => 'Obiettivo Campagna' ,
	'LBL_RELATED' => 'Correlato' ,
	'LBL_CLICKED_URL_KEY' => 'Chiave URL Cliccata' ,
	'LBL_URL_CLICKED' => 'URL Cliccata' ,
	'LBL_MORE_INFO' => 'Altre Informazioni' ,
	'LBL_CAMPAIGNS' => 'Campagne' ,

);


 


?>