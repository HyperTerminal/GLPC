<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 19:10 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Compiti di Progetto' ,
	'LBL_MODULE_TITLE' => 'Compiti del Progetto: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Compito Progetto' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Compiti di Progetto' ,
	'LBL_EDIT_TASK_IN_GRID_TITLE' => 'Modifica Compito nella Griglia' ,
	'LBL_ID' => 'Codice:' ,
	'LBL_PROJECT_TASK_ID' => 'Cod. Compito di Progetto' ,
	'LBL_PROJECT_ID' => 'Cod. Progetto:' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento:' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica:' ,
	'LBL_ASSIGNED_USER_ID' => 'Assegnato A:' ,
	'LBL_MODIFIED_USER_ID' => 'Cod. Utente Modificato:' ,
	'LBL_CREATED_BY' => 'Creato Da:' ,
	'LBL_TEAM_ID' => 'Team:' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_DATE_DUE' => 'Data Scadenza Completamento:' ,
	'LBL_TIME_DUE' => 'Ora Scadenza Completamento:' ,
	'LBL_RESOURCE' => 'Risorsa:' ,
	'LBL_PREDECESSORS' => 'Predecessori:' ,
	'LBL_DATE_START' => 'Data Inizio:' ,
	'LBL_DATE_FINISH' => 'Data Fine:' ,
	'LBL_TIME_START' => 'Ora Inizio:' ,
	'LBL_TIME_FINISH' => 'Ora Fine:' ,
	'LBL_DURATION' => 'Durata:' ,
	'LBL_DURATION_UNIT' => 'Unit&#224; di durata:' ,
	'LBL_ACTUAL_DURATION' => 'Durata Attuale:' ,
	'LBL_PARENT_ID' => 'Progetto:' ,
	'LBL_PARENT_TASK_ID' => 'Cod. Compito Genitore' ,
	'LBL_PERCENT_COMPLETE' => 'Progresso (%):' ,
	'LBL_PRIORITY' => 'Priorit&#224;:' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_ORDER_NUMBER' => 'Priorit&#224; (max&#061;0):' ,
	'LBL_TASK_NUMBER' => 'Compito Numero:' ,
	'LBL_TASK_ID' => 'Cod. Compito:' ,
	'LBL_DEPENDS_ON_ID' => 'Dipende Da:' ,
	'LBL_MILESTONE_FLAG' => 'Compito Fondamentale:' ,
	'LBL_ESTIMATED_EFFORT' => 'Sforzo Stimato (ore):' ,
	'LBL_ACTUAL_EFFORT' => 'Sforzo Attuale (ore):' ,
	'LBL_UTILIZATION' => 'Utilizzo (%):' ,
	'LBL_DELETED' => 'Cancellato:' ,
	'LBL_LIST_ORDER_NUMBER' => 'Priorit&#224;' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_DAYS' => 'giorni' ,
	'LBL_LIST_PARENT_NAME' => 'Progetto' ,
	'LBL_LIST_PERCENT_COMPLETE' => 'Percentuale completata (%)' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_DURATION' => 'Durata' ,
	'LBL_LIST_ACTUAL_DURATION' => 'Durata Attuale' ,
	'LBL_LIST_ASSIGNED_USER_ID' => 'Assegnato A' ,
	'LBL_LIST_DATE_DUE' => 'Data Scadenza Completamento' ,
	'LBL_LIST_DATE_START' => 'Data Inizio' ,
	'LBL_LIST_DATE_FINISH' => 'Data Fine' ,
	'LBL_LIST_PRIORITY' => 'Priorit&#224;' ,
	'LBL_LIST_CLOSE' => 'Chiudi' ,
	'LBL_PROJECT_NAME' => 'Nome Progetto' ,
	'LNK_NEW_PROJECT' => 'Nuovo Progetto' ,
	'LNK_PROJECT_LIST' => 'Lista Progetti' ,
	'LNK_NEW_PROJECT_TASK' => 'Nuovo Compito di Progetto' ,
	'LNK_PROJECT_TASK_LIST' => 'Compiti di Progetto' ,
	'LBL_LIST_MY_PROJECT_TASKS' => 'I miei Compiti di Progetto' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Compiti del progetto' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Compito di Progetto' ,
	'LBL_ACTIVITIES_TITLE' => 'Attivit&#224;' ,
	'LBL_HISTORY_TITLE' => 'Cronologia' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia' ,
	'DATE_JS_ERROR' => 'Prego inserire una data corrispondente al periodo inserito' ,
	'LBL_ASSIGNED_USER_NAME' => 'Assegnato A' ,
	'LBL_PARENT_NAME' => 'Nome Progetto' ,
	'LBL_LIST_PROJECT_NAME' => 'Progetti' ,

);


 


?>