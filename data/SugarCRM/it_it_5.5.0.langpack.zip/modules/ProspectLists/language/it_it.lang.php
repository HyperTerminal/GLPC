<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 22:08 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Liste Obiettivi' ,
	'LBL_MODULE_ID' => 'Liste Obiettivi' ,
	'LBL_MODULE_TITLE' => 'Lista Obiettivi: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Lista Obiettivi' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Obiettivi' ,
	'LBL_PROSPECT_LIST_NAME' => 'Nome:' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_ENTRIES' => 'Voci Totali:' ,
	'LBL_LIST_PROSPECT_LIST_NAME' => 'Lista Obiettivi' ,
	'LBL_LIST_ENTRIES' => 'Voci' ,
	'LBL_LIST_DESCRIPTION' => 'Descrizione' ,
	'LBL_LIST_TYPE_NO' => 'Tipo' ,
	'LBL_LIST_END_DATE' => 'Data Fine' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica' ,
	'LBL_MODIFIED' => 'Modificato da:' ,
	'LBL_CREATED' => 'Creato da:' ,
	'LBL_TEAM' => 'Team:' ,
	'LBL_ASSIGNED_TO' => 'Assegnato a:' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LNK_NEW_CAMPAIGN' => 'Nuova Campagna' ,
	'LNK_CAMPAIGN_LIST' => 'Campagne' ,
	'LNK_NEW_PROSPECT_LIST' => 'Nuova Lista Obiettivi' ,
	'LNK_PROSPECT_LIST_LIST' => 'Liste Obiettivi' ,
	'LBL_MODIFIED_BY' => 'Modificato da:' ,
	'LBL_CREATED_BY' => 'Creato da:' ,
	'LBL_DATE_CREATED' => 'Data Creazione:' ,
	'LBL_DATE_LAST_MODIFIED' => 'Data Modifica:' ,
	'LNK_NEW_PROSPECT' => 'Nuovo Obiettivo' ,
	'LNK_PROSPECT_LIST' => 'Obiettivi' ,
	'LBL_PROSPECT_LISTS_SUBPANEL_TITLE' => 'Liste Obiettivi' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads' ,
	'LBL_PROSPECTS_SUBPANEL_TITLE' => 'Obiettivi' ,
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Aziende' ,
	'LBL_COPY_PREFIX' => 'Copia di' ,
	'LBL_USERS_SUBPANEL_TITLE' => 'Utenti' ,
	'LBL_TYPE' => 'Tipo' ,
	'LBL_LIST_TYPE' => 'Tipo:' ,
	'LBL_LIST_TYPE_LIST_NAME' => 'Tipo' ,
	'LBL_NEW_FORM_TITLE' => 'Nuova Lista Obiettivo' ,
	'LBL_MARKETING_MESSAGE' => 'Messaggio di Email Marketing' ,
	'LBL_DOMAIN_NAME' => 'Nome Dominio' ,
	'LBL_DOMAIN' => 'No email al Dominio:' ,
	'LBL_LIST_PROSPECTLIST_NAME' => 'Nome' ,

);


 


?>