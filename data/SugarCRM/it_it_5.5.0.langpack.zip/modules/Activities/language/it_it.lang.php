<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 13:39 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Attivit&#224;' ,
	'LBL_MODULE_TITLE' => 'Attivit&#224;: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Attivit&#224;' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Attivit&#224;' ,
	'LBL_LIST_SUBJECT' => 'Soggetto' ,
	'LBL_LIST_CONTACT' => 'Contatto' ,
	'LBL_LIST_RELATED_TO' => 'Relativo a' ,
	'LBL_LIST_DATE' => 'Data' ,
	'LBL_LIST_TIME' => 'Ora Inizio' ,
	'LBL_LIST_CLOSE' => 'Chiuso' ,
	'LBL_SUBJECT' => 'Oggetto:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_LOCATION' => 'Luogo:' ,
	'LBL_DATE_TIME' => 'Data e Ora Inizio:' ,
	'LBL_DATE' => 'Data Inizio:' ,
	'LBL_TIME' => 'Ora Inizio:' ,
	'LBL_DURATION' => 'Durata:' ,
	'LBL_DURATION_MINUTES' => 'Durata in minuti:' ,
	'LBL_HOURS_MINS' => '(ore/minuti)' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_MEETING' => 'Riunione:' ,
	'LBL_DESCRIPTION_INFORMATION' => 'Informazioni Descrizione' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_COLON' => ':' ,
	'LBL_DEFAULT_STATUS' => 'Pianificato' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_EMAIL' => 'Nuova Email' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_TASK_LIST' => 'Compiti' ,
	'LNK_NOTE_LIST' => 'Note' ,
	'LNK_EMAIL_LIST' => 'Emails' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'NTC_REMOVE_INVITEE' => 'Sicuro di voler rimuovere questi invitati dalla riunione ?' ,
	'LBL_INVITEE' => 'Partecipanti' ,
	'LBL_LIST_DIRECTION' => 'Direzione' ,
	'LBL_DIRECTION' => 'Direzione' ,
	'LNK_NEW_APPOINTMENT' => 'Nuovo Appuntamento' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'LBL_OPEN_ACTIVITIES' => 'Attivit&#224; Aperte' ,
	'LBL_HISTORY' => 'Storico' ,
	'LBL_UPCOMING' => 'Le mie prossime attivit&#224;' ,
	'LBL_TODAY' => 'per' ,
	'LBL_NEW_TASK_BUTTON_TITLE' => 'Nuovo Compito [Alt+N]' ,
	'LBL_NEW_TASK_BUTTON_KEY' => 'N' ,
	'LBL_NEW_TASK_BUTTON_LABEL' => 'Nuovo Compito' ,
	'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Pianifica Riunione[Alt+M]' ,
	'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M' ,
	'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Pianifica Riunione' ,
	'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Pianifica Chiamata[Alt+C]' ,
	'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C' ,
	'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Pianifica Chiamata' ,
	'LBL_NEW_NOTE_BUTTON_TITLE' => 'Nuova [Alt+T]' ,
	'LBL_NEW_NOTE_BUTTON_KEY' => 'T' ,
	'LBL_NEW_NOTE_BUTTON_LABEL' => 'Nuova Nota' ,
	'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Traccia Email [Alt+K]' ,
	'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K' ,
	'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Traccia Email' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_DUE_DATE' => 'Data prevista' ,
	'LBL_LIST_LAST_MODIFIED' => 'Ultima modifica' ,
	'NTC_NONE_SCHEDULED' => 'Niente di pianificato.' ,
	'appointment_filter_dom' => array (
			'today' => 'oggi' ,
			'tomorrow' => 'domani' ,
			'this Saturday' => 'questa settimana' ,
			'next Saturday' => 'la prossima settimana' ,
			'last this_month' => 'questo mese' ,
			'last next_month' => 'il prossimo mese' ,
	),
	'LNK_IMPORT_NOTES' => 'Importa Note' ,
	'NTC_NONE' => 'Nessuna' ,
	'LBL_ACCEPT_THIS' => 'Accetti?' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Attivit&#224; Aperte' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,

);


 


?>