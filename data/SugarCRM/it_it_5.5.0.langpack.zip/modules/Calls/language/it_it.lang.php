<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 14:05 
$mod_strings = array(
	'LBL_BLANK' => '' ,
	'LBL_MODULE_NAME' => 'Chiamate' ,
	'LBL_MODULE_TITLE' => 'Chiamate: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Chiamata' ,
	'LBL_LIST_FORM_TITLE' => 'Elenco Chiamate' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Appuntamento' ,
	'LBL_LIST_CLOSE' => 'Chiudi' ,
	'LBL_LIST_SUBJECT' => 'Soggetto' ,
	'LBL_LIST_CONTACT' => 'Contatto' ,
	'LBL_LIST_RELATED_TO' => 'Relativo a' ,
	'LBL_LIST_RELATED_TO_ID' => 'Relativo a ID' ,
	'LBL_LIST_DATE' => 'Data di inizio' ,
	'LBL_LIST_TIME' => 'Ora di inizio' ,
	'LBL_LIST_DURATION' => 'Durata' ,
	'LBL_LIST_DIRECTION' => 'Direzione' ,
	'LBL_SUBJECT' => 'Soggetto:' ,
	'LBL_REMINDER' => 'Avviso:' ,
	'LBL_CONTACT_NAME' => 'Contatto:' ,
	'LBL_DESCRIPTION_INFORMATION' => 'Descrizione' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_DIRECTION' => 'Direzione:' ,
	'LBL_DATE' => 'Data di inizio:' ,
	'LBL_DURATION' => 'Durata:' ,
	'LBL_DURATION_HOURS' => 'Ore di Durata:' ,
	'LBL_DURATION_MINUTES' => 'Minuti di Durata:' ,
	'LBL_HOURS_MINUTES' => '(ore/minuti)' ,
	'LBL_CALL' => 'Chiamata:' ,
	'LBL_DATE_TIME' => 'Data e ora di inizio:' ,
	'LBL_TIME' => 'Ora di inizio:' ,
	'LBL_HOURS_ABBREV' => 'h' ,
	'LBL_MINSS_ABBREV' => 'm' ,
	'LBL_COLON' => ':' ,
	'LBL_DEFAULT_STATUS' => 'Pianificata' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_EMAIL' => 'Nuova Email' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_TASK_LIST' => 'Compiti' ,
	'LNK_NOTE_LIST' => 'Note' ,
	'LNK_EMAIL_LIST' => 'Lista Email' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler togliere questo invitato dalla chiamata?' ,
	'LBL_INVITEE' => 'Partecipanti' ,
	'LBL_RELATED_TO' => 'Riferito A:' ,
	'LNK_NEW_APPOINTMENT' => 'Nuovo Appuntamento' ,
	'LBL_SCHEDULING_FORM_TITLE' => 'Pianificazione' ,
	'LBL_ADD_INVITEE' => 'Aggiungi Partecipanti' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_FIRST_NAME' => 'Nome' ,
	'LBL_LAST_NAME' => 'Cognome' ,
	'LBL_EMAIL' => 'Email' ,
	'LBL_PHONE' => 'Telefono' ,
	'LBL_SEND_BUTTON_TITLE' => 'Invia Inviti [Alt+I]' ,
	'LBL_SEND_BUTTON_KEY' => 'I' ,
	'LBL_SEND_BUTTON_LABEL' => 'Invia Inviti' ,
	'LBL_DATE_END' => 'Data Fine' ,
	'LBL_TIME_END' => 'Ora Fine' ,
	'LBL_REMINDER_TIME' => 'Tempo di Avviso' ,
	'LBL_SEARCH_BUTTON' => 'Cerca' ,
	'LBL_ACTIVITIES_REPORTS' => 'Report Attivit&#224;' ,
	'LBL_ADD_BUTTON' => 'Aggiungi' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Chiamate' ,
	'LBL_LOG_CALL' => 'Registro Chiamate' ,
	'LNK_SELECT_ACCOUNT' => 'Seleziona Azienda' ,
	'LNK_NEW_ACCOUNT' => 'Nuova Azienda' ,
	'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunit&#224;' ,
	'LBL_DEL' => 'Elimina' ,
	'LBL_LEADS_SUBPANEL_TITLE' => 'Leads' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_USERS_SUBPANEL_TITLE' => 'Utenti' ,
	'LBL_OUTLOOK_ID' => 'Cod. Outlook' ,
	'LBL_MEMBER_OF' => 'Membro di' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Note' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Assegnato A' ,
	'LBL_LIST_MY_CALLS' => 'Le Mie Chiamate' ,
	'LBL_SELECT_FROM_DROPDOWN' => 'Prego prima selezionare dalla lista dei correlati' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a' ,
	'LBL_ASSIGNED_TO_ID' => 'Utente assegnato' ,
	'NOTICE_DURATION_TIME' => 'Il tempo di durata deve essere superiore a 0' ,

);


 


?>