<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.20 16:18 
$mod_strings = array(
	'LBL_MODULE_TITLE' => 'Le mie Ricerche Salvate' ,
	'LBL_SEARCH_FORM_TITLE' => 'Le mie Ricerche Salvate : Cerca' ,
	'LBL_LIST_FORM_TITLE' => 'Lista delle Ricerche Salvate' ,
	'LBL_DELETE_CONFIRM' => 'Vuoi eliminare la Ricerca selezionata ?' ,
	'LBL_UPDATE_BUTTON_TITLE' => 'Aggiorna questa ricerca' ,
	'LBL_DELETE_BUTTON_TITLE' => 'Elimina questa Ricerca' ,
	'LBL_SAVE_BUTTON_TITLE' => 'Salva la ricerca corrente' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_MODULE' => 'Modulo' ,
	'LBL_ORDER_BY_COLUMNS' => 'Ordina Per Colonna:' ,
	'LBL_DIRECTION' => 'Direzione:' ,
	'LBL_SAVE_SEARCH_AS' => 'Salva questa ricerca come:' ,
	'LBL_SAVE_SEARCH_AS_HELP' => 'Questo permette di salvare le tue impostazioni di visualizzazione e i filtri nella Ricerca Avanzata.' ,
	'LBL_PREVIOUS_SAVED_SEARCH' => 'Ricerche Salvate precedenti' ,
	'LBL_PREVIOUS_SAVED_SEARCH_HELP' => 'Modifica o Elimina le Ricerche Salvate' ,
	'LBL_ASCENDING' => 'Crescente' ,
	'LBL_DESCENDING' => 'Decrescente' ,
	'LBL_MODIFY_CURRENT_SEARCH' => 'Modifica la ricerca corrente' ,

);


 


?>