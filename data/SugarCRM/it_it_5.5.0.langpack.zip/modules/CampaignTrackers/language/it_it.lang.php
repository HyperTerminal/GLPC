<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 14:33 
$mod_strings = array(
	'LBL_ID' => 'Codice' ,
	'LBL_TRACKER_KEY' => 'Chiave Tracker' ,
	'LBL_TRACKER_URL' => 'URL Tracker' ,
	'LBL_TRACKER_NAME' => 'Nome Tracker' ,
	'LBL_CAMPAIGN_ID' => 'Codice Campagna' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica' ,
	'LBL_MODIFIED_USER_ID' => 'Codice Utente Modificato' ,
	'LBL_CREATED_BY' => 'Creato da' ,
	'LBL_DELETED' => 'Eliminato' ,
	'LBL_CAMPAIGN' => 'Campagna' ,
	'LBL_OPTOUT' => 'Disiscritto' ,
	'LBL_MODULE_NAME' => 'Trackers Campagna' ,
	'LBL_EDIT_CAMPAIGN_NAME' => 'Nome Campagna:' ,
	'LBL_EDIT_TRACKER_NAME' => 'Nome Tracker:' ,
	'LBL_EDIT_TRACKER_URL' => 'URL Tracker:' ,
	'LBL_SUBPANEL_TRACKER_NAME' => 'Nome' ,
	'LBL_SUBPANEL_TRACKER_URL' => 'URL' ,
	'LBL_SUBPANEL_TRACKER_KEY' => 'Chiave' ,
	'LBL_EDIT_MESSAGE_URL' => 'URL per il Messaggio della Campagna:' ,
	'LBL_EDIT_TRACKER_KEY' => 'Chiave Tracker:' ,
	'LBL_EDIT_OPT_OUT' => 'Link Disiscrizione ?' ,
	'LNK_CAMPAIGN_LIST' => 'Campagne' ,

);


 


?>