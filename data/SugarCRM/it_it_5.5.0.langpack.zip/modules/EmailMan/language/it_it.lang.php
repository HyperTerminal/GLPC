<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 17:44 
$mod_strings = array(
	'LBL_SEND_DATE_TIME' => 'Data Invio' ,
	'LBL_IN_QUEUE' => 'In coda ?' ,
	'LBL_IN_QUEUE_DATE' => 'Data inoltro' ,
	'ERR_INT_ONLY_EMAIL_PER_RUN' => 'Sono ammessi solo numeri interi per il numero di messaggi alla volta.' ,
	'LBL_ATTACHMENT_AUDIT' => 'inviato. Non &#232; stato duplicato localmente per risparmiare spazio su disco.' ,
	'LBL_CONFIGURE_SETTINGS' => 'Configura' ,
	'LBL_CUSTOM_LOCATION' => 'Utente Definito' ,
	'LBL_DEFAULT_LOCATION' => 'Predefinito' ,
	'LBL_DISCLOSURE_TITLE' => 'Inserisci clausola in ogni email' ,
	'LBL_DISCLOSURE_TEXT_TITLE' => 'Contenuto della clausola' ,
	'LBL_DISCLOSURE_TEXT_SAMPLE' => 'NOTA: Il presente messaggio (che include gli allegati) &#232; inviato ad uso esclusivo della parte cui &#232; indirizzato e pu&#242; contenere informazioni riservate, coperte da segreto professionale o comunque non divulgabili. Qualora Lei non sia il corretto destinatario del messaggio, le &#232; fatto divieto di qualsiasi uso, divulgazione, copia o riproduzione del medesimo. Se ha ricevuto questo messaggio per errore, la preghiamo di comunicare al mittente l&#39;accaduto e di cancellare dal suo sistema il presente messaggio e gli allegati immediatamente. Grazie.' ,
	'LBL_EMAIL_DEFAULT_CHARSET' => 'Componi email usando questo set di caratteri' ,
	'LBL_EMAIL_DEFAULT_CLIENT' => 'Componi email in questo formato' ,
	'LBL_EMAIL_DEFAULT_EDITOR' => 'Componi email usando questo programma' ,
	'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS' => 'Elimina Note correlate e files allegati con le email eliminate' ,
	'LBL_EMAIL_GMAIL_DEFAULTS' => 'Precompila Gmail Defaults' ,
	'LBL_EMAIL_PER_RUN_REQ' => 'Numero di messaggi alla volta:' ,
	'LBL_EMAIL_SMTP_SSL' => 'Abilita SMTP con SSL' ,
	'LBL_EMAIL_USER_TITLE' => 'Impostazioni Email Utente' ,
	'LBL_EMAILS_PER_RUN' => 'Numero di messaggi alla volta:' ,
	'LBL_ID' => 'Codice' ,
	'LBL_LIST_CAMPAIGN' => 'Campagna' ,
	'LBL_LIST_FORM_PROCESSED_TITLE' => 'Processati' ,
	'LBL_LIST_FORM_TITLE' => 'Coda' ,
	'LBL_LIST_FROM_EMAIL' => 'Email Mittente' ,
	'LBL_LIST_FROM_NAME' => 'Nome Mittente' ,
	'LBL_LIST_IN_QUEUE' => 'In Esecuzione' ,
	'LBL_LIST_MESSAGE_NAME' => 'Messaggio di Marketing' ,
	'LBL_LIST_RECIPIENT_EMAIL' => 'Email Destinatario' ,
	'LBL_LIST_RECIPIENT_NAME' => 'Nome Destinatario' ,
	'LBL_LIST_SEND_ATTEMPTS' => 'Tentativi di Invio' ,
	'LBL_LIST_SEND_DATE_TIME' => 'Invia in Data' ,
	'LBL_LIST_USER_NAME' => 'Nome Utente' ,
	'LBL_LOCATION_ONLY' => 'Posizione' ,
	'LBL_LOCATION_TRACK' => 'Posizione dei files di tracking della campagna (ad es. campaing_tracker.php)' ,
	'LBL_CAMP_MESSAGE_COPY' => 'Mantieni una copia dei messaggi delle campagne:' ,
	'LBL_CAMP_MESSAGE_COPY_DESC' => 'Vuoi fare una copia di <bold>OGNI</bold> messaggio email invitao durante tutte le campagne? <bold>Raccomandiamo di lasciare il valore di default: NO</bold>. Scegliendo no verr&#224; conservato solo il modello della mail che &#232; stata inviata e le variabili necessarie a ricreare il singolo messaggio.' ,
	'LBL_MAIL_SENDTYPE' => 'Consegna Messaggi (MTA):' ,
	'LBL_MAIL_SMTPAUTH_REQ' => 'Utilizzare Autenticazione SMTP ?' ,
	'LBL_MAIL_SMTPPASS' => 'Password SMTP:' ,
	'LBL_MAIL_SMTPPORT' => 'Porta SMTP:' ,
	'LBL_MAIL_SMTPSERVER' => 'Server SMTP:' ,
	'LBL_MAIL_SMTPUSER' => 'Login SMTP:' ,
	'LBL_MARKETING_ID' => 'Cod. Marketing' ,
	'LBL_MODULE_ID' => 'EmailMan' ,
	'LBL_MODULE_NAME' => 'Email di Massa' ,
	'LBL_CAMP_MODULE_NAME' => 'Impostazioni Campagna Email' ,
	'LBL_MODULE_TITLE' => 'Gestione Coda Email Marketing' ,
	'LBL_NOTIFICATION_ON_DESC' => 'Invia email di notifica quando avvengono delle assegnazioni.' ,
	'LBL_NOTIFY_FROMADDRESS' => 'Indirizzo Mittente:' ,
	'LBL_NOTIFY_FROMNAME' => 'Nome Mittente:' ,
	'LBL_NOTIFY_ON' => 'Notifiche su ?' ,
	'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Inviare notifiche ai nuovi utenti' ,
	'LBL_NOTIFY_TITLE' => 'Opzioni Notifiche Email' ,
	'LBL_OLD_ID' => 'Vecchio Codice' ,
	'LBL_OUTBOUND_EMAIL_TITLE' => 'Opzioni Posta in Uscita' ,
	'LBL_RELATED_ID' => 'Cod. Correlato' ,
	'LBL_RELATED_TYPE' => 'Tipo Correlato' ,
	'LBL_SAVE_OUTBOUND_RAW' => 'Salva Sorgente delle Email in Uscita' ,
	'LBL_SEARCH_FORM_PROCESSED_TITLE' => 'Cerca nei processati' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Coda' ,
	'LBL_VIEW_PROCESSED_EMAILS' => 'Mostra Email Processate' ,
	'LBL_VIEW_QUEUED_EMAILS' => 'Mostra Email in Coda' ,
	'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE' => 'Valore di site_url in config.php' ,
	'TXT_REMOVE_ME_ALT' => 'Per rimuoverti da questa lista vai a' ,
	'TXT_REMOVE_ME_CLICK' => 'clicca qui' ,
	'TXT_REMOVE_ME' => 'Per rimuoverti da questa lista' ,
	'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER' => 'Invia notifica dall&#39;indirizzo email degli utenti assegnati ?' ,
	'LBL_SECURITY_TITLE' => 'Impostazioni Sicurezza Email' ,
	'LBL_SECURITY_DESC' => 'Seleziona i tag che non devono essere permessi nelle mail in entrata o mostrati nel modulo Email' ,
	'LBL_SECURITY_APPLET' => 'Tag APPLET' ,
	'LBL_SECURITY_BASE' => 'Tag BASE' ,
	'LBL_SECURITY_EMBED' => 'Tag EMBED' ,
	'LBL_SECURITY_FORM' => 'Tag FORM' ,
	'LBL_SECURITY_FRAME' => 'Tag FRAME' ,
	'LBL_SECURITY_FRAMESET' => 'Tag FRAMESET' ,
	'LBL_SECURITY_IFRAME' => 'Tag IFRAME' ,
	'LBL_SECURITY_IMPORT' => 'Tag IMPORT' ,
	'LBL_SECURITY_LAYER' => 'Tag LAYER' ,
	'LBL_SECURITY_LINK' => 'Tag LINK' ,
	'LBL_SECURITY_OBJECT' => 'Tag OBJECT' ,
	'LBL_SECURITY_OUTLOOK_DEFAULTS' => 'Selezione il livello minimo di sicurezza per Outlook (errori nella visualizzazione)' ,
	'LBL_SECURITY_PRESERVE_RAW' => 'Mantieni il codice sorgente delle email, inclusi i contenuti potenzialmente pericolosi. Questa opzione preserva i messaggi completi solo nel database, mentre non influisce sul filtro di visualizzazione del CRM.<br /><span class&#061;&quot;error&quot;>Questo potrebbe causare una compromissione del sistema.</span>' ,
	'LBL_SECURITY_SCRIPT' => 'Tag SCRIPT' ,
	'LBL_SECURITY_STYLE' => 'Tag STYLE' ,
	'LBL_SECURITY_TOGGLE_ALL' => 'Attiva tutte le opzioni' ,
	'LBL_SECURITY_XMP' => 'Tag XMP' ,
	'LBL_YES' => 'S&#236;' ,
	'LBL_NO' => 'No' ,
	'LBL_PREPEND_TEST' => '[Test]:' ,
	'LBL_SEND_ATTEMPTS' => 'Tentativi di invio' ,

);


 


?>