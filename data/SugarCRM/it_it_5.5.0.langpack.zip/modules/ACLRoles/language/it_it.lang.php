<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 13:36 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Ruoli' ,
	'LBL_MODULE_TITLE' => 'Ruoli: Home' ,
	'LBL_ROLE' => 'Ruolo' ,
	'LBL_NAME' => 'Nome' ,
	'LBL_DESCRIPTION' => 'Descrizione' ,
	'LIST_ROLES' => 'Lista Ruoli' ,
	'LBL_USERS_SUBPANEL_TITLE' => 'Utenti' ,
	'LIST_ROLES_BY_USER' => 'Lista Ruoli per Utente' ,
	'LBL_ROLES_SUBPANEL_TITLE' => 'Ruoli Utente' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca' ,
	'LBL_CREATE_ROLE' => 'Nuovo Ruolo' ,
	'LBL_EDIT_VIEW_DIRECTIONS' => 'Doppio click in una cella per cambiare il valore.' ,
	'LBL_ACCESS_DEFAULT' => 'Predefinito' ,
	'LBL_ALL' => 'Tutti' ,
	'LBL_DUPLICATE_OF' => 'Duplicato di' ,
	'LBL_USER_NAME_FOR_ROLE' => 'Utenti/Gruppi/Ruoli' ,

);


 


?>