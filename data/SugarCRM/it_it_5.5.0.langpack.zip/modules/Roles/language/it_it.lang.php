<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 20:15 
$mod_strings = array(
	'LBL_ROLE' => 'Ruolo:' ,
	'LBL_LANGUAGE' => 'Lingua:' ,
	'LBL_MODULE_NAME' => 'Ruoli' ,
	'LBL_MODULE_TITLE' => 'Ruoli: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Ruolo' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Ruoli' ,
	'LNK_NEW_ROLE' => 'Nuovo Ruolo' ,
	'LNK_ROLES' => 'Ruoli' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_ALLOWED_MODULES' => 'Sezioni Abilitate:' ,
	'LBL_DISALLOWED_MODULES' => 'Sezioni Vietate:' ,
	'LBL_ASSIGN_MODULES' => 'Modifica Sezioni:' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Ruoli' ,
	'LBL_USERS' => 'Utenti' ,
	'LBL_USERS_SUBPANEL_TITLE' => 'Utenti' ,

);


 


?>