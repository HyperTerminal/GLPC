<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:52 
$mod_strings = array(
	'LBL_STEP_1' => 'Passo 1: Scegli il Modulo e il Modello' ,
	'LBL_MAILMERGE_MODULE' => 'Scegli Modulo:' ,
	'LBL_MAILMERGE_SELECTED_MODULE' => 'Modulo Selezionato:' ,
	'LBL_MAILMERGE_TEMPLATES' => 'Scegli Modello:' ,
	'LBL_STEP_2' => 'Passo 2: Scegli Oggetti da Unire' ,
	'LBL_MAILMERGE_OBJECTS' => 'Oggetti Selezionati:' ,
	'LBL_STEP_3' => 'Imposta l&#39;Associazione' ,
	'LBL_STEP_4' => 'Controlla e Concludi' ,
	'LBL_SELECTED_MODULE' => 'Modulo Selezionato:' ,
	'LBL_SELECTED_TEMPLATE' => 'Modello Selezionato:' ,
	'LBL_SELECTED_ITEMS' => 'Oggetti Selezionati:' ,
	'LBL_STEP_5' => 'Unione Mail Completo' ,
	'LBL_MERGED_FILE' => 'File Uniti:' ,
	'LNK_NEW_MAILMERGE' => 'Inizia Unione Mail' ,
	'LNK_UPLOAD_TEMPLATE' => 'Aggiungi Modello' ,
	'LBL_DOC_NAME' => 'Nome Documento:' ,
	'LBL_FILENAME' => 'Nome File:' ,
	'LBL_DOC_VERSION' => 'Revisione:' ,
	'LBL_DOC_DESCRIPTION' => 'Descrizione:' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_RELATIONSHIP' => 'Imposta Relazione' ,
	'LBL_FINISH' => 'Inizia Unione' ,
	'LBL_NEXT' => 'Prossimo >' ,
	'LBL_BACK' => '< Precedente' ,
	'LBL_START' => 'Inizia Nuovamente' ,
	'LBL_TEMPLATE_NOTICE' => 'I modelli sono documenti in formato MS Word contenenti campi unione. I documenti vengono caricati e salvati nel modulo Documenti.' ,
	'LBL_CONTAINS_CONTACT_INFO' => 'Il modello selezionato contiene relative' ,
	'LBL_ADDIN_NOTICE' => 'Questa funzione richiede l&#39;installazione di Sugar Mail Merge per Microsoft Word.' ,
	'LBL_BROWSER_NOTICE' => 'Devi utilizzare Internet Explorer 6.0 o successivi per attuare l&#39;unione.' ,

);


 


?>