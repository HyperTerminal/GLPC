<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 17:40 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Grafici' ,
	'LBL_MODULE_TITLE' => 'Grafici: Home' ,
	'LNK_NEW_ACCOUNT' => 'Nuova Azienda' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_CASE' => 'Nuovo Ticket Supporto' ,
	'LNK_NEW_CONTACT' => 'Nuovo Contatto' ,
	'LNK_NEW_ISSUE' => 'Segnala Errore' ,
	'LNK_NEW_LEAD' => 'Nuovo Lead' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunit&#224;' ,
	'LNK_NEW_QUOTE' => 'Nuova Offerta' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LBL_ADD_A_CHART' => 'Aggiungi grafico' ,
	'LBL_DELETE_FROM_DASHBOARD' => 'Cancella dai grafici' ,
	'LBL_MOVE_DOWN' => 'Sposta Su' ,
	'LBL_MOVE_UP' => 'Sposta Gi&#249;' ,
	'LBL_BASIC_CHARTS' => '-- Grafici Base --' ,
	'LBL_PUBLISHED_REPORTS' => '-- Rapporti Globali Gruppo --' ,
	'LBL_MY_REPORTS' => '-- I Miei Rapporti --' ,
	'LBL_TEAM_REPORTS' => '-- I Rapporti del mio Team --' ,
	'LBL_REPORT_NO_CHART' => 'Questo rapporto non ha un grafico' ,
	'LBL_MOVE_CHARTS' => '(Clicca sul nome di un grafico per spostarlo)' ,
	'LBL_DASHBOARD_PAGE_1' => 'Pag. iniziale Grafici' ,
	'LBL_DASHBOARD_PAGE_2' => 'Grafici Vendita' ,

);


 


?>