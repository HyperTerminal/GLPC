<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:42 
$mod_strings = array(
	'LBL_ID' => 'ID' ,
	'LBL_MODULE_NAME' => 'RSS' ,
	'LBL_MODULE_ID' => 'Feeds' ,
	'LBL_MODULE_TITLE' => 'RSS: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca RSS News Feed' ,
	'LBL_LIST_FORM_TITLE' => 'Lista RSS News Feed' ,
	'LBL_MY_LIST_FORM_TITLE' => 'I Miei RSS News Feeds' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovi RSS News Feed' ,
	'NTC_DELETE_CONFIRMATION' => 'Sicuro di voler eliminare questo dato ?' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LNK_NEW_FEED' => 'Nuovo RSS News Feed' ,
	'LNK_FEED_LIST' => 'Tutti i RSS News Feeds' ,
	'LNK_MY_FEED_LIST' => 'I miei RSS News Feeds' ,
	'LBL_TITLE' => 'Titolo' ,
	'LBL_RSS_URL' => 'RSS URL' ,
	'LBL_ONLY_MY' => 'Solo i miei favoriti' ,
	'LBL_VISIT_WEBSITE' => 'visita sito web' ,
	'LBL_LAST_UPDATED' => 'Ultimo aggiornamento' ,
	'LBL_DELETE_FAVORITES' => 'Togli dai Favoriti' ,
	'LBL_DELETE_FAV_BUTTON_TITLE' => 'Togli dai Favoriti [Alt+D]' ,
	'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]' ,
	'LBL_DELETE_FAV_BUTTON_LABEL' => 'Togli dai favoriti' ,
	'LBL_ADD_FAV_BUTTON_TITLE' => 'Aggiungi ai favoriti [Alt+A]' ,
	'LBL_ADD_FAV_BUTTON_KEY' => '[Alt+A]' ,
	'LBL_ADD_FAV_BUTTON_LABEL' => 'Aggiungi ai favoriti' ,
	'LBL_MOVE_UP' => 'Sposta Su' ,
	'LBL_MOVE_DOWN' => 'Sposta Gi&#249;' ,
	'LBL_FEED_NOT_AVAILABLE' => 'Feed non disponibile' ,
	'LBL_REFRESH_CACHE' => 'Clicca qui per aggiornare la cache' ,
	'LBL_TILE' => 'Titolo' ,
	'LBL_URL' => 'URL' ,
	'LBL_DESCRIPTION' => 'Descrizione' ,

);


 


?>