<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 21:43 
$mod_strings = array(
	'ShowActiveUsers' => 'Mostra Utenti Attivi' ,
	'ShowLastModifiedRecords' => 'Ultimi 10 Records Modificati' ,
	'ShowTopUser' => 'Utenti Top' ,
	'ShowMyModuleUsage' => 'My Module Usage' ,
	'ShowMyWeeklyActivities' => 'Le mie attivit&#224; settimanali' ,
	'ShowTop3ModulesUsed' => 'Il mio Top 3 dei moduli utilizzati' ,
	'ShowLoggedInUserCount' => 'Numero di Utenti attivi' ,
	'ShowMyCumulativeLoggedInTime' => 'Login Time (Questa Settimana)' ,
	'ShowUsersCumulativeLoggedInTime' => 'Login Time degli Utenti (Questa Settimana)' ,
	'action' => 'Azione' ,
	'active_users' => 'Numero di Utenti attivi' ,
	'date_modified' => 'Data dell&#39; ultima azione' ,
	'different_modules_accessed' => 'Numero dei Moduli usati' ,
	'first_name' => 'Nome' ,
	'item_id' => 'ID' ,
	'item_summary' => 'Cognome' ,
	'last_action' => 'Data/Ora ultima Azione' ,
	'last_name' => 'Cognome' ,
	'module_name' => 'Nome Modulo' ,
	'records_modified' => 'Totale Records Modificati' ,
	'top_module' => 'Top Moduli Accessi' ,
	'total_count' => 'Totale Pagine Viste' ,
	'total_login_time' => 'Orario (hh:mm:ss)' ,
	'user_name' => 'Username' ,
	'users' => 'Utenti' ,
	'LBL_ENABLE' => 'Attivato' ,
	'LBL_MODULE_NAME_TITLE' => 'Trackers' ,
	'LBL_TRACKER_SETTINGS' => 'Impostazioni Tracker' ,
	'LBL_TRACKER_QUERIES_DESC' => 'Tracker Queries' ,
	'LBL_TRACKER_QUERIES_HELP' => 'Registra le istruzioni SQL quando &quot;Registra interrogazioni database lente&quot; &#232; abilitata e il tempo di esecuzione eccede la il valore della &quot;Soglia interrogazioni lente&quot;' ,
	'LBL_TRACKER_PERF_DESC' => 'Tracker Performance' ,
	'LBL_TRACKER_PERF_HELP' => 'Track database roundtrips, files accessed and memory usage' ,
	'LBL_TRACKER_SESSIONS_DESC' => 'Tracker Sessions' ,
	'LBL_TRACKER_SESSIONS_HELP' => 'Track active users and users&#39; session information' ,
	'LBL_TRACKER_DESC' => 'Tracker Actions' ,
	'LBL_TRACKER_HELP' => 'Track user&#39;s page views (modules and records accessed) and record saves' ,
	'LBL_TRACKER_PRUNE_INTERVAL' => 'Number of days of Tracker data to store when Scheduler prunes the tables' ,
	'LBL_TRACKER_PRUNE_RANGE' => 'Numero di giorni' ,

);


 


?>