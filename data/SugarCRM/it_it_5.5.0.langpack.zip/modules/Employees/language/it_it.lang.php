<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:42 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Impiegati' ,
	'LBL_MODULE_TITLE' => 'Impiegati: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Impiegati' ,
	'LBL_LIST_FORM_TITLE' => 'Impiegati' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Impiegato' ,
	'LBL_EMPLOYEE' => 'Impiegati:' ,
	'LBL_LOGIN' => 'Login' ,
	'LBL_RESET_PREFERENCES' => 'Ripristina Preferenze Predefinite' ,
	'LBL_TIME_FORMAT' => 'Formato Ora:' ,
	'LBL_DATE_FORMAT' => 'Formato Data:' ,
	'LBL_TIMEZONE' => 'Fuso Orario:' ,
	'LBL_CURRENCY' => 'Valuta:' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_LAST_NAME' => 'Cognome' ,
	'LBL_LIST_EMPLOYEE_NAME' => 'Nome Impiegato' ,
	'LBL_LIST_DEPARTMENT' => 'Dipartimento' ,
	'LBL_LIST_REPORTS_TO_NAME' => 'Dipende Da' ,
	'LBL_LIST_EMAIL' => 'Email' ,
	'LBL_LIST_PRIMARY_PHONE' => 'Telefono' ,
	'LBL_LIST_USER_NAME' => 'Nome Utente' ,
	'LBL_LIST_ADMIN' => 'Amministratore' ,
	'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Nuovo Impiegato [Alt+N]' ,
	'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Nuovo Impiegato' ,
	'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N' ,
	'LBL_ERROR' => 'Errore:' ,
	'LBL_PASSWORD' => 'Password:' ,
	'LBL_EMPLOYEE_NAME' => 'Nome Impiegato:' ,
	'LBL_USER_NAME' => 'Nome Utente:' ,
	'LBL_FIRST_NAME' => 'Nome:' ,
	'LBL_LAST_NAME' => 'Cognome:' ,
	'LBL_EMPLOYEE_SETTINGS' => 'Impostazioni Impiegato' ,
	'LBL_THEME' => 'Tema:' ,
	'LBL_LANGUAGE' => 'Lingua:' ,
	'LBL_ADMIN' => 'Amminsitratore:' ,
	'LBL_EMPLOYEE_INFORMATION' => 'Informazioni Impiegato' ,
	'LBL_OFFICE_PHONE' => 'Telefono Ufficio:' ,
	'LBL_REPORTS_TO' => 'Dipende da Id:' ,
	'LBL_REPORTS_TO_NAME' => 'Dipende da:' ,
	'LBL_OTHER_PHONE' => 'Altro:' ,
	'LBL_OTHER_EMAIL' => 'Altro Email:' ,
	'LBL_NOTES' => 'Note:' ,
	'LBL_DEPARTMENT' => 'Dipartimento:' ,
	'LBL_TITLE' => 'Titolo:' ,
	'LBL_ANY_PHONE' => 'Telefono Generico:' ,
	'LBL_ANY_EMAIL' => 'Email Generica:' ,
	'LBL_ADDRESS' => 'Indirizzo:' ,
	'LBL_CITY' => 'Comune:' ,
	'LBL_STATE' => 'Provincia:' ,
	'LBL_POSTAL_CODE' => 'CAP:' ,
	'LBL_COUNTRY' => 'Nazione:' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_MOBILE_PHONE' => 'Cellulare:' ,
	'LBL_OTHER' => 'Altro:' ,
	'LBL_FAX' => 'Fax:' ,
	'LBL_EMAIL' => 'Email:' ,
	'LBL_HOME_PHONE' => 'Telefono Casa:' ,
	'LBL_WORK_PHONE' => 'Telefono Ufficio:' ,
	'LBL_ADDRESS_INFORMATION' => 'Informazioni Indirizzo' ,
	'LBL_EMPLOYEE_STATUS' => 'Stato Impiegato:' ,
	'LBL_PRIMARY_ADDRESS' => 'Indirizzo principale:' ,
	'LBL_SAVED_SEARCH' => 'Opzioni del layout' ,
	'LBL_CREATE_USER_BUTTON_TITLE' => 'Nuovo Utente [Alt+N]' ,
	'LBL_CREATE_USER_BUTTON_LABEL' => 'Nuovo Utente' ,
	'LBL_CREATE_USER_BUTTON_KEY' => 'N' ,
	'LBL_FAVORITE_COLOR' => 'Colore Preferito:' ,
	'LBL_MESSENGER_ID' => 'Nome IM:' ,
	'LBL_MESSENGER_TYPE' => 'Tipo IM:' ,
	'ERR_EMPLOYEE_NAME_EXISTS_1' => 'L&#39;impiegato' ,
	'ERR_EMPLOYEE_NAME_EXISTS_2' => 'esiste gi&#224;. Non sono ammessi impiegati con lo stesso nome. Modifica il nome afffinch&#232; sia unico.' ,
	'ERR_LAST_ADMIN_1' => 'L&#39;impiegato &quot;' ,
	'ERR_LAST_ADMIN_2' => '&quot; &#232; l&#39;ultimo impiegato con accesso amministrativo. Dev&#39;esserci almeno un impiegato amministratore.' ,
	'LNK_NEW_EMPLOYEE' => 'Nuovo Impiegato' ,
	'LNK_EMPLOYEE_LIST' => 'Impiegati' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'LBL_LIST_EMPLOYEE_STATUS' => 'Stato' ,
	'LBL_SUGAR_LOGIN' => 'E&#39; un utente del Crm' ,
	'LBL_RECEIVE_NOTIFICATIONS' => 'Notifica su assegnazione' ,
	'LBL_IS_ADMIN' => 'E&#39; un amministratore' ,
	'LBL_GROUP' => 'Utente Gruppo' ,
	'LBL_PORTAL_ONLY' => 'Utente solo del portale' ,

);


 


?>