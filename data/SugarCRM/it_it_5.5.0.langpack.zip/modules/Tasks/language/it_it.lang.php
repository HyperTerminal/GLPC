<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 21:34 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Compiti' ,
	'LBL_TASK' => 'Compiti:' ,
	'LBL_MODULE_TITLE' => 'Compiti: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Compito' ,
	'LBL_LIST_FORM_TITLE' => 'Elenco Compiti' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Compito' ,
	'LBL_NEW_FORM_SUBJECT' => 'soggetto:' ,
	'LBL_NEW_FORM_DUE_DATE' => 'data di completamento:' ,
	'LBL_NEW_FORM_DUE_TIME' => 'ora di completamento:' ,
	'LBL_NEW_TIME_FORMAT' => '(24:00)' ,
	'LBL_LIST_CLOSE' => 'Chiuso' ,
	'LBL_LIST_SUBJECT' => 'Oggetto' ,
	'LBL_LIST_CONTACT' => 'Contatto' ,
	'LBL_LIST_PRIORITY' => 'Priorit&#224;' ,
	'LBL_LIST_RELATED_TO' => 'Relativo a' ,
	'LBL_LIST_DUE_DATE' => 'Data di completamento' ,
	'LBL_LIST_DUE_TIME' => 'Ora di completamento' ,
	'LBL_SUBJECT' => 'Oggetto:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_DUE_DATE' => 'Data di completamento' ,
	'LBL_DUE_TIME' => 'Ora Scadenza Completamento:' ,
	'LBL_PRIORITY' => 'Priorit&#224;:' ,
	'LBL_COLON' => ':' ,
	'LBL_DUE_DATE_AND_TIME' => 'Data & Ora di completamento' ,
	'LBL_START_DATE_AND_TIME' => 'Data e Ora di Inizio:' ,
	'LBL_START_DATE' => 'Data di Inizio:' ,
	'LBL_LIST_START_DATE' => 'Data di Inizio' ,
	'LBL_START_TIME' => 'Ora di Inizio:' ,
	'LBL_LIST_START_TIME' => 'Ora di Inizio' ,
	'DATE_FORMAT' => '(aaaa-mm-gg 24:00)' ,
	'LBL_NONE' => 'nessuno' ,
	'LBL_CONTACT' => 'Contatto:' ,
	'LBL_EMAIL_ADDRESS' => 'Indirizzo Email:' ,
	'LBL_PHONE' => 'Telefono:' ,
	'LBL_EMAIL' => 'Email:' ,
	'LBL_DESCRIPTION_INFORMATION' => 'Descrizione' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_LIST_COMPLETE' => 'Termina' ,
	'LBL_LIST_STATUS' => 'Stato:' ,
	'LBL_DATE_DUE_FLAG' => 'Nessuna Scadenza Completamento' ,
	'LBL_DATE_START_FLAG' => 'Nessuna Data di Inizio' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'ERR_INVALID_HOUR' => 'Inserire un&#39;ora compresa tra 0 e 24' ,
	'LBL_DEFAULT_STATUS' => 'Non iniziata' ,
	'LBL_DEFAULT_PRIORITY' => 'Media' ,
	'LBL_LIST_MY_TASKS' => 'I miei compiti aperti' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_EMAIL' => 'Nuova Email' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_TASK_LIST' => 'Compiti' ,
	'LNK_NOTE_LIST' => 'Note' ,
	'LNK_EMAIL_LIST' => 'Emails' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'LBL_CONTACT_FIRST_NAME' => 'Nome Contatto' ,
	'LBL_CONTACT_LAST_NAME' => 'Cognome Contatto' ,
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Utente Assegnato' ,
	'LBL_ASSIGNED_TO_NAME' => 'Assegnato a:' ,
	'LBL_LIST_DATE_MODIFIED' => 'Data Ultima Modifica' ,
	'LBL_CONTACT_ID' => 'ID Contatto:' ,
	'LBL_PARENT_ID' => 'ID Parent:' ,
	'LBL_CONTACT_PHONE' => 'Telefono Contatto:' ,
	'LBL_PARENT_NAME' => 'Tipo di Parent:' ,
	'LBL_ACTIVITIES_REPORTS' => 'Report Attivit&#224;' ,

);


 


?>