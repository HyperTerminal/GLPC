<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
global $sugar_config;

 // 2009.12.17 20:20 
$mod_strings = array(
	'LBL_OOTB_WORKFLOW' => 'Processa Compiti del Flusso di Lavoro' ,
	'LBL_OOTB_REPORTS' => 'Esegui Compiti per la Generazione dei Rapporti' ,
	'LBL_OOTB_IE' => 'Controlla Posta in Arrivo nelle Caselle' ,
	'LBL_OOTB_BOUNCE' => 'Eegui processi notturni per il controllo delle email di ritorno' ,
	'LBL_OOTB_CAMPAIGN' => 'Esegui invio notturno delle Campagne Email' ,
	'LBL_OOTB_PRUNE' => 'Comprimi il Database il primo giorno del mese' ,
	'LBL_OOTB_TRACKER' => 'Cancella il Registro Utenti il primo del mese' ,
	'LBL_UPDATE_TRACKER_SESSIONS' => 'Aggiorna la tabella tracker_sessions' ,
	'LBL_LIST_JOB_INTERVAL' => 'Intervallo:' ,
	'LBL_LIST_LIST_ORDER' => 'Pianificatori:' ,
	'LBL_LIST_NAME' => 'Pianificatore:' ,
	'LBL_LIST_RANGE' => 'Limit:' ,
	'LBL_LIST_REMOVE' => 'Rimuovi:' ,
	'LBL_LIST_STATUS' => 'Stato:' ,
	'LBL_LIST_TITLE' => 'Lista Pianificazione:' ,
	'LBL_LIST_EXECUTE_TIME' => 'Verr&#224; eseguito di:' ,
	'LBL_SUN' => 'Domenica' ,
	'LBL_MON' => 'Luned&#236;' ,
	'LBL_TUE' => 'Marted&#236;' ,
	'LBL_WED' => 'Mercoled&#236;' ,
	'LBL_THU' => 'Gioved&#236;' ,
	'LBL_FRI' => 'Venerd&#236;' ,
	'LBL_SAT' => 'Sabato' ,
	'LBL_ALL' => 'Ogni Giorno' ,
	'LBL_EVERY_DAY' => 'Ogni giorno' ,
	'LBL_AT_THE' => 'Al' ,
	'LBL_EVERY' => 'Ogni' ,
	'LBL_FROM' => 'Da' ,
	'LBL_ON_THE' => 'Al' ,
	'LBL_RANGE' => 'a' ,
	'LBL_AT' => 'di' ,
	'LBL_IN' => 'in' ,
	'LBL_AND' => 'e' ,
	'LBL_MINUTES' => 'minuti' ,
	'LBL_HOUR' => 'ore' ,
	'LBL_HOUR_SING' => 'ora' ,
	'LBL_MONTH' => 'mese' ,
	'LBL_OFTEN' => 'Pi&#249; spesso possibile' ,
	'LBL_MIN_MARK' => 'minuto scelto' ,
	'LBL_MINS' => 'min' ,
	'LBL_HOURS' => 'ore' ,
	'LBL_DAY_OF_MONTH' => 'data' ,
	'LBL_MONTHS' => 'mese' ,
	'LBL_DAY_OF_WEEK' => 'giorno' ,
	'LBL_CRONTAB_EXAMPLES' => 'Quanto sopra utilizza la notazione crontab.' ,
	'LBL_ALWAYS' => 'Sempre' ,
	'LBL_CATCH_UP' => 'Esegui Se Mancato' ,
	'LBL_CATCH_UP_WARNING' => 'Non contrassegnare se l&#39;esecuzione pu&#242; richiedere molto tempo.' ,
	'LBL_DATE_TIME_END' => 'Data e Ora Fine' ,
	'LBL_DATE_TIME_START' => 'Data e Ora Inizio' ,
	'LBL_INTERVAL' => 'Intervallo' ,
	'LBL_JOB' => 'Job' ,
	'LBL_LAST_RUN' => 'Ultima Esecuzione' ,
	'LBL_MODULE_NAME' => 'Pianificazione CRM' ,
	'LBL_MODULE_TITLE' => 'Pianificazione' ,
	'LBL_NAME' => 'Nome Job' ,
	'LBL_NEVER' => 'Mai' ,
	'LBL_NEW_FORM_TITLE' => 'Nuova Pianificazione' ,
	'LBL_PERENNIAL' => 'continuo' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Pianificazione' ,
	'LBL_SCHEDULER' => 'Pianificatore:' ,
	'LBL_STATUS' => 'Stato' ,
	'LBL_TIME_FROM' => 'Attivo Da' ,
	'LBL_TIME_TO' => 'Attivo A' ,
	'LBL_WARN_CURL_TITLE' => 'Avviso cURL:' ,
	'LBL_WARN_CURL' => 'Avviso:' ,
	'LBL_WARN_NO_CURL' => 'Il PHP di questo sistema non ha le librerie cURL (--with-curl&#061;/path/to/curl_library). Contatta l&#39;amministratore del server per risolvere questo problema. Senza queste librerie non &#232; possibile eseguire i job pianificati.' ,
	'LBL_BASIC_OPTIONS' => 'Settaggi Base' ,
	'LBL_ADV_OPTIONS' => 'Opzioni Avanzate' ,
	'LBL_TOGGLE_ADV' => 'Opzioni Avanzate' ,
	'LBL_TOGGLE_BASIC' => 'Opzioni Base' ,
	'LNK_LIST_SCHEDULER' => 'Pianificazioni' ,
	'LNK_NEW_SCHEDULER' => 'Nuova Pianificazione' ,
	'LNK_LIST_SCHEDULED' => 'Job Pianificati' ,
	'SOCK_GREETING' => 'Questa &#232; l&#39;interfaccia per il Servizio di Pianificazione. [ Comandi del servizio disponibili: start|restart|shutdown|status ]. Per uscire scrivi &#39;quit&#39;. Per fermare il servizio scrivi &#39;shutdown&#39;.' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'ERR_CRON_SYNTAX' => 'Sintassi Cron non valida' ,
	'NTC_DELETE_CONFIRMATION' => 'Sicuro di voler cancellare questo dato ?' ,
	'NTC_STATUS' => 'Imposta lo stato a Disattivato per rimuovere questa pianificazione dalla lista del Pianificatore.' ,
	'NTC_LIST_ORDER' => 'Imposta l&#39;ordine con cui questa Pianificazione apparir&#224; nella lista del Pianificatore' ,
	'LBL_CRON_INSTRUCTIONS_WINDOWS' => 'Per impostare il pianificatore di Windows' ,
	'LBL_CRON_INSTRUCTIONS_LINUX' => 'Per impostare il pianificatore Crontab' ,
	'LBL_CRON_LINUX_DESC' => 'Aggiungi questa linea al tuo crontab:' ,
	'LBL_CRON_WINDOWS_DESC' => 'Crea un file batch con i seguenti comandi:' ,
	'LBL_NO_PHP_CLI' => 'Se il tuo server non ha disponibile il PHP eseguibile, puoi usare wget o curl per lanciare i job.<br>per wget: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;wget --quiet --non-verbose '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1</b><br>for curl: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;curl --silent '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1', 
	'LBL_JOBS_SUBPANEL_TITLE' => 'Job Attivi' ,
	'LBL_EXECUTE_TIME' => 'Tempo Esecuzione' ,
	'LBL_REFRESHJOBS' => 'Refresh Jobs' ,
	'LBL_POLLMONITOREDINBOXES' => 'Verifica i profili Mail in entrata' ,
	'LBL_RUNMASSEMAILCAMPAIGN' => 'Esegui invio notturno delle Campagne Email' ,
	'LBL_POLLMONITOREDINBOXESFORBOUNCEDCAMPAIGNEMAILS' => 'Eegui processi notturni per il controllo delle email di ritorno' ,
	'LBL_PRUNEDATABASE' => 'Comprimi il Database il primo giorno del mese' ,
	'LBL_TRIMTRACKER' => 'Cancella il Registro Utenti il primo del mese' ,

);


 


?>