<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 22:10 
$mod_strings = array(
	'LBL_ADD_ANOTHER_FILE' => 'Aggiungi un altro File' ,
	'LBL_ADD_DOCUMENT' => 'Aggiungi un Documento' ,
	'LBL_ADD_FILE' => 'Aggiungi File' ,
	'LBL_ATTACHMENTS' => 'Allegati' ,
	'LBL_BODY' => 'Corpo:' ,
	'LBL_CLOSE' => 'Chiudi:' ,
	'LBL_COLON' => ':' ,
	'LBL_CONTACT_AND_OTHERS' => 'Contatto/Lead/Obiettivo' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_EDIT_ALT_TEXT' => 'Modifica Testo Alternativo' ,
	'LBL_EMAIL_ATTACHMENT' => 'Allegato Email' ,
	'LBL_HTML_BODY' => 'Corpo HTML' ,
	'LBL_INSERT_VARIABLE' => 'Inserisci Variabile:' ,
	'LBL_INSERT_URL_REF' => 'Inserisici URL di riferimento' ,
	'LBL_INSERT_TRACKER_URL' => 'Inserisci URL del Tracker:' ,
	'LBL_INSERT' => 'Inserisci' ,
	'LBL_LIST_DATE_MODIFIED' => 'Ultima Modifica' ,
	'LBL_LIST_DESCRIPTION' => 'Descrizione' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Modelli Email' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_MODULE_NAME' => 'Modelli Email' ,
	'LBL_MODULE_TITLE' => 'Modelli Email: Home' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Modello Email' ,
	'LBL_PUBLISH' => 'Pubblicazione:' ,
	'LBL_RELATED_TO' => 'Riferito A:' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Modelli Email' ,
	'LBL_SHOW_ALT_TEXT' => 'Mostra Testo Alternativo' ,
	'LBL_SUBJECT' => 'Oggetto:' ,
	'LBL_SUGAR_DOCUMENT' => 'Documento CRM' ,
	'LBL_TEAMS' => 'Teams:' ,
	'LBL_TEAMS_LINK' => 'Teams' ,
	'LBL_TEXT_BODY' => 'Corpo Testo Semplice' ,
	'LBL_USERS' => 'Utenti' ,
	'LNK_ALL_EMAIL_LIST' => 'Tutte le Email' ,
	'LNK_ARCHIVED_EMAIL_LIST' => 'Email Archiviate' ,
	'LNK_CHECK_EMAIL' => 'Controllo Email' ,
	'LNK_DRAFTS_EMAIL_LIST' => 'Bozza' ,
	'LNK_EMAIL_TEMPLATE_LIST' => 'Modelli Email' ,
	'LNK_IMPORT_NOTES' => 'Importa Note' ,
	'LNK_NEW_ARCHIVE_EMAIL' => 'Crea Email Archiviate' ,
	'LNK_NEW_EMAIL_TEMPLATE' => 'Nuovo Modello Email' ,
	'LNK_NEW_EMAIL' => 'Archivia Email' ,
	'LNK_NEW_SEND_EMAIL' => 'Composizione Email' ,
	'LNK_SENT_EMAIL_LIST' => 'Email Inviate' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'LBL_NEW' => 'Nuovo' ,
	'LNK_CHECK_MY_INBOX' => 'Controlla la Mia Posta' ,
	'LNK_GROUP_INBOX' => 'Posta in Arrivo del Gruppo' ,
	'LNK_MY_ARCHIVED_LIST' => 'I Miei Archivi' ,
	'LNK_MY_DRAFTS' => 'Bozze' ,
	'LNK_MY_INBOX' => 'Posta in Arrivo' ,
	'LBL_LIST_BASE_MODULE' => 'Modulo di Base:' ,
	'LBL_TEXT_ONLY' => 'Solo Testo' ,
	'LBL_SEND_AS_TEXT' => 'Invia Solo Testo' ,
	'LBL_ACCOUNT' => 'Profilo' ,
	'LBL_BASE_MODULE' => 'Modulo Base' ,
	'LBL_FROM_NAME' => 'Nome Mittente' ,
	'LBL_PLAIN_TEXT' => 'Testo Semplice' ,
	'LBL_CREATED_BY' => 'Creato da' ,
	'LBL_FROM_ADDRESS' => 'Indirizzo Mittente' ,
	'LBL_PUBLISHED' => 'Pubblicato' ,
	'LBL_ACTIVITIES_REPORTS' => 'Report Attivit&#224;' ,

);


 


?>