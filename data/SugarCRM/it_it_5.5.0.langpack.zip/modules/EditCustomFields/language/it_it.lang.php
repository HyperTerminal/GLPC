<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 17:42 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Modifica Campi Personalizzati' ,
	'LBL_ADD_FIELD' => 'Nuovo Campo:' ,
	'LBL_MODULE_TITLE' => 'Modifica Campi Personalizzati' ,
	'LBL_MODULE_SELECT' => 'Sezione da Modificare' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Sezione' ,
	'COLUMN_TITLE_NAME' => 'Nome Campo' ,
	'COLUMN_TITLE_DISPLAY_LABEL' => 'Mostra Etichetta' ,
	'COLUMN_TITLE_LABEL_VALUE' => 'Valore Etichetta' ,
	'COLUMN_TITLE_LABEL' => 'Etichetta Sistema' ,
	'COLUMN_TITLE_DATA_TYPE' => 'Tipo Informazione' ,
	'COLUMN_TITLE_MAX_SIZE' => 'Dimensione Massima' ,
	'COLUMN_TITLE_HELP_TEXT' => 'Testo di Aiuto' ,
	'COLUMN_TITLE_COMMENT_TEXT' => 'Testo Commento' ,
	'COLUMN_TITLE_REQUIRED_OPTION' => 'Campo Necessario' ,
	'COLUMN_TITLE_DEFAULT_VALUE' => 'Valore Predefinito' ,
	'COLUMN_TITLE_DEFAULT_EMAIL' => 'Valore Predefinito' ,
	'COLUMN_TITLE_EXT1' => 'Metainformazione Extra 1' ,
	'COLUMN_TITLE_EXT2' => 'Metainformazione Extra 2' ,
	'COLUMN_TITLE_EXT3' => 'Metainformazione Extra 3' ,
	'COLUMN_TITLE_FRAME_HEIGHT' => 'IFrame Altezza' ,
	'COLUMN_TITLE_HTML_CONTENT' => 'HTML' ,
	'COLUMN_TITLE_URL' => 'URL Predefinito' ,
	'COLUMN_TITLE_AUDIT' => 'Verifica ?' ,
	'COLUMN_TITLE_REPORTABLE' => 'Accessibile ai Rapporti' ,
	'COLUMN_TITLE_MIN_VALUE' => 'Valore Min' ,
	'COLUMN_TITLE_MAX_VALUE' => 'Valore Max' ,
	'COLUMN_TITLE_DISPLAYED_ITEM_COUNT' => '# Oggetti visualizzati' ,
	'COLUMN_DISABLE_NUMBER_FORMAT' => 'Disattiva Formato' ,
	'LBL_DROP_DOWN_LIST' => 'Lista Valori' ,
	'LBL_RADIO_FIELDS' => 'Campi Radio' ,
	'LBL_MULTI_SELECT_LIST' => 'Lista Valori Multipli' ,
	'COLUMN_TITLE_PRECISION' => 'Precisione' ,
	'MSG_DELETE_CONFIRM' => 'Sicuro di voler eliminare questo oggetto ?' ,
	'POPUP_INSERT_HEADER_TITLE' => 'Aggiungi Campo Personalizzato' ,
	'POPUP_EDIT_HEADER_TITLE' => 'Modifica Campo Personalizzato' ,
	'LNK_SELECT_CUSTOM_FIELD' => 'Scegli Campo Personalizzato' ,
	'LNK_REPAIR_CUSTOM_FIELD' => 'Ripara Campi Personalizzati' ,
	'LBL_MODULE' => 'Modulo' ,
	'COLUMN_TITLE_MASS_UPDATE' => 'Aggiornamento Globale' ,
	'COLUMN_TITLE_IMPORTABLE' => 'Importa' ,
	'COLUMN_TITLE_DUPLICATE_MERGE' => 'Unione Dati Duplicati' ,
	'LBL_LABEL' => 'Etichetta' ,
	'LBL_DATA_TYPE' => 'Tipo di Dati' ,
	'LBL_DEFAULT_VALUE' => 'Valore Predefinito' ,
	'LBL_AUDITED' => 'Monitorato' ,
	'LBL_REPORTABLE' => 'Accessibile ai Rapporti' ,
	'ERR_RESERVED_FIELD_NAME' => 'Chiave riservata' ,
	'ERR_SELECT_FIELD_TYPE' => 'Seleziona un Tipo di Campo' ,
	'LBL_BTN_ADD' => 'Aggiungi' ,
	'LBL_BTN_EDIT' => 'Modifica' ,
	'LBL_GENERATE_URL' => 'Genera URL' ,
	'LBL_DEPENDENT_CHECKBOX' => 'Dpendente' ,
	'LBL_DEPENDENT_TRIGGER' => 'Trigger' ,
	'LBL_BTN_EDIT_VISIBILITY' => 'Modifica Visibilit&#224;' ,

);


 


?>