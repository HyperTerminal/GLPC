<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.16 15:13 
$mod_strings = array(
	'ERR_NO_OPPS' => 'Crea qualche opportunit&#224; per vedere i grafici delle opportunit&#224;.' ,
	'LBL_ALL_OPPORTUNITIES' => 'Il totale di tutte le opportunit&#224; &#232;' ,
	'LBL_CHART_TYPE' => 'Tipologia Grafico:' ,
	'LBL_CREATED_ON' => 'Ultimo aggiornamento' ,
	'LBL_DATE_END' => 'Data Fine:' ,
	'LBL_DATE_RANGE_TO' => 'a' ,
	'LBL_DATE_RANGE' => 'L&#39;arco di tempo &#232;' ,
	'LBL_DATE_START' => 'Data Inizio:' ,
	'LBL_EDIT' => 'Modifica' ,
	'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Mostra gli importi cumulativi delle opportunit&#224; per i lead selezionati per ricavo degli utenti selezionati. Il ricavo si basa sullo stadio di vendita Chiuso Vinto, Chiuso Perso o qualsiasi altro stadio.' ,
	'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Tutte le Opportunit&#224; per Lead per Ricavo' ,
	'LBL_LEAD_SOURCE_FORM_DESC' => 'Mostra gli importi cumulativi delle opportunit&#224; per i lead selezionati per gli utenti selezionati.' ,
	'LBL_LEAD_SOURCE_FORM_TITLE' => 'Tutte le Opportunit&#224; per Lead' ,
	'LBL_LEAD_SOURCE_OTHER' => 'Altro' ,
	'LBL_LEAD_SOURCES' => 'Origini Lead:' ,
	'LBL_MODULE_NAME' => 'Grafici' ,
	'LBL_MODULE_TITLE' => 'Grafici: Home' ,
	'LBL_MONTH_BY_OUTCOME_DESC' => 'Mostra gli importi cumulativi delle opportunit&#224; per mese, per ricavo, per gli utenti selezionati, ove la data di chiusura rientra nell&#39;arco di tempo specificato. Il ricavo si basa sullo stadio di vendita Chiuso Vinto, Chiuso Perso o qualsiasi altro stadio.' ,
	'LBL_NUMBER_OF_OPPS' => 'Numero di Opportunit&#224;' ,
	'LBL_OPP_SIZE' => 'Dimensioni opportunit&#224; in' ,
	'LBL_OPP_THOUSANDS' => 'K' ,
	'LBL_OPPS_IN_LEAD_SOURCE' => 'opportunit&#224; dove il lead &#232;' ,
	'LBL_OPPS_IN_STAGE' => 'dove lo stadio di vendita &#232;' ,
	'LBL_OPPS_OUTCOME' => 'dove il ricavo &#232;' ,
	'LBL_OPPS_WORTH' => 'valore delle opportunit&#224;' ,
	'LBL_PIPELINE_FORM_TITLE_DESC' => 'Mostra gli importi cumulativi per  gli stadi di vendita selezionati, per le tue opportunit&#224; dove la data di chiusura rientra nell&#39;arco di tempo specificato.' ,
	'LBL_CAMPAIGN_ROI_TITLE_DESC' => 'Mostra la risposta della campagna in base al ritorno dell&#39;investimento' ,
	'LBL_REFRESH' => 'Aggiorna' ,
	'LBL_ROLLOVER_DETAILS' => 'Passa sopra le barre per i dettagli' ,
	'LBL_ROLLOVER_WEDGE_DETAILS' => 'Passa sopra gli spicchi per i dettagli' ,
	'LBL_SALES_STAGE_FORM_DESC' => 'Mostra gli importi cumulativi delle opportunit&#224; per gli stadi di vendita selezionati, per gli utenti selezionati dove la data di chiusura rientra nell&#39;arco di tempo specificato.' ,
	'LBL_SALES_STAGE_FORM_TITLE' => 'Filtro per Stadio di Vendita' ,
	'LBL_SALES_STAGES' => 'Stadio di Vendita:' ,
	'LBL_TOTAL_PIPELINE' => 'Il filtro totale &#232;' ,
	'LBL_USERS' => 'Utenti:' ,
	'LBL_YEAR_BY_OUTCOME' => 'Filtro per Mese e Ricavo' ,
	'LBL_YEAR' => 'Anno:' ,
	'LNK_NEW_ACCOUNT' => 'Nuova Azienda' ,
	'LNK_NEW_CALL' => 'Pianifica Chiamata' ,
	'LNK_NEW_CASE' => 'Nuovo Ticket' ,
	'LNK_NEW_CONTACT' => 'Nuovo Contatto' ,
	'LNK_NEW_ISSUE' => 'Segnala Errore' ,
	'LNK_NEW_LEAD' => 'Nuovo Lead' ,
	'LNK_NEW_MEETING' => 'Pianifica Riunione' ,
	'LNK_NEW_NOTE' => 'Nuova Nota/Allegato' ,
	'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunit&#224;' ,
	'LNK_NEW_QUOTE' => 'Nuova Offerta' ,
	'LNK_NEW_TASK' => 'Nuovo compito' ,
	'NTC_NO_LEGENDS' => 'Nessuno' ,
	'LBL_TITLE' => 'Titolo:' ,
	'LBL_MY_MODULES_USED_SIZE' => 'Numero di accessi' ,

);


 


?>