<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:43 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Cronologia' ,
	'LBL_MODULE_TITLE' => 'Cronologia: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Ricerca Cronologia' ,
	'LBL_LIST_FORM_TITLE' => 'Cronologia' ,
	'LBL_LIST_SUBJECT' => 'Oggetto' ,
	'LBL_LIST_CONTACT' => 'Contatto' ,
	'LBL_LIST_RELATED_TO' => 'Collegato a' ,
	'LBL_LIST_DATE' => 'Data' ,
	'LBL_LIST_TIME' => 'Ora Inizio' ,
	'LBL_LIST_CLOSE' => 'Chiudi' ,
	'LBL_SUBJECT' => 'Oggetto:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_LOCATION' => 'Posizione:' ,
	'LBL_DATE_TIME' => 'Data & Ora Inizio:' ,
	'LBL_DATE' => 'Data Inizio:' ,
	'LBL_TIME' => 'Ora Inizio:' ,
	'LBL_DURATION' => 'Durata:' ,
	'LBL_HOURS_MINS' => '(ore/minuti)' ,
	'LBL_CONTACT_NAME' => 'Nome Contatto:' ,
	'LBL_MEETING' => 'Riunione:' ,
	'LBL_DESCRIPTION_INFORMATION' => 'Informazioni Descrizione' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_COLON' => ':' ,
	'LBL_DEFAULT_STATUS' => 'Pianificato' ,
	'LNK_NEW_CALL' => 'Pianifica Chiamata' ,
	'LNK_NEW_MEETING' => 'Pianifica Riunione' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'LNK_NEW_NOTE' => 'Nuova Nota o Allegato' ,
	'LNK_NEW_EMAIL' => 'Archivia Email' ,
	'LNK_CALL_LIST' => 'Chiamate' ,
	'LNK_MEETING_LIST' => 'Riunioni' ,
	'LNK_TASK_LIST' => 'Compiti' ,
	'LNK_NOTE_LIST' => 'Note' ,
	'LNK_EMAIL_LIST' => 'Emails' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'NTC_REMOVE_INVITEE' => 'Sicuro di voler rimuovere gli invitati dalla riunione ?' ,
	'LBL_INVITEE' => 'Invitati' ,
	'LBL_LIST_DIRECTION' => 'Direzione' ,
	'LBL_DIRECTION' => 'Direzione' ,
	'LNK_NEW_APPOINTMENT' => 'Nuovo Appuntamento' ,
	'LNK_VIEW_CALENDAR' => 'Oggi' ,
	'LBL_OPEN_ACTIVITIES' => 'Attivit&#224; aperte' ,
	'LBL_HISTORY' => 'Cronologia' ,
	'LBL_UPCOMING' => 'I miei prossimi Appuntamenti' ,
	'LBL_TODAY' => 'attraverso' ,
	'LBL_NEW_TASK_BUTTON_TITLE' => 'Nuovo Compito [Alt+N]' ,
	'LBL_NEW_TASK_BUTTON_KEY' => 'N' ,
	'LBL_NEW_TASK_BUTTON_LABEL' => 'Nuovo Compito' ,
	'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Nuova Riunione [Alt+M]' ,
	'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M' ,
	'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Pianifica Riunione' ,
	'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Pianifica Chiamata [Alt+C]' ,
	'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C' ,
	'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Pianifica Chiamata' ,
	'LBL_NEW_NOTE_BUTTON_TITLE' => 'Nuova Nota o Allegato [Alt+T]' ,
	'LBL_NEW_NOTE_BUTTON_KEY' => 'T' ,
	'LBL_NEW_NOTE_BUTTON_LABEL' => 'Nuova Nota o Allegato' ,
	'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archivia Email [Alt+K]' ,
	'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K' ,
	'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Archivia Email' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_LIST_DUE_DATE' => 'Data Scadenza' ,
	'LBL_LIST_LAST_MODIFIED' => 'Ultima Modifica' ,
	'NTC_NONE_SCHEDULED' => 'Niente di pianificato.' ,
	'appointment_filter_dom' => array (
			'today' => 'oggi' ,
			'tomorrow' => 'domani' ,
			'this Saturday' => 'questa settimana' ,
			'next Saturday' => 'la prossima settimana' ,
			'last this_month' => 'questo mese' ,
			'last next_month' => 'il mese prossimo' ,
	),
	'LNK_IMPORT_NOTES' => 'Importa Note' ,
	'NTC_NONE' => 'Nessuno' ,
	'LBL_ACCEPT_THIS' => 'Accetti?' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Cronologia' ,

);


 


?>