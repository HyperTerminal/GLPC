<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 18:42 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Aziende' ,
	'LBL_MODULE_TITLE' => 'Aziende: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Azienda' ,
	'LBL_LIST_FORM_TITLE' => 'Elenco Aziende' ,
	'LBL_NEW_FORM_TITLE' => 'Nuova Azienda' ,
	'LNK_NEW_CONTACT' => 'Nuovo Contatto' ,
	'LNK_NEW_ACCOUNT' => 'Nuova Azienda' ,
	'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunit&#224;' ,
	'LNK_NEW_CASE' => 'Nuovo Ticket Supporto' ,
	'LNK_NEW_NOTE' => 'Nuova Nota' ,
	'LNK_NEW_CALL' => 'Nuova Chiamata' ,
	'LNK_NEW_EMAIL' => 'Nuova Email' ,
	'LNK_NEW_MEETING' => 'Nuova Riunione' ,
	'LNK_NEW_TASK' => 'Nuovo Compito' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,

);


 


?>