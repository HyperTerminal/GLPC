<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 19:10 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Progetto' ,
	'LBL_MODULE_TITLE' => 'Progetti: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Progetto' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Progetti' ,
	'LBL_HISTORY_TITLE' => 'Cronologia' ,
	'LBL_ID' => 'Codice:' ,
	'LBL_DATE_ENTERED' => 'Data Inserimento:' ,
	'LBL_DATE_MODIFIED' => 'Data Modifica:' ,
	'LBL_ASSIGNED_USER_ID' => 'Assegnato A:' ,
	'LBL_ASSIGNED_USER_NAME' => 'Assegnato a:' ,
	'LBL_MODIFIED_USER_ID' => 'Cod. Utente Modificato:' ,
	'LBL_CREATED_BY' => 'Creato Da:' ,
	'LBL_TEAM_ID' => '' ,
	'LBL_NAME' => 'Nome:' ,
	'LBL_PDF_PROJECT_NAME' => 'Nome Progetto:' ,
	'LBL_DESCRIPTION' => 'Descrizione:' ,
	'LBL_DELETED' => 'Cancellato:' ,
	'LBL_DATE' => 'Data:' ,
	'LBL_DATE_START' => 'Data Inizio:' ,
	'LBL_DATE_END' => 'Data Fine:' ,
	'LBL_PRIORITY' => 'Priorit&#224;:' ,
	'LBL_STATUS' => 'Stato:' ,
	'LBL_MY_PROJECTS' => 'I Miei Progetti' ,
	'LBL_MY_PROJECT_TASKS' => 'I Miei Compiti di progetto' ,
	'LBL_TOTAL_ESTIMATED_EFFORT' => 'Totale Sforzo Stimato (ore):' ,
	'LBL_TOTAL_ACTUAL_EFFORT' => 'Totale Sforzo Attuale (ore):' ,
	'LBL_LIST_NAME' => 'Nome' ,
	'LBL_LIST_DAYS' => 'giorni' ,
	'LBL_LIST_ASSIGNED_USER_ID' => 'Assegnato A' ,
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Totale Sforzo Stimato (ore)' ,
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Totale Sforzo Attuale (ore)' ,
	'LBL_LIST_UPCOMING_TASKS' => 'Prossimi Compiti (1 settimana)' ,
	'LBL_LIST_OVERDUE_TASKS' => 'Compiti in Arretrato' ,
	'LBL_LIST_OPEN_CASES' => 'Ticket Aperti' ,
	'LBL_LIST_END_DATE' => 'Data Fine' ,
	'LBL_LIST_TEAM_ID' => 'Team' ,
	'LBL_PROJECT_SUBPANEL_TITLE' => 'Progetti' ,
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Compiti Progetto' ,
	'LBL_CONTACT_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Aziende' ,
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Opportunit&#224;' ,
	'LBL_QUOTE_SUBPANEL_TITLE' => 'Offerte' ,
	'LBL_NEW_FORM_TITLE' => 'Nuovo Progetto' ,
	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Sicuro di voler rimuovere questo contatto dal progetto ?' ,
	'LNK_NEW_PROJECT' => 'Nuovo Progetto' ,
	'LNK_PROJECT_LIST' => 'Lista Progetti' ,
	'LNK_NEW_PROJECT_TASK' => 'Nuovo Compito Progetto' ,
	'LNK_PROJECT_TASK_LIST' => 'Compiti Progetto' ,
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Progetti' ,
	'LBL_ACTIVITIES_TITLE' => 'Attivit&#224;' ,
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Attivit&#224;' ,
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Cronologia' ,
	'LBL_QUICK_NEW_PROJECT' => 'Nuovo Progetto' ,
	'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Compiti del Progetto' ,
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatti' ,
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Aziende' ,
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Opportunit&#224;' ,
	'LBL_CASES_SUBPANEL_TITLE' => 'Tickets' ,
	'LBL_BUGS_SUBPANEL_TITLE' => 'Errori' ,
	'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Prodottti' ,
	'LBL_TASK_ID' => 'Codice' ,
	'LBL_TASK_NAME' => 'Nome Compito' ,
	'LBL_DURATION' => 'Durata' ,
	'LBL_ACTUAL_DURATION' => 'Durata Attuale' ,
	'LBL_START' => 'Inizio' ,
	'LBL_FINISH' => 'Fine' ,
	'LBL_PREDECESSORS' => 'Predecessori' ,
	'LBL_PERCENT_COMPLETE' => '% Completata' ,
	'LBL_MORE' => 'Ancora...' ,
	'LBL_PERCENT_BUSY' => '% Occupata' ,
	'LBL_TASK_ID_WIDGET' => 'codice' ,
	'LBL_TASK_NAME_WIDGET' => 'descrizione' ,
	'LBL_DURATION_WIDGET' => 'durata' ,
	'LBL_START_WIDGET' => 'data_inizio' ,
	'LBL_FINISH_WIDGET' => 'data_fine' ,
	'LBL_PREDECESSORS_WIDGET' => 'predecessori_' ,
	'LBL_PERCENT_COMPLETE_WIDGET' => 'percentuale_completata' ,
	'LBL_EDIT_PROJECT_TASKS_TITLE' => 'Modifica Compiti Progetto' ,
	'LBL_OPPORTUNITIES' => 'Opportunit&#224;' ,
	'LBL_LAST_WEEK' => 'Indietro' ,
	'LBL_NEXT_WEEK' => 'Avanti' ,
	'LBL_PROJECTRESOURCES_SUBPANEL_TITLE' => 'Risorse del Progetto' ,
	'LBL_PROJECTTASK_SUBPANEL_TITLE' => 'Attivit&#224; del Progetto' ,
	'LBL_HOLIDAYS_SUBPANEL_TITLE' => 'Vacanze' ,

);


 


?>