<?php
/*********************************************************************************
 * The contents of this file are subject to the GPL License Version 2.
 * You may obtain a copy of the License at http://www.opensource.org/licenses/
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the Italian language pack for the base application. 
 * Authors(s):  Witcom s.r.l., http://www.witcom.com/ 
 * Contributor(s): _________________________________________________
 *
 * Eventuali aggiornamenti sono disponibili sul sito http://www.witcom.com 
 * Per personalizzazioni, integrazioni e segnalazioni scrivete a crm@witcom.com 
 ********************************************************************************/
 
 // 2009.12.17 20:15 
$mod_strings = array(
	'LBL_MODULE_NAME' => 'Releases' ,
	'LBL_MODULE_TITLE' => 'Releases: Home' ,
	'LBL_SEARCH_FORM_TITLE' => 'Cerca Release' ,
	'LBL_LIST_FORM_TITLE' => 'Lista Release' ,
	'LBL_NEW_FORM_TITLE' => 'Nuova Release' ,
	'LBL_RELEASE' => 'Release:' ,
	'LBL_LIST_NAME' => 'Release' ,
	'LBL_NAME' => 'Versione Release:' ,
	'LBL_LIST_LIST_ORDER' => 'Ordinamento' ,
	'LBL_LIST_ORDER' => 'Ordinamento:' ,
	'LBL_LIST_STATUS' => 'Stato' ,
	'LBL_STATUS' => 'Stato:' ,
	'LNK_NEW_RELEASE' => 'Lista Release' ,
	'NTC_DELETE_CONFIRMATION' => 'Sicuro di voler eliminare questo dato ?' ,
	'ERR_DELETE_RECORD' => 'Per l&#39;eliminazione &#232; necessario fornire l&#39;identificativo del record.' ,
	'NTC_STATUS' => 'Imposta lo Stato a Non Attiva per rimuovere questa release dalla lista valori' ,
	'NTC_LIST_ORDER' => 'Imposta l&#39;ordinamento con cui questa release apparir&#224; nelle liste valori Release' ,
	'release_status_dom' => array (
			'Active' => 'Attiva' ,
			'Inactive' => 'Non Attiva' ,
	),

);


 


?>