<?PHP 
$manifest = array( 
	'name' => 'Italiano - Witcom',
	'description' => 'Traduzione Italiana per SugarCRM a cura di <a href="http://www.witcom.com" target="_blank">WITCOM SRL</a>',
	'type' => 'langpack',
	'is_uninstallable' => true,
	'version' => '5.5.0',
	'acceptable_sugar_flavors' => array(0=>'CE'),
	'published_date' => '2010-01-04',
	'author' => ' Witcom srl  ',
	'acceptable_sugar_versions' => array (
					'exact_matches' => array (),
					'regex_matches' => array ('5\.5\.0'),
    			),
	'icon' => 'include/images/flag-it_IT.png');

$installdefs = array(
	'id'=> 'it_it',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'),
	array('from'=> '<basepath>/jscalendar','to'=> 'jscalendar'),
	)
);
?>
