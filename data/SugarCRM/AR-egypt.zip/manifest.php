<?PHP 
$manifest = array( 
	'name' => 'Arabic Egypt',
	'description' => 'Translation For SugarCRM',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '4.5.0d',
	'acceptable_sugar_flavors' => array (0 => 'OS'),
	'published_date' => '17/12/2006',
	'author' => 'ICT Trust Fund',
	'acceptable_sugar_versions' => array ( "exact_matches" => array (), "regex_matches" => array (  0=>"4\\.5\\.*", 1 => "4\\.2\\.*" , 2 => "4\\.0\\.*" , 3=> "3\\.5\\.*" )),
);

$installdefs = array(
	'id'=> 'ar_EG',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>
