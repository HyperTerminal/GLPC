<?php
$manifest = array(
	'acceptable_sugar_versions' => array (
		'exact_matches' => array (
			'6.5.0'
		),
		'regex_matches' => array (
      			0 => '6\\.5\\.[0-2]$',
		),
	),

	'name' => 'Castellano',

	'description' => 'Paquete de idioma Castellano (Latinoamérica)',

	'author' => 'Carlos Espinosa',

	'published_date' => '2012-6-26',

	'version' => '6.5.0',

	'type' => 'langpack',

	'icon' => '',

	'is_uninstallable' => TRUE
);
?>
