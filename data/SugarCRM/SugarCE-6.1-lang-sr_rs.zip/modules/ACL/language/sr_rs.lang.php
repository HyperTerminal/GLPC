<?php

$mod_strings = array(
'LBL_ALLOW_ALL' => 'Svi',
'LBL_ALLOW_NONE' => 'Nijedna',
'LBL_ALLOW_OWNER' => 'Vlasnik',
'LBL_ROLE' => 'Uloga',
'LBL_NAME' => 'Ime',
'LBL_DESCRIPTION' => 'Opis',
'LIST_ROLES' => 'Izlistaj uloge',
'LBL_USERS_SUBPANEL_TITLE' => 'Korisnici',
'LIST_ROLES_BY_USER' => 'Lista uloga po korisniku',
'LBL_ROLES_SUBPANEL_TITLE' => 'Korisničke uloge',
'LBL_SEARCH_FORM_TITLE' => 'Pretraga',
'LBL_NO_ACCESS' => 'Nemate pristup ovom delu. Kontaktirajte administratora vašeg sajta kako bi dobili mogućnost pristupa.',
'LBL_ADDING' => 'Dodavanje za ',

);




?>