<?php

$mod_strings = array(
'LBL_ACCESS_ALL' => 'Svi',
'LBL_ACCESS_NONE' => 'Nijedna',
'LBL_ACCESS_OWNER' => 'Vlasnik',
'LBL_ACCESS_NORMAL' => 'Normalno',
'LBL_ACCESS_ADMIN' => 'Administracija',
'LBL_ACCESS_ENABLED' => 'Omogućeno',
'LBL_ACCESS_DISABLED' => 'Onemogućeno',
'LBL_ACCESS_DEV' => 'Developer',
'LBL_ACCESS_ADMIN_DEV' => 'Admin & Developer',
'LBL_NAME' => 'Ime',
'LBL_DESCRIPTION' => 'Opis',
'LIST_ROLES' => 'Lista uloga',
'LBL_USERS_SUBPANEL_TITLE' => 'Korisnici',
'LIST_ROLES_BY_USER' => 'Lista uloga po korisniku',
'LBL_ROLES_SUBPANEL_TITLE' => 'Uloge korisnika',
'LBL_SEARCH_FORM_TITLE' => 'Pretraga',
'LBL_ACTION_VIEW' => 'Pregled',
'LBL_ACTION_EDIT' => 'Izmeni',
'LBL_ACTION_DELETE' => 'Obriši',
'LBL_ACTION_IMPORT' => 'Uvoz',
'LBL_ACTION_EXPORT' => 'Izvoz',
'LBL_ACTION_LIST' => 'Lista',
'LBL_ACTION_ACCESS' => 'Pristup',
'LBL_ACTION_ADMIN' => 'Tip pristupa',
'LBL_ACCESS_DEFAULT' => 'Nije postavljeno',

);




?>