<?php

$mod_strings = array(
'LBL_YOURS' => 'Vaši',
'LBL_IN_DATABASE' => 'U bazi podataka',
'LBL_CONFLICT_EXISTS' => 'Postoji konflikt za - ',
'LBL_ACCEPT_DATABASE' => 'Pristupite bazi',
'LBL_ACCEPT_YOURS' => 'Prihvatite Vaš',
'LBL_RECORDS_MATCH' => 'Zapisi koji se podudaraju',
'LBL_NO_LOCKED_OBJECTS' => 'Nema zaključanih objekata',

);




?>