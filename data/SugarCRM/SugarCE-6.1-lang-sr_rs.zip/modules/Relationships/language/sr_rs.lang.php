<?php

$mod_strings = array(
'LBL_ID' => 'ID broj veze',
'LBL_RELATIONSHIP_NAME' => 'Ime veze',
'LBL_LHS_MODULE' => 'Ime modula sa leve strane',
'LBL_LHS_TABLE' => 'Ime tabele se leve strane',
'LBL_LHS_KEY' => 'Ime ključa sa leve strane',
'LBL_RHS_MODULE' => 'Ime modula sa desne strane',
'LBL_RHS_TABLE' => 'Ime tabele sa desne strane',
'LBL_RHS_KEY' => 'Ime ključa sa desne strane',
'LBL_JOIN_TABLE' => 'Poveži ime tabele',
'LBL_JOIN_KEY_LHS' => 'Poveži ključ sa levom stranom',
'LBL_JOIN_KEY_RHS' => 'Poveži ključ sa desnom stranom',
'LBL_RELATIONSHIP_TYPE' => 'Tip veze',
'LBL_RELATIONSHIP_ROLE_COLUMN' => 'Ime kolone povezanost uloga',
'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE' => 'Vrednost kolone povezanost uloga',
'LBL_REVERSE' => 'Obratno',
'LBL_DELETED' => 'Obrisan',

);




?>