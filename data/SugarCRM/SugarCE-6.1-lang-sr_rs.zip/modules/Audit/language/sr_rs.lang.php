<?php

$mod_strings = array(
'LBL_FIELD_NAME' => 'Polje',
'LBL_OLD_NAME' => 'Stara vrednost',
'LBL_NEW_VALUE' => 'Nova vrednost',
'LBL_CREATED_BY' => 'Promenio',
'LBL_LIST_DATE' => 'Promeni datum',
'LBL_AUDITED_FIELDS' => 'Kontrolisana polja u ovom modulu: ',
'LBL_NO_AUDITED_FIELDS_TEXT' => 'U ovom modulu nema polja koja su kontrolisana',
'LBL_CHANGE_LOG' => 'Dnevnik promena',

);




?>