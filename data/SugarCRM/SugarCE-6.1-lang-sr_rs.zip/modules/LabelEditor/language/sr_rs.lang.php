<?php

$mod_strings = array(
'LBL_MODULE_NAME' => 'Editor naziva',
'LBL_KEY' => 'Ključ:',
'LBL_VALUE' => 'Količina:',

);




?>