<?php

$mod_strings = array(
'LBL_MODULE_NAME' => 'Uloge',
'LBL_MODULE_TITLE' => 'Uloge: Početna strana',
'LBL_ROLE' => 'Svrha',
'LBL_NAME' => 'Ime',
'LBL_DESCRIPTION' => 'Opis',
'LIST_ROLES' => 'Lista uloga',
'LBL_USERS_SUBPANEL_TITLE' => 'Korisnici',
'LIST_ROLES_BY_USER' => 'Lista uloga po korisniku',
'LBL_LIST_FORM_TITLE' => 'Uloge',
'LBL_ROLES_SUBPANEL_TITLE' => 'Uloge korisnika',
'LBL_SEARCH_FORM_TITLE' => 'Pretraga',
'LBL_CREATE_ROLE' => 'Kreiraj ulogu',
'LBL_EDIT_VIEW_DIRECTIONS' => 'Kliknite dva puta na ćeliju da bi promenili vrednost.',
'LBL_ACCESS_DEFAULT' => 'Nije postavljeno',
'LBL_ALL' => 'Svi',
'LBL_DUPLICATE_OF' => 'Duplikat ',

);




?>