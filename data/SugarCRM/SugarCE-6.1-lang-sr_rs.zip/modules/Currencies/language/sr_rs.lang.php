<?php

$mod_strings = array(
'LBL_MODULE_NAME' => 'Valute',
'LBL_LIST_FORM_TITLE' => 'Valute',
'LBL_CURRENCY' => 'Valuta',
'LBL_ADD' => 'Dodaj',
'LBL_MERGE' => 'Spoji',
'LBL_MERGE_TXT' => 'Molim, izaberite valute koje želite da preslikate u izabranu valutu. Ovo će obrisati sve valute koje su označene i ponovo primeniti za svaku vrednost povezanu sa njima izabranu valutu.',
'LBL_US_DOLLAR' => 'Američki dolar',
'LBL_DELETE' => 'Obriši',
'LBL_LIST_SYMBOL' => 'Simbol valute',
'LBL_LIST_NAME' => 'Ime valute',
'LBL_LIST_ISO4217' => 'ISO 4217 kod',
'LBL_LIST_ISO4217_HELP' => 'Unesite ISO 4217 šifru od tri slova koja definiše ime i simbol valute.',
'LBL_UPDATE' => 'Ažuriraj',
'LBL_LIST_RATE' => 'Stopa konverzije',
'LBL_LIST_RATE_HELP' => 'Stopa konverzije od 0.5 za evro znači da 10 USD = 5 EVRO',
'LBL_LIST_STATUS' => 'Status',
'LNK_NEW_CONTACT' => 'Novi kontakt',
'LNK_NEW_ACCOUNT' => 'Nova kompanija',
'LNK_NEW_OPPORTUNITY' => 'Nova planirana prodaja',
'LNK_NEW_CASE' => 'Novi slučaj',
'LNK_NEW_NOTE' => 'Kreiraj belešku ili dodatak',
'LNK_NEW_CALL' => 'Novi poziv',
'LNK_NEW_EMAIL' => 'Nova elektronska poruka',
'LNK_NEW_MEETING' => 'Novi sastanak',
'LNK_NEW_TASK' => 'Kreiraj zadatak',
'NTC_DELETE_CONFIRMATION' => 'Da li ste sigurni da želite da obrišete ovaj zapis? Svaki zapis koji koristi ovu valutu će biti konvertovan podrazumevanu valutu sistema kada mu se pristupi. Možda je bolje da samo stavite status na \"Neaktivno\".',
'LBL_BELOW_MIN' => 'Rata ',
'currency_status_dom' => array (
'Active' => 'Aktivan',
'Inactive' => 'Neaktivan',
),

);




?>