<?php

$mod_strings = array(
'ShowActiveUsers' => 'Prikaži aktivne korisnike',
'ShowLastModifiedRecords' => 'Poslednjih 10 izmenjenih zapisa',
'ShowTopUser' => 'Glavni korisnik',
'ShowMyModuleUsage' => 'Moji podaci o korišćenju modula',
'ShowMyWeeklyActivities' => 'Moje sedmične aktivnosti',
'ShowTop3ModulesUsed' => 'Moja 3 najviše korišćena modula',
'ShowLoggedInUserCount' => 'Broj aktivnih korisnika',
'ShowMyCumulativeLoggedInTime' => 'Kumulativno vreme moje prijave (ove sedmice)',
'ShowUsersCumulativeLoggedInTime' => 'Kumulativno vreme prijave korisnika ( ove sedmice)',
'action' => 'Radnja',
'active_users' => 'Broj aktivnih korisnika',
'date_modified' => 'Datum poslednje akcije',
'different_modules_accessed' => 'Broj modula kojima je pristupljeno',
'first_name' => 'Ime',
'item_id' => 'ID broj',
'item_summary' => 'Ime',
'last_action' => 'Datum/vreme poslednje akcije',
'last_name' => 'Prezime',
'module_name' => 'Ime modula',
'records_modified' => 'Ukupno promenjenih zapisa',
'top_module' => 'Moduli kojim je najčešće pristupano',
'total_count' => 'Ukupan broj pregled astrane',
'total_login_time' => 'Vreme (hh:mm:ss)',
'user_name' => 'Korisničko ime',
'users' => 'Korisnici',
'LBL_ENABLE' => 'Omogućeno',
'LBL_MODULE_NAME_TITLE' => 'Sistemi za praćenje',
'LBL_MODULE_NAME' => 'Sistemi za praćenje',
'LBL_TRACKER_SETTINGS' => 'Podešavanja sistema za praćenje',
'LBL_TRACKER_QUERIES_DESC' => 'Upiti za sisteme praćenja',
'LBL_TRACKER_QUERIES_HELP' => 'Pratite SQL izraze kada je opcija \"Upiši spore upite\" omogućena i kada izvršenje upita prevaziđe vrednost \"Vremenski prag sporog upita\"  ',
'LBL_TRACKER_PERF_DESC' => 'Performanse sistema za praćenje',
'LBL_TRACKER_PERF_HELP' => 'Praćenje DB ciklusa, pristupa fajlovima i iskorišćenosti memorije',
'LBL_TRACKER_SESSIONS_DESC' => 'Sesije sistema za praćenje',
'LBL_TRACKER_SESSIONS_HELP' => 'Prati aktivne korisnike i korisničke informacije sesije',
'LBL_TRACKER_DESC' => 'Akcije sistema za praćenje',
'LBL_TRACKER_HELP' => 'Prati preglede korisničke strane (module i zapise kojima je pristupljeno) i čuvanje zapisa',
'LBL_TRACKER_PRUNE_INTERVAL' => 'Broj dana koliko će se čuvati podaci sistema za praćenje kada Planer očisti tabele',
'LBL_TRACKER_PRUNE_RANGE' => 'Broj dana',

);




?>