<?php

$mod_strings = array(
'LBL_MODULE_NAME' => 'Kalendar',
'LBL_MODULE_TITLE' => 'Kalendar',
'LBL_MODULE_ACTION' => 'Pregled',
'LNK_NEW_CALL' => 'Evidentiraj poziv',
'LNK_NEW_MEETING' => 'Zakaži sastanak',
'LNK_NEW_APPOINTMENT' => 'Kreiraj susret',
'LNK_NEW_TASK' => 'Kreiraj zadatak',
'LNK_CALL_LIST' => 'Pozivi',
'LNK_MEETING_LIST' => 'Sastanci',
'LNK_TASK_LIST' => 'Zadaci',
'LNK_VIEW_CALENDAR' => 'Danas',
'LNK_IMPORT_CALLS' => 'Uvezi pozive',
'LNK_IMPORT_MEETINGS' => 'Uvezi sastanke',
'LNK_IMPORT_TASKS' => 'Uvezi zadatke',
'LBL_MONTH' => 'Mesec',
'LBL_DAY' => 'Dan',
'LBL_YEAR' => 'Godina',
'LBL_WEEK' => 'Nedelja',
'LBL_PREVIOUS_MONTH' => 'Prethodni mesec',
'LBL_PREVIOUS_DAY' => 'Prethodni dan',
'LBL_PREVIOUS_YEAR' => 'Prethodna godina',
'LBL_PREVIOUS_WEEK' => 'Prethodna nedelja',
'LBL_NEXT_MONTH' => 'Sledeći mesec',
'LBL_NEXT_DAY' => 'Sledeći dan',
'LBL_NEXT_YEAR' => 'Sledeća godina',
'LBL_NEXT_WEEK' => 'Sledeća nedelja',
'LBL_AM' => 'Pre podne',
'LBL_PM' => 'Po podne',
'LBL_SCHEDULED' => 'Zakazan',
'LBL_BUSY' => 'Zauzeto',
'LBL_CONFLICT' => 'Sukob',
'LBL_USER_CALENDARS' => 'Kalendari korisnika',
'LBL_SHARED' => 'Zajednički',
'LBL_PREVIOUS_SHARED' => 'Prethodni',
'LBL_NEXT_SHARED' => 'Sledeći',
'LBL_SHARED_CAL_TITLE' => 'Zajednički kalendar',
'LBL_USERS' => 'Korisnik',
'LBL_REFRESH' => 'Osveži',
'LBL_EDIT' => 'Izmeni',
'LBL_SELECT_USERS' => 'Odaberi korisnike za prikaz kalendara',
'LBL_FILTER_BY_TEAM' => 'Filtriraj listu korisnika po timovima:',
'LBL_ASSIGNED_TO_NAME' => 'Dodeljen',
'LBL_DATE' => 'Datum i vreme početka',

);




?>