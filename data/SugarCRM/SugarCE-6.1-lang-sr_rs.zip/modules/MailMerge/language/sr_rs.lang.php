<?php

$mod_strings = array(
'LBL_STEP_1' => 'Korak 1: Odaberite modul i šablon',
'LBL_MAILMERGE_MODULE' => 'Izaberi modul: ',
'LBL_MAILMERGE_SELECTED_MODULE' => 'Izabrani modul: ',
'LBL_MAILMERGE_TEMPLATES' => 'Izabrani šablon: ',
'LBL_STEP_2' => 'Korak 2: Odaberite objekte za spajanje',
'LBL_MAILMERGE_OBJECTS' => 'Izaberi objekte: ',
'LBL_STEP_3' => 'Postavi udruživanje kontakata',
'LBL_STEP_4' => 'Pregledaj i završi',
'LBL_SELECTED_MODULE' => 'Izabrani modul: ',
'LBL_SELECTED_TEMPLATE' => 'Izabrani šablon: ',
'LBL_SELECTED_ITEMS' => 'Izabrani artikli: ',
'LBL_STEP_5' => 'Završi spajanje pošte',
'LBL_MERGED_FILE' => 'Spojeni fajlovi: ',
'LNK_NEW_MAILMERGE' => 'Početak spajanja pošte',
'LNK_UPLOAD_TEMPLATE' => 'Uvezi šablon',
'LBL_DOC_NAME' => 'Ime dokumenta:',
'LBL_FILENAME' => 'Ime fajla:',
'LBL_DOC_VERSION' => 'Revizija:',
'LBL_DOC_DESCRIPTION' => 'Opis:',
'LBL_LIST_NAME' => 'Ime',
'LBL_LIST_RELATIONSHIP' => 'Postavi veze kontakata',
'LBL_FINISH' => 'Počni spajanje',
'LBL_NEXT' => 'Sledeći >',
'LBL_BACK' => '< Nazad',
'LBL_START' => 'Za nastavak rada kliknite ovde',
'LBL_TEMPLATE_NOTICE' => 'Šabloni su dokumenti Microsoft Word-a koji sadrže spojena polja koji su uvezeni i sačuvani u modulu dokumenta.',
'LBL_CONTAINS_CONTACT_INFO' => 'Izaberi šablone koji sadrže povezane ',
'LBL_ADDIN_NOTICE' => 'Ovo zahteva instaliranje Sugar dodatka za spajanje elektronske pošte u Microsoft Word.',
'LBL_BROWSER_NOTICE' => 'Morate da pokrenete IE 6.0 ili veći da bi uradili stvarno spajanje.',

);




?>