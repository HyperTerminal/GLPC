<?php

$mod_strings = array(
'LBL_EMAIL_ADDRESS_ID' => 'ID broj',
'LBL_EMAIL_ADDRESS' => 'E-adresa',
'LBL_EMAIL_ADDRESS_CAPS' => 'Email Address caps',
'LBL_INVALID_EMAIL' => 'Invalid Email',
'LBL_OPT_OUT' => 'Iskljucenje opcije',
'LBL_DATE_CREATE' => 'Date Create',
'LBL_DATE_MODIFIED' => 'Datum izmene',
'LBL_DELETED' => 'Obrisi',

);




?>