<?php

$mod_strings = array(
'LBL_ID' => 'ID broj',
'LBL_TRACKER_KEY' => 'Ključ sistema za praćenje',
'LBL_TRACKER_URL' => 'URL sistema za praćenje',
'LBL_TRACKER_NAME' => 'Ime sistema za praćenje',
'LBL_CAMPAIGN_ID' => 'ID broj kampanje',
'LBL_DATE_ENTERED' => 'Datum unosa',
'LBL_DATE_MODIFIED' => 'Datum izmene',
'LBL_MODIFIED_USER_ID' => 'Promenjeni ID broj korisnika',
'LBL_CREATED_BY' => 'Autor',
'LBL_DELETED' => 'Obrisan',
'LBL_CAMPAIGN' => 'Kampanja',
'LBL_OPTOUT' => 'Isključena opcija',
'LBL_MODULE_NAME' => 'Sistem za praćenje kampanje',
'LBL_EDIT_CAMPAIGN_NAME' => 'Ime kampanje:',
'LBL_EDIT_TRACKER_NAME' => 'Ime sistema za praćenje:',
'LBL_EDIT_TRACKER_URL' => 'URL sistema za praćenje:',
'LBL_SUBPANEL_TRACKER_NAME' => 'Ime',
'LBL_SUBPANEL_TRACKER_URL' => 'URL',
'LBL_SUBPANEL_TRACKER_KEY' => 'Taster',
'LBL_EDIT_MESSAGE_URL' => 'URL za poruke kampanje:',
'LBL_EDIT_TRACKER_KEY' => 'Ključ sistema za praćenje:',
'LBL_EDIT_OPT_OUT' => 'link za Isključenje opcije ?',
'LNK_CAMPAIGN_LIST' => 'Kampanje',

);




?>