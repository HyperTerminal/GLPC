<?php

$mod_strings = array(
'LBL_EXECUTE_TIME' => 'Vreme izvršavanja',

);




?>