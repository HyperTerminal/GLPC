<?php

$mod_strings = array(
'LBL_MODULE_NAME' => 'Izdanja',
'LBL_MODULE_TITLE' => 'Izdanja: Početna strana',
'LBL_SEARCH_FORM_TITLE' => 'Pretraga izdanja',
'LBL_LIST_FORM_TITLE' => 'Lista izdanja',
'LBL_NEW_FORM_TITLE' => 'Novo izdanje',
'LBL_RELEASE' => 'Izdanje:',
'LBL_LIST_NAME' => 'Izdanje',
'LBL_NAME' => 'Verzija izdanja:',
'LBL_LIST_LIST_ORDER' => 'Porudžbina',
'LBL_LIST_ORDER' => 'Porudžbina:',
'LBL_LIST_STATUS' => 'Status',
'LBL_STATUS' => 'Status:',
'LNK_NEW_RELEASE' => 'Lista izdanja',
'NTC_DELETE_CONFIRMATION' => 'Da li ste sigurni da želite da obrišete ovaj zapis?',
'ERR_DELETE_RECORD' => 'Morate navesti odgovarajući broj zapisa da bi obrisali izdanje.',
'NTC_STATUS' => 'Podesi status na Neaktivno da uklonili ovo izdanje iz padajućeg menija Liste izdanja',
'NTC_LIST_ORDER' => 'Postavi redosled po kome će se ovo izdanje prikazati u padajućoj listi Izdanja',
'release_status_dom' => array (
'Active' => 'Aktivan',
'Inactive' => 'Neaktivan',
),

);




?>