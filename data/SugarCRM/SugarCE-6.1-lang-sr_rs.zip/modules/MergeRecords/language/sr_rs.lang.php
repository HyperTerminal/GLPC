<?php

$mod_strings = array(
'LBL_MODULE_NAME' => 'Kombinovani zapisi',
'LBL_MODULE_TITLE' => 'Kombinovani zapisi: Početna strana',
'LBL_SEARCH_FORM_TITLE' => 'Pretraga kombinacija',
'LBL_LIST_FORM_TITLE' => 'Lista kombinacija',
'LBL_LBL_MERGE_RECORDS_STEP_1' => 'Korak 1: Nađi Traži zapise koje ćeš da kombinuješ sa',
'LBL_AVAIL_FIELDS' => 'Polja koja su na raspolaganju',
'LBL_FILTER_COND' => 'Uslov filtriranja',
'LBL_SELECTED_FIELDS' => 'Odabrana polja',
'LBL_MERGE_RECORDS_WITH' => 'Spoji zapise sa',
'LBL_MERGE_VALUE_OVER' => 'Spoji vrednosti preko',
'LBL_NEXT_STEP_TITLE' => 'Pređi na sledeći korak[Ctrl+N]',
'LBL_NEXT_STEP_BUTTON_KEY' => 'N',
'LBL_NEXT_STEP_BUTTON_LABEL' => 'Sledeći korak >',
'LBL_PERFORM_MERGE_BUTTON_TITLE' => 'Uradi spajanje[Ctrl+P]',
'LBL_PERFORM_MERGE_BUTTON_KEY' => 'P',
'LBL_PERFORM_MERGE_BUTTON_LABEL' => 'Uradi spajanje',
'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE' => 'Sačuvaj spojeno[Ctrl+S]',
'LBL_SAVE_MERGED_RECORD_BUTTON_KEY' => 'S',
'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL' => 'Sačuvaj spojeno',
'LBL_STEP2_FORM_TITLE' => 'Zapisi koji su nađeni da se spoje sa:',
'LBL_SELECT_ERROR' => 'Morate da napravite izbor pre nego što nastavite dalje.',
'LBL_SELECT_PRIMARY' => 'Izaberite osnovni zapis za spajanje.',
'LBL_CHANGE_PARENT' => 'Postavite kao osnovi',
'LBL_REMOVE_FROM_MERGE' => 'Ukloni',
'LBL_DIFF_COL_VALUES' => 'Kolone čija se vrednost u osnovnom redu razlikuje od vrednosti u spojenom redu:',
'LBL_SAME_COL_VALUES' => 'Kolone čija je vrednost slična kroz sve redove:',
'ERR_EXCEEDS_MAX' => 'Dozvoljeno Vam je da spojite najviše 5 zapisa. Zapisi koji prelaze limit neće biti uzeti u obzir.',
'LBL_DELETE_MESSAGE' => 'Ovom akcijom biće obrisani sledeći zapis(i):',
'LBL_PROCEED' => 'Nastavi?',
'LBL_STEP1_DIRECTIONS' => 'Pronađite moguće duplikate zapisa. Ako su mogući duplikati pronađeni, možete da izaberete zapise koje će te spojiti sa aktivnim zapisima.',

);




?>