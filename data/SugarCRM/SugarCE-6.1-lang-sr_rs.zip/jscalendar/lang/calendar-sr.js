// ** I18N

// Calendar EN language
// Author: Mihai Bazon, <mishoo@infoiasi.ro>
// Encoding: any
// Distributed under the same terms as the calendar itself.

// For translators: please use UTF-8 if possible.  We strongly believe that
// Unicode is the answer to a real internationalized world.  Also please
// include your contact information in the header, as can be seen above.

// full day names
Calendar._DN = new Array
("Nedelja",
 "Ponedeljak",
 "Utorak",
 "Sreda",
 "Četvrtak",
 "Petak",
 "Subota",
 "Nedelja");

// Please note that the following array of short day names (and the same goes
// for short month names, _SMN) isn't absolutely necessary.  We give it here
// for exemplification on how one can customize the short day names, but if
// they are simply the first N letters of the full name you can simply say:
//
//   Calendar._SDN_len = N; // short day name length
//   Calendar._SMN_len = N; // short month name length
//
// If N = 3 then this is not needed either since we assume a value of 3 if not
// present, to be compatible with translation files that were written before
// this feature.

// short day names
Calendar._SDN = new Array
("Ned",
 "Pon",
 "Uto",
 "Sre",
 "Čet",
 "Pet",
 "Sub",
 "Ned");

// full month names
Calendar._MN = new Array
("Januar",
 "Februar",
 "Mart",
 "April",
 "Maj",
 "Jun",
 "Jul",
 "Avgust",
 "Septembar",
 "Oktobar",
 "Novembar",
 "Decembar");

// short month names
Calendar._SMN = new Array
("Jan",
 "Feb",
 "Mar",
 "Apr",
 "Maj",
 "Jun",
 "Jul",
 "Avg",
 "Sep",
 "Okt",
 "Nov",
 "Dec");

// tooltips
Calendar._TT = {};
Calendar._TT["INFO"] = "O kalendaru";

Calendar._TT["ABOUT"] =
"DHTML Date/Time Selector\n" +
"(c) dynarch.com 2002-2003\n" + // don't translate this this ;-)
"Za najnoviju verziju posetite: http://dynarch.com/mishoo/calendar.epl\n" +
"Distribuira se pod GNU GPL licencom. Za više detalja pogledajte http://gnu.org/licenses/lgpl.html." +
"\n\n" +
"Biranje datuma:\n" +
"- Koristite \xab, \xbb dugmiće da biste izabrali godinu\n" +
"- Koristite " + String.fromCharCode(0x2039) + ", " + String.fromCharCode(0x203a) + " dugmiće da biste izabrali mesec\n" +
"- Držite pritisnut taster miša na neki od dugmića iznad kako biste ubrzali biranje.";
Calendar._TT["ABOUT_TIME"] = "\n\n" +
"Biranje vremena:\n" +
"- Kliknite na bilo koji deo vremena kako ga ubrzali\n" +
"- ili kliknite dok držite pritisnut Shift da biste ga usporili\n" +
"- ili kliknite i prevucite radi bržeg biranja.";

Calendar._TT["PREV_YEAR"] = "Preth. godina (pritisnite za opcije)";
Calendar._TT["PREV_MONTH"] = "Preth. mesec (pritisnite za opcije)";
Calendar._TT["GO_TODAY"] = "Idi na danas";
Calendar._TT["NEXT_MONTH"] = "Sled. mesec (pritisnite za opcije)";
Calendar._TT["NEXT_YEAR"] = "Sled. godina (pritisnite za opcije)";
Calendar._TT["SEL_DATE"] = "Izaberite datum i vreme";
Calendar._TT["DRAG_TO_MOVE"] = "Prevucite da biste pomerili";
Calendar._TT["PART_TODAY"] = " (danas)";

// the following is to inform that "%s" is to be the first day of week
// %s will be replaced with the day name.
Calendar._TT["DAY_FIRST"] = "Prvo prikazati %s";

// This may be locale-dependent.  It specifies the week-end days, as an array
// of comma-separated numbers.  The numbers are from 0 to 6: 0 means Sunday, 1
// means Monday, etc.
Calendar._TT["WEEKEND"] = "0,6";

Calendar._TT["CLOSE"] = "Uskoro";
Calendar._TT["TODAY"] = "Danas";
//Calendar._TT["TIME_PART"] = "(Shift-)Click or drag to change value";
Calendar._TT["TIME_PART"] = "Da biste izmenili prevucite mišem ili koristite strelice";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "%Y-%m-%d";
Calendar._TT["TT_DATE_FORMAT"] = "%a, %b %e";

Calendar._TT["WK"] = "nd";
Calendar._TT["TIME"] = "Vreme:";
