<?PHP

// manifest file for information regarding application of new code
$manifest = array(
    // only install on the following regex sugar versions (if empty, no check)
    'acceptable_sugar_versions' => array (
        'exact_matches' => array (),
        'regex_matches' => array (  0 => '3\\.5\\.1*' ),
    ),

        // Version for which this langpack can work
    'acceptable_sugar_flavors' =>
      array (
        0 => 'OS'
      ),

    // name of new code
    'name' => 'bg_bg language pack',

    // description of new code
   'description' => 'Bulgarian translation (bg_bg) for SugarCRM upto v3.5.1d from OIC',


    // author of new code
    'author' => 'OpenIdeasCompany www.openideascompany.com',

    // date published
    'published_date' => '2005/12/19',

    // version of code
    'version' => '3.5.1d',

    // type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',


    // icon for displaying in UI (path to graphic contained within zip package)
    //'icon' => 'include/images/flag-ru.png',

    // Uninstall is allowed
    'is_uninstallable' => TRUE,

    // File to be copied
    'copy_files' =>
            array (
                  'from_dir' => 'bg_bg',
                  'to_dir' => '',
                  'force_copy' =>
                          array (
                          ),
            ),
    );

?>