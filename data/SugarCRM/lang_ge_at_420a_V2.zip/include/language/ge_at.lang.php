<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.44 2006/04/02 10:20:55 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (

  'language_pack_name' => 'Deutsch (AT)',
  
  'moduleList' =>
  array (
    'Home' => 'Home',
    'Dashboard' => 'Statistik',
    'Contacts' => 'Kontakte',
    'Accounts' => 'Kunden',
    'Opportunities' => 'Verkaufschancen',
    'Cases' => 'Anfragen',
    'Notes' => 'Notizen',
    'Calls' => 'Anrufe',
    'Emails' => 'Emails',
    'Meetings' => 'Termine',
    'Tasks' => 'Aufgaben',
    'Calendar' => 'Kalender',
    'Leads' => 'Interessenten',
    'Activities' => 'Aktivit�ten',
    'Bugs' => 'Bug Tracker',
    'Feeds' => 'RSS',
    'iFrames'=>'Webportale',
    'TimePeriods'=>'Zeitpl�ne',
    'Project'=>'Projekte',
    'ProjectTask'=>'Projektaufgaben',
    'Campaigns'=>'Kampagnen',
    'Documents'=>'Dokumente',
    'Sync'=>'Sync',
    'Users' => 'User',
    'Releases' => 'Releases',
		'Prospects' => 'Zielpersonen', 
		'Queues' => 'Warteschlangen', 
		'EmailMarketing' => 'Email-Aussendung', 
		'EmailTemplates' => 'Email Vorlagen', 
		'ProspectLists' => 'Verteilerlisten', 
     ),
      
     
     'moduleListSingular' => 
     array ( 
       'Home' => 'Home', 
       'Dashboard' => 'Statistik', 
       'Contacts' => 'Kontakt', 
       'Accounts' => 'Kunde', 
       'Opportunities' => 'Verkaufschance', 
       'Cases' => 'Anfrage', 
       'Notes' => 'Notiz', 
       'Calls' => 'Anruf', 
       'Emails' => 'Email', 
       'Meetings' => 'Termin', 
       'Tasks' => 'Aufgabe', 
       'Calendar' => 'Kalender', 
       'Leads' => 'Interessent', 
       'Activities' => 'Aktivit�t', 
       'Bugs' => 'Bug Tracker', 
       'Feeds' => 'RSS', 
       'iFrames'=>'Mein Portal', 
       'TimePeriods'=>'Zeitplan', 
       'Project'=>'Projekt', 
       'ProjectTask'=>'Projektaufgabe', 
       'Campaigns'=>'Kampagne', 
       'Documents'=>'Dokument', 
       'Sync'=>'Sync', 
       'Users' => 'User' 
    
  ),
  'account_type_dom' =>
  array (
    '' => '',
    'Analyst' => 'Marktanalytiker',
    'Competitor' => 'Konkurrent',
    'Customer' => 'Kunde',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Presse',
    'Prospect' => 'Zielperson',
    'Reseller' => 'Wiederverk�ufer',
    'Other' => 'Andere',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' =>
  array (
    '' => '',
    'Apparel' => 'Bekleidung',
    'Banking' => 'Bankwesen',
    'Biotechnology' => 'Biotechnologie',
    'Chemicals' => 'Chemie',
    'Communications' => 'Kommunikation',
    'Construction' => 'Konstruktion',
    'Consulting' => 'Consulting',
    'Education' => 'Lehre',
    'Electronics' => 'Elektronik',
    'Energy' => 'Energie',
    'Engineering' => 'Maschinenbau',
    'Entertainment' => 'Unterhaltung',
    'Environmental' => 'Umwelt',
    'Finance' => 'Finanz',
    'Government' => 'Regierung',
    'Healthcare' => 'Gesundheitswesen',
    'Hospitality' => 'Hospitality',
    'Insurance' => 'Versicherung',
    'Machinery' => 'Maschinenbau',
    'Manufacturing' => 'Manufacturing',
    'Media' => 'Medien',
    'Not For Profit' => 'Non-Profit Organisation',
    'Recreation' => 'Freizeit und Erholung',
    'Retail' => 'Einzelhandel',
    'Shipping' => 'Versand',
    'Technology' => 'Technologie',
    'Telecommunications' => 'Telekommunikation',
    'Transportation' => 'Transportwesen',
    'Utilities' => 'Utilities',
    'Other' => 'Andere',
  ),
  'lead_source_default_key' => 'Self Generated',
  'lead_source_dom' =>
  array (
    '' => '',
    'Cold Call' => 'Cold Call',
    'Existing Customer' => 'Bestehender Kunde',
    'Self Generated' => 'Selbst angelegt',
    'Employee' => 'Mitarbeiter',
    'Partner' => 'Partner',
    'Public Relations' => 'Werbung',
    'Direct Mail' => 'Mailing',
    'Conference' => 'Konferenz',
    'Trade Show' => 'Messe',
    'Web Site' => 'Webseite',
    'Word of mouth' => 'Mund zu Mund Propaganda',
    'Email' => 'Email',
    'Other' => 'Andere',
  ),
  
    'checkbox_dom'=> array(
  	''=>'',
  	'1'=>'Ja',
  	'2'=>'Nein',
  ),
  
  'dom_int_bool'	=> array(
  		1 => 'Ja',
			0 => 'Nein',
	),
	
		'dom_switch_bool'		=> array (
			'on' => 'Ja',
			'off' => 'Nein',
			'' => 'Nein', 
	),
	
	'dom_email_link_type'	=> array(	
					''			=> 'System Standard Mail Client',
					'sugar'		=> 'SugarCRM Mail Client',
					'mailto'	=> 'Externer Mail Client',
	),

	'dom_email_editor_option'=> array(
			''			=> 'Standard Email Format',
			'html'		=> 'HTML Email',
			'plain'		=> 'Nur Text Email',
	),
	
	  'document_template_type_dom' =>
  array(
  	''=>'',
  	'mailmerge'=>'Serienbrief',
  	'eula'=>'EULA',
  	'nda'=>'NDA',
  	'license'=>'Lizenzvereinbarung',
  ),
  
  //prospect list type dom
  'prospect_list_type_dom' =>
  array (
    'default' => 'Standard',
    'seed' => 'Seed',
    'exempt_domain' => 'Ausschlu� - nach Domain',
    'exempt_address' => 'Ausschlu� - nach Email Adresse',
    'exempt' => 'Ausschlu� - nach Id',
    'test' => 'Test',
  ),
  
  'opportunity_type_dom' =>
  array (
    '' => '',
    'Existing Business' => 'bestehender Kunde',
    'New Business' => 'Neukunde',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim�rer Entscheidungstr�ger',
    'Business Decision Maker' => 'Gesch�ftlicher Entscheidungstr�ger',
    'Business Evaluator' => 'Gesch�ftlicher Gutachter',
    'Technical Decision Maker' => 'Technischer Entscheidungstr�ger',
    'Technical Evaluator' => 'Technischer Gutachter',
    'Executive Sponsor' => 'Leitender Sponsor',
    'Influencer' => 'Einflussreiche Person',
    'Other' => 'Other',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Contact' => 'Prim�rer Kontakt',
    'Alternate Contact' => 'Alternativer Kontakt',
  ),
      'payment_terms' => 
     array ( 
           '' => '', 
           'Net 15' => 'Net 15', 
           'Net 30' => 'Net 30', 
     ), 

  'sales_stage_default_key' => 'Prospecting',
  'sales_stage_dom' =>
  array (
    'Prospecting' => 'Prospektphase',
    'Qualification' => 'Eignungspr�fung',
    'Needs Analysis' => 'Ben�tigt Analyse',
    'Value Proposition' => 'Wertabsch�tzung',
    'Id. Decision Makers' => 'liegt bei Entscheidungstr�gern',
    'Perception Analysis' => 'Wahrnehmungsanalyse',
    'Proposal/Price Quote' => 'Angebotsphase',
    'Negotiation/Review' => 'Verhandlungsphase',
    'Closed Won' => 'Abschluss erfolgreich',
    'Closed Lost' => 'Abschluss negativ',
  ),
  
  'sales_probability_dom' => // keys must be the same as sales_stage_dom 
     array ( 
       'Prospecting' => '10', 
       'Qualification' => '20', 
       'Needs Analysis' => '25', 
       'Value Proposition' => '30', 
       'Id. Decision Makers' => '40', 
       'Perception Analysis' => '50', 
       'Proposal/Price Quote' => '65', 
       'Negotiation/Review' => '80', 
       'Closed Won' => '100', 
       'Closed Lost' => '0', 
     ), 


  'activity_dom' =>
  array (
    'Call' => 'Anruf',
    'Meeting' => 'Termin',
    'Task' => 'Aufgabe',
    'Email' => 'Email',
    'Note' => 'Notiz',
  ),
  'salutation_dom' =>
  array (
    '' => '',
    'Hr.' => 'Hr.',
    'Fr.' => 'Fr.',
    'Mr.' => 'Mr.',
    'Ms.' => 'Ms.',
    'Mrs.' => 'Mrs.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  //time is in seconds; the greater the time the longer it takes;
  'reminder_max_time'=>3600,
  'reminder_time_options' => array( 60=> '1 Minute vorher',
  								  300=> '5 Minuten vorher',
  								  600=> '10 Minuten vorher',
  								  900=> '15 Minuten vorher',
  								  1800=> '30 Minuten vorher',
  								  3600=> '1 Stunde vorher',
								 ),

  'task_priority_default' => 'Medium',
  'task_priority_dom' =>
  array (
    'High' => 'Hoch',
    'Medium' => 'Mittel',
    'Low' => 'Niedrig',
  ),
  'task_status_default' => 'Not Started',
  'task_status_dom' =>
  array (
    'Not Started' => 'nicht begonnen',
    'In Progress' => 'in Bearbeitung',
    'Completed' => 'abgeschlossen',
    'Pending Input' => 'ben�tigt Eingabe',
    'Deferred' => 'verschoben',
  ),
  'meeting_status_default' => 'Planned',
  'meeting_status_dom' =>
  array (
    'Planned' => 'geplant',
    'Held' => 'erledigt',
    'Not Held' => 'nicht durchgef�hrt',
  ),
  'call_status_default' => 'Planned',
  'call_status_dom' =>
  array (
    'Planned' => 'geplant',
    'Held' => 'erledigt',
    'Not Held' => 'nicht durchgef�hrt',
  ),
  'call_direction_default' => 'Outbound',
  'call_direction_dom' =>
  array (
    'Inbound' => 'Eingehend',
    'Outbound' => 'Ausgehend',
  ),
  'lead_status_dom' =>
  array (
    '' => '',
    'New' => 'Neu',
    'Assigned' => 'Zugewiesen',
    'In Process' => 'In Bearbeitung',
    'Converted' => 'Konvertiert',
    'Recycled' => 'Wiederaufgenommen',
    'Dead' => 'Beendet',
  ),
  'lead_status_noblank_dom' =>
  array (
    'New' => 'Neu',
    'Assigned' => 'Zugewiesen',
    'In Process' => 'In Bearbeitung',
    'Converted' => 'Konvertiert',
    'Recycled' => 'Wiederaufgenommen',
    'Dead' => 'Beendet',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' =>
  array (
    'New' => 'Neu',
    'Assigned' => 'Zugewiesen',
    'Closed' => 'Geschlossen',
    'Pending Input' => 'Ben�tigt Eingabe',
    'Rejected' => 'Abgewiesen',
    'Duplicate' => 'Duplikat',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' =>
  array (
    'P1' => 'Hoch',
    'P2' => 'Mittel',
    'P3' => 'Niedrig',
  ),
  'user_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'employee_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Terminated' => 'Beendet',
    'Leave of Absence' => 'Freistellung',
  ),
  'messenger_type_dom' =>
  array (
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
    'AOL' => 'AOL',
  ),

	'project_task_priority_options' => array (
		'High' => 'Hoch',
		'Medium' => 'Mittel',
		'Low' => 'Niedrig',
	),
	'project_task_status_options' => array (
		'Not Started' => 'Nicht begonnen',
		'In Progress' => 'in Bearbeitung',
		'Completed' => 'Beendet',
		'Pending Input' => 'Ben�tigt Eingabe',
		'Deferred' => 'Aufgeschoben',
	),
	'project_task_utilization_options' => array (
		'0' => 'keine',
		'25' => '25',
		'50' => '50',
		'75' => '75',
		'100' => '100',
	),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' =>
  array (
    'Accounts' => 'Kunden',
    'Opportunities' => 'Verkaufschancen',
    'Cases' => 'Anfragen',
    'Leads' => 'Interessenten',
    'Contacts' => 'Kontakte', 
    'Bugs' => 'Bugs',
    'Project' => 'Projekte',
    'ProjectTask' => 'Projektaufgaben',
    'Tasks' => 'Aufgaben',
     ),

  'record_type_display_notes' =>
  array (
    'Accounts' => 'Kunden',
    'Opportunities' => 'Verkaufschancen',
    'Contacts' => 'Kontakte',
    'Cases' => 'Anfragen',
    'Leads' => 'Interessenten',
    'Bugs' => 'Bugs',
    'Emails' => 'Emails',
    'Project' => 'Projekte',
    'ProjectTask' => 'Projektaufgaben',
	  'Meetings' => 'Termine', 
	  'Calls' => 'Anrufe',

     ),

	
  'quote_type_dom' =>
  array (
    'Quotes' => 'Angebot',
    'Orders' => 'Bestellung',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' =>
  array (
    'Draft' => 'Entwurf',
    'Negotiation' => 'Verhandlung',
    'Delivered' => 'Zugestellt',
    'On Hold' => 'Warteposition',
    'Confirmed' => 'Best�tigt',
    'Closed Accepted' => 'Abschluss angenommen',
    'Closed Lost' => 'Abschluss negativ',
    'Closed Dead' => 'Abschluss unm�glich',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' =>
  array (
    'Pending' => 'in Schwebe',
    'Confirmed' => 'Best�tigt',
    'On Hold' => 'Warteposition',
    'Shipped' => 'Versandt',
    'Cancelled' => 'Storniert',
  ),

//Note:  do not translate quote_relationship_type_default_key
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim�rer Entscheidungstr�ger',
    'Business Decision Maker' => 'Gesch�ftlicher Entscheidungstr�ger',
    'Business Evaluator' => 'Gesch�ftlicher Gutachter',
    'Technical Decision Maker' => 'Technischer Entscheidungstr�ger',
    'Technical Evaluator' => 'Technischer Gutachter',
    'Executive Sponsor' => 'Leitender Sponsor',
    'Influencer' => 'Einflussreiche Person',
    'Other' => 'Andere',
  ),
  'layouts_dom' =>
  array (
    'Standard' => 'Standard',
    'Invoice' => 'Rechnung',
    'Terms' => 'Zahlungsbedingungen',
  ),

  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' =>
  array (
    'Urgent' => 'Dringend',
    'High' => 'Hoch',
    'Medium' => 'Mittel',
    'Low' => 'Niedrig',
  ),
   'bug_resolution_default_key' => '',
  'bug_resolution_dom' =>
  array (
  	'' => '',
  	'Accepted' => 'Akzeptiert',
    'Duplicate' => 'Duplikat',
    'Fixed' => 'Behoben',
    'Out of Date' => 'Out of Date',
    'Invalid' => 'Ung�ltig',
    'Later' => 'Sp�ter',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' =>
  array (
    'New' => 'Neu',
    'Assigned' => 'Zugewiesen',
    'Closed' => 'Geschlossen',
    'Pending' => 'Anh�ngig',
    'Rejected' => 'Abgewiesen',
  ),
  
  'bug_type_default_key' => 'Bug',
  'bug_type_dom' =>
  array (
    'Defect' => 'Bug',
    'Feature' => 'Feature',
  ),


  'source_default_key' => '',
  'source_dom' =>
  array (
	  '' => '',
  	'Internal' => 'Intern',
  	'Forum' => 'Forum',
  	'Web' => 'Web',
  	'InboundEmail' => 'Email',
  ),

  'product_category_default_key' => '',
  'product_category_dom' =>
  array (
	'' => '',
  	'Accounts' => 'Kunden',
  	'Activities' => 'Aktivit�ten',
  	'Bug Tracker' => 'Bug Tracker',
  	'Calendar' => 'Kalender',
  	'Calls' => 'Anrufe',
  	'Campaigns' => 'Kampagnen',  	
  	'Cases' => 'Anfragen',
  	'Contacts' => 'Kontakte',
  	'Currencies' => 'W�hrungen',
  	'Dashboard' => 'Statistik',
  	'Documents' => 'Dokumente',
  	'Emails' => 'Emails',
  	'Feeds' => 'Feeds',
  	'Forecasts' => 'Forecasts',  	
  	'Help' => 'Help',
  	'Home' => 'Home',
  	'Leads' => 'Interessenten',
  	'Meetings' => 'Termine',
  	'Notes' => 'Notizen',
  	'Opportunities' => 'Verkaufschancen',
  	'Outlook Plugin' => 'Outlook Plugin',
  	'Product Catalog' => 'Produktkatalog',
  	'Products' => 'Produkte',  	
  	'Projects' => 'Projekte',  	
  	'Quotes' => 'Angebote',
  	'Releases' => 'Releases',
  	'RSS' => 'RSS',
  	'Studio' => 'Studio',
  	'Upgrade' => 'Upgrade',
  	'Users' => 'User',
  ),
 
  /*Added entries 'Queued' and 'Sending' for 4.0 release..*/ 

  'campaign_status_dom' =>
  array (
    '' => '',
        'Planning' => 'Planung',
        'Active' => 'Aktiv',
        'Inactive' => 'Inaktiv',
        'Complete' => 'Abschluss',
         'In Queue' => 'In Warteschlange', 
         'Sending'=> 'Wird gesendet', 

  ),
  'campaign_type_dom' =>
  array (
        '' => '',
        'Telesales' => 'Televerkauf',
        'Mail' => 'Postaussendung',
        'Email' => 'Email',
        'Print' => 'Print',
        'Web' => 'Web',
        'Radio' => 'Radio',
        'Television' => 'Fernsehen',
        ),



  'notifymail_sendtype' =>
  array (
    'sendmail' => 'PHP sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => array('-12'=>'(GMT - 12) International Date Line West',
  							'-11'=>'(GMT - 11) Midway Island, Samoa',
  							'-10'=>'(GMT - 10) Hawaii',
  							'-9'=>'(GMT - 9) Alaska',
  							'-8'=>'(GMT - 8) San Francisco',
  							'-7'=>'(GMT - 7) Phoenix',
  							'-6'=>'(GMT - 6) Saskatchewan',
  							'-5'=>'(GMT - 5) New York',
  							'-4'=>'(GMT - 4) Santiago',
  							'-3'=>'(GMT - 3) Buenos Aires',
  							'-2'=>'(GMT - 2) Mittel Atlantik',
  							'-1'=>'(GMT - 1) Azoren',
  							'0'=>'(GMT) London',
  							'1'=>'(GMT + 1) Madrid',
  							'2'=>'(GMT + 2) Athen',
  							'3'=>'(GMT + 3) Moskau',
  							'4'=>'(GMT + 4) Kabul',
  							'5'=>'(GMT + 5) Ekaterinburg',
  							'6'=>'(GMT + 6) Astana',
  							'7'=>'(GMT + 7) Bangkok',
  							'8'=>'(GMT + 8) Perth',
  							'9'=>'(GMT + 9) Seol',
  							'10'=>'(GMT + 10) Brisbane',
  							'11'=>'(GMT + 11) Solomone Is.',
  							'12'=>'(GMT + 12) Auckland',
  							),
      'dom_cal_month_long'=>array(
                '0'=>'',
                '1'=>'J�nner',
                '2'=>'Februar',
                '3'=>'M�rz',
                '4'=>'April',
                '5'=>'Mai',
                '6'=>'Juni',
                '7'=>'Juli',
                '8'=>'August',
                '9'=>'September',
                '10'=>'Oktober',
                '11'=>'November',
                '12'=>'Dezember',
        ),

        'dom_report_types'=>array(
                'tabular'=>'Zeilen und Spalten',
                'summary'=>'Zusammenfassung',
                'detailed_summary'=>'Zusammenfassung mit Details',
        ),
        'dom_email_types'=>array(
                // 'sent'=>'Gesendet',
                'out'=>'Gesendet',
                'archived'=>'Archiviert',
                'draft'=>'Entwurf',
                'inbound'  => 'Intern', 
           ), 
          
           'dom_email_status' => array ( 
                   'archived'      => 'Archiviert', 
                   'unread'        => 'Ungelesen', 
                   'read'          => 'Gelesen', 
                   'replied'       => 'Beantwortet', 
                   'closed'        => 'Abgeschlossen', 
                   'sent'          => 'Gesendet', 
                   'send_error'=> 'Sendefehler', 
                   'draft'         => 'Entwurf', 
           ), 
    
           'dom_email_server_type' => array(    
           			   ''              => '--None--', 
                   'imap'          => 'IMAP', 
                   'pop3'          => 'POP3', 
           ),
           // Pr�fen 
           'dom_mailbox_type'   => array(
           			/*''                   => '--None Specified--',*/ 
                  'pick'         => '-', 
                  'bug'          => 'Neuen Bug berichten', 
                  'support'      => 'Neue Anfrage', 
                  'contact'  => 'Neuer Kontakt', 
                  'sales'        => 'Neuer Interessent', 
                  'task'         => 'Neue Aufgabe', 
                  'bounce'       => 'Bounces verarbeiten', 
           ),

					 'dom_email_distribution'	=> array(
           				''             => '--None--',
                  'direct'       => 'Direkte Zuweisung',
                  'roundRobin'   => 'Round-Robin (siehe Wikipedia)',
                  'leastBusy'    => 'nach User-Auslastung (Least-Busy)',
           ),

           'dom_email_errors'    => array(
           			 1 => 'Bei direkter Zuweisung nur einen User ausw�hlen.', 
				 				 2 => 'Bei direkter Zuweisung d�rfen Sie nur ausgew�hlte Eintr�ge verwenden.', 
           ), 
           
           'dom_email_bool'       => array(
           			 'bool_true' => 'Ja', 
	               'bool_false' => 'Nein', 
           ), 
    
           'schedulers_times_dom'  => array(       
           			 'not run'       => 'nicht durchgef�hrt', 
                 'ready'         => 'bereit', 
                 'in progress'   => 'in Bearbeitung', 
                 'failed'        => 'fehlgeschlagen', 
                 'completed'		 => 'abgeschlossen',  
 							   'no curl'			 => 'nicht durchgef�hrt, keine cURL verf�gbar',
           ),
   
	'forecast_schedule_status_dom' =>
  	array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  
	'forecast_type_dom' =>
  	array (
    'Direct' => 'Direkt',
    'Rollup' => 'Rollup',
  ),  
	
	'document_category_dom' =>
  	array (
  	'' => '',
    'Marketing' => 'Marketing/Vertrieb',
    'Sales' => 'Verkauf',
    'Knowledege Base' => 'Wissensdatenbank',    
  ),  

	'document_subcategory_dom' =>
  	array (
  	'' => '',
	'Marketing Collateral' => 'Vertrieb Begleitdokumente',
	'Product Brochures' => 'Produkt Kataloge',
	'FAQ' => 'FAQ',
  ),  
  
	'document_status_dom' =>
  	array (
    'Active' => 'Aktiv',
    'Draft' => 'Entwurf',
		'FAQ' => 'FAQ',
		'Expired' => 'Abgelaufen',
		'Under Review' => 'Unter Durchsicht',
		'Pending' => 'anh�ngig',
  ),
	'dom_meeting_accept_options' =>
  	array (
		'accept' => 'Annehmen',
		'decline' => 'Ablehnen',
		'tentative' => 'Vorl�ufig',
	
  ),
	'dom_meeting_accept_status' =>
  	array (
	'accept' => 'Angenommen',
	'decline' => 'Abgelehnt',
	'tentative' => 'Vorl�ufig',
	'none'  => 'Kein',
  ),
  

	//	'queue_type_dom' => array(
	//		'Users' => 'Users',
	//		'Mailbox' => 'Mailbox',
	//	),		   
   
   
  // Pr�fen

 

  
  'email_marketing_status_dom' => 
  array (
  	'' => '',
  	'active'=>'Aktiv',
  	'inactive'=>'Inaktiv',
  ),

//pr�fen
  'campainglog_activity_type_dom' =>
  array (
  	''=>'',
    'targeted' => 'Email gesendet/Sendeversuch',
    'send error'=>'Bounced Email, andere Ursache',
    'invalid email'=>'Bounced Email, ung�ltige Email Adresse',
    'link'=>'hat auf Link geklickt',
    'viewed'=>'hat Message gelesen',
    'removed'=>'hat sich ausgetragen',
    'lead'=>'Interessent wurde angelegt',
    'contact'=>'Kontakt wurde angelegt',        
  ),

  'campainglog_target_type_dom' =>
  array (
    'Contacts' => 'Kontakte',
    'Users'=>'User',
    'Prospects'=>'Zielpersonen',
    'Leads'=>'Interessenten',
  ),

  
  
  
 
  
  
);

$app_strings = array (
	'LBL_ARCHIVE' => 'Archivieren',
  'LBL_SERVER_RESPONSE_TIME' => 'Server Antwortzeit:',
  'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'Sekunden.',
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Meine Einstellungen',
  'LBL_EMPLOYEES' => 'Mitarbeiter',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Abmelden',
  'LBL_SYNC' => 'Sync',
  'LBL_SEARCH' => 'Suche',
  'LBL_LAST_VIEWED' => 'Zuletzt aufgerufen',
  'NTC_WELCOME' => 'Willkommen',
  'NTC_SUPPORT_SUGARCRM' => 'Bitte unterst�tzen Sie das  SugarCRM open source Projekt mit einer Spende �ber PayPal -  schnell, gratis, sicher!',
  'NTC_NO_ITEMS_DISPLAY' => 'leer',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Speichern [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Bearbeiten [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Bearbeiten',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplizieren [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplizieren',
  'LBL_DELETE_BUTTON_TITLE' => 'L�schen [Alt+D]',
  'LBL_DELETE_BUTTON' => 'L�schen',
  'LBL_UNDELETE_BUTTON' => 'Wiederherstellen', 
  'LBL_UNDELETE_BUTTON_TITLE' => 'Wiederherstellen [Alt+D]', 
  'LBL_NEW_BUTTON_TITLE' => 'Neu [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => '�ndern [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Abbrechen [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Suchen [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Leeren [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Ausw�hlen [Alt+T]',
  'LBL_ADD_BUTTON' => 'Hinzuf�gen',
  'LBL_ADD_BUTTON_TITLE' => 'Hinzuf�gen [Alt+A]',
  'LBL_ADD_BUTTON_KEY' => 'A',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Speichern',
  'LBL_EDIT_BUTTON_LABEL' => 'Bearbeiten',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplizieren',
  'LBL_DELETE_BUTTON_LABEL' => 'L�schen',
  'LBL_UNDELETE_BUTTON_LABEL' => 'Wiederherstellen',
  'LBL_NEW_BUTTON_LABEL' => 'Neu',
  'LBL_CHANGE_BUTTON_LABEL' => '�ndern',
  'LBL_CANCEL_BUTTON_LABEL' => 'Abbrechen',
  'LBL_SEARCH_BUTTON_LABEL' => 'Suche',
  'LBL_CLEAR_BUTTON_LABEL' => 'Leeren',
  'LBL_NEXT_BUTTON_LABEL' => 'N�chster',
  'LBL_SELECT_BUTTON_LABEL' => 'Ausw�hlen',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Kontakt ausw�hlen [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
	'LBL_EMAIL_PDF_BUTTON_LABEL' => 'Email as PDF', 
	'LBL_EMAIL_PDF_BUTTON_TITLE' => 'Email as PDF [Alt+M]', 
	'LBL_EMAIL_PDF_BUTTON_KEY' => 'M', 

  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Als PDF drucken',
  'LBL_VIEW_PDF_BUTTON_TITLE' => 'Als PDF drucken [Alt+P]',
  'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
  'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Angebot in Verkaufschance umwandeln',
  'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Angebot in Verkaufschance umwandeln [Alt+O]',
  'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Kontakt ausw�hlen',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'User ausw�hlen [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'User ausw�hlen',
  'LBL_CREATE_BUTTON_LABEL' => 'Neu',
  'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'Bericht ausw�hlen',
  'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'Bericht ausw�hlen',
  'LBL_DONE_BUTTON_KEY' => 'X',
  'LBL_DONE_BUTTON_TITLE' => 'Fertig [Alt+X]',
  'LBL_DONE_BUTTON_LABEL' => 'Fertig',
     
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L', 
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE' => 'Zur Verteilerliste hinzf�gen', 
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'Zur Verteilerliste hinzf�gen', 

  'LBL_SHORTCUTS' => 'Schnellstart',
  'LBL_LIST_NAME' => 'Name',



  'LBL_LIST_USER_NAME' => 'User Name',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Name',
  'LBL_LIST_CONTACT_ROLE' => 'Kontakt Rolle',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_USER_LIST' => 'Userliste',
  'LBL_CONTACT_LIST' => 'Kontaktliste',
  'LBL_RELATED_RECORDS' => 'Datensatz verkn�pfen mit:',
  'LBL_MASS_UPDATE' => 'Massenaktualisierung',
  'LNK_ADVANCED_SEARCH' => 'Erweiterte Suche',
  'LNK_BASIC_SEARCH' => 'Einfache Suche',
  'LNK_EDIT' => 'Bearbeiten',
  'LNK_REMOVE' => 'Entfernen',
  'LNK_DELETE' => 'L�schen',
  'LNK_DELETE_ALL' => 'Alle l�schen',
  'LNK_LIST_START' => 'Start',
  'LNK_LIST_NEXT' => 'N�chste Seite',
  'LNK_LIST_PREVIOUS' => 'Vorherige Seite',
  'LNK_LIST_END' => 'Ende',
  'LNK_LIST_RETURN' => 'Zur�ck zur Liste',
  'LBL_LIST_OF' => 'von',
  'LNK_RESUME' => 'Weiter',
  'LBL_OR' => 'oder',
  'LBL_BY' => 'von',
  'LNK_PRINT' => 'Drucken',
  'LNK_HELP' => 'Hilfe',
  'LNK_ABOUT' => 'About',
  'NTC_REQUIRED' => 'verpflichtende Eingabe',
  'LBL_REQUIRED_SYMBOL' => '*',
  
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_YEAR_FORMAT' => '(yyyy)',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'M�chten Sie die ausgew�hlten Datens�tze wirklich l�schen?',
  'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen?',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'ERR_CREATING_TABLE' => 'Fehler beim Anlegen der Tabelle: ',
  'ERR_CREATING_FIELDS' => 'Error filling in additional detail fields: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Verpflichtende Eingabe fehlt:',
   'ERR_SQS_NO_MATCH_FIELD' => 'Kein Treffer f�r dieses Feld: ',
  'ERR_INVALID_EMAIL_ADDRESS' => 'keine g�lige Email Adresse.',
  'ERR_SELF_REPORTING' => 'User kann nicht an sich selbst berichten.',
  'ERR_INVALID_DATE_FORMAT' => 'g�ltiges Datumsformat ist:',
  'ERR_INVALID_MONTH' => 'Bitte geben Sie eine g�ltiges Monat ein.',
  'ERR_INVALID_DAY' => 'Bitte geben Sie einen g�ltigen Tag ein.',
  'ERR_INVALID_YEAR' => 'Bitte geben Sie eine g�ltige 4-stellige Jahreszahl ein.',
  'ERR_INVALID_DATE' => 'Bitte geben Sie eine g�ltiges Datum ein.',
  'ERR_INVALID_HOUR' => 'Bitte geben Sie eine g�ltige Stunde ein.',
  'ERR_INVALID_TIME' => 'Bitte geben Sie eine g�ltige Zeit ein.',
  'ERR_INVALID_AMOUNT' => 'Bitte geben Sie einen g�ltigen Betrag ein.',
   'ERR_NOTHING_SELECTED' =>'W�hlen Sie eine Eintrag aus.', 
   'ERR_SQS_NO_MATCH' =>'Keine Treffer', 

  'NTC_CLICK_BACK' => 'Bitte klicken Sie auf den Z�r�ck Button des Browser und beheben Sie diesen Fehler.',
  'LBL_LIST_ASSIGNED_USER' => 'User',
  'LBL_ASSIGNED_TO' => 'zugewiesen an:',
  'LBL_DATE_MODIFIED' => 'ge�ndert am:',
  'LBL_DATE_ENTERED' => 'erstellt am:',
  'LBL_CURRENT_USER_FILTER' => 'Nur meine Eintr�ge:',
  'NTC_LOGIN_MESSAGE' => 'Bitte geben Sie Benutzername und Passwort ein.',
  'LBL_NONE' => '--',
  'LBL_BACK' => 'Zur�ck',
  'LBL_IMPORT' => 'Importieren',
  'LBL_EXPORT' => 'Exportieren',
  'LBL_EXPORT_ALL' => 'Alle exportieren',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Speichern & Neu [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Speichern & Neu',
  'LBL_NAME' => 'Name',



  'LBL_CHECKALL' => 'Alle ausw�hlen',
  'LBL_CLEARALL' => 'Alle abw�hlen',
  'LBL_SUBJECT' => 'Betreff',
  'LBL_ENTER_DATE' => 'Datum eingeben',
  'LBL_CREATED' => 'erstellt von',
  'LBL_MODIFIED' => 'ge�ndert von',
  'LBL_DELETED'=>'Gel�scht',
  'LBL_ID'=>'ID',
  'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Neue Email [Alt+L]',
  'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
  'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Neue Email',
  'ERR_OPPORTUNITY_NAME_MISSING' => 'Es wurde kein Name f�r die Verkaufschance eingegeben.  Bitte geben sie einen Namen an.',
  'ERR_OPPORTUNITY_NAME_DUPE' => 'Es gibt bereits eine Verkaufschance mit diesem Namen: %s .  Bitte w�hlen Sie einen anderen Namen.',
  'LBL_OPPORTUNITY_NAME' => 'Verkaufschance Name',
  'LBL_DELETE' => 'L�schen',
  'LBL_UNDELETE' => 'Wiederherstellen',
  'LBL_UPDATE' => 'Speichern',
  'LBL_STATUS_UPDATED'=>'Ihr Status f�r diesen Termin wurde ge�ndert!',
  'LBL_STATUS'=>'Status:',
  'LBL_CLOSE_WINDOW'=>'Fenster schliessen',
  //'LBL_SORT' => 'Sortieren',
  'LBL_OPENALL_BUTTON_TITLE' => 'Alle �ffnen [Alt+O]', 
     'LBL_OPENALL_BUTTON_KEY' => 'O', 
     'LBL_OPENALL_BUTTON_LABEL' => 'Alle �ffnen', 
     'LBL_CLOSEALL_BUTTON_TITLE' => 'Alle schliessen [Alt+I]', 
     'LBL_CLOSEALL_BUTTON_KEY' => 'Q', 
     'LBL_CLOSEALL_BUTTON_LABEL' => 'Alle schliessen', 
     'LBL_OPENTO_BUTTON_TITLE' => '�ffnen: [Alt+T]', 
     'LBL_OPENTO_BUTTON_KEY' => 'T', 
     'LBL_OPENTO_BUTTON_LABEL' => '�ffnen: ', 
     'LBL_UNAUTH_ADMIN' => 'Unerlaubter Zugriff auf Administration', 
     'NTC_REMOVE_CONFIRMATION' => 'M�chten Sie diese Beziehung entfernen?', 
     'LBL_ASSIGNED_TO_USER'=>'zugewiesen an', 
     'LBL_MODIFIED_BY_USER'=>'ge�ndert von', 
     'LBL_CREATED_BY_USER'=>'erstellt von', 
     'LBL_TEAMS_LINK'=>'Team', 
     'LBL_PRODUCT_BUNDLES'=>'Produktgruppe', 
     'LBL_TASKS'=>'Aufgaben', 
     'LBL_NOTES'=>'Notizen', 
     'LBL_MEETINGS'=>'Termine', 
     'LBL_CALLS'=>'Anrufe', 
     'LBL_EMAILS'=>'Emails', 
     'LBL_PROJECTS'=>'Projekte', 
     'LBL_SHIP_TO_ACCOUNT'=>'Versand an Kunden', 
     'LBL_BILL_TO_ACCOUNT'=>'Rechnung an Kunden', 
     'LBL_SHIP_TO_CONTACT'=>'Versand an Kontakt', 
     'LBL_BILL_TO_CONTACT'=>'Rechnung an Kontakt', 
     'LBL_PRODUCT_BUNDLES'=>'Produktgruppe', 
     'LBL_OPPORTUNITY'=>'Verkaufschance', 
     'LBL_PRODUCTS'=>'Produkte', 
     'LBL_OPPORTUNITIES'=>'Verkaufschancen', 
     'LBL_ACCOUNTS'=>'Kunden', 
     'LBL_BUGS'=>'Bugs', 
     'LBL_CASES'=>'Anfragen', 
     'LBL_DIRECT_REPORTS'=>'Verkn�pfte Kontakte', 
     'LBL_LEADS'=>'Interessenten', 
     'LBL_PROJECTS'=>'Projekte', 
     'LBL_QUOTES'=>'Angebote', 
     'LBL_USERS_SYNC'=>'User Sync', 
     'LBL_MEMBERS'=>'Mitglieder', 
     'LBL_CONTACTS'=>'Kontakte', 
     'LBL_QUOTES_SHIP_TO'=>'Angebote versenden an', 
     'LBL_ACCOUNT'=>'Kunde', 
     'LBL_CONTACT'=>'Kontakt', 
     'LBL_USERS'=>'User', 
     'LBL_CASE'=>'Anfrage', 
     'LBL_PROJECT_TASKS'=>'Projektaufgaben', 
     'LBL_SHOW'=>'anzeigen', 
     'LBL_HIDE'=>'verbergen', 
     'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'Zusammenfassung [Alt+H]', 
     'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H', 
     'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Zusammenfassung', 
     'LNK_VIEW_CHANGE_LOG' => '�nderungsprotokoll', 
     
      'LBL_SYNC' => 'Sync', 
      'LBL_UNSYNC' => 'Unsync', 
      'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Email archivieren [Alt+K]', 
      'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K', 
      'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Email archivieren ',
      'LBL_CAMPAIGNS_SEND_QUEUED' => 'Email Kampagnen in Warteschlange senden',
      
      // Pr�fen
     'LBL_SERVER_RESPONSE_RESOURCES' => 'F�r diese Seite verwendete Resourcen (Abfragen, Dateiein)', 
     'LBL_MAILMERGE' => 'Serienbrief', 
     'LBL_MAILMERGE_KEY' => 'M', 
     'LBL_DST_NEEDS_FIXIN' => 'Der Sommerzeit Korrektur Patch muss angewandt ausgef�hrt werden.  Bitte klicken Sie zu <a href="index.php?module=Administration&action=DstFix">Reparatur</a> link in der Administration und f�hren Sie den Sommerzeit Korrektur Patch aus.', 
    
     'LBL_SQS_INDICATOR' => '', 
     'LBL_ADDITIONAL_DETAILS' => 'Zus�tzliche Angaben', 
     'LBL_ADDITIONAL_DETAILS_CLOSE' => 'Schliessen', 
     'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'Zum Schliessen Klicken', 
     'LBL_IMPORT_PROSPECTS'=>'Zielpersonen importieren', 
     
  
'LBL_ADD_DOCUMENT' => 'Dokument hinzuf�gen',
'LBL_VIEW_BUTTON_KEY' => 'V',
'LBL_VIEW_BUTTON_LABEL' => 'Anzeigen',
'LBL_VIEW_BUTTON_TITLE' => 'Anzeigen [Alt+V]',
'LBL_VIEW_BUTTON' => 'Anzeigen',
'LBL_LISTVIEW_MASS_UPDATE_CONFIRM' => ';M�chten Sie wirklich die ganze Liste l�schen?',
'LBL_LISTVIEW_NO_SELECTED' => 'Bitte w�hlen Sie mindestens einen Datensatz aus.',
'LBL_LISTVIEW_OPTION_CURRENT' => 'Aktuelle Seite',
'LBL_LISTVIEW_OPTION_ENTIRE' => 'Gesamte Liste',
'LBL_LISTVIEW_OPTION_SELECTED' => 'Ausgew�hlte Datens�tze',
'LBL_LISTVIEW_SELECTED_OBJECTS' => 'Ausgew�hlt: ',
'LBL_REMOVE' => 'Entfernen',
'LNK_GET_LATEST'=>'W�hle letztes',
'LNK_GET_LATEST_TOOLTIP'=>'Mit letzter Version ersetzen',
'LNK_LOAD_SIGNED'=>'Signieren',
'LNK_LOAD_SIGNED_TOOLTIP'=>'Mit signiertem Dokument ersetzen',
'LOGIN_LOGO_ERROR'=> 'Bitte ersetzen Sie die SugarCRM Logos.',
'ERROR_FULLY_EXPIRED'=> "Ihre Firmenlizenz f�r SugarCRM ist mehr als 30 Tage abgelaufen und muss erneuert werden. Nur Administratoren k�nnen einloggen.",
'ERROR_LICENSE_EXPIRED'=> "Ihre Firmenlizenz f�r SugarCRM muss erneuert werden. Nur Administratoren k�nnen einloggen.",
	
	




);

?>
