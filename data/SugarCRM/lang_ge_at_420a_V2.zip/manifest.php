<?PHP
// manifest file for information regarding application of new code
$manifest = array(
	// only install on the following regex sugar versions (if empty, no check) 
		'acceptable_sugar_versions' => array (
		'exact_matches' => array (),
		'regex_matches' => array ('4.2.[0-9][a-z]?'),
	),

    'acceptable_sugar_flavors' =>
    array (
        0 => 'OS',

    ),


    // name of new code
    'name' => 'German (AT) Language Pack',

    // description of new code
    'description' => 'German (AT) Language Pack',

    // author of new code
    'author' => 'krokogras',

    // date published
    'published_date' => '2006/04/23',

    // version of code
    'version' => '4.2.03',

    // type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',
    
    // Uninstall Option
    'is_uninstallable' => TRUE,

    // icon for displaying in UI (path to graphic contained within zip package)
    'icon' => '',
);


$installdefs = array(
	'id'=> 'ge_at',
);

?>