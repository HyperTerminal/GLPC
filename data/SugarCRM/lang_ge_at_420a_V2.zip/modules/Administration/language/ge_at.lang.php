<?php
 if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: ge_at.lang.php,v 1.29 2006/04/01 12:22:06 krokogras Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Administration',
	'LBL_MODULE_TITLE' => 'Administration: Home',
	'LBL_NEW_FORM_TITLE' => 'Neuer Kunde',
	'LNK_NEW_USER' => 'Neuer User',
	'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Systemeinstellungen',
	'LBL_CONFIGURE_SETTINGS' => 'Systemweite Einstellungen editieren',
	'LBL_UPGRADE_TITLE' => 'Reparatur',
	'LBL_UPGRADE' => 'Sugar Suite �berpr�fen und reparieren',
	'LBL_MANAGE_USERS_TITLE' => 'User Management',
	'LBL_MANAGE_USERS' => 'Userberechtigungen und Passw�rter verwalten',
	'LBL_ADMINISTRATION_HOME_TITLE' => 'System',

	

	'LBL_NOTIFY_SUBJECT' => 'Email Betreff:',
	
	'LBL_CURRENCY' => 'W�hrungen und Umrechnungsfaktoren editieren',
	'LBL_RELEASE' => 'Softwarereleases und -versionen editieren (f�r Bugtracker)',
	'LBL_LAYOUT' => 'Panels, Felder und Beschriftungen systemweit hinzuf�gen, �ndern, entfernen',
	'LBL_MANAGE_CURRENCIES' => 'W�hrungen',
	'LBL_MANAGE_RELEASES' => 'Releases',
	'LBL_MANAGE_LAYOUT' => 'Layout Editor',
	'LBL_MANAGE_OPPORTUNITIES' => 'Verkaufschancen',
	'LBL_UPGRADE_CURRENCY' => 'W�hrungsbetr�ge werden aktualisiert in ',
	'LBL_EDIT_CUSTOM_FIELDS' => 'Benutzerdef. Felder',
	'DESC_MODULES_QUEUED' => 'Diese Module sind installationsbereit:', 
	'DESC_FILES_QUEUED' => 'Diese Module sind installationsbereit:', 
	'DESC_MODULES_INSTALLED' => 'Diese Module sind installiert:', 
	'DESC_FILES_INSTALLED' => 'Diese Module sind installiert:', 
	'DESC_EDIT_CUSTOM_FIELDS' => 'Benutzerdefinierte Felder hinzuf�gen, �ndern, l�schen',
	'LBL_DROPDOWN_EDITOR' => 'Auswahlfeld Editor',
	'DESC_DROPDOWN_EDITOR' => 'Auswahlfeld Listeneintr�ge hinzuf�gen, l�schen oder editieren.',
	'LBL_IFRAME'=> 'Web-Portal',
	'DESC_IFRAME' => 'Register zum Anzeigen beliebiger Web-Portale (Websites) hinzuf�gen',
	'LBL_BUG_TITLE' => 'Bugbericht',
	'LBL_TIMEZONE' => 'Zeitzone',
	'LBL_STUDIO_TITLE' => 'Anpassung',
	'LBL_UPLOAD_MODULE' => 'Modul uploaden: ', 
	'LBL_UPLOAD_UPGRADE' => 'Upgrade uploaden: ', 

	'LBL_CONFIGURE_TABS' => 'Register konfigurieren',
	'LBL_CHOOSE_WHICH'=>'Geben Sie an, welche Register systemweit angezeigt werden sollen',
	'LBL_DISPLAY_TABS'=>'Register anzeigen',
	'LBL_HIDE_TABS'=>'Register verstecken',
	'LBL_EDIT_TABS'=>'Register bearbeiten',
	'LBL_UPGRADE_DB_TITLE' => 'Datenbank upraden',
	'LBL_UPGRADE_DB' => 'Datenbank von Version 2.0.x auf  2.5 updaten',
	'LBL_UPGRADE_DB_BEGIN' => 'Upgrade gestartet',
	'LBL_UPGRADE_DB_COMPLETE' => 'Upgrade fertig',
	'LBL_UPGRADE_VERSION'=>'Versionsinformatin wird upgedated',
	'LBL_UPGRADE_DB_FAIL' => 'Upgrade fehlgeschlagen',
	'LBL_FORECAST_TITLE'=> 'Vorschau',
	
	'LBL_UPGRADE_WIZARD' => 'Upgrade Assistent zur Verwaltung von Upgrades',
	'LBL_UPGRADE_WIZARD_TITLE' => 'Upgrade Assistent',
	'LBL_MODULE_LOADER' => 'Module, Language Packs oder Skins hinzuf�gen oder entfernen',
	'LBL_MODULE_LOADER_TITLE' => 'Modul Assistent',
	
	// done: hier pr�fen ob alle variablen notwendig sind
	//'LBL_UPGRADE_CONFIG_TITLE' => 'Konfigurationsdatei uggraden',
	//'LBL_UPGRADE_CONFIG' => 'Konfigurationsdatei upgraden, soda� Variabeln in Arrays gespeichert werden.',
	//'BTN_PERFORM_UPGRADE' => 'Upgrade durchf�hren',
	//'LBL_PERFORM_UPGRADE' => 'Konfiguration upgraden',
	//'LBL_CONFIG_CHECK' => 'Konfigurations�berpr�fung',
	//'MSG_CONFIG_FILE_UP_TO_DATE' => 'Ihre Konfigurationsdatei ist "up to date".',
	//'MSG_CONFIG_FILE_READY_FOR_UPGRADE' => 'Ihre alte Konfigurationsdatei kann upgegradet werden.  Fertigen Sie unbedingt vorher ein Backup Ihrer config.php Datei an!',
	//'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'Bitte vergeben Sie Schreibrechte an Ihre Konfigurationsdatei (config.php), damit die Datei in aktuelle Format aktulisiert werden kann.',
	//'MSG_CONFIG_FILE_UPGRADE_SUCCESS' => 'Ihre Konfigurationsdatei wurde erfolgreich aktualisiert.',
	//'MSG_CONFIG_FILE_UPGRADE_FAILED' => 'Konfigurationsdatei konnte nicht aktualisiert werden.',
	
	// 'LBL_UPGRADE_DROPDOWN' => 'Benutzerdefinierte Beschriftungen und Auswahlfelder ins neue Format konvertieren',
	//'LBL_UPGRADE_DROPDOWN_TITLE' => 'Benutzerdefinierte Beschriftungen aktualisieren',
	//'LBL_UPGRADE_CUSTOM_FIELDS' => 'Benutzerdefinierte Felder aktualisieren',
	//'LBL_UPGRADE_CUSTOM_FIELDS_TITLE' => 'Benutzerdefinierte Felder ',
	// ende done
	
	
	'LBL_ALLOW_USER_TABS' => 'Benutzern Registeranpassung erlauben',
	'LBL_RENAME_TABS'=>'Register umbenennen',
	'LBL_CHANGE_NAME_TABS'=>'Beschriftung der Register (Tabs) �ndern.',
	'LBL_MASS_EMAIL_MANAGER_DESC'=> 'Massenmail Warteschlange bearbeiten',
	
	'LBL_MASS_EMAIL_MANAGER_TITLE'=> 'Warteschlangen Management',
	'LBL_MASS_EMAIL_MANAGER_HEADER'=>'Massenmail Management',
	'LBL_MANAGE_ROLES_TITLE' => 'Rollen Management',
  
  'LBL_BACKUPS_TITLE' => 'Backups', 
  'LBL_BACKUPS' => 'Backup ausf�hren', 
   

   
   'LBL_SUGAR_SCHEDULER_TITLE' => 'Servicepl�ne', 
   'LBL_SUGAR_SCHEDULER' => 'Geplante Service Aufgaben einrichten', 
      
       
   'LBL_INBOUND_EMAIL_TITLE' => 'Email-Empfang', 
   'LBL_MANAGE_MAILBOX' => 'Mailbox - Mangagement', 
   'LBL_MAILBOX_DESC' => 'Mailboxen f�r Email-Empfang einrichten.', 
           

           


	'LBL_MANAGE_ROLES' => 'Rollenmitgliedschaft und Rolleneigenschaften definieren',
	'LBL_IMPORT_CUSTOM_FIELDS_TITLE' => 'Importiere benutzerdefinierte Felddefinitionen',
	'LBL_EXPORT_CUSTOM_FIELDS_TITLE' => 'Exportiere benutzerdefinierte Felddefinitionen',
	'LBL_EXTERNAL_DEV_TITLE'=> 'Benutzerdef. Felder �bertragen',
	'LBL_EXTERNAL_DEV_DESC'=> 'Benutzerdefinierte Felder von einem System in ein anderes �bertragen',
	'LBL_IMPORT_CUSTOM_FIELDS'=> 'Importiere benutzerdefinierte Felddefinitionen aus einer *.sugar Datei', 
	'LBL_EXPORT_CUSTOM_FIELDS'=> 'Exportiere benutzerdefinierte Felddefinitionen in eine einer *.sugar Datei', 
	'LBL_IMPORT_CUSTOM_FIELDS_STRUCT'=> ' Benutzerdefinierte Feldstruktur (CustomFieldStruct.sug)',
	'LBL_IMPORT_CUSTOM_FIELDS_DESC'=> ' <br>Importieren Sie ein *.sug Datei, welche von einem anderen System exportiert wurde. Dadurch �bernehmen Sie benutzerdefinierte Felddefinitionen eines anderen Systems in dieses System. Vor dem Import sollten Sie Ihre gegenw�rtigen benutzerdefineierten Feldstrukturen exportieren. Beim Import werden Sie darauf hingewiesen welche Datenbank�nderungen durchgef�hrt werden. Best�tigen Sie die �nderungen durch Klicken auf den Link am Ende des Dialoges. Wenn Sie den Importvorgang r�ckg�ngig machen m�chten k�nnen Sie einfach wieder die zuerst exportierten Felddefinitionen importieren. <br> Warnung!: Durch den Import werden alle bereits definerten nicht in der *.sugar Datei enthaltenen Feldstrukturen gel�scht und auch alle Daten gel�scht, welche in diesen benutzerdefineten Feldern eingegeben wurden.',
	
	
	
	'LBL_REBUILD_AUDIT_TITLE' => 'Protokoll aktualisieren', 
	'LBL_REBUILD_AUDIT_DESC' => 'Protokolltabellen erg�nzen.', 
	
	'LBL_REBUILD_EXTENSIONS_TITLE' => 'Erweiterungen wiederherstellen', 
	'LBL_REBUILD_EXTENSIONS_DESC' => 'Wiederherstellen von Erweiterungen wie  Vardefs, Languagepacks, Men�s, Administration', 
    
   'LBL_REBUILD_CONFIG' =>'Konfigurationsdatei aktualisieren', 
   'LBL_REBUILD_CONFIG_DESC' =>'Konfigurationsdatei config.php aktualisieren (Versioninformation und Standardwerte).', 
   'BTN_REBUILD_CONFIG' =>'Aktualisieren', 
   'LBL_CONFIG_CHECK' =>'Konfigurations�berpr�fung', 
   'MSG_CONFIG_FILE_READY_FOR_REBUILD' => 'Die Konfigurationsdatei config.php ist zur Aktualisierung bereit.', 
   'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'Bitte setzen Sie config.php schreibbar und versuchen Sie es noch einmal.', 
   'MSG_CONFIG_FILE_REBUILD_SUCCESS' => 'Die Konfigurationsdatei config.php wurde erfolgreich aktualisiert.', 
   'MSG_CONFIG_FILE_REBUILD_FAILED' => 'Die Konfigurationsdatei config.php konnte nicht aktualisiert werden.', 

   'LBL_REPAIR_DATABASE' =>'Datenbankreparatur', 
   'LBL_REPAIR_DATABASE_DESC' =>'Datenbankreparatur basierend auf Werten welche in vardefs definiert sind (MYSQL ONLY)', 
   'LBL_REPAIR_DISPLAYSQL' =>'SQL anzeigen', 
  
   'LBL_REPAIR_DATABASE_TEXT'=>'Hier updaten Sie die Datenbank um �nderungen der Vardefs und Metadata Beziehungen zu aktualisieren. <br>W�hlen Sie eine Option: <br>SQL anzeigen zeigt die SQL Abrage an, welche ausgef�hrt werden wird.<br> SQL Exportieren exportiert die SQL Abfrage in eine Datei<br> SQL ausf�hren f�hrt die SQL-Abfrage aus.', 
   'LBL_REPAIR_EXPORTSQL' =>'SQL Abfrage exportieren', 
   'LBL_REPAIR_EXECUTESQL' =>'SQL Abfrage ausf�hren', 
  
	'LBL_SUGAR_UPDATE_TITLE'=>'Sugar Updates', 
	'LBL_SUGAR_UPDATE'=>'Auf Updates pr�fen.', 
	'LBL_UPDATE_TITLE'=>'Sugar Updates aktivieren:', 
	'LBL_UPDATE_CHECK_TYPE'=>'Auf Updates pr�fen', 
	'LBL_UPDATE_CHECK_AUTO'=>'Automatisch', 
	'LBL_UPDATE_CHECK_MANUAL'=>'Manuell', 
	'LBL_CHECK_NOW_TITLE' =>'Jetzt pr�fen', 
	'LBL_CHECK_NOW_LABEL' =>'Jetzt pr�fen', 
	'LBL_SEND_STAT'=>'Gebrauchsstatistik - Berichte an Sugar Team senden.', 
	'LBL_CONFIGURE_UPDATER'=>'Sugar Updates konfigurieren', 
	'HEARTBEAT_MESSAGE'=>"<BR>Wenn diese Option aktiviert wird, wird Ihr System periodisch anonyme Statistiken �ber Ihre Installation an SugarCRM Inc senden. Anonyme Statistiken �ber Ihr System helfen uns durch Verst�ndnis des Benutzungsmusters das Produkt zu verbessern. Im Gegenzug erhalten Adminstratoren Update Verst�ndigungen wenn neue Versionen oder Updates verf�gbar sind.", 
	'LBL_ERROR_VERSION_INFO'=>'Fehler beim Abfragen der Versionsinformation, bitte versuchen Sie es sp�ter noch einmal.', 
	'LBL_REBUILD_REL_TITLE'=>'Beziehungen wiederherstellen', 
	'LBL_REBUILD_REL_DESC'=>'Wiederherstellen der Beziehungen der Metadaten und l�schen der Cache Datei.', 
	'LBL_UPGRADE_CUSTOM_LABELS_TITLE'=>'Benutzerdef. Beschriftungen', 
  'LBL_UPGRADE_CUSTOM_LABELS_DESC'=>'Benutzerdefinierte Beschriftungen der Eingabefelder f�r installierte Sprachdateien aktualisieren.', 

	'LBL_MASSAGE_MASS_EMAIL'=>'GMT Datums Fix f�r gesendete Massenmail', 
	'LBL_MASSAGE_MASS_EMAIL_DESC'=>'SugarCRM  ben�tigt ein Update der Massenmaildaten.  Um fortzufahren klicken Sie auf "Begin Update".', 
	'LBL_PERFORM_UPDATE'=>'Update durchf�hren', 
	'MSG_INCREASE_UPLOAD_MAX_FILESIZE' => 'Warnung: Ihre PHP Konfiguration muss ge�ndert werden, damit Dateien gr�sser 6MB  auf den Server hochgeladen werden k�nnen.  �ndern Sie den upload_max_filesize Wert in Ihrer php.ini. Diese befindet sich unter:', 
	'LBL_CLEAR_CHART_DATA_CACHE_TITLE'=>'Datencache der Graphikstatistik l�schen', 
	'LBL_CLEAR_CHART_DATA_CACHE_DESC'=>'Gecachte Daten der Graphikstatistik l�schen.', 
	'LBL_REBUILD_HTACCESS'=>'.htaccess Dateien neu generieren', 
	'LBL_REBUILD_HTACCESS_DESC'=>'.htaccess Dateien neu generieren um den Zugang zu gewissen Dateien zu sperren.', 

 
   
            'LBL_APPLY_DST_FIX' => 'Sommerzeit Zeitkorrektur Patch anwenden', 
           'LBL_APPLY_DST_FIX_DESC' => 'Dieser verpflichtende Schritt ver�ndert die Behandlung von Zeitangaben (nur MYSQL).', 
           'LBL_DST_BEFORE' => 'Bevor Sie beginnen:', 
           'LBL_DST_BEFORE_DESC' => 'Diese Korrektur ver�ndert Ihre Daten.  Bitte fertigen Sie vor Anwendung dieser Korrektur ein Backup Ihrer Datenbank an.', 
           'LBL_DST_FIX_DONE_DESC' => 'Der Sommerzeit Zeitkorrektur Patch wurde erfolgreich durchgef�hrt.', 
           'LBL_DST_FIX_TARGET' => 'Ziel:', 
           'LBL_DST_FIX_CONFIRM' => 'Best�tigen: ', 
           'LBL_DST_FIX_CONFIRM_DESC' => 'Bitte pr�fen Sie die Werte unterhalb und best�tigen Sie, da� Ihr System richtig konfiguriert ist.', 
           'LBL_DST_START_DATE_TIME' => 'Beginndatum/-zeit', 
           'LBL_DST_END_DATE_TIME' => 'Abschlussdatum/zeit', 
           'LBL_DST_CURRENT_SERVER_TIME' => 'Festgestellte lokale Server Zeit:', 
           'LBL_DST_CURRENT_SERVER_TIME_ZONE' => 'Festgestellte Server Zeitzone:', 
           'LBL_DST_CURRENT_SERVER_TIME_ZONE_LOCALE' => 'Lokale Server Zeitzone:', 
           'LBL_DST_UPGRADE' => 'Upgrade:', 
           'LBL_DST_APPLY_FIX' => 'Sommerzeit Zeitkorrektur Patch auf existierende Daten anwenden.  Bitte legen Sie zuerst ein Backup an.', 
           'LBL_DST_FIX_USER_TZ' => 'Dieser Schritt setzt die Zeitzone f�r alle User auf die am ehesten zutreffende Einstellung.', 
           'LBL_DST_FIX_USER' => 'User Zeitzonen:<br>(OPTIONAL)', 
           'LBL_DST_SET_USER_TZ' => 'User Zeitzone einstellen', 
    
         

	   'LBL_MANAGE_GROUPS_TITLE'       => 'Gruppen verwalten', 
           'LBL_MANAGE_GROUPS'                     => 'Gruppenverarbeitung einstellen', 
           'LBL_MASS_EMAIL_CONFIG_TITLE'=>'Email-Kampagnen Einstellungen', 
           'LBL_MASS_EMAIL_CONFIG_DESC'=> 'Einstellungen von Massenmail und Email-Kampagnen', 
          // 'LBL_MAILMERGE' => 'Serienbrief', 
           'LBL_ENABLE_MAILMERGE' => 'Serienbrief-Funktionen aktivieren?', 
           //'LBL_MAILMERGE_DESC' => 'Diese Einstellung sollte nur angekreuzt werden, wen das Sugar Plug-in f�r Microsoft Word gekauft und lizensiert wurde.', 
           'LBL_REPAIR_ACTION' => 'Was m�chten Sie machen?', 
           // backups 
           'LBL_BACKUP_DIRECTORY' => 'Verzeichnis:', 
           'LBL_BACKUP_DIRECTORY_WRITABLE' => 'muss f�r die Sugar Applikation schreibbar sein', 
           'LBL_BACKUP_FILENAME' => 'Dateiname:', 
           'LBL_BACKUP_INSTRUCTIONS_1' => 'Dieses Tool soll Ihnen bei der Erstellung von Backups der Sugar Suite Dateien assistieren. Datenbank Backups sollten ebenfalls regelm��ig erfolgen!', 
           'LBL_BACKUP_INSTRUCTIONS_2' => 'Geben Sie die folgenen Informatienen ein, damit ein Backup der Sugar Application Dateien als zip Datei erfolgen kann:', 
           'LBL_BACKUP_CONFIRM' => 'Einstellungen best�tigen', 
           'LBL_BACKUP_DIRECTORY_ERROR' => 'Backupverzeichnis muss angegeben werden.', 
           'LBL_BACKUP_FILENAME_ERROR' => 'Backup Dateiname muss angegeben werden.', 
           'LBL_BACKUP_CONFIRMED' => 'Einstellungen best�tigt. Press backup to perform the backup.', 
           'LBL_BACKUP_RUN_BACKUP' => 'Backup starten', 
           'LBL_BACKUP_DIRECTORY_EXISTS' => 'Backupverzeichnis existiert nicht und konnte auch nicht erstellt werden.', 
           'LBL_BACKUP_DIRECTORY_NOT_WRITABLE' => 'Backupverzeichnis existiert, ist aber nicht schreibbar.', 
           'LBL_BACKUP_FILE_EXISTS' => 'Die Zieldatei existiert bereit in diesem Verzeichnis.', 
           'LBL_BACKUP_FILE_AS_SUB' => 'Zieldatei existiert bereits as Verzeichnisname im angegebenen Backupverzeichnis', 
           'LBL_BACKUP_FILE_STORED' => 'Backup erfolgreich gespeichert als', 
           'LBL_BACKUP_BACK_HOME' => 'Zur�ck zur Administration - Home', 
           // module loader 
           'LBL_ML_NAME' => 'Name', 
           'LBL_ML_TYPE' => 'Typ', 
           'LBL_ML_VERSION' => 'Version', 
           'LBL_ML_PUBLISHED' => 'Ver�ffentlicht am', 
           'LBL_ML_UNINSTALLABLE' => 'Deinstalliert', 
           'LBL_ML_DESCRIPTION' => 'Beschreibung', 
           'LBL_ML_INSTALLED' => 'Installiert am', 
           'LBL_ML_ACTION' => 'Aktion', 
    
           // htaccess repair 
           'LBL_HT_NO_WRITE' => 'Datei ist schreibgesch�tzt: ', 
           'LBL_HT_NO_WRITE_2' => 'If you want to secure your files from being accessible via browser, create an .htaccess file in your root directory with the lines:', 
           'LBL_HT_DONE' => '--- FERTIG ---', 
    
           // import custom fields 
           'LBL_ICF_IMPORT_S' => 'Struktur importieren', 
           'LBL_ICF_DROPPING' => 'Die Metadaten der benutzerdefinierten Felder werden verworfen', 
           'LBL_ICF_ADDING' => 'Adding Custom Field Meta Data Information - ', 
    
           'LBL_GO' => 'Start', 
           'LBL_PROXY_TITLE'=>'Proxy Einstellungen', 
           'LBL_PROXY_ON'=>'Proxy aktivieren?', 
           'LBL_PROXY_ON_DESC'=>'Einen Proxy Server verwenden um Zugang zu externen Resourcen (wie beispielsweise Sugar - Updates) zu erhalten.', 
           'LBL_PROXY_HOST'=>'Proxy Host', 
           'LBL_PROXY_PORT'=>'Port', 
           'LBL_PROXY_AUTH'=>'Authentifizierung?', 
           'LBL_PROXY_USERNAME'=>'User Name', 
           'LBL_PROXY_PASSWORD'=>'Passwort', 
           'LBL_GLOBAL_TEAM_DESC' => 'Global sichtbar', 
           'ERR_NOT_FOR_ORACLE'=>'This function not currently implemented for this configuration.', 
           'LBL_IMPORT_VALIDATION_KEY' =>'Import Validation Key', 
           'LBL_EXPORT_DOWNLOAD_KEY' =>'Export Download Key', 
           'LBL_VALIDATION_FILE'=>'Validation Key File', 
           'LBL_AVAILABLE_UPDATES'=>'Verf�gbare Updates', 
           'LBL_UPDATE_DESCRIPTIONS'=>'Beschreibung', 
           
	   
	   'WARN_REPAIR_CONFIG' => 'Warnung: Die config.php Datei muss repariert werden.  Klicken Sie dazu auf den "Reparieren" Link in der Administration.', 
           'WARN_INSTALLER_LOCKED'=>'Warnung: Damit Ihre Daten sicher sind muss das  Installationsscript  in der config.php Datei deaktiviert werden. Setzen Sie \'installer_locked\' auf \'true\'', 
           
	   
	   //Hmmm das betrifft wohl die Professional Version
	   'FATAL_LICENSE_REQUIRED' => "Fatal: Your license key information is required .<br>   Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen to update your license information and restore full functionality.", 
           'FATAL_LICENSE_EXPIRED'=> "Fatal: Your license has expired for more than 30 days", 
           'FATAL_LICENSE_EXPIRED2'=> "Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen to update your license information and restore full functionality.", 
           'ERROR_LICENSE_EXPIRED'=> "Error: Your license expired ", 
           'ERROR_LICENSE_EXPIRED2' => " day(s) ago.   Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen to enter your new license key.  If you do not enter a new license key within 30 days of your license key expiration, you will no longer be able to log into this application.", 
           'WARN_LICENSE_EXPIRED'=> "Notice: Your license expires in ", 
           'WARN_LICENSE_EXPIRED2' =>" day(s). Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen.", 
           'FATAL_VALIDATION_REQUIRED' => "Fatal: Your validation key information is required .<br>   Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen to update your license information and restore full functionality.<br>Either re-save your license information to have it authenticated or export the key and import the validation key. " , 
           'FATAL_VALIDATION_EXPIRED'=> "Fatal: Your validation key has expired for more than 30 days", 
           'FATAL_VALIDATION_EXPIRED2'=> "Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen to update your license information and restore full functionality.", 
           'ERROR_VALIDATION_EXPIRED'=> "Error: Your validation key expired ", 
           'ERROR_VALIDATION_EXPIRED2' => " day(s) ago.   Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a> in the Admin screen to enter your new validation key.  If you do not enter a new validation key within 30 days of your validation key expiration, you will no longer be able to log into this application.", 
           'WARN_VALIDATION_EXPIRED'=> "Notice: Your validation key expires in ", 
           'WARN_VALIDATION_EXPIRED2' =>" day(s). Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen.", 
           'WARN_LICENSE_SEATS'=>  "Warning: User licenses exceeded by ", 
           'WARN_LICENSE_SEATS2' => ".  Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen.", 
           'FATAL_LICENSE_ALTERED' => "Your license has been altered since the last time you were able to validate it. <br> Please go to the <a href='index.php?action=LicenseSettings&module=Administration'>'\"License Management\"</a>  in the Admin screen.", 
           'WARN_UPGRADE' => 'Warning: Please upgrade ', 
           'WARN_UPGRADE2'=>' using the upgrade in the <a href="index.php?module=Administration&action=Upgrade">administration panel</a>', 
           'WARN_UPGRADE_APP'=> "Eine neuere Version der Sugar Suite ist verf�gbar. ", 
           'LBL_REVALIDATE'=>'Re-validate' , 
           'LBL_STATUS'=>'Status ', 
           'LBL_VALIDATION_SUCCESS_DATE'=>'Letze erfolgreiche �berpr�fung: ', 
           'LBL_VALIDATION_FAIL_DATE'=>'Letzte fehlgeschlagene �berpr�fung: ', 
           'LBL_NEVER'=>'Nie', 
           'LBL_MANUAL_VALIDATION'=>'If you experience persistent problems with automatic validation, please check your Proxy configuration in the <a href="index.php?module=Administration&action=ConfigureSettings">Configure Settings</a> admin panel.  If your system environment prohibits your system from communicating to the license validation server through the internet, you should proceed with the <a href="#" onclick="toggleDisplay(\'mainbody\');toggleDisplay(\'manualbody\');">Manual Validation</a> steps. ', 
           'LBL_MANUAL_VALIDATION1'=> 'Step 1: Generate a license key information file by clicking the following button. ', 
           'LBL_MANUAL_VALIDATION2'=> 'Then save the file (sugarkey.lic) on your local file system.', 
           'LBL_MANUAL_VALIDATION3'=> 'Step 2: Transfer the sugarkey.lic file to a system where you can access the internet with a web browser.   <br<br>Go to <a href="http://updates.sugarcrm.com/license">http://updates.sugarcrm.com/license</a>  and submit the sugarkey.lic file.  <br><br>The license validation web site will perform the validation immediately and return you the validation key file (sugarvalidationkey.lic) if the validation is successful.  You browser should prompt you to save the file.  ', 
           'LBL_MANUAL_VALIDATION4'=>'Step 3:  Transfer the validation key file (sugarvalidationkey.lic) back to the SugarCRM system.  Import the validation key using this form below: ', 
           'LBL_MANUAL_VALIDATION5'=> 'After you import the validation key, you have completed the manual validation process.  Your system will update the validation key expiration date, which is the next time you need re-validate.', 
           'LBL_MANUAL_VALIDATION_TXT' => 'Manual Validation', 
           
	   
	   			 'ERROR_MANIFEST_TYPE' => 'in der Manifest Datei muss ein Paket-Typ angegeben sein.', 
           'ERROR_PACKAGE_TYPE' => 'Manifest file specifies an unrecognized package type', 
           'ERROR_VERSION_INCOMPATIBLE' => 'Die hochgeladenen Datei ist nicht midt dieser Version der Sugar Suite kompatibel: ', 
           'ERROR_FLAVOR_INCOMPATIBLE' => 'Die hinaufgeladenen Datei ist nicht mit dieser Sugar Suite Ausgabe (Open Source, Professional, ....) kompatibel: ', 
           'MSG_REBUILD_RELATIONSHIPS' => 'Bitte klicken Sie auf den  <a href="index.php?module=Administration&action=Upgrade">Reparieren</a> Link und dann auf Beziehungen wiederherstellen.', 
           'MSG_REBUILD_EXTENSIONS' => 'Bitte klicken Sie auf den <a href="index.php?module=Administration&action=Upgrade">Reparieren</a> Link und dann auf Erweiterungen wiederherstellen.', 
           'LBL_COULD_NOT_CONNECT'=>'Error: Verbindung mit dem Sugar Server konnte nicht hergestellt werden. Pr�fen Sie Ihre Proxy Einstellungen in den  <a href="index.php?module=Administration&action=ConfigureSysteettings">Systemeinstellungen</a> der Administrationsoberfl�che. Letzter Verbindungsversuch @ ', 
           
 

'LBL_UPTODATE'=>'Sie arbeiten mit der neuesten Version',
'LBL_EMAIL_TITLE' => 'Email',
'LBL_REBUILD' => 'Wiederherstellen',
'LBL_REBUILD_SCHEDULERS_TITLE' => 'Service Pl�ne wiederherstellen',
'LBL_REBUILD_SCHEDULERS_DESC' => 'Wiederherstellen der Serviceplan -Aufgaben l�scht alle vorhandenen Aufgaben und deren Protokollierung.  Alle Serviceplan-Aufgaben der Originalinstalleion werden mit ihren Standardwerten wiederhergestellt.',
'LBL_REBUILD_SCHEDULERS_DESC_SHORT' => 'Standard Serviceplan-Aufgaben wiederherstellen.',
'LBL_REBUILD_SCHEDULERS_DESC_SUCCESS' => 'Standard Serviceplan-Aufgaben wurden wiederhergestellt.',
'LBL_RETURN' => 'Return',

	// diagnostics
	'LBL_CONFIGURATOR_TITLE'=>'Konfiguration',
	'LBL_CONFIGURATOR_DESC'=>'Config.php editieren',
	'LBL_DIAGNOSTIC_TITLE'=>'Analyse',
	'LBL_DIAGNOSTIC_DESC'=>'System Konfiguraton analysieren',
	'LBL_DIAGNOSTIC_CONFIGPHP'=>'SugarCRM config.php',
	'LBL_DIAGNOSTIC_CUSTOMDIR'=>'SugarCRM "Custom" Verzeichnis',
	'LBL_DIAGNOSTIC_PHPINFO'=>'phpinfo()',
	'LBL_DIAGNOSTIC_MYSQLDUMPS'=>'MySQL - Konfiguration Tabellen Dumps',
	'LBL_DIAGNOSTIC_MYSQLSCHEMA'=>'MySQL - Alle Tabellen Schemas',
	'LBL_DIAGNOSTIC_MYSQLINFO'=>'MySQL - Allgemeine Informationen',
	'LBL_DIAGNOSTIC_MD5'=>'MD5 info',
	'LBL_DIAGNOSTIC_FILESMD5'=>'&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;Copy files.md5',
	'LBL_DIAGNOSTIC_CALCMD5'=>'&nbsp;&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;Copy MD5 Calculated array',
	'LBL_DIAGNOSTIC_BLBF'=>'BeanList/BeanFiles files exist',
	'LBL_DIAGNOSTIC_SUGARLOG'=>'SugarCRM Protokolldatei',
	'LBL_DIAGNOSTIC_ACCESS' => 'You must be an administrator to run the diagnostic tool.',
	'LBL_DIAGNOSTIC_BEANLIST_DESC' => 'This information tells us whether or not the beanFiles specified in the beanList actually exists. This can be an issue with an improperly defined module loaded extension.',
	'LBL_DIAGNOSTIC_BEANLIST_GREEN' => 'Vorhandene Dateien sind gr�n gekennzeichnet.',
	'LBL_DIAGNOSTIC_BEANLIST_ORANGE' => 'Nicht indizierte Dateien sind orange gekennzeichnet, k�nnen daher nicht verarbeitet werden.',
	'LBL_DIAGNOSTIC_BEANLIST_RED' => 'Fehlende Dateien sind gr�n gekennzeichnet.',
	'LBL_DIAGNOSTIC_NO_MYSQL' => 'You do not have MySQL. The MySQL functions in have been disabled.',
	'LBL_DIAGNOSTIC_EXECUTING' => 'Analyse wird erstellt...',
	'LBL_DIAGNOSTIC_GETCONFPHP' => 'Verarbeite config.php...',
	'LBL_DIAGNOSTIC_GETCUSTDIR' => 'Verarbeite Custom Verzeichnis...',
	'LBL_DIAGNOSTIC_GETPHPINFO' => 'Verarbeite phpinfo()',
	'LBL_DIAGNOSTIC_GETTING' => 'Arbeite...',
	'LBL_DIAGNOSTIC_GETMYSQLINFO' => 'mysql Info',
	'LBL_DIAGNOSTIC_GETMYSQLTD' => 'mysql Dumps',
	'LBL_DIAGNOSTIC_GETMYSQLTS' => 'mysql Schema',
	'LBL_DIAGNOSTIC_GETMD5INFO' => 'Verarbeite md5 Information...',
	'LBL_DIAGNOSTIC_GETBEANFILES' => 'Pr�fe auf Existenz von bean Dateien...',
	'LBL_DIAGNOSTIC_GETSUGARLOG' => 'Verarbeite sugarcrm.log',
	'LBL_DIAGNOSTIC_DOWNLOADLINK' => 'Analyse-Datei downloaden',
	'LBL_DIAGNOSTIC_DELETELINK' => 'Analyse-Datei l�schen',
	'LBL_DIAGNOSTIC_DONE' => 'Fertig',	
  'LBL_DIAG_EXECUTE_BUTTON' => 'Analyse starten',
  'LBL_DIAG_CANCEL_BUTTON' => 'Abbrechen',
    
    
    
  'LBL_SUGAR_NETWORK_TITLE' => 'Sugar Netzwerk',
	'LBL_SUPPORT_TITLE' => 'Sugar Support Plattform',
	'LBL_SUPPORT' => 'Ihre Plattform f�r technischen Support und mehr',
	'LBL_PLUGINS_TITLE' => 'Sugar Forge',
	'LBL_PLUGINS' => 'Plug-ins und Sugar Erweiterungen laden.',
	'LBL_DOCUMENTATION_TITLE' => 'Online Dokumentation',
	'LBL_DOCUMENTATION' => 'Benutzer- und Administrator Hilfedokumentation',
	'LBL_BACKUP_TITLE' => 'Online Backups',
	'LBL_BACKUP' => 'Backups planen und wiederherstellen.',
	'LBL_USERS_TITLE' => 'User',



);
?>
