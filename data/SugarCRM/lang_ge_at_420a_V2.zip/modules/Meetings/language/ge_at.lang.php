<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.17 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Termine',
  'LBL_MODULE_TITLE' => 'Termine: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche Termin',
  'LBL_LIST_FORM_TITLE' => 'Terminliste',
  'LBL_NEW_FORM_TITLE' => 'Neuer Termin',
  'LBL_SCHEDULING_FORM_TITLE' => 'Zeitplan',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'geh�rt zu',
  'LBL_LIST_DATE' => 'Beginndatum',
  'LBL_LIST_TIME' => 'Beginnzeit',
  'LBL_LIST_CLOSE' => 'Schliessen',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Ort:',
  'LBL_DATE_TIME' => 'Beginndatum & -zeit:',
  'LBL_DATE' => 'Beginndatum:',
  'LBL_TIME' => 'Beginzeit:',
  'LBL_DURATION' => 'Dauer:',
  'LBL_DURATION_HOURS' => 'Dauer Stunden:',
  'LBL_DURATION_MINUTES' => 'Dauer Minuten:',
  'LBL_HOURS_MINS' => '(Stunden/Minuten)',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_MEETING' => 'Termin:',
  'LBL_DESCRIPTION_INFORMATION' => 'Weitere Informationen',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'geplant',
	'LNK_NEW_CALL'=>'Neuer Anruf',
	'LNK_NEW_MEETING'=>'Neuer Termin',
	'LNK_NEW_TASK'=>'Neue Aufgabe',
	'LNK_NEW_NOTE'=>'Neue Notiz oder Attachment',
	'LNK_NEW_EMAIL'=>'Email archivieren',
	'LNK_CALL_LIST'=>'Anrufe',
	'LNK_MEETING_LIST'=>'Termine',
	'LNK_TASK_LIST'=>'Aufgaben',
	'LNK_NOTE_LIST'=>'Notizen',
	'LNK_EMAIL_LIST'=>'Emails',

  'LNK_VIEW_CALENDAR' => 'Heute',
  'ERR_DELETE_RECORD' => 'Termin kann nur bei Angabe einer Datensatznummer gel�scht werden.',
  'NTC_REMOVE_INVITEE' => 'Teilnehmer von Besprechung entfernen?',
  'LBL_INVITEE' => 'Teilnehmer',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',

  'LBL_ADD_INVITEE' => 'Teilnehmer hinzuf�gen',
  'LBL_NAME' => 'Name',
  'LBL_FIRST_NAME' => 'Vorname',
  'LBL_LAST_NAME' => 'Nachname',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Telefon B�ro',
  'LBL_REMINDER' => 'Erinnerung:',
  'LBL_SEND_BUTTON_TITLE'=>'An Teilnehmer senden [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'An Teilnehmer senden',
  'LBL_REMINDER_TIME'=>'Erinnerungszeit',
  'LBL_MODIFIED_BY'=>'ge�ndert von',
  'LBL_CREATED_BY'=>'erstellt durch',
  'LBL_DATE_END'=>'Enddatum',
	
	'LBL_SEARCH_BUTTON'=> 'Suchen',
	'LBL_ADD_BUTTON'=> 'Hinzuf�gen',
	
	'LBL_DEL'=> 'L�schen', 
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Termine', 
	'LBL_LIST_STATUS'=>'Status', 
	'LBL_LIST_DUE_DATE'=>'F�lligkeitsdatum',
	'LBL_LIST_DATE_MODIFIED'=>'ge�ndert am', 
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
	'LBL_USERS_SUBPANEL_TITLE' => 'User', 
	'LBL_HOURS_ABBREV' => 'h', 
	'LBL_MINSS_ABBREV' => 'm', 
     
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Notizen', 
	'LBL_OUTLOOK_ID' => 'Outlook ID', 

);


?>
