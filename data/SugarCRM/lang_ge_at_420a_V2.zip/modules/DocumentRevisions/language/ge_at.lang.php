<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.2 2006/04/01 12:22:06 krokogras Exp $
 * Description:  Defines the Austrian German language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/


$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumentversion',
	
	'LNK_NEW_DOCUMENT' => 'Neues Dokument',
	'LNK_DOCUMENT_LIST'=> 'Dokumentenliste',

	//vardef labels
	'LBL_REVISION_NAME' => 'Versionsnummer',
	'LBL_FILENAME' => 'Dateiname',
	'LBL_MIME' => 'Mime Type',
	'LBL_REVISION' => 'Version',
	'LBL_DOCUMENT' => 'Verkn�pftes Dokument',
	'LBL_LATEST_REVISION' => 'Letzte Version',
	'LBL_CHANGE_LOG'=> '�nderungsprotokoll',
	'LBL_ACTIVE_DATE'=> 'Erscheinungsdatum',
	'LBL_EXPIRATION_DATE' => 'Expiration Date',
	'LBL_FILE_EXTENSION'  => 'Dateierweiterung',
	'LBL_DET_CREATED_BY' => 'angelegt von:',
	'LBL_DET_DATE_CREATED' => 'angelegt am:',
	
	'LBL_DOC_NAME' => 'Dokumentname:',
	'LBL_DOC_VERSION' => 'Version:',
	
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Version',
	'LBL_REV_LIST_ENTERED' => 'angelegt am',
	'LBL_REV_LIST_CREATED' => 'angelegt von',
	'LBL_REV_LIST_LOG'=> '�nderungsprotokoll',
	'LBL_REV_LIST_FILENAME' => 'Dateiname',
	
	'LBL_CURRENT_DOC_VERSION'=> 'Letzte Version:',
	'LBL_CHANGE_LOG'=> '�nderungsprotokoll:',
	'LBL_SEARCH_FORM_TITLE'=> 'Suche Dokument',
	
	//error messages
	'ERR_FILENAME'=> 'Dateiname',
	'ERR_DOC_VERSION'=> 'Dokument Version',
	'ERR_DELETE_CONFIRM'=> 'Diese Dokumentversion l�schen?',
	'ERR_DELETE_LATEST_VERSION'=> 'Sie d�rfen die letzte Version eines Dokuments nicht l�schen.',
);


?>
