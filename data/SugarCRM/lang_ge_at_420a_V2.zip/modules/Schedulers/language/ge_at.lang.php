<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.12 2006/04/01 12:22:06 krokogras Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
global $sugar_config;
    
$mod_strings = array (
// List Labels
'LBL_LIST_JOB_INTERVAL' => 'Intervall:',
'LBL_LIST_LIST_ORDER' => 'Serviceplan:',
'LBL_LIST_NAME' => 'Serviceplan:',
'LBL_LIST_RANGE' => 'Zeitraum:',
'LBL_LIST_REMOVE' => 'Entfernen:',
'LBL_LIST_STATUS' => 'Status:',
'LBL_LIST_TITLE' => 'Servicepl�ne:',
'LBL_LIST_EXECUTE_TIME' => 'N�chste Durchf�hrung:',
// human readable:
'LBL_SUN'		=> 'Sonntag',
'LBL_MON'		=> 'Montag',
'LBL_TUE'		=> 'Dienstag',
'LBL_WED'		=> 'Mittwoch',
'LBL_THU'		=> 'Donnerstag',
'LBL_FRI'		=> 'Freitag',
'LBL_SAT'		=> 'Samstag',
'LBL_ALL'		=> 'T�glich',
'LBL_EVERY_DAY'	=> 'T�glich ',
'LBL_AT_THE'	=> 'Am ',
'LBL_EVERY'		=> 'alle ',
'LBL_FROM'		=> 'von ',
'LBL_ON_THE'	=> 'Am ',
'LBL_RANGE'		=> ' bis ',
'LBL_AT' 		=> ' um ',
'LBL_IN'		=> ' in ',
'LBL_AND'		=> ' und ',
'LBL_MINUTES'	=> ' Minuten ',
'LBL_HOUR'		=> ' Stunden',
'LBL_HOUR_SING'	=> ' Stunde',
'LBL_MONTH'		=> ' Monat',
'LBL_OFTEN'		=> ' So oft wie m�glich.',
'LBL_MIN_MARK'	=> ' minute mark',


// crontabs
'LBL_MINS' => 'Min',
'LBL_HOURS' => 'Std',
'LBL_DAY_OF_MONTH' => 'Tag des Monats',
'LBL_MONTHS' => 'Monate',
'LBL_DAY_OF_WEEK' => 'Wochentage',
'LBL_CRONTAB_EXAMPLES' => 'Oben finden Sie ein Standard crontab Beispiel.',
// Labels
'LBL_ALWAYS' => 'Immer',
'LBL_CATCH_UP' => 'Ausf�hren nach Ausfall',
'LBL_CATCH_UP_WARNING' => 'Uncheck if this Job may take more than a moment to run.',
'LBL_DATE_TIME_END' => 'Enddatum/-zeit',
'LBL_DATE_TIME_START' => 'Startdatum/-zeit',
'LBL_INTERVAL' => 'Intervall',
'LBL_JOB' => 'Aufgabe',
'LBL_LAST_RUN' => 'Letzte Durchf�hrung',
'LBL_MODULE_NAME' => 'Sugar Serviceplan',
'LBL_MODULE_TITLE' => 'Servicepl�ne',
'LBL_NAME' => 'Serviceplan Name',
'LBL_NEVER' => 'Nie',
'LBL_NEW_FORM_TITLE' => 'Neuer Task',
'LBL_PERENNIAL' => 'unbefristet',
'LBL_SEARCH_FORM_TITLE' => 'Suche Task',
'LBL_SCHEDULER' => 'Serviceplan:',
'LBL_STATUS' => 'Status',
'LBL_TIME_FROM' => 'Aktiv von',
'LBL_TIME_TO' => 'Aktiv bis',
'LBL_WARN_CURL_TITLE' => 'cURL Warnung:',
'LBL_WARN_CURL' => 'Warnung:',
'LBL_WARN_NO_CURL' => 'Auf diesem System sind die cURL Libraries nicht aktiviert/kompliert. PHP module (--with-curl=/path/to/curl_library).  Kontaktieren Sie Ihren Administrator um dieses Problem zu beheben.  Ohne  cURL Funktionalit�t k�nnen keine Serviceplan-Aufgaben abarbeiten.',
'LBL_BASIC_OPTIONS' => 'Einfache Einstellungen',
'LBL_ADV_OPTIONS'		=> 'Erweiterte Einstellungen',
'LBL_TOGGLE_ADV' => 'Erweiterte Einstellungen',
'LBL_TOGGLE_BASIC' => 'Einfache Einstellungen',
// Links

'LNK_LIST_SCHEDULER' => 'Servicepl�ne',
'LNK_NEW_SCHEDULER' => 'Neuer Serviceplan',
'LNK_LIST_SCHEDULED' => 'Servicepl�ne',



// Messages
'SOCK_GREETING' => "\nDiese Oberfl�che dient dazu, geplante SugarCRM Service Tasks durchzuf�hren. \n[ Verf�gbare Befehle sind: start|restart|shutdown|status ]\nTo quit, type 'quit'.  To shutdown the service 'shutdown'.\n",
'ERR_DELETE_RECORD' => 'Die Datensatz ID muss angegeben werden, damit der Datensatz gel�scht werden kann.',
'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen?',
'NTC_STATUS' => 'Setzen Sie den Status auf inaktiv damit dieser Task nicht in Auswahllisten aufscheint.',
'NTC_LIST_ORDER' => 'Einstellung der Reihenfolge in welcher dieser Task in Auswahlfeld-Listen erscheinen soll',
'LBL_CRON_INSTRUCTIONS_WINDOWS' => 'Windows Task Planer einrichten:',
'LBL_CRON_INSTRUCTIONS_LINUX' => 'Crontab einrichten:',
'LBL_CRON_LINUX_DESC' => 'F�gen Sie diese Zeile in Ihr  crontab ein: ',
'LBL_CRON_WINDOWS_DESC' => 'Legen Sie eine  batch Datei mit folgenden Kommandozeilen an: ',
'LBL_NO_PHP_CLI' => 'Bei Problemen k�nnen Sie alternativ  wget oder curl verwenden um Ihre Aufgabe zu starten.<br>F�r wget: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;wget --quiet --non-verbose '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1</b><br><br>f�r curl: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;curl --silent '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1', 

// Subpanels
'LBL_JOBS_SUBPANEL_TITLE' => 'Aufgaben Logbuch',
'LBL_EXECUTE_TIME' => 'Verarbeitungszeit',

// _DOM
'scheduler_status_dom' => 
	array (
	'Active' => 'Aktiv',
	'Inactive' => 'Inaktiv',
	),
'scheduler_period_dom' => 
	array (
	'min' => 'Minuten',
	'hour' => 'Stunden',
	),
);

?>
