<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.17 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Zielpersonen',
  'LBL_INVITEE' => 'Verkn�pfte Kontakte',
  'LBL_MODULE_TITLE' => 'Zielpersonen: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Zielpersonen',
  'LBL_LIST_FORM_TITLE' => 'Verteilerliste',
  'LBL_NEW_FORM_TITLE' => 'Neue Zielperson',
  'LBL_PROSPECT' => 'Zielperson:',
  'LBL_BUSINESSCARD' => 'Visitenkarte',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_LIST_PROSPECT_NAME' => 'Zielperson Name',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Email2',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_PROSPECT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'Vorname',
  'LBL_ASSIGNED_TO_NAME'=>'zugewiesen an',
//DONT CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DONT CONVERT
  'LBL_EXISTING_PROSPECT' => 'Es wurde ein existierender Kontakt verwendet',
  'LBL_CREATED_PROSPECT' => 'Es wurde ein neuer Kontakt erstellt',
  'LBL_EXISTING_ACCOUNT' => 'Es wurde ein existierender Kunde verwendet',
  'LBL_CREATED_ACCOUNT' => 'Es wurde ein neuer Kunde erstellt',
  'LBL_CREATED_CALL' => 'Es wurde ein neuer Anruf erstellt',
  'LBL_CREATED_MEETING' => 'Es wurde ein neuer Termin erstellt',
  'LBL_ADDMORE_BUSINESSCARD' => 'Weitere Visitenkarte eingeben',
  'LBL_ADD_BUSINESSCARD' => 'Visitenkarte eingeben',
  'LBL_NAME' => 'Name:',
  'LBL_PROSPECT_NAME' => 'Zielperson Name:',
  'LBL_PROSPECT_INFORMATION' => 'Zielperson Informationen',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_OFFICE_PHONE' => 'Telefon B�ro:',
  'LBL_ACCOUNT_NAME' => 'Kundenname:',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_MOBILE_PHONE' => 'Telefon Mobil:',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Hauptadresse Strasse:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Hauptadresse Stadt:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Hauptadresse Land:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Hauptadresse BL:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Hauptadresse PLZ:',
  'LBL_ALT_ADDRESS_STREET' => 'Zusatzadresse Strasse:',
  'LBL_ALT_ADDRESS_CITY' => 'Zusatzadresse Stadt:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Zusatzadresse Country:',
  'LBL_ALT_ADDRESS_STATE' => 'Zusatzadresse BL:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Zusatzadresse PLZ:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_BIRTHDATE' => 'Geburtstag:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email2:',
  'LBL_ANY_EMAIL' => 'Beliebige Email-Adresse:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Telefon Assistent:',
  'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Hauptadresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Zusatzadresse:',
  'LBL_ANY_ADDRESS' => 'Beliebige Adresse:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Weitere Informationen',
  'LBL_ADDRESS_INFORMATION' => 'Adressangaben',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_PROSPECT_ROLE' => 'Rolle:',
  'LBL_OPP_NAME' => 'Verkaufschance Name:',
  'LBL_IMPORT_VCARD' => 'Importiere vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Beim Importieren einer vCard automatisch neue Zielperson anlegen..',
  'LBL_DUPLICATE' => 'M�glicherweise doppelte Zielperson',
  'MSG_SHOW_DUPLICATES' => 'Ein �hnliche Zielperson ist bereits vorhanden. W�hlen Sie einen bereits existierende Zielperson aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Zielpersonendaten zu verwenden, oder klicken Sie auf Abbrechen..',
  'MSG_DUPLICATE' => 'Ein �hnliche Zielperson ist bereits vorhanden. W�hlen Sie einen bereits existierende Zielperson aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Zielpersonendaten zu verwenden, oder klicken Sie auf Abbrechen..',
  'LNK_PROSPECT_LIST' => 'Zielpersonen',
  'LNK_IMPORT_VCARD' => 'vCard importieren',
  'LNK_NEW_PROSPECT' => 'Neue Zielperson',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_EMAIL' => 'Email archivieren',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
  'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen?',
  'NTC_REMOVE_CONFIRMATION' => 'Kontakt von dieser Anfrage entfernen?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Diesen Kontakt als verkn�pften Kontakt entfernen?',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopiere Hauptadresse nach Zusatzadresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopiere Zusatzadresse nach Hauptadresse',
  'LBL_SALUTATION' => 'Anrede',
  'LBL_SAVE_PROSPECT' => 'Speichere Zielperson',
  'LBL_CREATED_OPPORTUNITY' =>'Es wurde eine neue Verkaufschance erstellt',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Zum Anlegen einer Verkaufschance muss ein Kunde angegeben werden.\n  Bitte w�hlen Sie einen existierenden Kunden oder geben Sie einen neuen Kunden ein.',
  'LNK_SELECT_ACCOUNT' => 'Kunden ausw�hlen',
  'LNK_NEW_PROSPECT' => 'Neue Zielperson',
  'LNK_PROSPECT_LIST' => 'Zielpersonen',  
  'LNK_NEW_CAMPAIGN' => 'Neue Kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagnen',
  'LNK_NEW_PROSPECT_LIST' => 'Neue Verteilerliste',
  'LNK_PROSPECT_LIST_LIST' => 'Verteilerlisten',
  'LNK_IMPORT_PROSPECT' => 'Importiere Zielpersonen',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Ausgew�hlte Zielpersonen �bernehmen',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Ausgew�hlte Zielpersonen �bernehmen',
  'LBL_INVALID_EMAIL'=>'Email-Adresse ung�ltig:',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Zielpersonen',
  
  'LBL_CONVERT_BUTTON_KEY' => 'V', 
  'LBL_CONVERT_BUTTON_TITLE' => 'Zielperson konvertieren', 
  'LBL_CONVERT_BUTTON_LABEL' => 'Zielperson konvertieren', 
  'LBL_CONVERTPROSPECT'=>'Zielperson konvertieren', 
  'LNK_NEW_CONTACT'=>'Neuer Kontakt', 
  'LBL_CREATED_CONTACT'=>"Neuer Kontakt wurde angelegt", 
  'LBL_BACKTO_PROSPECTS'=>'Zur�ck zu Zielpersonen', 
  'LBL_CAMPAIGNS'=>'Kampagnen', 
  'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagnen Protokoll', 
  'LBL_TRACKER_KEY'=>'Tracker Key', 
  'LBL_LEAD_ID'=>'Interessent Id', 
  'LBL_CONVERTED_LEAD'=>'Konvertierter Interessent', 
  'LBL_ACCOUNT_NAME'=>'Kundenname', 
  'LBL_EDIT_ACCOUNT_NAME'=>'Kundenname:', 

);

?>