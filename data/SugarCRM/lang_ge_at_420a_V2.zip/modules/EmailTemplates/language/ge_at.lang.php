<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langat/SugarSuite_Lang_DE_AT/modules/EmailTemplates/language/ge_at.lang.php,v 1.12 2006/04/02 10:20:57 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Email Vorlagen',
  'LBL_MODULE_TITLE' => 'Email Vorlagen: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Email Vorlagen',
  'LBL_LIST_FORM_TITLE' => 'Email Vorlagenliste',
  'LBL_NEW_FORM_TITLE' => 'Neue Email Vorlage',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_DESCRIPTION' => 'Beschreibung',
  'LBL_LIST_DATE_MODIFIED' => 'ge�ndert am:',
  'LBL_NAME' => 'Name:',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_CLOSE' => 'Schliessen:',
  'LBL_RELATED_TO' => 'geh�rt zu:',
  'LBL_BODY' => 'Html Nachricht:',
  'LBL_PUBLISH' => 'Ver�ffentlichen:',
  'LBL_COLON' => ':',

	'LNK_NEW_EMAIL_TEMPLATE'=>'Neue Email Vorlage',
	'LNK_EMAIL_TEMPLATE_LIST'=>'Alle Email Vorlagen',
	'LNK_IMPORT_NOTES'=>'Notizen importieren',
	'LNK_VIEW_CALENDAR' => 'Heute',
	'LNK_CHECK_EMAIL'=>'Pr�fe Email',
	'LNK_NEW_SEND_EMAIL'=>'Neue Email',
	'LNK_ARCHIVED_EMAIL_LIST'=>'Archivierte Emails',
	'LNK_SENT_EMAIL_LIST'=>'Gesendete Emails',
	'LNK_NEW_EMAIL'=>'Email archivieren',
	'LBL_INSERT_VARIABLE'=>'Variable einf�gen:',
	'LBL_INSERT'=>'Einf�gen',
	 
	'LNK_DRAFTS_EMAIL_LIST'=>'Alle Entw�rfe',
	'LNK_ALL_EMAIL_LIST'=>'Alle Emails',
	'LNK_NEW_ARCHIVE_EMAIL'=>'Email archivieren',
	'LBL_CONTACT_AND_OTHERS'=>'Kontakt/Interessent/Zielperson',
	
	'LBL_HTML_BODY'=>'HTML Nachricht', 
	'LBL_TEXT_BODY'=>'Text Nachricht', 
	'LBL_EDIT_ALT_TEXT'=>'Text Nachricht bearbeiten', 
	'LBL_SHOW_ALT_TEXT'=>'Text Nachricht anzeigen', 
          
  
          'LBL_ATTACHMENTS'                       => 'Attachments', 
           'LBL_ADD_FILE'                          => 'Datei hinzuf�gen', 
           'LBL_EMAIL_ATTACHMENT'          => 'Email Attachment', 
           // for Inbox 
           'LNK_MY_INBOX'                          => 'Mein Posteingang', 
           'LNK_GROUP_INBOX'                       => 'Gruppen Posteing.', 
           'LNK_MY_DRAFTS'                         => 'Meine Entw�rfe', 
           'LBL_NEW'                                       => 'Neu', 
           
           	'LNK_CHECK_MY_INBOX'		=> 'Meine Emails abrufen',
						'LNK_MY_ARCHIVED_LIST'		=> 'Meine Archive',
           
'LBL_ADD_ANOTHER_FILE'		=> 'Weitere Datei hinzuf�gen',
	'LBL_ADD_DOCUMENT'			=> 'Sugar Dokument hinzuf�gen',

	'LBL_INSERT_URL_REF'		=> 'URL Referenz einf�gen',
	'LBL_INSERT_TRACKER_URL'	=> 'Tracker URL einf�gen:',	
	'LBL_TEAM'					=> 'Team:',
	'LBL_TEAMS_LINK'			=> 'Team',
	'LBL_DEFAULT_LINK_TEXT'		=> 'Standard Link Text.'


);


?>
