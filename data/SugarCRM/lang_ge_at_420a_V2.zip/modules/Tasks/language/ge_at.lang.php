<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.9 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aufgaben',
  'LBL_TASK' => 'Aufgaben: ',
  'LBL_MODULE_TITLE' => ' Aufgaben: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Aufgaben',
  'LBL_LIST_FORM_TITLE' => 'Aufgaben - Liste',
  'LBL_NEW_FORM_TITLE' => 'Neue Aufgabe',
  'LBL_NEW_FORM_SUBJECT' => 'Betreff:',
  'LBL_NEW_FORM_DUE_DATE' => 'F�lligkeitsdatum:',
  'LBL_NEW_FORM_DUE_TIME' => 'F�lligkeitszeit:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Schliessen',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_PRIORITY' => 'Priorit�t',
  'LBL_LIST_RELATED_TO' => 'geh�rt zu',
  'LBL_LIST_DUE_DATE' => 'F�lligkeitsdatum',
  'LBL_LIST_DUE_TIME' => 'F�lligkeitszeit',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_STATUS' => 'Status:',
  'LBL_DUE_DATE' => 'F�lligkeitsdatum:',
  'LBL_DUE_TIME' => 'F�lligkeitszeit:',
  'LBL_PRIORITY' => 'Priorit�t:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'F�lligkeitsdatum & -zeit:',
  'LBL_START_DATE_AND_TIME' => 'Beginndatum/-zeit:',
  'LBL_START_DATE' => 'Beginndatum:',
  'LBL_START_TIME' => 'Beginnzeit:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'keine',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Weitere Informationen',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_NAME' => 'Betreff:',
  'LBL_CONTACT_NAME' => 'Kontakt: ',
  'LBL_LIST_COMPLETE' => 'Fertig:',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_DATE_DUE_FLAG' => 'Kein F�lligkeitsdatum',
  'LBL_DATE_START_FLAG' => 'kein Beginndatum',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'ERR_INVALID_HOUR' => 'Bitte eine Stunde zwischen 0 und 24 angeben',
  'LBL_DEFAULT_STATUS' => 'Nicht begonnen',
  'LBL_DEFAULT_PRIORITY' => 'Medium',
  'LBL_LIST_MY_TASKS' => 'Meine offenen Aufgaben',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
  'LNK_NEW_EMAIL' => 'Email archivieren',
  'LNK_CALL_LIST' => 'Anrufe',
  'LNK_MEETING_LIST' => 'Termine',
  'LNK_TASK_LIST' => 'Aufgaben',
  'LNK_NOTE_LIST' => 'Notizen',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Heute',
  'LBL_CONTACT_FIRST_NAME'=>'Kontakt Vorname',
  'LBL_CONTACT_LAST_NAME'=>'Kontakt Nachname',
);


?>
