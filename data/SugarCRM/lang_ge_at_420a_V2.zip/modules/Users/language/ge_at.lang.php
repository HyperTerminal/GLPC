<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.21 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'User',
  'LBL_MODULE_TITLE' => 'User: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: User',
  'LBL_LIST_FORM_TITLE' => 'User',
  'LBL_NEW_FORM_TITLE' => 'Neuer User',
  'LBL_USER' => 'User:',
  'LBL_LOGIN'=> 'User Name',
  'LBL_RESET_PREFERENCES' => 'Standardeinstellungen wiederherstellen',
  'LBL_TIME_FORMAT' => 'Zeitformat:',
  'LBL_DATE_FORMAT' => 'Datumsformat:',
  'LBL_TIMEZONE' => 'Zeitzone:',
  
  'LBL_CURRENCY' => 'W�hrung:',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_LIST_USER_NAME' => 'User Name',
  'LBL_LIST_DEPARTMENT' => 'Abteilung',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Telefon B�ro:',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Neuer User [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Neuer User',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fehler:',
  'LBL_PASSWORD' => 'Passwort:',
  'LBL_USER_NAME' => 'User Name:',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_USER_SETTINGS' => 'User Einstellungen',
  'LBL_THEME' => 'Skin:',
  'LBL_LANGUAGE' => 'Sprache:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_USER_INFORMATION' => 'Mitarbeiter Informationen',
  'LBL_OFFICE_PHONE' => 'Telefon B�ro:',
  'LBL_REPORTS_TO' => 'Berichte an:',
  'LBL_REPORTS_TO_NAME' => 'Berichte an:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_OTHER_EMAIL' => 'Email2:',
  'LBL_NOTES' => 'Notizen:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_STATUS' => 'Status:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_ANY_EMAIL' => 'Beliebige Email-Adresse:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Name:',
  'LBL_MOBILE_PHONE' => 'Telefon Mobil:',
  'LBL_OTHER' => 'Pager:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMAIL_OTHER' => 'Email 2:',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_ADDRESS_INFORMATION' => 'Adressangaben',
  'LBL_PRIMARY_ADDRESS' => 'Anschrift:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Passwort �ndern [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Passwort �ndern',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Passwort �ndern',
  'LBL_OLD_PASSWORD' => 'Altes Passwort:',
  'LBL_NEW_PASSWORD' => 'Neues Passwort:',
  'LBL_CONFIRM_PASSWORD' => 'Passwort best�tigen:',
  'LBL_EMPLOYEE_STATUS' => 'Mitarbeiter Status:',
  'LBL_MESSENGER_TYPE' => 'IM Type:',
  'LBL_MESSENGER_ID' => 'IM Name:',
  'ERR_ENTER_OLD_PASSWORD' => 'Bitte geben Sie Ihr altes Passwort ein.',
  'ERR_ENTER_NEW_PASSWORD' => 'Bitte geben Sie Ihr neues Passwort ein.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Bitte best�tigen Sie Ihr Passwort.',
  'ERR_REENTER_PASSWORDS' => 'Bitte wiederholen Sie die Passworteingabe.  Die \\"neue Passwort\\" und  \\"Passwort best�tigen\\" Eingaben stimmen nicht �berein.',
  'ERR_INVALID_PASSWORD' => 'Sie m�ssen einen g�ltigen Usernamen und ein g�ltiges Passwort eingeben.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'User Passwort �nderung fehlgeschlagen f�r ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' fehlgeschlagen.  Das neue Passwort muss eingegeben werden.',
  //'ERR_PASSWORD_INCORRECT_OLD' => 'Falsches altes Passwort f�r User $this->user_name. Geben Sie das richtige alte Passwort ein.',
  'ERR_USER_NAME_EXISTS_1' => 'Der Username ',
  'ERR_USER_NAME_EXISTS_2' => ' existiert bereits.  Usernamen m�ssen eindeutig sein.  �ndern Sie den Usernamen.',
  'ERR_LAST_ADMIN_1' => 'Der User namens "',
  'ERR_LAST_ADMIN_2' => '" ist der letzte User mit Administratorrechten.  Mindestens ein User muss Administrator bleiben.',
  'LNK_NEW_USER' => 'Neuer User',
  'LNK_USER_LIST' => 'Userliste',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Zuweisungsverst�ndigung:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Email Verst�ndigung absenden, wenn ein Datensatz an Sie zugewiesen wird.',
  'LBL_ADMIN_TEXT' => 'Diesem User Administrator Rechte zuweisen',
  'LBL_PORTAL_ONLY' => 'Nur Portal User:',
  'LBL_PORTAL_ONLY_TEXT' => 'Nur Portal User: Dieser User kann nicht ins SugarCRM Web Interface einloggen. Dieser User hat nur Zugang zu Portal Webservices.',
  'LBL_TIME_FORMAT_TEXT' => 'Zeitformat einstellen',
  'LBL_DATE_FORMAT_TEXT' => 'Datumsformat  einstellen',
  'LBL_TIMEZONE_TEXT' => 'Passende Zeitzone einstellen',
  'LBL_TIMEZONE_DST_TEXT' => 'Sommerzeit �berwachen',
  'LBL_GRIDLINE' => 'Gitterlinien anzeigen:',
  'LBL_GRIDLINE_TEXT' => 'Gitterlinien in Detailansichten anzeigen',
  'LBL_CURRENCY_TEXT' => 'Standardw�hrung angeben',
  'LBL_DISPLAY_TABS'=>'Anzeigen',
  'LBL_HIDE_TABS'=>'Verstecken',
  'LBL_EDIT_TABS'=>'Register bearbeiten',
  'LBL_REMOVED_TABS'=>'Vom Admin entfernte Register',
  'LBL_CHOOSE_WHICH'=>'W�hlen Sie aus, welche Register angezeigt werden sollen',


  'LBL_MAIL_OPTIONS_TITLE' => 'E-mail Optionen',
  'LBL_MAIL_FROMNAME' => '"Von" Angezeigter Name:',
  'LBL_MAIL_FROMADDRESS' => '"Von" Emailadresse:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
  'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP Username:',
  'LBL_MAIL_SMTPPASS' => 'SMTP Passwort:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'SMTP Authentifizierung verwenden?',
  'LBL_CALENDAR_OPTIONS'=>'Kalender Optionen',
  'LBL_PUBLISH_KEY'=>'Ver�ffentlichungs Schl�ssel:',
  'LBL_CHOOSE_A_KEY'=>'W�hlen Sie einen Schl�ssel um unautorisierte Ver�ffentlichung Ihres Kalenders zu verhindern',
  'LBL_YOUR_PUBLISH_URL'=>'Publish at my location:',
  'LBL_YOUR_QUERY_URL'=>'Your Query URL:',
  'LBL_REMINDER'=>'Standard Erinnerung:',
  'LBL_REMINDER_TEXT'=>'Standardm��ige Zeitspanne zur Erinnerung an f�llige Anrufe oder Termine',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Ausgew�hlte User �bernehmen',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Ausgew�hlte User �bernehmen',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_MAX_TAB' => 'Anzahl der maximal angezeigten Register:',
	'LBL_SEARCH_URL'=>'Suchlocation:',
	
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'User',
  'LBL_ADDRESS_STREET' => 'Strasse:',
  'LBL_ADDRESS_CITY' => 'Stadt:',
  'LBL_ADDRESS_COUNTRY' => 'Land:',
  'LBL_ADDRESS_STATE' => 'BL:',
  'LBL_ADDRESS_POSTALCODE' => 'PLZ:',
  'LBL_OFFICE_PHONE' => 'Telefon B�ro:',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_MOBILE_PHONE' => 'Telefon Mobil:',
  'LBL_WORK_PHONE' => 'Telefon B�ro:',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_IS_ADMIN' => 'Ist Administrator',
  

  
'LBL_LIST_ACCEPT_STATUS' => 'Annahmestatus',
'LBL_TIMEZONE_DST' => 'Sommerzeit:',
'ERR_PASSWORD_INCORRECT_OLD_1' => 'Falsches altes Passwort f�r User ', 
'ERR_PASSWORD_INCORRECT_OLD_2' => '. Geben Sie das Passwort  nochmals ein.', 
'ERR_REPORT_LOOP' => 'Das System hat eine Berichtschleife festgestellt. Ein User kann nicht an sich selbst berichten, ein Manager kann nicht an seine Mitarbeiter berichten.',
'LBL_ROLES_SUBPANEL_TITLE'=>'Rollen', 
//'LBL_PICK_TZ' => 'Bitte w�hlen Sie Ihre Zeitzone. Sie erhalten diese Aufforderung nur einmal. Sie k�nnen diese Einstellung aber jederzeit unter "Meine Einstellungen" �ndern.', 
'LBL_DST_INSTRUCTIONS' => '(+DST) Sommerzeiteinstellungen werden ber�cksichtigt', 
'LBL_GROUP' => 'Gruppen User:', 
'LBL_LIST_GROUP' => 'Gruppe', 

'LBL_GROUP_DESC' => 'Gruppen-User.  Dieser User kann sich nicht ins Sugar Suite Webinterface einloggen. Dieser User wird dazu verwendet, beim Email-Empfang Emails einer Gruppe zuzuweisen.', 

'LBL_GROUP_USER_STATUS' => 'Gruppen User', 
'LBL_MAILMERGE' => 'Serienbrief:', 
'LBL_MAILMERGE_TEXT' => 'Serienbrief-Funktionalit�t aktivieren. (Diese Funktion mus auch vom Systemadministrator freigeschaltet werden.)', 
'LBL_SETTINGS_URL' => 'URL:', 
'LBL_SETTINGS_URL_DESC' => 'Verwemdem Sie diese URL wenn Sie die Log-In Einstellungen im Sugar Plug-in f�r Microsoft Outlook und im Sugar Plug-in f�r Microsoft Word eingeben.', 
'LBL_PROMPT_TIMEZONE' => 'Zeitzonenpr�fung:', 
'LBL_PROMPT_TIMEZONE_TEXT' => 'User beim Einloggen zum Best�tigen der Zeitzone auffordern.', 
 



'ERR_EMAIL_NO_OPTS'					=> 'Optimale Einstellungen f�r Email-Posteingang konnte nicht ermittelt werden.',
	'ERR_IE_FAILURE1'					=> '[Zur�ck]',
	'ERR_IE_FAILURE2'					=> 'Verbindung zum Emailkonto fehlgeschlagen.  Pr�fen Sie Ihre Einstellungen und versuchen Sie es nochmals.',
	'ERR_PASSWORD_MISMATCH'				=> 'Die Passw�rter stimmen nicht �berein.',
	'LBL_BUTTON_CREATE'					=> 'Neu',
	'LBL_BUTTON_EDIT'					=> 'Bearbeiten',
	'LBL_NUMBER_GROUPING_SEP'			=> '1000-er Trennzeichen',
	'LBL_NUMBER_GROUPING_SEP_TEXT'		=> 'Verwendetes Tausender-Trennzeichen',
		'LBL_DECIMAL_SEP'					=> 'Decimalzeichen',
	'LBL_DECIMAL_SEP_TEXT'				=> 'Verwendetes Dezimalzeichen',
'LBL_EDIT'							=> 'Bearbeiten',
	'LBL_EMAIL_EDITOR_OPTION'			=> 'Email Format',
	'LBL_EMAIL_LINK_TYPE'				=> 'Email Client',
	'LBL_EMAIL_SHOW_COUNTS'				=> 'Emails z�hlen?',
	'LBL_EMAIL_SIGNATURE_ERROR1'		=> 'Die Signatur ben�tigt eine Bezeichnung.',
	'LBL_INBOUND_TITLE'					=> 'Kontoeinstellungen',
'LBL_LIST_MEMBERSHIP'				=> 'Mitgliedschaft',
'LBL_NEW_PASSWORD1'					=> 'Passwort',
	'LBL_NEW_PASSWORD2'					=> 'Passwort best�tigen',

	'LBL_PICK_TZ_WELCOME'				=> 'Willkommen.',
	'LBL_PICK_TZ_DESCRIPTION'           => 'Bitte w�hlen Sie Ihre Zeitzone aus der Liste unten. Sie k�nnen diese Einstellung sp�ter unter  "Meine Einstellungen" �ndern.',

	'LBL_SIGNATURE'						=> 'Signatur',
	'LBL_SIGNATURE_HTML'				=> 'HTML Signatur',
	'LBL_SIGNATURE_DEFAULT'				=> 'Signatur verwenden?',
	'LBL_SIGNATURE_PREPEND'				=> 'Signatur beim Antworten?',
	'LBL_SIGNATURES'					=> 'Signaturen:',
	'LBL_TAB_TITLE_EMAIL'				=> 'Email Einstellungen',
	'LBL_TAB_TITLE_USER'				=> 'User Einstellungen',


	'LBL_BASIC'							=> 'Maileingang Setup',
	'LBL_CERT_DESC'						=> 'Verpflichtende �berpr�fung des Mail Server Zertifikats - selbstsignierende Zertifikate nicht zulassen.',
	'LBL_CERT'							=> 'Zertifikat pr�fen',
	'LBL_FIND_OPTIMUM_KEY'				=> 'f',
	'LBL_FIND_OPTIMUM_MSG'				=> '<br>Ermittelt die optimalen Verbindungseinstellungen.',
	'LBL_FIND_OPTIMUM_TITLE'			=> 'Optimalkonfiguration ermitteln',
	'LBL_FORCE'							=> 'Force Negative',
	'LBL_FORCE_DESC'					=> 'Some IMAP/POP3 servers require special switches. Check to force a negative switch when connecting (i.e., /notls)',
	'LBL_FOUND_OPTIMUM_MSG'				=> '<br>Found optimum settings.	Press the button below to apply them to your Mailbox.',
	'LBL_EMAIL_INBOUND_TITLE'			=> 'Email Posteingang Einstellungen',
	'LBL_EMAIL_OUTBOUND_TITLE'			=> 'Email Postausgang Einstellungen',
	
	'LBL_MAILBOX_DEFAULT'				=> 'INBOX',
	'LBL_MAILBOX_SSL_DESC'				=> 'SSL beim Verbindungsaufbau verwenden. Bei Fehlern pr�fen, ob Ihre PHP Konfiguration "--with-imap-ssl" inkludiert.',
	'LBL_MAILBOX'						=> '�berwachte Ordner',
	'LBL_MAILBOX_TYPE'					=> 'M�gliche Aktionen',
	'LBL_MARK_READ_NO'					=> 'Nachricht wird nach dem Import am Server als gel�scht markiert',
	'LBL_MARK_READ_YES'					=> 'Nachricht wird nach dem Import am Server belassen',
	'LBL_MARK_READ_DESC'				=> 'Nachrichten nach Import am Server  als gelesen markieren; nicht l�schen.',
	'LBL_MARK_READ'						=> 'Nachrichten am Server belassen',
	
	'LBL_ONLY_SINCE_NO'		=> 'Nein. Pr�fe alle Nachrichten am Server.',
	'LBL_ONLY_SINCE_YES'				=> 'Ja.',
	'LBL_ONLY_SINCE_DESC'		=> 'Bei der Verwendung des POP3 Protokolls kann nicht zwischen nach neuen, ungelesenen Nachrichten gefiltert werden. Diese Einstellung erm�glicht die �berpr�fung auf neue Nachrichten seit dem letztem Abruf der Mailbox unter POP3 und erh�ht damit die Performance falls Ihr Mailserver IMAP nicht unterst�tzt.', 

	

	
	
	
	
	'LBL_ONLY_SINCE'					=> 'Nur seit letzter Abrage importieren',
	'LBL_PORT'							=> 'Mailserver Port',
	'LBL_SERVER_OPTIONS'				=> 'Erweiterte Einstellungen',
	'LBL_SERVER_TYPE'					=> 'Mailserver Protokoll',
	'LBL_SERVER_URL'					=> 'Mailserver Adresse',
	'LBL_SSL'							=> 'SSL verwenden',
	'LBL_SSL_DESC'						=> 'Wenn Ihr Mailserver Secure Socket Connections unterst�tzt, wird beim Importieren der Nachrichten SSL verwendet..',
	'LBL_TEST_BUTTON_KEY'				=> 't',
	'LBL_TEST_BUTTON_TITLE'				=> 'Test [Alt+T]',
	'LBL_TEST_SETTINGS'					=> 'Einstellungen testen',
	'LBL_TEST_SUCCESSFUL'				=> 'Verbindung erfolgreich erstellt.',
	'LBL_TLS_DESC'			=> 'Transport Layer Security Protokoll verwenden - verwenden Sie dieses Protokoll nur, wenn es vom Mailserver unterst�tzt wird.',
	'LBL_TLS'							=> 'TLS verwenden',
	'LBL_TOGGLE_ADV'					=> 'Erweiterte Einstellungen',
	
	'LBL_APPLY_OPTIMUMS'						=> 'Optimaleinstellungen anwenden',
	'LBL_ASSIGN_TO_USER'				=> 'an User zuweisen',

);


?>
