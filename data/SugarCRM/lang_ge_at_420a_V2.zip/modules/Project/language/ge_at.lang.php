<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/**
 * Austrian German language strings
 
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: ge_at.lang.php,v 1.7 2006/02/05 00:35:14 krokogras Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projekt',
	'LBL_MODULE_TITLE' => 'Projekte: Home',
	'LBL_SEARCH_FORM_TITLE' => 'Suche: Projekt',
  'LBL_LIST_FORM_TITLE' => 'Projektliste',
	'LBL_HISTORY_TITLE' => 'Verlauf',
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'erstellt am:',
	'LBL_DATE_MODIFIED' => 'ge�ndert am:',
	'LBL_ASSIGNED_USER_ID' => 'Bearbeitung durch:',
	'LBL_MODIFIED_USER_ID' => 'ge�ndert von:',
	'LBL_CREATED_BY' => 'erstellt von:',
	'LBL_TEAM_ID' => 'Team:',
	'LBL_NAME' => 'Name:',
	'LBL_DESCRIPTION' => 'Beschreibung:',
	'LBL_DELETED' => 'Gel�scht:',

	'LBL_TOTAL_ESTIMATED_EFFORT' => 'Gesch�tzter Aufwand (Std.):',
	'LBL_TOTAL_ACTUAL_EFFORT' => 'Tats�chlicher Aufwand (Std.):',

	'LBL_LIST_NAME' => 'Name',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Bearbeitung durch',
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Gesch�tzter Aufwand (Std.)',
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Tats�chlicher Aufwand (Std.)',

	'LBL_PROJECT_SUBPANEL_TITLE' => 'Projekte',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Projektaufgaben',
	'LBL_CONTACT_SUBPANEL_TITLE' => 'Kontakte',
	'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Kunden',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Verkaufschancen',
	'LBL_QUOTE_SUBPANEL_TITLE' => 'Angebote',

	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Diesen Kontakt vom Projekt entfernen?',

	'LNK_NEW_PROJECT'	=> 'Neues Projekt',
	'LNK_PROJECT_LIST'	=> 'Projektliste',
	'LNK_NEW_PROJECT_TASK'	=> 'Neue Projektaufgabe',
	'LNK_PROJECT_TASK_LIST'	=> 'Projektaufgaben',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projekte', 
  'LBL_ACTIVITIES_TITLE'=>'Aktivit�ten', 
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
	'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Projektaufgaben', 
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Kunden', 
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Verkaufschancen', 
	'LBL_QUICK_NEW_PROJECT' => 'Neues Projekt',


	
	
);
?>
