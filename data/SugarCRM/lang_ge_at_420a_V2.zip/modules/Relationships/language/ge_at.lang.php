<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
 /*********************************************************************************
 * $Id: ge_at.lang.php,v 1.5 2006/02/06 01:03:43 krokogras Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/


$mod_strings = array (
  'LBL_ID' => 'Beziehung Id',
  'LBL_RELATIONSHIP_NAME' => 'Beziehung Name',
  'LBL_LHS_MODULE' => 'LHS Modul Name',
  'LBL_LHS_TABLE' => 'LHS Tabellen Name',
  'LBL_LHS_KEY' => 'LHS Schl�ssel Name',
  'LBL_RHS_MODULE' => 'RHS Modul Name',
  'LBL_RHS_TABLE' => 'RHS Tabellen Name',
  'LBL_RHS_KEY' => 'RHS Schl�ssel Name',
  'LBL_JOIN_TABLE' => 'Verkn�pfte Tabelle',
  'LBL_JOIN_KEY_LHS' => 'Verkn�pfungsschl�ssel LHS',
  'LBL_JOIN_KEY_RHS' => 'Verkn�pfungsschl�ssel RHS',
  'LBL_RELATIONSHIP_TYPE' => 'Beziehung Typ',
  //pr�fen
  'LBL_RELATIONSHIP_ROLE_COLUMN' => 'Beziehung Rolle-Spaltenname',
  'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE' => 'Beziehung Rolle-Spaltenwert',
  'LBL_REVERSE' => 'Reversiv' ,
  'LBL_DELETED' => 'Gel�scht',
);
  
?>
