<?php
 if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.18 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kampagnen',
  'LBL_MODULE_TITLE' => 'Kampagnen: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Kampagne',
  'LBL_LIST_FORM_TITLE' => 'Kampagnen - Liste',
  'LBL_CAMPAIGN_NAME' => 'Name:',
  'LBL_CAMPAIGN' => 'Kampagne:',
  'LBL_NAME' => 'Name: ',
  'LBL_INVITEE' => 'Kontakte',
  'LBL_LIST_CAMPAIGN_NAME' => 'Kampagne',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_TYPE' => 'Typ',
  'LBL_LIST_END_DATE' => 'Abschlussdatum',
  'LBL_DATE_ENTERED' => 'erstellt am',
  'LBL_DATE_MODIFIED' => 'ge�ndert am',
  'LBL_MODIFIED' => 'ge�ndert von:',
  'LBL_CREATED' => 'erstellt von: ',
  'LBL_TEAM' => 'Team: ',
  'LBL_ASSIGNED_TO' => 'Bearbeitung durch: ',
  'LBL_CAMPAIGN_START_DATE' => 'Beginndatum:',
  'LBL_CAMPAIGN_END_DATE' => 'Abschlussdatum: ',
  'LBL_CAMPAIGN_STATUS' => 'Status: ',
  'LBL_CAMPAIGN_BUDGET' => 'Budget: ',
  'LBL_CAMPAIGN_EXPECTED_COST' => 'Erwartete Kosten:',
  'LBL_CAMPAIGN_ACTUAL_COST' => 'Tats�chliche Kosten: ',
  'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Erwarteter Umsatz: ',
  'LBL_CAMPAIGN_TYPE' => 'Typ: ',
  'LBL_CAMPAIGN_OBJECTIVE' => 'Zielsetzung: ',
  'LBL_CAMPAIGN_CONTENT' => 'Beschreibung: ',
  'LNK_NEW_CAMPAIGN' => 'Neue Kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagnen',
  'LNK_NEW_PROSPECT' => 'Neue Zielperson',
  'LNK_PROSPECT_LIST' => 'Zielpersonen',
  'LNK_NEW_PROSPECT_LIST' => 'Neue Verteilerliste',
  'LNK_PROSPECT_LIST_LIST' => 'Verteilerlisten',
  'LBL_MODIFIED_BY' => 'ge�ndert von: ',
  'LBL_CREATED_BY' => 'erstellt von: ',
  'LBL_DATE_CREATED' => 'erstellt am: ',
  'LBL_DATE_LAST_MODIFIED' => 'ge�ndert am: ',
  'LBL_TRACKER_KEY' => 'Tracker: ',
  'LBL_TRACKER_URL' => 'Tracker URL: ',
  'LBL_TRACKER_TEXT' => 'Tracker Link Text: ',
  'LBL_TRACKER_COUNT' => 'Tracker Count: ',
  'LBL_REFER_URL' => 'Tracker Redirect URL: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kampagnen', 
  'LBL_EMAIL_CAMPAIGNS_TITLE' =>'Email Kampagnen', 
  'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => 'Verteilerliste', 
  'LBL_EMAIL_MARKETING_SUBPANEL_TITLE' => 'Email-Aussendungen', 
 
     'LBL_NEW_FORM_TITLE' => 'Neue Kampagne',
     'LNK_NEW_EMAIL_TEMPLATE' => 'Neue Email Vorlage', 
     'LNK_EMAIL_TEMPLATE_LIST' => 'Alle Email Vorlagen', 
     'LBL_TRACK_BUTTON_TITLE' =>'Status anzeigen', 
     'LBL_TRACK_BUTTON_KEY' =>'T', 
     'LBL_TRACK_BUTTON_LABEL' =>'Status anzeigen', 
     'LBL_QUEUE_BUTTON_TITLE'=>'Emails senden', 
     'LBL_QUEUE_BUTTON_KEY'=>'u', 
     'LBL_QUEUE_BUTTON_LABEL'=>'Emails senden', 
     'LBL_TEST_BUTTON_TITLE'=>'Testen', 
     'LBL_TEST_BUTTON_KEY'=>'e', 
     'LBL_TEST_BUTTON_LABEL'=>'Testen', 
    
     'LBL_TODETAIL_BUTTON_TITLE'=>'Details anzeigen', 
     'LBL_TODETAIL_BUTTON_KEY'=>'T', 
     'LBL_TODETAIL_BUTTON_LABEL'=>'Details anzeigen', 
 
     
     
     'LBL_DEFAULT'=>'Alle Verteilerlisten', 
     'LBL_MESSAGE_QUEUE_TITLE'=>'Warteschlangen', 
     'LBL_LOG_ENTRIES_TITLE'=>'Reaktionen', 
     
 
    
     'LBL_LOG_ENTRIES_TARGETED_TITLE'=>'Email gesendet/Sendeversuch', 
     'LBL_LOG_ENTRIES_SEND_ERROR_TITLE'=>'Bounced Email, andere Ursache', 
     'LBL_LOG_ENTRIES_INVALID_EMAIL_TITLE'=>'Bounced Email, ung�ltige Email Adresse', 
     'LBL_LOG_ENTRIES_LINK_TITLE'=>'hat auf Link geklickt', 
     'LBL_LOG_ENTRIES_VIEWED_TITLE'=>'hat Message gelesen', 
     'LBL_LOG_ENTRIES_REMOVED_TITLE'=>'hat sich ausgetragen', 
     'LBL_LOG_ENTRIES_LEAD_TITLE'=>'Interessent wurde angelegt', 
     'LBL_LOG_ENTRIES_CONTACT_TITLE'=>'Kontakt wurde angelegt', 
    
     'LBL_BACK_TO_CAMPAIGNS'=>'Back to Campaigns', 
     //error messages. 
     'ERR_NO_EMAIL_MARKETING'=>'Es muss mindestens eine aktive Email-Aussendung mit der Kampagne verkn�ft sein.', 
     'ERR_NO_TARGET_LISTS'=>'Es muss mindestens eine Verteilerliste mit der Kampagne verkn�pft sein.', 
     'ERR_NO_TEST_TARGET_LISTS'=>'Es muss mindestes ein Verteilerliste des Typs Test mit der Kampagne verkn�pft sein.', 
     'ERR_SENDING_NOW'=>'Messages are being delivered , please try this later.', 
     'ERR_MESS_NOT_FOUND_FOR_LIST'=>'Keine Email-Aussendung f�r diese Verteilerliste gefunden', 
     'ERR_MESS_DUPLICATE_FOR_LIST'=>'Mehrere Email-Aussendungen wurden f�r diese Verteilerliste definiert', 
     'ERR_FIX_MESSAGES'=>'Bitte korrigieren Sie folgende Fehler:', 
    
     'LBL_TRACK_DELETE_BUTTON_KEY'=>'D', 
     'LBL_TRACK_DELETE_BUTTON_TITLE'=>'Test Eintr�ge l�schen', 
     'LBL_TRACK_DELETE_BUTTON_LABEL'=>'Test Eintr�ge l�schen', 
     'LBL_TRACK_DELETE_CONFIRM'=>'Eintr�ge im Logbuch welche durch den Testlauf erzeugt wurden werden gel�scht. Fortfahren?', 
     'ERR_NO_MAILBOX'=>"Den folgenden Email-Aussendungen wurde keine Mailbox (zur Verarbeitung der Bounces) zugewiesen.<BR>Bitte korrigieren Sie diesen Fehler.", 
     'LBL_LIST_TO_ACTIVITY'=>'Status anzeigen', 
     
      'LBL_CURRENCY_ID'=>'W�hrungs ID',
      'LBL_CURRENCY'=>'W�hrung',
      'LBL_TRACKED_URLS'=>'Tracker URLs',
      'LBL_TRACKED_URLS_SUBPANEL_TITLE'=>'Tracker URLs',


);


?>
