<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.7 2006/04/01 08:19:05 krokogras Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
        
   	
	'ERR_NO_OPPS' => 'Bitte geben Sie einige  Verkaufschancen ein um Verkaufschancen-Graphiken darzustellen.',
	'LBL_ALL_OPPORTUNITIES' => 'Gesamtumsatz aller Verkaufschancen ist ',
	'LBL_CREATED_ON' => 'Abfrage um:',
	'LBL_DATE_END' => 'Abschlussdatum:', 
	
	
	'LBL_DATE_RANGE_TO' => 'bis',
	'LBL_DATE_RANGE' => 'Datumsbereich ist',
	'LBL_DATE_START' => 'Begin Date:',
	'LBL_EDIT' => 'Bearbeiten',
	'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Zeigt kumulative Verkaufschancenums�tze nach ausgew�hlter Herkunft und Ergebnis f�r ausgew�hlte User wobei das erwartete Abschlussdatum im angegebenen Datumsbereich liegt.  Ergebnis wird folgendermassen klassifiziert: Abschluss positiv, Abschluss negativ, anderer Wert.',
	
	'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Alle Verkaufschancen nach Herkunft nach Umsatz',
	'LBL_LEAD_SOURCE_FORM_DESC' => 'Zeigt kumulative Verkaufschancenums�tze nach Herkunft f�r ausgew�hlte User.', 
	
	'LBL_LEAD_SOURCE_FORM_TITLE' => 'Alle Verkaufschancen nach Herkunft',
	'LBL_LEAD_SOURCE_OTHER' => 'Andere',  
	'LBL_LEAD_SOURCES' => 'Herkunft:',
	'LBL_MODULE_NAME' => 'Statistik',
	'LBL_MODULE_TITLE' => 'Statistik: Home',
	'LBL_MONTH_BY_OUTCOME_DESC' => 'Zeigt kumulative Verkaufschancenums�tze nach Monaten f�r ausgew�hlte User wobei das erwartete Abschlussdatum im angegebenen Datumsbereich liegt.  Umsatz wird nach Ergebnis eingeteilt: Abschluss erfolgreich, Abschluss negativ, anderer Wert.',
	'LBL_OPP_SIZE' => 'Verkaufschancenumsatz in',
	'LBL_OPP_THOUSANDS'=> ' K', 
	
	'LBL_OPPS_IN_LEAD_SOURCE' => 'Verkaufschancen nach Herkunft',
	'LBL_OPPS_IN_STAGE' => ' - Verkaufsphase ist',
	'LBL_OPPS_OUTCOME' => ' Ergebnis ist ',
	'LBL_OPPS_WORTH' => 'Verkaufschancenumsatz',
	'LBL_PIPELINE_FORM_TITLE_DESC' => 'Zeigt kumulative Verkaufschancenums�tze nach ausgew�hlten Verkaufsphasen wobei das erwartete Abschlussdatum im angegebenen Datumsbereich liegt.',
	
	'LBL_REFRESH' => 'Aktualisieren',
	'LBL_ROLLOVER_DETAILS' => 'F�r Details Maus �ber den Balken bewegen.',
	'LBL_ROLLOVER_WEDGE_DETAILS' => 'F�r Details Maus �ber das Kreissegment bewegen.',
	
	'LBL_SALES_STAGE_FORM_DESC' => 'Zeigt kumulative Verkaufschancenums�tze nach Verkaufsphasen f�r ausgew�hlte User wobei das erwartete Abschlussdatum im angegebenen Datumsbereich liegt.',
	'LBL_SALES_STAGE_FORM_TITLE' => 'Umsatz nach Verkaufsphase',
	
	'LBL_SALES_STAGES' => 'Verkaufsphase:',
	
	'LBL_TOTAL_PIPELINE' => 'Gesamtumsatz: ',
	'LBL_USERS' => 'User:',
	
	'LBL_YEAR' => 'Jahr:',
	'LBL_YEAR_BY_OUTCOME' => 'Umsatz nach Monaten und  Ergebnis',
	
	'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
	'LNK_NEW_CALL' => 'Neuer Anruf',
	'LNK_NEW_CASE' => 'Neue Anfrage',
	'LNK_NEW_CONTACT' => 'Neuer Kontakt',
	'LNK_NEW_ISSUE' => 'Neuen Bug berichten',
	'LNK_NEW_LEAD' => 'Neuer Interessent',
	'LNK_NEW_MEETING' => 'Neuer Termin',
	'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
	'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
	'LNK_NEW_QUOTE' => 'Neuees Angebot',
	'LNK_NEW_TASK' => 'Neue Aufgabe',
	'NTC_NO_LEGENDS' => 'Keine',

 		

);


?>
