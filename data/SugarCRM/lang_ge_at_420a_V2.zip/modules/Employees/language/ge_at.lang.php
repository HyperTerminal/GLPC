<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.10 2006/04/02 10:20:57 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Mitarbeiter',
  'LBL_MODULE_TITLE' => 'Mitarbeiter: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Mitarbeiter',
  'LBL_LIST_FORM_TITLE' => 'Mitarbeiter',
  'LBL_NEW_FORM_TITLE' => 'Neuer Mitarbeiter',
  'LBL_EMPLOYEE' => 'Mitarbeiter:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Standardeinstellungen wiederherstellen',
  'LBL_TIME_FORMAT' => 'Zeitformat:',
  'LBL_DATE_FORMAT' => 'Datumsformat:',
  'LBL_TIMEZONE' => 'Aktuelle Zeit:',
  'LBL_CURRENCY' => 'W�hrung:',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_LIST_EMPLOYEE_NAME' => 'Mitarbeitername',
  'LBL_LIST_DEPARTMENT' => 'Abteilung',
  'LBL_LIST_REPORTS_TO_NAME' => 'Berichte an',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Telefon B�ro',
  'LBL_LIST_USER_NAME' => 'User',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Mitarbeiterstatus',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Neuer Mitarbeiter [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Neuer Mitarbeiter',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fehler:',
  'LBL_PASSWORD' => 'Password:',
  'LBL_EMPLOYEE_NAME' => 'Mitarbeitername:',
  'LBL_USER_NAME' => 'User Name:',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_EMPLOYEE_SETTINGS' => 'Mitarbeiter Einstellungen',
  'LBL_THEME' => 'Skin:',
  'LBL_LANGUAGE' => 'Sprache:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_EMPLOYEE_INFORMATION' => 'Mitarbeiter Informationen',
  'LBL_OFFICE_PHONE' => 'Telefon B�ro:',
  'LBL_REPORTS_TO' => 'Berichte an:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_OTHER_EMAIL' => 'Email2:',
  'LBL_NOTES' => 'Notizen:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_ANY_EMAIL' => 'Beliebige Email-Adresse:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Name:',
  'LBL_MOBILE_PHONE' => 'Telefon Mobil:',
  'LBL_OTHER' => 'Pager:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_ADDRESS_INFORMATION' => 'Adressangaben',
  'LBL_EMPLOYEE_STATUS' => 'Mitarbeiterstatus:',
  'LBL_PRIMARY_ADDRESS' => 'Anschrift:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Neuer Mitarbeiter [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Neuer Mitarbeiter',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Lieblingsfarbe:',
  'LBL_MESSENGER_ID' => 'IM Name:',
  'LBL_MESSENGER_TYPE' => 'IM Typ:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Der Mitarbeitername ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' existiert bereits.  Doppelte Mitarbeiternamene sind nicht erlaubt.  W�hlen Sie einen einzigartigen Mitarbeiternamen.',
  'ERR_LAST_ADMIN_1' => 'Der Mitarbeiter namens "',
  'ERR_LAST_ADMIN_2' => '" ist der letze Mitarbeiter mit Administrator Status.  Mindestens ein Mitarbeiter muss Administrator bleiben.',
  'LNK_NEW_EMPLOYEE' => 'Neuer Mitarbeiter',
  'LNK_EMPLOYEE_LIST' => 'Mitarbeiter',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',

  'LBL_LIST_EMPLOYEE_STATUS' => 'Mitarbeiterstatus',

);


?>
