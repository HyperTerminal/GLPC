<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.6 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Releases',
  'LBL_MODULE_TITLE' => 'Releases: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Release',
  'LBL_LIST_FORM_TITLE' => 'Release - Liste',
  'LBL_NEW_FORM_TITLE' => 'Neues Release',
  'LBL_RELEASE' => 'Release:',
  'LBL_LIST_NAME' => 'Release',
  'LBL_NAME' => 'Release Version:',
  'LBL_LIST_LIST_ORDER' => 'Sortierung',
  'LBL_LIST_ORDER' => 'Sortierung:',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_STATUS' => 'Status:',
  'LNK_NEW_RELEASE' => 'Release Liste',
  'NTC_DELETE_CONFIRMATION' => 'Wollen Sie diesen Datensatz wirklich l�schen?',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_STATUS' => 'Setzen Sie den Status auf inaktiv, damit das Release aus Auswahlfeldern entfernt wird.',
  'NTC_LIST_ORDER' => 'Stellen Sie die Sortierreihenfolge ein, nach welcher dieses Release in Auswahlfeldern erscheinen soll.',
  'release_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
);


?>
