<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.14 2006/04/02 10:20:57 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Das Verzeichnis ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' existiert nicht oder ist nicht schreibbar',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Datei konnte nicht auf den Server geladen werden. M�glicherweise ist die maximale Uploadgr�sse von \'upload_max_filesize\'  in Ihrer  php.ini zu klein.',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Datei zu gross. Max:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Bytes. Ver�ndern Sie  $sugar_config[\'upload_maxsize\'] in  der config.php',
  'LBL_MODULE_NAME' => 'Importieren',
  'LBL_TRY_AGAIN' => 'Versuchen Sie es noch einmal',
  'LBL_ERROR' => 'Error:',
  'ERR_MULTIPLE' => 'Mehrere Spalten sind mit dem gleichen Feldnamen definiert.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Verpflichtennde Felder fehlen:',
  'ERR_SELECT_FULL_NAME' => 'Vollst�ndiger Name kann nicht gew�hlt werden wenn  Vorname und  Nachname ausgew�hlt sind.',
  'ERR_SELECT_FILE' => 'W�hlen Sie eine Datei f�r den Upload.',
  'LBL_SELECT_FILE' => 'Datei ausw�hlen:',
  'LBL_CUSTOM' => 'Benutzerdefiniert',
  'LBL_CUSTOM_CSV' => 'Comma getrennte Datei (CVS)',
  'LBL_CUSTOM_TAB' => 'Tab Getrennte Datei',
  'LBL_DONT_MAP' => '-- Diese Feld nicht zuordnen --',
  'LBL_STEP_1_TITLE' => 'Schritt 1: Quelle ausw�hlen',
  'LBL_WHAT_IS' => 'Welche Datenquelle m�chten Sie verwenden?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Meine gespeicherten Datenquellen:',
  'LBL_PUBLISH' => 'ver�ffentlichen',
  'LBL_DELETE' => 'L�schen',
  'LBL_PUBLISHED_SOURCES' => 'Published Sources:',
  'LBL_UNPUBLISH' => 'un-publish',
  'LBL_NEXT' => 'Weiter >',
  'LBL_BACK' => '< Zur�ck',
  'LBL_STEP_2_TITLE' => 'Schritt 2: Exportierte Datei hochladen',
  'LBL_HAS_HEADER' => 'hat Kopfzeile:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'W�hlen Sie die Datei f�r den Import:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 2000 und Outlook 97  kann Daten im <b>CSV</b> (Comma Separated Values) Format speichern, dieses Format kann ins System importiert werden. Folgen Sie den unten angef�hrten Schritten um Daten aus Outlook zu exportieren:',
  'LBL_OUTLOOK_NUM_1' => 'Start <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'W�hlen Sie im Men� <b>Datei</b>, dann <b>Import und Export ...</b>',
  'LBL_OUTLOOK_NUM_3' => 'W�hlen Sie <b>Export in eine Datei</b> und klicken Sie auf Weiter',
  'LBL_OUTLOOK_NUM_4' => 'W�hlen Sie  <b>CSV</b> (Comma Separated Values) (Windows) und klicken Sie auf <b>Weiter</b>.',
  'LBL_OUTLOOK_NUM_5' => 'W�hlen Sie den  <b>Kontakte</b> Ordner und klicken Sie auf <b>Weiter</b>.',
  'LBL_OUTLOOK_NUM_6' => 'Geben Sie Dateiname und Speicherort an  und klicken Sie auf <b>Weiter</b>',
  'LBL_OUTLOOK_NUM_7' => 'W�hlen Sie <b>Fertigstellen</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! kann Daten im <b>CSV</b> (Comma Separated Values) Format speichern, dieses Format kann ins System importiert werden. Folgen Sie den unten angef�hrten Schritten um Daten aus Act!, zu exportieren:',
  'LBL_ACT_NUM_1' => 'Starten Sie <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'W�hlen Sie im Men�  <b>Datei</b>,  <b>Data Exchange</b>,  <b>Exportieren...</b>',
  'LBL_ACT_NUM_3' => 'W�hlen Sie als Dateityp <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'W�hlen Sie Dateinamen und Speicherort f�r die zu exportierten Daten und klicken Sie auf <b>Weiter</b>',
  'LBL_ACT_NUM_5' => 'Nur <b>Kontakt Datens�tze</b> ausw�hlen',
  'LBL_ACT_NUM_6' => 'Klicken Sie auf <b>Optionen...</b>',
  'LBL_ACT_NUM_7' => 'W�hlen Sie <b>Comma</b> als Feldtrennzeichen',
  'LBL_ACT_NUM_8' => 'Kreuzen Sie die  <b>Yes, export field names</b> Checkbox an und klicken Sie auf <b>OK</b>',
  'LBL_ACT_NUM_9' => 'Klicken Sie auf  <b>Weiter</b>',
  'LBL_ACT_NUM_10' => 'W�hlen Sie <b>Alle Datens�tze</b> und klicken sie dann auf <b>Fertigstellen</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com  kann Daten im <b>CSV</b> (Comma Separated Values) Format speichern, dieses Format kann ins System importiert werden. Folgen Sie den unten angef�hrten Schritten um Daten aus Salesforce.com zu exportieren:',
  'LBL_SF_NUM_1' => '�ffnen Sie Ihren Browser, gehen Sie zu http://www.salesforce.com, und loggen Sie sich ein.',
  'LBL_SF_NUM_2' => 'Klicken Sie auf das <b>Reports</b> Register im Hauptmen�',
  'LBL_SF_NUM_3' => '<b>Um Kunden zu exportieren:</b> Klicken Sie auf den <b>Active Accounts</b> Link.<br><b>Um Kontakte zu exportieren:</b> Klicken Sie auf den <b>Mailing List</b> Link',
  'LBL_SF_NUM_4' => 'On <b>Step 1: Select your report type</b>, select <b>Tabular Report</b>click <b>Next</b>',
  'LBL_SF_NUM_5' => 'On <b>Step 2: Select the report columns</b>, choose the columns you want to export and click <b>Next</b>',
  'LBL_SF_NUM_6' => 'On <b>Step 3: Select the information to summarize</b>, just click <b>Next</b>',
  'LBL_SF_NUM_7' => 'On <b>Step 4: Order the report columns</b>, just click <b>Next</b>',
  'LBL_SF_NUM_8' => 'On <b>Step 5: Select your report criteria</b>, under <b></b>, choose a date far enough in the past to include all your Kunden. You can also export a subset of Kunden using more advanced criteria. When you are done, click <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'A report will be generated, and the page should display <b>Report Generation Status: Complete.</b> Now click <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => 'On <b>Export Report:</b>, for <b>Export File Format:</b>, choose <b>Comma Delimited .csv</b>. Click <b>Export</b>.',
  'LBL_SF_NUM_11' => 'A dialog will pop up for you to save the export file to your computer.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Die meisten Programme k�nnen Daten im <b>CSV</b> (Comma Separated Values) Format speichern, dieses Format kann ins System importiert werden. Meistens gehen Sie dabei folgendermassen vor:',
  'LBL_CUSTOM_NUM_1' => 'Starten Sie das Programm und �ffnen Sie die Datendatei',
  'LBL_CUSTOM_NUM_2' => 'W�hlen Sie im Men� <b>Speichern als...</b> oder  <b>Exportieren...</b>',
  'LBL_CUSTOM_NUM_3' => 'Speichern Sie die Datei im <b>CSV</b> Format.',
  'LBL_IMPORT_TAB_TITLE' => 'Die meisten Programme k�nnen Daten im <b>Tab Delimited text</b> (.tsv oder tab) Format speichern. Meistens gehen Sie dabei folgendermassen vor:',
  'LBL_TAB_NUM_1' => 'Starten Sie das Programm und �ffnen Sie die Datendatei',
  'LBL_TAB_NUM_2' => 'W�hlen Sie im Men� <b>Speichern als...</b> oder  <b>Exportieren...</b>',
  'LBL_TAB_NUM_3' => 'Speichern Sie die Datei im <b>Tab Separated Values</b> Format',
  'LBL_STEP_3_TITLE' => 'Schritt 3: Felder zuordnen und importieren',
  'LBL_SELECT_FIELDS_TO_MAP' => 'W�hlen Sie in der Liste die Felder aus, welche importiert werden sollen. Wenn Sie fertig sind, klicken Sie auf <b>Jetzt importieren</b>:',
  'LBL_DATABASE_FIELD' => 'Datenbankfeld',
  'LBL_HEADER_ROW' => 'Kopfzeile',
  'LBL_ROW' => 'Zeile',
  'LBL_SAVE_AS_CUSTOM' => 'Als benutzerdefinierte Zuordnung speichern:',
  'LBL_CONTACTS_NOTE_1' => 'Entweder Nachname oder Vollst�nder Name m�ssen zugeordnet werden.',
  'LBL_CONTACTS_NOTE_2' => 'Wenn Vollst�ndiger Name zugeordnet wird werden  Vorname und  Nachname ignoriert.',
  'LBL_CONTACTS_NOTE_3' => 'Wenn Vollst�ndiger Name zugeordnet wird, wird beim Einf�gen in die Datenbank der Inhalt von Vollst�ndiger Name in Vorname und  Nachname augeteilt.',
  'LBL_CONTACTS_NOTE_4' => 'Die Felder  Adresse Strasse 2 und Adresse Strasse 3 werden zusamengezogen und in das Hauptadresse Strasse Feld gespeichert.',
  'LBL_ACCOUNTS_NOTE_1' => 'Kundenname muss zugeordnet werden.',
  'LBL_ACCOUNTS_NOTE_2' => 'Die Felder  Adresse Strasse 2 und Adresse Strasse 3 werden zusamengezogen und in das Hauptadresse Strasse Feld gespeichert.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Verkaufschance-Name, Kundenname, Enddatum, und Verkaufsstatus sind verpflichtende Felder.',
  'LBL_IMPORT_NOW' => 'Jetzt importieren',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Die importierte Datei kann nicht gelesen werden',
  'LBL_NOT_SAME_NUMBER' => 'There were not the same number of fields per line in your file',
  'LBL_NO_LINES' => 'In Ihrer Importdatei konnten keine Zeilen zum Importieren gefunden werden',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Die Import Datei wurde bereits verarbeitet oder existiert nicht',
  'LBL_SUCCESS' => 'Erfolgreich:',
  'LBL_SUCCESSFULLY' => 'Erfolgreich importiert',
  'LBL_LAST_IMPORT_UNDONE' => 'Letzter Import wurde r�ckg�ngig gemacht',
  'LBL_NO_IMPORT_TO_UNDO' => 'Es gab nichts r�ckg�ngig zu machen.',
  'LBL_FAIL' => 'Fehlgeschlagen:',
  'LBL_RECORDS_SKIPPED' => 'Datens�tze �bersprungen da in diesen ein oder mehrere verpflichtende Angaben fehlten',
  'LBL_IDS_EXISTED_OR_LONGER' => 'Datens�tze �bersprungen weil die id\'s entweder vorhanden oder l�nger als 36 Zeichen war',
  'LBL_RESULTS' => 'Ergebnisse',
  'LBL_IMPORT_MORE' => 'Weitere importieren',
  'LBL_FINISHED' => 'abgeschlossen',
  'LBL_UNDO_LAST_IMPORT' => 'Letzer Import r�ckg�ngig',
  'LBL_LAST_IMPORTED'=>'Zuletzt importiert',
  'ERR_MULTIPLE_PARENTS' => 'Es kann un eine Parent ID definiert werden',
);




?>
