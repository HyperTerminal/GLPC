<?php
 if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
  ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.14 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Translation(s): by krokogras
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aktivit�ten',
  'LBL_MODULE_TITLE' => 'Aktivit�ten: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Aktivit�ten',
  'LBL_LIST_FORM_TITLE' => 'Aktivit�tenliste',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'geh�rt zu',
  'LBL_LIST_DATE' => 'Datum',
  'LBL_LIST_TIME' => 'Zeit',
  'LBL_LIST_CLOSE' => 'Schliessen',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Ort:',
  'LBL_DATE_TIME' => 'Beginndatum & -zeit:',
  'LBL_DATE' => 'Beginndatum:',
  'LBL_TIME' => 'Beginnzeit:',
  'LBL_DURATION' => 'Dauer:',
  'LBL_HOURS_MINS' => '(Stunden/Minuten)',
  'LBL_CONTACT_NAME' => 'Kontakt Name: ',
  'LBL_MEETING' => 'Termin:',
  'LBL_DESCRIPTION_INFORMATION' => 'Weitere Informationen',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'geplant',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
  'LNK_NEW_EMAIL' => 'Email archivieren',
  'LNK_CALL_LIST' => 'Anrufe',
  'LNK_MEETING_LIST' => 'Termine',
  'LNK_TASK_LIST' => 'Aufgaben',
  'LNK_NOTE_LIST' => 'Notizen',
  'LNK_EMAIL_LIST' => 'Emails',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_REMOVE_INVITEE' => 'Teilnehmer vom Termin entfernen?',
  'LBL_INVITEE' => 'Teilnehmer',
  'LBL_LIST_DIRECTION' => 'Richtung',
  'LBL_DIRECTION' => 'Richtung',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
  'LNK_VIEW_CALENDAR' => 'Heute',
  'LBL_OPEN_ACTIVITIES' => 'Offene Aktivit�ten',
  'LBL_HISTORY' => 'Verlauf',
  'LBL_UPCOMING' => 'Meine offenen Termine & Anrufe',
  'LBL_TODAY' => 'bis ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Neue Aufgabe [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Neue Aufgabe',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Neuer Termin [Alt+T]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'T',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Neuer Termin',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Neuer Anruf [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Neuer Anruf',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Neue Notiz oder Attachment [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Neue Notiz oder Attachment',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Email archivieren [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Email archivieren',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DUE_DATE' => 'F�lligkeitsdatum',
  'LBL_LIST_LAST_MODIFIED' => 'ge�ndert am',
  'NTC_NONE_SCHEDULED' => 'Keine geplant.',
  'appointment_filter_dom' => array(
  	 'today' => 'heute'
  	,'tomorrow' => 'morgen'
  	,'this Saturday' => 'diese Woche'
  	,'next Saturday' => 'n�chste Woche'
  	,'last this_month' => 'dieses Monat'
  	,'last next_month' => 'n�chstes Monat'
  ),
  'LNK_IMPORT_NOTES'=>'Notizen importieren',
  'NTC_NONE'=>'None',
	'LBL_ACCEPT_THIS'=>'Akzeptieren?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Offene Aktivit�ten',
	
);


?>
