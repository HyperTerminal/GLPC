<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.16 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Verkaufschance',
  'LBL_MODULE_TITLE' => 'Verkaufschancen: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Verkaufschancen',
  'LBL_LIST_FORM_TITLE' => 'Verkaufschancenliste',
  'LBL_OPPORTUNITY_NAME' => 'Verkaufschance Name:',
  'LBL_OPPORTUNITY' => 'Verkaufschance:',
  'LBL_NAME' => 'Verkaufschance Name',
  'LBL_INVITEE' => 'Kontakte',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Verkaufschance',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_AMOUNT' => 'Umsatz',
  'LBL_LIST_DATE_CLOSED' => 'Abschlussdatum',
  'LBL_LIST_SALES_STAGE' => 'Verkaufsphase',
  'LBL_ACCOUNT_ID'=>'Kunden-ID', 
  'LBL_CURRENCY_ID'=>'W�hrung-ID', 
  'LBL_TEAM_ID' =>'Team-ID', 

//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Verkaufschance - W�hrungsupdate',
  'UPDATE_DOLLARAMOUNTS' => 'U.S. Dollar Ums�tze aktualisieren',
  'UPDATE_VERIFY' => 'Ums�tze �berpr�fen',
  'UPDATE_VERIFY_TXT' => '�berpr�ft, ob die Umsatzbetr�ge in Verkaufschancen g�ltige Zahlen sind)',
  'UPDATE_FIX' => 'Ums�tze reparieren',
  'UPDATE_FIX_TXT' => 'Versucht ung�lige Umsatzzahlen zu reparieren indem g�ltige Zahlen aus den aktuellen Umsatzzahlen generiert werden. Alle Betr�ge werden in ein Datenbankfeld amount_backup gesichert. Wenn Fehler bei dieser Prozedur auftreten d�rfen Sie diese Prozedur nicht vor Wiedereinspielen des Backups  wiederholen  da sonst das Backup mit ung�ltigen Daten �berschrieben werden k�nnte.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'U.S. Dollar Ums�tze in  Verkaufschancen mit den aktuellen Wechselkursen aktualisieren. Dieser Wert wir zur Berechnung von Graphiken und Listen verwendet.',
  'UPDATE_CREATE_CURRENCY' => 'Neue W�hrung wird angelegt:',
  'UPDATE_VERIFY_FAIL' => 'Datensatz�berpr�fung abgeschlossen:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Aktueller Umsatz:',
  'UPDATE_VERIFY_FIX' => 'Die Korrektur w�rde folgendes ergeben',
  'UPDATE_INCLUDE_CLOSE' => 'Geschlossene Datens�tze inkludieren',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Neuer Betrag:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Neue W�hrung:',
  'UPDATE_DONE' => 'Done',
  'UPDATE_BUG_COUNT' => 'Es wurden Fehler gefunden und eine Korrektur versucht:',
  'UPDATE_BUGFOUND_COUNT' => 'Fehler gefunden:',
  'UPDATE_COUNT' => 'Datens�tze aktualisiert:',
  'UPDATE_RESTORE_COUNT' => 'Ums�tze wiederhergestellt:',
  'UPDATE_RESTORE' => 'Ums�tze wiederherstellen',
  'UPDATE_RESTORE_TXT' => 'Ums�tze vom Backup wiederherstellen.',
  'UPDATE_FAIL' => 'Update fehlgeschlagen - ',
  'UPDATE_NULL_VALUE' => 'Umsatz ist NULL, wird auf 0 gesetzt',
  'UPDATE_MERGE' => 'W�hrungen zusammenf�hren',
  'UPDATE_MERGE_TXT' => 'Mehrere W�hrungen vereinen. Wenn Sie bemerken, das mehrere W�hrungsdatens�tze f�r ein und dieselbe W�hrung existieren m�chten Sie diese wahrscheinlich vereinen.',
  'LBL_ACCOUNT_NAME' => 'Kundenname:',
  'LBL_AMOUNT' => 'Umsatz:',
  'LBL_CURRENCY' => 'W�hrung:',
  'LBL_DATE_CLOSED' => 'Erwartetes Abschlussdatum:',
  'LBL_TYPE' => 'Typ:',
  'LBL_NEXT_STEP' => 'N�chster Schritt:',
  'LBL_LEAD_SOURCE' => 'Herkunft:',
  'LBL_SALES_STAGE' => 'Verkaufsphase:',
  'LBL_PROBABILITY' => 'Wahrscheinlichkeint (%):',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_DUPLICATE' => 'M�glicherweise Verkaufschancen Doppelerfassung',
  'MSG_DUPLICATE' => 'Eine �hnliche Verkaufschance ist bereits vorhanden. W�hlen Sie einen bereits existierende Verkaufschance aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Daten zu verwenden, oder klicken Sie auf Abbrechen.',
  'LBL_NEW_FORM_TITLE' => 'Neue Verkaufschance',
  'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
  'LNK_OPPORTUNITY_LIST' => 'Verkaufschancen',
  'ERR_DELETE_RECORD' => 'Es muss eine Datensatznummer (ID) angegeben werden, damit diese Verkaufschance gel�scht werden kann..',
  'LBL_TOP_OPPORTUNITIES' => 'Meine offenen Verkaufschancen',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Kontakt von dieser Verkaufschance entfernen?',
  'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Verkaufschance vom Projekt entfernen?',
  'LBL_AMOUNT_BACKUP'=>'Umsatz Backup',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Verkaufschancen', 
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
  'LBL_RAW_AMOUNT'=>'Rohbetrag',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Interessenten', 
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekte', 
  'LBL_ASSIGNED_TO_NAME' => 'zugewiesen an:',


);

?>
