<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/**
 * DefaultGerman language strings
 *
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: ge_at.lang.php,v 1.7 2006/04/01 12:22:06 krokogras Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projektaufgaben',
	'LBL_MODULE_TITLE' => 'Projektaufgaben: Home',
	'LBL_SEARCH_FORM_TITLE' => 'Suche Projektaufgaben',
	'LBL_LIST_FORM_TITLE'=> 'Projektaufgabenliste',
	
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'erstellt am:',
	'LBL_DATE_MODIFIED' => 'ge�ndert am:',
	'LBL_ASSIGNED_USER_ID' => 'Bearbeitung durch:',
	'LBL_MODIFIED_USER_ID' => 'ge�ndert von:',
	'LBL_CREATED_BY' => 'erstellt von:',
	'LBL_TEAM_ID' => 'Team:',
	'LBL_NAME' => 'Name:',
	'LBL_STATUS' => 'Status:',
	'LBL_DATE_DUE' => 'F�lligkeitsdatum:',
	'LBL_TIME_DUE' => 'F�lligkeitszeit:',
	'LBL_DATE_START' => 'Beginndatum:',
	'LBL_TIME_START' => 'Beginnzeit:',
	'LBL_PARENT_ID' => 'Projekt:',
	'LBL_PRIORITY' => 'Priorit�t:',
	'LBL_DESCRIPTION' => 'Beschreibung:',
	'LBL_ORDER_NUMBER' => 'Sortier-Nr.:',
	'LBL_TASK_NUMBER' => 'Aufgabennummer:',
	'LBL_DEPENDS_ON_ID' => 'Abh�ngig von:',
	'LBL_MILESTONE_FLAG' => 'Milestone:',
	'LBL_ESTIMATED_EFFORT' => 'Gesch�tzter Aufwand (Std.):',
	'LBL_ACTUAL_EFFORT' => 'Tats�chlicher Aufwand (Std.):',
	'LBL_UTILIZATION' => 'Fertigstellung (%):',
	'LBL_PERCENT_COMPLETE' => 'Fortschritt (%):',
	'LBL_DELETED' => 'Gel�scht:',

	'LBL_LIST_ORDER_NUMBER' => 'Sortier-Nr.',
	'LBL_LIST_NAME' => 'Name',
	'LBL_LIST_PARENT_NAME' => 'Projekt',
	'LBL_LIST_PERCENT_COMPLETE' => 'Fortschritt (%)',
	'LBL_LIST_STATUS' => 'Status',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Bearbeitung durch',
	'LBL_LIST_DATE_DUE' => 'F�lligkeitsdatum',
	'LBL_LIST_DATE_START' => 'Beginndatum',
	'LBL_PROJECT_NAME' => 'Projektname',
	
	'LNK_NEW_PROJECT'	=> 'Neues Projekt',
	'LNK_PROJECT_LIST'	=> 'Projektliste',
	'LNK_NEW_PROJECT_TASK'	=> 'Neue Projektaufgabe',
	'LNK_PROJECT_TASK_LIST'	=> 'Projektaufgaben',

	'LBL_LIST_MY_PROJECT_TASKS' => 'Meine offenen Projektaufgaben', 
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projektaufgaben', 
	
	'LBL_ACTIVITIES_TITLE'=>'Aktivit�ten', 
	'LBL_HISTORY_TITLE'=>'Verlauf', 
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
	'LBL_LIST_PRIORITY' => 'Priorit�t', 
	'LBL_LIST_CLOSE' => 'Schliessen', 
	'LBL_NEW_FORM_TITLE' => 'Neue Projektaufgabe',
	'DATE_JS_ERROR' => 'Bitte geben Sie ein passendes Datum ein',

);
?>
