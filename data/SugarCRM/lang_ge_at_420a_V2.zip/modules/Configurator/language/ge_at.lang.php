<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.3 2006/04/01 16:56:54 krokogras Exp $
 * Description:  Defines the Austrian German language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME'=>'System Einstellungen',
	'LBL_MODULE_TITLE'=>'Standardeinstellungen f�r alle User',
	'ADMIN_EXPORT_ONLY'=>'Nur Admins d�rfen exportieren',
	'DISABLE_EXPORT'=>'Export deaktivieren',
	'DEFAULT_CURRENCY_NAME'=>'W�hrung Name',
	'DEFAULT_CURRENCY_SYMBOL'=>'W�hrung Symbol',
	'DEFAULT_CURRENCY_ISO4217'=>'ISO 4217 W�hrungscode',
	'DEFAULT_CURRENCY'=>'Standardw�hrung',
	'EXPORT'=>'Exportieren',
	'QUOTES_CURRENT_LOGO'=>'Logo in Angeboten verwenden ',
	'NEW_QUOTE_LOGO'=>'Neues Logo hochladen (867x74)',
	'CURRENT_LOGO'=>'Aktuell verwendetes Logo',
	'NEW_LOGO'=>'Neues Logo hochladen (212x40)',
	'DEFAULT_SYSTEM_SETTINGS'=>'User Interface',
	'DEFAULT_DATE_FORMAT'=>'Standard Datumsformat',
	'DEFAULT_TIME_FORMAT'=>'Standard Zeitformat',
	'DEFAULT_THEME'=> 'Standard Skin',
	'LIST_ENTRIES_PER_LISTVIEW'=>'Zeilen pro Seite in Listenansicht ',
	'LIST_ENTRIES_PER_SUBPANEL'=>'Zeilen pro Seite in Subpanels',
	'DISPLAY_LOGIN_NAV'=>'Register auf Login Seite anzeigen',
	'DISPLAY_RESPONSE_TIME'=>'Serververarbeitungszeiten anzeigen',
	'ADVANCED'=>'Erweitert',
	'VERIFY_CLIENT_IP'=>'User IP Adresse �berwachen',
	'LOG_MEMORY_USAGE'=>'Speicherbedarf protokollieren',
	'LOG_SLOW_QUERIES'=> 'Langsame Abfragen protokollieren',
	'SLOW_QUERY_TIME_MSEC'=>'Voreinstellung f�r langsame Abfragen in Millisekunden (msec)',
	'UPLOAD_MAX_SIZE'=>'Maximale Upload Dateigr��e',
	'STACK_TRACE_ERRORS'=>'Interne Fehlermeldungen anzeigen',
	'IMAGES'=>'Logos',
	'DEFAULT_LANGUAGE'=>'Standard Sprache',
	'LBL_RESTORE_BUTTON_LABEL'=>'Wiederherstellen',
	

	
	
	'LBL_PORTAL_TITLE' => 'Kunden Self-Service Portal',
	'LBL_PORTAL_ON' => 'Externes Kunden Self-Service Portal einschalten?',
	'LBL_PORTAL_ON_DESC' => 'Anfragen, Notizen und andere Daten sind im externen Kunden Self-Service Portal freischalten.',

	
	'LBL_PROXY_AUTH'=>'Authentifizierung?',
	'LBL_PROXY_HOST'=>'Proxy Host',
	'LBL_PROXY_ON_DESC'=>'Proxy Server Einstellungen konfigurieren',
	'LBL_PROXY_ON'=>'Proxy Server verwenden?',
	'LBL_PROXY_PASSWORD'=>'Passwort',
	'LBL_PROXY_PORT'=>'Port',
	'LBL_PROXY_TITLE'=>'Proxy Einstellungen',
	'LBL_PROXY_USERNAME'=>'User Name',
	
	
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;', 
	'LBL_SKYPEOUT_ON' => 'SkypeOut&reg;  Integration aktivieren?', 
	'LBL_SKYPEOUT_ON_DESC' => 'Erm�glicht die Verwendung von  SkypeOut&reg;  zum T�tigen von Anrufen durch Klicken auf die Telefonnummer. Die Telefonnummern m�ssen entsprechend formatiert sein. Das  "+" muss f�r den L�ndercode verwendet werden. Mehr Information �ber die Formatierung von Telfonnummern finden Sie unter <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>    ', 
	
		
	   'LBL_MAILMERGE' => 'Serienbrief', 
           'LBL_ENABLE_MAILMERGE' => 'Serienbrief-Funktionen aktivieren?', 
           'LBL_MAILMERGE_DESC' => 'Diese Einstellung sollte nur angekreuzt werden, wen das Sugar Plug-in f�r Microsoft Word gekauft und lizensiert wurde.', 

	
	'LBL_LOGVIEW' => 'Protokoll Einstellungen',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'System Einstelunen',
	'LBL_MAIL_SMTPAUTH_REQ'				=> 'SMTP Authentifizierung verwenden?',
	'LBL_MAIL_SMTPPASS'					=> 'SMTP Password:',
	'LBL_MAIL_SMTPPORT'					=> 'SMTP Port:',
	'LBL_MAIL_SMTPSERVER'				=> 'SMTP Server:',
	'LBL_MAIL_SMTPUSER'					=> 'SMTP Username:',
	'LBL_NOTIFY_FROMADDRESS' => '"From" Address:',
	'LBL_NOTIFY_SUBJECT' => 'Email subject:',
	'DEFAULT_NUMBER_GROUPING_SEP'			=> '1000-er Trennzeichen',
	'DEFAULT_DECIMAL_SEP'					=> 'Dezimalzeichen',
);


?>
