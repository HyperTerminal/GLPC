<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.4 2006/02/10 19:31:27 krokogras Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/
 
$mod_strings = array (
  'LBL_STEP_1' => 'Step 1: Modul und Vorlage ausw�hlen',
  'LBL_MAILMERGE_MODULE' => 'Module ausw�hlen: ',
  'LBL_MAILMERGE_SELECTED_MODULE' => 'Ausgew�hltes Modul: ',
  'LBL_MAILMERGE_TEMPLATES' => 'Vorlage ausw�hlen: ',
  'LBL_STEP_2' => 'Step 2: Objekte f�r Serienbrief ausw�hlen',
  'LBL_MAILMERGE_OBJECTS' => 'Objekte ausw�hlen: ',
  'LBL_STEP_3' => 'Kontakt Zuordnung erstellen',
  'LBL_STEP_4' => '�berpr�fen und Fertigstellen',
  'LBL_SELECTED_MODULE' => 'Gew�hlte Module: ',
  'LBL_SELECTED_TEMPLATE' => 'Gew�hlte Vorlagen: ',
  'LBL_SELECTED_ITEMS' => 'Gew�hlte Elemente: ',
  'LBL_STEP_5' => 'Serienbrieferstellung abgeschlossen',
  'LBL_MERGED_FILE' => 'Merged File: ',
  'LNK_NEW_MAILMERGE' => 'Serienbrief starten',
  'LNK_UPLOAD_TEMPLATE' => 'Vorlage hochladen',
  'LBL_DOC_NAME' => 'Dokumentname:',
  'LBL_FILENAME' => 'Dateiname:',
  'LBL_DOC_VERSION' => 'Version:',
  'LBL_DOC_DESCRIPTION'=>'Beschreibung:',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_RELATIONSHIP' => 'Kontaktbeziehungen erstellen',
  'LBL_FINISH' => 'Serienbrieferstellung starten',
  'LBL_NEXT' => 'Weier >',
  'LBL_BACK' => '< Zur�ck',
  'LBL_START' => 'Neustart',
  'LBL_TEMPLATE_NOTICE' => 'Templates are Microsoft Word documents containing merge fields that have been uploaded and stored in the Documents module.',
  'LBL_CONTAINS_CONTACT_INFO' => 'Selected template contains Contact information.',
  'LBL_ADDIN_NOTICE' => 'This requires the installation of Sugar Mail Merge add-in to Microsoft Word.',
  'LBL_BROWSER_NOTICE' => 'You must be running IE 6.0 or greater to perform the actual merge.',



);


?>
