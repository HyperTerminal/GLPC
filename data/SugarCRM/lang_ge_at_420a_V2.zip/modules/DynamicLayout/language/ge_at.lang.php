<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (

'LBL_ADVANCED'=> 'Erweitert:',
'DESC_USING_LAYOUT_TITLE' => 'Layout Editor verwenden',
'DESC_USING_LAYOUT_SHORTCUTS' => 'Schnellstartleiste:',
'DESC_USING_LAYOUT_TOOLBAR' => 'Toolbox:',
'DESC_USING_LAYOUT_EDIT_ROWS' => 'Editiere Zeilen:',
'DESC_USING_LAYOUT_SELECT_FILE' => 'Layoutdatei w�hlen:',
'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Layout editieren:',
'DESC_USING_LAYOUT_ADD_FIELD' => 'Feld hinzuf�gen:',
'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Eintrag entfernen:',
'DESC_USING_LAYOUT_DISPLAY_HTML' => 'HTML Code anzeigen:',
'DESC_USING_LAYOUT_BLK1' => 'Mit dem  Layout Editor k�nnen Sie Felder, Register oder Panele verschieben und damit das Layout an Ihre Bed�rfnisse anpassen. W�hlen Sie zun�chst die Seite welche Sie anpassen m�chten mittels der �Select File� Auswahl.',
'DESC_USING_LAYOUT_BLK2' => ' W�hlen Sie die Seite aus, welche Sie editieren m�chten. Wenn Sie nicht sicher sind, welche Datei Sie bearbeiten m�chten, w�hlen Sie �Direktbearbeitung�. Dadurch erscheint ein Bearbeiten Icon an allen editierbaren Stellen der Applikation. Navigieren Sei einfach durch die Applikation zu der Seite welche Sie editieren m�chten. Klicken Sie auf das Bearbeiten Icon, und Sie werden in die Editieransicht dieser Seite geleitet. Bearbeitungen an einer Seite gehen verloren wenn die aktuelle Seite nicht gespeichert wird. ',
'DESC_USING_LAYOUT_BLK3' => ' Verschieben Sie einzelne <b>Objekte (das ind Felder, Beschriftungen oder Subpanels)</b> per Drag und Drop. Benutzen Sie dazu die Objektgriffe ',
'DESC_USING_LAYOUT_BLK4' => ' in der N�he des zu verschiebenden Objektes. Klicken sie dann auf den Objektgriff  an der Stelle wohin Sie das Objekt verschieben m�chten. Dadurch wird das ausgew�hlte Objekt von seiner urspr�nglichen Position auf die neue Position verschoben. Wenn sich dort schon ein Objekt befindet werden die Positionen ausgetauscht. Wenn Sie ein Objekt entfernen m�chten ziehen sie das Objekt auf die Toolbox in der linken Men�leiste.',
'DESC_USING_LAYOUT_BLK5' => ' erm�glicht das Hinzuf�gen und Entfernen von Zeilen in den Subpanels. Wenn Sie auf das Plus Symbol klicken wird eine Zeile unter der ausgew�hlten Zeile hinzugef�gt, wenn Sie auf das Minus Symbol klicken wird die ausgew�hlte Ziele entfernt.',
'DESC_USING_LAYOUT_BLK6' => 'Die Toolbox ist ein Hilfsmittel mit welchem neue Felder und Beschriftungen in ein Formular eingef�gt werden k�nnen. Objekte (Felder, Beschriftungen, Subpanels) welche vom Formular entfernt wurden k�nnen in der Toolbox aufbewahrt werden.',
'DESC_USING_LAYOUT_BLK7' => ' Es �ffnet sich ein Dialog in welchem der Feldtyp definiert werden kann. Nahc dem Hinzuf�gen wird das neue Feld in der Toolbox abgelegt. Von dort kann es mittels Objektgriff auf das Formular verschoben werden.',
'DESC_USING_LAYOUT_BLK8' => ' W�hlen Sie den Griff eines Objekts und klicken Sie auf den Text �Drag unwanted items here�. Dadurch wird das unerw�nschte Objekt in der Toolbox abgelegt.',
'DESC_USING_LAYOUT_BLK9' => ' Beim Ankreuzen dieser Checkbox wird der Html Code f�r jedes Feld im Tooltip angezeigt. Diese Anzeige ist sehr CPU- intensiv und sollte daher nur bei Bedarf verwendet werden.',
'DESC_USING_LAYOUT_BLK10' => 'Klicken Sie auf den �Layout speichern� Button um ein Layout zu speichern.',
'NO_RECORDS_LISTVIEW'=>'Damit eine Listenansicht editiert werden kann muss mindestens eine Datenzeile vorhanden sein.  Erstellen Sie daher bitte vor dem Editieren einen Datensatz f�r die Liste welche editiert werden soll.',
'LBL_SELECT_FILE'=>'Layoutdatei w�hlen',
'LBL_EDIT_LAYOUT'=>'Editiere Layout',
'LBL_EDIT_ROWS'=>'Editiere Zeilen',
'LBL_EDIT_COLUMNS'=>'Editiere Spalten',
'LBL_EDIT_LABELS'=>'Editiere Beschriftungen',
'LBL_EDIT_FIELDS'=>'Editiere benutzerdefinierte Felder',
'LBL_ADD_FIELDS'=>'Benutzerdefiniertes Feld hinzuf�gen',
'LBL_DISPLAY_HTML'=>'HTML Code anzeigen',
'LBL_SELECT_FILE'=> 'Layoutdatei w�hlen',
  

'LBL_SAVE_LAYOUT'=> 'Layout speichern', 
'LBL_SELECT_A_SUBPANEL' => 'Subpanel ausw�hlen', 
'LBL_SELECT_SUBPANEL' => 'Subpanel ausw�hlen', 
'LBL_TOOLBOX' => 'Toolbox', 
'LBL_STAGING_AREA' => 'Zwischenablage (Ziehen sie Objekte mit der Maus hierher)', 
'LBL_SUGAR_FIELDS_STAGE' => 'Sugar Felder (Klicken Sie auf ein Element um es in die Zwischenablage einzuf�gen)', 
'LBL_SUGAR_BIN_STAGE' => 'Sugar Bin (Klicken Sie auf ein Element um es in die Zwischenablage einzuf�gen)', 
'LBL_VIEW_SUGAR_FIELDS' => 'Sugar Felder anzeigen', 
'LBL_VIEW_SUGAR_BIN' => 'Sugar Bin anzeigen', 
'LBL_EDIT_IN_PLACE' => 'Direktbearbeitung:',

);
?>
