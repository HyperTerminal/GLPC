<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.13 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Verteilerlisten',
  'LBL_MODULE_TITLE' => 'Verteilerlisten: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Verteilerliste',
  'LBL_LIST_FORM_TITLE' => 'Verteilerlisten',
  'LBL_PROSPECT_LIST_NAME' => 'Name:',
  'LBL_NAME' => 'Name: ',
  'LBL_ENTRIES' => 'Gesamt Eintr�ge: ',
  'LBL_LIST_PROSPECT_LIST_NAME' => 'Verteilerliste',
  'LBL_LIST_ENTRIES' => 'Eintr�ge',
  'LBL_LIST_DESCRIPTION' => 'Beschreibung',
  'LBL_LIST_TYPE_NO' => 'Typ',
  'LBL_LIST_END_DATE' => 'Abschlussdatum',
  'LBL_DATE_ENTERED' => 'erstellt am',
  'LBL_DATE_MODIFIED' => 'ge�ndert am',
  'LBL_MODIFIED' => 'ge�ndert von: ',
  'LBL_CREATED' => 'erstellt von: ',
  'LBL_TEAM' => 'Team: ',
  'LBL_ASSIGNED_TO' => 'Bearbeitung durch: ',
  'LBL_DESCRIPTION' => 'Beschreibung: ',
  'LNK_NEW_CAMPAIGN' => 'Neue Kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagnen',
  'LNK_NEW_PROSPECT_LIST' => 'Neue Verteilerliste',
  'LNK_PROSPECT_LIST_LIST' => 'Verteilerlisten',
  'LBL_MODIFIED_BY' => 'ge�ndert von: ',
  'LBL_CREATED_BY' => 'erstellt von: ',
  'LBL_DATE_CREATED' => 'erstellt am: ',
  'LBL_DATE_LAST_MODIFIED' => 'ge�ndert am: ',
  'LNK_NEW_PROSPECT' => 'Neue Zielperson',
  'LNK_PROSPECT_LIST' => 'Zielpersonen',
  //'LBL_DEFAULT_SUBPANEL_TITLE' => 'Verteilerlisten',
  'LBL_PROSPECT_LISTS_SUBPANEL_TITLE' => 'Verteilerlisten',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
	'LBL_LEADS_SUBPANEL_TITLE' => 'Interessenten', 


	'LBL_PROSPECTS_SUBPANEL_TITLE'=>'Zielpersonen', 
	'LBL_COPY_PREFIX' =>'Kopie von', 
	'LBL_USERS_SUBPANEL_TITLE' =>'User', 
	'LBL_TYPE' => 'Typ', 
	'LBL_LIST_TYPE' => 'Typ:', 
	'LBL_LIST_TYPE_LIST_NAME'=>'Typ', 
	'LBL_NEW_FORM_TITLE'=>'Neue Verteilerliste', 
	'LBL_MARKETING_MESSAGE'=>'Email-Aussendung', 
	'LBL_DOMAIN_NAME'=>'Domain Name', 
	'LBL_DOMAIN'=>'Keine Mails and die Domain:', 


);


?>
