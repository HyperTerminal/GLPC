<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');

/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): krokogras
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.22 2006/04/02 10:07:21 krokogras Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/



$mod_strings = array (
	'ERR_ARCHIVE_EMAIL'		=> 'Fehler: Sie m�ssen die zu archivierende Emails ausw�hlen.',
	'ERR_DATE_START'		=> 'Beginndatum',
	'ERR_DELETE_RECORD'		=> 'Die Datensatz ID muss angegeben werden, damit der Datensatz gel�scht werden kann.',	
	'ERR_NOT_ADDRESSED'		=> 'Es muss eine Email Adresse ins Feld An, CC oder BCC eingegeben werden',
	'ERR_TIME_START'		=> 'Beginnzeit',
	'LBL_ACCOUNTS_SUBPANEL_TITLE'   => 'Kunden',
	'LBL_ADD_ANOTHER_FILE'		=> 'Eine weitere Datei hinzuf�gen',
	'LBL_ADD_FILE'			=> 'Datei hinzuf�gen',
	'LBL_ARCHIVED_MODULE_NAME'	=> 'Emails archivieren',
	'LBL_ATTACHMENTS'		=> 'Attachments:',
	'LBL_BCC'			=> 'Bcc:',
	'LBL_BODY'			=> 'Body:',
	'LBL_CC'			=> 'Cc:',
	'LBL_COLON'			=> ':',
	'LBL_COMPOSE_MODULE_NAME'	=> 'Email verfassen',
	'LBL_CONTACT_FIRST_NAME'	=> 'Kontakt Vorname',
	'LBL_CONTACT_LAST_NAME'		=> 'Kontakt Nachname',
	'LBL_CONTACT_NAME'			=> 'Kontakt:',
	'LBL_CONTACTS_SUBPANEL_TITLE'	=> 'Kontakte',
	'LBL_CREATED_BY'		=> 'erstellt von',
	'LBL_DATE_AND_TIME'		=> 'Versanddatum/-zeit:',
	'LBL_DATE_SENT'			=> 'Versanddatum:',
	'LBL_DATE'			=> 'Versanddatum:',
	'LBL_DESCRIPTION'		=> 'Beschreibung',
	'LBL_EDIT_ALT_TEXT'		=> 'Text Nachricht bearbeiten',
	'LBL_EDIT_MY_SETTINGS'		=> 'Meine Einstellungen bearbeiten',
	'LBL_EMAIL_ATTACHMENT'		=> 'Email Attachment',
	'LBL_LEADS_SUBPANEL_TITLE'	=> 'Interessenten',
	'LBL_EMAIL_SELECTOR'		=> 'Ausw�hlen',
	'LBL_EMAIL'			=> 'Email:',
	'LBL_ERROR_SENDING_EMAIL'	=> 'Fehler beim Mailversand!',
	'LBL_FROM_NAME'			=> 'Von Name',
	'LBL_FROM'			=> 'Von:',
	'LBL_HTML_BODY'			=> 'HTML Nachricht',
	'LBL_INVITEE'			=> 'Empf�nger',
	'LBL_MESSAGE_SENT'		=> 'Email wurde gesendet...',
	'LBL_MODIFIED_BY'		=> 'ge�ndert von',
	'LBL_MODULE_NAME_NEW'		=> 'Email archivieren',
	'LBL_MODULE_NAME'		=> 'Alle Emails',
	'LBL_MODULE_TITLE'		=> 'Emails: ',
	'LBL_NEW_FORM_TITLE'		=> 'Email archivieren',
	'LBL_NOT_SENT'			=> 'Fehler beim Mailversand!',
	'LBL_NOTE_SEMICOLON'		=> 'Tipp: Verwenden Sie bei mehreren Empf�ngern den Strichpunkt als Trennzeichen.',
	'LBL_SAVE_AS_DRAFT_BUTTON_KEY'  => 'R',
	'LBL_SAVE_AS_DRAFT_BUTTON_LABEL'=> 'Als Entwurf speichern',
	'LBL_SAVE_AS_DRAFT_BUTTON_TITLE'=> 'Als Entwurf speichern [Alt+R]',
	'LBL_SEARCH_FORM_DRAFTS_TITLE'  => 'Suche Entw�rfe',
	'LBL_SEARCH_FORM_SENT_TITLE'    => 'Suche versandte Email',
	'LBL_SEARCH_FORM_TITLE'		=> 'Email Suche',
	'LBL_SEND_BUTTON_KEY'		=> 'S',
	'LBL_SEND_BUTTON_LABEL'		=> 'Senden',
	'LBL_SEND_BUTTON_TITLE'		=> 'Senden [Alt+S]',
	'LBL_SEND'			=> 'SENDEN',
	'LBL_SENT_MODULE_NAME'		=> 'Gesendete Emails',
	'LBL_SHOW_ALT_TEXT'		=> 'Text Nachricht anzeigen',
	'LBL_SUBJECT'			=> 'Betreff:',
	'LBL_TEXT_BODY'			=> 'Text Nachricht',
	'LBL_TIME'			=> 'Versandzeit:',
	'LBL_TO_ADDRS'			=> 'An',
	'LBL_TO'			=> 'An:',
	'LBL_USE_TEMPLATE'		=> 'Vorlage verwenden:',
	'LBL_USERS_SUBPANEL_TITLE'	=> 'User',
	'LBL_USERS'			=> 'User',

	'LNK_ALL_EMAIL_LIST'		=> 'Alle Emails',
	'LNK_ARCHIVED_EMAIL_LIST'	=> 'Archivierte Emails',
	'LNK_CALL_LIST'			=> 'Anrufe',
	'LNK_DRAFTS_EMAIL_LIST'		=> 'Alle Entw�rfe',
	'LNK_EMAIL_LIST'		=> 'Emails',
	'LNK_EMAIL_TEMPLATE_LIST'	=> 'Alle Email Vorlagen',
	'LNK_MEETING_LIST'		=> 'Termine',
	'LNK_NEW_ARCHIVE_EMAIL'		=> 'Email archivieren',
	'LNK_NEW_CALL'			=> 'Neuer Anruf',
	'LNK_NEW_EMAIL_TEMPLATE'	=> 'Neue  Email Vorlage',
	'LNK_NEW_EMAIL'			=> 'Email archivieren',
	'LNK_NEW_MEETING'		=> 'Neuer Termin',
	'LNK_NEW_NOTE'			=> 'Neue Notiz oder Attachment',
	'LNK_NEW_SEND_EMAIL'		=> 'Neue Email',
	'LNK_NEW_TASK'			=> 'Neue Aufgabe',
	'LNK_NOTE_LIST'			=> 'Notizen',
	'LNK_SENT_EMAIL_LIST'		=> 'Gesendete Emails',
	'LNK_TASK_LIST'			=> 'Aufgaben',
	'LNK_VIEW_CALENDAR'		=> 'Heute',

	'LBL_LIST_ASSIGNED'		=> 'zugewiesen',
	'LBL_LIST_CONTACT_NAME'		=> 'Kontakt',
	'LBL_LIST_CONTACT'		=> 'Kontakt',
	'LBL_LIST_CREATED'		=> 'angelegt am',
	'LBL_LIST_DATE_SENT'		=> 'Datum',
	'LBL_LIST_DATE'			=> 'Datum',
	'LBL_LIST_FORM_DRAFTS_TITLE'    => 'Entw�rfe',
	'LBL_LIST_FORM_SENT_TITLE'	=> 'Gesendete Emails',
	'LBL_LIST_FORM_TITLE'		=> 'Email Liste',
	'LBL_LIST_FROM_ADDR'		=> 'Von',
	'LBL_LIST_RELATED_TO'		=> 'Zuordnung',
	'LBL_LIST_SUBJECT'		=> 'Betreff',
	'LBL_LIST_TIME'			=> 'Versandzeit',
	'LBL_LIST_TO_ADDR'		=> 'An',
	'LBL_LIST_TYPE'			=> 'Typ',

	'NTC_REMOVE_INVITEE'		=> 'Diesen Empf�nger entfernen?',
	'WARNING_SETTINGS_NOT_CONF'	=> 'Warnung: Ihre Email Einstellungen sind nicht richtig konfiguriert.',

	// for InboundEmail
	'LBL_BUTTON_REPLY_KEY'		=> 'r',
	'LBL_BUTTON_REPLY_TITLE'	=> 'Antworten [Alt+R]',
	'LBL_BUTTON_REPLY'		=> 'Antworten',
	'LBL_CASES_SUBPANEL_TITLE'	=> 'Anfragen',
	'LBL_INTENT'			=> 'Einr�cken',
	'LBL_MESSAGE_ID'		=> 'Message ID',
	'LBL_REPLY_TO_ADDRESS'		=> 'Antworten: Emailadresse',
	'LBL_REPLY_TO_NAME'		=> 'Antworten: Name',

	'LBL_LIST_BUG'			=> 'Bug',
	'LBL_LIST_CASE'			=> 'Anfrage',
	'LBL_LIST_CONTACT'		=> 'Kontakt',
	'LBL_LIST_LEAD'			=> 'Interessent',
	'LBL_LIST_TASK'			=> 'Aufgabe',

	// for Inbox
	'LBL_ALL'			=> 'Alle',
	'LBL_ASSIGN_WARN'		=> 'Stellen Sie sicher, dass alle 3 Optionen ausgew�hlt sind.',
	'LBL_BACK_TO_GROUP'		=> 'Zur�ck zum Gruppen-Posteingang',
	'LBL_BUTTON_DISTRIBUTE_KEY'	=> 'a',
	'LBL_BUTTON_DISTRIBUTE_TITLE'   => 'Zuweisen [Alt+A]',
	'LBL_BUTTON_DISTRIBUTE'		=> 'Zuweisen',
	'LBL_BUTTON_GRAB_KEY'		=> 't',
	'LBL_BUTTON_GRAB_TITLE'		=> 'Von der Gruppe �bernehmen [Alt+T]',
	'LBL_BUTTON_GRAB'		=> 'Von der Gruppe �bernehmen',
	'LBL_CREATE_BUG'		=> 'Neuen Bugbericht anlegen',
	'LBL_CREATE_CASE'		=> 'Neue Anfrage',
	'LBL_CREATE_CONTACT'		=> 'Neuer Kontakt',
	'LBL_CREATE_LEAD'		=> 'Neuer Interessent',
	'LBL_CREATE_TASK'		=> 'Neue Aufgabe',
	'LBL_DIST_TITLE'		=> 'Zuweisung',
	 
	'LBL_LOCK_FAIL_DESC'		=> 'Das gew�hlte Element ist zur Zeit nicht verf�gbar.',
	//pr�fen
	'LBL_LOCK_FAIL_USER'		=> ' has taken ownership.',
	'LBL_MASS_DELETE_ERROR'		=> 'Keine ausgew�hlten Elemente wurden gel�scht.',
	'LBL_NEW'			=> 'Neu',
	'LBL_NEXT_EMAIL'		=> 'N�chtstes freies Element',
	
	
	'LBL_NO_GRAB_DESC'		=> 'Keine neuen Eintr�ge.  Versuchen Sie es sp�ter noch einmal.',
	'LBL_QUICK_REPLY'		=> 'Aktion',
	'LBL_REPLIED'			=> 'beantwortet',
	'LBL_SELECT_TEAM'		=> 'Teams ausw�hlen',
	'LBL_TAKE_ONE_TITLE'		=> 'Reps',
	'LBL_TITLE_SEARCH_RESULTS'	=> 'Suchergebnisse',
	'LBL_TO'			=> 'An: ',
	 
	'LBL_TOGGLE_ALL'		=> 'Alle ausw�hlen',
	'LBL_UNKNOWN'			=> 'unbekannt',
	'LBL_UNREAD_HOME'		=> 'Ungelesene Emails',
	'LBL_UNREAD'			=> 'Ungelesen',
	'LBL_USE_ALL'			=> 'Alle Suchergebnisse',
	'LBL_USE_CHECKED'		=> 'Nur ausgew�hlte',
	
	'LBL_USE_MAILBOX_INFO'		=> 'Verwende "Von" Adresse der Mailbox',
	
	'LBL_USE'			=> 'Zuweisen:',
	'LBL_USER_SELECT'		=> 'User ausw�hlen',
	'LBL_USING_RULES'		=> 'Regeln verwenden:',
	'LBL_WARN_NO_DIST'		=> 'Keine Versandmethode ausgew�hlt',
	'LBL_WARN_NO_USERS'		=> 'Keine User ausgew�hlt',

	'LBL_LIST_STATUS'		=> 'Status',
	'LBL_LIST_TITLE_GROUP_INBOX'	=> 'Gruppen Posteingang',
	'LBL_LIST_TITLE_MY_DRAFTS'	=> 'Meine Entw�rfe',
	'LBL_LIST_TITLE_MY_INBOX'	=> 'Mein Posteingang',
	'LBL_LIST_TITLE_MY_SENT'	=> 'Mein Postausgang',

	'LNK_DATE_SENT'			=> 'Sendedatum',
	'LNK_GROUP_INBOX'		=> 'Gruppen Posteing.',
	'LNK_MY_DRAFTS'			=> 'Meine Entw�rfe',
	'LNK_MY_INBOX'			=> 'Mein Posteingang',
	'LNK_QUICK_REPLY'		=> 'Antworten',

	
	'LBL_ASSIGNED_TO'		=> 'Zuweisen an:',
	'LBL_MEMBER_OF'			=> 'Parent',
	'LBL_QUICK_CREATE'		=> 'Erzeuge.......',
	'LBL_STATUS'			=> 'Email Status:',
	'LBL_TYPE'			=> 'Typ:',
	
 
	
	'LBL_CONFIRM_DELETE'		=> 'M�chten Sie diesen Ordner wirklich l�schen?',
	'LBL_ADD_DOCUMENT'			=> 'Sugar Dokument hinzuf�gen',
	'LBL_ARCHIVED_EMAIL'		=> 'Archivierte Email',
	'LBL_BUGS_SUBPANEL_TITLE'	=> 'Bugs',
	'LBL_EMAIL_EDITOR_OPTION'	=> 'Send HTML Email',
	'LBL_EMAILS_ACCOUNTS_REL'	=> 'Emails:Kunden',
	'LBL_EMAILS_BUGS_REL'		=> 'Emails:Bugs',
	'LBL_EMAILS_CASES_REL'		=> 'Emails:Anfragen',
	'LBL_EMAILS_CONTACTS_REL'	=> 'Emails:Kontakte',
	'LBL_EMAILS_LEADS_REL'		=> 'Emails:Interessenten',
	'LBL_EMAILS_OPPORTUNITIES_REL'=> 'Emails:Verkaufschancen',
	'LBL_EMAILS_PROJECT_REL'	=> 'Emails:Projekte',
	'LBL_EMAILS_PROJECTTASK_REL'=> 'Emails:Projektaufgaben',
	'LBL_EMAILS_PROSPECT_REL'	=> 'Emails:Zielkunden',
	'LBL_EMAILS_TASKS_REL'		=> 'Emails:Aufgaben',
	'LBL_EMAILS_USERS_REL'		=> 'Emails:User',
	'LBL_LEADS_SUBPANEL_TITLE'	=> 'Interessenten',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Verkaufschancen',
	'LBL_PROJECT_SUBPANEL_TITLE'=> 'Projekte',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE'=> 'Projektaufgaben',
	
	'LBL_SEND_ANYWAYS'			=> 'Betreff f�r diese Email fehlt! Trotzdem senden/speichern?',
	'LBL_SIGNATURE'				=> 'Signatur',
	
		'LBL_BUTTON_CHECK'			=> 'Mail abrufen',
	'LBL_BUTTON_CHECK_TITLE'	=> 'Email abrufen [Alt+C]',
	'LBL_BUTTON_CHECK_KEY'		=> 'c',
	'LBL_BUTTON_FORWARD'		=> 'Weiterleiten',
	'LBL_BUTTON_FORWARD_TITLE'	=> 'Weiterleiten [Alt+F]',
	'LBL_BUTTON_FORWARD_KEY'	=> 'f',

	'LBL_INBOUND_TITLE'			=> 'Posteingang',
	'LBL_LIST_TITLE_MY_ARCHIVES'=> 'Meine archivierten Emails',
	'LNK_CHECK_MY_INBOX'		=> 'Meine Email abrufen',
	'LNK_MY_ARCHIVED_LIST'		=> 'Meine Archive',
);



?>