<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.12 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_TITLE' => 'Massen-Email Warteschlangen Management',
	'LBL_SEARCH_FORM_TITLE'=>'Suche: Warteschlange',
	'LBL_LIST_FORM_TITLE'=>'Warteschlange',
	'LBL_SEARCH_FORM_PROCESSED_TITLE'=>'Suche: Gesendete Emails',
	'LBL_LIST_FORM_PROCESSED_TITLE'=>'Gesendet',
	'LBL_LIST_CAMPAIGN'=> 'Kampagne',
'LBL_LIST_RECIPIENT_NAME'=>'Empf�nger Name',
'LBL_LIST_RECIPIENT_EMAIL'=>'Empf�nger Email',
'LBL_LIST_FROM_NAME'=>'Von Name',
'LBL_LIST_FROM_EMAIL'=>'Von Email',
'LBL_LIST_USER_NAME'=>'User Name',
'LBL_LIST_SEND_DATE_TIME'=>'Senden am',
'LBL_LIST_SEND_ATTEMPTS'=>'Sendeversuche',
'LBL_LIST_IN_QUEUE'=>'In Verarbeitung',
'LBL_VIEW_PROCESSED_EMAILS'=>'Zeige gesendete Emails',
'LBL_VIEW_QUEUED_EMAILS'=>'Zeige Emails in Warteschlange',


          'LBL_RELATED_ID'=>'Verkn�pfte Id', 
           'LBL_RELATED_TYPE'=>'Verkn�pfter Typ', 
           'LBL_MARKETING_ID'=>'Email-Aussendung-ID', 
           'LBL_LIST_MESSAGE_NAME'=>'Email-Aussendung', 
           'LBL_MODULE_NAME'=>'Email-Aussendungen', 
           'LBL_CONFIGURE_SETTINGS'=>'Konfigurieren', 
    
           'LBL_EMAILS_PER_RUN'=>'Anzahl der Emails pro Sendeversuch:', 
           'LBL_EMAIL_PER_RUN_REQ'=>'Anzahl der gesendenten Emails pro Sendeversuch:', 
           'LBL_LOCATION_ONLY'=>'Speicherort', 
           'LBL_LOCATION_TRACK'=>'Speicherort der Kampangen-Tracking Dateien (wie campaign_tracker.php)', 
           'LBL_DEFAULT_LOCATION'=>'Standard', 
           'LBL_CUSTOM_LOCATION'=>'Benutzerdefiniert', 
           'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE'=>'Einstellung von  site_url in Config.php', 
           'ERR_INT_ONLY_EMAIL_PER_RUN'=>'Nur ganze Zahlen erlaubt!', 
           'TXT_REMOVE_ME'=>'um sich von der Email-Liste abzumelden klicken Sie ', 
           'TXT_REMOVE_ME_ALT'=>'um sich von der Email-Liste abzumelden klicken Sie bitte ', 
           'TXT_REMOVE_ME_CLICK'=>'HIER', 
           'LBL_ID'=>'Id', 
           'LBL_OLD_ID'=>'Alte Id', 
           
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
	'LBL_MAIL_SMTPAUTH_REQ' => 'SMTP Authentifizierung verwenden?',
	'LBL_MAIL_SMTPPASS' => 'SMTP Passwort:',
	'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
	'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
	'LBL_MAIL_SMTPUSER' => 'SMTP Username:',
	
	
	
	'LBL_NOTIFICATION_ON_DESC' => 'Verst�ndigungen senden wenn Datens�tze an User zugewiesen werden.',
	'LBL_NOTIFY_FROMADDRESS' => '"Von" Emailadresse:',
	'LBL_NOTIFY_FROMNAME' => '"Von" Angezeigter Name:',
	'LBL_NOTIFY_ON' => 'Verst�ndigungen senden?',
	'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Standardm��ig Verst�ndigungen senden?',
	'LBL_NOTIFY_TITLE' => 'Email Verst�ndigung - Einstellungen',
           
 
  'LBL_OUTBOUND_EMAIL_TITLE'					=> 'Postausgang Email Einstellungen',    
  'LBL_EMAIL_USER_TITLE'						=> 'Benutzer Email Standardeinstellungen',     
  'LBL_EMAIL_DEFAULT_CLIENT'					=> 'Neue Emailnachrichten in diesem Format',
	'LBL_EMAIL_DEFAULT_EDITOR'					=> 'F�r neue Emailnachrichten diesen Client verwenden',         


);

?>
