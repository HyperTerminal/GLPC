<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.12 2006/04/02 10:20:58 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Notizen',
  'LBL_MODULE_TITLE' => 'Notizen: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Notizen',
  'LBL_LIST_FORM_TITLE' => 'Notizen - Liste',
  'LBL_NEW_FORM_TITLE' => 'Neue Notiz oder Attachment',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'geh�rt zu',
  'LBL_LIST_DATE_MODIFIED' => 'ge�ndert am',
  'LBL_LIST_FILENAME' => 'Attachment',
  'LBL_NOTE' => 'Notiz:',
  'LBL_NOTE_SUBJECT' => 'Notiz Betreff:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_FILENAME' => 'Attachment:',
  'LBL_FILE_MIME_TYPE' => 'Mime Typ', 
  'LBL_FILE_URL' => 'Datei URL', 
  'LBL_CLOSE' => 'Schliessen:',
  'LBL_RELATED_TO' => 'geh�rt zu:',
   
  'LBL_PARENT_TYPE' => '�bergeordneter Eintrag',
  'LBL_PARENT_ID' => 'Parent ID:',
  'LBL_OPPORTUNITY_ID' => 'Verkaufschancen ID:',
  'LBL_ACCOUNT_ID' => 'Kunden ID:',
	'LBL_CASE_ID' => 'Anfragen ID:',
	'LBL_CONTACT_ID' => 'Kontakt ID:',
	'LBL_LEAD_ID' => 'Interessenten ID:',
	
  'LBL_EMAIL_ADDRESS' => 'Email Adresse:',
  'LBL_COLON' => ':',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',

	'LNK_NEW_CALL'=>'Neuer Anruf',
	'LNK_NEW_MEETING'=>'Neuer Termin',
	'LNK_NEW_TASK'=>'Neue Aufgabe',
	'LNK_NEW_NOTE'=>'Neue Notiz oder Attachment',
	'LNK_NEW_EMAIL'=>'Email archivieren',
	'LNK_CALL_LIST'=>'Anrufe',
	'LNK_MEETING_LIST'=>'Termine',
	'LNK_TASK_LIST'=>'Aufgaben',
	'LNK_NOTE_LIST'=>'Notizen',
	'LNK_EMAIL_LIST'=>'Emails',
	'LNK_IMPORT_NOTES'=>'Notizen importieren',
	'LNK_VIEW_CALENDAR' => 'Heute',
	'LBL_PORTAL_FLAG'=>'Im Portal anzeigen?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Notizen', 
	'LBL_STATUS'=>'Status', 
	'LBL_NOTE_STATUS'=>'Status', 
	'LBL_DESCRIPTION' => 'Beschreibung', 
	
	'LBL_PRODUCT_ID' => 'Product ID:',
	'LBL_QUOTE_ID' => 'Angebot ID:',
	
	'LBL_MEMBER_OF' => 'Mitglied von:',
	'LBL_LIST_STATUS' => 'Status', 
	'LBL_LIST_CONTACT' => 'Kontakte', 



);


?>
