<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.10 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumente',
	'LBL_MODULE_TITLE' => 'Dokumente: Home',
	'LNK_NEW_DOCUMENT' => 'Neues Dokument',
	'LNK_DOCUMENT_LIST'=> 'Dokumentenliste',
	'LBL_DOC_REV_HEADER' => 'Dokumentversionen',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'Dokument Id',	
	'LBL_NAME' => 'Dokumentname',
	'LBL_DESCRIPTION' => 'Beschreibung',
	'LBL_CATEGORY' => 'Kategorie',
	'LBL_SUBCATEGORY' => 'Subkategorie',
	'LBL_STATUS' => 'Status', 
	'LBL_CREATED_BY'=> 'erstellt von',
	'LBL_DATE_ENTERED'=> 'erstellt am',
	'LBL_DATE_MODIFIED'=> 'ge�ndert am',
	'LBL_DELETED' => 'gel�scht',
	'LBL_MODIFIED'=> 'ge�ndert von',
	'LBL_CREATED'=> 'erstellt von',
	
	'LBL_REVISION_NAME' => 'Versionsnummer',
	'LBL_FILENAME' => 'Dateiname',
	'LBL_MIME' => 'Mime Type',
	'LBL_REVISION' => 'Version',
	'LBL_DOCUMENT' => 'Verwandtes Dokument',
	'LBL_LATEST_REVISION' => 'Letzte Version',
	'LBL_CHANGE_LOG'=> '�nderungsprotokoll',
	'LBL_ACTIVE_DATE'=> 'Erscheinungsdatum',
	'LBL_EXPIRATION_DATE' => 'Ablaufdatum',
	'LBL_FILE_EXTENSION'  => 'Datei Extension',
	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Unspezifiziert',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Dokumentname:',
	'LBL_FILENAME' => 'Dateiname:',
	'LBL_DOC_VERSION' => 'Version:',
	'LBL_CATEGORY_VALUE' => 'Kategorie:',
	'LBL_SUBCATEGORY_VALUE'=> 'Subkategorie:',
	'LBL_DOC_STATUS'=> 'Status:',
	'LBL_LAST_REV_CREATOR' => 'Versionsautor:',
	'LBL_LAST_REV_DATE' => 'Versionsdatum:',
	'LBL_DOWNNLOAD_FILE'=> 'Dokument downloaden:',
	



	'LBL_DOC_DESCRIPTION'=>'Beschreibung:',
	'LBL_DOC_ACTIVE_DATE'=> 'Erscheinungsdatum:',
	'LBL_DOC_EXP_DATE'=> 'Ablaufdatum:',
	
	//document list view.	
	'LBL_LIST_FORM_TITLE' => 'Dokumentenliste',	
	'LBL_LIST_DOCUMENT' => 'Dokument',
	'LBL_LIST_CATEGORY' => 'Kategorie',
	'LBL_LIST_SUBCATEGORY' => 'Subkategorie',
	'LBL_LIST_REVISION' => 'Version',
	'LBL_LIST_LAST_REV_CREATOR' => 'Autor',
	'LBL_LIST_LAST_REV_DATE' => 'Versionsdatum',
	'LBL_LIST_VIEW_DOCUMENT'=>'Dokument anzeigen',
	'LBL_LIST_ACTIVE_DATE' => 'Erscheinungsdatum',
	'LBL_LIST_EXP_DATE' => 'Ablaufdatum',
	'LBL_LIST_STATUS'=>'Status',
	
	//document revisions.
	//'LBL_REV_LIST_REVISION' => 'Version',
	//'LBL_REV_LIST_ENTERED' => 'erstellt am',
	//'LBL_REV_LIST_CREATED' => 'erstellt von',
	//'LBL_REV_LIST_LOG'=> '�nderungsprotokoll',
	
	//'LBL_CURRENT_DOC_VERSION'=> 'Aktuelle Version:',
	'LBL_CHANGE_LOG'=> '�nderungsprotokoll:',
	'LBL_SEARCH_FORM_TITLE'=> 'Suche Dokumente',
	//document search form.
	'LBL_SF_DOCUMENT' => 'Dokumentname:',
	'LBL_SF_CATEGORY' => 'Kategorie:',
	'LBL_SF_SUBCATEGORY'=> 'Subkategorie:',
	'LBL_SF_ACTIVE_DATE' => 'Erscheinungsdatum:',
	'LBL_SF_EXP_DATE'=> 'Ablaufdatum:',
	
	'DEF_CREATE_LOG' => 'Dokument erstellt',
	
	//error messages
	'ERR_DOC_NAME'=>'Dokumentname',
	'ERR_DOC_ACTIVE_DATE'=>'Erscheinungsdatum',
	'ERR_DOC_EXP_DATE'=> 'Ablaufdatum',
	'ERR_FILENAME'=> 'Dateiname',
	'ERR_DOC_VERSION'=> 'Dokumentversion',
	'ERR_DELETE_CONFIRM'=> 'Diese Dokumentversion l�schen?',
	'ERR_DELETE_LATEST_VERSION'=> 'Die letzte Version eines Dokuments kann nicht gel�scht werden!',
		 
  'LNK_NEW_MAIL_MERGE' => 'Serienbrief', 
  'LBL_MAIL_MERGE_DOCUMENT' => 'Serienbriefvorlage:', 
	 
	
  'LBL_TREE_TITLE' => 'Dokumente', 
  
  	'LBL_RELATED_DOCUMENT_ID'=>'Verkn�pfte Dokument-ID',
	'LBL_RELATED_DOCUMENT_REVISION_ID'=>'Verkn�pfte Dokumentversions-ID',
	'LBL_IS_TEMPLATE'=>'Ist eine Vorlage',
	'LBL_TEMPLATE_TYPE'=>'Dokumenttyp',


	'LBL_DET_RELATED_DOCUMENT'=>'Verkn�pftes Dokument:',
	'LBL_DET_RELATED_DOCUMENT_VERSION'=>"Version des verk�pften Dokuments:",
	'LBL_DET_IS_TEMPLATE'=>'Vorlage? :',
	'LBL_DET_TEMPLATE_TYPE'=>'Dokumenttyp:',
	
	
		
			//sub-panel vardefs.
	'LBL_LIST_DOCUMENT_NAME'=>'Dokumentname',
	// Pr�fen 4.2
	'LBL_CONTRACT_NAME'=>'Vertrag Name:',
	'LBL_LIST_IS_TEMPLATE'=>'Vorlage?',
	'LBL_LIST_TEMPLATE_TYPE'=>'Dokumenttyp',
	'LBL_LIST_SELECTED_REVISION'=>'Gew�hlte Version',
	'LBL_LIST_LATEST_REVISION'=>'Letzte Version',
);


?>
