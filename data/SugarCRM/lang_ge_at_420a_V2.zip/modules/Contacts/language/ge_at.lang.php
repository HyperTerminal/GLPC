<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.23 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM_ID' => 'Team ID',
  'LBL_MODULE_NAME' => 'Kontakte',
  'LBL_INVITEE' => 'Verkn�pfte Kontakte',
  'LBL_MODULE_TITLE' => 'Kontakte: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Kontakte',
  'LBL_LIST_FORM_TITLE' => 'Kontaktliste',
  'LBL_NEW_FORM_TITLE' => 'Neuer Kontakt',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakt-Verkaufschance:',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_BUSINESSCARD' => 'Visitenkarte',
  'LBL_LIST_NAME' => 'Kontaktname',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktname',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Email2',
  'LBL_LIST_PHONE' => 'Telefon B�ro',
  'LBL_LIST_CONTACT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'Vorname',
  'LBL_FULL_NAME' => 'Vollst�ndiger Name:',
  'LBL_ASSIGNED_TO_NAME' => 'zugewiesen an',
  
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT

  'LBL_EXISTING_CONTACT' => 'Es wurde ein existierender Kontakt werwendet',
  'LBL_CREATED_CONTACT' => 'Es wurde ein neuer Kontakt erstellt',
  'LBL_EXISTING_ACCOUNT' => 'Es wurde ein existierender Kunde werwendet',
  'LBL_EXISTING_OPPORTUNITY'=> 'Es wurde eine existierende Verkaufschance verwendet',
  'LBL_CREATED_ACCOUNT' => 'Es wurde ein neuer Kunder erstellt',
  'LBL_CREATED_CALL' => 'Es wurde ein neuer Anruf erstellt',
  'LBL_CREATED_MEETING' => 'Es wurde ein neuer Termin erstellt',
  'LBL_ADDMORE_BUSINESSCARD' => 'Weiter Visitenkarte eingeben',
  'LBL_ADD_BUSINESSCARD' => 'Visitenkarte eingeben',
  'LBL_NAME' => 'Name:',
  'LBL_CONTACT_NAME' => 'Kontakt Name:',
  'LBL_CONTACT_INFORMATION' => 'Kontakt Informationen',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_OFFICE_PHONE' => 'Telefon B�ro:',
  'LBL_ACCOUNT_NAME' => 'Kunde:',
  'LBL_ACCOUNT_ID' => 'Kunden-ID',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_MOBILE_PHONE' => 'Telefon Mobil:',
  'LBL_MODIFIED' => 'ge�ndert von User ID',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_ID' => 'ID:',
  'LBL_LEAD_SOURCE' => 'Herkunft:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Hauptadresse Strasse:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Hauptadresse Stadt:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Hauptadresse Land:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Hauptadresse BL:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Hauptadresse PLZ:',
  'LBL_ALT_ADDRESS_STREET' => 'Zusatzadresse Strasse:',
  'LBL_ALT_ADDRESS_CITY' => 'Zusatzadresse Stadt:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Zusatzadresse Land:',
  'LBL_ALT_ADDRESS_STATE' => 'Zusatzadresse BL:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Zusatzadresse PLZ:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_BIRTHDATE' => 'Geburtstag:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email2:',
  'LBL_ANY_EMAIL' => 'Beliebige Emailadresse:',
  'LBL_REPORTS_TO' => 'Berichte an:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_PORTAL_NAME' => 'Portal Username:',
  'LBL_NEW_PORTAL_PASSWORD' => 'Neues Portal Passwort:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Passwort ist gesetzt:',
  'LBL_PORTAL_ACTIVE' => 'Portal aktiv:',
  'LBL_PORTAL_INFORMATION' => 'Portal Einstellungen',
  'LBL_ASSISTANT_PHONE' => 'Assistent Telefon:',
  'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Hauptadresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Zusatzadresse:',
  'LBL_ANY_ADDRESS' => 'Beliebige Adresse:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_PORTAL_APP'=>'Portal Applikation',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beschreibung',
  'LBL_ADDRESS_INFORMATION' => 'Adressangaben',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_REPORTS_TO_ID'=>'Berichte an ID',
  'LBL_OPP_NAME' => 'Verkaufschance Name:',
  'LBL_OPPORTUNITY_ROLE_ID' => 'Verkaufschance Rollen ID:',
  'LBL_IMPORT_VCARD' => 'Importiere vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Beim Importieren einer vCard automatisch neuen Kontakt anlegen.',
  'LBL_DUPLICATE' => 'M�glicherweise doppelter Kontakteintrag',
  'MSG_SHOW_DUPLICATES' => 'Ein �hnlicher Kontakt ist bereits vorhanden. W�hlen Sie einen bereits existierenden Kontakt aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Kontaktdaten zu verwenden, oder klicken Sie auf Abbrechen.',
  'MSG_DUPLICATE' => 'Ein �hnlicher Kontakt ist bereits vorhanden. W�hlen Sie einen bereits existierenden Kontakt aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Kontaktdaten zu verwenden, oder klicken Sie auf Abbrechen.',
  'LNK_CONTACT_LIST' => 'Kontakte',
  'LNK_IMPORT_VCARD' => 'Kontakt von vCard',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_EMAIL' => 'Email archivieren',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
  'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen?',
  'NTC_REMOVE_CONFIRMATION' => 'Kontakt von der Anfrage entfernen?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Diesen Kontakt als verkn�pften Kontakt entfernen?',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopiere Hauptadresse nach Zusatzadresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopiere Zusatzadresse nach Hauptadresse',
  'LBL_SALUTATION' => 'Anrede',
  'LBL_SAVE_CONTACT' => 'Kontakt speichern',
  'LBL_CREATED_OPPORTUNITY' =>'es wurde eine neue Verkaufschance erstellt',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Zum Anlegen einer Verkaufschance muss ein Kunde angegeben werden.\n  Bitte w�hlen Sie einen existierenden Kunden oder geben Sie einen neuen Kunden ein.',
  'LNK_SELECT_ACCOUNT' => "Existierender Kunde",
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Markierte Kontakte �bernehmen',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Markierte Kontakte �bernehmen',
  'LBL_INVALID_EMAIL'=>'Email-Adresse ung�ltig:',
  'LBL_NOTE_SUBJECT' =>'Notiz Betreff',

	'LBL_PRIMARY_ADDRESS_STREET_2' => 'Hauptadresse Zeile 2', 
	'LBL_PRIMARY_ADDRESS_STREET_3' => 'Hauptadresse Zeile 3', 
	'LBL_ALT_ADDRESS_STREET_2' => 'Zusatzadresse Zeile 2', 
	'LBL_ALT_ADDRESS_STREET_3' => 'Zusatzadresse Zeile 3', 
	'LBL_SYNC_CONTACT' => 'Kontakt synchronisieren:', 
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kontakte', 
	'LBL_PRODUCTS_TITLE'=>'Produkte', 
	'LBL_RELATED_CONTACTS_TITLE'=>'Verkn�pfte Kontakte', 
	'LBL_DATE_MODIFIED' => 'ge�ndert am', 
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
	'LBL_DIRECT_REPORTS_SUBPANEL_TITLE'=>'Verkn�pfte Kontakte', 
	'LBL_OPPORTUNITY_ROLE'=>'Verkaufschance Rolle', 
	
	'LBL_LEADS_SUBPANEL_TITLE' => 'Interessenten',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Verkaufschancen',
	'LBL_CASES_SUBPANEL_TITLE' => 'Anfragen',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Bugs',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekte',
	 
	 'LBL_COPY_ADDRESS_CHECKED' => 'Adresse zu ausgew�hlten Kontakten kopieren', 
	 'LBL_TARGET_OF_CAMPAIGNS' => 'Kampagnen (Zielperson von) :', 
	 'LBL_CAMPAIGNS' =>      'Kampagnen', 
	 'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagnen Protokoll', 
   
	 'LBL_LIST_ACCEPT_STATUS' => '�bernahme Status',
	
);

?>
