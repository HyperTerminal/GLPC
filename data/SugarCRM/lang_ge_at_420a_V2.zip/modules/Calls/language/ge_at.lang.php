<?php
 if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.18 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Anrufe',
  'LBL_MODULE_TITLE' => 'Anrufe: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Anrufe',
  'LBL_LIST_FORM_TITLE' => 'Anrufliste',
  'LBL_NEW_FORM_TITLE' => 'Neuer Anruf',
  'LBL_LIST_CLOSE' => 'Schliessen',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'geh�rt zu',
  'LBL_LIST_DATE' => 'Beginndatum',
  'LBL_LIST_TIME' => 'Beginnzeit',
  'LBL_LIST_DURATION' => 'Dauer',
  'LBL_LIST_DIRECTION' => 'Richtung',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_REMINDER' => 'Erinnerung:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_DESCRIPTION_INFORMATION' => 'Weitere Informationen',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_STATUS' => 'Status:',
  'LBL_DIRECTION' => 'Richtung:',
  'LBL_DATE' => 'Datum:',
  'LBL_DURATION' => 'Dauer:',
  'LBL_DURATION_HOURS' => 'Dauer in Stunden:',
  'LBL_DURATION_MINUTES' => 'Dauer in Minuten:',
  'LBL_HOURS_MINUTES' => '(Stunden/Minuten)',
  'LBL_CALL' => 'Anruf:',
  'LBL_DATE_TIME' => 'Beginndatum & -zeit:',
  'LBL_TIME' => 'Zeit:',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'geplant',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
  'LNK_NEW_EMAIL' => 'Email archivieren',
  'LNK_CALL_LIST' => 'Anrufe',
  'LNK_MEETING_LIST' => 'Termine',
  'LNK_TASK_LIST' => 'Aufgaben',
  'LNK_NOTE_LIST' => 'Notizen',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Heute',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_REMOVE_INVITEE' => 'Teilnehmer von Anruf einfernen?',
  'LBL_INVITEE' => 'Teilnehmer',
  'LBL_RELATED_TO' => 'geh�rt zu:',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
	'LBL_SCHEDULING_FORM_TITLE' => 'Zeitplan',
  'LBL_ADD_INVITEE' => 'Teilnehmer hinzuf�gen',
  'LBL_NAME' => 'Name',
  'LBL_FIRST_NAME' => 'Vorname',
  'LBL_LAST_NAME' => 'Nachname',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Telefon',
  'LBL_REMINDER' => 'Erinnerung:',
  'LBL_SEND_BUTTON_TITLE'=>'An Teilnehmer senden [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'An Teilnehmer senden',
	'LBL_DATE_END'=>'Abschlussdatum',
	'LBL_TIME_END'=>'Abschlusszeit',
	'LBL_REMINDER_TIME'=>'Erinnerungszeit',
   'LBL_SEARCH_BUTTON'=> 'Suchen',
   'LBL_ADD_BUTTON'=> 'Hinzuf�gen',
   'LBL_DEFAULT_SUBPANEL_TITLE' => 'Anrufe', 
	 'LBL_LOG_CALL'=> 'Anruf aufzeichnen', 
	 'LNK_SELECT_ACCOUNT'=> 'Kunden ausw�hlen', 
	 'LNK_NEW_ACCOUNT'=> 'Neuer Kunde', 
	 'LNK_NEW_OPPORTUNITY'=> 'Neue Verkaufschance', 
	 'LBL_DEL' => 'L�schen', 

   'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
   'LBL_USERS_SUBPANEL_TITLE' => 'User', 
   
	'LBL_OUTLOOK_ID' => 'Outlook ID', 
	'LBL_MEMBER_OF' => 'Mitglied von', 
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Notizen', 



);


?>
