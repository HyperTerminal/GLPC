<?php
 if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.12 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Bug Tracker',
  'LBL_MODULE_TITLE' => 'Bug Tracker: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Bug',
  'LBL_LIST_FORM_TITLE' => 'Bug Liste',
  'LBL_NEW_FORM_TITLE' => 'Neuen Bug berichten',
  'LBL_CONTACT_BUG_TITLE' => 'Kontakt-Bug:',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_BUG' => 'Bug:',
  'LBL_BUG_NUMBER' => 'Bug Nummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Priorit�t:',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_CONTACT_NAME' => 'Kontakt Name:',
  'LBL_BUG_SUBJECT' => 'Bug Betreff:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Priorit�t',
  'LBL_LIST_RELEASE' => 'Release',
  'LBL_LIST_RESOLUTION' => 'L�sung',
  'LBL_LIST_LAST_MODIFIED' => 'ge�ndert am',
  'LBL_INVITEE' => 'Kontakte',
  'LBL_TYPE' => 'Typ:',
  'LBL_LIST_TYPE' => 'Typ',
  'LBL_RESOLUTION' => 'L�sung:',
  'LBL_RELEASE' => 'Release:',
  'LNK_NEW_BUG' => 'Neuen Bug berichten',
  'LNK_BUG_LIST' => 'Bugs',
  'NTC_REMOVE_INVITEE' => 'Kontakt von dieser Fehlermeldung entfernen?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Bug vom Kunden entfernen?',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'LBL_LIST_MY_BUGS' => 'Meine Bugs',
  
  'LBL_FOUND_IN_RELEASE' => 'Gefunden in Release:',
  'LBL_FIXED_IN_RELEASE' => 'Behoben in Release:',
  'LBL_WORK_LOG' => 'Arbeitsprotokoll:',
  'LBL_SOURCE' => 'Quelle:',
  'LBL_PRODUCT_CATEGORY' => 'Kategorie:',
  
  'LBL_CREATED_BY' => 'erstellt von:',
  'LBL_DATE_CREATED' => 'erstellt am:',
  'LBL_MODIFIED_BY' => 'ge�ndert von:',
  'LBL_DATE_LAST_MODIFIED' => 'ge�ndert am:',

  'LBL_LIST_EMAIL_ADDRESS' => 'Email Adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Name',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_PHONE' => 'Telefon',
  'NTC_DELETE_CONFIRMATION' => 'Kontakt von dieser Fehlermeldung entfernen?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Bug Tracker', 
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Kunden', 
	'LBL_CASES_SUBPANEL_TITLE' => 'Anfragen', 
	'LBL_SYSTEM_ID' => 'System ID',


  
  );


?>
