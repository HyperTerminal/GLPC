<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.2 2006/04/01 12:22:06 krokogras Exp $
 * Description:  Defines the Austrian German language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_ID'=>'Id',
	'LBL_TRACKER_KEY'=>'Tracker Key',
	'LBL_TRACKER_URL'=>'Tracker URL',
	'LBL_TRACKER_NAME'=>'Tracker Name',
	'LBL_CAMPAIGN_ID'=>'Kampagnen Id',
	'LBL_DATE_ENTERED'=>'angelegt am',
	'LBL_DATE_MODIFIED'=>'ge�ndert am',
	'LBL_MODIFIED_USER_ID'=>'ge�ndert von User Id',
	'LBL_CREATED_BY'=>'angelegt von',
	'LBL_DELETED'=>'Gel�scht',
	'LBL_CAMPAIGN'=>'Kampagne',
	'LBL_OPTOUT'=>'Opt-out',
	
	'LBL_MODULE_NAME'=>'Kampagnen Trackers',
	'LBL_EDIT_CAMPAIGN_NAME'=>'Kampagnen Name:',
	'LBL_EDIT_TRACKER_NAME'=>'Tracker Name:',
	'LBL_EDIT_TRACKER_URL'=>'Tracker URL:',
	
	'LBL_SUBPANEL_TRACKER_NAME'=>'Name',
	'LBL_SUBPANEL_TRACKER_URL'=>'URL',
	'LBL_SUBPANEL_TRACKER_KEY'=>'Key',
	'LBL_EDIT_MESSAGE_URL'=>'URL f�r Email-Kampagne:',
	'LBL_EDIT_TRACKER_KEY'=>'Tracker Key:',
	'LBL_EDIT_OPT_OUT'=>'Opt-out Link?',
	'LNK_CAMPAIGN_LIST'=>'Kampagnen',
);

?>
