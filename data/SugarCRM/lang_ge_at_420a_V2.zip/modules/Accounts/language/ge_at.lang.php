<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');

/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.16 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kunden',
  'LBL_MODULE_TITLE' => 'Kunden: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Kunden',
  'LBL_LIST_FORM_TITLE' => 'Kundenliste',
  'LBL_NEW_FORM_TITLE' => 'Neuer Kunde',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Subunternehmen',
  'LBL_BUG_FORM_TITLE' => 'Kunden',
  'LBL_LIST_ACCOUNT_NAME' => 'Kundenname',
  'LBL_LIST_CITY' => 'Stadt',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Bundesland',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Name',
  
  'LBL_BILLING_ADDRESS_STREET_2' =>'Rechnungsadresse Zeile 2', 
  'LBL_BILLING_ADDRESS_STREET_3' =>'Rechnungsadresse Zeile 3', 
  'LBL_BILLING_ADDRESS_STREET_4' =>'Rechnungsadresse Zeile 4', 
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Lieferadresse Zeile 2', 
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Lieferadresse Zeile 3', 
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Lieferadresse Zeile 4', 

  
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Kundendaten',
  'LBL_ACCOUNT' => 'Kunde:',
  'LBL_ACCOUNT_NAME' => 'Kundenname:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_PHONE_ALT' => 'Pager:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Symbol:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_MEMBER_OF' => 'Hauptunternehmen:',
  'LBL_PHONE_OFFICE' => 'Telefon B�ro:',
  'LBL_PHONE_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Angestellte:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email2:',
  'LBL_ANY_EMAIL' => 'Beliebige Email-Adresse:',
  'LBL_OWNERSHIP' => 'Eigent�mer:',
  'LBL_RATING' => 'Bewertung:',
  'LBL_INDUSTRY' => 'Branche:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Typ:',
  'LBL_ANNUAL_REVENUE' => 'Jahresumsatz:',
  'LBL_ADDRESS_INFORMATION' => 'Rechnungs- und Lieferadresse',
  'LBL_BILLING_ADDRESS' => 'Rechnungsadresse:',
  'LBL_BILLING_ADDRESS_STREET' => 'Rechnungsadresse Strasse:',
  'LBL_BILLING_ADDRESS_CITY' => 'Rechnungsadresse Stadt:',
  'LBL_BILLING_ADDRESS_STATE' => 'Rechnungsadresse BL:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Rechnungsadresse PLZ:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Rechnungsadresse Land:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Lieferadresse Strasse:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Lieferadresse Stadt:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Lieferadresse BL:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Lieferadresse PLZ:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Lieferadresse Land:',
  'LBL_SHIPPING_ADDRESS' => 'Lieferadresse:',
  'LBL_DATE_MODIFIED' => 'ge�ndert am:',
  'LBL_DATE_ENTERED' => 'erstellt am:',
  'LBL_ANY_ADDRESS' => 'Beliebige  Adresse:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Zus�tzliche Informationen',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopiere Rechnungsadresse in Lieferadresse',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopiere Lieferadresse in Rechnungsadresse',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Diesen Eintrag als Subunternehmen entfernen?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Wollen Sie diesen Datensatz wirklich entfernen?',
  'LBL_DUPLICATE' => 'M�glicherweise Kunden-Duplikat',
  'MSG_SHOW_DUPLICATES' => '. Ein �hnlicher Kundeneintrag ist bereits vorhanden. W�hlen Sie einen bereits existierenden Kunden aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Kundendaten zu verwenden, oder klicken Sie auf Abbrechen.',
  'MSG_DUPLICATE' => 'Ein �hnlicher Kundeneintrag ist bereits vorhanden. W�hlen Sie einen bereits existierenden Kunden aus der Liste unten, oder klicken Sie auf Speichern um die gerade eingegebenen Kundendaten zu verwenden, oder klicken Sie auf Abbrechen.',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_ACCOUNT_LIST' => 'Kunden',
  'LBL_INVITEE' => 'Kontakte',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen?',
  'LBL_SAVE_ACCOUNT' => 'Kunde speichern',
  'LBL_BUG_FORM_TITLE' => 'Kunden',
  'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Kunden vom Projekt entfernen?',
	
	
	'LBL_USERS_ASSIGNED_LINK'=>'zugewiesen an', 
	 'LBL_USERS_MODIFIED_LINK'=>'ge�ndert von', 
	 'LBL_USERS_CREATED_LINK'=>'erstellt von', 
	 'LBL_TEAMS_LINK'=>'Teams', 
	 'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kunden', 
	 'LBL_PRODUCTS_TITLE'=>'Produkte', 
	 'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
	 'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
	 'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'Subunternehmen', 
	 'LBL_NAME'=>'Name:', 
	   
   'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte', 
   'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Verkaufschancen', 
   'LBL_LEADS_SUBPANEL_TITLE' => 'Interessenten', 
   'LBL_CASES_SUBPANEL_TITLE' => 'Anfragen', 

   'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Subunternehmen', 
   'LBL_BUGS_SUBPANEL_TITLE' => 'Bugs', 
   'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekte', 
   'LBL_PUSH_CONTACTS_BUTTON_TITLE' => 'Kopieren...', 
   'LBL_PUSH_CONTACTS_BUTTON_LABEL' => 'Zu Kontakten kopieren', 
   'LBL_ASSIGNED_TO_NAME' => 'zugewiesen an:',



);


?>
