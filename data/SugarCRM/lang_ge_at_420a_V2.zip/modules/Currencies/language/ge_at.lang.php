<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.10 2006/04/02 10:20:56 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'W�hrungen',
  'LBL_CURRENCY' => 'W�hrung',
  'LBL_ADD' => 'Hinzuf�gen',
  'LBL_MERGE' => 'Zusammenf�hren',
  'LBL_MERGE_TXT' => 'Bitte w�hlen Sie die W�hrungen aus, welche Sie zur ausgew�hlten W�hrung zusammenf�hren m�chten. Alle markierten W�hrungen werden gel�scht und alle Betr�ge in dieser W�hrung werden in die ausgew�hlte W�hrung konvertiert.',
  'LBL_US_DOLLAR' => 'U.S. Dollar',
  'LBL_DELETE' => 'L�schen',
  'LBL_LIST_SYMBOL' => 'W�hrung Symbolzeichen',
  'LBL_LIST_NAME' => 'W�hrung Name',
  'LBL_LIST_ISO4217' => 'ISO 4217 Code',
  'LBL_UPDATE' => 'Speichern',
  'LBL_LIST_RATE' => 'Umrechnungsfaktor',
  'LBL_LIST_STATUS' => 'Status',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
  'LNK_NEW_CASE' => 'Neue Anfrage',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_EMAIL' => 'Neue Email',
  'LNK_NEW_MEETING' => 'Neuer Termin',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen? Es k�nnte besser sein, den Status auf inaktiv zu setzen, da sonst Datens�tze welche diese W�hrung verwenden bei Aufruf in die Standardw�hrung umgewandelt werden.',
  'currency_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
);


?>
