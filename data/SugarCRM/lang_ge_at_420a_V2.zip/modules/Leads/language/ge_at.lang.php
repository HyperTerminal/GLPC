<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: ge_at.lang.php,v 1.18 2006/04/02 10:20:57 krokogras Exp $
 * Description:  Defines the Austrian (German) language pack for the 4.2.0 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  
  'LBL_ASSIGNED_TO_NAME' => 'zugewiesen an',
  'LBL_MODULE_NAME' => 'Interessenten',
  'LBL_INVITEE' => 'Verkn�pfte Kontakte',
  'LBL_MODULE_TITLE' => 'Interessenten: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Suche: Interessenten',
  'LBL_LIST_FORM_TITLE' => 'Interessentenliste',
  'LBL_NEW_FORM_TITLE' => 'Neuer Interessent',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Interessenten-Verkaufschancen:',
  'LBL_CONTACT' => 'Interessent:',
  'LBL_BUSINESSCARD' => 'Interessent konvertieren',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_LIST_CONTACT_NAME' => 'Interessent Name',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  
   'LBL_CONTACT_ID' => 'Kontakt-ID', 
   'LBL_ACCOUNT_ID'=>'Kunden-ID', 
   'LBL_OPPORTUNITY_ID'=>'Verkaufschance-ID', 
  
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'Vorname',
  'LBL_LIST_REFERED_BY' => 'Empfohlen von',
  'LBL_LIST_LEAD_SOURCE' => 'Herkunft',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DATE_ENTERED' => 'erstellt am',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Herkunft Beschreibung',
  'LBL_LIST_MY_LEADS' => 'Meine Interessenten',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Es wurde ein existierender Kontakt verwendet',
  'LBL_CREATED_CONTACT' => 'Es wurde ein neuer Kontakt erstellt',
  'LBL_EXISTING_OPPORTUNITY' => 'Es wurde eine existierende Verkaufschance verwendet',
  'LBL_CREATED_OPPORTUNITY' => 'Es wurde eine neue Verkaufschance erstellt',
  'LBL_EXISTING_ACCOUNT' => 'Es wurde ein existierender Kunde verwendet',
  'LBL_CREATED_ACCOUNT' => 'Es wurde ein neuer Kunde erstellt',
  'LBL_CREATED_CALL' => 'Es wurde ein neuer Anruf erstellt',
  'LBL_CREATED_MEETING' => 'Es wurde ein neuer Termin erstellt',
  'LBL_BACKTOLEADS' => 'Zur�ck zu Interessenten',
  'LBL_CONVERTLEAD' => 'Interessent konvertieren',
  'LBL_NAME' => 'Name:',
  'LBL_CONTACT_NAME' => 'Interessent Name:',
  'LBL_CONTACT_INFORMATION' => 'Interessenten Information',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_OFFICE_PHONE' => 'Telefon B�ro:',
  'LBL_ACCOUNT_NAME' => 'Kundenname:',
  'LBL_OPPORTUNITY_NAME' => 'Verkaufschance Name:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Verkaufschance Umsatz:',
  'LBL_ANY_PHONE' => 'Beliebige Telefonnummer:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_MOBILE_PHONE' => 'Telefon Mobil:',
  'LBL_HOME_PHONE' => 'Telefon Privat:',
  'LBL_LEAD_SOURCE' => 'Herkunft:',
  'LBL_STATUS' => 'Status:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Herkunft Beschreibung:',
  'LBL_STATUS_DESCRIPTION' => 'Status Beschreibung:',
  'LBL_OTHER_PHONE' => 'Pager:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email2:',
  'LBL_ANY_EMAIL' => 'Beliebige Email-Adresse:',
  'LBL_REPORTS_TO' => 'Berichte an:',
  'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Hauptadresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Zusatzadresse:',
  'LBL_ANY_ADDRESS' => 'Beliebige Addresse:',
  'LBL_REFERED_BY' => 'Empfohlen von:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',


  'LBL_PRIMARY_ADDRESS_CITY' => 'Hauptadresse Stadt',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Hauptadresse BL',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Hauptadresse  PLZ',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Hauptadresse Land',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Hauptadresse Strasse',
  'LBL_PRIMARY_ADDRESS_STREET_2'=>'Hauptadresse Adresszeile 2', 
  'LBL_PRIMARY_ADDRESS_STREET_3'=>'Hauptadresse Adresszeile 3', 
  
  'LBL_ALT_ADDRESS_STREET' => 'Zusatzadresse Strasse',
  'LBL_ALT_ADDRESS_STREET_2' => 'Zusatzadresse Adresszeile 2', 
  'LBL_ALT_ADDRESS_STREET_3' => 'Zusatzadresse Adresszeile  3', 

  'LBL_ALT_ADDRESS_CITY' => 'Zusatzadresse Stadt',
  'LBL_ALT_ADDRESS_STATE' => 'Zusatzadresse BL',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Zusatzadresse PLZ',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Zusatzadresse Land',
  'LBL_DESCRIPTION_INFORMATION' => 'Weitere Informationen',
  'LBL_ADDRESS_INFORMATION' => 'Adressangaben',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_OPP_NAME' => 'Verkaufschance Name:',
  'LBL_IMPORT_VCARD' => 'Importiere vCard',
  'LNK_IMPORT_VCARD' => ' vCard importieren',
  'LBL_IMPORT_VCARDTEXT' => 'Beim Importieren einer vCard automatisch neuen Interessent anlegen.',
  'LBL_DUPLICATE' => '�hnliche Interessenten',
  'MSG_DUPLICATE' => '�hnliche Interessenten wurden gefunden. Pr�fen Sie die Liste auf Inteessenten welche Sie mit dem Datensatz verkn�pfen m�chten.',
  'LBL_ADD_BUSINESSCARD' => 'Neue Visitenkarte',
  'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
  'LNK_NEW_LEAD' => 'Neuer Interessent',
  'LNK_LEAD_LIST' => 'Interessenten',
  'NTC_DELETE_CONFIRMATION' => 'M�chten Sie diesen Datensatz wirklich l�schen?',
  'NTC_REMOVE_CONFIRMATION' => 'Intessent von Anfrage entfernen?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Diesen Kontakt als verkn�pften Kontakt entfernen?',
  'ERR_DELETE_RECORD' => 'Der Datensatz kann nur gel�scht werden wenn die Datensatznummer (ID) angegeben wird.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopiere Hauptadresse nach Zusatzadresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopiere Zusatzadresse nach Hauptadresse',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Attachment',
  'LNK_NEW_ACCOUNT' => 'Neuer Kunde',
  'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
  'LNK_SELECT_ACCOUNT' => 'Kunde ausw�hlen',
  'LBL_SALUTATION' => 'Anrede',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Zum Anlegen einer Verkaufschance muss ein Kunde angegeben werden.\n  Bitte w�hlen Sie einen existierenden Kunden oder geben Sie einen neuen Kunden ein.',
  'LBL_CONVERTLEAD_TITLE' => 'Konvertiere Interessent [Alt+V]',
  'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
    'LBL_PORTAL_NAME' => 'Portal Username:',
  'LBL_NEW_PORTAL_PASSWORD' => 'Neues Portal Passwort:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Passwort ist gesetzt:',
  'LBL_PORTAL_ACTIVE' => 'Portal aktiv:',
  'LBL_PORTAL_INFORMATION' => 'Portal Einstellungen',
  'LBL_PORTAL_APP'=> 'Portal Applikation',
  'LBL_ACCOUNT_DESCRIPTION'=> 'Kundenbeschreibung',
  'LBL_CONVERTED'=> 'Konvertiert',
  'LBL_REPORTS_TO_ID'=>'Berichte an ID',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Markierte Interessenten �bernehmen',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Markierte Interessenten �bernehmen',
  'LBL_INVALID_EMAIL'=>'Email-Adresse ung�ltig:',
  'LBL_CONVERTED_CONTACT' => 'Konvertierter Kontakt:',
  'LBL_CONVERTED_ACCOUNT'=>'Konvertierter Kunde:',
  'LBL_CONVERTED_OPP'=>'Konvertierte Verkaufschance:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Interessenten', 
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivit�ten', 
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf', 
	
  'LBL_FULL_NAME' => 'Vollst�ndiger Name:',
	    
  'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagnen Protokoll', 
       
  'LBL_TARGET_OF_CAMPAIGNS'=>'Erfolgreiche Kampagnen:', 
 

  'LBL_TARGET_BUTTON_LABEL'=>'kontaktiert', 
  'LBL_TARGET_BUTTON_TITLE'=>'kontaktiert', 
  'LBL_TARGET_BUTTON_KEY'=>'T', 
  'LBL_CAMPAIGN_ID'=>'Kampagnen Id', 

 

  
);


?>
