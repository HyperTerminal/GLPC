<?PHP 
$manifest = array( 
	'name' => 'Nederlands',
	'description' => 'Dutch translation for all SugarCRM versions (Latest Development Snapshot with generic Manifest file)',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '1.0',
	'acceptable_sugar_flavors' => array (),
	'published_date' => '13/11/2006',
	'author' => 'Robert Roossien (robert@buyways.nl)',
	'acceptable_sugar_versions' => array (),
	'icon' => 'include/images/flag-nl_nl.gif');

$installdefs = array(
	'id'=> 'nl_nl',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>
