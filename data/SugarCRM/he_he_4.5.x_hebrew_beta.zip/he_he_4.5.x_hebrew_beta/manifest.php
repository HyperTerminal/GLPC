<?PHP
$manifest = array( 
	'name' => 'Hebrew Language Pack',
	'description' => 'תרגום לשפה העברית',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '4.5.1',
	'acceptable_sugar_flavors' => array ( 0 => "OS", ),
	'author' => 'http://www.sugarforge.org/projects/hebrew',
	'acceptable_sugar_versions' => array ( "exact_matches" => array (), "regex_matches" => array (	0 => "4.5.1[a-z]?" ), ),
	'published_date' => '2007/02/28',
	'icon' => 'include/images/flag-HEB.png',
      );

$installdefs = array(
	'id'=> 'he_he',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'),
	array('from'=> '<basepath>/jscalendar','to'=> 'jscalendar'))
);
?>