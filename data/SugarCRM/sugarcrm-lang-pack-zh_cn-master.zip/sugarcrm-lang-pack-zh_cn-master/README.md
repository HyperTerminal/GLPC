sugarcrm-lang-pack-zh_cn
========================

SugarCRM Simplified Chinese Language Pack