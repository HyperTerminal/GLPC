<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2009 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Documents',
	'LBL_MODULE_TITLE' => 'Documents: Inici',
	'LNK_NEW_DOCUMENT' => 'Crear Document',
	'LNK_DOCUMENT_LIST'=> 'Llista de Documents',
	'LBL_SEARCH_FORM_TITLE'=> 'Cerca de Documents',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'ID de Document',
	'LBL_NAME' => 'Nom de Document',
	'LBL_DESCRIPTION' => 'Descripció',
	'LBL_CATEGORY' => 'Categoría',
	'LBL_SUBCATEGORY' => 'Subcategoría',
	'LBL_STATUS' => 'Estat',
	'LBL_IS_TEMPLATE'=>'Es una Plantilla',
	'LBL_TEMPLATE_TYPE'=>'Tipus de Document',
	'LBL_REVISION_NAME' => 'Número de Versió',
	'LBL_MIME' => 'Tipus MIME',
	'LBL_REVISION' => 'Versió',
	'LBL_DOCUMENT' => 'Document Relacionat',
	'LBL_LATEST_REVISION' => 'Última Versió',
	'LBL_CHANGE_LOG'=> 'Historial de Canvis',
	'LBL_ACTIVE_DATE'=> 'Data de Publicació',
	'LBL_EXPIRATION_DATE' => 'Data de Caducitat',
	'LBL_FILE_EXTENSION'  => 'Extensió d´Arxiu',

	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Sense especificar',
	//quick search
	'LBL_NEW_FORM_TITLE' => 'Nou Document',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Nom de Document:',
	'LBL_FILENAME' => 'Nom d´Arxiu:',
	'LBL_DOC_VERSION' => 'Revisió:',
	'LBL_CATEGORY_VALUE' => 'Categoría:',
	'LBL_SUBCATEGORY_VALUE'=> 'Subcategoría:',
	'LBL_DOC_STATUS'=> 'Estat:',
	'LBL_DET_TEMPLATE_TYPE'=>'Tipus de Document:',

	'LBL_TEAM'=> 'Equip:',

	'LBL_DOC_DESCRIPTION'=>'Descripció:',
	'LBL_DOC_ACTIVE_DATE'=> 'Data de Publicació:',
	'LBL_DOC_EXP_DATE'=> 'Data de Caducitat:',

	//document list view.
	'LBL_LIST_FORM_TITLE' => 'Llista de Documents',
	'LBL_LIST_DOCUMENT' => 'Document',
	'LBL_LIST_CATEGORY' => 'Categoría',
	'LBL_LIST_SUBCATEGORY' => 'Subcategoría',
	'LBL_LIST_REVISION' => 'Versió',
	'LBL_LIST_LAST_REV_CREATOR' => 'Publicat Per',
	'LBL_LIST_LAST_REV_DATE' => 'Data de Versió',
	'LBL_LIST_VIEW_DOCUMENT'=>'Veure',
    'LBL_LIST_DOWNLOAD'=> 'Descarregar',
	'LBL_LIST_ACTIVE_DATE' => 'Data de Publicació',
	'LBL_LIST_EXP_DATE' => 'Data de Caducitat',
	'LBL_LIST_STATUS'=>'Estat',

	//document search form.
	'LBL_SF_DOCUMENT' => 'Nom de Document:',
	'LBL_SF_CATEGORY' => 'Categoría:',
	'LBL_SF_SUBCATEGORY'=> 'Subcategoría:',
	'LBL_SF_ACTIVE_DATE' => 'Data de Publicació:',
	'LBL_SF_EXP_DATE'=> 'Data de Caducitat:',

	'DEF_CREATE_LOG' => 'Document Creat',

	//error messages
	'ERR_DOC_NAME'=>'Nom de Document',
	'ERR_DOC_ACTIVE_DATE'=>'Data de Publicació',
	'ERR_DOC_EXP_DATE'=> 'Data de Caducitat',
	'ERR_FILENAME'=> 'Nom d´Arxiu',

	'LBL_TREE_TITLE' => 'Documents',
	//sub-panel vardefs.
	'LBL_LIST_DOCUMENT_NAME'=>'Nom de Document',
);


?>
