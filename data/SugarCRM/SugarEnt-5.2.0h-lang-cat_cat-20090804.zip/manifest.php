<?php
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ram�n Feliu (ramon@slay.es).
 ********************************************************************************/
// manifest file for information regarding application of new code
$manifest = array(
	// only install on the following regex sugar versions (if empty, no check) 
    'acceptable_sugar_versions' =>
    array (
		'exact_matches' => array (
		),
		'regex_matches' => array (
			'5\.2\.0[a-z]?'
		),
    ),
    'acceptable_sugar_flavors' =>
    array (
        0 => 'CE',
        1 => 'PRO',
        2 => 'ENT',
    ),

    // name of new code
    'name' => 'Catala (Spain) Language Pack',

    // description of new code
    'description' => 'Catala (Spain) Language Pack',

    // author of new code
    'author' => 'Ramon Feliu',

    // date published
    'published_date' => '2009/08/04',

    // version of code
    'version' => '5.2.0h',

    // type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',

    // icon for displaying in UI (path to graphic contained within zip package)
    'icon' => 'include/images/flag-cat_CAT.png',
    
    'is_uninstallable' => TRUE,
    
);



$installdefs = array(
	'id'=> 'cat_cat',
/*	
   // This seems unnecessary:
   'copy' => array(
						array('from'=> '<basepath>/Llegeix.txt',
							  'to'=> 'Llegeix.txt',
							  ),
						array('from'=> '<basepath>/include',
							  'to'=> 'jscalendar',
							  ),
						array('from'=> '<basepath>/modules',
							  'to'=> 'jscalendar',
							  ),
						array('from'=> '<basepath>/modules',
							  'to'=> 'modules',
							  ),
					), */
	);
?>
