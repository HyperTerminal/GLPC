<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Format de dades',
  'LBL_MODULE_TITLE' 					=> 'Formats de dades: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Formats de Dades',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Formats de Dades',
  'LBL_LIST_NAME' 						=> 'Nom del Format de Dades',
  'LBL_LIST_QUERY_NAME' 				=> 'Nom de Consulta',
  'LBL_LIST_OUTPUT_DEFAULT' 			=> 'Sortida per Defecte',
  'LBL_LIST_LIST_ORDER_Y' 				=> 'Ordre Y',
  'LBL_LIST_LIST_ORDER_X' 				=> 'Ordre X',
  'LBL_LIST_VISIBLE' 					=> 'Visible?',
  'LBL_LIST_EXPORTABLE' 				=> 'Exportable?',
  'LBL_LIST_HEADER' 					=> 'Mostrar Capçalera?',
  'LBL_NAME' 							=> 'Nom del Format de Dades:',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_TYPE' 							=> 'Tipus:',
  'LBL_PARENT_DATASET' 					=> 'Format de Dades Parent:',
  'LBL_QUERY_NAME' 						=> 'Nom de Consulta:',
  'LBL_OUTPUT_DEFAULT' 					=> 'Tipus de Sortida per Defecte:',
  'LBL_LIST_ORDER_Y' 					=> 'Ordre en Eix Y:',
  'LBL_LIST_ORDER_X' 					=> 'Ordre en Eix X:',
  'LBL_HEADER' 							=> 'Mostrar Capçalera:',
  'LBL_EXPORTABLE' 						=> 'Exportable (Només Arxiu CSV):',
  'LBL_VISIBLE' 						=> 'Format de Dades Visible:',
  'LBL_TABLE_WIDTH' 					=> 'Amplada de la Taula %:',
  'LBL_FONT_SIZE' 						=> 'Tamany de la Font:',
  'LBL_REPORT_NAME' 					=> 'Nom d´Informe:',
  'LBL_PRESPACE_X' 						=> 'Marge lateral:',
  'LBL_PRESPACE_Y' 						=> 'Combinar amb el Format de Dades previ:',
  'LBL_TABLE_WIDTH_TYPE' 				=> 'Tipus d´Ample de la Taula:',
  'LBL_BODY_TEXT_COLOR' 				=> 'Color de Text del Cos:',
  'LBL_HEADER_TEXT_COLOR' 				=> 'Color de Text de la Capçalera:',
  'LBL_HEADER_BACK_COLOR' 				=> 'Color de Fons de la Capçalera:',
  'LBL_BODY_BACK_COLOR' 				=> 'Color de Fons del Cos:',
  'LBL_USE_PREV_HEADER' 				=> 'Agrupar amb Capçalera prèvia:',
  'LBL_CHILD_NAME' 						=> 'Subconsulta/Consulta hija:',
  'LBL_CUSTOM_LAYOUT' 					=> 'Disseny Personalitzat:',
  'LNK_LIST_REPORTMAKER' 				=> 'Llista d´Informes Empresarials',
  'LNK_NEW_REPORTMAKER' 				=> 'Crear Informe',
  'LNK_LIST_DATASET' 					=> 'Llista de Formats de Dades',
  'LNK_NEW_DATASET' 					=> 'Crear Format de Dades',
  'LNK_NEW_CUSTOMQUERY' 				=> 'Crear Consulta Personalitzada',
  'LNK_CUSTOMQUERIES' 					=> 'Consultes Personalitzades',
  'LNK_NEW_QUERYBUILDER' 				=> 'Crear Consulta',
  'LNK_QUERYBUILDER' 					=> 'Disenyador de Consultes',
  'LBL_ALL_REPORTS' 					=> 'Tots els Informes',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja eliminar aquest registre?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el producte.',
  'LBL_LAYOUT_TYPE' 					=> 'Tipus de Diseny:',
  'LBL_LAYOUT_PARENT_VALUE' 			=> 'Valor per Defecte:',
  'LBL_LAYOUT_DISPLAY_TYPE' 			=> 'Tipus de Visualització:',
  'LBL_LAYOUT_LIST_ORDER_X' 			=> 'Ordre de Llista en Eix X:',
  'LBL_LAYOUT_LIST_ORDER_Z' 			=> 'Ordre de Llista en Eix Z:',
  'LBL_MODIFY_HEAD' 					=> 'Modificar Atributs de la Capçalera:',
  'LBL_MODIFY_BODY' 					=> 'Modificar Atributs del Cos:',
  'LBL_BG_COLOR' 						=> 'Color de Fons:',
  'LBL_WRAP' 							=> 'Ajustar Text:',
  'LBL_DISPLAY_TYPE' 					=> 'Tipus de Visualització:',
  'LBL_STYLE' 							=> 'Estil de Font:',
  'LBL_DISPLAY_NAME' 					=> 'Nom de Visualització:',
  'LBL_FORMAT_TYPE' 					=> 'Tipus de Format:',
  'LBL_FORMAT' 							=> 'Format:',
  'LBL_CELL_SIZE' 						=> 'Amplada de Cel·la:',
  'LBL_HIDE_COLUMN' 					=> 'Amagar Columna en Informe:',
  'LBL_FINISHED_BUTTON' 				=> 'Acabat',
  'CONFIRM_LAYOUT_DISABLE' 				=> 'Al deshabilitar el disseny per defecte es perdran totes les propietats actuals del disseny personalitzat',
);


?>