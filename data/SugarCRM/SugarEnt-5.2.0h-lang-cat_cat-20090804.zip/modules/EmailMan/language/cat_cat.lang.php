<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
	'LBL_SEND_DATE_TIME'				=> 'Data de Tramesa',
	'LBL_IN_QUEUE'						=> 'En Cua?',
	'LBL_IN_QUEUE_DATE'					=> 'Data de posada en Cua',
	'LBL_DISCLOSURE_TITLE'				=> 'Afegir Missatge sobre Confidencialitat de Contingut a Cada Correu',
	'LBL_DISCLOSURE_TEXT_TITLE'			=> 'Confidencialitat de Contingut',
	'LBL_DISCLOSURE_TEXT_SAMPLE'		=> 'AVÍS: Aquest missatge de correu és per a ús únic del destinatari(s) i pot contenir informació privada i confidencial. Queda prohibit qualsevol tipus de revisió, ús, revelació o distribució no autoritzada. Si vostè no és el destinatari previst, si us plau, destrueixi totes les còpies del missatge original i notifiqui el remitent de manera que puguem corregir la direcció de correu en el nostre registre. Gràcies.',
	'LBL_ID' 							=> 'Id',
    'LBL_ATTACHMENT_AUDIT' 				=> ' ha estat enviat. No s´ha duplicat en local per minimitzar la utilització d´espai al disc dur.',
    'LBL_OLD_ID' 						=> 'Id Antic',
    'LBL_LIST_CAMPAIGN' 				=> 'Campanya',
    'LBL_LIST_FORM_PROCESSED_TITLE' 	=> 'Processats',
    'LBL_LIST_FORM_TITLE' 				=> 'Cua',
    'LBL_LIST_FROM_EMAIL' 				=> 'Correu del Remitent',
    'LBL_LIST_FROM_NAME' 				=> 'Nom del Remitent',
    'LBL_LIST_IN_QUEUE' 				=> 'En Procés',
    'LBL_LIST_RECIPIENT_EMAIL' 			=> 'Correu del Destinatari',
    'LBL_LIST_RECIPIENT_NAME' 			=> 'Nom del Destinatari',
    'LBL_LIST_SEND_ATTEMPTS' 			=> 'Intents de Tramesa',
    'LBL_LIST_SEND_DATE_TIME' 			=> 'Enviar el',
    'LBL_LIST_USER_NAME' 				=> 'Nom d´Usuari',
    'LBL_MODULE_TITLE' 					=> 'Administració de Cua d´Email Sortint',
    'LBL_SEARCH_FORM_PROCESSED_TITLE' 	=> 'Recerca de Processats',
    'LBL_SEARCH_FORM_TITLE' 			=> 'Recerca de Cues',
    'LBL_VIEW_PROCESSED_EMAILS' 		=> 'Veure Correus Processats',
    'LBL_VIEW_QUEUED_EMAILS' 			=> 'Veure Correus En Cua',
    'LBL_RELATED_ID' 					=> 'Id Relacionat',
    'LBL_RELATED_TYPE' 					=> 'Tipus Relacionat',
    'LBL_SAVE_OUTBOUND_RAW' 			=> 'Guardar els Missatges Sortints en format original',
    'LBL_MARKETING_ID' 					=> 'Id de Màrqueting',
    'LBL_MODULE_ID' 					=> 'EmailMan',
    'LBL_LIST_MESSAGE_NAME' 			=> 'Missatge de Màrqueting',
    'LBL_MODULE_NAME' 					=> 'Configuració de Correu',
    'LBL_CAMP_MODULE_NAME' 				=> 'Configuració de Correu de Campanya',
    'LBL_CONFIGURE_SETTINGS' 			=> 'Configurar',
    'LBL_EMAILS_PER_RUN' 				=> 'Nombre de Missatges enviats per lot', 
    'LBL_EMAIL_PER_RUN_REQ' 			=> 'Nombre de Missatges enviats per lot',
    'LBL_LOCATION_ONLY' 				=> 'Ubicació',
    'LBL_LOCATION_TRACK' 				=> 'Ubicació dels arxius de següiment de campanya (com campaign_tracker.php)',
    'LBL_CAMP_MESSAGE_COPY' 			=> 'Guardar copies dels missatges de la campanya:',
    'LBL_CAMP_MESSAGE_COPY_DESC' 		=> 'Desitja guardar còpies completes de <bold>CADA</bold> missatge de correu enviat durant totes les campanyes? <bold>Es recomana el valor per defecte de no fer-ho</bold>. Si elegeix no, només es guardarà la plantilla enviada i les variables per recrear el missatge individual.',
    'LBL_DEFAULT_LOCATION' 				=> 'Per Defecte',
    'LBL_CUSTOM_LOCATION' 				=> 'Definit per l´Usuari',
    'LBL_EMAIL_DEFAULT_CHARSET' 		=> 'Redactar missatges de correu en aquest joc de caràcters',
    'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE' => 'Valor en Config.php per site_url',
    'ERR_INT_ONLY_EMAIL_PER_RUN' 		=> 'Només es permeten valors sencers per el nombre de missatges enviats per lot',
    'TXT_REMOVE_ME' 					=> 'Per borrar la subscripció a aquesta llista de correu',
    'TXT_REMOVE_ME_ALT' 				=> 'Per borrar la subscripció a aquesta llista de correu vagi a',
    'TXT_REMOVE_ME_CLICK' 				=> 'faci clic aquí',
    'LBL_EMAIL_DEFAULT_CLIENT' 			=> 'Redactar missatges de correu en aquest format',
    'LBL_EMAIL_DEFAULT_EDITOR' 			=> 'Redactar correu fent servir aquest client',
    'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS' => 'Esborrar arxius adjunts i Notes relacionades al costat dels Missatges esborrats',
    'LBL_EMAIL_GMAIL_DEFAULTS' 			=> 'Omplir prèviament valors per defecte per a Gmail',
    'LBL_EMAIL_SMTP_SSL' 				=> 'Habilitar SMTP sobre SSL',
    'LBL_MAIL_SENDTYPE'					=> 'Agent de Transferència de Correu (MTA):',
	'LBL_MAIL_SMTPAUTH_REQ'				=> 'Usar Autentificació SMTP?',
	'LBL_MAIL_SMTPPASS'					=> 'Clau de pas SMTP:',
	'LBL_MAIL_SMTPPORT'					=> 'Port SMTP:',
	'LBL_MAIL_SMTPSERVER'				=> 'Servidor SMTP:',
	'LBL_MAIL_SMTPUSER'					=> 'Usuari SMTP:',
	'LBL_NOTIFICATION_ON_DESC' 			=> 'Envia correus de notificació quan s´assignen registres.',
	'LBL_NOTIFY_FROMADDRESS' 			=> 'Direcció remitent:',
	'LBL_NOTIFY_FROMNAME' 				=> 'Nom remitent:',
	'LBL_NOTIFY_ON'						=> 'Activar notificacions?',
	'LBL_NOTIFY_SEND_BY_DEFAULT'		=> 'Enviar notificacions per defecte en usuaris nous?',
	'LBL_NOTIFY_TITLE'					=> 'Opcions de Notificació de Correu',
	'LBL_OUTBOUND_EMAIL_TITLE'			=> 'Opcions de Correu Sortint',
	'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER' => 'Enviar notificació usant com a remitent la direcció d´email de l´usuari assignador?',
	'LBL_SECURITY_TITLE'				=> 'Configuració de Seguretat de Correu',
	'LBL_SECURITY_DESC'					=> 'Marqui allò que NO hauria de ser permès a Email entrant o mostrades en el mòdul d´Emails.',
	'LBL_SECURITY_APPLET'				=> 'Etiqueta Applet',
	'LBL_SECURITY_BASE'					=> 'Etiqueta Base',
	'LBL_SECURITY_EMBED'				=> 'Etiqueta Embed',
	'LBL_SECURITY_FORM'					=> 'Etiqueta Form',
	'LBL_SECURITY_FRAME'				=> 'Etiqueta Frame',
	'LBL_SECURITY_FRAMESET'				=> 'Etiqueta Frameset',
	'LBL_SECURITY_IFRAME'				=> 'Etiqueta iFrame',
	'LBL_SECURITY_IMPORT'				=> 'Etiqueta Import',
	'LBL_SECURITY_LAYER'				=> 'Etiqueta Layer',
	'LBL_SECURITY_LINK'					=> 'Etiqueta Link',
	'LBL_SECURITY_OBJECT'				=> 'Etiqueta Object',
	'LBL_SECURITY_OUTLOOK_DEFAULTS'		=> 'Seleccionar les precaucions mínimes de seguretat per defecte a Outlook (pot provocar errors en la visualització del contingut).',
	'LBL_SECURITY_PRESERVE_RAW'			=> 'Preservar codi font del correu, incloent contingut potencialment perillós. Aquesta opció només preservarà missatges originals en la base de dades; no es permetrà contingut sense filtrar en l´Interfície d´Usuari de SugarCRM .<br /><span class="error">Això pot fer que la seguretat del seu sistema es vegi compromesa.</span >',
	'LBL_SECURITY_SCRIPT'				=> 'Etiqueta Script',
	'LBL_SECURITY_STYLE'				=> 'Etiqueta Style',
	'LBL_SECURITY_TOGGLE_ALL'			=> 'Canviar Totes les Opcions',
	'LBL_SECURITY_XMP'					=> 'Etiqueta Xmp',
    'LBL_YES'                           => 'Sí',
    'LBL_NO'                            => 'No',
    'LBL_PREPEND_TEST'                  => '[Prova]: ',
	'LBL_SEND_ATTEMPTS'					=> 'Intents d´Enviament',

);


?>