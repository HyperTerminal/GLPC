<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_ADD_ANOTHER_FILE'				=> 'Afegir Un altre Arxiu',
  'LBL_ADD_DOCUMENT'					=> 'Afegir un Document Sugar',
  'LBL_INSERT_URL_REF'					=> 'Insertar Referència a URL',
  'LBL_INSERT_TRACKER_URL'				=> 'Insertar URL de Seguiment:',
  'LBL_TEAM' 							=> 'Equip:',
  'LBL_TEAMS_LINK' 						=> 'Equip',
  'LNK_CHECK_MY_INBOX' 					=> 'Comprovar el meu correu',
  'LNK_MY_ARCHIVED_LIST' 				=> 'Els Meus Arxius',
  'LBL_MODULE_NAME' 					=> 'Plantilles de Correu',
  'LBL_MODULE_TITLE' 					=> 'Plantilles de Correu: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Plantilles de Correu',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Plantilles de Correu',
  'LBL_NEW_FORM_TITLE' 					=> 'Crear Plantilla de Correu',
  'LBL_LIST_NAME' 						=> 'Nom',
  'LBL_LIST_DESCRIPTION' 				=> 'Descripció',
  'LBL_LIST_DATE_MODIFIED' 				=> 'Última Modificació',
  'LBL_NAME' 							=> 'Nom:',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_SUBJECT' 						=> 'Assumpte:',
  'LBL_SUGAR_DOCUMENT' 					=> 'Document Sugar',
  'LBL_CLOSE' 							=> 'Tancat:',
  'LBL_RELATED_TO' 						=> 'Relatiu a:',
  'LBL_BODY' 							=> 'Cos:',
  'LBL_PUBLISH' 						=> 'Publicació:',
  'LBL_COLON' 							=> ':',
  'LNK_NEW_EMAIL_TEMPLATE' 				=> 'Crear Plantilla de Correu',
  'LNK_EMAIL_TEMPLATE_LIST' 			=> 'Plantilles de Correu',
  'LNK_IMPORT_NOTES' 					=> 'Importar Notes',
  'LNK_VIEW_CALENDAR' 					=> 'Avui',
  'LNK_CHECK_EMAIL' 					=> 'Comprovar Correu',
  'LNK_NEW_SEND_EMAIL' 					=> 'Redactar Correu',
  'LNK_ARCHIVED_EMAIL_LIST' 			=> 'Correus Arxivats',
  'LNK_SENT_EMAIL_LIST' 				=> 'Correus Enviats',
  'LNK_NEW_EMAIL' 						=> 'Arxivar Correu',
  'LBL_INSERT_VARIABLE' 				=> 'Insertar Variable:',
  'LBL_INSERT' 							=> 'Insertar',
  'LNK_DRAFTS_EMAIL_LIST' 				=> 'Borrador',
  'LNK_ALL_EMAIL_LIST' 					=> 'Tots els Correus',
  'LNK_NEW_ARCHIVE_EMAIL' 				=> 'Crear Correu Arxivat',
  'LBL_CONTACT_AND_OTHERS' 				=> 'Contacte/Client Potencial/Públic Objectiu',
  'LBL_HTML_BODY' 						=> 'Cos HTML',
  'LBL_TEXT_BODY' 						=> 'Cos de Text',
  'LBL_USERS' 							=> 'Usuaris',
  'LBL_EDIT_ALT_TEXT' 					=> 'Editar Text Plà',
  'LBL_SHOW_ALT_TEXT' 					=> 'Mostrar Text Plà',
  'LBL_ATTACHMENTS' 					=> 'Adjunts',
  'LBL_ADD_FILE' 						=> 'Afegir un arxiu',
  'LBL_EMAIL_ATTACHMENT' 				=> 'Adjunt de Correu',
  'LNK_MY_INBOX' 						=> 'El Meu Correu',
  'LNK_GROUP_INBOX' 					=> 'Safata d´Entrada Compartida',
  'LNK_MY_DRAFTS' 						=> 'Borradors',
  'LBL_NEW' 							=> 'Nou',
  'LBL_MODULE_NAME_WORKFLOW' 			=> 'Plantilles de Correu per Workflow',
  'LBL_LIST_BASE_MODULE' 				=> 'Mòdul Base:',
  'LBL_TEXT_ONLY' 						=> 'Només Text',
  'LBL_SEND_AS_TEXT' 					=> 'Enviar Només Text',
  'LBL_ACCOUNT' 						=> 'Compte',
  'LBL_BASE_MODULE'						=> 'Mòdul Base',
  'LBL_FROM_NAME'						=> 'Nom del Remitent',
  'LBL_PLAIN_TEXT'						=> 'Text Plà',
  'LBL_CREATED_BY'						=> 'Creat Per',
  'LBL_FROM_ADDRESS'					=> 'Direcció del Remitent',
  'LBL_PUBLISHED'						=> 'Publicat',
);

?>