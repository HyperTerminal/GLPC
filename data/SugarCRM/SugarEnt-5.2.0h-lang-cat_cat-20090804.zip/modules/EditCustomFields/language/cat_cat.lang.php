<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Editar Camps Personalitzats',
  'LBL_ADD_FIELD' 						=> 'Afegir Camp:',
  'LBL_MODULE_TITLE' 					=> 'Edició de Camps Personalitzats',
  'LBL_MODULE_SELECT' 					=> 'Mòdul a Editar',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Mòduls',
  'COLUMN_TITLE_NAME' 					=> 'Nom de Camp',
  'COLUMN_TITLE_LABEL' 					=> 'Etiqueta del Sistema',
  'COLUMN_TITLE_DISPLAY_LABEL' 			=> 'Etiqueta Visible',
  'COLUMN_TITLE_LABEL_VALUE' 			=> 'Valor d´Etiqueta',
  'COLUMN_TITLE_MAX_SIZE' 				=> 'Mida Màxima',
  'COLUMN_TITLE_HELP_TEXT' 				=> 'Text d´Ajut',
  'COLUMN_TITLE_COMMENT_TEXT' 			=> 'Text de Comentari',
  'COLUMN_TITLE_REQUIRED_OPTION' 		=> 'Camp Requerit',
  'COLUMN_TITLE_DEFAULT_VALUE' 			=> 'Valor per Defecte',
  'COLUMN_TITLE_DEFAULT_EMAIL' 			=> 'Valor per Defecte',
  'COLUMN_TITLE_EXT1' 					=> 'Metacamp Extra 1',
  'COLUMN_TITLE_EXT2' 					=> 'Metacamp Extra 2',
  'COLUMN_TITLE_EXT3' 					=> 'Metacamp Extra 3',
  'COLUMN_TITLE_FRAME_HEIGHT' 			=> 'Altura de IFrame',
  'COLUMN_TITLE_HTML_CONTENT' 			=> 'HTML',
  'COLUMN_TITLE_URL'					=> 'URL per Defecte',
  'COLUMN_TITLE_AUDIT' 					=> 'Auditar',
  'COLUMN_TITLE_REPORTABLE' 			=> 'Informable',
  'COLUMN_TITLE_MIN_VALUE' 				=> 'Valor Mín.',
  'COLUMN_TITLE_MAX_VALUE' 				=> 'Valor Màx.',
  'COLUMN_TITLE_DISPLAYED_ITEM_COUNT'	=> 'Núm. Elements mostrats',
  'COLUMN_DISABLE_NUMBER_FORMAT' 		=> 'Deshabilitar Format',
  'LBL_DROP_DOWN_LIST' 					=> 'Llista Desplegable',
  'LBL_RADIO_FIELDS'					=> 'Camps de Radi',
  'LBL_MULTI_SELECT_LIST'				=> 'Llista de Selecció Múltiple',
  'COLUMN_TITLE_PRECISION'				=> 'Precisió',
  'MSG_DELETE_CONFIRM' 					=> 'Està segur que desitja eliminar aquest element?',
  'POPUP_INSERT_HEADER_TITLE' 			=> 'Afegir Camp Personalitzat',
  'POPUP_EDIT_HEADER_TITLE' 			=> 'Editar Camp Personalitzat',
  'LNK_SELECT_CUSTOM_FIELD' 			=> 'Seleccionar Camp Personalitzat',
  'LNK_REPAIR_CUSTOM_FIELD' 			=> 'Reparar Camps Personalitzats',
  'LBL_MODULE' 							=> 'Mòdul',
  'COLUMN_TITLE_MASS_UPDATE'			=> 'Actualització Massiva',
  'COLUMN_TITLE_IMPORTABLE'				=> 'Importable',
  'COLUMN_TITLE_DUPLICATE_MERGE'		=> 'Combinació de Duplicats',
  'LBL_LABEL'							=> 'Etiqueta',
  'LBL_DATA_TYPE'						=> 'Tipus de Dades',
  'LBL_DEFAULT_VALUE'					=> 'Valor per Defecte',
  'LBL_AUDITED'							=> 'Auditat',
  'LBL_REPORTABLE'						=> 'Informable',
  'ERR_RESERVED_FIELD_NAME'				=> 'Paraula Reservada',
  'ERR_SELECT_FIELD_TYPE'				=> 'Si us plau, seleccioni un tipus de camp',
  'LBL_BTN_ADD' 						=> 'Afegir',
  'LBL_BTN_EDIT' 						=> 'Editar',
  'LBL_GENERATE_URL' 					=> 'Generar URL',
);

?>