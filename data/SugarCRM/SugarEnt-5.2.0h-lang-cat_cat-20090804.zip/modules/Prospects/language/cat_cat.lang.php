<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Públic Objectiu',
  'LBL_MODULE_ID' 						=> 'Públic Objectiu',
  'LBL_INVITEE' 						=> 'Informa Directament',
  'LBL_MODULE_TITLE' 					=> 'Públic Objectiu: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Públic Objectiu',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Públic Objectiu',
  'LBL_NEW_FORM_TITLE' 					=> 'Nou Públic Objectiu',
  'LBL_PROSPECT' 						=> 'Públic Objectiu:',
  'LBL_BUSINESSCARD' 					=> 'Targeta de Visita',
  'LBL_LIST_NAME' 						=> 'Nom',
  'LBL_LIST_LAST_NAME' 					=> 'Cognom',
  'LBL_LIST_PROSPECT_NAME' 				=> 'Nom de Públic Objectiu',
  'LBL_LIST_TITLE' 						=> 'Títol',
  'LBL_LIST_EMAIL_ADDRESS' 				=> 'Correu',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' 		=> 'Correu Alternatiu',
  'LBL_LIST_PHONE' 						=> 'Telèfon',
  'LBL_LIST_PROSPECT_ROLE' 				=> 'Rol',
  'LBL_LIST_FIRST_NAME' 				=> 'Nom',
  'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a',
  'LBL_ASSIGNED_TO_ID' 					=> 'Assignat a:',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_CAMPAIGN_ID' 					=> 'ID Campanya',
  'LBL_EXISTING_PROSPECT' 				=> 'Usant un contacte existent',
  'LBL_CREATED_PROSPECT' 				=> 'Nou contacte creat',
  'LBL_EXISTING_ACCOUNT' 				=> 'Usat un compte existent',
  'LBL_CREATED_ACCOUNT' 				=> 'Nova compte creada',
  'LBL_CREATED_CALL' 					=> 'Nova trucada creada',
  'LBL_CREATED_MEETING' 				=> 'Nova reunió creada',
  'LBL_ADDMORE_BUSINESSCARD' 			=> 'Afegir un altre targeta de visita',
  'LBL_ADD_BUSINESSCARD' 				=> 'Introduïr Targeta de Visita',
  'LBL_NAME' 							=> 'Nom:',
  'LBL_FULL_NAME' 						=> 'Nom:',
  'LBL_PROSPECT_NAME' 					=> 'Nom del Públic Objectiu:',
  'LBL_PROSPECT_INFORMATION' 			=> 'Informació del Públic Objectiu',
  'LBL_FIRST_NAME' 						=> 'Nom:',
  'LBL_OFFICE_PHONE' 					=> 'Tel. Oficina:',
  'LBL_ANY_PHONE' 						=> 'Tel. Qualsevol:',
  'LBL_PHONE' 							=> 'Telèfon:',
  'LBL_LAST_NAME' 						=> 'Cognom:',
  'LBL_MOBILE_PHONE' 					=> 'Mòbil:',
  'LBL_HOME_PHONE' 						=> 'Casa:',
  'LBL_OTHER_PHONE' 					=> 'Tel. Alternatiu:',
  'LBL_FAX_PHONE' 						=> 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' 			=> 'Carrer Direcció Principal:',
  'LBL_PRIMARY_ADDRESS_CITY' 			=> 'Ciutat Direcció Principal:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' 		=> 'País Direcció Principal:',
  'LBL_PRIMARY_ADDRESS_STATE' 			=> 'Província/Estat Direcció Principal:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' 		=> 'CP Direcció Principal:',
  'LBL_ALT_ADDRESS_STREET' 				=> 'Carrer Direcció Alternativa:',
  'LBL_ALT_ADDRESS_CITY' 				=> 'Ciutat Direcció Alternativa:',
  'LBL_ALT_ADDRESS_COUNTRY' 			=> 'País Direcció Alternativa:',
  'LBL_ALT_ADDRESS_STATE' 				=> 'Província/Estat Direcció Alternativa:',
  'LBL_ALT_ADDRESS_POSTALCODE' 			=> 'CP Direcció Alternativa:',
  'LBL_TITLE' 							=> 'Títol:',
  'LBL_DEPARTMENT' 						=> 'Departament:',
  'LBL_BIRTHDATE' 						=> 'Data de naixement:',
  'LBL_EMAIL_ADDRESS' 					=> 'Correu:',
  'LBL_OTHER_EMAIL_ADDRESS' 			=> 'Correu alternatiu:',
  'LBL_ANY_EMAIL' 						=> 'Correu qualsevol:',
  'LBL_ASSISTANT' 						=> 'Assistent:',
  'LBL_ASSISTANT_PHONE' 				=> 'Tel. Assistent:',
  'LBL_DO_NOT_CALL' 					=> 'No Trucar:',
  'LBL_EMAIL_OPT_OUT' 					=> 'Refusar Correu:',
  'LBL_PRIMARY_ADDRESS' 				=> 'Direcció Principal:',
  'LBL_ALTERNATE_ADDRESS' 				=> 'Direcció Alternativa:',
  'LBL_ANY_ADDRESS' 					=> 'Direcció Alternativa:',
  'LBL_CITY' 							=> 'Ciutat:',
  'LBL_STATE' 							=> 'Província/Estat:',
  'LBL_POSTAL_CODE' 					=> 'CP:',
  'LBL_COUNTRY' 						=> 'País:',
  'LBL_DESCRIPTION_INFORMATION' 		=> 'Informació de Descripció',
  'LBL_ADDRESS_INFORMATION' 			=> 'Informació de Direcció',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_PROSPECT_ROLE' 					=> 'Rol:',
  'LBL_OPP_NAME' 						=> 'Nom Oportunitat:',
  'LBL_IMPORT_VCARD' 					=> 'Importar vCard',
  'LBL_IMPORT_VCARDTEXT' 				=> 'Crear un nou contacte automàticament important una vCard el seu sistema de fitxers.',
  'LBL_DUPLICATE' 						=> 'Possible Públic Objectiu Duplicat',
  'MSG_SHOW_DUPLICATES' 				=> 'El registre per al prospecte que crearà podria ser un duplicat d´un altre registre de prospecte existent. Els registres de prospectes amb noms i/o direccions de correu similars es llisten a continuación.<br>Faci clic en Guardar per continuar amb la creació d´aquest prospecte, o en Cancel·lar per tornar al mòdul sense crear el prospecte.',
  'MSG_DUPLICATE' 						=> 'El registre per al prospecte que crearà podria ser un duplicat d´un altre registre de prospecte existent. Els registres de prospectes amb noms i/o direccions de correu similars es llisten a continuación.<br>Faci clic en Guardar per continuar amb la creació d´aquest prospecte, o en Cancel·lar per tornar al mòdul sense crear el prospecte.',
  'LNK_PROSPECT_LIST' 					=> 'Públic Objectiu',
  'LNK_IMPORT_VCARD' 					=> 'Crear desde vCard',
  'LNK_NEW_PROSPECT' 					=> 'Crear Públic Objectiu',
  'LNK_NEW_ACCOUNT' 					=> 'Crear Compte',
  'LNK_NEW_OPPORTUNITY' 				=> 'Crear Oportunitat',
  'LNK_NEW_CASE' 						=> 'Crear Cas',
  'LNK_NEW_NOTE' 						=> 'Crear Nota o Adjunt',
  'LNK_NEW_CALL' 						=> 'Planificar Trucada',
  'LNK_NEW_EMAIL' 						=> 'Arxivar Correu',
  'LNK_NEW_MEETING' 					=> 'Planificar Reunió',
  'LNK_NEW_TASK' 						=> 'Crear Tasca',
  'LNK_NEW_APPOINTMENT' 				=> 'Crear Cita',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja eliminar aquest registre?',
  'NTC_REMOVE_CONFIRMATION' 			=> 'Està segur que desitja treure aquest contacte del cas?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Està segur que desitja treure aquest registre com un informador directe?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el contacte.',
  'NTC_COPY_PRIMARY_ADDRESS' 			=> 'Copiar direcció principal a direcció alternativa',
  'NTC_COPY_ALTERNATE_ADDRESS' 			=> 'Copiar direcció alternativa a direcció principal',
  'LBL_SALUTATION' 						=> 'Salutació',
  'LBL_SAVE_PROSPECT' 					=> 'Guardar Públic Objectiu',
  'LBL_CREATED_OPPORTUNITY' 			=> 'Crear una nova oportunitat',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' 	=> 'La creació d´una oportunitat requereix un compte.\n Si us plau, creï un compte nou o en seleccioni un existent.',
  'LNK_SELECT_ACCOUNT' 					=> 'Seleccionar Compte',
  'LNK_NEW_CAMPAIGN' 					=> 'Crear Campanya',
  'LNK_CAMPAIGN_LIST' 					=> 'Campanyes',
  'LNK_NEW_PROSPECT_LIST' 				=> 'Crear Llista de Públic Objectiu',
  'LNK_PROSPECT_LIST_LIST' 				=> 'Llistes de Públic Objectiu',
  'LNK_IMPORT_PROSPECT' 				=> 'Importar Públic Objectiu',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' 	=> 'Seleccioni Públic Objectiu Marcat',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' 	=> 'Seleccioni Públic Objectiu Marcat',
  'LBL_INVALID_EMAIL' 					=> 'Correu No Vàlid:',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Públic Objectiu',
  'LBL_PROSPECT_LIST' 					=> 'Públic Objectiu',
  'LBL_CONVERT_BUTTON_KEY' 				=> 'V',
  'LBL_CONVERT_BUTTON_TITLE' 			=> 'Convertir Públic Objectiu',
  'LBL_CONVERT_BUTTON_LABEL' 			=> 'Convertir Públic Objectiu',
  'LBL_CONVERTPROSPECT' 				=> 'Convertir Públic Objectiu',
  'LNK_NEW_CONTACT' 					=> 'Nou Contacte',
  'LBL_CREATED_CONTACT' 				=> 'S´ha creat un nou contacte',
  'LBL_BACKTO_PROSPECTS' 				=> 'Tornar a Públic Objectiu',
  'LBL_CAMPAIGNS' 						=> 'Campanyes',
  'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE' 	=> 'Registre de Campanyes',
  'LBL_TRACKER_KEY'						=> 'Clau de Seguiment',
  'LBL_LEAD_ID'							=> 'Id Client Potencial',
  'LBL_CONVERTED_LEAD'					=> 'Client Potencial Convertit',
  'LBL_ACCOUNT_NAME'					=> 'Nom de Compte:',
  'LBL_EDIT_ACCOUNT_NAME'				=> 'Nom de Compte:',
  'LBL_CREATED_USER' 					=> 'Usuari Creat',
  'LBL_MODIFIED_USER' 					=> 'Usuari Modificat',
);


?>