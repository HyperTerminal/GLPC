<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre a eliminar.',
  'LBL_ACCOUNT_ID' 						=> 'ID Compte:',
  'LBL_CASE_ID' 						=> 'ID Cas:',
  'LBL_CLOSE' 							=> 'Tancar:',
  'LBL_COLON' 							=> ':',
  'LBL_CONTACT_ID' 						=> 'ID Contacte:',
  'LBL_CONTACT_NAME' 					=> 'Contacte:',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Notes',
  'LBL_DESCRIPTION' 					=> 'Descripció',
  'LBL_EMAIL_ADDRESS' 					=> 'Correu:',
  'LBL_EMAIL_ATTACHMENT' 				=> 'Adjunt de Correu:',
  'LBL_FILE_MIME_TYPE' 					=> 'Tipus MIME',
  'LBL_FILE_URL' 						=> 'URL d´Arxiu',
  'LBL_FILENAME' 						=> 'Adjunt:',
  'LBL_LEAD_ID' 						=> 'ID Client Potencial:',
  'LBL_LIST_CONTACT_NAME' 				=> 'Contacte',
  'LBL_LIST_DATE_MODIFIED' 				=> 'Modificat',
  'LBL_LIST_FILENAME' 					=> 'Adjunt',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Notes',
  'LBL_LIST_RELATED_TO' 				=> 'Relatiu a',
  'LBL_LIST_SUBJECT' 					=> 'Assumpte',
  'LBL_LIST_STATUS' 					=> 'Estat',
  'LBL_LIST_CONTACT' 					=> 'Contacte',
  'LBL_MODULE_NAME' 					=> 'Notes',
  'LBL_MODULE_TITLE' 					=> 'Notes: Inici',
  'LBL_NEW_FORM_TITLE' 					=> 'Nova Nota o Arxiu Adjunt',
  'LBL_NOTE_STATUS' 					=> 'Nota',
  'LBL_NOTE_SUBJECT' 					=> 'Assumpte:',
  'LBL_NOTES_SUBPANEL_TITLE' 			=> 'Adjunts',
  'LBL_NOTE' 							=> 'Nota:',
  'LBL_OPPORTUNITY_ID' 					=> 'ID Oportunitat:',
  'LBL_PARENT_ID' 						=> 'ID Padre:',
  'LBL_PARENT_TYPE' 					=> 'Tipus de Padre',
  'LBL_PHONE' 							=> 'Telèfon:',
  'LBL_PORTAL_FLAG' 					=> 'Mostrar en el Portal?',
  'LBL_EMBED_FLAG' 						=> 'Incloure en correu?',
  'LBL_PRODUCT_ID' 						=> 'ID Producte:',
  'LBL_QUOTE_ID' 						=> 'ID Pressupost:',
  'LBL_RELATED_TO' 						=> 'Relatiu a:',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Notes',
  'LBL_STATUS' 							=> 'Estat',
  'LBL_SUBJECT' 						=> 'Assumpte:',
  'LNK_CALL_LIST' 						=> 'Trucades',
  'LNK_EMAIL_LIST' 						=> 'Correus',
  'LNK_IMPORT_NOTES' 					=> 'Importar Notes',
  'LNK_MEETING_LIST' 					=> 'Reunions',
  'LNK_NEW_CALL' 						=> 'Programar Trucada',
  'LNK_NEW_EMAIL' 						=> 'Arxivar Correu',
  'LNK_NEW_MEETING' 					=> 'Programar Reunió',
  'LNK_NEW_NOTE' 						=> 'Nova Nota o Adjunt',
  'LNK_NEW_TASK' 						=> 'Nova Tasca',
  'LNK_NOTE_LIST' 						=> 'Notes',
  'LNK_TASK_LIST' 						=> 'Tasques',
  'LNK_VIEW_CALENDAR' 					=> 'Avui',
  'LBL_MEMBER_OF' 						=> 'Membre de:',
  'LBL_LIST_ASSIGNED_TO_NAME' 			=> 'Usuari Assignat',
  'LBL_OC_FILE_NOTICE' 					=> 'Si us plau, iniciï la sessió al servidor per veure l´arxiu',
  'LBL_REMOVING_ATTACHMENT'				=> 'Traient adjunt...',
  'ERR_REMOVING_ATTACHMENT'				=> 'Error al treure adjunt...',
  'LBL_CREATED_BY'						=> 'Creat Per',
  'LBL_MODIFIED_BY'						=> 'Modificat Per',
  'LBL_SEND_ANYWAYS'					=> 'Aquest correu no te assumpte. Enviar/guardar de tota manera?',
  'LBL_LIST_EDIT_BUTTON' 				=> 'Editar',
);


?>