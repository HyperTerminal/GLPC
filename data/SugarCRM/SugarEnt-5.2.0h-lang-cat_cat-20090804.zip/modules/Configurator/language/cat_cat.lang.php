<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME'					=> 'Configuració del Sistema',
	'LBL_MODULE_ID'						=> 'Configurador',
	'LBL_MODULE_TITLE'					=> 'Interfície d´Usuari',
	'ADMIN_EXPORT_ONLY'					=> 'Només l´Admin pot exportar',
	'CAPTCHA'							=> 'Validació Captcha (comprobació usuari humanà)',
	'CAPTCHA_PRIVATE_KEY'				=> 'Clau privada de Captcha',
	'CAPTCHA_PUBLIC_KEY'				=> 'Clau pública de Captcha',
	'DISABLE_EXPORT'					=> 'Deshabilitar exportació',
	'DEFAULT_CURRENCY_NAME'				=> 'Nom de moneda',
	'DEFAULT_CURRENCY_SYMBOL'			=> 'Símbol de moneda',
	'DEFAULT_CURRENCY_ISO4217'			=> 'Còdig de moneda ISO 4217',
	'DEFAULT_CURRENCY'					=> 'Moneda predeterminada',
	'ENABLE_CAPTCHA'					=> 'Habilitar validacions Captcha per evitar trameses automàtiques de sol·licituds de formularis?',
	'EXPORT'							=> 'Exportació',
	'EXPORT_CHARSET'					=> 'Joc de caràcters d´exportació predeterminat',
	'EXPORT_DELIMITER'					=> 'Delimitador per Exportació',
	'QUOTES_CURRENT_LOGO'				=> 'Logo per Pressuposts',
	'NEW_QUOTE_LOGO'					=> 'Pujar nou logo per Pressuposts',
    'NEW_QUOTE_LOGO_HELP'				=> 'El format d´arxiu de l´imatge necessari es .jpg.<BR>El tamany recomanat es de 867x74 punts.',
    'QUOTES_CURRENT_LOGO'				=> 'Logo per Pressuposts',
	'CURRENT_LOGO'						=> 'Logo actual',
	'NEW_LOGO'							=> 'Pujar nou logo',
    'NEW_LOGO_HELP'						=> 'El format d´arxiu de l´imatge pot ser .png o .jpg.<BR>El tamany recomanat es de 212x40 punts.',
	'DEFAULT_SYSTEM_SETTINGS'			=> 'Interfície d´Usuari',
	'DEFAULT_DATE_FORMAT'				=> 'Format de data predeterminat',
	'DEFAULT_TIME_FORMAT'				=> 'Format d´hora predeterminat',
	'DEFAULT_THEME'						=> 'Tema predeterminat',
	'LBL_USE_REAL_NAMES'				=> 'Mostrar nom complet (no id usuari)',
	'LIST_ENTRIES_PER_LISTVIEW'			=> 'Elements per pàgina per llistes',
	'LIST_ENTRIES_PER_SUBPANEL'			=> 'Elements per pàgina per subpanells',
	'LBL_WIRELESS_LIST_ENTRIES' 		=> 'Elements de llista per pàgina (Mòbil)',
	'LBL_WIRELESS_SUBPANEL_LIST_ENTRIES' => 'Elements de subplafó per pàgina (Mòbil)',
	'DISPLAY_LOGIN_NAV'					=> 'Mostrar pestanyes en la finestra d´inici de sessió',
	'DISPLAY_RESPONSE_TIME'				=> 'Mostrar els temps de resposta del servidor',
	'ADVANCED'							=> 'Avançat',
	'VERIFY_CLIENT_IP'					=> 'Validar direcció IP del usuari',
	'LOG_MEMORY_USAGE'					=> 'Registrar utilització de memòria',
	'LOG_SLOW_QUERIES'					=> 'Registrar consultes lentas',
    'LOCK_HOMEPAGE_HELP'				=> 'Aquesta opció serveix per <BR> 1) la creació de noves pàgines d´inici en el mòdul Inici, i <BR>2) la personalització de la ubicació del dashlet en les pàgines d´inici usant arrosegar i soltar.',
	'SLOW_QUERY_TIME_MSEC'				=> 'Temps umbral per consultes lentes (ms)',
	'UPLOAD_MAX_SIZE'					=> 'Tamany màxim per pujada d´arxius',
	'STACK_TRACE_ERRORS'				=> 'Mostrar traça de la pila d´errors',
	'IMAGES'							=> 'Logos',
	'DEFAULT_LANGUAGE'					=> 'Llenguatge predeterminat',
	'LBL_RESTORE_BUTTON_LABEL'			=> 'Restaurar',
	'LBL_PORTAL_ON_DESC' 				=> 'Permet que un Cas, Incidència, Nota i altres dades siguin accessibles per un sistema extern de portal d´autoservei per a clients.',
	'LBL_PORTAL_ON' 					=> 'Permetre integració de portal d´autoservei?',
	'LBL_PORTAL_TITLE' 					=> 'Portal d´Autoservei per al Client',
	'LBL_PROXY_AUTH'					=> 'Autentificació?',
	'LBL_PROXY_HOST'					=> 'Servidor Proxy',
	'LBL_PROXY_ON_DESC'					=> 'Configura la direcció del servidor proxy i la configuració de l´autentificació',
	'LBL_PROXY_ON'						=> 'Utilitzar servidor proxy?',
	'LBL_PROXY_PASSWORD'				=> 'Clau de pas',
	'LBL_PROXY_PORT'					=> 'Port',
	'LBL_PROXY_TITLE'					=> 'Configuració del Proxy',
	'LBL_PROXY_USERNAME'				=> 'Nom d´Usuari',
	'LBL_SKYPEOUT_ON_DESC' 				=> 'Permet als usuaris fer clic en els números de telèfon per realitzar trucades utilitzant SkypeOut&reg;. Els números han d´estar formatats degudament per utilitzar aquesta funcionalitat. El número ha de tenir el format: " + "Còdig País" "Número", com a +34 965 555 555. Per a més informació, vegi el FAQ de Skype en  <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">FAQ de Skype&reg;</a>	',
	'LBL_SKYPEOUT_ON' 					=> 'Permetre integració amb SkypeOut&reg;?',
	'LBL_SKYPEOUT_TITLE' 				=> 'SkypeOut&reg;',
	'LBL_MAILMERGE' 					=> 'Combinar Correspondència',
	'LBL_ENABLE_MAILMERGE' 				=> 'Habilitar combinar correspondència?',
	'LBL_MAILMERGE_DESC' 				=> 'Aquesta opció s´hauria de marcar només si té el complement Sugar per a Microsoft&reg; Word&reg;.',
	'LBL_LOGVIEW' 						=> 'Configuració de Registre',
	'LBL_CONFIGURE_SETTINGS_TITLE' 		=> 'Configuració del Sistema',
	'LBL_MAIL_SMTPAUTH_REQ'				=> 'Usar Autentificació SMTP?',
	'LBL_MAIL_SMTPPASS'					=> 'Clau de pas SMTP:',
	'LBL_MAIL_SMTPPORT'					=> 'Port SMTP:',
	'LBL_MAIL_SMTPSERVER'				=> 'Servidor SMTP:',
	'LBL_MAIL_SMTPUSER'					=> 'Usuari SMTP:',
	'LBL_NOTIFY_FROMADDRESS' 			=> 'Direcció "De":',
	'LBL_NOTIFY_SUBJECT' 				=> 'Assumpte de correu:',
	'DEFAULT_NUMBER_GROUPING_SEP'		=> 'Separador de milers',
	'DEFAULT_DECIMAL_SEP'				=> 'Símbol decimal',
	'LOCK_HOMEPAGE' 					=> 'No permetre el disseny personalitzat de la Pàgina d´Inici', 
	'LOCK_SUBPANELS'					=> 'No permetre el disseny personalitzat dels subpanells',
	'MAX_DASHLETS'						=> 'Màxim número de Dashlets en la Página d´Inici',
	'SYSTEM_NAME'						=> 'Nom del Sistema',
	'LBL_OC_STATUS' 					=> 'Estat per defecte de Client Desconectat:',
    'DEFAULT_OC_STATUS' 				=> 'Habilitar Client Desconectat per defecte',
    'LBL_OC_STATUS_DESC' 				=> 'Aquí pot comprovar si desitja que qualsevol usuari pugui tenir accés a un Client Desconnectat. En un altre cas, pot configurar l´acess a nivell d´usuari.',
    'SESSION_TIMEOUT' 					=> 'Caducitat de la Sessió del Portal',
    'SESSION_TIMEOUT_UNITS' 			=> 'segons',
    'LBL_LDAP_TITLE'					=> 'Suport d´Autentificació LDAP',
    'LBL_LDAP_ENABLE'					=> 'Habilitar LDAP',
    'LBL_LDAP_SERVER_HOSTNAME'			=> 'Servidor:',
    'LBL_LDAP_SERVER_PORT'				=> 'Número de Port:',
    'LBL_LDAP_ADMIN_USER'				=> 'Usuari Autentificat:',
    'LBL_LDAP_ADMIN_USER_DESC'			=> 'Utilitzat per buscar l´usuari Sugar. [Pot ser que hagi d´estar totalment calificat]<br>La connexió serà anònima si no es proveeix.',
    'LBL_LDAP_ADMIN_PASSWORD'			=> 'Clau de pas Autenticada:',
    'LBL_LDAP_AUTO_CREATE_USERS'		=> 'Crear Usuaris Automàticament:',
    'LBL_LDAP_BASE_DN'					=> 'DN Base:',
    'LBL_LDAP_LOGIN_ATTRIBUTE'			=> 'Atribut de Login:',
    'LBL_LDAP_BIND_ATTRIBUTE'			=> 'Atribut de Bind:',
    'LBL_LDAP_BIND_ATTRIBUTE_DESC'		=> 'Per connectar al servidor LDAP Exemples d´usuari:[<b>AD:</b>&nbsp;userPrincipalName] [<b>openLDAP:</b>&nbsp;userPrincipalName] [<b>Mac&nbsp;OS&nbsp;X:</b>&nbsp;uid] ',
    'LBL_LDAP_LOGIN_ATTRIBUTE_DESC'		=> 'Per buscar en el servidor LDAP Exemples d´usuari:[<b>AD:</b>&nbsp;userPrincipalName] [<b>openLDAP:</b>&nbsp;dn] [<b>Mac&nbsp;OS&nbsp;X:</b>&nbsp;dn] ',
    'LBL_LDAP_SERVER_HOSTNAME_DESC'		=> 'Exemple: ldap.example.com',
    'LBL_LDAP_SERVER_PORT_DESC'			=> 'Exemple: 389',
    'LBL_LDAP_BASE_DN_DESC'				=> 'Exemple: DC=SugarCRM,DC=com',
    'LBL_LDAP_AUTO_CREATE_USERS_DESC'	=> 'Si un usuari autenticat no existeis, es creará un nou en Sugar.',
    'LBL_LDAP_ENC_KEY'					=> 'Clau d´Encriptació:',
    'DEVELOPER_MODE' 					=> 'Manera Desenvolupador',
    'LBL_LDAP_ENC_KEY_DESC'				=> 'Per l´autentificació SOAP al usar LDAP.',
    'LDAP_ENC_KEY_NO_FUNC_DESC' 		=> 'L´extensió php_mcrypt ha d´estar habilitada en el seu arxiu php.ini.',
    'LBL_ALL' 							=> 'Tot',
    'LBL_MARK_POINT' 					=> 'Marcar Punt',
    'LBL_NEXT_' 						=> 'Següent>>',
    'LBL_REFRESH_FROM_MARK' 			=> 'Actualitzar Desde Marca',
    'LBL_SEARCH' 						=> 'Buscar:',
    'LBL_REG_EXP' 						=> 'Exp. Reg.:',
    'LBL_IGNORE_SELF' 					=> 'Ignorar dades Pròpies:',
    'LBL_MARKING_WHERE_START_LOGGING'	=> 'Marcant des d´on iniciar la traça',
    'LBL_DISPLAYING_LOG'				=> 'Mostrant Traça',
    'LBL_YOUR_PROCESS_ID'				=> 'El seu ID de procés',
    'LBL_YOUR_IP_ADDRESS'				=> 'La seva Direcció IP es',
    'LBL_IT_WILL_BE_IGNORED'			=> ' Serà ignorat ',
    'LBL_LOG_NOT_CHANGED'				=> 'la traça no ha cambiat',
    'LBL_ALERT_JPG_IMAGE' 				=> 'El format d´arxiu de la imatge ha de ser JPEG.	Pugi un nou arxiu l´extensió del qual sigui .jpg.',
    'LBL_ALERT_TYPE_IMAGE' 				=> 'El format d´arxiu de la imatge ha de ser JPEG o PNG.	Pugi un nou arxiu l´extensió del qual sigui .jpg o .png.',
    'LBL_ALERT_SIZE_RATIO' 				=> 'La relació d´aspecte de la imatge hauria de ser entre 1:1 i 10:1. La imatge serà redimensionada.',
    'LBL_ALERT_SIZE_RATIO_QUOTES' 		=> 'La relació d´aspecte de la imatge hauria de ser entre 3:1 i 20:1. Pugi una nova imatge amb aquesta proporció.',    
    'ERR_ALERT_FILE_UPLOAD' 			=> 'Error en pujar la imatge.',
    'LBL_LOGGER'						=> 'Configuració de Traça',
	'LBL_LOGGER_FILENAME'				=> 'Nom d´Arxiu de Traça',
	'LBL_LOGGER_FILE_EXTENSION'			=> 'Extensió',
	'LBL_LOGGER_MAX_LOG_SIZE'			=> 'Tamany màxim de traça',
	'LBL_LOGGER_DEFAULT_DATE_FORMAT'	=> 'Format de data per defecte',
	'LBL_LOGGER_LOG_LEVEL'				=> 'Nivell de Traça',
	'LBL_LOGGER_MAX_LOGS'				=> 'Número màxim de traçes (abans de rotació)',
	'LBL_LOGGER_FILENAME_SUFFIX' 		=> 'Afegir després el nom d´arxiu',
	'LBL_VCAL_PERIOD' 					=> 'Període de Temps per Actualizacions vCal:',
	'vCAL_HELP' 						=> 'Faci servir aquesta opció per determinar el número de mesos per endavant sobre la data actual amb la que es pública l´informació relativa al estat de Disponible/Ocupat sobre trucades i reunions.</BR>Per desactivar la publicació del estat Disponible/Ocupat, posi "0".  El mínim es 1 mes; el màxim 12.',
);


?>
