<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Gràfics',
  'LBL_MODULE_TITLE' 					=> 'Gràfics: Inici',
  'LNK_NEW_ACCOUNT' 					=> 'Nou Compte',
  'LNK_NEW_CALL' 						=> 'Programar Trucada',
  'LNK_NEW_CASE' 						=> 'Nou Cas',
  'LNK_NEW_CONTACT' 					=> 'Nou Contacte',
  'LNK_NEW_ISSUE' 						=> 'Informar d´Incidència',
  'LNK_NEW_LEAD' 						=> 'Nou Client Potencial',
  'LNK_NEW_MEETING' 					=> 'Programar Reunió',
  'LNK_NEW_NOTE' 						=> 'Nova Nota o Arxiu Adjunt',
  'LNK_NEW_OPPORTUNITY' 				=> 'Nova Oportunitat',
  'LNK_NEW_QUOTE' 						=> 'Nou Pressupost',
  'LNK_NEW_TASK' 						=> 'Nova Tasca',
  'LBL_ADD_A_CHART' 					=> 'Afegir un Gràfic',
  'LBL_DELETE_FROM_DASHBOARD' 			=> 'Esborrar dels Gràfics',
  'LBL_MOVE_DOWN' 						=> 'Pujar',
  'LBL_MOVE_UP' 						=> 'Baixar',
  'LBL_BASIC_CHARTS' 					=> '-- Gràfics Simples --',
  'LBL_PUBLISHED_REPORTS' 				=> '-- Informes Publicats per Equip Global --',
  'LBL_MY_REPORTS' 						=> '-- Els Meus Informes Guardats --',
  'LBL_TEAM_REPORTS' 					=> '-- Informes del Meu Equip --',
  'LBL_REPORT_NO_CHART' 				=> 'Aquest informe no te un gràfic',
  'LBL_MOVE_CHARTS' 					=> '(Faci clic en un nom de gràfic per moure´l a un altre lloc)',
  'LBL_DASHBOARD_PAGE_1' 				=> 'Inici de Gràfics',
  'LBL_DASHBOARD_PAGE_2' 				=> 'Gràfics de Vendes',
);


?>