<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Productes',
  'LBL_MODULE_TITLE' 					=> 'Productes: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Productes',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Productes',
  'LBL_NEW_FORM_TITLE' 					=> 'Crear Producte',
  'LBL_PRODUCT' 						=> 'Producte:',
  'LBL_RELATED_PRODUCTS' 				=> 'Productes Relacionats',
  'LBL_LIST_NAME' 						=> 'Producte',
  'LBL_LIST_MANUFACTURER' 				=> 'Proveïdor',
  'LBL_LIST_LBL_MFT_PART_NUM' 			=> 'Nº Peça',
  'LBL_LIST_QUANTITY' 					=> 'Quantitat',
  'LBL_LIST_COST_PRICE' 				=> 'Cost',
  'LBL_LIST_DISCOUNT_PRICE' 			=> 'Preu',
  'LBL_LIST_LIST_PRICE' 				=> 'Preu Llista',
  'LBL_LIST_STATUS' 					=> 'Estat',
  'LBL_LIST_ACCOUNT_NAME' 				=> 'Nom del Compte',
  'LBL_LIST_CONTACT_NAME' 				=> 'Nom del Contacte',
  'LBL_LIST_QUOTE_NAME' 				=> 'Nom del Pressupost',
  'LBL_LIST_DATE_PURCHASED' 			=> 'Comprat',
  'LBL_LIST_SUPPORT_EXPIRES' 			=> 'Caduca',
  'LBL_NAME' 							=> 'Producte:',
  'LBL_URL' 							=> 'URL Producte:',
  'LBL_QUOTE_NAME' 						=> 'Nom del Pressupost:',
  'LBL_CONTACT_NAME' 					=> 'Nom del Contacte:',
  'LBL_DATE_PURCHASED' 					=> 'Comprat:',
  'LBL_DATE_SUPPORT_EXPIRES' 			=> 'Caducitat del Suport:',
  'LBL_DATE_SUPPORT_STARTS' 			=> 'Inici del Suport:',
  'LBL_COST_PRICE' 						=> 'Cost:',
  'LBL_DISCOUNT_PRICE' 					=> 'Preu Unitari:',
  'LBL_LIST_PRICE' 						=> 'Preu de Llista:',
  'LBL_VENDOR_PART_NUM' 				=> 'Número de Parte del Vendedor:',
  'LBL_MFT_PART_NUM' 					=> 'Número de Parte del Fabricant:',
  'LBL_DISCOUNT_PRICE_DATE' 			=> 'Data de Preu amb Descompte:',
  'LBL_WEIGHT' 							=> 'Pes:',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_TYPE' 							=> 'Tipus:',
  'LBL_CATEGORY' 						=> 'Categoria:',
  'LBL_QUANTITY' 						=> 'Quantitat:',
  'LBL_STATUS' 							=> 'Estat:',
  'LBL_TAX_CLASS' 						=> 'Tipus d´Impost:',
  'LBL_MANUFACTURER' 					=> 'Fabricant:',
  'LBL_SUPPORT_DESCRIPTION' 			=> 'Desc. del Suport:',
  'LBL_SUPPORT_TERM' 					=> 'Términi del Suport:',
  'LBL_SUPPORT_NAME' 					=> 'Títol del Suport:',
  'LBL_SUPPORT_CONTACT' 				=> 'Contacte del Suport:',
  'LBL_PRICING_FORMULA' 				=> 'Fórmula de Valoració:',
  'LBL_ACCOUNT_NAME' 					=> 'Nom del Compte:',
  'LNK_PRODUCT_LIST' 					=> 'Productes',
  'LNK_NEW_PRODUCT' 					=> 'Crear Producte',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja eliminar aquest registre?',
  'NTC_REMOVE_CONFIRMATION' 			=> 'Està segur que desitja treure aquesta relació entre productes?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el producte.',
  'LBL_CURRENCY' 						=> 'Moneda:',
  'LBL_ASSET_NUMBER' 					=> 'Múmero de Actiu:',
  'LBL_SERIAL_NUMBER' 					=> 'Número de Serie:',
  'LBL_BOOK_VALUE' 						=> 'Valor Comptable:',
  'LBL_BOOK_VALUE_DATE' 				=> 'Data del Valor Comptable:',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Productes',
  'LBL_RELATED_PRODUCTS_TITLE' 			=> 'Productes Relacionats',
  'LBL_WEBSITE' 						=> 'Lloc web',
  'LBL_PRICING_FACTOR' 					=> 'Factor de Valoració',
  'LBL_ACCOUNT_ID' 						=> 'ID Compte',
  'LBL_CONTACT_ID' 						=> 'ID Contacte',
  'LBL_CATEGORY_NAME'					=> 'Nom de Categoria:',
  'LBL_NOTES_SUBPANEL_TITLE' 			=> 'Notes',
  'LBL_MEMBER_OF' 						=> 'Membre de:',
  'LBL_PROJECTS_SUBPANEL_TITLE' 		=> 'Projectes',
  'LBL_CONTRACTS_SUBPANEL_TITLE' 		=> 'Contractes',
  'LBL_CONTRACTS' 						=> 'Contractes',  
  'LBL_PRODUCT_CATEGORIES' 				=> 'Categories de Productes',
  'LBL_PRODUCT_TYPES' 					=> 'Tipus de Productes',
  'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a:',
  'LBL_PRODUCT_TEMPLATE_ID'				=> 'ID de Plantilla de Producte:',
  'LBL_QUOTE_ID'						=> 'ID de Pressupost',
  'LBL_CREATED_USER' 					=> 'Usuari Creat',
  'LBL_MODIFIED_USER' 					=> 'Usuari Modificat',
  'LBL_QUOTE' 							=> 'Pressupost',
  'LBL_CONTACT' 						=> 'Contacte',
);


?>