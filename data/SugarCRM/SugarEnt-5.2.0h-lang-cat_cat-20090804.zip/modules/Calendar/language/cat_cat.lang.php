<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'						=> 'Calendari',
  'LBL_MODULE_TITLE'					=> 'Calendari',
  'LNK_NEW_CALL' 						=> 'Programar Trucada',
  'LNK_NEW_MEETING' 					=> 'Programar Reunió',
  'LNK_NEW_APPOINTMENT' 				=> 'Crear Cita',
  'LNK_NEW_TASK' 						=> 'Crear Tasca',
  'LNK_CALL_LIST' 						=> 'Trucades',
  'LNK_MEETING_LIST' 					=> 'Reunions',
  'LNK_TASK_LIST' 						=> 'Tasques',
  'LNK_VIEW_CALENDAR' 					=> 'Avui',
  'LNK_IMPORT_CALLS'					=> 'Importar Trucades',
  'LNK_IMPORT_MEETINGS'					=> 'Importar Reunions',
  'LNK_IMPORT_TASKS'					=> 'Importar Tasques',
  'LBL_MONTH' 							=> 'Mes',
  'LBL_DAY' 							=> 'Dia',
  'LBL_YEAR' 							=> 'Any',
  'LBL_WEEK' 							=> 'Setmana',
  'LBL_PREVIOUS_MONTH' 					=> 'Mes Anterior',
  'LBL_PREVIOUS_DAY' 					=> 'Dia Anterior',
  'LBL_PREVIOUS_YEAR' 					=> 'Any Anterior',
  'LBL_PREVIOUS_WEEK' 					=> 'Setmana Anterior',
  'LBL_NEXT_MONTH' 						=> 'Mes Següent',
  'LBL_NEXT_DAY' 						=> 'Dia Següent',
  'LBL_NEXT_YEAR' 						=> 'Any Següent',
  'LBL_NEXT_WEEK' 						=> 'Setmana Següent',
  'LBL_AM' 								=> 'AM',
  'LBL_PM' 								=> 'PM',
  'LBL_SCHEDULED' 						=> 'Planificat',
  'LBL_BUSY' 							=> 'Ocupat',
  'LBL_CONFLICT' 						=> 'Conflicte',
  'LBL_USER_CALENDARS' 					=> 'Calendaris d´Usuari',
  'LBL_SHARED' 							=> 'Compartit',
  'LBL_PREVIOUS_SHARED' 				=> 'Anterior',
  'LBL_NEXT_SHARED' 					=> 'Següent',
  'LBL_SHARED_CAL_TITLE' 				=> 'Calendari Compartit',
  'LBL_USERS' 							=> 'Usuari',
  'LBL_REFRESH' 						=> 'Actualitzar',
  'LBL_EDIT' 							=> 'Editar',
  'LBL_SELECT_USERS' 					=> 'Seleccioni usuaris per a la visualització de calendari',
  'LBL_FILTER_BY_TEAM' 					=> 'Filtrat d´usuaris per equip:',
  'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a',
  'LBL_DATE' 							=> 'Data i Hora d´Inici'
);

$mod_list_strings = array(
  'dom_cal_weekdays' => 
  array (
    0 => 'Diu',
    1 => 'Dill',
    2 => 'Dima',
    3 => 'Dix',
    4 => 'Dij',
    5 => 'Div',
    6 => 'Dis',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Diumenge',
    1 => 'Dilluns',
    2 => 'Dimarts',
    3 => 'Dimecres',
    4 => 'Dijous',
    5 => 'Divendres',
    6 => 'Dissabte',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Gen',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Abr',
    5 => 'Mai',
    6 => 'Jun',
    7 => 'Jul',
    8 => 'Ago',
    9 => 'Set',
    10 => 'Oct',
    11 => 'Nov',
    12 => 'Des',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Gener',
    2 => 'Febrer',
    3 => 'Març',
    4 => 'Abril',
    5 => 'Maig',
    6 => 'Juny',
    7 => 'Juliol',
    8 => 'Agost',
    9 => 'Setembre',
    10 => 'Octubre',
    11 => 'Novembre',
    12 => 'Desembre',
  ),
);


?>