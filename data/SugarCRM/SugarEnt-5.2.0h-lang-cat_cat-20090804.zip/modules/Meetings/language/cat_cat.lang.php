<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Reunions',
  'LBL_MODULE_TITLE' 					=> 'Reunions: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Reunions',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Reunions',
  'LBL_NEW_FORM_TITLE' 					=> 'Crear Cita',
  'LBL_SCHEDULING_FORM_TITLE' 			=> 'Planificació',
  'LBL_LIST_SUBJECT' 					=> 'Assumpte',
  'LBL_LIST_CONTACT' 					=> 'Contacte',
  'LBL_LIST_RELATED_TO' 				=> 'Relatiu a',
  'LBL_LIST_DATE' 						=> 'Data Inici',
  'LBL_LIST_TIME' 						=> 'Hora Inici',
  'LBL_LEADS_SUBPANEL_TITLE' 			=> 'Clients Potencials',
  'LBL_LIST_CLOSE' 						=> 'Tancat',
  'LBL_SUBJECT' 						=> 'Assumpte: ',
  'LBL_STATUS' 							=> 'Estat:',
  'LBL_LOCATION' 						=> 'Lloc:',
  'LBL_DATE_TIME' 						=> 'Data i hora d´inici:',
  'LBL_DATE' 							=> 'Data Inici:',
  'LBL_TIME' 							=> 'Hora Inici:',
  'LBL_HOURS_ABBREV' 					=> 'h',
  'LBL_MINSS_ABBREV' 					=> 'm',
  'LBL_DURATION' 						=> 'Durada:',
  'LBL_DURATION_HOURS' 					=> 'Hores Durada:',
  'LBL_DURATION_MINUTES' 				=> 'Minuts Durada:',
  'LBL_HOURS_MINS' 						=> '(hores/minuts)',
  'LBL_CONTACT_NAME' 					=> 'Nom Contacte: ',
  'LBL_MEETING' 						=> 'Reunió:',
  'LBL_DESCRIPTION_INFORMATION' 		=> 'Informació addicional',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_COLON' 							=> ':',
  'LBL_DEFAULT_STATUS' 					=> 'Planificada',
  'LNK_NEW_CALL' 						=> 'Programar Trucada',
  'LNK_NEW_MEETING' 					=> 'Programar Reunió',
  'LNK_NEW_TASK' 						=> 'Nova Tasca',
  'LNK_NEW_NOTE' 						=> 'Nova Nota',
  'LNK_NEW_EMAIL' 						=> 'Arxivar Correu',
  'LNK_CALL_LIST' 						=> 'Trucades',
  'LNK_MEETING_LIST' 					=> 'Reunions',
  'LNK_TASK_LIST' 						=> 'Tasques',
  'LNK_NOTE_LIST' 						=> 'Notes',
  'LNK_EMAIL_LIST' 						=> 'Correus',
  'LNK_VIEW_CALENDAR' 					=> 'Avui',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre a eliminar.',
  'NTC_REMOVE_INVITEE' 					=> 'Està segur de que vol esborrar a aquest assistent de la reunió?',
  'LBL_INVITEE' 						=> 'Assistents',
  'LNK_NEW_APPOINTMENT' 				=> 'Crear Cita',
  'LBL_ADD_INVITEE' 					=> 'Afegir Assistents',
  'LBL_NAME' 							=> 'Nom',
  'LBL_FIRST_NAME' 						=> 'Nom',
  'LBL_LAST_NAME' 						=> 'Cognoms',
  'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a:',
  'LBL_EMAIL' 							=> 'Correu',
  'LBL_PHONE' 							=> 'Telèfon',
  'LBL_REMINDER' 						=> 'Avís:',
  'LBL_SEND_BUTTON_TITLE' 				=> 'Enviar Invitacions [Alt+I]',
  'LBL_SEND_BUTTON_KEY' 				=> 'I',
  'LBL_SEND_BUTTON_LABEL' 				=> 'Enviar Invitacions',
  'LBL_REMINDER_TIME' 					=> 'Hora Avís',
  'LBL_MODIFIED_BY' 					=> 'Modificat per',
  'LBL_CREATED_BY' 						=> 'Creat per',
  'LBL_DATE_END' 						=> 'Data Fi',
  'LBL_SEARCH_BUTTON' 					=> 'Recerca',
  'LBL_ADD_BUTTON' 						=> 'Afegir',
  'LBL_DEL' 							=> 'Esborrar',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Reunions',
  'LBL_LIST_STATUS' 					=> 'Estat',
  'LBL_LIST_DUE_DATE' 					=> 'Data de Venciment',
  'LBL_LIST_DATE_MODIFIED' 				=> 'Data de Modificació',
  'LBL_CONTACTS_SUBPANEL_TITLE' 		=> 'Contactes',
  'LBL_USERS_SUBPANEL_TITLE' 			=> 'Usuaris',
  'LBL_HISTORY_SUBPANEL_TITLE' 			=> 'Notes',
  'LBL_OUTLOOK_ID' 						=> 'ID Outlook',
  'LBL_LIST_ASSIGNED_TO_NAME' 			=> 'Usuari Assignat',
  'LBL_LIST_MY_MEETINGS' 				=> 'Les Meves Reunions',
  'LBL_ACCEPT_THIS' 					=> 'Acceptar?',
  'LBL_CREATED_USER' 					=> 'Usuari Creat',
  'LBL_MODIFIED_USER' 					=> 'Usuari Modificat',
  'NOTICE_DURATION_TIME' 				=> 'El temps de durada te que ser major que 0',
);


?>