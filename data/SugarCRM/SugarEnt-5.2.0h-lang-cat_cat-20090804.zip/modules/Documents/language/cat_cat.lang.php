<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Documents',
  'LBL_MODULE_TITLE' 					=> 'Documents: Inici',
  'LNK_NEW_DOCUMENT' 					=> 'Crear Document',
  'LNK_DOCUMENT_LIST' 					=> 'Llista de Documents',
  'LBL_DOC_REV_HEADER' 					=> 'Versions',
  'LBL_SEARCH_FORM_TITLE'				=> 'Recerca de Documents',
  'LBL_DOCUMENT_ID' 					=> 'Id de Document',
  'LBL_NAME' 							=> 'Nom de Document',
	//module
  'LBL_DESCRIPTION' 					=> 'Descripció',
  'LBL_CATEGORY' 						=> 'Categoria',
  'LBL_SUBCATEGORY' 					=> 'Subcategoría',
  'LBL_STATUS' 							=> 'Estat',
  'LBL_CREATED_BY' 						=> 'Creat per',
	//vardef labels
  'LBL_DATE_ENTERED' 					=> 'Data Creación',
  'LBL_DATE_MODIFIED' 					=> 'Data Modificació',
  'LBL_DELETED' 						=> 'Eliminat',
  'LBL_MODIFIED' 						=> 'Modificat per ID',
  'LBL_MODIFIED_USER' 					=> 'Modificat per',
  'LBL_CREATED' 						=> 'Creat per',
  'LBL_REVISIONS' 						=> 'Versions',
  'LBL_RELATED_DOCUMENT_ID'				=> 'ID de Document Relacionat',
  'LBL_RELATED_DOCUMENT_REVISION_ID'	=> 'ID de Versió de Document Relacionat',
  'LBL_IS_TEMPLATE'						=> 'Es una Plantilla',
  'LBL_TEMPLATE_TYPE'					=> 'Tipus de Document',
  'LBL_ASSIGNED_TO_NAME'				=> 'Assignat a:',
  'LBL_REVISION_NAME' 					=> 'Número de Versió',
  'LBL_FILENAME' 						=> 'Nom d´Arxiu:',
  'LBL_MIME' 							=> 'Tipus MIME',
  'LBL_REVISION' 						=> 'Versió',
  'LBL_DOCUMENT' 						=> 'Document Relacionat',
  'LBL_LATEST_REVISION' 				=> 'Última Versió',
  'LBL_CHANGE_LOG' 						=> 'Històrial de Canvis:',
  'LBL_ACTIVE_DATE' 					=> 'Data de Publicació',
  'LBL_EXPIRATION_DATE' 				=> 'Data de Caducitat',
  'LBL_FILE_EXTENSION' 					=> 'Extensió d´Arxiu',
  'LBL_CAT_OR_SUBCAT_UNSPEC' 			=> 'Sense especificar',
  //quick search
  'LBL_NEW_FORM_TITLE' 					=> 'Nou Document',
  'LBL_DOC_NAME' 						=> 'Nom de Document:',
  'LBL_DOC_VERSION' 					=> 'Versió:',
  'LBL_CATEGORY_VALUE' 					=> 'Categoria:',
  'LBL_SUBCATEGORY_VALUE' 				=> 'Subcategoría:',
  'LBL_DOC_STATUS' 						=> 'Estat:',
  'LBL_LAST_REV_CREATOR' 				=> 'Versió Creada Per:',
  'LBL_LAST_REV_DATE' 					=> 'Data de Versió:',
  'LBL_DOWNNLOAD_FILE' 					=> 'Arxiu de Descarrega:',
  'LBL_DET_RELATED_DOCUMENT'			=> 'Document Relacionat:',
  'LBL_DET_RELATED_DOCUMENT_VERSION'	=> 'Versió de Document Relacionat:',
  'LBL_DET_IS_TEMPLATE'					=> 'Plantilla? :',
  'LBL_DET_TEMPLATE_TYPE'				=> 'Tipus de Document:',
  'LBL_TEAM' 							=> 'Equip:',
	//document edit and detail view
  'LBL_DOC_DESCRIPTION' 				=> 'Descripció:',
  'LBL_DOC_ACTIVE_DATE' 				=> 'Data de Publicació:',
  'LBL_DOC_EXP_DATE' 					=> 'Data de Caducitat:',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Documents',
  'LBL_LIST_DOCUMENT' 					=> 'Document',
  'LBL_LIST_DOWNLOAD' 					=> 'Descarregar',
  'LBL_LIST_CATEGORY' 					=> 'Categoría',
  'LBL_LIST_SUBCATEGORY' 				=> 'Subcategoría',
  'LBL_LIST_REVISION' 					=> 'Versió',
  'LBL_LIST_LAST_REV_CREATOR' 			=> 'Publicat Per',
  'LBL_LIST_LAST_REV_DATE' 				=> 'Data de Versió',
  'LBL_LIST_VIEW_DOCUMENT' 				=> 'Veure',
  'LBL_LIST_ACTIVE_DATE' 				=> 'Data de Publicació',
  'LBL_LIST_EXP_DATE' 					=> 'Data de Caducitat',
	//document list view.
  'LBL_LIST_STATUS' 					=> 'Estat',	
  'LBL_SF_DOCUMENT' 					=> 'Nom de Document:',
  'LBL_SF_CATEGORY' 					=> 'Categoría:',
  'LBL_SF_SUBCATEGORY' 					=> 'Subcategoría:',
  'LBL_SF_ACTIVE_DATE' 					=> 'Data de Publicació:',
  'LBL_SF_EXP_DATE' 					=> 'Data de Caducitat:',
  'DEF_CREATE_LOG' 						=> 'Document Creat',
  'ERR_DOC_NAME' 						=> 'Nom de Document',
  'ERR_DOC_ACTIVE_DATE' 				=> 'Data de Publicació',
  'ERR_DOC_EXP_DATE' 					=> 'Data de Caducitat',
	//document revisions.
  'ERR_FILENAME' 						=> 'Nom d´Arxiu',
  'ERR_DOC_VERSION' 					=> 'Versió de Document',
  'ERR_DELETE_CONFIRM' 					=> 'Desitja eliminar aquesta versió del document?',
  'ERR_DELETE_LATEST_VERSION' 			=> 'No té permisos per eliminar l´última versió d´un document.',
  'LNK_NEW_MAIL_MERGE' 					=> 'Combinar Correspondència',
  'LBL_MAIL_MERGE_DOCUMENT' 			=> 'Plantilla per Combinar Correspondència:',
  'LBL_TREE_TITLE' 						=> 'Documents',
  	//sub-panel vardefs.
  'LBL_LIST_DOCUMENT_NAME'				=> 'Nom de Document',
  'LBL_CONTRACT_NAME'					=> 'Nom de Contracte:',
  'LBL_LIST_IS_TEMPLATE'				=> 'Plantilla?',
  'LBL_LIST_TEMPLATE_TYPE'				=> 'Tipus de Document',
  'LBL_LIST_SELECTED_REVISION'			=> 'Versió Seleccionada',
  'LBL_LIST_LATEST_REVISION'			=> 'Última Versió',
  'LBL_CONTRACTS_SUBPANEL_TITLE'		=> 'Contractes Relacionats',
  //'LNK_DOCUMENT_CAT'=>'Categorias de Documents',
  'LBL_LAST_REV_CREATE_DATE'			=> 'Data de Creació de l´Última Versió',
  'LBL_CONTRACTS' 						=> 'Contractes',
  'LBL_CREATED_USER' 					=> 'Usuari Creat',
);


?>