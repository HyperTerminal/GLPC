﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 				=> 'Favorits Web',
  'LBL_MODULE_ID' 					=> 'iFrames',
  'LBL_MODULE_TITLE' 				=> 'Portal: Inici',
  'LBL_LIST_STATUS' 				=> 'Visible',
  'LBL_LIST_NAME' 					=> 'Nom',
  'LBL_LIST_URL' 					=> 'Lloc Web',
  'LBL_LIST_TYPE' 					=> 'Tipus',
  'LBL_LIST_CREATED_BY' 			=> 'Creat per',
  'LBL_LIST_PLACEMENT' 				=> 'Posició',
  'LBL_LIST_FORM_TITLE' 			=> 'Llista de Favorits Web',
  'LBL_ADD_SITE' 					=> 'Afegir Lloc',
  'LBL_LIST_SITES' 					=> 'Llistar Llocs',
  'LBL_ID' 							=> 'ID',
  'LBL_CHECKED' 					=> 'seleccionat',
  'DEFAULT_URL' 					=> 'http://www.copacker.es',
  'DROPDOWN_PLACEMENT' 				=> 
  array (
    'all' 							=> 'Menú de Pestanyes i Menú d´Accessos Directes',
    'tab' 							=> 'Menú de Pestanyes',
    'shortcut' 						=> 'Menú de Accessos Directes',
  ),
  'DROPDOWN_TYPE' => 
  array (
    'personal' 						=> 'Personal',
    'global' 						=> 'Global',
  ),
'LBL_DASHLET_TITLE' 				=> 'El Meu Lloc Web',
'LBL_DASHLET_OPT_TITLE' 			=> 'Títol',
'LBL_DASHLET_OPT_URL' 				=> 'Ubicació del Lloc Web',
'LBL_DASHLET_OPT_HEIGHT' 			=> 'Altura del Dashlet (en píxels)',
'LBL_DASHLET_SUGAR_NEWS' 			=> 'Noticies de Sugar',
'LBL_DASHLET_DISCOVER_SUGAR_PRO' 	=> 'Descubreixi Sugar Professional',
);


?>