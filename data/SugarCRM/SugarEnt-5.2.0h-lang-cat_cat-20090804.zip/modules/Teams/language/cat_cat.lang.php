<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Equips',
  'LBL_MODULE_TITLE' 					=> 'Equips: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca d´Equips',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista d´Equips',
  'LBL_NEW_FORM_TITLE' 					=> 'Nou Equip',
  'LBL_TEAM' 							=> 'Equips:',
  'LNK_LIST_TEAMNOTICE' 				=> 'Notícies d´Equip',
  'LBL_NAME' 							=> 'Nom d´Equip:',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_TEAM_MEMBERS' 					=> 'Membres del Equip',
  'LBL_INVITEE' 						=> 'Membres del Equip',
  'LNK_NEW_TEAM' 						=> 'Nou Equip',
  'LNK_LIST_TEAM' 						=> 'Equips',
  'LBL_LIST_NAME' 						=> 'Nom',
  'LBL_LIST_DESCRIPTION' 				=> 'Descripció',
  'LBL_LIST_DEPARTMENT' 				=> 'Department',
  'LBL_LIST_TITLE' 						=> 'Títol',
  'LBL_PRIVATE' 						=> 'Privat',
  'LBL_LIST_REPORTS_TO' 				=> 'Informa A',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar aquest equip.',
  'ERR_ADD_RECORD' 						=> 'Ha d´especificar un número de registre per a agragar a aquest usuari a l´equip.',
  'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => 'Està segur que desitja treure aquest usuari de l´equip?',
  'LBL_USERS' 							=> 'Usuaris',
  'LBL_GLOBAL_TEAM_DESC' 				=> 'Visibilitat Global',
  'LBL_USERS_SUBPANEL_TITLE' 			=> 'Usuaris',
  'LBL_PRIVATE_TEAM_FOR' 				=> 'Equip privat per:',
  
);


?>