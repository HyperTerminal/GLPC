<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

global $sugar_config;

$mod_strings = array (
// OOTB Scheduler Job Names:
'LBL_OOTB_WORKFLOW'						=> 'Processar Tasques de Workflow',
'LBL_OOTB_REPORTS'						=> 'Executar Tasques Programades de Generació d´Informes',
'LBL_OOTB_IE'							=> 'Comprovar Safates d´Entrada',
'LBL_OOTB_BOUNCE'						=> 'Executar Procés Nocturn de Correus de Campanya Rebotats',
'LBL_OOTB_CAMPAIGN'						=> 'Executar Procés Nocturn de Campanyes de Correu Massiu',
'LBL_OOTB_PRUNE'						=> 'Truncar Base de dades al Inici del Mes',
'LBL_OOTB_TRACKER'						=> 'Truncar Històrial d´Usuari al Inici del Mes',
'LBL_UPDATE_TRACKER_SESSIONS' 			=> 'Actualitzar taula tracker_sessions',
// List Labels
'LBL_LIST_JOB_INTERVAL' 				=> 'Interval:',
'LBL_LIST_LIST_ORDER' 					=> 'Planificacions:',
'LBL_LIST_NAME' 						=> 'Planificador:',
'LBL_LIST_RANGE' 						=> 'Rang:',
'LBL_LIST_REMOVE' 						=> 'Treure:',
'LBL_LIST_STATUS' 						=> 'Estat:',
'LBL_LIST_TITLE' 						=> 'Llista de Planificació:',
'LBL_LIST_EXECUTE_TIME' 				=> 'Será executat en:',
// human readable:
'LBL_SUN' 								=> 'Diumenge',
'LBL_MON' 								=> 'Dilluns',
'LBL_TUE' 								=> 'Dimarts',
'LBL_WED' 								=> 'Dimecres',
'LBL_THU' 								=> 'Dijous',
'LBL_FRI' 								=> 'Divendres',
'LBL_SAT' 								=> 'Dissabte',
'LBL_ALL'								=> 'Tots els dies',
'LBL_EVERY_DAY'							=> 'Tots els dies ',
'LBL_AT_THE'							=> 'El ',
'LBL_EVERY'								=> 'Cada ',
'LBL_FROM'								=> 'Desde ',
'LBL_ON_THE'							=> 'En el ',
'LBL_RANGE'								=> ' a ',
'LBL_AT' 								=> ' en ',
'LBL_IN'								=> ' en ',
'LBL_AND'								=> ' i ',
'LBL_MINUTES'							=> ' minuts ',
'LBL_HOUR'								=> ' hores',
'LBL_HOUR_SING'							=> ' hora',
'LBL_MONTH'								=> ' mes',
'LBL_OFTEN'								=> ' Tan sovint com sigui possible.',
'LBL_MIN_MARK'							=> ' marca per minut',

// crontabs
'LBL_MINS' 								=> 'min',
'LBL_HOURS' 							=> 'hrs',
'LBL_DAY_OF_MONTH' 						=> 'data',
'LBL_MONTHS' 							=> 'mes',
'LBL_DAY_OF_WEEK' 						=> 'dia',
'LBL_CRONTAB_EXAMPLES' 					=> 'Lo a dalt mostrat utilitza notació estàndard de crontab.',
// Labels
'LBL_ALWAYS' 							=> 'Sempre',
'LBL_CATCH_UP' 							=> 'Executar Si Falla',
'LBL_CATCH_UP_WARNING' 					=> 'Desmarqui si l´execució d´aquesta tasca pot durar més d´un moment.',
'LBL_DATE_TIME_END' 					=> 'Data i Hora de Fi',
'LBL_DATE_TIME_START' 					=> 'Data i Hora d´Inici',
'LBL_INTERVAL' 							=> 'Interval',
'LBL_JOB' 								=> 'Tasca',
'LBL_LAST_RUN' 							=> 'Última Execució Exitosa',
'LBL_MODULE_NAME' 						=> 'Planificador Sugar',
'LBL_MODULE_TITLE' 						=> 'Planificacions',
'LBL_NAME' 								=> 'Nom de Tasca',
'LBL_NEVER' 							=> 'Mai',
'LBL_NEW_FORM_TITLE' 					=> 'Nova Planificació',
'LBL_PERENNIAL' 						=> 'continu',
'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Planificació',
'LBL_SCHEDULER' 						=> 'Planificador:',
'LBL_STATUS' 							=> 'Estat',
'LBL_TIME_FROM' 						=> 'Actiu Desde',
'LBL_TIME_TO' 							=> 'Actiu Fins a',
'LBL_WARN_CURL_TITLE' 					=> 'Avís cURL:',
'LBL_WARN_CURL' 						=> 'Avís:',
'LBL_WARN_NO_CURL' 						=> 'Aquest sistema no té les llibreries cURL habilitades/compilades en el mòdul de PHP (--with-curl=/ruta/a/libreria_curl).  ﻿Si us plau, contacti amb el seu administrador per resoldre el problema. Sense la funcionalitat que proveeix cURL, el Planificador no pot utilitzar fils amb les seves tasques.',
'LBL_BASIC_OPTIONS' 					=> 'Configuració Bàsica',
'LBL_ADV_OPTIONS'						=> 'Opcions Avançades',
'LBL_TOGGLE_ADV' 						=> 'Opcions Avançades',
'LBL_TOGGLE_BASIC' 						=> 'Opcions Bàsiques',
// Links
'LNK_LIST_SCHEDULER' 					=> 'Planificacions',
'LNK_NEW_SCHEDULER' 					=> 'Nou Planificador',
'LNK_LIST_SCHEDULED' 					=> 'Tasques Planificades',
// Messages
'SOCK_GREETING' 						=> "\nAquest és l'interfície d'usuari per al Servei de Planificació de SugarCRM. \n[ Comandos de dimoni disponibles: start|restart|shutdown|status ]\nPer sortir, escrigui 'quit'.  Per parar el servei 'shutdown'.\n",
'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar la planificació.',
'ERR_CRON_SYNTAX' 						=> 'Sintaxis de Cron invàlida',
'NTC_DELETE_CONFIRMATION' 				=> 'Està segur que desitja eliminar aquest registre?',
'NTC_STATUS' 							=> 'Estableixi l´estat a Inactiu per treure aquesta planificació de les llistes desplegables de selecció de Planificador',
'NTC_LIST_ORDER' 						=> 'Estableixi l´ordre en el qual aquesta planificació apareixerà en les llistes desplegables de selecció de Planificador',
'LBL_CRON_INSTRUCTIONS_WINDOWS' 		=> 'Per configurar el Planificador de Windows',
'LBL_CRON_INSTRUCTIONS_LINUX' 			=> 'Per configurar Crontab',
'LBL_CRON_LINUX_DESC' 					=> 'Afegeixi aquesta línia en el seu crontab: ',
'LBL_CRON_WINDOWS_DESC' 				=> 'Crear un arxiu de procés per lots amb els següents comandos: ',
'LBL_NO_PHP_CLI' 						=> 'Si el seu servidor no té disponibles els binaris PHP, pot utilitzar wget o curl per llançar les seves Tasques .<br>per wget: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;wget --quiet --non-verbose '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1</b><br>per curl: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;curl --silent '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1',
// Subpanels
'LBL_JOBS_SUBPANEL_TITLE'				=> 'Registre de Tasques',
'LBL_EXECUTE_TIME'						=> 'Temps d´Execució',
);
?>
