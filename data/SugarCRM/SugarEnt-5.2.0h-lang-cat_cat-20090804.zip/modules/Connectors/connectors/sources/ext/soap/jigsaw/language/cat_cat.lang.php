<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2009 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$connector_strings = array (
    //licensing information shown in config screen
    'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><td valign="top" width="35%" class="dataLabel"><image src="http://www.jigsaw.com/images/cornerstone/header/jigsawLogo.jpg" border="0"></td><td width="65%" class="dataLabel">' .
                            'Jigsaw&#169; dona dades de companyies de forma gratuita a tots els usuaris de SugarCRM – ¡no es necessari registrar-se! ' .
                            'Els usuaris registrats poden fer servir el directori de Jigsaw&#169; amb més de 10 milions de contactes de negoci, ' .
                            'tots compleerts amb nom, càrreg, direcció de correu i número de teléfon. ' .
                            'Registreu-vos a <a style="cursor:pointer" href="http://www.jigsaw.com" target="_blank">http://www.jigsaw.com</a>.</td></tr>',

    //vardef labels
	'LBL_ID' => 'ID de la Companyia',
	'LBL_COMPANY_NAME' => 'Nom de la Companyia',
	'LBL_CITY' => 'Ciutat',
	'LBL_STREET' => 'Carrer',
	'LBL_STATE' => 'Estat/Província',
	'LBL_ZIP' => 'Còdig Postal',
	'LBL_COUNTRY' => 'País',
	'LBL_PHONE' => 'Teléfon',
	'LBL_SIC_CODE' => 'Còdig CNAE/SIC',
	'LBL_REVENUE' => 'Volumen de Negoci Anual',
	'LBL_REVENUE_RANGE' => 'Volumen de Negoci Anual Estimat',
	'LBL_OWNERSHIP' => 'Propietat',
	'LBL_WEBSITE' => 'Sitio Web',
	'LBL_LINKED_IN_JIGSAW' => 'Enlaç a Companyia en Jigsaw.com',
	'LBL_INDUSTRY1' => 'Industria Principal',
	'LBL_STOCK_SYMBOL' => 'Símbol Bursàtil',
	'LBL_STOCK_EXCHANGE' => 'Bolsa de Valores',
	'LBL_CREATED_ON' => 'Data de Creació del Perfil',
	'LBL_EMPLOYEE_COUNT' => 'Nº de Empleats',
	'LBL_EMPLOYEE_RANGE' => 'Dotació de personal',
	'LBL_ADDRESS' => 'Direcció',

	//Configuration labels
	'range_end' => 'Tamany Màxim de Llista de Resultats',
	'jigsaw_wsdl' => 'URL WSDL',
	'jigsaw_api_key' => 'Clau API',
);

?>
