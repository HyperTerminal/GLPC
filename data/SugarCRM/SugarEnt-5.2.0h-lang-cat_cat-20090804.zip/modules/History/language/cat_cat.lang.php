<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * English language file for History
 *
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 */
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Històrial',
  'LBL_MODULE_TITLE' 					=> 'Històrial: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca en Històrial',
  'LBL_LIST_FORM_TITLE' 				=> 'Històrial',
  'LBL_LIST_SUBJECT' 					=> 'Assumpte',
  'LBL_LIST_CONTACT' 					=> 'Contacte',
  'LBL_LIST_RELATED_TO' 				=> 'Relatiu a',
  'LBL_LIST_DATE' 						=> 'Data',
  'LBL_LIST_TIME' 						=> 'Hora d´Inici',
  'LBL_LIST_CLOSE' 						=> 'Tancament',
  'LBL_SUBJECT' 						=> 'Assumpte:',
  'LBL_STATUS' 							=> 'Estat:',
  'LBL_LOCATION' 						=> 'Lloc:',
  'LBL_DATE_TIME' 						=> 'Data i Hora d´Inici:',
  'LBL_DATE' 							=> 'Data d´Inici:',
  'LBL_TIME' 							=> 'Hora d´Inici:',
  'LBL_DURATION' 						=> 'Durada:',
  'LBL_HOURS_MINS' 						=> '(hores/minuts)',
  'LBL_CONTACT_NAME' 					=> 'Nom del Contacte: ',
  'LBL_MEETING' 						=> 'Reunió:',
  'LBL_DESCRIPTION_INFORMATION' 		=> 'Informació de Descripció',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_COLON' 							=> ':',
  'LBL_DEFAULT_STATUS' 					=> 'Planificat',
  'LNK_NEW_CALL' 						=> 'Prograrmar Trucada',
  'LNK_NEW_MEETING' 					=> 'Programar Reunió',
  'LNK_NEW_TASK' 						=> 'Crear Tasca',
  'LNK_NEW_NOTE' 						=> 'Crear Nota o Adjunt',
  'LNK_NEW_EMAIL' 						=> 'Arxivar Correu',
  'LNK_CALL_LIST' 						=> 'Trucades',
  'LNK_MEETING_LIST' 					=> 'Reunions',
  'LNK_TASK_LIST' 						=> 'Tasques',
  'LNK_NOTE_LIST' 						=> 'Notes',
  'LNK_EMAIL_LIST' 						=> 'Correus',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el compte.',
  'NTC_REMOVE_INVITEE' 					=> 'Está segur de que desitja treure aquest invitat a la reunió?',
  'LBL_INVITEE' 						=> 'Convidats',
  'LBL_LIST_DIRECTION' 					=> 'Direcció',
  'LBL_DIRECTION' 						=> 'Direcció',
  'LNK_NEW_APPOINTMENT' 				=> 'Nova Cita',
  'LNK_VIEW_CALENDAR' 					=> 'Avui',
  'LBL_OPEN_ACTIVITIES' 				=> 'Activitats Obertes',
  'LBL_HISTORY' 						=> 'Històrial',
  'LBL_UPCOMING' 						=> 'Les Meves Pròximes Cites',
  'LBL_TODAY' 							=> 'fins a ',
  'LBL_NEW_TASK_BUTTON_TITLE' 			=> 'Crear Tasca [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' 			=> 'N',
  'LBL_NEW_TASK_BUTTON_LABEL'			=> 'Crear Tasca',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' 	=> 'Programar Reunió [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' 	=> 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' 	=> 'Programar Reunió',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' 		=> 'Programar Trucada [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' 		=> 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' 		=> 'Programar Trucada',
  'LBL_NEW_NOTE_BUTTON_TITLE' 			=> 'Crear Nota o Arxiu Adjunt [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' 			=> 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' 			=> 'Crear Nota o Arxiu Adjunt',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' 		=> 'Arxivar Correu [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' 			=> 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' 		=> 'Arxivar Correu',
  'LBL_LIST_STATUS' 					=> 'Estat',
  'LBL_LIST_DUE_DATE' 					=> 'Data de Venciment',
  'LBL_LIST_LAST_MODIFIED' 				=> 'Modificat',
  'NTC_NONE_SCHEDULED' 					=> 'Rés programat.',
  'appointment_filter_dom' => array(
  	 'today' 				=> 'avui'
  	,'tomorrow' 			=> 'demà'
  	,'this Saturday' 		=> 'aquesta setmana'
  	,'next Saturday' 		=> 'la setmana vinent'
  	,'last this_month' 		=> 'aquest mes'
  	,'last next_month' 		=> 'el mes vinent'
  ),
  'LNK_IMPORT_NOTES'					=>'Importar Notes',
  'NTC_NONE'							=>'Cap',
  'LBL_ACCEPT_THIS'						=>'Acceptar?',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Històrial',
);

?>
