<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Incidències',
  'LBL_MODULE_TITLE' 					=> 'Seguiment d´Incidències: Inici',
  'LBL_MODULE_ID' 						=> 'Incidències',  
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca d´Incidències',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista d´Incidències',
  'LBL_NEW_FORM_TITLE' 					=> 'Nova Incidència',
  'LBL_CONTACT_BUG_TITLE' 				=> 'Contacte-Incidència:',
  'LBL_SUBJECT' 						=> 'Assumpte:',
  'LBL_BUG' 							=> 'Incidència:',
  'LBL_BUG_NUMBER' 						=> 'Número d´Incidència:',
  'LBL_NUMBER' 							=> 'Número:',
  'LBL_STATUS' 							=> 'Estat:',
  'LBL_PRIORITY' 						=> 'Prioritat:',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_CONTACT_NAME' 					=> 'Contacte:',
  'LBL_BUG_SUBJECT' 					=> 'Assumpte de la Incidència:',
  'LBL_CONTACT_ROLE' 					=> 'Rol:',
  'LBL_LIST_NUMBER' 					=> 'Núm.',
  'LBL_LIST_SUBJECT' 					=> 'Assumpte',
  'LBL_LIST_STATUS' 					=> 'Estat',
  'LBL_LIST_PRIORITY' 					=> 'Prioritat',
  'LBL_LIST_RELEASE'					=> 'Release',
  'LBL_LIST_RESOLUTION' 				=> 'Resolució',
  'LBL_LIST_LAST_MODIFIED' 				=> 'Modificat',
  'LBL_INVITEE' 						=> 'Contactes',
  'LBL_TYPE' 							=> 'Tipus:',
  'LBL_LIST_TYPE' 						=> 'Tipus',
  'LBL_RESOLUTION' 						=> 'Resolució:',
  'LBL_RELEASE' 						=> 'Release:',
  'LNK_NEW_BUG' 						=> 'Informe d´Incidència',
  'LNK_BUG_LIST' 						=> 'Incidències',
  'NTC_REMOVE_INVITEE' 					=> 'Està segur que desitja treure aquest contacte de la incidència?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' 	=> 'Està segur que desitja moure aquesta incidència fora d´aquest compte?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar la incidència.',
  'LBL_LIST_MY_BUGS' 					=> 'Les Meves Incidències Assignades',
  'LBL_FOUND_IN_RELEASE' 				=> 'Trobat en Llançament:',
  'LBL_FIXED_IN_RELEASE' 				=> 'Corregit en Llançament:',
  'LBL_LIST_FIXED_IN_RELEASE' 			=> 'Corregit en Llançament',  
  'LBL_WORK_LOG' 						=> 'Registre d´Activitat:',
  'LBL_SOURCE' 							=> 'Font:',
  'LBL_PRODUCT_CATEGORY'				=> 'Categoria:',
  'LBL_CREATED_BY' 						=> 'Creat per:',
  'LBL_DATE_CREATED' 					=> 'Data de creació:',
  'LBL_MODIFIED_BY' 					=> 'Modificat per:',
  'LBL_DATE_LAST_MODIFIED' 				=> 'Última modificació:',
  'LBL_LIST_EMAIL_ADDRESS' 				=> 'Correu',
  'LBL_LIST_CONTACT_NAME' 				=> 'Contacte',
  'LBL_LIST_ACCOUNT_NAME' 				=> 'Compte',
  'LBL_LIST_PHONE' 						=> 'Telèfon',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja treure aquest contacte d´aquesta incidència?',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Seguiment d´Incidències',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'		=> 'Activitats',
  'LBL_HISTORY_SUBPANEL_TITLE'			=> 'Històrial',
  'LBL_CONTACTS_SUBPANEL_TITLE' 		=> 'Contactes',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' 		=> 'Comptes',
  'LBL_CASES_SUBPANEL_TITLE' 			=> 'Casos',
  'LBL_PROJECTS_SUBPANEL_TITLE' 		=> 'Projectes',
  'LBL_SYSTEM_ID' 						=> 'ID Sistema',
  'LBL_LIST_ASSIGNED_TO_NAME' 			=> 'Usuari Assignat',
  'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a',
  'LBL_ASSIGNED_TO_ID' 					=> 'Usuari Assignat',
  'LNK_BUG_REPORTS' 					=> 'Informes d´Incidències',
  'LBL_SHOW_IN_PORTAL' 					=> 'Mostrar en el Portal',
);
?>
