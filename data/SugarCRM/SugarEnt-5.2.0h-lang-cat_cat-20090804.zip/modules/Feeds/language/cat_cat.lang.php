<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'RSS',
  'LBL_MODULE_ID' 						=> 'Fonts RSS',
  'LBL_MODULE_TITLE' 					=> 'RSS: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'RSS Recerca de Fonts de Notícies',
  'LBL_LIST_FORM_TITLE' 				=> 'RSS Llista de Fonts de Notícies',
  'LBL_MY_LIST_FORM_TITLE' 				=> 'Les Meves Fonts de Notícies RSS',
  'LBL_NEW_FORM_TITLE' 					=> 'Nova Font de Notícies RSS',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja eliminar aquest registre?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar aquesta font.',
  'LNK_NEW_FEED' 						=> 'Nova Font de Notícies RSS',
  'LNK_FEED_LIST' 						=> 'Totes les Fonts de Notícies RSS',
  'LNK_MY_FEED_LIST' 					=> 'Les Meves Fonts de Notícies RSS',
  'LBL_TITLE' 							=> 'Títol',
  'LBL_RSS_URL' 						=> 'URL RSS',
  'LBL_ONLY_MY' 						=> 'Només els meus favorits',
  'LBL_VISIT_WEBSITE' 					=> 'visitar lloc web',
  'LBL_LAST_UPDATED' 					=> 'Actualizat',
  'LBL_DELETE_FAVORITES' 				=> 'Treure de Favorits',
  'LBL_DELETE_FAV_BUTTON_TITLE' 		=> 'Treure de Favorits [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' 			=> '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' 		=> 'Treure de Favorits',
  'LBL_ADD_FAV_BUTTON_TITLE' 			=> 'Afegir a Favorits [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' 				=> '[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' 			=> 'Afegir a Favorits',
  'LBL_MOVE_UP' 						=> 'Moure Adalt',
  'LBL_MOVE_DOWN' 						=> 'Moure Abaix',
  'LBL_FEED_NOT_AVAILABLE'				=> 'Font no disponible',
  'LBL_REFRESH_CACHE'					=> 'Faci clic aquí per actualitzar la caché',
  'LBL_TILE'							=> 'Títol',
  'LBL_URL'								=> 'URL',
  'LBL_DESCRIPTION'						=> 'Descripció',
);


?>
