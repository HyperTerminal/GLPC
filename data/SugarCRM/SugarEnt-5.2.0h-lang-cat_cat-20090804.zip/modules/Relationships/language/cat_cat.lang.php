﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_ID' => 'Id de Relació',
  'LBL_RELATIONSHIP_NAME' => 'Nom de Relació',
  'LBL_LHS_MODULE' => 'Nom de Mòdul LHS',
  'LBL_LHS_TABLE' => 'Nom de Taula LHS',
  'LBL_LHS_KEY' => 'Nom de Clau LHS',
  'LBL_RHS_MODULE' => 'Nom de Mòdul RHS',
  'LBL_RHS_TABLE' => 'Nom de Taula RHS',
  'LBL_RHS_KEY' => 'Nom de Clau RHS',
  'LBL_JOIN_TABLE' => 'Nom de Taula de Join',
  'LBL_JOIN_KEY_LHS' => 'Clau de Join LHS',
  'LBL_JOIN_KEY_RHS' => 'Clau de Join RHS',
  'LBL_RELATIONSHIP_TYPE' => 'Tipus de Relació',
  'LBL_RELATIONSHIP_ROLE_COLUMN' => 'Nom de Columna de Rol de Relació',
  'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE' => 'Valor de Columna de Rol de Relació',
  'LBL_REVERSE' => 'Invertir' ,
  'LBL_DELETED' => 'Eliminat',
);
  
?>
