<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
	// module labels
	'LBL_MODULE_NAME' 					=> 'Contractes',
	'LBL_MODULE_TITLE' 					=> 'Contractes: Inici',
	
	// quick menu link labels
	'LNK_NEW_CONTRACT' 					=> 'Nou Contracte',
	'LNK_CONTRACT_LIST' 				=> 'Llista de Contractes',

	// quick create label
	'LBL_NEW_FORM_TITLE' 				=> 'Nou Contracte',

	// vardef labels
	'LBL_CONTRACT_NAME' 				=> 'Nom de Contracte:',
	'LBL_REFERENCE_CODE' 				=> 'Còdig de Referència:',
	'LBL_ACCOUNT_NAME' 					=> 'Compte:',
	'LBL_OPPORTUNITY' 					=> 'Oportunitat:',
	'LBL_START_DATE' 					=> 'Data d´Inici:',
	'LBL_END_DATE' 						=> 'Data de Fi:',
	'LBL_TOTAL_CONTRACT_VALUE' 			=> 'Valor del Contracte:',
	'LBL_TOTAL_CONTRACT_VALUE_USDOLLAR' => 'Valor del Contracte (Dòlar EEUU):',
	'LBL_STATUS' 						=> 'Estat:',
	'LBL_CUSTOMER_SIGNED_DATE' 			=> 'Data de Firma per Client:',
	'LBL_COMPANY_SIGNED_DATE' 			=> 'Data de Firma per Companyía:',
	'LBL_CONTRACT_TERM' 				=> 'Terme de Contracte:',
	'LBL_EXPIRATION_NOTICE' 			=> 'Avís de Caducitat:',
	'LBL_TIME_TO_EXPIRY' 				=> 'Temps per Caducitat:',
	'LBL_DESCRIPTION' 					=> 'Descripció:',
	'LBL_TEAM' 							=> 'Equip:',
	'LBL_ASSIGNED_TO' 					=> 'Assignat a:',
	'LBL_CURRENCY_ID' 					=> 'ID Moneda:',
	'LBL_CURRENCY' 						=> 'Moneda:',
	'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a:',
                        
	// listview labels
	'LBL_LIST_FORM_TITLE' 				=> 'Llista de Contractes',	
	'LBL_LIST_CONTRACT_NAME' 			=> 'Nom de Contracte',
	'LBL_LIST_ACCOUNT_NAME' 			=> 'Compte',
	'LBL_LIST_START_DATE' 				=> 'Inici',
	'LBL_LIST_END_DATE' 				=> 'Fi',
	'LBL_LIST_STATUS' 					=> 'Estat',
	'LBL_LIST_TEAM_NAME' 				=> 'Equip',
	'LBL_LIST_ASSIGNED_TO_USER' 		=> 'Usuari',
	'LBL_DAYS' 							=> 'Dia(es)',
	'LBL_UNDEFINED' 					=> 'No definit',
	'LBL_NONE' 							=> 'Cap',

	// search form labels
	'LBL_SEARCH_FORM_TITLE' 			=> 'Recerca de Contractes',
	'LBL_SF_CONTRACT_NAME' 				=> 'Nom de Contracte:',
	'LBL_SF_ACCOUNT_NAME' 				=> 'Compte:',
	'LBL_SF_STATUS' 					=> 'Estat:',
	'LBL_SF_CONTRACT_TYPE' 				=> 'Tipus:',
	'LBL_SF_START_DATE' 				=> 'Data d´Inici:',
	'LBL_SF_END_DATE' 					=> 'Data de Fi:',
	'LBL_SF_ASSIGNED_TO' 				=> 'Assignat a:',
	
	// subpanels
	'LBL_DOCUMENTS_SUBPANEL_TITLE' 		=> 'Documents',
	'LBL_CONTACTS_SUBPANEL_TITLE' 		=> 'Contactes',
	'LBL_NOTES_SUBPANEL_TITLE' 			=> 'Notes',
	'LBL_PRODUCTS_SUBPANEL_TITLE' 		=> 'Productes',
	'LBL_QUOTES_SUBPANEL_TITLE' 		=> 'Pressuposts',
	'LBL_LIST_NAME' 					=> 'Nom',
	'LBL_LIST_CONTRACT_VALUE' 			=> 'Valor',	
	'LBL_TYPE'							=> 'Tipus',
	'LBL_CONTRACT_TYPE'					=> 'Tipus:',
	'LBL_CREATED_USER' 					=> 'Usuari Creat',
    'LBL_MODIFIED_USER' 				=> 'Usuari Modificat',
    'LBL_DOCUMENTS' 					=> 'Documents',
);

?>
