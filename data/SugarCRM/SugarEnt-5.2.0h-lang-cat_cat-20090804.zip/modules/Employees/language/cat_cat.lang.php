<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Empleats',
  'LBL_MODULE_TITLE' 					=> 'Empleats: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Empleats',
  'LBL_LIST_FORM_TITLE' 				=> 'Empleats',
  'LBL_NEW_FORM_TITLE' 					=> 'Nou Empleat',
  'LBL_EMPLOYEE' 						=> 'Empleat:',
  'LBL_LOGIN' 							=> 'Login',
  'LBL_RESET_PREFERENCES' 				=> 'Restablir Preferències per Defecte',
  'LBL_TIME_FORMAT' 					=> 'Format Hora:',
  'LBL_DATE_FORMAT' 					=> 'Format Data:',
  'LBL_TIMEZONE' 						=> 'Zona Horaria:',
  'LBL_CURRENCY' 						=> 'Moneda:',
  'LBL_LIST_NAME' 						=> 'Nom',
  'LBL_LIST_LAST_NAME' 					=> 'Cognom',
  'LBL_LIST_EMPLOYEE_NAME' 				=> 'Nom del Empleat',
  'LBL_LIST_DEPARTMENT' 				=> 'Departament',
  'LBL_LIST_REPORTS_TO_NAME' 			=> 'Informa a',
  'LBL_LIST_EMAIL' 						=> 'Correu',
  'LBL_LIST_PRIMARY_PHONE' 				=> 'Telèfon Principal',
  'LBL_LIST_USER_NAME' 					=> 'Nom d´Usuari',
  'LBL_LIST_EMPLOYEE_STATUS' 			=> 'Estat',
  'LBL_LIST_ADMIN' 						=> 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' 		=> 'Nou Empleat [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' 		=> 'Nou Empleat',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' 		=> 'N',
  'LBL_ERROR' 							=> 'Error:',
  'LBL_PASSWORD' 						=> 'Contransenya:',
  'LBL_EMPLOYEE_NAME' 					=> 'Nom del Empleat:',
  'LBL_USER_NAME' 						=> 'Nom d´Usuari:',
  'LBL_FIRST_NAME' 						=> 'Nom:',
  'LBL_LAST_NAME' 						=> 'Cognom:',
  'LBL_EMPLOYEE_SETTINGS' 				=> 'Preferències del Empleat',
  'LBL_THEME' 							=> 'Tema:',
  'LBL_LANGUAGE' 						=> 'Llenguatge:',
  'LBL_ADMIN' 							=> 'Administrador:',
  'LBL_EMPLOYEE_INFORMATION' 			=> 'Informació del Empleat',
  'LBL_OFFICE_PHONE' 					=> 'Tel. Oficina:',
  'LBL_REPORTS_TO' 						=> 'Informa a Id:',
  'LBL_REPORTS_TO_NAME' 				=> 'Informa a:',
  'LBL_OTHER_PHONE' 					=> 'Un altre:',
  'LBL_OTHER_EMAIL' 					=> 'Correu Alternatiu:',
  'LBL_NOTES' 							=> 'Notes:',
  'LBL_DEPARTMENT' 						=> 'Departament:',
  'LBL_TITLE' 							=> 'Títol:',
  'LBL_ANY_PHONE' 						=> 'Tel. Alternatiu:',
  'LBL_ANY_EMAIL' 						=> 'Correu Alternatiu:',
  'LBL_ADDRESS' 						=> 'Direcció:',
  'LBL_CITY' 							=> 'Ciutat:',
  'LBL_STATE' 							=> 'Estat/Província:',
  'LBL_POSTAL_CODE' 					=> 'Còdig Postal:',
  'LBL_COUNTRY' 						=> 'País:',
  'LBL_NAME' 							=> 'Nom:',
  'LBL_MOBILE_PHONE' 					=> 'Mòbil:',
  'LBL_OTHER' 							=> 'Un altre:',
  'LBL_FAX' 							=> 'Fax:',
  'LBL_EMAIL' 							=> 'Correu:',
  'LBL_HOME_PHONE' 						=> 'Tel. Casa:',
  'LBL_WORK_PHONE' 						=> 'Tel. Treball:',
  'LBL_ADDRESS_INFORMATION' 			=> 'Informació de Direcció',
  'LBL_EMPLOYEE_STATUS' 				=> 'Estat del Empleat:',
  'LBL_PRIMARY_ADDRESS' 				=> 'Direcció Principal:',
  'LBL_CREATE_USER_BUTTON_TITLE' 		=> 'Crear Usuari [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' 		=> 'Crear Usuari',
  'LBL_CREATE_USER_BUTTON_KEY' 			=> 'N',
  'LBL_FAVORITE_COLOR' 					=> 'Color Favorit:',
  'LBL_MESSENGER_ID' 					=> 'Nom MI:',
  'LBL_MESSENGER_TYPE' 					=> 'Tipus MI:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' 			=> 'El nom del empleat ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' 			=> ' ja existeix. No es permeten empleats duplicats. Canviï el nom de l´empleat perquè sigui únic.',
  'ERR_LAST_ADMIN_1' 					=> 'El nom del empleat "',
  'ERR_LAST_ADMIN_2' 					=> '" és l´últim empleat amb permisos d´administrador. Almenys un empleat ha de ser un administrador.',
  'LNK_NEW_EMPLOYEE' 					=> 'Crear Empleat',
  'LNK_EMPLOYEE_LIST' 					=> 'Empleats',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar l´empleat.',
  'LBL_DEFAULT_TEAM' 					=> 'Equip per Defecte:',
  'LBL_DEFAULT_TEAM_TEXT' 				=> 'Selecciona l´equip per defecte per nous registres',
  'LBL_MY_TEAMS' 						=> 'Els Meus Equips',
  'LBL_LIST_DESCRIPTION' 				=> 'Descripció',
  'LNK_EDIT_TABS' 						=> 'Editar Pestanyes',
  'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => 'Està segur de que vol esborrar aquest empleat del equipo?',
  'LBL_SUGAR_LOGIN' 					=> 'Es Usuari de Sugar',  
  'LBL_RECEIVE_NOTIFICATIONS' 			=> 'Notificar al seu Assignat',  
  'LBL_IS_ADMIN' 						=> 'Es Administrador',  
  'LBL_GROUP' 							=> 'Usuari de Grup',
  'LBL_PORTAL_ONLY'						=> 'Usuari Només de Portal',
  );


?>