<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Consultes Personalizades',
  'LBL_MODULE_TITLE' 					=> 'Consultes Personalizades',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Consultes Personalizades',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Consultes Personalizades',
  'LBL_CUSTOMQUERY' 					=> 'Consulta Personalitzada:',
  'LBL_QUERY_TYPE' 						=> 'Tipus de Consulta:',
  'LBL_LIST_NAME' 						=> 'Nom de Consulta',
  'LBL_LIST_DESCRIPTION' 				=> 'Descripció',
  'LBL_NAME' 							=> 'Nom de Consulta:',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_LIST_LIST_ORDER' 				=> 'Ordre',
  'LBL_LIST_ORDER' 						=> 'Ordre:',
  'LBL_QUERY_LOCKED' 					=> 'Consulta Bloquejada:',
  'LBL_LIST_VALID' 						=> 'Consulta Vàlida?',
  'LNK_PRODUCT_LIST' 					=> 'Catàleg de Productes',
  'LNK_REPORT_MAKER' 					=> 'Disenyador d´Informes',
  'LNK_NEW_SHIPPER' 					=> 'Proveïdors de Transport',
  'LBL_RUN_QUERY' 						=> 'Executar Consulta',
  'LNK_LIST_REPORTMAKER' 				=> 'Lista d´Informes Empresarials',
  'LNK_NEW_REPORTMAKER' 				=> 'Crear Informe',
  'LNK_LIST_DATASET' 					=> 'Llista de Formats de dades',
  'LNK_NEW_DATASET' 					=> 'Crear Format de dades',
  'LNK_NEW_CUSTOMQUERY' 				=> 'Crear Consulta Personalitzada',
  'LNK_CUSTOMQUERIES' 					=> 'Consultas Personalitzades',
  'LNK_NEW_QUERYBUILDER' 				=> 'Crear Consulta',
  'LNK_QUERYBUILDER' 					=> 'Disenyador de Consultes',
  'LBL_ALL_REPORTS' 					=> 'Tots els Informes',
  'LNK_NEW_PRODUCT_TYPE' 				=> 'Tipus de Producte',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja eliminar aquest registre?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el tipus de producte.',
  'NTC_LIST_ORDER' 						=> 'Estableix l´ordre en el qual aquesta categoria apareixerà en les llistes desplegables de Categories de Productes',
  'LNK_IMPORT_PRODUCT_CATEGORIES' 		=> 'Importar Categories de Productes',
  'DUPBLANK_ERROR_MSG' 					=> 'Té, o un nom de columna buit, o un nom de columna duplicat',
  'QUERY_ERROR_MSG' 					=> 'Aquesta Consulta no es vàlida.',
  'LBL_REPAIR_BUTTON_TITLE' 			=> 'Reparar Consulta [Alt+R]',
  'LBL_REPAIR_BUTTON_KEY' 				=> 'R',
  'LBL_REPAIR_BUTTON_LABEL' 			=> 'Reparar Consulta',
  'LBL_JSCRIPT_MULTI_MAP_ERROR' 		=> 'Ha definit més d´una columna amb el mateix nom de camp.',
  'LBL_REMOVE_LAYOUT_DATA' 				=> 'Treure les dades del Disseny',
  'CHILD_ERROR_MSG' 					=> 'Aquesta Consulta només és accessible mitjançant el Format de dades padre',
  'ERROR_RESULT_MSG' 					=> 'Aquesta Consulta no és vàlida.',
  'CHILD_RESULT_MSG' 					=> 'Aquesta consulta no pot ser executada de forma independent.',
  'LBL_QUERYRESULT' 					=> 'Resultats de la Consulta',
);


?>