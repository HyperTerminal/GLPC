<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 				=> 'Activitats',
  'LBL_MODULE_TITLE' 				=> 'Activitats: Inici',
  'LBL_SEARCH_FORM_TITLE' 			=> 'Recerca d´Activitats',
  'LBL_LIST_FORM_TITLE' 			=> 'Lista d´Activitats',
  'LBL_LIST_SUBJECT' 				=> 'Assumpte',
  'LBL_LIST_CONTACT' 				=> 'Contacte',
  'LBL_LIST_RELATED_TO' 			=> 'Relatiu a',
  'LBL_LIST_DATE' 					=> 'Data',
  'LBL_LIST_TIME' 					=> 'Hora d´inici',
  'LBL_LIST_CLOSE' 					=> 'Tancar',
  'LBL_SUBJECT' 					=> 'Assumpte:',
  'LBL_STATUS' 						=> 'Estat:',
  'LBL_LOCATION' 					=> 'Lloc:',
  'LBL_DATE_TIME' 					=> 'Inici:',
  'LBL_DATE' 						=> 'Data d´inici:',
  'LBL_TIME' 						=> 'Hora d´inici:',
  'LBL_DURATION' 					=> 'Durada:',
  'LBL_DURATION_MINUTES' 			=> 'Minuts de Durada:',
  'LBL_HOURS_MINS' 					=> '(hores/minuts)',
  'LBL_CONTACT_NAME' 				=> 'Contacte: ',
  'LBL_MEETING' 					=> 'Reunió:',
  'LBL_DESCRIPTION_INFORMATION' 	=> 'Informació addicional',
  'LBL_DESCRIPTION' 				=> 'Descripció:',
  'LBL_COLON' 						=> ':',
  'LBL_DEFAULT_STATUS' 				=> 'Planificada',
  'LNK_NEW_CALL' 					=> 'Programar Trucada',
  'LNK_NEW_MEETING' 				=> 'Programar Reunió',
  'LNK_NEW_TASK' 					=> 'Nova Tasca',
  'LNK_NEW_NOTE' 					=> 'Nova Nota o Arxiu Adjunt',
  'LNK_NEW_EMAIL' 					=> 'Nou Correu Arxivat',
  'LNK_CALL_LIST' 					=> 'Trucades',
  'LNK_MEETING_LIST' 				=> 'Reunions',
  'LNK_TASK_LIST' 					=> 'Tasques',
  'LNK_NOTE_LIST' 					=> 'Notes',
  'LNK_EMAIL_LIST' 					=> 'Correus',
  'ERR_DELETE_RECORD' 				=> 'Ha d´especificar un número de registre per eliminar el compte.',
  'NTC_REMOVE_INVITEE' 				=> 'Està segur que desitja eliminar aquest assistent a la reunió?',
  'LBL_INVITEE' 					=> 'Assistents',
  'LBL_LIST_DIRECTION' 				=> 'Direcció',
  'LBL_DIRECTION' 					=> 'Direcció',
  'LNK_NEW_APPOINTMENT' 			=> 'Nova Cita',
  'LNK_VIEW_CALENDAR' 				=> 'Avui',
  'LBL_OPEN_ACTIVITIES' 			=> 'Activitats Obertes',
  'LBL_HISTORY' 					=> 'Històrial',
  'LBL_UPCOMING' 					=> 'Les Meves Pròximes Cites',
  'LBL_TODAY' 						=> 'fins a ',
  'LBL_NEW_TASK_BUTTON_TITLE' 		=> 'Nova Tasca [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' 		=> 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' 		=> 'Nova Tasca',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Programar Reunió [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Programar Reunió',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' 	=> 'Programar Trucada [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' 	=> 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' 	=> 'Programar Trucada',
  'LBL_NEW_NOTE_BUTTON_TITLE' 		=> 'Nova Nota o Arxiu Adjunt [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' 		=> 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' 		=> 'Nova Nota o Arxiu Adjunt',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' 	=> 'Correu Seguiment [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' 		=> 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' 	=> 'Correu Seguiment',
  'LBL_LIST_STATUS' 				=> 'Estat',
  'LBL_LIST_DUE_DATE' 				=> 'Data Venciment',
  'LBL_LIST_LAST_MODIFIED' 			=> 'Modificat',
  'NTC_NONE_SCHEDULED' 				=> 'Sense programació.',
  'appointment_filter_dom' =>
   array(
  	 'today' 						=> 'avui',
	 'tomorrow' 					=> 'demà',
	 'this Saturday' 				=> 'aquesta setmana',
	 'next Saturday' 				=> 'la setmana vinent',
	 'last this_month' 				=> 'aquest mes',
	 'last next_month' 				=> 'proper mes',
  ),
  'LNK_IMPORT_NOTES' 				=> 'Importar Notes',
  'NTC_NONE' 						=> 'Cap',
  'LBL_ACCEPT_THIS' 				=> 'Acceptar?',
  'LBL_DEFAULT_SUBPANEL_TITLE' 		=> 'Activitats Obertes',
  'LBL_LIST_ASSIGNED_TO_NAME' 		=> 'Usuari Assignat',
);


?>