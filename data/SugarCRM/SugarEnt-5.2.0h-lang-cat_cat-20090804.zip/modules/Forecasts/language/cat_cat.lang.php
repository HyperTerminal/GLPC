<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Objectius',
  'LNK_NEW_OPPORTUNITY' 				=> 'Crear Oportunitat',
  'LBL_MODULE_TITLE' 					=> 'Objectius',
  'LBL_LIST_FORM_TITLE' 				=> 'Objectius Realitzats',
  'LNK_UPD_FORECAST' 					=> 'Full d´Objectiu',
  'LNK_QUOTA' 							=> 'Quotas',
  'LNK_FORECAST_LIST' 					=> 'Històrial de Previsions',
  'LBL_FORECAST_HISTORY' 				=> 'Previsions: Històrial',
  'LBL_FORECAST_HISTORY_TITLE' 			=> 'Previsions: Històrial',
  //module strings.
  'LBL_TIMEPERIOD_NAME' 				=> 'Període de Temps',
  'LBL_USER_NAME' 						=> 'Nom d´Usuari',
  'LBL_REPORTS_TO_USER_NAME' 			=> 'Informa A',
  'LBL_FORECAST_ID' 					=> 'ID',
  'LBL_FORECAST_TIME_ID' 				=> 'ID Període de Temps',
  'LBL_FORECAST_TYPE' 					=> 'Tipus de Previsió',
  'LBL_FORECAST_OPP_COUNT' 				=> 'Oportunitats',
  'LBL_FORECAST_OPP_WEIGH' 				=> 'Quantitat Ponderada',
  'LBL_FORECAST_OPP_COMMIT' 			=> 'Cas Probable',
  'LBL_FORECAST_OPP_BEST_CASE'			=> 'Cas Millor',
  'LBL_FORECAST_OPP_WORST'				=> 'Cas Pitjor',
  //var defs
  'LBL_FORECAST_USER' 					=> 'Usuari',
  'LBL_DATE_COMMITTED' 					=> 'Data Realització',
  'LBL_DATE_ENTERED' 					=> 'Data Creació',
  'LBL_DATE_MODIFIED' 					=> 'Data Modificació',
  //forecast table
  'LBL_CREATED_BY' 						=> 'Creat per',
  'LBL_DELETED' 						=> 'Eliminat',
  'LBL_MODIFIED_USER_ID'				=> 'Modificat per',  
  'LBL_QC_TIME_PERIOD' 					=> 'Període de Temps:',
  'LBL_QC_OPPORTUNITY_COUNT' 			=> 'Compte d´Oportunitats:',
  'LBL_QC_WEIGHT_VALUE' 				=> 'Quantitat Ponderada:',
  'LBL_QC_COMMIT_VALUE' 				=> 'Quantitat Realitzada:',
  'LBL_QC_COMMIT_BUTTON' 				=> 'Realitzar',
  'LBL_QC_WORKSHEET_BUTTON' 			=> 'Full de càlcul',
  'LBL_QC_ROLL_COMMIT_VALUE' 			=> 'Quantitat Realitzada en Dinàmica:',
  'LBL_QC_DIRECT_FORECAST' 				=> 'La Meva Previsió Directa:',
  'LBL_QC_ROLLUP_FORECAST' 				=> 'La Meva Previsió de Grup:',
  'LBL_QC_UPCOMING_FORECASTS' 			=> 'Els Meus Objectius',
  'LBL_QC_LAST_DATE_COMMITTED' 			=> 'Última Data de Realització:',
   //Quick Commit labels.
  'LBL_QC_LAST_COMMIT_VALUE' 			=> 'Última Quantitat Realitzada:',
  'LBL_QC_HEADER_DELIM' 				=> 'A',
  'LBL_OW_OPPORTUNITIES' 				=> 'Oportunitat',
  'LBL_OW_ACCOUNTNAME' 					=> 'Compte',
  'LBL_OW_REVENUE' 						=> 'Quantitat',
  'LBL_OW_WEIGHTED' 					=> 'Quantitat Ponderada',
  'LBL_OW_MODULE_TITLE' 				=> 'Full d´Oportunitat',
  'LBL_OW_PROBABILITY' 					=> 'Probabilitat',
  'LBL_OW_NEXT_STEP'					=> 'Següent Pas',
  'LBL_OW_DESCRIPTION'					=> 'Descripció',
  'LBL_OW_TYPE'							=> 'Tipus',
  'LNK_NEW_TIMEPERIOD' 					=> 'Crear Període de Temps',
  'LNK_TIMEPERIOD_LIST' 				=> 'Períodes de Temps',
  'LBL_SVFS_FORECASTDATE' 				=> 'Data d´Inici de Planificació',
  'LBL_SVFS_STATUS' 					=> 'Estat',
  'LBL_SVFS_USER' 						=> 'Per a',
  'LBL_SVFS_CASCADE' 					=> 'Propagar en cascada a Informes?',
  //opportunity worksheet list view labels
  'LBL_SVFS_HEADER' 					=> 'Planificació del Objectiu:',
  'LB_FS_KEY' 							=> 'ID',
  'LBL_FS_TIMEPERIOD_ID' 				=> 'ID Període de Temps',
  'LBL_FS_USER_ID' 						=> 'ID Usuari',
  'LBL_FS_TIMEPERIOD' 					=> 'Període de Temps',
  'LBL_FS_START_DATE' 					=> 'Data d´Inici',
  'LBL_FS_END_DATE' 					=> 'Data de Fi',
  //forecast schedule shortcuts
  'LBL_FS_FORECAST_START_DATE' 			=> 'Data d´Inici del Objectiu',
  'LBL_FS_STATUS' 						=> 'Estat',
  'LBL_FS_FORECAST_FOR' 				=> 'Planificar per a:',
  //Forecast schedule sub panel list view.
  'LBL_FS_CASCADE' 						=> 'En cascada?',
  'LBL_FS_MODULE_NAME' 					=> 'Planificació d´Objectiu',
  'LBL_FS_CREATED_BY' 					=> 'Creat per',
  'LBL_FS_DATE_ENTERED' 				=> 'Data Creació',
  'LBL_FS_DATE_MODIFIED' 				=> 'Data Modificació',
  'LBL_FS_DELETED' 						=> 'Eliminat',
  //Forecast Schedule detail; view.....
  'LBL_FDR_USER_NAME' 					=> 'Informador Directe',
  'LBL_FDR_OPPORTUNITIES' 				=> 'Oportunitats en objectiu:',
  'LBL_FDR_WEIGH' 						=> 'Quantitat Ponderada d´oportunitats:',
  'LBL_FDR_COMMIT' 						=> 'Quantitat Realitzada',
  'LBL_FDR_DATE_COMMIT' 				=> 'Data de Realització',
  'LBL_DV_HEADER' 						=> 'Objectius: Full de càlcul',
  'LBL_DV_MY_FORECASTS' 				=> 'Els Meus Objectius',
  'LBL_DV_MY_TEAM' 						=> 'Objectius del meu Equip',
  'LBL_DV_TIMEPERIODS' 					=> 'Períodes de Temps:',
  'LBL_DV_FORECAST_PERIOD' 				=> 'Període de Temps del Objectiu',
  'LBL_DV_FORECAST_OPPORTUNITY' 		=> 'Oportunitats del Objectiu',
  'LBL_SEARCH' 							=> 'Seleccionar',
  'LBL_SEARCH_LABEL' 					=> 'Seleccionar',
  'LBL_COMMIT_HEADER' 					=> 'Realització d´Objectiu',
  'LBL_DV_LAST_COMMIT_DATE' 			=> 'Última Data de Realització:',
  'LBL_DV_LAST_COMMIT_AMOUNT' 			=> 'Últimes Quantitats Realitzades:',
  //forecast worksheet direct reports forecast
  'LBL_DV_FORECAST_ROLLUP' 				=> 'Previsió Dinàmica',
  'LBL_DV_TIMEPERIOD' 					=> 'Període de Temps:',
  'LBL_DV_TIMPERIOD_DATES' 				=> 'Rang de Dates:',
  'LBL_LV_TIMPERIOD' 					=> 'Període de Temps',
  'LBL_LV_TIMPERIOD_START_DATE' 		=> 'Data d´Inici',
  'LBL_LV_TIMPERIOD_END_DATE' 			=> 'Data de Fi',
  //detail view.
  'LBL_LV_TYPE' 						=> 'Tipus d´Objectiu',
  'LBL_LV_COMMIT_DATE' 					=> 'Data de Realització',
  'LBL_LV_OPPORTUNITIES' 				=> 'Oportunitats',
  'LBL_LV_WEIGH' 						=> 'Quantitat Ponderada',
  'LBL_LV_COMMIT' 						=> 'Quantitat Realitzada',
  'LBL_COMMIT_NOTE' 					=> 'Introdueixi les quantitats que desitgi realitzar en el Període de Temps seleccionat:',
  'LBL_COMMIT_MESSAGE' 					=> 'Vol introduir aquestes quantitats com realitzades?',
  'ERR_FORECAST_AMOUNT' 				=> 'La Quantitat Realitzada és un valor requerit, i ha de ser numèric.',
  // js error strings
  'LBL_FC_START_DATE' 					=> 'Data d´Inici',
  'LBL_FC_USER' 						=> 'Programar Per a',
  'LBL_NO_ACTIVE_TIMEPERIOD'			=> 'No hi ha cap període de temps Actiu per al Objectiu.',
  'LBL_FDR_ADJ_AMOUNT'					=> 'Quantitat Ajustada',
  'LBL_SAVE_WOKSHEET'					=> 'Guardar Full de càlcul',
  'LBL_RESET_WOKSHEET'					=> 'Reiniciar Full de càlcul',
  'LBL_SHOW_CHART'						=> 'Veure Gràfic',
  'LBL_RESET_CHECK'						=> 'Tots les dades del full de càlcul per al període de temps seleccionat i per a l´usuari que ha iniciat la sessió s´eliminaran, desitja continuar?',
  'LB_FS_LIKELY_CASE'					=> 'Cas Probable',
  'LB_FS_WORST_CASE'					=> 'Cas Pitjor',
  'LB_FS_BEST_CASE'						=> 'Cas Millor',
  'LBL_FDR_WK_LIKELY_CASE'				=> 'Est. Caso Probable',
  'LBL_FDR_WK_BEST_CASE'				=> 'Est. Caso Millor',
  'LBL_FDR_WK_WORST_CASE'				=> 'Est. Caso Pitjor',
  'LBL_BEST_CASE'						=> 'Cas Millor:',
  'LBL_LIKELY_CASE'						=> 'Cas Probable:',
  'LBL_WORST_CASE'						=> 'Cas Pitjor:',
  'LBL_FDR_C_BEST_CASE'					=> 'Cas Millor',
  'LBL_FDR_C_WORST_CASE'				=> 'Cas Pitjor',
  'LBL_FDR_C_LIKELY_CASE'				=> 'Cas Probable',
  'LBL_QC_LAST_BEST_CASE'				=> 'Quantitat Última Realització (Caso Millor):',
  'LBL_QC_LAST_LIKELY_CASE'				=> 'Quantitat Última Realització (Caso Probable):',
  'LBL_QC_LAST_WORST_CASE'				=> 'Quantitat Última Realització (Caso Pitjor):',
  'LBL_QC_ROLL_BEST_VALUE'				=> 'Quantitat Dinàmica Realitzada (Caso Millor):',
  'LBL_QC_ROLL_LIKELY_VALUE'			=> 'Quantitat Dinàmica Realitzada (Caso Probable):',
  'LBL_QC_ROLL_WORST_VALUE'				=> 'Quantitat Dinàmica Realitzada (Caso Pitjor):',  
  'LBL_QC_COMMIT_BEST_CASE'				=> 'Quantitat Realitzada (Caso Millor):',
  'LBL_QC_COMMIT_LIKELY_CASE'			=> 'Quantitat Realitzada (Caso Probable):',
  'LBL_QC_COMMIT_WORST_CASE'			=> 'Quantitat Realitzada (Caso Pitjor):',
  'LBL_FORECAST_FOR'					=> 'Full d´Objectiu per a: ',
  'LBL_FMT_ROLLUP_FORECAST'				=> '(Dinàmica)',
  'LBL_FMT_DIRECT_FORECAST'				=> '(Directa)',
  //labels used by the chart.
  'LBL_GRAPH_TITLE'						=> 'Històrial de Previsions',
  'LBL_GRAPH_QUOTA_ALTTEXT'				=> 'Quota per a %s',
  'LBL_GRAPH_COMMIT_ALTTEXT'			=> 'Quantitat Realitzada per a %s',
  'LBL_GRAPH_OPPS_ALTTEXT'				=> 'El valor de les oportunitats tancades en %s',
  'LBL_GRAPH_QUOTA_LEGEND'				=> 'Quota',
  'LBL_GRAPH_COMMIT_LEGEND'				=> 'Previsió Realitzada',
  'LBL_GRAPH_OPPS_LEGEND'				=> 'Oportunitats Tancades',
  'LBL_TP_QUOTA'						=> 'Quota:',
  'LBL_CHART_FOOTER'					=> 'Històrial de Objectiu<br/>Quantitat en Cuota vs Prevista vs Valor d´Oportunitat Tancada',
  'LBL_TOTAL_VALUE'						=> 'Totals:',
  'LBL_COPY_AMOUNT'						=> 'Quantitat total',
  'LBL_COPY_WEIGH_AMOUNT'				=> 'Quantitats totals ponderades',
  'LBL_WORKSHEET_AMOUNT'				=> 'Quantitats totals estimades',
  'LBL_COPY'							=> 'Copiar Valors',  
  'LBL_COMMIT_AMOUNT'					=> 'Suma de valors Realitzats.',
  'LBL_COPY_FROM'						=> 'Copiar valor de:',
  'LBL_CHART_TITLE' 					=> 'Pressupuestat vs. Realitzat vs. Real',
);


?>