﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
	'LBL_ID'=>'Id',
	'LBL_DATE_ENTERED'				=> 'Data d´Alta',
	'LBL_DATE_MODIFIED'				=> 'Data de Modificació',
	'LBL_MODIFIED_USER_ID'			=> 'Modificat per l´Usuari',
	'LBL_CREATED_BY'				=> 'Creat per',
	'LBL_DELETED'					=> 'Eliminat',
	'LBL_DOCUMENTS'					=> 'Documents',
	'LBL_TYPE_NAME'					=> 'Nom del Tipus',
	'LBL_MODULE_NAME'				=> 'Tipus de Contracte',
	'LBL_MODULE_TITLE'				=> 'Tipus de Contracte',
	'LBL_LIST_FORM_TITLE'			=> 'Tipus de Contracte',
	'LBL_CONTRACT_TYPE'				=> 'Tipus de Contracte',
	'LBL_LIST_ORDER'				=> 'Ordre de Llistat:',
	'LNK_CONTRACTTYPE_LIST'			=> 'Tipus de Contracte',
	'LBL_LIST_NAME'					=> 'Nom',
	'LBL_LIST_LIST_ORDER'			=> 'Ordre de Llistat',
	'LBL_NAME'						=> 'Nom:',
	'NTC_DELETE_CONFIRMATION'		=> 'Esborrar Tipus de Contracte?',
	'LBL_DOCUMENTS_SUBPANEL_TITLE'	=> 'Documents',
	'LBL_SEARCH_FORM_TITLE' 		=> 'Recerca per Tipus de Contracte',
);
?>
