<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 					=> 'Alertes',
  'LBL_MODULE_TITLE' 					=> 'Alertes: Inici',
  'LBL_MODULE_SECTION_TITLE' 			=> 'Les següents operacions seran realitzades',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca d´Alertes de Workflow',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista d´Alertes',
  'LBL_NEW_FORM_TITLE' 					=> 'Crear Alerta de Workflow',
  'LBL_LIST_NAME' 						=> 'Nom',
  'LBL_LIST_ALERT_TYPE' 				=> 'Tipus d´Alerta',
  'LBL_LIST_ALERT_TEXT' 				=> 'Missatge per l´Alerta',
  'LBL_CUSTOM_TEMPLATE_NAME' 			=> 'Plantilla Personalitzada',
  'LBL_NAME' 							=> 'Nom:',
  'LBL_ALERT_TEXT' 						=> 'Text de l´Alerta:',
  'LBL_ALERT_TYPE' 						=> 'Tipus d´Alerta:',
  'LBL_SOURCE_TYPE' 					=> 'Tipus d´Origen:',
  'LBL_LIST_TYPE' 						=> 'Tipus:',
  'LBL_LIST_DETAILS' 					=> 'Detalls',
  'LNK_NEW_WORKFLOW' 					=> 'Crear Definició de Workflow',
  'LNK_WORKFLOW' 						=> 'Llista de Definicions de Workflow',
  'LBL_PARENT_WORKFLOW' 				=> 'Objecte de Workflow Padre:',
  'LBL_RETURN_TO_WORKFLOW' 				=> 'Tornar a Definició de Workflow',
  'NTC_REMOVE_ALERT' 					=> 'Està segur que desitja treure aquesta alerta i tots els seus destinataris?',
  'LBL_LIST_STATEMENT' 					=> 'Descripció del Event:',
  'STATEMENT_PART1' 					=> 'Enviar',
  'STATEMENT_PART2' 					=> 'usant un',
  'LNK_LIST_REPORTMAKER' 				=> 'Llista d´Informes',
  'LNK_NEW_REPORTMAKER' 				=> 'Crear Informe',
  'LNK_LIST_DATASET' 					=> 'Llista de Formats de Dades',
  'LNK_NEW_DATASET' 					=> 'Crear Format de Dades',
  'LNK_NEW_QUERYBUILDER' 				=> 'Crear Consulta',
  'LNK_QUERYBUILDER' 					=> 'Disenyador de Consultes',
  'LBL_ALL_REPORTS' 					=> 'Tots els Informes',
  'NTC_DELETE_CONFIRMATION' 			=> 'Està segur que desitja eliminar aquest registre?',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el producte.',
  'LBL_NEW_BUTTON_LABEL_ALERT' 			=> 'Crear Alerta',
  'LBL_NEW_BUTTON_KEY_ALERT' 			=> 'A',
  'LBL_NEW_BUTTON_TITLE_ALERT' 			=> 'Crear Alerta [Alt+A]',
  'LBL_NEW_BUTTON_LABEL_ACTION' 		=> 'Crear Acció',
  'LBL_NEW_BUTTON_KEY_ACTION' 			=> 'C',
  ////////////Old stuff below, eventually move or rename or delete
  'LBL_NEW_BUTTON_TITLE_ACTION' 		=> 'Crear Acció [Alt+C]',
  'LBL_MODULE_NAME_COMBO' 				=> 'Alertes',
  'LNK_ALERT_TEMPLATES' 				=> 'Plantilles d´Alerta',
  'LNK_PROCESS_VIEW' 					=> 'Ordre d´Execució del Workflow',
  'LBL_LIST_COMPONENTS' 				=> 'Components',
  'LBL_RECIPIENTS' 						=> 'Destinataris',
  'LBL_MODULE_TITLE_INVITE' 			=> 'Convidar a Gent',
  'LBL_SHOW' 							=> 'Mostrar',
  );


?>