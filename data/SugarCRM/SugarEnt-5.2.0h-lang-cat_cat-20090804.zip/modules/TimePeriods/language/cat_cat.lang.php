<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'LBL_NAME' 							=> 'ID',
  'LBL_TP_NAME' 						=> 'Període de Temps',
  'LBL_TP_START_DATE' 					=> 'Data d´Inici',
  'LBL_TP_END_DATE' 					=> 'Data de Fi',
  'LBL_TP_FISCAL_YEAR' 					=> 'Any Fiscal',
  'LBL_MODULE_NAME' 					=> 'Períodes de Temps',
  'LBL_MODULE_TITLE' 					=> 'Períodes de Temps: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Períodes de Temps',
  'LBL_LIST_FORM_TITLE' 				=> 'Períodes de Temps',
  'LBL_NEW_FORM_TITLE' 					=> 'Nou Període de Temps',
  'LNK_NEW_TIMEPERIOD' 					=> 'Nou Període de Temps',
  'LNK_TIMEPERIOD_LIST' 				=> 'Períodes de Temps',
  'LBL_TP_IS_FISCAL_YEAR' 				=> 'Es Any Fiscal?',
  'LBL_PARENT_ID' 						=> 'Id Padre',
  'LBL_CREATED_BY' 						=> 'Creat per',
  'LBL_DATE_ENTERED' 					=> 'Data de Creació',
  'LBL_DATE_MODIFIED' 					=> 'Data de Modificació',
  'LBL_DELETED' 						=> 'Eliminat',
  'LBL_SEARCH_TP_NAME' 					=> 'Període de Temps',
  'LBL_SEARCH_TP_START_DATE' 			=> 'Data d´Inici',
  'LBL_SEARCH_TP_END_DATE' 				=> 'Data de Fi',
  'ERR_TIME_PERIOD_DATE_RANGE' 			=> 'La data de final del període de temps hauria de ser posterior a la d´inici.',
);


?>