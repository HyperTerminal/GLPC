<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Veuresion
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * *******************************************************************************/
/*********************************************************************************
 * Description:  Defines the Catalan language pack for the base application. 
 * $Id: cat_cat.lang.php,v 1.0 2009/08/04 16:13:27 rfeliu Exp $
 * Source: SugarCRM 5.2.0
 * Contributor(s): Ramón Feliu (ramon@slay.es).
 ********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre per eliminar el compte.',
  'LBL_MODULE_NAME' 					=> 'Casos',
  'LBL_MODULE_TITLE' 					=> 'Casos: Inici',
  'LBL_SEARCH_FORM_TITLE' 				=> 'Recerca de Casos',
  'LBL_NEW_FORM_TITLE' 					=> 'Nou Cas',
  'LBL_CONTACT_CASE_TITLE' 				=> 'Contacte-Cas:',
  'LBL_SUBJECT' 						=> 'Assumpte:',
  'LBL_CASE' 							=> 'Cas:',
  'LBL_CASE_NUMBER' 					=> 'Número:',
  'LBL_NUMBER' 							=> 'Número:',
  'LBL_STATUS' 							=> 'Estat:',
  'LBL_PRIORITY' 						=> 'Prioritat:',
  'LBL_PROJECTS_SUBPANEL_TITLE' 		=> 'Projectes',
  'LBL_ACCOUNT_NAME' 					=> 'Compte:',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' 		=> 'Comptes',
  'LBL_ATTACH_NOTE' 					=> 'Adjuntar Nota',
  'LBL_DESCRIPTION' 					=> 'Descripció:',
  'LBL_FILENANE_ATTACHMENT' 			=> 'Arxivar Adjunt',	
  'LBL_RESOLUTION' 						=> 'Resolució:',
  'LBL_CONTACT_NAME' 					=> 'Contacte:',
  'LBL_CASE_SUBJECT' 					=> 'Assumpte:',
  'LBL_CONTACT_ROLE' 					=> 'Rol:',
  'LBL_INVITEE' 						=> 'Contactes',
  'ERR_DELETE_RECORD' 					=> 'Ha d´especificar un número de registre a eliminar.',
  'LBL_ACCOUNT_ID' 						=> 'ID Compte',
  'LBL_DEFAULT_SUBPANEL_TITLE' 			=> 'Casos',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' 		=> 'Activitats',
  'LBL_HISTORY_SUBPANEL_TITLE' 			=> 'Històrial',
  'LBL_CONTACTS_SUBPANEL_TITLE' 		=> 'Contactes',
  'LBL_BUGS_SUBPANEL_TITLE' 			=> 'Incidències',
  'LBL_MEMBER_OF' 						=> 'Compte',
  'LBL_SYSTEM_ID' 						=> 'ID Sistema',
  'LBL_LIST_ACCOUNT_NAME' 				=> 'Compte',
  'LBL_LIST_ASSIGNED' 					=> 'Assignat a',
  'LBL_LIST_CLOSE' 						=> 'Tancar',
  'LBL_LIST_FORM_TITLE' 				=> 'Llista de Casos',
  'LBL_LIST_LAST_MODIFIED' 				=> 'Modificat',
  'LBL_LIST_MY_CASES' 					=> 'Els Meus Casos Oberts',
  'LBL_LIST_NUMBER' 					=> 'Núm.',
  'LBL_LIST_PRIORITY' 					=> 'Prioritat',
  'LBL_LIST_STATUS' 					=> 'Estat',
  'LBL_LIST_SUBJECT' 					=> 'Assumpte',
  'LNK_CASE_LIST' 						=> 'Casos',
  'LNK_NEW_CASE' 						=> 'Nou Cas',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' 	=> 'Esta segur de que vol treure aquest cas de la incidència?',
  'NTC_REMOVE_INVITEE' 					=> 'Esta segur de que vol treure aquest contacte del compte?',
  'LBL_LIST_ASSIGNED_TO_NAME' 			=> 'Usuari Assignat',
  'LBL_LIST_DATE_CREATED' 				=> 'Data de Creació',
  'LBL_ASSIGNED_TO_NAME' 				=> 'Assignat a',
  'LBL_TYPE' 							=> 'Tipus',
  'LBL_WORK_LOG' 						=> 'Registre de Treball',
  'LNK_CASE_REPORTS' 					=> 'Informes de Casos',
  'LBL_SHOW_IN_PORTAL' 					=> 'Mostrar en Portal',
  'LBL_CREATE_KB_DOCUMENT' 				=> 'Crear Article',
  'LBL_CREATED_USER' 					=> 'Usuari Creat',
  'LBL_MODIFIED_USER' 					=> 'Usuari Modificat',
);


?>