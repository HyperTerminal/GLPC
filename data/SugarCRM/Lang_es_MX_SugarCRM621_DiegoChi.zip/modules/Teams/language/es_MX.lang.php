<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Equipos.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'ERR_ADD_RECORD' => 'Debe especificar un número de registro para agregar a este usuario al equipo' ,
   'ERR_DUP_NAME' => 'El nombre de equipo ya existe, por favor elija otro' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar este equipo' ,
   'ERR_INVALID_TEAM_REASSIGNMENT' => 'Error.  El equipo seleccionado <b>({0})</b> es un equipo que ha elegido eliminar.  Por favor, seleccione otro equipo' ,
   'ERR_CANNOT_REMOVE_PRIVATE_TEAM' => 'Error. No puede eliminar a un usuario de equipo privado' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_GLOBAL_TEAM_DESC' => 'Visibilidad global' ,
   'LBL_INVITEE' => 'Miembros del equipo' ,
   'LBL_LIST_DEPARTMENT' => 'Departmento' ,
   'LBL_LIST_DESCRIPTION' => 'Descripción' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de equipos' ,
   'LBL_LIST_NAME' => 'Nombre' ,
   'LBL_FIRST_NAME' => 'Nombre:' ,
   'LBL_LAST_NAME' => 'Apellido:' ,
   'LBL_LIST_REPORTS_TO' => 'Reportar a' ,
   'LBL_LIST_TITLE' => 'Título' ,
   'LBL_MODULE_NAME' => 'Equipos' ,
   'LBL_MODULE_TITLE' => 'Equipos : Inicio' ,
   'LBL_NAME' => 'Nombre de equipo:' ,
   'LBL_NAME_2' => 'Nombre de equipo (2):' ,
   'LBL_PRIMARY_TEAM_NAME' => 'Nombre de equipo principal' ,
   'LBL_NEW_FORM_TITLE' => 'Nuevo equipo' ,
   'LBL_PRIVATE' => 'Privado' ,
   'LBL_PRIVATE_TEAM_FOR' => 'Equipo privado para:' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de equipos' ,
   'LBL_TEAM_MEMBERS' => 'Miembros del equipo' ,
   'LBL_TEAM' => 'Equipos:' ,
   'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios' ,
   'LBL_USERS' => 'Usuarios' ,
   'LBL_REASSIGN_TEAM_TITLE' => 'Hay registros asignados a los siguientes equipos: <b>{0}</b><br>Antes de eliminar los equipos, debe primero reasignar estos registros a un nuevo equipo.  Seleccione un equipo para utilizar como reemplazo' ,
   'LBL_REASSIGN_TEAM_BUTTON_KEY' => 'R' ,
   'LBL_REASSIGN_TEAM_BUTTON_LABEL' => 'Reasignar' ,
   'LBL_REASSIGN_TEAM_BUTTON_TITLE' => 'Reasignar [Alt+R]' ,
   'LBL_CONFIRM_REASSIGN_TEAM_LABEL' => '¿Proceder a actualizar los registros afectados para que utilicen el nuevo equipo?' ,
   'LBL_REASSIGN_TABLE_INFO' => 'Actualizando tabla {0}' ,
   'LBL_REASSIGN_TEAM_COMPLETED' => 'La operación se ha completado con éxito' ,
   'LNK_LIST_TEAM' => 'Equipos' ,
   'LNK_LIST_TEAMNOTICE' => 'Noticias de equipo' ,
   'LNK_NEW_TEAM' => 'Nuevo equipo' ,
   'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => '¿Está seguro que desea quitar a este usuario del equipo?' );

?>