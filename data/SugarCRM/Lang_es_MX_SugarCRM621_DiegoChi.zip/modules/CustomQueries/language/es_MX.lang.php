<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Consultas personalizadas.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Consultas personalizadas' ,
   'LBL_MODULE_TITLE' => 'Consultas personalizadas' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de consultas personalizadas' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de consultas personalizadas' ,
   'LBL_CUSTOMQUERY' => 'Consulta personalizada:' ,
   'LBL_QUERY_TYPE' => 'Tipo de consulta:' ,
   'LBL_LIST_NAME' => 'Nombre de la consulta' ,
   'LBL_LIST_DESCRIPTION' => 'Descripción' ,
   'LBL_NAME' => 'Nombre:' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_LIST_LIST_ORDER' => 'Orden' ,
   'LBL_LIST_ORDER' => 'Orden:' ,
   'LBL_QUERY_LOCKED' => 'Consulta bloqueada:' ,
   'LBL_LIST_VALID' => '¿Consulta válida?' ,
   'LNK_PRODUCT_LIST' => 'Catálogo de productos' ,
   'LNK_REPORT_MAKER' => 'Creador de Reportes' ,
   'LNK_NEW_SHIPPER' => 'Envío' ,
   'LBL_RUN_QUERY' => 'Ejecutar la consulta' ,
   'LNK_LIST_REPORTMAKER' => 'Lista de reportes' ,
   'LNK_NEW_REPORTMAKER' => 'Crear un reporte' ,
   'LNK_LIST_DATASET' => 'Lista de formato de datos' ,
   'LNK_NEW_DATASET' => 'Crear un formato de datos' ,
   'LNK_NEW_CUSTOMQUERY' => 'Crear una consulta personalizada' ,
   'LNK_CUSTOMQUERIES' => 'Consultas personalizadas' ,
   'LNK_NEW_QUERYBUILDER' => 'Crear una consulta' ,
   'LNK_QUERYBUILDER' => 'Consultas' ,
   'LBL_ALL_REPORTS' => 'Todos los reportes' ,
   'LNK_NEW_PRODUCT_TYPE' => 'Tipos de productos' ,
   'NTC_DELETE_CONFIRMATION' => '¿Está seguro que desea eliminar este registro?' ,
   'ERR_DELETE_RECORD' => 'Tiene que especificar un número de registro para eliminar el tipo de producto' ,
   'NTC_LIST_ORDER' => 'Definir el orden en el cual esta categoría incluye listas de producto de la categoría de productos' ,
   'LNK_IMPORT_PRODUCT_CATEGORIES' => 'Importar categorías de producto' ,
   'DUPBLANK_ERROR_MSG' => 'Es posible que algún nombre de columna esté duplicado' ,
   'QUERY_ERROR_MSG' => 'Esta consulta es incorrecta' ,
   'LBL_REPAIR_BUTTON_TITLE' => 'Reparar la consulta [Alt+R]' ,
   'LBL_REPAIR_BUTTON_KEY' => 'R' ,
   'LBL_REPAIR_BUTTON_LABEL' => 'Reparar la consulta' ,
   'LBL_JSCRIPT_MULTI_MAP_ERROR' => 'Algunas columnas han sido definidas para el mismo campo' ,
   'LBL_REMOVE_LAYOUT_DATA' => 'Remove Layout Data' ,
   'CHILD_ERROR_MSG' => 'La consulta sólo es accesible desde el formato de datos original' ,
   'ERROR_RESULT_MSG' => 'Esta consulta es incorrecta' ,
   'CHILD_RESULT_MSG' => 'Esta consulta no puede funcionar de manera independiente' ,
   'LBL_QUERYRESULT' => 'Resultado de la consulta' );

?>