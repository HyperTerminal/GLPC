<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de KBTags.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Etiquetas de artículo' ,
   'LBL_MODULE_TITLE' => 'Etiquetas de artículo' ,
   'LNK_NEW_TAG' => 'Crear etiqueta de artículo' ,
   'LNK_KBTAG_LIST' => 'Listar etiquetas de artículo' ,
   'LBL_SEARCH_FORM_TITLE' => 'Buscar etiquetas de artículo' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de etiquetas de artículo' ,
   'LBL_KBTAGS_ID' => 'ID etiqueta:' ,
   'LBL_PARENT_TAG_ID' => 'IdD padre:' ,
   'LBL_ROOT_TAG' => 'Raíz:' ,
   'LBL_TAG_NAME' => 'Nombre de etiqueta' ,
   'LBL_CREATED_BY' => 'Creado por' ,
   'LBL_DATE_ENTERED' => 'Fecha de creación' ,
   'LBL_DATE_MODIFIED' => 'Fecha de modificación' ,
   'LBL_DELETED' => 'Eliminado' ,
   'LBL_MODIFIED' => 'Modificado por ID' ,
   'LBL_MODIFIED_USER' => 'Modificado por' ,
   'LBL_CREATED' => 'Creado por' ,
   'LBL_CHILD_TAG_IN_TREE_HOVER' => 'Etiqueta hija' ,
   'LBL_CHILD_TAGS_IN_TREE_HOVER' => 'Etiquetas hijas' ,
   'LBL_ARTICLE_IN_TREE_HOVER' => 'Artículo' ,
   'LBL_ARTICLES_IN_TREE_HOVER' => 'Artículos' ,
   'LBL_THIS_TAG_CONTAINS_TREE_HOVER' => 'Esta etiqueta contiene' ,
   'LBL_TAGS_ROOT_LABEL' => 'Etiquetas' ,
   'LBL_ROOT_TAG_CAN_NOT_BE_RENAMED' => 'La etiqueta raíz no puede ser renombrada' ,
   'LBL_SOURCE_AND_TARGET_TAGS_ARE_SAME' => 'Las etiquetas origen y destino son la misma' ,
   'LBL_NO_MATHING_TAG_FOUND' => 'No se han encontrado etiquetas que coincidan con los criterios de búsqueda' ,
   'LBL_TYPE_TAG_NAME_TO_SEARCH' => 'Introduzca el nombre de etiqueta a buscar' ,
   'LBL_TAGS_CHILD_TAGS_WITH_ARTICLE_CAN_NOT_BE_DELETE' => 'Las etiquetas hijas de las etiquetas con artículos no pueden ser eliminadas' ,
   'LBL_FAQ_TAG_CAN_NOT_BE_DELETED' => ' etiqueta y no pueden ser eliminadas' ,
   'LBL_UNTAGGED_ARTICLES_NODE' => 'Artículos sin etiqueta' );

?>