<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-professional-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.; All Rights Reserved.
********************************************************************************/
/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el SOAP Hoovers.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$connector_strings = array (
    //licensing information shown in config screen
    'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><td valign="top" width="35%" class="dataLabel"><image src="http://www.jigsaw.com/images/cornerstone/header/jigsawLogo.jpg" border="0"></td><td width="65%" class="dataLabel">' .
                            'Jigsaw&#169; proporciona datos de empresas y usuarios de SugarCRM – ¡no es necesario registrarse! ' .
                            'Los miembros registrados en Jigsaw&#169;&#039;s pueden accesar a más de 10 millones de contactos, ' .
                            'con nombre, cargo, e-Mail y teléfono' .
                            'Registro: <a style="cursor:pointer" href="http://www.jigsaw.com" target="_blank">http://www.jigsaw.com</a></td></tr>',

    //vardef labels
	'LBL_ID' => 'ID compañía',
	'LBL_COMPANY_NAME' => 'Compañía',
	'LBL_CITY' => 'Ciudad',
	'LBL_STREET' => 'Calle',
	'LBL_STATE' => 'Estado',
	'LBL_COUNTRY' => 'País',
	'LBL_PHONE' => 'Teléfono',
	'LBL_SIC_CODE' => 'Código SIC',
	'LBL_REVENUE' => 'Ingresos',
	'LBL_REVENUE_RANGE' => 'Rango de ingresos estimados',
	'LBL_OWNERSHIP' => 'Propietario',
	'LBL_WEBSITE' => 'Sitio Web',
	'LBL_LINKED_IN_JIGSAW' => 'Sitio Web en Jigsaw',
	'LBL_INDUSTRY1' => 'Actividad',
	'LBL_STOCK_SYMBOL' => 'Símbolo de Stock',
	'LBL_STOCK_EXCHANGE' => 'Intercambio de Stock',
	'LBL_CREATED_ON' => 'Fecha de creación del perfil',
	'LBL_EMPLOYEE_COUNT' => 'Número de empleados',
	'LBL_EMPLOYEE_RANGE' => 'Empleados activos',
	
	//Error messages
	'ERROR_API_CALL' => 'Error: ',
	
	//Configuration labels
	'range_end' => 'Número máximo de lista de resultados',
	'jigsaw_wsdl' => 'URL de WSDL',
	'jigsaw_api_key' => 'Llave API',
);

?>