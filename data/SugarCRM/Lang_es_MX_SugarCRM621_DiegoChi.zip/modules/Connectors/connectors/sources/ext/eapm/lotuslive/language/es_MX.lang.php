<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el conector LotusLive.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$connector_strings = array ( 
   'LBL_LICENSING_INFO' => '<table border=&#034;0&#034; cellspacing=&#034;1&#034;><tbody><tr><td class=&#034;dataLabel&#034; valign=&#034;top&#034; width=&#034;35%&#034;>Obtenga una llave y una cadena secreta de LotusLive© para registrar su instancia SugarCRM como una nueva aplicación. La habilidad para registrarla será posible hasta el 8 de mayo de 2011<br>
&nbsp;<br>
Pasos para registrar su instancia:<br>
&nbsp;<br>
<ol>
<li>Inicie sesión en su cuenta de LotusLive (tiene que ser un administrador de LotusLive): <a href=&#034;https://www.lotuslive.com/&#034; target=&#034;_new&#034;>https://www.lotuslive.com/</a></li>
<li>De click en la administración en la barra del navegador en la parte de arriba.</li>
<li>De click en "Administrar aplicaciones de la compañía"</li>
<li>De click en "Registrar aplicación"</li>
<li>Introduzca un nombre y una descripción para la aplicación cuando se le pida. El nombre y la descripción de su aplicación puede ser cambiado en cualquier momento dando click en el menú siguiente de la aplicación y seleccionar Editar propiedades</li>
<li>Durante el registro, a su aplicación le será asignada una llave OAuth y una cadena secreta. Las aplicaciones registradas son mostradas en la administración de aplicaciones personalizadas. Para ver la llave asignada y la cadena secreta, de click en el menú en la aplicación apropiada y seleccione obtener credenciales</li>
</ol>
</td></tr></tbody></table>' ,
   'oauth_consumer_key' => 'Llave de usuario OAuth' ,
   'oauth_consumer_secret' => 'Cadena secreta de OAuth' );

?>