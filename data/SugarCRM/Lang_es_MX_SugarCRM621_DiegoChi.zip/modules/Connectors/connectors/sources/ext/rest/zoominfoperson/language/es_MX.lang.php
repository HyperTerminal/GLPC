<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-professional-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2009 SugarCRM, Inc.; All Rights Reserved.
********************************************************************************/
/*********************************************************************************
 * Description:  Define el paquete de lenguaje Espa�ol para el conector ZoomInfo - Person.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$connector_strings = array (
    //licensing information shown in config screen
    'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><td valign="top" width="35%" class="dataLabel"><image src="' . getWebPath('modules/Connectors/connectors/sources/ext/rest/zoominfoperson/images/zoominfo.gif') . '" border="0"></td><td width="65%" valign="top" class="dataLabel">' .
                            'ZoomInfo&#169; fournit des informations completes sur plus de 45 millions de personnes et plsu de 5 millions de societes.  Plus &#039;informations.  <a target="_blank" href="http://www.zoominfo.com/about">http://www.zoominfo.com/about</a></td></tr></table>',    
    
    'LBL_SEARCH_FIELDS_INFO' => 'Los siguientes campos est�n soportados por la API de Zoominfo&#169; Person : Nombre, Apellido e e-Mail',    
    
    //vardef labels
	'LBL_ID' => 'ID',
	'LBL_EMAIL' => 'e-Mail',
	'LBL_FIRST_NAME' => 'Nombre',
	'LBL_LAST_NAME' => 'Apellido',
	'LBL_JOB_TITLE' => 'Cargo',
	'LBL_IMAGE_URL' => 'URL de imagen',
	'LBL_SUMMARY_URL' => 'URL de resumen',
	'LBL_COMPANY_NAME' => 'Compa��a',
	
	//Configuration labels
	'url' => 'URL',
	'api_key' => 'API Key',
	
	//Other labels
	'ERROR_LBL_CONNECTION_PROBLEM' => 'Error: No es posible conectarse al servidor de Zoominfo - Person',
);

?>