<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-professional-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2009 SugarCRM, Inc.; All Rights Reserved.
********************************************************************************/
/*********************************************************************************
 * Description:  Define el paquete de lenguaje Espa�ol para el conector ZoomInfo - Company.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$connector_strings = array (
    //licensing information shown in config screen
    'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><td valign="top" width="35%" class="dataLabel"><image src="' . getWebPath('modules/Connectors/connectors/sources/ext/rest/zoominfocompany/images/zoominfo.gif') . '" border="0"></td><td width="65%" valign="top" class="dataLabel">' .
                            'ZoomInfo&#169; proporciona informaci�n completa de m�s de 45 millones de personas y m�s de 5 millones de compa��as. M�s informaci�n en <a target="_blank" href="http://www.zoominfo.com/about">http://www.zoominfo.com/about</a></td></tr></table>',    
    
    'LBL_SEARCH_FIELDS_INFO' => 'Los siguientes campos est�n soportados por la API de Zoominfo&#169; Company: Compa��a, Ciudad , Estado, Pa�s',

    //vardef labels
	'LBL_COMPANY_ID' => 'ID',
	'LBL_COMPANY_NAME' => 'Compa��a',
    'LBL_STREET' => 'Calle',
	'LBL_CITY' => 'Ciudad',
	'LBL_ZIP' => 'C�digo Postal',
	'LBL_STATE' => 'Estado',
	'LBL_COUNTRY' => 'Pa�s',
	'LBL_INDUSTRY' => 'Actividad',
	'LBL_WEBSITE' => 'Sitio Web',
	'LBL_DESCRIPTION' => 'Descripci�n',
	
	//Configuration labels
	'company_search_url' => 'URL de b�squeda de la compa��a',
	'company_detail_url' => 'URL de detalle de la compa��a',
	'api_key' => 'Llave API',
	
	//Other labels
	'ERROR_LBL_CONNECTION_PROBLEM' => 'Error: No es posible conectarse al servidor de Zoominfo - Company',
);
?>