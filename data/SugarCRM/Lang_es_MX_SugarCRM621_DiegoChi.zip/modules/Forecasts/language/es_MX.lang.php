<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Previsiones.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Previsiones' ,
   'LNK_NEW_OPPORTUNITY' => 'Nueva oportunidad' ,
   'LBL_MODULE_TITLE' => 'Previsiones' ,
   'LBL_LIST_FORM_TITLE' => 'Previsiones realizadas' ,
   'LNK_UPD_FORECAST' => 'Hoja de previsiones' ,
   'LNK_QUOTA' => 'Cuotas' ,
   'LNK_FORECAST_LIST' => 'Historial de previsiones' ,
   'LBL_FORECAST_HISTORY' => 'Previsiones : Historial' ,
   'LBL_FORECAST_HISTORY_TITLE' => 'Historial' ,
   'LBL_TIMEPERIOD_NAME' => 'Periodo' ,
   'LBL_USER_NAME' => 'Nombre de usuario' ,
   'LBL_REPORTS_TO_USER_NAME' => 'Reportar a' ,
   'LBL_FORECAST_ID' => 'ID' ,
   'LBL_FORECAST_TIME_ID' => 'ID de periodo' ,
   'LBL_FORECAST_TYPE' => 'Tipo de previsión' ,
   'LBL_FORECAST_OPP_COUNT' => 'Oportunidades' ,
   'LBL_FORECAST_OPP_WEIGH' => 'Cantidad ponderada' ,
   'LBL_FORECAST_OPP_COMMIT' => 'Escenario probable' ,
   'LBL_FORECAST_OPP_BEST_CASE' => 'Mejor escenario' ,
   'LBL_FORECAST_OPP_WORST' => 'Peor escenario' ,
   'LBL_FORECAST_USER' => 'Usuario' ,
   'LBL_DATE_COMMITTED' => 'Fecha compromiso' ,
   'LBL_DATE_ENTERED' => 'Fecha de creación' ,
   'LBL_DATE_MODIFIED' => 'Fecha de modificación' ,
   'LBL_CREATED_BY' => 'Creado por' ,
   'LBL_DELETED' => 'Eliminado' ,
   'LBL_MODIFIED_USER_ID' => 'Modificado por' ,
   'LBL_QC_TIME_PERIOD' => 'Periodo:' ,
   'LBL_QC_OPPORTUNITY_COUNT' => 'Número de oportunidades:' ,
   'LBL_QC_WEIGHT_VALUE' => 'Cantidad ponderada:' ,
   'LBL_QC_COMMIT_VALUE' => 'Cantidad comprometida:' ,
   'LBL_QC_COMMIT_BUTTON' => 'Realizar' ,
   'LBL_QC_WORKSHEET_BUTTON' => 'Hoja de cálculo' ,
   'LBL_QC_ROLL_COMMIT_VALUE' => 'Cantidad realizada en dinámica:' ,
   'LBL_QC_DIRECT_FORECAST' => 'Mis previsiones directas:' ,
   'LBL_QC_ROLLUP_FORECAST' => 'Mis previsiones de grupo:' ,
   'LBL_QC_UPCOMING_FORECASTS' => 'Mis previsiones' ,
   'LBL_QC_LAST_DATE_COMMITTED' => 'Última fecha de compromiso:' ,
   'LBL_QC_LAST_COMMIT_VALUE' => 'Última cantidad comprometida:' ,
   'LBL_QC_HEADER_DELIM' => 'A' ,
   'LBL_OW_OPPORTUNITIES' => 'Oportunidad' ,
   'LBL_OW_ACCOUNTNAME' => 'Cuenta' ,
   'LBL_OW_REVENUE' => 'Cantidad' ,
   'LBL_OW_WEIGHTED' => 'Cantidad ponderada' ,
   'LBL_OW_MODULE_TITLE' => 'Hoja de oportunidad' ,
   'LBL_OW_PROBABILITY' => 'Probabilidad' ,
   'LBL_OW_NEXT_STEP' => 'Siguiente paso' ,
   'LBL_OW_DESCRIPTION' => 'Descripción' ,
   'LBL_OW_TYPE' => 'Tipo' ,
   'LNK_NEW_TIMEPERIOD' => 'Crear periodo' ,
   'LNK_TIMEPERIOD_LIST' => 'Periodos' ,
   'LBL_SVFS_FORECASTDATE' => 'Fecha de inicio de planeación' ,
   'LBL_SVFS_STATUS' => 'Estado' ,
   'LBL_SVFS_USER' => 'Para ' ,
   'LBL_SVFS_CASCADE' => '¿Propagar en cascada a reportes?' ,
   'LBL_SVFS_HEADER' => 'Planeación de previsiones:' ,
   'LB_FS_KEY' => 'ID' ,
   'LBL_FS_TIMEPERIOD_ID' => 'ID de periodo' ,
   'LBL_FS_USER_ID' => 'ID de usuario' ,
   'LBL_FS_TIMEPERIOD' => 'Periodo' ,
   'LBL_FS_START_DATE' => 'Fecha inicial' ,
   'LBL_FS_END_DATE' => 'Fecha final' ,
   'LBL_FS_FORECAST_START_DATE' => 'Fecha inicial de la previsión' ,
   'LBL_FS_STATUS' => 'Estado' ,
   'LBL_FS_FORECAST_FOR' => 'Planear para:' ,
   'LBL_FS_CASCADE' => '¿En cascada?' ,
   'LBL_FS_MODULE_NAME' => 'Planeación de previsiones' ,
   'LBL_FS_CREATED_BY' => 'Creado por' ,
   'LBL_FS_DATE_ENTERED' => 'Fecha de creación' ,
   'LBL_FS_DATE_MODIFIED' => 'Fecha de modificación' ,
   'LBL_FS_DELETED' => 'Eliminado' ,
   'LBL_FDR_USER_NAME' => 'Reportar a' ,
   'LBL_FDR_OPPORTUNITIES' => 'Oportunidades de la previsión:' ,
   'LBL_FDR_WEIGH' => 'Cantidad ponderada de oportunidades:' ,
   'LBL_FDR_COMMIT' => 'Cantidad realizada' ,
   'LBL_FDR_DATE_COMMIT' => 'Fecha de compromiso' ,
   'LBL_DV_HEADER' => 'Previsiones : Hoja de cálculo' ,
   'LBL_DV_MY_FORECASTS' => 'Mis previsiones' ,
   'LBL_DV_MY_TEAM' => 'Previsiones de mi equipo' ,
   'LBL_DV_TIMEPERIODS' => 'Periodos:' ,
   'LBL_DV_FORECAST_PERIOD' => 'Periodo de la prevision' ,
   'LBL_DV_FORECAST_OPPORTUNITY' => 'Oportunidades de la previsión' ,
   'LBL_SEARCH' => 'Seleccionar' ,
   'LBL_SEARCH_LABEL' => 'Seleccionar' ,
   'LBL_COMMIT_HEADER' => 'Realizar previsión' ,
   'LBL_DV_LAST_COMMIT_DATE' => 'Última fecha de compromiso:' ,
   'LBL_DV_LAST_COMMIT_AMOUNT' => 'Últimas cantidades comprometidas:' ,
   'LBL_DV_FORECAST_ROLLUP' => 'Previsión dinámica' ,
   'LBL_DV_TIMEPERIOD' => 'Periodo:' ,
   'LBL_DV_TIMPERIOD_DATES' => 'Rango de fechas:' ,
   'LBL_LV_TIMPERIOD' => 'Periodo' ,
   'LBL_LV_TIMPERIOD_START_DATE' => 'Fecha de inicio' ,
   'LBL_LV_TIMPERIOD_END_DATE' => 'Fecha final' ,
   'LBL_LV_TYPE' => 'Tipo de previsión' ,
   'LBL_LV_COMMIT_DATE' => 'Fecha de compromiso' ,
   'LBL_LV_OPPORTUNITIES' => 'Oportunidades' ,
   'LBL_LV_WEIGH' => 'Cantidad ponderada' ,
   'LBL_LV_COMMIT' => 'Cantidad comprometida' ,
   'LBL_COMMIT_NOTE' => 'Introduzca los montos que va a comprometer en el período seleccionado' ,
   'LBL_COMMIT_MESSAGE' => '¿Quiere introducir estas cantidades como compromiso?' ,
   'ERR_FORECAST_AMOUNT' => 'El monto comprometido es un valor requerido, y debe ser numérico' ,
   'LBL_FC_START_DATE' => 'Fecha inicial' ,
   'LBL_FC_USER' => 'Programar para' ,
   'LBL_NO_ACTIVE_TIMEPERIOD' => 'No hay ningún periodo activo para la previsión.' ,
   'LBL_FDR_ADJ_AMOUNT' => 'Cantidad ajustada' ,
   'LBL_SAVE_WOKSHEET' => 'Guardar hoja de cálculo' ,
   'LBL_RESET_WOKSHEET' => 'Reiniciar hoja de cálculo' ,
   'LBL_SHOW_CHART' => 'Ver gráfico' ,
   'LBL_RESET_CHECK' => 'Se eliminarán todos los datos de la hoja de cálculo para el período seleccionado y para el usuario que ha iniciado la sesión. ¿Desea continuar?' ,
   'LB_FS_LIKELY_CASE' => 'Escenario probable' ,
   'LB_FS_WORST_CASE' => 'Pero escenario' ,
   'LB_FS_BEST_CASE' => 'Mejor escenario' ,
   'LBL_FDR_WK_LIKELY_CASE' => 'Estimación del escenario probable' ,
   'LBL_FDR_WK_BEST_CASE' => 'Estimación del mejor escenario' ,
   'LBL_FDR_WK_WORST_CASE' => 'Estimación del peor escenario' ,
   'LBL_BEST_CASE' => 'Mejor escenario:' ,
   'LBL_LIKELY_CASE' => 'Escenario probable:' ,
   'LBL_WORST_CASE' => 'Peor escenario:' ,
   'LBL_FDR_C_BEST_CASE' => 'Mejor escenario' ,
   'LBL_FDR_C_WORST_CASE' => 'Peor escenario' ,
   'LBL_FDR_C_LIKELY_CASE' => 'Escenario probable' ,
   'LBL_QC_LAST_BEST_CASE' => 'Cantidad último compromiso (mejor escenario):' ,
   'LBL_QC_LAST_LIKELY_CASE' => 'Cantidad último compromiso (escenario probable):' ,
   'LBL_QC_LAST_WORST_CASE' => 'Cantidad último compromiso (peor escenario):' ,
   'LBL_QC_ROLL_BEST_VALUE' => 'Cantidad dinámica realizada (mejor escenario):' ,
   'LBL_QC_ROLL_LIKELY_VALUE' => 'Cantidad dinámica realizada (escenario probable):' ,
   'LBL_QC_ROLL_WORST_VALUE' => 'Cantidad dinámica realizada (peor escenario):' ,
   'LBL_QC_COMMIT_BEST_CASE' => 'Cantidad comprometida (mejor escenario):' ,
   'LBL_QC_COMMIT_LIKELY_CASE' => 'Cantidad comprometida (escenario probable):' ,
   'LBL_QC_COMMIT_WORST_CASE' => 'Cantidad comprometida (peor escenario):' ,
   'LBL_FORECAST_FOR' => 'Hoja de previsión para:' ,
   'LBL_FMT_ROLLUP_FORECAST' => '(Dinámica)' ,
   'LBL_FMT_DIRECT_FORECAST' => '(Directa)' ,
   'LBL_GRAPH_TITLE' => 'Historial de previsiones' ,
   'LBL_GRAPH_QUOTA_ALTTEXT' => 'Cuota para %s' ,
   'LBL_GRAPH_COMMIT_ALTTEXT' => 'Cantidad comprometida para %s' ,
   'LBL_GRAPH_OPPS_ALTTEXT' => 'El valor de las oportunidades cerradas en %s' ,
   'LBL_GRAPH_QUOTA_LEGEND' => 'Cuota' ,
   'LBL_GRAPH_COMMIT_LEGEND' => 'Previsión comprometida' ,
   'LBL_GRAPH_OPPS_LEGEND' => 'Oportunidades cerradas' ,
   'LBL_TP_QUOTA' => 'Cuota:' ,
   'LBL_CHART_FOOTER' => 'Historial de previsión<br/>Cantidad en cuota vs Prevista vs Valor de oportunidad cerrada' ,
   'LBL_TOTAL_VALUE' => 'Totales:' ,
   'LBL_COPY_AMOUNT' => 'Cantidad total' ,
   'LBL_COPY_WEIGH_AMOUNT' => 'Cantidades totales ponderadas' ,
   'LBL_WORKSHEET_AMOUNT' => 'Cantidades totales estimadas' ,
   'LBL_COPY' => 'Copiar valores' ,
   'LBL_COMMIT_AMOUNT' => 'Suma de valores comprometidos' ,
   'LBL_COPY_FROM' => 'Copiar valor de:' ,
   'LBL_CHART_TITLE' => 'Cuota / Realizado / Actual' );

?>
