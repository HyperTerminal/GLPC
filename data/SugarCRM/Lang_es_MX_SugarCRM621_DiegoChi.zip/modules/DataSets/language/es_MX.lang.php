<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Formato de datos.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Formato de datos' ,
   'LBL_MODULE_TITLE' => 'Formato de datos : Inicio' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de formato de datos' ,
   'LBL_LIST_FORM_TITLE' => 'Lista formato de datos' ,
   'LBL_LIST_NAME' => 'Nombre' ,
   'LBL_LIST_QUERY_NAME' => 'Consulta' ,
   'LBL_LIST_OUTPUT_DEFAULT' => 'Salida predeterminada' ,
   'LBL_LIST_LIST_ORDER_Y' => 'Comando Y' ,
   'LBL_LIST_LIST_ORDER_X' => 'Comando X' ,
   'LBL_LIST_VISIBLE' => '¿Visible?' ,
   'LBL_LIST_EXPORTABLE' => '¿Exportable?' ,
   'LBL_LIST_HEADER' => '¿Ver cabecera?' ,
   'LBL_NAME' => 'Consulta:' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_TYPE' => 'Tipo:' ,
   'LBL_PARENT_DATASET' => 'Formato de datos:' ,
   'LBL_QUERY_NAME' => 'Consulta:' ,
   'LBL_OUTPUT_DEFAULT' => 'Tipo de salida predeterminada:' ,
   'LBL_LIST_ORDER_Y' => 'Orden eje-Y:' ,
   'LBL_LIST_ORDER_X' => 'Orden eje-X:' ,
   'LBL_HEADER' => 'Ver cabecera' ,
   'LBL_EXPORTABLE' => 'Exportable (sólo archivo CSV):' ,
   'LBL_VISIBLE' => 'Formato de datos visible:' ,
   'LBL_TABLE_WIDTH' => 'Ancho de la tabla %:' ,
   'LBL_FONT_SIZE' => 'Tamaño de la fuente:' ,
   'LBL_REPORT_NAME' => 'Reporte:' ,
   'LBL_PRESPACE_X' => 'Pre-espaciado X:' ,
   'LBL_PRESPACE_Y' => 'Pre-espaciado Y:' ,
   'LBL_TABLE_WIDTH_TYPE' => 'Tipo de ancho de la tabla:' ,
   'LBL_BODY_TEXT_COLOR' => 'Color del texto:' ,
   'LBL_HEADER_TEXT_COLOR' => 'Color de texto de la cabecera:' ,
   'LBL_HEADER_BACK_COLOR' => 'Color de fondo de la cabecera' ,
   'LBL_BODY_BACK_COLOR' => 'Color de fondo:' ,
   'LBL_USE_PREV_HEADER' => 'Agrupar con la cabecera anterior:' ,
   'LBL_CHILD_NAME' => 'Subconsulta:' ,
   'LBL_CUSTOM_LAYOUT' => 'Diseño personalizado:' ,
   'LNK_LIST_REPORTMAKER' => 'Lista de reportes' ,
   'LNK_NEW_REPORTMAKER' => 'Crear reporte' ,
   'LNK_LIST_DATASET' => 'Lista de formato de datos' ,
   'LNK_NEW_DATASET' => 'Crear un format de datos' ,
   'LNK_NEW_CUSTOMQUERY' => 'Crear consulta personalizada' ,
   'LNK_CUSTOMQUERIES' => 'Consultas personalizadas' ,
   'LNK_NEW_QUERYBUILDER' => 'Crear consulta' ,
   'LNK_QUERYBUILDER' => 'Consultas' ,
   'LBL_ALL_REPORTS' => 'Todos los reportes' ,
   'NTC_DELETE_CONFIRMATION' => '¿Esta seguro que desea eliminar este registro?' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminarlo' ,
   'LBL_LAYOUT_TYPE' => 'Tipo de diseño:' ,
   'LBL_LAYOUT_PARENT_VALUE' => 'Valor predeterminado:' ,
   'LBL_LAYOUT_DISPLAY_TYPE' => 'Tipo de pantalla:' ,
   'LBL_LAYOUT_LIST_ORDER_X' => 'Lista de orden X:' ,
   'LBL_LAYOUT_LIST_ORDER_Z' => 'Lista de orden Z:' ,
   'LBL_MODIFY_HEAD' => 'Modificar los atributos de la cabecera:' ,
   'LBL_MODIFY_BODY' => 'Modificar los atributos del texto:' ,
   'LBL_BG_COLOR' => 'Color de fondo:' ,
   'LBL_WRAP' => 'Ajustar texto:' ,
   'LBL_DISPLAY_TYPE' => 'Tipo de pantalla:' ,
   'LBL_STYLE' => 'Estilo:' ,
   'LBL_DISPLAY_NAME' => 'Nombre:' ,
   'LBL_FORMAT_TYPE' => 'Tipo de formato:' ,
   'LBL_FORMAT' => 'Formato:' ,
   'LBL_CELL_SIZE' => 'Tamaño de celda:' ,
   'LBL_HIDE_COLUMN' => 'Ocultar columna:' ,
   'LBL_FINISHED_BUTTON' => 'Terminar' ,
   'CONFIRM_LAYOUT_DISABLE' => 'Deshabilitando el diseño personalizado eliminará todas las propiedades existentes en el diseño' ,
   'LBL_LEFT' => 'Izquierda' ,
   'LBL_RIGHT' => 'Derecha' );

?>