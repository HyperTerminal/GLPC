<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Productos.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Productos' ,
   'LBL_MODULE_TITLE' => 'Productos: Inicio' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de productos' ,
   'LBL_LIST_FORM_TITLE' => 'Listar productos' ,
   'LBL_NEW_FORM_TITLE' => 'Crear producto' ,
   'LBL_PRODUCT' => 'Producto:' ,
   'LBL_RELATED_PRODUCTS' => 'Productos relacionados' ,
   'LBL_LIST_NAME' => 'Producto' ,
   'LBL_LIST_MANUFACTURER' => 'Proveedor' ,
   'LBL_LIST_LBL_MFT_PART_NUM' => 'Nº Pieza' ,
   'LBL_LIST_QUANTITY' => 'Cantidad' ,
   'LBL_LIST_COST_PRICE' => 'Coste' ,
   'LBL_LIST_DISCOUNT_PRICE' => 'Precio' ,
   'LBL_LIST_LIST_PRICE' => 'Precio de lista' ,
   'LBL_LIST_STATUS' => 'Estado' ,
   'LBL_LIST_ACCOUNT_NAME' => 'Nombre de cuenta' ,
   'LBL_LIST_CONTACT_NAME' => 'Nombre de contacto' ,
   'LBL_LIST_QUOTE_NAME' => 'Nombre de presupuesto' ,
   'LBL_LIST_DATE_PURCHASED' => 'Comprado' ,
   'LBL_LIST_SUPPORT_EXPIRES' => 'Fecha de expiración' ,
   'LBL_NAME' => 'Producto:' ,
   'LBL_URL' => 'URL producto:' ,
   'LBL_QUOTE_NAME' => 'Nombre de presupuesto:' ,
   'LBL_CONTACT_NAME' => 'Nombre de contacto:' ,
   'LBL_DATE_PURCHASED' => 'Comprado:' ,
   'LBL_DATE_SUPPORT_EXPIRES' => 'Cantidad del soporte:' ,
   'LBL_DATE_SUPPORT_STARTS' => 'Inicio del soporte:' ,
   'LBL_COST_PRICE' => 'Coste:' ,
   'LBL_DISCOUNT_PRICE' => 'Precio unitario:' ,
   'LBL_DEAL_TOT' => 'Descuento:' ,
   'LBL_DISCOUNT_RATE' => 'Tarifa de descuento' ,
   'LBL_DISCOUNT_RATE_USDOLLAR' => 'Tarifa de descuento (Dólares EUA)' ,
   'LBL_DISCOUNT_TOTAL' => 'Descuento total' ,
   'LBL_DISCOUNT_TOTAL_USDOLLAR' => 'Descuento (dólares EUA)' ,
   'LBL_SELECT_DISCOUNT' => '% de descuento' ,
   'LBL_LIST_PRICE' => 'Precio de lista:' ,
   'LBL_VENDOR_PART_NUM' => 'Número de parte del vendedor:' ,
   'LBL_MFT_PART_NUM' => 'Número de parte del fabricante:' ,
   'LBL_DISCOUNT_PRICE_DATE' => 'Fecha de precio con descuento:' ,
   'LBL_WEIGHT' => 'Peso:' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_TYPE' => 'Tipo:' ,
   'LBL_CATEGORY' => 'Categoría:' ,
   'LBL_QUANTITY' => 'Cantidad:' ,
   'LBL_STATUS' => 'Estado:' ,
   'LBL_TAX_CLASS' => 'Tipo de impuesto:' ,
   'LBL_MANUFACTURER' => 'Fabricante:' ,
   'LBL_SUPPORT_DESCRIPTION' => 'Descripción del soporte:' ,
   'LBL_SUPPORT_TERM' => 'Término del soporte:' ,
   'LBL_SUPPORT_NAME' => 'Título del soporte:' ,
   'LBL_SUPPORT_CONTACT' => 'Contacto del soporte:' ,
   'LBL_PRICING_FORMULA' => 'Fórmula de valoración:' ,
   'LBL_ACCOUNT_NAME' => 'Nombre de cuenta:' ,
   'LNK_PRODUCT_LIST' => 'Productos' ,
   'LNK_NEW_PRODUCT' => 'Crear producto' ,
   'NTC_DELETE_CONFIRMATION' => '¿Está seguro de eliminar este registro?' ,
   'NTC_REMOVE_CONFIRMATION' => '¿Está seguro de quitar esta relación entre productos?' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar el producto' ,
   'LBL_CURRENCY' => 'Divisa:' ,
   'LBL_ASSET_NUMBER' => 'Número de activo:' ,
   'LBL_SERIAL_NUMBER' => 'Número de serie:' ,
   'LBL_BOOK_VALUE' => 'Valor contable:' ,
   'LBL_BOOK_VALUE_USDOLLAR' => 'Valor contable (dólar de EUA):' ,
   'LBL_BOOK_VALUE_DATE' => 'Fecha del valor contable:' ,
   'LBL_DEFAULT_SUBPANEL_TITLE' => 'Productos' ,
   'LBL_RELATED_PRODUCTS_TITLE' => 'Productos relacionados' ,
   'LBL_WEBSITE' => 'Sitio Web' ,
   'LBL_COST_USDOLLAR' => 'Costo (dólares EUA)' ,
   'LBL_DISCOUNT_USDOLLAR' => 'Precio unitario (dólares EUA)' ,
   'LBL_LIST_USDOLLAR' => 'Precio de lista (dólares EUA)' ,
   'LBL_PRICING_FACTOR' => 'Factor de valoración' ,
   'LBL_ACCOUNT_ID' => 'ID de cuenta' ,
   'LBL_CONTACT_ID' => 'ID de contacto' ,
   'LBL_CATEGORY_NAME' => 'Nombre de categoría:' ,
   'LBL_NOTES_SUBPANEL_TITLE' => 'Notas' ,
   'LBL_MEMBER_OF' => 'Asociada a:' ,
   'LBL_PROJECTS_SUBPANEL_TITLE' => 'Proyectos' ,
   'LBL_DOCUMENTS_SUBPANEL_TITLE' => 'Documentos' ,
   'LBL_CONTRACTS_SUBPANEL_TITLE' => 'Contratos' ,
   'LBL_CONTRACTS' => 'Contratos' ,
   'LBL_PRODUCT_CATEGORIES' => 'Categorías de productos' ,
   'LBL_PRODUCT_TYPES' => 'Tipos de productos' ,
   'LBL_ASSIGNED_TO_NAME' => 'Asignado a:' ,
   'LBL_PRODUCT_TEMPLATE_ID' => 'ID de plantilla de producto:' ,
   'LBL_QUOTE_ID' => 'ID de cotización' ,
   'LBL_CREATED_USER' => 'Usuario creado' ,
   'LBL_MODIFIED_USER' => 'Usuario modificado' ,
   'LBL_QUOTE' => 'Cotizaciones' ,
   'LBL_CONTACT' => 'Contacto' ,
   'LBL_DISCOUNT_AMOUNT' => 'Cantidad descontada' ,
   'LBL_CURRENCY_SYMBOL_NAME' => 'Símbolo de divisa' ,
   'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Productos' ,
   'LNK_IMPORT_PRODUCTS' => 'Importar productos' );

?>