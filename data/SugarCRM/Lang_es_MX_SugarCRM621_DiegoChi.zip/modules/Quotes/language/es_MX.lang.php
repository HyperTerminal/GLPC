<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Cotizaciones.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'db_sales_stage' => 'LBL_LIST_SALES_STAGE' ,
   'db_name' => 'LBL_NAME' ,
   'db_amount' => 'LBL_LIST_AMOUNT' ,
   'db_date_closed' => 'LBL_LIST_DATE_CLOSED' ,
   'LBL_CONTRACTS' => 'Contratos' ,
   'LBL_CONTRACTS_SUBPANEL_TITLE' => 'Contratos' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminarlo' ,
   'LBL_ACCOUNT_ID' => 'ID de la cuenta' ,
   'LBL_ACCOUNT_NAME' => 'Nombre de la cuenta:' ,
   'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades' ,
   'LBL_ADD_COMMENT' => 'Agregar comentario' ,
   'LBL_ADD_GROUP' => 'Agregar grupo' ,
   'LBL_ADD_ROW' => 'Agregar fila' ,
   'LBL_ADDRESS_INFORMATION' => 'Información sobre dirección' ,
   'LBL_AMOUNT' => 'Cantidad:' ,
   'LBL_AMOUNT_USDOLLAR' => 'Cantidad (dólares EUA):' ,
   'LBL_ANY_ADDRESS' => 'Alguna dirección:' ,
   'LBL_BILL_TO' => 'Cargar a' ,
   'LBL_BILLING_ACCOUNT_NAME' => 'Nombre de cuenta de facturación' ,
   'LBL_BILLING_ACCOUNT' => 'Cuenta:' ,
   'LBL_BILLING_ADDRESS_CITY' => 'Ciudad de facturación' ,
   'LBL_BILLING_ADDRESS_COUNTRY' => 'País de facturación' ,
   'LBL_BILLING_ADDRESS_POSTAL_CODE' => 'Código postal de facturación' ,
   'LBL_BILLING_ADDRESS_STATE' => 'Estado/Provincia de facturación' ,
   'LBL_BILLING_ADDRESS_STREET' => 'Dirección de facturación' ,
   'LBL_BILLING_ADDRESS' => 'Dirección de facturación:' ,
   'LBL_BILLING_CONTACT_ID' => 'ID de contacto de facturación:' ,
   'LBL_BILLING_CONTACT_NAME' => 'Nombre de contacto de facturación:' ,
   'LBL_BILLING_CONTACT' => 'Contacto:' ,
   'LBL_BUNDLE_NAME' => 'Nombre de grupo:' ,
   'LBL_BUNDLE_STAGE' => 'Etapa de grupo:' ,
   'LBL_BUNDLE_DISCOUNT' => 'Descuento:' ,
   'LBL_CALC_GRAND' => 'Mostrar totales:' ,
   'LBL_CHECK_DATA' => 'Entrada de datos inválida: por favor, compruebe sus datos y asegúrese de que ha usado números válidos (0-9 or \'.\')' ,
   'LBL_CITY' => 'Ciudad:' ,
   'LBL_CONTACT_NAME' => 'Nombre del contacto:' ,
   'LBL_CONTACT_QUOTE_FORM_TITLE' => 'Contacto-Presupuesto:' ,
   'LBL_CONTACT_ROLE' => 'Rol del contacto:' ,
   'LBL_COUNTRY' => 'País:' ,
   'LBL_CREATED_BY' => 'Creado por' ,
   'LBL_CURRENCY' => 'Divisa:' ,
   'LBL_DATE_QUOTE_CLOSED' => 'Fecha de cierre real:' ,
   'LBL_DATE_QUOTE_EXPECTED_CLOSED' => 'Válido hasta:' ,
   'LBL_DEFAULT_SUBPANEL_TITLE' => 'Presupuesto' ,
   'LBL_DELETE_GROUP' => 'Eliminar grupo' ,
   'LBL_DESCRIPTION_INFORMATION' => 'Información de descripción' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_DUPLICATE' => 'Presupuesto posiblemente duplicado' ,
   'LBL_EMAIL_QUOTE_FOR' => 'Presupuesto para:' ,
   'LBL_EMAIL_DEFAULT_DESCRIPTION' => 'Aquí está el presupuesto solicitado (puede cambiar el texto)' ,
   'LBL_EMAIL_ATTACHMENT' => 'Adjunto de e-Mail:' ,
   'LBL_HISOTRY_SUBPANEL_TITLE' => 'Historial' ,
   'LBL_INVITEE' => 'Contactos' ,
   'LBL_INVOICE' => 'Factura' ,
   'LBL_LEAD_SOURCE' => 'Toma de contacto:' ,
   'LBL_LINE_ITEM_INFORMATION' => 'Línea de detalle' ,
   'LBL_LIST_ACCOUNT_NAME' => 'Nombre de cuenta' ,
   'LBL_LIST_AMOUNT' => 'Cantidad' ,
   'LBL_LIST_AMOUNT_USDOLLAR' => 'Cantidad (dólares EUA)' ,
   'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario asignado' ,
   'LBL_LIST_COST_PRICE' => 'Coste' ,
   'LBL_LIST_DATE_QUOTE_CLOSED' => 'Cierre real' ,
   'LBL_LIST_DATE_QUOTE_EXPECTED_CLOSED' => 'Válido hasta' ,
   'LBL_LIST_DISCOUNT_PRICE' => 'Precio unitario' ,
   'LBL_LIST_DEAL_TOT' => 'Descuento' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de presupuestos' ,
   'LBL_LIST_GRAND_TOTAL' => 'Totales' ,
   'LBL_LIST_LIST_PRICE' => 'Lista' ,
   'LBL_LIST_MANUFACTURER_PART_NUM' => 'Número de parte' ,
   'LBL_LIST_PRICING_FACTOR' => 'Factor' ,
   'LBL_LIST_PRICING_FORMULA' => 'Fórmula de valoración' ,
   'LBL_LIST_PRODUCT_NAME' => 'Producto' ,
   'LBL_LIST_QUANTITY' => 'Cantidad' ,
   'LBL_LIST_QUOTE_NAME' => 'Asunto' ,
   'LBL_LIST_QUOTE_NUM' => 'Número' ,
   'LBL_LIST_QUOTE_STAGE' => 'Etapa' ,
   'LBL_LIST_TAXCLASS' => 'Tipos de impuesto' ,
   'LBL_MODIFIED_BY' => 'Modificado por' ,
   'LBL_MODULE_NAME' => 'Cotizaciones' ,
   'LBL_MODULE_TITLE' => 'Cotizaciones : Inicio' ,
   'LBL_NAME' => 'Nombre de la cotización' ,
   'LBL_NEW_FORM_TITLE' => 'Crear cotización' ,
   'LBL_NEXT_STEP' => 'Siguiente paso:' ,
   'LBL_OPPORTUNITY_NAME' => 'Nombre de oportunidad:' ,
   'LBL_ORDER_STAGE' => 'Etapa del pedido' ,
   'LBL_ORIGINAL_PO_DATE' => 'Fecha original del pedido:' ,
   'LBL_PAYMENT_TERMS' => 'Forma de pago:' ,
   'LBL_PDF_BILLING_ADDRESS' => 'Cobrar a' ,
   'LBL_PDF_CURRENCY' => 'Divisa:' ,
   'LBL_PDF_GRAND_TOTAL' => 'Totales' ,
   'LBL_PDF_INVOICE_NUMBER' => 'Número de factura' ,
   'LBL_PDF_INVOICE_TITLE' => 'Factura' ,
   'LBL_PDF_ITEM_EXT_PRICE' => 'Precio externo' ,
   'LBL_PDF_ITEM_DISCOUNT' => 'Descuento' ,
   'LBL_PDF_ITEM_LIST_PRICE' => 'Precio de lista' ,
   'LBL_PDF_ITEM_PRODUCT' => 'Producto' ,
   'LBL_PDF_ITEM_QUANTITY' => 'Cantidad' ,
   'LBL_PDF_ITEM_UNIT_PRICE' => 'Precio unitario' ,
   'LBL_PDF_PART_NUMBER' => 'Número de parte:' ,
   'LBL_PDF_QUOTE_CLOSE' => 'Válido hasta:' ,
   'LBL_PDF_QUOTE_DATE' => 'Fecha:' ,
   'LBL_PDF_QUOTE_NUMBER' => 'Número de cotización:' ,
   'LBL_PDF_QUOTE_TITLE' => 'Cotización' ,
   'LBL_PDF_SALES_PERSON' => 'Comercial:' ,
   'LBL_PDF_SHIPPING_ADDRESS' => 'Enviar a' ,
   'LBL_PDF_SHIPPING_COMPANY' => 'Proveedor de transporte:' ,
   'LBL_PDF_SHIPPING' => 'Envío:' ,
   'LBL_PDF_SUBTOTAL' => 'Subtotal:' ,
   'LBL_PDF_DISCOUNT' => 'Descuento:' ,
   'LBL_PDF_NEW_SUB' => 'Subtotal descontado:' ,
   'LBL_PDF_TAX_RATE' => 'Tipo de impuestos:' ,
   'LBL_PDF_TAX' => 'Impuestos:' ,
   'LBL_PDF_TOTAL' => 'Total:' ,
   'LBL_POSTAL_CODE' => 'Código postal:' ,
   'LBL_PROJECTS_SUBPANEL_TITLE' => 'Proyectos' ,
   'LBL_PROPOSAL' => 'Cotización' ,
   'LBL_PURCHASE_ORDER_NUM' => 'Número de pedido de compra:' ,
   'LBL_QUOTE_NAME' => 'Asunto de la cotización:' ,
   'LBL_QUOTE_NUM' => 'Número de cotización:' ,
   'LBL_QUOTE_STAGE' => 'Etapa de la cotización:' ,
   'LBL_QUOTE_TYPE' => 'Tipo de cotización' ,
   'LBL_TAXABLE' => 'Sujeto a impuestos' ,
   'LBL_NON_TAXABLE' => 'Libre de impuestos' ,
   'LBL_QUOTE' => 'Cotización:' ,
   'LBL_QUOTE_LAYOUT_DOES_NOT_EXIST_ERROR' => 'el archivo de diseño de la cotización no existe: $layout' ,
   'LBL_QUOTE_LAYOUT_REGISTERED_ERROR' => 'el diseño de la cotización no ha sido registrado en modules/Quotes/Layouts.php' ,
   'LBL_REMOVE_COMMENT' => 'Quitar comentario' ,
   'LBL_REMOVE_ROW' => 'Quitar fila' ,
   'LBL_RENAME_ERROR' => 'ERROR: no puede moverse el archivo PDF a $destination. Intente dar permisos de escritura al servidor web para ese directorio' ,
   'LBL_SALES_STAGE' => 'Etapa de la cotización:' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de cotizaciones' ,
   'LBL_SHIP_TO' => 'Enviar a' ,
   'LBL_SHIPPING_ACCOUNT_NAME' => 'Nombre de la cuenta de envío:' ,
   'LBL_SHIPPING_ACCOUNT' => 'Cuenta:' ,
   'LBL_SHIPPING_ADDRESS_CITY' => 'Ciudad de envío' ,
   'LBL_SHIPPING_ADDRESS_COUNTRY' => 'País de envío' ,
   'LBL_SHIPPING_ADDRESS_POSTAL_CODE' => 'Código postal de envío' ,
   'LBL_SHIPPING_ADDRESS_STATE' => 'Estado/Provincia de envío' ,
   'LBL_SHIPPING_ADDRESS_STREET' => 'Dirección de envío' ,
   'LBL_SHIPPING_ADDRESS' => 'Dirección de envío:' ,
   'LBL_SHIPPING_CONTACT_ID' => 'ID de contacto de envío:' ,
   'LBL_SHIPPING_CONTACT_NAME' => 'Nombre de contacto de envío:' ,
   'LBL_SHIPPING_CONTACT' => 'Contacto:' ,
   'LBL_SHIPPING_PROVIDER' => 'Proveedor de transporte:' ,
   'LBL_SHIPPING_USDOLLAR' => 'Envío (dólares EUA)' ,
   'LBL_DEAL_TOT' => 'descuento total' ,
   'LBL_DEAL_TOT_USDOLLAR' => 'descuento total (dólares EUA)' ,
   'LBL_SHIPPING' => 'Envío:' ,
   'LBL_DISCOUNT_TOTAL' => 'Descuento:' ,
   'LBL_NEW_SUB' => 'Subtotal descontado:' ,
   'LBL_SHOW_LINE_NUMS' => 'Mostrar números&nbsp;de&nbsp;línea:' ,
   'LBL_STATE' => 'Estado/Provincia:' ,
   'LBL_SUBTOTAL_USDOLLAR' => 'Subtotal (dólares EUA)' ,
   'LBL_SUBTOTAL' => 'Subtotal:' ,
   'LBL_SYSTEM_ID' => 'ID de sistema' ,
   'LBL_TAX_USDOLLAR' => 'Impuestos (dólares EUA)' ,
   'LBL_TAX' => 'Impuestos:' ,
   'LBL_TAXRATE' => 'Tipo de impuesto:' ,
   'LBL_TOTAL_USDOLLAR' => 'Total (dólares EUA)' ,
   'LBL_TOTAL' => 'Total:' ,
   'LBL_TYPE' => 'Tipo:' ,
   'LNK_NEW_QUOTE' => 'Crear cotización' ,
   'LNK_QUOTE_LIST' => 'Cotizaciones' ,
   'MSG_DUPLICATE' => 'Está creando una cotización duplicada. Puede seleccionar una cotización de la siguiente lista o hacer click en guardar para duplicar la cotización' ,
   'NTC_COPY_BILLING_ADDRESS' => 'Copiar dirección de facturación a dirección de envío' ,
   'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar dirección de envío a dirección de facturación' ,
   'NTC_COPY_BILLING_ADDRESS2' => 'Copiar a dirección de envío' ,
   'NTC_COPY_SHIPPING_ADDRESS2' => 'Copiar a dirección de facturación' ,
   'NTC_REMOVE_COMMENT_CONFIRMATION' => '¿Está seguro que desea quitar este comentario de la cotización?' ,
   'NTC_REMOVE_PRODUCT_CONFIRMATION' => '¿Está seguro que desea quitar esta línea de detalle de la cotización?' ,
   'NTC_REMOVE_GROUP_CONFIRMATION' => '¿Está seguro que desea quitar este grupo de la cotización?' ,
   'NTC_REMOVE_QUOTE_CONFIRMATION' => '¿Está seguro que desea quitar este contacto de la cotización?' ,
   'QUOTE_REMOVE_PROJECT_CONFIRM' => '¿Está seguro que desea quitar esta cotización del proyecto?' ,
   'LNK_QUOTE_REPORTS' => 'Reportes de cotizaciones' ,
   'LBL_ASSIGNED_TO_NAME' => 'Asignado a:' ,
   'PDF_FORMAT' => 'Formato PDF:' ,
   'LBL_ASSIGNED_TO_ID' => 'Asignado a ID:' ,
   'LBL_PROJECT_SUBPANEL_TITLE' => 'Proyectos' ,
   'LBL_DOCUMENTS_SUBPANEL_TITLE' => 'Documentos' ,
   'LBL_QUOTE_INFORMATION' => 'Información de la cotización' ,
   'LBL_LIST_MY_QUOTES' => 'Mis cotizaciones' ,
   'NTC_OVERWRITE_ADDRESS_PHONE_CONFIRM' => 'Este registro contiene valores en el campo de dirección. Para sobreescribir estos valores con la siguiente dirección de la cuenta que ha seleccionado, de click en "Aceptar". Para mantener los valores actuales​​, de click en "Cancelar"' );

?>