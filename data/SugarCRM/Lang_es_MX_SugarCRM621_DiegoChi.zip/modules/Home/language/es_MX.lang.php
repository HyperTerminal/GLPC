<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Inicio.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Inicio' ,
   'LBL_MODULES_TO_SEARCH' => 'Módulos en los que buscar' ,
   'LBL_NEW_FORM_TITLE' => 'Nuevo contacto' ,
   'LBL_FIRST_NAME' => 'Nombre:' ,
   'LBL_LAST_NAME' => 'Apellidos:' ,
   'LBL_LIST_LAST_NAME' => 'Apellidos' ,
   'LBL_PHONE' => 'Teléfono:' ,
   'LBL_EMAIL_ADDRESS' => 'e-Mail:' ,
   'LBL_MY_PIPELINE_FORM_TITLE' => 'Mi pipeline' ,
   'LBL_PIPELINE_FORM_TITLE' => 'Pipeline por etapa de ventas' ,
   'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'Campaña ROI' ,
   'LBL_MY_CLOSED_OPPORTUNITIES_GAUGE' => 'Mi indicador de oportunidades ganadas' ,
   'LNK_NEW_CONTACT' => 'Nuevo contacto' ,
   'LNK_NEW_ACCOUNT' => 'Nueva cuenta' ,
   'LNK_NEW_OPPORTUNITY' => 'Nuevo contacto' ,
   'LNK_NEW_QUOTE' => 'Nueva cotización' ,
   'LNK_NEW_LEAD' => 'Nuevo cliente potencial' ,
   'LNK_NEW_CASE' => 'Nuevo caso' ,
   'LNK_NEW_NOTE' => 'Nueva nota o archivo adjunto' ,
   'LNK_NEW_CALL' => 'Programar llamada' ,
   'LNK_NEW_EMAIL' => 'Archivar e-Mail' ,
   'LNK_COMPOSE_EMAIL' => 'Redactar e-Mail' ,
   'LNK_NEW_MEETING' => 'Programar reunión' ,
   'LNK_NEW_TASK' => 'Nueva tarea' ,
   'LNK_NEW_BUG' => 'Informar de incidencia' ,
   'LBL_ADD_BUSINESSCARD' => 'Nueva tarjeta de visita' ,
   'ERR_ONE_CHAR' => 'Por favor, indique al menos un número o letra para su búsqueda...' ,
   'LBL_OPEN_TASKS' => 'Mis tareas pendientes' ,
   'LBL_SEARCH_RESULTS' => 'Resultado de la búsqueda' ,
   'LBL_SEARCH_RESULTS_IN' => 'en' ,
   'LNK_NEW_SEND_EMAIL' => 'Redactar e-Mail' ,
   'LBL_NO_ACCESS' => 'Usted no tiene acceso a esta área.  Contacte al administrador del sitio para tener acceso' ,
   'LBL_NO_RESULTS_IN_MODULE' => '-- Sin Resultados --' ,
   'LBL_NO_RESULTS' => '<h2>No se han encontrado resultados. Por favor, realice una nueva búsqueda</h2><br>' ,
   'LBL_NO_RESULTS_TIPS' => '<h3>Trucos para la búsqueda:</h3><ul><li>Asegúrese que ha seleccionado las categorías adecuadas más arriba.</li><li>Amplíe sus criterios de búsqueda.</li><li>Si aun así no obtiene resultados, pruebe con la opción de búsqueda avanzada</li></ul>' ,
   'LBL_RELOAD_PAGE' => 'Por favor, <a href="javascript: window.location.reload()">recargue la ventana</a> para usar este Sugar Dashlet' ,
   'LBL_ADD_DASHLETS' => 'Agregar Sugar Dashlets' ,
   'LBL_ADD_PAGE' => 'Agregar página' ,
   'LBL_DEL_PAGE' => 'Eliminar página' ,
   'LBL_WEBSITE_TITLE' => 'Sitio Web' ,
   'LBL_RSS_TITLE' => 'Lector de noticias' ,
   'LBL_DELETE_PAGE' => 'Eliminar página' ,
   'LBL_CHANGE_LAYOUT' => 'Cambiar diseño' ,
   'LBL_RENAME_PAGE' => 'Renombrar página' ,
   'LBL_CLOSE_DASHLETS' => 'Cerrar' ,
   'LBL_CLOSE_SITEMAP' => 'Cerrar' ,
   'LBL_OPTIONS' => 'Opciones' ,
   'LBL_TODAY' => 'Hoy' ,
   'LBL_YESTERDAY' => 'Ayer' ,
   'LBL_TOMORROW' => 'Mañana' ,
   'LBL_LAST_WEEK' => 'La semana pasada' ,
   'LBL_NEXT_WEEK' => 'La próxima semana' ,
   'LBL_LAST_7_DAYS' => 'Últimos 7 días' ,
   'LBL_NEXT_7_DAYS' => 'Siguientes 7 días' ,
   'LBL_LAST_MONTH' => 'Último mes' ,
   'LBL_NEXT_MONTH' => 'Siguiente mes' ,
   'LBL_LAST_QUARTER' => 'Último trimestre' ,
   'LBL_THIS_QUARTER' => 'Este trimestre' ,
   'LBL_LAST_YEAR' => 'Último año' ,
   'LBL_NEXT_YEAR' => 'Próximo año' ,
   'LBL_LAST_30_DAYS' => 'Últimos 30 días' ,
   'LBL_NEXT_30_DAYS' => 'Próximos 30 días' ,
   'LBL_THIS_MONTH' => 'Este mes' ,
   'LBL_THIS_YEAR' => 'Este año' ,
   'LBL_MODULES' => 'Módulos' ,
   'LBL_CHARTS' => 'Gráficos' ,
   'LBL_TOOLS' => 'Herramientas' ,
   'LBL_WEB' => 'Sitio Web' ,
   'LBL_MAX_DASHLETS_REACHED' => 'Ha alcanzado el número máximo de Sugar Dashlets que su administrador ha establecido. Por favor, quite un dashlet poder agregar más' ,
   'LBL_ADDING_DASHLET' => 'Agregar Sugar Dashlet ...' ,
   'LBL_ADDED_DASHLET' => 'Sugar Dashlet agregado' ,
   'LBL_REMOVE_DASHLET_CONFIRM' => '¿Está seguro que desea quitar el Sugar Dashlet?' ,
   'LBL_REMOVING_DASHLET' => 'Quitando Sugar Dashlet ...' ,
   'LBL_REMOVED_DASHLET' => 'Sugar Dashlet quitado' ,
   'LBL_DASHLET_CONFIGURE_GENERAL' => 'General' ,
   'LBL_DASHLET_CONFIGURE_FILTERS' => 'Filtros' ,
   'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Sólo mis elementos' ,
   'LBL_DASHLET_CONFIGURE_TITLE' => 'Título' ,
   'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Mostrar filas' ,
   'LBL_DASHLET_DELETE' => 'Eliminar Sugar Dashlet' ,
   'LBL_DASHLET_REFRESH' => 'Actualizar Sugar Dashlet' ,
   'LBL_DASHLET_EDIT' => 'Editar Sugar Dashlet' ,
   'LBL_TRAINING_TITLE' => 'Formación' ,
   'LBL_CREATING_NEW_PAGE' => 'Creando nueva página...' ,
   'LBL_NEW_PAGE_FEEDBACK' => 'Ha creado una nueva página. Puede agregar nuevo contenido con la opción de agregar Sugar Dashlets' ,
   'LBL_DELETE_PAGE_CONFIRM' => '¿Está seguro que desea eliminar esta página?' ,
   'LBL_SAVING_PAGE_TITLE' => 'Guardando título de página...' ,
   'LBL_RETRIEVING_PAGE' => 'Recuperando página...' ,
   'LBL_HOME_PAGE_1_NAME' => 'Mi Sugar' ,
   'LBL_HOME_PAGE_2_NAME' => 'Página de ventas' ,
   'LBL_HOME_PAGE_3_NAME' => 'Página de soporte' ,
   'LBL_HOME_PAGE_6_NAME' => 'Página de marketing' ,
   'LBL_HOME_PAGE_4_NAME' => 'Seguimiento' ,
   'LBL_SEARCH' => 'Buscar' ,
   'LBL_CLEAR' => 'Limpiar' ,
   'LBL_BASIC_CHARTS' => 'Gráficos básicos' ,
   'LBL_REPORT_CHARTS' => 'Gráficos de informes' ,
   'LBL_MY_FAVORITE_REPORT_CHARTS' => 'Mis reportes favoritos' ,
   'LBL_GLOBAL_REPORT_CHARTS' => 'Reportes del equipo global' ,
   'LBL_MY_TEAM_REPORT_CHARTS' => 'Reportes de mi equipo' ,
   'LBL_MY_SAVED_REPORT_CHARTS' => 'Mis reportes guardados' ,
   'LBL_DASHLET_SEARCH' => 'Buscar Sugar Dashlet' ,
   'LBL_VERSION' => 'Versión' ,
   'LBL_BUILD' => 'Build' ,
   'LBL_SUGAR_COMMUNITY_EDITION' => 'Sugar Community Edition' ,
   'LBL_SUGAR_PROFESSIONAL' => "Sugar Professional" ,
   'LBL_SUGAR_ENTERPRISE' => "Sugar Enterprise" ,
   'LBL_AND' => 'y' ,
   'LBL_ARE' => 'son' ,
   'LBL_TRADEMARKS' => 'marcas registradas' ,
   'LBL_OF' => 'de' ,
   'LBL_FOUNDERS' => 'Fundadores' ,
   'LBL_JOIN_SUGAR_COMMUNITY' => 'Únase a la comunidad SugarCRM' ,
   'LBL_DETAILS_SUGARFORGE' => 'Colabore y desarolle extensiones de SugarCRM' ,
   'LBL_DETAILS_SUGAREXCHANGE' => 'Compre y venda extensiones certificadas de SugarCRM' ,
   'LBL_TRAINING' => 'Formación' ,
   'LBL_DETAILS_TRAINING' => 'Aprenda más de SugarCRM utilizando material formativo interactivo en línea' ,
   'LBL_FORUMS' => 'Foros' ,
   'LBL_DETAILS_FORUMS' => 'Discuta sobre SugarCRM con usuarios y desarrolladores expertos de la comunidad' ,
   'LBL_WIKI' => 'Wiki' ,
   'LBL_DETAILS_WIKI' => 'Busque en la Base de conocimiento sobre temas de usuarios y desarrolladores' ,
   'LBL_DEVSITE' => 'Sitio del desarrollador' ,
   'LBL_DETAILS_DEVSITE' => 'Descubra recursos, tutoriales, y útiles enlaces para acelerar sus desarrollos sobre SugarCRM' ,
   'LBL_GET_SUGARCRM_RSS' => 'Suscríbase a canales sobre SugarCRM' ,
   'LBL_SUGARCRM_NEWS' => 'Noticias sobre SugarCRM' ,
   'LBL_SUGARCRM_TRAINING_NEWS' => 'Noticias sobre formación SugarCRM' ,
   'LBL_SUGARCRM_FORUMS' => 'Foros SugarCRM' ,
   'LBL_SUGARFORGE_NEWS' => 'Noticias en SugarForge' ,
   'LBL_ALL_NEWS' => 'Todas las noticias' ,
   'LBL_LINK_CURRENT_CONTRIBUTORS' => 'Haga clic en este enlace para ver una lista actual de los contribuyentes de SugarCRM' ,
   'LBL_SOURCE_CODE' => 'Código fuente' ,
   'LBL_SOURCE_SUGAR' => 'SugarCRM - La aplicación más popular del mundo para la automatización de la fuerza de ventas, creada por SugarCRM Inc' ,
   'LBL_SOURCE_XTEMPLATE' => 'XTemplate - Un motor de plantillas para PHP creado por Barnabás Debreceni' ,
   'LBL_SOURCE_NUSOAP' => 'NuSOAP - Un conjunto de clases PHP que permiten a los desarrolladores crear y consumir servicios web creado por NuSphere Corporation y Dietrich Ayala' ,
   'LBL_SOURCE_JSCALENDAR' => 'JS Calendar - Un calendario para introducir fechas creado por Mihai Bazon' ,
   'LBL_SOURCE_PHPPDF' => 'PHP PDF - Una librería para crear documentos PDF creado por Wayne Munro' ,
   'LBL_SOURCE_JSONPHP' => 'JSON.php - Un script PHP para convertir a y del formato de datos JSON, por Michal Migurski' ,
   'LBL_SOURCE_JSON' => 'JSON.js - Un analizador JSON y convertidor a cadenas JSON realizado en JavaScript' ,
   'LBL_SOURCE_HTTP_WEBDAV_SERVER' => 'HTTP_WebDAV_Server - Una implementación de servidor WebDAV en PHP' ,
   'LBL_SOURCE_JS_O_LAIT' => 'JavaScript O Lait - Una biblioteca de módulos y componentes reutilizables para mejorar el desarrollo con JavaScript, por Jan-Klaas Kollhof' ,
   'LBL_SOURCE_PCLZIP' => 'PclZip - libería que ofrece funciones de compresión y extracción para archivos Zip, por Vincent Blavet' ,
   'LBL_SOURCE_SMARTY' => 'Smarty - Un motor de plantillas para PHP' ,
   'LBL_SOURCE_OVERLIBMWS' => 'Overlibmws - una librería de JavaScript para creación de ventanas en el lado del cliente' ,
   'LBL_SOURCE_YAHOO_UI_LIB' => 'Yahoo! User Interface Library - La biblioteca de utilidades de interfaz gráfica facilita la implementación de características para un cliente con una interfaz rico' ,
   'LBL_SOURCE_PHPMAILER' => 'PHPMailer - Una clase para transferencia de e-Mail para PHP con características completas' ,
   'LBL_SOURCE_CRYPT_BLOWFISH' => 'Crypt_Blowfish - Permite una rápida encriptación blowfish en ambos sentidos sin requerir la extensión PHP MCrypt' ,
   'LBL_SOURCE_HTML_SAFE' => 'HTML_Safe - Un analizador que elimina el contenido potencialmente peligroso del código HTML' ,
   'LBL_SOURCE_XML_HTMLSAX3' => 'XML_HTMLSax3 - Un analizador SAX para HTML y otros documentos con XML mal formado' ,
   'LBL_SOURCE_YAHOO_UI_LIB_EXT' => 'Yahoo! UI Extensions Library - Extensiones para la Yahoo! User Interface Library, por Jack Slocum' ,
   'LBL_SOURCE_JSMIN' => 'JSMin - un filtro que elimina comentarios y espacios en blanco no necesarios de los archivos JavaScript' ,
   'LBL_SOURCE_SWFOBJECT' => 'SWFObject - detección JavaScript y script de incrustación del reproductor de Flash' ,
   'LBL_SOURCE_TINYMCE' => 'TinyMCE - Control de edición WYSIWYG para navegadores web que permite al usuario editar el contenido HTML' ,
   'LBL_SOURCE_EXT' => 'Ext - Framework JavaScript para clientes de aplicaciones web' ,
   'LBL_SOURCE_RECAPTCHA' => 'reCAPTCHA - Un servicio CAPTCHA gratuito que ayuda a digitalizar libros, periódicos y los programas de radio de toda la vida' ,
   'LBL_SOURCE_TCPDF' => 'TCPDF - Una clase PHP para generar documentos PDF' ,
   'LBL_SOURCE_CSSMIN' => 'CssMin - un convertidor y reductor de css.' ,
   'LBL_SOURCE_PHPSAML' => 'PHP-SAML - Herramienta simple de SAML para PHP.' ,
   'LBL_SOURCE_ISCROLL' => 'iScroll - El overflow:scroll para webkit móvil.  Scrolling nativo dentro de un elemento con ancho y alto' ,
   'LBL_SOURCE_FLASHCANVAS' => 'FlashCanvas - FlashCanvas es una librería de JavaScript que agrega soporte HTML5 para Internet Explorer. Renderiza formas e imágenes via API de dibujo de Flash. Soporta la mayoría de los APIs de dibujo y, en muchos casos, se ejecuta más rápido que otras librerías similares que usan VML o Silverlight' ,
   'LBL_SOURCE_JIT' => 'JavaScript InfoVis Toolkit - El JavaScript InfoVis Toolkit proporciona herramientas para crear visualizaciones de datos interactivas para la Web.' ,
   'LBL_DASHLET_TITLE' => 'Mis sitios' ,
   'LBL_DASHLET_OPT_TITLE' => 'Título' ,
   'LBL_DASHLET_OPT_URL' => 'Dirección del sitio web' ,
   'LBL_DASHLET_OPT_HEIGHT' => 'Altura del Dashlet (en pixeles)' ,
   'LBL_DASHLET_SUGAR_NEWS' => 'Noticias SugarCRM' ,
   'LBL_DASHLET_DISCOVER_SUGAR_PRO' => 'Descubra SugarCRM' ,
   'dashlet_categories_dom' => array (
      'Module Views' => 'Vistas del módulo' ,
      'Portal' => 'Portal' ,
      'Charts' => 'Gráficos' ,
      'Tools' => 'Herramientas' ,
      'Miscellaneous' => 'Varios'   ));

?>