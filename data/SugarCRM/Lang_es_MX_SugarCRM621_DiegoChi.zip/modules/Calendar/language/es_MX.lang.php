<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Calendario.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_list_strings = array ( 
   'dom_cal_month' => array (
      '0' => '' ,
      '1' => 'Ene' ,
      '2' => 'Feb' ,
      '3' => 'Mar' ,
      '4' => 'Abr' ,
      '5' => 'May' ,
      '6' => 'Jun' ,
      '7' => ' Jul' ,
      '8' => 'Ago' ,
      '9' => 'Sep' ,
      '10' => 'Oct' ,
      '11' => 'Nov' ,
      '12' => 'Dic'   ),
   'dom_cal_month_long' => array (
      '0' => '' ,
      '1' => 'Enero' ,
      '2' => 'Febrero' ,
      '3' => 'Marzo' ,
      '4' => 'Abril' ,
      '5' => 'Mayo' ,
      '6' => 'Junio' ,
      '7' => 'Julio' ,
      '8' => 'Agosto' ,
      '9' => 'Septiembre' ,
      '10' => 'Octubre' ,
      '11' => 'Noviembre' ,
      '12' => 'Diciembre'   ),
   'dom_cal_weekdays' => array (
      '0' => 'Dom' ,
      '1' => 'Lun' ,
      '2' => 'Mar' ,
      '3' => 'Mié' ,
      '4' => 'Jue' ,
      '5' => 'Vie' ,
      '6' => 'Sáb'   ),
   'dom_cal_weekdays_long' => array (
      '0' => 'Domingo' ,
      '1' => 'Lunes' ,
      '2' => 'Martes' ,
      '3' => 'Miércoles' ,
      '4' => 'Jueves' ,
      '5' => 'Viernes' ,
      '6' => 'Sábado'   ));
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Calendario' ,
   'LBL_MODULE_TITLE' => 'Calendario' ,
   'LBL_MODULE_ACTION' => 'Ver' ,
   'LNK_NEW_CALL' => 'Programar llamada' ,
   'LNK_NEW_MEETING' => 'Programar reunión' ,
   'LNK_NEW_APPOINTMENT' => 'Crear cita' ,
   'LNK_NEW_TASK' => 'Crear tarea' ,
   'LNK_CALL_LIST' => 'Llamadas' ,
   'LNK_MEETING_LIST' => 'Reuniones' ,
   'LNK_TASK_LIST' => 'Tareas' ,
   'LNK_VIEW_CALENDAR' => 'Hoy' ,
   'LNK_IMPORT_CALLS' => 'Importar llamadas' ,
   'LNK_IMPORT_MEETINGS' => 'Importar reuniones' ,
   'LNK_IMPORT_TASKS' => 'Importar tareas' ,
   'LBL_MONTH' => 'Mes' ,
   'LBL_DAY' => 'Día' ,
   'LBL_YEAR' => 'Año' ,
   'LBL_WEEK' => 'Semana' ,
   'LBL_PREVIOUS_MONTH' => 'Mes anterior' ,
   'LBL_PREVIOUS_DAY' => 'Día anterior' ,
   'LBL_PREVIOUS_YEAR' => 'Año anterior' ,
   'LBL_PREVIOUS_WEEK' => 'Semana anterior' ,
   'LBL_NEXT_MONTH' => 'Mes siguiente' ,
   'LBL_NEXT_DAY' => 'Día siguiente' ,
   'LBL_NEXT_YEAR' => 'Año siguiente' ,
   'LBL_NEXT_WEEK' => 'Semana siguiente' ,
   'LBL_AM' => 'AM' ,
   'LBL_PM' => 'PM' ,
   'LBL_SCHEDULED' => 'Planeado' ,
   'LBL_BUSY' => 'Ocupado' ,
   'LBL_CONFLICT' => 'Conflicto' ,
   'LBL_USER_CALENDARS' => 'Calendario de usuario' ,
   'LBL_SHARED' => 'Compartido' ,
   'LBL_PREVIOUS_SHARED' => 'Anterior' ,
   'LBL_NEXT_SHARED' => 'Siguiente' ,
   'LBL_SHARED_CAL_TITLE' => 'Calendario compartido' ,
   'LBL_USERS' => 'Usuario' ,
   'LBL_REFRESH' => 'Actualizar' ,
   'LBL_EDIT' => 'Editar' ,
   'LBL_SELECT_USERS' => 'Seleccione usuarios para la visualización de calendario' ,
   'LBL_FILTER_BY_TEAM' => 'Filtrado de usuarios por equipo:' ,
   'LBL_ASSIGNED_TO_NAME' => 'Asignado a' ,
   'LBL_DATE' => 'Fecha y hora de inicio' );

?>