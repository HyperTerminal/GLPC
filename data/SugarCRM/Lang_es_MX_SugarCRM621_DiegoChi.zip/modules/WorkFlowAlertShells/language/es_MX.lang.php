<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Alertas.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Alertas' ,
   'LBL_MODULE_TITLE' => 'Alertas : Inicio' ,
   'LBL_MODULE_SECTION_TITLE' => 'Las siguientes operaciones serán realizadas' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de alertas de flujo de trabajo' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de alertas' ,
   'LBL_NEW_FORM_TITLE' => 'Crear alerta de flujo de trabajo' ,
   'LBL_LIST_NAME' => 'Nombre' ,
   'LBL_LIST_ALERT_TYPE' => 'Tipo de alerta' ,
   'LBL_LIST_ALERT_TEXT' => 'Mensaje para la Alerta' ,
   'LBL_CUSTOM_TEMPLATE_NAME' => 'Plantilla personalizada' ,
   'LBL_NAME' => 'Nombre:' ,
   'LBL_ALERT_TEXT' => 'Texto de la alerta:' ,
   'LBL_ALERT_TYPE' => 'Tipo de alerta:' ,
   'LBL_SOURCE_TYPE' => 'Tipo de origen:' ,
   'LBL_LIST_TYPE' => 'Tipo:' ,
   'LBL_LIST_DETAILS' => 'Detalles' ,
   'LNK_NEW_WORKFLOW' => 'Crear definición de flujo de trabajo' ,
   'LNK_WORKFLOW' => 'Lista de Definiciones de flujo de trabajo' ,
   'LBL_PARENT_WORKFLOW' => 'Objeto de flujo de trabajo padre:' ,
   'LBL_RETURN_TO_WORKFLOW' => 'Volver a definición de flujo de trabajo' ,
   'NTC_REMOVE_ALERT' => '¿Está seguro que desea quitar esta alerta y todos sus destinatarios?' ,
   'LBL_LIST_STATEMENT' => 'Descripción del evento:' ,
   'STATEMENT_PART1' => 'Enviar' ,
   'STATEMENT_PART2' => 'usando un' ,
   'LNK_LIST_REPORTMAKER' => 'Lista de reportes' ,
   'LNK_NEW_REPORTMAKER' => 'Crear reporte' ,
   'LNK_LIST_DATASET' => 'Lista de formato de datos' ,
   'LNK_NEW_DATASET' => 'Crear formato de datos' ,
   'LNK_NEW_QUERYBUILDER' => 'Crear consulta' ,
   'LNK_QUERYBUILDER' => 'Diseñador de consultas' ,
   'LBL_ALL_REPORTS' => 'Todos los reportes' ,
   'NTC_DELETE_CONFIRMATION' => '¿Está seguro que desea eliminar este registro?' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar el producto' ,
   'LBL_NEW_BUTTON_LABEL_ALERT' => 'Crear alerta' ,
   'LBL_NEW_BUTTON_KEY_ALERT' => 'A' ,
   'LBL_NEW_BUTTON_TITLE_ALERT' => 'Crear alerta [Alt+A]' ,
   'LBL_NEW_BUTTON_LABEL_ACTION' => 'Crear acción' ,
   'LBL_NEW_BUTTON_KEY_ACTION' => 'C' ,
   'LBL_NEW_BUTTON_TITLE_ACTION' => 'Crear acción [Alt+C]' ,
   'LBL_MODULE_NAME_COMBO' => 'Alertas' ,
   'LNK_ALERT_TEMPLATES' => 'Plantillas de alerta' ,
   'LNK_PROCESS_VIEW' => 'Orden de ejecución del flujo de trabajo' ,
   'LBL_LIST_COMPONENTS' => 'Componentes' ,
   'LBL_RECIPIENTS' => 'Destinatarios' ,
   'LBL_MODULE_TITLE_INVITE' => 'Invitar a participantes' ,
   'LBL_SHOW' => 'Mostrar' ,
   'LBL_RECIPIENT_ERROR' => 'Este destinatario contiene errores y no puede sr mostrado' ,
   'LBL_ALERT_ERRORS' => 'Aviso : Una o más alertas contienen errores' );

?>