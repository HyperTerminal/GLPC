<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Plantillas de productos.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar el producto' ,
   'LBL_ACCOUNT_NAME' => 'Nombre de la cuenta:' ,
   'LBL_ASSIGNED_TO' => 'Asignado a:' ,
   'LBL_ASSIGNED_TO_ID' => 'Asignado a ID:' ,
   'LBL_CATEGORY_NAME' => 'Nombre de categoría:' ,
   'LBL_CATEGORY' => 'Categoría:' ,
   'LBL_CONTACT_NAME' => 'Nombre del contacto:' ,
   'LBL_COST_PRICE' => 'Coste:' ,
   'LBL_COST_USDOLLAR' => 'Coste (dólares EUA):' ,
   'LBL_CURRENCY' => 'Divisa:' ,
   'LBL_CURRENCY_SYMBOL_NAME' => 'Símbolo de divisa:' ,
   'LBL_DATE_AVAILABLE' => 'Fecha de disponibilidad:' ,
   'LBL_DATE_COST_PRICE' => 'Fecha-Coste-Precio:' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_DISCOUNT_PRICE_DATE' => 'Fecha de descuento de precio:' ,
   'LBL_DISCOUNT_PRICE' => 'Precio unitario:' ,
   'LBL_DISCOUNT_USDOLLAR' => 'Precio de descuento (dólares EUA):' ,
   'LBL_LIST_CATEGORY' => 'categorías:' ,
   'LBL_LIST_CATEGORY_ID' => 'ID de categoría:' ,
   'LBL_LIST_COST_PRICE' => 'Coste:' ,
   'LBL_LIST_DISCOUNT_PRICE' => 'Precio:' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de catálogo de productos' ,
   'LBL_LIST_LBL_MFT_PART_NUM' => 'Número de parte' ,
   'LBL_LIST_LIST_PRICE' => 'Listea' ,
   'LBL_LIST_MANUFACTURER' => 'Fabricante' ,
   'LBL_LIST_MANUFACTURER_ID' => 'ID del fabricante:' ,
   'LBL_LIST_NAME' => 'Nombre' ,
   'LBL_LIST_PRICE' => 'Precio de lista:' ,
   'LBL_LIST_QTY_IN_STOCK' => 'Cantidad' ,
   'LBL_LIST_STATUS' => 'Disponibilidad' ,
   'LBL_LIST_TYPE' => 'Tipo:' ,
   'LBL_LIST_TYPE_ID' => 'Tipo:' ,
   'LBL_LIST_USDOLLAR' => 'Lista (dólares EUA):' ,
   'LBL_MANUFACTURER_NAME' => 'Nombre del proveedor:' ,
   'LBL_MANUFACTURER' => 'Proveedor:' ,
   'LBL_MFT_PART_NUM' => 'Número de parte:' ,
   'LBL_MODULE_NAME' => 'Catálogo de productos' ,
   'LBL_MODULE_ID' => 'Plantilla de productos' ,
   'LBL_MODULE_TITLE' => 'Catálogo de productos: Inicio' ,
   'LBL_NAME' => 'Nombre de producto:' ,
   'LBL_NEW_FORM_TITLE' => 'Crear elemento' ,
   'LBL_PERCENTAGE' => 'Porcentaje (%)' ,
   'LBL_POINTS' => 'Puntos' ,
   'LBL_PRICING_FORMULA' => 'Fórmula de valoración predeterminada:' ,
   'LBL_PRICING_FACTOR' => 'Factor de valoración:' ,
   'LBL_PRODUCT' => 'Producto:' ,
   'LBL_PRODUCT_ID' => 'ID de producto:' ,
   'LBL_QUANTITY' => 'Cantidad en stock:' ,
   'LBL_RELATED_PRODUCTS' => 'Producto relacionado' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de catálogo de producto' ,
   'LBL_STATUS' => 'Disponibilidad:' ,
   'LBL_SUPPORT_CONTACT' => 'Contacto del soporte:' ,
   'LBL_SUPPORT_DESCRIPTION' => 'Descripción del soporte:' ,
   'LBL_SUPPORT_NAME' => 'Nombre del soporte:' ,
   'LBL_SUPPORT_TERM' => 'Plazo del soporte:' ,
   'LBL_TAX_CLASS' => 'Tipo de impuesto:' ,
   'LBL_TYPE_NAME' => 'Nombre de tipo' ,
   'LBL_TYPE' => 'Tipo' ,
   'LBL_URL' => 'URL del producto:' ,
   'LBL_VENDOR_PART_NUM' => 'Número de parte del vendedor:' ,
   'LBL_WEIGHT' => 'Peso:' ,
   'LNK_IMPORT_PRODUCTS' => 'Importar productos' ,
   'LNK_NEW_MANUFACTURER' => 'Proveedores' ,
   'LNK_NEW_PRODUCT_CATEGORY' => 'Categorías de producto' ,
   'LNK_NEW_PRODUCT_TYPE' => 'Tipos de producto' ,
   'LNK_NEW_PRODUCT' => 'Crear producto para el catálogo' ,
   'LNK_NEW_SHIPPER' => 'Proveedores de transporte' ,
   'LNK_PRODUCT_LIST' => 'Catálogo de productos' ,
   'NTC_DELETE_CONFIRMATION' => '¿Está seguro que desea eliminar este registro?' );

?>