<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Cuotas.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Cuotas' ,
   'LBL_MODULE_TITLE' => 'Cuotas: Inicio' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de cuotas' ,
   'LBL_QUOTA' => 'Cuota:' ,
   'LBL_DIRECT_REPORT' => 'Reporte directo' ,
   'LBL_QUOTA_AMOUNT' => 'Cantidad de cuota' ,
   'LBL_LAST_MODIFIED' => 'Última modificación' ,
   'LBL_COMMIT_STATUS' => 'Estado de realización' ,
   'LBL_COMMITTED' => 'Asignado' ,
   'LBL_NOT_COMMITTED' => 'Pendiente' ,
   'LBL_MODULE_FORECASTS_NAME' => 'Previsiones' ,
   'LNK_FORECAST_LIST' => 'Previsiones' ,
   'LNK_FORECAST_HISTORY' => 'Historial de previsión' ,
   'LNK_UPD_FORECAST' => 'Hoja de previsiones' ,
   'LNK_QUOTA' => 'Cuotas' ,
   'LBL_NAME' => 'Nombre:' ,
   'LBL_TIME_PERIOD' => 'Periodo de tiempo:' ,
   'LBL_SELECT_TIME_PERIOD' => 'Seleccione el periodo de tiempo...' ,
   'LBL_AMOUNT' => 'Cantidad:' ,
   'LBL_CURRENCY' => 'Divisa:' ,
   'LBL_COMMIT' => 'Realizado:' ,
   'LBL_SELECT_USER' => 'Seleccione usuario...' ,
   'LBL_NO_QUOTAS_TIMEPERIOD' => 'No sea han introducido cuotas para sus reportes directos en este periodo de tiempo' ,
   'LBL_CURRENT_USER_QUOTA' => 'Su cuota asignada para este periodo de tiempo es: ' ,
   'LBL_CURRENT_USER_NO_QUOTA' => 'No se ha asignado una cuota para este periodo de tiempo' ,
   'LBL_USER_ID' => 'ID de usuario' );

?>