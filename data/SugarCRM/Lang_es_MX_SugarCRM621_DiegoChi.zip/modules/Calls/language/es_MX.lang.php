<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Llamadas.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Llamadas' ,
   'LBL_MODULE_TITLE' => 'Llamadas : Inicio' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de llamadas' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de llamadas' ,
   'LBL_NEW_FORM_TITLE' => 'Crear cita' ,
   'LBL_LIST_CLOSE' => 'Cerrar' ,
   'LBL_LIST_SUBJECT' => 'Asunto' ,
   'LBL_LIST_CONTACT' => 'Contacto' ,
   'LBL_LIST_RELATED_TO' => 'Relacionado con' ,
   'LBL_LIST_RELATED_TO_ID' => 'Relacionado con ID' ,
   'LBL_LIST_DATE' => 'Fecha de inicio' ,
   'LBL_LIST_TIME' => 'Hora de inicio' ,
   'LBL_LIST_DURATION' => 'Duración' ,
   'LBL_LIST_DIRECTION' => 'Dirección' ,
   'LBL_SUBJECT' => 'Asunto:' ,
   'LBL_REMINDER' => 'Aviso:' ,
   'LBL_CONTACT_NAME' => 'Contacto:' ,
   'LBL_DESCRIPTION_INFORMATION' => 'Información adicional' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_STATUS' => 'Estado:' ,
   'LBL_DIRECTION' => 'Dirección:' ,
   'LBL_DATE' => 'Fecha de inicio:' ,
   'LBL_DURATION' => 'Duración:' ,
   'LBL_DURATION_HOURS' => 'Horas de duración:' ,
   'LBL_DURATION_MINUTES' => 'Minutos duración:' ,
   'LBL_HOURS_MINUTES' => '(horas/minutos)' ,
   'LBL_CALL' => 'Llamada:' ,
   'LBL_DATE_TIME' => 'Inicio:' ,
   'LBL_TIME' => 'Hora inicio:' ,
   'LBL_HOURS_ABBREV' => 'h' ,
   'LBL_MINSS_ABBREV' => 'm' ,
   'LBL_COLON' => ':' ,
   'LNK_NEW_CALL' => 'Programar llamada' ,
   'LNK_NEW_MEETING' => 'Programar reunión' ,
   'LNK_CALL_LIST' => 'Llamadas' ,
   'LNK_IMPORT_CALLS' => 'Importar llamadas' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro a eliminar' ,
   'NTC_REMOVE_INVITEE' => '¿Está seguro que desea quitar a este participante de la llamada?' ,
   'LBL_INVITEE' => 'Participantes' ,
   'LBL_RELATED_TO' => 'Relacionado con:' ,
   'LNK_NEW_APPOINTMENT' => 'Crear cita' ,
   'LBL_SCHEDULING_FORM_TITLE' => 'Planeación' ,
   'LBL_ADD_INVITEE' => 'Agregar invitados' ,
   'LBL_NAME' => 'Nombre' ,
   'LBL_FIRST_NAME' => 'Nombre' ,
   'LBL_LAST_NAME' => 'Apellido' ,
   'LBL_EMAIL' => 'e-Mail' ,
   'LBL_PHONE' => 'Teléfono' ,
   'LBL_SEND_BUTTON_TITLE' => 'Enviar invitaciones [Alt+I]' ,
   'LBL_SEND_BUTTON_KEY' => 'I' ,
   'LBL_SEND_BUTTON_LABEL' => 'Enviar invitaciones' ,
   'LBL_DATE_END' => 'Fecha final' ,
   'LBL_TIME_END' => 'Hora final' ,
   'LBL_REMINDER_TIME' => 'Hora de aviso' ,
   'LBL_SEARCH_BUTTON' => 'Buscar' ,
   'LBL_ACTIVITIES_REPORTS' => 'Informe de actividad' ,
   'LBL_ADD_BUTTON' => 'Agregar' ,
   'LBL_DEFAULT_SUBPANEL_TITLE' => 'Llamadas' ,
   'LBL_LOG_CALL' => 'Registrar llamada' ,
   'LNK_SELECT_ACCOUNT' => 'Seleccionar cuenta' ,
   'LNK_NEW_ACCOUNT' => 'Nueva cuenta' ,
   'LNK_NEW_OPPORTUNITY' => 'Nueva oportunidad' ,
   'LBL_DEL' => 'Eliminar.' ,
   'LBL_LEADS_SUBPANEL_TITLE' => 'Clientes potenciales' ,
   'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos' ,
   'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios' ,
   'LBL_OUTLOOK_ID' => 'ID Outlook' ,
   'LBL_MEMBER_OF' => 'Miembro de' ,
   'LBL_HISTORY_SUBPANEL_TITLE' => 'Notas' ,
   'LBL_LIST_ASSIGNED_TO_NAME' => 'Asignado a' ,
   'LBL_LIST_MY_CALLS' => 'Mis llamadas' ,
   'LBL_SELECT_FROM_DROPDOWN' => 'Por favor, seleccione antes un elemento de la lista desplegable relacionado con' ,
   'LBL_ASSIGNED_TO_NAME' => 'Asignado a' ,
   'LBL_ASSIGNED_TO_ID' => 'Usuario asignado' ,
   'NOTICE_DURATION_TIME' => 'El tiempo de duración debe ser mayor que 0' ,
   'LBL_CALL_INFORMATION' => 'Información de llamada' ,
   'LBL_REMOVE' => 'Quitar' );

?>