<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Creación de reportes.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Reportes empresariales' ,
   'LBL_MODULE_TITLE' => 'Reportes empresariales' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de reportes empresariales' ,
   'LBL_LIST_FORM_TITLE' => 'Todos los reportes empresariales' ,
   'LBL_LIST_NAME' => 'Nombre' ,
   'LBL_LIST_QUERY_NAME' => 'Consulta' ,
   'LBL_LIST_PUBLISHED' => 'Publicado' ,
   'LBL_LIST_SCHEDULED' => 'Planeado' ,
   'LBL_LIST_TYPE' => 'Tipo' ,
   'LBL_LIST_MODULE_TITLE' => 'Módulo' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_PARENT_DATASET' => 'Conjunto de datos padre:' ,
   'LBL_QUERY_NAME' => 'Nombre de consulta:' ,
   'LBL_TYPE' => 'Tipo de reporte:' ,
   'LBL_SCHEDULED' => 'Planear reporte:' ,
   'LBL_PUBLISHED' => 'Publicar reporte:' ,
   'LBL_NAME' => 'Nombre de reporte:' ,
   'LBL_TITLE' => 'Título del reporte:' ,
   'LBL_TABLE_WIDTH' => 'Ancho de tabla %:' ,
   'LBL_TABLE_HEIGHT' => 'Alto de tabla %:' ,
   'LBL_FONT_SIZE' => 'Tamaño de fuente:' ,
   'NTC_DELETE_CONFIRMATION' => '¿Está seguro que desea eliminar este registro?' ,
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar el producto' ,
   'LBL_CURRENCY' => 'Divisa:' ,
   'LNK_LIST_REPORTMAKER' => 'Lista de reportes empresariales' ,
   'LNK_NEW_REPORTMAKER' => 'Crear reporte' ,
   'LNK_LIST_DATASET' => 'Lista de formatos de datos' ,
   'LNK_NEW_DATASET' => 'Crear formato de datos' ,
   'LNK_NEW_CUSTOMQUERY' => 'Crear consulta personalizada' ,
   'LNK_CUSTOMQUERIES' => 'Consultas personalizadas' ,
   'LNK_NEW_QUERYBUILDER' => 'Crear consulta' ,
   'LNK_QUERYBUILDER' => 'Diseñador de consultas' ,
   'LNK_ADVANCED_REPORTING' => 'Reportes empresariales' ,
   'LBL_ALL_REPORTS' => 'Todos los reportes' ,
   'LBL_ADD_DATA_SET' => 'Agregar un nuevo conjunto de datos' ,
   'LBL_EDIT_DATA_SET' => 'Actualizar conjunto de datos' ,
   'LBL_DATA_SET' => 'Conjunto de datos:' ,
   'LBL_LIST_ORDER_Y' => 'Posicionamiento vertical:' ,
   'LBL_LIST_ORDER_X' => 'Posicionamiento horizontal:' ,
   'LBL_REPORT_ALIGN' => 'Alineación del reporte:' ,
   'LBL_ADD_BUTTON_TITLE' => 'Seleccionar [Alt+A]' ,
   'LBL_ADD_BUTTON_KEY' => 'A' ,
   'LBL_ADD_BUTTON_LABEL' => 'Seleccionar' ,
   'LBL_NEW_BUTTON_TITLE' => 'Agregar [Alt+N]' ,
   'LBL_NEW_BUTTON_KEY' => 'N' ,
   'LBL_NEW_BUTTON_LABEL' => 'Crear nuevo' ,
   'LBL_DETAILS_BUTTON_TITLE' => 'Detalles del reporte [Alt+D]' ,
   'LBL_DETAILS_BUTTON_KEY' => 'D' ,
   'LBL_DETAILS_BUTTON_LABEL' => 'Detalles del reporte' ,
   'LBL_EDIT_BUTTON_TITLE' => 'Editar reporte [Alt+E]' ,
   'LBL_EDIT_BUTTON_KEY' => 'N' ,
   'LBL_EDIT_BUTTON_LABEL' => 'Editar' ,
   'LBL_RUN_BUTTON_TITLE' => 'Ejecutar reporte [Alt+R]' ,
   'LBL_RUN_BUTTON_KEY' => 'R' ,
   'LBL_RUN_BUTTON_LABEL' => 'Ejecutar reporte' ,
   'LNK_UP' => 'Arriba' ,
   'LNK_DOWN' => 'Abajo' ,
   'LBL_NONE' => 'Sin planear' ,
   'LBL_SCHEDULE_EMAIL' => 'Planeado' ,
   'LBL_HELLO' => 'Hola' ,
   'LBL_SCHEDULED_REPORT_MSG_INTRO' => 'Adjunto se encuentra un reporte autogenerado enviado a usted desde la aplicación SugarCRM. Este reporte se creó el ' ,
   'LBL_SCHEDULED_REPORT_MSG_BODY1' => ' y se guardó con el nombre "' ,
   'LBL_SCHEDULED_REPORT_MSG_BODY2' => '". Si desea cambiar la configuración de sus reportes, inicie la sesión en la aplicación SugarCRM y haga click en la pestaña "Reportes".\n\n' );

?>