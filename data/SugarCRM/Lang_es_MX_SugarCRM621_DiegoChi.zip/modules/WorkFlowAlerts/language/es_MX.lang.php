<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Lista de destinatarios de alertas.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Lista de Destinatarios de Alertas' ,
   'LBL_MODULE_TITLE' => 'Destinatarios : Inicio' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de destinatarios de flujo de trabajo' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de destinatarios' ,
   'LBL_NEW_FORM_TITLE' => 'Crear destinatario de flujo de trabajo' ,
   'LBL_LIST_USER_TYPE' => 'Tipo de usuario' ,
   'LBL_LIST_ARRAY_TYPE' => 'Tipo de acción' ,
   'LBL_LIST_RELATE_TYPE' => 'Tipo relacionado' ,
   'LBL_LIST_ADDRESS_TYPE' => 'Tipo de dirección' ,
   'LBL_LIST_FIELD_VALUE' => 'Usuario' ,
   'LBL_LIST_REL_MODULE1' => 'Módulo relacionado' ,
   'LBL_LIST_REL_MODULE2' => 'Módulo relacionado con el relacionado' ,
   'LBL_LIST_WHERE_FILTER' => 'Estado' ,
   'LBL_USER_TYPE' => 'Tipo de usuario:' ,
   'LBL_ARRAY_TYPE' => 'Tipo de acción:' ,
   'LBL_RELATE_TYPE' => 'Tipo de relación:' ,
   'LBL_WHERE_FILTER' => 'Estado:' ,
   'LBL_FIELD_VALUE' => 'Usuario seleccionado:' ,
   'LBL_REL_MODULE1' => 'Módulo relacionado:' ,
   'LBL_REL_MODULE2' => 'Módulo relacionado con el relacionado:' ,
   'LBL_CUSTOM_USER' => 'Usuario personalizado:' ,
   'LNK_NEW_WORKFLOW' => 'Crear un flujo de trabajo' ,
   'LNK_WORKFLOW' => 'Objetos del flujo de trabajo' ,
   'LBL_LIST_STATEMENT' => 'Destinatarios de la alerta:' ,
   'LBL_LIST_STATEMENT_CONTENT' => 'Enviar la alerta al siguiente destinatario:' ,
   'LBL_ALERT_CURRENT_USER' => 'Un usuario asociado al objetivo' ,
   'LBL_ALERT_CURRENT_USER_TITLE' => 'Un usuario asociado con el módulo objetivo' ,
   'LBL_ALERT_REL_USER' => 'Un usuario asociado con el relacionado ' ,
   'LBL_ALERT_REL_USER_TITLE' => 'Un usuario asociado con un módulo relacionado' ,
   'LBL_ALERT_REL_USER_CUSTOM' => 'El destinatario asociado con un relacionado' ,
   'LBL_ALERT_REL_USER_CUSTOM_TITLE' => 'El destinatario asociado con un módulo relacionado' ,
   'LBL_ALERT_TRIG_USER_CUSTOM' => 'El destinatario asociado con el módulo objetivo' ,
   'LBL_ALERT_TRIG_USER_CUSTOM_TITLE' => 'El destinatario asociado con el módulo objetivo' ,
   'LBL_ALERT_SPECIFIC_USER' => 'Un especificado' ,
   'LBL_ALERT_SPECIFIC_USER_TITLE' => 'Un usuario especificado' ,
   'LBL_ALERT_SPECIFIC_TEAM' => 'Todos los usuarios en un especificado ' ,
   'LBL_ALERT_SPECIFIC_TEAM_TITLE' => 'Todos los usuarios en un equipo especificado' ,
   'LBL_ALERT_SPECIFIC_ROLE' => 'Todos los usuarios en un especificado' ,
   'LBL_ALERT_SPECIFIC_ROLE_TITLE' => 'Todos los usuarios en un especificado rol' ,
   'LBL_ALERT_SPECIFIC_TEAM_TARGET_TITLE' => 'Miembros del equipo relacionados con el módulo de trabajo' ,
   'LBL_ALERT_SPECIFIC_TEAM_TARGET' => 'Todos los usuarios de equipos que estén asociados al módulo de trabajo' ,
   'LBL_ALERT_LOGIN_USER_TITLE' => 'Usuario con la sesión iniciada en el momento de ejecución' ,
   'LBL_RECORD' => 'Módulo' ,
   'LBL_TEAM' => 'Equipo' ,
   'LBL_USER' => 'Usuario' ,
   'LBL_USER_MANAGER' => 'responsable del usuario' ,
   'LBL_ROLE' => 'Rol' ,
   'LBL_SEND_EMAIL' => 'Enviar un correo a:' ,
   'LBL_USER1' => ' que creó el registro' ,
   'LBL_USER2' => ' que modificó por última vez el registro' ,
   'LBL_USER3' => 'Actual' ,
   'LBL_USER3b' => ' del sistema' ,
   'LBL_USER4' => ' que tiene el registro asignado' ,
   'LBL_USER5' => ' a quien fue asignado el registro' ,
   'LBL_ADDRESS_TO' => 'Para:' ,
   'LBL_ADDRESS_CC' => 'CC:' ,
   'LBL_ADDRESS_BCC' => 'CCO:' ,
   'LBL_ADDRESS_TYPE' => 'utilizando la dirección ' ,
   'LBL_ADDRESS_TYPE_TARGET' => 'Tipo' ,
   'LBL_ALERT_REL1' => 'Módulo Relacionado: ' ,
   'LBL_ALERT_REL2' => 'Módulo relacionado con el relacionado: ' ,
   'LBL_NEXT_BUTTON' => 'Siguiente' ,
   'LBL_PREVIOUS_BUTTON' => 'Anterior' ,
   'LBL_BLANK' => '' ,
   'NTC_REMOVE_ALERT_USER' => '¿Está seguro que desea quitar este destinatario de la alerta?' ,
   'LBL_REL_CUSTOM_STRING' => 'Seleccione campos personalizados de email y nombre' ,
   'LBL_REL_CUSTOM' => 'Seleccione campo personalizado de e-Mail: ' ,
   'LBL_REL_CUSTOM2' => 'Campo' ,
   'LBL_AND' => 'y campo para el nombre:' ,
   'LBL_REL_CUSTOM3' => 'Campo' ,
   'LBL_FILTER_CUSTOM' => '(Filtro Adicional) Filtrar módulo relacionado por específico ' ,
   'LBL_FIELD' => 'Campo' ,
   'LBL_SPECIFIC_FIELD' => 'campo' ,
   'LBL_FILTER_BY' => '(Filtro Adicional) Filtrar módulo relacionado por ' ,
   'LBL_MODULE_NAME_INVITE' => 'Lista de invitados' ,
   'LBL_LIST_STATEMENT_INVITE' => 'Invitados a reunión/llamada:' ,
   'LBL_SELECT_VALUE' => 'Debe seleccionar un valor válido' ,
   'LBL_SELECT_NAME' => 'Debe seleccionar un campo personalizado para el nombre' ,
   'LBL_SELECT_EMAIL' => 'Debe seleccionar un campo personalizado para el e-Mail' ,
   'LBL_SELECT_FILTER' => 'Debe seleccionar un campo para filtrar por su valor' ,
   'LBL_SELECT_NAME_EMAIL' => 'Debe seleccionar los campos de nombre y de e-Mail' ,
   'LBL_PLEASE_SELECT' => 'Por favor, realice la selección' );

?>