<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Versiones.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'LBL_MODULE_NAME' => 'Definiciones del flujos de trabajo' ,
   'LBL_MODULE_ID' => 'Flujos de trabajo' ,
   'LBL_MODULE_TITLE' => 'Flujos de trabajo : Inicio' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de flujos de trabajo' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de flujos de trabajo' ,
   'LBL_NEW_FORM_TITLE' => 'Crear definición de flujos de trabajo' ,
   'LBL_LIST_NAME' => 'Nombre' ,
   'LBL_LIST_TYPE' => 'Ejecución al:' ,
   'LBL_LIST_BASE_MODULE' => 'Módulo objetivo:' ,
   'LBL_LIST_STATUS' => 'Estado' ,
   'LBL_NAME' => 'Nombre:' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_TYPE' => 'Ejecución al:' ,
   'LBL_STATUS' => 'Estado:' ,
   'LBL_BASE_MODULE' => 'Módulo objetivo:' ,
   'LBL_LIST_ORDER' => 'Órden de proceso:' ,
   'LBL_FROM_NAME' => 'Nombre del remitente:' ,
   'LBL_FROM_ADDRESS' => 'Dirección del remitente:' ,
   'LNK_NEW_WORKFLOW' => 'Crear definición de flujo de trabajo' ,
   'LNK_WORKFLOW' => 'Lista de definiciones de flujo de trabajo' ,
   'LBL_ALERT_TEMPLATES' => 'Plantillas de alertas' ,
   'LBL_CREATE_ALERT_TEMPLATE' => 'Crear una plantilla de alerta:' ,
   'LBL_SUBJECT' => 'Asunto:' ,
   'LBL_RECORD_TYPE' => 'Aplicar a:' ,
   'LBL_RELATED_MODULE' => 'Módulo relacionado:' ,
   'LBL_PROCESS_LIST' => 'Secuencia de flujo de trabajo' ,
   'LNK_ALERT_TEMPLATES' => 'Plantillas de e-Mails de alerta' ,
   'LNK_PROCESS_VIEW' => 'Secuencia de flujo de trabajo' ,
   'LBL_PROCESS_SELECT' => 'Por favor, seleecione un módulo:' ,
   'LBL_LACK_OF_TRIGGER_ALERT' => 'Advertencia: Debe crear un disparador para que funcione este objeto de flujo de trabajo' ,
   'LBL_LACK_OF_NOTIFICATIONS_ON' => 'Advertencia: Para enviar alertas, proporcione la información sobre el servidor SMTP en Admin > Configuración de e-Mail' ,
   'LBL_FIRE_ORDER' => 'Orden de proceso:' ,
   'LBL_RECIPIENTS' => 'Destinatarios' ,
   'LBL_INVITEES' => 'Invitados' ,
   'LBL_INVITEE_NOTICE' => 'Atención, debe de seleccionar al menos un invitado para crear esto' ,
   'NTC_REMOVE_ALERT' => '¿Está seguro que quiere quitar este flujo de trabajo?' ,
   'LBL_EDIT_ALT_TEXT' => 'Texto Alt' ,
   'LBL_INSERT' => 'Insertar' ,
   'LBL_SELECT_OPTION' => 'Por favor, seleccione una opción' ,
   'LBL_SELECT_VALUE' => 'Debe seleccionar un valor' ,
   'LBL_SELECT_MODULE' => 'Por favor, seleccione un módulo relacionado' ,
   'LBL_SELECT_FILTER' => 'Debe seleccionar un campo de filtrado para el módulo relacionado' ,
   'LBL_LIST_UP' => 'ar' ,
   'LBL_LIST_DN' => 'ab' ,
   'LBL_SET' => 'Establecer' ,
   'LBL_AS' => 'como' ,
   'LBL_SHOW' => 'Mostrar' ,
   'LBL_HIDE' => 'Ocultar' ,
   'LBL_SPECIFIC_FIELD' => 'campo espeficiado' ,
   'LBL_ANY_FIELD' => 'cualquier campo' ,
   'LBL_LINK_RECORD' => 'Vincular con registro' ,
   'LBL_INVITE_LINK' => 'Enlace de invitación a reunión/llamada' ,
   'LBL_PLEASE_SELECT' => 'Por favor, seleccione' ,
   'LBL_BODY' => 'Cuerpo:' ,
   'LBL__S' => '&#034;s&#039;' ,
   'LBL_ALERT_SUBJECT' => 'ALERTA FLUJO DE TRABAJO' ,
   'LBL_ACTION_ERROR' => 'La acción no puede ser ejecutada. Cambie la acción para todos los campos y para que sus valores sean válidos' ,
   'LBL_ACTION_ERRORS' => 'Aviso : Una o más acciones contienen errores.' ,
   'LBL_ALERT_ERROR' => 'Esta alerta no puede ser ejecutada. Modifique la alerta para que la configuración sea válida.' ,
   'LBL_ALERT_ERRORS' => 'Aviso : Una o más alertas contienen errores' ,
   'LBL_TRIGGER_ERROR' => 'Aviso : Esta versión contiene errores y no será ejecutada' ,
   'LBL_TRIGGER_ERRORS' => 'Aviso : Uno o más disparadores contienen errores' );

?>