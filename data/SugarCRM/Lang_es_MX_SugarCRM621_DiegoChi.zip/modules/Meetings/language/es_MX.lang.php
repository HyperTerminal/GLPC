<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************
 * Description:  Define el paquete de lenguaje Español para el módulo de Reuniones.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Diego Chi <diego.chi@mail.com>
 ********************************************************************************/
$mod_strings = array ( 
   'ERR_DELETE_RECORD' => 'Debe especificar un número de registro a eliminar' ,
   'LBL_ACCEPT_THIS' => '¿Aceptar?' ,
   'LBL_ADD_BUTTON' => 'Agregar' ,
   'LBL_ADD_INVITEE' => 'Agregar asistentes' ,
   'LBL_COLON' => ':' ,
   'LBL_CONTACT_NAME' => 'Nombre de contacto:' ,
   'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos' ,
   'LBL_CREATED_BY' => 'Creado por' ,
   'LBL_DATE_END' => 'Fecha final' ,
   'LBL_DATE_TIME' => 'Fecha y hora de inicio:' ,
   'LBL_DATE' => 'Fecha inicial:' ,
   'LBL_DEFAULT_SUBPANEL_TITLE' => 'Reuniones' ,
   'LBL_DEL' => 'Eliminar' ,
   'LBL_DESCRIPTION_INFORMATION' => 'Información adicional' ,
   'LBL_DESCRIPTION' => 'Descripción:' ,
   'LBL_DURATION_HOURS' => 'Horas de duración:' ,
   'LBL_DURATION_MINUTES' => 'Minutos de duración:' ,
   'LBL_DURATION' => 'Duración:' ,
   'LBL_EMAIL' => 'e-Mail' ,
   'LBL_FIRST_NAME' => 'Nombre' ,
   'LBL_HISTORY_SUBPANEL_TITLE' => 'Notas' ,
   'LBL_HOURS_ABBREV' => 'h' ,
   'LBL_HOURS_MINS' => '(horas/minutos)' ,
   'LBL_INVITEE' => 'Asistentes' ,
   'LBL_LAST_NAME' => 'Apellidos' ,
   'LBL_ASSIGNED_TO_NAME' => 'Asignado a:' ,
   'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario asignado' ,
   'LBL_LIST_CLOSE' => 'Cerrado' ,
   'LBL_LIST_CONTACT' => 'Contacto' ,
   'LBL_LIST_DATE_MODIFIED' => 'Fecha de modificación' ,
   'LBL_LIST_DATE' => 'Fecha inicial' ,
   'LBL_LIST_DIRECTION' => 'Dirección' ,
   'LBL_LIST_DUE_DATE' => 'Fecha de vencimiento' ,
   'LBL_LIST_FORM_TITLE' => 'Lista de reuniones' ,
   'LBL_LIST_MY_MEETINGS' => 'Mis reuniones' ,
   'LBL_LIST_RELATED_TO' => 'Relacionado con' ,
   'LBL_LIST_STATUS' => 'Estado' ,
   'LBL_LIST_SUBJECT' => 'Asunto' ,
   'LBL_LIST_TIME' => 'Hora de inicio' ,
   'LBL_LEADS_SUBPANEL_TITLE' => 'Clientes potenciales' ,
   'LBL_LOCATION' => 'Lugar:' ,
   'LBL_MEETING' => 'Reunión:' ,
   'LBL_MINSS_ABBREV' => 'm' ,
   'LBL_MODIFIED_BY' => 'Modificado por' ,
   'LBL_MODULE_NAME' => 'Reuniones' ,
   'LBL_MODULE_TITLE' => 'Reuniones : Inicio' ,
   'LBL_NAME' => 'Nombre' ,
   'LBL_NEW_FORM_TITLE' => 'Crear cita' ,
   'LBL_OUTLOOK_ID' => 'ID de Outlook' ,
   'LBL_PHONE' => 'Teléfono:' ,
   'LBL_REMINDER_TIME' => 'Hora de aviso' ,
   'LBL_REMINDER' => 'Aviso:' ,
   'LBL_REMOVE' => 'Quitar' ,
   'LBL_SCHEDULING_FORM_TITLE' => 'Planeación' ,
   'LBL_SEARCH_BUTTON' => 'Búsqueda' ,
   'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de reuniones' ,
   'LBL_SEND_BUTTON_KEY' => 'I' ,
   'LBL_SEND_BUTTON_LABEL' => 'Enviar invitaciones' ,
   'LBL_SEND_BUTTON_TITLE' => 'Enviar invitaciones [Alt+I]' ,
   'LBL_STATUS' => 'Estado:' ,
   'LBL_TYPE' => 'Tipo de reunión' ,
   'LBL_PASSWORD' => 'Contraseña de la reunión' ,
   'LBL_URL' => 'Iniciar/Unirse a una reunión' ,
   'LBL_CREATOR' => 'Creador de reuniones ' ,
   'LBL_EXTERNALID' => 'ID de la aplicación externa' ,
   'LBL_SUBJECT' => 'Asunto:' ,
   'LBL_TIME' => 'Hora de inicio:' ,
   'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios' ,
   'LBL_ACTIVITIES_REPORTS' => 'Reporte de actividad' ,
   'LNK_MEETING_LIST' => 'Reuniones' ,
   'LNK_NEW_APPOINTMENT' => 'Crear cita' ,
   'LNK_NEW_MEETING' => 'Programar reunión' ,
   'LNK_IMPORT_MEETINGS' => 'Importar reuniiones' ,
   'NTC_REMOVE_INVITEE' => '¿Esta seguro que desea quitar a este invitado de la reunión?' ,
   'LBL_CREATED_USER' => 'Usuario creado' ,
   'LBL_MODIFIED_USER' => 'Usuario modificado' ,
   'NOTICE_DURATION_TIME' => 'El tiempo de duración debe ser mayor que 0' ,
   'LBL_MEETING_INFORMATION' => 'Información de la reunión' ,
   'LBL_LIST_JOIN_MEETING' => 'Unirse a la reunión' ,
   'LBL_JOIN_EXT_MEETING' => 'Unirse a la reunión' ,
   'LBL_HOST_EXT_MEETING' => 'Iniciar reunión' ,
   'LBL_EXTNOT_HEADER' => 'Error : no invitado' ,
   'LBL_EXTNOT_MAIN' => 'No le es posible unirse a esta reunión porque no es un invitado' ,
   'LBL_EXTNOT_RECORD_LINK' => 'Ver reunión' ,
   'LBL_EXTNOT_GO_BACK' => 'Volver al registro anterior' ,
   'LBL_EXTNOSTART_HEADER' => 'Error : No se puede iniciar la reunión' ,
   'LBL_EXTNOSTART_MAIN' => 'Usted no puede iniciar esta reunión porque no es un administrador o el propietario de la reunión' );

?>