Varianta in limba romana, pentru SugarCRM versiunea 5.5.1
  Varianta beta.

   raulluarro@gmail.com
   http://microtechnologie.com/