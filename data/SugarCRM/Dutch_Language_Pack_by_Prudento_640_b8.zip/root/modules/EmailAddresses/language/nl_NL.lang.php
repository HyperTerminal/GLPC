<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Copyright (c) 2010 Prudento (http://www.prudento.com)
 * All rights reserved.
 *
 * Permission is granted for use, copying, modification, distribution,
 * and distribution of modified versions of this work as long as the
 * above copyright notice is included.
 */

$mod_strings = array (
'LBL_EMAIL_ADDRESS_ID' => 'ID',
'LBL_EMAIL_ADDRESS' => 'E-mail adres',
'LBL_EMAIL_ADDRESS_CAPS' => 'E-mail adres hoofdletters',
'LBL_INVALID_EMAIL' => 'Ongeldig e-mail',
'LBL_OPT_OUT' => 'Afgemeld',
'LBL_DATE_CREATE' => 'Datum aanmaak',
'LBL_DATE_MODIFIED' => 'Datum gewijzigd op',
'LBL_DELETED' => 'Verwijderen',
);

