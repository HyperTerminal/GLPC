<?PHP 
$manifest = array( 
	'name' => 'Czech',
	'description' => 'Language pack for Czech',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '5.0.0',
	'acceptable_sugar_flavors' => array (),
	'published_date' => '2008-01-15',
	'author' => 'extrasolution.com',
	'acceptable_sugar_versions' => array (),
);

$installdefs = array(
	'id'=> 'cs_cz',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>
