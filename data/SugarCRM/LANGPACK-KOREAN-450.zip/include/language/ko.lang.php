<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.340 2006/07/28 00:15:18 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'language_pack_name' => 'Korean',
  'moduleList' =>
  array (
    'Home' 		=> '슈가CRM홈',
    'Dashboard' 	=> '대시보드',
    'Contacts' 		=> '거래고객관리',
    'Accounts' 		=> '거래처관리',
    'Opportunities' 	=> '안건관리',
    'Cases' 		=> '사례관리',
    'Notes' 		=> '노트',
    'Calls' 			=> '콜관리',
    'Emails' 		=> 'E메일',
    'Meetings' 		=> '미팅',
    'Tasks' 		=> '타스크',
    'Calendar' 		=> '스케쥴관리',
    'Leads' 		=> '리드관리',
    'Activities' 		=> '영업활동관리',
    'Bugs' 		=> '결함관리',
    'Feeds' 		=> 'RSS',
    'iFrames'		=>'My포탈',
    'TimePeriods'	=>'기간',
    'Project'		=>'프로잭트',
    'ProjectTask'	=>'프로젝트타스크',
    'Campaigns'	=>'캠페인',
    'Documents'	=>'자료관리',
    'Sync'			=>'동기',
    'Users' 		=> '유저',
    'Releases' 		=> '릴리즈',    
    'Prospects' 	=> '타켓',
    'Queues' 		=> '작업큐',
    'EmailMarketing' => 'E메일마켓팅',
    'EmailTemplates' => 'E메일템프렛',
    'ProspectLists' 	=> '타켓리스트',
    'SavedSearch' 	=> '검색결과저장',
        ),
  'moduleListSingular' =>
  array (
     'Home' 		=> 'Home',
    'Dashboard' 	=> 'Dashboard',
    'Contacts' 		=> 'Contact',
    'Accounts' 		=> 'Account',
    'Opportunities' 	=> 'Opportunity',
    'Cases' 		=> 'Case',
    'Notes' 		=> 'Note',
    'Calls' 			=> 'Call',
    'Emails' 		=> 'Email',
    'Meetings' 		=> 'Meeting',
    'Tasks' 		=> 'Task',
    'Calendar' 		=> 'Calendar',
    'Leads' 		=> 'Lead',
    'Activities' 		=> 'Activitie',
    'Bugs' 		=> 'Bug Tracker',
    'Feeds' 		=> 'RSS',
    'iFrames'		=>'My Portal',
    'TimePeriods'	=>'Time Period',
    'Project'		=>'Projects',
    'ProjectTask'	=>'Project Task',
    'Campaigns'	=>'Campaigns',
    'Documents'	=>'Documents',
    'Sync'			=>'Sync',
    'Users' 		=> 'User',
        ),        

  'checkbox_dom'=> array(
  	''=>'',
  	'1'=>'Yes',
  	'2'=>'No',
  ),
          
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' =>
  array (
    '' => '',
    'Analyst' 		=> '아날리스트',
    'Competitor' 	=> '경쟁업체',
    'Customer' 		=> '거래처',
    'Integrator' 		=> '시스템설계업체',
    'Investor' 		=> '투자업체',
    'Partner' 		=> '파트너',
    'Press' 		=> '프레스',
    'Prospect' 		=> '잠재거래처',
    'Reseller' 		=> '리세일러',
    'Other' 		=> '기타',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' =>
  array (
    '' => '',
    'Apparel' 			=> '어패럴',
    'Banking' 			=> '뱅킹',
    'Biotechnology' 		=> '바이오테크놀러지',
    'Chemicals' 		=> '화학',
    'Communications' 	=> '통신',
    'Construction' 		=> '건설',
    'Consulting' 		=> '컨설팅',
    'Education' 		=> '교육',
    'Electronics' 		=> '전자',
    'Energy' 			=> '에너지',
    'Engineering' 		=> '엔지니어링',
    'Entertainment' 		=> '흥행',
    'Environmental' 		=> '환경',
    'Finance' 			=> '금융',
    'Government' 		=> '자치구',
    'Healthcare' 		=> '헬스',
    'Hospitality' 		=> '숙박',
    'Insurance' 			=> '보험',
    'Machinery' 		=> '기계',
    'Manufacturing' 		=> '제조',
    'Media' 			=> '메디아',
    'Not For Profit' 		=> '비영리재단',
    'Recreation' 		=> '레크리에이션',
    'Retail' 			=> '소매업',
    'Shipping' 			=> '물류',
    'Technology' 		=> '테크놀로지',
    'Telecommunications' => '전기통신',
    'Transportation' 		=> '운송',
    'Utilities' 			=> '공익사업',
    'Other' 			=> '기타',
  ),
  'source_default_key' => 'Self Generated',
  'lead_source_dom' =>
  array (
    '' => '',
    'Cold Call' 			=> '방문판매',
    'Existing Customer' 	=> '기존거래처',
    'Self Generated' 		=> '자기생성',
    'Employee' 			=> '종업원',
    'Partner' 			=> '파트너',
    'Public Relations' 	=> 'PR',
    'Direct Mail' 		=> 'DM우편',
    'Conference' 		=> '컨퍼런스',
    'Trade Show' 		=> '전시회',
    'Web Site' 			=> '웹사이트',
    'Word of mouth' 	=> '입소문',
    'Email' 			=> 'E메일',
    'Other' 			=> '기타',
  ),
  'opportunity_type_dom' =>
  array (
    '' => '',
    'Existing Business' 	=> '기존비지네스',
    'New Business' 		=> '신규비지네스',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Primary Decision Maker',
    'Business Decision Maker' => 'Business Decision Maker',
    'Business Evaluator' => 'Business Evaluator',
    'Technical Decision Maker' => 'Technical Decision Maker',
    'Technical Evaluator' => 'Technical Evaluator',
    'Executive Sponsor' => 'Executive Sponsor',
    'Influencer' => 'Influencer',
    'Other' => 'Other',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Contact' 	=> '주담당자',
    'Alternate Contact' 	=> '부담당자',
  ),
  'payment_terms' =>
  array (
  	'' => '', 
	'Net 15' => 'Net 15',
	'Net 30' => 'Net 30',
  ),  
  'sales_stage_default_key' => 'Prospecting',
  'sales_stage_dom' =>
  array (
    'Prospecting' 			=> '고객선별',
    'Qualification' 			=> '선별종료',
    'Needs Analysis' 		=> '수요분석',
    'Value Proposition' 		=> '유용성제안',
    'Id. Decision Makers' 		=> '결재자확인',
    'Perception Analysis' 		=> '이해도분석',
    'Proposal/Price Quote' 	=> '제안/견적',
    'Negotiation/Review' 		=> '최종교섭중',
    'Closed Won' 			=> '수주종료',
    'Closed Lost' 			=> '수주실패',
  ),
  'sales_probability_dom' => // keys must be the same as sales_stage_dom
  array (
    'Prospecting' 			=> '10',
    'Qualification' 			=> '20',
    'Needs Analysis' 		=> '25',
    'Value Proposition' 		=> '30',
    'Id. Decision Makers' 		=> '40',
    'Perception Analysis' 		=> '50',
    'Proposal/Price Quote' 	=> '65',
    'Negotiation/Review' 		=> '80',
    'Closed Won' 			=> '100',
    'Closed Lost' 			=> '0',
  ),
  'activity_dom' =>
  array (
    'Call' 		=> '콜',
    'Meeting' 	=> '미팅',
    'Task' 		=> '타스크',
    'Email' 	=> 'E메일',
    'Note' 		=> '노트',
  ),
  'salutation_dom' =>
  array (
    '' => '',
    'Mr.' 	=> 'Mister.',
    'Ms.' 	=> 'Missus.',
    'Mrs.' => 'Missurs.',
    'Dr.' 	=> 'Doctor.',
    'Prof.' => 'Professor.',
  ),
  //time is in seconds; the greater the time the longer it takes;
  'reminder_max_time'=>3600,
  'reminder_time_options' => 
  array( 
	  	60		=> '1 분전',
  		300		=> '5 분전',
  		600		=> '10 분전',
  		900		=> '15 분전',
  		1800		=> '30 분전',
  		3600		=> '1 시간전',
	 ),

  'task_priority_default' => 'Medium',
  'task_priority_dom' =>
  array (
    'High' 		=> '고',
    'Medium' 	=> '중',
    'Low' 		=> '저',
  ),
  'task_status_default' => 'Not Started',
  'task_status_dom' =>
  array (
    'Not Started' 	=> '미개시',
    'In Progress' 	=> '진행중',
    'Completed' 	=> '완료',
    'Pending Input' 	=> '회답대기',
    'Deferred' 		=> '연기',
  ),
  'meeting_status_default' => 'Planned',
  'meeting_status_dom' =>
  array (
    'Planned' 	=> '계획',
    'Held' 		=> '실시',
    'Not Held' 	=> '미실시',
  ),
  'call_status_default' => 'Planned',
  'call_status_dom' =>
  array (
    'Planned' 	=> '계획',
    'Held' 		=> '실시',
    'Not Held' 	=> '미실시',
  ),
  'call_direction_default' => 'Outbound',
  'call_direction_dom' =>
  array (
    'Inbound' 		=> '인바운드',
    'Outbound' 		=> '아웃바운드',
  ),
  'lead_status_dom' =>
  array (
    '' => '',
    'New' 			=> '신규',
    'Assigned' 		=> '할당됨',
    'In Process' 	=> '처리중',
    'Converted' 	=> '컨버트됨',
    'Recycled' 		=> '처음으로',
    'Dead' 		=> '무효처리',
  ),
  'lead_status_noblank_dom' =>
  array (
    'New' 			=> '신규',
    'Assigned' 		=> '할당',
    'In Process' 	=> '진행중',
    'Converted' 	=> '컨버트됨',
    'Recycled' 		=> '처음으로',
    'Dead' 		=> '무효처리',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' =>
  array (
    'New' 			=> '신규',
    'Assigned' 		=> '할당',
    'Closed' 		=> '완료',
    'Pending Input' 	=> '계획중',
    'Rejected' 		=> '리젝트',
    'Duplicate' 		=> '복사',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' =>
  array (
    'P1' => '고',
    'P2' => '중',
    'P3' => '저',
  ),
  'user_status_dom' =>
  array (
    'Active' 	=> '활동중',
    'Inactive' 	=> '비활동',
  ),
  'employee_status_dom' =>
  array (
    'Active' 			=> '활동중',
    'Terminated' 		=> '퇴직',
    'Leave of Absence' 	=> '휴직',
  ),
  'messenger_type_dom' =>
  array (
    '' => '',
    'MSN' 	=> 'MSN',
    'Yahoo!' 	=> 'Yahoo!',
    'AOL' 		=> 'AOL',
  ),

	'project_task_priority_options' => array (
		'High' 	=> '고',
		'Medium' => '중',
		'Low' 	=> '저',
	),
	'project_task_status_options' => array (
		'Not Started' 		=> '시작전',
		'In Progress' 		=> '진행중',
		'Completed' 		=> '완료',
		'Pending Input' 	=> '보류',
		'Deferred' 		=> '연기',
	),
	'project_task_utilization_options' => array (
		'0' 		=> 'none',
		'25' 		=> '25',
		'50' 		=> '50',
		'75' 		=> '75',
		'100' 	=> '100',
	),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' =>
  array (
    'Accounts' 	=> 'Account',
    'Opportunities' 	=> 'Opportunity',
    'Cases' 		=> 'Case',
    'Leads' 		=> 'Lead',
    'Contacts' 		=> 'Contacts', // cn (11/22/2005) added to support Emails
    'Bugs' 		=> 'Bug',
    'Project' 		=> 'Project',
    'ProjectTask' 	=> 'Project Task',
    'Tasks' 		=> 'Task',
  ),

  'record_type_display_notes' =>
  array (
    'Accounts' 	=> 'Account',
    'Contacts' 		=> 'Contact',
    'Opportunities' 	=> 'Opportunity',
    'Cases' 		=> 'Case',
    'Leads' 		=> 'Lead',
    'Bugs' 		=> 'Bug',
    'Emails' 		=> 'Email',
    'Project' 		=> 'Project',
    'ProjectTask' 	=> 'Project Task',
    'Meetings' 		=> 'Meeting',
    'Calls' 			=> 'Call'
  ),

  'quote_type_dom' =>
  array (
    'Quotes' 	=> '견적',
    'Orders' 	=> '주문',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' =>
  array (
    'Draft' 				=> '드래프트',
    'Negotiation' 		=> '교섭중',
    'Delivered' 			=> '출하완료',
    'On Hold' 			=> '출하홀딩',
    'Confirmed' 		=> '확인완료',
    'Closed Accepted' 	=> '수령완료',
    'Closed Lost' 		=> '손해처리완료',
    'Closed Dead' 		=> '무효처리완료',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' =>
  array (
    'Pending' 		=> '보류',
    'Confirmed' 	=> '확인',
    'On Hold' 		=> '출하대기',
    'Shipped' 		=> '출하완료',
    'Cancelled' 	=> '취소완료',
  ),

//Note:  do not translate quote_relationship_type_default_key
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' 		=> '주결재자',
    'Business Decision Maker' 	=> '비지네스결재자',
    'Business Evaluator' 			=> '비지네스평가자',
    'Technical Decision Maker' 	=> '기술계결재자',
    'Technical Evaluator' 			=> '기술계평가자',
    'Executive Sponsor' 			=> '중요스폰사',
    'Influencer' 					=> '영향력행사자',
    'Other' 					=> '기타',
  ),
  'layouts_dom' =>
  array (
    'Standard' 		=> '견적서',
    'Invoice' 		=> '청구서',
    'Terms' 		=> '지불조건'
  ),

  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' =>
  array (
    'Urgent' 		=> '긴급',
    'High' 			=> '고',
    'Medium' 		=> '중',
    'Low' 			=> '저',
  ),
   'bug_resolution_default_key' => '',
  'bug_resolution_dom' =>
  array (
  	'' => '',
    'Accepted' 		=> '접수완료',
    'Duplicate' 		=> '복사',
    'Fixed' 		=> '수정완료',
    'Out of Date' 	=> '기간만료',
    'Invalid' 		=> '무효',
    'Later' 		=> '추후처리',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' =>
  array (
    'New' 			=> '신규',
    'Assigned' 		=> '할당',
    'Closed' 		=> '종료',
    'Pending' 		=> '보류중',
    'Rejected' 		=> '거부',
  ),
   'bug_type_default_key' => 'Bug',
  'bug_type_dom' =>
  array (
    'Defect' 	=> '결함',
    'Feature' 	=> '사양',
  ),

  'source_default_key' => '',
  'source_dom' =>
  array (
	'' => '',
  	'Internal' 			=> '내부',
  	'Forum' 			=> '포럼',
  	'Web' 			=> '웹',
  	'InboundEmail' 	=> 'E메일'
  ),

  'product_category_default_key' => '',
  'product_category_dom' =>
  array (
	'' => '',
  	'Accounts' 		=> 'Accounts',
  	'Activities' 		=> 'Activities',
  	'Bug Tracker' 		=> 'Bug Tracker',
  	'Calendar' 		=> 'Calendar',
  	'Calls' 			=> 'Calls',
  	'Campaigns' 		=> 'Campaigns',  	
  	'Cases' 			=> 'Cases',
  	'Contacts' 		=> 'Contacts',
  	'Currencies' 		=> 'Currencies',
  	'Dashboard' 		=> 'Dashboard',
  	'Documents' 		=> 'Documents',
  	'Emails' 			=> 'Emails',
  	'Feeds' 			=> 'Feeds',
  	'Forecasts' 		=> 'Forecasts',  	
  	'Help' 			=> 'Help',
  	'Home' 			=> 'Home',
  	'Leads' 			=> 'Leads',
  	'Meetings' 		=> 'Meetings',
  	'Notes' 			=> 'Notes',
  	'Opportunities' 	=> 'Opportunities',
  	'Outlook Plugin' 	=> 'Outlook Plugin',
  	'Product Catalog' 	=> 'Product Catalog',  	
  	'Products' 		=> 'Products',  	
  	'Projects' 		=> 'Projects',  	
  	'Quotes' 			=> 'Quotes',
  	'Releases' 		=> 'Releases',
  	'RSS' 			=> 'RSS',
  	'Studio' 			=> 'Studio',
  	'Upgrade' 		=> 'Upgrade',
  	'Users' 			=> 'Users',
  ),

  /*Added entries 'Queued' and 'Sending' for 4.0 release..*/
  'campaign_status_dom' =>
  array (
    	'' => '',
        'Planning' 	=> '계획중',
        'Active' 		=> '활동중',
        'Inactive' 	=> '비활동',
        'Complete' 	=> '완료',
        'In Queue' 	=> '대기중',
        'Sending'	=> '송신',
  ),
  'campaign_type_dom' =>
  array (
        '' => '',
        'Telesales' => '전화영업',
        'Mail' => 'DM우편',
        'Email' => 'E메일',
        'Print' => '우편물',
        'Web' => '웹',
        'Radio' => '라디오',
        'Television' => '텔레비젼',
        ),
  'notifymail_sendtype' =>
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => 
  array(   '-12'=>'(GMT - 12) International Date Line West',
  		'-11'=>'(GMT - 11) Midway Island, Samoa',
  		'-10'=>'(GMT - 10) Hawaii',
  		'-9'=>'(GMT - 9) Alaska',
  		'-8'=>'(GMT - 8) San Francisco',
  		'-7'=>'(GMT - 7) Phoenix',
  		'-6'=>'(GMT - 6) Saskatchewan',
  		'-5'=>'(GMT - 5) New York',
  		'-4'=>'(GMT - 4) Santiago',
  		'-3'=>'(GMT - 3) Buenos Aires',
  		'-2'=>'(GMT - 2) Mid-Atlantic',
  		'-1'=>'(GMT - 1) Azores',
  		'0'=>'(GMT)',
  		'1'=>'(GMT + 1) Madrid',
  		'2'=>'(GMT + 2) Athens',
  		'3'=>'(GMT + 3) Moscow',
  		'4'=>'(GMT + 4) Kabul',
  		'5'=>'(GMT + 5) Ekaterinburg',
  		'6'=>'(GMT + 6) Astana',
  		'7'=>'(GMT + 7) Bangkok',
  		'8'=>'(GMT + 8) Perth',
  		'9'=>'(GMT + 9) Seol',
  		'10'=>'(GMT + 10) Brisbane',
  		'11'=>'(GMT + 11) Solomone Is.',
  		'12'=>'(GMT + 12) Auckland',
  		),
      'dom_cal_month_long'=>array(
                '0'=>"",
                '1'=>"1월",
                '2'=>"2월",
                '3'=>"3월",
                '4'=>"4월",
                '5'=>"5월",
                '6'=>"6월",
                '7'=>"7월",
                '8'=>"8월",
                '9'=>"9월",
                '10'=>"10월",
                '11'=>"11월",
                '12'=>"12월",
        ),

        'dom_report_types'=>array(
                'tabular'				=>'표형식레포트',
                'summary'			=>'요약레포트',
                'detailed_summary'	=>'상세레포트',
        ),
	'dom_email_types'	=> array(
		'out'			=> '송신',
		'archived'	=> '저장',
		'draft'		=> '드래프트',
		'inbound'		=> '인바운드',
	),
	'dom_email_status' => array (
		'archived'		=> '저장',
		'closed'		=> '종료',
		'draft'		=> '드래프트',
		'read'		=> '읽음',
		'replied'		=> '회신',
		'sent'		=> '송신',
		'send_error'	=> '송신에라',
		'unread'		=> '안읽음',
	),
		
	'dom_email_server_type' => array(	
		''			=> '--None--',
		'imap'		=> 'IMAP',
		'pop3'		=> 'POP3',
	),
	'dom_mailbox_type'	=> array(/*''			=> '--None Specified--',*/
		'pick'	=> '작성 [임의]',
		'bug'	=> '결함작성',
		'support'	=> '사례작성',
		'contact' => '고객작성',
		'sales'	=> '리드작성',
		'task'	=> '타스크작성',
		'bounce'	=> '바운드처리',
	),
	'dom_email_distribution'=> array(
		''			=> '--None--',
		'direct'		=> '직접할당',
		'roundRobin'	=> '회람형식',
		'leastBusy'	=> '최소관련',
	),
	'dom_email_errors'		=> array(
		1 => 'Only select one user when Direct Assigning items.',
		2 => 'You must assign Only Checked Items when Direct Assigning items.',
	),
	'dom_email_bool'		=> array(
		'bool_true' => 'Yes',
		'bool_false' => 'No',
	),
	'dom_int_bool'			=> array(
		1 => 'Yes',
		0 => 'No',
	),
	'dom_switch_bool'		=> array (
		'on' => 'Yes',
		'off' => 'No',
		''	=> 'No', 
	),
	'dom_email_link_type'	=> array(	
		''			=> 'System Default Mail Client',
		'sugar'		=> 'SugarCRM Mail Client',
		'mailto'		=> 'External Mail Client',
	),
	'dom_email_editor_option'=> array(	
		''			=> 'Default Email Format',
		'html'		=> 'HTML Email',
		'plain'		=> 'Plain Text Email'),

	
	'schedulers_times_dom'	=> array(	
		'not run'		=> 'Past Run Time, Not Executed',
		'ready'		=> 'Ready',
		'in progress'	=> 'In Progress',
		'failed'		=> 'Failed',
		'completed'	=> 'Completed',
		'no curl'		=> 'Not Run: No cURL available',
	),

	'forecast_schedule_status_dom' =>
  	array (
    		'Active' => 'Active',
    		'Inactive' => 'Inactive',
  	),
	'forecast_type_dom' =>
  	array (
    		'Direct' => 'Direct',
    		'Rollup' => 'Rollup',
  	),  
	
	'document_category_dom' =>
  	array (
  		'' => '',
    		'Marketing' => 'Marketing',
    		'Knowledege Base' => 'Knowledge Base',
    		'Sales' => 'Sales',    
  	),  

	'document_subcategory_dom' =>
  	array (
  		'' => '',
    		'Marketing Collateral' => 'Marketing Collateral',
    		'Product Brochures' => 'Product Brochures',
		'FAQ' => 'FAQ',
  	),  
  
  'document_status_dom' =>
  	array (
 	'Active' 			=> '활동',
	'Draft' 			=> '드래프트',
	'FAQ' 			=> 'FAQ',
	'Expired' 			=> 'Expired',
	'Under Review' 	=> '심사중',
	'Pending' 		=> '보류',
  ),
  'document_template_type_dom' =>
  array(
  	''=>'',
  	'mailmerge'	=>'Mail Merge',
  	'eula'		=>'EULA',
  	'nda'		=>'NDA',
  	'license'		=>'License Agreement',
  ),
	'dom_meeting_accept_options' =>
  	array (
	'accept' 		=> '허가',
	'decline' 		=> '거부',
	'tentative' 	=> '예정',
  ),
	'dom_meeting_accept_status' =>
  	array (
	'accept' 		=> '허가',
	'decline' 		=> '거부',
	'tentative' 	=> '예정',
	'none'		=> '없음',
  ),

// deferred
/*
// QUEUES MODULE DOMs
'queue_type_dom' => array(
	'Users' => 'Users',
	'Mailbox' => 'Mailbox',
),		   
*/

//prospect list type dom
  'prospect_list_type_dom' =>
  array (
    'default' 			=> '초기값',
    'seed' 				=> '시드데이타',
    'exempt_domain' 	=> '금지리스트 - 도메인',
    'exempt_address' 	=> '금지리스트 - E메일주소',
    'exempt' 			=> '금지리스트 - ID',
    'test' 				=> '테스트',
  ),
  
  'email_marketing_status_dom' => 
  array (
  	'' => '',
  	'active'=>'활동중',
  	'inactive'=>'비활동'
  ),

  'campainglog_activity_type_dom' =>
  array (
  	''=>'',
    'targeted' 		=> '송부/시행회수',
    'send error'	=>'송신에라,기타',
    'invalid email'	=>'송신에라,부정E메일',
    'link'			=>'링크클릭',
    'viewed'		=>'화면보기완료',
    'removed'		=>'삭제완료',
    'lead'			=>'리드작성완료',
    'contact'		=>'거래처담당작성완료',        
  ),

  'campainglog_target_type_dom' =>
  array (
    'Contacts' 		=>'고객',
    'Users'		=>'유저',
    'Prospects'		=>'타켓',
    'Leads'		=>'리드',
  ),
  
  'merge_operators_dom' => array (
    'like'		=>'Contains',
    'exact'		=>'Exactly',
    'start'		=>'Starts With',
  ),

  'custom_fields_merge_dup_dom'=> array (
        0	=>'Disabled',
        1	=>'Enabled',
        2	=>'In Filter',
        3	=>'Default Selected Filter',
  ),
  'navigation_paradigms' => array(
        'gm'=>'Grouped Modules',
        'm'=>'Modules'
  ),

);

$app_strings = array (
	
	'ERR_CREATING_FIELDS' => 'Error filling in additional detail fields: ',
	'ERR_CREATING_TABLE' => 'Error creating table: ',
	'ERR_DELETE_RECORD' => 'A record number must be specified to delete the contact.',
	'ERR_EXPORT_DISABLED' => 'Exports Disabled.',
	'ERR_EXPORT_TYPE' => 'Error exporting ',
	'ERR_INVALID_AMOUNT' => 'Please enter a valid amount.',
	'ERR_INVALID_DATE_FORMAT' => 'The date format must be: ',
	'ERR_INVALID_DATE' => 'Please enter a valid date.',
	'ERR_INVALID_DAY' => 'Please enter a valid day.',
	'ERR_INVALID_EMAIL_ADDRESS' => 'not a valid email address.',
	'ERR_INVALID_HOUR' => 'Please enter a valid hour.',
	'ERR_INVALID_MONTH' => 'Please enter a valid month.',
	'ERR_INVALID_TIME' => 'Please enter a valid time.',
	'ERR_INVALID_YEAR' => 'Please enter a valid 4 digit year.',
	'ERR_NEED_ACTIVE_SESSION' => 'An active session is required to export content.',
	'ERR_NOT_ADMIN' => "Unauthorized access to administration.",
	'ERR_MISSING_REQUIRED_FIELDS' => 'Missing required field:',
    	'ERR_MISSING_CUSTOM_DELIMITER' => 'Must specify a custom delimiter.',    
	'ERR_INVALID_VALUE' => 'Invalid Value:',
	'ERR_NOTHING_SELECTED' =>'Please make a selection before proceeding.',
	'ERR_OPPORTUNITY_NAME_DUPE' => 'An opportunity with the name %s already exists.  Please enter another name below.',
	'ERR_OPPORTUNITY_NAME_MISSING' => 'An opportunity name was not entered.  Please enter an opportunity name below.',
	'ERR_SELF_REPORTING' => 'User cannot report to him or herself.',
	'ERR_SQS_NO_MATCH_FIELD' => 'No match for field: ',
	'ERR_SQS_NO_MATCH' =>'No Match',
	'ERR_POTENTIAL_SEGFAULT' => 'A potential Apache segmentation fault was detected.  Please notify your system administrator to confirm this problem and have her/him report it to SugarCRM.',
	
	'LBL_ACCOUNT'=>'거래처',
	'LBL_ACCOUNTS'=>'거래처',
	'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
	'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => '요약표시',
	'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => '요약표시[Alt+H]',
	'LBL_ADD_BUTTON_KEY' => 'A',
	'LBL_ADD_BUTTON_TITLE' => '추가 [Alt+A]',
	'LBL_ADD_BUTTON' => '추가',
	'LBL_ADD_DOCUMENT' => '자료추가',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => '타켓리스트추가',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE' => '타켓리스트추가',
	'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => '클릭에의한종료',
	'LBL_ADDITIONAL_DETAILS_CLOSE' => '종료',
	'LBL_ADDITIONAL_DETAILS' => '상세추가',
	'LBL_ADMIN' => '관리화면',
	'LBL_ALT_HOT_KEY' => 'Alt+',
	'LBL_ARCHIVE' => 'Archive',
	'LBL_ASSIGNED_TO_USER'=>'할당유저',
	'LBL_ASSIGNED_TO' => '할당:',
	'LBL_BACK' => '이전',
	'LBL_BILL_TO_ACCOUNT'=>'청구된거래처',
	'LBL_BILL_TO_CONTACT'=>'청구된고객',
	'LBL_BROWSER_TITLE' => 'SugarCRM  한글버전 - Commercial Open Source CRM',
	'LBL_BUGS'=>'결함정보',
	'LBL_BY' => 'by',
	'LBL_CALLS'=>'콜',
	'LBL_CAMPAIGNS_SEND_QUEUED' => '큐에의한 캠페인메일 송신',
	'LBL_CANCEL_BUTTON_KEY' => 'X',
	'LBL_CANCEL_BUTTON_LABEL' => '취소',
	'LBL_CANCEL_BUTTON_TITLE' => '취소 [Alt+X]',
	'LBL_CASE'=>'사례',
	'LBL_CASES'=>'사례',
	'LBL_CHANGE_BUTTON_KEY' => 'G',
	'LBL_CHANGE_BUTTON_LABEL' => '변경',
	'LBL_CHANGE_BUTTON_TITLE' => '변경[Alt+G]',
	'LBL_CHARSET' => 'UTF-8',
	'LBL_CHECKALL' => '전부체크',
	'LBL_CLEAR_BUTTON_KEY' => 'C',
	'LBL_CLEAR_BUTTON_LABEL' => '지우기',
	'LBL_CLEAR_BUTTON_TITLE' => '지우기[Alt+C]',
	'LBL_CLEARALL' => '전부지우기',
	'LBL_CLOSE_WINDOW'=>'윈도우종료',
	'LBL_CLOSEALL_BUTTON_KEY' => 'Q',
	'LBL_CLOSEALL_BUTTON_LABEL' => '전부종료',
	'LBL_CLOSEALL_BUTTON_TITLE' => '전부종료 [Alt+I]',
    	'LBL_CLOSE_AND_CREATE_BUTTON_LABEL' => '종료후신규작성',
    	'LBL_CLOSE_AND_CREATE_BUTTON_TITLE' => '종료후신규작성 [Alt+C]',
    	'LBL_CLOSE_AND_CREATE_BUTTON_KEY' => 'C',    
	'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
	'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'E메일작성',
	'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'E메일작성[Alt+L]',
	'LBL_CONTACT_LIST' => '거래고객리스트',
	'LBL_CONTACT'=>'거래고객',
	'LBL_CONTACTS'=>'거래고객',
	'LBL_CREATE_BUTTON_LABEL' => '신규작성',
	'LBL_CREATED_BY_USER'=>'작성자',
	'LBL_CREATED' => '작성자',
	'LBL_CURRENT_USER_FILTER' => 'My 아이템:',
	'LBL_DATE_ENTERED' => '작성일:',
	'LBL_DATE_MODIFIED' => '최후변경일:',
	'LBL_DELETE_BUTTON_KEY' => 'D',
	'LBL_DELETE_BUTTON_LABEL' => '삭제',
	'LBL_DELETE_BUTTON_TITLE' => '삭제[Alt+D]',
	'LBL_DELETE_BUTTON' => '삭제',
	'LBL_DELETE' => '삭제',
	'LBL_DELETED'=>'삭제',
	'LBL_DIRECT_REPORTS'=>'직속상관',
	'LBL_DONE_BUTTON_KEY' => 'X',
	'LBL_DONE_BUTTON_LABEL' => 'Done',
	'LBL_DONE_BUTTON_TITLE' => 'Done [Alt+X]',
	'LBL_DST_NEEDS_FIXIN' => 'The application requires a Daylight Saving Time fix to be applied.  Please go to the <a href="index.php?module=Administration&action=DstFix">Repair</a> link in the Admin console and apply the Daylight Saving Time fix.',
	'LBL_DUPLICATE_BUTTON_KEY' => 'U',
	'LBL_DUPLICATE_BUTTON_LABEL' => '복제',
	'LBL_DUPLICATE_BUTTON_TITLE' => '복제 [Alt+U]',
	'LBL_DUPLICATE_BUTTON' => '복제',
	'LBL_EDIT_BUTTON_KEY' => 'E',
	'LBL_EDIT_BUTTON_LABEL' => '편집',
	'LBL_EDIT_BUTTON_TITLE' => '편집 [Alt+E]',
	'LBL_EDIT_BUTTON' => '편집',
	'LBL_VIEW_BUTTON_KEY' => 'V',
	'LBL_VIEW_BUTTON_LABEL' => '화면',
	'LBL_VIEW_BUTTON_TITLE' => '화면[Alt+V]',
	'LBL_VIEW_BUTTON' => '화면',
	'LBL_EMAIL_PDF_BUTTON_KEY' => 'M',
	'LBL_EMAIL_PDF_BUTTON_LABEL' => 'PDF메일출력',
	'LBL_EMAIL_PDF_BUTTON_TITLE' => 'PDF메일출력 [Alt+M]',
	'LBL_EMAILS'=>'E메일',
	'LBL_EMPLOYEES' => '종업원',
	'LBL_ENTER_DATE' => '작성일',
	'LBL_EXPORT_ALL' => '전부내보내기',
	'LBL_EXPORT' => '내보내기',
	'LBL_HIDE'=>'비표시',
	'LBL_ID'=>'ID',
	'LBL_IMPORT_PROSPECTS'=>'타켓읽어들이기',
	'LBL_IMPORT' => '읽어들이기',
    	'LBL_IMPORT_STARTED' => '읽어들이기 시작: ',    
	'LBL_LAST_VIEWED' => '이전에본화면',
	'LBL_LEADS'=>'리드',
	
	'LBL_LIST_ACCOUNT_NAME' => '거래처명',
	'LBL_LIST_ASSIGNED_USER' => '유저',
	'LBL_LIST_CONTACT_NAME' => '거래담당자명',
	'LBL_LIST_CONTACT_ROLE' => '거래담당자역활',
	'LBL_LIST_EMAIL' => 'E메일',
	'LBL_LIST_NAME' => '리스트명',
	'LBL_LIST_OF' => '의',
	'LBL_LIST_PHONE' => '전화',
	'LBL_LIST_USER_NAME' => '유저명',
	'LBL_LISTVIEW_MASS_UPDATE_CONFIRM' => 'Are you sure you want to update the entire list?',
	'LBL_LISTVIEW_NO_SELECTED' => 'Please select at least 1 record to proceed.',
    	'LBL_LISTVIEW_TWO_REQUIRED' => 'Please select at least 2 records to proceed.',    
	'LBL_LISTVIEW_OPTION_CURRENT' => '현재페이지',
	'LBL_LISTVIEW_OPTION_ENTIRE' => '전리스트',
	'LBL_LISTVIEW_OPTION_SELECTED' => '선택레코드',
	'LBL_LISTVIEW_SELECTED_OBJECTS' => '선택: ',
	
	'LBL_LOCALE_NAME_EXAMPLE_FIRST' => '종근',
	'LBL_LOCALE_NAME_EXAMPLE_LAST' => '윤',
	'LBL_LOCALE_NAME_EXAMPLE_SALUTATION' => 'Mr.',
	'LBL_LOGOUT' => '로그아웃',
	'LBL_MAILMERGE_KEY' => 'M',
	'LBL_MAILMERGE' => 'Mail Merge',
	'LBL_MASS_UPDATE' => '일괄 변경',
	'LBL_MEETINGS'=>'미팅',
	'LBL_MEMBERS'=>'멤버',
	'LBL_MODIFIED_BY_USER'=>'변경유저',
	'LBL_MODIFIED' => '편집자',
	'LBL_MY_ACCOUNT' => '유저설정',
	'LBL_NAME' => '명칭',
	'LBL_NEW_BUTTON_KEY' => 'N',
	'LBL_NEW_BUTTON_LABEL' => '작성',
	'LBL_NEW_BUTTON_TITLE' => '작성[Alt+N]',
	'LBL_NEXT_BUTTON_LABEL' => '다음',
	'LBL_NONE' => '--None--',
	'LBL_NOTES'=>'노트',
	'LBL_OPENALL_BUTTON_KEY' => 'O',
	'LBL_OPENALL_BUTTON_LABEL' => '전부오픈',
	'LBL_OPENALL_BUTTON_TITLE' => '전부오픈[Alt+O]',
	'LBL_OPENTO_BUTTON_KEY' => 'T',
	'LBL_OPENTO_BUTTON_LABEL' => '오픈: ',
	'LBL_OPENTO_BUTTON_TITLE' => '오픈: [Alt+T]',
	'LBL_OPPORTUNITIES'=>'안건',
	'LBL_OPPORTUNITY_NAME' => '안건명',
	'LBL_OPPORTUNITY'=>'안건',
	'LBL_OR' => 'OR',
	'LBL_PERCENTAGE_SYMBOL' => '%',
	'LBL_PRODUCT_BUNDLES'=>'제품번들',
	'LBL_PRODUCT_BUNDLES'=>'제품번들',
	'LBL_PRODUCTS'=>'제품',
	'LBL_PROJECT_TASKS'=>'프로젝트타스크',
	'LBL_PROJECTS'=>'프로젝트',
	'LBL_PROJECTS'=>'프로젝트',
	'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
	'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => '견적에의한안건작성',
	'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => '견적에의한안건작성 [Alt+O]',
	'LBL_QUOTES_SHIP_TO'=>'견적제출처',
	'LBL_QUOTES'=>'견적',
	'LBL_RELATED_RECORDS' => '관련레코드',
	'LBL_REMOVE' => '삭제',
	'LBL_REQUIRED_SYMBOL' => '*',
	'LBL_SAVE_BUTTON_KEY' => 'S',
	'LBL_SAVE_BUTTON_LABEL' => '저장',
	'LBL_SAVE_BUTTON_TITLE' => '저장[Alt+S]',
    	'LBL_FULL_FORM_BUTTON_KEY' => 'F',
    	'LBL_FULL_FORM_BUTTON_LABEL' => '전화면',
    	'LBL_FULL_FORM_BUTTON_TITLE' => '전화면[Alt+F]',
	'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
	'LBL_SAVE_NEW_BUTTON_LABEL' => '저장 & 신규작성',
	'LBL_SAVE_NEW_BUTTON_TITLE' => '저장 & 신규작성[Alt+V]',
	'LBL_SEARCH_BUTTON_KEY' => 'Q',
	'LBL_SEARCH_BUTTON_LABEL' => '검색',
	'LBL_SEARCH_BUTTON_TITLE' => '검색[Alt+Q]',
	'LBL_SEARCH' => '검색',
	'LBL_SELECT_BUTTON_KEY' => 'T',
	'LBL_SELECT_BUTTON_LABEL' => '선택',
	'LBL_SELECT_BUTTON_TITLE' => '선택[Alt+T]',
	'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
	'LBL_SELECT_CONTACT_BUTTON_LABEL' => '담당선택',
	'LBL_SELECT_CONTACT_BUTTON_TITLE' => '담당선택[Alt+T]',
	'LBL_SELECT_REPORTS_BUTTON_LABEL' => '레포트선택',
	'LBL_SELECT_REPORTS_BUTTON_TITLE' => '레포트 선택',
	'LBL_SELECT_USER_BUTTON_KEY' => 'U',
	'LBL_SELECT_USER_BUTTON_LABEL' => '유저 선택',
	'LBL_SELECT_USER_BUTTON_TITLE' => '유저 선택[Alt+U]',
	'LBL_SERVER_RESPONSE_RESOURCES' => 'Resources used to construct this page (queries, files)',
	'LBL_SERVER_RESPONSE_TIME_SECONDS' => '초.',
	'LBL_SERVER_RESPONSE_TIME' => '서버응답시간:',
	'LBL_SHIP_TO_ACCOUNT'=>'거래처에납품',
	'LBL_SHIP_TO_CONTACT'=>'담당자에게납품',
	'LBL_SHORTCUTS' => '메뉴',
	'LBL_SHOW'=>'보기',
	'LBL_SQS_INDICATOR' => '',
	'LBL_STATUS_UPDATED'=>'이이벤트에의해스테타스가변경되었습니다!',
	'LBL_STATUS'=>'상태:',
	'LBL_SUBJECT' => '제목',
	'LBL_SYNC' => '동기',
	'LBL_SYNC' => '동기',

    'LBL_TABGROUP_ALL' => 'All',
    'LBL_TABGROUP_ACTIVITIES' => '영업관리',
    'LBL_TABGROUP_COLLABORATION' => '협업관리',
    'LBL_TABGROUP_HOME' => '슈가CRM',
    'LBL_TABGROUP_MARKETING' => '마켓팅관리',
    'LBL_TABGROUP_OTHER' => '기타',
    'LBL_TABGROUP_REPORTS' => '레포트',
    'LBL_TABGROUP_SALES' => '영업관리',
    'LBL_TABGROUP_SUPPORT' => '서포트관리',
    'LBL_TABGROUP_TOOLS' => '도구',

	'LBL_TASKS'=>'타스크',
	'LBL_TEAMS_LINK'=>'팀',
	'LBL_THOUSANDS_SYMBOL' => 'K',
	'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
	'LBL_TRACK_EMAIL_BUTTON_LABEL' => '메일저장',
	'LBL_TRACK_EMAIL_BUTTON_TITLE' => '메일저장[Alt+K]',
	'LBL_UNAUTH_ADMIN' => 'Unauthorized access to administration',
	'LBL_UNDELETE_BUTTON_LABEL' => '삭제취소',
	'LBL_UNDELETE_BUTTON_TITLE' => '삭제취소 [Alt+D]',
	'LBL_UNDELETE_BUTTON' => '삭제취소',
	'LBL_UNDELETE' => '삭제취소',
	'LBL_UNSYNC' => '비동기',
	'LBL_UPDATE' => '변경',
	'LBL_USER_LIST' => '유저리스트',
	'LBL_USERS_SYNC'=>'유저 동기',
	'LBL_USERS'=>'유저',
	'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
	'LBL_VIEW_PDF_BUTTON_LABEL' => 'PDF출력',
	'LBL_VIEW_PDF_BUTTON_TITLE' => 'PDF출력 [Alt+P]',
	
	'LNK_ABOUT' => '사이트정보',
	'LNK_ADVANCED_SEARCH' => '고급 검색',
	'LNK_BASIC_SEARCH' => '기본 검색',
    	'LNK_SAVED_VIEWS' => '검색 & 레이아웃 저장',
	'LNK_DELETE_ALL' => '전부삭제', 
	'LNK_DELETE' => '삭제',
	'LNK_EDIT' => '편집',
	'LNK_GET_LATEST'=>'최신으로',
	'LNK_GET_LATEST_TOOLTIP'=>'최신버전으로',
	'LNK_HELP' => '도움말',
	'LNK_LIST_END' => '최후',
	'LNK_LIST_NEXT' => '다음',
	'LNK_LIST_PREVIOUS' => '이전',
	'LNK_LIST_RETURN' => '리스트표시',
	'LNK_LIST_START' => '최초',
	'LNK_LOAD_SIGNED'=>'사인',
	'LNK_LOAD_SIGNED_TOOLTIP'=>'Replace with signed document',
	'LNK_PRINT' => '프린트',
	'LNK_REMOVE' => '삭제',
	'LNK_RESUME' => '이전',
	'LNK_VIEW_CHANGE_LOG' => '화면변경로그',
	
	'NTC_CLICK_BACK' => 'Please click the browser back button and fix the error.',
	'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
	'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
	'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Are you sure you want to delete selected record(s)?',
	'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
	'NTC_LOGIN_MESSAGE' => 'Please enter your username and password.',
	'NTC_NO_ITEMS_DISPLAY' => 'none',
	'NTC_REMOVE_CONFIRMATION' => 'Are you sure you want to remove this relationship?',
	'NTC_REQUIRED' => 'Indicates required field',
	'NTC_SUPPORT_SUGARCRM' => 'Support the SugarCRM open source project with a donation through PayPal - it\'s fast, free and secure!',
	'NTC_TIME_FORMAT' => '(24:00)',
	'NTC_WELCOME' => '환영합니다:',
	'NTC_YEAR_FORMAT' => '(yyyy)',
	'LOGIN_LOGO_ERROR'=> 'Please replace the SugarCRM logos.',
	'ERROR_FULLY_EXPIRED'=> "Your company's license for SugarCRM has expired for more than 30 days and needs to be brought up to date. Only admins may login.",
	'ERROR_LICENSE_EXPIRED'=> "Your company's license for SugarCRM needs to be updated. Only admins may login",
	'ERROR_LICENSE_VALIDATION'=> "Your company's license for SugarCRM needs to be validated. Only admins may login",
	'ERROR_NO_RECORD' => 'Error retrieving record.  This record may be deleted or you may not be authorized to view it.',
	'LBL_DUP_MERGE'=>'중복검색',
	// Ajax status strings
	'LBL_LOADING' => '로딩중 ...',
	'LBL_SAVING_LAYOUT' => '레이아웃 저장중 ...',
	'LBL_SAVED_LAYOUT' => '레이아웃저장.',
	'LBL_SAVED' => '저장',
	'LBL_SAVING' => '저장중',
	'LBL_DISPLAY_COLUMNS' => '컬럼표시',
	'LBL_HIDE_COLUMNS' => '컬럼감춤',
    	'LBL_SEARCH_CRITERIA' => '검색조건',
    	'LBL_SAVED_VIEWS' => '화면저장',
    	'LBL_MERGE_DUPLICATES'  => '복제',
);
?>
