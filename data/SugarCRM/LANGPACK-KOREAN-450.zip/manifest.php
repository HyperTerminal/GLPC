<?PHP 
$manifest = array( 
	'name' => 'Korean',
	'description' => 'SugarCRM Open Source 4.5.0 Korean Language Pack',
	'type' => 'langpack',
	'is_uninstallable' => true,
	'version' => '4.5.0',
	'acceptable_sugar_flavors' => array('OS'),
	'published_date' => '2006-09-30',
	'author' => 'e-System Korea Inc.',
	'acceptable_sugar_versions' => array('4.5.0'),
);

$installdefs = array(
	'id'=> 'ko',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
		array('from'=> '<basepath>/include','to'=> 'include',),
		array('from'=> '<basepath>/modules','to'=> 'modules')
	)
);
?>
