<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.44 2006/07/24 18:59:00 wayne Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' 		=> '거래고객작성',
  'LBL_FIRST_NAME' 			=> '이름(성):',
  'LBL_LAST_NAME' 			=> '이름(명):',
  'LBL_LIST_LAST_NAME' 		=> '이름(명)',
  'LBL_PHONE' 				=> '전화:',
  'LBL_EMAIL_ADDRESS' 		=> 'E메일:',
  'LBL_PIPELINE_FORM_TITLE' 	=> 'My 파이프라인',
  'LNK_NEW_CONTACT' 			=> '거래고객작성',
  'LNK_NEW_ACCOUNT' 		=> '거래처 작성',
  'LNK_NEW_OPPORTUNITY' 		=> '안건 작성',
  'LNK_NEW_LEAD' 			=> '리드 작성',
  'LNK_NEW_CASE' 			=> '사례작성',
  'LNK_NEW_NOTE' 			=> '노트작성',
  'LNK_NEW_CALL' 			=> '콜스케쥴작성',
  'LNK_NEW_EMAIL' 			=> '메일작성',
  'LNK_COMPOSE_EMAIL' 		=> '이메일 작성',
  'LNK_NEW_MEETING' 			=> '미팅스케쥴작성',
  'LNK_NEW_TASK' 			=> '타스크작성',
  'LNK_NEW_BUG' 				=> '결함레포트작성',
  'LBL_ADD_BUSINESSCARD' 		=> '비지네스카드작성',

  'ERR_ONE_CHAR' 			=> 'Please enter at least one letter or number for your search ...',
  'LBL_OPEN_TASKS' 			=> 'My 오픈타스크',
  'LBL_SEARCH_RESULTS' 		=> '검색결과',
  'LBL_SEARCH_RESULTS_IN' 	=> 'in', 
  'LNK_NEW_SEND_EMAIL' 		=> '이메일작성',
  'LBL_NO_RESULTS_IN_MODULE' => '-- No Results --',
  'LBL_NO_RESULTS' 			=> '<h2>There were no results found. Please search again.</h2><br>',
  'LBL_NO_RESULTS_TIPS' 		=> '<h3>Search Tips:</h3><ul><li>Make sure you have the proper categories selected above.</li><li>Broaden your search criteria.</li><li>If you still cannot find any results try the advanced search of that module.</li></ul>',
  
  'LBL_RELOAD_PAGE' 			=> 'Please <a href="javascript: window.location.reload()">reload the window</a> to use this Dashlet.',
  'LBL_ADD_DASHLETS' 			=> '대쉬렛츠추가',
  'LBL_CLOSE_DASHLETS' 		=> '종료',
  'LBL_OPTIONS' 				=> '옵션', 
  // dashlet search fields
  'LBL_TODAY'					=>'오늘',
  'LBL_YESTERDAY' 			=> '어제', 
  'LBL_TOMORROW'			=>'내일',
  'LBL_LAST_WEEK'			=>'전주',
  'LBL_NEXT_WEEK'			=>'다음주',
  'LBL_LAST_7_DAYS'			=>'이전7일',
  'LBL_NEXT_7_DAYS'			=>'다음7일',
  'LBL_LAST_MONTH'			=>'이전달',
  'LBL_NEXT_MONTH'			=>'다음달',
  'LBL_LAST_QUARTER'			=>'이전3개월',
  'LBL_THIS_QUARTER'			=>'이번 3개월',
  'LBL_LAST_YEAR'				=>'이전년',
  'LBL_NEXT_YEAR'			=>'다음해',
  'LBL_THIS_MONTH' 			=> '이번달',
  'LBL_THIS_YEAR' 				=> '올해',
  'LBL_LAST_30_DAYS' 			=> '이전30일',
  'LBL_NEXT_30_DAYS' 			=> '다음30일',
  'LBL_THIS_MONTH' 			=> '이번달',
  'LBL_THIS_YEAR' 				=> '올해',
  'LBL_LAST_30_DAYS' 			=> '이전30일',
  'LBL_NEXT_30_DAYS' 			=> '다음30일',
  
  // Dashlet Categories
  'dashlet_categories_dom' => array(
      'Module Views' 	=> '모쥴 화면',
      'Portal' 			=> '포탈',
      'Charts' 			=> '챠트',
      'Tools' 			=> '도구',
      'Miscellaneous' 	=> '기타'
      ),
  'LBL_MAX_DASHLETS_REACHED' => 'You have reached the maximum number of dashlets your adminstrator has set. Please remove a dashlet to add more.',
  'LBL_ADDING_DASHLET' 		=> '대쉬렛츠추가 ...',
  'LBL_ADDED_DASHLET' 		=> '대쉬렛츠추가',
  'LBL_REMOVING_DASHLET' 	=> '대쉬렛츠삭제 ...',
  'LBL_REMOVED_DASHLET' 		=> '대쉬렛츠추가',
  
);
?>
