<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.54 2006/07/11 17:25:53 jenny Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '미팅',
  'LBL_MODULE_TITLE' => '미팅: Home',
  'LBL_SEARCH_FORM_TITLE' => '미팅 검색',
  'LBL_LIST_FORM_TITLE' => '미팅 리스트',
  'LBL_NEW_FORM_TITLE' => '미팅 스케쥴 작성',
  'LBL_SCHEDULING_FORM_TITLE' => '스케쥴',
  'LBL_LIST_SUBJECT' => '제목',
  'LBL_LIST_CONTACT' => '거래 담당자',
  'LBL_LIST_RELATED_TO' => '관련',
  'LBL_LIST_DATE' => '시작일',
  'LBL_LIST_TIME' => '시작시간',
  'LBL_LIST_CLOSE' => '종료',
  'LBL_SUBJECT' => '제목:',
  'LBL_STATUS' => '상태:',
  'LBL_LOCATION' => '장소:',
  'LBL_DATE_TIME' => '시작일시:',
  'LBL_DATE' => '시작일:',
  'LBL_TIME' => '시간시간:',
   'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_DURATION' => '시간:',
  'LBL_DURATION_HOURS' => '시간:',
  'LBL_DURATION_MINUTES' => '분:',
  'LBL_HOURS_MINS' => '(시간/분)',
  'LBL_CONTACT_NAME' => '거래담당자:',
  'LBL_MEETING' => '미팅:',
  'LBL_DESCRIPTION_INFORMATION' => '상세정보',
  'LBL_DESCRIPTION' => '상세:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => '기획',
'LNK_NEW_CALL'=>'콜스케쥴작성',
'LNK_NEW_MEETING'=>'미팅스케쥴작성',
'LNK_NEW_TASK'=>'타스크작성',
'LNK_NEW_NOTE'=>'노트작성',
'LNK_NEW_EMAIL'=>'E메일 작성',
'LNK_CALL_LIST'=>'콜스케쥴작성',
'LNK_MEETING_LIST'=>'미팅리스트',
'LNK_TASK_LIST'=>'타스크 리스트',
'LNK_NOTE_LIST'=>'노트리스트',
'LNK_EMAIL_LIST'=>'E메일리스트',

  'LNK_VIEW_CALENDAR' => '오늘',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the meeting.',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this invitee from the meeting?',
  'LBL_INVITEE' => 'Invitees',
  'LNK_NEW_APPOINTMENT' => '약속작성',

  'LBL_ADD_INVITEE' => '참가자추가',
  'LBL_NAME' => '명칭',
  'LBL_FIRST_NAME' => '이름(성)',
  'LBL_LAST_NAME' => '이름(명)',
  'LBL_EMAIL' => 'E메일',
  'LBL_PHONE' => '직장전화:',
  'LBL_REMINDER' => '통보:',
  'LBL_SEND_BUTTON_TITLE'=>'초대메일송신[Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'초대메일송신',
  'LBL_REMINDER_TIME'=>'통보시간',
  'LBL_MODIFIED_BY'=>'편집자',
  'LBL_CREATED_BY'=>'등록자',
  'LBL_DATE_END'=>'종료일',
	
  'LBL_SEARCH_BUTTON'=> '검색',
  'LBL_ADD_BUTTON'=> '추가',
  'LBL_DEL'=> '삭제',
  'LBL_DEFAULT_SUBPANEL_TITLE' => '미팅',
  'LBL_LIST_STATUS'=>'상태',
  'LBL_LIST_DUE_DATE'=>'만료일',
  'LBL_LIST_DATE_MODIFIED'=>'편집일',
  
  'LBL_CONTACTS_SUBPANEL_TITLE' => '거래담당자',
  'LBL_USERS_SUBPANEL_TITLE' => '유저',
  'LBL_HISTORY_SUBPANEL_TITLE' => '노트',
  'LBL_OUTLOOK_ID' => '아웃룩ID',
  'LBL_LIST_ASSIGNED_TO_NAME' => '할당유저',
  'LBL_LIST_MY_MEETINGS' => 'My 미팅 리스트',
  'LBL_ACCEPT_THIS'=>'허가?',  
);


?>
