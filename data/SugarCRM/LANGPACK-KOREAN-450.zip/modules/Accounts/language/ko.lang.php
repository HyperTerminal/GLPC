<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.52 2006/06/09 11:15:25 wayne Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '거래처',
  'LBL_MODULE_TITLE' => '거래처: 홈',
  'LBL_HOMEPAGE_TITLE' => 'My 거래처 리스트',
  'LBL_SEARCH_FORM_TITLE' => '거래처 검색',
  'LBL_LIST_FORM_TITLE' => '거래처 리스트',
  'LBL_VIEW_FORM_TITLE' => '거래처 화면',
  'LBL_NEW_FORM_TITLE' => '거래처 작성',
  'LBL_MEMBER_ORG_FORM_TITLE' => '멤버 조직',
  'LBL_BUG_FORM_TITLE' => '거래처',
  'LBL_LIST_ACCOUNT_NAME' => '거래처명',
  'LBL_LIST_CITY' => '시구군',
  'LBL_LIST_WEBSITE' => '웹사이트',
  'LBL_LIST_STATE' => '읍면동',
  'LBL_LIST_PHONE' => '전화',
  'LBL_LIST_EMAIL_ADDRESS' => 'E메일 리스트',
  'LBL_LIST_CONTACT_NAME' => '거래처 담당자명',
  'LBL_BILLING_ADDRESS_STREET_2' =>'청구처 주소2',
  'LBL_BILLING_ADDRESS_STREET_3' =>'청구처 주소3',
  'LBL_BILLING_ADDRESS_STREET_4' =>'청구처 주소4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => '배송처 주소2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => '배송처 주소3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => '배송처 주소4',
  
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => '거래처 정보',
  'LBL_ACCOUNT' => '거래처:',
  'LBL_ACCOUNT_NAME' => '거래처명:',
  'LBL_PHONE' => '전화:',
  'LBL_PHONE_ALT' => '연락전화:',
  'LBL_WEBSITE' => '웹사이트:',
  'LBL_FAX' => '팩스:',
  'LBL_TICKER_SYMBOL' => '증권코드:',
  'LBL_OTHER_PHONE' => '연락전화:',
  'LBL_ANY_PHONE' => '연락전화:',
  'LBL_MEMBER_OF' => '멤버의:',
  'LBL_PHONE_OFFICE' => '직장전화:',
  'LBL_PHONE_FAX' => '팩스:',
  'LBL_EMAIL' => 'E메일:',
  'LBL_EMPLOYEES' => '종업원:',
  'LBL_OTHER_EMAIL_ADDRESS' => '연락E메일:',
  'LBL_ANY_EMAIL' => '연락메일:',
  'LBL_OWNERSHIP' => '소유자:',
  'LBL_RATING' => '업계순위:',
  'LBL_INDUSTRY' => '업종:',
  'LBL_SIC_CODE' => '업종코드:',
  'LBL_TYPE' => '업태:',
  'LBL_ANNUAL_REVENUE' => '년간매출:',
  'LBL_ADDRESS_INFORMATION' => '주소 정보',
  'LBL_BILLING_ADDRESS' => '청구처 주소:',
  'LBL_BILLING_ADDRESS_STREET' => '청구처 주소1:',
  'LBL_BILLING_ADDRESS_CITY' => '청구처 시구군:',
  'LBL_BILLING_ADDRESS_STATE' => '청구처 읍면동:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => '청구처 우편번호:',
  'LBL_BILLING_ADDRESS_COUNTRY' => '청구처 국가:',
  'LBL_SHIPPING_ADDRESS_STREET' => '배송처 주소:',
  'LBL_SHIPPING_ADDRESS_CITY' => '배송처 시구군:',
  'LBL_SHIPPING_ADDRESS_STATE' => '배송처 주소:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => '배송처 우편번호:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => '배송처 국가:',
  'LBL_SHIPPING_ADDRESS' => '배송처 주소:',
  'LBL_DATE_MODIFIED' => '최종변경일:',
  'LBL_DATE_ENTERED' => '작성일:',
  'LBL_ANY_ADDRESS' => '연락주소:',
  'LBL_CITY' => '시구군:',
  'LBL_STATE' => '읍면동:',
  'LBL_POSTAL_CODE' => '우편번호:',
  'LBL_COUNTRY' => '국가:',
  'LBL_PUSH_CONTACTS_BUTTON_TITLE' => '복사...',
  'LBL_PUSH_CONTACTS_BUTTON_LABEL' => '거래담당자 복사',
  'LBL_DESCRIPTION_INFORMATION' => '상세 정보',
  'LBL_DESCRIPTION' => '상세:',
  'NTC_COPY_BILLING_ADDRESS' => '청구처 주소를 배송처 주소로 복사',
  'NTC_COPY_SHIPPING_ADDRESS' => '배송처 주소를 청구처 주소로 복사',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Are you sure you want to remove this record as a member organization?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this record?',
  'LBL_DUPLICATE' => 'Possible Duplicate Account',
  'MSG_SHOW_DUPLICATES' => 'Creating this contact may potentialy create a duplicate contact. You may either click on Create Account to continue creating this new account with the previously entered data or you may click Cancel.',
  'MSG_DUPLICATE' => 'Creating this account may potentialy create a duplicate account. You may either select an account from the list below or you may click on Create Account to continue creating a new account with the previously entered data.',
  'LNK_NEW_ACCOUNT' => '거래처 작성',



  'LNK_ACCOUNT_LIST' => '거래처',
  'LBL_INVITEE' => '거래담당자',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
  'LBL_SAVE_ACCOUNT' => '거래처저장',
  'LBL_BUG_FORM_TITLE' => '거래처',
    'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Are you sure you want to remove this account from this project?',
    'LBL_USERS_ASSIGNED_LINK'=>'할당유저',
    'LBL_USERS_MODIFIED_LINK'=>'변경유저',
    'LBL_USERS_CREATED_LINK'=>'작성유저',
    'LBL_TEAMS_LINK'=>'부서',
    'LBL_DEFAULT_SUBPANEL_TITLE' => '거래처',
    'LBL_PRODUCTS_TITLE'=>'제품',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'영업활동',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'이력',
    'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'멤버조직',
    'LBL_NAME'=>'이름:',
    
    'LBL_CONTACTS_SUBPANEL_TITLE' => '거래담당자',
    'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => '안건',
    'LBL_LEADS_SUBPANEL_TITLE' => '리드',
    'LBL_CASES_SUBPANEL_TITLE' => '사례',
    'LBL_MEMBER_ORG_SUBPANEL_TITLE' => '멤버조직',
    'LBL_BUGS_SUBPANEL_TITLE' => '결함정보',
    'LBL_PROJECTS_SUBPANEL_TITLE' => '제품',
    'LBL_ASSIGNED_TO_NAME' => '할당유저명:',

    // Dashlet Categories
    'LBL_DEFAULT' => '화면',
    'LBL_CHARTS'    => '챠트',
    'LBL_UTILS'    => '유틀리티',
    'LBL_MISC'    => '기타',
    
);


?>
