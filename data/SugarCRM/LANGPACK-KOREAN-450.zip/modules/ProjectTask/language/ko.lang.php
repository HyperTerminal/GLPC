<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Default English language strings
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: en_us.lang.php,v 1.31 2006/06/06 17:58:32 majed Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => '프로젝트 타스크',
	'LBL_MODULE_TITLE' => '프로젝트 타스크: 홈',
	'LBL_SEARCH_FORM_TITLE' => '프로젝트 타스크 검색',
	'LBL_LIST_FORM_TITLE'=> '프로젝트 타스크 리스트',
	
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => '등록일:',
	'LBL_DATE_MODIFIED' => '변경일:',
	'LBL_ASSIGNED_USER_ID' => '할당:',
	'LBL_MODIFIED_USER_ID' => '변경유저 Id:',
	'LBL_CREATED_BY' => '작성자:',
	'LBL_TEAM_ID' => '부서:',
	'LBL_NAME' => '명칭:',
	'LBL_STATUS' => '상태:',
	'LBL_DATE_DUE' => '만료일:',
	'LBL_TIME_DUE' => '만료시간:',
	'LBL_DATE_START' => '시작일:',
	'LBL_TIME_START' => '시작시간:',
	'LBL_PARENT_ID' => '프로젝트:',
	'LBL_PRIORITY' => '우선순위:',
	'LBL_DESCRIPTION' => '상세:',
	'LBL_ORDER_NUMBER' => '주문:',
	'LBL_TASK_NUMBER' => '타스크번호:',
	'LBL_DEPENDS_ON_ID' => '의존처:',
	'LBL_MILESTONE_FLAG' => '중요:',
	'LBL_ESTIMATED_EFFORT' => '견적시간(시간):',
	'LBL_ACTUAL_EFFORT' => '실적시간(시간):',
	'LBL_UTILIZATION' => '부하률 (%):',
	'LBL_PERCENT_COMPLETE' => '진척율 (%):',
	'LBL_DELETED' => '삭제:',

	'LBL_LIST_ORDER_NUMBER' => '주문',
	'LBL_LIST_NAME' => '명칭',
	'LBL_LIST_PARENT_NAME' => '프로젝트',
	'LBL_LIST_PERCENT_COMPLETE' => '진척률(%)',
	'LBL_LIST_STATUS' => '상태',
	'LBL_LIST_ASSIGNED_USER_ID' => '할당',
	'LBL_LIST_DATE_DUE' => '만료일',
	'LBL_LIST_DATE_START' => '시작일',
	'LBL_LIST_PRIORITY' => '우선순위',
	'LBL_LIST_CLOSE' => '종료',
	'LBL_PROJECT_NAME' => '프로젝트명',

	'LNK_NEW_PROJECT'	=> '프로젝트 작성',
	'LNK_PROJECT_LIST'	=> '프로젝트리스트',
	'LNK_NEW_PROJECT_TASK'	=> '프로젝트 타스크 작성',
	'LNK_PROJECT_TASK_LIST'	=> '프로젝트 타스크 리스트',
	
	'LBL_LIST_MY_PROJECT_TASKS' => 'My 오픈 프로젝트 타스크',
	'LBL_DEFAULT_SUBPANEL_TITLE' => '프로젝트 타스크s',
	'LBL_NEW_FORM_TITLE' => '프로젝트 타스크 작성',

	'LBL_ACTIVITIES_TITLE'=>'영업활동',
	'LBL_HISTORY_TITLE'=>'이력',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'영업활동',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'이력', 
	'DATE_JS_ERROR' => 'Please enter a date corresponding to the time entered',
);
?>
