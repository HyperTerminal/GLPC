<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.41 2006/06/09 03:50:32 sadek Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD'				=> 'A record number must be specified to delete the account.',
	
	'LBL_ACCOUNT_ID'					=> '거래처ID',
	'LBL_ACCOUNT_NAME'				=> '거래처명:',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'	=> '영업활동',
	'LBL_BUGS_SUBPANEL_TITLE'		=> '결함정보',
	'LBL_CASE_NUMBER'				=> '사례넘버:',
	'LBL_CASE_SUBJECT'				=> '사례제목:',
	'LBL_CASE'						=> '사례:',
	'LBL_CONTACT_CASE_TITLE'			=> '거래담당자-사례:',
	'LBL_CONTACT_NAME'				=> '거래담당자명:',
	'LBL_CONTACT_ROLE'				=> '역활:',
	'LBL_CONTACTS_SUBPANEL_TITLE'	=> '거래담당자',
	'LBL_DEFAULT_SUBPANEL_TITLE'		=> '사례',
	'LBL_DESCRIPTION'					=> '상세:',
	'LBL_HISTORY_SUBPANEL_TITLE'		=> '이력',
	'LBL_INVITEE'						=> '거래담당자',
	'LBL_MEMBER_OF'					=> '거래처',
	'LBL_MODULE_NAME'				=> '사례',
	'LBL_MODULE_TITLE'				=> '사례: 홈',
	'LBL_NEW_FORM_TITLE'				=> '신규사례작성',
	'LBL_NUMBER'					=> '넘버:',
	'LBL_PRIORITY'					=> '우선순위:',
	'LBL_RESOLUTION'					=> '리솔루션:',
	'LBL_SEARCH_FORM_TITLE'			=> '사례 검색',
	'LBL_STATUS'						=> '상태:',
	'LBL_SUBJECT'					=> '제목:',
	'LBL_SYSTEM_ID'					=> '시스템ID',
	
	'LBL_LIST_ACCOUNT_NAME'			=> '거래처명',
	'LBL_LIST_ASSIGNED'				=> '할당',
	'LBL_LIST_CLOSE'					=> '종료',
	'LBL_LIST_FORM_TITLE'				=> '사례 리스트',
	'LBL_LIST_LAST_MODIFIED'			=> '최종변경일',
	'LBL_LIST_MY_CASES'				=> 'My 사례 리스트',
	'LBL_LIST_NUMBER'				=> '번호.',
	'LBL_LIST_PRIORITY'				=> '우선순위',
	'LBL_LIST_STATUS'					=> '상태',
	'LBL_LIST_SUBJECT'				=> '제목',
	
	'LNK_CASE_LIST'					=> '사례 리스트',
	'LNK_NEW_CASE'					=> '신규사례작성',
	'NTC_REMOVE_FROM_BUG_CONFIRMATION'	=> 'Are you sure you want to remove this case from this bug?',
	'NTC_REMOVE_INVITEE'				=> 'Are you sure you want to remove this contact from the case?',
	'LBL_LIST_ASSIGNED_TO_NAME' 		=> '할당유저',
	'LBL_LIST_DATE_CREATED'			=> '등록일',


);


?>
