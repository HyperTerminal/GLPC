<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array(
'LBL_MODULE_NAME' => '포탈',
'LBL_MODULE_TITLE' => '포탈: 홈',
'LBL_LIST_STATUS'=>'표시',
'LBL_LIST_NAME'=>'웹사이트명칭',
'LBL_LIST_URL'=>'웹사이트주소',
'LBL_LIST_TYPE'=>'웹사이트종류',
'LBL_LIST_CREATED_BY'=>'작성자',
'LBL_LIST_PLACEMENT'=>'편성',
'LBL_LIST_FORM_TITLE' => '포탈일람',
'LBL_ADD_SITE' => '사이트추가',
'LBL_LIST_SITES' => '사이트리스트',
'LBL_ID' => 'ID',
'LBL_CHECKED' => '체크',
'DEFAULT_URL' => 'http://www.sugarcrm.co.kr',

'DROPDOWN_PLACEMENT'=>array(
	'all' => '탭메뉴및 미니메뉴',
	'tab' => '탭메뉴',
	'shortcut'=>'미니메뉴',
	),
'DROPDOWN_TYPE'=>array(
	'personal' => '퍼스날',
	'global' => '글로벌',
	),
);
?>
