<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.40 2006/06/06 17:57:54 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '영업활동',
  'LBL_MODULE_TITLE' => '영업활동: 홈',
  'LBL_SEARCH_FORM_TITLE' => '영업활동 검색',
  'LBL_LIST_FORM_TITLE' => '영업활동 리스트',
  'LBL_LIST_SUBJECT' => '제목',
  'LBL_LIST_CONTACT' => '거래고객',
  'LBL_LIST_RELATED_TO' => '관련처',
  'LBL_LIST_DATE' => '일자',
  'LBL_LIST_TIME' => '개시시간',
  'LBL_LIST_CLOSE' => '종료',
  'LBL_SUBJECT' => '제목:',
  'LBL_STATUS' => '상태:',
  'LBL_LOCATION' => '장소:',
  'LBL_DATE_TIME' => '개시일시:',
  'LBL_DATE' => '개시일:',
  'LBL_TIME' => '개시시간:',
  'LBL_DURATION' => '시간:',
  'LBL_HOURS_MINS' => '(시간/분)',
  'LBL_CONTACT_NAME' => '거래고객명: ',
  'LBL_MEETING' => '미팅:',
  'LBL_DESCRIPTION_INFORMATION' => '상세 정보',
  'LBL_DESCRIPTION' => '상세내용:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => '계획',
  'LNK_NEW_CALL' => '콜스케쥴작성',
  'LNK_NEW_MEETING' => '미팅스케쥴작성',
  'LNK_NEW_TASK' => '타스크작성',
  'LNK_NEW_NOTE' => '노트작성',
  'LNK_NEW_EMAIL' => 'E메일작성',
  'LNK_CALL_LIST' => '콜리스트',
  'LNK_MEETING_LIST' => '미팅리스트',
  'LNK_TASK_LIST' => '타스크리스트',
  'LNK_NOTE_LIST' => '노트리스트',
  'LNK_EMAIL_LIST' => 'E메일리스트',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this invitee from the meeting?',
  'LBL_INVITEE' => '참가자일람',
  'LBL_LIST_DIRECTION' => '방향',
  'LBL_DIRECTION' => '방향',
  'LNK_NEW_APPOINTMENT' => '약속작성',
  'LNK_VIEW_CALENDAR' => '오늘',
  'LBL_OPEN_ACTIVITIES' => '미실시 영업활동',
  'LBL_HISTORY' => '히스토리',
  'LBL_UPCOMING' => 'My 예정',
  'LBL_TODAY' => '표시범위',
  'LBL_NEW_TASK_BUTTON_TITLE' => '타스크작성[Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => '타스크작성',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => '미팅스케쥴작성[Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => '미팅스케쥴작성',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => '콜스케쥴작성[Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => '콜스케쥴작성',
  'LBL_NEW_NOTE_BUTTON_TITLE' => '노트작성[Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => '노트작성',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'E메일작성[Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'E메일작성',
  'LBL_LIST_STATUS' => '상태',
  'LBL_LIST_DUE_DATE' => '기간만료일',
  'LBL_LIST_LAST_MODIFIED' => '최종변경일',
  'NTC_NONE_SCHEDULED' => '예정없음.',
  'appointment_filter_dom' => array(
  	 'today' => '오늘'
  	,'tomorrow' => '내일'
  	,'this Saturday' => '이번주'
  	,'next Saturday' => '다음주'
  	,'last this_month' => '이번달'
  	,'last next_month' => '다음달'
  ),
  'LNK_IMPORT_NOTES'=>'노트 읽어들이기',
  'NTC_NONE'=>'없음',
  'LBL_ACCEPT_THIS'=>'허가?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => '미실시 영업활동',
   'LBL_LIST_ASSIGNED_TO_NAME' => '할당된유저',
);


?>
