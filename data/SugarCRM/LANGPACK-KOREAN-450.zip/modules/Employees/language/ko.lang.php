<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.5 2006/06/06 17:58:20 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '종업원',
  'LBL_MODULE_TITLE' => '종업원: 홈',
  'LBL_SEARCH_FORM_TITLE' => '종업원 검색',
  'LBL_LIST_FORM_TITLE' => '종업원',
  'LBL_NEW_FORM_TITLE' => '종업원 작성',
  'LBL_EMPLOYEE' => '종업원:',
  'LBL_LOGIN' => '로그인',
  'LBL_RESET_PREFERENCES' => 'Reset To Default Preferences',
  'LBL_TIME_FORMAT' => '시간표시형식:',
  'LBL_DATE_FORMAT' => '일자표시형식:',
  'LBL_TIMEZONE' => '현재시간:',
  'LBL_CURRENCY' => '통화:',
  'LBL_LIST_NAME' => '이름',
  'LBL_LIST_LAST_NAME' => '이름(성)',
  'LBL_LIST_종업원_NAME' => '종업원 이름',
  'LBL_LIST_DEPARTMENT' => '부서',
  'LBL_LIST_REPORTS_TO_NAME' => '직속상사',
  'LBL_LIST_EMAIL' => '메일',
  'LBL_LIST_PRIMARY_PHONE' => '전화',
  'LBL_LIST_USER_NAME' => '유저명',
  'LBL_LIST_종업원_STATUS' => '상태',
  'LBL_LIST_ADMIN' => '관리',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => '종업원작성[Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => '종업원작성',
  'LBL_NEW_종업원_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Error:',
  'LBL_PASSWORD' => '패스워드:',
  'LBL_EMPLOYEE_NAME' => '종업원 이름:',
  'LBL_USER_NAME' => '유저명:',
  'LBL_FIRST_NAME' => '아름(명):',
  'LBL_LAST_NAME' => '이름(성):',
  'LBL_EMPLOYEE_SETTINGS' => '종업원 설정',
  'LBL_THEME' => '썸:',
  'LBL_LANGUAGE' => '언어:',
  'LBL_ADMIN' => '관리자:',
  'LBL_EMPLOYEE_INFORMATION' => '종업원 정보',
  'LBL_OFFICE_PHONE' => '사무실전화:',
  'LBL_REPORTS_TO' => '직속상사:',
  'LBL_OTHER_PHONE' => '다른전화:',
  'LBL_OTHER_EMAIL' => '다른메일:',
  'LBL_NOTES' => '노트:',
  'LBL_DEPARTMENT' => '부서:',
  'LBL_TITLE' => '작위:',
  'LBL_ANY_PHONE' => '전화:',
  'LBL_ANY_EMAIL' => 'E메일:',
  'LBL_ADDRESS' => '주소:',
  'LBL_CITY' => '시구군:',
  'LBL_STATE' => '읍면동:',
  'LBL_POSTAL_CODE' => '우편번호:',
  'LBL_COUNTRY' => '국가:',
  'LBL_NAME' => '이름:',
  'LBL_MOBILE_PHONE' => '모바일:',
  'LBL_OTHER' => '기타:',
  'LBL_FAX' => '팩스:',
  'LBL_EMAIL' => 'E메일:',
  'LBL_HOME_PHONE' => '자택전화:',
  'LBL_ADDRESS_INFORMATION' => '주소 정보',
  'LBL_EMPLOYEE_STATUS' => '상태:',
  'LBL_PRIMARY_ADDRESS' => '주소:',
  'LBL_CREATE_USER_BUTTON_TITLE' => '유저 작성[Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => '유저 작성',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => '좋아하는색깔:',
  'LBL_MESSENGER_ID' => 'IM 명:',
  'LBL_MESSENGER_TYPE' => 'IM 종류:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => '종업원 이름',
  'ERR_종업원_NAME_EXISTS_2' => ' already exists.  Duplicate 종업원 names are not allowed.  Change the 종업원 name to be unique.',
  'ERR_LAST_ADMIN_1' => '종업원 이름',
  'ERR_LAST_ADMIN_2' => '" is the last 종업원 with administrator access.  At least one 종업원 must be an administrator.',
  'LNK_NEW_EMPLOYEE' => '종업원 작성',
  'LNK_EMPLOYEE_LIST' => '종업원리스트',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
  'LBL_LIST_EMPLOYEE_STATUS' => '상태',

);


?>
