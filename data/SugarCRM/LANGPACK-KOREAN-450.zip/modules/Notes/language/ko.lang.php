<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.44 2006/06/28 02:36:57 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
	'LBL_ACCOUNT_ID' => '거래처ID:',
	'LBL_CASE_ID' => '사례ID:',
	'LBL_CLOSE' => '종료:',
	'LBL_COLON' => ':',
	'LBL_CONTACT_ID' => '거래담당자ID:',
	'LBL_CONTACT_NAME' => '거래담당자:',
	'LBL_DEFAULT_SUBPANEL_TITLE' => '노트',
	'LBL_DESCRIPTION' => '상세',
	'LBL_EMAIL_ADDRESS' => 'E메일주소:',
	'LBL_FILE_MIME_TYPE' => 'Mime Type',
	'LBL_FILE_URL' => 'File URL',
	'LBL_FILENAME' => '첨부파일:',
	'LBL_LEAD_ID' => '리드ID:',
	'LBL_LIST_CONTACT_NAME' => '거래담당자',
	'LBL_LIST_DATE_MODIFIED' => '최종변경일',
	'LBL_LIST_FILENAME' => '첨부파일',
	'LBL_LIST_FORM_TITLE' => '노트 리스트',
	'LBL_LIST_RELATED_TO' => '관련',
	'LBL_LIST_SUBJECT' => '제목',
	'LBL_LIST_STATUS' => '상태',
	'LBL_LIST_CONTACT' => '거래담당자',
	'LBL_MODULE_NAME' => '노트',
	'LBL_MODULE_TITLE' => '노트: 홈',
	'LBL_NEW_FORM_TITLE' => '노트 작성',
	'LBL_NOTE_STATUS' => '노트',
	'LBL_NOTE_SUBJECT' => '노트 제목:',
	'LBL_NOTES_SUBPANEL_TITLE' => '첨부파일',
	'LBL_NOTE' => '노트:',
	'LBL_OPPORTUNITY_ID' => '안건 ID:',
	'LBL_PARENT_ID' => '패런트ID:',
	'LBL_PARENT_TYPE' => '패런트종류',
	'LBL_PHONE' => '전화:',
	'LBL_PORTAL_FLAG' => '포탈에표시?',
	'LBL_PRODUCT_ID' => '제품 ID:',
	'LBL_QUOTE_ID' => '견적 ID:',
	'LBL_RELATED_TO' => '관련처:',
	'LBL_SEARCH_FORM_TITLE' => '노트 검색',
	'LBL_STATUS' => '상태',
	'LBL_SUBJECT' => '제목:',
	'LNK_CALL_LIST' => '콜',
	'LNK_EMAIL_LIST' => 'E메일',
	'LNK_IMPORT_NOTES' => '노트읽어들이기',
	'LNK_MEETING_LIST' => '미팅',
	'LNK_NEW_CALL' => '콜스케쥴작성',
	'LNK_NEW_EMAIL' => 'E메일저장',
	'LNK_NEW_MEETING' => '미팅스케쥴작성',
	'LNK_NEW_NOTE' => '노트 작성',
	'LNK_NEW_TASK' => '타스크작성',
	'LNK_NOTE_LIST' => '노트',
	'LNK_TASK_LIST' => '타스크',
	'LNK_VIEW_CALENDAR' => '오늘',
	'LBL_MEMBER_OF' => '멤버:',
	'LBL_LIST_ASSIGNED_TO_NAME' => '할당유저',
);

?>
