<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.21 2006/06/06 17:57:55 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
   'LBL_MODULE_NAME' => '스케쥴관리' ,
   'LBL_MODULE_TITLE' => '스케쥴관리' ,
   'LNK_NEW_CALL' => '콜예약작성' ,
   'LNK_NEW_MEETING' => '미팅예약작성' ,
   'LNK_NEW_APPOINTMENT' => '예약작성' ,
   'LNK_NEW_TASK' => '타스크작성' ,
   'LNK_CALL_LIST' => '콜리스트' ,
   'LNK_MEETING_LIST' => '미팅리스트' ,
   'LNK_TASK_LIST' => '타스크리스트' ,
   'LNK_VIEW_CALENDAR' => '오늘' ,
   'LBL_MONTH' => '월별' ,
   'LBL_DAY' => '일별' ,
   'LBL_YEAR' => '년도별' ,
   'LBL_WEEK' => '주별' ,
   'LBL_PREVIOUS_MONTH' => '전월' ,
   'LBL_PREVIOUS_DAY' => '전일' ,
   'LBL_PREVIOUS_YEAR' => '전년' ,
   'LBL_PREVIOUS_WEEK' => '전주' ,
   'LBL_NEXT_MONTH' => '다음달' ,
   'LBL_NEXT_DAY' => '다음날' ,
   'LBL_NEXT_YEAR' => '다음해' ,
   'LBL_NEXT_WEEK' => '다음주' ,
   'LBL_AM' => 'AM' ,
   'LBL_PM' => 'PM' ,
   'LBL_SCHEDULED' => '작성완료' ,
   'LBL_BUSY' => '예정있음' ,
   'LBL_CONFLICT' => '다른일정과중복' ,
   'LBL_USER_CALENDARS' => '유저일정' ,
   'LBL_SHARED' => '공유' ,
   'LBL_PREVIOUS_SHARED' => '이전' ,
   'LBL_NEXT_SHARED' => '다음' ,
   'LBL_SHARED_CAL_TITLE' => '공유일정' ,
   'LBL_USERS' => '할당유저' ,
   'LBL_REFRESH' => '갱긴' ,
   'LBL_EDIT' => '편집' ,
   'LBL_SELECT_USERS' => '표시할유저선택' ,
   'LBL_FILTER_BY_TEAM' => '팀별표시: ',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
      '0' => '<nobr>일' ,
      '1' => '월' ,
      '2' => '화' ,
      '3' => '수' ,
      '4' => '목' ,
      '5' => '금' ,
      '6' => '토' ,
),
'dom_cal_weekdays_long'=>array(
      '0' => '일요일' ,
      '1' => '월요일' ,
      '2' => '화요일' ,
      '3' => '수요일' ,
      '4' => '목요일' ,
      '5' => '금요일' ,
      '6' => '토요일' ,
),
'dom_cal_month'=>array(
      '0' => '' ,
      '1' => '1월' ,
      '2' => '2월' ,
      '3' => '3월' ,
      '4' => '4월' ,
      '5' => '5월' ,
      '6' => '6월' ,
      '7' => '7월' ,
      '8' => '8월' ,
      '9' => '9월' ,
      '10' => '10월' ,
      '11' => '11월' ,
      '12' => '12월' ,
),
'dom_cal_month_long'=>array(
      '0' => '' ,
      '1' => '1월' ,
      '2' => '2월' ,
      '3' => '3월' ,
      '4' => '4월' ,
      '5' => '5월' ,
      '6' => '6월' ,
      '7' => '7월' ,
      '8' => '8월' ,
      '9' => '9월' ,
      '10' => '10월' ,
      '11' => '11월' ,
      '12' => '12월' ,
)
);
?>
