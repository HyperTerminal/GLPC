<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
********************************************************************************/
/*********************************************************************************
* $Id: en_us.lang.php,v 1.37 2006/06/09 10:55:36 wayne Exp $
* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributor(s): ______________________________________..
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
    'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
    //END DON'T CONVERT
    'ERR_DELETE_RECORD' => 'en_us A record number must be specified to delete the lead.',
    'LBL_ACCOUNT_DESCRIPTION'=> '거래처 상세',
    'LBL_ACCOUNT_ID'=>'거래처 ID',
    'LBL_ACCOUNT_NAME' => '거래처명:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'영업활동',
    'LBL_ADD_BUSINESSCARD' => '명함추가',
    'LBL_ADDRESS_INFORMATION' => '주소 정보',
    'LBL_ALT_ADDRESS_CITY' => '부주소 시구군',
    'LBL_ALT_ADDRESS_COUNTRY' => '부주소 국가',
    'LBL_ALT_ADDRESS_POSTALCODE' => '부주소 우편코드',
    'LBL_ALT_ADDRESS_STATE' => '부주소 읍면동',
    'LBL_ALT_ADDRESS_STREET_2' => '부주소 주소2',
    'LBL_ALT_ADDRESS_STREET_3' => '부주소 주소3',
    'LBL_ALT_ADDRESS_STREET' => '부주소 주소',
    'LBL_ALTERNATE_ADDRESS' => '연락주소:',
    'LBL_ANY_ADDRESS' => '연락주소:',
    'LBL_ANY_EMAIL' => 'E메일:',
    'LBL_ANY_PHONE' => '전화:',
    'LBL_ASSIGNED_TO_NAME' => '할당유저',
    'LBL_BACKTOLEADS' => '리드로돌아감',
    'LBL_BUSINESSCARD' => '리드변환',
    'LBL_CITY' => '시구군:',
    'LBL_CONTACT_ID' => '거래담당자 ID',
    'LBL_CONTACT_INFORMATION' => '리드 정보',
    'LBL_CONTACT_NAME' => '리드 정보:',
    'LBL_CONTACT_OPP_FORM_TITLE' => '리드-안건:',
    'LBL_CONTACT_ROLE' => '역활:',
    'LBL_CONTACT' => '리드:',
    'LBL_CONVERTED_ACCOUNT'=>'거래처 변환:',
    'LBL_CONVERTED_CONTACT' => '거래담당자 변환:',
    'LBL_CONVERTED_OPP'=>'안건 변환:',
    'LBL_CONVERTED'=> '변환',
    'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
    'LBL_CONVERTLEAD_TITLE' => '리드변환[Alt+V]',
    'LBL_CONVERTLEAD' => '리드변환',
    'LBL_COUNTRY' => '국가:',
    'LBL_CREATED_ACCOUNT' => '신규거래처작성',
    'LBL_CREATED_CALL' => '신규 콜작성',
    'LBL_CREATED_CONTACT' => '신규 거래담당자 작성',
    'LBL_CREATED_MEETING' => '신규 미팅 작성',
    'LBL_CREATED_OPPORTUNITY' => '신규 안건 작성',
    'LBL_DEFAULT_SUBPANEL_TITLE' => '리드',
    'LBL_DEPARTMENT' => '부문:',
    'LBL_DESCRIPTION_INFORMATION' => '상세 정보',
    'LBL_DESCRIPTION' => '상세:',
    'LBL_DO_NOT_CALL' => '전화불가:',
    'LBL_DUPLICATE' => '같은종류의 리드',
    'LBL_EMAIL_ADDRESS' => 'E메일:',
    'LBL_EMAIL_OPT_OUT' => '메일송신:',
    'LBL_EXISTING_ACCOUNT' => '기존 거래처 사용',
    'LBL_EXISTING_CONTACT' => '기존 거래담당자 사용',
    'LBL_EXISTING_OPPORTUNITY' => '기존 안건 사용',
    'LBL_FAX_PHONE' => '팩스:',
    'LBL_FIRST_NAME' => '이름(성):',
    'LBL_FULL_NAME' => '이름:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'이력',
    'LBL_HOME_PHONE' => '자택전화:',
    'LBL_IMPORT_VCARD' => 'vCard에서작성',
    'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new lead by importing a vCard from your file system.',
    'LBL_INVALID_EMAIL'=>'무효E메일:',
    'LBL_INVITEE' => '직속상관',
    'LBL_LAST_NAME' => '이름(명):',
    'LBL_LEAD_SOURCE_DESCRIPTION' => '리드 소스 상세:',
    'LBL_LEAD_SOURCE' => '리드 소스:',
    'LBL_LIST_ACCOUNT_NAME' => '거래처명',
    'LBL_LIST_CONTACT_NAME' => '리드명',
    'LBL_LIST_CONTACT_ROLE' => '역활',
    'LBL_LIST_DATE_ENTERED' => '입력일',
    'LBL_LIST_EMAIL_ADDRESS' => 'E메일',
    'LBL_LIST_FIRST_NAME' => '이름(성)',
    'LBL_VIEW_FORM_TITLE' => '리드표시',    
    'LBL_LIST_FORM_TITLE' => '리드 리스트',
    'LBL_LIST_LAST_NAME' => '이름(명)',
    'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => '리드 소스 상세',
    'LBL_LIST_LEAD_SOURCE' => '리드 소스',
    'LBL_LIST_MY_LEADS' => 'My 리드 리스트',
    'LBL_LIST_NAME' => '이름',
    'LBL_LIST_PHONE' => '직장 전화',
    'LBL_LIST_REFERED_BY' => '소개자',
    'LBL_LIST_STATUS' => '상태',
    'LBL_LIST_TITLE' => '직위',
    'LBL_MOBILE_PHONE' => '휴대폰:',
    'LBL_MODULE_NAME' => '리드',
    'LBL_MODULE_TITLE' => '리드: 홈',
    'LBL_NAME' => '이름:',
    'LBL_NEW_FORM_TITLE' => '리드 작성',
    'LBL_NEW_PORTAL_PASSWORD' => '신규 포탈패스워드:',
    'LBL_OFFICE_PHONE' => '직장전화:',
    'LBL_OPP_NAME' => '안건명:',
    'LBL_OPPORTUNITY_AMOUNT' => '안건 금액:',
    'LBL_OPPORTUNITY_ID'=>'안건 ID',
    'LBL_OPPORTUNITY_NAME' => '안건명:',
    'LBL_OTHER_EMAIL_ADDRESS' => '연락E메일:',
    'LBL_OTHER_PHONE' => '연락 전화:',
    'LBL_PHONE' => '전화:',
    'LBL_PORTAL_ACTIVE' => '포탈 액티브:',
    'LBL_PORTAL_APP'=> '포탈 어픞리케이션',
    'LBL_PORTAL_INFORMATION' => '포탈 정보',
    'LBL_PORTAL_NAME' => '포탈명:',
    'LBL_PORTAL_PASSWORD_ISSET' => '포탈 패스워드 설정:',
    'LBL_POSTAL_CODE' => '우편번호:',
    'LBL_PRIMARY_ADDRESS_CITY' => '시구군',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => '국가',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => '우편번호',
    'LBL_PRIMARY_ADDRESS_STATE' => '읍면동',
    'LBL_PRIMARY_ADDRESS_STREET_2'=>'주소 2',
    'LBL_PRIMARY_ADDRESS_STREET_3'=>'주소 3',   
    'LBL_PRIMARY_ADDRESS_STREET' => '주소',
    'LBL_PRIMARY_ADDRESS' => '메인주소:',
    'LBL_REFERED_BY' => '소개자:',
    'LBL_REPORTS_TO_ID'=>'직속상사ID',
    'LBL_REPORTS_TO' => '직속상사:',
    'LBL_SALUTATION' => '경칭',
    'LBL_SEARCH_FORM_TITLE' => '리드 검색',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => '체크리드선택',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => '체크리드선택',
    'LBL_STATE' => '읍면동:',
    'LBL_STATUS_DESCRIPTION' => '상태 상세:',
    'LBL_STATUS' => '상태:',
    'LBL_TITLE' => '직위:',
    'LNK_IMPORT_VCARD' => 'vCard에서 작성',
    'LNK_LEAD_LIST' => '리드',
    'LNK_NEW_ACCOUNT' => '거래처 작성',
    'LNK_NEW_APPOINTMENT' => '약속 작성',
    'LNK_NEW_CONTACT' => '거래담당자 작성',
    'LNK_NEW_LEAD' => '리드 작성',
    'LNK_NEW_NOTE' => '노트 작성',
    'LNK_NEW_OPPORTUNITY' => '안건 작성',
    'LNK_SELECT_ACCOUNT' => '거래처 선택',
    'MSG_DUPLICATE' => 'Similar leads have been found. Please check the box of any leads you would like to associate with the Records that will be created from this conversion. Once you are done, please press next.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Copy alternate address to primary address',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Copy primary address to alternate address',
    'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Creating an opportunity requires an account.\n Please either create a new one or select an existing one.',
    'NTC_REMOVE_CONFIRMATION' => 'Are you sure you want to remove this lead from this case?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Are you sure you want to remove this record as a direct report?',
    'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'캠페인',
    'LBL_TARGET_OF_CAMPAIGNS'=>'성공한캠페인:',
    'LBL_TARGET_BUTTON_LABEL'=>'타켓작성',
    'LBL_TARGET_BUTTON_TITLE'=>'타켓작성',
    'LBL_TARGET_BUTTON_KEY'=>'T',
    'LBL_CAMPAIGN_ID'=>'캠페인ID',
  	'LBL_LIST_ASSIGNED_TO_NAME' => '할당유저',
);


?>
