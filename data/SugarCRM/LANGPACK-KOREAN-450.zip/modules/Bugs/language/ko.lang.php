<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.22 2006/07/31 20:06:17 jenny Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '결함정보',
  'LBL_MODULE_TITLE' => '결함정보: 홈',
  'LBL_MODULE_ID' => '결함정보',  
  'LBL_SEARCH_FORM_TITLE' => '결함정보 검색',
  'LBL_LIST_FORM_TITLE' => '결함정보 리스',
  'LBL_NEW_FORM_TITLE' => '결함정보 작성',
  'LBL_CONTACT_BUG_TITLE' => '거래담당자-결함정보:',
  'LBL_SUBJECT' => '제목:',
  'LBL_BUG' => '결함정보:',
  'LBL_BUG_NUMBER' => '결함정보 넘버:',
  'LBL_NUMBER' => '넘버:',
  'LBL_STATUS' => '상태:',
  'LBL_PRIORITY' => '우선순위:',
  'LBL_DESCRIPTION' => '상세:',
  'LBL_CONTACT_NAME' => '거래담당자명:',
  'LBL_BUG_SUBJECT' => '결함 제목:',
  'LBL_CONTACT_ROLE' => '역활:',
  'LBL_LIST_NUMBER' => '넘버.',
  'LBL_LIST_SUBJECT' => '제목',
  'LBL_LIST_STATUS' => '상태',
  'LBL_LIST_PRIORITY' => '우선순위',
  'LBL_LIST_RELEASE' => '릴리즈',
  'LBL_LIST_RESOLUTION' => '리솔루션',
  'LBL_LIST_LAST_MODIFIED' => '최종병경일',
  'LBL_INVITEE' => '거래담당자',
  'LBL_TYPE' => '종류:',
  'LBL_LIST_TYPE' => '종류',
  'LBL_RESOLUTION' => '리솔루션:',
  'LBL_RELEASE' => '릴리즈:',
  'LNK_NEW_BUG' => '결함정보작성',
  'LNK_BUG_LIST' => '결함정보리스트',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this contact from the bug?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this bug from this account?',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the bug.',
  'LBL_LIST_MY_BUGS' => 'My 할당 결함정보',
  
  'LBL_FOUND_IN_RELEASE' => '릴리즈 검색:',
  'LBL_FIXED_IN_RELEASE' => '수정완료 릴리즈:',
  'LBL_LIST_FIXED_IN_RELEASE' => '수정완료 릴리즈',  
  'LBL_WORK_LOG' => '워크로그:',
  'LBL_SOURCE' => '소스:',
  'LBL_PRODUCT_CATEGORY' => '카테고리:',
  
  'LBL_CREATED_BY' => '등록자:',
  'LBL_DATE_CREATED' => '등록일:',
  'LBL_MODIFIED_BY' => '최종편집일:',
  'LBL_DATE_LAST_MODIFIED' => '최종편집일:',

  'LBL_LIST_EMAIL_ADDRESS' => 'E메일 주소',
  'LBL_LIST_CONTACT_NAME' => '거래담당자명',
  'LBL_LIST_ACCOUNT_NAME' => '거래처명',
  'LBL_LIST_PHONE' => '전화',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to remove this contact from this bug?',
  
  'LBL_DEFAULT_SUBPANEL_TITLE' => '결함 정보',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'영업활동',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'이력',
  'LBL_CONTACTS_SUBPANEL_TITLE' => '거래담당자',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => '거래처',
  'LBL_CASES_SUBPANEL_TITLE' => '사례',
  'LBL_SYSTEM_ID' => '시스템ID',
  'LBL_LIST_ASSIGNED_TO_NAME' => '할당유저',
  );


?>
