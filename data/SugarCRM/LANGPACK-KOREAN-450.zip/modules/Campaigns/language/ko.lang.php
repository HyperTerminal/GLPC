<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.34 2006/06/06 17:57:56 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '캠페인',
  'LBL_MODULE_TITLE' => '캠페인: 홈',
  'LBL_SEARCH_FORM_TITLE' => '캠페인 검색',
  'LBL_LIST_FORM_TITLE' => '캠페인 리스트',
  'LBL_CAMPAIGN_NAME' => '명칭:',
  'LBL_CAMPAIGN' => '캠페인:',
  'LBL_NAME' => '명칭: ',
  'LBL_INVITEE' => '거래담당자',
  'LBL_LIST_CAMPAIGN_NAME' => '캠페인',
  'LBL_LIST_STATUS' => '상태',
  'LBL_LIST_TYPE' => '종류',
  'LBL_LIST_END_DATE' => '종료일',
  'LBL_DATE_ENTERED' => '등록일',
  'LBL_DATE_MODIFIED' => '편집일',
  'LBL_MODIFIED' => '편집자: ',
  'LBL_CREATED' => '등록자: ',
  'LBL_TEAM' => '부서: ',
  'LBL_ASSIGNED_TO' => '할당: ',
  'LBL_CAMPAIGN_START_DATE' => '시작일: ',
  'LBL_CAMPAIGN_END_DATE' => '종료일: ',
  'LBL_CAMPAIGN_STATUS' => '상태: ',
  'LBL_CAMPAIGN_BUDGET' => '예산: ',
  'LBL_CAMPAIGN_EXPECTED_COST' => '예상경비: ',
  'LBL_CAMPAIGN_ACTUAL_COST' => '실질경비: ',
  'LBL_CAMPAIGN_EXPECTED_REVENUE' => '예상매출: ',
  'LBL_CAMPAIGN_TYPE' => '종류: ',
  'LBL_CAMPAIGN_OBJECTIVE' => '목적: ',
  'LBL_CAMPAIGN_CONTENT' => '상세: ',
  'LNK_NEW_CAMPAIGN' => '캠페인작성',
  'LNK_CAMPAIGN_LIST' => '캠페인리스트',
  'LNK_NEW_PROSPECT' => '타켓작성',
  'LNK_PROSPECT_LIST' => '타켓리스트',
  'LNK_NEW_PROSPECT_LIST' => '타켓리스트작성',
  'LNK_PROSPECT_LIST_LIST' => '타켓리스트',
  'LBL_MODIFIED_BY' => '편집자:',
  'LBL_CREATED_BY' => '등록자: ',
  'LBL_DATE_CREATED' => '등록일: ',
  'LBL_DATE_LAST_MODIFIED' => '편집일: ',
  'LBL_TRACKER_KEY' => '추적: ',
  'LBL_TRACKER_URL' => '추적URL: ',
  'LBL_TRACKER_TEXT' => '추적링크텍스트: ',
  'LBL_TRACKER_COUNT' => '추적 카운트: ',
  'LBL_REFER_URL' => '추적리다이렉트URL: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => '캠페인',
  'LBL_EMAIL_CAMPAIGNS_TITLE' =>'E메일 캠페인',
  'LBL_NEW_FORM_TITLE' => '캠페인 작성',
  'LBL_TRACKED_URLS'=>'추적 URLs',
  'LBL_TRACKED_URLS_SUBPANEL_TITLE'=>'추적 URLs',

  'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => '타켓리스트',
  'LBL_EMAIL_MARKETING_SUBPANEL_TITLE' => 'E메일 마켓팅',
  'LNK_NEW_EMAIL_TEMPLATE' => 'E메일 템플렛 작성',
  'LNK_EMAIL_TEMPLATE_LIST' => 'E메일 템플렛',
  'LBL_TRACK_BUTTON_TITLE' =>'상태표시',
  'LBL_TRACK_BUTTON_KEY' =>'T',
  'LBL_TRACK_BUTTON_LABEL' =>'상태표시',
  'LBL_QUEUE_BUTTON_TITLE'=>'E메일송신',
  'LBL_QUEUE_BUTTON_KEY'=>'u',
  'LBL_QUEUE_BUTTON_LABEL'=>'E메일송신',
  'LBL_TEST_BUTTON_TITLE'=>'테스트송신',
  'LBL_TEST_BUTTON_KEY'=>'e',
  'LBL_TEST_BUTTON_LABEL'=>'테스트송신',

  'LBL_TODETAIL_BUTTON_TITLE'=>'상세표시',
  'LBL_TODETAIL_BUTTON_KEY'=>'T',
  'LBL_TODETAIL_BUTTON_LABEL'=>'상세표시',
  
  'LBL_DEFAULT'=>'전 타켓리스트',
  'LBL_MESSAGE_QUEUE_TITLE'=>'대기 멧세지',
  'LBL_LOG_ENTRIES_TITLE'=>'응답',
  
  'LBL_LOG_ENTRIES_TARGETED_TITLE'=>'송신/시행회수',
  'LBL_LOG_ENTRIES_SEND_ERROR_TITLE'=>'송신에라,기타',  
  'LBL_LOG_ENTRIES_INVALID_EMAIL_TITLE'=>'송신에라,무효 E메일',
  'LBL_LOG_ENTRIES_LINK_TITLE'=>'링크에서클릭',  
  'LBL_LOG_ENTRIES_VIEWED_TITLE'=>'표시멧세지',
  'LBL_LOG_ENTRIES_REMOVED_TITLE'=>'삭제',
  'LBL_LOG_ENTRIES_LEAD_TITLE'=>'리드 작성',
  'LBL_LOG_ENTRIES_CONTACT_TITLE'=>'거래담당자 작성',
  
  'LBL_BACK_TO_CAMPAIGNS'=>'캠페인으로 돌아가기',
  //error messages.
  'ERR_NO_EMAIL_MARKETING'=>'There must be atleast one active Email Marketing message associated with the campaign.',
  'ERR_NO_TARGET_LISTS'=>'There must be atleast one Target List associated with the campaign.',
  'ERR_NO_TEST_TARGET_LISTS'=>'There must be atleast one Target List of type Test associated with the campaign.',  
  'ERR_SENDING_NOW'=>'Messages are being delivered , please try this later.',
  'ERR_MESS_NOT_FOUND_FOR_LIST'=>'No Email Marketing message found for this target list',
  'ERR_MESS_DUPLICATE_FOR_LIST'=>'Multiple Email Marketing message are defined for this target list',
  'ERR_FIX_MESSAGES'=>'Please correct the following errors before proceeding',
  
  'LBL_TRACK_DELETE_BUTTON_KEY'=>'D',
  'LBL_TRACK_DELETE_BUTTON_TITLE'=>'테스트입력 삭제',
  'LBL_TRACK_DELETE_BUTTON_LABEL'=>'테스트입력 삭제',
  'LBL_TRACK_DELETE_CONFIRM'=>'This option will delete log entries created by the test run. Continue?',
  'ERR_NO_MAILBOX'=>"Following marketing message do not have a mailbox associated with them.<BR>Please correct that before proceeding.",
  'LBL_LIST_TO_ACTIVITY'=>'상태표시',
  'LBL_CURRENCY_ID'=>'통화ID',
  'LBL_CURRENCY'=>'통화',
);


?>
