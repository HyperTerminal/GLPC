<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Default English language strings
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: en_us.lang.php,v 1.29 2006/06/06 17:58:33 majed Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => '프로젝트',
	'LBL_MODULE_TITLE' => '프로젝트: 홈',
	'LBL_SEARCH_FORM_TITLE' => '프로젝트 검색',
    'LBL_LIST_FORM_TITLE' => '프로젝트 리스트',
    'LBL_HISTORY_TITLE' => '이력',

	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => '입력일:',
	'LBL_DATE_MODIFIED' => '편집일:',
	'LBL_ASSIGNED_USER_ID' => '할당:',
	'LBL_MODIFIED_USER_ID' => '편집유저Id:',
	'LBL_CREATED_BY' => '등록자:',
	'LBL_TEAM_ID' => '부서:',
	'LBL_NAME' => '명칭:',
	'LBL_DESCRIPTION' => '상세:',
	'LBL_DELETED' => '삭제:',

	'LBL_TOTAL_ESTIMATED_EFFORT' => '견적시간계 (시간):',
	'LBL_TOTAL_ACTUAL_EFFORT' => '실질시간계 (시간):',

	'LBL_LIST_NAME' => '명칭',
	'LBL_LIST_ASSIGNED_USER_ID' => '할당',
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => '견적시간계 (시간)',
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => '실질시간계 (시간)',

	'LBL_PROJECT_SUBPANEL_TITLE' => '프로젝트',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => '프로젝트 타스크',
	'LBL_CONTACT_SUBPANEL_TITLE' => '거래담당자',
	'LBL_ACCOUNT_SUBPANEL_TITLE' => '거래처',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => '안건',
	'LBL_QUOTE_SUBPANEL_TITLE' => '견적',

	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Are you sure you want to remove this contact from this project?',
	
	'LNK_NEW_PROJECT'	=> '프로젝트 작성',
	'LNK_PROJECT_LIST'	=> '프로젝트 리스트',
	'LNK_NEW_PROJECT_TASK'	=> '프로젝트 타스크작성',
	'LNK_PROJECT_TASK_LIST'	=> '프로젝트 타스크',
	'LBL_DEFAULT_SUBPANEL_TITLE' => '프로젝트',
	'LBL_ACTIVITIES_TITLE'=>'영업활동',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'영업활동',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'이력',
	'LBL_QUICK_NEW_PROJECT'	=> '프로젝트 작성',
	
	'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => '프로젝트 타스크',
	'LBL_CONTACTS_SUBPANEL_TITLE' => '거래담당자',
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => '거래처',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => '안건',



);
?>
