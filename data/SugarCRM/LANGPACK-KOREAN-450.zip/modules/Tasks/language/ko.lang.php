<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.41 2006/07/14 00:50:46 jenny Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' 				=> '타스크',
  'LBL_TASK' 						=> '타스크: ',
  'LBL_MODULE_TITLE' 				=> '타스크: 홈',
  'LBL_SEARCH_FORM_TITLE' 		=> '타스크 검색',
  'LBL_LIST_FORM_TITLE' 			=> '타스크 리스트',
  'LBL_NEW_FORM_TITLE' 			=> '타스크 작성',
  'LBL_NEW_FORM_SUBJECT' 		=> '제목:',
  'LBL_NEW_FORM_DUE_DATE' 		=> '종료일:',
  'LBL_NEW_FORM_DUE_TIME' 		=> '종료시간:',
  'LBL_NEW_TIME_FORMAT' 			=> '(24:00)',
  'LBL_LIST_CLOSE' 				=> '종료',
  'LBL_LIST_SUBJECT' 				=> '제목',
  'LBL_LIST_CONTACT' 				=> '거래담당자',
  'LBL_LIST_PRIORITY' 				=> '우선순위',
  'LBL_LIST_RELATED_TO' 			=> '관련처',
  'LBL_LIST_DUE_DATE' 				=> '종료일',
  'LBL_LIST_DUE_TIME' 				=> '종료시간',
  'LBL_SUBJECT' 					=> '제목:',
  'LBL_STATUS' 					=> '상태:',
  'LBL_DUE_DATE' 					=> '종료일:',
  'LBL_DUE_TIME' 					=> '종료시간:',
  'LBL_PRIORITY' 					=> '우선순위:',
  'LBL_COLON' 					=> ':',
  'LBL_DUE_DATE_AND_TIME' 		=> '종료일시:',
  'LBL_START_DATE_AND_TIME' 		=> '시작일시:',
  'LBL_START_DATE' 				=> '시작일:',
  'LBL_LIST_START_DATE' 			=> '시작일',
  'LBL_START_TIME' 				=> '시작시간:',
  'LBL_LIST_START_TIME' 			=> '시작시간',  
  'DATE_FORMAT' 					=> '(yyyy-mm-dd)',
  'LBL_NONE' 						=> '미사용',
  'LBL_CONTACT' 					=> '거래담당자:',
  'LBL_PHONE' 					=> '전화:',
  'LBL_EMAIL' 						=> 'E메일:',
  'LBL_DESCRIPTION_INFORMATION' 	=> '상세정보',
  'LBL_DESCRIPTION' 				=> '상세:',
  'LBL_NAME' 						=> '명칭:',
  'LBL_CONTACT_NAME' 			=> '거래처담당자: ',
  'LBL_LIST_COMPLETE' 			=> '완료:',
  'LBL_LIST_STATUS' 				=> '상태',
  'LBL_DATE_DUE_FLAG' 			=> '종료일',
  'LBL_DATE_START_FLAG' 			=> '시작일',
  'ERR_DELETE_RECORD' 			=> 'A record number must be specified to delete the contact.',
  'ERR_INVALID_HOUR' 				=> 'Please enter an hour between 0 and 24',
  'LBL_DEFAULT_STATUS' 			=> '미시작',
  'LBL_DEFAULT_PRIORITY' 			=> '중',
  'LBL_LIST_MY_TASKS' 			=> 'My 오픈 타스크',
  'LNK_NEW_CALL' 				=> '콜스케쥴작성',
  'LNK_NEW_MEETING' 				=> '미팅스케쥴작성',
  'LNK_NEW_TASK' 				=> '타스크 작성',
  'LNK_NEW_NOTE' 				=> '노트 작성',
  'LNK_NEW_EMAIL' 				=> 'E메일 저장',
  'LNK_CALL_LIST' 					=> '콜스케쥴리스트',
  'LNK_MEETING_LIST' 				=> '미팅스케쥴리스트',
  'LNK_TASK_LIST' 					=> '타스크리스트',
  'LNK_NOTE_LIST' 				=> '노트리스트',
  'LNK_EMAIL_LIST' 				=> 'E메일리스트',
  'LNK_VIEW_CALENDAR' 			=> '오늘',
  'LBL_CONTACT_FIRST_NAME'		=>'거래담당자 이름(명)',
  'LBL_CONTACT_LAST_NAME'		=>'거래담당자 이름(성)',
  'LBL_LIST_ASSIGNED_TO_NAME' 	=> '할당유저',
);
?>
