<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.22 2006/07/14 00:25:51 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => '자료관리',
	'LBL_MODULE_TITLE' => '자료관리: 홈',
	'LNK_NEW_DOCUMENT' => '자료 작성',
	'LNK_DOCUMENT_LIST'=> '자료 리스트',
	'LBL_DOC_REV_HEADER' => '자료 리비젼',
	'LBL_SEARCH_FORM_TITLE'=> '자료 검색',
	//vardef labels
	'LBL_DOCUMENT_ID' => '자료 Id',	
	'LBL_NAME' => '자료명',
	'LBL_DESCRIPTION' => '상세',
	'LBL_CATEGORY' => '카테고리',
	'LBL_SUBCATEGORY' => '서브 카테고리',
	'LBL_STATUS' => '상태', 
	'LBL_CREATED_BY'=> '등록자',
	'LBL_DATE_ENTERED'=> '등록일',
	'LBL_DATE_MODIFIED'=> '최종편집일',
	'LBL_DELETED' => '삭제',
	'LBL_MODIFIED'=> '편집자',
	'LBL_CREATED'=> '등록자',
	'LBL_RELATED_DOCUMENT_ID'=>'관련자료 Id',
	'LBL_RELATED_DOCUMENT_REVISION_ID'=>'관련 자료 개정Id',
	'LBL_IS_TEMPLATE'=>'템플렛',
	'LBL_TEMPLATE_TYPE'=>'자료종류',
	
	'LBL_REVISION_NAME' => '개정번호',
	'LBL_FILENAME' => '파일명',
	'LBL_MIME' => 'Mime종류',
	'LBL_REVISION' => '개정',
	'LBL_DOCUMENT' => '관련 자료',
	'LBL_LATEST_REVISION' => '최종개정번호',
	'LBL_CHANGE_LOG'=> '변경로그',
	'LBL_ACTIVE_DATE'=> '공개일',
	'LBL_EXPIRATION_DATE' => '만료일',
	'LBL_FILE_EXTENSION'  => '파일확장자',
	
	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Unspecified',
	//document edit and detail view
	'LBL_DOC_NAME' => '자료명:',
	'LBL_FILENAME' => '파일명:',
	'LBL_DOC_VERSION' => '개정번호:',
	'LBL_CATEGORY_VALUE' => '카테고리:',
	'LBL_SUBCATEGORY_VALUE'=> '서브카테고리:',
	'LBL_DOC_STATUS'=> '상태:',
	'LBL_LAST_REV_CREATOR' => '개정판작성자:',
	'LBL_LAST_REV_DATE' => '개정일:',
	'LBL_DOWNNLOAD_FILE'=> '다운로드파일:',
	'LBL_DET_RELATED_DOCUMENT'=>'관련 자료:',
	'LBL_DET_RELATED_DOCUMENT_VERSION'=>"관련자료 개정판:",
	'LBL_DET_IS_TEMPLATE'=>'템픞렛? :',
	'LBL_DET_TEMPLATE_TYPE'=>'자료종류:',



	'LBL_DOC_DESCRIPTION'=>'상세:',
	'LBL_DOC_ACTIVE_DATE'=> '발행일:',
	'LBL_DOC_EXP_DATE'=> '만료일:',
	
	//document list view.	
	'LBL_LIST_FORM_TITLE' => '자료리스트',	
	'LBL_LIST_DOCUMENT' => '자료 리스트',
	'LBL_LIST_CATEGORY' => '카테고리',
	'LBL_LIST_SUBCATEGORY' => '서브카테고리',
	'LBL_LIST_REVISION' => '개정판',
	'LBL_LIST_LAST_REV_CREATOR' => '발행자',
	'LBL_LIST_LAST_REV_DATE' => '개정일',
	'LBL_LIST_VIEW_DOCUMENT'=>'표시',
    'LBL_LIST_DOWNLOAD'=> '다운로드',    
	'LBL_LIST_ACTIVE_DATE' => '개정일',
	'LBL_LIST_EXP_DATE' => '만료일',
	'LBL_LIST_STATUS'=>'상태',
	
	//document search form.
	'LBL_SF_DOCUMENT' => '자료명:',
	'LBL_SF_CATEGORY' => '카테고리:',
	'LBL_SF_SUBCATEGORY'=> '서브카테고리:',
	'LBL_SF_ACTIVE_DATE' => '개정일:',
	'LBL_SF_EXP_DATE'=> '만료일:',
	
	'DEF_CREATE_LOG' => '자료작성로그',
	
	//error messages
	'ERR_DOC_NAME'=>'자료명',
	'ERR_DOC_ACTIVE_DATE'=>'개정일',
	'ERR_DOC_EXP_DATE'=> '만료일',
	'ERR_FILENAME'=> '파일명',
	'ERR_DOC_VERSION'=> '자료버젼',
	'ERR_DELETE_CONFIRM'=> 'Do you want to delete this document revision?',
	'ERR_DELETE_LATEST_VERSION'=> 'You are not allowed to delete the latest revision of a document.',
	'LNK_NEW_MAIL_MERGE' => '메일작성',
	'LBL_MAIL_MERGE_DOCUMENT' => '메일작성템플렛:',
	
	'LBL_TREE_TITLE' => '자료관리',
	//sub-panel vardefs.
	'LBL_LIST_DOCUMENT_NAME'=>'자료명',
	'LBL_CONTRACT_NAME'=>'거래담당자명:',
	'LBL_LIST_IS_TEMPLATE'=>'템플렛?',
	'LBL_LIST_TEMPLATE_TYPE'=>'자료종류',
	'LBL_LIST_SELECTED_REVISION'=>'선택개정판',
	'LBL_LIST_LATEST_REVISION'=>'최종개정판',
    //'LNK_DOCUMENT_CAT'=>'Document Categories',
);


?>
