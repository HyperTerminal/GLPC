<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.57 2006/06/09 09:18:52 wayne Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => '안건',
  'LBL_MODULE_TITLE' => '안건: 홈',
  'LBL_SEARCH_FORM_TITLE' => '안건 검색',
  'LBL_VIEW_FORM_TITLE' => '안건 표시',
  'LBL_LIST_FORM_TITLE' => '안건 리스트',
  'LBL_OPPORTUNITY_NAME' => '안건명:',
  'LBL_OPPORTUNITY' => '안건:',
  'LBL_NAME' => '안건명',
  'LBL_INVITEE' => '거래담당자',
  'LBL_LIST_OPPORTUNITY_NAME' => '안건',
  'LBL_LIST_ACCOUNT_NAME' => '거래처명',
  'LBL_LIST_AMOUNT' => '금액',
  'LBL_LIST_DATE_CLOSED' => '종료',
  'LBL_LIST_SALES_STAGE' => '영업스테이지',
  'LBL_ACCOUNT_ID'=>'거래처ID',
  'LBL_CURRENCY_ID'=>'통화ID',
  'LBL_TEAM_ID' =>'부서ID',

//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT

  'UPDATE' => '안건 - 통화 변경',
  'UPDATE_DOLLARAMOUNTS' => 'Update U.S. Dollar Amounts',
  'UPDATE_VERIFY' => 'Verify Amounts',
  'UPDATE_VERIFY_TXT' => 'Verifies that the amount values in opportunities are valid decimal numbers with only numeric characters(0-9) and decimals(.)',
  'UPDATE_FIX' => 'Fix Amounts',
  'UPDATE_FIX_TXT' => 'Attempts to fix any invalid amounts by creating a valid decimal from the current amount. This will backup any amounts it modifies into a database field amount_backup. If you run this and notice bugs, do not rerun this without restoring from the backup as it may overwrite the backup with new invalid data.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Update the U.S. Dollar amounts for opportunities based on the current set currency rates. This value is used to calculate Graphs and List View Currency Amounts.',
  'UPDATE_CREATE_CURRENCY' => 'Creating New Currency:',
  'UPDATE_VERIFY_FAIL' => 'Record Failed Verification:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Current Amount:',
  'UPDATE_VERIFY_FIX' => 'Running Fix would give',
  'UPDATE_INCLUDE_CLOSE' => 'Include Closed Records',
  'UPDATE_VERIFY_NEWAMOUNT' => 'New Amount:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'New Currency:',
  'UPDATE_DONE' => 'Done',
  'UPDATE_BUG_COUNT' => 'Bugs Found and Attempted to Resolve:',
  'UPDATE_BUGFOUND_COUNT' => 'Bugs Found:',
  'UPDATE_COUNT' => 'Records Updated:',
  'UPDATE_RESTORE_COUNT' => 'Record Amounts Restored:',
  'UPDATE_RESTORE' => 'Restore Amounts',
  'UPDATE_RESTORE_TXT' => 'Restores amount values from the backups created during Fix.',
  'UPDATE_FAIL' => 'Could not update - ',
  'UPDATE_NULL_VALUE' => 'Amount is NULL setting it to 0 -',
  'UPDATE_MERGE' => 'Merge Currencies',
  'UPDATE_MERGE_TXT' => 'Merge multiple currencies into a single currency. If you notice that there are multiple currency records for the same currency, you may choose to merge them together. This will also merge the currencies for all other modules.',
  'LBL_ACCOUNT_NAME' => '거래처명:',
  'LBL_AMOUNT' => '금액:',
  'LBL_CURRENCY' => '통화:',
  'LBL_DATE_CLOSED' => '수주예정일:',
  'LBL_TYPE' => '종류:',
  'LBL_NEXT_STEP' => '다음 스텝:',
  'LBL_LEAD_SOURCE' => '리드 소스:',
  'LBL_SALES_STAGE' => '영업스테이지:',
  'LBL_PROBABILITY' => '확률 (%):',
  'LBL_DESCRIPTION' => '상세:',
  'LBL_DUPLICATE' => '안건정보가 중복가능성이있습니다',
  'MSG_DUPLICATE' => 'Creating this opportunity may potentialy create a duplicate opportunity. You may either select an opportunity from the list below or you may click on Create New Opportunity to continue creating a new opportunity with the previously entered data.',
  'LBL_NEW_FORM_TITLE' => '안건 작성',
  'LNK_NEW_OPPORTUNITY' => '안건 작성',
  'LNK_OPPORTUNITY_LIST' => '안건 리스트',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the opportunity.',
  'LBL_TOP_OPPORTUNITIES' => 'My 미처리 안건 리스트',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Are you sure you want to remove this contact from this opportunity?',
	'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Are you sure you want to remove this opportunity from this project?',
	'LBL_AMOUNT_BACKUP'=>'금액 백업',
	'LBL_DEFAULT_SUBPANEL_TITLE' => '안건',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'영업활동',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'이력',
    'LBL_RAW_AMOUNT'=>'안건규모',
	
    'LBL_LEADS_SUBPANEL_TITLE' => '리드',
    'LBL_CONTACTS_SUBPANEL_TITLE' => '거래담당자',
    'LBL_PROJECTS_SUBPANEL_TITLE' => '프로젝트',
	'LBL_ASSIGNED_TO_NAME' => '할당유저:',
	'LBL_LIST_ASSIGNED_TO_NAME' => '할당유저',
  'LBL_LIST_SALES_STAGE' => '영업스테이지',

);

?>
