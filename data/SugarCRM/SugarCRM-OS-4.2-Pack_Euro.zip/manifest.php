<?php
$manifest = array(
    array (
      'exact_matches' =>
        array (
        ),
      'regex_matches' =>
        array (
          0 => '4.2.0[a]'
        ),
    ),
    'acceptable_sugar_flavors' =>
      array (
        0 => 'OS',
      ),

    'name' => 'Pack Euro - Sugar OS 4.2 - CorraTech',

    'description' => 'Change the SugarCRM currency from US dollar ($) to Euro (�)',

    'author' => 'Corratech.fr',

    'published_date' => '2006/06/08',

    'version' => '1.0.2',

    'type' => 'patch',

    'icon' => 'euro-os/include/images/corratech.gif',

    'is_uninstallable' => FALSE,

    'copy_files' =>
  	  array (
  		'from_dir' => 'euro-os',
  		'to_dir' => '',
  		'force_copy' =>
  			array (
  			),
  	  ),
);
?>
 