<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2010 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * Description:  Defines the Spanish language pack for the base application.
 * $Id: es_es.lang.php,v 1.8 2010/08/03 16:29:18 aserrano Exp $
 * Source: SugarCRM 6.0.0
 * Contributor(s): Alberto Serrano (alb.serrano@gmail.com).
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tipos de Producto',
  'LBL_MODULE_TITLE' => 'Tipos de Producto: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Tipos de Producto',
  'LBL_LIST_FORM_TITLE' => 'Lista de Tipos de Producto',
  'LBL_PRODUCTTYPE' => 'Tipo de Producto:',
  'LBL_LIST_NAME' => 'Tipo de Producto',
  'LBL_LIST_DESCRIPTION' => 'Descripción',
  'LBL_NAME' => 'Tipo de Producto:',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_LIST_LIST_ORDER' => 'Orden',
  'LBL_LIST_ORDER' => 'Orden:',
  'LNK_PRODUCT_LIST' => 'Ver Catálogo de Productos',
  'LNK_NEW_PRODUCT' => 'Crear Producto para el Catálogo',
  'LNK_NEW_MANUFACTURER' => 'Proveedores',
  'LNK_NEW_SHIPPER' => 'Proveedores de Transporte',
  'LNK_NEW_PRODUCT_CATEGORY' => 'Categorías de Productos',
  'LNK_NEW_PRODUCT_TYPE' => 'Lista de Tipos de Producto',
  'NTC_DELETE_CONFIRMATION' => '¿Está seguro de que desea eliminar este registro?',
  'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar el tipo de producto.',
  'NTC_LIST_ORDER' => 'Establece el orden en que este tipo aparecerá en las listas desplegables de Tipo de Producto',
  'LNK_IMPORT_PRODUCT_TYPES' => 'Importar Tipos de Producto',
  'LBL_CREATED_BY' => 'Creado Por',
);


?>