<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$mod_strings = array (
  'LBL_ASSIGNED_TO' => 'Atribuído a:',
  'LBL_EMAIL_ADDRESSES' => 'Endereço(s) de E-mail',
  'LBL_FAX' => 'Fax:',
  'LBL_PUSH_BILLING' => 'Pagamento Push',
  'LBL_PUSH_SHIPPING' => 'Pagamento Push',
  'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Tem a certeza que pretende remover a empresa deste projecto?',
  'ERR_DELETE_RECORD' => 'Um número de registo deve ser especificado para eliminar a empresa.',
  'LBL_ACCOUNT_NAME' => 'Nome da Empresa:',
  'LBL_ACCOUNT' => 'Empresa:',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Atividades',
  'LBL_ADDRESS_INFORMATION' => 'Informação de Endereço',
  'LBL_ANNUAL_REVENUE' => 'Rendimento Anual:',
  'LBL_ANY_ADDRESS' => 'Qualquer Endereço:',
  'LBL_ANY_EMAIL' => 'Qualquer E-mail:',
  'LBL_ANY_PHONE' => 'Qualquer Telefone:',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuído a:',
  'LBL_RATING' => 'Classificação',
  'LBL_ASSIGNED_USER' => 'Atribuído a:',
  'LBL_ASSIGNED_TO_ID' => 'Atribuído a:',
  'LBL_BILLING_ADDRESS_CITY' => 'Cidade de Faturamento:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'País de Faturamento:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'CEP de Faturamento:',
  'LBL_BILLING_ADDRESS_STATE' => 'Estado de Faturamento:',
  'LBL_BILLING_ADDRESS_STREET_2' => 'Rua de Faturamento 2',
  'LBL_BILLING_ADDRESS_STREET_3' => 'Rua de Faturamento 3',
  'LBL_BILLING_ADDRESS_STREET_4' => 'Rua de Faturamento 4',
  'LBL_BILLING_ADDRESS_STREET' => 'Rua de Faturamento:',
  'LBL_BILLING_ADDRESS' => 'Endereço de Faturamento:',
  'LBL_ACCOUNT_INFORMATION' => 'Informação da Empresa',
  'LBL_CITY' => 'Cidade:',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contatos',
  'LBL_COUNTRY' => 'País:',
  'LBL_DATE_ENTERED' => 'Data de Criação:',
  'LBL_DATE_MODIFIED' => 'Data de Modificação:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Empresas',
  'LBL_DESCRIPTION_INFORMATION' => 'Informação de Descrição',
  'LBL_DESCRIPTION' => 'Descrição:',
  'LBL_DUPLICATE' => 'Possível Empresa Duplicada',
  'LBL_EMAIL' => 'E-mail:',
  'LBL_EMPLOYEES' => 'Empregados:',
  'LBL_INDUSTRY' => 'Indústria:',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Empresa',
  'LBL_LIST_CITY' => 'Cidade',
  'LBL_LIST_EMAIL_ADDRESS' => 'Endereço de E-mail',
  'LBL_LIST_PHONE' => 'Telefone',
  'LBL_LIST_STATE' => 'Estado',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_MEMBER_OF' => 'Membro de:',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organizações Membro',
  'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Organizações Membro',
  'LBL_NAME' => 'Nome:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro E-mail:',
  'LBL_OTHER_PHONE' => 'Outro Telefone:',
  'LBL_OWNERSHIP' => 'Propriedade:',
  'LBL_PARENT_ACCOUNT_ID' => 'ID Empresa de Origem',
  'LBL_PHONE_ALT' => 'Telefone Alternativo:',
  'LBL_PHONE_FAX' => 'Fax:',
  'LBL_PHONE_OFFICE' => 'Telefone Comercial:',
  'LBL_PHONE' => 'Telefone:',
  'LBL_EMAIL_ADDRESS' => 'Endereço(s) de E-mail',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_SAVE_ACCOUNT' => 'Gravar Empresa',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Cidade de Entrega:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'País de Entrega:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'CEP Entrega:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Estado de Entrega:',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Rua de Entrega 2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Rua de Entrega 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Rua de Entregao 4',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Rua de Entrega',
  'LBL_SHIPPING_ADDRESS' => 'Endereço de Entrega',
  'LBL_STATE' => 'Estado:',
  'LBL_TEAMS_LINK' => 'Equipes',
  'LBL_TICKER_SYMBOL' => 'Símbolo de Bolsa',
  'LBL_TYPE' => 'Tipo:',
  'LBL_USERS_ASSIGNED_LINK' => 'Usuários',
  'LBL_USERS_CREATED_LINK' => 'Criado pelo Usuário',
  'LBL_USERS_MODIFIED_LINK' => 'Usuários Modificados',
  'LBL_VIEW_FORM_TITLE' => 'Visualização da Empresa',
  'LBL_WEBSITE' => 'Website:',
  'LNK_ACCOUNT_LIST' => 'Empresas',
  'LNK_NEW_ACCOUNT' => 'Criar Empresa',
  'MSG_DUPLICATE' => 'A criação desta empresa poderá gerar potencialmente uma empresa duplicada. Você pode selecionar uma empresa na lista abaixo ou clicar em Gravar para continuar a criar uma nova empresa com os dados previamente inseridos.',
  'MSG_SHOW_DUPLICATES' => 'A criação desta empresa poderá gerar potencialmente uma empresa duplicada. Você pode clicar em Gravar para continuar a criar esta nova empresa com os dados previamente inseridos ou pode clicar em Cancelar.',
  'NTC_COPY_BILLING_ADDRESS' => 'Copiar endereço de faturamento para endereço de entrega',
  'NTC_COPY_BILLING_ADDRESS2' => 'Copiar para entrega',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar endereço de entrega para endereço de faturamento',
  'NTC_COPY_SHIPPING_ADDRESS2' => 'Copiar para faturamento',
  'NTC_DELETE_CONFIRMATION' => 'Tem certeza que pretende remover este registo?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Tem certeza que pretende remover este registo?',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Tem certeza que pretende remover este registo como organização membro?',
);

