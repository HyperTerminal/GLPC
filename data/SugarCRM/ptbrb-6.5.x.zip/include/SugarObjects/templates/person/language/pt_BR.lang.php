<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Master Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/master-subscription-agreement
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2012 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/

	

$mod_strings = array (
  'LBL_ANY_EMAIL' => 'Outro E-mail:',
  'LBL_FAX_PHONE' => 'Fax',
  'LBL_SALUTATION' => 'Saudação',
  'LBL_NAME' => 'Nome',
  'LBL_FIRST_NAME' => 'Primeiro Nome',
  'LBL_LAST_NAME' => 'Último Nome',
  'LBL_TITLE' => 'Título',
  'LBL_DEPARTMENT' => 'Departamento',
  'LBL_DO_NOT_CALL' => 'Não Telefonar',
  'LBL_HOME_PHONE' => 'Telefone de Residencial',
  'LBL_MOBILE_PHONE' => 'Telefone Celular',
  'LBL_OFFICE_PHONE' => 'Telefone Comercial',
  'LBL_OTHER_PHONE' => 'Outro Telefone',
  'LBL_EMAIL_ADDRESS' => 'Endereço(s) de E-mail',
  'LBL_PRIMARY_ADDRESS' => 'Endereço Principal',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Endereço Principal',
  'LBL_PRIMARY_ADDRESS_STREET_2' => 'Rua Endereço Principal 2:',
  'LBL_PRIMARY_ADDRESS_STREET_3' => 'Rua Endereço Principal 3:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Cidade',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Estado',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'CEP',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'País Endereço Principal:',
  'LBL_ALT_ADDRESS' => 'Endereço Alternativo',
  'LBL_ALT_ADDRESS_STREET' => 'Outro Endereço',
  'LBL_ALT_ADDRESS_STREET_2' => 'Outro Endereço Rua 2:',
  'LBL_ALT_ADDRESS_STREET_3' => 'Outro Endereço Rua 3:',
  'LBL_ALT_ADDRESS_CITY' => 'Cidade Alternativa',
  'LBL_ALT_ADDRESS_STATE' => 'Estado Alternativo',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'CEP Alternativo',
  'LBL_ALT_ADDRESS_COUNTRY' => 'País Alternativo',
  'LBL_COUNTRY' => 'País',
  'LBL_STREET' => 'Outro Endereço',
  'LBL_PRIMARY_STREET' => 'Endereço:',
  'LBL_ALT_STREET' => 'Outro Endereço:',
  'LBL_CITY' => 'Cidade',
  'LBL_STATE' => 'Estado',
  'LBL_POSTALCODE' => 'CEP',
  'LBL_POSTAL_CODE' => 'CEP',
  'LBL_CONTACT_INFORMATION' => 'Informação de Contato',
  'LBL_ADDRESS_INFORMATION' => 'Endereço(s)',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuído a',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro E-mail:',
  'LBL_ASSISTANT' => 'Assistente',
  'LBL_ASSISTANT_PHONE' => 'Telefone de Assistente',
  'LBL_WORK_PHONE' => 'Telefone Comercial',
  'LNK_IMPORT_VCARD' => 'Criar a partir do vCard',
  'LBL_PICTURE_FILE' => 'Fotografia',
);

