<?php 
$manifest = array( 
	'name' => 'Finnish',
	'description' => 'Finnish langpack by Antamis',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '4.5.1g 1.0',
	'acceptable_sugar_flavors' => array ("OS"),
	'published_date' => '1.11.2007',
	'author' => 'Markku Suominen / markku.suominen@antamis.com',
	'acceptable_sugar_versions' => array ("4.5.1*"),
);

$installdefs = array(
	'id'=> 'fi_fi',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>