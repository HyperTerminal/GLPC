<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_ACCEPT_THIS' => 'Hyväksy?',
  'LBL_ADD_BUTTON' => 'Lisää',
  'LBL_ADD_INVITEE' => 'Lisää kutsutut',
  'LBL_BLANK' => '&nbsp;',
  'LBL_COLON' => ':',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_CREATED_BY' => 'Luonut: ',
  'LBL_DATE_END' => 'Lopetuspäivä',
  'LBL_DATE_TIME' => 'Aloituspäivä ja aika:',
  'LBL_DATE' => 'Aloituspäivä:',
  'LBL_DEFAULT_STATUS' => 'Ei aloitettu',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_DEL' => 'Poista',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_DURATION_HOURS' => 'Kesto tunteja:',
  'LBL_DURATION_MINUTES' => 'Kesto minuutteja:',
  'LBL_DURATION' => 'Kesto:',
  'LBL_EMAIL' => 'Sähköposti:',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_HOURS_MINS' => '(tuntia/minuuttia)',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
  'LBL_LIST_CLOSE' => 'Sulje',
  'LBL_LIST_CONTACT' => 'Kontaktit',
  'LBL_LIST_DATE_MODIFIED' => 'Viimeksi muutettu',
  'LBL_LIST_DATE' => 'Aloituspäivä',
  'LBL_LIST_DUE_DATE' => 'Valmistumispäivä',
  'LBL_LIST_FORM_TITLE' => 'Tapaamiset',
  'LBL_LIST_MY_MEETINGS' => 'Omat tapaamiset',
  'LBL_LIST_RELATED_TO' => 'Liittyy aiheeseen',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_TIME' => 'Aloitusaika',
  'LBL_LOCATION' => 'Sijainti:',
  'LBL_MEETING' => 'Tapaaminen:',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_MODIFIED_BY' => 'Muokannut: ',
  'LBL_MODULE_NAME' => 'Tapaamiset',
  'LBL_MODULE_TITLE' => 'Tapaamiset: etusivu',
  'LBL_NAME' => 'Nimi:',
  'LBL_NEW_FORM_TITLE' => 'Uusi tapaaminen',
  'LBL_OUTLOOK_ID' => 'Outlook ID',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_REMINDER_TIME' => 'Muistutusaika',
  'LBL_REMINDER' => 'Oletusmuistutus:',
  'LBL_SCHEDULING_FORM_TITLE' => 'Aikataulu',
  'LBL_SEARCH_BUTTON' => 'Etsi',
  'LBL_SEARCH_FORM_TITLE' => 'Hae tapaaminen',
  'LBL_SEND_BUTTON_KEY' => 'I',
  'LBL_SEND_BUTTON_LABEL' => 'Lähetä kutsut',
  'LBL_SEND_BUTTON_TITLE' => 'Lähetä kutsut [Alt+I]',
  'LBL_STATUS' => 'Tila:',
  'LBL_SUBJECT' => 'Aihe',
  'LBL_TIME' => 'Aloitusaika:',
  'LBL_USERS_SUBPANEL_TITLE' => 'Käyttäjät',
  'LNK_CALL_LIST' => 'Puhelut',
  'LNK_EMAIL_LIST' => 'Sähköpostit',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_NEW_APPOINTMENT' => 'Uusi tapaaminen',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_NOTE_LIST' => 'Muistiot',
  'LNK_TASK_LIST' => 'Tehtävät',
  'LNK_VIEW_CALENDAR' => 'Tänään',
  'NTC_REMOVE_INVITEE' => 'Haluatko poistaa henkilön tapaamisesta?',
  'LBL_ACCEPT_STATUS' => "Hyväksy tila:", // longreach
  'LBL_ACCOUNT' => "Asiakas",
  'LBL_ADD_RESOURCE_BUTTON' => "Lisää resurssi",
  'LBL_IS_FIRST_RECURRING' => "Tämä on ensimmäinen toistuvan tapaamisen ilmentymä.",
  'LBL_IS_RECURRENCE' => "Tämä on toistuvan tapaamisen ilmentymä.",
  'LBL_RESOURCES_SUBPANEL_TITLE' => "Resurssit",
);


?>