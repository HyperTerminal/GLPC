<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'ERR_INT_ONLY_EMAIL_PER_RUN' => 'Vain kokonaislukuja Sähköposteja per ajo -asetuksessa?',
  'LBL_ATTACHMENT_AUDIT' => ' lähetettiin. Siitä ei tehty kaksoiskappaletta paikallisesti levytilan säästämiseksi.',
  'LBL_CONFIGURE_SETTINGS' => 'Asetukset',
  'LBL_CUSTOM_LOCATION' => 'Käyttäjän määrittelemä',
  'LBL_DEFAULT_LOCATION' => 'Oletus',
  'LBL_EMAIL_DEFAULT_CHARSET' => 'Lähetä sähköpostia käyttäen tätä merkistöä',
  'LBL_EMAIL_DEFAULT_CLIENT' => 'Uusi sähköposti tässä muodossa',
  'LBL_EMAIL_DEFAULT_EDITOR' => 'Uusi sähköposti käyttäen tätä ohjelmaa',
  'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS' => 'Poista sähköpostien mukana niihin liittyvät muistiot ja liitetiedostot',
  'LBL_EMAIL_PER_RUN_REQ' => 'Sähköposteja per ajo',
  'LBL_EMAIL_USER_TITLE' => 'Käyttäjän sähköpostin oletusarvot',
  'LBL_EMAILS_PER_RUN' => 'Sähköposteja per ajo',
  'LBL_ID' => 'Relaation Id',
  'LBL_LIST_CAMPAIGN' => 'Kampanja',
  'LBL_LIST_FORM_PROCESSED_TITLE' => 'Suoritettu',
  'LBL_LIST_FORM_TITLE' => 'Käyttäjät',
  'LBL_LIST_FROM_EMAIL' => 'Lähettäjän sähköpostiosoite',
  'LBL_LIST_FROM_NAME' => 'Lähettäjän nimi',
  'LBL_LIST_IN_QUEUE' => 'Prosessoidaan',
  'LBL_LIST_MESSAGE_NAME' => 'Markkinointiviesti',
  'LBL_LIST_RECIPIENT_EMAIL' => 'Vastaanottajan sähköposti',
  'LBL_LIST_RECIPIENT_NAME' => 'Vastaanottajan nimi',
  'LBL_LIST_SEND_ATTEMPTS' => 'Lähetysyrityksiä',
  'LBL_LIST_SEND_DATE_TIME' => 'Lähetysaika',
  'LBL_LIST_USER_NAME' => 'Käyttäjätunnus',
  'LBL_LOCATION_ONLY' => 'Sijainti',
  'LBL_LOCATION_TRACK' => 'Seurantatiedostojen sijainti(kuten campaign_tracker.php)',
  'LBL_CAMP_MESSAGE_COPY' => 'Säilytä kampanjaviestien kopiot:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Käytä SMTP autentikointia?',
  'LBL_MAIL_SMTPPASS' => 'SMTP salasana:',
  'LBL_MAIL_SMTPPORT' => 'SMTP portti:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP palvelin:',
  'LBL_MAIL_SMTPUSER' => 'SMTP käyttäjätunnus:',
  'LBL_MARKETING_ID' => 'Markkinointi Id',
  'LBL_MODULE_ID' => 'EmailMan',
  'LBL_MODULE_NAME' => 'Sähköpostiasetukset',
  'LBL_MODULE_TITLE' => 'Lähtevän sähköpostin jonon hallinta',
  'LBL_NOTIFICATION_ON_DESC' => 'Lähettää muistutusviestin kun tehtäviä osoitetaan käyttäjille.',
  'LBL_NOTIFY_FROMADDRESS' => 'Lähettäjän osoite:',
  'LBL_NOTIFY_FROMNAME' => 'Lähettäjän nimi:',
  'LBL_NOTIFY_ON' => 'Muistutukset päällä?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Lähetä muistutukset oletusarvoisesti?',
  'LBL_NOTIFY_TITLE' => 'Sähköpostin lähetysvalinnat',
  'LBL_OLD_ID' => 'Vanha Id',
  'LBL_OUTBOUND_EMAIL_TITLE' => 'Lähtevän sähköpostin valinnat',
  'LBL_RELATED_ID' => 'Liittyvä Id',
  'LBL_RELATED_TYPE' => 'Liittyvä tyyppi',
  'LBL_SAVE_OUTBOUND_RAW' => 'Tallenne lähtevien viestien raakadata',
  'LBL_SEARCH_FORM_PROCESSED_TITLE' => 'Haku suoritettu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae käyttäjä',
  'LBL_VIEW_PROCESSED_EMAILS' => 'Näytä lähetetyt sähköpostit',
  'LBL_VIEW_QUEUED_EMAILS' => 'Näytä jonossa olevat sähköpostit',
  'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE' => 'Config.php tiedoston site_url -asetuksen arvo',
  'TXT_REMOVE_ME_ALT' => 'Poistaaksesi itsesi tältä sähköpostilistalta siirry kohtaan ',
  'TXT_REMOVE_ME_CLICK' => 'napsauta tässä',
  'TXT_REMOVE_ME' => 'poistaaksesi sähköpostiosoitteesi postituslistalta ',
  'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER' => 'Lähetä muistutus vastuuhenkilön sähköpostiosoitteesta?',
  'LBL_SECURITY_TITLE' => 'Sähköpostin tietoturva-asetukset',
  'LBL_SECURITY_DESC' => 'Valitse tagit, joita ei sallita saapuvissa sähköpostiviesteissä ja joita ei esitetä Sähköpostit-moduulissa.',
  'LBL_SECURITY_APPLET' => 'Applet tagi',
  'LBL_SECURITY_BASE' => 'Base tagi',
  'LBL_SECURITY_EMBED' => 'Embed tagi',
  'LBL_SECURITY_FORM' => 'Form tagi',
  'LBL_SECURITY_FRAME' => 'Frame tagi',
  'LBL_SECURITY_FRAMESET' => 'Frameset tagi',
  'LBL_SECURITY_IFRAME' => 'iFrame tagi',
  'LBL_SECURITY_IMPORT' => 'Import tagi',
  'LBL_SECURITY_LAYER' => 'Layer tagi',
  'LBL_SECURITY_LINK' => 'Link tagi',
  'LBL_SECURITY_OBJECT' => 'Object tagi',
  'LBL_SECURITY_OUTLOOK_DEFAULTS' => 'Valitse Outlookin vähimmäisturva-asetukset (virheet oikeanmuotoisen näytön vieressä).',
  'LBL_SECURITY_PRESERVE_RAW' => 'Säilytä sähköpostin lähdekoodi, mukaan lukien mahdollinen haitallinen sisältö. Tämä valinta säilyttää alkuperäisen lähdekoodin vain tietokannassa, sitä ei esitetä sellaisenaan Sugarin käyttöliittymässä.<br /><span class="error">Tämä voi altistaa järjestelmän haavoittuvuuksille.</span>',
  'LBL_SECURITY_SCRIPT' => 'Script tagi',
  'LBL_SECURITY_STYLE' => 'Style tagi',
  'LBL_SECURITY_TOGGLE_ALL' => 'Muuta kaikki valinnat',
  'LBL_SECURITY_XMP' => 'Xmp tagi',
  'LBL_YES' => 'Kyllä',
  'LBL_NO' => 'Ei',
  'LBL_PREPEND_TEST' => '[Testi]: ',
);


?>