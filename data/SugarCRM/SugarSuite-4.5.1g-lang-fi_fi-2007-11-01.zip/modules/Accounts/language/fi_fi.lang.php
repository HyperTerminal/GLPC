<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Asiakkaat',
  'LBL_MODULE_TITLE' => 'Asiakkaat: etusivu',
  'LBL_HOMEPAGE_TITLE' => 'Omat asiakkaat',
  'LBL_SEARCH_FORM_TITLE' => 'Hae asiakas',
  'LBL_LIST_FORM_TITLE' => 'Asiakkaat',
  'LBL_VIEW_FORM_TITLE' => 'Asiakasnäkymä',
  'LBL_NEW_FORM_TITLE' => 'Uusi asiakas',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Jäsenorganisaatiot',
  'LBL_BUG_FORM_TITLE' => 'Asiakkaat',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_CITY' => 'Kaupunki',
  'LBL_LIST_WEBSITE' => 'WWW-sivusto',
  'LBL_LIST_STATE' => 'Lääni',
  'LBL_LIST_PHONE' => 'Puhelin',
  'LBL_LIST_EMAIL_ADDRESS' => 'Sähköposti',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktit',
  'LBL_BILLING_ADDRESS_STREET_2' => 'Laskutusosoite 2',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_BILLING_ADDRESS_STREET_3' => 'Laskutusosoite 3',
  'LBL_BILLING_ADDRESS_STREET_4' => 'Laskutusosoite 4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Postitusosoite 2',
//END DON'T CONVERT
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Postitusosoite 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Postitusosoite 4',
  'LBL_PARENT_ACCOUNT_ID' => 'Parent Account ID',
  'LBL_CAMPAIGN_ID' => 'Campaign ID',
  'db_name' => 'LBL_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
  'LBL_ACCOUNT_INFORMATION' => 'Tietoja asiakkaasta',
  'LBL_ACCOUNT' => 'Asiakas:',
  'LBL_ACCOUNT_NAME' => 'Asiakas',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_PHONE_ALT' => 'Muu puhelin:',
  'LBL_WEBSITE' => 'WWW-sivusto:',
  'LBL_FAX' => 'Faksi:',
  'LBL_TICKER_SYMBOL' => 'Merkintäsymboli:',
  'LBL_OTHER_PHONE' => 'Muu puhelin:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_MEMBER_OF' => 'Jäsen:',
  'LBL_PHONE_OFFICE' => 'Toimiston numero:',
  'LBL_PHONE_FAX' => 'Puhelinfaksi:',
  'LBL_EMAIL' => 'Sähköposti:',
  'LBL_EMPLOYEES' => 'Työntekijät:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Muu sähköposti:',
  'LBL_ANY_EMAIL' => 'Muu sähköposti:',
  'LBL_OWNERSHIP' => 'Omistaja:',
  'LBL_RATING' => 'Arvio:',
  'LBL_INDUSTRY' => 'Toimiala:',
  'LBL_SIC_CODE' => 'LY-tunnus:',
  'LBL_TYPE' => 'Tyyppi',
  'LBL_ANNUAL_REVENUE' => 'Liikevaihto:',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_BILLING_ADDRESS' => 'Laskutusosoite:',
  'LBL_BILLING_ADDRESS_STREET' => 'Laskutusosoite katuosoite:',
  'LBL_BILLING_ADDRESS_CITY' => 'Laskutusosoite kaupunki:',
  'LBL_BILLING_ADDRESS_STATE' => 'Laskutusosoite lääni:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Laskutusosoite postinumero:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Laskutusosoite maa:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Postitusosoite katuosoite:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Postitusosoite kaupunki:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Postitusosoite lääni:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Postitusosoite postinumero:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Postitusosoite maa:',
  'LBL_SHIPPING_ADDRESS' => 'Postitusosoite:',
  'LBL_DATE_MODIFIED' => 'Muokkauspäivä',
  'LBL_DATE_ENTERED' => 'Kirjauspäivä',
  'LBL_ANY_ADDRESS' => 'Muu osoite:',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_STATE' => 'Lääni:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_PUSH_CONTACTS_BUTTON_TITLE' => 'Kopioi',
  'LBL_PUSH_CONTACTS_BUTTON_LABEL' => 'Kopioi kontakteihin',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopioi laskutusosoite postitusosoitteeksi',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopioi postitusosoite laskutusosoitteeksi',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Haluatko varmasti poistaa tämän jäsenorganisaation',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Haluatko poistaa tämän bugin tältä asiakkaalta?',
  'LBL_DUPLICATE' => 'Mahdollisesti kaksi samanlaista asiakasta',
  'MSG_SHOW_DUPLICATES' => 'Uuden asiakkaan luonti voi tuottaa kaksoiskappaleen. Peru toiminto napsauttamalla Peru-painiketta tai luo uusi asiakas napsauttamalla Tallenna-painiketta.',
  'MSG_DUPLICATE' => 'Asiakkaan luonti voi tuottaa kaksoiskappaleen. Voit joko valita asiakkaan alle olevasta listasta tai napsauttaa Luo asiakas -painiketta jatkaaksesi uuden asiakkaan luontia aikaisemmin syötetyn tiedon pohjalta.',
  'LNK_NEW_ACCOUNT' => 'Uusi asiakas',
  'LNK_ACCOUNT_LIST' => 'Asiakkaat',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tämän tietueen?',
  'LBL_SAVE_ACCOUNT' => 'Tallenna asiakas',
  'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Halutko poistaa asiakkaan tästä projektista?',
  'LBL_USERS_ASSIGNED_LINK' => 'Määritellyt käyttäjät',
  'LBL_USERS_MODIFIED_LINK' => 'Muokatut käyttäjät',
  'LBL_USERS_CREATED_LINK' => 'Luotu käyttäjien toimesta',
  'LBL_TEAMS_LINK' => 'Tiimit',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_PRODUCTS_TITLE' => 'Tuotteet',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Jäsenorganisaatiot',
  'LBL_NAME' => 'Nimi:',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Liidit',
  'LBL_CASES_SUBPANEL_TITLE' => 'Palvelupyynnöt',
  'LBL_BUGS_SUBPANEL_TITLE' => 'Bugit',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projektit',
  'LBL_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
  'LBL_DEFAULT' => 'Näkymät',
  'LBL_CHARTS' => 'Kaaviot',
  'LBL_UTILS' => 'Apuohjelmat',
  'LBL_MISC' => 'Muuta',
    // Dashlet Categories
);


?>