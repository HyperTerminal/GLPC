<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'ERR_BAD_LOGIN_PASSWORD' => 'Virheellinen käyttäjätunnus tai salasana',
  'ERR_BODY_TOO_LONG' => 'Runkoteksti liian pitkä, viestistä noudetaan vain osa.',
  'ERR_INI_ZLIB' => 'Zlib-pakkausta ei saatu väliaikaisesti pois päältä.  "Kokeile asetuksia" voi epäonnistua.',
  'ERR_MAILBOX_FAIL' => 'Yhtään postilaatikkoa ei pystytty hakemaan.',
  'ERR_NO_IMAP' => 'IMAP-kirjastoja ei löydetä. Korjaa tämä ennen kuin jatkat saaapuvan sähköpostin asetusten muuttamista',
  'ERR_NO_OPTS_SAVED' => 'Saapuvan postin optimiasetuksia ei tallennettu. Tarkista asetukset',
  'ERR_TEST_MAILBOX' => 'Tarkista asetukset ja yritä uudelleen.',
  'LBL_APPLY_OPTIMUMS' => 'Ota optimiasetukset käyttöön',
  'LBL_ASSIGN_TO_USER' => 'Valitse vastuuhenkilö',
  'LBL_AUTOREPLY_OPTIONS' => 'Automaattivastauksen valinnat',
  'LBL_AUTOREPLY' => 'Automaattivastauksen pohja',
  'LBL_BASIC' => 'Perusasetukset',
  'LBL_CASE_MACRO' => 'Palvelupyynnön makro',
  'LBL_CASE_MACRO_DESC' => 'Määrittele makro, jota käytetään tulevien sähköpostien linkittämiseen palvelupyyntöihin.',
  'LBL_CASE_MACRO_DESC2' => 'Voit antaa minkä arvon tahansa, mutta säilytä merkintä <b>"%1"</b>.',
  'LBL_CERT_DESC' => 'Pakota sähköpostipalvelimen turvasertifikaatin tunnistus - älä käytä jos self-signing.',
  'LBL_CERT' => 'Validoi sertifikaatti',
  'LBL_CLOSE_POPUP' => 'Sulje ikkuna',
  'LBL_CREATE_NEW_GROUP' => '--Luo postilaatikkoryhmä tallennettaessa --',
  'LBL_CREATE_TEMPLATE' => 'Luo',
  'LBL_DEFAULT_FROM_ADDR' => 'Oletus: ',
  'LBL_DEFAULT_FROM_NAME' => 'Oletus: ',
  'LBL_DELETE_SEEN' => 'Delete Read Emails After Import',
  'LBL_EDIT_TEMPLATE' => 'Muokkaa',
  'LBL_EMAIL_OPTIONS' => 'Sähköpostin käsittelyvalinnat',
  'LBL_FILTER_DOMAIN_DESC' => 'Älä lähetä automaattivastauksia tähän domainiin.',
  'LBL_FILTER_DOMAIN' => 'Älä lähetä automaattivastausta domainiin',
  'LBL_FIND_OPTIMUM_KEY' => 'f',
  'LBL_FIND_OPTIMUM_MSG' => '<br>Haetaan yhteyden optimiasetuksia.',
  'LBL_FIND_OPTIMUM_TITLE' => 'Hae optimiasetukset',
  'LBL_FIND_SSL_WARN' => '<br>SSL:n testaaminen voi kestää kauan, odota.<br>',
  'LBL_FORCE_DESC' => 'Osa IMAP/POP3 -palvelimista vaatii erikoisasetuksia. Tarkista asetukset pakottaaksesi käänteiset asetukset voimaan yhteyttä luotaessa (kuten esim. /notls)',
  'LBL_FORCE' => 'Pakota käänteiset asetukset',
  'LBL_FOUND_MAILBOXES' => 'Seuraavat postilaatikot löydettiin:',
  'LBL_FOUND_OPTIMUM_MSG' => '<br>Optimiasetukset löydetty. Napsauta alle olevaa painiketta ottaaksesi ne sähköpostilaatikkosi käyttöön.',
  'LBL_FROM_ADDR' => 'Lähettäjän osoite',
  'LBL_FROM_NAME_ADDR' => 'Vastaanottajan nimi/sähköpostiosoite:',
  'LBL_FROM_NAME' => '"Lähettäjän nimi',
  'LBL_GROUP_QUEUE' => 'Määrittele ryhmälle',
  'LBL_HOME' => 'Etusivu',
  'LBL_LIST_MAILBOX_TYPE' => 'Postilaatikon käyttöaste',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_SERVER_URL' => 'Sähköpostipalvelin:',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LOGIN' => 'Kirjaudu',
  'LBL_MAILBOX_DEFAULT' => 'SAAPUVAT',
  'LBL_MAILBOX_SSL_DESC' => 'SSL:ä yhteyttä muodostettaessa. Jos tämä ei toimi, tarkista että PHP-ympäristön asetuksissa on "--with-imap-ssl" .',
  'LBL_MAILBOX_SSL' => 'Käytä SSL:ä',
  'LBL_MAILBOX_TYPE' => 'Mahdolliset toiminnot',
  'LBL_MAILBOX' => 'Seurannassa olevat kansiot',
  'LBL_MARK_READ_DESC' => 'Merkitse viestit luetuiksi posteja tuotaessa; älä poista.',
  'LBL_MARK_READ_NO' => 'Sähköposti merkitty poistetuksi tuonnin jälkeen',
  'LBL_MARK_READ_YES' => 'Sähköposti jätetään palvelimelle tuonnin jälkeen',
  'LBL_MARK_READ' => 'Jätä viestit palvelimelle',
  'LBL_MODULE_NAME' => 'Sähköposti',
  'LBL_MODULE_TITLE' => 'Sähköposti: etusivu',
  'LBL_NAME' => 'Nimi:',
  'LBL_NO_OPTIMUMS' => 'Optimiarvoja ei löydetty. Tarkista asetukset ja yritä uudelleen.',
  'LBL_ONLY_SINCE_DESC' => 'Jos käytössä on POP3, PHP ei voi erotella luettuja/ei-luettuja viestejä. Tämä valinta mahdollistaan viimeisimmän tarkistuksen jälkeen saapuneiden viestien noutamisen. Asetus nopeuttaa sähköpostin hakun huomattavasti jos sähköpostipalvelin ei tue IMAP-protokollaa.',
  'LBL_ONLY_SINCE_NO' => 'Ei, tarkista kaikkia palvelimelle olevia viestejä vastaan.',
  'LBL_ONLY_SINCE_YES' => 'Kyllä',
  'LBL_ONLY_SINCE' => 'Tuo vain viimeisimmän tarkistuksen jälkeen:',
  'LBL_PASSWORD_CHECK' => 'Tarkista salasana',
  'LBL_PASSWORD' => 'Salasana:',
  'LBL_POP3_SUCCESS' => 'POP3-yhteyden testaaminen onnistui.',
  'LBL_POPUP_FAILURE' => 'Yhteyden muodostaminen epäonnistui. Virhe näytetään alla.',
  'LBL_POPUP_SUCCESS' => 'Yhteyden muodostaminen onnistui. Asetukset ovat oikein.',
  'LBL_POPUP_TITLE' => 'Kokeile asetuksia',
  'LBL_PORT' => 'Sähköpostipalvelimen portti',
  'LBL_QUEUE' => 'Sähköpostijono',
  'LBL_SAVE_RAW' => 'Tallenna alkuperäinen data (raw source)',
  'LBL_SAVE_RAW_DESC_1' => 'Valitse "Kyllä" jos haluat tallentaa jokaisen tuodun sähköpostiviestin alkuperäisen datan (raw source).',
  'LBL_SAVE_RAW_DESC_2' => 'Suuret liitetiedostot voivat aiheuttaa ongelmia vääriä asetuksia käyttävien tietokantojen kanssa.',
  'LBL_SERVER_OPTIONS' => 'Postipalvelimen valinnat',
  'LBL_SERVER_TYPE' => 'Postipalvelimen protokolla',
  'LBL_SERVER_URL' => 'Saapuvan postin palvelin',
  'LBL_SSL_DESC' => 'Jos sähköpostipalvelimesi tukee secure socket -yhteyksiä, tämä asetus pakottaa SSL-yhteyksien käyttöön sähköpostia tuotaessa.',
  'LBL_SSL' => 'Käytä SSL:ä',
  'LBL_STATUS' => 'Tila:',
  'LBL_SYSTEM_DEFAULT' => 'Oletus',
  'LBL_TEST_BUTTON_KEY' => 't',
  'LBL_TEST_BUTTON_TITLE' => 'Testi [Alt+T]',
  'LBL_TEST_SETTINGS' => 'Kokeile asetuksia',
  'LBL_TEST_SUCCESSFUL' => 'Yhteyden luominen onnistui',
  'LBL_TEST_WAIT_MESSAGE' => 'Odota hetki...',
  'LBL_TLS_DESC' => 'Käytä Transport Layer Security -ominaisuutta kun otat yhteyttä sähköpostipalvelimeen - käytä tätä vain jos sähköpostipalvelimesi tukee protokollaa.',
  'LBL_TLS' => 'Käytä TLS',
  'LBL_WARN_IMAP_TITLE' => 'Saapuva posti estetty',
  'LBL_WARN_IMAP' => 'Varoitukset:',
  'LBL_WARN_NO_IMAP' => 'Sähköposteja <b>ei voida lukea</b> järjestelmään ilman IMAP-kirjastoja. IMAP c-client kirjastoja ei ole käytössä/käännetty PHP moduuliin (--with-imap=/path/to/imap_c-client_library). Ota yhteyttä järjestelmän ylläpitäjään.',
  'LNK_CREATE_GROUP' => 'Uusi uusi ryhmä',
  'LNK_LIST_CREATE_NEW' => 'Seuraa uutta postilaatikkoa',
  'LNK_LIST_MAILBOXES' => 'Kaikki postilaatikot',
  'LNK_LIST_QUEUES' => 'Kaikki jonot',
  'LNK_LIST_SCHEDULER' => 'Ajastetut tehtävät',
  'LNK_LIST_TEST_IMPORT' => 'Testaa sähköpostin tuonti',
  'LNK_NEW_QUEUES' => 'Uusi uusi jono',
  'LNK_SEED_QUEUES' => 'Anna jonosyötteet tiimeiltä',
);


?>