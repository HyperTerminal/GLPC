<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Prospektit',
  'LBL_MODULE_ID' => 'Prospektit',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_MODULE_TITLE' => 'Prospektit: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae prospekti',
  'LBL_LIST_FORM_TITLE' => 'Prospektit',
  'LBL_NEW_FORM_TITLE' => 'Uusi prospekti',
  'LBL_PROSPECT' => 'Kohde:',
  'LBL_BUSINESSCARD' => 'Käyntikortti',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_LIST_PROSPECT_NAME' => 'Prospektin nimi',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_LIST_TITLE' => 'Asema',
  'LBL_LIST_EMAIL_ADDRESS' => 'Sähköposti',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Muu sähköposti',
  'LBL_LIST_PHONE' => 'Puhelin',
  'LBL_LIST_PROSPECT_ROLE' => 'Rooli',
//END DON'T CONVERT
  'LBL_LIST_FIRST_NAME' => 'Etunimi',
  'LBL_ASSIGNED_TO_NAME' => 'Määritelty nimelle',
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'LBL_CAMPAIGN_ID' => 'Campaign ID',
  'LBL_EXISTING_PROSPECT' => 'Käytti olemassa olevaa kontaktia',
  'LBL_CREATED_PROSPECT' => 'Uusi kontakti luotu',
  'LBL_EXISTING_ACCOUNT' => 'Käytti olemassa olevaa asiakasta',
  'LBL_CREATED_ACCOUNT' => 'Uusi asiakas luotu',
  'LBL_CREATED_CALL' => 'Uusi puhelinsoitto luotu',
  'LBL_CREATED_MEETING' => 'Uusi tapaaminen luotu',
  'LBL_ADDMORE_BUSINESSCARD' => 'Lisää toinen käyntikortti',
  'LBL_ADD_BUSINESSCARD' => 'Luo käyntikortin avulla',
  'LBL_NAME' => 'Nimi:',
  'LBL_PROSPECT_NAME' => 'Prospektin nimi',
  'LBL_PROSPECT_INFORMATION' => 'Prospektin tiedot',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_OFFICE_PHONE' => 'Toimiston puhelin:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_MOBILE_PHONE' => 'Matkapuhelin:',
  'LBL_HOME_PHONE' => 'Kotipuhelin:',
  'LBL_OTHER_PHONE' => 'Muu puhelin:',
  'LBL_FAX_PHONE' => 'Faksi:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Ensisijainen osoite Katuosoite:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Ensisijainen osoite Kaupunki:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Ensisijainen osoite Maa:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Ensisijainen osoite Lääni:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Ensisijainen osoite Postinumero:',
  'LBL_ALT_ADDRESS_STREET' => 'Vaihtoehtoinen katuosoite:',
  'LBL_ALT_ADDRESS_CITY' => 'Vaihtoehtoinen osoite Kaupunki:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Vaihtoehtoinen osoite Maa:',
  'LBL_ALT_ADDRESS_STATE' => 'Vaihtoehtoinen osoite Lääni:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Vaihtoehtoinen osoite Postinumero:',
  'LBL_TITLE' => 'Asema:',
  'LBL_DEPARTMENT' => 'Osasto:',
  'LBL_BIRTHDATE' => 'Syntymäaika:',
  'LBL_EMAIL_ADDRESS' => 'Sähköposti:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Muu sähköposti:',
  'LBL_ANY_EMAIL' => 'Muu sähköposti:',
  'LBL_ASSISTANT' => 'Assistentti:',
  'LBL_ASSISTANT_PHONE' => 'Assistentin puhelin:',
  'LBL_DO_NOT_CALL' => 'älä soita:',
  'LBL_EMAIL_OPT_OUT' => 'Ei sähköpostia:',
  'LBL_PRIMARY_ADDRESS' => 'Ensisijainen osoite:',
  'LBL_ALTERNATE_ADDRESS' => 'Muu osoite:',
  'LBL_ANY_ADDRESS' => 'Muu osoite:',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_STATE' => 'Lääni:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_PROSPECT_ROLE' => 'Rooli:',
  'LBL_OPP_NAME' => 'Mahdollisuuden nimi:',
  'LBL_IMPORT_VCARD' => 'Tuo vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Luo automaattisesti uusi kontakti tuomalla vCard-tiedosto.',
  'LBL_DUPLICATE' => 'Mahdollisesti kaksi samanlaista prospektia',
  'MSG_SHOW_DUPLICATES' => 'Prospektin luonti saattaa tuottaa kaksoiskappaleen. Peru toiminto napsauttamalla Peru-painiketta tai luo uusi prospekti napsauttamalla Tallenna-painiketta.',
  'MSG_DUPLICATE' => 'Prospektin luonti voi tuottaa kaksoiskappaleen. Voit joko valita prospektin alle olevasta listasta tai napsauttaa Luo prospekti -painiketta jatkaaksesi uuden prospektin luontia aikaisemmin syötetyn tiedon pohjalta.',
  'LNK_IMPORT_VCARD' => 'Luo vCard:n avulla',
  'LNK_NEW_ACCOUNT' => 'Uusi asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Uusi myyntimahdollisuus',
  'LNK_NEW_CASE' => 'Uusi palvelupyyntö',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_NEW_APPOINTMENT' => 'Uusi tapaaminen',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tämän tietueen?',
  'NTC_REMOVE_CONFIRMATION' => 'Haluatko poistaa kontaktin tästä palvelupyynnöstä?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Haluatko poistaa tietueen suorana raporttina?',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopioi ensisijainen osoite toissijaiseksi osoitteeksi',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopioi toissijainen osoite ensisijaiseksi osoitteeksi',
  'LBL_SALUTATION' => 'Tervehdys',
  'LBL_SAVE_PROSPECT' => 'Tallenna prospekti',
  'LBL_CREATED_OPPORTUNITY' => 'Uusi myyntimahdollisuus luotu',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Asiakas tulee luoda ennen myyntimahdollisuutta. Luo uusi asiakas tai käytä olemassa olevaa asiakasta.',
  'LNK_SELECT_ACCOUNT' => 'Valitse asiakas',
  'LNK_NEW_PROSPECT' => 'Uusi prospekti',
  'LNK_PROSPECT_LIST' => 'Prospektit',
  'LNK_NEW_CAMPAIGN' => 'Uusi kampanja',
  'LNK_CAMPAIGN_LIST' => 'Kampanjat',
  'LNK_NEW_PROSPECT_LIST' => 'Uusi prospektilista',
  'LNK_PROSPECT_LIST_LIST' => 'Prospektilistat',
  'LNK_IMPORT_PROSPECT' => 'Tuo prospektit',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Valitse merkityt käyttäjät',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Valitse merkityt käyttäjät',
  'LBL_INVALID_EMAIL' => 'Virheellinen sähköposti:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_CONVERT_BUTTON_KEY' => 'V',
  'LBL_CONVERT_BUTTON_TITLE' => 'Muunna kohde',
  'LBL_CONVERT_BUTTON_LABEL' => 'Muunna kohde',
  'LBL_CONVERTPROSPECT' => 'Muunna prospekti',
  'LNK_NEW_CONTACT' => 'Uusi kontakti',
  'LBL_CREATED_CONTACT' => 'Uusi kontakti luotu',
  'LBL_BACKTO_PROSPECTS' => 'Takaisin prospekteihin',
  'LBL_CAMPAIGNS' => 'Kampanjat',
  'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE' => 'Kampanjaloki',
  'LBL_TRACKER_KEY' => 'Trakkeriavain',
  'LBL_LEAD_ID' => 'Liidin id',
  'LBL_CONVERTED_LEAD' => 'Muunnettu liidi',
  'LBL_ACCOUNT_NAME' => 'Asiakas',
  'LBL_EDIT_ACCOUNT_NAME' => 'Asiakas:',
);


?>