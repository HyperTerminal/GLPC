<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Prospektilistat',
  'LBL_MODULE_ID' => 'Prospektilistat',
  'LBL_MODULE_TITLE' => 'Prospektilistat: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae prospektilista',
  'LBL_LIST_FORM_TITLE' => 'Prospektilistat',
  'LBL_PROSPECT_LIST_NAME' => 'Nimi:',
  'LBL_NAME' => 'Nimi:',
  'LBL_ENTRIES' => 'Listoja yhteensä: ',
  'LBL_LIST_PROSPECT_LIST_NAME' => 'Prospektilista',
  'LBL_LIST_ENTRIES' => 'Listat',
  'LBL_LIST_DESCRIPTION' => 'Kuvaus',
  'LBL_LIST_TYPE_NO' => 'Tyyppi',
  'LBL_LIST_END_DATE' => 'Lopetuspäivä',
  'LBL_DATE_ENTERED' => 'Kirjauspäivä',
  'LBL_DATE_MODIFIED' => 'Muokkauspäivä',
  'LBL_MODIFIED' => 'Muokannut: ',
  'LBL_CREATED' => 'Luonut: ',
  'LBL_TEAM' => 'Tiimi: ',
  'LBL_ASSIGNED_TO' => 'Vastuuhenkilö: ',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LNK_NEW_CAMPAIGN' => 'Uusi kampanja',
  'LNK_CAMPAIGN_LIST' => 'Kampanjat',
  'LNK_NEW_PROSPECT_LIST' => 'Uusi prospektilista',
  'LNK_PROSPECT_LIST_LIST' => 'Prospektilistat',
  'LBL_MODIFIED_BY' => 'Muokannut: ',
  'LBL_CREATED_BY' => 'Luonut: ',
  'LBL_DATE_CREATED' => 'Luontipäivä: ',
  'LBL_DATE_LAST_MODIFIED' => 'Muokattu: ',
  'LNK_NEW_PROSPECT' => 'Uusi prospekti',
  'LNK_PROSPECT_LIST' => 'Prospektit',
  'LBL_PROSPECT_LISTS_SUBPANEL_TITLE' => 'Prospektilistat',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Liidit',
  'LBL_PROSPECTS_SUBPANEL_TITLE' => 'Prospektit',
  'LBL_COPY_PREFIX' => 'Kopio kohteesta',
  'LBL_USERS_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_TYPE' => 'Tyyppi',
  'LBL_LIST_TYPE' => 'Tyyppi:',
  'LBL_LIST_TYPE_LIST_NAME' => 'Tyyppi',
  'LBL_NEW_FORM_TITLE' => 'Uusi kohdelista',
  'LBL_MARKETING_MESSAGE' => 'Markkinointiviesti',
  'LBL_DOMAIN_NAME' => 'Domainin nimi',
  'LBL_DOMAIN' => 'Ei sähköposteja domainiin:',
  'LBL_LIST_PROSPECTLIST_NAME' => 'Nimi',
);


?>