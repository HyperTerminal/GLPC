<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tehtävät',
  'LBL_TASK' => 'Tehtävät:',
  'LBL_MODULE_TITLE' => 'Tehtävät: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae tehtävä',
  'LBL_LIST_FORM_TITLE' => 'Tehtävät',
  'LBL_NEW_FORM_TITLE' => 'Uusi tehtävä',
  'LBL_NEW_FORM_SUBJECT' => 'Aihe',
  'LBL_NEW_FORM_DUE_DATE' => 'Lopetupäivä:',
  'LBL_NEW_FORM_DUE_TIME' => 'Lopetusaika:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Sulje',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_CONTACT' => 'Kontakti',
  'LBL_LIST_PRIORITY' => 'Prioriteetti',
  'LBL_LIST_RELATED_TO' => 'Liittyy aiheeseen',
  'LBL_LIST_DUE_DATE' => 'Valmistumispäivä',
  'LBL_LIST_DUE_TIME' => 'Valmistumisaika',
  'LBL_SUBJECT' => 'Aihe',
  'LBL_STATUS' => 'Tila:',
  'LBL_DUE_DATE' => 'Lopetupäivä:',
  'LBL_DUE_TIME' => 'Lopetusaika:',
  'LBL_PRIORITY' => 'Prioriteetti:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Tehtävä valmis:',
  'LBL_START_DATE_AND_TIME' => 'Aloituspäivä ja aika:',
  'LBL_START_DATE' => 'Aloituspäivä:',
  'LBL_LIST_START_DATE' => 'Aloituspäivä',
  'LBL_START_TIME' => 'Aloitusaika:',
  'LBL_LIST_START_TIME' => 'Aloitusaika',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'Ei valittu',
  'LBL_CONTACT' => 'Kontaktin nimi: ',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_EMAIL' => 'Sähköposti:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_NAME' => 'Nimi:',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_LIST_COMPLETE' => 'Valmis:',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_DATE_DUE_FLAG' => 'Ei takarajapäivää',
  'LBL_DATE_START_FLAG' => 'Ei aloitusaikaa',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'ERR_INVALID_HOUR' => 'Anna tunti.',
  'LBL_DEFAULT_STATUS' => 'Ei aloitettu',
  'LBL_DEFAULT_PRIORITY' => 'Normaali',
  'LBL_LIST_MY_TASKS' => 'Omat avoimet tehtävät',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_CALL_LIST' => 'Puhelut',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_TASK_LIST' => 'Tehtävät',
  'LNK_NOTE_LIST' => 'Muistiot',
  'LNK_EMAIL_LIST' => 'Sähköpostit',
  'LNK_VIEW_CALENDAR' => 'Tänään',
  'LBL_CONTACT_FIRST_NAME' => 'Yhteyshenkilön etunimi',
  'LBL_CONTACT_LAST_NAME' => 'Yhteyshenkilön sukunimi',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
);


?>