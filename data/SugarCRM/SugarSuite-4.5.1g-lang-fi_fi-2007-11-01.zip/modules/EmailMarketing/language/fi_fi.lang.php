<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Sähköpostimarkkinointi',
  'LBL_MODULE_TITLE' => 'Sähköpostimarkkinointi: etusivu',
  'LBL_LIST_FORM_TITLE' => 'Sähköpostimarkkinointi',
  'LBL_PROSPECT_LIST_NAME' => 'Nimi:',  //longreach
  'LBL_NAME' => 'Nimi:',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_FROM_ADDR' => 'Lähettäjä',
  'LBL_LIST_DATE_START' => 'Aloituspäivä',
  'LBL_LIST_TEMPLATE_NAME' => 'Sähköpostimalli',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_STATUS' => 'Tila:',
  'LBL_STATUS_TEXT' => 'Tila:',
  'LBL_DATE_ENTERED' => 'Luontipäivä',
  'LBL_DATE_MODIFIED' => 'Muokkauspäivä',
  'LBL_MODIFIED' => 'Muokannut: ',
  'LBL_CREATED' => 'Luonut: ',
  'LBL_MESSAGE_FOR' => 'Viestin vastaanottaja:',
  'LBL_MESSAGE_FOR_ID' => 'Viesti henkilölle',
  'LBL_FROM_NAME' => 'Lähettäjän nimi',
  'LBL_FROM_ADDR' => 'Lähettäjän osoite',
  'LBL_DATE_START' => 'Aloituspäivä:',
  'LBL_TIME_START' => 'Aloitusaika:',
  'LBL_START_DATE_TIME' => 'Aloituspäivä ja -aika: ',
  'LBL_TEMPLATE' => 'Sähköpostin pohja: ',
  'LBL_MODIFIED_BY' => 'Muokannut: ',
  'LBL_CREATED_BY' => 'Luonut: ',
  'LBL_DATE_CREATED' => 'Luotu: ',
  'LBL_DATE_LAST_MODIFIED' => 'Muokattu: ',
  'LNK_NEW_CAMPAIGN' => 'Uusi kampanja',
  'LNK_CAMPAIGN_LIST' => 'Kampanjat',
  'LNK_NEW_PROSPECT_LIST' => 'Uusi kohdelista',
  'LNK_PROSPECT_LIST_LIST' => 'Kohdelistat',
  'LNK_NEW_PROSPECT' => 'Uusi kohde',
  'LNK_PROSPECT_LIST' => 'Kohteet',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Sähköpostimarkkinointi',
  'LBL_CREATE_EMAIL_TEMPLATE' => 'Luo',
  'LBL_EDIT_EMAIL_TEMPLATE' => 'Muokkaa',
  'LBL_FROM_MAILBOX' => 'Postilaatikosta',
  'LBL_FROM_MAILBOX_NAME' => 'Käytä postilaatikkoa:',
  'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => 'Kohdelistat',
  'LBL_ALL_PROSPECT_LISTS' => 'Kampanjan kaikki kohdelistat.',
  'LBL_RELATED_PROSPECT_LISTS' => 'Tähän viestiin liittyvät kohdelistat.',
  'LBL_PROSPECT_LIST_NAME' => 'Kohdelistan nimi',
  'LBL_LIST_PROSPECT_LIST_NAME' => 'Kohdelistat',
  'LBL_MODULE_SEND_TEST' => 'Kampanja: lähetä testiviesti',
  'LBL_MODULE_SEND_EMAILS' => 'Kampanja: lähetä viestit',
  'LBL_SCHEDULE_MESSAGE_TEST' => 'Valitse kanpanjaviestit jotka haluat lähettää testinä:',
  'LBL_SCHEDULE_MESSAGE_EMAILS' => 'Valitse kampanjaviestit jotka haluat aikatauluttaa lähetettäväksi määrättyyn aikaan määrättynä päivänä:',
  'LBL_SCHEDULE_BUTTON_TITLE' => 'Lähetä',
  'LBL_SCHEDULE_BUTTON_LABEL' => 'Lähetä',
  'LBL_SCHEDULE_BUTTON_KEY' => 'T',
  // longreach - added
  'LBL_TEMPLATE_NAME' => 'Käytettävän pohjan nimi:',
);


?>