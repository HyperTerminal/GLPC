<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Bugit',
  'LBL_MODULE_TITLE' => 'Bugit: etusivu',
  'LBL_MODULE_ID' => 'Bugit',
  'LBL_SEARCH_FORM_TITLE' => 'Hae bugi',
  'LBL_LIST_FORM_TITLE' => 'Bugit',
  'LBL_NEW_FORM_TITLE' => 'Uusi bugi',
  'LBL_CONTACT_BUG_TITLE' => 'Bugin kontakti:',
  'LBL_SUBJECT' => 'Aihe',
  'LBL_BUG' => 'Bugi:',
  'LBL_BUG_NUMBER' => 'Buginumero:',
  'LBL_NUMBER' => 'Numero:',
  'LBL_STATUS' => 'Tila:',
  'LBL_PRIORITY' => 'Prioriteetti:',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_BUG_SUBJECT' => 'Bugin aihe:',
  'LBL_CONTACT_ROLE' => 'Rooli:',
  'LBL_LIST_NUMBER' => 'Nro',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_PRIORITY' => 'Prioriteetti',
  'LBL_LIST_RELEASE' => 'Julkaisu',
  'LBL_LIST_RESOLUTION' => 'Käsittely',
  'LBL_LIST_LAST_MODIFIED' => 'Viimeksi muutettu',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_TYPE' => 'Tyyppi',
  'LBL_LIST_TYPE' => 'Tyyppi:',
  'LBL_RESOLUTION' => 'Lopputulos:',
  'LBL_RELEASE' => 'Julkaisu:',
  'LNK_NEW_BUG' => 'Raportoi bugi',
  'LNK_BUG_LIST' => 'Bugit',
  'NTC_REMOVE_INVITEE' => 'Haluatko poistaa henkilön tapaamisesta?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Haluatko poistaa tämän bugin tältä asiakkaalta?',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_LIST_MY_BUGS' => 'Omat bugit',
  'LBL_FOUND_IN_RELEASE' => 'Löydetty versiosta',
  'LBL_FIXED_IN_RELEASE' => 'Korjattu versiossa',
  'LBL_LIST_FIXED_IN_RELEASE' => 'Korjattu versiossa',
  'LBL_WORK_LOG' => 'Työpäiväkirja',
  'LBL_SOURCE' => 'Lähde',
  'LBL_PRODUCT_CATEGORY' => 'Tuotekategoria',
  'LBL_CREATED_BY' => 'Luonut: ',
  'LBL_DATE_CREATED' => 'Luontipäivä: ',
  'LBL_MODIFIED_BY' => 'Muokannut: ',
  'LBL_DATE_LAST_MODIFIED' => 'Muokattu: ',
  'LBL_LIST_EMAIL_ADDRESS' => 'Sähköposti',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktit',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_PHONE' => 'Puhelin',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tämän tietueen?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Asiakkaat',
  'LBL_CASES_SUBPANEL_TITLE' => 'Palvelupyynnöt',
  'LBL_SYSTEM_ID' => 'Järjestelmän ID',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
);


?>