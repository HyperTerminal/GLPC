<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Myyntimahdollisuudet',
  'LBL_MODULE_TITLE' => 'Myyntimahdollisuudet: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae myyntimahdollisuus',
  'LBL_VIEW_FORM_TITLE' => 'Myyntimahdollisuusnäkymä',
  'LBL_LIST_FORM_TITLE' => 'Myyntimahdollisuudet',
  'LBL_OPPORTUNITY_NAME' => 'Mahdollisuuden nimi:',
  'LBL_OPPORTUNITY' => 'Myyntimahdollisuus:',
  'LBL_NAME' => 'Nimi:',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Myyntimahdollisuus',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_AMOUNT' => 'Amount',
  'LBL_LIST_DATE_CLOSED' => 'Sulje',
  'LBL_LIST_SALES_STAGE' => 'Myynnin tila',
//END DON'T CONVERT
  'LBL_ACCOUNT_ID' => 'Asiakkaan tunnus',
  'LBL_CURRENCY_ID' => 'Valuutan tunnus',
  'LBL_TEAM_ID' => 'Tiimi:',
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
  'UPDATE' => 'Myyntimahdollisuus - valuutan päivitys',
  'UPDATE_DOLLARAMOUNTS' => 'Päivitä USD määrät',
  'UPDATE_VERIFY' => 'Tarkista määrät',
  'UPDATE_VERIFY_TXT' => 'Varmistaa että myyntimahdollisuuksiin syötetyt luvut sisältävät vain numeroita (0-9) ja desimaalierottimen (.)',
  'UPDATE_FIX' => 'Korjaa summat',
  'UPDATE_FIX_TXT' => 'Toiminto yrittää korjata virheelliset summat luomalla voimassaolevan desimaalin nykyisestä summasta. Toiminto tekee varmuuskopion muokatut summat tietokannan kenttään amount_backup. Jos suoritat toiminnon ja havaitset virheitä, älä suorita toimintoa uudelleen ennen kuin olet palauttanut alkuperäiset arvot. Muussa tapauksessa voit korvata varmuuskopion virheellisillä tiedoilla.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Päivitä myyntimahdollisuuksien USD summat valitun valuutan muuntokurssin mukaan. Arvoa käytetään graafien ja listojen laskennassa',
  'UPDATE_CREATE_CURRENCY' => 'Luodaan uusi valuutta:',
  'UPDATE_VERIFY_FAIL' => 'Tietueen tunnistaminen ei onnistunut:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Nykyinen määrä:',
  'UPDATE_VERIFY_FIX' => 'Korjauksen ajamalla tulee',
  'UPDATE_INCLUDE_CLOSE' => 'Ota mukaan suljetut tietueet',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Uusi määrä:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Uusi valuutta:',
  'UPDATE_DONE' => 'Valmis',
  'UPDATE_BUG_COUNT' => 'Virheitä löydetty ja yritetty ratkaista:',
  'UPDATE_BUGFOUND_COUNT' => 'Virheitä löydetty:',
  'UPDATE_COUNT' => 'Tietueita päivitetty:',
  'UPDATE_RESTORE_COUNT' => 'Tietueen summat palautettu:',
  'UPDATE_RESTORE' => 'Palauta määrät',
  'UPDATE_RESTORE_TXT' => 'Palauttaa summat korjauksen yhteydessä tehdystä varmuuskopiosta.',
  'UPDATE_FAIL' => 'Päivitys ei onnistunut -',
  'UPDATE_NULL_VALUE' => 'Arvo on NULL, asetetaan arvoksi 0 -',
  'UPDATE_MERGE' => 'Yhdistä valuutat',
  'UPDATE_MERGE_TXT' => 'Yhdistää useamman valuutan yhdeksi valuutaksi. Jos huomaat että samaan valuuttaa liittyy useita valuuttatietueita, voit yhdistää ne. Muutos koskee myös muissa moduuleissa esiintyviä valuuttoja.',
  'LBL_ACCOUNT_NAME' => 'Asiakas',
  'LBL_AMOUNT' => 'Summa:',
  'LBL_CURRENCY' => 'Valuutta:',
  'LBL_DATE_CLOSED' => 'Oletettu päätöspäivä:',
  'LBL_TYPE' => 'Tyyppi',
  'LBL_CAMPAIGN' => 'Kampanja:',
  'LBL_NEXT_STEP' => 'Seuraava askel:',
  'LBL_LEAD_SOURCE' => 'Liidin lähde:',
  'LBL_SALES_STAGE' => 'Myynnin tila:',
  'LBL_PROBABILITY' => 'Todennäköisyys (%):',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_DUPLICATE' => 'Mahdollisesti kaksi samanlaista prospektia',
  'MSG_DUPLICATE' => 'Myyntimahdollisuudenb luonti voi tuottaa kaksoiskappaleen. Voit joko valita myyntimahdollisuuden alla olevasta listasta tai napsauttaa Luo myyntimahdollisuus -painiketta jatkaaksesi uuden kontakti luontia aikaisemmin syötetyn tiedon pohjalta.',
  'LBL_NEW_FORM_TITLE' => 'Uusi käyttäjä',
  'LNK_NEW_OPPORTUNITY' => 'Uusi myyntimahdollisuus',
  'LNK_OPPORTUNITY_LIST' => 'Myyntimahdollisuudet',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_TOP_OPPORTUNITIES' => 'Tärkeimmät avoimet myyntimahdollisuudet',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Haluatko poistaa myyntimahdollisuuteen liittyvän kontaktin?',
  'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Haluatko poistaa projektiin liittyvän myyntimahdollisuuden?',
  'LBL_AMOUNT_BACKUP' => 'Varmuuskopioi summa',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_RAW_AMOUNT' => 'Arvioitu määrä',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Liidit',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projektit',
  'LBL_ASSIGNED_TO_NAME' => 'Määritelty nimelle',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
   
);


?>