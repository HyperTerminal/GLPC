<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_ACCOUNT_ID' => 'Asiakkaan tunnus',
  'LBL_CASE_ID' => 'Palvelupyynnön ID:',
  'LBL_CLOSE' => 'Sulje:',
  'LBL_COLON' => ':',
  'LBL_CONTACT_ID' => 'Kontaktin ID:',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_EMAIL_ADDRESS' => 'Sähköposti:',
  'LBL_FILE_MIME_TYPE' => 'Mime-tyyppi',
  'LBL_FILE_URL' => 'Tiedoston URL',
  'LBL_FILENAME' => 'Liitetiedosto:',
  'LBL_LEAD_ID' => 'Liidin id',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktit',
  'LBL_LIST_DATE_MODIFIED' => 'Viimeksi muutettu',
  'LBL_LIST_FILENAME' => 'Liitetiedosto',
  'LBL_LIST_FORM_TITLE' => 'Käyttäjät',
  'LBL_LIST_RELATED_TO' => 'Liittyy aiheeseen',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_CONTACT' => 'Kontaktit',
  'LBL_MODULE_NAME' => 'Muistiot',
  'LBL_MODULE_TITLE' => 'Muistiot: etusivu',
  'LBL_NEW_FORM_TITLE' => 'Uusi muistio',
  'LBL_NOTE_STATUS' => 'Muistio',
  'LBL_NOTE_SUBJECT' => 'Muistion aihe:',
  'LBL_NOTES_SUBPANEL_TITLE' => 'Liitetiedostot',
  'LBL_NOTE' => 'Muistio:',
  'LBL_OPPORTUNITY_ID' => 'Myyntimahdollisuuden ID:',
  'LBL_PARENT_ID' => 'Projekti:',
  'LBL_PARENT_TYPE' => 'Isännän tyyppi',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_PORTAL_FLAG' => 'Näytä portaalissa?',
  'LBL_EMBED_FLAG' => 'Sähköpostin liitteeksi?',
  'LBL_PRODUCT_ID' => 'Tuote ID:',
  'LBL_QUOTE_ID' => 'Tarjous ID:',
  'LBL_RELATED_TO' => 'Liittyy henkilöön:',
  'LBL_SEARCH_FORM_TITLE' => 'Hae käyttäjä',
  'LBL_STATUS' => 'Tila:',
  'LBL_SUBJECT' => 'Aihe',
  'LNK_CALL_LIST' => 'Puhelut',
  'LNK_EMAIL_LIST' => 'Sähköpostit',
  'LNK_IMPORT_NOTES' => 'Tuo tietoja',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_NOTE_LIST' => 'Muistiot',
  'LNK_TASK_LIST' => 'Tehtävät',
  'LNK_VIEW_CALENDAR' => 'Tänään',
  'LBL_MEMBER_OF' => 'Jäsen:',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
  'LBL_REMOVING_ATTACHMENT' => 'Poistetaan liitetiedosto...',
  'ERR_REMOVING_ATTACHMENT' => 'Liitetiedoston poistaminen epäonnistui...',
);


?>