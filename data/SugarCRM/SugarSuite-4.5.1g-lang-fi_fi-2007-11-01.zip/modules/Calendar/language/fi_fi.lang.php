<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kalenteri',
  'LBL_MODULE_TITLE' => 'Kalenteri: etusivu',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_APPOINTMENT' => 'Uusi tapaaminen',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_CALL_LIST' => 'Puhelut',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_TASK_LIST' => 'Tehtävät',
  'LNK_VIEW_CALENDAR' => 'Tänään',
  'LBL_MONTH' => ' kuukausi',
  'LBL_DAY' => 'Päivä',
  'LBL_YEAR' => 'Vuosi:',
  'LBL_WEEK' => 'Viikko',
  'LBL_PREVIOUS_MONTH' => 'Edellinen kuukausi',
  'LBL_PREVIOUS_DAY' => 'Edellinen päivä',
  'LBL_PREVIOUS_YEAR' => 'Edellinen vuosi',
  'LBL_PREVIOUS_WEEK' => 'Edellinen viikko',
  'LBL_NEXT_MONTH' => 'Seuraava kuukausi',
  'LBL_NEXT_DAY' => 'Seuraava päivä',
  'LBL_NEXT_YEAR' => 'Seuraava vuosi',
  'LBL_NEXT_WEEK' => 'Seuraava viikko',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Aikataulu valittu',
  'LBL_BUSY' => 'Varattu',
  'LBL_CONFLICT' => 'Päällekkäinen',
  'LBL_USER_CALENDARS' => 'Käyttäjien kalenterit',
  'LBL_SHARED' => 'Jaettu',
  'LBL_PREVIOUS_SHARED' => 'Edellinen',
  'LBL_NEXT_SHARED' => 'Seuraava',
  'LBL_SHARED_CAL_TITLE' => 'Jaettu kalenteri',
  'LBL_USERS' => 'Käyttäjät',
  'LBL_REFRESH' => 'Päivitä',
  'LBL_EDIT' => 'Muokkaa',
  'LBL_SELECT_USERS' => 'Valitse käyttäjät kalenterinäyttöä varten',
  'LBL_FILTER_BY_TEAM' => 'Suodata käyttäjälista tiimin mukaan:',
);

$mod_list_strings = array (
  'dom_cal_weekdays' => 
  array (
    0 => 'Su',
    1 => 'Ma',
    2 => 'Ti',
    3 => 'Ke',
    4 => 'To',
    5 => 'Pe',
    6 => 'La',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Sunnuntai',
    1 => 'Maanantai',
    2 => 'Tiistai',
    3 => 'Keskiviikko',
    4 => 'Torstai',
    5 => 'Perjantai',
    6 => 'Lauantai',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Tammi',
    2 => 'Helmi',
    3 => 'Maalis',
    4 => 'Huhti',
    5 => 'Touko',
    6 => 'Kesä',
    7 => 'Heinä',
    8 => 'Elo',
    9 => 'Syys',
    10 => 'Loka',
    11 => 'Marras',
    12 => 'Joulu',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Tammikuu',
    2 => 'Helmikuu',
    3 => 'Maaliskuu',
    4 => 'Huhtikuu',
    5 => 'Toukokuu',
    6 => 'Kesäkuu',
    7 => 'Heinäkuu',
    8 => 'Elokuu',
    9 => 'Syyskuu',
    10 => 'Lokakuu',
    11 => 'Marraskuu',
    12 => 'Joulukuu',
  ),
);


?>