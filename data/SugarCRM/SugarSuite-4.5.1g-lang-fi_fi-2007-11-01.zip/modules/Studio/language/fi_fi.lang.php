<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_EDIT_LAYOUT' => 'Muokkaa ulkoasua',
  'LBL_EDIT_ROWS' => 'Muokkaa rivejä',
  'LBL_EDIT_COLUMNS' => 'Muokkaa sarakkeita',
  'LBL_EDIT_LABELS' => 'Muokkaa otsikoita',
  'LBL_EDIT_FIELDS' => 'Muokkaa omia kenttiä',
  'LBL_ADD_FIELDS' => 'Lisää omia kenttiä',
  'LBL_DISPLAY_HTML' => 'Näytä HTML-koodi',
  'LBL_SELECT_FILE' => 'Valitse tiedosto',
  'LBL_SAVE_LAYOUT' => 'Tallenna ulkoasu',
  'LBL_SELECT_A_SUBPANEL' => 'Valitse alipaneeli',
  'LBL_SELECT_SUBPANEL' => 'Valitse alipaneeli',
  'LBL_MODULE_TITLE' => 'Studio',
  'LBL_TOOLBOX' => 'Työkalut',
//CUSTOM FIELDS
  'LBL_STAGING_AREA' => 'Väliaikainen alue (siirrä nimikkeitä tänne)',
  'LBL_SUGAR_FIELDS_STAGE' => 'Sugar kentät (napsauta nimikkeitä lisätäksesi ne väliaikaiselle alueelle)',
  'LBL_SUGAR_BIN_STAGE' => 'Sugar säilytysalue (napsauta nimikkeitä lisätäksesi ne väliaikaiselle alueelle)',
  'LBL_VIEW_SUGAR_FIELDS' => 'Näytä Sugar-kentät',
  'LBL_VIEW_SUGAR_BIN' => 'Näytä Sugar säilytysalue',
  'LBL_FAILED_TO_SAVE' => 'Tallentaminen ei onnistunut',
  'LBL_PUBLISHING' => 'Julkaistaan ...',
  'LBL_PUBLISHED' => 'Julkaistu',
  'LBL_FAILED_PUBLISHED' => 'Julkaiseminen ei onnistunut',
  'LBL_NAME' => 'Nimi',
  'LBL_LABEL' => 'Otsikko',
  'LBL_MASS_UPDATE' => 'Massapäivitys',
//STUDIO WIZARD
  'LBL_AUDITED' => 'Auditoidaan',
  'LBL_CUSTOM_MODULE' => 'Moduuli',
  'LBL_DEFAULT_VALUE' => 'Oletusarvo',
  'LBL_REQUIRED' => 'Arvo vaaditaan',
  'LBL_DATA_TYPE' => 'Tyyppi',
  'LBL_HISTORY' => 'Historia',
  'LBL_SW_WELCOME' => '<h2>Tervetuloa Studion käyttäjäksi</h2><br> Mitä haluat tehdä tänään?<br><b> Valitse haluttu toiminto.</b>',
  'LBL_SW_EDIT_MODULE' => 'Muokkaa moduulia',
  'LBL_SW_EDIT_DROPDOWNS' => 'Muokkaa pudotusvalikoita',
  'LBL_SW_EDIT_TABS' => 'Muokkaa kielekkeitä',
  'LBL_SW_RENAME_TABS' => 'Nimeä kielekkeet',
  'LBL_SW_EDIT_GROUPTABS' => 'Määrittele ryhmäkielekkeet',
//SELECT MODULE WIZARD
  'LBL_SW_EDIT_PORTAL' => 'Muokkaa portaalia',
  'LBL_SW_EDIT_WORKFLOW' => 'Muokkaa työkulunhallinnan jonoa',
//SELECT MODULE ACTION
  'LBL_SW_REPAIR_CUSTOMFIELDS' => 'Korjaa omat kentät',
  'LBL_SW_MIGRATE_CUSTOMFIELDS' => 'Muunna omat kentät',
  'LBL_SMW_WELCOME' => '<h2>Tervetuloa Studion käyttäjäksi</h2><br><b>Valitse moduuli.',
  'LBL_SMA_WELCOME' => '<h2>Muokkaa moduulia</h2>Mitä haluat tehdä moduulille?<br><b>Valitse toiminto.',
  'LBL_SMA_EDIT_CUSTOMFIELDS' => 'Muokkaa räätälöityjä kenttiä',
//Manager Backups History
  'LBL_SMA_EDIT_LAYOUT' => 'Muokkaa ulkoasua',
  'LBL_SMA_EDIT_LABELS' => 'Muokkaa otsikoita',
  'LBL_MB_PREVIEW' => 'Esikatsele',
  'LBL_MB_RESTORE' => 'Palauta',
  'LBL_MB_DELETE' => 'Poista',
  'LBL_MB_COMPARE' => 'Vertaa',
//EDIT DROP DOWNS
  'LBL_MB_WELCOME' => '<h2>Historia</h2><br> Historia näyttää muokattavan tiedoston aikaisemmat versiot. Voit vertailla ja palauttaa edelliset versiot. Jos palautat tiedoston, siitä tulee työtiedosto, joka tulee julkaista ennen kuin muut käyttäjät näkevät sen.<br> Mitä haluat tehdä tänään?<br><b> Valitse haluttu toiminto.</b>',
  'LBL_ED_CREATE_DROPDOWN' => 'Luo pudotusvalikko',
  'LBL_ED_WELCOME' => '<h2>Pudotusvalikkoeditori</h2><br><b>Voit joko muokata olemassa olevaan pudotusvalikkoa tai luoda uuden.',
  'LBL_DROPDOWN_NAME' => 'Pudotusvalikon nimi:',
  'LBL_DROPDOWN_LANGUAGE' => 'Pudotusvalikon kieli:',
//EDIT CUSTOM FIELDS
  'LBL_EC_WELCOME' => '<h2>Omakenttäeditori</h2><br><b>Voit joko katsella tai muokata omaa kenttää, luoda uuden oman kentän tai tyhjentään oman kentän välimuistitiedon.',
  'LBL_EC_VIEW_CUSTOMFIELDS' => 'Näytä omat kentät',
  'LBL_EC_CREATE_CUSTOMFIELD' => 'Luo oma kenttä',
  'LBL_EC_CLEAR_CACHE' => 'Tyhjennä välimuisti',
  'LBL_SM_WELCOME' => '<h2>Historia</h2><br><b>Valitse tiedosto jonka haluat nähdä.</b>',
//SELECT MODULE
  'LBL_DD_DISPALYVALUE' => 'Näytä arvo',
//END WIZARDS
  'LBL_DD_DATABASEVALUE' => 'Tietokannan arvo',
//DROP DOWN EDITOR
  'LBL_DD_ALL' => 'Kaikki',
  'LBL_BTN_SAVE' => 'Tallenna',
  'LBL_BTN_SAVEPUBLISH' => 'Tallenna ja julkaise',
  'LBL_BTN_HISTORY' => 'Historia',
//BUTTONS
  'LBL_BTN_NEXT' => 'Seuraava',
  'LBL_BTN_BACK' => 'Takaisin',
  'LBL_BTN_ADDCOLS' => 'Lisää sarakkeita',
  'LBL_BTN_ADDROWS' => 'Lisää rivejä',
  'LBL_BTN_UNDO' => 'Peru',
  'LBL_BTN_REDO' => 'Tee uudelleen',
  'LBL_BTN_ADDCUSTOMFIELD' => 'Lisää muokattu kenttä',
  'LBL_BTN_TABINDEX' => 'Muokkaa sarkainjärjestystä',
  'LBL_TAB_SUBTABS' => 'Alikielekkeet',
  'LBL_MODULES' => 'Moduulit',
  'LBL_DEFAULT' => 'Oletusarvo',
  'LBL_ADDITIONAL' => 'Lisä',
//TABS
  'LBL_AVAILABLE' => 'Käytettävissä',
  'LBL_LISTVIEW_DESCRIPTION' => 'Alla näytetään kolme saraketta. Oletuskenttä sisältää kentät, jotka näytetään oletuksena listanäkymässä. Lisäsarake sisältää kentät, joita käyttäjä voi valita ja käytettävissä olevat -sarake sisältää ylläpitäjän käyttöön tarkoitetut kentät joita voidaan lisätä oletusnäkymään. Kolmannessa sarakkeessa on myös kentät joita käyttäjät voivat käyttää, mutta jotka eivät ole käytössä.',
  'LBL_LISTVIEW_EDIT' => 'Listanäkymäeditori',
//LIST VIEW EDITOR
  'ERROR_ALREADY_EXISTS' => 'Tiedosto on jo olemassa',
  'ERROR_INVALID_KEY_VALUE' => 'Virhe: virheellinen Key-arvo: [\']',
  'LBL_SW_SUGARPORTAL' => 'Sugar Portaali',
  'LBL_SMP_WELCOME' => 'Valitse muokattava moduuli alla olevasta listasta',
  'LBL_SP_WELCOME' => 'Tervetuloa Studion Sugar Portaali -osaan. Voit muokata moduuleja täällä tai sykronoida portaalin kanssa.<br> Valitse alla olevasta listasta.',
  'LBL_SP_SYNC' => 'Portaalin synkronointi',
//ERRORS
  'LBL_SYNCP_WELCOME' => 'Anna päivitettävän portaalin URL ja napsauta Go-painiketta.<br> Näet lomakkeen, jossa kysytään käyttäjätunnustasi ja salasanaa.<br> Anna Sugar käyttäjätunnus ja salasana ja napsauta Begin Sync -painiketta.',
  'LBL_LISTVIEWP_DESCRIPTION' => 'Alla on kaksi saraketta: Default-sarakkeessa on listattu näytettävät kentät ja Available-sarakkeessa listataan kentät, joita ei ole valittu. Vedä ja pudota kenttiä sarakkeiden välillä hiiren avulla. Voit myös järjestää sarakkeen nimikkeet vetämällä ja pudottamalla niitä.',
  'LBL_SP_STYLESHEET' => 'Vie tyylitiedosto palvelimelle',
//SUGAR PORTAL
  'LBL_SP_UPLOADSTYLE' => 'Napsauta selaa-painiketta ja valitse palvelimelle vietävä tyylitiedosto koneeltasi.<br> Kun seuraavan kerran synkronisoit portaalin, tyylitiedosto ladataan siinä mukana.',
  'LBL_SP_UPLOADED' => 'Viety palvelimelle',
  'ERROR_SP_UPLOADED' => 'Varmista, että olet viemässä palvelimelle tyylitiedostoa.',
  'LBL_SP_PREVIEW' => 'Ohessa näkymä siitä, miltä tyylitiedosto näyttää',
);


?>