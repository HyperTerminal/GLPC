<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
	//module
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

	//vardef labels
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Dokumentit',
  'LBL_MODULE_TITLE' => 'Dokumentit: etusivu',
  'LNK_NEW_DOCUMENT' => 'Uusi dokumentti',
  'LNK_DOCUMENT_LIST' => 'Dokumenttilista',
  'LBL_DOC_REV_HEADER' => 'Dokumentin versiot',
  'LBL_SEARCH_FORM_TITLE' => 'Hae dokumentti',
  'LBL_DOCUMENT_ID' => 'Dokumentin tunnus',
  'LBL_NAME' => 'Dokumentin nimi:',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_CATEGORY' => 'Kategoria',
  'LBL_SUBCATEGORY' => 'Alakategoria',
  'LBL_STATUS' => 'Tila:',
  'LBL_CREATED_BY' => 'Luonut: ',
  'LBL_DATE_ENTERED' => 'Luontipäivä',
  'LBL_DATE_MODIFIED' => 'Muokkauspäivä',
  'LBL_DELETED' => 'Poistettu',
  'LBL_MODIFIED' => 'Muokannut: ',
  'LBL_MODIFIED_USER' => 'Käyttäjä muokannut',
  'LBL_CREATED' => 'Luonut: ',
  'LBL_RELATED_DOCUMENT_ID' => 'Liittyvän dokumentin tunnus',
  'LBL_RELATED_DOCUMENT_REVISION_ID' => 'Liittyvän dokumentin version tunnus',
  'LBL_IS_TEMPLATE' => 'On malli',
  'LBL_TEMPLATE_TYPE' => 'Dokumentin tyyppi',
  'LBL_REVISION_NAME' => 'Versionumero',
  'LBL_FILENAME' => 'Tiedostonimi',
  'LBL_MIME' => 'Mime-tyyppi',
  'LBL_REVISION' => 'Versio',
  'LBL_DOCUMENT' => 'Liittyvä dokumentti',
  'LBL_LATEST_REVISION' => 'Viimeisin versio',
	//document edit and detail view
  'LBL_CHANGE_LOG' => 'Muutosloki',
  'LBL_ACTIVE_DATE' => 'Julkaisupäivä',
  'LBL_EXPIRATION_DATE' => 'Vanhentumispäivä',
  'LBL_FILE_EXTENSION' => 'Tiedoston tarkennin',
  'LBL_CAT_OR_SUBCAT_UNSPEC' => 'Ei määritelty',
  'LBL_DOC_NAME' => 'Dokumentin nimi:',
  'LBL_FILENAME' => 'Liitetiedosto:',
  'LBL_DOC_VERSION' => 'Versio:',
  'LBL_CATEGORY_VALUE' => 'Kategoria',
  'LBL_SUBCATEGORY_VALUE' => 'Alakategoria:',
  'LBL_DOC_STATUS' => 'Tila:',
  'LBL_LAST_REV_CREATOR' => 'Version luonut:',
  'LBL_LAST_REV_DATE' => 'Version päiväys:',
  'LBL_DOWNNLOAD_FILE' => 'Lataa tiedosto:',
  'LBL_DET_RELATED_DOCUMENT' => 'Liittyvä dokumentti:',
  'LBL_DET_RELATED_DOCUMENT_VERSION' => 'Aiheeseen liittyvän dokumentin versio:',
  'LBL_DET_IS_TEMPLATE' => 'Malli? :',
  'LBL_DET_TEMPLATE_TYPE' => 'Dokumentin tyyppi:',
  'LBL_DOC_DESCRIPTION' => 'Kuvaus:',
  'LBL_DOC_ACTIVE_DATE' => 'Julkaisupäivä:',
	//document list view.
  'LBL_DOC_EXP_DATE' => 'Vanhentumispäivä:',
  'LBL_LIST_FORM_TITLE' => 'Käyttäjät',
  'LBL_LIST_DOCUMENT' => 'Dokumentti',
  'LBL_LIST_CATEGORY' => 'Kategoria',
  'LBL_LIST_SUBCATEGORY' => 'Alakategoria',
  'LBL_LIST_REVISION' => 'Versio',
  'LBL_LIST_LAST_REV_CREATOR' => 'Julkaissut',
  'LBL_LIST_LAST_REV_DATE' => 'Version päiväys',
  'LBL_LIST_VIEW_DOCUMENT' => 'Näytä',
  'LBL_LIST_DOWNLOAD' => 'Lataa',
  'LBL_LIST_ACTIVE_DATE' => 'Julkaisupäivä',
  'LBL_LIST_EXP_DATE' => 'Vanhentumispäivä',
  'LBL_LIST_STATUS' => 'Tila',
	//document search form.
  'LBL_SF_DOCUMENT' => 'Dokumentin nimi:',
  'LBL_SF_CATEGORY' => 'Kategoria',
  'LBL_SF_SUBCATEGORY' => 'Alakategoria:',
  'LBL_SF_ACTIVE_DATE' => 'Julkaisupäivä:',
  'LBL_SF_EXP_DATE' => 'Vanhenemispäivä:',
  'DEF_CREATE_LOG' => 'Dokumentti luotu',
  'ERR_DOC_NAME' => 'Dokumentin nimi',
  'ERR_DOC_ACTIVE_DATE' => 'Julkaisupäivä',
	//error messages
  'ERR_DOC_EXP_DATE' => 'Vanhentumispäivä',
  'ERR_FILENAME' => 'Tiedostonimi',
  'ERR_DOC_VERSION' => 'Dokumentin versio',
  'ERR_DELETE_CONFIRM' => 'Haluatko poistaa dokumentin version?',
  'ERR_DELETE_LATEST_VERSION' => 'Et voi poistaa dokumentin viimeisintä versiota.',
  'LNK_NEW_MAIL_MERGE' => 'Joukkopostitus',
  'LBL_MAIL_MERGE_DOCUMENT' => 'Joukkopostitusmalli:',
  'LBL_TREE_TITLE' => 'Dokumentit',
  'LBL_LIST_DOCUMENT_NAME' => 'Dokumentin nimi',
  'LBL_CONTRACT_NAME' => 'Sopimuksen nimi:',
  'LBL_LIST_IS_TEMPLATE' => 'Malli?',
	//sub-panel vardefs.
  'LBL_LIST_TEMPLATE_TYPE' => 'Dokumentin tyyppi',
  'LBL_LIST_SELECTED_REVISION' => 'Valittu versio',
  'LBL_LIST_LATEST_REVISION' => 'Viimeisin versio',
  'LBL_CONTRACTS_SUBPANEL_TITLE' => 'Aiheeseen liittyvät sopimukset',
  'LBL_LAST_REV_CREATE_DATE' => 'Viimisimmän version luontipäivä',
  'LNK_DOCUMENT_CAT' => 'Dokumenttien ryhmät',
);

    //'LNK_DOCUMENT_CAT'=>'Document Categories',

?>