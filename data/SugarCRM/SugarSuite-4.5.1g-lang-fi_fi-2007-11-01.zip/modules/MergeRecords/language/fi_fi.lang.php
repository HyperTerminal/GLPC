<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Yhdistä tietueet',
  'LBL_MODULE_TITLE' => 'Yhdistä tietueet: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Yhdistettävien tietueiden haku',
  'LBL_LIST_FORM_TITLE' => 'Yhdistettävien tietueiden lista',
  'LBL_LBL_MERGRE_RECORDS_STEP_1' => 'Vaihe 1: Etsi yhdistettävät tietueet',
  'LBL_AVAIL_FIELDS' => 'Käytettävissä olevat kentät',
  'LBL_SELECTED_FIELDS' => 'Valitut kentät',
  'LBL_MERGE_RECORDS_WITH' => 'Yhdistä tiedot nimikkeen kanssa',
  'LBL_MERGE_VALUE_OVER' => 'Merge value over',
  'LBL_NEXT_STEP_TITLE' => 'Seuraava vaihe[Ctrl+N]',
  'LBL_NEXT_STEP_BUTTON_KEY' => 'N',
  'LBL_NEXT_STEP_BUTTON_LABEL' => 'Seuraava vaihe >',
  'LBL_PERFORM_MERGE_BUTTON_TITLE' => 'Yhdistä[Ctrl+P]',
  'LBL_PERFORM_MERGE_BUTTON_KEY' => 'P',
  'LBL_PERFORM_MERGE_BUTTON_LABEL' => 'Yhdistä',
  'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE' => 'Tallenna muutokset[Ctrl+S]',
  'LBL_SAVE_MERGED_RECORD_BUTTON_KEY' => 'S',
  'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL' => 'Tallenna muutokset',
  'LBL_STEP2_FORM_TITLE' => 'Tietuetta löyettiin jotka yhdistetään:',
  'LBL_SELECT_ERROR' => 'Nimike tulee valita ennen kuin voit jatkaa.',
  'LBL_SELECT_PRIMARY' => 'Valitse yhdistämistoiminnon ensisijainen tietue.',
  'LBL_CHANGE_PARENT' => 'Korvaa tiedolla',
  'LBL_REMOVE_FROM_MERGE' => 'Poista',
  'LBL_DIFF_COL_VALUES' => 'Kentät joiden ensisijaisella rivillä oleva arvo eroaa yhdistettävien rivien arvoista:',
  'LBL_SAME_COL_VALUES' => 'Seuraavien kenttien arvot ovat samat joka rivillä:',
  'ERR_EXCEEDS_MAX' => 'Voit yhdistää enintään viisi tietuetta. Muut tietueet sivuutetaan.',
  'LBL_DELETE_MESSAGE' => 'Toiminto poistaa seuraavat tietueet:',
  'LBL_PROCEED' => 'Jatka ?',
);


?>