<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'ADMIN_EXPORT_ONLY' => 'Vain ylläpitäjät voivat viedä tietoja tiedostoon',
  'ADVANCED' => 'Edistyneet',
  'CURRENT_LOGO' => 'Nykyinen käytössä oleva logo',
  'DEFAULT_CURRENCY_ISO4217' => 'ISO 4217 valuuttakoodi',
  'DEFAULT_CURRENCY_NAME' => 'Valuutan nimi',
  'DEFAULT_CURRENCY_SYMBOL' => 'Valuutan symboli',
  'DEFAULT_CURRENCY' => 'Oletusvaluutta',
  'DEFAULT_DATE_FORMAT' => 'Päiväyksen oletusmuoto',
  'DEFAULT_DECIMAL_SEP' => 'Desimaalisymboli',
  'DEFAULT_LANGUAGE' => 'Oletuskieli',
  'DEFAULT_NUMBER_GROUPING_SEP' => 'Tuhaterotin',
  'DEFAULT_SYSTEM_SETTINGS' => 'Käyttöliittymä',
  'DEFAULT_THEME' => 'Oletusteema',
  'DEFAULT_TIME_FORMAT' => 'Ajan oletusmuoto',
  'DISABLE_EXPORT' => 'Estä tietojen vienti',
  'DISPLAY_LOGIN_NAV' => 'Näytä kielekkeet kirjautumissivulla',
  'DISPLAY_RESPONSE_TIME' => 'Näytä palvelimen vasteaika',
  'EXPORT' => 'Vie',
  'EXPORT_CHARSET' => 'Tietojen viennin oletusmerkistö',
  'EXPORT_DELIMITER' => 'Erotinmerkki tietoja vietäessä',
  'IMAGES' => 'Logot',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Muuta asetuksia',
  'LBL_ENABLE_MAILMERGE' => 'Salli joukkopostitus',
  'LBL_LOGVIEW' => 'Muuta lokiasetuksia',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Käytä SMTP autentikointia?',
  'LBL_MAIL_SMTPPASS' => 'SMTP salasana:',
  'LBL_MAIL_SMTPPORT' => 'SMTP portti:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP palvelin:',
  'LBL_MAIL_SMTPUSER' => 'SMTP käyttäjätunnus:',
  'LBL_MAILMERGE_DESC' => 'Aktivoi valinta vain jos Sugar-lisäosa Microsoft Word -ohjelmaa varten on ostettu ja lisenssi on voimassa',
  'LBL_MAILMERGE' => 'Joukkopostitus:',
  'LBL_MODULE_NAME' => 'Järjestelmän asetukset',
  'LBL_MODULE_ID' => 'Konfigurointi',
  'LBL_MODULE_TITLE' => 'Käyttöliittymä',
  'LBL_NOTIFY_FROMADDRESS' => '"Lähettäjä" osoite:',
  'LBL_NOTIFY_SUBJECT' => 'Sähköpostin aihe:',
  'LBL_PORTAL_ON_DESC' => 'Sallii palvelupyyntöjen, muistioiden sekä muiden tietojen käytön ulkoisen asiakkaille tarkoitetun itsepalveluportaalin kautta.',
  'LBL_PORTAL_ON' => 'Salli itsepalveluportaalin liittäminen?',
  'LBL_PORTAL_TITLE' => 'Asiakkaiden itsepalveluportaali',
  'LBL_PROXY_AUTH' => 'Autentikointi?',
  'LBL_PROXY_HOST' => 'Proxypalvelin',
  'LBL_PROXY_ON_DESC' => 'Käytä proxya käyttäessäsi ulkopuolisia palveluita kuten Sugar-päivityksiä.',
  'LBL_PROXY_ON' => 'Ota Proxy käyttöön?',
  'LBL_PROXY_PASSWORD' => 'Salasana',
  'LBL_PROXY_PORT' => 'Portti',
  'LBL_PROXY_TITLE' => 'Proxy-asetukset',
  'LBL_PROXY_USERNAME' => 'Käyttäjätunnus',
  'LBL_RESTORE_BUTTON_LABEL' => 'Palauta',
  'LBL_SKYPEOUT_ON_DESC' => 'Sallii käyttäjien napsauttaa puhelinnumeroita soittaakseen SkypeOut&reg;:n avulla. Numerot tulee muotoilla oikein jotta toimintoa voidaan käyttää. Oikea muoto on "+"  "maakoodi" "numero" katso lisätietoja osoitteessa <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>',
  'LBL_SKYPEOUT_ON' => 'Salli SkypeOut&reg; integraatio?',
  'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
  'LBL_USE_REAL_NAMES' => 'Näytä koko nimi (ei käyttäjätunnusta)',
  'LIST_ENTRIES_PER_LISTVIEW' => 'Nimikkeiden määrä listanäkymän yhdellä sivulla',
  'LIST_ENTRIES_PER_SUBPANEL' => 'Nimikkeiden määrä alipaneelin yhdellä sivulla',
  'LOG_MEMORY_USAGE' => 'Kirjaa lokiin muistin käyttö',
  'LOG_SLOW_QUERIES' => 'Kirjaa lokiin hitaat kyselyt',
  'NEW_LOGO' => 'Lataa uusi logo (212x40)',
  'NEW_QUOTE_LOGO' => 'Vie palvelimelle uusi tarjouslogo (867x74)',
  'QUOTES_CURRENT_LOGO' => 'Tarjouksissa käytetty logo',
  'SLOW_QUERY_TIME_MSEC' => 'Hitaan kyselyn raja (millisekunteja)',
  'STACK_TRACE_ERRORS' => 'Näytä virhepino',
  'UPLOAD_MAX_SIZE' => 'Suurin sallittu palvelimelle vietävän tiedoston koko',
  'VERIFY_CLIENT_IP' => 'Validoi käyttäjän IP-osoite',
  'LOCK_HOMEPAGE' => 'Käyttäjät eivät voi muokata etusivua',
  'LOCK_SUBPANELS' => 'Käyttäjät eivät voi muokata alipaneeleiden ulkoasua',
  'MAX_DASHLETS' => 'Suurin sallittu Dashlet-osien määrä etusivulla',
  'SYSTEM_NAME' => 'Järjestelmän nimi',
  'LBL_LDAP_TITLE' => 'LDAP autentikointituki',
  'LBL_LDAP_ENABLE' => 'Ota LDAP käyttöön',
  'LBL_LDAP_SERVER_HOSTNAME' => 'Palvelin:',
  'LBL_LDAP_SERVER_PORT' => 'Portin numero:',
  'LBL_LDAP_ADMIN_USER' => 'Autentikoitu käyttäjä:',
  'LBL_LDAP_ADMIN_USER_DESC' => 'Käytetään Sugar-käyttäjän etsimiseen. [May need to be fully qualified]<br>It will bind anonymously if not provided.',
  'LBL_LDAP_ADMIN_PASSWORD' => 'Autentikoitu salasana:',
  'LBL_LDAP_AUTO_CREATE_USERS' => 'Uusi käyttäjät automaattisesti:',
  'LBL_LDAP_BASE_DN' => 'Perus DN:',
  'LBL_LDAP_LOGIN_ATTRIBUTE' => 'Login attribuutti:',
  'LBL_LDAP_BIND_ATTRIBUTE' => 'Bind attribuutti:',
  'LBL_LDAP_BIND_ATTRIBUTE_DESC' => 'For Binding the LDAP User Examples:[<b>AD:</b>&nbsp;userPrincipalName] [<b>openLDAP:</b>&nbsp;userPrincipalName] [<b>Mac&nbsp;OS&nbsp;X:</b>&nbsp;uid] ',
  'LBL_LDAP_LOGIN_ATTRIBUTE_DESC' => 'For searching for the LDAP User Examples:[<b>AD:</b>&nbsp;userPrincipalName] [<b>openLDAP:</b>&nbsp;dn] [<b>Mac&nbsp;OS&nbsp;X:</b>&nbsp;dn] ',
  'LBL_LDAP_SERVER_HOSTNAME_DESC' => 'Esimerkki: ldap.omasivu.fi',
  'LBL_LDAP_SERVER_PORT_DESC' => 'Esimerkki: 389',
  'LBL_LDAP_BASE_DN_DESC' => 'Esimerkki: DC=SugarCRM,DC=com',
  'LBL_LDAP_AUTO_CREATE_USERS_DESC' => 'Jos autentikoitua käyttäjää ei ole, se luodaan Sugariin.',
  'LBL_LDAP_ENC_KEY' => 'Kryptausavain:',
  'LBL_LDAP_ENC_KEY_DESC' => 'SOAP-autentikointi kun käytössä ldap.',
  'LDAP_ENC_KEY_NO_FUNC_DESC' => 'php_mcrypt -laajennus tulee olla käytössä php.ini -tiedostossa.',
);


?>