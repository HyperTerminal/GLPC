<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Hakemistoa',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' ei ole tai se on kirjoitussuojattu',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Tiedoston vienti palvelimelle ei onnistunut. Voi olla että php.ini-tiedoston \'upload_max_filesize\' arvoa tulee kasvattaa.',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Tiedosto on liian suuri, suurin sallittu koko:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'tavua. Muuta $sugar_config[\'upload_maxsize\'] arvoa tiedostossa config.php',
  'LBL_MODULE_NAME' => 'Käyttäjät',
  'LBL_TRY_AGAIN' => 'Yritä uudelleen',
  'LBL_ERROR' => 'Virhe:',
  'ERR_MULTIPLE' => 'Useammalla kentällä on sama nimi.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Syötä tieto vaadittuihin kenttiin:',
  'ERR_SELECT_FULL_NAME' => 'Et voi valita koko nimeä kun Etunimi ja Sukunimi on valittu.',
  'ERR_SELECT_FILE' => 'Palvelimelle vietävä tiedosto.',
  'LBL_SELECT_FILE' => 'Valitse tiedosto:',
  'LBL_CUSTOM' => 'Muokattu',
  'LBL_CUSTOM_CSV' => 'Muokattu pilkulla erotettu tiedosto',
  'LBL_CSV' => 'Pilkulla erotettu tiedosto',
  'LBL_TAB' => 'Sarkainmerkillä erotettu tiedosto',
  'LBL_CUSTOM_DELIMETED' => 'Omalla erotinmerkillä erotettu tiedosto',
  'LBL_CUSTOM_DELIMETER' => 'Oma erotinmerkki:',
  'LBL_CUSTOM_TAB' => 'Muokattu sarkaimella erotettu tiedosto',
  'LBL_DONT_MAP' => '-- älä ota huomioon tätä kenttää --',
  'LBL_STEP_1_TITLE' => 'Kohta 1: Valitse lähde',
  'LBL_WHAT_IS' => 'Mikä on tietolähde?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Tallennetut lähteet:',
  'LBL_PUBLISH' => 'julkaise',
  'LBL_DELETE' => 'Poista',
  'LBL_PUBLISHED_SOURCES' => 'Julkaistut lähteet:',
  'LBL_UNPUBLISH' => 'lopeta julkaisu',
  'LBL_NEXT' => 'Seuraava >',
  'LBL_BACK' => 'Takaisin',
  'LBL_STEP_2_TITLE' => 'Kohta 2: Vie tiedosto palvelimelle',
  'LBL_HAS_HEADER' => 'Otsikko on:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOTES' => 'Lisämerkinnät:',
  'LBL_NOW_CHOOSE' => 'Valitse tuotava tiedosto:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 ja 2000 viedä tiedot <b>Comma Separated Values</b> muodossa jota voidaan käyttää data tuontiin järjestelmään. Vie tieto Outlookista seuraavien ohjeiden avulla:',
  'LBL_OUTLOOK_NUM_1' => 'Käynnistä <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'Valitse <b>File</b> valikko, sen jälkeen <b>Import and Export ...</b> valikko',
  'LBL_OUTLOOK_NUM_3' => 'Valitse <b>Export to a file</b> ja valitse Next',
  'LBL_OUTLOOK_NUM_4' => 'Valitse <b>Comma Separated Values (Windows)</b> ja napsauta <b>Next</b>.<br>  Huomaa: voit ehkä joutua asentamaan tiedon vienti (export) komponentin',
  'LBL_OUTLOOK_NUM_5' => 'Valitse <b>Contacts</b> kansio ja napsauta <b>Next</b>. Voit valita toisen kontakteja sis',
  'LBL_OUTLOOK_NUM_6' => 'Valitse tiedosto ja napsauta <b>Next</b>',
  'LBL_OUTLOOK_NUM_7' => 'Napsauta <b>Finish</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! voi viedä tietoa <b>Comma Separated Values</b> muodossa. Tätä muotoa voidaan käyttää tiedon tuontiin. Vie tieto Act!-ohjelmasta seuraavien ohjeiden avulla:',
  'LBL_ACT_NUM_1' => 'Käynnistä <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'Valitse <b>File</b> valikko, <b>Data Exchange</b> valikko ja sen jälkeen <b>Export...</b> valikko',
  'LBL_ACT_NUM_3' => 'Valitse tiedostotyypiksi <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'Valitse tiedostonimi ja sijainti vietävälle tiedolle ja napsauta <b>Next</b>',
  'LBL_ACT_NUM_5' => 'Valitse <b>Contacts records only</b>',
  'LBL_ACT_NUM_6' => 'Napsauta <b>Options...</b> painiketta',
  'LBL_ACT_NUM_7' => 'Valitse <b>Comma</b> kenttien erotinmerkiksi',
  'LBL_ACT_NUM_8' => 'Valitse <b>Yes, export field names</b> valinta ja napsauta <b>OK</b>',
  'LBL_ACT_NUM_9' => 'Napsauta <b>Next</b>',
  'LBL_ACT_NUM_10' => 'Valitse <b>All Records</b> napsauta sen jälkeen <b>Finish</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com voi viedä tietoa <b>Comma Separated Values</b> muodossa. Tätä muotoa voidaan käyttää tiedon tuontiin. Vie tieto Salesforce.com-sivustolta seuraavien ohjeiden avulla:',
  'LBL_SF_NUM_1' => 'Avaa selain ja siirry sivustolle http://www.salesforce.com. Kirjaudu sähköpostiosoitteesi ja salanasi avulla',
  'LBL_SF_NUM_2' => 'Napsauta <b>Reports</b> kielekettä ylävalikossa',
  'LBL_SF_NUM_3' => '<b>Asiakastietojen vienti:</b> Napsauta <b>Active Accounts</b> linkkiä<br><b>Kontaktien vienti:</b> Napsauta <b>Mailing List</b> linkkiä',
  'LBL_SF_NUM_4' => '<b>kohta 1: Valitse raportin tyyppi</b>, valitse <b>Tabular Report</b>napsauta <b>Next</b>',
  'LBL_SF_NUM_5' => '<b>kohta 2: Valitse raportin sarakkeet</b>, valitse halutut sarakkeet ja napsauta <b>Next</b>',
  'LBL_SF_NUM_6' => '<b>kohta 3: Valitse kokoomatieto</b>, napsauta<b>Next</b>',
  'LBL_SF_NUM_7' => '<b>kohta 4: Järjestä raportin sarakkeet</b>, napsauta <b>Next</b>',
  'LBL_SF_NUM_8' => '<b>kohta 5: Valitse raportin kriteerit</b>, kohdassa <b>Start Date</b>, valitse riittävän pitkällä menneisyydessä oleva päivämäärä jotta kaikki asiakastiedot tulisivat mukaan. Voit myös viedä osan asiakastiedoista tarkempia kriteerejä käyttämällä. Kun olet valmis, napsauta <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'Raportti luodaan ja sivulla tulisi näkyä <b>Report Generation Status: Complete.</b> Napsauta tämän jälkeen <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => 'Kohdassa <b>Export Report:</b>, ja <b>Export File Format:</b>, valitse <b>Comma Delimited .csv</b>. Napsauta <b>Export</b>.',
  'LBL_SF_NUM_11' => 'Esiin tulevan valintaikkunan avulla tallennat tiedoston omalle koneellesi.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Monet sovellukset sallivat tiedon viennin <b>Comma Delimited text file (.csv)</b> -muodossa. Useimmat ohjelmat seuraavat näitä ohjeita:',
  'LBL_CUSTOM_NUM_1' => 'Käynnistä sovellus ja avaa tiedosto',
  'LBL_CUSTOM_NUM_2' => 'Valitse <b>Save As...</b> tai <b>Export...</b> valikko',
  'LBL_CUSTOM_NUM_3' => 'Tallenna tiedosto <b>CSV</b> tai <b>Comma Separated Values</b> muodossa',
  'LBL_IMPORT_TAB_TITLE' => 'Monet sovellukset sallivat tiedon viennin <b>Tab Delimited text file (.tsv or .tab)</b> -muodossa. Useimmat ohjelmat seuraavat näitä ohjeita:',
  'LBL_TAB_NUM_1' => 'Käynnistä sovellus ja avaa tiedosto',
  'LBL_TAB_NUM_2' => 'Valitse <b>Save As...</b> tai <b>Export...</b> valikko',
  'LBL_TAB_NUM_3' => 'Tallenna tiedosto  <b>TSV</b> tai <b>Tab Separated Values</b> muodossa',
  'LBL_STEP_3_TITLE' => 'Kohta 3: Vahvista kentät ja tuo',
  'LBL_SELECT_FIELDS_TO_MAP' => 'Valitse alla olevasta listasta tuotavat kentät ja mihin ne tietokannassa kohdistet',
  'LBL_DATABASE_FIELD' => 'Tietokannan kenttä',
  'LBL_HEADER_ROW' => 'Otsikkorivi',
  'LBL_ROW' => 'Rivi',
  'LBL_SAVE_AS_CUSTOM' => 'Tallenna muokattuna karttana:',
  'LBL_CONTACTS_NOTE_1' => 'Joko suku- tai etunimi tulee kohdistaa.',
  'LBL_CONTACTS_NOTE_2' => 'Jos koko nimi -kenttä on kohdistettu, etunimi ja sukunimi sivuutetaan.',
  'LBL_CONTACTS_NOTE_3' => 'Jos koko nimi - kenttä on kohdistettu, koko nimi -kentässä oleva tieto jaetaan etunimi ja sukunimi -kenttiin tietokantaan siirrettäessä.',
  'LBL_CONTACTS_NOTE_4' => 'Kentät Katuosoite 2 ja Katuosoite 3 yhdistetään Katuosoite-kenttään tietokantaan siirrettäessä.',
  'LBL_ACCOUNTS_NOTE_1' => 'Asiakas tulee kohdistaa.',
  'LBL_ACCOUNTS_NOTE_2' => 'Kentät Katuosoite 2 ja Katuosoite 3 yhdistetään Katuosoite-kenttään tietokantaan siirrettäessä.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Myyntimahdollisuuden nimi, Asiakas, Sulkemispäivämäärä ja Myynnin tila ovat vaadittuja kenttiä.',
  'LBL_IMPORT_NOW' => 'Tuo nyt',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Tiedoston avaaminen ei onnistunut',
  'LBL_NOT_SAME_NUMBER' => 'Tiedostossa ei ollut samaa määrää kenttiä eri riveillä',
  'LBL_NO_LINES' => 'Tiedostossa ei ollut rivejä',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Tiedosto on jo käsitelty tai sitä ei ole',
  'LBL_SUCCESS' => 'Onnistui:',
  'LBL_SUCCESSFULLY' => 'Tiedot tuotu onnistuneesti',
  'LBL_LAST_IMPORT_UNDONE' => 'Viimeisin tiedon tuonti on peruttu',
  'LBL_NO_IMPORT_TO_UNDO' => 'Peruttavaa tiedon tuontia ei ollut.',
  'LBL_FAIL' => 'Virhe:',
  'LBL_RECORDS_SKIPPED' => 'tietuetta sivuutettiin koska niistä puuttui yksi tai useampi vaadittu kenttä',
  'LBL_IDS_EXISTED_OR_LONGER' => 'tietuetta sivuutettiin koska avainkentät olivat jo olemassa tai ne olivat yli 36 merkkiä pitkiä',
  'LBL_RESULTS' => 'Tulokset',
  'LBL_IMPORT_MORE' => 'Tuo lisää',
  'LBL_FINISHED' => 'Valmis',
  'LBL_UNDO_LAST_IMPORT' => 'Peru viimeisin tiedon tuonti',
  'LBL_LAST_IMPORTED' => 'Viimeksi tuotu',
  'ERR_MULTIPLE_PARENTS' => 'Voit määritellä vain yhden Parent ID -tunnuksen',
  'LBL_DUPLICATES' => 'Havaittiin kaksoiskappaleita',
  'LBL_DUPLICATE_LIST' => 'Lataa lista kaksoiskappaleista',
  'LBL_UNIQUE_INDEX' => 'Valitse indeksi, jonka mukaan kaksoiskappaleita etsitään',
  'LBL_VERIFY_DUPS' => 'Vahvista duplikaatit vasten valittuja indeksejä',
  'LBL_INDEX_USED' => 'Käytetyt indeksit',
  'LBL_INDEX_NOT_USED' => 'Indeksit joita ei käytetty',
  'LBL_IMPORT_MODULE_ERROR_NO_MOVE' => 'Tiedoston palvelimelle vienti ei onnistunut. Tarkista Sugar-asennushakemiston tiedostojen käyttöoikeudet.',
  '' => '',
);


?>