<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
// OOTB Scheduler Job Names:
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
// List Labels
  'LBL_OOTB_WORKFLOW' => 'Suorita työkulunhallinnan (workflow) tehtävät',
  'LBL_OOTB_REPORTS' => 'Suorita ajastetut tehtävät, jotka luovat raportteja',
  'LBL_OOTB_IE' => 'Tarkista sähköpostilaatikot',
  'LBL_OOTB_BOUNCE' => 'Aja jokaöinen tarkistus, joka näyttää kampanjassa olleet virheelliset sähköpostiosoitteet',
  'LBL_OOTB_CAMPAIGN' => 'Aja jokaöiset sähköpostikampanjat',
  'LBL_OOTB_PRUNE' => 'Järjestä tietokanta kuukauden 1. päivä',
  'LBL_LIST_JOB_INTERVAL' => 'Suoritustiheys:',
  'LBL_LIST_LIST_ORDER' => 'Ajastetut tehtävät:',
// human readable:
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_RANGE' => 'Alue:',
  'LBL_LIST_REMOVE' => 'Poista:',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_TITLE' => 'Asema',
  'LBL_LIST_EXECUTE_TIME' => 'Suoritetaan:',
  'LBL_SUN' => 'Sunnuntai',
  'LBL_MON' => 'Maanantai',
  'LBL_TUE' => 'Tiistai',
  'LBL_WED' => 'Keskiviikko',
  'LBL_THU' => 'Torstai',
  'LBL_FRI' => 'Perjantai',
  'LBL_SAT' => 'Lauantai',
  'LBL_ALL' => 'Joka päivä',
  'LBL_EVERY_DAY' => 'Joka päivä ',
  'LBL_AT_THE' => 'At the ',
  'LBL_EVERY' => 'Joka',
  'LBL_FROM' => 'Lähettäjä ',
  'LBL_ON_THE' => 'Valittu aika ',
  'LBL_RANGE' => ' - ',
  'LBL_AT' => 'at ',
  'LBL_IN' => 'in ',
  'LBL_AND' => 'ja ',
  'LBL_MINUTES' => 'minuutit ',
  'LBL_HOUR' => ' tunnit',
// crontabs
  'LBL_HOUR_SING' => ' tunti',
  'LBL_MONTH' => ' kuukausi',
  'LBL_OFTEN' => ' Niin usein kuin mahdollista',
  'LBL_MIN_MARK' => ' minuutin merkki',
  'LBL_MINS' => 'min',
  'LBL_HOURS' => 'h',
// Labels
  'LBL_DAY_OF_MONTH' => 'päiväys',
  'LBL_MONTHS' => 'kk',
  'LBL_DAY_OF_WEEK' => 'päivä',
  'LBL_CRONTAB_EXAMPLES' => 'Yllä käytetään normaalia crontab-merkintätapaa.',
  'LBL_ALWAYS' => 'Aina',
  'LBL_CATCH_UP' => 'Suorita jos ei onnistu',
  'LBL_CATCH_UP_WARNING' => 'Poista valinta jos tämä työn ajo vie enemmän kuin hetken.',
  'LBL_DATE_TIME_END' => 'Lopetuspäivä ja -aika',
  'LBL_DATE_TIME_START' => 'Aloituspäivä ja -aika',
  'LBL_INTERVAL' => 'Suoritustiheys',
  'LBL_JOB' => 'Työ',
  'LBL_LAST_RUN' => 'viimeksi ajettu',
  'LBL_MODULE_NAME' => 'Ajastetut tehtävät',
  'LBL_MODULE_TITLE' => 'Ajastetut tehtävät: etusivu',
  'LBL_NAME' => 'Nimi:',
  'LBL_NEVER' => 'Ei koskaan',
  'LBL_NEW_FORM_TITLE' => 'Uusi ajastettu tehtävä',
  'LBL_PERENNIAL' => 'jatkuva',
  'LBL_SEARCH_FORM_TITLE' => 'Hae ajastettu tehtävä',
  'LBL_SCHEDULER' => 'Ajastetut:',
  'LBL_STATUS' => 'Tila:',
  'LBL_TIME_FROM' => 'Aktiivinen lähtien',
  'LBL_TIME_TO' => 'Aktiivinen saakka',
  'LBL_WARN_CURL_TITLE' => 'cURL varoitus:',
  'LBL_WARN_CURL' => 'Varoitus:',
  'LBL_WARN_NO_CURL' => 'Järjestelmän PHP moduulissa ei ole cURL kirjastoja päällä/käännetty (--with-curl=/path/to/curl_library). Ota yhteyttä järjestelmän ylläpitäjään. Ilman cURL toimintoa ajastettuja tehtäviä ei voi käyttää.',
// Links
  'LBL_BASIC_OPTIONS' => 'Perusasetukset',
  'LBL_ADV_OPTIONS' => 'Edistyneet valinnat',
  'LBL_TOGGLE_ADV' => 'Edistyneet valinnat',
  'LBL_TOGGLE_BASIC' => 'Perusvalinnat',
  'LNK_LIST_SCHEDULER' => 'Ajastetut tehtävät',
  'LNK_NEW_SCHEDULER' => 'Uusi ajastettu tehtävä',
// Messages
  'LNK_LIST_SCHEDULED' => 'Ajastetut tehtävät',
  'SOCK_GREETING' => 'Tämä on sovelluksen automaattisten tehtävien hallinnan käyttöliittymä. [ Käytettävissä olevat daemon-komennot: start|restart|shutdown|status ]  Voit lopettaa kirjoittamalla \'quit\'. Palvelu lopetetaan kirjoittamalla \'shutdown\'. ',
  'ERR_DELETE_RECORD' => 'Anna tietuenumero poistaaksesi ajastetun tehtävän.',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tämän tietueen?',
  'NTC_STATUS' => 'Aseta tilaksi ei-aktiivinen poistaaksesi tämän työn ajastettujen töiden listasta',
  'NTC_LIST_ORDER' => 'Aseta työn ajastettujen töiden listassa näkyvä järjestys',
  'LBL_CRON_INSTRUCTIONS_WINDOWS' => 'Windows Scheduler asetukset',
  'LBL_CRON_INSTRUCTIONS_LINUX' => 'Crontab asetukset',
  'LBL_CRON_LINUX_DESC' => 'Lisää tämä rivi crontab-kohtaan: ',
  'LBL_CRON_WINDOWS_DESC' => 'Uusi komentotiedosto, joka sisältää seuraavat komennot: ',
  'LBL_NO_PHP_CLI' => 'Jos palvelimella ei ole PHP-binääritiedostoa, voit käyttää wget tai curl -toimintoja palveluiden suorittamiseen.<brwget esimerkki: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;wget --quiet --non-verbose /cron.php > /dev/null 2>&1</b><br>curl esimerkki: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;curl --silent /cron.php > /dev/null 2>&1',
  'LBL_JOBS_SUBPANEL_TITLE' => 'Työloki',
  'LBL_EXECUTE_TIME' => 'Suoritusaika',
  'scheduler_status_dom' => 
  array (
    'Active' => 'Aktiivinen',
    'Inactive' => 'Ei-aktiivinen',
  ),
  'scheduler_period_dom' => 
  array (
    'min' => 'Minuutit',
    'hour' => 'Tunnit',
  ),
);


?>