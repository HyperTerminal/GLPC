<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Räätälöidyt kentät',
  'LBL_ADD_FIELD' => 'Lisää kenttä:',
  'LBL_MODULE_TITLE' => 'Muokkaa räätälöityjä kenttiä',
  'LBL_MODULE_SELECT' => 'Muokattava moduuli',
  'LBL_SEARCH_FORM_TITLE' => 'Hae räätälöity kenttä',
  'COLUMN_TITLE_NAME' => 'Kentän nimi',
  'COLUMN_TITLE_LABEL' => 'Kentän otsikko',
  'COLUMN_TITLE_DATA_TYPE' => 'Tietotyyppi',
  'COLUMN_TITLE_MAX_SIZE' => 'Suurin koko',
  'COLUMN_TITLE_HELP_TEXT' => 'Ohjeteksti',
  'COLUMN_TITLE_REQUIRED_OPTION' => 'Arvo vaaditaan',
  'COLUMN_TITLE_DEFAULT_VALUE' => 'Oletusarvo',
  'COLUMN_TITLE_DEFAULT_EMAIL' => 'Oletusarvo',
  'COLUMN_TITLE_EXT1' => 'Ylim. metatietokenttä 1',
  'COLUMN_TITLE_EXT2' => 'Ylim. metatietokenttä 2',
  'COLUMN_TITLE_EXT3' => 'Ylim. metatietokenttä 3',
  'COLUMN_TITLE_HTML_CONTENT' => 'HTML',
  'COLUMN_TITLE_URL' => 'Oletus URL',
  'COLUMN_TITLE_AUDIT' => 'Tallenna muutostieto ?',
  'COLUMN_TITLE_MIN_VALUE' => 'Pienin arvo',
  'COLUMN_TITLE_MAX_VALUE' => 'Suurin arvo',
  'COLUMN_TITLE_DISPLAYED_ITEM_COUNT' => '# nimikettä esitetään',
  'LBL_DROP_DOWN_LIST' => 'Pudotusvalikko',
  'LBL_RADIO_FIELDS' => 'Radio kentät',
  'LBL_MULTI_SELECT_LIST' => 'Monivalintalista',
  'COLUMN_TITLE_PRECISION' => 'Tarkkuus',
  'MSG_DELETE_CONFIRM' => 'Haluatko poistaa tämän?',
  'POPUP_INSERT_HEADER_TITLE' => 'Lisää oma kenttä',
  'POPUP_EDIT_HEADER_TITLE' => 'Muokkaa omaa kenttää',
  'LNK_SELECT_CUSTOM_FIELD' => 'Valitse oma kenttä',
  'LNK_REPAIR_CUSTOM_FIELD' => 'Korjaa omat kentät',
  'LBL_MODULE' => 'Moduuli',
  'COLUMN_TITLE_MASS_UPDATE' => 'Massapäivitys',
  'COLUMN_TITLE_DUPLICATE_MERGE' => 'Yhdistä duplikaatit',
  'LBL_LABEL' => 'Otsikko',
  'LBL_DATA_TYPE' => 'Tietotyyppi',
  'LBL_DEFAULT_VALUE' => 'Oletusarvo',
  'LBL_AUDITED' => 'Auditoitu',
);


?>