<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_ADVANCED' => 'Lisävalinnat:',
  'LBL_EDIT_IN_PLACE' => 'Muokkaa paikalla:',
  'DESC_USING_LAYOUT_TITLE' => 'Ulkoasueditorin käyttö',
  'DESC_USING_LAYOUT_SHORTCUTS' => 'Pikavalinnat:',
  'DESC_USING_LAYOUT_TOOLBAR' => 'Työkalurivi:',
  'DESC_USING_LAYOUT_EDIT_ROWS' => 'Muokkaa rivejä:',
  'DESC_USING_LAYOUT_SELECT_FILE' => 'Valitse tiedosto:',
  'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Muokkaa kenttiä:',
  'DESC_USING_LAYOUT_ADD_FIELD' => 'Lisää kenttä:',
  'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Poista nimike:',
  'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Näytä HTML-koodi:',
  'DESC_USING_LAYOUT_BLK1' => 'Kenttäeditorin avulla voi muokata kenttiä, kielekkeitä ja kielekkeiden paneeleita tarpeittesi mukaan. Valitse ensin sivu ja näkymä jota haluat muokata &#8220;Select File&#8221; pikanäppäimen avulla.',
  'DESC_USING_LAYOUT_BLK2' => ' antaa valita eri sivun muokattavaksi. Sivulle tehdyt muutokset menetetään ellei niitä tallenneta. Jos et ole varma mitä tiedostoa pitäisi muuttaa, voit valita &#8220;Muokkaa paikalla&#8221; valinnan. Tämä lisää muokkauskentän kaikille sovelluksen muokattavissa oleville sivuille. Siirry ensin sivulle jota haluat muokata, napsauta muokkausvalintaa ja pääset sivun muokkausnäkymään.',
  'DESC_USING_LAYOUT_BLK3' => ' siirrä ja järjestä yksittäisiä kenttiä tai niiden otsikoita. Valitse ensin siirrettävän kentän tai otsikon kahva ',
  'DESC_USING_LAYOUT_BLK4' => ' ja napsauta nimikkeen kahvaa johon haluat kentän tai otsikon sijoittaa. Tällä tavoin siirrät nimikkeen alkuperäisestä sijaintipaikasta uuteen kohtaan. Jos kohteessa oli jo kenttä tai otsikko, nämä kaksi nimikettä vaihtavat paikkoja. Alipaneelien siirtäminen tapahtuu samoin kuin kenttien. Valitse ensin lähdealipaneelin kahva ja sen jälkeen kohteen kahva ja nämä kaksi muuttavat paikkaansa. Kun haluat poistaa lomakkeen näytöltä, vedä nimike vasemmalla olevan valikkorivin Työkalulaatikon alueelle.',
  'DESC_USING_LAYOUT_BLK5' => ' muuttaa näkymän jotta voit lisätä ja poistaa rivejä tarkemmat tiedot sisältävästä paneelista. Plus-näppäin (+) lisää rivin valitun rivin alle, miinus-näppäin (&#8211;) poistaa rivin.',
  'DESC_USING_LAYOUT_BLK6' => 'Työkalulaatikko tarjoaa työtilan, jonka avulla voit lisätä uusia kenttiä ja otsikoita lomakkeelle, väliaikaisesti säilyttää lomakkeelta poistettuja kenttiä ja hylätä nimikkeitä.',
  'DESC_USING_LAYOUT_BLK7' => ' avaa valintanäkymän jossa voit määritellä lisättävän kentän tietotyypin ja otsikon. Napsauta Add-painiketta lisätäksesi uuden kentän ja sen otsikon työkalulaatikon työtilaan. Siirrä uusi kenttä työtilasta valitsemalla ensin siirrettävän kentän kahvan ja napsauttamalla sen jälkeen kohdekentän kahvan kohdalla.',
  'DESC_USING_LAYOUT_BLK8' => ' tehdään valitsemalla sen kahva ja napsauttamalla tekstiä &#8220;siirrä ja nimikkeet tänne&#8221;. Tämä tallentaa valitun nimikkeen Työkalulaatikon työtilaan.',
  'DESC_USING_LAYOUT_BLK9' => ' valintakenttä näyttää jokaisen kentän muodostavan html-koodin. Vaikka tämä voi olla hyödyllinen tieto, se vaatii kuitenkin paljon prosessointitehoa ja sitä tulisi käyttää vain tarvittaessa.',
  'DESC_USING_LAYOUT_BLK10' => 'Tallenna muutokset napsauttamalla &#8220;Tallenna ulkoasu&#8221; painiketta. Peru muutokset napsauttamalla jotain muuta sovelluksen kielekettä ja siirtymällä sovelluksen toiseen osaan. Tällöin viimeisen tallennuksen jälkeen tehdyt muutokset sivuutetaan.',
  'NO_RECORDS_LISTVIEW' => 'Jotta voit muokata listanäkymää, tulee nämän sisältää ainakin yksi tietue. Luo listassa näytettävä tietue ennen kuin muokkaat näkymää.',
  'LBL_EDIT_LAYOUT' => 'Muokkaa ulkoasua',
  'LBL_EDIT_ROWS' => 'Muokkaa rivejä',
  'LBL_EDIT_COLUMNS' => 'Muokkaa sarakkeita',
  'LBL_EDIT_LABELS' => 'Muokkaa otsikoita',
  'LBL_EDIT_FIELDS' => 'Muokkaa räätälöityjä kenttiä',
  'LBL_ADD_FIELDS' => 'Lisää omia kenttiä',
  'LBL_DISPLAY_HTML' => 'Näytä HTML-koodi',
  'LBL_SELECT_FILE' => 'Valitse tiedosto:',
  'LBL_SAVE_LAYOUT' => 'Tallenna ulkoasu',
  'LBL_SELECT_A_SUBPANEL' => 'Valitse alipaneeli',
  'LBL_SELECT_SUBPANEL' => 'Valitse alipaneeli',
  'LBL_TOOLBOX' => 'Työkalut',
  'LBL_STAGING_AREA' => 'Väliaikainen alue (siirrä ja pudota nimikkeet tänne)',
  'LBL_SUGAR_FIELDS_STAGE' => 'Sugar kentät (napsauta nimikkeitä lisätäksesi ne väliaikaiselle alueelle)',
  'LBL_SUGAR_BIN_STAGE' => 'Sugar säilytysalue (napsauta nimikkeitä lisätäksesi ne väliaikaiselle alueelle)',
  'LBL_VIEW_SUGAR_FIELDS' => 'Näytä Sugar-kentät',
  'LBL_VIEW_SUGAR_BIN' => 'Näytä Sugar säilytysalue',
);


?>