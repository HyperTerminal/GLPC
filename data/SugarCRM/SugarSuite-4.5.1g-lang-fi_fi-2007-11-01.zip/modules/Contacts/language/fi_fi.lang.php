<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
    //DON'T CONVERT THESE THEY ARE MAPPINGS
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/
    //END DON'T CONVERT

$mod_strings = array (
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'LBL_ACCOUNT_ID' => 'Asiakkaan tunnus',
  'LBL_ACCOUNT_NAME' => 'Asiakas',
  'LBL_CAMPAIGN' => 'Campaign:',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_ADD_BUSINESSCARD' => 'Luo käyntikortin avulla',
  'LBL_ADDMORE_BUSINESSCARD' => 'Lisää toinen käyntikortti',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_ALT_ADDRESS_CITY' => 'Vaihtoehtoinen osoite Kaupunki:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Vaihtoehtoinen osoite Maa:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Vaihtoehtoinen osoite Postinumero:',
  'LBL_ALT_ADDRESS_STATE' => 'Vaihtoehtoinen osoite Lääni:',
  'LBL_ALT_ADDRESS_STREET_2' => 'Vaihtoehtoinen katuosoite 2',
  'LBL_ALT_ADDRESS_STREET_3' => 'Vaihtoehtoinen katuosoite 3',
  'LBL_ALT_ADDRESS_STREET' => 'Vaihtoehtoinen katuosoite:',
  'LBL_ALTERNATE_ADDRESS' => 'Muu osoite:',
  'LBL_ANY_ADDRESS' => 'Muu osoite:',
  'LBL_ANY_EMAIL' => 'Muu sähköposti:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_ASSIGNED_TO_NAME' => 'Määritelty nimelle',
  'LBL_ASSISTANT_PHONE' => 'Assistentin puhelin:',
  'LBL_ASSISTANT' => 'Assistentti:',
  'LBL_BIRTHDATE' => 'Syntymäaika:',
  'LBL_BUSINESSCARD' => 'Käyntikortti',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_CAMPAIGN_ID' => 'Campaign ID',
  'LBL_CONTACT_INFORMATION' => 'Kontaktin tiedot',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakti-mahdollisuus:',
  'LBL_CONTACT_ROLE' => 'Rooli:',
  'LBL_CONTACT' => 'Kontaktin nimi: ',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_CREATED_ACCOUNT' => 'Uusi asiakas luotu',
  'LBL_CREATED_CALL' => 'Uusi puhelinsoitto luotu',
  'LBL_CREATED_CONTACT' => 'Uusi kontakti luotu',
  'LBL_CREATED_MEETING' => 'Uusi tapaaminen luotu',
  'LBL_CREATED_OPPORTUNITY' => 'Uusi myyntimahdollisuus luotu',
  'LBL_DATE_MODIFIED' => 'Muokkauspäivä',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_DEPARTMENT' => 'Osasto:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_DIRECT_REPORTS_SUBPANEL_TITLE' => 'Raportoi suoraan',
  'LBL_DO_NOT_CALL' => 'älä soita:',
  'LBL_DUPLICATE' => 'Mahdollisesti kaksi samanlaista prospektia',
  'LBL_EMAIL_ADDRESS' => 'Sähköposti:',
  'LBL_EMAIL_OPT_OUT' => 'Ei sähköpostia:',
  'LBL_EXISTING_ACCOUNT' => 'Käytti olemassa olevaa asiakasta',
  'LBL_EXISTING_CONTACT' => 'Käytti olemassa olevaa kontaktia',
  'LBL_EXISTING_OPPORTUNITY' => 'Käytti olemassa olevaa myyntimahdollisuutta',
  'LBL_FAX_PHONE' => 'Faksi:',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_FULL_NAME' => 'Koko nimi:',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_HOME_PHONE' => 'Kotipuhelin:',
  'LBL_ID' => 'Relaation Id',
  'LBL_IMPORT_VCARD' => 'Tuo vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Uusi automaattisesti uusi kontakti tuomalla vCard-tiedosto.',
  'LBL_INVALID_EMAIL' => 'Virheellinen sähköposti:',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_LEAD_SOURCE' => 'Liidin lähde:',
  'LBL_LIST_ACCEPT_STATUS' => 'Hyväksy tila',
  'LBL_LIST_ACCOUNT_NAME' => 'Asiakas',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktit',
  'LBL_LIST_CONTACT_ROLE' => 'Rooli',
  'LBL_LIST_EMAIL_ADDRESS' => 'Sähköposti',
  'LBL_LIST_FIRST_NAME' => 'Etunimi',
  'LBL_LIST_FORM_TITLE' => 'Käyttäjät',
  'LBL_VIEW_FORM_TITLE' => 'Kontaktinäkymä',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Muu sähköposti',
  'LBL_LIST_PHONE' => 'Puhelin',
  'LBL_LIST_TITLE' => 'Asema',
  'LBL_MOBILE_PHONE' => 'Matkapuhelin:',
  'LBL_MODIFIED' => 'Muokannut: ',
  'LBL_MODULE_NAME' => 'Kontaktit',
  'LBL_MODULE_TITLE' => 'Kontaktit: etusivu',
  'LBL_NAME' => 'Nimi:',
  'LBL_NEW_FORM_TITLE' => 'Uusi kontakti',
  'LBL_NEW_PORTAL_PASSWORD' => 'Portaalin uusi salasana:',
  'LBL_NOTE_SUBJECT' => 'Muistion aihe:',
  'LBL_OFFICE_PHONE' => 'Toimiston puhelin:',
  'LBL_OPP_NAME' => 'Mahdollisuuden nimi:',
  'LBL_OPPORTUNITY_ROLE_ID' => 'Myyntimahdollisuuden roolin ID:',
  'LBL_OPPORTUNITY_ROLE' => 'Myyntimahdollisuuden rooli',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Muu sähköposti:',
  'LBL_OTHER_PHONE' => 'Muu puhelin:',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_PORTAL_ACTIVE' => 'Portaali aktiivinen:',
  'LBL_PORTAL_APP' => 'Portaalisovellut',
  'LBL_PORTAL_INFORMATION' => 'Tietoja portaalista',
  'LBL_PORTAL_NAME' => 'Portaalin nimi:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'Portaalin salasana asetettu:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Ensisijainen osoite Kaupunki:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Ensisijainen osoite Maa:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Ensisijainen osoite Postinumero:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Ensisijainen osoite Lääni:',
  'LBL_PRIMARY_ADDRESS_STREET_2' => 'Ensisijainen katuosoite 2',
  'LBL_PRIMARY_ADDRESS_STREET_3' => 'Ensisijainen katuosoite 3',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Ensisijainen osoite Katuosoite:',
  'LBL_PRIMARY_ADDRESS' => 'Ensisijainen osoite:',
  'LBL_PRODUCTS_TITLE' => 'Tuotteet',
  'LBL_RELATED_CONTACTS_TITLE' => 'Liittyvät kontaktit',
  'LBL_REPORTS_TO_ID' => 'Raportoi tunnukselle',
  'LBL_REPORTS_TO' => 'Raportoi henkilölle:',
  'LBL_SALUTATION' => 'Tervehdys',
  'LBL_SAVE_CONTACT' => 'Tallenna kontakti',
  'LBL_SEARCH_FORM_TITLE' => 'Hae käyttäjä',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Valitse merkityt käyttäjät',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Valitse merkityt käyttäjät',
  'LBL_STATE' => 'Lääni:',
  'LBL_SYNC_CONTACT' => 'Synkronisoi kontaktit:',
  'LBL_TEAM_ID' => 'Tiimi ID:',
  'LBL_TITLE' => 'Asema:',
  'LNK_CONTACT_LIST' => 'Kontaktit',
  'LNK_IMPORT_VCARD' => 'Luo vCard:n avulla',
  'LNK_NEW_ACCOUNT' => 'Uusi asiakas',
  'LNK_NEW_APPOINTMENT' => 'Uusi tapaaminen',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_CASE' => 'Uusi palvelupyyntö',
  'LNK_NEW_CONTACT' => 'Uusi kontakti',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_OPPORTUNITY' => 'Uusi myyntimahdollisuus',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_SELECT_ACCOUNT' => 'Valitse asiakas',
  'MSG_DUPLICATE' => 'Kontaktin luonti voi tuottaa kaksoiskappaleen. Voit joko valita kontaktin alle olevasta listasta tai napsauttaa Luo kontakti -painiketta jatkaaksesi uuden kontakti luontia aikaisemmin syötetyn tiedon pohjalta.',
  'MSG_SHOW_DUPLICATES' => 'Tämän kontaktin luonti saattaa aiheuttaa prospektin kaksoiskappaleen. Voit napsauttaa Peru-painiketta peruuttaaksesi toiminnon tai Luo prospekti -painiketta jatkaaksesi uuden kontakti luontia.',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopioi toissijainen osoite ensisijaiseksi osoitteeksi',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopioi ensisijainen osoite toissijaiseksi osoitteeksi',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tämän tietueen?',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Asiakas tulee luoda ennen myyntimahdollisuutta. Luo uusi asiakas tai käytä olemassa olevaa asiakasta.',
  'NTC_REMOVE_CONFIRMATION' => 'Haluatko poistaa kontaktin tästä palvelupyynnöstä?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Haluatko poistaa tietueen suorana raporttina?',
  'LBL_USER_PASSWORD' => 'Salasana:',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Liidit',
  'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
  'LBL_CASES_SUBPANEL_TITLE' => 'Palvelupyynnöt',
  'LBL_BUGS_SUBPANEL_TITLE' => 'Bugit',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projektit',
  'LBL_COPY_ADDRESS_CHECKED' => 'Kopioi osoite valittuihin kontakteihin',
  'LBL_TARGET_OF_CAMPAIGNS' => 'Kampanjat (kohde) :',
  'LBL_CAMPAIGNS' => 'Kampanjat',
  'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE' => 'Kampanjaloki',
  'LBL_LIST_CITY' => 'Kaupunki',
  'LBL_LIST_STATE' => 'Lääni',
  'LBL_HOMEPAGE_TITLE' => 'Omat kontaktit',
);


?>