<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Projektit',
  'LBL_MODULE_TITLE' => 'Projektit: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae projekti',
  'LBL_LIST_FORM_TITLE' => 'Projektit',
  'LBL_HISTORY_TITLE' => 'Historia',
  'LBL_ID' => 'Relaation Id',
  'LBL_DATE_ENTERED' => 'Kirjauspäivä',
  'LBL_DATE_MODIFIED' => 'Muokkauspäivä',
  'LBL_ASSIGNED_USER_ID' => 'Vastuuhenkilö:',
  'LBL_MODIFIED_USER_ID' => 'Muokattu käyttäjätunnus:',
  'LBL_CREATED_BY' => 'Luonut: ',
  'LBL_TEAM_ID' => 'Tiimi:',
  'LBL_NAME' => 'Nimi:',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_DELETED' => 'Poistettu',
  'LBL_TOTAL_ESTIMATED_EFFORT' => 'Arvioidut työtunnit:',
  'LBL_TOTAL_ACTUAL_EFFORT' => 'Toteutuneet työtunnit:',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_ASSIGNED_USER_ID' => 'Vastuuhenkilö',
  'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Arvioidut työtunnit',
  'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Toteutuneet työtunnit',
  'LBL_PROJECT_SUBPANEL_TITLE' => 'Projektit',
  'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Projektin tehtävät',
  'LBL_CONTACT_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Asiakkaat',
  'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
  'LBL_QUOTE_SUBPANEL_TITLE' => 'Tarjoukset',
  'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Haluatko poistaa kontaktin tästä projektista?',
  'LNK_NEW_PROJECT' => 'Uusi projekti',
  'LNK_PROJECT_LIST' => 'Projektilista',
  'LNK_NEW_PROJECT_TASK' => 'Uusi tehtävä',
  'LNK_PROJECT_TASK_LIST' => 'Projektin tehtävät',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_ACTIVITIES_TITLE' => 'Aktiviteetit',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_QUICK_NEW_PROJECT' => 'Uusi projekti',
  'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Projektin tehtävät',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Asiakkaat',
  'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
);


?>