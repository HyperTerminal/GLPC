<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'DESC_MODULES_INSTALLED' => 'Seuraavat moduulit on asennettu:',
  'DESC_MODULES_QUEUED' => 'Seuraavat moduulit ovat valmiita asennettavaksi:',
  'ERR_UW_CANNOT_DETERMINE_GROUP' => 'Ryhmää ei voida määritellä',
  'ERR_UW_CANNOT_DETERMINE_USER' => 'Omistajaa ei voida määritellä',
  'ERR_UW_CONFIG_WRITE' => 'Virhe päivitettäessä config.php-tiedostoa uudella versiotiedolla.',
  'ERR_UW_CONFIG' => 'Poista config.php tiedoston kirjoitussuojaus ja lataa tämä sivu uudelleen.',
  'ERR_UW_DIR_NOT_WRITABLE' => 'Hakemisto on kirjoitussuojattu',
  'ERR_UW_FILE_NOT_COPIED' => 'Tiedostoa ei kopioitu',
  'ERR_UW_FILE_NOT_DELETED' => 'Ongelma asennuspaketin poistamisessa ',
  'ERR_UW_FILE_NOT_READABLE' => 'Tiedostoa ei voida lukea.',
  'ERR_UW_FILE_NOT_WRITABLE' => 'Tiedostoa ei voida siirtää tai se on kirjoitussuojattu',
  'ERR_UW_FLAVOR_2' => 'Päivityspaketin versio: ',
  'ERR_UW_FLAVOR' => 'SugarCRM järjestelmän versio: ',
  'ERR_UW_LOG_FILE_UNWRITABLE' => './upgradeWizard.log tiedostoa ei voida luoda tai se on kirjoitussuojattu. Tarkista SugarCRM hakemiston käyttöoikeudet.',
  'ERR_UW_MBSTRING_FUNC_OVERLOAD' => 'mbstring.func_overload set to a value higher than 1.  Please change this in your php.ini and restart the web server.',
  'ERR_UW_MYSQL_VERSION' => 'SugarCRM vaatii MySQL version 4.1.2 tai uudemman. Löydetty: ',
  'ERR_UW_NO_FILE_UPLOADED' => 'Valitse tiedosto ja yritä uudelleen.<br>',
  'ERR_UW_NO_FILES' => 'Virhe havaittu, tarkistettavia tiedostoja ei löydetty.',
  'ERR_UW_NO_MANIFEST' => 'zip-tiedosto ei sisältänyt manifest.php tiedostoa. Ei voida jatkaa.',
  'ERR_UW_NO_VIEW' => 'Virheellinen näkymä määritelty.',
  'ERR_UW_NO_VIEW2' => 'Näkymää ei määritelty, siirry ylläpitoliittymän kautta tälle sivulle.',
  'ERR_UW_NOT_VALID_UPLOAD' => 'Virheellinen tiedosto.',
  'ERR_UW_NO_CREATE_TMP_DIR' => 'temp hakemistoa ei voida luoda. Tarkista tiedosto-oikeudet.',
  'ERR_UW_ONLY_PATCHES' => 'Voit ladata vain patch-paketteja tällä sivulla.',
  'ERR_UW_PREFLIGHT_ERRORS' => 'Virheitä havaittu esitarkistuksesen aikana',
  'ERR_UW_UPLOAD_ERR' => 'Virhe tiedostoa palvelimelle vietäessä, yritä uudelleen.<br>',
  'ERR_UW_VERSION' => 'SugarCRM versio: ',
  'ERR_UW_WRONG_TYPE' => 'Tämä sivu ei ole käyttöä varten ',
  'ERR_UW_PHP_FILE_ERRORS' => 
  array (
    1 => 'Palvelimelle ladattavan tiedoston koko ylittää php.ini-tiedostossa määritellyn upload_max_filesize -asetuksen.',
    2 => 'Palvelimelle ladattavan tiedoston koko ylittää html-lomakkeella määritellyn MAX_FILE_SIZE -asetuksen.',
    3 => 'Tiedosto vietiin palvelimelle vain osittain.',
    4 => 'Tiedostoa ei viety palvelimelle.',
    5 => 'Tuntematon virhe.',
    6 => 'Väliaikaisille tiedostoille tarkoitettu hakemisto puuttuu.',
    7 => 'Tiedoston kirjoittaminen epäonnistui.',
    8 => 'Tiedoston lataus palvelimelle keskeytettiin by extension.',
  ),
  'LBL_BUTTON_BACK' => 'Takaisin',
  'LBL_BUTTON_CANCEL' => 'Peru',
  'LBL_BUTTON_DELETE' => 'Poista asennuspaketti',
  'LBL_BUTTON_DONE' => 'Valmis',
  'LBL_BUTTON_INSTALL' => 'Esitarkistuspäivitys',
  'LBL_BUTTON_NEXT' => 'Seuraava',
  'LBL_BUTTON_RECHECK' => 'Tarkista uudelleen',
  'LBL_UPLOAD_UPGRADE' => 'Vie palvelimelle päivitystiedosto: ',
  'LBL_UW_BACKUP_FILES_EXIST_TITLE' => 'Tiedoston varmuuskopio',
  'LBL_UW_BACKUP_FILES_EXIST' => 'Päivityksen varmuuskopiot löytyvät paikasta',
  'LBL_UW_BACKUP' => 'Tiedoston varmuuskopio',
  'LBL_UW_CANCEL_DESC' => 'Päivitysvelhon toiminta peruttu. Kaikki väliaikaiset tiedostot sekä palvelimelle viety zip-tiedosto on poistettu.<br><br>Napsauta \\"Seuraava\\" aloittaaksesi päivitysvelhon alusta.',
  'LBL_UW_CHARSET_SCHEMA_CHANGE' => 'Merkistömuutokset',
  'LBL_UW_CHECK_ALL' => 'Valitse kaikki',
  'LBL_UW_CHECKLIST' => 'Päivityksen vaiheet',
  'LBL_UW_COMMIT_ADD_TASK_DESC_1' => 'Korvattujen tiedostojen varmuuskopio löytyy seuraavasta hakemistosta:',
  'LBL_UW_COMMIT_ADD_TASK_DESC_2' => 'Tee muutokset käsin seuraaviin tiedostoihin:',
  'LBL_UW_COMMIT_ADD_TASK_NAME' => 'Päivityksen tila: tee muutokset käsin',
  'LBL_UW_COMMIT_ADD_TASK_OVERVIEW' => 'Käytä haluamaasi menetelmää tiedoston välisten erojen löytämiseksi sekä muutosten tekemiseksi. Ennen tätä SugarCRM asennus ei ole valmis.',
  'LBL_UW_COMPLETE' => 'Valmis',
  'LBL_UW_COMPLIANCE_ALL_OK' => 'Kaikki järjestelmävaatimukset täytetään',
  'LBL_UW_COMPLIANCE_CALLTIME' => 'PHP-asetus: Call Time Pass By Reference',
  'LBL_UW_COMPLIANCE_CURL' => 'cURL-moduuli',
  'LBL_UW_COMPLIANCE_IMAP' => 'IMAP-moduuli',
  'LBL_UW_COMPLIANCE_MBSTRING' => 'MBStrings-moduuli',
  'LBL_UW_COMPLIANCE_MBSTRING_FUNC_OVERLOAD' => 'MBStrings mbstring.func_overload Parameter',
  'LBL_UW_COMPLIANCE_MEMORY' => 'PHP-asetus: Memory Limit',
  'LBL_UW_COMPLIANCE_MSSQL_MAGIC_QUOTES' => 'MS SQL Server & PHP Magic Quotes GPC',
  'LBL_UW_COMPLIANCE_MYSQL' => 'Minimi MySQL-versiovaatimus',
  'LBL_UW_COMPLIANCE_PHP_INI' => 'php.ini -tiedoston sijainti',
  'LBL_UW_COMPLIANCE_PHP_VERSION' => 'Minimi PHP-versiovaatimus',
  'LBL_UW_COMPLIANCE_SAFEMODE' => 'PHP-asetus: Safe Mode',
  'LBL_UW_COMPLIANCE_TITLE' => 'Palvelinasetusten tarkistus',
  'LBL_UW_COMPLIANCE_TITLE2' => 'Havaitut asetukset',
  'LBL_UW_COMPLIANCE_XML' => 'XML Parsing',
  'LBL_UW_COPIED_FILES_TITLE' => 'Tiedostot kopioitu',
  'LBL_UW_CUSTOM_TABLE_SCHEMA_CHANGE' => 'Muokatun taulun rakenteen muutokset',
  'LBL_UW_DB_CHOICE1' => 'Päivitysvelho suorittaa SQL-skriptin',
  'LBL_UW_DB_CHOICE2' => 'Käsin suoritettavat SQL-komennot',
  'LBL_UW_DB_INSERT_FAILED' => 'INSERT epäonnistui - vertailtavat tulokset eroavat',
  'LBL_UW_DB_ISSUES_PERMS' => 'Tietokannan oikeudet',
  'LBL_UW_DB_ISSUES' => 'Tietokanta-asetukset',
  'LBL_UW_DB_METHOD' => 'Tietokannan päivitystapa',
  'LBL_UW_DB_NO_ADD_COLUMN' => 'ALTER TABLE [table] ADD COLUMN [column]',
  'LBL_UW_DB_NO_CHANGE_COLUMN' => 'ALTER TABLE [table] CHANGE COLUMN [column]',
  'LBL_UW_DB_NO_CREATE' => 'CREATE TABLE [table]',
  'LBL_UW_DB_NO_DELETE' => 'DELETE FROM [table]',
  'LBL_UW_DB_NO_DROP_COLUMN' => 'ALTER TABLE [table] DROP COLUMN [column]',
  'LBL_UW_DB_NO_DROP_TABLE' => 'DROP TABLE [table]',
  'LBL_UW_DB_NO_ERRORS' => 'Kaikki oikeudet käytettävissä',
  'LBL_UW_DB_NO_INSERT' => 'INSERT INTO [table]',
  'LBL_UW_DB_NO_SELECT' => 'SELECT [x] FROM [table]',
  'LBL_UW_DB_NO_UPDATE' => 'UPDATE [table]',
  'LBL_UW_DB_PERMS' => 'Tarvittavat oikeudet',
  'LBL_UW_DESC_MODULES_INSTALLED' => 'Seuraavat päivitykset on asennettu:',
  'LBL_UW_END_DESC' => 'Onnittelut, ohjelmisto on päivitetty.',
  'LBL_UW_END_DESC2' => 'Jos olet valinnut tekeväsi käsin vaiheet kuten tiedostojen yhdistämisen tai SQL-komentojen suorittamisen, tee se nyt. Järjestelmä on epävakaassa tilassa ennen kuin ne on tehty.',
  'LBL_UW_END_LOGOUT' => 'Kirjaudu ulos ohjelmistosto, jos aiot tehdä lisäpäivityksiä.',
  'LBL_UW_END_LOGOUT2' => 'Kirjaudu ulos',
  'LBL_UW_REPAIR_INDEX' => 'Paranna tietokannan suorituskykyä ajamalla <a href="index.php?module=Administration&action=RepairIndex" target="_blank">Korjaa indeksit</a> skripti.',
  'LBL_UW_FILE_DELETED' => ' on poistettu.<br>',
  'LBL_UW_FILE_GROUP' => 'Ryhmä',
  'LBL_UW_FILE_ISSUES_PERMS' => 'Tiedosto-oikeudet',
  'LBL_UW_FILE_ISSUES' => 'Tiedosto-ongelmat',
  'LBL_UW_FILE_NEEDS_DIFF' => 'Tiedosto vaatii käsin tehtävää vertailua ja muutosten tekemisen käsin',
  'LBL_UW_FILE_NO_ERRORS' => '<b>Tiedostoja ei ole kirjoitussuojattu</b>',
  'LBL_UW_FILE_OWNER' => 'Omistaja',
  'LBL_UW_FILE_PERMS' => 'Käyttöoikeudet',
  'LBL_UW_FILE_UPLOADED' => ' on viety palvelimelle',
  'LBL_UW_FILE' => 'Tiedosto',
  'LBL_UW_FILES_QUEUED' => 'Seuraavat päitykset ovat valmiita asennettavaksi:',
  'LBL_UW_FILES_REMOVED' => 'Seuraavat tiedostot poistetaan järjestelmästä:<br>',
  'LBL_UW_FROZEN' => 'Vaaditut kohdat tulee suorittaa loppuun ennen kuin voidaan jatkaa.',
  'LBL_UW_HIDE_DETAILS' => 'Piilota tarkemmat tiedot',
  'LBL_UW_IN_PROGRESS' => 'Käynnissä',
  'LBL_UW_INCLUDING' => 'Mukaan lukien',
  'LBL_UW_INCOMPLETE' => 'Epätäydellinen',
  'LBL_UW_INSTALL' => 'Tiedostojen asennus',
  'LBL_UW_MANUAL_MERGE' => 'Tiedostojen yhdistäminen',
  'LBL_UW_MODULE_READY_UNINSTALL' => 'Moduuli voidaan poistaa.  Napsauta \\"Commit\\" jatkaaksesi.<br>',
  'LBL_UW_MODULE_READY' => 'Moduuli on jo asennettu. Napsauta \\"Commit\\" jatkaaksesti asennusta.',
  'LBL_UW_NO_INSTALLED_UPGRADES' => 'Tallennettuja päivityksiä ei havaittu.',
  'LBL_UW_NONE' => 'ei mitään',
  'LBL_UW_NOT_AVAILABLE' => 'Ei käytettävissä',
  'LBL_UW_OVERWRITE_DESC' => 'Kaikki muutetut tiedostot korvataan - mukaan lukien kaikki tehdyt koodi- ja sivupohjamuutokset. Haluatko varmasti jatkaa?',
  'LBL_UW_OVERWRITE_FILES_CHOICE1' => 'Ylikirjoita kaikki tiedostot',
  'LBL_UW_OVERWRITE_FILES_CHOICE2' => 'Tiedostojen yhdistäminen käsin - säilytä kaikki',
  'LBL_UW_OVERWRITE_FILES' => 'Yhdistämistapa',
  'LBL_UW_PATCH_READY' => 'Patch-tiedoston asentamista voidaan jatkaa. Napsuta alla olevaa \\"Commit\\" painiketta suorittaaksesi päivityksen loppuun.',
  'LBL_UW_PATCH_READY2' => '<h2>Huomaa: muokattuja ulkoasutiedostoja löydetty</h2><br />Seuraavissa tiedostoissa on uusia kenttiä tai niiden ulkoasua on muokattu Studion kautta. Asentamasi patch-paketti sisältää myös muutoksia tiedostoihin. Jokaisen <u>tiedoston</u> kohdalla voit:<br><ul><li>[<b>Oletus</b>] Säilyttää nykyisen version jättämällä valintalaatikon tyhjäksi. Path-paketin muutokset sivuutetaan.</li>tai<li>Hyväksyä päivitettyjen tiedostojen asentaminen ja korvaamalla nykyiset tiedostosi. Tekemäsi muutokset joudutaan tekemään uudestaan Studion kautta.</li></ul>',
  'LBL_UW_PREFLIGHT_ADD_TASK' => 'Luo uusi tehtävä muistuttamaan käsin tehtävästä yhdistämisestä?',
  'LBL_UW_PREFLIGHT_COMPLETE' => 'Ennen asennusta tehtävä testi',
  'LBL_UW_PREFLIGHT_DIFF' => 'Eroavat ',
  'LBL_UW_PREFLIGHT_EMAIL_REMINDER' => 'Lähetä sähköpostia itsellesi muistuttaaksesi käsin tehtävästä tiedostojen yhdistämisestä?',
  'LBL_UW_PREFLIGHT_FILES_DESC' => 'Alla listattuja tiedostoja on muokattu. Poista valinta tiedostojen kohdalta, jotka vaativat käsin tehtävän yhdistämisen. <i>Jos tiedoston kohdalla on huomattu ulkoasumuutoksia, on valinta automaattisesti poistettu; valitse kaikki tiedostot, jotka korvataan.',
  'LBL_UW_PREFLIGHT_NO_DIFFS' => 'Käsin tehtävät tiedostojen yhdistämiset eivät ole tarpeeen.',
  'LBL_UW_PREFLIGHT_NOT_NEEDED' => 'Ei tarpeen.',
  'LBL_UW_PREFLIGHT_PRESERVE_FILES' => 'Automaattisesti säilytetyt tiedostot:',
  'LBL_UW_PREFLIGHT_TESTS_PASSED' => 'Kaikki ennen asennusta tehtävät testit on läpäisty. Napsauta \\"Next\\" tehdäksesi muutokset.',
  'LBL_UW_PREFLIGHT_TOGGLE_ALL' => 'Vaihda kaikki valinnat',
  'LBL_UW_REBUILD_TITLE' => 'Nouda tulokset uudelleen',
  'LBL_UW_SCHEMA_CHANGE' => 'Tietokantarakenteen muutokset',
  'LBL_UW_SHOW_COMPLIANCE' => 'Näytä havaitut asetukset',
  'LBL_UW_SHOW_DB_PERMS' => 'Näytä puuttuvat tietokantaoikeudet',
  'LBL_UW_SHOW_DETAILS' => 'Näytä tarkemmat tiedot',
  'LBL_UW_SHOW_DIFFS' => 'Näytä tiedostot, jotka vaativat yhdistämisen käsin',
  'LBL_UW_SHOW_NW_FILES' => 'Näytä tiedostot, joissa virheelliset käyttöoikeudet',
  'LBL_UW_SHOW_SCHEMA' => 'Näytä tietokannan muutosskripti',
  'LBL_UW_SHOW_SQL_ERRORS' => 'Näytä virheelliset kyselyt',
  'LBL_UW_SHOW' => 'Näytä',
  'LBL_UW_SKIPPED_FILES_TITLE' => 'Sivuutetut tiedostot',
  'LBL_UW_SKIPPING_FILE_OVERWRITE' => 'Tiedostojen korvaaminen sivuutetaan - käsin tehtävä yhdistely valittu.',
  'LBL_UW_SQL_RUN' => 'Tarkista milloin SQL on suoritettu käsin',
  'LBL_UW_START_DESC' => 'Tervetuloa SugarCRM päivitysvelhoon. Päivitysvelho auttaa ylläpitäjiä päivittämään SugarCRM:n. Seuraa annettuja ohjeita huolellisesti.',
  'LBL_UW_START_DESC2' => 'Suosittelemme, että päivitys tehdään tuotantopalvelimen kopiolle mahdollisten virheiden selvittämiseksi. Varmuuskopioi ennen päivitystä tietokanta ja järjestelmätiedostot (kaikki tiedostot SugarCRM kansiossa).',
  'LBL_UW_START_UPGRADED_UW_DESC' => 'Uusi päivitysvelho jatkaa nyt päivitysprosessia. Tämä päivitys on vain testitarkoituksiin. <b>Älä asenna tätä päivitystä tuotantopalvelimelle.</b>',
  'LBL_UW_START_UPGRADED_UW_TITLE' => 'Tervetuloa uuteen päivitysvelhoon',
  'LBL_UW_SYSTEM_CHECK_CHECKING' => 'Tarkistetaan, odota hetki, toimenpide voi viedä 30 sekuntia.',
  'LBL_UW_SYSTEM_CHECK_FILE_CHECK_START' => 'Etsitään kaikki tarkistettavat tiedostot.',
  'LBL_UW_SYSTEM_CHECK_FILES' => 'Tiedostot',
  'LBL_UW_SYSTEM_CHECK_FOUND' => 'Löydetty',
  'LBL_UW_TITLE_CANCEL' => 'Peru',
  'LBL_UW_TITLE_COMMIT' => 'Suorita päivitys',
  'LBL_UW_TITLE_END' => 'Yhteenveto',
  'LBL_UW_TITLE_PREFLIGHT' => 'Ennen asennusta tehtävä tarkistus',
  'LBL_UW_TITLE_START' => 'Aloita',
  'LBL_UW_TITLE_SYSTEM_CHECK' => 'Järjestelmän tarkistukset',
  'LBL_UW_TITLE_UPLOAD' => 'Vie päivitystiedosto palvelimelle',
  'LBL_UW_TITLE' => 'Päivitysvelho',
  'LBL_UW_UNINSTALL' => 'Poista asennus',
);


?>