<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Uusi kontakti',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_EMAIL_ADDRESS' => 'Sähköposti:',
  'LBL_PIPELINE_FORM_TITLE' => 'Oma myyntiennuste',
  'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'Kampanjan ROI',
  'LNK_NEW_CONTACT' => 'Uusi kontakti',
  'LNK_NEW_ACCOUNT' => 'Uusi asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Uusi myyntimahdollisuus',
  'LNK_NEW_LEAD' => 'Uusi liidi',
  'LNK_NEW_CASE' => 'Uusi palvelupyyntö',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_COMPOSE_EMAIL' => 'Uusi sähköposti',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_NEW_BUG' => 'Raportoi bugi',
  'LBL_ADD_BUSINESSCARD' => 'Luo käyntikortin avulla',
  'ERR_ONE_CHAR' => 'Anna vähintään yksi kirjain tai numero hakua varten...',
  'LBL_OPEN_TASKS' => 'Omat avoimet tehtävät',
  'LBL_SEARCH_RESULTS' => 'Hakutulokset',
  'LBL_SEARCH_RESULTS_IN' => 'in',
  'LNK_NEW_SEND_EMAIL' => 'Uusi sähköposti',
  'LBL_NO_RESULTS_IN_MODULE' => '-- ei tuloksia --',
  'LBL_NO_RESULTS' => '<h2>Hakutuloksia ei löydetty, yritä uudelleen.</h2><br>',
  'LBL_NO_RESULTS_TIPS' => '<h3>Hakuvirheitä:</h3><ul><li>Varmista että olet valinnut halutut kategoriat alla.</li><li>Laajenna hakukriteereitä.</li><li>Jos et edelleenkään saa hakutuloksia, kokeile moduulin edistynyt haku -toimintoa.</li></ul>',
  'LBL_RELOAD_PAGE' => '<a href="javascript: window.location.reload()">Päivitä selainikkuna</a> käyttääksesi dashletia.',
  // dashlet search fields
  'LBL_ADD_DASHLETS' => 'Lisää Dashlet',
  'LBL_CLOSE_DASHLETS' => 'Sulje',
  'LBL_OPTIONS' => 'Valinnat',
  'LBL_TODAY' => 'Tänään',
  'LBL_YESTERDAY' => 'Eilen',
  'LBL_TOMORROW' => 'Huomenna',
  'LBL_LAST_WEEK' => 'Viime viikolla',
  'LBL_NEXT_WEEK' => 'Seuraava viikko',
  'LBL_LAST_7_DAYS' => 'Edelliset 7 päivää',
  'LBL_NEXT_7_DAYS' => 'Seuraavat 7 päivää',
  'LBL_LAST_MONTH' => 'Edellinen kuukausi',
  'LBL_NEXT_MONTH' => 'Seuraava kuukausi',
  'LBL_LAST_QUARTER' => 'Edellinen vuosineljännes',
  'LBL_THIS_QUARTER' => 'Tämä vuosineljännes',
  'LBL_LAST_YEAR' => 'Edellinen vuosi',
  'LBL_NEXT_YEAR' => 'Seuraava vuosi',
  'LBL_THIS_MONTH' => 'Tämä kuukausi',
  'LBL_THIS_YEAR' => 'Tämä vuosi',
  'LBL_LAST_30_DAYS' => 'Edelliset 30 päivää',
  'LBL_NEXT_30_DAYS' => 'Seuraavat 30 päivää',
  'dashlet_categories_dom' => 
  array (
  // Dashlet Categories
    'Module Views' => 'Moduulinäkymät',
    'Portal' => 'Portaali',
    'Charts' => 'Kaaviot',
    'Tools' => 'Apuohjelmat',
    'Miscellaneous' => 'Sekalaista',
  ),
  'LBL_MAX_DASHLETS_REACHED' => 'Ylläpitäjän määrittelemä suurin sallittu dashlet-määrä on saavutettu. Poista jokin dashlet ennen kuin lisäät seuraavan.',
  'LBL_ADDING_DASHLET' => 'Lisätään Dashlet ...',
  'LBL_ADDED_DASHLET' => 'Dashlet lisätty',
  'LBL_REMOVE_DASHLET_CONFIRM' => 'Haluatko varmasti poistaa Dashletin?',
  'LBL_REMOVING_DASHLET' => 'Poistetaan Dashlet ...',
  'LBL_REMOVED_DASHLET' => 'Dashlet poistettu',
  'LBL_DASHLET_CONFIGURE_GENERAL' => 'Yleistä',
  'LBL_DASHLET_CONFIGURE_FILTERS' => 'Suodattimet',
  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Vain omat nimikkeet',
  'LBL_DASHLET_CONFIGURE_TITLE' => 'Otsikko',
  'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Näytä rivit',
//  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'My Items Only',
  'LBL_TRAINING_TITLE' => 'Koulutus',
);


?>