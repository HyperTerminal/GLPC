<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
//END DON'T CONVERT
  'LBL_MODULE_NAME' => 'RSS-syötteet',
  'LBL_MODULE_ID' => 'Syötteet',
  'LBL_MODULE_TITLE' => 'RSS-syötteet: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae käyttäjä',
  'LBL_LIST_FORM_TITLE' => 'Käyttäjät',
  'LBL_MY_LIST_FORM_TITLE' => 'Omat RSS-syötteet',
  'LBL_NEW_FORM_TITLE' => 'Uusi RSS-syöte',
  'NTC_DELETE_CONFIRMATION' => 'Haluatko poistaa tämän tietueen?',
  'ERR_DELETE_RECORD' => 'Poista tietue antamalla tietueen numero.',
  'LNK_NEW_FEED' => 'Uusi RSS-syöte',
  'LNK_FEED_LIST' => 'Kaikki RSS -syötteet',
  'LNK_MY_FEED_LIST' => 'Omat RSS-syötteet',
  'LBL_TITLE' => 'Asema:',
  'LBL_RSS_URL' => 'RSS URL',
  'LBL_ONLY_MY' => 'Vain omat linkit',
  'LBL_VISIT_WEBSITE' => 'siirry sivustolle',
  'LBL_LAST_UPDATED' => 'Päivitetty',
  'LBL_DELETE_FAVORITES' => 'Poista suosikit-listasta',
  'LBL_DELETE_FAV_BUTTON_TITLE' => 'Poista suosikit-listasta [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' => 'Poista suosikit-listasta',
  'LBL_ADD_FAV_BUTTON_TITLE' => 'Lisää suosikkeini [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' => '[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' => 'Lisää suosikkeihin',
  'LBL_MOVE_UP' => 'Siirrä ylös',
  'LBL_MOVE_DOWN' => 'Siirrä alas',
  'LBL_FEED_NOT_AVAILABLE' => 'Syötettä ei saatavilla',
  'LBL_REFRESH_CACHE' => 'Päivitä välimuisti napsauttamalla tässä',
  'LBL_TILE' => 'Asema',
  'LBL_URL' => 'URL',
  'LBL_DESCRIPTION' => 'Kuvaus',
);


?>