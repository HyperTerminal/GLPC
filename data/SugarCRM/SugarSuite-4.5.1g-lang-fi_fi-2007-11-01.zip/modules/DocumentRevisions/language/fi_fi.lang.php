<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
	//module
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/
	//vardef labels

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Käyttäjät',
  'LNK_NEW_DOCUMENT' => 'Uusi dokumentti',
  'LNK_DOCUMENT_LIST' => 'Dokumenttilista',
  'LBL_REVISION_NAME' => 'Versionumero',
  'LBL_FILENAME' => 'Liitetiedosto:',
  'LBL_MIME' => 'Mime-tyyppi',
  'LBL_REVISION' => 'Versio',
  'LBL_DOCUMENT' => 'Liittyvä dokumentti',
  'LBL_LATEST_REVISION' => 'Viimeisin versio',
  'LBL_CHANGE_LOG' => 'Muutosloki',
  'LBL_ACTIVE_DATE' => 'Julkaisupäivä',
  'LBL_EXPIRATION_DATE' => 'Vanhentumispäivä',
  'LBL_FILE_EXTENSION' => 'Tiedoston tarkennin',
  'LBL_DET_CREATED_BY' => 'Luonut:',
	//document revisions.
  'LBL_DET_DATE_CREATED' => 'Luontipäivä:',
  'LBL_DOC_NAME' => 'Dokumentin nimi:',
  'LBL_DOC_VERSION' => 'Versio:',
  'LBL_REV_LIST_REVISION' => 'Versiot',
  'LBL_REV_LIST_ENTERED' => 'Luontipäivä',
  'LBL_REV_LIST_CREATED' => 'Luonut',
  'LBL_REV_LIST_LOG' => 'Muutosloki',
  'LBL_REV_LIST_FILENAME' => 'Tiedostonimi',
  'LBL_CURRENT_DOC_VERSION' => 'Nykyinen versio:',
	//error messages
  'LBL_SEARCH_FORM_TITLE' => 'Hae käyttäjä',
  'ERR_FILENAME' => 'Tiedostonimi',
  'ERR_DOC_VERSION' => 'Dokumentin versio',
  'ERR_DELETE_CONFIRM' => 'Haluatko poistaa dokumentin version?',
  'ERR_DELETE_LATEST_VERSION' => 'Et voi poistaa dokumentin viimeisintä versiota.',
);


?>