<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Työntekijät',
  'LBL_MODULE_TITLE' => 'Työntekijät: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae työntekijä',
  'LBL_LIST_FORM_TITLE' => 'Työntekijät',
  'LBL_NEW_FORM_TITLE' => 'Uusi työntekijä',
  'LBL_EMPLOYEE' => 'Työntekijät:',
  'LBL_LOGIN' => 'Kirjaudu',
  'LBL_RESET_PREFERENCES' => 'Palauta oletusasetukset',
  'LBL_TIME_FORMAT' => 'Ajan muoto:',
  'LBL_DATE_FORMAT' => 'Päiväyksen muoto:',
  'LBL_TIMEZONE' => 'Aika:',
  'LBL_CURRENCY' => 'Valuutta:',
  'LBL_LIST_NAME' => 'Nimi',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_LIST_EMPLOYEE_NAME' => 'Työntekijän nimi',
  'LBL_LIST_DEPARTMENT' => 'Osasto',
  'LBL_LIST_REPORTS_TO_NAME' => 'Raportoi henkilölle',
  'LBL_LIST_EMAIL' => 'Sähköposti',
  'LBL_LIST_PRIMARY_PHONE' => 'Ensisijainen puhelin',
  'LBL_LIST_USER_NAME' => 'Käyttäjätunnus',
  'LBL_LIST_ADMIN' => 'Ylläpito',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Uusi työntekijä [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Uusi työntekijä',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Virhe:',
  'LBL_PASSWORD' => 'Salasana:',
  'LBL_EMPLOYEE_NAME' => 'Työntekijän nimi:',
  'LBL_USER_NAME' => 'Käyttäjätunnus:',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_EMPLOYEE_SETTINGS' => 'Työntekijän asetukset',
  'LBL_THEME' => 'Teema:',
  'LBL_LANGUAGE' => 'Kieli:',
  'LBL_ADMIN' => 'Ylläpitäjä:',
  'LBL_EMPLOYEE_INFORMATION' => 'Työntekijän tiedot',
  'LBL_OFFICE_PHONE' => 'Toimiston puhelin:',
  'LBL_REPORTS_TO' => 'Raportoi henkilölle:',
  'LBL_OTHER_PHONE' => 'Muu puhelin:',
  'LBL_OTHER_EMAIL' => 'Muu sähköposti:',
  'LBL_NOTES' => 'Lisätietoa:',
  'LBL_DEPARTMENT' => 'Osasto:',
  'LBL_TITLE' => 'Asema:',
  'LBL_ANY_PHONE' => 'Muu puhelin:',
  'LBL_ANY_EMAIL' => 'Muu sähköposti:',
  'LBL_ADDRESS' => 'Osoite:',
  'LBL_CITY' => 'Kaupunki:',
  'LBL_STATE' => 'Lääni:',
  'LBL_POSTAL_CODE' => 'Postinumero:',
  'LBL_COUNTRY' => 'Maa:',
  'LBL_NAME' => 'Nimi:',
  'LBL_MOBILE_PHONE' => 'Matkapuhelin:',
  'LBL_OTHER' => 'Muuta:',
  'LBL_FAX' => 'Faksi:',
  'LBL_EMAIL' => 'Sähköposti:',
  'LBL_HOME_PHONE' => 'Kotipuhelin:',
  'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
  'LBL_EMPLOYEE_STATUS' => 'Työntekijän tila:',
  'LBL_PRIMARY_ADDRESS' => 'Ensisijainen osoite:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Uusi käyttäjä [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Uusi käyttäjä',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Mieliväri:',
  'LBL_MESSENGER_ID' => 'IM nimi:',
  'LBL_MESSENGER_TYPE' => 'IM tyyppi:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Työntekijän nimi ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' on jo olemassa. Kaksoiskappaleita ei sallita. Muuta työntekijän nimeä siten että siitä tulee yksilöllinen.',
  'ERR_LAST_ADMIN_1' => 'Käyttäjätunnus "',
  'ERR_LAST_ADMIN_2' => ' on viimeinen ylläpitäjä (admin). Ainakin yhden käyttäjän tulee olla ylläpitäjä.',
  'LNK_NEW_EMPLOYEE' => 'Uusi työntekijä',
  'LNK_EMPLOYEE_LIST' => 'Työntekijät',
  'ERR_DELETE_RECORD' => 'Tietuenumero tulee määritellä jotta voit poistaa tilin.',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Tila',
  'LBL_SUGAR_LOGIN' => 'On Sugar-käyttäjä',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Lähetä viesti annetuista tehtävistä',
  'LBL_IS_ADMIN' => 'On ylläpitäjä',
  'LBL_GROUP' => 'Ryhmäkäyttäjä',
  'LBL_PORTAL_ONLY' => 'Vain portaalikäyttäjä',
);


?>