<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * : 
 * : fi_fi.lang.php,version 1.11.2007 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 4.5.1g
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2007 Markku Suominen / Antamis Finland Oy. Some Rights Reserved.
 * Lisenssi : Tämä teos on lisensoitu Creative Commons Nimi mainittava-Ei kaupalliseen käyttöön- 
 * Sama lisenssi -lisenssillä. Nähdäksesi lisenssin vieraile osoitteessa 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/
 *
 * License: Creative Commons Attribution-NonCommercial-ShareAlike
 * More info: http://creativecommons.org/licenses/by-nc-sa/1.0/fi/deed.en_GB
 * 
 * Sinulla on vapaus kopioida, levittää ja esittää teosta sekä
 * valmistaa jälkiperäisiä teoksia seuraavilla ehdoilla:
 *
 * - Nimi mainittava. Teoksen tekijä on ilmoitettava siten kuin tekijä tai teoksen lisensoija on sen määrännyt.
 * Tekijän määräys: Author, Copyright, Web, Lisenssi ja License -rivien tiedot tulee näyttää kokonaisuudessaan 
 * jokaisen jälkiperäisen teoksen alussa siinä muodossa kuin ne tiedostossa esitetään.
 * - Ei-kaupalliseen käyttöön. Teosta ei saa käyttää kaupallisiin tarkoituksiin.
 * - Sama lisenssi. Jos teet muutoksia tai käytät teosta oman teoksesi pohjana, tulee syntynyt 
 * teos jakaa lisenssillä, joka on identtinen alkuperäisen teoksen lisenssin kanssa.
 *
 * Mikäli teosta käytetään lisenssin vastaisesti, on kyseessä tekijänoikeusloukkaus. 
 *
 * Uudelleenkäyttäessäsi tai levittäessäsi teosta, sinun tulee tehdä selväksi muille tämän teoksen
 * käyttäjille nämä lisenssiehdot. Tämän lisenssin rajoituksista voidaan luopua tekijänoikeuden omistajan 
 * antamalla luvalla.  Ota tällöin yhteyttä tekijänoikeuden omistajaan
 * Tämä lisenssi ei vaikuta tekijänoikeuslaissa sallittuun yksityiskopiointioikeuteen tai muiden lakien 
 * myöntämiin oikeuksiin. Tämä on tiivistelmä täydellisestä juridisesta lisenssistä. 
 * http://creativecommons.org/licenses/by-nc-sa/1.0/fi/legalcode
   *********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aktiviteetit',
  'LBL_MODULE_TITLE' => 'Aktiviteetit: etusivu',
  'LBL_SEARCH_FORM_TITLE' => 'Hae aktiviteetti',
  'LBL_LIST_FORM_TITLE' => 'Aktiviteetit',
  'LBL_LIST_SUBJECT' => 'Aihe',
  'LBL_LIST_CONTACT' => 'Kontaktit',
  'LBL_LIST_RELATED_TO' => 'Liittyy aiheeseen',
  'LBL_LIST_DATE' => 'Aloituspäivä',
  'LBL_LIST_TIME' => 'Aloitusaika',
  'LBL_LIST_CLOSE' => 'Sulje',
  'LBL_SUBJECT' => 'Aihe',
  'LBL_STATUS' => 'Tila:',
  'LBL_LOCATION' => 'Sijainti:',
  'LBL_DATE_TIME' => 'Aloituspäivä ja aika:',
  'LBL_DATE' => 'Aloituspäivä:',
  'LBL_TIME' => 'Aloitusaika:',
  'LBL_DURATION' => 'Kesto:',
  'LBL_HOURS_MINS' => '(tuntia/minuuttia)',
  'LBL_CONTACT_NAME' => 'Kontaktin nimi: ',
  'LBL_MEETING' => 'Tapaaminen:',
  'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
  'LBL_DESCRIPTION' => 'Kuvaus:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Ei aloitettu',
  'LNK_NEW_CALL' => 'Uusi puhelinsoitto',
  'LNK_NEW_MEETING' => 'Uusi tapaaminen',
  'LNK_NEW_TASK' => 'Uusi tehtävä',
  'LNK_NEW_NOTE' => 'Uusi muistio tai liitetiedosto',
  'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
  'LNK_CALL_LIST' => 'Puhelut',
  'LNK_MEETING_LIST' => 'Tapaamiset',
  'LNK_TASK_LIST' => 'Tehtävät',
  'LNK_NOTE_LIST' => 'Muistiot',
  'LNK_EMAIL_LIST' => 'Sähköpostit',
  'ERR_DELETE_RECORD' => 'Poista asiakas antamalla tietueen numero.',
  'NTC_REMOVE_INVITEE' => 'Haluatko poistaa henkilön tapaamisesta?',
  'LBL_INVITEE' => 'Raportoi suoraan',
  'LBL_LIST_DIRECTION' => 'Suunta',
  'LBL_DIRECTION' => 'Suunta',
  'LNK_NEW_APPOINTMENT' => 'Uusi tapaaminen',
  'LNK_VIEW_CALENDAR' => 'Tänään',
  'LBL_OPEN_ACTIVITIES' => 'Avoimet aktiviteetit',
  'LBL_HISTORY' => 'Historia',
  'LBL_UPCOMING' => 'Omat tulevat aktiviteetit',
  'LBL_TODAY' => 'saakka ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Uusi tehtävä [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Uusi tehtävä',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Etsi',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Uusi tapaaminen',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Valitse tapaamisaika',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Uusi puhelinsoitto',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Uusi muistio tai liite [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Uusi muistio tai liitetiedosto',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arkistoi sähköposti [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arkistoi sähköposti',
  'LBL_LIST_STATUS' => 'Tila',
  'LBL_LIST_DUE_DATE' => 'Valmistumispäivä',
  'LBL_LIST_LAST_MODIFIED' => 'Viimeksi muutettu',
  'NTC_NONE_SCHEDULED' => 'Ei löydetty',
  'appointment_filter_dom' => 
  array (
    'today' => 'tänään',
    'tomorrow' => 'huomenna',
    'this Saturday' => 'tällä viikolla',
    'next Saturday' => 'seuraava viikko',
    'last this_month' => 'tämä kuukausi',
    'last next_month' => 'seuraava kuukausi',
  ),
  'LNK_IMPORT_NOTES' => 'Tuo tietoja',
  'NTC_NONE' => 'Ei mitään',
  'LBL_ACCEPT_THIS' => 'Hyväksy?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Käyttäjät',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
);


?>