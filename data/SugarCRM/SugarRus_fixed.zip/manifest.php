<?php
$manifest = array(
	'acceptable_sugar_versions' => array (
		'exact_matches' => array (
			'4.0.0'
		),
		'regex_matches' => array (
		),
	),

	'name' => 'ru_ru',

	'description' => 'ru_ru language pack',

	'author' => '',

	'published_date' => '2005-12-12',

	'version' => '4.0',

	'type' => 'langpack',

	'icon' => '',

	'is_uninstallable' => TRUE
);
?>