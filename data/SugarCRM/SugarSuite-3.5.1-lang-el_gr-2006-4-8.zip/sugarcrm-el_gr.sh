#!/bin/sh

SugarCRM=/opt/sugarcrm/3.5.1-dev
DictFile=$(cat el_gr-dictionary.lang.txt)
langDir=include/language
langUSTemplate=$SugarCRM/$langDir/el_gr.notify_template.html
langUSDict=$SugarCRM/$langDir/el_gr.lang.php

test -d ${SugarCRM} || ( echo can not find ${SugarCRM}; exit 1)

for file in `cd ${SugarCRM}/modules; find . -type f -name el_gr.lang.php`; do
	dir=$(dirname $file)
	dir=modules/$dir
	file=modules/$file
	test -d $dir  || ( echo creating $dir ; mkdir -p $dir )
	test -f $file || ( echo copying ${SugarCRM}/$file; cp ${SugarCRM}/$file $dir )
	echo Translating $dir/el_gr.lang.php
	perl -p -i.bak -e "$DictFile" $file
	rm ${file}.bak
	mv $file $dir/el_gr.lang.php 
	echo
done

test -d $langDir || ( echo creating $langDir ; mkdir -p $langDir )

if [ ! -f $langUSTemplate ]; then
	echo error can not copy $langUSTemplate
else
	echo creating $langDir/el_gr.notify_template.html
	cp $langUSTemplate $langDir/el_gr.notify_template.html
fi

if [ ! -f $langUSDict ]; then
	echo error can not copy $langUSDict
else
	echo translating $langDir/el_gr.lang.php
	cp $langUSDict $langDir
	perl -p -i.bak -e 's/US English/UK English/g' $langDir/el_gr.lang.php
	rm $langDir/el_gr.lang.php.bak
	mv $langDir/el_gr.lang.php $langDir/el_gr.lang.php
fi

