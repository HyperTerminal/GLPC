<?php
 /*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
?>
<html>
<body>
<?php
require('../../../include/class_webdav_client/class_webdav_client.php');

$wdc = new webdav_client();
$wdc->set_server('127.0.0.1');
$wdc->set_port(80);
//$wdc->set_user('test@sugar.com');
//$wdc->set_pass('test');
// use HTTP/1.1
$wdc->set_protocol(1);
// enable debugging
$wdc->set_debug(false);


if (!$wdc->open()) {
  print 'Error: could not open server connection';
  exit;
}
// check if server supports webdav rfc 2518
if (!$wdc->check_webdav('/sugarcrm/vcal_server.php/user_id=1&type=vfb&source=outlook')) {
  print 'Error: server does not support webdav or user/password may be wrong';
  exit;
}

$path = '/sugarcrm/vcal_server.php/user_id=1&type=vfb&source=outlook&key=test23';

$http_status_array = $wdc->lock($path);
$http_status_put = $wdc->put_file($path, 'mytest.ifb');
$http_status = $wdc->unlock($path, $http_status_array[0]['locktoken']);


print "<HR>";
print "<b>TEST: vcal_server PUT to path: $path</b><BR><BR>\n\n";
print "RESULT:<BR>\n";
print "webdav server returns for PUT:' . $http_status_put . '<br><BR><BR>\n\n\n";

print "<HR>";
$buffer = '';
$http_status_get = $wdc->get($path,$buffer);

print "<b>TEST: vcal_server GET with path: $path</b><BR><BR>";
print "RESULT:<BR>";
print 'webdav server returns:<BR><pre>' . $http_status_get . '</pre><br>';
print 'webdav server returns buffer:<BR><pre>' . $buffer . '</pre><br>';

$wdc->close();
flush();
?>
</body>
<html>
