<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.217 2005/09/23 07:41:17 robert Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'language_pack_name' => 'DK Dansk',
  'moduleList' =>
  array (
    'Home' => 'Hjem',
    'Dashboard' => 'Dashboard',
    'Contacts' => 'Kontakter',
    'Accounts' => 'Kunder',
    'Opportunities' => 'Muligheder',
    'Cases' => 'Sager',
    'Notes' => 'Noter',
    'Calls' => 'Opkald',
    'Emails' => 'Emails',
    'Meetings' => 'M&oslash;der',
    'Tasks' => 'Opgaver',
    'Calendar' => 'Kalender',
    'Leads' => 'Emner',
	'ZuckerMail' => 'ZuckerMail',







    'Activities' => 'Aktiviteter',
    'Bugs' => 'Fejl S&oslash;ger',
    'Feeds' => 'RSS',
    'iFrames'=>'Min Portal',
    'TimePeriods'=>'Tids Perioder',
    'Project'=>'Projekter',
    'ProjectTask'=>'Projekt Opgaver',
    'Campaigns'=>'Kampagner',
    'Documents'=>'Dokumenter',
    'Sync'=>'Sync',






    'Users' => 'Brugere',
    'Releases' => 'Udgivelser'
        ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' =>
  array (
    '' => '',
    'Analyst' => 'Analyst',
    'Competitor' => 'Modpart',
    'Customer' => 'Kunde',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Presse',
    'Prospect' => 'Prospect',
    'Reseller' => 'Gensalg',
    'Other' => 'Andre',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' =>
  array (
    '' => '',
    'Apparel' => 'Apparel',
    'Banking' => 'Banking',
    'Biotechnology' => 'Bioteknologi',
    'Chemicals' => 'Kemikalier',
    'Communications' => 'Kommunikation',
    'Construction' => 'Konstruktion',
    'Consulting' => 'Konsultering',
    'Education' => 'Uddannelse',
    'Electronics' => 'Elektronik',
    'Energy' => 'Energi',
    'Engineering' => 'Engineering',
    'Entertainment' => 'Underholdning',
    'Environmental' => 'Omgivelser',
    'Finance' => 'Finans',
    'Government' => 'Regering',
    'Healthcare' => 'Helbredspleje',
    'Hospitality' => 'Hospital',
    'Insurance' => 'Forsikring',
    'Machinery' => 'Maskiner',
    'Manufacturing' => 'Leverand&oslash;r',
    'Media' => 'Media',
    'Not For Profit' => 'Ikke For Profit',
    'Recreation' => 'Rekreation',
    'Retail' => 'Retail',
    'Shipping' => 'Forsendelse',
    'Technology' => 'Teknologi',
    'Telecommunications' => 'Telekommunikation',
    'Transportation' => 'Transportering',
    'Utilities' => 'Utilities',
    'Other' => 'Andre',
  ),
  'lead_source_default_key' => 'Self Generated',
  'lead_source_dom' =>
  array (
    '' => '',
    'Cold Call' => 'Koldt Opkald',
    'Existing Customer' => 'Eksisterende Kunde',
    'Self Generated' => 'Selv Genereret',
    'Employee' => 'Medarbejder',
    'Partner' => 'Partner',
    'Public Relations' => 'Offentlig Relationer',
    'Direct Mail' => 'Direkte Post',
    'Conference' => 'Konference',
    'Trade Show' => 'Handels Show',
    'Web Site' => 'Web Site',
    'Word of mouth' => 'Ord fra mund',
    'Other' => 'Andre',
  ),
  'opportunity_type_dom' =>
  array (
    '' => '',
    'Existing Business' => 'Eksisterende Forretning',
    'New Business' => 'Ny Forretning',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim&aelig;r Valg Tager',
    'Business Decision Maker' => 'Forretnings Valg Tager',
    'Business Evaluator' => 'Forretnings Evaluerer',
    'Technical Decision Maker' => 'Teknisk Valg Tager',
    'Technical Evaluator' => 'Teknish Evaluerer',
    'Executive Sponsor' => 'Hoved Sponsor',
    'Influencer' => 'P&aring;virker',
    'Other' => 'Andet',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Contact' => 'Prim&aelig;r Kontakt',
    'Alternate Contact' => 'Alternativ Kontakt',
  ),
  'sales_stage_default_key' => 'Prospecting',
  'sales_stage_dom' =>
  array (
    'Prospecting' => 'Prospecting',
    'Qualification' => 'Kvalifikation',
    'Needs Analysis' => 'Mangler Analyse',
    'Value Proposition' => 'Value Proposition',
    'Id. Decision Makers' => 'Id. Valg Tager',
    'Perception Analysis' => 'Perception Analyse',
    'Proposal/Price Quote' => 'Forslag/Pris Citat',
    'Negotiation/Review' => 'Forhandling/Review',
    'Closed Won' => 'Lukket Vandt',
    'Closed Lost' => 'Lukket Tabt',
  ),

  'activity_dom' =>
  array (
    'Call' => 'Opkald',
    'Meeting' => 'M&aelig;de',
    'Task' => 'Opgave',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' =>
  array (
    '' => '',
    'Mr.' => 'Hr.',
    'Ms.' => 'Frk.',
    'Mrs.' => 'Fru.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  //time is in seconds; the greater the time the longer it takes;
  'reminder_max_time'=>3600,
  'reminder_time_options' => array( 60=> '1 minut f&aelig;r',
  								  300=> '5 minutter f&oslash;r',
  								  600=> '10 minutter f&oslash;r',
  								  900=> '15 minutter f&oslash;r',
  								  1800=> '30 minutter f&oslash;r',
  								  3600=> '1 time f&oslash;r',
								 ),

  'task_priority_default' => 'Medium',
  'task_priority_dom' =>
  array (
    'High' => 'H&oslash;j',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
  'task_status_default' => 'Ikke Startet',
  'task_status_dom' =>
  array (
    'Not Started' => 'Ikke Startet',
    'In Progress' => 'I Fremskridt',
    'Completed' => 'Udf&oslash;rt',
    'Pending Input' => 'Ventende Input',
    'Deferred' => 'Deferred',
  ),
  'meeting_status_default' => 'Planlagt',
  'meeting_status_dom' =>
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Holdt',
    'Not Held' => 'Ikke Holdt',
  ),
  'call_status_default' => 'Planlagt',
  'call_status_dom' =>
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Holdt',
    'Not Held' => 'Ikke Holdt',
  ),
  'call_direction_default' => 'Outbound',
  'call_direction_dom' =>
  array (
    'Inbound' => 'Inbound',
    'Outbound' => 'Outbound',
  ),
  'lead_status_dom' =>
  array (
    '' => '',
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'In Process' => 'I Proces',
    'Converted' => 'Konverteret',
    'Recycled' => 'Smidt ud',
    'Dead' => 'D&oslash;d',
  ),
  'lead_status_noblank_dom' =>
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'In Process' => 'I Proces',
    'Converted' => 'Konverteret',
    'Recycled' => 'Smidt ud',
    'Dead' => 'D&oslash;d',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' =>
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'Closed' => 'Lukket',
    'Pending Input' => 'Ventende Input',
    'Rejected' => 'Afvist',
    'Duplicate' => 'Kopieret',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' =>
  array (
    'P1' => 'H&oslash;j',
    'P2' => 'Medium',
    'P3' => 'Lav',
  ),
  'user_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'employee_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Terminated' => 'Termineret',
    'Leave of Absence' => 'Leave of Absence',
  ),
  'messenger_type_dom' =>
  array (
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
    'AOL' => 'AOL',
  ),

	'project_task_priority_options' => array (
		'High' => 'H&oslash;j',
		'Medium' => 'Medium',
		'Low' => 'Lav',
	),
	'project_task_status_options' => array (
		'Not Started' => 'Ikke Startet',
		'In Progress' => 'I Fremskridt',
		'Completed' => 'Udf&oslash;rt',
		'Pending Input' => 'Ventende Input',
		'Deferred' => 'Deferred',
	),
	'project_task_utilization_options' => array (
		'0' => 'Ingen',
		'25' => '25',
		'50' => '50',
		'75' => '75',
		'100' => '100',
	),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' =>
  array (
    'Accounts' => 'Kunde',
    'Opportunities' => 'Mulighed',
    'Cases' => 'Sag',
    'Leads' => 'Emne',




    'Bugs' => 'Fejl',
    'Project' => 'Projekt',
    'ProjectTask' => 'Projekt Opgave',
  ),

  'record_type_display_notes' =>
  array (
    'Accounts' => 'Kunde',
	'Contacts' => 'Kontakt',
    'Opportunities' => 'Mulighed',
    'Cases' => 'Sag',
    'Leads' => 'Emne',





    'Bugs' => 'Fejl',
    'Emails' => 'Email',
    'Project' => 'Projekt',
    'ProjectTask' => 'Projekt Opgave',
  ),






































	
  'quote_type_dom' =>
  array (
    'Quotes' => 'Citat',
    'Orders' => 'Ordre',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' =>
  array (
    'Draft' => 'Draft',
    'Negotiation' => 'Forhandling',
    'Delivered' => 'Leveret',
    'On Hold' => 'P&aring; Hold',
    'Confirmed' => 'Godkendt',
    'Closed Accepted' => 'Lukket Accepteret',
    'Closed Lost' => 'Lukket Tabt',
    'Closed Dead' => 'Lukket d&oslash;d',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' =>
  array (
    'Pending' => 'Ventende',
    'Confirmed' => 'Godkendt',
    'On Hold' => 'P&aring; Hold',
    'Shipped' => 'Sent',
    'Cancelled' => 'Annulleret',
  ),

//Note:  do not translate quote_relationship_type_default_key
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim&aelig;r Valg Tager',
    'Business Decision Maker' => 'Forretnings Valg Tager',
    'Business Evaluator' => 'Forretnings Evaluerer',
    'Technical Decision Maker' => 'Teknisk Valg Tager',
    'Technical Evaluator' => 'Teknisk Evaluerer',
    'Executive Sponsor' => 'Hoved Sponsor',
    'Influencer' => 'Influencer',
    'Other' => 'Andet',
  ),
  'layouts_dom' =>
  array (
    'Standard' => 'Forslag',
    'Invoice' => 'Invoice',
    'Terms' => 'Betalings Betingelser'
  ),

  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' =>
  array (
    'Urgent' => 'Vigtig',
    'High' => 'H&oslash;j',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
   'bug_resolution_default_key' => '',
  'bug_resolution_dom' =>
  array (
  	'' => '',
  	'Accepted' => 'Accepteret',
    'Duplicate' => 'Kopi',
    'Fixed' => 'Ordnet',
    'Out of Date' => 'For&aelig;ldet',
    'Invalid' => 'Ugyldig',
    'Later' => 'Senere',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' =>
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'Closed' => 'Lukket',
    'Pending' => 'Ventende',
    'Rejected' => 'Afvist',
  ),
   'bug_type_default_key' => 'Bug',
  'bug_type_dom' =>
  array (
    'Defect' => 'Defect',
    'Feature' => 'Feature',
  ),

  'source_default_key' => '',
  'source_dom' =>
  array (
	'' => '',
  	'Internal' => 'Intern',
  	'Forum' => 'Forum',
  	'Web' => 'Web',
  ),

  'product_category_default_key' => '',
  'product_category_dom' =>
  array (
	'' => '',
  	'Accounts' => 'Kunder',
  	'Activities' => 'Aktiviteter',
  	'Bug Tracker' => 'Fejl s&oslash;ger',
  	'Calendar' => 'Kalender',
  	'Calls' => 'Opkald',
  	'Campaigns' => 'kampagner',  	
  	'Cases' => 'Sager',
  	'Contacts' => 'kontakter',
  	'Currencies' => 'Valutaer',
  	'Dashboard' => 'Dashboard',
  	'Documents' => 'Dokumenter',
  	'Emails' => 'Emails',
  	'Feeds' => 'Feeds',
  	'Forecasts' => 'Forecasts',  	
  	'Help' => 'Hj&aelig;lp',
  	'Home' => 'Hjem',
  	'Leads' => 'Leadelser',
  	'Meetings' => 'M&oslash;der',
  	'Notes' => 'Notes',
  	'Opportunities' => 'Muligheder',
  	'Outlook Plugin' => 'Outlook Plugin',
  	'Product Catalog' => 'Produkt Katalog',  	
  	'Products' => 'Produkter',  	
  	'Projects' => 'Projekter',  	
  	'Quotes' => 'Citater',
  	'Releases' => 'Udgivelser',
  	'RSS' => 'RSS',
  	'Studio' => 'Studio',
  	'Upgrade' => 'Opgradering',
  	'Users' => 'Brugere',
  ),

  'campaign_status_dom' =>
  array (
    '' => '',
        'Planning' => 'Planl&aelig;gning',
        'Active' => 'Aktiv',
        'Inactive' => 'Inaktiv',
        'Complete' => 'Udf&oslash;rt',
  ),
  'campaign_type_dom' =>
  array (
        '' => '',
        'Telesales' => 'Telesalg',
        'Mail' => 'Mail',
        'Email' => 'Email',
        'Print' => 'Print',
        'Web' => 'Web',
        'Radio' => 'Radio',
        'Television' => 'Fjernsyn',
        ),



  'notifymail_sendtype' =>
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => array('-12'=>'(GMT - 12) International Date Line West',
  							'-11'=>'(GMT - 11) Midway Island, Samoa',
  							'-10'=>'(GMT - 10) Hawaii',
  							'-9'=>'(GMT - 9) Alaska',
  							'-8'=>'(GMT - 8) San Francisco',
  							'-7'=>'(GMT - 7) Phoenix',
  							'-6'=>'(GMT - 6) Saskatchewan',
  							'-5'=>'(GMT - 5) New York',
  							'-4'=>'(GMT - 4) Santiago',
  							'-3'=>'(GMT - 3) Buenos Aires',
  							'-2'=>'(GMT - 2) Mid-Atlantic',
  							'-1'=>'(GMT - 1) Azores',
  							'0'=>'(GMT)',
  							'1'=>'(GMT + 1) K&oslash;benhavn',
  							'2'=>'(GMT + 2) Athens',
  							'3'=>'(GMT + 3) Moscow',
  							'4'=>'(GMT + 4) Kabul',
  							'5'=>'(GMT + 5) Ekaterinburg',
  							'6'=>'(GMT + 6) Astana',
  							'7'=>'(GMT + 7) Bangkok',
  							'8'=>'(GMT + 8) Perth',
  							'9'=>'(GMT + 9) Seol',
  							'10'=>'(GMT + 10) Brisbane',
  							'11'=>'(GMT + 11) Solomone Is.',
  							'12'=>'(GMT + 12) Auckland',
  							),
      'dom_cal_month_long'=>array(
                '0'=>"",
                '1'=>"Januar",
                '2'=>"Februar",
                '3'=>"Marts",
                '4'=>"April",
                '5'=>"Maj",
                '6'=>"Juni",
                '7'=>"Juli",
                '8'=>"August",
                '9'=>"September",
                '10'=>"Oktober",
                '11'=>"November",
                '12'=>"December",
        ),

        'dom_report_types'=>array(
                'tabular'=>'R&aelig;kker og Kolonner',
                'summary'=>'Sum',
                'detailed_summary'=>'Sum med detaljer',
        ),
        'dom_email_types'=>array(
                'out'=>'Sendt',
                'archived'=>'Arkiveret',
                'draft'=>'Draft',
        ),
	'forecast_schedule_status_dom' =>
  	array (
    'Active' => 'Activ',
    'Inactive' => 'Inaktiv',
  ),
	'forecast_type_dom' =>
  	array (
    'Direct' => 'Direkte',
    'Rollup' => 'Rollup',
  ),  
	
	'document_category_dom' =>
  	array (
  	'' => '',
    'Marketing' => 'Marketing',
    'Knowledege Base' => 'Knowledge Base',
    'Sales' => 'Salg',    
  ),  

	'document_subcategory_dom' =>
  	array (
  	'' => '',
    'Marketing Collateral' => 'Marketing Collateral',
    'Product Brochures' => 'Produkt Brochurer',
	'FAQ' => 'FAQ',
  ),  
  
	'document_status_dom' =>
  	array (
    'Active' => 'Aktiv',
    'Draft' => 'Draft',
	'FAQ' => 'FAQ',
	'Expired' => 'Udl&oslash;bet',
	'Under Review' => 'Under Revidering',
	'Pending' => 'Ventende',
  ),
	'dom_meeting_accept_options' =>
  	array (
	'accept' => 'Accepter',
	'decline' => 'Afsl&aring;',
	'tentative' => 'Tentative',
  ),
	'dom_meeting_accept_status' =>
  	array (
	'accept' => 'Accepteret',
	'decline' => 'Afsl&aring;et',
	'tentative' => 'Tentative',
  ),






































































































































































































































































































































);

$app_strings = array (
  'LBL_SERVER_RESPONSE_TIME' => 'Server svar tid:',
  'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'sekunder.',
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Kommerciel Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Mine Kunder',
  'LBL_EMPLOYEES' => 'Medarbejdere',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Log ud',
  'LBL_SYNC' => 'Synkronisering',
  'LBL_SEARCH' => 'S&oslash;g',
  'LBL_LAST_VIEWED' => 'Sidst Set',
  'NTC_WELCOME' => 'Velkommen',
  'NTC_SUPPORT_SUGARCRM' => 'St&oslash;t SugarCRM open source projektet med en donation gennem PayPal - det er hurtigt, gratis og sikkert!',
  'NTC_NO_ITEMS_DISPLAY' => 'ingen',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Gem [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Rediger [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Rediger',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Kopier [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Kopier',
  'LBL_DELETE_BUTTON_TITLE' => 'Slet [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Slet',
  'LBL_UNDELETE_BUTTON' => 'Fortryd slet',
  'LBL_UNDELETE_BUTTON_TITLE' => 'Fortryd slet [Alt+D]',
  'LBL_NEW_BUTTON_TITLE' => 'Opret [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Skift [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Annuller [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'S&oslash;g [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Ryd [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'V&aelig;lg [Alt+T]',
  'LBL_ADD_BUTTON' => 'Tilf&oslash;j',
  'LBL_ADD_BUTTON_TITLE' => 'Tilf&oslash;j [Alt+A]',
  'LBL_ADD_BUTTON_KEY' => 'A',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Gem',
  'LBL_EDIT_BUTTON_LABEL' => 'Rediger',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Kopier',
  'LBL_DELETE_BUTTON_LABEL' => 'Slet',
  'LBL_UNDELETE_BUTTON_LABEL' => 'Fortryd slet',
  'LBL_NEW_BUTTON_LABEL' => 'Opre',
  'LBL_CHANGE_BUTTON_LABEL' => 'Skift',
  'LBL_CANCEL_BUTTON_LABEL' => 'Annuller',
  'LBL_SEARCH_BUTTON_LABEL' => 'S&oslash;g',
  'LBL_CLEAR_BUTTON_LABEL' => 'Ryd',
  'LBL_NEXT_BUTTON_LABEL' => 'N&aelig;ste',
  'LBL_SELECT_BUTTON_LABEL' => 'V&aelig;lg',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'V&aelig;lg Kontakt [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Skriv som PDF',
  'LBL_VIEW_PDF_BUTTON_TITLE' => 'Skriv som PDF [Alt+P]',
  'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
  'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Opret Mulighed fra Citat',
  'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Opret Mulighed fra Citat [Alt+O]',
  'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'V&aelig;lg Kontakt',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'V&aelig;lg Bruger [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'V&aelig;lg Bruger',
  'LBL_CREATE_BUTTON_LABEL' => 'Opret',
  'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'V&aelig;lg Rapporter',
  'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'V&aelig;lg fra Rapporter',
  'LBL_DONE_BUTTON_KEY' => 'X',
  'LBL_DONE_BUTTON_TITLE' => 'Udf&oslash;rt [Alt+X]',
  'LBL_DONE_BUTTON_LABEL' => 'Udf&oslash;rt',
  'LBL_SHORTCUTS' => 'Genveje',
  'LBL_LIST_NAME' => 'Navn',



  'LBL_LIST_USER_NAME' => 'Bruger Navn',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_LIST_CONTACT_ROLE' => 'Kontakt Rolle',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde Navn',
  'LBL_USER_LIST' => 'Bruger Liste',
  'LBL_CONTACT_LIST' => 'Kontakt Liste',
  'LBL_RELATED_RECORDS' => 'Lignende Data',
  'LBL_MASS_UPDATE' => 'Masse Updatering',
  'LNK_ADVANCED_SEARCH' => 'Avanceret',
  'LNK_BASIC_SEARCH' => 'Generel',
  'LNK_EDIT' => 'rediger',
  'LNK_REMOVE' => 'fjern',
  'LNK_DELETE' => 'slet',
  'LNK_DELETE_ALL' => 'slet alle',
  'LNK_LIST_START' => 'Start',
  'LNK_LIST_NEXT' => 'N&aelig;ste',
  'LNK_LIST_PREVIOUS' => 'Forrige',
  'LNK_LIST_END' => 'Slut',
  'LNK_LIST_RETURN' => 'Returner til Liste',
  'LNK_RESUME' => 'Forts&aelig;t',
  'LBL_LIST_OF' => 'over',
  'LBL_OR' => 'Eller',
  'LBL_BY' => 'af',
  'LNK_PRINT' => 'Udskriv',
  'LNK_HELP' => 'Hj&aelig;lp',
  'LNK_ABOUT' => 'Om',
  'NTC_REQUIRED' => 'Indikerer p&aring;kr&aelig;vet felt',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_YEAR_FORMAT' => '(yyyy)',
  'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(yyyy-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Er du sikker p&aring; at du vil slette de valgte data?',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; at du vil slette denne?',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v&aelig;re valgt for at slette kontakten.',
  'ERR_CREATING_TABLE' => 'Fejl under oprettelse af tabel: ',
  'ERR_CREATING_FIELDS' => 'Fejl under udfyldning af ekstra detaljer felterne: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Mangler p&aring;kr&aelig;vet felt:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'ikke en gyldig email adresse.',
  'ERR_INVALID_DATE_FORMAT' => 'Data formatet skal v&aelig;re: ',
  'ERR_INVALID_MONTH' => 'Indtast venligst en gyldig m&aring;ned.',
  'ERR_INVALID_DAY' => 'Indtast venligst en gyldig dag.',
  'ERR_INVALID_YEAR' => 'Indtast venligst en gyldig 4 tals &aring;r.',
  'ERR_INVALID_DATE' => 'Indtast venligst en gyldig dato.',
  'ERR_INVALID_HOUR' => 'Indtast venligst en gyldig time.',
  'ERR_INVALID_TIME' => 'Indtast venligst en gyldig tid.',
  'ERR_INVALID_AMOUNT' => 'Indtast venligst en gyldig m&aelig;ngde.',
  'NTC_CLICK_BACK' => 'Klik venligst p&aring; browserens tilbage knap og ret fejlen.',
  'LBL_LIST_ASSIGNED_USER' => 'Bruger',
  'LBL_ASSIGNED_TO' => 'Tildelt til:',
  'LBL_DATE_MODIFIED' => 'Sidst Rettet:',
  'LBL_DATE_ENTERED' => 'Oprettelsesdato:',
  'LBL_CURRENT_USER_FILTER' => 'Kun mine ting:',
  'NTC_LOGIN_MESSAGE' => 'Indtast venligst dit brugernavn og kodeord.',
  'LBL_NONE' => '--Ingen--',
  'LBL_BACK' => 'Tilbage',
  'LBL_IMPORT' => 'Importer',
  'LBL_EXPORT' => 'Eksporter',
  'LBL_EXPORT_ALL' => 'Eksporter Alle',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Gem & Opret Ny [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Gem & Opret Ny',
  'LBL_NAME' => 'Navn',




  'LBL_CHECKALL' => 'Marker Alle',
  'LBL_CLEARALL' => 'Ryd Alle',
  'LBL_SUBJECT' => 'Overskrift',
  'LBL_ENTER_DATE' => 'Indtast Dato',
  'LBL_CREATED' => 'Oprettet af',
  'LBL_MODIFIED' => 'Rettet af',
  'LBL_DELETED'=>'Slettet',
  'LBL_ID'=>'ID',
  'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Send Email [Alt+L]',
  'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
  'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Send Email',
  'ERR_OPPORTUNITY_NAME_MISSING' => 'Et muligheds navn var ikke indtastet.  Imdtast venligst et muligheds navn nedenunder.',
  'ERR_OPPORTUNITY_NAME_DUPE' => 'En mulighed med navnet %s  eksisterer allerede.  Indtast venligst en andet navn nedenunder.',
  'LBL_OPPORTUNITY_NAME' => 'Muligheds Navn',
  'LBL_DELETE' => 'Slet',
  'LBL_UNDELETE' => 'Fortryd slet',
  'LBL_UPDATE' => 'Opdater',
  'LBL_STATUS_UPDATED'=>'Din Status for denne begivenhed er blevet opdateret!',
  'LBL_STATUS'=>'Status:',
  'LBL_CLOSE_WINDOW'=>'Luk Vindue',
  'LBL_OPENALL_BUTTON_TITLE' => 'ŀben Alle [Alt+O]',
  'LBL_OPENALL_BUTTON_KEY' => 'O',
  'LBL_OPENALL_BUTTON_LABEL' => 'ŀben Alle',
  'LBL_CLOSEALL_BUTTON_TITLE' => 'Luk Alle [Alt+I]',
  'LBL_CLOSEALL_BUTTON_KEY' => 'Q',
  'LBL_CLOSEALL_BUTTON_LABEL' => 'Luk Alle',
  'LBL_OPENTO_BUTTON_TITLE' => 'ŀben Til: [Alt+T]',
  'LBL_OPENTO_BUTTON_KEY' => 'T',
  'LBL_OPENTO_BUTTON_LABEL' => 'ŀben Til: ',












  'LBL_UNAUTH_ADMIN' => 'Uautoriseret adgang til administrationen',
  'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p&aring; at du vil fjerne dette forhold?',
  
        'LBL_ASSIGNED_TO_USER'=>'Tildelt til Bruger',
        'LBL_MODIFIED_BY_USER'=>'Rettet af Bruger',
        'LBL_CREATED_BY_USER'=>'Oprettet af Bruger',
        'LBL_TEAMS_LINK'=>'Hold',
  'LBL_PRODUCT_BUNDLES'=>'Produkt Bundles',
  'LBL_TASKS'=>'Opgaver',
  'LBL_NOTES'=>'Noter',
  'LBL_MEETINGS'=>'M&oslash;der',
  'LBL_CALLS'=>'Opkald',
  'LBL_EMAILS'=>'Emails',
  'LBL_PROJECTS'=>'Projekter',
  'LBL_SHIP_TO_ACCOUNT'=>'Send til Kunde',
  'LBL_BILL_TO_ACCOUNT'=>'Bon til Kunde',
  'LBL_SHIP_TO_CONTACT'=>'Send til Kontakt',
  'LBL_BILL_TO_CONTACT'=>'Bon til Kontakt',
  'LBL_PRODUCT_BUNDLES'=>'Produkt Bundles',
  'LBL_OPPORTUNITY'=>'Mulighed',
  'LBL_PRODUCTS'=>'Produkter',
  'LBL_OPPORTUNITIES'=>'Muligheder',
  'LBL_ACCOUNTS'=>'Kunder',
  'LBL_BUGS'=>'Fejl',
  'LBL_CASES'=>'Sager',
  'LBL_DIRECT_REPORTS'=>'Direkte Rapporter',
  'LBL_LEADS'=>'Emner',
  'LBL_PROJECTS'=>'Projekter',
  'LBL_QUOTES'=>'Citater',
  'LBL_USERS_SYNC'=>'Brugers Sync',
  'LBL_MEMBERS'=>'Medlemmer',
  'LBL_CONTACTS'=>'Kontakter',
  'LBL_QUOTES_SHIP_TO'=>'Citater Send til',
  'LBL_ACCOUNT'=>'Kunder',
  'LBL_CONTACT'=>'Kontakt',
  'LBL_USERS'=>'Brugere',
  'LBL_CASE'=>'Sag',
  'LBL_PROJECT_TASKS'=>'Projekt Opgaver',
  'LBL_SHOW'=>'Vis',
  'LBL_HIDE'=>'Skjul',
  'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'Se Resultat [Alt+H]',
  'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
  'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Se Resultat',
  'LNK_VIEW_CHANGE_LOG' => 'Se Forandrings Log',
  'LBL_SYNC' => 'Sync',
  'LBL_UNSYNC' => 'Afsync',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arkiver Email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arkiver Email',
  
);

?>
