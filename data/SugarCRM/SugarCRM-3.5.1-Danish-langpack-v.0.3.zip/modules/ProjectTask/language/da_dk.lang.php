<?php
/**
 * Default English language strings
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: en_us.lang.php,v 1.25 2005/08/10 23:21:48 ajay Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projekt Opgaver',
	'LBL_MODULE_TITLE' => 'Projekt Opgaver: Hjem',
	'LBL_SEARCH_FORM_TITLE' => 'Projekt Opgaver S�gning',
	'LBL_LIST_FORM_TITLE'=> 'Projekt Opgaver Liste',
	
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Dato Indskrevet:',
	'LBL_DATE_MODIFIED' => 'Dato Rettet:',
	'LBL_ASSIGNED_USER_ID' => 'Tildelt Til:',
	'LBL_MODIFIED_USER_ID' => 'Rettet Bruger Id:',
	'LBL_CREATED_BY' => 'Oprettet Af:',
	'LBL_TEAM_ID' => 'Hold:',
	'LBL_NAME' => 'Navn:',
	'LBL_STATUS' => 'Status:',
	'LBL_DATE_DUE' => 'Ved Dato:',
	'LBL_TIME_DUE' => 'Ved Tid:',
	'LBL_DATE_START' => 'Start Dat:',
	'LBL_TIME_START' => 'Start Tid:',
	'LBL_PARENT_ID' => 'Projekt:',
	'LBL_PRIORITY' => 'Prioritet:',
	'LBL_DESCRIPTION' => 'Beskrivelse:',
	'LBL_ORDER_NUMBER' => 'Ordre:',
	'LBL_TASK_NUMBER' => 'Opgave Nummer:',
	'LBL_DEPENDS_ON_ID' => 'Afh�nger Af:',
	'LBL_MILESTONE_FLAG' => 'Milesten:',
	'LBL_ESTIMATED_EFFORT' => 'Ansl�et Ydelse (timer):',
	'LBL_ACTUAL_EFFORT' => 'Faktiske Ydelse (timer):',
	'LBL_UTILIZATION' => 'Utilisation (%):',
	'LBL_PERCENT_COMPLETE' => 'Progres (%):',
	'LBL_DELETED' => 'Slettet:',

	'LBL_LIST_ORDER_NUMBER' => 'Ordre',
	'LBL_LIST_NAME' => 'Navn',
	'LBL_LIST_PARENT_NAME' => 'Projekt',
	'LBL_LIST_PERCENT_COMPLETE' => 'Progres (%)',
	'LBL_LIST_STATUS' => 'Status',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Tildelt Til',
	'LBL_LIST_DATE_DUE' => 'Dato Ved',
	'LBL_LIST_DATE_START' => 'Start Dato',
	'LBL_PROJECT_NAME' => 'Projekt Navn',

	'LNK_NEW_PROJECT'	=> 'Opret Projekt',
	'LNK_PROJECT_LIST'	=> 'Projekt Liste',
	'LNK_NEW_PROJECT_TASK'	=> 'Opret Projekt Opgave',
	'LNK_PROJECT_TASK_LIST'	=> 'Projekt Opgaver',
	
	'LBL_LIST_MY_PROJECT_TASKS' => 'Mine �bne Projekt Opgaver',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projekt Opgaver',

	'LBL_ACTIVITIES_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_TITLE'=>'Historie',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie', 
);
?>
