<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

// $Id: en_us.lang.php,v 1.110 2005/09/26 07:57:08 majed Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Administration',
	'LBL_MODULE_TITLE' => 'Administration: Hjem',
	'LBL_NEW_FORM_TITLE' => 'Opret Konto',
	'LNK_NEW_USER' => 'Opret Bruger',
	'ERR_DELETE_RECORD' => 'Et data nummer skal v�re valgt for at slette kontoen.',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Konfigurer Ops�tning',
	'LBL_CONFIGURE_SETTINGS' => 'Konfigurer system-bred ops�tning',
	'LBL_UPGRADE_TITLE' => 'Reparer',
	'LBL_UPGRADE' => 'Tjek og reparer Sugar Suite',
	'LBL_MANAGE_USERS_TITLE' => 'Bruger Administration',
	'LBL_MANAGE_USERS' => 'Administrer bruger kontoer og kodeord',
	'LBL_ADMINISTRATION_HOME_TITLE' => 'System',
	'LBL_NOTIFY_TITLE' => 'Email P�mindelses Konfiguration',
	'LBL_NOTIFY_FROMADDRESS' => '"Fra" Adresse:',
	'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
	'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
	'LBL_MAIL_SENDTYPE' => 'Mail Overf�rsels Agent:',
	'LBL_MAIL_SMTPUSER' => 'SMTP Brugernavn:',
	'LBL_MAIL_SMTPPASS' => 'SMTP Kodeord:',
	'LBL_MAIL_SMTPAUTH_REQ' => 'Brug SMTP Godkendelse?',
	'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Send p�mindelser som standard?',
	'LBL_NOTIFY_SUBJECT' => 'Email overskrift:',
	'LBL_NOTIFY_ON' => 'P�mindelser sl�et til?',
	'LBL_NOTIFY_FROMNAME' => '"Fra" Navn:',
	'LBL_CURRENCY' => 'Valuta og valutakurs ops�tning',
	'LBL_RELEASE' => 'Administrer udgivelser og versioner',
	'LBL_LAYOUT' => 'Tilf�j, fjern, skift felter, og layout felter og paneler henover applikationen',
	'LBL_MANAGE_CURRENCIES' => 'Valutaer',
	'LBL_MANAGE_RELEASES' => 'Udgivelser',
	'LBL_MANAGE_LAYOUT' => 'Felt Layout',
	'LBL_MANAGE_OPPORTUNITIES' => 'Muligheder',
	'LBL_UPGRADE_CURRENCY' => 'Opgrader kurs m�ngde i',
	'LBL_EDIT_CUSTOM_FIELDS' => 'Rediger Specielle Felter',
	'DESC_MODULES_QUEUED' => 'De F�lgende Moduler er lokalt i k� for installation:',
	'DESC_FILES_QUEUED' => 'De f�lgende Opgraderinger er lokalt i k� for installation:',
	'DESC_MODULES_INSTALLED' => 'De f�lgende Moduler er blevet installeret:',
	'DESC_FILES_INSTALLED' => 'De f�lgende Opgraderinger er blevet installeret:',
    'DESC_EDIT_CUSTOM_FIELDS' => 'Rediger de specielle felter oprettet for felt Layoutet',
	'LBL_DROPDOWN_EDITOR' => 'Dropdown Editor',
	'DESC_DROPDOWN_EDITOR' => 'Tilf�j, slet, eller skift dropdown listen i applikationen',
	'LBL_IFRAME'=> 'Portal',
	'DESC_IFRAME' => 'Tilf�j faner com kan vise hvilken som helt web side',
	'LBL_BUG_TITLE' => 'Fejl Finder',
	'LBL_TIMEZONE' => 'Tids Zone',
	'LBL_STUDIO_TITLE' => 'Studie',
	'LBL_UPLOAD_MODULE' => 'Upload et Modul: ',
	'LBL_UPLOAD_UPGRADE' => 'Upload en Opgradering: ',
	'LBL_CONFIGURE_TABS' => 'Configurer Faner',
	'LBL_CHOOSE_WHICH'=>'V�lg hvilke faner der er vist system-bredt',
	'LBL_DISPLAY_TABS'=>'Vis Faner',
	'LBL_HIDE_TABS'=>'Skjul Faner',
	'LBL_EDIT_TABS'=>'Rediger Faner',
	'LBL_UPGRADE_DB_TITLE' => 'Opgrader database',
	'LBL_UPGRADE_DB' => 'Opdater databasen fra version 2.0.x to 2.5 ',
	'LBL_UPGRADE_DB_BEGIN' => 'Begynder Opgradering',
	'LBL_UPGRADE_DB_COMPLETE' => 'Opgradering Fuldf�rt',
	'LBL_UPGRADE_VERSION'=>'Opdaterings version info',
	'LBL_UPGRADE_DB_FAIL' => 'Opgradering Mislykkedes',
	'LBL_FORECAST_TITLE'=> 'Forecast',
	'LBL_PORTAL_TITLE' => 'Kunde Selv-Service Portal',
	'LBL_PORTAL_ON' => 'Sl� Selv-Service Portal Integration til?',
	'LBL_PORTAL_ON_DESC' => 'Tillader Sag, Note og andre data at v�re tilg�ngelig for et eksternt kunde self-service portal system.',
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
	'LBL_SKYPEOUT_ON' => 'Sl� SkypeOut&reg; Integration til?',
	'LBL_SKYPEOUT_ON_DESC' => 'Tillader brugere at klikke p� telefonnumre for at ringe med SkypeOut&reg;. Numrene skal v�re formateret rigtigt for at g�re denne feature brugbar. Det skal v�re "+"  "Landekoden" "Nummeret" for mere information om formatteringen se <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>    ',
	'LBL_NOTIFICATION_ON_DESC' => 'Sender p�mindelses emails n�r data er tildelt.',
    'LBL_UPGRADE_WIZARD' => 'Opgraderings Wizard til at administrere opgraderinger',
    'LBL_UPGRADE_WIZARD_TITLE' => 'Opgraderings Wizard',
    'LBL_MODULE_LOADER' => 'Tilf�j eller fjern moduler til Sugar',
    'LBL_MODULE_LOADER_TITLE' => 'Modul Indl�ser',
	'LBL_ALLOW_USER_TABS' => 'Tillad brugere at konfigurere faner',
	'LBL_RENAME_TABS'=>'Omd�b Faner',
	'LBL_CHANGE_NAME_TABS'=>'Skift navn p� fanerne.',
	'LBL_MASS_EMAIL_MANAGER_DESC'=> 'Administrer masse email k�en',
	'LBL_MASS_EMAIL_MANAGER_TITLE'=> 'Masse Email Administration',
	'LBL_MANAGE_ROLES_TITLE' => 'Rolle Administration',
	'LBL_MANAGE_ROLES' => 'Administrer rolle medlemsskab og egenskaber',
    'LBL_BACKUPS_TITLE' => 'Backups',
    'LBL_BACKUPS' => 'Udf�r en backup',
	'LBL_IMPORT_CUSTOM_FIELDS_TITLE' => 'Importer Struktur i Specielle Felter',
	'LBL_EXPORT_CUSTOM_FIELDS_TITLE' => 'Exporter Struktur i Specielle Felter',
	'LBL_EXTERNAL_DEV_TITLE'=> 'Migrer Specielle Felter',
	'LBL_EXTERNAL_DEV_DESC'=> 'Migrer struktur i specielle felter fra �t system til et andet',
	'LBL_IMPORT_CUSTOM_FIELDS'=> 'Importer definitioner p� specielle felter fra en .sugar fil', 
	'LBL_EXPORT_CUSTOM_FIELDS'=> 'Exporter definitioner p� specielle felter til en .sugar fil', 
	'LBL_IMPORT_CUSTOM_FIELDS_STRUCT'=> ' Special Felt Struktur (SugarCustomFieldStruct.sug)',
	'LBL_IMPORT_CUSTOM_FIELDS_DESC'=> ' <br>Importer en .sug fil som var exporteret fra en anden maskine. Dette vil forsage at det specielle felts struktur p� denne maskine matcher det specielle felt p� den anden maskine. Det er anbefalet at du eksporterer din nuv�rende special felt Struktur f�r du importerer en. Efter at have importeret Special Felt Strukturen, vil systemet automatisk guide dig igennem en Special Felt Opgradering som informerer dig om hvilke �ndringer der vil blive lavet i databasen. Hvis du accepterer disse �ndinger klik p� execute non-simulation mode linket i bunden. Hvis du �nsker at g� tilbage til det gamle igen skal du bare importere den struktur du exporterede f�r du k�rte denne import. Hvis du g�r <br> Advarsel: Dette vil fjerne alle f�r definerede special felt strukturer der ikke er defineret i .sug filen s�vel som alle data gemt i de special felter.',

	'LBL_REBUILD_AUDIT_TITLE' => 'Genopbygget Lydh�r',
	'LBL_REBUILD_AUDIT_DESC' => 'Genopbygger lydh�rs tabel.',
	
	'LBL_REBUILD_EXTENSIONS_TITLE' => 'Genopbyg Extensions',
	'LBL_REBUILD_EXTENSIONS_DESC' => 'Genopbygger extensions inklusiv udvidet vardefs, sprog pakker, menuer, og administration',

    'LBL_REBUILD_CONFIG' =>'Genopbygger Konfig Fil',
    'LBL_REBUILD_CONFIG_DESC' =>'Genopbyg config.php ved at updatere versionen og tilf�je tilf�ldigheder n�r det ikke er tydeligt erkl�ret.',
    'BTN_REBUILD_CONFIG' =>'Genopbygger',
    'LBL_CONFIG_CHECK' =>'Konfig Tjek',
    'MSG_CONFIG_FILE_READY_FOR_REBUILD' => 'config.php filen er klar til genopbyggelse.',
    'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'G�r venligst config.php skrivbar og pr�v igen.',
    'MSG_CONFIG_FILE_REBUILD_SUCCESS' => 'config.php genopbygning lykkedes.',
    'MSG_CONFIG_FILE_REBUILD_FAILED' => 'config.php kunne ikke blive genopbygget.',

	'LBL_REPAIR_DATABASE' =>'Reparer Database',
	'LBL_REPAIR_DATABASE_DESC' =>'Reparer database baseret p� m�ngde defineret i vardefs (KUN MYSQL)',
	'LBL_REPAIR_DISPLAYSQL' =>'Vis SQL',
	'LBL_REPAIR_DATABASE_TEXT'=>'Dette v�rkt�j tillader dig at opgradere databasen til at matche alle �ndringer lavet i bean vardefs og forholds metadata. <br>Du kan v�lge mellem tre muligheder : <br>Vis SQL vil vise den sql som vil blive eksekveret p� sk�rmen<br> Eksporter SQL vil eksportere den sql til en fil<br> Eksekver SQL vil eksekvere den SQL.',
	'LBL_REPAIR_EXPORTSQL' =>'Eksporter SQL',
	'LBL_REPAIR_EXECUTESQL' =>'Eksekver SQL',





































































	'LBL_SUGAR_UPDATE_TITLE'=>'Sugar Opdateringer',
	'LBL_SUGAR_UPDATE'=>'Tjek for nyeste opdateringer.',
	'LBL_UPDATE_TITLE'=>'Sl� Sugar Opdateringer til:',
	'LBL_UPDATE_CHECK_TYPE'=>'Tjek for opdateringer',
	'LBL_UPDATE_CHECK_AUTO'=>'Automatisk',
	'LBL_UPDATE_CHECK_MANUAL'=>'Manuelt',
	'LBL_CHECK_NOW_TITLE' =>'Tjek Nu',
	'LBL_CHECK_NOW_LABEL' =>'Tjek Nu',
	'LBL_SEND_STAT'=>'Brugs Statistik Rapport sl�et til.',	
	'LBL_CONFIGURE_UPDATER'=>'Konfigurer Sugar Opdateringer',
	'HEARTBEAT_MESSAGE'=>"<BR>N�r dette er sl�et til vil dit system periodisk sende SugarCRM Inc. anonyme statistikker om din installation det vil hj�lpe os  til at forst� brugs m�nstre og forbedre produktet. I geng�ld for denne information, vil administratorer modtage opdaterings p�mindelser n�r der er nye versioner eller opdateringer tilg�ngelige.",
	'LBL_ERROR_VERSION_INFO'=>'Fejl under modtagelse af version information, pr�v venlist igen senere.',
	'LBL_REBUILD_REL_TITLE'=>'Genopbyg Forhold',
	'LBL_REBUILD_REL_DESC'=>'Genopbyg forholds meta data og drop cache filen.',
	'LBL_UPGRADE_CUSTOM_LABELS_TITLE'=>'Opgrader Special M�rker',
	'LBL_UPGRADE_CUSTOM_LABELS_DESC'=>'Opgrader formatet af special felt m�rkerne i alle sprog filerne.',
	'LBL_MASSAGE_MASS_EMAIL'=>'GMT Dato Tids Fix for Sendt Masse Email',
	'LBL_MASSAGE_MASS_EMAIL_DESC'=>'SugarCRM 3.5.1+ kr�ver en opdatering til Mass Email dataen.  Klik "Begynd Opdatering" for at forts�tte.',
	'LBL_PERFORM_UPDATE'=>'Udf�r Opdatering',
	'MSG_INCREASE_UPLOAD_MAX_FILESIZE' => 'Advarsel: Din PHP konfiguration skal skiftes for at tillade filer p� mindst 6MB at blive uploaded.  �nder venligst upload_max_filesize i din php.ini som ligger i',
 	'LBL_CLEAR_CHART_DATA_CACHE_TITLE'=>'Ryd Chart Data Cache',
 	'LBL_CLEAR_CHART_DATA_CACHE_DESC'=>'Fjerner cached data filer brugt af charts.',
        'LBL_REBUILD_HTACCESS'=>'Genopbyg .htaccess fil',
        'LBL_REBUILD_HTACCESS_DESC'=>'Genopbygger .htaccess for at begr�nse adgang til bestemte filer direkte.',

);
?>
