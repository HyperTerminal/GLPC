<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
// $Id: en_us.lang.php,v 1.12 2005/09/14 03:01:09 majed Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Rediger Special Felter',
	'LBL_ADD_FIELD'=> 'Tilf�j Felt:',
	'LBL_MODULE_TITLE' => 'Rediger Special Felter',
	'LBL_MODULE_SELECT' => 'Modul ttil Redigering',
	'LBL_SEARCH_FORM_TITLE' => 'Modul S�gning',
	'COLUMN_TITLE_NAME' => 'Felt Navn',
	'COLUMN_TITLE_LABEL' => 'Felt M�rkat',
	'COLUMN_TITLE_DATA_TYPE' => 'Data Type',
	'COLUMN_TITLE_MAX_SIZE' => 'Maksimum St�rrelse',
	'COLUMN_TITLE_REQUIRED_OPTION' => 'P�kr�vet Felt',
	'COLUMN_TITLE_DEFAULT_VALUE' => 'Standard V�rdi',
	'COLUMN_TITLE_EXT1' => 'Ekstra Meta Felt 1',
	'COLUMN_TITLE_EXT2' => 'Ekstra Meta Felt 2',
	'COLUMN_TITLE_EXT3' => 'Ekstra Meta Felt 3',
	'COLUMN_TITLE_AUDIT' =>'Lydh�r ?',
	'LBL_DROP_DOWN_LIST' => 'Drop Down Liste',
	'MSG_DELETE_CONFIRM' => 'Er du sikker p� at du vil slette denne ting?',
	'POPUP_INSERT_HEADER_TITLE' => 'Tilf�j Special Felt',
	'POPUP_EDIT_HEADER_TITLE' => 'Rediger Special Felt',
	'LNK_SELECT_CUSTOM_FIELD' => 'V�lg Special Felt',
	'LNK_REPAIR_CUSTOM_FIELD' => 'Reparer Special Felter',
);
?>
