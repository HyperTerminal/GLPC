<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.9 2005/08/15 07:46:09 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'RSS',
  'LBL_MODULE_TITLE' => 'RSS: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'RSS Nyheds Feed S�gning',
  'LBL_LIST_FORM_TITLE' => 'RSS Nyheds Feed Liste',
  'LBL_MY_LIST_FORM_TITLE' => 'Mine RSS Nyheds Feeds',
  'LBL_NEW_FORM_TITLE' => 'Ny RSS Nyheds Feed',
//END DON'T CONVERT
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p� at du vil slette denne?',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette kontakten.',
  'LNK_NEW_FEED' => 'Ny RSS Nyheds Feed',
  'LNK_FEED_LIST' => 'Alle RSS Nyheds Feeds',
  'LNK_MY_FEED_LIST' => 'Mine RSS Nyheds Feeds',
  'LBL_TITLE' => 'Titel',
  'LBL_RSS_URL' => "RSS URL",
  'LBL_ONLY_MY'=>"Kun mine favoritter",
  'LBL_VISIT_WEBSITE' => 'bes�g website',
  'LBL_LAST_UPDATED' => 'sidst opdateret',
  'LBL_DELETE_FAVORITES' =>'Slet fra Favoritter',
  'LBL_DELETE_FAV_BUTTON_TITLE' =>'Slet fra favoritter [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' =>'Slet fra favoritter',
  'LBL_ADD_FAV_BUTTON_TITLE' =>'Tilf�j til favoritter [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' =>'[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' =>'Tilf�j til favoritter',
  'LBL_MOVE_UP' =>'Flyt Op',
  'LBL_MOVE_DOWN' => 'Flyt Ned',
  'LBL_FEED_NOT_AVAILABLE'=>'Feed ikke tilg�ngelig',
  'LBL_REFRESH_CACHE'=>'Klik her for at opdatere cachen',
  'LBL_TILE'=>'Titel',
  'LBL_URL'=>'URL',
  'LBL_DESCRIPTION'=>'Beskrivelse',
);


?>
