<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.49 2005/08/15 07:18:06 jacob Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Brugere',
  'LBL_MODULE_TITLE' => 'Brugere: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Bruger S�gning',
  'LBL_LIST_FORM_TITLE' => 'Brugere',
  'LBL_NEW_FORM_TITLE' => 'Ny Bruger',
  'LBL_USER' => 'Brugere:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Genskab standard egenskaber',
  'LBL_TIME_FORMAT' => 'Tids Format:',
  'LBL_DATE_FORMAT' => 'Dato Format:',
  'LBL_TIMEZONE' => 'Nuv�rende Tid:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_LIST_USER_NAME' => 'Bruger Navn',
  'LBL_LIST_DEPARTMENT' => 'Afdeling',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim�r Telefon',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Ny Bruger [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Ny Bruger',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fejl:',
  'LBL_PASSWORD' => 'Kodeord:',
  'LBL_USER_NAME' => 'Bruger Navn:',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_USER_SETTINGS' => 'Bruger Ops�tning',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Sprog:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_USER_INFORMATION' => 'Bruger Information',
  'LBL_OFFICE_PHONE' => 'Kontor Telefon:',
  'LBL_REPORTS_TO' => 'Rapporterer til:',
  'LBL_REPORTS_TO_NAME' => 'Rapporterer til:',
  'LBL_OTHER_PHONE' => 'Anden telefon:',
  'LBL_OTHER_EMAIL' => 'Anden Email:',
  'LBL_NOTES' => 'Noter:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_STATUS' => 'Status:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Tilf�ldig Telefon:',
  'LBL_ANY_EMAIL' => 'Tilf�ldig Email:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Navn:',
  'LBL_MOBILE_PHONE' => 'Mobilnummer:',
  'LBL_OTHER' => 'Andet:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMAIL_OTHER' => 'Email 2:',
  'LBL_HOME_PHONE' => 'Hjemme telefon:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
  'LBL_PRIMARY_ADDRESS' => 'Prim�r Adresse:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Skift Kodeord [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Skift Kodeord',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Skift kodeord',
  'LBL_OLD_PASSWORD' => 'Gamle kodeord:',
  'LBL_NEW_PASSWORD' => 'Nye kodeord:',
  'LBL_CONFIRM_PASSWORD' => 'Godkend kodeord:',
  'LBL_EMPLOYEE_STATUS' => 'Medarbejder Status:',
  'LBL_MESSENGER_TYPE' => 'IM Type:',
  'LBL_MESSENGER_ID' => 'IM Navn:',
  'ERR_ENTER_OLD_PASSWORD' => 'Indtast venligst dit gamle kodeord.',
  'ERR_ENTER_NEW_PASSWORD' => 'Indtast venligst dit nye kodeord.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Indtast venligst din kodeords godkendelse.',
  'ERR_REENTER_PASSWORDS' => 'Gen-indtast venligst Kordeord. \\"nyt kodeord\\" og \\"Godkend kordeord\\" felterne er ikke det samme.',
  'ERR_INVALID_PASSWORD' => 'Du skal specificere et gyldigt brugernavn og kodeord.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Bruger kodeords �ndring mislykkedes for ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' mislykkedes. Det nye kordeord skal skrives.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'Forkert gammelt kodeord for $this->user_name. Gen-indtast kodeords information.',
  'ERR_USER_NAME_EXISTS_1' => 'Brugernavnet ',
  'ERR_USER_NAME_EXISTS_2' => ' Eksisterer allerede.  Dobbelte brugernavne er ikke tilladt.  Skift brugernavnet.',
  'ERR_LAST_ADMIN_1' => 'Brugernavnet "',
  'ERR_LAST_ADMIN_2' => '" er den sidste bruge med administrator adgang.  Minds �n bruger skal v�re en administrator.',
  'LNK_NEW_USER' => 'Opret Bruger',
  'LNK_USER_LIST' => 'Brugere',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette kontoen.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Tildelings Notifikation:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Modtag en e-mail notifikation n�r data bliver tildelt til dig.',
  'LBL_ADMIN_TEXT' => 'Giver administrator rettigheder til denne',
  'LBL_PORTAL_ONLY' => 'Kun Portal Bruger:',
  'LBL_PORTAL_ONLY_TEXT' => 'Brugeren er portal bruger og kan ikke logge ind gennem SugarCRM webinterfacet. Denne bruger er kun brugt til portal webservices. Normale brugere kan ikke blive brugt til portal webservices.',
  'LBL_TIME_FORMAT_TEXT' => 'S�t display formatet for tids afm�rkninger',
  'LBL_DATE_FORMAT_TEXT' => 'S�t display formatet for dato afm�rkninger',
  'LBL_TIMEZONE_TEXT' => 'S�t den nuv�rende tid',
  'LBL_GRIDLINE' => 'Vis Gridlines:',
  'LBL_GRIDLINE_TEXT' => 'Kontrolerer gridlines i detaljeret',
  'LBL_CURRENCY_TEXT' => 'V�lg standard valuta',
  'LBL_DISPLAY_TABS'=>'Vis Faner',
  'LBL_HIDE_TABS'=>'Skjul Faner',
  'LBL_EDIT_TABS'=>'Rediger Faner',
  'LBL_REMOVED_TABS'=>'Admin Fjen Faner',
  'LBL_CHOOSE_WHICH'=>'V�lg hvilke faner der skal vises',








  'LBL_MAIL_OPTIONS_TITLE' => 'E-mail Ops�tning',
  'LBL_MAIL_FROMNAME' => '"Fra" Navn:',
  'LBL_MAIL_FROMADDRESS' => '"Fra" Adresse:',
  'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
  'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
  'LBL_MAIL_SENDTYPE' => 'Mail Overf�rsels Agent:',
  'LBL_MAIL_SMTPUSER' => 'SMTP Brugernavn:',
  'LBL_MAIL_SMTPPASS' => 'SMTP Kodeord:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Brug SMTP Godkendelse?',
  'LBL_CALENDAR_OPTIONS'=>'Kalender Ops�tning',
  'LBL_PUBLISH_KEY'=>'Udgiv N�gle:',
  'LBL_CHOOSE_A_KEY'=>'V�lg en n�gle for at forhindre uautoriserede at udgive din kalender',
  'LBL_YOUR_PUBLISH_URL'=>'Udgiv p� mit sted:',
  'LBL_YOUR_QUERY_URL'=>'Din Query URL:',
  'LBL_REMINDER'=>'Standard P�minder:',
  'LBL_REMINDER_TEXT'=>'Standard tid til at p�minde en person op et kommende opkald eller m�de',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'V�lg markerede brugere',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'V�lg markerede brugere',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_MAX_TAB' => 'Antal faner der skal vises:',
  'LBL_SEARCH_URL'=>'S�ge sted:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Brugere',
  'LBL_ADDRESS_STREET' => 'Adresse Vej:',
  'LBL_ADDRESS_CITY' => 'Adresse By:',
  'LBL_ADDRESS_COUNTRY' => 'Adresse Land:',
  'LBL_ADDRESS_STATE' => 'Adresse Stat:',
  'LBL_ADDRESS_POSTALCODE' => 'Adresse Postnummer:',
  'LBL_OFFICE_PHONE' => 'Kontor Telefon:',
  'LBL_ANY_PHONE' => 'Tilf�ldig Telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_MOBILE_PHONE' => 'Mobilnummer:',
  'LBL_WORK_PHONE' => 'Arbejds Telefon:',
  'LBL_HOME_PHONE' => 'Hjemme Telefon:',
  'LBL_OTHER_PHONE' => 'Anden Telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_IS_ADMIN' => 'Er Administrator',
);
?>
