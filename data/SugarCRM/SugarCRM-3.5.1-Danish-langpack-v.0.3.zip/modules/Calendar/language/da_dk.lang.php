<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.19 2005/07/25 07:23:07 clint Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'=>'Kalender',
  'LBL_MODULE_TITLE'=>'Kalender',
  'LNK_NEW_CALL' => 'Skemal�g Opkald',
  'LNK_NEW_MEETING' => 'Skemal�g M�de',
  'LNK_NEW_APPOINTMENT' => 'Opret Aftale',
  'LNK_NEW_TASK' => 'Opret Opgave',
  'LNK_CALL_LIST' => 'Opkald',
  'LBL_CONTACTS' => 'Kontakter:',
  'LNK_MEETING_LIST' => 'M�der',
  'LNK_TASK_LIST' => 'Opgaver',
  'LNK_VIEW_CALENDAR' => 'Idag',
  'LBL_MONTH' => 'M�ned',
  'LBL_DAY' => 'Dag',
  'LBL_YEAR' => '�r',
  'LBL_WEEK' => 'Uge',
  'LBL_PREVIOUS_MONTH' => 'Sidste M�ned',
  'LBL_PREVIOUS_DAY' => 'Sidste Dag',
  'LBL_PREVIOUS_YEAR' => 'Sidste �r',
  'LBL_PREVIOUS_WEEK' => 'Sidste Uge',
  'LBL_NEXT_MONTH' => 'N�ste M�ned',
  'LBL_NEXT_DAY' => 'N�ste Dag',
  'LBL_NEXT_YEAR' => 'N�ste �r',
  'LBL_NEXT_WEEK' => 'N�ste Uge',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Skemalagt',
  'LBL_BUSY' => 'Optaget',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'Bruger Kalendere',
  'LBL_SHARED' => 'Delt',
  'LBL_PREVIOUS_SHARED' => 'Forrige',
  'LBL_NEXT_SHARED' => 'N�ste',
  'LBL_SHARED_CAL_TITLE' => 'Delt Kalender',
  'LBL_USERS' => 'Bruger',
  'LBL_REFRESH' => 'Opdater',
  'LBL_EDIT' => 'Rediger',
  'LBL_SELECT_USERS' => 'V�lg brugere til kalender display',
  'LBL_FILTER_BY_TEAM' => 'Filtrer bruger liste via hold:',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"S�n",
"Man",
"Tir",
"Ons",
"Tor",
"Fre",
"L�r",
),
'dom_cal_weekdays_long'=>array(
"S�ndag",
"Mandag",
"Tirsdag",
"Onsdag",
"Torsdag",
"Fredag",
"L�rdag",
),
'dom_cal_month'=>array(
"",
"Jan",
"Feb",
"Mar",
"Apr",
"Maj",
"Jun",
"Jul",
"Aug",
"Sep",
"Okt",
"Nov",
"Dec",
),
'dom_cal_month_long'=>array(
"",
"Januar",
"Februar",
"Marts",
"April",
"Maj",
"Juni",
"Juli",
"August",
"September",
"Oktober",
"November",
"December",
)
);
?>
