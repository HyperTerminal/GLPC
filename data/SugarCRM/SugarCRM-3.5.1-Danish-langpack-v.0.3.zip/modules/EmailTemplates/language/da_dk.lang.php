<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /var/cvsroot/sugarcrm/modules/EmailTemplates/language/en_us.lang.php,v 1.10 2005/08/03 17:56:13 jgreen Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Email Skabeloner',
  'LBL_MODULE_TITLE' => 'Email Skabeloner: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Email Skabelon S�gning',
  'LBL_LIST_FORM_TITLE' => 'Email Skabelon Liste',
  'LBL_NEW_FORM_TITLE' => 'Opret Email Skabelon',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_DESCRIPTION' => 'Beskrivelse',
  'LBL_LIST_DATE_MODIFIED' => 'Sidst Rettet',
  'LBL_NAME' => 'Navn:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_SUBJECT' => 'Overskrift:',
  'LBL_CLOSE' => 'Luk:',
  'LBL_RELATED_TO' => 'Relateret Til:',
  'LBL_BODY' => 'Body:',
  'LBL_PUBLISH' => 'Udgiv:',
  'LBL_COLON' => ':',

'LNK_NEW_EMAIL_TEMPLATE'=>'Opret Email Skabelon',
'LNK_EMAIL_TEMPLATE_LIST'=>'Email Skabeloner',
'LNK_IMPORT_NOTES'=>'Importer Noter',
'LNK_VIEW_CALENDAR' => 'Idag',
'LNK_CHECK_EMAIL'=>'Tjek Mail',
'LNK_NEW_SEND_EMAIL'=>'Skriv Email',
'LNK_ARCHIVED_EMAIL_LIST'=>'Arkiverede Emails',
'LNK_SENT_EMAIL_LIST'=>'Sendte Emails',
'LNK_NEW_EMAIL'=>'Arkiver Email',
'LBL_INSERT_VARIABLE'=>'Inds�t Variabel:',
'LBL_INSERT'=>'Inds�t',
'LNK_DRAFTS_EMAIL_LIST'=>'Draft',
'LNK_ALL_EMAIL_LIST'=>'Alle Emails',
'LNK_NEW_ARCHIVE_EMAIL'=>'Opret Arkiveret Email',
'LBL_CONTACT_AND_OTHERS'=>'Kontakt/Ledelse/Prospekt',
'LBL_HTML_BODY'=>'HTML Body',
'LBL_TEXT_BODY'=>'Tekst Body',
'LBL_EDIT_ALT_TEXT'=>'Rediger Alternativ Text',
'LBL_SHOW_ALT_TEXT'=>'Vis Alternativ Text',


 





);


?>
