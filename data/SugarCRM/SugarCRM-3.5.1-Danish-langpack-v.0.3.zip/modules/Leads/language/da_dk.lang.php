<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
********************************************************************************/
/*********************************************************************************
* $Id: en_us.lang.php,v 1.31 2005/09/18 19:18:03 chris Exp $
* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributor(s): ______________________________________..
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
    'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
    //END DON'T CONVERT
    'ERR_DELETE_RECORD' => 'da_dk Et data nummer skal v�re specificeret for at slette emnet.',
    'LBL_ACCOUNT_DESCRIPTION'=> 'Konto Beskrivelse',
    'LBL_ACCOUNT_ID'=>'Konto ID',
    'LBL_ACCOUNT_NAME' => 'Konto Navn:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
    'LBL_ADD_BUSINESSCARD' => 'Tilf�j Forretnings Kort',
    'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
    'LBL_ALT_ADDRESS_CITY' => 'Alternativ Adresse By',
    'LBL_ALT_ADDRESS_COUNTRY' => 'Alternativ Adresse Land',
    'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternativ Adresse Postnummer',
    'LBL_ALT_ADDRESS_STATE' => 'Alternativ Adresse Stat',
    'LBL_ALT_ADDRESS_STREET_2' => 'Alternativ Adresse Vej 2',
    'LBL_ALT_ADDRESS_STREET_3' => 'Alternativ Adresse Vej 3',
    'LBL_ALT_ADDRESS_STREET' => 'Alternativ Adresse Vej',
    'LBL_ALTERNATE_ADDRESS' => 'Anden Adresse:',
    'LBL_ANY_ADDRESS' => 'Tilf�ldig Adresse:',
    'LBL_ANY_EMAIL' => 'Tilf�ldig Email:',
    'LBL_ANY_PHONE' => 'Tilf�ldig Telefon:',
    'LBL_ASSIGNED_TO_NAME' => 'Tildelt Til Navn',
    'LBL_BACKTOLEADS' => 'Tilbage Til Emne',
    'LBL_BUSINESSCARD' => 'Konvert�r Emne',
    'LBL_CITY' => 'By:',
    'LBL_CONTACT_ID' => 'Kontakt ID',
    'LBL_CONTACT_INFORMATION' => 'Emne Information',
    'LBL_CONTACT_NAME' => 'Emne Navn:',
    'LBL_CONTACT_OPP_FORM_TITLE' => 'Emne-Mulighed:',
    'LBL_CONTACT_ROLE' => 'Rolle:',
    'LBL_CONTACT' => 'Emne:',
    'LBL_CONVERTED_ACCOUNT'=>'Konverteret Konto:',
    'LBL_CONVERTED_CONTACT' => 'Konverteret Kontakt:',
    'LBL_CONVERTED_OPP'=>'Konverteret Mulighed:',
    'LBL_CONVERTED'=> 'Konverteret',
    'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
    'LBL_CONVERTLEAD_TITLE' => 'Konvert�r Emne [Alt+V]',
    'LBL_CONVERTLEAD' => 'Konvert�r Emne',
    'LBL_COUNTRY' => 'Land:',
    'LBL_CREATED_ACCOUNT' => 'Oprettet en ny konto',
    'LBL_CREATED_CALL' => 'Oprettet et nyt opkald',
    'LBL_CREATED_CONTACT' => 'Oprettet en ny kontakt',
    'LBL_CREATED_MEETING' => 'Oprettet et nyt m�de',
    'LBL_CREATED_OPPORTUNITY' => 'Oprettet en ny mulighed',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Emner',
    'LBL_DEPARTMENT' => 'Afdeling:',
    'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelses Information',
    'LBL_DESCRIPTION' => 'Beskrivelse:',
    'LBL_DO_NOT_CALL' => 'Kald ikke op:',
    'LBL_DUPLICATE' => 'Lignende Emner',
    'LBL_EMAIL_ADDRESS' => 'Email:',
    'LBL_EMAIL_OPT_OUT' => 'Email Opt Ud:',
    'LBL_EXISTING_ACCOUNT' => 'Brugt en eksisterende konto',
    'LBL_EXISTING_CONTACT' => 'Brugt en eksisterende konto',
    'LBL_EXISTING_OPPORTUNITY' => 'Brugt en eksisterende mulighed',
    'LBL_FAX_PHONE' => 'Fax:',
    'LBL_FIRST_NAME' => 'Fornavn:',
    'LBL_FULL_NAME' => 'Fulde navn:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
    'LBL_HOME_PHONE' => 'Hjemme Telefon:',
    'LBL_IMPORT_VCARD' => 'Importer vCard',
    'LBL_IMPORT_VCARDTEXT' => 'Opret automatisk en nyt emne ved at importere et vCard fra dit fil system.',
    'LBL_INVALID_EMAIL'=>'Ugyldig Email:',
    'LBL_INVITEE' => 'Direkte Rapporter',
    'LBL_LAST_NAME' => 'Efternavn:',
    'LBL_LEAD_SOURCE_DESCRIPTION' => 'Ledende Kilde Beskrivelse:',
    'LBL_LEAD_SOURCE' => 'Ledende Kilde:',
    'LBL_LIST_ACCOUNT_NAME' => 'Konto Navn',
    'LBL_LIST_CONTACT_NAME' => 'Emne Navn',
    'LBL_LIST_CONTACT_ROLE' => 'Rolle',
    'LBL_LIST_DATE_ENTERED' => 'Dato Oprettet',
    'LBL_LIST_EMAIL_ADDRESS' => 'Email',
    'LBL_LIST_FIRST_NAME' => 'Fornavn',
    'LBL_LIST_FORM_TITLE' => 'Emne Liste',
    'LBL_LIST_LAST_NAME' => 'Efternavn',
    'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Ledende Kilde Beskrivelse',
    'LBL_LIST_LEAD_SOURCE' => 'Ledende Kilde',
    'LBL_LIST_MY_LEADS' => 'Mine Emner',
    'LBL_LIST_NAME' => 'Navn',
    'LBL_LIST_PHONE' => 'Kontor Telefon',
    'LBL_LIST_REFERED_BY' => 'Refereret Af',
    'LBL_LIST_STATUS' => 'Status',
    'LBL_LIST_TITLE' => 'Titel',
    'LBL_MOBILE_PHONE' => 'Mobilnummer:',
    'LBL_MODULE_NAME' => 'Emner',
    'LBL_MODULE_TITLE' => 'Emner: Hjem',
    'LBL_NAME' => 'Navn:',
    'LBL_NEW_FORM_TITLE' => 'Nyt Emne',
    'LBL_NEW_PORTAL_PASSWORD' => 'Nyt Portal Kodeord:',
    'LBL_OFFICE_PHONE' => 'Kontor Telefon:',
    'LBL_OPP_NAME' => 'Muligheds Navn:',
    'LBL_OPPORTUNITY_AMOUNT' => 'Muligheds M�ngde:',
    'LBL_OPPORTUNITY_ID'=>'Muligheds ID',
    'LBL_OPPORTUNITY_NAME' => 'Muligheds Navn:',
    'LBL_OTHER_EMAIL_ADDRESS' => 'Anden Email:',
    'LBL_OTHER_PHONE' => 'Anden Telefon:',
    'LBL_PHONE' => 'Telefon:',
    'LBL_PORTAL_ACTIVE' => 'Portal Aktiv:',
    'LBL_PORTAL_APP'=> 'Portal Applikation',
    'LBL_PORTAL_INFORMATION' => 'Portal Information',
    'LBL_PORTAL_NAME' => 'Portal Navn:',
    'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Kodeord er Sat:',
    'LBL_POSTAL_CODE' => 'Postnummer:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Prim�r Adresse By',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Prim�r Adresse Land',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Prim�r Adresse Postnummer',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Prim�r Adresse Stat',
    'LBL_PRIMARY_ADDRESS_STREET_2'=>'Prim�r Adresse Vej 2',
    'LBL_PRIMARY_ADDRESS_STREET_3'=>'Prim�r Adresse Vej 3',   
    'LBL_PRIMARY_ADDRESS_STREET' => 'Prim�r Adresse Vej',
    'LBL_PRIMARY_ADDRESS' => 'Prim�r Adresse:',
    'LBL_REFERED_BY' => 'Refereret Af:',
    'LBL_REPORTS_TO_ID'=>'Rapporterer Til ID',
    'LBL_REPORTS_TO' => 'Rapporterer Til:',
    'LBL_SALUTATION' => 'Tiltale',
    'LBL_SEARCH_FORM_TITLE' => 'Emne S�gning',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'V�lg Markerede Emner',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'V�lg Markerede Emner',
    'LBL_STATE' => 'Stat:',
    'LBL_STATUS_DESCRIPTION' => 'Status Beskrivelse:',
    'LBL_STATUS' => 'Status:',
    'LBL_TITLE' => 'Titel:',
    'LNK_IMPORT_VCARD' => 'Opret Fra vCard',
    'LNK_LEAD_LIST' => 'Emner',
    'LNK_NEW_ACCOUNT' => 'Opret Konto',
    'LNK_NEW_APPOINTMENT' => 'Opret aftale',
    'LNK_NEW_CONTACT' => 'Opret kontakt',
    'LNK_NEW_LEAD' => 'Opret Emne',
    'LNK_NEW_NOTE' => 'Opret Note eller vedh�ftning',
    'LNK_NEW_OPPORTUNITY' => 'Opret mulighed',
    'LNK_SELECT_ACCOUNT' => 'Select konto',
    'MSG_DUPLICATE' => 'Lignende emner er blevet fundet. Tjek venligst boksen med emner du �nsker at associere med data der vil blive oprettet fra denne konvertering. N�r du er f�rdig, tryk n�ste.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopier alternativ adresse til prim�r adresse',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Kopier prim�r adresse til alternativ adresse',
    'NTC_DELETE_CONFIRMATION' => 'Er du sikker p� at du vil slette denne?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Oprettelse af en mulighed kr�ver en konto.\n Opret enten en ny eller v�lg en eksisterende.',
    'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p� at du vil fjerne dette emne fra denne sag?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne som en direkte rapport?',
);


?>
