<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.14 2005/02/09 07:08:54 andrew Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'Valutaer',
  'LBL_CURRENCY' => 'Valuta',
  'LBL_ADD' => 'Tilf�j',
  'LBL_MERGE' => 'Bland',
  'LBL_MERGE_TXT' => 'Mark�r venligst de valutaer som du gerne vil knytte til den valgte kurs. Dette vil slette alle de valutaer med en markering og tildele et tilf�ldigt antal associeret med dem til den valte kurs.',
  'LBL_US_DOLLAR' => 'U.S. Dollar',
  'LBL_DELETE' => 'Slet',
  'LBL_LIST_SYMBOL' => 'Valuta Symbol',
  'LBL_LIST_NAME' => 'Valuta Navn',
  'LBL_LIST_ISO4217' => 'ISO 4217 Kode',
  'LBL_UPDATE' => 'Opdater',
  'LBL_LIST_RATE' => 'Konverterings Rate',
  'LBL_LIST_STATUS' => 'Status',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny Konto',
  'LNK_NEW_OPPORTUNITY' => 'Ny Mulighed',
  'LNK_NEW_CASE' => 'Ny Sag',
  'LNK_NEW_NOTE' => 'Opret Note eller Vedh�ftning',
  'LNK_NEW_CALL' => 'Nyt Opkald',
  'LNK_NEW_EMAIL' => 'Ny Email',
  'LNK_NEW_MEETING' => 'Nyt M�de',
  'LNK_NEW_TASK' => 'Opret Opgave',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p� at du vil slette denne? Det kan v�re bedre at s�tte status til inaktiv ellers kan andre ting som bruger denne kurs blive konverteret til U.S. Dollars n�r de bliver tilg�et.',
  'currency_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
);


?>
