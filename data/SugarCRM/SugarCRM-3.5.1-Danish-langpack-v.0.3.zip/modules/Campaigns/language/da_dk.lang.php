<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.13 2005/09/12 22:00:52 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kampagner',
  'LBL_MODULE_TITLE' => 'Kampagner: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Kampagner S�g',
  'LBL_LIST_FORM_TITLE' => 'Kampagner Liste',
  'LBL_CAMPAIGN_NAME' => 'Navn:',
  'LBL_CAMPAIGN' => 'Kampagner:',
  'LBL_NAME' => 'Navn: ',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_LIST_CAMPAIGN_NAME' => 'Kampagner',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_LIST_END_DATE' => 'Slut Dato',
  'LBL_DATE_ENTERED' => 'Dato Indtastet',
  'LBL_DATE_MODIFIED' => 'Dato Rettet',
  'LBL_MODIFIED' => 'Rettet af: ',
  'LBL_CREATED' => 'Oprettet af: ',
  'LBL_TEAM' => 'Hold: ',
  'LBL_ASSIGNED_TO' => 'Tildelt til: ',
  'LBL_CAMPAIGN_START_DATE' => 'Start Dato: ',
  'LBL_CAMPAIGN_END_DATE' => 'Slut Dato: ',
  'LBL_CAMPAIGN_STATUS' => 'Status: ',
  'LBL_CAMPAIGN_BUDGET' => 'Budget: ',
  'LBL_CAMPAIGN_EXPECTED_COST' => 'Forventet Kost: ',
  'LBL_CAMPAIGN_ACTUAL_COST' => 'Faktiske Kost: ',
  'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Forventet Indtjening: ',
  'LBL_CAMPAIGN_TYPE' => 'Type: ',
  'LBL_CAMPAIGN_OBJECTIVE' => 'M�l: ',
  'LBL_CAMPAIGN_CONTENT' => 'Beskrivelse: ',
  'LNK_NEW_CAMPAIGN' => 'Opret Kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagner',
  'LNK_NEW_PROSPECT' => 'Opret Prospekt',
  'LNK_PROSPECT_LIST' => 'Prospekter',
  'LNK_NEW_PROSPECT_LIST' => 'Opret Prospekt Liste',
  'LNK_PROSPECT_LIST_LIST' => 'Prospekt Lister',
  'LBL_MODIFIED_BY' => 'Rettet af: ',
  'LBL_CREATED_BY' => 'Oprettet af: ',
  'LBL_DATE_CREATED' => 'Oprettet dato: ',
  'LBL_DATE_LAST_MODIFIED' => 'Rettet dato: ',
  'LBL_TRACKER_KEY' => 'Sporer: ',
  'LBL_TRACKER_URL' => 'Sporer URL: ',
  'LBL_TRACKER_TEXT' => 'Sporer Link Tekst: ',
  'LBL_TRACKER_COUNT' => 'Sporer Antal: ',
  'LBL_REFER_URL' => 'Sporer Omdirigering URL: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kampagner',
  'LBL_EMAIL_CAMPAIGNS_TITLE' =>'Email Kampagner',

	'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => 'Prospekt Lister',
	'LBL_EMAIL_MARKETING_SUBPANEL_TITLE' => 'Email Marketing',
);


?>
