<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.36 2005/02/25 01:59:36 julian Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Opgaver',
  'LBL_TASK' => 'Opgaver: ',
  'LBL_MODULE_TITLE' => ' Opgaver: Hjem',
  'LBL_SEARCH_FORM_TITLE' => ' Opgave S�gning',
  'LBL_LIST_FORM_TITLE' => ' Opgave Liste',
  'LBL_NEW_FORM_TITLE' => ' Opret Opgave',
  'LBL_NEW_FORM_SUBJECT' => 'Overskrift:',
  'LBL_NEW_FORM_DUE_DATE' => 'Ved Dato:',
  'LBL_NEW_FORM_DUE_TIME' => 'Ved Tid:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Luk',
  'LBL_LIST_SUBJECT' => 'Overskrift',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_PRIORITY' => 'Prioritet',
  'LBL_LIST_RELATED_TO' => 'Relateret til',
  'LBL_LIST_DUE_DATE' => 'Ved Date',
  'LBL_LIST_DUE_TIME' => 'Ved Tid',
  'LBL_SUBJECT' => 'Overskrift:',
  'LBL_STATUS' => 'Status:',
  'LBL_DUE_DATE' => 'Ved Dato:',
  'LBL_DUE_TIME' => 'Ved Tid:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Ved Dato & Tid:',
  'LBL_START_DATE_AND_TIME' => 'Start Dato & Tid:',
  'LBL_START_DATE' => 'Start Dato:',
  'LBL_START_TIME' => 'Start Tid:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'ingen',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelses Information',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_NAME' => 'Navn:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn: ',
  'LBL_LIST_COMPLETE' => 'Udf�rt:',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_DATE_DUE_FLAG' => 'Ingen Ved Dato',
  'LBL_DATE_START_FLAG' => 'Ingen Start Dato',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette kontakten.',
  'ERR_INVALID_HOUR' => 'Indskriv venligst en tid mellem 0 and 24',
  'LBL_DEFAULT_STATUS' => 'Ikke Startet',
  'LBL_DEFAULT_PRIORITY' => 'Medium',
  'LBL_LIST_MY_TASKS' => 'Mine �bne Opgaver',
  'LNK_NEW_CALL' => 'Skemal�g Opkald',
  'LNK_NEW_MEETING' => 'Skemal�g M�de',
  'LNK_NEW_TASK' => 'Opret Opgave',
  'LNK_NEW_NOTE' => 'Opret Note eller Vedh�ftning',
  'LNK_NEW_EMAIL' => 'Arkiver Email',
  'LNK_CALL_LIST' => 'Opkald',
  'LNK_MEETING_LIST' => 'M�der',
  'LNK_TASK_LIST' => 'Opgaver',
  'LNK_NOTE_LIST' => 'Noter',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Idag',
  'LBL_CONTACT_FIRST_NAME'=>'Kontakt Fornavn',
  'LBL_CONTACT_LAST_NAME'=>'Kontakt Efternavn',
);


?>
