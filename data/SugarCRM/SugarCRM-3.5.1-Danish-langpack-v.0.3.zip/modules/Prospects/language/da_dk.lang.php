<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.7 2005/07/28 20:50:12 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Prospekter',
  'LBL_INVITEE' => 'Direkte Rapporter',
  'LBL_MODULE_TITLE' => 'Prospekter: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Prospekt S�gning',
  'LBL_LIST_FORM_TITLE' => 'Prospekt Liste',
  'LBL_NEW_FORM_TITLE' => 'Ny Prospekt',
  'LBL_PROSPECT' => 'Prospekt:',
  'LBL_BUSINESSCARD' => 'Forretnings Kort',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_LIST_PROSPECT_NAME' => 'Prospekt Navn',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Anden Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_PROSPECT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'Fornavm',
  'LBL_ASSIGNED_TO_NAME'=>'Tildelt Til Navn',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_PROSPECT' => 'Brugt en eksisterende kontakt',
  'LBL_CREATED_PROSPECT' => 'Oprettet en ny kontakt',
  'LBL_EXISTING_ACCOUNT' => 'Brugt en eksisterende konto',
  'LBL_CREATED_ACCOUNT' => 'Oprettet en ny konto',
  'LBL_CREATED_CALL' => 'Oprettet et nyt opkald',
  'LBL_CREATED_MEETING' => 'Oprettet et nyt m�de',
  'LBL_ADDMORE_BUSINESSCARD' => 'Tilf�j et forretnings kort',
  'LBL_ADD_BUSINESSCARD' => 'Indskriv forretnings kort',
  'LBL_NAME' => 'Navn:',
  'LBL_PROSPECT_NAME' => 'Prospekt Navn:',
  'LBL_PROSPECT_INFORMATION' => 'Prospekt Information',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_OFFICE_PHONE' => 'Kontor telefon:',
  'LBL_ACCOUNT_NAME' => 'Konto navn:',
  'LBL_ANY_PHONE' => 'Tilf�ldig telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_MOBILE_PHONE' => 'Mobilnummer:',
  'LBL_HOME_PHONE' => 'Hjem:',
  'LBL_OTHER_PHONE' => 'Anden Telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Prim�r Adresse Vej:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Prim�r Adresse By:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Prim�r Adresse Land:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Prim�r Adresse Stat:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Prim�r Adresse Postnummer:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternativ Adresse Vej:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternativ Adresse By:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternativ Adresse Land:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternativ Adresse Stat:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternativ Adresse Postnummer:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_BIRTHDATE' => 'F�dselsdag:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Anden Email:',
  'LBL_ANY_EMAIL' => 'Tilf�ldig Email:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Assistent Telefon:',
  'LBL_DO_NOT_CALL' => 'Kald ikke op:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Ud:',
  'LBL_PRIMARY_ADDRESS' => 'Prim�r Adresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Anden Adress:',
  'LBL_ANY_ADDRESS' => 'Tilf�ldig Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelses Information',
  'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_PROSPECT_ROLE' => 'Rolle:',
  'LBL_OPP_NAME' => 'Muligheds Navn:',
  'LBL_IMPORT_VCARD' => 'Importer vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatisk opret en ny kontakt ved at importere et vCard fra dit fil system.',
  'LBL_DUPLICATE' => 'Mulige Duplikant Prospekter',
  'MSG_SHOW_DUPLICATES' => 'Oprettelse af denne kontakt kan potentielt oprette en duplikant kontakt. Du kan enten klikke p� Opret Prospekt for at forts�tte med at oprette denne nye kontakt med de f�r indtastede data eller du kan klikke Cancel.',
  'MSG_DUPLICATE' => 'Oprettelse af denne kontakt kan potentielt oprette en duplikant kontakt. Du kan enten v�lge en kontakt fra listen nedenunder eller du kan klikke p� Opret Prospekt for at forts�tte med oprettelse af en ny kontakt med med de f�r indtastede data.',
  'LNK_PROSPECT_LIST' => 'Prospekter',
  'LNK_IMPORT_VCARD' => 'Opret Fra vCard',
  'LNK_NEW_PROSPECT' => 'Opret Prospekt',
  'LNK_NEW_ACCOUNT' => 'Opret Konto',
  'LNK_NEW_OPPORTUNITY' => 'Opret Mulighed',
  'LNK_NEW_CASE' => 'Opret Sag',
  'LNK_NEW_NOTE' => 'Opret Note eller Vedh�ftning',
  'LNK_NEW_CALL' => 'Skemal�g Opkald',
  'LNK_NEW_EMAIL' => 'Arkiver Email',
  'LNK_NEW_MEETING' => 'Skemal�g M�de',
  'LNK_NEW_TASK' => 'Opret Opgave',
  'LNK_NEW_APPOINTMENT' => 'Opret Aftale',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikekr p� at du vil slette denne?',
  'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne kontakt fra denne sag?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne som en direkte rapport?',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette kontakten.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'kopier prim�r adresse til alternativ adresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'kopier alternativ adresse til prim�r adresse',
  'LBL_SALUTATION' => 'Tiltale',
  'LBL_SAVE_PROSPECT' => 'Gem Prospekt',
  'LBL_CREATED_OPPORTUNITY' =>'Oprettet en my mulighed',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Oprettelse af en mulighed kr�ver en konto.\n Opret enten en ny eller v�lg en eksisterende.',
  'LNK_SELECT_ACCOUNT' => "V�lg Konto",
  'LNK_NEW_PROSPECT' => 'Opret Prospekt',
  'LNK_PROSPECT_LIST' => 'Prospekter',  
  'LNK_NEW_CAMPAIGN' => 'Opret Kampagner',
  'LNK_CAMPAIGN_LIST' => 'Kampagner',
  'LNK_NEW_PROSPECT_LIST' => 'Opret Prospekt Liste',
  'LNK_PROSPECT_LIST_LIST' => 'Prospekt Lister',
  'LNK_IMPORT_PROSPECT' => 'Importer Prospekter',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'V�lg Markerede Prospekter',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'V�lg Markerede Prospekter',
  'LBL_INVALID_EMAIL'=>'Ugyldig Email:',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Prospekter',
);


?>
