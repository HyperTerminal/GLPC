<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.41 2005/09/12 22:00:52 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kunder',
  'LBL_MODULE_TITLE' => 'Kunder: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Kunde S�gning',
  'LBL_LIST_FORM_TITLE' => 'Kunde Liste',
  'LBL_NEW_FORM_TITLE' => 'Ny Kunde',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Medlems Organisationer',
  'LBL_BUG_FORM_TITLE' => 'Kunder',
  'LBL_LIST_ACCOUNT_NAME' => 'Kunde Navn',
  'LBL_LIST_CITY' => 'By',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Land',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email Adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_BILLING_ADDRESS_STREET_2' =>'Betalings Adresse Vej 2',
  'LBL_BILLING_ADDRESS_STREET_3' =>'Betalings Adresse Vej 3',
  'LBL_BILLING_ADDRESS_STREET_4' =>'Betalings Adresse Vej 4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Modtager Adresse Vej 2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Modtager Adresse Vej 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Modtager Adresse Vej 4',
  
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Kunde Information',
  'LBL_ACCOUNT' => 'Kunde:',
  'LBL_ACCOUNT_NAME' => 'Kunde Navn:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_PHONE_ALT' => 'Alternativ telefon:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Ticker Symbol:',
  'LBL_OTHER_PHONE' => 'Anden telefon:',
  'LBL_ANY_PHONE' => 'Tilf�ldig telefon:',
  'LBL_MEMBER_OF' => 'Medlem af:',
  'LBL_PHONE_OFFICE' => 'Telefon Kontor:',
  'LBL_PHONE_FAX' => 'Telefon Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Medarbejdere:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Anden Email:',
  'LBL_ANY_EMAIL' => 'Tilf�ldig Email:',
  'LBL_OWNERSHIP' => 'Ejerskab:',
  'LBL_RATING' => 'Rating:',
  'LBL_INDUSTRY' => 'Industri:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => '�rlig Indkomst:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
  'LBL_BILLING_ADDRESS' => 'Betalings Adresse:',
  'LBL_BILLING_ADDRESS_STREET' => 'Betalings Adresse Vej:',
  'LBL_BILLING_ADDRESS_CITY' => 'Betalings Adresse By:',
  'LBL_BILLING_ADDRESS_STATE' => 'Betalings Adresse Stat:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Betalings Adresse Postnummer:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Betalings Adresse Land:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Modtager Adresse Vej:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Modtager Adresse By:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Modtager Adresse Stat:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Modtager Adresse Postnummer:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Modtager Adresse Land:',
  'LBL_SHIPPING_ADDRESS' => 'Modtager Adresse:',
  'LBL_DATE_MODIFIED' => 'Dato Rettet:',
  'LBL_DATE_ENTERED' => 'Dato Indskrevet:',
  'LBL_ANY_ADDRESS' => 'Tilf�ldig Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelses Information',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopier betalings adresse til modtager adresse',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopier modtager adresse til betalings adresse',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne som en medlems organisation?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Er du sikker p� du vil fjerne denne?',
  'LBL_DUPLICATE' => 'Mulige Dobbelt Kunder',
  'MSG_SHOW_DUPLICATES' => 'Oprettelse af denne kunde kan potentielt oprette en dobbelt kunde. Du kan enten klikke p� Opret Kunde for at forts�tte med at oprette den nye kunde med den f�r indtastede data eller du kan klikke Annuller.',
  'MSG_DUPLICATE' => 'Oprettelse af denne kunde kan potentielt oprette en dobbelt kunde. Du kan enten v�lge en kunde fra listen nedenunder eller du kan klikke p� Opret Kunde for at forts�tte med oprettelsen af en ny kunde med de f�r indtastede data.',
  'LNK_NEW_ACCOUNT' => 'Opret Kunde',



  'LNK_ACCOUNT_LIST' => 'Kunde',
  'LBL_INVITEE' => 'Kontakter',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re valgt for at slette kunden.',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p� at du vil slette denne?',
  'LBL_SAVE_ACCOUNT' => 'Gem Kunde',
  'LBL_BUG_FORM_TITLE' => 'Kunde',
	'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Er du sikker p� at du vil fjerne denne kunde fra dette projekt?',
	'LBL_USERS_ASSIGNED_LINK'=>'Tildelte Brugere',
	'LBL_USERS_MODIFIED_LINK'=>'Rettede Brugere',
	'LBL_USERS_CREATED_LINK'=>'Oprettet Af Brugere',
	'LBL_TEAMS_LINK'=>'Hold',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kunder',
	'LBL_PRODUCTS_TITLE'=>'Produkter',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
	'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'Medlems Organisationer',
	'LBL_NAME'=>'Navn:',
	
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Muligheder',
	'LBL_LEADS_SUBPANEL_TITLE' => 'Emner',
	'LBL_CASES_SUBPANEL_TITLE' => 'Sager',




	'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Medlems Organisationer',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Fejl',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekter',
);


?>
