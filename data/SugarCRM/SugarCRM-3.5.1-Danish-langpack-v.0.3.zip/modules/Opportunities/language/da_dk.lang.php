<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.49 2005/09/12 22:00:52 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Muligheder',
  'LBL_MODULE_TITLE' => 'Muligheder: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Muligheder S�gning',
  'LBL_LIST_FORM_TITLE' => 'Muligheder Liste',
  'LBL_OPPORTUNITY_NAME' => 'Muligheder Navn:',
  'LBL_OPPORTUNITY' => 'Mulighed:',
  'LBL_NAME' => 'Mulighed Navn',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Mulighed',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto Navn',
  'LBL_LIST_AMOUNT' => 'M�ngde',
  'LBL_LIST_DATE_CLOSED' => 'Luk',
  'LBL_LIST_SALES_STAGE' => 'Salgs Stadie',
  'LBL_ACCOUNT_ID'=>'Konto ID',
  'LBL_CURRENCY_ID'=>'Valuta ID',
  'LBL_TEAM_ID' =>'Hold ID',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Muligheder - Valuta Opdatering',
  'UPDATE_DOLLARAMOUNTS' => 'Opdater U.S. Dollar M�ngder',
  'UPDATE_VERIFY' => 'Godkend M�ngder',
  'UPDATE_VERIFY_TXT' => 'Godkender at m�ngde v�rdierne i muligheder er gyldige decimal numre med kun numeriske karakterer(0-9) og decimaler(.)',
  'UPDATE_FIX' => 'Fix M�ngder',
  'UPDATE_FIX_TXT' => 'Fors�ger at fixe alle ugyldige m�ngder ved at lave et gyldigt decimal fra den nuv�rende m�ngde. Dette vil backup andre m�ngder det �ndres ind i et database felt amount_backup. Hvis du k�rer dette og opdager fejl, returner ikke dette uden  at genskabe fra backupen da det kan overskrive backupen med ny ugyldig data.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Opdater U.S. Dollar m�ngder for muligheder baseret p� det nuv�rende s�t valuta kurs. Denne v�rdi er brugt til at udregne grafer og Liste Vis Valuta M�ngder.',
  'UPDATE_CREATE_CURRENCY' => 'Opretter Ny Valuta:',
  'UPDATE_VERIFY_FAIL' => 'Data Mislykkedes Godkendelse:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Nuv�rende M�ngde:',
  'UPDATE_VERIFY_FIX' => 'K�rsel af Fix ville give',
  'UPDATE_INCLUDE_CLOSE' => 'Inklud�r Lukkede Data',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Ny M�ngde:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Ny Valuta:',
  'UPDATE_DONE' => 'F�rdig',
  'UPDATE_BUG_COUNT' => 'Felj Fundet og Fors�gt at L�se:',
  'UPDATE_BUGFOUND_COUNT' => 'Fejl Fundet:',
  'UPDATE_COUNT' => 'Data Opdateret:',
  'UPDATE_RESTORE_COUNT' => 'Data M�ngder Genskabt:',
  'UPDATE_RESTORE' => 'Genskab M�ngder',
  'UPDATE_RESTORE_TXT' => 'Genskaber m�ngde v�rdier fra backuperne der blev oprettet under Fixen.',
  'UPDATE_FAIL' => 'Kunne ikke opdatere - ',
  'UPDATE_NULL_VALUE' => 'M�ngde er NULL s�tter den til 0 -',
  'UPDATE_MERGE' => 'Sammenl�g Valutaer',
  'UPDATE_MERGE_TXT' => 'Sammenl�g flere valutaer ind i en enkelt valuta. Hvis du opdager at der er flere valuta data for den samme valuta, kan du v�lge at l�gge dem sammen. Dette vil ogs� sammenl�gge valutaerne for alle andre moduler.',
  'LBL_ACCOUNT_NAME' => 'Konto Navn:',
  'LBL_AMOUNT' => 'M�ngde:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_DATE_CLOSED' => 'Forventet Lukkede Dato:',
  'LBL_TYPE' => 'Type:',
  'LBL_NEXT_STEP' => 'N�ste Trin:',
  'LBL_LEAD_SOURCE' => 'Ledende Kilde:',
  'LBL_SALES_STAGE' => 'Salgs Stadie:',
  'LBL_PROBABILITY' => 'Sandsynlighed (%):',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_DUPLICATE' => 'Mulige Duplikerede Muligheder',
  'MSG_DUPLICATE' => 'Oprettelse af denne mulighed kan potentielt oprettee en dobbelt mulighed. Du kan enten V�lge en Mulighed fra listen nedenunder eller du kan klikke p� Opret Ny Mulighed for at forts�tte med oprettelse af en ny mulighed med det f�r indtastede data.',
  'LBL_NEW_FORM_TITLE' => 'Opret Mulighed',
  'LNK_NEW_OPPORTUNITY' => 'Opret Mulighed',



  'LNK_OPPORTUNITY_LIST' => 'Muligheder',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette muligheden.',
  'LBL_TOP_OPPORTUNITIES' => 'Mine Top �bne Muligheder',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne kontakt fra denne mulighed?',
	'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Er du sikker p� at du vil fjerne denne mulighed fra dette projekt?',
	'LBL_AMOUNT_BACKUP'=>'M�ngde Backup',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Muligheder',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
    'LBL_RAW_AMOUNT'=>'R� M�ngde',
	
    'LBL_LEADS_SUBPANEL_TITLE' => 'Emner',
    'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',



    'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projects',
);

?>
