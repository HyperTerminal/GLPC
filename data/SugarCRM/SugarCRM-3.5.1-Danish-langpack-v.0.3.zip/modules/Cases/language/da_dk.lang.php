<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.31 2005/09/12 22:00:52 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Sager',
  'LBL_MODULE_TITLE' => 'Sager: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Sag S�gning',
  'LBL_LIST_FORM_TITLE' => 'Sags Liste',
  'LBL_NEW_FORM_TITLE' => 'Ny Sag',
  'LBL_CONTACT_CASE_TITLE' => 'Kontakt-sag:',
  'LBL_SUBJECT' => 'Overskrift:',
  'LBL_CASE' => 'Sag:',
  'LBL_CASE_NUMBER' => 'Sags Nummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_ACCOUNT_NAME' => 'Konto Navn:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_RESOLUTION' => 'L�sning:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_CASE_SUBJECT' => 'Sags Overskrift:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Nr.',
  'LBL_LIST_SUBJECT' => 'Overskrift',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto Navn',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Prioritet',
  'LBL_LIST_LAST_MODIFIED' => 'Sidst Rettet',
  'LBL_INVITEE' => 'Kontakter',
  'LNK_NEW_CASE' => 'Opret Sag',
  'LNK_CASE_LIST' => 'Sager',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� at du vil fjerne denne kontakt fra sagen?',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�lges for at slette kontoen.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne dag fra denne fejl?',
  'LBL_LIST_CLOSE' => 'Luk',
  'LBL_LIST_MY_CASES' => 'Mine �bne Sager',
  
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Sager',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Fejl',
	
);


?>
