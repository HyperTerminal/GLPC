<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
'LBL_ADVANCED'=> 'Avanceret:',
'DESC_USING_LAYOUT_TITLE' => 'Bruger Layout Editoren',
'DESC_USING_LAYOUT_SHORTCUTS' => 'Genveje:',
'DESC_USING_LAYOUT_TOOLBAR' => 'V�rkt�jslinje:',
'DESC_USING_LAYOUT_EDIT_ROWS' => 'Rediger R�kker:',
'DESC_USING_LAYOUT_SELECT_FILE' => 'V�lg Fil:',
'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Rediger Layout:',
'DESC_USING_LAYOUT_ADD_FIELD' => 'Tilf�j Felt:',
'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Fjern en ting:',
'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Vis HTML kode:',
'DESC_USING_LAYOUT_BLK1' => 'Layout editoren lader dig omarrangere felter, faner, og paneler p� faner for at lave layout efter dine behov. V�lg f�rst udseendet af den side du vil redigere via �V�lg Fil� genvejen.',
'DESC_USING_LAYOUT_BLK2' => ' tillader dig at v�lge en anden side at redigere; �ndringer p� den nuv�rende side g�r tabt hvis ikke de er gemt. Hvis du ikke er sikker p� hvilken fil du vil redigere kan du markere �Rediger i plads� boksen; dette vil tilf�je en rediger boks til alle de redigerbare steder gennem applikationen. Naviger gennem applikationen til den side du �nsker at redigere, klik p� rediger boksen, og du vil blive returneret til redigerings layout for den fil.',
'DESC_USING_LAYOUT_BLK3' => ' tr�k og omarranger individuelle felter eller deres m�rkater. V�lg item handlet ',
'DESC_USING_LAYOUT_BLK4' => ' ved siden af det felt eller m�rkat du �nsker at flytte, og klik p� det item handle hvor du �nsker feltet eller m�rkatet skal v�re. Dette vil flytte tingen fra dets tidligere sted til dets nye sted. Hvis der allerede var et felt eller m�rkat p� destinationen vil de to ting bytte positioner. Flytning af under-paneler er det samme som at flytte felter; v�lg p� kilde under-panel handle og destinations handle og de to vil bytte plads. For at fjerne et felt eller form fra sk�rmen, tr�k tingen til v�rkt�jslinjen i den venstre menu.',
'DESC_USING_LAYOUT_BLK5' => ' skifter udseendet for at tillade tilf�jelse og fjernelse af r�kker i detalje panelet. Ved at trykke + kan du tilf�je en r�kke under den valgte, og ved at trykke � kan du fjerne r�kken.',
'DESC_USING_LAYOUT_BLK6' => 'V�rkt�jslinjen giver arbejdsplads til at tilf�je nye felter og m�rkater p� en form, midlertidigt beholde ting som er blevet fjernet fra en form, og kasserede ting.',
'DESC_USING_LAYOUT_BLK7' => ' �bner et valg display til at specificere den type felt du �nsker at tilf�je og m�rkatet der f�lger med det. Ved at trykke p� tilf�j kan du putte det nye felt og dets m�rkat i v�rkt�jslinjen. Her fra kan feltet blive tilf�jet ved at v�lge den nye tings handle og handlet for dens destination.',
'DESC_USING_LAYOUT_BLK8' => ' er opn�et ved at v�lge dets handle og klikke p� teksten �Tr�k u�nskede ting her til�. Dette vil l�gge den valgte ting i v�rkt�jslinjen.',
'DESC_USING_LAYOUT_BLK9' => ' valg felt viser den html som omfatter hvert felt. Mens dette kan v�re informativ er det meget CPU kr�vende, og burde kun blive brugt n�r n�dvendigt.',
'DESC_USING_LAYOUT_BLK10' => 'For at gemme �ndringer tryk �Gem Layout� knappen. For at kassere �ndringer klik p� en anden fane applikationen og alle �ndinger vil blive kasseret for den side der bliver redigeret.',
'NO_RECORDS_LISTVIEW'=>'For at redigere et liste udseende der skal v�re midst �n r�kke af data.  Opret venligst data til dette liste udseende f�r du fors�ger at redigere.',
'LBL_EDIT_LAYOUT'=>'Rediger Layout',
'LBL_EDIT_ROWS'=>'Rediger R�kker',
'LBL_EDIT_COLUMNS'=>'Rediger Kolonner',
'LBL_EDIT_LABELS'=>'Rediger M�rkater',
'LBL_EDIT_FIELDS'=>'Rediger Special Felter',
'LBL_ADD_FIELDS'=>'Tilf�j Special Felt',
'LBL_DISPLAY_HTML'=>'Vis HTML Kode',
'LBL_SELECT_FILE'=> 'V�lg Fil',
);
?>
