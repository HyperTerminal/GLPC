<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.38 2005/09/20 22:07:51 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette Kontoen.',
	'LBL_ACCOUNT_ID' => 'Konto ID:',
	'LBL_CASE_ID' => 'Sags ID:',
	'LBL_CLOSE' => 'Luk:',
	'LBL_COLON' => ':',
	'LBL_CONTACT_ID' => 'Kontakt ID:',
	'LBL_CONTACT_NAME' => 'Kontakt:',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Noter',
	'LBL_DESCRIPTION' => 'Beskrivelse',
	'LBL_EMAIL_ADDRESS' => 'Email Adresse:',
	'LBL_FILE_MIME_TYPE' => 'Mime Type',
	'LBL_FILE_URL' => 'Fil URL',
	'LBL_FILENAME' => 'Vedh�ftning:',
	'LBL_LEAD_ID' => 'Ledelses ID:',
	'LBL_LIST_CONTACT_NAME' => 'Kontakt',
	'LBL_LIST_DATE_MODIFIED' => 'Sidst Rettet',
	'LBL_LIST_FILENAME' => 'Vedh�ftning',
	'LBL_LIST_FORM_TITLE' => 'Note Liste',
	'LBL_LIST_RELATED_TO' => 'Relateret Til',
	'LBL_LIST_SUBJECT' => 'Overskrift',
	'LBL_MODULE_NAME' => 'Noter',
	'LBL_MODULE_TITLE' => 'Noter: Hjem',
	'LBL_NEW_FORM_TITLE' => 'Opret Note eller Vedh�ftning',
	'LBL_NOTE_STATUS' => 'Note',
	'LBL_NOTE_SUBJECT' => 'Note Overskrift:',
	'LBL_NOTE' => 'Note:',
	'LBL_OPPORTUNITY_ID' => 'Muligheds ID:',
	'LBL_PARENT_ID' => 'F�lles ID:',
	'LBL_PARENT_TYPE' => 'F�lles Type',
	'LBL_PHONE' => 'Telefon:',
	'LBL_PORTAL_FLAG' => 'Vis i Portal?',
	'LBL_PRODUCT_ID' => 'Produkt ID:',
	'LBL_QUOTE_ID' => 'Citat ID:',
	'LBL_RELATED_TO' => 'Relateret Til:',
	'LBL_SEARCH_FORM_TITLE' => 'Note S�gning',
	'LBL_STATUS' => 'Status',
	'LBL_SUBJECT' => 'Overskrift:',
	'LNK_CALL_LIST' => 'Opkald',
	'LNK_EMAIL_LIST' => 'Emails',
	'LNK_IMPORT_NOTES' => 'Importer Noter',
	'LNK_MEETING_LIST' => 'M�der',
	'LNK_NEW_CALL' => 'Skemal�g Opkald',
	'LNK_NEW_EMAIL' => 'Arkiver Email',
	'LNK_NEW_MEETING' => 'Skemal�g M�de',
	'LNK_NEW_NOTE' => 'Opret Note eller Vedh�ftning',
	'LNK_NEW_TASK' => 'Opret Opgave',
	'LNK_NOTE_LIST' => 'Noter',
	'LNK_TASK_LIST' => 'Opgaver',
	'LNK_VIEW_CALENDAR' => 'Idag',
);

?>
