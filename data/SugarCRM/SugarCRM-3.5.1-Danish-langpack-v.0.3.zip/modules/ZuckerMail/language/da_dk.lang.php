<?php
define(ZUCKER_CHARSET,"US-ASCII"); 

$mod_strings = array (
  'LBL_MODULE_NAME' => 'ZuckerMail',

  'LBL_MENU_BOXES' => 'Konto Administration',
  'LBL_MENU_ABOUT' => 'Om os',

  'LBL_BOX_OVERVIEW' => 'Indbox Oversigt',
  
  'LBL_BOX' => 'Indbox',
  'LBL_BOX_LIST' => 'Indbox Liste',
  'LBL_BOX_LIST_GLOBAL' => 'Delt Indbox Liste',
  'LBL_BOX_LIST_PRIVATE' => 'Privat Indbox Liste',
  'LBL_BOX_NEW' => 'Ny Indbox',
  'LBL_BOX_EDIT' => 'Skift Indbox',
  'LBL_BOX_TYPE_POP3' => 'POP3',
  'LBL_BOX_TYPE_IMAP' => 'IMAP',
  'LBL_BOX_TYPE_RAW' => 'Raw',
  'LBL_BOX_NAME' => 'Navn',
  'LBL_BOX_DESCRIPTION' => 'Beskrivelse',
  'LBL_BOX_SERVER' => 'Server',
  'LBL_BOX_USERNAME' => 'Brugernavn',
  'LBL_BOX_PASSWORD' => 'Kodeord',
  'LBL_BOX_FOLDER' => 'Mappe',
  'LBL_BOX_TLS' => 'Krypterede Forbindelser (TLS)',
  'LBL_BOX_VALIDATECERTS' => 'Godkend Certifikat',
  'LBL_BOX_URL' => 'Forbindelse URL',
  'LBL_BOX_GLOBAL' => 'Delt',
  'LBL_BOX_YES' => 'Ja',
  'LBL_BOX_NO' => 'Nej',
  'LBL_BOX_TEST_CONNECTION' => 'Test Forbindelse',
  'LBL_BOX_MSG_COUNT' => 'Beskeder:',
  'LBL_BOX_NEW_COUNT' => 'Nye Beskeder:',
  'LBL_BOX_LAST_CHANGE' => 'Sidste �ndring:',

  'LBL_BOX_DIRECTION' => 'Retning',
  'LBL_BOX_MARK_AS_READ' => 'Mark�r som L�st',
  'LBL_BOX_DELETE_AFTER_IMPORT' => 'Slet efter Import',
  
  'LBL_MAIL_SEARCH' => 'S�g Beskeder',
  
  'LBL_MAIL' => 'Mail',
  'LBL_MAIL_FROM' => 'Fra',
  'LBL_MAIL_TO' => 'To',
  'LBL_MAIL_CC' => 'CC',
  'LBL_MAIL_SENT' => 'Sendt Dato',
  'LBL_MAIL_SUBJECT' => 'Overskrift',
  'LBL_MAIL_BODY' => 'Body',
  'LBL_MAIL_ATTACHMENTS' => 'Vedh�ftninger',
  'LBL_MAIL_ATTACHMENT_SIZE' => 'St�rrelse',
  'LBL_MAIL_STATUS' => 'Status',
  
  'LBL_MAIL_IMPORT' => 'arkiver',  
  'LBL_MAIL_DELETE' => 'slet',  
  'LBL_MAIL_DELETE_LONG' => 'Slet fr Indbox', 
  'LBL_MAIL_BACK' => 'Tilbage til Indbox', 
  'LBL_MAIL_IMPORT_GO' => 'Import�r',  
  
  'LBL_MAIL_TOOLS' => 'V�rkt�jer:',
  'LBL_MAIL_ASSIGN' => 'Tildel:',
  
  
  'LBL_REPLY' => 'Svar',
  'LBL_REPLYALL' => 'Svar Alle',
  'LBL_FORWARD' => 'Videresend',
  
);

$mod_list_strings = array (
  'GLOBAL_TYPES' =>
  array (
    'Y' => 'Delt',
    'N' => 'Privat',
  ),
  'DIRECTION_TYPES' =>
  array (
	'incoming' => 'Indkommende Folder',
	'outgoing' => 'Udg�ende Folder',
  ),
);


?>