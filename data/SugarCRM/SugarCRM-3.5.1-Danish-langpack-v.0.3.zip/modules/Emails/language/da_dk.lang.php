<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.62 2005/09/12 22:00:52 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Alle Emails',
  'LBL_ARCHIVED_MODULE_NAME' => 'Arkiverede Emails',
  'LBL_MODULE_NAME_NEW' => 'Arkiver Email',
  'LBL_MODULE_TITLE' => 'Emails: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Email S�gning',
  'LBL_LIST_FORM_TITLE' => 'Email Liste',
  'LBL_NEW_FORM_TITLE' => 'Arkiver Email',
  'LBL_LIST_SUBJECT' => 'Overskrift',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Relateret til',
  'LBL_LIST_DATE' => 'Dato Sendt',
  'LBL_LIST_TIME' => 'Tid Sendt',
  'ERR_DELETE_RECORD' => 'Et data nummmer skal v�re specifiveret for at slette kontoen.',
  'LBL_DATE_SENT' => 'Dato Sendt:',
  'LBL_SUBJECT' => 'Overskrift:',
  'LBL_BODY' => 'Body:',
  'LBL_DATE_AND_TIME' => 'Dato & Tid Sendt:',
  'LBL_DATE' => 'Dato Sendt:',
  'LBL_TIME' => 'Tid Sendt:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� at du vil fjerne denne modtager fra denne email?',
  'LBL_INVITEE' => 'Modtagere',

'LNK_NEW_CALL'=>'Skemal�g Opkald',
'LNK_NEW_MEETING'=>'Skemal�g M�de',
'LNK_NEW_TASK'=>'Opret Opgave',
'LNK_NEW_NOTE'=>'Opret Note eller Vedh�ftning',
'LNK_NEW_EMAIL'=>'Arkiver Email',
'LNK_CALL_LIST'=>'Opkald',
'LNK_MEETING_LIST'=>'M�der',
'LNK_TASK_LIST'=>'Opgaver',
'LNK_NOTE_LIST'=>'Noter',
'LNK_EMAIL_LIST'=>'Emails',
'LNK_NEW_SEND_EMAIL'=>'Skriv Email',
'LNK_ARCHIVED_EMAIL_LIST'=>'Arkiverede Emails',
'LNK_SENT_EMAIL_LIST'=>'Sendte Emails',
'LNK_ALL_EMAIL_LIST'=>'Alle Emails',
'LNK_NEW_ARCHIVE_EMAIL'=>'Opret Arkiveret Email',
'LNK_VIEW_CALENDAR' => 'Idag',

  'LBL_COMPOSE_MODULE_NAME' => 'Skriv Email',
  'LBL_SENT_MODULE_NAME' => 'Sendt Emails',
  'LBL_SEND' => 'SEND',
  'LBL_SEARCH_FORM_SENT_TITLE' => 'S�g i Sendte Emails',
  'LBL_LIST_FORM_SENT_TITLE' => 'Sendte Emails',
'LBL_SEND_BUTTON_LABEL'=>'Send',
'LBL_SEND_BUTTON_TITLE' => 'Send [Alt+S]',
'LBL_SEND_BUTTON_KEY' => 'S',
'LBL_SAVE_AS_DRAFT_BUTTON_TITLE'=>'Gem Draft [Alt+R]',
'LBL_SAVE_AS_DRAFT_BUTTON_KEY'=>'R',
'LBL_SAVE_AS_DRAFT_BUTTON_LABEL'=>'Gem Draft',
'LBL_LIST_TO_ADDR'=>'Til',
'LBL_TO_ADDRS'=>'Til',
'LBL_FROM'=>'Fra:',
'LBL_LIST_FROM_ADDR'=>'Fra',
'LNK_NEW_EMAIL_TEMPLATE'=>'Opret Email Skabelon',
'LNK_EMAIL_TEMPLATE_LIST'=>'Email Skabeloner',
"LBL_USE_TEMPLATE"=>"Brug Skabelon:",
"LBL_BCC"=>"Bcc:",
"LBL_CC"=>"Cc:",
"LBL_TO"=>"Til:",
"LBL_ERROR_SENDING_EMAIL"=>"Fejl ved afsendelse",
"LBL_MESSAGE_SENT"=>"Besked Sendt",
'LNK_DRAFTS_EMAIL_LIST'=>'Drafts',
'LBL_SEARCH_FORM_DRAFTS_TITLE'=>'S�gning Drafts',
'LBL_LIST_FORM_DRAFTS_TITLE'=>'Draft',
'LBL_ATTACHMENTS'=>'Vedh�ftninger:',
'LBL_ADD_FILE'=>'Tilf�j Fil',
'LBL_ADD_ANOTHER_FILE'=>'Tilf�j Flere Filer',
'LBL_EMAIL_ATTACHMENT'=>'Email Vedh�ftning',
'LBL_CONTACT_FIRST_NAME'=>'Kontakt Fornavn',
'LBL_CONTACT_LAST_NAME'=>'Kontakt Efternavn',
'ERR_NOT_ADDRESSED'=>'Emails skal have en Til, CC eller BCC adresse',
'LBL_NOTE_SEMICOLON'=>'Note: Brug et semi-kolon som separator for flere email adresser.',
'WARNING_SETTINGS_NOT_CONF'=>'Advarsel: Din email ops�tning er ikke konfigureret til at sende emails.',
'LBL_EDIT_MY_SETTINGS'=>'Rediger Min Ops�tning',
'LBL_NOT_SENT'=>'Afsendelses Fejl',
'LBL_LIST_CREATED'=>'Oprettet',
'LBL_EMAIL_SELECTOR'=>'V�lg',
'LBL_CREATED_BY'=>'Oprettet af',
'LBL_DESCRIPTION'=>'Beskrivelse',
'LBL_FROM_NAME'=>'Fra Navn',
'LBL_LIST_CONTACT_NAME'=>'Kontakt Navn',
'LBL_LIST_DATE_SENT'=>'Dato Sendt',
'LBL_MODIFIED_BY'=>'Rettet Af',
'LBL_HTML_BODY'=>'HTML Body',
'LBL_TEXT_BODY'=>'Tekst Body',
'LBL_EDIT_ALT_TEXT'=>'Rediger Alternativ Tekst',
'LBL_SHOW_ALT_TEXT'=>'Vis Alternativ Tekst',
'LBL_USERS'=>'Brugere',

'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
'LBL_USERS_SUBPANEL_TITLE' => 'Brugere',
);


?>
