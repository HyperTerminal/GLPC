<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.45 2005/09/14 02:30:39 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'M�der',
  'LBL_MODULE_TITLE' => 'M�der: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'M�de S�gning',
  'LBL_LIST_FORM_TITLE' => 'M�de Liste',
  'LBL_NEW_FORM_TITLE' => 'Skemal�g M�de',
  'LBL_SCHEDULING_FORM_TITLE' => 'Skemal�gning',
  'LBL_LIST_SUBJECT' => 'Overskrift',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Relateret til',
  'LBL_LIST_DATE' => 'Start Dato',
  'LBL_LIST_TIME' => 'Start Tid',
  'LBL_LIST_CLOSE' => 'Luk',
  'LBL_SUBJECT' => 'Overskrift:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Sted:',
  'LBL_DATE_TIME' => 'Start Dato & Tid:',
  'LBL_DATE' => 'Start Dato:',
  'LBL_TIME' => 'Start Tid:',
  'LBL_DURATION' => 'Varighed:',
  'LBL_DURATION_HOURS' => 'Varighed Timer:',
  'LBL_DURATION_MINUTES' => 'Varighed Minutter:',
  'LBL_HOURS_MINS' => '(timer/minutter)',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_MEETING' => 'M�de:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelses Information',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planlagt',
'LNK_NEW_CALL'=>'Skemal�g Opkald',
'LNK_NEW_MEETING'=>'Skemal�g M�de',
'LNK_NEW_TASK'=>'Opret Opgave',
'LNK_NEW_NOTE'=>'Opret Note eller Vedh�ftning',
'LNK_NEW_EMAIL'=>'Arkiver Email',
'LNK_CALL_LIST'=>'Opkald',
'LNK_MEETING_LIST'=>'M�der',
'LNK_TASK_LIST'=>'Opgaver',
'LNK_NOTE_LIST'=>'Noter',
'LNK_EMAIL_LIST'=>'Emails',

  'LNK_VIEW_CALENDAR' => 'Idag',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette m�det.',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� at du vil fjerne denne m�deindkaldet fra m�det?',
  'LBL_INVITEE' => 'M�deindkaldte',
  'LNK_NEW_APPOINTMENT' => 'Opret Aftale',

  'LBL_ADD_INVITEE' => 'Tilj�j m�deindkaldte',
  'LBL_NAME' => 'Navn',
  'LBL_FIRST_NAME' => 'Fornavn',
  'LBL_LAST_NAME' => 'Efternavn',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Telefon Kontor:',
  'LBL_REMINDER' => 'P�minder:',
  'LBL_SEND_BUTTON_TITLE'=>'Send Indvitationer [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'Send Indvitationer',
  'LBL_REMINDER_TIME'=>'P�minder Tid',
  'LBL_MODIFIED_BY'=>'Rettet af',
  'LBL_CREATED_BY'=>'Oprettet af',
  'LBL_DATE_END'=>'Dato Slut',
	
  'LBL_SEARCH_BUTTON'=> 'S�g',
  'LBL_ADD_BUTTON'=> 'Tilf�j',
  'LBL_DEL'=> 'Slet',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'M�der',
  'LBL_LIST_STATUS'=>'Status',
  'LBL_LIST_DUE_DATE'=>'Ved Dato',
  'LBL_LIST_DATE_MODIFIED'=>'Dat0 Rettet',
  
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_USERS_SUBPANEL_TITLE' => 'Brugere',
);


?>
