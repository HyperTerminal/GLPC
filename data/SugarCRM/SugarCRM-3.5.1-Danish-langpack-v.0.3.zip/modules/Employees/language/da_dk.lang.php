<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.3 2005/04/28 21:51:25 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Medarbejdere',
  'LBL_MODULE_TITLE' => 'Medarbejdere: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Medarbejder S�gning',
  'LBL_LIST_FORM_TITLE' => 'Medarbejdere',
  'LBL_NEW_FORM_TITLE' => 'Ny Medarbejder',
  'LBL_EMPLOYEE' => 'Medarbejdere:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Gendan Til Standard Egenskaber',
  'LBL_TIME_FORMAT' => 'Tids Format:',
  'LBL_DATE_FORMAT' => 'Dato Format:',
  'LBL_TIMEZONE' => 'Nuv�rende Tid:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_LIST_EMPLOYEE_NAME' => 'Medarbejder Navn',
  'LBL_LIST_DEPARTMENT' => 'Afdeling',
  'LBL_LIST_REPORTS_TO_NAME' => 'Rapporterer Til',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim�r Telefon',
  'LBL_LIST_USER_NAME' => 'Bruger Navn',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Medarbejder Status',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Ny Medarbejder [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Ny Medarbejder',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fejl:',
  'LBL_PASSWORD' => 'Kodeord:',
  'LBL_EMPLOYEE_NAME' => 'Medarbejder Navn:',
  'LBL_USER_NAME' => 'Bruger Navn:',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_EMPLOYEE_SETTINGS' => 'Medarbejder Settings',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Sprog:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_EMPLOYEE_INFORMATION' => 'Medarbejder Information',
  'LBL_OFFICE_PHONE' => 'Konto Telefon:',
  'LBL_REPORTS_TO' => 'Rapporterer til:',
  'LBL_OTHER_PHONE' => 'Anden telefon:',
  'LBL_OTHER_EMAIL' => 'Anden Email:',
  'LBL_NOTES' => 'Noter:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Tilf�ldig telefon:',
  'LBL_ANY_EMAIL' => 'Tilf�ldig Email:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Navn:',
  'LBL_MOBILE_PHONE' => 'Mobilnummer:',
  'LBL_OTHER' => 'Andet:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Hjemme Telefon:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse Information',
  'LBL_EMPLOYEE_STATUS' => 'Medarbejder Status:',
  'LBL_PRIMARY_ADDRESS' => 'Prim�r Address:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Opret Bruger [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Opret Bruger',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Favorit Farve:',
  'LBL_MESSENGER_ID' => 'IM Navn:',
  'LBL_MESSENGER_TYPE' => 'IM Type:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Medarbejderens navn ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' Eksisterer allerede.  Dobbelt medarbejder navne er ikke tilladt.  Skift medarbejderens navn.',
  'ERR_LAST_ADMIN_1' => 'Medarbejderens navn "',
  'ERR_LAST_ADMIN_2' => '" er den sidste medarbejder med administrator adgang.  Mindst �n medarbejder skal v�re administrator.',
  'LNK_NEW_EMPLOYEE' => 'Opret Medarbejder',
  'LNK_EMPLOYEE_LIST' => 'Medarbejdere',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re specificeret for at slette kontoen.',








  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',

);


?>
