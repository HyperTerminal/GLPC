<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.35 2005/05/26 17:05:24 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Biblioteket',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' eksisterer ikke eller er ikke skrivbar',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Filen blev ikke uploaded. Det kan v�re at \'upload_max_filesize\' ops�tningen i din php.ini fil er sat til en lav v�rdi',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Filen er for stor. Maksimum:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Bytes. �nder $sugar_config[\'upload_maxsize\'] i config.php',
  'LBL_MODULE_NAME' => 'Importer',
  'LBL_TRY_AGAIN' => 'Pr�v Igen',
  'LBL_ERROR' => 'Fejl:',
  'ERR_MULTIPLE' => 'Flere kolonner er blevet defineret med det samme felt navn.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Manglende p�kr�vede felter:',
  'ERR_SELECT_FULL_NAME' => 'Du kan ikke v�lge fulde navn n�r fornavn og efternavn er valgt.',
  'ERR_SELECT_FILE' => 'V�lg den fil du vil uploade.',
  'LBL_SELECT_FILE' => 'V�lg fil:',
  'LBL_CUSTOM' => 'Special',
  'LBL_CUSTOM_CSV' => 'Special Comma Delimited Fil',
  'LBL_CUSTOM_TAB' => 'Special Tab Delimited Fil',
  'LBL_DONT_MAP' => '-- Do not map this field --',
  'LBL_STEP_1_TITLE' => 'Trin 1: V�lg Kilde',
  'LBL_WHAT_IS' => 'Hvad er data kilden?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Mine gemte kilder:',
  'LBL_PUBLISH' => 'udgiv',
  'LBL_DELETE' => 'slet',
  'LBL_PUBLISHED_SOURCES' => 'Udgivet kilder:',
  'LBL_UNPUBLISH' => 'Fortryd udgivelse',
  'LBL_NEXT' => 'N�ste >',
  'LBL_BACK' => '< Tilbage',
  'LBL_STEP_2_TITLE' => 'Trin 2: Upload Eksport Fil',
  'LBL_HAS_HEADER' => 'Har Header:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'V�lg nu den fil der skal importeres:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 og 2000 kan eksportere data i <b>Comma Separated Values</b> formatet hvilken kan blive brugt til at importere data ind i systemet. For at eksportere din data fra Outlook, f�lg trinene nedenunder:',
  'LBL_OUTLOOK_NUM_1' => 'Start <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'V�lg <b>Filer</b>, og s� <b>Importer og Eksporter ...</b>',
  'LBL_OUTLOOK_NUM_3' => 'V�lg <b>Eksporter til en fil</b> og klik N�ste',
  'LBL_OUTLOOK_NUM_4' => 'V�lg <b>Comma Separated Values (Windows)</b> og klik <b>N�ste</b>.<br>  Note: Du kan blive bedt om at installere export komponentet',
  'LBL_OUTLOOK_NUM_5' => 'V�lg <b>Kontakter</b> mappen og klik <b>N�ste</b>. Du kan v�lge forskellige kontakt mapper hvis dine kontakter er gemt i flere mapper',
  'LBL_OUTLOOK_NUM_6' => 'V�lg et filnavn og klik <b>N�ste</b>',
  'LBL_OUTLOOK_NUM_7' => 'Klik <b>F�rdig</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! kan eksportere data i <b>Comma Separated Values</b> format hvilket kan blive brugt til at importere data ind i systemet. For at exportere din data fra Act!, f�lg trinene nedenunder:',
  'LBL_ACT_NUM_1' => 'K�r <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'V�lg <b>Filer</b> , og <b>Data Exchange</b>, og s� <b>Export...</b>',
  'LBL_ACT_NUM_3' => 'V�lg fil typen <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'V�lg et filnavn og sted til den eksporterede data og klik <b>N�ste</b>',
  'LBL_ACT_NUM_5' => 'V�lg <b>Kun kontakt data</b>',
  'LBL_ACT_NUM_6' => 'Klik p� <b>Options...</b>',
  'LBL_ACT_NUM_7' => 'V�lg <b>Komma</b> som felt separator',
  'LBL_ACT_NUM_8' => 'Mark�r <b>Ja, eksporter felt navne</b> og klik <b>OK</b>',
  'LBL_ACT_NUM_9' => 'Klik <b>N�ste</b>',
  'LBL_ACT_NUM_10' => 'V�lg <b>Alle Data</b> og Klik <b>F�rdig</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com kan eksportere data i <b>Comma Separated Values</b> format hvilket kan blive brugt til at importere data ind i systemet. For at eksportere din data fra Salesforce.com, f�lg trinene nedenunder:',
  'LBL_SF_NUM_1' => '�ben din browser, og g� til http://www.salesforce.com, og log ind med din email adresse og kodeord',
  'LBL_SF_NUM_2' => 'Klik p� <b>Rapporter</b> fanen i top menuen',
  'LBL_SF_NUM_3' => '<b>For at eksportere kontoer:</b> Klik p� <b>Aktive Kontoer</b> linket<br><b>For at eksport Kontakter:</b> Klik p� <b>Mailing Liste</b> linket',
  'LBL_SF_NUM_4' => 'P� <b>Trin 1: V�lg din rapport type</b>, v�lg <b>Tabular Rapport</b>klik <b>N�ste</b>',
  'LBL_SF_NUM_5' => 'P� <b>Trin 2: V�lg rapport kolonnen</b>, v�lg de kolonner du vil eksportere og klik <b>N�ste</b>',
  'LBL_SF_NUM_6' => 'P� <b>Trin 3: V�lg den information der skal g�res op</b>, bare klik <b>N�ste</b>',
  'LBL_SF_NUM_7' => 'P� <b>Trin 4: S�t rapport kolonnerne i orden</b>, bare klik <b>N�ste</b>',
  'LBL_SF_NUM_8' => 'P� <b>Trin 5: V�lg dit rapport kriteria</b>, under <b>Start Dato</b>, v�lg en dato langt nok tilbage til at inkludere alle dine kontoer. Du kan ogs� eksportere et under s�t af kontoer ved at bruge mere avancerede kriteriaer. N�r du er f�rdig, klik <b>K�r Rapport</b>',
  'LBL_SF_NUM_9' => 'En rapport vil blive oprettet, og siden burde visw <b>Rapport oprettlses status: F�rdig.</b> Klik nu <b>Eksporter til Excel</b>',
  'LBL_SF_NUM_10' => 'P� <b>Eksporter Rapport:</b>, for <b>Exporter Fil Format:</b>, v�lg <b>Comma Delimited .csv</b>. Klik <b>Eksporter</b>.',
  'LBL_SF_NUM_11' => 'En dialog vil komme frem her skal du v�lge at gemme eksport filen p� din computer.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Mange applikationer vil tillade dig at eksportere data ind i en <b>Comma Delimited tekst fil (.csv)</b>. Generelt f�lger de fleste appliationer disse trin:',
  'LBL_CUSTOM_NUM_1' => 'K�r applickationen og �ben data filen',
  'LBL_CUSTOM_NUM_2' => 'V�lg <b>Gem som...</b> eller <b>Eksporter...</b>',
  'LBL_CUSTOM_NUM_3' => 'Gem filen i et <b>CSV</b> eller <b>Comma Separated Values</b> format',
  'LBL_IMPORT_TAB_TITLE' => 'Mange applikationer vil tillade dig at eksportere data ind i en <b>Tab Delimited tekst fil (.tsv eller .tab)</b>. Generelt f�lger de fleste appliationer disse trin:',
  'LBL_TAB_NUM_1' => 'K�r applickationen og �ben data filen',
  'LBL_TAB_NUM_2' => 'V�lg <b>Gem som...</b> eller <b>Export...</b>',
  'LBL_TAB_NUM_3' => 'Gem filn i et <b>TSV</b> eller <b>Tab Separated Values</b> format',
  'LBL_STEP_3_TITLE' => 'Trin 3: Godkend Felter og Importering',
  'LBL_SELECT_FIELDS_TO_MAP' => 'I listen nedenunder, skal du v�lge felterne i din import fil som burde blive importeret ind i hvert felt i systemet. N�r du er f�rdig, klik <b>Importer Nu</b>:',
  'LBL_DATABASE_FIELD' => 'Database Felt',
  'LBL_HEADER_ROW' => 'Header R�kke',
  'LBL_ROW' => 'R�kke',
  'LBL_SAVE_AS_CUSTOM' => 'Gem asom Speciel Mapping:',
  'LBL_CONTACTS_NOTE_1' => 'Enten Efternavn eller Fulde navn skal v�re mapped.',
  'LBL_CONTACTS_NOTE_2' => 'Hvis Fulde navn er mapped, s� bliver Fornavn og Efternavn ignoreret.',
  'LBL_CONTACTS_NOTE_3' => 'Hvis Fulde navn er mapped, s� bliver dataen i Fuldnavn splittet op i Fornavn og Efternavn n�r indsat i databasen.',
  'LBL_CONTACTS_NOTE_4' => 'Felterne der slutter med Adresse Vej 2 og Adresse Vej 3 bliver sammenk�det med Adresse Vej Felt n�r indsat i databasen.',
  'LBL_ACCOUNTS_NOTE_1' => 'Konto Navn skal v�re mapped.',
  'LBL_ACCOUNTS_NOTE_2' => 'Felter der slutter med Address Street 2 og Address Street 3 er sammenk�det med Adresse Vej Feltet n�r indsat i databasen.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Muligheds Navn, Konto Navn, Dato Lukket, og Salgs Stadie er p�kr�vede felter.',
  'LBL_IMPORT_NOW' => 'Importer Nu',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Kan ikke �bne den importerede fil til l�sning',
  'LBL_NOT_SAME_NUMBER' => 'Der var ikke det samme antal felter pr linie i din fil',
  'LBL_NO_LINES' => 'Der var ingen linier i din import fil',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Import filen er allerede blevet behandlet eller eksisterer ikke',
  'LBL_SUCCESS' => 'Succes:',
  'LBL_SUCCESSFULLY' => 'Importeret med succes',
  'LBL_LAST_IMPORT_UNDONE' => 'Din sidste importering var ikke f�rdiggjort',
  'LBL_NO_IMPORT_TO_UNDO' => 'Der var ingen importering at fortryde.',
  'LBL_FAIL' => 'Mislykkedes:',
  'LBL_RECORDS_SKIPPED' => 'data sprunget over fordi de mangler en eller flere p�kr�vede felter',
  'LBL_IDS_EXISTED_OR_LONGER' => 'Data sprunget over fordi id\'et enten eksisterede eller var l�ngere end 36 karakterer',
  'LBL_RESULTS' => 'Resultater',
  'LBL_IMPORT_MORE' => 'Importer Mere',
  'LBL_FINISHED' => 'F�rdiggjort',
  'LBL_UNDO_LAST_IMPORT' => 'Fortryd Sidste Importering',
  'LBL_LAST_IMPORTED'=>'Sidst Importeret',
  'ERR_MULTIPLE_PARENTS' => 'Du kan kun have �t f�lles ID defineret',
);

$mod_list_strings = Array(

/* Removed these arrays. They are now generated during import processing using the respective modules vardef.
	contacts_import_fields
  	accounts_import_fields
 	leads_import_fields
	manufacturers_import_fields
	feeds_import_fields
	opportunities_import_fields
	notes_import_fields
	productcategories_import_fields
	producttemplates_import_fields
	producttypes_import_fields
	prospects_import_fields
*/


);

?>
