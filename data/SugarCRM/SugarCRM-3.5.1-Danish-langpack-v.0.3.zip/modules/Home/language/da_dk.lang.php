<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.31 2005/05/09 22:21:44 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Ny Kontakt',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'Min Pipeline',
  'LNK_NEW_CONTACT' => 'Opret Kontakt',
  'LNK_NEW_ACCOUNT' => 'Opret Konto',
  'LNK_NEW_OPPORTUNITY' => 'Opret Mulighed',



  'LNK_NEW_LEAD' => 'Opret Emne',
  'LNK_NEW_CASE' => 'Opret sag',
  'LNK_NEW_NOTE' => 'Opret Note eller vedh�ftning',
  'LNK_NEW_CALL' => 'Skemal�g Opkald',
  'LNK_NEW_EMAIL' => 'Arkiver Email',
  'LNK_NEW_MEETING' => 'Skemal�g M�de',
  'LNK_NEW_TASK' => 'Opret Opgave',
  'LNK_NEW_BUG' => 'Rapporter Fejl',
  'LBL_ADD_BUSINESSCARD' => 'Indtast Forretnings Kort',
  'ERR_ONE_CHAR' => 'Indtask venligst midst �t bogstav eller nummer i din s�gning ...',
  'LBL_OPEN_TASKS' => 'Mine �bne Opgaver',
  'LBL_SEARCH_RESULTS' => 'S�ge Resultater'
);


?>
