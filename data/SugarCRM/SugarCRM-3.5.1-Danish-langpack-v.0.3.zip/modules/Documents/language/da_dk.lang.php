<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.11 2005/07/23 00:28:14 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumenter',
	'LBL_MODULE_TITLE' => 'Dokumenter: Hjem',
	'LNK_NEW_DOCUMENT' => 'Opret Dokument',
	'LNK_DOCUMENT_LIST'=> 'Dokument Liste',
	'LBL_DOC_REV_HEADER' => 'Dokument Revisioner',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'Dokument Id',	
	'LBL_NAME' => 'Document Name',
	'LBL_DESCRIPTION' => 'Beskrivelse',
	'LBL_CATEGORY' => 'Kategori',
	'LBL_SUBCATEGORY' => 'Under Kategori',
	'LBL_STATUS' => 'Status', 
	'LBL_CREATED_BY'=> 'Oprettet af',
	'LBL_DATE_ENTERED'=> 'Dato Indskrevet',
	'LBL_DATE_MODIFIED'=> 'Dato Rettet',
	'LBL_DELETED' => 'Slettet',
	'LBL_MODIFIED'=> 'Rettet af',
	'LBL_CREATED'=> 'Oprettet af',
	
	'LBL_REVISION_NAME' => 'Revisions Nummer',
	'LBL_FILENAME' => 'Filnavn',
	'LBL_MIME' => 'Mime Type',
	'LBL_REVISION' => 'Revision',
	'LBL_DOCUMENT' => 'Relaterede Dokumenter',
	'LBL_LATEST_REVISION' => 'Seneste Revision',
	'LBL_CHANGE_LOG'=> '�ndrings Log',
	'LBL_ACTIVE_DATE'=> 'Udgivelse Dato',
	'LBL_EXPIRATION_DATE' => 'Udl�bs Dato',
	'LBL_FILE_EXTENSION'  => 'Fil Extension',
	
	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Ikke Specificeret',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Dokument Navn:',
	'LBL_FILENAME' => 'Filnavn:',
	'LBL_DOC_VERSION' => 'Revision:',
	'LBL_CATEGORY_VALUE' => 'Kategori:',
	'LBL_SUBCATEGORY_VALUE'=> 'Under Kategori:',
	'LBL_DOC_STATUS'=> 'Status:',
	'LBL_LAST_REV_CREATOR' => 'Revision Oprettet Af:',
	'LBL_LAST_REV_DATE' => 'Revisions Dato:',
	'LBL_DOWNNLOAD_FILE'=> 'Download Fil:',
	



	'LBL_DOC_DESCRIPTION'=>'Beskrivelse:',
	'LBL_DOC_ACTIVE_DATE'=> 'Udgivelses Dato:',
	'LBL_DOC_EXP_DATE'=> 'Udl�bs Dato:',
	
	//document list view.	
	'LBL_LIST_FORM_TITLE' => 'Dokument Liste',	
	'LBL_LIST_DOCUMENT' => 'Dokument',
	'LBL_LIST_CATEGORY' => 'Kategori',
	'LBL_LIST_SUBCATEGORY' => 'Under Kategori',
	'LBL_LIST_REVISION' => 'Revision',
	'LBL_LIST_LAST_REV_CREATOR' => 'Udgivet Af',
	'LBL_LIST_LAST_REV_DATE' => 'Revisions Dato',
	'LBL_LIST_VIEW_DOCUMENT'=>'Vis',
	'LBL_LIST_ACTIVE_DATE' => 'Udgivelses Dato',
	'LBL_LIST_EXP_DATE' => 'Udl�bs Dato',
	
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Revisioner',
	'LBL_REV_LIST_ENTERED' => 'Dato Oprettet',
	'LBL_REV_LIST_CREATED' => 'Oprettet af',
	'LBL_REV_LIST_LOG'=> '�ndrings Log',
	
	'LBL_CURRENT_DOC_VERSION'=> 'Nuv�rende Revision:',
	'LBL_CHANGE_LOG'=> '�ndrings Log:',
	'LBL_SEARCH_FORM_TITLE'=> 'Dokument S�gning',
	//document search form.
	'LBL_SF_DOCUMENT' => 'Dokument Navn:',
	'LBL_SF_CATEGORY' => 'Kategori:',
	'LBL_SF_SUBCATEGORY'=> 'Under Kategori:',
	'LBL_SF_ACTIVE_DATE' => 'Udgivelses Dato:',
	'LBL_SF_EXP_DATE'=> 'Udl�bs Dato:',
	
	'DEF_CREATE_LOG' => 'Dokument Oprettet',
	
	//error messages
	'ERR_DOC_NAME'=>'Dokument Navn',
	'ERR_DOC_ACTIVE_DATE'=>'Udgivelses Dato',
	'ERR_DOC_EXP_DATE'=> 'Udl�bs Dato',
	'ERR_FILENAME'=> 'Filnavn',
	'ERR_DOC_VERSION'=> 'Dokument Version',
	'ERR_DELETE_CONFIRM'=> 'Vil du slette dette dokuments revision?',
	'ERR_DELETE_LATEST_VERSION'=> 'Du har ikke tilladelse til at slette den seneste revision af et dokument.',

);


?>
