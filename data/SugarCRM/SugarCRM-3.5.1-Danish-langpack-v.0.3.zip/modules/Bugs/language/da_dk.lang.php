<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.14 2005/09/12 22:00:52 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Fejl Finder',
  'LBL_MODULE_TITLE' => 'Fejl Finder: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Fejl S�gning',
  'LBL_LIST_FORM_TITLE' => 'Fejl Liste',
  'LBL_NEW_FORM_TITLE' => 'Ny Fejl',
  'LBL_CONTACT_BUG_TITLE' => 'KontaKt-Fejl:',
  'LBL_SUBJECT' => 'Overskrift:',
  'LBL_BUG' => 'Fejl:',
  'LBL_BUG_NUMBER' => 'Fejl Nummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_BUG_SUBJECT' => 'Fejl Overskrift:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Nr.',
  'LBL_LIST_SUBJECT' => 'Overskrift',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Prioritet',
  'LBL_LIST_RELEASE' => 'Udgivelse',
  'LBL_LIST_RESOLUTION' => 'L�sning',
  'LBL_LIST_LAST_MODIFIED' => 'Sidst Rettet',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_TYPE' => 'Type:',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_RESOLUTION' => 'L�sning:',
  'LBL_RELEASE' => 'Udgivelse:',
  'LNK_NEW_BUG' => 'Rapport�r fejl',
  'LNK_BUG_LIST' => 'Fejl',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� at du vil fjerne denne kontakt fra fejlen?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne fejl fra denne konto?',
  'ERR_DELETE_RECORD' => 'Et data nummer skal v�re valgt for at slette fejlen.',
  'LBL_LIST_MY_BUGS' => 'Mine tildelte fejl',
  
  'LBL_FOUND_IN_RELEASE' => 'Fundet i udgivelse:',
  'LBL_FIXED_IN_RELEASE' => 'Fixet i udgivelse:',
  'LBL_WORK_LOG' => 'Arbejds Log:',
  'LBL_SOURCE' => 'Kilde:',
  'LBL_PRODUCT_CATEGORY' => 'Kategori:',
  
  'LBL_CREATED_BY' => 'Oprettet af:',
  'LBL_DATE_CREATED' => 'Oprettet Dato:',
  'LBL_MODIFIED_BY' => 'Sidst rettet af:',
  'LBL_DATE_LAST_MODIFIED' => 'Rettet Dato:',

  'LBL_LIST_EMAIL_ADDRESS' => 'Email Adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto Navn',
  'LBL_LIST_PHONE' => 'Telefon',
  'NTC_DELETE_CONFIRMATION' => 'Er Du dikker p� at du vil fjerne denne kontakt fra denne fejl?',
  
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Fejl Finder',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Kontoer',
  'LBL_CASES_SUBPANEL_TITLE' => 'Sager',
    
  );


?>
