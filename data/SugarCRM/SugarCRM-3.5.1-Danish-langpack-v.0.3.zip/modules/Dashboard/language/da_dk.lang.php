<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.39 2005/09/21 17:37:40 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
    'ERR_NO_OPPS' => 'Opret venligst nogle Muligheder for at se Muligheds grafer.',
    'LBL_ALL_OPPORTUNITIES' => 'Total m�ngde af alle muligheder er ',
    'LBL_CREATED_ON' => 'Sidst k�rt d. ',
    'LBL_DATE_END' => 'Slut Dato:',
    'LBL_DATE_RANGE_TO' => 'til',
    'LBL_DATE_RANGE' => 'Dato afstand er',
    'LBL_DATE_START' => 'Start Dato:',
    'LBL_EDIT' => 'Rediger',
    'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Viser kumulativ muligheds m�ngde af valgte ledende kilde af resultatet for valgte brugere hvor den beregnede lukke dato er indenfor den specificerede dato afstand. Resultatet er baseret p� om salgs stadiet er Lukket Vundet, Lukket Tabt eller et andet antal.',
    'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Alle muligheder af Ledende Kilde af resultat',
    'LBL_LEAD_SOURCE_FORM_DESC' => 'Viser kumulativ muligheds m�ngde af valgte ledende kilde for valgte brugere.',
    'LBL_LEAD_SOURCE_FORM_TITLE' => 'Alle muligheder Af Ledende Kilde',
    'LBL_LEAD_SOURCE_OTHER' => 'Andet',
    'LBL_LEAD_SOURCES' => 'Ledende Kilde:',
    'LBL_MODULE_NAME' => 'Dashboard',
    'LBL_MODULE_TITLE' => 'Dashboard: Hjem',
    'LBL_MONTH_BY_OUTCOME_DESC' => 'Viser kumulativ muligheds m�ngde af valgte ledende kilde af resultatet for valgte brugere hvor den beregnede lukke dato er indenfor den specificerede dato afstand. Resultatet er baseret p� om salgs stadiet er Lukket Vundet, Lukket Tabt eller et andet antal.',
    'LBL_OPP_SIZE' => 'Muligheds st�rrelse i',
    'LBL_OPP_THOUSANDS'=> 'K',
    'LBL_OPPS_IN_LEAD_SOURCE' => 'muligheder hvor ledende kilde er',
    'LBL_OPPS_IN_STAGE' => ' hvor salgs stadiet er',
    'LBL_OPPS_OUTCOME' => ' hvor resultatet er',
    'LBL_OPPS_WORTH' => 'muligheder v�rdi',
    'LBL_PIPELINE_FORM_TITLE_DESC' => 'Viser kumulativ muligheds m�ngde af valgte ledende kilde af resultatet for valgte brugere hvor den beregnede lukke dato er indenfor den specificerede dato afstand.',
    'LBL_REFRESH' => 'Opdater',
    'LBL_ROLLOVER_DETAILS' => 'K�r over en bar for at vise detaljer.',
    'LBL_ROLLOVER_WEDGE_DETAILS' => 'K�r over wedge for detaljer.',
    'LBL_SALES_STAGE_FORM_DESC' => 'Viser kumulativ muligheds m�ngde af valgte ledende kilde af resultatet for valgte brugere hvor den beregnede lukke dato er indenfor den specificerede dato afstand.',
    'LBL_SALES_STAGE_FORM_TITLE' => 'Pipeline Af Salgs Stadie',
    'LBL_SALES_STAGES' => 'Salgs Stadier:',
    'LBL_TOTAL_PIPELINE' => 'Pipeline total er ',
    'LBL_USERS' => 'Brugere:',
    'LBL_YEAR_BY_OUTCOME' => 'Pipeline Af M�ned Af Resultat',
    'LBL_YEAR' => '�r:',
    'LNK_NEW_ACCOUNT' => 'Opret Konto',
    'LNK_NEW_CALL' => 'Skemal�g Opkald',
    'LNK_NEW_CASE' => 'Opret Sag',
    'LNK_NEW_CONTACT' => 'Opret Kontakt',
    'LNK_NEW_ISSUE' => 'Reporter Fejl',
    'LNK_NEW_LEAD' => 'Opret Emne',
    'LNK_NEW_MEETING' => 'Skemal�g M�de',
    'LNK_NEW_NOTE' => 'Opret Note eller Vedh�ftning',
    'LNK_NEW_OPPORTUNITY' => 'Opret Mulighed',
    'LNK_NEW_QUOTE' => 'Opret Citat',
    'LNK_NEW_TASK' => 'Opret Opgave',
    'NTC_NO_LEGENDS' => 'Ingen',
);


?>
