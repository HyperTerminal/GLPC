﻿Descriere
=========

Acest pachet vă oferă distribuţia SugarCRM OS în limba română. Encoding-ul folosit este UTF-8 (no Byte Order Mark).

Instalare
=========

1. Pe contul admin mergeţi în 'Administration: Home' şi accesaţi 'Module Loader'
2. Dacă se face upgrade, daţi clic pe butonul 'Uninstall' din dreptul vechiului pachet
3. Daţi clic pe 'Browse', alegeţi arhiva .zip unde se află acest pachet apoi 'Open' şi 'Upload'
4. Daţi clic pe butonul 'Install' din dreptul noului pachet
5. Verificaţi că este totul bifat şi daţi clic pe 'Commit'
6. Daţi 'Logout' şi veţi avea o nouă limbă de ales în dialogul de autentificare


Succes!