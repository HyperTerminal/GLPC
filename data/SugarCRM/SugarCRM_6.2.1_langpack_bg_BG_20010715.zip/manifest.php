<?php 
$manifest = array(
    array (
        'exact_matches' => array (
        ),
        'regex_matches' => array (
            0 => '6\.2\.1'
        ),
    ),
	'name' => 'Български',
	'description' => 'Българска локализация за SugarCRM 6.2.1',
	'id'=> 'bg_bg',
	'lang_file_suffix' => 'bg_bg',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '621-110716',
	'acceptable_sugar_flavors' => array(0=>'CE'),
	'published_date' => '2011/07/16',
	'author' => 'CreaSoft.biz',
);
?>
