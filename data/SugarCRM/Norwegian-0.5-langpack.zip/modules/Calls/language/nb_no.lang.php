<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Oppringning',
  'LBL_MODULE_TITLE' => 'Oppringning: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k Oppringning',
  'LBL_LIST_FORM_TITLE' => 'Liste Oppringninger',
  'LBL_NEW_FORM_TITLE' => 'Avtal Oppringning',
  'LBL_LIST_CLOSE' => 'Avslutt',
  'LBL_LIST_SUBJECT' => 'Vedr�rende',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Relatert til',
  'LBL_LIST_DATE' => 'Start Dato',
  'LBL_LIST_TIME' => 'Start Tid',
  'LBL_LIST_DURATION' => 'Varighet',
  'LBL_LIST_DIRECTION' => 'Retning',
  'LBL_SUBJECT' => 'Vedr�rende:',
  'LBL_REMINDER' => 'P�minnelse:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_STATUS' => 'Status:',
  'LBL_DIRECTION' => 'Sorter:',
  'LBL_DATE' => 'Start Dato:',
  'LBL_DURATION' => 'Varighet:',
  'LBL_DURATION_HOURS' => 'Varighet Timer:',
  'LBL_DURATION_MINUTES' => 'Varighet Minutter:',
  'LBL_HOURS_MINUTES' => '(timer/minutter)',
  'LBL_CALL' => 'Oppringning:',
  'LBL_DATE_TIME' => 'Start Dato & Tid:',
  'LBL_TIME' => 'Start Tid:',
  'LBL_HOURS_ABBREV' => 't',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planlagt',
  'LNK_NEW_CALL' => 'Ny Oppringning',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_EMAIL' => 'Ny E-post',
  'LNK_CALL_LIST' => 'Oppringninger',
  'LNK_MEETING_LIST' => 'M�ter',
  'LNK_TASK_LIST' => 'Oppgaver',
  'LNK_NOTE_LIST' => 'Notater',
  'LNK_EMAIL_LIST' => 'E-post',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'ERR_DELETE_RECORD' => 'Et ref nr m� oppgis for � slette oppf�ringen.',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� � fjerne den inviterte fra Oppringning?',
  'LBL_INVITEE' => 'Initiativtaker',
  'LBL_RELATED_TO' => 'Relatert til:',
  'LNK_NEW_APPOINTMENT' => 'Opprett Avtale',
  'LBL_SCHEDULING_FORM_TITLE' => 'Tidsplan',
  'LBL_ADD_INVITEE' => 'Legg til deltakere',
  'LBL_NAME' => 'Navn',
  'LBL_FIRST_NAME' => 'Fornavn',
  'LBL_LAST_NAME' => 'Etternavn',
  'LBL_EMAIL' => 'E-post',
  'LBL_PHONE' => 'Tlf',
  'LBL_SEND_BUTTON_TITLE' => 'Send deltakerinvitasjoner [Alt+I]',
  'LBL_SEND_BUTTON_KEY' => 'I',
  'LBL_SEND_BUTTON_LABEL' => 'Send deltakerinvitasjoner',
  'LBL_DATE_END' => 'Dato Slutt',
  'LBL_TIME_END' => 'Tid Slutt',
  'LBL_REMINDER_TIME' => 'P�minnelses Tid',
  'LBL_SEARCH_BUTTON' => 'S�k',
  'LBL_ADD_BUTTON' => 'Legg til',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Oppringninger',
  'LBL_LOG_CALL' => 'Loggf�r Oppringning',
  'LNK_SELECT_ACCOUNT' => 'Velg Bel�p',
  'LNK_NEW_ACCOUNT' => 'Ny Konto',
  'LNK_NEW_OPPORTUNITY' => 'Ny SalgsmMulighet',
  'LBL_DEL' => 'Slett',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_USERS_SUBPANEL_TITLE' => 'Brukere',
  'LBL_OUTLOOK_ID' => 'Outlook ID',
  'LBL_MEMBER_OF' => 'Medlem av',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Notater',
)

?>
