<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' => 'Et referansenr m� oppgis for � slette Oppf�ringen.',
  'LBL_ACCOUNT_ID' => 'Virksomhet ID:',
  'LBL_CASE_ID' => 'Hendelse ID:',
  'LBL_CLOSE' => 'Avsluttet:',
  'LBL_COLON' => ':',
  'LBL_CONTACT_ID' => 'Kontakt ID:',
  'LBL_CONTACT_NAME' => 'Kontaktnavn:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Notater',
  'LBL_DESCRIPTION' => 'Beskrivelse',
  'LBL_EMAIL_ADDRESS' => 'E-post adresse:',
  'LBL_FILE_MIME_TYPE' => 'Mime Type',
  'LBL_FILE_URL' => 'Fil URL',
  'LBL_FILENAME' => 'Vedlegg:',
  'LBL_LEAD_ID' => 'Mulighet ID:',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_LIST_DATE_MODIFIED' => 'Sist Oppdatert',
  'LBL_LIST_FILENAME' => 'Vedlegg',
  'LBL_LIST_FORM_TITLE' => 'Vis Notater',
  'LBL_LIST_RELATED_TO' => 'Relatert til',
  'LBL_LIST_SUBJECT' => 'Vedr�rende',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_MODULE_NAME' => 'Notater',
  'LBL_MODULE_TITLE' => 'Notater : Hjem',
  'LBL_NEW_FORM_TITLE' => 'Nytt Notat',
  'LBL_NOTE_STATUS' => 'Note',
  'LBL_NOTE_SUBJECT' => 'Notat vedr�rende:',
  'LBL_NOTE' => 'Notat:',
  'LBL_OPPORTUNITY_ID' => 'Salgsmulighet ID:',
  'LBL_PARENT_ID' => 'Forelder ID:',
  'LBL_PARENT_TYPE' => 'Forelder Type',
  'LBL_PHONE' => 'Telefon:',
  'LBL_PORTAL_FLAG' => 'Vis i Portal?',
  'LBL_PRODUCT_ID' => 'Produkt ID:',
  'LBL_QUOTE_ID' => 'Tilbud ID:',
  'LBL_RELATED_TO' => 'Relatert til:',
  'LBL_SEARCH_FORM_TITLE' => 'S�k Notater',
  'LBL_STATUS' => 'Status',
  'LBL_SUBJECT' => 'Vedr�rende:',
  'LNK_CALL_LIST' => 'Oppringninger',
  'LNK_EMAIL_LIST' => 'E-post',
  'LNK_IMPORT_NOTES' => 'Importer Notater',
  'LNK_MEETING_LIST' => 'M�ter',
  'LNK_NEW_CALL' => 'Ny Oppringning',
  'LNK_NEW_EMAIL' => 'Ny E-post',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NOTE_LIST' => 'Notater',
  'LNK_TASK_LIST' => 'Oppgaver',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_MEMBER_OF' => 'Medlem av:',
)

?>
