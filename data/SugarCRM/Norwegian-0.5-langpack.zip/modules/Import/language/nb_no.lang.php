<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Mappen finnes ikke',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => 'Finnes ikke, eller man kan ikke skrive til den',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Filen ble ikke lastet opp, pr�v igjen',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Filen er for stor. Maks:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Byte. Endre $upload_maxsize i config.php',
  'LBL_MODULE_NAME' => 'Import',
  'LBL_TRY_AGAIN' => 'Pr�v igjen',
  'LBL_ERROR' => 'Feil:',
  'ERR_MULTIPLE' => 'Flere kolonner har blitt oppgitt med samme navn.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Manglende p�krevde felt:',
  'ERR_SELECT_FULL_NAME' => 'Du kan ikke velge Fullt Navn n�r Fornavn og Etternavn er valgt.',
  'ERR_SELECT_FILE' => 'Velg filen som skal lastes opp.',
  'LBL_SELECT_FILE' => 'Velg fil:',
  'LBL_CUSTOM' => 'Vanlig',
  'LBL_CUSTOM_CSV' => 'Vanlig komma separert fil',
  'LBL_CUSTOM_TAB' => 'Vanlig Tab separert fil',
  'LBL_DONT_MAP' => '-- Ikke velg dette feltet --',
  'LBL_STEP_1_TITLE' => 'Steg 1: Velg kilde',
  'LBL_WHAT_IS' => 'Hva slags datakilde skal brukes?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Mine lagrede kilder:',
  'LBL_PUBLISH' => 'publiser',
  'LBL_DELETE' => 'slett',
  'LBL_PUBLISHED_SOURCES' => 'Publiserte Kilder:',
  'LBL_UNPUBLISH' => 'av-publiser',
  'LBL_NEXT' => 'Neste >',
  'LBL_BACK' => '< Tilbake',
  'LBL_STEP_2_TITLE' => 'Steg 2: Last opp Eksport Fil',
  'LBL_HAS_HEADER' => 'Har Toppfelt:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'N�, velg filen som skal importeres:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 og 2000 kan eksportere data som Komma separerte verdier. Dette kan brukes til � importere verdiene inn i dette systemet. F�lg instruksjonene under for � eksportere data fra Outlook:',
  'LBL_OUTLOOK_NUM_1' => 'Start Outlook',
  'LBL_OUTLOOK_NUM_2' => 'Velg Fil menyen, s� Import og Eksport feltet fra menyen',
  'LBL_OUTLOOK_NUM_3' => 'Velg Eksport til fil og klikk Neste',
  'LBL_OUTLOOK_NUM_4' => 'Velg Komma Separerte Verdier (Windows) og klikk Neste. Merk: Du kan bli bedt om � installere eksport-komponenten.',
  'LBL_OUTLOOK_NUM_5' => 'Select the Contacts folder and click Next. You can select different contacts folders if your contacts are stored in multiple folders',
  'LBL_OUTLOOK_NUM_6' => 'Choose a filename and click Next',
  'LBL_OUTLOOK_NUM_7' => 'Click Finish',
  'LBL_IMPORT_ACT_TITLE' => 'Act! can export data in the Comma Separated Values format which can be used to import data into the system. To export your data from Act!, follow the steps below:',
  'LBL_ACT_NUM_1' => 'Launch ACT!',
  'LBL_ACT_NUM_2' => 'Select the File menu, the Data Exchange menu option, then the Export... menu option',
  'LBL_ACT_NUM_3' => 'Select the file type Text-Delimited',
  'LBL_ACT_NUM_4' => 'Choose a filename and location for the exported data and click Next',
  'LBL_ACT_NUM_5' => 'Select Contacts records only',
  'LBL_ACT_NUM_6' => 'Click the Options... button',
  'LBL_ACT_NUM_7' => 'Select Comma as the field separator character',
  'LBL_ACT_NUM_8' => 'Check the Yes, export field names checkbox and click OK',
  'LBL_ACT_NUM_9' => 'Click Next',
  'LBL_ACT_NUM_10' => 'Select All Records and then Click Finish',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com can export data in the Comma Separated Values format which can be used to import data into the system. To export your data from Salesforce.com, follow the steps below:',
  'LBL_SF_NUM_1' => 'Open your browser, go to http://www.salesforce.com, and login with your email address and password',
  'LBL_SF_NUM_2' => 'Click on the Reports tab on the top menu',
  'LBL_SF_NUM_3' => 'To export Accounts: Click on the Active Accounts link
To export Contacts: Click on the Mailing List link',
  'LBL_SF_NUM_4' => 'On Step 1: Select your report type, select Tabular Reportclick Next',
  'LBL_SF_NUM_5' => 'On Step 2: Select the report columns, choose the columns you want to export and click Next',
  'LBL_SF_NUM_6' => 'On Step 3: Select the information to summarize, just click Next',
  'LBL_SF_NUM_7' => 'On Step 4: Order the report columns, just click Next',
  'LBL_SF_NUM_8' => 'On Step 5: Select your report criteria, under Start Date, choose a date far enough in the past to include all your Accounts. You can also export a subset of Accounts using more advanced criteria. When you are done, click Run Report',
  'LBL_SF_NUM_9' => 'A report will be generated, and the page should display Report Generation Status: Complete. Now click Export to Excel',
  'LBL_SF_NUM_10' => 'On Export Report:, for Export File Format:, choose Comma Delimited .csv. Click Export.',
  'LBL_SF_NUM_11' => 'A dialog will pop up for you to save the export file to your computer.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Mange programmer tillater eksportering av data v.hj.a. en Komma separert tekst file (.tsv or .tab). Vanligvis kan en bruke f�lgende prosedyre i de fleste programmer:',
  'LBL_CUSTOM_NUM_1' => 'Start programmet og �pne filen du �nsker og eksportere',
  'LBL_CUSTOM_NUM_2' => 'Velg Lagre Som... eller Eksport... menyvalg',
  'LBL_CUSTOM_NUM_3' => 'Lagre filen i CSV eller Komma Separerte Verdier format',
  'LBL_IMPORT_TAB_TITLE' => 'Mange programmer tillater eksportering av data v.hj.a. en Tab-oppdelt tekst file (.tsv or .tab). Vanligvis kan en bruke f�lgende prosedyre i de fleste programmer:',
  'LBL_TAB_NUM_1' => 'Launch the application and Open the data file',
  'LBL_TAB_NUM_2' => 'Velg Lagre Som... eller Eksport... menyvalg',
  'LBL_TAB_NUM_3' => 'Lagre filen i et TSV eller Tab Separert format',
  'LBL_STEP_3_TITLE' => 'Steg 3: Bekreft Felt og Importer',
  'LBL_SELECT_FIELDS_TO_MAP' => 'I listen under, velg feltene i importfilen som du �nsker � importere inn i de forskjellige feltene i systemet. N�r du er ferdig, klikk Importer N�:',
  'LBL_DATABASE_FIELD' => 'Database Felt',
  'LBL_HEADER_ROW' => 'Topp Rad',
  'LBL_ROW' => 'Rad',
  'LBL_SAVE_AS_CUSTOM' => 'Lagre med spesiell oppdeling:',
  'LBL_CONTACTS_NOTE_1' => 'Enten Etternavn eller Fullt navn m� bestemmes.',
  'LBL_CONTACTS_NOTE_2' => 'Hvis Fullt Navn er valg, da ignoreres Fornavn og Etteravn.',
  'LBL_CONTACTS_NOTE_3' => 'Hvis Fullt Navn velges, da vil Fullt Navn deles opp i Fornavn og Etternavn n�r det blir lagret i databasen.',
  'LBL_CONTACTS_NOTE_4' => 'Felt som ender i Adresse Gate/Vei 2 og Adresse Gate/Vei 3 vil bli satt sammen i Adresse Gate/Vei feltet n�r det lagres i databasen.',
  'LBL_ACCOUNTS_NOTE_1' => 'Kontonavn m� bestemmes.',
  'LBL_ACCOUNTS_NOTE_2' => 'Felt som ender i Adresse Gate/Vei 2 og Adresse Gate/Vei 3 vil bli satt sammen i Adresse Gate/Vei feltet n�r det lagres i databasen.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Mulighet Navn, Konto Navn, Dato Avsluttet, og Salgs Trinn er p�krevde felt.',
  'LBL_IMPORT_NOW' => 'Importer N�',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Kan ikke �pne den importerte filen',
  'LBL_NOT_SAME_NUMBER' => 'Det var ikke likt antall felt per linje i filen du ville importere',
  'LBL_NO_LINES' => 'Fant ingen linjer i importfilen',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Importfilen har allerede blitt prosessert eller s� eksisterer den ikke',
  'LBL_SUCCESS' => 'Fullf�rt:',
  'LBL_SUCCESSFULLY' => 'Import fullf�rt',
  'LBL_LAST_IMPORT_UNDONE' => 'Din siste import ble angret',
  'LBL_NO_IMPORT_TO_UNDO' => 'Fant ingen import og angre.',
  'LBL_FAIL' => 'Feilet:',
  'LBL_RECORDS_SKIPPED' => 'hoppet over elementer',
  'LBL_IDS_EXISTED_OR_LONGER' => 'id\'er eksisterte allerede eller var lengre enn 36 tegn',
  'LBL_RESULTS' => 'Resultater',
  'LBL_IMPORT_MORE' => 'Importer Mer',
  'LBL_FINISHED' => 'Fullf�rt',
  'LBL_UNDO_LAST_IMPORT' => 'Angre Siste Import',
  'LBL_LAST_IMPORTED' => 'Sist Importert',
  'ERR_MULTIPLE_PARENTS' => 'Du kan bare ha en forelder ID definert',
)

?>
