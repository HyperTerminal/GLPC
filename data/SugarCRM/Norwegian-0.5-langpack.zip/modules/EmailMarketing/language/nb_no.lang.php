<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Epost Markedsf�ring',
  'LBL_MODULE_TITLE' => 'Epost Markedsf�ring: Hjem',
  'LBL_LIST_FORM_TITLE' => 'Epost Markedsf�ring Kampanjer',
  'LBL_PROSPECT_LIST_NAME' => 'Navn:',
  'LBL_NAME' => 'Navn: ',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_FROM_ADDR' => 'Fra Epost',
  'LBL_LIST_DATE_START' => 'Start Dato',
  'LBL_LIST_TEMPLATE_NAME' => 'Epost Mal',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_STATUS' => 'Status',
  'LBL_STATUS_TEXT' => 'Status:',
  'LBL_DATE_ENTERED' => 'Dato Opprettet',
  'LBL_DATE_MODIFIED' => 'Dato Endret',
  'LBL_MODIFIED' => 'Endret Av: ',
  'LBL_CREATED' => 'Opprettet Av: ',
  'LBL_MESSAGE_FOR' => 'Send This Message To:',
  'LBL_MESSAGE_FOR_ID' => 'Message For',
  'LBL_FROM_NAME' => 'Fra Navn: ',
  'LBL_FROM_ADDR' => 'Fra Epost Adresse: ',
  'LBL_DATE_START' => 'Start Dato',
  'LBL_TIME_START' => 'Start Tid',
  'LBL_START_DATE_TIME' => 'Start Dato & Tid: ',
  'LBL_TEMPLATE' => 'Epost Mal: ',
  'LBL_MODIFIED_BY' => 'Endret av: ',
  'LBL_CREATED_BY' => 'Opprettet Av: ',
  'LBL_DATE_CREATED' => 'Opprettet dato: ',
  'LBL_DATE_LAST_MODIFIED' => 'Endret dato: ',
  'LNK_NEW_CAMPAIGN' => 'Opprett Kampanje',
  'LNK_CAMPAIGN_LIST' => 'Kampanjer',
  'LNK_NEW_PROSPECT_LIST' => 'Lag Prospekt Liste',
  'LNK_PROSPECT_LIST_LIST' => 'Prospekt Liste',
  'LNK_NEW_PROSPECT' => 'Opprett Prospekt',
  'LNK_PROSPECT_LIST' => 'Prospekter',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Epost Markedsf�ring',
  'LBL_CREATE_EMAIL_TEMPLATE' => 'Create',
  'LBL_EDIT_EMAIL_TEMPLATE' => 'Edit',
  'LBL_FROM_MAILBOX' => 'From Mailbox',
  'LBL_FROM_MAILBOX_NAME' => 'Use Mailbox:',
  'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => 'Target Lists',
  'LBL_ALL_PROSPECT_LISTS' => 'All Target Lists in the Campaign.',
  'LBL_RELATED_PROSPECT_LISTS' => 'All Target Lists related to this message.',
  'LBL_LIST_PROSPECT_LIST_NAME' => 'Targeted Lists',
  'LBL_MODULE_SEND_TEST' => 'Campaign: Send Test',
  'LBL_MODULE_SEND_EMAILS' => 'Campaign: Send Emails',
  'LBL_SCHEDULE_MESSAGE_TEST' => 'Please select the campaign messages that you would like to send test:',
  'LBL_SCHEDULE_MESSAGE_EMAILS' => 'Please select the campaign messages that you would like to schedule for sending at specified start date and time:',
  'LBL_SCHEDULE_BUTTON_TITLE' => 'Send',
  'LBL_SCHEDULE_BUTTON_LABEL' => 'Send',
  'LBL_SCHEDULE_BUTTON_KEY' => 'T',
)

?>
