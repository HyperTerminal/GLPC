<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_ID' => 'Id',
  'LBL_OLD_ID' => 'Old Id',
  'LBL_LIST_CAMPAIGN' => 'Kampanje',
  'LBL_LIST_FORM_PROCESSED_TITLE' => 'Behandlet',
  'LBL_LIST_FORM_TITLE' => 'K�',
  'LBL_LIST_FROM_EMAIL' => 'Fra Epost',
  'LBL_LIST_FROM_NAME' => 'Fra Navn',
  'LBL_LIST_IN_QUEUE' => 'Under Behandling',
  'LBL_LIST_RECIPIENT_EMAIL' => 'Mottaker Epost',
  'LBL_LIST_RECIPIENT_NAME' => 'Mottaker Navn',
  'LBL_LIST_SEND_ATTEMPTS' => 'Sende Fors�k',
  'LBL_LIST_SEND_DATE_TIME' => 'Sendt',
  'LBL_LIST_USER_NAME' => 'Bruker Navn',
  'LBL_MODULE_TITLE' => 'Epost K� Administrasjon',
  'LBL_SEARCH_FORM_PROCESSED_TITLE' => 'Behandlet S�k',
  'LBL_SEARCH_FORM_TITLE' => 'K� S�k',
  'LBL_VIEW_PROCESSED_EMAILS' => 'Se Bahandlet Epost',
  'LBL_VIEW_QUEUED_EMAILS' => 'Se Epost i K�',
  'LBL_RELATED_ID' => 'Related Id',
  'LBL_RELATED_TYPE' => 'Related Type',
  'LBL_MARKETING_ID' => 'Marketing Id',
  'LBL_LIST_MESSAGE_NAME' => 'Marketing Message',
  'LBL_MODULE_NAME' => 'Mass Emailer',
  'LBL_CONFIGURE_SETTINGS' => 'Configure',
  'LBL_EMAILS_PER_RUN' => 'Number of emails sent per batch:',
  'LBL_EMAIL_PER_RUN_REQ' => 'Number of emails sent per batch:',
  'LBL_LOCATION_ONLY' => 'Location',
  'LBL_LOCATION_TRACK' => 'Location of campaign tracking files (like campaign_tracker.php)',
  'LBL_DEFAULT_LOCATION' => 'Default',
  'LBL_CUSTOM_LOCATION' => 'User Defined',
  'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE' => 'Value of Config.php setting site_url',
  'ERR_INT_ONLY_EMAIL_PER_RUN' => 'Only integer values are allow for Number of emails sent per batch',
  'TXT_REMOVE_ME' => 'To remove yourself from this email list ',
  'TXT_REMOVE_ME_ALT' => 'To remove yourself from this email list go to',
  'TXT_REMOVE_ME_CLICK' => 'click here',
)

?>
