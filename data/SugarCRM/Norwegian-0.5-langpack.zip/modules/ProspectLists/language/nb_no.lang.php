<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Utvalgte m�l',
  'LBL_MODULE_TITLE' => 'Utvalgte m�l: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Utvalgte m�l S�k',
  'LBL_LIST_FORM_TITLE' => 'Utvalgte m�l',
  'LBL_PROSPECT_LIST_NAME' => 'Navn:',
  'LBL_NAME' => 'Navn: ',
  'LBL_ENTRIES' => 'Totale Oppf�ringer: ',
  'LBL_LIST_PROSPECT_LIST_NAME' => 'Utvalgte m�l',
  'LBL_LIST_ENTRIES' => 'Oppf�ringer',
  'LBL_LIST_DESCRIPTION' => 'Beskrivelse',
  'LBL_LIST_TYPE_NO' => 'Type',
  'LBL_LIST_END_DATE' => 'Sluttdato',
  'LBL_DATE_ENTERED' => 'Opprettet Dato',
  'LBL_DATE_MODIFIED' => 'Endret Dato',
  'LBL_MODIFIED' => 'Modifisert av: ',
  'LBL_CREATED' => 'Opprettet av: ',
  'LBL_TEAM' => 'Team: ',
  'LBL_ASSIGNED_TO' => 'Tilegnet: ',
  'LBL_DESCRIPTION' => 'Beskrivelse: ',
  'LNK_NEW_CAMPAIGN' => 'Opprett Kampanje',
  'LNK_CAMPAIGN_LIST' => 'Kampanjer',
  'LNK_NEW_PROSPECT_LIST' => 'Opprett liste',
  'LNK_PROSPECT_LIST_LIST' => 'Utvalgte m�l',
  'LBL_MODIFIED_BY' => 'Endret av: ',
  'LBL_CREATED_BY' => 'Opprettet av: ',
  'LBL_DATE_CREATED' => 'Opprettet dato: ',
  'LBL_DATE_LAST_MODIFIED' => 'Endret dato: ',
  'LNK_NEW_PROSPECT' => 'Opprett Prospekt',
  'LNK_PROSPECT_LIST' => 'Utvalgte m�l',
  'LBL_PROSPECT_LISTS_SUBPANEL_TITLE' => 'Utvalgte m�l',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Mulige kunder',
  'LBL_PROSPECTS_SUBPANEL_TITLE' => 'Utvalgte M�l',
  'LBL_COPY_PREFIX' => 'kopi av',
  'LBL_USERS_SUBPANEL_TITLE' => 'Brukere',
  'LBL_TYPE' => 'Type',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_LIST_TYPE_LIST_NAME' => 'Type',
  'LBL_NEW_FORM_TITLE' => 'Ny liste',
  'LBL_MARKETING_MESSAGE' => 'E-post Marketing budskap',
  'LBL_DOMAIN_NAME' => 'Domene navn',
  'LBL_DOMAIN' => 'Ingen E-post til domene:',
)

?>
