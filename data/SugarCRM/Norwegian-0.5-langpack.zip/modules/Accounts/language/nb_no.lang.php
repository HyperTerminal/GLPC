<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Konto',
  'LBL_MODULE_TITLE' => 'Konto: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k Konto',
  'LBL_LIST_FORM_TITLE' => 'Kontoer',
  'LBL_NEW_FORM_TITLE' => 'Ny Konto',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Medlemsorganisasjoner',
  'LBL_BUG_FORM_TITLE' => 'Kontoer',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto',
  'LBL_LIST_CITY' => 'By',
  'LBL_LIST_WEBSITE' => 'Webside',
  'LBL_LIST_STATE' => 'Fylke',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'E-post Adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
  'LBL_BILLING_ADDRESS_STREET_2' => 'Faktura Gateadresse 2',
  'LBL_BILLING_ADDRESS_STREET_3' => 'Faktura Gateadresse 3',
  'LBL_BILLING_ADDRESS_STREET_4' => 'Faktura Gateadresse 4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Levering Gaeadresse 2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Levering Gateadresse 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Levering Gateadresse 4',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
  'LBL_ACCOUNT_INFORMATION' => 'Konto Info',
  'LBL_ACCOUNT' => 'Konto:',
  'LBL_ACCOUNT_NAME' => 'Konto:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_PHONE_ALT' => 'Alternativ Telefon:',
  'LBL_WEBSITE' => 'Webside:',
  'LBL_FAX' => 'Faks:',
  'LBL_TICKER_SYMBOL' => 'B�rs Symbol:',
  'LBL_OTHER_PHONE' => 'Annet Telefonnr:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_MEMBER_OF' => 'Medlem av:',
  'LBL_PHONE_OFFICE' => 'Telefon Arbeid',
  'LBL_PHONE_FAX' => 'Tlf Faks:',
  'LBL_EMAIL' => 'E-post:',
  'LBL_EMPLOYEES' => 'Ansatte:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Annen E-post:',
  'LBL_ANY_EMAIL' => 'E-post:',
  'LBL_OWNERSHIP' => 'Eierskap:',
  'LBL_RATING' => 'Vurdering:',
  'LBL_INDUSTRY' => 'Bransje:',
  'LBL_SIC_CODE' => 'SIC Kode:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => '�rlig Omsetning:',
  'LBL_ADDRESS_INFORMATION' => 'Adresse info',
  'LBL_BILLING_ADDRESS' => 'Faktura adresse:',
  'LBL_BILLING_ADDRESS_STREET' => 'Faktureringsadresse Gate/ Vei:',
  'LBL_BILLING_ADDRESS_CITY' => 'Faktureringsadresse Sted/ By:',
  'LBL_BILLING_ADDRESS_STATE' => 'Faktureringsadresse Fylke:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Faktureringsadresse Postnummer:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Faktureringsadresse Land:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Leveringsadresse Gate/ Vei:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Leveringsadresse Sted/ By:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Leveringsadresse Fylke:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Leveringsadresse Postnummer:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Leveringsadresse Land:',
  'LBL_SHIPPING_ADDRESS' => 'Postadresse:',
  'LBL_DATE_MODIFIED' => 'Dato Endret:',
  'LBL_DATE_ENTERED' => 'Dato opprettet:',
  'LBL_ANY_ADDRESS' => 'Annen adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Fylke:',
  'LBL_POSTAL_CODE' => 'Postnr:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_PUSH_CONTACTS_BUTTON_TITLE' => 'Kopier til..',
  'LBL_PUSH_CONTACTS_BUTTON_LABEL' => 'Kopier til kontakter',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopier Faktura adresse til Postadresse',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopier Postadresse til Faktura adresse',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne oppf�ringen som medlems organisasjon?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Er du sikker p� at du vil fjerne denne oppf�ringen?',
  'LBL_DUPLICATE' => 'Mulig Duplikat Konto',
  'MSG_SHOW_DUPLICATES' => 'Opprettelse av denne kontakten kan f�re til duplikate kontakter. Du kan enten klikke p� Opprett for � fortsette opprettelsen av denne kontakten, eller du kan trykke p� avbryt.',
  'MSG_DUPLICATE' => 'Opprettlese av denne kontakten kan f�re til duplikater. Du kan enten velge en kontakt fra listen under, eller du kan klikke p� Opprett Kontakt for � fortsette oprettelsen av kontakten med de allerede innlagte date.',
  'LNK_NEW_ACCOUNT' => 'Ny Konto',
  'LNK_ACCOUNT_LIST' => 'Kontoer',
  'LBL_INVITEE' => 'Kontakter',
  'ERR_DELETE_RECORD' => 'Et ref nr m� oppgis for � slette Oppf�ringen.',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p� at du vill slette denne oppf�ringen?',
  'LBL_SAVE_ACCOUNT' => 'Lagre Konto',
  'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Er du sikker p� at du vil fjerne oppf�ringen fra dette prosjektet?',
  'LBL_USERS_ASSIGNED_LINK' => 'Tilordnede Brukere',
  'LBL_USERS_MODIFIED_LINK' => 'Endrede Brukere',
  'LBL_USERS_CREATED_LINK' => 'Opprettet av Brukere',
  'LBL_TEAMS_LINK' => 'Team',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kontoer',
  'LBL_PRODUCTS_TITLE' => 'Produkter',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteter',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historie',
  'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Medlemsorganisasjoner',
  'LBL_NAME' => 'Navn:',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Salgsmuligheter',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Mulige kunder',
  'LBL_CASES_SUBPANEL_TITLE' => 'Support',
  'LBL_BUGS_SUBPANEL_TITLE' => 'Bugs',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Prosjekter',
  'LBL_ASSIGNED_TO_NAME' => 'Tilknyttet:',
)

?>
