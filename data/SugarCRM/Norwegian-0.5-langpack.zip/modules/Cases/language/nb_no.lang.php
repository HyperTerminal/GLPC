<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Hendelse',
  'LBL_MODULE_TITLE' => 'Hendelse : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k Hendelser',
  'LBL_LIST_FORM_TITLE' => 'Hendelsesliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Hendelse',
  'LBL_CONTACT_CASE_TITLE' => 'Kontakt-Hedelse:',
  'LBL_SUBJECT' => 'Tittel:',
  'LBL_CASE' => 'Hendelse:',
  'LBL_CASE_NUMBER' => 'Hendelsesnummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_ACCOUNT_NAME' => 'Konto:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_RESOLUTION' => 'L�sning:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_CASE_SUBJECT' => 'Hendelse Emne:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Nr.',
  'LBL_LIST_SUBJECT' => 'Tittel',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Prioritet',
  'LBL_LIST_LAST_MODIFIED' => 'Sist Oppdatert',
  'LBL_INVITEE' => 'Kontakter',
  'LNK_NEW_CASE' => 'Ny Hendelse',
  'LNK_CASE_LIST' => 'Hendelser',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p� � slette denne Kontakten fra saken?',
  'ERR_DELETE_RECORD' => 'Et ref nr m� oppgis for � slette denne oppf�ringen.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Er du sikker p� at du vil slette saken fra denne buggen?',
  'LBL_LIST_CLOSE' => 'Avslutt',
  'LBL_LIST_MY_CASES' => 'Mine �pne Hendelser',
  'LBL_ACCOUNT_ID' => 'Virksomhet ID',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Hendelser',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteter',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historikk',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_BUGS_SUBPANEL_TITLE' => 'Bugs',
  'LBL_MEMBER_OF' => 'Virksomhet',
  'LBL_SYSTEM_ID' => 'System ID',
)

?>
