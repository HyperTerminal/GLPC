<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Bugs',
  'LBL_MODULE_TITLE' => 'Bugs: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Bug S�k',
  'LBL_LIST_FORM_TITLE' => 'Bugliste',
  'LBL_NEW_FORM_TITLE' => 'Ny Bug',
  'LBL_CONTACT_BUG_TITLE' => 'Kontakt-Bug:',
  'LBL_SUBJECT' => 'Emne:',
  'LBL_BUG' => 'Bug:',
  'LBL_BUG_NUMBER' => 'Bug Nr:',
  'LBL_NUMBER' => 'Nr:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_CONTACT_NAME' => 'Kontakt Navn:',
  'LBL_BUG_SUBJECT' => 'Bug emne:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Nr.',
  'LBL_LIST_SUBJECT' => 'Emne',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Prioritet',
  'LBL_LIST_RELEASE' => 'Versjon',
  'LBL_LIST_RESOLUTION' => 'Forslag',
  'LBL_LIST_LAST_MODIFIED' => 'Sist endret',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_TYPE' => 'Type:',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_RESOLUTION' => 'Forslag:',
  'LBL_RELEASE' => 'Versjon:',
  'LNK_NEW_BUG' => 'Ny Bug',
  'LNK_BUG_LIST' => 'Bugs',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this contact from the bug?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Are you sure you want to remove this bug from this account?',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the bug.',
  'LBL_LIST_MY_BUGS' => 'Mine tilegnede Bugs',
  'LBL_FOUND_IN_RELEASE' => 'Found in Release:',
  'LBL_FIXED_IN_RELEASE' => 'Fixed in Release:',
  'LBL_WORK_LOG' => 'Work Log:',
  'LBL_SOURCE' => 'Source:',
  'LBL_PRODUCT_CATEGORY' => 'Kategori:',
  'LBL_CREATED_BY' => 'Opprettet av:',
  'LBL_DATE_CREATED' => 'Opprettet dato:',
  'LBL_MODIFIED_BY' => 'Sist endret av:',
  'LBL_DATE_LAST_MODIFIED' => 'Endret Dato:',
  'LBL_LIST_EMAIL_ADDRESS' => 'E-post',
  'LBL_LIST_CONTACT_NAME' => 'Kontakt',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto',
  'LBL_LIST_PHONE' => 'Tlf',
  'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to remove this contact from this bug?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Bugs',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteter',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historie',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Kontoer',
  'LBL_CASES_SUBPANEL_TITLE' => 'Support-hendelser',
  'LBL_SYSTEM_ID' => 'System ID',
)

?>
