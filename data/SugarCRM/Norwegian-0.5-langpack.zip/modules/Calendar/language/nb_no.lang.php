<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kalender',
  'LBL_MODULE_TITLE' => 'Kalender',
  'LNK_NEW_CALL' => 'Ny Oppringning',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_APPOINTMENT' => 'Ny Avtale',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_CALL_LIST' => 'Oppringninger',
  'LNK_MEETING_LIST' => 'M�ter',
  'LNK_TASK_LIST' => 'Oppgaver',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_MONTH' => 'M�ned',
  'LBL_DAY' => 'Dag',
  'LBL_YEAR' => '�r',
  'LBL_WEEK' => 'Uke',
  'LBL_PREVIOUS_MONTH' => 'Forrige M�ned',
  'LBL_PREVIOUS_DAY' => 'Forrige Dag',
  'LBL_PREVIOUS_YEAR' => 'Forrige �r',
  'LBL_PREVIOUS_WEEK' => 'Forrige Uke',
  'LBL_NEXT_MONTH' => 'Neste M�ned',
  'LBL_NEXT_DAY' => 'Neste Dag',
  'LBL_NEXT_YEAR' => 'Neste �r',
  'LBL_NEXT_WEEK' => 'Neste Uke',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Planlagt',
  'LBL_BUSY' => 'Opptatt',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'Bruker Kalendere',
  'LBL_SHARED' => 'Delt',
  'LBL_PREVIOUS_SHARED' => 'Forrige',
  'LBL_NEXT_SHARED' => 'Neste',
  'LBL_SHARED_CAL_TITLE' => 'Delt kalender',
  'LBL_USERS' => 'Brukere',
  'LBL_REFRESH' => 'Oppdater',
  'LBL_EDIT' => 'Rediger',
  'LBL_SELECT_USERS' => 'Velg brukere for delt kalendervisning',
  'LBL_FILTER_BY_TEAM' => 'Filtrer brukere p� team:',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"S�n",
"Man",
"Tir",
"Ons",
"Tor",
"Fre",
"L�r",
),
'dom_cal_weekdays_long'=>array(
"S�ndag",
"Mandag",
"Tirsdag",
"Onsdag",
"Torsdag",
"Fredag",
"L�rdag",
),
'dom_cal_month'=>array(
"",
"Jan",
"Feb",
"Mar",
"Apr",
"Mai",
"Jun",
"Jul",
"Aug",
"Sep",
"Okt",
"Nov",
"Des",
),
'dom_cal_month_long'=>array(
"",
"Januar",
"Februar",
"Mars",
"April",
"Mai",
"Juni",
"July",
"August",
"September",
"Oktober",
"November",
"Desember",

)
);
?>
