<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Historie',
  'LBL_MODULE_TITLE' => 'Historie: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Historie S�k',
  'LBL_LIST_FORM_TITLE' => 'Historie',
  'LBL_LIST_SUBJECT' => 'Subjekt',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Knyttet til',
  'LBL_LIST_DATE' => 'Dato',
  'LBL_LIST_TIME' => 'Startet',
  'LBL_LIST_CLOSE' => 'Avsluttet',
  'LBL_SUBJECT' => 'Subjekt:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Lokasjon:',
  'LBL_DATE_TIME' => 'Start Dato & Klokkeslett:',
  'LBL_DATE' => 'Start Dato:',
  'LBL_TIME' => 'Start Klokkeslett:',
  'LBL_DURATION' => 'Varighet:',
  'LBL_HOURS_MINS' => '(timer/minutter)',
  'LBL_CONTACT_NAME' => 'Kontqkt navn: ',
  'LBL_MEETING' => 'M�te:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planlagt',
  'LNK_NEW_CALL' => 'Nu Oppringning',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LNK_NEW_NOTE' => 'Nytt Notat eller Vedlegg',
  'LNK_NEW_EMAIL' => 'Ny E-post',
  'LNK_CALL_LIST' => 'Oppringninger',
  'LNK_MEETING_LIST' => 'M�ter',
  'LNK_TASK_LIST' => 'Oppgaver',
  'LNK_NOTE_LIST' => 'Notater',
  'LNK_EMAIL_LIST' => 'E-post',
  'ERR_DELETE_RECORD' => 'Oppgi referansenr for � slette denne oppf�ringen',
  'NTC_REMOVE_INVITEE' => 'Vil du fjerne den inviterte fra m�tet?',
  'LBL_INVITEE' => 'Inviterte',
  'LBL_LIST_DIRECTION' => 'Retning',
  'LBL_DIRECTION' => 'Retning',
  'LNK_NEW_APPOINTMENT' => 'Ny Avtale',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_OPEN_ACTIVITIES' => '�pne Aktiviteter',
  'LBL_HISTORY' => 'Historie',
  'LBL_UPCOMING' => 'Mine Avtaler',
  'LBL_TODAY' => 'Gjennom',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Ny Oppgave [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'O',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Ny Oppgave',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Nytt M�te [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'Nytt M�te',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Nytt M�te',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Ny Oppringning [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Ny Oppringing',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Nytt Notat eller Vedlegg [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Nytt Notat eller Vedlegg',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arkiver E-post [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arkiver E-post',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DUE_DATE' => 'Dato',
  'LBL_LIST_LAST_MODIFIED' => 'Sist endret',
  'NTC_NONE_SCHEDULED' => 'Ingen oppf�ring.',
  'appointment_filter_dom' => 
  array (
    'today' => 'i dag',
    'tomorrow' => 'i morgen',
    'this Saturday' => 'denne uken',
    'next Saturday' => 'neste uke',
    'last this_month' => 'denne m�neden',
    'last next_month' => 'neste m�ned',
  ),
  'LNK_IMPORT_NOTES' => 'Importer Notater',
  'NTC_NONE' => 'Ingen',
  'LBL_ACCEPT_THIS' => 'Aksepter?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Historie',
)

?>
