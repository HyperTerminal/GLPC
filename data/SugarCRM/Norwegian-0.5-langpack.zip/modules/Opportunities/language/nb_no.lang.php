<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Salgsmuligheter',
  'LBL_MODULE_TITLE' => 'Salgsmuligheter : Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S�k Salgsmuligheter',
  'LBL_LIST_FORM_TITLE' => 'Vis Salgsmuligheter',
  'LBL_OPPORTUNITY_NAME' => 'Navn:',
  'LBL_OPPORTUNITY' => 'Salgsmulighet:',
  'LBL_NAME' => 'Navn',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Salgsmulighet',
  'LBL_LIST_ACCOUNT_NAME' => 'Konto',
  'LBL_LIST_AMOUNT' => 'Bel�p',
  'LBL_LIST_DATE_CLOSED' => 'Avsluttet Dato',
  'LBL_LIST_SALES_STAGE' => 'Salgsfase',
  'LBL_ACCOUNT_ID' => 'Konto ID',
  'LBL_CURRENCY_ID' => 'Valuta ID',
  'LBL_TEAM_ID' => 'Team ID',
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
  'UPDATE' => 'Opportunity - Currency Update',
  'UPDATE_DOLLARAMOUNTS' => 'Update U.S. Dollar Amounts',
  'UPDATE_VERIFY' => 'Verify Amounts',
  'UPDATE_VERIFY_TXT' => 'Verifies that the amount values in opportunities are valid decimal numbers with only numeric characters(0-9) and decimals(.)',
  'UPDATE_FIX' => 'Fix Amounts',
  'UPDATE_FIX_TXT' => 'Attempts to fix any invalid amounts by creating a valid decimal from the current amount. This will backup any amounts it modifies into a database field amount_backup. If you run this and notice issues, do not rerun this without restoring from the backup as it may overwrite the backup with new invalid data.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Update the U.S. Dollar amounts for opportunities based on the current set currency rates. This value is used to calculate Graphs and List View Currency Amounts.',
  'UPDATE_CREATE_CURRENCY' => 'Creating New Currency:',
  'UPDATE_VERIFY_FAIL' => 'Record Failed Verification:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Current Amount:',
  'UPDATE_VERIFY_FIX' => 'Running Fix would give',
  'UPDATE_INCLUDE_CLOSE' => 'Include Closed Records',
  'UPDATE_VERIFY_NEWAMOUNT' => 'New Amount:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'New Currency:',
  'UPDATE_DONE' => 'Done',
  'UPDATE_BUG_COUNT' => 'Bugs Found and Attempted to Resolve:',
  'UPDATE_BUGFOUND_COUNT' => 'Bugs Found:',
  'UPDATE_COUNT' => 'Records Updated:',
  'UPDATE_RESTORE_COUNT' => 'Record Amounts Restored:',
  'UPDATE_RESTORE' => 'Restore Amounts',
  'UPDATE_RESTORE_TXT' => 'Restores amount values from the backups created during Fix.',
  'UPDATE_FAIL' => 'Could not update - ',
  'UPDATE_NULL_VALUE' => 'Amount is NULL setting it to 0 -',
  'UPDATE_MERGE' => 'Merge Currencies',
  'UPDATE_MERGE_TXT' => 'Merge multiple currencies into a single currency. If you notice that there are multiple currency records for the same currency, you may choose to merge them together. This will also merge the currencies for all other modules.',
  'LBL_ACCOUNT_NAME' => 'Navn:',
  'LBL_AMOUNT' => 'Bel�p:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_DATE_CLOSED' => 'Avsluttet Dato:',
  'LBL_TYPE' => 'Type:',
  'LBL_NEXT_STEP' => 'Neste fase:',
  'LBL_LEAD_SOURCE' => 'Kilde:',
  'LBL_SALES_STAGE' => 'Salgsfase:',
  'LBL_PROBABILITY' => 'Sannsynlighet(%):',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_DUPLICATE' => 'Possible Duplicate Opportunity',
  'MSG_DUPLICATE' => 'Creating this opportunity may potentialy create a duplicate opportunity. You may either select an opportunity from the list below or you may click on Create New Opportunity to continue creating a new opportunity with the previously entered data.',
  'LBL_NEW_FORM_TITLE' => 'Ny Konto',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgsmulighet',
  'LNK_OPPORTUNITY_LIST' => 'Salgsmuligheter',
  'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for � slette det mulige Salget.',
  'LBL_TOP_OPPORTUNITIES' => 'St�rste Salgsmuligheter',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Er du sikker p� � slette denne contakten fra Salgsmulighet?',
  'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Are you sure you want to remove this opportunity from this project?',
  'LBL_AMOUNT_BACKUP' => 'Amount Backup',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Salgsmulighet',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteter',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historie',
  'LBL_RAW_AMOUNT' => 'Verdi',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Mulige kunder',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Prosjekter',
  'LBL_ASSIGNED_TO_NAME' => 'Tilordnet bruker:',
)

?>
