<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.26.4.3 2006/01/08 04:36:04 majed Exp $
 * Description:  TODO: To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array('LBL_MODULE_TITLE'		=> 'Inbound Email',
					 'LBL_MODULE_NAME'		=> 'Inbound Email Setup',
					 'LBL_BASIC'			=> 'Basic Setup',
					 'LBL_SERVER_OPTIONS'	=> 'Mail Server Options',
					 'LBL_NAME'				=> 'Name',
					 'LBL_STATUS'			=> 'Status',
					 'LBL_SERVER_URL'		=> 'Mail Server Address',
					 'LBL_LOGIN'			=> 'User Name',
					 'LBL_PASSWORD'			=> 'Password',
					 'LBL_PASSWORD_CHECK'	=> 'Password Check',
					 'LBL_SERVER_TYPE'		=> 'Mail Server Protocol',
					 'LBL_MAILBOX'			=> 'Monitored Folder',
					 'LBL_MAILBOX_SSL'		=> 'Use SSL',
					 'LBL_MAILBOX_SSL_DESC'	=> 'Use SSL when connecting. If this does not work, check that your PHP installation included "--with-imap-ssl" in the configuration.',
					 'LBL_MAILBOX_DEFAULT'	=> 'INBOX',
					 'LBL_TLS'				=> 'Use TLS',
					 'LBL_TLS_DESC'			=> 'Use Transport Layer Security when connecting to the mail server - only use this if your mail server supports this protocol.',
					 'LBL_CERT'				=> 'Validate Certificate',
					 'LBL_CERT_DESC'		=> 'Force validation of the mail server\'s Security Certificate - do not use if self-signing.',
					 'LBL_MARK_READ'		=> 'Leave Messages On Server',
					 'LBL_MARK_READ_DESC'	=> 'Mark messages read on mail server on import; do not delete.',
					 'LBL_MARK_READ_YES'	=> 'Email left on server after import',
					 'LBL_MARK_READ_NO'		=> 'Email marked deleted after import',
					 'LBL_QUEUE'			=> 'Mailbox Queue',
					 'LBL_TEST_SETTINGS'	=> 'Test Settings',
					 'LBL_TEST_BUTTON_TITLE'=> 'Test [Alt+T]',
					 'LBL_TEST_BUTTON_KEY'	=> 't',
					 'LBL_TEST_SUCCESSFUL'	=> 'Connection completed successfully.',
					 'LBL_MAILBOX_TYPE'		=> 'Possible Actions',
					 'LBL_AUTOREPLY'		=> 'Auto-Reply Template',
					 'LBL_CREATE_TEMPLATE'	=> 'Create',
					 'LBL_EDIT_TEMPLATE'	=> 'Edit',
					 'LBL_AUTOREPLY_OPTIONS'=> 'Auto-Reply Options',
					 'LBL_FROM_NAME'		=> '"From" Name',
					 'LBL_FROM_ADDR'		=> '"From" Address',
					 'LBL_WARN_IMAP_TITLE'	=> 'IMAP Warning',
					 'LBL_PORT'				=> 'Mail Server Port',
					 'LBL_SSL'				=> 'Use SSL',
					 'LBL_SSL_DESC'			=> 'If your mail server supports secure socket connections, enabling this will force SSL connections when importing email.',
					 'LBL_WARN_IMAP'		=> 'Warnings:',
					 'LBL_WARN_NO_IMAP'		=> 'This system does not have the IMAP c-client libraries enabled/compiled into the PHP module (--with-imap=/path/to/imap_c-client_library).  Please contact your administrator to resolve this issue.',
					 'LBL_EMAIL_OPTIONS'	=> 'Email Handling Options',
					 'LBL_GROUP_QUEUE'		=> 'Assign To Group',
					 'LBL_DEFAULT_FROM_NAME'=> 'Default: ',
					 'LBL_DEFAULT_FROM_ADDR'=> 'Default: ',
					 'LBL_FROM_NAME_ADDR'	=> 'Reply Name/Email',
					 'LBL_ONLY_SINCE'		=> 'Import Only Since Last Check:',
					 'LBL_ONLY_SINCE_YES'	=> 'Yes.',
					 'LBL_ONLY_SINCE_NO'	=> 'No. Check against all emails on mail server.',
					 'LBL_ONLY_SINCE_DESC'	=> 'When using POP3, PHP cannot filter for New/Unread messages.  This flag allows the request to check for messages SINCE the last time the mailbox was polled.  This will significantly improve performance if your mail server cannot support IMAP.', 



					 'LBL_CREATE_NEW_GROUP'	=> '--Create Mailbox Group On Save--',
					 'LBL_SYSTEM_DEFAULT'	=> 'System Default',
					 'LBL_FILTER_DOMAIN'	=> 'No Auto-reply to Domain',
					 'LBL_FILTER_DOMAIN_DESC'=> 'Do not send Auto-replies to this domain.',
					 /* LBL_LIST_ */
					 'LBL_LIST_NAME'		=> 'Name:',
					 'LBL_LIST_STATUS'		=> 'Status:',
					 'LBL_LIST_SERVER_URL'	=> 'Mail Server:',
					 'LBL_LIST_MAILBOX_TYPE'=> 'Mailbox Usage',
					 /* LBL_LNK_ */
					 'LNK_LIST_MAILBOXES'	=> 'All Mailboxes',
					 'LNK_LIST_CREATE_NEW'	=> 'Monitor New Mailbox',
					 'LNK_LIST_QUEUES'		=> 'All Queues',
					 'LNK_NEW_QUEUES'		=> 'Create New Queue',
					 'LNK_LIST_SCHEDULER'	=> 'Schedulers',
					 'LNK_LIST_TEST_IMPORT'	=> 'Test Email Import',
					 'LNK_CREATE_GROUP'		=> 'Create New Group',
					 'LNK_LIST_QUEUES'		=> 'All Queues',
					 'LNK_NEW_QUEUES'		=> 'Create New Queue',
					 'LNK_SEED_QUEUES'		=> 'Seed Queues From Teams',
					 /* LBL_POPUP */
					 'LBL_POPUP_TITLE'		=> 'Test Settings',
					 'LBL_TEST_WAIT_MESSAGE'=> 'One moment please...',
					 'LBL_POPUP_SUCCESS'	=> 'Test connection successful.  Your settings are working.',
					 'LBL_POPUP_FAILURE'	=> 'Test connection failed. The error is shown below.',
					 'LBL_FOUND_MAILBOXES'	=> 'Found the following usable folders:',
					 'LBL_CLOSE_POPUP'		=> 'Close Window',
					 'ERR_TEST_MAILBOX'		=> 'Please check your settings and try again.',
					 'ERR_MAILBOX_FAIL'		=> 'Could not retreive any mailboxes.',
				);

?>
