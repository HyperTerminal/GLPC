
<?php
if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
$mod_strings = array (
'LBL_ACCESS_ALL'=>'Alle',
'LBL_ACCESS_NONE'=>'Ingen',
'LBL_ACCESS_OWNER'=>'Eier',
'LBL_ACCESS_NORMAL'=>'Normal',
'LBL_ACCESS_ADMIN'=>'Admin',
'LBL_ACCESS_ENABLED'=>'Aktiv',
'LBL_ACCESS_DISABLED'=>'Inaktiv',
'LBL_NAME'=>'Navn',
'LBL_DESCRIPTION'=>'Beskrivelse',
'LIST_ROLES'=>'Liste med roller',
'LBL_USERS_SUBPANEL_TITLE'=>'Brukere',
'LIST_ROLES_BY_USER'=>'Roller basert p� bruker',
'LBL_ROLES_SUBPANEL_TITLE'=>'Brukerens roller',
'LBL_SEARCH_FORM_TITLE'=>'Search',
'LBL_ACTION_VIEW'=>'Se p�',
'LBL_ACTION_EDIT'=>'Rediger',
'LBL_ACTION_DELETE'=>'Slett',
'LBL_ACTION_IMPORT'=>'Importer',
'LBL_ACTION_EXPORT'=>'Eksporter',
'LBL_ACTION_LIST'=>'Liste',
'LBL_ACTION_ACCESS'=>'Tilgang',
'LBL_ACTION_ADMIN'=>'Brukertype',

)
?>
