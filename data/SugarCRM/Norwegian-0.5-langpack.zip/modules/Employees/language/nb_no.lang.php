<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Ansatte',
  'LBL_MODULE_TITLE' => 'Ansatte: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Ansatte S�k',
  'LBL_LIST_FORM_TITLE' => 'Ansatte',
  'LBL_NEW_FORM_TITLE' => 'Ny Ansatt',
  'LBL_EMPLOYEE' => 'Ansatte:',
  'LBL_LOGIN' => 'Logg inn',
  'LBL_RESET_PREFERENCES' => 'Sett til standardverdier',
  'LBL_TIME_FORMAT' => 'Tidsformat:',
  'LBL_DATE_FORMAT' => 'Datoformat:',
  'LBL_TIMEZONE' => 'N�tid:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Etternavn',
  'LBL_LIST_EMPLOYEE_NAME' => 'Ansattes Navn',
  'LBL_LIST_DEPARTMENT' => 'Avdeling',
  'LBL_LIST_REPORTS_TO_NAME' => 'Rapporter til',
  'LBL_LIST_EMAIL' => 'E-post',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim�r tlf',
  'LBL_LIST_USER_NAME' => 'Brukernavn',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Ny ansatt [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Ny ansatt',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Feil:',
  'LBL_PASSWORD' => 'Passord:',
  'LBL_EMPLOYEE_NAME' => 'Ansattes navn:',
  'LBL_USER_NAME' => 'Brukernavn:',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Etternavn:',
  'LBL_EMPLOYEE_SETTINGS' => 'Ansattes innstillinger',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Spr�k:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_EMPLOYEE_INFORMATION' => 'Ansatt info',
  'LBL_OFFICE_PHONE' => 'Tlf jobb:',
  'LBL_REPORTS_TO' => 'Rapporterer til:',
  'LBL_OTHER_PHONE' => 'Andre:',
  'LBL_OTHER_EMAIL' => 'Annen E-post:',
  'LBL_NOTES' => 'Notater:',
  'LBL_DEPARTMENT' => 'Avdeling:',
  'LBL_TITLE' => 'Tittel:',
  'LBL_ANY_PHONE' => 'Any Phone:',
  'LBL_ANY_EMAIL' => 'Any Email:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Fylke:',
  'LBL_POSTAL_CODE' => 'Postnr:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Navn:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_OTHER' => 'Annen:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'E-post:',
  'LBL_HOME_PHONE' => 'Tlf hjem:',
  'LBL_ADDRESS_INFORMATION' => 'Addresse Info',
  'LBL_EMPLOYEE_STATUS' => 'Ansatt Status:',
  'LBL_PRIMARY_ADDRESS' => 'Prim�r Adresse:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Ny bruker [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Ny bruker',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Favorittfarge:',
  'LBL_MESSENGER_ID' => 'IM Navn:',
  'LBL_MESSENGER_TYPE' => 'IM Type:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Ansattes navn',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => 'eksisterer allerede.  Duplikater er ikke tillatt.  Change the employee name to be unique.',
  'ERR_LAST_ADMIN_1' => 'Ansattes navn "',
  'ERR_LAST_ADMIN_2' => '" er den siste ansatte med admin aksess.  Minst en ansat m� v�re admin.',
  'LNK_NEW_EMPLOYEE' => 'Ny Ansatt',
  'LNK_EMPLOYEE_LIST' => 'Ansatte',
  'ERR_DELETE_RECORD' => 'Et referansenr er p�krevd for � slette oppf�ringen.',
)

?>
