<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Oversikt',
  'LBL_MODULE_TITLE' => 'Oversikt: Hjem',
  'LNK_NEW_ACCOUNT' => 'Ny Konto',
  'LNK_NEW_CALL' => 'Ny Oppringning',
  'LNK_NEW_CASE' => 'Ny Support-hendelse',
  'LNK_NEW_CONTACT' => 'Ny Kontakt',
  'LNK_NEW_ISSUE' => 'Ny Bug',
  'LNK_NEW_LEAD' => 'Ny Mulig kunde',
  'LNK_NEW_MEETING' => 'Nytt M�te',
  'LNK_NEW_NOTE' => 'Nytt Notat',
  'LNK_NEW_OPPORTUNITY' => 'Ny Salgsmulighet',
  'LNK_NEW_QUOTE' => 'Nytt Pristilbud',
  'LNK_NEW_TASK' => 'Ny Oppgave',
  'LBL_ADD_A_CHART' => 'Legg til i oversikt',
  'LBL_DELETE_FROM_DASHBOARD' => 'Slett fra Oversikt',
  'LBL_MOVE_DOWN' => 'Flytt Oppover',
  'LBL_MOVE_UP' => 'Flytt Nedover',
  'LBL_BASIC_CHARTS' => '-- Grunnleggende Oversikt --',
  'LBL_PUBLISHED_REPORTS' => '-- Publiserte Rapporter --',
  'LBL_MY_REPORTS' => '-- Mine Lagrede Rapporter --',
  'LBL_TEAM_REPORTS' => '-- Mitt teams Rapporter --',
  'LBL_REPORT_NO_CHART' => 'Denne rapporten har ikke en oversikt',
)

?>
