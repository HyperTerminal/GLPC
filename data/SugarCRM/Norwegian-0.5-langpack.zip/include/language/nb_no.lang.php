<?php

if(empty($GLOBALS['sugarEntry'])) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php, v 0.1, 27 February, 2006, Exp $
 * Description:  Norwegian language pack for SugarCRM 4.0.1 base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * Extension of Norwegian language pack for SugarCRM 3.5.1 by Aleksander Solheim
 * Portions created by 2Web are Copyright (C) 2Web.
 * All Rights Reserved.
 ********************************************************************************/

$app_list_strings = array (
  'language_pack_name' => 'Norsk (bokm�l)',
  'moduleList' => 
  array (
    'Home' => 'Hjem',
    'Dashboard' => 'Oversikt',
    'Contacts' => 'Kontakter',
    'Accounts' => 'Konto',
    'Opportunities' => 'Salgsmulighet',
    'Cases' => 'Support',
    'Notes' => 'Notater og vedlegg',
    'Calls' => 'Oppringninger',
    'Emails' => 'E-post',
    'Meetings' => 'M�ter',
    'Tasks' => 'Oppgaver',
    'Calendar' => 'Kalender',
    'Leads' => 'Mulige kunder',
    'Activities' => 'Aktiviteter',
    'Bugs' => 'Bugs',
    'Feeds' => 'RSS',
    'iFrames' => 'Min portal',
    'TimePeriods' => 'Tidsperioder',
    'Project' => 'Prosjekter',
    'ProjectTask' => 'Prosjektoppgaver',
    'Campaigns' => 'Kampanje',
    'Documents' => 'Dokument',
    'Sync' => 'Synk',
    'Users' => 'Brukere',
    'Releases' => 'Utgaver',
    'Prospects' => 'Utvalgte M�l',
    'Queues' => 'K�',
    'EmailMarketing' => 'Markedsf�ring E-post',
    'EmailTemplates' => 'E-post Template',
    'ProspectLists' => 'Utvalgte M�l',
  ),
  'moduleListSingular' => 
  array (
    'Home' => 'Hjem',
    'Dashboard' => 'Oversikt',
    'Contacts' => 'Kontakt',
    'Accounts' => 'Konto',
    'Opportunities' => 'Salgsmulighet',
    'Cases' => 'Support-hendelse',
    'Notes' => 'Notat',
    'Calls' => 'Oppringning',
    'Emails' => 'E-post',
    'Meetings' => 'M�te',
    'Tasks' => 'Oppgave',
    'Calendar' => 'Kalender',
    'Leads' => 'Mulig kunde',
    'Activities' => 'Aktivitet',
    'Bugs' => 'Bug',
    'Feeds' => 'RSS',
    'iFrames' => 'Min Portal',
    'TimePeriods' => 'Tidsperiode',
    'Project' => 'Prosjekt',
    'ProjectTask' => 'Prosjektoppgave',
    'Campaigns' => 'Kampanje',
    'Documents' => 'Dokument',
    'Sync' => 'Synk',
    'Users' => 'Bruker',
    '######' => 'Translate whole array',
  ),
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analytiker',
    'Competitor' => 'Konkurrent',
    'Customer' => 'Kunde',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Presse',
    'Prospect' => 'Prospekt',
    'Reseller' => 'Forhandler',
    'Other' => 'Andre',
  ),
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'Klesbransje',
    'Banking' => 'Bank',
    'Biotechnology' => 'Bioteknologi',
    'Communications' => 'Kommunikasjonsutstyr',
    'Construction' => 'Konstruksjonsvirksomhet',
    'Consulting' => 'Konsulentvirksomhet',
    'Education' => 'Utdanning',
    'Electronics' => 'Elektronikk',
    'Energy' => 'Energi',
    'Engineering' => 'Ingeni�rvirksomhet',
    'Entertainment' => 'Underholdning',
    'Environmental' => 'Milj�',
    'Finance' => 'Finans',
    'Government' => 'Offentlig forvaltning',
    'Healthcare' => 'Helse',
    'Hospitality' => 'Hotel/Restaurant',
    'Insurance' => 'Forsikring',
    'Machinery' => 'Maskinteknikk',
    'Manufacturing' => 'Produsent',
    'Media' => 'Media',
    'Not For Profit' => 'Frivillig virksomhet',
    'Recreation' => 'Turisme/reiser',
    'Retail' => 'Salg til sluttkunde',
    'Shipping' => 'Shipping',
    'Technology' => 'Teknologi',
    'Telecommunications' => 'Telekommunikasjon',
    'Transportation' => 'Transport',
    'Utilities' => 'Verkt�y',
    'Other' => 'Andre',
  ),
  '0source_default_key' => 'Self Generated',
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Kald oppringning',
    'Existing Customer' => 'Eksisterende kunde',
    'Self Generated' => 'Selvgenerert',
    'Employee' => 'Ansatt',
    'Partner' => 'Partner',
    'Public Relations' => 'Public Relations',
    'Direct Mail' => 'Direct Mail',
    'Conference' => 'Konferanse',
    'Trade Show' => 'Messe',
    'Web Site' => 'Internettside',
    'Word of mouth' => 'Rykte',
    'Email' => 'E-post',
    'Other' => 'Annet',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Eksisterende kundeforhold',
    'New Business' => 'Nytt kundeforhold',
  ),
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim�r beslutningstaker',
    'Business Decision Maker' => 'Forretningsmessig beslutningstaker',
    'Business Evaluator' => 'Forretningsmessig evaluator',
    'Technical Decision Maker' => 'Teknisk beslutningstaker',
    'Technical Evaluator' => 'Teknisk evaluator',
    'Executive Sponsor' => 'Ledelse',
    'Influencer' => 'Person med innflytelse',
    'Other' => 'Annet',
  ),
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Prim�r kontakt',
    'Alternate Contact' => 'Alternativ kontakt',
  ),
  'payment_terms' => 
  array (
    '' => '',
    'Net 15' => 'Netto 15',
    'Net 30' => 'Netto 30',
    '######' => 'Translate whole array',
  ),
  'sales_stage_default_key' => 'Prospecting',
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospektering',
    'Qualification' => 'Kvalifisering',
    'Proposal/Price Quote' => 'Tilbud sendt',
    'Negotiation/Review' => 'Forhandling/oppdatering',
    'Closed Won' => 'Vunnet',
    'Closed Lost' => 'Tapt',
  ),
  'sales_probability_dom' => 
  array (
    'Prospecting' => '10',
    'Qualification' => '20',
    'Needs Analysis' => '25',
    'Value Proposition' => '30',
    'Id. Decision Makers' => '40',
    'Perception Analysis' => '50',
    'Proposal/Price Quote' => '65',
    'Negotiation/Review' => '80',
    'Closed Won' => '100',
    'Closed Lost' => '0',
    '######' => 'Translate whole array',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Oppringning',
    'Meeting' => 'M�te',
    'Task' => 'Oppgave',
    'Email' => 'E-post',
    'Note' => 'Notat',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Hr',
    'Ms.' => 'Fr�ken',
    'Mrs.' => 'Fru',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  'reminder_max_time' => 3600,
  'reminder_time_options' => 
  array (
    60 => '1 minutt f�r',
    300 => '5 minutter f�r',
    600 => '10 minutter f�r',
    900 => '15 minutter f�r',
    1800 => '30 minutter f�r',
    3600 => '1 time f�r',
  ),
  'task_priority_default' => 'Medium',
  'task_priority_dom' => 
  array (
    'High' => 'H�y',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
  'task_status_default' => 'Not Started',
  'task_status_dom' => 
  array (
    'Not Started' => 'Ikke p�begynt',
    'In Progress' => 'I utvikling',
    'Completed' => 'Avsluttet',
    'Pending Input' => 'Venter p� opplysninger',
    'Deferred' => 'Kansellert',
  ),
  'meeting_status_default' => 'Planned',
  'meeting_status_dom' => 
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Avholdt',
    'Not Held' => 'Ikke Avholdt',
  ),
  'call_status_default' => 'Held',
  'call_status_dom' => 
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Fullf�rt',
    'Not Held' => 'Ikke Fullf�rt',
  ),
  'call_direction_default' => 'Outbound',
  'call_direction_dom' => 
  array (
    'Inbound' => 'Innkommende',
    'Outbound' => 'Utg�ende',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'Ny',
    'Assigned' => 'Tilordnet',
    'In Process' => 'Prosesseres',
    'Converted' => 'Konvertert',
    'Recycled' => 'Gjenbrukt',
    'Dead' => 'D�d',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'Ny',
    'Assigned' => 'Tilordnet',
    'In Process' => 'Prosesseres',
    'Converted' => 'Konvertert',
    'Recycled' => 'Gjenbrukt',
    'Dead' => 'D�d',
  ),
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'Closed' => 'Avsluttet',
    'Pending Input' => 'Venter p� opplysninger',
    'Rejected' => 'Avsl�tt',
    'Duplicate' => 'Duplikat',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'H�y',
    'P2' => 'Medium',
    'P3' => 'Lav',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'employee_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Terminated' => 'Inaktiv',
    'Leave of Absence' => 'Permisjon',
  ),
  'messenger_type_dom' => 
  array (
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
    'AOL' => 'AOL',
  ),
  'project_task_priority_options' => 
  array (
    'High' => 'H�y',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
  'project_task_status_options' => 
  array (
    'Not Started' => 'Ikke p�begynt',
    'In Progress' => 'Prosesseres',
    'Completed' => 'Fullf�rt',
    'Pending Input' => 'Venter p� opplysninger',
    'Deferred' => 'Kansellert',
  ),
  'project_task_utilization_options' => 
  array (
    0 => 'ingen',
    25 => '25',
    50 => '50',
    75 => '75',
    100 => '100',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Konto',
    'Opportunities' => 'Salgsmulighet',
    'Cases' => 'Support',
    'Leads' => 'Mulige kunder',
    'Contacts' => 'Kontakter',
    'Bugs' => 'Bug',
    'Project' => 'Prosjekt',
    'ProjectTask' => 'Prosjektoppgave',
    'Tasks' => 'Oppgaver',
  ),
  'record_type_display_notes' => 
  array (
    'Accounts' => 'Konto',
    'Contacts' => 'Kontakter',
    'Opportunities' => 'Salgsmulighet',
    'Cases' => 'Support',
    'Leads' => 'Mulige kunder',
    'Bugs' => 'Bug',
    'Emails' => 'E-post',
    'Project' => 'Prosjekt',
    'ProjectTask' => 'Prosjektoppgave',
    'Meetings' => 'M�ter',
    'Calls' => 'Oppringning',
  ),
  'quote_type_dom' => 
  array (
    'Quotes' => 'Tilbud',
    'Orders' => 'Ordre',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' => 
  array (
    'Draft' => 'Utkast',
    'Negotiation' => 'I Forhandling',
    'Delivered' => 'Levert',
    'On Hold' => 'P� Vent',
    'Confirmed' => 'Bekreftet',
    'Closed Accepted' => 'Lukket akseptert',
    'Closed Lost' => 'Lukket Mistet',
    'Closed Dead' => 'Lukket D�d',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' => 
  array (
    'Pending' => 'Avventende',
    'Confirmed' => 'Bekreftet',
    'On Hold' => 'P� vent',
    'Shipped' => 'Levert',
    'Cancelled' => 'Kansellert',
  ),
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim�r Besluttningstaker',
    'Business Decision Maker' => 'Forettningsmessig Besluttningstaker',
    'Business Evaluator' => 'Forretnings Evaluator',
    'Technical Decision Maker' => 'Teknisk Besluttningstaker',
    'Technical Evaluator' => 'Teknisk Evaluator',
    'Executive Sponsor' => 'Hovedsponsor',
    'Influencer' => 'Besluttningsp�virker',
    'Other' => 'Annen',
  ),
  'layouts_dom' => 
  array (
    'Standard' => 'Forslag',
    'Invoice' => 'Faktura',
    'Terms' => 'Betalingsbetingelser',
  ),
  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' => 
  array (
    'Urgent' => 'Haster',
    'High' => 'H�y',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
  'bug_resolution_default_key' => '',
  'bug_resolution_dom' => 
  array (
    '' => '',
    'Accepted' => 'Godkjent',
    'Duplicate' => 'Duplikat',
    'Fixed' => 'Fikset',
    'Out of Date' => 'Foreldet',
    'Invalid' => 'Ugyldig',
    'Later' => 'Utsatt',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' => 
  array (
    'New' => 'Ny',
    'Assigned' => 'Tilordnet',
    'Closed' => 'Lukket',
    'Pending' => 'Til forfall',
    'Rejected' => 'Avvist',
  ),
  'bug_type_default_key' => 'Bug',
  'bug_type_dom' => 
  array (
    'Defect' => 'Defekt',
    'Feature' => '�nsket Funksjon',
  ),
  'source_default_key' => '',
  'source_dom' => 
  array (
    '' => '',
    'Internal' => 'Intern',
    'Forum' => 'Forum',
    'Web' => 'Web',
    'InboundEmail' => 'Innkommende E-post',
  ),
  'product_category_default_key' => '',
  'product_category_dom' => 
  array (
    '' => '',
    'Accounts' => 'Konto',
    'Activities' => 'Aktiviteter',
    'Bug Tracker' => 'Bug Tracker',
    'Calendar' => 'Kalender',
    'Calls' => 'Oppringninger',
    'Campaigns' => 'Kampanjer',
    'Cases' => 'Support',
    'Contacts' => 'Kontakter',
    'Currencies' => 'Valuta',
    'Dashboard' => 'Oversiktspanel',
    'Documents' => 'Dokumenter',
    'Emails' => 'E-post',
    'Feeds' => 'RSS',
    'Forecasts' => 'Forventninger',
    'Help' => 'Hjelp',
    'Home' => 'Hjem',
    'Leads' => 'Mulige kunder',
    'Meetings' => 'M�ter',
    'Notes' => 'Notater',
    'Opportunities' => 'Salgsmuligheter',
    'Outlook Plugin' => 'Outlook Plugin',
    'Product Catalog' => 'Produkt Katalog',
    'Products' => 'Produkter',
    'Projects' => 'Prosjekter',
    'Quotes' => 'Tilbud',
    'Releases' => 'Releases',
    'RSS' => 'RSS',
    'Studio' => 'Studio',
    'Upgrade' => 'Oppgradering',
    'Users' => 'Brukere',
  ),
  'campaign_status_dom' => 
  array (
    '' => '',
    'Planning' => 'Planlagt',
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
    'Complete' => 'Fullf�rt',
    'In Queue' => 'I k�',
    'Sending' => 'Under sending',
  ),
  'campaign_type_dom' => 
  array (
    '' => '',
    'Telesales' => 'Telefonsalg',
    'Mail' => 'Post',
    'Email' => 'E-post',
    'Print' => 'Annonsering i Avis/Magasin',
    'Web' => 'Web',
    'Radio' => 'Radio',
    'Television' => 'TV',
  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => 
  array (
    -12 => '(GMT - 12) International Date Line West',
    -11 => '(GMT - 11) Midway Island, Samoa',
    -10 => '(GMT - 10) Hawaii',
    -9 => '(GMT - 9) Alaska',
    -8 => '(GMT - 8) San Francisco',
    -7 => '(GMT - 7) Phoenix',
    -6 => '(GMT - 6) Saskatchewan',
    -5 => '(GMT - 5) New York',
    -4 => '(GMT - 4) Santiago',
    -3 => '(GMT - 3) Buenos Aires',
    -2 => '(GMT - 2) Mid-Atlantic',
    -1 => '(GMT - 1) Azores',
    0 => '(GMT)',
    1 => '(GMT + 1) Madrid',
    2 => '(GMT + 2) Athens',
    3 => '(GMT + 3) Moscow',
    4 => '(GMT + 4) Kabul',
    5 => '(GMT + 5) Ekaterinburg',
    6 => '(GMT + 6) Astana',
    7 => '(GMT + 7) Bangkok',
    8 => '(GMT + 8) Perth',
    9 => '(GMT + 9) Seol',
    10 => '(GMT + 10) Brisbane',
    11 => '(GMT + 11) Solomone Is.',
    12 => '(GMT + 12) Auckland',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Januar',
    2 => 'Februar',
    3 => 'Mars',
    4 => 'April',
    5 => 'Mai',
    6 => 'Juni',
    7 => 'Juli',
    8 => 'August',
    9 => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'Desember',
  ),
  'dom_report_types' => 
  array (
    'tabular' => 'Rader og Kolonner',
    'summary' => 'Oppsummering',
    'detailed_summary' => 'Oppsumering med detaljer',
  ),
  'dom_email_types' => 
  array (
    'out' => 'Sendt',
    'archived' => 'Arkivert',
    'draft' => 'Kladd',
    'inbound' => 'Innkommende',
  ),
  'dom_email_status' => 
  array (
    'archived' => 'Arkivert',
    'unread' => 'Ulest',
    'read' => 'Lest',
    'replied' => 'Besvart',
    'closed' => 'Avsluttet',
    'sent' => 'Sendt',
    'send_error' => 'Send Error',
    'draft' => 'Kladd',
    '######' => 'Translate whole array',
  ),
  'dom_email_server_type' => 
  array (
    '' => '--Ingen--',
    'imap' => 'IMAP',
    'pop3' => 'POP3',
    '######' => 'Translate whole array',
  ),
  'dom_mailbox_type' => 
  array (
    'pick' => 'Velg [Vilk�rlig]',
    'bug' => 'Opprett Bug',
    'support' => 'Opprett Hendelse',
    'contact' => 'Opprett Kontakt',
    'sales' => '',
    'task' => 'Opprett Oppgave',
    'bounce' => 'Bounce Handling',
    '######' => 'Translate whole array',
  ),
  'dom_email_distribution' => 
  array (
    '' => '--None--',
    'direct' => 'Direct Assign',
    'roundRobin' => 'Round-Robin',
    'leastBusy' => 'Least-Busy',
    '######' => 'Translate whole array',
  ),
  'dom_email_errors' => 
  array (
    1 => 'Only select one user when Direct Assigning items.',
    2 => 'You must assign Only Checked Items when Direct Assigning items.',
    '######' => 'Translate whole array',
  ),
  'dom_email_bool' => 
  array (
    'bool_true' => 'Yes',
    'bool_false' => 'No',
    '######' => 'Translate whole array',
  ),
  'schedulers_times_dom' => 
  array (
    'not run' => 'Past Run Time, Not Executed',
    'ready' => 'Ready',
    'in progress' => 'In Progress',
    'failed' => 'Failed',
    'completed' => 'Completed',
    '######' => 'Translate whole array',
  ),
  'forecast_schedule_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Inaktiv',
  ),
  'forecast_type_dom' => 
  array (
    'Direct' => 'Direkte',
    'Rollup' => 'Opprulling',
  ),
  'document_category_dom' => 
  array (
    '' => '',
    'Marketing' => 'Markedsf�ring',
    'Knowledege Base' => 'Kunnskapsbase',
    'Sales' => 'Salg',
  ),
  'document_subcategory_dom' => 
  array (
    '' => '',
    'Marketing Collateral' => 'Markedsf�ring',
    'Product Brochures' => 'Produktark',
    'FAQ' => 'Ofte Stilte Sp�rsm�l',
  ),
  'document_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Draft' => 'Kladd',
    'FAQ' => 'Ofte Stilte Sp�rsm�l',
    'Expired' => 'Utl�pt',
    'Under Review' => 'Vurderes',
    'Pending' => 'P� vent',
  ),
  'dom_meeting_accept_options' => 
  array (
    'accept' => 'Aksepter',
    'decline' => 'Avvis',
    'tentative' => 'Tentativ',
  ),
  'dom_meeting_accept_status' => 
  array (
    'accept' => 'Akseptert',
    'decline' => 'Avvist',
    'tentative' => 'Tentativt',
    'none' => 'Ingen',
  ),
  'prospect_list_type_dom' => 
  array (
    '' => '',
    'default' => 'Standard',
    'seed' => 'Gradert',
    'test' => 'Test',
    'exempt' => 'Utvalgt Liste - ved Id',
    'exempt_address' => 'Utvalgt liste - ved E-post adresse',
    'exempt_domain' => 'Utvalgt liste - ved Domene',
    '######' => 'Translate whole array',
  ),
  'email_marketing_status_dom' => 
  array (
    '' => '',
    'active' => 'Active',
    'inactive' => 'Inactive',
    '######' => 'Translate whole array',
  ),
  'campainglog_activity_type_dom' => 
  array (
    '' => '',
    'targeted' => 'Message Sent/Attempted',
    'send error' => 'Bounced Messages,Other',
    'invalid email' => 'Bounced Messages,Invalid Email',
    'link' => 'Click-thru Link',
    'viewed' => 'Viewed Message',
    'removed' => 'Opted Out',
    'lead' => 'Leads Created',
    'contact' => 'Contacts Created',
    '######' => 'Translate whole array',
  ),
  'campainglog_target_type_dom' => 
  array (
    'Contacts' => 'Contacts',
    'Users' => 'Users',
    'Prospects' => 'Targets',
    'Leads' => 'Leads',
    '######' => 'Translate whole array',
  ),
)

?>
