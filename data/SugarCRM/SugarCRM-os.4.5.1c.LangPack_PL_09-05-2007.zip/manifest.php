<?PHP 
$manifest = array( 
	'name' => 'PL Polski',
	'description' => 'Polish translation for SugarCRM Enterprise Edition from Grupa Atlantis and Contributors for SugarCRM',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => 'os.4.5.1.c',
	'acceptable_sugar_flavors' => array (0 => 'OS'),
	'published_date' => '09/05/2007',
	'author' => 'grupa-atlantis.com',
	'acceptable_sugar_versions' => array ( "exact_matches" => array (), "regex_matches" => array (  0=>"4\\.5\\.*", 1 => "4\\.2\\.*" , 2 => "4\\.0\\.*" , 3=> "3\\.5\\.*" )),
	'icon' => 'include/images/flag-pl_PL.gif');

$installdefs = array(
	'id'=> 'pl_PL',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>
