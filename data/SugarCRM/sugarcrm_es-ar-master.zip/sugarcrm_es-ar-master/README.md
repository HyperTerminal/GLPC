sugarcrm_es-ar
==============

SugarCRM 6.5 - Spanish Argentina Language Pack

* Se determinó con la herramienta cloc la cantidad de lineas en los archivos a traducir.

cloc en_us
defined(%hash) is deprecated at /usr/bin/cloc line 1277.
  (Maybe you should just omit the defined()?)
      81 text files.
      81 unique files.                              
       0 files ignored.

http://cloc.sourceforge.net v 1.53  T=0.5 s (162.0 files/s, 32564.0 lines/s)
-------------------------------------------------------------------------------
Language                     files          blank        comment           code
-------------------------------------------------------------------------------
PHP                             79            854           3232          11749
HTML                             2             91            162            194
-------------------------------------------------------------------------------
SUM:                            81            945           3394          11943
-------------------------------------------------------------------------------

* Detalle de lineas por cada archivo

cloc --by-file en_us
defined(%hash) is deprecated at /usr/bin/cloc line 1277.
  (Maybe you should just omit the defined()?)
      81 text files.
      81 unique files.                              
       0 files ignored.

http://cloc.sourceforge.net v 1.53  T=1.0 s (81.0 files/s, 16282.0 lines/s)
------------------------------------------------------------------------------------------------------------------------------------------
File                                                                                                   blank        comment           code
------------------------------------------------------------------------------------------------------------------------------------------
en_us/include/language/en_us.lang.php                                                                    190            103           2968
en_us/modules/Administration/language/en_us.lang.php                                                      34             47           1082
en_us/modules/ModuleBuilder/language/en_us.lang.php                                                       47             58            612
en_us/install/language/en_us.lang.php                                                                     24             46            512
en_us/modules/Users/language/en_us.lang.php                                                               31             47            500
en_us/modules/Campaigns/language/en_us.lang.php                                                           16             48            376
en_us/modules/Configurator/language/en_us.lang.php                                                        41             47            347
en_us/modules/Emails/language/en_us.lang.php                                                              21             47            331
en_us/modules/Import/language/en_us.lang.php                                                               3             39            331
en_us/modules/UpgradeWizard/language/en_us.lang.php                                                       18             42            250
en_us/modules/Leads/language/en_us.lang.php                                                                5             44            225
en_us/modules/Contacts/language/en_us.lang.php                                                             9             44            190
en_us/modules/Home/language/en_us.lang.php                                                                22             44            184
en_us/include/language/en_us.notify_template.html                                                         81            124            167
en_us/modules/Calendar/language/en_us.lang.php                                                            16             34            161
en_us/modules/Prospects/language/en_us.lang.php                                                            3             43            153
en_us/modules/InboundEmail/language/en_us.lang.php                                                         8             42            151
en_us/modules/Accounts/language/en_us.lang.php                                                             4             46            142
en_us/modules/Meetings/language/en_us.lang.php                                                            11             44            133
en_us/modules/Documents/language/en_us.lang.php                                                           12             50            131
en_us/modules/Studio/language/en_us.lang.php                                                              26             52            130
en_us/modules/Employees/language/en_us.lang.php                                                            7             40            121
en_us/modules/EmailMan/language/en_us.lang.php                                                             9             40            114
en_us/modules/Calls/language/en_us.lang.php                                                                8             42            113
en_us/modules/Opportunities/language/en_us.lang.php                                                        6             44            108
en_us/modules/Schedulers/language/en_us.lang.php                                                           8             49            105
en_us/include/SugarObjects/templates/company/language/en_us.lang.php                                       8             34             94
en_us/modules/Project/language/en_us.lang.php                                                             19             35             93
en_us/include/SugarObjects/templates/sale/language/en_us.lang.php                                          7             42             90
en_us/modules/SugarFeed/language/en_us.lang.php                                                            4             34             87
en_us/modules/DynamicFields/language/en_us.lang.php                                                        6             40             87
en_us/modules/Activities/language/en_us.lang.php                                                           6             40             86
en_us/modules/Cases/language/en_us.lang.php                                                                9             42             85
en_us/modules/Connectors/language/en_us.lang.php                                                           5             34             83
en_us/modules/History/language/en_us.lang.php                                                              5             34             81
en_us/modules/ProjectTask/language/en_us.lang.php                                                         10             34             77
en_us/modules/Tasks/language/en_us.lang.php                                                                6             41             76
en_us/modules/Bugs/language/en_us.lang.php                                                                10             41             75
en_us/modules/EmailTemplates/language/en_us.lang.php                                                       4             41             74
en_us/modules/EAPM/language/en_us.lang.php                                                                 4             35             72
en_us/modules/Notes/language/en_us.lang.php                                                                4             41             71
en_us/include/SugarObjects/templates/file/language/en_us.lang.php                                         11             47             65
en_us/modules/EmailMarketing/language/en_us.lang.php                                                      10             40             58
en_us/modules/Charts/language/en_us.lang.php                                                               6             40             58
en_us/modules/CampaignLog/language/en_us.lang.php                                                          5             40             55
en_us/modules/ProspectLists/language/en_us.lang.php                                                        6             40             53
en_us/include/SugarObjects/templates/person/language/en_us.lang.php                                        1             34             51
en_us/modules/Trackers/language/en_us.lang.php                                                             5             43             44
en_us/modules/Currencies/language/en_us.lang.php                                                           5             40             39
en_us/modules/DocumentRevisions/language/en_us.lang.php                                                   11             44             37
en_us/modules/MailMerge/language/en_us.lang.php                                                            5             40             36
en_us/include/SugarObjects/templates/issue/language/application/en_us.lang.php                             2             40             35
en_us/modules/MergeRecords/language/en_us.lang.php                                                         9             40             35
en_us/modules/ACLActions/language/en_us.lang.php                                                           1             34             31
en_us/modules/CampaignTrackers/language/en_us.lang.php                                                     6             40             29
en_us/modules/Releases/language/en_us.lang.php                                                             5             40             28
en_us/include/SugarObjects/templates/file/language/application/en_us.lang.php                              5             39             28
en_us/modules/OAuthKeys/language/en_us.lang.php                                                            2             34             28
en_us/modules/Studio/language/en_us.Portal.html                                                           10             38             27
en_us/modules/SchedulersJobs/language/en_us.lang.php                                                       1             35             26
en_us/modules/SavedSearch/language/en_us.lang.php                                                          6             40             24
en_us/include/SugarObjects/templates/issue/language/en_us.lang.php                                         5             40             24
en_us/modules/ACLRoles/language/en_us.lang.php                                                             1             34             22
en_us/modules/Roles/language/en_us.lang.php                                                                5             34             21
en_us/modules/Relationships/language/en_us.lang.php                                                        4             40             21
en_us/modules/ACL/language/en_us.lang.php                                                                  2             34             20
en_us/modules/Help/language/en_us.lang.php                                                                 5             40             20
en_us/include/SugarObjects/templates/company/language/application/en_us.lang.php                           3             40             19
en_us/include/SugarObjects/templates/basic/language/en_us.lang.php                                         4             34             17
en_us/modules/Connectors/connectors/sources/ext/rest/insideview/language/en_us.lang.php                    3             34             16
en_us/modules/OAuthTokens/language/en_us.lang.php                                                          3             34             16
en_us/modules/Groups/language/en_us.lang.php                                                               2             36             13
en_us/modules/Audit/language/en_us.lang.php                                                                4             34             12
en_us/modules/EmailAddresses/language/en_us.lang.php                                                       3             40             12
en_us/modules/OptimisticLock/language/en_us.lang.php                                                       5             40             12
en_us/include/SugarObjects/templates/sale/language/application/en_us.lang.php                              5             40             11
en_us/modules/Connectors/connectors/sources/ext/rest/linkedin/language/en_us.lang.php                      6             42             10
en_us/modules/LabelEditor/language/en_us.lang.php                                                          2             34              8
en_us/include/SugarObjects/implements/team_security/language/en_us.lang.php                                1             34              5
en_us/include/SugarObjects/implements/assignable/language/en_us.lang.php                                   1             34              5
en_us/modules/MySettings/language/en_us.lang.php                                                           2             34              4
------------------------------------------------------------------------------------------------------------------------------------------
SUM:                                                                                                     945           3394          11943
------------------------------------------------------------------------------------------------------------------------------------------

