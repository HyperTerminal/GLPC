<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tareas',
  'LBL_TASK' => 'Tareas: ',
  'LBL_MODULE_TITLE' => ' Tareas: Inicio',
  'LBL_SEARCH_FORM_TITLE' => ' Búsqueda de Tareas',
  'LBL_LIST_FORM_TITLE' => ' Lista de Tareas',
  'LBL_NEW_FORM_TITLE' => ' Nueva Tarea',
  'LBL_NEW_FORM_SUBJECT' => 'Asunto:',
  'LBL_NEW_FORM_DUE_DATE' => 'Fecha Vencimiento:',
  'LBL_NEW_FORM_DUE_TIME' => 'Hora Vencimiento:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_PRIORITY' => 'Prioridad',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_DUE_DATE' => 'Fecha Vencimiento',
  'LBL_LIST_DUE_TIME' => 'Hora Vencimiento',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_STATUS' => 'Estado:',
  'LBL_DUE_DATE' => 'Fecha vencimiento:',
  'LBL_DUE_TIME' => 'Hora vencimiento:',
  'LBL_PRIORITY' => 'Prioridad:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Fecha y hora de vencimiento:',
  'LBL_START_DATE_AND_TIME' => 'Fecha y hora de inicio:',
  'LBL_START_DATE' => 'Fecha de inicio:',
  'LBL_LIST_START_DATE' => 'Fecha de inicio',
  'LBL_START_TIME' => 'Hora de inicio:',
  'LBL_LIST_START_TIME' => 'Hora de inicio',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  'LBL_NONE' => 'Ninguno',
  'LBL_CONTACT' => 'Contacto:',
  'LBL_PHONE' => 'Teléfono:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Información adicional',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_NAME' => 'Nombre:',
  'LBL_CONTACT_NAME' => 'Contacto: ',
  'LBL_LIST_COMPLETE' => 'Completo:',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_DATE_DUE_FLAG' => 'Sin fecha de vencimiento',
  'LBL_DATE_START_FLAG' => 'Sin fecha de inicio',
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'ERR_INVALID_HOUR' => 'Por favor, introduzca una hora entre 0 y 24',
  'LBL_DEFAULT_STATUS' => 'No Iniciada',
  'LBL_DEFAULT_PRIORITY' => 'Media',
  'LBL_LIST_MY_TASKS' => 'Mis Tareas Abiertas',
  'LNK_NEW_CALL' => 'Programar Llamada',
  'LNK_NEW_MEETING' => 'Programar Reunión',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NEW_NOTE' => 'Nueva Nota o Archivo Adjunto',
  'LNK_NEW_EMAIL' => 'Archivar Email',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_CONTACT_FIRST_NAME' => 'Nombre del Contacto',
  'LBL_CONTACT_LAST_NAME' => 'Apellido del Contacto',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
);


?>