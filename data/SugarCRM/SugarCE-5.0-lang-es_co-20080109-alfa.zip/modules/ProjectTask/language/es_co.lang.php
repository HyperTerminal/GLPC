<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tareas de Proyecto',
  'LBL_MODULE_TITLE' => 'Tareas de Proyecto: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Tareas de Proyecto',
  'LBL_LIST_FORM_TITLE' => 'Lista de Tareas de Proyecto',
  'LBL_ID' => 'Id:',
  'LBL_DATE_ENTERED' => 'Fecha Creación:',
  'LBL_DATE_MODIFIED' => 'Fecha Modificación:',
  'LBL_ASSIGNED_USER_ID' => 'Asignado a:',
  'LBL_MODIFIED_USER_ID' => 'Modificado por:',
  'LBL_CREATED_BY' => 'Creado por:',
  'LBL_TEAM_ID' => 'Equipo:',
  'LBL_NAME' => 'Nombre:',
  'LBL_STATUS' => 'Estado:',
  'LBL_DATE_DUE' => 'Fecha Vencimiento:',
  'LBL_TIME_DUE' => 'Hora Vencimiento:',
  'LBL_DATE_START' => 'Fecha Inicio:',
  'LBL_TIME_START' => 'Hora Inicio:',
  'LBL_PARENT_ID' => 'Proyecto:',
  'LBL_PRIORITY' => 'Prioridad:',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_ORDER_NUMBER' => 'Orden:',
  'LBL_TASK_NUMBER' => 'Número de Tarea:',
  'LBL_DEPENDS_ON_ID' => 'Depende de:',
  'LBL_MILESTONE_FLAG' => 'Hito:',
  'LBL_ESTIMATED_EFFORT' => 'Trabajo Estimado (h):',
  'LBL_ACTUAL_EFFORT' => 'Trabajo Real (h):',
  'LBL_UTILIZATION' => 'Ocupación (%):',
  'LBL_PERCENT_COMPLETE' => 'Progreso (%):',
  'LBL_DELETED' => 'Eliminada:',
  'LBL_LIST_ORDER_NUMBER' => 'Orden',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_PARENT_NAME' => 'Proyecto',
  'LBL_LIST_PERCENT_COMPLETE' => 'Progreso (%)',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_ASSIGNED_USER_ID' => 'Asignada a',
  'LBL_LIST_DATE_DUE' => 'Fecha Vencimiento',
  'LBL_LIST_DATE_START' => 'Fecha Inicio',
  'LBL_LIST_PRIORITY' => 'Prioridad',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_PROJECT_NAME' => 'Nombre Proyecto',
  'LNK_NEW_PROJECT' => 'Crear Proyecto',
  'LNK_PROJECT_LIST' => 'Lista de Proyectos',
  'LNK_NEW_PROJECT_TASK' => 'Crear Tarea de Proyecto',
  'LNK_PROJECT_TASK_LIST' => 'Tareas de Proyecto',
  'LBL_LIST_MY_PROJECT_TASKS' => 'Mis Tareas de Proyecto Abiertas',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Tareas de Proyecto',
  'LBL_NEW_FORM_TITLE' => 'Nueva Tarea de Proyecto',
  'LBL_ACTIVITIES_TITLE' => 'Actividades',
  'LBL_HISTORY_TITLE' => 'Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historial',
  'DATE_JS_ERROR' => 'Por favor, introduzca una fecha que corresponda a la hora introducida',
);
?>
