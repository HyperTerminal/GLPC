<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Revisión de Documento',
	
	'LNK_NEW_DOCUMENT' => 'Nuevo Documento',
	'LNK_DOCUMENT_LIST'=> 'Lista de Documentos',

	//vardef labels
	'LBL_REVISION_NAME' => 'Número de Revisión',
	'LBL_FILENAME' => 'Nombre de Archivo',
	'LBL_MIME' => 'Tipo MIME',
	'LBL_REVISION' => 'Revisión',
	'LBL_DOCUMENT' => 'Documento Relacionado',
	'LBL_LATEST_REVISION' => 'Última Revisión',
	'LBL_ACTIVE_DATE'=> 'Fecha de Publicación',
	'LBL_EXPIRATION_DATE' => 'Fecha de Caducidad',
	'LBL_FILE_EXTENSION'  => 'Extensión de Archivo',
	'LBL_DET_CREATED_BY' => 'Creado Por:',
	'LBL_DET_DATE_CREATED' => 'Fecha de Creación:',
	
	'LBL_DOC_NAME' => 'Nombre de Documento:',
	'LBL_DOC_VERSION' => 'Revisión:',
	
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Revisión',
	'LBL_REV_LIST_ENTERED' => 'Fecha de Creación',
	'LBL_REV_LIST_CREATED' => 'Creado por',
	'LBL_REV_LIST_LOG'=> 'Registro de Cambios',
	'LBL_REV_LIST_FILENAME' => 'Nombre de archivo',
	
	'LBL_CURRENT_DOC_VERSION'=> 'Última Revisión:',
	'LBL_CHANGE_LOG'=> 'Registro de Cambios:',
	'LBL_SEARCH_FORM_TITLE'=> 'Búsqueda de Documentos',
	
	//error messages
	'ERR_FILENAME'=> 'Nombre de Archivo',
	'ERR_DOC_VERSION'=> 'Versión de Documento',
	'ERR_DELETE_CONFIRM'=> '¿Desea eliminar esta revisión del documento?',
	'ERR_DELETE_LATEST_VERSION'=> 'No tiene permisos para eliminar la última revisión de un documento.',
);


?>
