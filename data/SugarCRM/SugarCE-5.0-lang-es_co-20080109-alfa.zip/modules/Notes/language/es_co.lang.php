<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'LBL_ACCOUNT_ID' => 'ID Cuenta:',
  'LBL_CASE_ID' => 'ID Caso:',
  'LBL_CLOSE' => 'Cerrar:',
  'LBL_COLON' => ':',
  'LBL_CONTACT_ID' => 'ID Contacto:',
  'LBL_CONTACT_NAME' => 'Contacto:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Notas',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_FILE_MIME_TYPE' => 'Tipo MIME',
  'LBL_FILE_URL' => 'URL de Archivo',
  'LBL_FILENAME' => 'Adjunto:',
  'LBL_LEAD_ID' => 'ID Candidato:',
  'LBL_LIST_CONTACT_NAME' => 'Contacto',
  'LBL_LIST_DATE_MODIFIED' => 'Modificado',
  'LBL_LIST_FILENAME' => 'Adjunto',
  'LBL_LIST_FORM_TITLE' => 'Lista de Notas',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_MODULE_NAME' => 'Notas',
  'LBL_MODULE_TITLE' => 'Notas: Inicio',
  'LBL_NEW_FORM_TITLE' => 'Nueva Nota o Archivo Adjunto',
  'LBL_NOTE_STATUS' => 'Nota',
  'LBL_NOTE_SUBJECT' => 'Asunto:',
  'LBL_NOTES_SUBPANEL_TITLE' => 'Adjuntos',
  'LBL_NOTE' => 'Nota:',
  'LBL_OPPORTUNITY_ID' => 'ID Oportunidad:',
  'LBL_PARENT_ID' => 'ID Padre:',
  'LBL_PARENT_TYPE' => 'Tipo de Padre',
  'LBL_PHONE' => 'Teléfono:',
  'LBL_PORTAL_FLAG' => '¿Mostrar en el Portal?',
  'LBL_EMBED_FLAG' => '¿Incluir en email?',
  'LBL_PRODUCT_ID' => 'ID Producto:',
  'LBL_QUOTE_ID' => 'ID Presupuesto:',
  'LBL_RELATED_TO' => 'Relativo a:',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Notas',
  'LBL_STATUS' => 'Estado',
  'LBL_SUBJECT' => 'Asunto:',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_IMPORT_NOTES' => 'Importar Notas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_NEW_CALL' => 'Programar Llamada',
  'LNK_NEW_EMAIL' => 'Archivar Email',
  'LNK_NEW_MEETING' => 'Programar Reunión',
  'LNK_NEW_NOTE' => 'Nueva Nota o Adjunto',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_MEMBER_OF' => 'Miembro de:',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
  'LBL_OC_FILE_NOTICE' => 'Por favor, inicie la sesión en el servidor para ver el archivo',
  'LBL_REMOVING_ATTACHMENT'=>'Quitando adjunto...',
  'ERR_REMOVING_ATTACHMENT'=>'Error al quitar adjunto...',
);


?>