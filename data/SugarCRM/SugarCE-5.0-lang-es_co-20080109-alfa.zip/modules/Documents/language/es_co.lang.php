<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Documentos',
  'LBL_MODULE_TITLE' => 'Documentos: Inicio',
  'LNK_NEW_DOCUMENT' => 'Crear Documento',
  'LNK_DOCUMENT_LIST' => 'Lista de Documentos',
  'LBL_DOC_REV_HEADER' => 'Revisiones',
  'LBL_SEARCH_FORM_TITLE'=> 'Búsqueda de Documentos',
  'LBL_DOCUMENT_ID' => 'Id de Documento',
  'LBL_NAME' => 'Nombre de Documento',
	//module
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_CATEGORY' => 'Categoría',
  'LBL_SUBCATEGORY' => 'Subcategoría',
  'LBL_STATUS' => 'Estado',
  'LBL_CREATED_BY' => 'Creado por',
	//vardef labels
  'LBL_DATE_ENTERED' => 'Fecha Creación',
  'LBL_DATE_MODIFIED' => 'Fecha Modificación',
  'LBL_DELETED' => 'Eliminado',
  'LBL_MODIFIED' => 'Modificado por id',
  'LBL_MODIFIED_USER' => 'Modificado por',
  'LBL_CREATED' => 'Creado por',
  'LBL_RELATED_DOCUMENT_ID'=>'Id de Documento Relacionado',
  'LBL_RELATED_DOCUMENT_REVISION_ID'=>'Id de Revisión de Documento Relacionado',
  'LBL_IS_TEMPLATE'=>'Es una Plantilla',
  'LBL_TEMPLATE_TYPE'=>'Tipo de Documento',
  'LBL_REVISION_NAME' => 'Número de Revisión',
  'LBL_FILENAME' => 'Nombre de Archivo:',
  'LBL_MIME' => 'Tipo MIME',
  'LBL_REVISION' => 'Revisión',
  'LBL_DOCUMENT' => 'Documento Relacionado',
  'LBL_LATEST_REVISION' => 'Última Revisión',
  'LBL_CHANGE_LOG' => 'Historial de Cambios:',
  'LBL_ACTIVE_DATE' => 'Fecha de Publicación',
  'LBL_EXPIRATION_DATE' => 'Fecha de Caducidad',
  'LBL_FILE_EXTENSION' => 'Extensión de Archivo',
  'LBL_CAT_OR_SUBCAT_UNSPEC' => 'Sin especificar',
  'LBL_DOC_NAME' => 'Nombre de Documento:',
  'LBL_DOC_VERSION' => 'Revisión:',
  'LBL_CATEGORY_VALUE' => 'Categoría:',
  'LBL_SUBCATEGORY_VALUE' => 'Subcategoría:',
  'LBL_DOC_STATUS' => 'Estado:',
  'LBL_LAST_REV_CREATOR' => 'Revisión Creada Por:',
  'LBL_LAST_REV_DATE' => 'Fecha de Revisión:',
  'LBL_DOWNNLOAD_FILE' => 'Archivo de Descarga:',
  'LBL_DET_RELATED_DOCUMENT'=>'Documento Relacionado:',
  'LBL_DET_RELATED_DOCUMENT_VERSION'=>'Revisión de Documento Relacionado:',
  'LBL_DET_IS_TEMPLATE'=>'¿Plantilla? :',
  'LBL_DET_TEMPLATE_TYPE'=>'Tipo de Documento:',
  'LBL_TEAM' => 'Equipo:',
	//document edit and detail view
  'LBL_DOC_DESCRIPTION' => 'Descripción:',
  'LBL_DOC_ACTIVE_DATE' => 'Fecha de Publicación:',
  'LBL_DOC_EXP_DATE' => 'Fecha de Caducidad:',
  'LBL_LIST_FORM_TITLE' => 'Lista de Documentos',
  'LBL_LIST_DOCUMENT' => 'Documento',
  'LBL_LIST_DOWNLOAD' => 'Descargar',
  'LBL_LIST_CATEGORY' => 'Categoría',
  'LBL_LIST_SUBCATEGORY' => 'Subcategoría',
  'LBL_LIST_REVISION' => 'Revisión',
  'LBL_LIST_LAST_REV_CREATOR' => 'Publicado Por',
  'LBL_LIST_LAST_REV_DATE' => 'Fecha de Revisión',
  'LBL_LIST_VIEW_DOCUMENT' => 'Ver',
  'LBL_LIST_ACTIVE_DATE' => 'Fecha de Publicación',
  'LBL_LIST_EXP_DATE' => 'Fecha de Caducidad',
	//document list view.
  'LBL_LIST_STATUS' => 'Estado',	
  'LBL_SF_DOCUMENT' => 'Nombre de Documento:',
  'LBL_SF_CATEGORY' => 'Categoría:',
  'LBL_SF_SUBCATEGORY' => 'Subcategoría:',
  'LBL_SF_ACTIVE_DATE' => 'Fecha de Publicación:',
  'LBL_SF_EXP_DATE' => 'Fecha de Caducidad:',
  'DEF_CREATE_LOG' => 'Documento Creado',
  'ERR_DOC_NAME' => 'Nombre de Documento',
  'ERR_DOC_ACTIVE_DATE' => 'Fecha de Publicación',
  'ERR_DOC_EXP_DATE' => 'Fecha de Caducidad',
	//document revisions.
  'ERR_FILENAME' => 'Nombre de archivo',
  'ERR_DOC_VERSION' => 'Versión de Documento',
  'ERR_DELETE_CONFIRM' => '¿Desea eliminar esta revisión del documento?',
  'ERR_DELETE_LATEST_VERSION' => 'No tiene permisos para eliminar la última revisión de un documento.',
  'LNK_NEW_MAIL_MERGE' => 'Combinar Correspondencia',
  'LBL_MAIL_MERGE_DOCUMENT' => 'Plantilla para Combinar Correspondencia:',
  'LBL_TREE_TITLE' => 'Documentos',
  	//sub-panel vardefs.
  'LBL_LIST_DOCUMENT_NAME'=>'Nombre de Documento',
  'LBL_CONTRACT_NAME'=>'Nombre de Contrato:',
  'LBL_LIST_IS_TEMPLATE'=>'¿Plantilla?',
  'LBL_LIST_TEMPLATE_TYPE'=>'Tipo de Documento',
  'LBL_LIST_SELECTED_REVISION'=>'Revisión Seleccionada',
  'LBL_LIST_LATEST_REVISION'=>'Última Revisión',
  'LBL_CONTRACTS_SUBPANEL_TITLE'=>'Contratos Relacionados',
  //'LNK_DOCUMENT_CAT'=>'Categorías de Documentos',
  'LBL_LAST_REV_CREATE_DATE'=>'Fecha de Creación de Última Revisión',
);


?>