<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Proyecto',
  'LBL_MODULE_TITLE' => 'Proyectos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Proyectos',
  'LBL_LIST_FORM_TITLE' => 'Lista de Proyectos',
  'LBL_HISTORY_TITLE' => 'Historial',
  'LBL_ID' => 'Id:',
  'LBL_DATE_ENTERED' => 'Fecha Creación:',
  'LBL_DATE_MODIFIED' => 'Fecha Modificación:',
  'LBL_ASSIGNED_USER_ID' => 'Asignado a:',
  'LBL_MODIFIED_USER_ID' => 'Modificado por:',
  'LBL_CREATED_BY' => 'Creado por:',
  'LBL_TEAM_ID' => 'Equipo:',
  'LBL_NAME' => 'Nombre:',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_DELETED' => 'Eliminado:',
  'LBL_TOTAL_ESTIMATED_EFFORT' => 'Trabajo Total Estimado (h):',
  'LBL_TOTAL_ACTUAL_EFFORT' => 'Trabajo Total Real (h):',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_ASSIGNED_USER_ID' => 'Asignado a',
  'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Trabajo Total Estimado (h)',
  'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Trabajo Total Real (h)',
  'LBL_PROJECT_SUBPANEL_TITLE' => 'Proyectos',
  'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Tareas de Proyecto',
  'LBL_CONTACT_SUBPANEL_TITLE' => 'Contactos',
  'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Cuentas',
  'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Oportunidades',
  'LBL_QUOTE_SUBPANEL_TITLE' => 'Presupuestos',
  'CONTACT_REMOVE_PROJECT_CONFIRM' => '¿Está seguro de que desea eliminar este contacto de este proyecto?',
  'LNK_NEW_PROJECT' => 'Crear Proyecto',
  'LNK_PROJECT_LIST' => 'Lista de Proyectos',
  'LNK_NEW_PROJECT_TASK' => 'Crear Tarea de Proyecto',
  'LNK_PROJECT_TASK_LIST' => 'Tareas de Proyecto',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Proyectos',
  'LBL_ACTIVITIES_TITLE' => 'Actividades',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historial',
  'LBL_QUICK_NEW_PROJECT' => 'Nuevo Proyecto',
  'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Tareas de Proyecto',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Cuentas',
  'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Oportunidades',
  'LBL_QUOTES_SUBPANEL_TITLE' => 'Presupuestos',
);


?>