<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

global $sugar_config;

$mod_strings = array (
// OOTB Scheduler Job Names:
'LBL_OOTB_WORKFLOW'		=> 'Procesar Tareas de Workflow',
'LBL_OOTB_REPORTS'		=> 'Ejecutar Tareas Programadas de Generación de Informes',
'LBL_OOTB_IE'			=> 'Comprobar Bandejas de Entrada',
'LBL_OOTB_BOUNCE'		=> 'Ejecutar Proceso Nocturno de Emails de Campaña Rebotados',
'LBL_OOTB_CAMPAIGN'		=> 'Ejecutar Proceso Nocturno de Campañas de Email Masivo',
'LBL_OOTB_PRUNE'		=> 'Truncar Base de datos al Inicio del Mes',
// List Labels
'LBL_LIST_JOB_INTERVAL' => 'Intervalo:',
'LBL_LIST_LIST_ORDER' => 'Planificadores:',
'LBL_LIST_NAME' => 'Planificador:',
'LBL_LIST_RANGE' => 'Rango:',
'LBL_LIST_REMOVE' => 'Quitar:',
'LBL_LIST_STATUS' => 'Estado:',
'LBL_LIST_TITLE' => 'Lista de Planificación:',
'LBL_LIST_EXECUTE_TIME' => 'Será ejecutado en:',
// human readable:
'LBL_SUN' => 'Domingo',
'LBL_MON' => 'Lunes',
'LBL_TUE' => 'Martes',
'LBL_WED' => 'Miércoles',
'LBL_THU' => 'Jueves',
'LBL_FRI' => 'Viernes',
'LBL_SAT' => 'Sábado',
'LBL_ALL'		=> 'Todos los días',
'LBL_EVERY_DAY'	=> 'Todos los días ',
'LBL_AT_THE'	=> 'El ',
'LBL_EVERY'		=> 'Cada ',
'LBL_FROM'		=> 'Desde ',
'LBL_ON_THE'	=> 'En el ',
'LBL_RANGE'		=> ' a ',
'LBL_AT' 		=> ' en ',
'LBL_IN'		=> ' en ',
'LBL_AND'		=> ' y ',
'LBL_MINUTES'	=> ' minutos ',
'LBL_HOUR'		=> ' horas',
'LBL_HOUR_SING'	=> ' hora',
'LBL_MONTH'		=> ' mes',
'LBL_OFTEN'		=> ' Tan a menudo como sea posible.',
'LBL_MIN_MARK'	=> ' marca por minuto',

// crontabs
'LBL_MINS' => 'min',
'LBL_HOURS' => 'hrs',
'LBL_DAY_OF_MONTH' => 'fecha',
'LBL_MONTHS' => 'me',
'LBL_DAY_OF_WEEK' => 'día',
'LBL_CRONTAB_EXAMPLES' => 'Lo arriba mostrado utiliza notación estándar de crontab.',
// Labels
'LBL_ALWAYS' => 'Siempre',
'LBL_CATCH_UP' => 'Ejecutar Si Falla',
'LBL_CATCH_UP_WARNING' => 'Desmarque si la ejecución de esta Tarea puede durar más de un momento.',
'LBL_DATE_TIME_END' => 'Fecha y Hora de Fin',
'LBL_DATE_TIME_START' => 'Fecha y Hora de Inicio',
'LBL_INTERVAL' => 'Intervalo',
'LBL_JOB' => 'Tarea',
'LBL_LAST_RUN' => 'Última Ejecución Exitosa',
'LBL_MODULE_NAME' => 'Planificador Sugar',
'LBL_MODULE_TITLE' => 'Planificadores',
'LBL_NAME' => 'Nombre de Tarea',
'LBL_NEVER' => 'Nunca',
'LBL_NEW_FORM_TITLE' => 'Nueva Planificación',
'LBL_PERENNIAL' => 'continuo',
'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Planificación',
'LBL_SCHEDULER' => 'Planificador:',
'LBL_STATUS' => 'Estado',
'LBL_TIME_FROM' => 'Activo Desde',
'LBL_TIME_TO' => 'Activo Hasta',
'LBL_WARN_CURL_TITLE' => 'Aviso cURL:',
'LBL_WARN_CURL' => 'Aviso:',
'LBL_WARN_NO_CURL' => 'Este sistema no tiene las librerías cURL habilitadas/compiladas en el módulo de PHP (--with-curl=/ruta/a/libreria_curl).  Por favor, contacte con su administrador para resolver el problema.  Sin la funcionalidad que provee cURL, el Planificador no puede utilizar hilos con sus tareas.', //HACER: Revisar traducción de "thread"
'LBL_BASIC_OPTIONS' => 'Configuración Básica',
'LBL_ADV_OPTIONS'		=> 'Opciones Avanzadas',
'LBL_TOGGLE_ADV' => 'Opciones Avanzadas',
'LBL_TOGGLE_BASIC' => 'Opciones Básicas',
// Links
'LNK_LIST_SCHEDULER' => 'Planificadores',
'LNK_NEW_SCHEDULER' => 'Nuevo Planificador',
'LNK_LIST_SCHEDULED' => 'Tareas Planificadas',
// Messages
'SOCK_GREETING' => "\nEste es el interfaz de usuario para el Servicio de Planificación de SugarCRM. \n[ Comandos de demonio disponibles: start|restart|shutdown|status ]\nPara salir, teclee 'quit'.  Para detener el servicio 'shutdown'.\n",
'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro para eliminar la planificación.',
'NTC_DELETE_CONFIRMATION' => '¿Está seguro de que desea eliminar este registro?',
'NTC_STATUS' => 'Establezca el estado a Inactivo para quitar esta Planificación de las listas desplegables de selección de Planificador',
'NTC_LIST_ORDER' => 'Establezca el orden en que esta Planificación aparecerá en las listas desplegables de selección de Planificador',
'LBL_CRON_INSTRUCTIONS_WINDOWS' => 'Para configurar el Planificador de Windows',
'LBL_CRON_INSTRUCTIONS_LINUX' => 'Para configurar Crontab',
'LBL_CRON_LINUX_DESC' => 'Añada esta línea en su crontab: ',
'LBL_CRON_WINDOWS_DESC' => 'Crear un archivo de proceso por lotes con los siguientes comandos: ',
'LBL_NO_PHP_CLI' => 'Si su servidor no tiene disponibles los binarios PHP, puede utilizar wget o curl para lanzar sus Tareas.<br>para wget: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;wget --quiet --non-verbose '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1</b><br>para curl: <b>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;curl --silent '.$sugar_config['site_url'].'/cron.php > /dev/null 2>&1',
// Subpanels
'LBL_JOBS_SUBPANEL_TITLE'	=> 'Registro de Tareas',
'LBL_EXECUTE_TIME'			=> 'Tiempo de Ejecución',
);
?>
