<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Oportunidades',
  'LBL_MODULE_TITLE' => 'Oportunidades: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Oportunidades',
  'LBL_VIEW_FORM_TITLE' => 'Vista de Oportunidades',
  'LBL_LIST_FORM_TITLE' => 'Lista de Oportunidades',
  'LBL_OPPORTUNITY_NAME' => 'Nombre Oportunidad:',
  'LBL_OPPORTUNITY' => 'Oportunidad:',
  'LBL_NAME' => 'Nombre Oportunidad',
  'LBL_INVITEE' => 'Contactos',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Oportunidad',
  'LBL_LIST_ACCOUNT_NAME' => 'Cuenta',
  'LBL_LIST_AMOUNT' => 'Cantidad',
  'LBL_LIST_DATE_CLOSED' => 'Fecha Cierre',
  'LBL_LIST_SALES_STAGE' => 'Etapa Ventas',
  'LBL_ACCOUNT_ID' => 'ID Cuenta',
  'LBL_CURRENCY_ID' => 'ID Moneda',
  'LBL_TEAM_ID' => 'ID Equipo',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Opportunidad - Actualizar Moneda',
  'UPDATE_DOLLARAMOUNTS' => 'Actualizar Cantidades Dólar EEUU',
  'UPDATE_VERIFY' => 'Verificar Cantidades',
  'UPDATE_VERIFY_TXT' => 'Verifica que los valores de las cantidades en las oportunidades son números decimales válidos con sólo caracteres numéricos (0-9) y decimales(.)',
  'UPDATE_FIX' => 'Corregir Cantidades',
  'UPDATE_FIX_TXT' => 'Intenta corregir cualquier cantidad no válida creando un número decimal válido a partir de la cantidad actual. Antes realiza una copia de seguridad de todas las cantidades modificadas en el campo de base de datos amount_backup. Si tras la correción detecta problemas, no vuelva a realizar esta operación sin restaurar los valores previos desde la copia de seguridad ya que si no sobreescribirá la copia de seguridad con nuevos datos incorrectos.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Actualiza las cantidades en Dólares EEUU para las oportunidades basadas en el conjunto actual de monedas. Este valor se usa para calcular gráficas y vistas de listas de cantidades monetarias.',
  'UPDATE_CREATE_CURRENCY' => 'Creación de nueva moneda:',
  'UPDATE_VERIFY_FAIL' => 'Fallo de verificación de registro:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Cantidad actual:',
  'UPDATE_VERIFY_FIX' => 'La corrección daría',
  'UPDATE_INCLUDE_CLOSE' => 'Registros cerrados incluidos',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nueva cantidad:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nueva moneda:',
  'UPDATE_DONE' => 'Hecho',
  'UPDATE_BUG_COUNT' => 'Problemas detectados y supuéstamente corregidos:',
  'UPDATE_BUGFOUND_COUNT' => 'Problemas detectados:',
  'UPDATE_COUNT' => 'Registros actualizados:',
  'UPDATE_RESTORE_COUNT' => 'Registros con cantidades restauradas:',
  'UPDATE_RESTORE' => 'Restaurar Cantidades',
  'UPDATE_RESTORE_TXT' => 'Restaura los valores de las cantidades desde la copia de seguridad creada durante la corrección.',
  'UPDATE_FAIL' => 'No ha podido actualizarse - ',
  'UPDATE_NULL_VALUE' => 'La cantidad es NULL, estableciéndola a 0 -',
  'UPDATE_MERGE' => 'Unificar Monedas',
  'UPDATE_MERGE_TXT' => 'Unifica múltiples monedas en una única moneda. Si detecta que hay múltiples registros de tipo moneda para la misma moneda, puede unificarlas. Esto también unificará las monedas para el resto de módulos.',
  'LBL_ACCOUNT_NAME' => 'Cuenta:',
  'LBL_AMOUNT' => 'Cantidad:',
  'LBL_CURRENCY' => 'Moneda:',
  'LBL_DATE_CLOSED' => 'Fecha de cierre:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_CAMPAIGN' => 'Campaña:',
  'LBL_NEXT_STEP' => 'Próximo paso:',
  'LBL_LEAD_SOURCE' => 'Toma de contacto:',
  'LBL_SALES_STAGE' => 'Etapa de ventas:',
  'LBL_PROBABILITY' => 'Probabilidad (%):',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_DUPLICATE' => 'Posible oportunidad duplicada',
  'MSG_DUPLICATE' => 'La creación de esta oportunidad puede producir una oportunidad duplicada. Puede elegir una oportunidad existente de la lista inferior o hacer clic en Guardar para continuar la creación de una nueva oportunidad con los datos introducidos previamente.',
  'LBL_NEW_FORM_TITLE' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LNK_OPPORTUNITY_REPORTS' => 'Informes de Oportunidades',
  'LNK_OPPORTUNITY_LIST' => 'Oportunidades',
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'LBL_TOP_OPPORTUNITIES' => 'Mis Principales Oportunidades',
  'NTC_REMOVE_OPP_CONFIRMATION' => '¿Está seguro de que desea eliminar este contacto de esta oportunidad?',
  'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => '¿Está seguro de que desea eliminar esta oportunidad de este proyecto?',
  'LBL_AMOUNT_BACKUP' => 'Cantidad de Respaldo',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Oportunidades',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historial',
  'LBL_RAW_AMOUNT' => 'Cantidad Bruta',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Candidatos',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
  'LBL_QUOTES_SUBPANEL_TITLE' => 'Presupuestos',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Proyectos',
  'LBL_ASSIGNED_TO_NAME' => 'Usuario Asignado:',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
  'LBL_CONTRACTS'=>'Contratos',
  'LBL_CONTRACTS_SUBPANEL_TITLE'=>'Contratos',	
  'LBL_LIST_SALES_STAGE'=>'Estapa de Ventas',
);


?>