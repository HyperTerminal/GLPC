<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/	

$mod_strings = array (
	'LBL_MODULE_NAME'=>'Configuración del Sistema',
	'LBL_MODULE_ID'=>'Configurador',
	'LBL_MODULE_TITLE'=>'Interfaz de Usuario',
	'ADMIN_EXPORT_ONLY'=>'Sólo el Admin puede exportar',
	'DISABLE_EXPORT'=>'Deshabilitar exportación',
	'DEFAULT_CURRENCY_NAME'=>'Nombre de moneda',
	'DEFAULT_CURRENCY_SYMBOL'=>'Símbolo de moneda',
	'DEFAULT_CURRENCY_ISO4217'=>'Código de moneda ISO 4217',
	'DEFAULT_CURRENCY'=>'Moneda predeterminada',
	'EXPORT'=>'Exportación',
	'EXPORT_CHARSET'=>'Juego de caracteres de exportación predeterminado',
	'EXPORT_DELIMITER'=>'Delimitador para Exportación',
	'QUOTES_CURRENT_LOGO'=>'Logo utilizado en Presupuestos ',
	'NEW_QUOTE_LOGO'=>'Subir nuevo logo de Presupuesto (867x74)',
	'CURRENT_LOGO'=>'Logo actual en uso',
	'NEW_LOGO'=>'Subir nuevo logo (212x40)',
	'DEFAULT_SYSTEM_SETTINGS'=>'Interfaz de Usuario',
	'DEFAULT_DATE_FORMAT'=>'Formato de fecha predeterminado',
	'DEFAULT_TIME_FORMAT'=>'Formato de hora predeterminado',
	'DEFAULT_THEME'=> 'Tema predeterminado',
	'LBL_USE_REAL_NAMES'=>'Mostrar nombre completo (no id usuario)',
	'LIST_ENTRIES_PER_LISTVIEW'=>'Ítems por página para listas',
	'LIST_ENTRIES_PER_SUBPANEL'=>'Ítems por página para subpaneles',
	'DISPLAY_LOGIN_NAV'=>'Mostrar pestañas en la ventana de inicio de sesión',
	'DISPLAY_RESPONSE_TIME'=>'Mostrar los tiempos de respuesta del servidor',
	'ADVANCED'=>'Avanzado',
	'VERIFY_CLIENT_IP'=>'Validar dirección IP del usuario',
	'LOG_MEMORY_USAGE'=>'Registrar utilización de memoria',
	'LOG_SLOW_QUERIES'=> 'Registrar consultas lentas',
	'SLOW_QUERY_TIME_MSEC'=>'Tiempo umbral para consultas lentas (ms)',
	'UPLOAD_MAX_SIZE'=>'Tamaño máximo para subida de archivos',
	'STACK_TRACE_ERRORS'=>'Mostrar traza de la pila de errores',
	'IMAGES'=>'Logos',
	'DEFAULT_LANGUAGE'=>'Lenguaje predeterminado',
	'LBL_RESTORE_BUTTON_LABEL'=>'Restaurar',
	'LBL_PORTAL_ON_DESC' => 'Permite que un Caso, Nota y otros datos sean accesibles por un sistema externo de portal de autoservicio para clientes.',
	'LBL_PORTAL_ON' => '¿Permitir integración de portal de autoservicio?',
	'LBL_PORTAL_TITLE' => 'Portal de Autoservicio para el Cliente',
	'LBL_PROXY_AUTH'=>'¿Autenticación?',
	'LBL_PROXY_HOST'=>'Servidor Proxy',
	'LBL_PROXY_ON_DESC'=>'Configura la dirección del servidor proxy y la configuración de la autenticación',
	'LBL_PROXY_ON'=>'¿Utilizar servidor proxy?',
	'LBL_PROXY_PASSWORD'=>'Contraseña',
	'LBL_PROXY_PORT'=>'Puerto',
	'LBL_PROXY_TITLE'=>'Configuración del Proxy',
	'LBL_PROXY_USERNAME'=>'Nombre de Usuario',
	'LBL_SKYPEOUT_ON_DESC' => 'Permite a los usuarios hacer clic en los números de teléfono para realizar llamadas utilizando SkypeOut&reg;. Los números deben de estar formateados debidamente para utilizar esta funcionalidad. El número debe tener el formato: "+"  "Código País" "Número", como +34 965 555 555. Para más información, vea el FAQ de Skype en <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">FAQ de Skype&reg;</a>	',
	'LBL_SKYPEOUT_ON' => '¿Permitir integración con SkypeOut&reg;?',
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
	'LBL_MAILMERGE' => 'Combinar Correspondencia',
	'LBL_ENABLE_MAILMERGE' => '¿Habilitar combinar correspondencia?',
	'LBL_MAILMERGE_DESC' => 'Esta opción debería marcarse sólo si tiene el complemento Sugar para Microsoft&reg; Word&reg;.',
	'LBL_LOGVIEW' => 'Configuración de Registro',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configuración del Sistema',
	'LBL_MAIL_SMTPAUTH_REQ'				=> '¿Usar Autenticación SMTP?',
	'LBL_MAIL_SMTPPASS'					=> 'Contraseña SMTP:',
	'LBL_MAIL_SMTPPORT'					=> 'Puerto SMTP:',
	'LBL_MAIL_SMTPSERVER'				=> 'Servidor SMTP:',
	'LBL_MAIL_SMTPUSER'					=> 'Usuario SMTP:',
	'LBL_NOTIFY_FROMADDRESS' => 'Dirección "De":',
	'LBL_NOTIFY_SUBJECT' => 'Asunto de correo:',
	'DEFAULT_NUMBER_GROUPING_SEP'			=> 'Separador de miles',
	'DEFAULT_DECIMAL_SEP'					=> 'Símbolo decimal',
	'LOCK_HOMEPAGE' => 'No permitir el diseño personalizado de la Página de Inicio', 
	'LOCK_SUBPANELS'=> 'No permitir el diseño personalizado de subpaneles',
	'MAX_DASHLETS'=>'Máximo número de Dashlets en la Página de Inicio',
	'SYSTEM_NAME'=>'Nombre del Sistema',
	'LBL_OC_STATUS' => 'Estado por defecto de Cliente Desconectado:',
    'DEFAULT_OC_STATUS' => 'Habilitar Cliente Desconectado por defecto',
    'LBL_OC_STATUS_DESC' => 'Aquí puede comprobar si desea que cualquier usuario pueda tener acceso a un Cliente Desconectado.  En otro caso, puede configurar el aceso a nivel de usuario.',
    'SESSION_TIMEOUT' => 'Caducidad de la Sesión del Portal',
    'SESSION_TIMEOUT_UNITS' => 'segundos',

    'LBL_LDAP_TITLE'=>'Soporte de Autenticación LDAP',
    'LBL_LDAP_ENABLE'=>'Habilitar LDAP',
    'LBL_LDAP_SERVER_HOSTNAME'=> 'Servidor:',
    'LBL_LDAP_SERVER_PORT'=> 'Número de Puerto:',
    'LBL_LDAP_ADMIN_USER'=> 'Usuario Autenticado:',
    'LBL_LDAP_ADMIN_USER_DESC'=>'Utilizado para buscar el usuario Sugar. [Puede que tenga que estar totalmente calificado]<br>La conexión será anónima si no se provee.',
    'LBL_LDAP_ADMIN_PASSWORD'=> 'Contraseña Autenticada:',
    'LBL_LDAP_AUTO_CREATE_USERS'=>'Crear Usuarios Automáticamente:',
    'LBL_LDAP_BASE_DN'=>'DN Base:',
    'LBL_LDAP_LOGIN_ATTRIBUTE'=>'Atributo de Login:',
    'LBL_LDAP_BIND_ATTRIBUTE'=>'Atributo de Bind:',
    'LBL_LDAP_BIND_ATTRIBUTE_DESC'=>'Para conectar al servidor LDAP Ejemplos de usuario:[<b>AD:</b>&nbsp;userPrincipalName] [<b>openLDAP:</b>&nbsp;userPrincipalName] [<b>Mac&nbsp;OS&nbsp;X:</b>&nbsp;uid] ',
    'LBL_LDAP_LOGIN_ATTRIBUTE_DESC'=>'Para buscar en el servidor LDAP Ejemplos de usuario:[<b>AD:</b>&nbsp;userPrincipalName] [<b>openLDAP:</b>&nbsp;dn] [<b>Mac&nbsp;OS&nbsp;X:</b>&nbsp;dn] ',
    'LBL_LDAP_SERVER_HOSTNAME_DESC'=>'Ejemplo: ldap.example.com',
    'LBL_LDAP_SERVER_PORT_DESC'=>'Ejemplo: 389',
    'LBL_LDAP_BASE_DN_DESC'=>'Ejemplo: DC=SugarCRM,DC=com',
    'LBL_LDAP_AUTO_CREATE_USERS_DESC'=> 'Si un usuario autenticado no existe, se creará uno nuevo en Sugar.',
    'LBL_LDAP_ENC_KEY'	=> 'Clave de Encriptación:',
    'LBL_LDAP_ENC_KEY_DESC'	=> 'Para la autenticación SOAP al usar LDAP.',
    'LDAP_ENC_KEY_NO_FUNC_DESC' => 'La extensión php_mcrypt debe estar habilitada en su archivo php.ini.'
    );


?>
