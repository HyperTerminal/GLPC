<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array(

	'LBL_ASSIGN_TEAM'		=> 'Asignar a Equipo',

	
	'ERR_BAD_LOGIN_PASSWORD'=> 'Usuario o contraseña incorrecta',
	'ERR_BODY_TOO_LONG' => '\rEl texto del cuerpo es demasiado largo para capturar el email COMPLETO. Truncado.',
	'ERR_INI_ZLIB'			=> 'No pudo deshabilitarse la compresión Zlib temporalmente.  Puede que "Comprobar Configuración" falle.',
	'ERR_MAILBOX_FAIL'		=> 'No se pudo recuperar ninguna bandeja de correo.',
	'ERR_NO_IMAP'			=> 'No se han encontrado las librerías de IMAP.  Por favor, resuelva esto antes de continuar con la configuración de correo entrante',
	'ERR_NO_OPTS_SAVED'		=> 'No se han guardado valores óptimos con su bandeja de correo entrante.  Por favor, revise la configuración',
	'ERR_TEST_MAILBOX'		=> 'Por favor, compruebe su configuración e inténtelo de nuevo.',
	
	'LBL_APPLY_OPTIMUMS'	=> 'Aplicar Valores Óptimos',
	'LBL_ASSIGN_TO_USER'	=> 'Asignar a Usuario',
	'LBL_AUTOREPLY_OPTIONS'	=> 'Opciones de Respuesta Automática',
	'LBL_AUTOREPLY'			=> 'Plantilla de Respuesta Automática',
	'LBL_BASIC'				=> 'Configuración Básica',
	'LBL_CASE_MACRO'		=> 'Macro de Casos',
	'LBL_CASE_MACRO_DESC'	=> 'Establece la macro que será analizada y utilizada para vincular el email importado a un Caso.',
	'LBL_CASE_MACRO_DESC2'	=> 'Establezca ésto a cualquier valor que desee, pero preserve el <b>"%1"</b>.',
	'LBL_CERT_DESC' => 'Fozar la validación del Certificado de Seguridad del servidor - no utilizar en certificados no firmados por una autoridad raíz reconocida.',
	'LBL_CERT'				=> 'Validar Certificado',
	'LBL_CLOSE_POPUP'		=> 'Cerrar Ventana',
	'LBL_CREATE_NEW_GROUP'	=> '--Crear Grupo de Bandejas al Guardar--',
	'LBL_CREATE_TEMPLATE'	=> 'Crear',
	'LBL_DEFAULT_FROM_ADDR'	=> 'Por defecto: ',
	'LBL_DEFAULT_FROM_NAME'	=> 'Por defecto: ',
	'LBL_DELETE_SEEN'		=> 'Eliminar Emails Leídos Tras Importación',
	'LBL_EDIT_TEMPLATE'		=> 'Editar',
	'LBL_EMAIL_OPTIONS'		=> 'Opciones de Gestión de Correo',
	'LBL_FILTER_DOMAIN_DESC'=> 'No enviar respuestas automáticas a este dominio.',
	'LBL_FILTER_DOMAIN'		=> 'No enviar Respuestas automáticas a Dominio',
	'LBL_FIND_OPTIMUM_KEY'	=> 'f',
	'LBL_FIND_OPTIMUM_MSG'	=> '<br>Buscando variables óptimas de conexión.',
	'LBL_FIND_OPTIMUM_TITLE'=> 'Buscar Configuración Óptima',
	'LBL_FIND_SSL_WARN'		=> '<br>La comprobación de SSL puede durar bastante tiempo.  Por favor, tenga paciencia.<br>',
	'LBL_FORCE_DESC'		=> 'Algunos servidores IMAP/POP3 requieren opciones especiales. Marque para forzar una opción negativa al conectar (ej., /notls)',
	'LBL_FORCE'				=> 'Forzar Negativo',
	'LBL_FOUND_MAILBOXES'	=> 'Se han encontrado las siguientes carpetas utilizables.<br>Haga clic en una para seleccionarla:',
	'LBL_FOUND_OPTIMUM_MSG'	=> '<br>Opciones óptimas encontradas.	Presiones el siguiente botón para aplicarlas a su bandeja de correo.',
	'LBL_FROM_ADDR'			=> 'Dirección del remitente',
	'LBL_FROM_NAME_ADDR'	=> 'Nombre/Correo de Respuesta',
	'LBL_FROM_NAME'			=> 'Nombre del remitente',
	'LBL_GROUP_QUEUE'		=> 'Asignar a Grupo',
	'LBL_HOME' 				=> 'Inicio',
	'LBL_LIST_MAILBOX_TYPE'	=> 'Utilización de la Bandeja',
	'LBL_LIST_NAME'			=> 'Nombre:',
	'LBL_LIST_SERVER_URL'	=> 'Servidor de Correo:',
	'LBL_LIST_STATUS'		=> 'Estado:',
	'LBL_LOGIN'				=> 'Nombre de Usuario',
	'LBL_MAILBOX_DEFAULT'	=> 'INBOX',
	'LBL_MAILBOX_SSL_DESC'	=> 'Usar SSL en la conexión. Si no funciona, compruebe que su instalación de PHP incluye "--with-imap-ssl" en la configuración.',
	'LBL_MAILBOX_SSL'		=> 'Usar SSL',
	'LBL_MAILBOX_TYPE'		=> 'Acciones Posibles',
	'LBL_MAILBOX'			=> 'Carpeta Monitorizada',
	'LBL_MARK_READ_DESC'	=> 'Importar y marcar mensajes como leídos en el servidor de correo; no borrar.',
	'LBL_MARK_READ_NO'		=> 'Email marcado como borrado tras importación',
	'LBL_MARK_READ_YES'		=> 'Email dejado en el servidor tras importación',
	'LBL_MARK_READ'			=> 'Dejar mensajes en el servidor',
	'LBL_MODULE_NAME'		=> 'Configuración de Correo Entrante',
	'LBL_MODULE_TITLE'		=> 'Correo Entrante',
	'LBL_NAME'				=> 'Nombre',
	'LBL_NO_OPTIMUMS'		=> 'No se han encontrado valores óptimos.  Por favor, compruebe su configuración e inténtelo de nuevo.',
	'LBL_ONLY_SINCE_DESC'	=> 'Al usar POP3, PHP no se pueden realizar filtros en mesajes Nuevos/No leídos.  Esta opción permite que se soliciten mensajes DESDE la última vez que la bandeja fue consultada.  Esto mejorará significativamente el rendimiento si su servidor de correo no soporta IMAP.', 
	'LBL_ONLY_SINCE_NO'		=> 'No. Comprobar contra todos los correos en el servidor de correo.',
	'LBL_ONLY_SINCE_YES'	=> 'Sí.',
	'LBL_ONLY_SINCE'		=> 'Importar sólo desde la última comprobación',
	'LBL_PASSWORD_CHECK'	=> 'Comprobar Contraseña',
	'LBL_PASSWORD'			=> 'Contraseña',
	'LBL_POP3_SUCCESS'		=> 'Su prueba de conexión de POP3 tuvo éxito.',
	'LBL_POPUP_FAILURE'		=> 'Prueba de conexión fallida. El error es el siguiente:',
	'LBL_POPUP_SUCCESS'		=> 'Prueba de conexión exitosa.  Su configuración funciona.',
	'LBL_POPUP_TITLE'		=> 'Comprobar Configuración',
	'LBL_PORT'				=> 'Puerto del Servidor de Correo',
	'LBL_QUEUE'				=> 'Cola de la Bandeja',
	'LBL_SAVE_RAW'			=> 'Guardar Código Fuente Original',
	'LBL_SAVE_RAW_DESC_1'	=> 'Seleccione "Sí" si quiere preservar el código fuente original para cada email importado.',
	'LBL_SAVE_RAW_DESC_2'	=> 'Los archivos adjuntos grandes pueden producir erroror en bases de datos configuradas de forma restringida o incorrecta.',
	'LBL_SERVER_OPTIONS'	=> 'Configuración Avanzada',
	'LBL_SERVER_TYPE'		=> 'Protocolo del Servidor de Correo',
	'LBL_SERVER_URL'		=> 'Dirección del Servidor de Correo',
	'LBL_SSL_DESC'			=> 'Si su servidor de correo soporta conexiones seguras de sockets (SSL), habilitar esta opción forzará conexiones SSL al importar el correo.',
	'LBL_SSL'				=> 'Usar SSL',
	'LBL_STATUS'			=> 'Estado',
	'LBL_SYSTEM_DEFAULT'	=> 'Por Defecto en el Sistema',
	'LBL_TEST_BUTTON_KEY'	=> 't',
	'LBL_TEST_BUTTON_TITLE'	=> 'Probar [Alt+T]',
	'LBL_TEST_SETTINGS'		=> 'Probar Configuración',
	'LBL_TEST_SUCCESSFUL'	=> 'Conexión completada con éxito.',
	'LBL_TEST_WAIT_MESSAGE'	=> 'Un momento, por favor...',
	'LBL_TLS_DESC'			=> 'Usar Transport Layer Security para conectarse al servidor de correo - sólo use ésto si su servidor de correo soporta este protocolo.',
	'LBL_TLS'				=> 'Usar TLS',
	'LBL_WARN_IMAP_TITLE'	=> 'Correo Entrante Deshabilitado',
	'LBL_WARN_IMAP'			=> 'Avisos:',
	'LBL_WARN_NO_IMAP'		=> 'El Correo Entrante <b>no puede</b> funcionar sin las librerías de C del cliente de IMAP habilitadas/compiladas en el módulo de PHP.  Por favor, contacte con su administrador para resolver este problema.',
	
	'LNK_CREATE_GROUP'		=> 'Crear Nuevo Grupo',
	'LNK_LIST_CREATE_NEW'	=> 'Monitorizar Nueva Bandeja',
	'LNK_LIST_MAILBOXES'	=> 'Todas las Bandejas',
	'LNK_LIST_QUEUES'		=> 'Todas las Colas',
	'LNK_LIST_SCHEDULER'	=> 'Planificadores',
	'LNK_LIST_TEST_IMPORT'	=> 'Probar Importación de Correo',
	'LNK_NEW_QUEUES'		=> 'Crear Nueva Cola',
	'LNK_SEED_QUEUES'		=> 'Crear semilla para Colas de Equipos', // HACER: Revisar traducción
);

?>
