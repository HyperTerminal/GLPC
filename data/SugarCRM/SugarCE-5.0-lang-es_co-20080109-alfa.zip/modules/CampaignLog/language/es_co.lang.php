<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_ID' => 'ID Lista Prospectos',
  'LBL_ID' => 'ID',
  'LBL_TARGET_TRACKER_KEY' => 'Clave de Seguimiento de Objetivo',
  'LBL_TARGET_ID' => 'ID de Objetivo',
  'LBL_TARGET_TYPE' => 'Tipo de Objetivo',
  'LBL_ACTIVITY_TYPE' => 'Tipo de Actividad',
  'LBL_ACTIVITY_DATE' => 'Fecha de Actividad',
  'LBL_RELATED_ID' => 'ID Relacionado',
  'LBL_RELATED_TYPE' => 'Tipo Relacionado',
  'LBL_DELETED' => 'Eliminado',
  'LBL_MODULE_NAME' => 'Registro de Campaña',
  'LBL_LIST_RECIPIENT_EMAIL' => 'Email de Destinatario',
  'LBL_LIST_RECIPIENT_NAME' => 'Nombre de Destinatario',
  'LBL_ARCHIVED' => 'Archivado',
  'LBL_HITS' => 'Aciertos',
  'LBL_CAMPAIGN_NAME' => 'Nombre:',
  'LBL_CAMPAIGN' => 'Campaña:',
  'LBL_NAME' => 'Nombre: ',
  'LBL_INVITEE' => 'Contactos',
  'LBL_LIST_CAMPAIGN_NAME' => 'Campaña',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_TYPE' => 'Tipo',
  'LBL_LIST_END_DATE' => 'Fecha de Fin',
  'LBL_DATE_ENTERED' => 'Fecha de Alta',
  'LBL_DATE_MODIFIED' => 'Fecha de Modificación',
  'LBL_MODIFIED' => 'Modificado por: ',
  'LBL_CREATED' => 'Creado por: ',
  'LBL_TEAM' => 'Equipo: ',
  'LBL_ASSIGNED_TO' => 'Asignado a: ',
  'LBL_CAMPAIGN_START_DATE' => 'Fecha de Inicio: ',
  'LBL_CAMPAIGN_END_DATE' => 'Fecha de Fin: ',
  'LBL_CAMPAIGN_STATUS' => 'Estado: ',
  'LBL_CAMPAIGN_BUDGET' => 'Presupuesto: ',
  'LBL_CAMPAIGN_EXPECTED_COST' => 'Coste Estimado: ',
  'LBL_CAMPAIGN_ACTUAL_COST' => 'Coste Real: ',
  'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Ingresos Estimados: ',
  'LBL_CAMPAIGN_TYPE' => 'Tipo: ',
  'LBL_CAMPAIGN_OBJECTIVE' => 'Objetivo: ',
  'LBL_CAMPAIGN_CONTENT' => 'Descripción: ',
  'LBL_LIST_FORM_TITLE' => 'Campañas Objetivo',
  'LBL_LIST_ACTIVITY_DATE' => 'Fecha de Actividad',
  'LBL_LIST_CAMPAIGN_OBJECTIVE' => 'Objetivo de la Campaña',
  'LBL_RELATED' => 'Relacionado',
  'LBL_CLICKED_URL_KEY'=>'Clave del URL Visitado',
  'LBL_URL_CLICKED'=>'URL Visitado',
  'LBL_MORE_INFO'=>'Más Información',
);


?>