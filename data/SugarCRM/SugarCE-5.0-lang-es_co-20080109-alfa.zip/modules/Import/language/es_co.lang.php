<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'El directorio ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' no existe o no tiene permisos de escritura en el mismo',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'El archivo no pudo subirse con éxito. Puede que la opción \'upload_max_filesize\' de su archivo php.ini esté establecida a un valor demasiado pequeño',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'El archivo es demasiado grande. Máx:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Bytes. Cambie $sugar_config[\'upload_maxsize\'] en config.php',
  'LBL_MODULE_NAME' => 'Importar',
  'LBL_TRY_AGAIN' => 'Pruebe de nuevo',
  'LBL_ERROR' => 'Error:',
  'ERR_MULTIPLE' => 'Se han definido múltiples columnas con el mismo nombre de campo.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Faltan campos requeridos:',
  'ERR_SELECT_FULL_NAME' => 'No puede seleccionar Nombre Completo cuando Nombre y Apellido están seleccionados.',
  'ERR_SELECT_FILE' => 'Seleccione el archivo a subir.',
  'LBL_SELECT_FILE' => 'Seleccione archivo:',
  'LBL_CUSTOM' => 'Personalizado',
  'LBL_CUSTOM_CSV' => 'Archivo Personalizado Delimitado por Comas',
  'LBL_CSV' => 'Archivo Delimitado por Comas',
  'LBL_TAB' => 'Archivo Delimitado por Tabulaciones',
  'LBL_CUSTOM_DELIMITED' => 'Archivo con Delimitador Personalizado',
  'LBL_CUSTOM_DELIMITER' => 'Delimitador Personalizado:',
  'LBL_CUSTOM_TAB' => 'Archivo Personalizado Delimitado por Tabuladores',
  'LBL_DONT_MAP' => '-- No asocie este campo --',
  'LBL_STEP_1_TITLE' => 'Paso 1: Seleccione el origen',
  'LBL_WHAT_IS' => '¿Cuál es el origen de datos?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Mis Orígenes Guardados:',
  'LBL_PUBLISH' => 'publicar',
  'LBL_DELETE' => 'eliminar',
  'LBL_PUBLISHED_SOURCES' => 'Orígenes Publicados:',
  'LBL_UNPUBLISH' => 'despublicar',
  'LBL_NEXT' => 'Siguiente >',
  'LBL_BACK' => '< Anterior',
  'LBL_STEP_2_TITLE' => 'Paso 2: Subida de archivo exportado',
  'LBL_HAS_HEADER' => 'Tiene cabecera:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOTES' => 'Notas:',
  'LBL_NOW_CHOOSE' => 'Ahora elija el archivo a importar:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 y 2000 pueden exportar datos en el formato <b>Valores Separados por Coma (CSV)</b>, que puede ser utilizado para importar datos en el sistema. Para exportar sus datos desde Outlook, siga los siguientes pasos:',
  'LBL_OUTLOOK_NUM_1' => 'Inicie <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'Seleccione el menú <b>Archivo</b>, y entonces la opción de menú <b>Importar y Exportar ...</b>',
  'LBL_OUTLOOK_NUM_3' => 'Seleccione <b>Exportar a un archivo</b> y haga clic en Siguiente',
  'LBL_OUTLOOK_NUM_4' => 'Seleccione <b>Valores Separados por Coma (Windows)</b> y haga clic en <b>Siguiente</b>.<br>  Nota: Es posible que se le solicite la instalación del componente de exportación',
  'LBL_OUTLOOK_NUM_5' => 'Seleccione la carpeta <b>Contactos</b> y haga clic en <b>Siguiente</b>. Puede seleccionar distintas carpetas de contactos si sus contactos están almacenados en distintas carpetas',
  'LBL_OUTLOOK_NUM_6' => 'Escoja un nombre de archivo y haga clic en <b>Siguiente</b>',
  'LBL_OUTLOOK_NUM_7' => 'Haga clic en <b>Finalizar</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! puede exportar datos en el formato <b>Valores Separados por Coma (CSV)</b>, que puede ser utilizado para importar datos en el sistema. Para exportar sus datos desde Act!, siga los siguientes pasos:',
  'LBL_ACT_NUM_1' => 'Lance <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'Seleccione el menú <b>Archivo</b>, la opción de menú <b>Intercambio de Datos</b>, y entonces la opción de menú <b>Exportar...</b>',
  'LBL_ACT_NUM_3' => 'Seleccione el tipo de archivo <b>Texto-Delimitado</b>',
  'LBL_ACT_NUM_4' => 'Elija un nombre de archivo y una localización para los datos exportados y haga clic en <b>Siguiente</b>',
  'LBL_ACT_NUM_5' => 'Seleccione <b>Sólo registros de contactos</b>',
  'LBL_ACT_NUM_6' => 'Haga clic en el botón <b>Opciones...</b>',
  'LBL_ACT_NUM_7' => 'Seleccione <b>Coma</b> como el carácter separador de campos',
  'LBL_ACT_NUM_8' => 'Marque el cuadro de selección <b>Sí, exportar nombres de campos</b> y haga clic en <b>Aceptar</b>',
  'LBL_ACT_NUM_9' => 'Haga clic en <b>Siguient</b>',
  'LBL_ACT_NUM_10' => 'Seleccione <b>Todos los Registros</b> y haga clic en <b>Finalizar</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com puede exportar datos en el formato <b>Valores Separados por Coma</b> que puede ser utilizado para importar datos en el sistema. Para exportar sus datos desde Salesforce.com, siga los siguientes pasos:',
  'LBL_SF_NUM_1' => 'Abra su navegador, vaya a http://www.salesforce.com, e inicie su sesión con su email y contraseña',
  'LBL_SF_NUM_2' => 'Haga clic en la pestaña <b>Reports</b> del menú superior',
  'LBL_SF_NUM_3' => '<b>Para exportar cuentas:</b> Haga clic en el enlace <b>Active Accounts</b><br><b>Para exportar contactos:</b> Haga clic en el enlace <b>Mailing List</b>',
  'LBL_SF_NUM_4' => 'En <b>Step 1: Select your report type</b>, seleccione <b>Tabular Report</b> y haga clic en <b>Next</b>',
  'LBL_SF_NUM_5' => 'En <b>Step 2: Select the report columns</b>, seleccione las columnas que desee exportar y haga clic en <b>Next</b>',
  'LBL_SF_NUM_6' => 'En <b>Step 3: Select the information to summarize</b>, simplemente haga clic en <b>Next</b>',
  'LBL_SF_NUM_7' => 'En <b>Step 4: Order the report columns</b>, simplemente haga clic en <b>Next</b>',
  'LBL_SF_NUM_8' => 'En <b>Step 5: Select your report criteria</b>, bajo <b>Start Date</b>, seleccione una fecha suficientemente pasada como para incluir todas sus cuentas. También puede exportar un subconjunto de cuentas utilizando criterios más avanzados. Cuando haya terminado, haga clic en <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'Se generará un informe, y la página debería mostrar <b>Report Generation Status: Complete.</b> Ahora haga clic en <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => 'En <b>Export Report:</b>, para <b>Export File Format:</b>, seleccione <b>Comma Delimited .csv</b>. Haga clic en <b>Export</b>.',
  'LBL_SF_NUM_11' => 'Aparecerá un cuadro de diálogo para que guarde el archivo exportado en su ordenador.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Muchas aplicaciones le permiten exportar datos en el formato <b>Archivo de texto separado por comas (.csv)</b>. Habitualmente, la mayoría de aplicaciones siguen estos pasos genéricos:',
  'LBL_CUSTOM_NUM_1' => 'Lance la aplicación y Abra el archivo de datos',
  'LBL_CUSTOM_NUM_2' => 'Seleccione la opción de menú <b>Guardar como...</b> o <b>Exportar...</b>',
  'LBL_CUSTOM_NUM_3' => 'Guarde el archivo en el formato <b>CSV</b> o <b>Valores Separados por Comas</b>',
  'LBL_IMPORT_TAB_TITLE' => 'Muchas aplicaciones le permiten exportar datos en el formato <b>Archivo de texto separado por tabuladores (.tsv o .tab)</b>. Habitualmente, la mayoría de aplicaciones siguen estos pasos genéricos:',
  'LBL_TAB_NUM_1' => 'Lance la aplicación y Abra el archivo de datos',
  'LBL_TAB_NUM_2' => 'Seleccione la opción de menú <b>Guardar como...</b> o <b>Exportar...</b>',
  'LBL_TAB_NUM_3' => 'Guarde el archivo en el formato <b>TSV</b> o <b>Valores Separados por Tabuladores</b>',
  'LBL_STEP_3_TITLE' => 'Paso 3: Confirme los Campos e Importe',
  'LBL_SELECT_FIELDS_TO_MAP' => 'En la siguente lista, seleccione los campos de su archivo de importación que deban de ser importados en cada campo del sistema. Cuando termine, haga clic en <b>Importar Ahora</b>:',
  'LBL_DATABASE_FIELD' => 'Campo de Base de Datos',
  'LBL_HEADER_ROW' => 'Fila de Cabecera',
  'LBL_ROW' => 'Fila',
  'LBL_SAVE_AS_CUSTOM' => 'Guardar como Asociación Personalizada:',
  'LBL_CONTACTS_NOTE_1' => 'Debe asociar o Apellido o Nombre Completo.',
  'LBL_CONTACTS_NOTE_2' => 'Si asocia Nombre Completo, Nombre y Apellido serán ignorados.',
  'LBL_CONTACTS_NOTE_3' => 'Si asocia Nombre Completo, los datos en Nombre Completo se dividirán en Nombre y Apellido cuando se inserten en la base de datos.',
  'LBL_CONTACTS_NOTE_4' => 'Los campos que terminan en Calle Dirección 2 y Calle Dirección 3 se concatenarán en el campo Dirección Principal cuando se inserten en la base de datos.',
  'LBL_ACCOUNTS_NOTE_1' => 'Debe de asociarse Nombre de Cuenta.',
  'LBL_ACCOUNTS_NOTE_2' => 'Los campos que terminan en Calle Dirección 2 y Calle Dirección 3 se concatenarán en el campo Dirección Principal cuando se inserten en la base de datos.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Nombre de Oportunidad, Nombre de Cuenta, Fecha de Cierre, y Estado de Venta son campos requeridos.',
  'LBL_IMPORT_NOW' => 'Importar Ahora',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'No puede abrirse el archivo de importación para lectura',
  'LBL_NOT_SAME_NUMBER' => 'No hay el mismo número de campos en cada línea de su archivo de importación',
  'LBL_NO_LINES' => 'No hay líneas en su archivo de importación',
  'LBL_FILE_ALREADY_BEEN_OR' => 'El archivo de importación no existe o ya ha sido procesado',
  'LBL_SUCCESS' => 'Éxito:',
  'LBL_SUCCESSFULLY' => 'Importado con Éxito',
  'LBL_LAST_IMPORT_UNDONE' => 'Su última importación a sido deshecha',
  'LBL_NO_IMPORT_TO_UNDO' => 'No hay importación que deshacer.',
  'LBL_FAIL' => 'Fallo:',
  'LBL_RECORDS_SKIPPED' => 'registros saltados',
  'LBL_IDS_EXISTED_OR_LONGER' => 'id\'s que o bien existían o tenían más de 36 caracteres',
  'LBL_RESULTS' => 'Resultados',
  'LBL_IMPORT_MORE' => 'Importar Más',
  'LBL_FINISHED' => 'Finalizado',
  'LBL_UNDO_LAST_IMPORT' => 'Deshacer Última Importación',
  'LBL_LAST_IMPORTED' => 'Última Importación',
  'ERR_MULTIPLE_PARENTS' => 'Sólo puede haber definido un ID padre',
  'LBL_DUPLICATES' => 'Se han Encontrado Duplicados',
  'LBL_DUPLICATE_LIST' => 'Descargar Lista de Duplicados',
  'LBL_UNIQUE_INDEX' => 'Elija el Índice para comparación de duplicados',
  'LBL_VERIFY_DUPS' => 'Verificar entradas duplicadas contra los índices seleccionados',
  'LBL_INDEX_USED' => 'Índices usados',
  'LBL_INDEX_NOT_USED' => 'Índices no usados',
  'LBL_IMPORT_MODULE_ERROR_NO_MOVE' => 'El archivo no ha sido subido con éxito.  Compruebe los permisos de ficheros en el directorio de caché de su instalación de Sugar.',
  );


?>