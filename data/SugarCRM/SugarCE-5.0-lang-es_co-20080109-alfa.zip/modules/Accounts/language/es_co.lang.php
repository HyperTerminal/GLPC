<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Cuentas',
  'LBL_MODULE_TITLE' => 'Cuentas: Inicio',
  'LBL_HOMEPAGE_TITLE' => 'Mis Cuentas',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Cuentas',
  'LBL_LIST_FORM_TITLE' => 'Lista de Cuentas',
  'LBL_VIEW_FORM_TITLE' => 'Vista de Cuenta',  
  'LBL_NEW_FORM_TITLE' => 'Nueva Cuenta',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organizaciones Miembro',
  'LBL_BUG_FORM_TITLE' => 'Cuentas',
  'LBL_LIST_ACCOUNT_NAME' => 'Nombre',
  'LBL_LIST_CITY' => 'Ciudad',
  'LBL_LIST_WEBSITE' => 'Sitio Web',
  'LBL_LIST_STATE' => 'Estado',
  'LBL_LIST_PHONE' => 'Teléfono',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Contacto',
  'LBL_BILLING_ADDRESS_STREET_2' => 'Calle de dirección de cobro 2',
  'LBL_BILLING_ADDRESS_STREET_3' => 'Calle de dirección de cobro 3',
  'LBL_BILLING_ADDRESS_STREET_4' => 'Calle de dirección de cobro 4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Calle de dirección de envío 2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Calle de dirección de envío 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Calle de dirección de envío 4',
  'LBL_PARENT_ACCOUNT_ID' => 'ID Cuenta Padre',
  'LBL_CAMPAIGN_ID' => 'ID Campaña',
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
  'LBL_ACCOUNT_INFORMATION' => 'Información de la Cuenta',
  'LBL_ACCOUNT' => 'Cuenta:',
  'LBL_ACCOUNT_NAME' => 'Nombre:',
  'LBL_PHONE' => 'Teléfono:',
  'LBL_PHONE_ALT' => 'Teléfono alternativo:',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'LBL_WEBSITE' => 'Web:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Sigla bursátil:',
//END DON'T CONVERT
  'LBL_OTHER_PHONE' => 'Tel. alternativo:',
  'LBL_ANY_PHONE' => 'Cualquier teléfono:',
  'LBL_MEMBER_OF' => 'Miembro de:',
  'LBL_PHONE_OFFICE' => 'Teléfono oficina:',
  'LBL_PHONE_FAX' => 'Fax oficina:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Empleados:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email alternativo:',
  'LBL_ANY_EMAIL' => 'Cualquier email:',
  'LBL_OWNERSHIP' => 'Propietario:',
  'LBL_RATING' => 'Rating:',
  'LBL_INDUSTRY' => 'Industria:',
  'LBL_SIC_CODE' => 'Código SIC:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Ingresos anuales:',
  'LBL_ADDRESS_INFORMATION' => 'Direcciones',
  'LBL_BILLING_ADDRESS' => 'Dirección de cobro:',
  'LBL_BILLING_ADDRESS_STREET' => 'Calle de dirección de cobro:',
  'LBL_BILLING_ADDRESS_CITY' => 'Ciudad de dirección de cobro:',
  'LBL_BILLING_ADDRESS_STATE' => 'Estado/provincia de dirección de cobro:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'CP de dirección de cobro:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'País de dirección de cobro:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Calle de dirección de envío:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Ciudad de dirección de envío:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Estado/provincia de dirección de envío:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'CP de dirección de envío:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'País de dirección de envío:',
  'LBL_SHIPPING_ADDRESS' => 'Dirección de envío:',
  'LBL_DATE_MODIFIED' => 'Modificado:',
  'LBL_DATE_ENTERED' => 'Creado:',
  'LBL_ANY_ADDRESS' => 'Cualquier dirección:',
  'LBL_CITY' => 'Ciudad:',
  'LBL_STATE' => 'Estado/Provincia:',
  'LBL_POSTAL_CODE' => 'Código postal:',
  'LBL_COUNTRY' => 'País:',
  'LBL_PUSH_CONTACTS_BUTTON_TITLE' => 'Copiar...',
  'LBL_PUSH_CONTACTS_BUTTON_LABEL' => 'Copiar a Contactos',
  'LBL_DESCRIPTION_INFORMATION' => 'Información adicional',
  'LBL_DESCRIPTION' => 'Descripción:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copiar dirección de cobro a dirección de envío',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar dirección de envío a dirección de cobro',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => '¿Está seguro de que desea eliminar este registro como organización miembro?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => '¿Está seguro de que desea eliminar este registro?',
  'LBL_DUPLICATE' => 'Posible cuenta duplicada',
  'MSG_SHOW_DUPLICATES' => 'La creación de esta cuenta puede crear un duplicado. Puede hacer clic en Guardar para continuar con la creación de esta nueva cuenta con los datos previamente introducidos o puede hacer clic en Cancelar.',
  'MSG_DUPLICATE' => 'La creación de esta cuenta puede producir una cuenta duplicada. Puede elegir una cuenta existente de la lista inferior o hacer clic en Guardar para continuar la creación de una nueva cuenta con los datos introducidos previamente.',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_ACCOUNT_REPORTS' => 'Informes de Cuentas',
  'LNK_ACCOUNT_LIST' => 'Cuentas',
  'LBL_INVITEE' => 'Contactos',
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'NTC_DELETE_CONFIRMATION' => '¿Está seguro de que desea eliminar este registro?',
  'LBL_SAVE_ACCOUNT' => 'Guardar Cuenta',
  'ACCOUNT_REMOVE_PROJECT_CONFIRM' => '¿Está seguro de que desea quitar esta cuenta de este proyecto?',
  'LBL_USERS_ASSIGNED_LINK' => 'Usuarios Asignados',
  'LBL_USERS_MODIFIED_LINK' => 'Usuarios Modificados',
  'LBL_USERS_CREATED_LINK' => 'Creado por Usuarios',
  'LBL_TEAMS_LINK' => 'Equipos',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Cuentas',
  'LBL_PRODUCTS_TITLE' => 'Productos',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historial',
  'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Organizaciones Miembro',
  'LBL_NAME' => 'Nombre:',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
  'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Oportunidades',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Candidatos',
  'LBL_CASES_SUBPANEL_TITLE' => 'Casos',
  'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Productos',
  'LBL_QUOTES_SUBPANEL_TITLE' => 'Presupuestos',
  'LBL_CONTRACTS'=>'Contratos',	
  'LBL_CONTRACTS_SUBPANEL_TITLE'=>'Contratos',
  'LBL_BUGS_SUBPANEL_TITLE' => 'Incidencias',
  'LBL_PROJECTS_SUBPANEL_TITLE' => 'Proyectos',
 'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Are you sure you want to remove this account from this project?',
 'LBL_USERS_ASSIGNED_LINK'=>'Usuarios Asignados',
 'LBL_USERS_MODIFIED_LINK'=>'Usuarios Modificados',
 'LBL_USERS_CREATED_LINK'=>'Usuarios Creado Por', // REV.
 'LBL_TEAMS_LINK'=>'Equipos',
 'LBL_DEFAULT_SUBPANEL_TITLE' => 'Cuentas',
 'LBL_PRODUCTS_TITLE'=>'Productos',
 'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Actividades',
 'LBL_HISTORY_SUBPANEL_TITLE'=>'Historial',
 'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'Organizaciones Miembro',
 'LBL_NAME'=>'Nombre:',
    
 'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
 'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Oportunidades',
 'LBL_LEADS_SUBPANEL_TITLE' => 'Candidatos',
 'LBL_CASES_SUBPANEL_TITLE' => 'Casos',

 'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Productos',
 'LBL_QUOTES_SUBPANEL_TITLE' => 'Presupuestos',
 'LBL_CONTRACTS'=>'Contratos',	
 'LBL_CONTRACTS_SUBPANEL_TITLE'=>'Contratos',

 'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Organizaciones Miembro',
 'LBL_BUGS_SUBPANEL_TITLE' => 'Incidencias',
 'LBL_PROJECTS_SUBPANEL_TITLE' => 'Proyectos',
 'LBL_ASSIGNED_TO_NAME' => 'Usuario Asignado:',

 // Dashlet Categories
 'LBL_DEFAULT' => 'Vistas',
 'LBL_CHARTS'  => 'Gráficos',
 'LBL_UTILS'   => 'Utilidades',
 'LBL_MISC'    => 'Varios',
);


?>