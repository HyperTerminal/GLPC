<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Combinación de Registros',
  'LBL_MODULE_TITLE' => 'Combinación de Registros: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Combinaciones',
  'LBL_LIST_FORM_TITLE' => 'Lista de Combinaciones',

  'LBL_LBL_MERGRE_RECORDS_STEP_1' => 'Paso 1: Búsqueda de Registros con los que Combinar',
  'LBL_AVAIL_FIELDS' => 'Campos Disponibles',
  'LBL_SELECTED_FIELDS' => 'Campos Seleccionados',
  'LBL_MERGE_RECORDS_WITH' => 'Combinar Registros Con',
  'LBL_MERGE_VALUE_OVER' => 'Combinar valores sobre',

  'LBL_NEXT_STEP_TITLE' => 'Pasar a Siguiente Paso[Ctrl+N]',
  'LBL_NEXT_STEP_BUTTON_KEY' => 'N',
  'LBL_NEXT_STEP_BUTTON_LABEL' => 'Siguiente Paso >',

  'LBL_PERFORM_MERGE_BUTTON_TITLE' => 'Realizar Combinación[Ctrl+P]',
  'LBL_PERFORM_MERGE_BUTTON_KEY' => 'P',
  'LBL_PERFORM_MERGE_BUTTON_LABEL' => 'Realizar Combinación',

  'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE' => 'Guardar Combinación[Ctrl+S]',
  'LBL_SAVE_MERGED_RECORD_BUTTON_KEY' => 'S',
  'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL' => 'Guardar Combinación',

  'LBL_STEP2_FORM_TITLE' => 'Registros Encontrados con los que Combinar:',
  'LBL_SELECT_ERROR'=>'Debe realizar una selección antes de continuar.',
  'LBL_SELECT_PRIMARY'=>'Seleccione el registro principal para la combinación.',
  'LBL_CHANGE_PARENT'=>'Establecer como principal',
  'LBL_REMOVE_FROM_MERGE'=>'Quitar',
  'LBL_DIFF_COL_VALUES'=>'Columnas cuyo valor en la fila principal difiere del valor en las filas de combinación:',
  'LBL_SAME_COL_VALUES'=>'Columnas cuyo valor es similar en todas las filas:',
  'ERR_EXCEEDS_MAX'=>'Sólo le está permitido combinar un máximo de 5 registros. Los registros que excedan este límite serán ignorados.',
  'LBL_DELETE_MESSAGE'=>'Esta acción eliminará los siguientes registros:',
  'LBL_PROCEED'=>'¿Continuar?',
);


?>
