<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'RSS',
  'LBL_MODULE_ID' => 'Fuentes RSS',
  'LBL_MODULE_TITLE' => 'RSS: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'RSS Búsqueda de Fuentes de Noticias',
  'LBL_LIST_FORM_TITLE' => 'RSS Lista de Fuentes de Noticias',
  'LBL_MY_LIST_FORM_TITLE' => 'Mis Fuentes de Noticias RSS',
  'LBL_NEW_FORM_TITLE' => 'Nueva Fuente de Noticias RSS',
  'NTC_DELETE_CONFIRMATION' => '¿Está seguro de que desea eliminar este registro?',
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro para eliminar esta fuente.',
  'LNK_NEW_FEED' => 'Nueva Fuente de Noticias RSS',
  'LNK_FEED_LIST' => 'Todas las Fuentes de Noticias RSS',
  'LNK_MY_FEED_LIST' => 'Mis Fuentes de Noticias RSS',
  'LBL_TITLE' => 'Título',
  'LBL_RSS_URL' => 'URL RSS',
  'LBL_ONLY_MY' => 'Solo mis favoritos',
  'LBL_VISIT_WEBSITE' => 'visitar sitio web',
  'LBL_LAST_UPDATED' => 'Actualizado',
  'LBL_DELETE_FAVORITES' =>'Quitar de Favoritos',
  'LBL_DELETE_FAV_BUTTON_TITLE' =>'Quitar de Favoritos [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' =>'Quitar de Favoritos',
  'LBL_ADD_FAV_BUTTON_TITLE' =>'Añadir a favoritos [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' =>'[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' =>'Añadir a favoritos',
  'LBL_MOVE_UP' =>'Mover Arriba',
  'LBL_MOVE_DOWN' => 'Mover Abajo',
  'LBL_FEED_NOT_AVAILABLE'=>'Fuente no disponible',
  'LBL_REFRESH_CACHE'=>'Haga clic aquí para actualizar la caché',
  'LBL_TILE'=>'Título',
  'LBL_URL'=>'URL',
  'LBL_DESCRIPTION'=>'Descripción',
);


?>
