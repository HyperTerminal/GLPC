<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
	'LBL_ADD_ANOTHER_FILE'		=> 'Agregar Otro Archivo',
	'LBL_ADD_DOCUMENT'			=> 'Agregar un Documento Sugar',
	'LBL_INSERT_URL_REF'		=> 'Insertar Referencia a URL',
	'LBL_INSERT_TRACKER_URL'	=> 'Insertar URL de Seguimiento:',
	'LBL_TEAM' => 'Equipo:',
	'LBL_TEAMS_LINK' => 'Equipo',
	'LNK_CHECK_MY_INBOX' => 'Comprobar mi correo',
	'LNK_MY_ARCHIVED_LIST' => 'Mis Archivos',
	'LBL_DEFAULT_LINK_TEXT' => 'Texto de enlace por defecto',	
  'LBL_MODULE_NAME' => 'Plantillas de Email',
  'LBL_MODULE_TITLE' => 'Plantillas de Email: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Plantillas de Email',
  'LBL_LIST_FORM_TITLE' => 'Lista de Plantillas de Email',
  'LBL_NEW_FORM_TITLE' => 'Crear Plantilla de Email',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_LIST_DESCRIPTION' => 'Descripción',
  'LBL_LIST_DATE_MODIFIED' => 'Última Modificación',
  'LBL_NAME' => 'Nombre:',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_CLOSE' => 'Cerrado:',
  'LBL_RELATED_TO' => 'Relativo a:',
  'LBL_BODY' => 'Cuerpo:',
  'LBL_PUBLISH' => 'Publicación:',
  'LBL_COLON' => ':',
  'LNK_NEW_EMAIL_TEMPLATE' => 'Crear Plantilla de Email',
  'LNK_EMAIL_TEMPLATE_LIST' => 'Plantillas de Email',
  'LNK_IMPORT_NOTES' => 'Importar Notas',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LNK_CHECK_EMAIL' => 'Comprobar Email',
  'LNK_NEW_SEND_EMAIL' => 'Redactar Email',
  'LNK_ARCHIVED_EMAIL_LIST' => 'Emails Archivados',
  'LNK_SENT_EMAIL_LIST' => 'Emails Enviados',
  'LNK_NEW_EMAIL' => 'Archivar Email',
  'LBL_INSERT_VARIABLE' => 'Insertar Variable:',
  'LBL_INSERT' => 'Insertar',
  'LNK_DRAFTS_EMAIL_LIST' => 'Borrador',
  'LNK_ALL_EMAIL_LIST' => 'Todos los Emails',
  'LNK_NEW_ARCHIVE_EMAIL' => 'Crear Email Archivado',
  'LBL_CONTACT_AND_OTHERS' => 'Contacto/Candidato/Prospecto',
  'LBL_HTML_BODY' => 'Cuerpo HTML',
  'LBL_TEXT_BODY' => 'Cuerpo de Texto',
  'LBL_EDIT_ALT_TEXT' => 'Editar Texto Plano',
  'LBL_SHOW_ALT_TEXT' => 'Mostrar Texto Plano',
  'LBL_ATTACHMENTS' => 'Adjuntos',
  'LBL_ADD_FILE' => 'Agregar un archivo',
  'LBL_EMAIL_ATTACHMENT' => 'Adjunto de Email', /* HACER: Revisar, puede ser "Enviar Adjunto" */
  'LNK_MY_INBOX' => 'Bandeja de Entrada',
  'LNK_GROUP_INBOX' => 'Bandeja de Entrada Compartida',
  'LNK_MY_DRAFTS' => 'Borradores',
  'LBL_NEW' => 'Nuevo',
  'LBL_MODULE_NAME_WORKFLOW' => 'Plantillas de Correo para Workflow',
  'LBL_LIST_BASE_MODULE' => 'Módulo Base:',
  'LBL_TEXT_ONLY' => 'Sólo Texto',
  'LBL_SEND_AS_TEXT' => 'Enviar Sólo Texto',
  'LBL_ACCOUNT' => 'Cuenta',
);


	// for Inbox
?>