<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
	'LBL_ID'=>'Id',
	'LBL_TRACKER_KEY'=>'Clave de Seguimiento',
	'LBL_TRACKER_URL'=>'URL de Seguimiento',
	'LBL_TRACKER_NAME'=>'Nombre de Seguimiento',
	'LBL_CAMPAIGN_ID'=>'Id Campaña',
	'LBL_DATE_ENTERED'=>'Fecha Creación',
	'LBL_DATE_MODIFIED'=>'Fecha Modificación',
	'LBL_MODIFIED_USER_ID'=>'Modificado por',
	'LBL_CREATED_BY'=>'Creado por',
	'LBL_DELETED'=>'Eliminado',
	'LBL_CAMPAIGN'=>'Campaña',
	'LBL_OPTOUT'=>'Opción de no ir adelante',
	
	'LBL_MODULE_NAME'=>'Seguimientos de Campaña',
	'LBL_EDIT_CAMPAIGN_NAME'=>'Nombre de Campaña:',
	'LBL_EDIT_TRACKER_NAME'=>'Nombre de Seguimiento:',
	'LBL_EDIT_TRACKER_URL'=>'URL de Seguimiento:',
	
	'LBL_SUBPANEL_TRACKER_NAME'=>'Nombre',
	'LBL_SUBPANEL_TRACKER_URL'=>'URL',
	'LBL_SUBPANEL_TRACKER_KEY'=>'Clave',
	'LBL_EDIT_MESSAGE_URL'=>'URL para Mensaje de Campaña:',
	'LBL_EDIT_TRACKER_KEY'=>'Clave de Seguimiento:',
	'LBL_EDIT_OPT_OUT'=>'¿Enlace para no ir adelante?',
	'LNK_CAMPAIGN_LIST'=>'Campañas',
);

?>
