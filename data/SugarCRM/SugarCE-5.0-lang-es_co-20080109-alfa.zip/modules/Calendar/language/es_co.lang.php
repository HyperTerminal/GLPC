<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'=>'Calendario',
  'LBL_MODULE_TITLE'=>'Calendario',
  'LNK_NEW_CALL' => 'Programar Llamada',
  'LNK_NEW_MEETING' => 'Programar Reunión',
  'LNK_NEW_APPOINTMENT' => 'Crear Cita',
  'LNK_NEW_TASK' => 'Crear Tarea',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_MONTH' => 'Mes',
  'LBL_DAY' => 'Día',
  'LBL_YEAR' => 'Año',
  'LBL_WEEK' => 'Semana',
  'LBL_PREVIOUS_MONTH' => 'Mes Anterior',
  'LBL_PREVIOUS_DAY' => 'Día Anterior',
  'LBL_PREVIOUS_YEAR' => 'Año Anterior',
  'LBL_PREVIOUS_WEEK' => 'Semana Anterior',
  'LBL_NEXT_MONTH' => 'Mes Siguiente',
  'LBL_NEXT_DAY' => 'Día Siguiente',
  'LBL_NEXT_YEAR' => 'Año Siguiente',
  'LBL_NEXT_WEEK' => 'Semana Siguiente',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Planificado',
  'LBL_BUSY' => 'Ocupado',
  'LBL_CONFLICT' => 'Conflicto',
  'LBL_USER_CALENDARS' => 'Calendarios de Usuario',
  'LBL_SHARED' => 'Compartido',
  'LBL_PREVIOUS_SHARED' => 'Anterior',
  'LBL_NEXT_SHARED' => 'Siguiente',
  'LBL_SHARED_CAL_TITLE' => 'Calendario Compartido',
  'LBL_USERS' => 'Usuario',
  'LBL_REFRESH' => 'Actualizar',
  'LBL_EDIT' => 'Editar',
  'LBL_SELECT_USERS' => 'Seleccione usuarios para la visualización de calendario',
  'LBL_FILTER_BY_TEAM' => 'Filtrado de usuarios por equipo:',
);

$mod_list_strings = array(
  'dom_cal_weekdays' => 
  array (
    0 => 'Do',
    1 => 'Lu',
    2 => 'Ma',
    3 => 'Mi',
    4 => 'Ju',
    5 => 'Vi',
    6 => 'Sa',
  ),
  'dom_cal_weekdays_long' => 
  array (
    0 => 'Domingo',
    1 => 'Lunes',
    2 => 'Martes',
    3 => 'Miércoles',
    4 => 'Jueves',
    5 => 'Viernes',
    6 => 'Sábado',
  ),
  'dom_cal_month' => 
  array (
    0 => '',
    1 => 'Ene',
    2 => 'Feb',
    3 => 'Mar',
    4 => 'Abr',
    5 => 'May',
    6 => 'Jun',
    7 => 'Jul',
    8 => 'Ago',
    9 => 'Sep',
    10 => 'Oct',
    11 => 'Nov',
    12 => 'Dic',
  ),
  'dom_cal_month_long' => 
  array (
    0 => '',
    1 => 'Enero',
    2 => 'Febrero',
    3 => 'Marzo',
    4 => 'Abril',
    5 => 'Mayo',
    6 => 'Junio',
    7 => 'Julio',
    8 => 'Agosto',
    9 => 'Septiembre',
    10 => 'Octubre',
    11 => 'Noviembre',
    12 => 'Diciembre',
  ),
);


?>