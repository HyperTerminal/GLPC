<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 * Contributor(s): Jose Alberto Gonzalez Rouillé, www.dimensionix.com spin.jag@gmail.com.
 ********************************************************************************/
$mod_strings = array(
'help'=>array(
	'package'=>array(
			'create'=>'Proporcione un <b>Nombre</b> Para el paquete.  El Nombre que introduzca debe ser alfanumérico y no contener espacios. (Ejemplo: HR_Gestion)<br/><br/> Usted puede proporcionar <b>Autor</b> y <b>Descripción</b> para el paquete. <br/><br/>Haga Click <b>Guardar</b> para crear el paquete.',
			'modify'=>'Usted puede modificar el <b>Nombre</b>, <b>Autor</b> y <b>Descripción</b> de el paquete, asi como ver y personalizar todos los módulos que contienen el paquete .<br><br>También puede <b>Publicar</b> y <b>Desplegar</b> el Paquete, asi como <b>Exportar</b> los cambios hechos en el paquete.',			
			'name'=>'Este es el <b>Nombre</b> del paquete actual. <br/><br/>El Nombre que introduzca debe ser alfanumérico y no contener espacios. (Ejemplo: HR_Gestion)',
			'author'=>'Este es el <b>Autor</b> Que se muestra durante la instalación como el nombre de la entidad que hizo el paquete. El autor pueder ser tanto una persona o una empresa.',
			'description'=>'Esta es la <b>Descripción</b> de el paquete que es mostrada durante la instalación.',
			'publishbtn'=>'Haga Click en <b>Publicar</b> para guardar todos los datos itroducidos y crea un archivo .zip que es un version instalable del paquete.<br><br>Use <b>Module Loader</b> para subir el archivo .zip e instalar el paquete.',
			'deploybtn'=>'>Haga Click en <b>Desplegar</b> para guardar todos los datos introducidos e instalar el paquete, incluidos todos los modulos, en el caso actual.',
			'duplicatebtn'=>'Haga Click en <b>Duplicar</b> para copiar el contenido de el paquete en un nuevo paquete y mostrar el nuevo paquete. <br/><br/>para el nuevo paquete, un nuevo nombre se generara automaticamente agregando un numero al final del nombre del paquete usado para crearlo. Usted puede renombrar el nuevo paquete Ingresando un nuevo <b>Nombre</b> y cliqueando en <b>Guardar</b>.',			
			'exportbtn'=>'Haga Click en <b>Exportar</b> para crear un archivo .zip que contiene los cambios hechos en el paquete.<br><br>El archivo contiene código generado para el paquete de personalización, y no se trata de una versión instalable del paquete.<br><br>Use <b>Module Loader</b>para importar el archivo zip y hacer las personalizaciones disponibles para los paquetes nuevos.',
			'deletebtn'=>'Haga Click en <b>Borrar</b> Para suprimir este paquete y todos los archivos relacionados con este paquete.',
			'savebtn'=>'Haga Click en <b>Guardar</b> para guardar todos los datos relacionados con este paquete.',
			'existing_module'=>'Haga Click en el <b>nombre de un modulo</b> para editar y personalizar las propiedades de los campos, las relaciones y diseños asociados con el módulo.',
			'new_module'=>'Haga Click en <b>Nuevo Modulo</b> para crear un nuevo modulo para este paquete.',
			'key'=>'Estas 5-Letras, alfanumérica <b>Clave</b> Se utilizarán para prefijo de todos los directorios, nombres de clase y tablas de la base de datos de todos los módulos en el paquete actual.<br><br>La clave se utiliza para tratar de alcanzar un nombre de tabla singularidad.',
			'readme'=>'Usted Puede agregar un <b>Leame</b> de texto para este paquete.<br><br>El Readme estará disponible en el momento de la instalación.',
	),
	'main'=>array(
		
	
	),
	'module'=>array(
		// BEGIN SUGAR PRO ONLY
		'create'=>'Proporcione un <b>Nombre</b> para el módulo. la <b>Etiqueta</b> que nos proporcione aparecerán en la pestaña de navegación. <br/><br/>Elige para mostrar una pestaña de navegación para el modulo. marque  <b>Pestaña de Navegación</b>en el checkbox.<br/><br/>Compruebe el <b>Equipo de Seguridad</b> para tener un equipo de selección de campos dentro de el modulo de registros. <br/><br/>A continuación, seleccione el tipo de módulo que desea crear. <br/><br/>Seleccione un tipo de plantilla. Cada plantilla contiene un conjunto específico de campos, así como diseños predefinidos, para utilizar como base en el módulo. <br/><br/>Haga Click en <b>Guardar</b> Para crear el modulo.',
		// END SUGAR PRO ONLY
		// BEGIN SUGAR COM ONLY
		'create'=>'Proporcione un <b>Nombre</b> para el módulo. la <b>Etiqueta</b> que nos proporcione aparecerán en la pestaña de navegación. <br/><br/>Elige para mostrar una pestaña de navegación para el modulo. marque  <b>Pestaña de Navegación</b>en el checkbox.<br/><br/>A continuación, seleccione el tipo de módulo que desea crear. <br/><br/>Seleccione un tipo de plantilla. Cada plantilla contiene un conjunto específico de campos, así como diseños predefinidos, para utilizar como base en el módulo. <br/><br/>Haga Click en <b>Guardar</b> Para crear el modulo.',
		// END SUGAR COM ONLY		
		'modify'=>'Puede cambiar el módulo de propiedades o personalizar los <b>campos</b>, <b>Relaciones</b> y <b>Diseños</b> relacionados con el módulo.',
		'team_security'=>'Comprobación de el <b>Equipo de Seguridad</b> casilla activara un equipo de seguridad para este modulo.  <br/><br/>Si el equipo de seguridad esta activo, the Team selection field will appear within the records in the module ',
		'reportable'=>'Si selecciona esta casilla, este módulo permite tener generador de informes.',
		'assignable'=>'Si selecciona esta casilla, permitirá llevar un registro en este módulo para ser asignado a un usuario seleccionado.',
		'has_tab'=>'Si selecciona "pestaña de navegación" proporcionará una pestaña de navegación para el módulo.',
		'acl'=>'Si selecciona esta casilla, permitirá controles de acceso en este módulo, incluido el campo Nivel de Seguridad.',
		'studio'=>'Si selecciona esta casilla, permitirá a los administradores personalizar este módulo dentro de Studio.',
		'audit'=>'Si selecciona esta casilla, permitirá Auditoría para este módulo. Los cambios en ciertos campos se registran de manera que los administradores pueden revisar el historial de cambios.',
		'viewfieldsbtn'=>'Click <b>View Fields</b> to view the fields associated with the module and to create and edit custom fields.',
		'viewrelsbtn'=>'Haga clic en <b>Ver Campos</b> para ver los campos relacionados con el módulo y para crear y editar campos personalizados.',
		'viewlayoutsbtn'=>'Haga clic en <b>Ver Diseños</b> para ver los diseños para el módulo y para personalizar los campos arrglandolos dentro de el diseño.',
		'duplicatebtn'=>'Haga clic en <b>Duplicar</b> para copiar las propiedades del módulo en un nuevo módulo y para mostrar el nuevo módulo. <br/> <br/> Para el nuevo módulo, un nuevo nombre se generará automáticamente añadiendo un número al final del nombre del módulo utilizado para crear el nuevo. <br/><br/> Puede cambiar el nombre de el Modulo nuevo introduciendo un nuevo <b>Nombre</b> y hacer clic en <b>Guardar</b>.',
		'deletebtn'=>'Haga Click en <b>Eliminar</b> para eliminar este modulo.',
		'name'=>'Este es el <b>Nombre</b> de la actual módulo. <br/><br/> El nombre que introduzca debe ser alfanumérico y debe comenzar con una letra y no contener espacios. (Ejemplo: HR_Gestión)',
		'label'=>'Esta es la <b>Etiqueta</b> que aparecerá en la pestaña de navegación para el módulo. ',
		'savebtn'=>'Haga Click en <b>Guardar</b> para guardar toda la información relacionada con el modulo.',
		'type_basic'=>'el tipo de plantilla <b>básica</b> proporciona campos básicos, como el Nombre, Asignado a, el Equipo, Fecha de creación y Descripción de los campos.',
		'type_company'=>'el tipo de plantilla <b>Empresa</b> proporciona campos de   organizacion-específica, tales como Nombre de la empresa, la Industria y la dirección de facturación. <br/> <br/> Utilice esta plantilla para crear módulos que son similares a la norma de un módulo de Cuentas.',
		'type_issue'=>'El tipo de plantilla <b>Emisión</b> proporciona casos de campos especificos de error, tales como Número, estado, prioridad y descripción. <br/> <br/> Utilice esta plantilla para crear módulos que son similares a estandares para los modulos de casos de error.',
		'type_person'=>'El tipo de plantilla <b>Persona</b> ofrece los campos específicos de un individuo, como el Saludo, Título, Nombre, Dirección y Teléfono. <br/><br/> Utilice esta plantilla para crear módulos que son similares a los estandares de modulos para Contactos y clientes.',
		
	),
	'dropdowns'=>array(
		'default' => 'Todos los Menus desplegables de la aplicación, se listan aquí. <br> <br> Para realizar cambios para un menú desplegable, haga clic en el nombre del menú desplegable. <br><br> Realice los cambios en el <b>Editor de menus desplegables</b> en el formulario de la parte derecha del panel, y haga clic en <b>Guardar</b>. Realice los cambios que sean necesarios, y luego haga clic en "Guardar </b>. <br><br> Para crear un nuevo menú desplegable, haga clic en <b>Añadir menu desplegable </b>. Introduzca las propiedades de la lista desplegable situada formulario en el <b>Editor de menus desplegables</b> y haga clic en <b>Guardar</b>.'
	),
	'listViewEditor'=>array(
		'modify'	=> 'la columna <b>por defecto</b> contiene los campos que se muestran en una vista de lista por defecto. <br/><br/> la columna <b> Disponible</b> contiene los campos que el usuario puede elegir para crear Una lista personalizada. <br/><br/> La columna <b>Ocultos</b>contiene los campos que usted como administrador puede agregar por defecto o columnas disponibles para que los usuarios las vean.', 
		'savebtn'	=> 'Haga clic en <b>Guardar y Utilizar</b> para guardar todos los cambios que usted ha hecho y los hace activos dentro de el módulo.',
		'Hidden' 	=> 'Oculta campos que actualmente no estan disponibles para verlos por los usuarios en la lista de vistas.',
		'Available' => 'Activa campos que no se muestran por defecto, pero se pueden agregar a la lista de vistas para los usuarios.',
		'Default'	=> 'Por defecto se muestran los campos a los usuarios que no han creado lista personalizada.'
	),
	'searchViewEditor'=>array(
		'modify'	=> 'La columna contiene <b>por defecto</b> los campos que se mostrarán en la búsqueda. <br/><br/> La columna contiene campos <b>ocultos</b> disponibles para usted como un administrador para añadir a la vista.', 
		'savebtn'	=> 'Al hacer clic en <b>Guardar y Utilizar</b> para guardar todos los cambios y hacerlos activos',
		'Hidden' 	=> 'Los campos oculto son campos que no se muestra en la vista de búsqueda.',
		'Default'	=> 'Los campos por defecto se mostrarán en la vista de búsqueda.'
	),
	'layoutEditor'=>array(
		'default'	=> 'Realice los cambios en la capa mostrada puede arrastrar y soltar elementos  y campos entre las dos areas en esta pagina. <br/><br/> La columna de la izquierda, llamada <b>caja de Herramientas</b>, contiene herramientas útiles, elementos y campos para modificar el diseño. <br/><br/> El área a mano derecha, llamada <b>Diseño Actual</b> o <b>Vista previa del diseño</b>, contiene el modulo de diseño <br/><br/>Si el área de diseño es llamada <b>Diseño Actual</b> Entonces usted esta trabajando en una copia de el diseño que es actualmente mostrado en el modulo. <br/><br/>Si el área de diseño es llamada <b>Vista previa del diseño</b> Entonces usted esta trabajando en una copia creada anteriormente Haga click en <b>Guardar</b> Nota: Si otro usuario utiliza una copia diferente de el diseño, la que puede ver en esta área tal vez no coincida con la versión actual.', 
		'saveBtn'	=> 'Haga Click en <b>Guardar</b> para preservar los cambios que haga en el diseño. Si no despliega los cambios antes de salir de estudio, los cambios no se mostrarán en el módulo. Cuando vuelva a estudio para modificar el diseño, se muestra el diseño con los cambios preservados. el diseño no se mostrara en el mostrara en el modulo hasta que haga click en <b>Guardar y Utilizar</b>.',
		'publishBtn'=> 'Haga clic en <b>Guardar y Utilizar</b> para implementar el diseño. <br><br>después de implementar, el diseño sera inmediatamente mostrado en el módulo.',
		'toolbox'	=> 'La <b>Caja de Herramientas</b> contiene una variedad de herramientas útiles para la edición de diseños, incluyendo la Papelera, diseño adicional de elementos y el conjunto de campos disponibles. <br/><br/>Cualquiera de los elementos y de los campos se pueden arrastrar y soltar en el diseño, y cualquier diseño de los elementos y campos se pueden arrastrar y soltar en la papelera. <br/><br/>Arrastrando una nueva fila o  un nuevo panel de elementos a el diseño sera  agregado en el diseño donde este es quitado. <br/><br/>Un campo de relleno crea espacio en blanco en el diseño en que se haya colocado. <br/><br/> Arrastre y suelte cualquiera de los campos disponibles a un campo en un panel de intercambio de los dos.',
		'panels'	=> 'Esta área muestra como su diseño se publicara dentro de el modulo cuando esta se use.<br/><br/>Puede posicionar campos, columnas y paneles arrastrando y soltándolos en la posición deseada. <br/><br/>Quite elementos arrastrando y soltándolos en la  papelera de la caja de herramientas, o agregar nuevos elementos y campos arrastrando y soltando de la caja de herramientas en la posición deseada en el diseño.',
		'delete'	=> 'Arrastre y suelte cualquier elemento aqui para remover de el diseño',
	),
	'fieldsEditor'=>array(
		'default'	=> 'Todos los campos que estan disponibles para el modulo actual estan listados aqui. <br><br> Los campos estandar que incluye el modulo por defecto aparecen en el area <b>Por defecto</b>. <br><br> Los campos personalizados que fueron creados para el modulo aparecen en el area <b>Personalizados</b>.<br><br>Para Editar los campos, haga click en el <b>Nombre de el Campo</b>.  Realize los cambios con el formulario de <b>Propiedades</b> de el panel de la derecha, y haga click en <b>Guardar</b>. <br><br>Mientras visualiza las propiedades de los campos, puede crear rapidamente un nuevo campo con propiedades similares haga click en <b>Clone</b>.Realice los campos que sean necesarios, y luego haga click en <b>Guardar</b> <br><br>Para crear un campo nuevo, haga click en <b>Agregar Campo</b>. Intrusca las propiedades para el campo en el formulario de <b>Propiedades</b>, y haga click en <b>Guardar</b>. El Campo nuevo aparecerá  en el area <b>Personalizado</b>.<br><br> Para Cambiar las etiquetas de cualquiera de los campos, haga click en <b>Editar Etiqutas</b>.',
	),
	'exportcustom'=>array(
	    'exportHelp'=>'Exporte las personalizaciones hechas con estudio mediante la creancion de paquetes que pude cargar en otra instancia de Sugar atravez de el <b>Modulo de Carga</b>.<br><br>Primero, provea un <b>Nombre del paquete</b>. Puede Proveer información del <b>Autor</b> y <b>Descripción</b> también para el paquete.<br><br>Seleccione el modulo(s) que contiene las personalizaciones  que usted desea exportar. Solo los módulos que contienen personalizaciones aparecerán para su selección. <br><br>a Continuación, haga click en <b>Exportar</b> para crear un archivo .zip para el paquete que contiene las personalizaciones.',
	    'exportCustomBtn'=>'Haga click en <b>Exportar</b> para crear un archivo .zip contenedor de las personaliaciones de el paquete que puede exportar.',
	    'name'=>'Este es el <b>Nombre</b> de el paquete. Este nombre se mostrara durante la instalacion.',
	    'author'=>'Este es el <b>Autor</b>Que se muestra durante la instalación como el nombre de la entidad que creó el paquete. El autor puede ser tanto una persona o una empresa.',
	    'description'=>'Este es la <b>Descripción</b> de el paquete que se muestra durante la instalación.',
	),
	'studioWizard'=>array(
		'mainHelp' 	=> 'Bienvenido al area de <b>Herramientas para desarrolladores</b>. <br/><br/>Utilice las herramientas dentro de esta area de creación y gestión estándar y personalizacion de módulos y campos.',
		'studioBtn'	=> 'Utilice <b>Estudio</b> para personalizar los módulos instalados.',
		'mbBtn'		=> 'Utilice <b>Módulo Creador</b> para crear nuevos módulos.',
		'sugarPortalBtn' => 'Utilice <b>Editor del portal  Sugar</b> para administrar y personalizar el portal de Sugar.',
		'dropDownEditorBtn' => 'Utilice el <b>Editor desplegable </b> para añadir y editar desplegables globales para la aplicación .',
		'appBtn' 	=> 'El modo de aplicación es donde se puede personalizar diversas propiedades del programa, como el número de informes de TPS son mostrados en la página principal',
		'backBtn'	=> 'Regresa al paso anterior.',
		'studioHelp'=> 'En <b>Estudio</ b>, puede cambiar la forma en que se muestra la información, determinar lo que datos estan disponibles y crear campos de informacion personalizados para modulos <i>instalados</i>.',
		'moduleBtn'	=> 'Haga click para editar este modulo.',
		'moduleHelp'=> 'Seleccione el componente de un módulo que le gustaría editar.',
		'fieldsBtn'	=> 'Determinar qué información puede ser almacenada en el módulo para controlar los<b>Campos</b> en el módulo. <br/><br/>Puede editar y crear nuevos campos para almacenar información.',		
		'labelsBtn' => 'Editar las <b>Etiquetas</ b> que muestran los campos en el módulo.'	,
		'layoutsBtn'=> 'Editar los siguientes <b>Diseños</b> de el módulo : Editar Vista, vistar Detalles, listar vista y vista de busqueda.',
		'subpanelBtn'=> 'Determinar qué información es mostrada en los <b>Subpanels</b> para este módulo.',
		'layoutsHelp'=> 'Seleccione un <b>Diseño</b> para editar.',
		'subpanelHelp'=> 'Seleccione un <b>Subpanel</b> para editar.',
		'labelsHelp'=> 'Los nombre mostrados para las <b>Etiquetas</b> para todos los campos que estan disponibles en el modulo actual se muestran en la columna a mano derecha.<br><br> Edite el nombre haciendo click en el campo, introduzca un nuevo nombre haciendo click en <b>Guardar</b>.',
        'newPackage'=>'Haga Click en <b>Nuevo Paquete</b> para crear un nuevo paquete.',
        'exportBtn' => 'Haga Click en <b>Exportar Personalizaciones</b> para crear un paquete que contiene las personalizaciones realizadas en el Estudio de módulos específicos.',
        'mbHelp'    => '<b>Bienvenido al Módulo Builder</b>. <br/><br/> Use <b>Módulo Builder</b> para crear paquetes que contienen módulos personalizados basado en Estandares u objetos personalizados. <br/> <br/> Para empezar, haga clic en Nuevo Paquete <b> </ b> para crear un nuevo paquete, o seleccione un paquete para editar.',
	    'viewBtnEditView' => 'Modifica el diseño del modulo <b>Editar Vista</b>.',
	    'viewBtnDetailView' => 'Modifica el diseño del modulo <b>Detalles Vista</b>.',
	    'viewBtnListView' => 'Modifica el diseño del modulo <b>Listar Vista</b>.',
	    'searchBtn' => 'Modifica el diseño del modulo <b>Búsqueda</b>.',
		'viewBtnQuickCreate' =>  'Modifica el diseño del modulo <b>Creación Rápida</b>.',    
	    'searchHelp'=> 'Seleccione un <b>Diseño de Búsqueda</b> para editar.',
	    'BasicSearchBtn' => 'Modifique el formulario de <b>Búsqueda Básica</b> que aparece en la pestaña de búsqueda básica en el área para la búsqueda en el modulo .',
	    'AdvancedSearchBtn' => 'Modifique el formulario de <b>Búsqueda Avanzada</b> que aparece en la pestaña de búsqueda avanzada en el área para la búsqueda en el modulo.',
	    'portalHelp' => 'Administre y personalice el <b>Portal Sugar</b>.',
	    'SPUploadCSS' => 'Suba una <b>Hoja de estilos</b> para el Portal Sugar.',
	    'SPSync' => '<b>Sync</b> Personalizaciones para un instancia del el Portal Sugar.',
	    'Layouts' => 'Modifique los <b>Diseños</b> de los módulos para el Portal Sugar.',
	    'portalLayoutHelp' => 'Los módulos dentro de el Portal Sugar aparecen en esta área. Seleccione un módulo para editar el <b>Diseño</b>.',
		'relationshipsHelp' => 'Se puede relacionar este módulo a otros módulos en el mismo paquete o de los módulos ya instalados en la Aplicación.<br/><br/> Para crear una nueva relación, haga clic en <b>Añadir Relación</ b>. Las propiedades de la relación se muestran en el formulario en la parte derecha del panel. Utilice La lista desplegable <b>Relacionado a</b>  para seleccionar el módulo a los que se refieren el módulo actual. <br><br>Provea una <b>Etiqueta</ b> que aparecerá como título del sub-panel para el correspondiente módulo. <br><br>Las relaciones entre los módulos  se gestionarán a través de sub-paneles que aparecen debajo de la Vistas de detalle en los módulos.<br> <br> Para el sub-panel de el modulo relacionado, que podría estar en condiciones de seleccionar diferentes sub-panel de diseños, dependiendo de en qué módulo es seleccionado para la relación. <br/><br/>Haga clic en <b>Guardar </b> para crear una relación. Haga clic en <b>Eliminar</b> para borrar la relación de seleccionada. <br/><br/> Para editar una relación existente, haga clic en <b>Nombre de Relación</b>, y edite las propiedades dentro de el panel a mano derecha.',
		'editDropDownBtn' => 'Edita un Dropdown general',
		'addDropDownBtn' => 'Agrega un nuevo Dropdown general',
	),
	'portalSync'=>array(
	    'default' => 'Introduzca la <b>URL del Portal Sugar</b> de la instancia de el portal para actualizar, y haga click  en <b>Ir</b>.<br><br>Introduzca un nombre de usuario válido en Sugar y la contraseña, y luego haga click en <b>Empezar sincronización</b>. <br><br>Las Personalizaciones realizadas a los <b>diseños</b>de el Portal Sugar, junto con las <b>hojas de estilos</b> si uno se ha subido, se transferirán a  un instancia especificada de el portal.',
	),
	'portalStyle'=>array(
	    'default' => 'Desde aquí puede personalizar la vista del Portal Sugar.',
	),
), 

'assistantHelp'=>array(
	'package'=>array(
			//custom begin
			'nopackages'=>'Para empezar un proyecto, haga clic en <b>Nuevo Paquete</b> para crear un nuevo paquete de su módulo(s) personalizado. <br/><br/> Cada paquete puede contener uno o más módulos. <br/> <br/> Por ejemplo, puede ser que desea crear un paquete que contiene un módulo personalizado que se relaciona con el módulo de Cuentas. O bien, usted puede ser que desee crear un paquete que contiene varios de los nuevos módulos que trabajar juntos como un proyecto y que están relacionadas entre sí y con otros módulos existentes en la aplicación.',
			'somepackages'=>'Un <b>paquete</b> actúa como un contenedor de módulos personalizados, que son parte de un proyecto. El paquete puede contener uno o más <b>módulos personalizados</b>, que pueden estar relacionados entre sí o con otros módulos en la aplicación. <br/> <br/> Después de crear un paquete para su proyecto, usted puede crear Módulos de los paquetes de inmediato, o puede volver al Constructor de Módulos en otro momento para completar el proyecto. <br><br>Cuando el proyecto se completa, puede <b>Desplegar</b> para instalar el paquete de módulos personalizados dentro  de la aplicación.',
			'afterSave'=>'Su nuevo paquete debe contener por lo menos un módulo. Usted puede crear uno o más módulos personalizados para el paquete.<br/><br/>Haga clic en <b>Nuevo Módulo</b> para crear un módulo personalizado para este paquete.<br/><br/>Después de crear por lo menos un módulo, puede publicar o desplegar en el paquete para hacerlo disponible en su instancia y / o de otras instancias de usuarios. <br/><br/>Para desplegar el paquete en un paso dentro de su instancia de Sugar, haga click en <b>Desplegar</b>.<br><br>Haga click en <b>Publicar</b> para guardar el paquete como un archivo .zip. Después el archivo .Zip se guarda en su sistema, utilice el <b>Módulo de Carga</b> para Subir e instalar el paquete en su instancia de Sugar.<br/><br/> Puede distribuir el archivo a otros usuarios para cargar e instalar dentro de sus propias instancias de Sugar.',
			'create'=>'Un <b>paquete</b> actúa como un contenedor de módulos personalizados, que son parte de un proyecto. El paquete puede contener uno o más <b>módulos</b> personalizados , que pueden estar relacionados entre sí o con otros módulos en la aplicación. <br/><br/>Después de crear un paquete para su proyecto, usted puede crear Módulos de los paquetes de inmediato, o puede volver a la Constructor de modulos en otro momento para completar el proyecto.',
			),
	'main'=>array(
		'welcome'=>'Utilize  las <b>Herramientas de Desarrollo</b> para crear y manejar estándares y módulos personalizados y campos.<br/><br/>Para administrar los módulos de la aplicación, haga click en <b>Estudio</b>.<br/><br/>Para crear módulos personalizados, haga click en <b> Constructor de Modulos</b>.',
		'studioWelcome'=>'Todos los módulos instalados actualmente, incluyendo estándar y los objetos del módulo de carga, son personalizables dentro Estudio.'
	),
	'module'=>array(
		'somemodules'=>"Dado que el actual paquete contiene al menos un módulo, puede <b>Desplegar</b> los módulos en el paquete dentro de  su instancia de Sugar o <b>Publicar</b> el paquete que se instalará en la actual instancia de Sugar u otra Instancia utilizando el <b>Módulo de Carga</b>.<br/><br/>Para instalar el paquete directamente dentro de su instancia de Sugar, haga clic en <b>Desplegar</b>.<br><br>Para crear una archivo . zip de el paquete que puede ser cargado e instalado dentro de la instancia actual de azúcar y otros casos utilizando el <b>Módulo  de Carga</b>, haga clic en <b>Publicar</b>. <br/> <br/> Usted puede construir los módulos de este paquete en etapas, y publicar o desplegar cuando esté listo para hacerlo. <br/><br/>Después de la publicación o el despliegue de un paquete, puede hacer cambios en el conjunto de propiedades y personalizar los módulos más. Luego volverá a re-publicar o re-desplegar el paquete para aplicar los cambios." ,
		'editView'=> 'Aquí se pueden editar los campos ya existentes. Usted puede eliminar cualquiera de los campos ya existentes o añadir campos disponibles en el panel de la izquierda.',
		'create'=>'Cuando escoja el tipo de <b>Tipo</b> del módulo que desea crear, tenga en cuenta los tipos de campos que quiera que en el módulo. <br/><br/>Cada plantilla del módulo contiene una serie de campos relacionados con el tipo de módulo descrito por el título.<br/><br/> <b>Básicos</b> -Proporciona campos básicos que aparecen en Módulos estándar, tales como el Nombre, Asignado a, el Equipo, Fecha de creación y el campo Descripción. <br/><br/><b>Empresa</b> - Proporciona campos de una organización específica, tales como Nombre de la empresa, la Industria y   Dirección. Utilice esta plantilla para crear módulos que son similares a módulos estandar de contabilidad.<br/><br/><b>Persona</b> - Proporciona campos específicos de un individuo, como el Saludo, Título, Nombre, Dirección y Teléfono . Utilice esta plantilla para crear módulos que son similares a módulos estandar de contactos y clientes.<br/><br/><b>Número</b> - Proporciona caso de error-y campos específicos, tales como Número, estado, prioridad Y descripción. Utilice esta plantilla para crear modulos similares a los estandares de Casos y Bug Tracker. <br/><br/> Nota: Después de crear el módulo, puede editar las etiquetas de los campos proporcionado por la plantilla, así como Crear campos personalizados para agregar los diseños del módulo.',
		'afterSave'=>'Personalice el módulo para que se adapte a sus necesidades de edición y creación de campos, establezca  relaciones con otros módulos y la organización de los campos dentro de el diseño.<br/><br/>Para ver los campos de la plantilla y gestionar los campos personalizados en el módulo, haga clic en <b>Ver Campos</b>.<br/><br/>Para crear y manejar las relaciones entre el módulo y otros módulos, ya sean módulos existentes u otros módulos personalizados en el mismo paquete, haga clic en <b>Ver Relaciones</b>.<br/><br/>Para editar los diseños módulo, haga clic en <b>Ver Diseños</b>. Puede cambiar a Vista Detallada, Editar Vista y  Listar Vista de diseño para el modulo solo podrá para los módulos existentes en la aplicación dentro de estudio.<br/><br/>Para crear un módulo con las mismas propiedades del módulo actual, Haga clic en <b>Duplicar</b>. Puede personalizar aún más el módulo nuevo.',
		'viewfields'=>'Los campos en el módulo puede ser personalizado para satisfacer sus necesidades.<br/><br/>No puede eliminar campos estándar, pero puede quitarlos de los diseños apropiados dentro de los diseños de páginas.<br/><br/>Puede editar las etiquetas de los campos estándar. Las otras propiedades de los campos estándar no son editables. Sin embargo, usted puede crear rápidamente nuevos campos que tienen propiedades similares, haga clic en el nombre de un campo y, a continuación, haga clic en <b>Clone</b> en el formulario de <b>Propiedades</ b>. Introduzca las nuevas propiedades y, a continuación, haga clic en <b>Guardar</b>.<br/> <br/> Si usted es la personaliza un nuevo módulo, una vez que el módulo se ha instalado, no todas las propiedades de los campos puede ser editadas. Configure de todas las propiedades de los campos estándar y campos personalizados antes de publicar e instalar el paquete que contiene el módulo personalizado.',
		'viewrelationships'=>'Puede crear relaciones varios-a-varios entre el actual módulo y otros módulos en el paquete, y / o entre el actual módulo y los módulos ya instalados en la aplicación.<br><br>Para crear relaciones uno-a-varios y uno-a-uno, cree <b>Relacionar</b> y <b>Relacionar Flex</b>campos de los módulos.',
		'viewlayouts'=>'Puede controlar qué campos están disponibles para la captura de datos dentro de <b>Editar Vista</b>. También se puede controlar los datos  que se muestra dentro de <b>Ver Detalles</b>. Las vistas no tienen que coincidir.<br/><br/> La creación rápida de un formulario es mostrada cuando se hace clic en <b>Crear</ b>en un módulo subpanel. Por defecto, <b>Crear Rápido</ b> el formulario de el diseño es el mismo por defecto que el diseño de <b>Editar Vista</b>. Puede personalizar de forma rápida Crear de manera que contenga menos y / o diferentes campos de la Vista de Diseño.<br><br> Puede determinar el módulo de seguridad el usando la personalizacion de el diseño junto con <b>Gestión de Roles</b>.<br><br>',
		'existingModule' =>'Después de la creación y personalización de este módulo, puede crear módulos adicionales o regresar al paquete a <b>Publicar</b> o <b>Desplegar</b> el paquete.<br><br>Para crear módulos adicionales, haga clic en <b>Duplicar</b> para crear un módulo con las mismas propiedades que el actual módulo, o navegar de vuelta al paquete, y haga clic en <b>Nuevo Módulo</b>.<br><br>Si está listo a <b>Publicar</b> o <b>Desplegar</ b>, el paquete que contiene este módulo, navegar de vuelta al paquete para realizar estas funciones. Puede publicar y desplegar paquetes que contengan al menos un módulo.',
		'labels'=> 'Las etiquetas de los campos estandar  así como los campos personalizados se pueden cambiar. Cambiar etiquetas de un campo no afectará a los datos almacenados en los campos.',
	),
	'listViewEditor'=>array(
		'modify'	=> 'Hay tres columnas que aparecen a la izquierda. La Columna "por defecto" contiene los campos que se muestran en una vista de lista por defecto, La columna "Disponible" contiene los campos que el usuario puede elegir para crear una vista de una lista personalizada, y la columna "Oculto" contiene los campos disponibles para su uso Como administrador para añadir a las ya sea por defecto o columnas disponibles para su uso por los usuarios, pero se encuentra inhabilitado.', 
		'savebtn'	=> 'Al hacer clic en <b>Guardar</b> guardar todos los cambios y hace que este activo',
		'Hidden' 	=> 'Campos ocultos son campos que no están disponibles actualmente para los usuarios para el uso en vista de lista.',
		'Available' => 'Campos disponibles son los campos que no se muestran por defecto, pero puede ser activado por los usuarios.',
		'Default'	=> 'Por defecto se muestran los campos a los usuarios que no han creado una lista personalizada en la vista de ajustes.'
	),
	'searchViewEditor'=>array(
		'modify'	=> 'Hay dos columnas mostradas a la izquierda. la columna "por defecto" contiene los campos que se mostrarán en la vista de búsqueda, y la columna "Oculto" contiene los campos disponibles para usted como un administrador para añadir a la vista.', 
		'savebtn'	=> 'Al hacer clic en <b>Guardar y Desplegar</b> guarda todos los cambios y los hace activos',
		'Hidden' 	=> 'Campos oculto son campos que no se muestra en la vista de búsqueda.',
		'Default'	=> 'Campos por defecto que se mostrarán en la vista de búsqueda.'
	),
	'layoutEditor'=>array(
		'default'	=> 'Hay dos columnas mostradas a la izquierda. La columna de la derecha, el actual diseño de la etiqueta o de diseño de la vista previa, es donde se cambia el diseño de el módulo. La columna de la izquierda, titulado Caja de herramientas, contiene elementos útiles y herramientas para su uso cuando la edición de el diseño. <br/><br/> Si el area de diseño,  que llevará por título Diseño Actual entonces está trabajando en una copia de el diseño actualmente utilizado el módulo de visualización.<br/><br/>Si es llamado Vista previa de diseño de entonces Están trabajando en una copia creada anteriormente por un clic en el botón Guardar, ya que podría haber sido cambiado a partir de la versión vista por los usuarios de este módulo.', 
		'saveBtn'	=> 'Al hacer clic en este botón guarda el diseño de modo que usted pueda conservar sus cambios. Al volver a este módulo empezará a partir de este diseño modificado. Su diseño sin embargo no será visto por los usuarios del módulo hasta que haga clic en el botón Guardar y Publicar.',
		'publishBtn'=> 'Haga clic en este botón para desplegar el diseño. Esto significa que este diseño será inmediatamente visto por los usuarios de este módulo.',
		'toolbox'	=> 'La caja de herramientas contiene una variedad de funciones útiles para la edición de diseños, incluyendo un área de la basura, un conjunto de elementos adicionales y un conjunto de campos disponibles. Cualquiera de estas puede ser arrastrado y colocado en el diseño.',
		'panels'	=> 'Esta zona muestra la forma en que su diseño se verá a los usuarios de este módulo cuando este sea mostrado.<br/><br/>Puede reposicionar elementos tales como campos, filas y paneles  arrastrándolos y soltándolos; eliminar elementos arrastrándolos y soltándolos En la zona de la basura en la caja de herramientas, o añadir nuevos elementos arrastrándolos de la caja de herramientas y soltándolos sobre ellos en el diseño en la posición deseada.'
	),
	'dropdownEditor'=>array(
		'default'	=> 'Hay dos columnas mostradas a la izquierda. La columna de la derecha, el actual diseño de la etiqueta o de diseño de la vista previa, es donde se cambia el diseño de el módulo. La columna de la izquierda, titulado Caja de herramientas, contiene elementos útiles y herramientas para su uso cuando la edición de el diseño. <br/><br/> Si el area de diseño,  que llevará por título Diseño Actual entonces está trabajando en una copia de el diseño actualmente utilizado el módulo de visualización.<br/><br/>Si es llamado Vista previa de diseño de entonces Están trabajando en una copia creada anteriormente por un clic en el botón Guardar, ya que podría haber sido cambiado a partir de la versión vista por los usuarios de este módulo.', 
		'dropdownaddbtn'=> 'Al hacer clic en este botón añade un nuevo elemento a la lista desplegable.',
	),
	'exportcustom'=>array(
	    'exportHelp'=>'Exporte personalizaciones realizadas en Estudio mediante la creación de paquetes que se puede cargar en otra instancia de Sugar a través de el <b>Módulo de Carga</b>.<br><br>En primer lugar, proporcione un <b>Nombre del paquete</ b>. Puede proporcionar <b>Autor</b> y <b>Descripción</b> para la información de el paquete también.<br><br>Seleccione el módulo(s) que contienen la personalizaciónes que desea exportar. Sólo los módulos que contiene personalizaciones aparecerá para seleccionar.<br><br> A continuación, haga clic en <b>Exportar</b> para crear un Archivo .zip para el paquete que contiene los cambios.',
	    'exportCustomBtn'=>'Haga clic en <b>Exportar</ b> para crear un  archivo .zip para el paquete que contiene la personalización que usted desea exportar.
',
	    'name'=>'Este es el <b>Nombre</b> de el paquete. Este nombre sera mostrado durante la instalación.',
	    'author'=>'This is the <b>Author</b> that is displayed during installation as the name of the entity that created the package. The Author can be either an individual or a company.
',
	    'description'=>'Este es la <b>Descripción</b> del paquete que se muestra durante la instalación.',
	),
	'studioWizard'=>array(
		'mainHelp' 	=> 'Bienvenido a el area <b>Herramientas de Desarrollo</b>.<br/><br/> Utilize las herramientas dentro de esta area para crear y manejar estandares y personalizar modulos y campos.',
		'studioBtn'	=> 'Utilice <b>Estudio</b> para personalizar los módulos instalados pora cambiar la organización de los campos, seleccionando que campos estan disponibles y creando campos de datos personalizados.',
		'mbBtn'		=> 'Utilice el <b>Módulo Constructor</b> para crear nuevos módulos.',
		'appBtn' 	=> 'Use de aplicaciones para personalizar el modo de diversas propiedades del programa, como el número de informes de TPS se muestran en la página principal',
		'backBtn'	=> 'Volver a la etapa anterior.',
		'studioHelp'=> 'Utilice <b>Estudio</b> para personalizar los módulos instalados.',
		'moduleBtn'	=> 'Haga clic para editar este módulo.',
		'moduleHelp'=> 'Seleccione el módulo de componente que desea editar',
		'fieldsBtn'	=> 'Modificar el tipo de información que se almacena en el módulo de control de la <b> Campos</b> en el módulo.<br/><br/>Puede editar y crear campos personalizados aquí.',
		'labelsBtn' => 'Haga clic en <b>Guardar</b> para guardar etiquetas personalizadas.'	,
		'layoutsBtn'=> 'Personalize el <b>Diseño</b> de Edición, Detalle, la Lista y vista de búsqueda.',
		'subpanelBtn'=> 'Edite que información se muestra en estos subpaneles.',
		'layoutsHelp'=> 'Seleccione un <b>Diseño para editar</b>.<br/><br/>Para cambiar el formato que contiene los campos de datos para la entrada de datos, haga click en <b>Editar Vista</b>.<br/><br/>Para cambiar el diseño que muestra los datos entró en el campo en el editor de Vista, haga clic en <b>Ver Detalles</b>. <br/><br/> Para cambiar las columnas que aparecen en la lista por defecto, haga click en <b>Vista de lista</b>.<br/><br/>Para cambiar la búsqueda Básica y Avanzada, haga click en <b>Buscar</b>.',
		'subpanelHelp'=> 'Seleccione un <b>Subpanel</b> para editar.',
		'searchHelp' => 'Seleccione un diseño de <b>Búsqueda</b> para editar.',
		'labelsBtn'	=> 'Edite las <b>Etiquetas</b> para mostrar los valores en este módulo.',
        'newPackage'=>'Haga clic en <b>Nuevo Paquete</b> para crear un nuevo paquete.',
        'mbHelp'    => '<b>Bienvenido al Constructor de Módulos</ b>. <br/><br/>Use el <b>Constructor de Módulos</ b> para crear paquetes que contienen módulos personalizados basado en estandares objetos personalizados. <br/><br/>Para empezar, haga clic en <b>Nuevo Paquete</ b> para crear un nuevo paquete, o seleccione un paquete para editar. <br/> <br/> Un<b>Paquete</b> Actúa como un contenedor de módulos personalizados, que son parte de un proyecto. El paquete puede contener uno o más módulos personalizados que pueden ser relacionados unos con otros o con los módulos en la aplicación. <br/> <br/> Ejemplos: Es posible que desee crear un paquete que contiene un módulo personalizado que se relaciona con el módulo estándar de Cuentas. O bien, usted puede ser que desee crear un paquete que contiene varios de los nuevos módulos que trabajan juntos como un proyecto y que están relacionadas entre sí y con los módulos en la aplicación.',
        'exportBtn' => 'Haga clic en <b>Exportar Personalizaciones </b> para crear un paquete que contiene las personalizaciones realizadas en Estudio para módulos específicos.',
	),
	
	
),
//ASSISTANT
'LBL_AS_SHOW' => 'Mostrar el Asistente en el futuro',
'LBL_AS_IGNORE' => 'Ignorar el asistente en el futuro.',
'LBL_AS_SAYS' => 'Asistente dice:',


//STUDIO2
'LBL_MODULEBUILDER'=>'Constructor de Modulos',
'LBL_STUDIO' => 'Estudio',
'LBL_DROPDOWNEDITOR' => 'Editor de menus',
'LBL_DEVELOPER_TOOLS' => 'Herramientas de Desarrollo',
'LBL_SUGARPORTAL' => 'Editor del Portal Sugar',
'LBL_SYNCPORTAL' => 'Sync Portal',
'LBL_PACKAGE_LIST' => 'Lista de paquetes',
'LBL_HOME' => 'Inicio',
'LBL_NONE'=>'-Ninguno-',

'LBL_ADD_FIELDS'=>'Agregar Campos Personalizados',
'LBL_AVAILABLE_SUBPANELS'=>'Subpanels Disponibles',
'LBL_ADVANCED'=>'Avanzado',
'LBL_ADVANCED_SEARCH'=>'Busqueda Avanzada',
'LBL_BASIC'=>'Basico',
'LBL_BASIC_SEARCH'=>'Busqueda Basica',
'LBL_CURRENT_LAYOUT'=>'Diseño Actual',
'LBL_DISPLAY_HTML'=>'Mostrar Codigo HTML',
'LBL_DETAILVIEW'=>'Vista de Detalles',
'LBL_DROP_HERE' => '[Suelte Aqui]',
'LBL_EDIT'=>'Editar',
'LBL_EDIT_LAYOUT'=>'Editar Diseño',
'LBL_EDIT_ROWS'=>'Editar Filas',
'LBL_EDIT_COLUMNS'=>'Editar Columnas',
'LBL_EDIT_LABELS'=>'Editar Etiquetas',
'LBL_EDIT_FIELDS'=>'Editar Campos Personalizados',
'LBL_EDIT_PORTAL'=>'Editar porta para ',
'LBL_EDIT_FIELDS'=>'Editar Campos',
'LBL_EDITVIEW'=>'EditView',
'LBL_FILLER'=>'(filler)',
'LBL_FIELDS'=>'Campos',
'LBL_FAILED_TO_SAVE' => 'Fallo al Guardar',
'LBL_FAILED_PUBLISHED' => 'Publicacion fallida',
'LBL_LAYOUT_PREVIEW'=>'Vista previa del Diseño',
'LBL_LAYOUTS'=>'Diseños',
'LBL_LISTVIEW'=>'ListView',
'LBL_MODULES'=>'Modulos',
'LBL_MODULE_TITLE' => 'Estudio',
'LBL_NEW_PACKAGE' => 'Nuevo Paquete',
'LBL_NEW_PANEL'=>'Nuevo Panel',
'LBL_NEW_ROW'=>'Nueva Fila',
'LBL_PUBLISHING' => 'Publicando ...',
'LBL_PUBLISHED' => 'Publicado',
'LBL_RELATIONSHIPS'=>'Relaciones',
'LBL_SELECT_FILE'=> 'Seleccione Archivo',
'LBL_SAVE_LAYOUT'=> 'Guarde Diseño',
'LBL_SELECT_A_SUBPANEL' => 'Seleccione un Subpanel',
'LBL_SELECT_SUBPANEL' => 'Seleccione Subpanel',
'LBL_SUBPANELS' => 'Subpanels',
'LBL_SEARCH_FORMS' => 'Formulario de Busqueda',
'LBL_SEARCH'=>'Busqueda',
'LBL_STAGING_AREA' => 'Area de Almacenamiento (arrastrar y soltar elementos aquí)',
'LBL_SUGAR_FIELDS_STAGE' => 'Campos de Sugar (click items to add to staging area)',
'LBL_SUGAR_BIN_STAGE' => 'Sugar Bin (Clic en los elementos para añadir esta area)',
'LBL_TOOLBOX' => 'Caja de Herramientas',
'LBL_VIEW_SUGAR_FIELDS' => 'Ver los campos de Sugar',
'LBL_VIEW_SUGAR_BIN' => 'Ver los Bin de Sugar',
'LBL_QUICKCREATE' => 'CrearRapido',
'LBL_EDIT_DROPDOWNS' => 'Editar un menu desplegable Global',
'LBL_ADD_DROPDOWN' => 'Agregar un menu desplegable Global',

'LBL_DROPDOWN_TITLE_NAME' => 'Nombre del Menu Desplegable',
'LBL_DROPDOWN_LANGUAGE' => 'Idioma del Menu Desplegable',
'LBL_DROPDOWN_ITEMS' => 'Items del Menu Desplegable',
'LBL_DROPDOWN_ITEM_NAME' => 'Nombre de Campo',
'LBL_DROPDOWN_ITEM_LABEL' => 'Mostrar Etiqueta',

//STUDIO QUESTIONS
'LBL_QUESTION_FUNCTION' => 'Selecione una Función o Componente.',
'LBL_QUESTION_MODULE1' => 'Seleccione un modulo.',
'LBL_QUESTION_EDIT' => 'Seleccione un modulo para editar.',
'LBL_QUESTION_LAYOUT' => 'Seleccione un diseño para editar.',
'LBL_QUESTION_SUBPANEL' => 'Seleccione un Subpanel para editar.',
'LBL_QUESTION_SEARCH' => 'Seleccione un diseño de busqueda para editar.',
'LBL_QUESTION_MODULE' => 'Seleccione un componente del modulo para editar.',
'LBL_QUESTION_PACKAGE' => 'Seleccione un paquete para editar, o crear un nuevo paquete.',
'LBL_QUESTION_EDITOR' => 'Seleccione una Herramienta.',
'LBL_QUESTION_DROPDOWN' => 'Seleccione un Menu desplegable para editar, o para crear un nuevo menu desplegable.',
//CUSTOM FIELDS
'LBL_NAME'=>'Nombre',
'LBL_LABELS'=>'Etiquetas',
'LBL_MASS_UPDATE'=>'Actualización en masa',
'LBL_AUDITED'=>'Auditoria',
'LBL_CUSTOM_MODULE'=>'Modulo',
'LBL_DEFAULT_VALUE'=>'Valor por defecto',
'LBL_REQUIRED'=>'Requerido',
'LBL_DATA_TYPE'=>'Tipo',
'LBL_HCUSTOM'=>'CUSTOM',
'LBL_HDEFAULT'=>'DEFAULT',

'LBL_LANGUAGE'=>'Idioma:',


//SECTION
'LBL_SECTION_EDLABELS' => 'Edite Etiquetas',
'LBL_SECTION_PACKAGES' => 'Paquetes',
'LBL_SECTION_MODULES' => 'Modulos',
'LBL_SECTION_PORTAL' => 'Portal',
'LBL_SECTION_DROPDOWNS' => 'Menu deplegable',
'LBL_SECTION_PROPERTIES' => 'Propiedades',
'LBL_SECTION_DROPDOWNED' => 'Editor de menu desplegable',
'LBL_SECTION_HELP' => 'Ayuda',
'LBL_SECTION_ACTION' => 'Acción',
'LBL_SECTION_MAIN' => 'Menu',
'LBL_SECTION_EDPANELLABEL' => 'Edite Etiqueta del Panel',
//WIZARDS

//LIST VIEW EDITOR
'LBL_DEFAULT'=>'Por Defecto',
'LBL_HIDDEN'=>'Oculto',
'LBL_AVAILABLE'=>'Disponible',
'LBL_LISTVIEW_DESCRIPTION'=>'Hay tres columnas mostradas a continuación. la columna <b>por Defecto</b> contiene los campos que se muestran en una vista de lista por defecto. la columna <b>adicional</ b> contiene los campos que el usuario puede elegir para crear una vista personalizada. la columna <b>Disponible</b> muestra los campos disponibles para usted como un administrador para añadir columnas por Defecto o columnas adicionales para su uso por los usuarios.', 
'LBL_LISTVIEW_EDIT'=>'Ver Lista Editor',

//Manager Backups History
'LBL_MB_PREVIEW'=>'Previo',
'LBL_MB_RESTORE'=>'Restaurar',
'LBL_MB_DELETE'=>'Eliminar',
'LBL_MB_COMPARE'=>'Comparar',

//END WIZARDS

//BUTTONS
'LBL_BTN_SAVE'=>'Guardar',
'LBL_BTN_CANCEL'=>'Cancelar',
'LBL_BTN_UPLOAD'=>'Subir',
'LBL_BTN_SAVEPUBLISH'=>'Guarde & Despliegue',
'LBL_BTN_NEXT'=>'Siguiente',
'LBL_BTN_BACK'=>'Anterior',
'LBL_BTN_ADDCOLS'=>'Agregar Columnas',
'LBL_BTN_ADDROWS'=>'Agregar Filas',
'LBL_BTN_ADDFIELD'=>'Agregar Campos',
'LBL_BTN_ADDDROPDOWN'=>'Agregar Menu desplegable',
'LBL_BTN_EDLABELS'=>'Editar Etiquetas',
'LBL_BTN_UNDO'=>'Deshacer',
'LBL_BTN_REDO'=>'Rehacer',
'LBL_BTN_ADDCUSTOMFIELD'=>'Agregar Campo Personalizado',
'LBL_BTN_EXPORT'=>'Exportar Personalizaciones',
'LBL_BTN_DUPLICATE'=>'Duplicar',
'LBL_BTN_PUBLISH'=>'Publicar',
'LBL_BTN_DEPLOY'=>'Desplegar',
'LBL_BTN_EXP'=>'Exportar',
'LBL_BTN_DELETE'=>'Eliminar',
'LBL_BTN_VIEW_LAYOUTS'=>'Ver Diseños',
'LBL_BTN_VIEW_FIELDS'=>'Ver Campos',
'LBL_BTN_VIEW_RELATIONSHIPS'=>'Ver Relaciones',

//TABS


//ERRORS
'ERROR_ALREADY_EXISTS'=> 'Error: Campo Ya Existente',
'ERROR_INVALID_KEY_VALUE'=> "Error: Caracter Invalido: [']",




































//PACKAGE AND MODULE BUILDER
'LBL_NAME'=>'Nombre del Paquete:',
'LBL_MODULE_NAME'=>'Nombre del Modulos:',
'LBL_AUTHOR'=>'Autor:',
'LBL_DESCRIPTION'=>'Descripción:',
'LBL_KEY'=>'Clave:',
'LBL_ADD_README'=>' Leame',
'LBL_MODULES'=>'Modulos:',
'LBL_LAST_MODIFIED'=>'Ultima Modificación:',
'LBL_NEW_MODULE'=>'Modulo Nuevo',
'LBL_LABEL'=>'Etiqueta:',
'LBL_PACKAGE'=>'Paquete:',
'LBL_TYPE'=>'Tipe:',
'LBL_TEAM_SECURITY'=>'Equipo de Seguridad',
'LBL_NAV_TAB'=>'Pestaña de Navegación',
'LBL_CREATE'=>'Crear',
'LBL_LIST'=>'Lista',
'LBL_LIST_VIEW'=>'Vista de lista',
'LBL_HISTORY'=>'Historial',
'LBL_ACTIVITIES'=>'Actividades',
'LBL_SEARCH'=>'Buscar',
'LBL_NEW'=>'Nuevo',
//EXPORT CUSTOMS
'LBL_EC_TITLE'=>'Exportar personalizaciones',
'LBL_EC_NAME'=>'Nombre de paquete:',
'LBL_EC_AUTHOR'=>'Autor:',
'LBL_EC_DESCRIPTION'=>'Descripción:',
'LBL_EC_KEY'=>'Clave:',
'LBL_EC_CHECKERROR'=>'Favor Selecione un modulo.',
'LBL_EC_CUSTOMFIELD'=>'campo(s) personalido',
'LBL_EC_CUSTOMLAYOUT'=>'diseño(s) personalizado',
'LBL_EC_NOCUSTOM'=>'No hay Modulos personalizados.',
'LBL_EC_EMPTYCUSTOM'=>'personalizaciones vacio.',
'LBL_EC_EXPORTBTN'=>'Exportar',
'LBL_MODULE_DEPLOYED' => 'Modulos ha sido desplegados.',

//AJAX STATUS
'LBL_AJAX_FAILED_DATA' => 'No se han podido recuperar datos',
'LBL_AJAX_TIME_DEPENDENT' => 'Una vez depende de la acción en curso y espere por favor, inténtelo de nuevo en pocos segundos',
'LBL_AJAX_LOADING' => 'Cargando...',
'LBL_AJAX_DELETING' => 'Eliminando...',
'LBL_AJAX_BUILDPROGRESS' => 'Construcción en Progreso...',
'LBL_AJAX_DEPLOYPROGRESS' => 'Despliege en Progreso...',

//JS
'LBL_JS_REMOVE_PACKAGE' => '¿Está seguro de que desea eliminar este paquete? Esto eliminara definitivamente todos los archivos asociados con este paquete.',

'LBL_DEPLOY_IN_PROGRESS' => 'Desplegando Paquete'
);

