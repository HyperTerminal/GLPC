<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',

  'LBL_MODULE_NAME' => 'Casos',
  'LBL_MODULE_TITLE' => 'Casos: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Casos',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Caso',
  'LBL_CONTACT_CASE_TITLE' => 'Contacto-Caso:',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_CASE' => 'Caso:',
  'LBL_CASE_NUMBER' => 'Número:',
  'LBL_NUMBER' => 'Número:',
  'LBL_STATUS' => 'Estado:',
  'LBL_PRIORITY' => 'Prioridad:',
  'LBL_ACCOUNT_NAME' => 'Cuenta:',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_RESOLUTION' => 'Resolución:',
  'LBL_CONTACT_NAME' => 'Contacto:',
  'LBL_CASE_SUBJECT' => 'Asunto:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_INVITEE' => 'Contactos',

  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'LBL_ACCOUNT_ID' => 'ID Cuenta',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Casos',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historial',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
  'LBL_BUGS_SUBPANEL_TITLE' => 'Incidencias',
  'LBL_MEMBER_OF' => 'Cuenta',
  'LBL_SYSTEM_ID' => 'ID Sistema',

  'LBL_LIST_ACCOUNT_NAME' => 'Cuenta',
  'LBL_LIST_ASSIGNED' => 'Asignado a',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_LIST_FORM_TITLE' => 'Lista de Casos',
  'LBL_LIST_LAST_MODIFIED' => 'Modificado',
  'LBL_LIST_MY_CASES' => 'Mis Casos Abiertos',
  'LBL_LIST_NUMBER' => 'Núm.',
  'LBL_LIST_PRIORITY' => 'Prioridad',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_SUBJECT' => 'Asunto',

  'LNK_CASE_LIST' => 'Casos',
  'LNK_NEW_CASE' => 'Nuevo Caso',

  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => '¿Está seguro de que desea quitar este caso de la incidencia?',
  'NTC_REMOVE_INVITEE' => '¿Está seguro de que desea quitar a este contacto de la cuenta?',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
  'LBL_LIST_DATE_CREATED' => 'Fecha de Creación',
  'LNK_CASE_REPORTS' => 'Informes de Casos',
);


?>