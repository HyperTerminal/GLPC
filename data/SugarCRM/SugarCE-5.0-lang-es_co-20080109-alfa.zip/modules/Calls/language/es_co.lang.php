<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Llamadas',
  'LBL_MODULE_TITLE' => 'Llamadas: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Llamadas',
  'LBL_LIST_FORM_TITLE' => 'Lista de Llamadas',
  'LBL_NEW_FORM_TITLE' => 'Programación de Llamadas',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_DATE' => 'Fecha Inicio',
  'LBL_LIST_TIME' => 'Hora Inicio',
  'LBL_LIST_DURATION' => 'Duración',
  'LBL_LIST_DIRECTION' => 'Dirección',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_REMINDER' => 'Aviso:',
  'LBL_CONTACT_NAME' => 'Contacto:',
  'LBL_DESCRIPTION_INFORMATION' => 'Información adicional',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_STATUS' => 'Estado:',
  'LBL_DIRECTION' => 'Dirección:',
  'LBL_DATE' => 'Fecha Inicio:',
  'LBL_DURATION' => 'Duración:',
  'LBL_DURATION_HOURS' => 'Horas Duración:',
  'LBL_DURATION_MINUTES' => 'Minutos Duración:',
  'LBL_HOURS_MINUTES' => '(horas/minutos)',
  'LBL_CALL' => 'Llamada:',
  'LBL_DATE_TIME' => 'Inicio:',
  'LBL_TIME' => 'Hora inicio:',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planificada',
  'LNK_NEW_CALL' => 'Programar Llamada',
  'LNK_NEW_MEETING' => 'Programar Reunión',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NEW_NOTE' => 'Nueva Nota o Archivo Adjunto',
  'LNK_NEW_EMAIL' => 'Archivar Email',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'NTC_REMOVE_INVITEE' => '¿Está seguro de que desea quitar a este participante de la llamada?',
  'LBL_INVITEE' => 'Participantes',
  'LBL_RELATED_TO' => 'Relativo a',
  'LNK_NEW_APPOINTMENT' => 'Crear Cita',
  'LBL_SCHEDULING_FORM_TITLE' => 'Planificación',
  'LBL_ADD_INVITEE' => 'Añadir Invitados',
  'LBL_NAME' => 'Nombre',
  'LBL_FIRST_NAME' => 'Nombre',
  'LBL_LAST_NAME' => 'Apellido',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Teléfono',
  'LBL_SEND_BUTTON_TITLE' => 'Enviar Invitaciones [Alt+I]',
  'LBL_SEND_BUTTON_KEY' => 'I',
  'LBL_SEND_BUTTON_LABEL' => 'Enviar Invitaciones',
  'LBL_DATE_END' => 'Fecha de Fin',
  'LBL_TIME_END' => 'Hora de Fin',
  'LBL_REMINDER_TIME' => 'Hora Aviso',
  'LBL_SEARCH_BUTTON' => 'Buscar',
  'LBL_ADD_BUTTON' => 'Añadir',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Llamadas',
  'LBL_LOG_CALL' => 'Registrar Llamada',
  'LNK_SELECT_ACCOUNT' => 'Seleccionar Cuenta',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  'LBL_DEL' => 'Eliminar',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
  'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios',
  'LBL_OUTLOOK_ID' => 'ID Outlook',
  'LBL_MEMBER_OF' => 'Miembro De',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Notas',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
  'LBL_LIST_MY_CALLS' => 'Mis Llamadas',
  'LBL_SELECT_FROM_DROPDOWN' => 'Por favor, seleccione antes un elemento de la lista desplegable Relativo A.',
);


?>