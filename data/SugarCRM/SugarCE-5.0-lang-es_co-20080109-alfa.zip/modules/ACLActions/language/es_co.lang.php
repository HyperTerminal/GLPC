<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_ACCESS_ALL' => 'Todo',
  'LBL_ACCESS_NONE' => 'Nada',
  'LBL_ACCESS_OWNER' => 'Propietario',
  'LBL_ACCESS_NORMAL' => 'Normal',
  'LBL_ACCESS_ADMIN' => 'Admin',
  'LBL_ACCESS_ENABLED' => 'Habilitado',
  'LBL_ACCESS_DISABLED' => 'Deshabilitado',
  'LBL_NAME' => 'Nombre',
  'LBL_DESCRIPTION' => 'Descripción',
  'LIST_ROLES' => 'Listar Roles',
  'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios',
  'LIST_ROLES_BY_USER' => 'Listar Roles por Usuario',
  'LBL_ROLES_SUBPANEL_TITLE' => 'Roles de Usuario',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda',
  'LBL_ACTION_VIEW' => 'Ver',
  'LBL_ACTION_EDIT' => 'Editar',
  'LBL_ACTION_DELETE' => 'Eliminar',
  'LBL_ACTION_IMPORT' => 'Importar',
  'LBL_ACTION_EXPORT' => 'Exportar',
  'LBL_ACTION_LIST' => 'Listar',
  'LBL_ACTION_ACCESS' => 'Acceso',
  'LBL_ACTION_ADMIN' => 'Tipo de Usuario',
  'LBL_ACCESS_DEFAULT'=>'Por defecto',
);


?>