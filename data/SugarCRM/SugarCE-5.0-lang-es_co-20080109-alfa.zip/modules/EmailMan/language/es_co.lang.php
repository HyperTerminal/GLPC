<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_ID' => 'Id',
  'LBL_ATTACHMENT_AUDIT' => ' ha sido enviado.  No se ha duplicado en local para minimizar la utilización de espacio en el disco duro.',
  'LBL_OLD_ID' => 'Id Antiguo',
  'LBL_LIST_CAMPAIGN' => 'Campaña',
  'LBL_LIST_FORM_PROCESSED_TITLE' => 'Procesados',
  'LBL_LIST_FORM_TITLE' => 'Cola',
  'LBL_LIST_FROM_EMAIL' => 'Email del Remitente',
  'LBL_LIST_FROM_NAME' => 'Nombre del Remitente',
  'LBL_LIST_IN_QUEUE' => 'En Proceso',
  'LBL_LIST_RECIPIENT_EMAIL' => 'Email del Destinatario',
  'LBL_LIST_RECIPIENT_NAME' => 'Nombre del Destinatario',
  'LBL_LIST_SEND_ATTEMPTS' => 'Intentos de Envío',
  'LBL_LIST_SEND_DATE_TIME' => 'Enviar el',
  'LBL_LIST_USER_NAME' => 'Nombre de Usuario',
  'LBL_MODULE_TITLE' => 'Administración de Cola de Email Saliente',
  'LBL_SEARCH_FORM_PROCESSED_TITLE' => 'Búsqueda de Procesados',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Colas',
  'LBL_VIEW_PROCESSED_EMAILS' => 'Ver Emails Procesados',
  'LBL_VIEW_QUEUED_EMAILS' => 'Ver Emails Encolados',
  'LBL_RELATED_ID' => 'Id Relacionado',
  'LBL_RELATED_TYPE' => 'Tipo Relacionado',
  'LBL_SAVE_OUTBOUND_RAW' => 'Guardar los Emails Salientes en formato original',
  'LBL_MARKETING_ID' => 'Id de Marketing',
  'LBL_MODULE_ID' => 'EmailMan',
  'LBL_LIST_MESSAGE_NAME' => 'Mensaje de Marketing',
  'LBL_MODULE_NAME' => 'Configuración de Correo',
  'LBL_CONFIGURE_SETTINGS' => 'Configurar',
  'LBL_EMAILS_PER_RUN' => 'Número de emails enviados por lote', 
  'LBL_EMAIL_PER_RUN_REQ' => 'Número de emails enviados por lote',
  'LBL_LOCATION_ONLY' => 'Ubicación',
  'LBL_LOCATION_TRACK' => 'Ubicación de los archivos de seguimiento de campaña (como campaign_tracker.php)',
  'LBL_CAMP_MESSAGE_COPY' => 'Guardar copias de los mensajes de la campaña:',
  'LBL_DEFAULT_LOCATION' => 'Por Defecto',
  'LBL_CUSTOM_LOCATION' => 'Definido por el Usuario',
  'LBL_EMAIL_DEFAULT_CHARSET' => 'Componer mensajes de email en este juego de caracteres',
  'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE' => 'Valor en Config.php para site_url',
  'ERR_INT_ONLY_EMAIL_PER_RUN' => 'Sólo se permiten valores enteros para el Número de emails enviados por lote',
  'TXT_REMOVE_ME' => 'Para borrar su suscripción a esta lista de correo ',
  'TXT_REMOVE_ME_ALT' => 'Para borrar su suscripción a esta lista de correo vaya a',
  'TXT_REMOVE_ME_CLICK' => 'haga clic aquí',
  'LBL_EMAIL_DEFAULT_CLIENT' => 'Redactar mensajes de correo en este formato',
  'LBL_EMAIL_DEFAULT_EDITOR' => 'Redactar correo usando este cliente',
  'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS'		=> 'Eliminar archivos adjuntos y Notas relacionadas junto a los Emails borrados',
  'LBL_MAIL_SENDTYPE'							=> 'Agente de Transferencia de Correo (MTA):',
	'LBL_MAIL_SMTPAUTH_REQ'						=> '¿Usar Autenticación SMTP?',
	'LBL_MAIL_SMTPPASS'							=> 'Contraseña SMTP:',
	'LBL_MAIL_SMTPPORT'							=> 'Puerto SMTP:',
	'LBL_MAIL_SMTPSERVER'						=> 'Servidor SMTP:',
	'LBL_MAIL_SMTPUSER'							=> 'Usuario SMTP:',
	'LBL_NOTIFICATION_ON_DESC' 					=> 'Envía correos de notificación cuando se asignan registros.',
	'LBL_NOTIFY_FROMADDRESS' 					=> 'Dirección remitente:',
	'LBL_NOTIFY_FROMNAME' 						=> 'Nombre remitente:',
	'LBL_NOTIFY_ON'								=> '¿Activar notificaciones?',
	'LBL_NOTIFY_SEND_BY_DEFAULT'				=> '¿Enviar notificaciones por defecto en usuarios nuevos?',
	'LBL_NOTIFY_TITLE'							=> 'Opciones de Notificación de Correo',
	'LBL_OUTBOUND_EMAIL_TITLE'					=> 'Opciones de Correo Saliente',
	'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER'		=> '¿Enviar notificación usando como remitente la dirección de email del usuario asignador?',
	
	'LBL_SECURITY_TITLE'						=> 'Configuración de Seguridad de Email',
	'LBL_SECURITY_DESC'							=> 'Marque aquello que NO debería ser permitido en Email entrante o mostradas en el módulo de Emails.',
	'LBL_SECURITY_APPLET'						=> 'Etiqueta Applet',
	'LBL_SECURITY_BASE'							=> 'Etiqueta Base',
	'LBL_SECURITY_EMBED'						=> 'Etiqueta Embed',
	'LBL_SECURITY_FORM'							=> 'Etiqueta Form',
	'LBL_SECURITY_FRAME'						=> 'Etiqueta Frame',
	'LBL_SECURITY_FRAMESET'						=> 'Etiqueta Frameset',
	'LBL_SECURITY_IFRAME'						=> 'Etiqueta iFrame',
	'LBL_SECURITY_IMPORT'						=> 'Etiqueta Import',
	'LBL_SECURITY_LAYER'						=> 'Etiqueta Layer',
	'LBL_SECURITY_LINK'							=> 'Etiqueta Link',
	'LBL_SECURITY_OBJECT'						=> 'Etiqueta Object',
	'LBL_SECURITY_OUTLOOK_DEFAULTS'				=> 'Seleccionar las precauciones mínimas de seguridad por defecto en Outlook (puede provocar errores en la visualización del contenido).',
	'LBL_SECURITY_PRESERVE_RAW'					=> 'Preservar código fuente del email, incluyendo contenido potencialmente peligroso.  Esta opción sólo preservará mensajes originales en la base de datos; no se permitirá contenido sin filtrar en el Interfaz de Usuario de SugarCRM .<br /><span class="error">Esto puede hacer que la seguridad de su sistema se vea comprometida.</span>',
	'LBL_SECURITY_SCRIPT'						=> 'Etiqueta Script',
	'LBL_SECURITY_STYLE'						=> 'Etiqueta Style',
	'LBL_SECURITY_TOGGLE_ALL'					=> 'Cambiar Todas las Opciones',
	'LBL_SECURITY_XMP'							=> 'Etiqueta Xmp',
    'LBL_YES'                                   => 'Sí',
    'LBL_NO'                                    => 'No',
    'LBL_PREPEND_TEST'                          => '[Prueba]: ',
	
);


?>