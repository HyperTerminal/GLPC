<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Actividades',
  'LBL_MODULE_TITLE' => 'Actividades: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Actividades',
  'LBL_LIST_FORM_TITLE' => 'Lista de Actividades',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_CONTACT' => 'Contacto',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_DATE' => 'Fecha',
  'LBL_LIST_TIME' => 'Hora inicio',
  'LBL_LIST_CLOSE' => 'Cerrar',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_STATUS' => 'Estado:',
  'LBL_LOCATION' => 'Lugar:',
  'LBL_DATE_TIME' => 'Inicio:',
  'LBL_DATE' => 'Fecha inicio:',
  'LBL_TIME' => 'Hora inicio:',
  'LBL_DURATION' => 'Duración:',
  'LBL_HOURS_MINS' => '(horas/minuntos)',
  'LBL_CONTACT_NAME' => 'Contacto: ',
  'LBL_MEETING' => 'Reunión:',
  'LBL_DESCRIPTION_INFORMATION' => 'Información adicional',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planificada',
  'LNK_NEW_CALL' => 'Programar Llamada',
  'LNK_NEW_MEETING' => 'Programar Reunión',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NEW_NOTE' => 'Nueva Nota o Archivo Adjunto',
  'LNK_NEW_EMAIL' => 'Nuevo Email Archivado',
  'LNK_CALL_LIST' => 'Llamadas',
  'LNK_MEETING_LIST' => 'Reuniones',
  'LNK_TASK_LIST' => 'Tareas',
  'LNK_NOTE_LIST' => 'Notas',
  'LNK_EMAIL_LIST' => 'Emails',
  'ERR_DELETE_RECORD' => 'Debe de especificar un número de registro a eliminar.',
  'NTC_REMOVE_INVITEE' => '¿Está seguro de que desea eliminar a este asistente a la reunión?',
  'LBL_INVITEE' => 'Asistentes',
  'LBL_LIST_DIRECTION' => 'Dirección',
  'LBL_DIRECTION' => 'Dirección',
  'LNK_NEW_APPOINTMENT' => 'Nueva Cita',
  'LNK_VIEW_CALENDAR' => 'Hoy',
  'LBL_OPEN_ACTIVITIES' => 'Actividades Abiertas',
  'LBL_HISTORY' => 'Historial',
  'LBL_UPCOMING' => 'Mis Próximas Citas',
  'LBL_TODAY' => 'hasta ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Nueva Tarea [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Nueva Tarea',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Programar Reunión [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Programar Reunión',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Programar Llamada [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Programar Llamada',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Nueva Nota o Archivo Adjunto [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Nueva Nota o Archivo Adjunto',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Email Seguimiento [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Email Seguimiento',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_DUE_DATE' => 'Fecha Vencimiento',
  'LBL_LIST_LAST_MODIFIED' => 'Modificado',
  'NTC_NONE_SCHEDULED' => 'Sin programación.',
  'appointment_filter_dom' => 
  array (
    'today' => 'hoy',
    'tomorrow' => 'mañana',
    'this Saturday' => 'esta semana',
    'next Saturday' => 'la semana que viene',
    'last this_month' => 'este mes',
    'last next_month' => 'el mes que viene',
  ),
  'LNK_IMPORT_NOTES' => 'Importar Notas',
  'NTC_NONE' => 'Ninguna',
  'LBL_ACCEPT_THIS' => '¿Aceptar?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Actividades Abiertas',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
);


?>