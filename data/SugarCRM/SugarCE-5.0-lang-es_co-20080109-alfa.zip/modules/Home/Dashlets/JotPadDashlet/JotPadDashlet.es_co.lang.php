<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2008 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * WEDNESDAY 09/january/2008
 ********************************************************************************/




$defaultText = 
<<<EOQ
Bienvenido a Sugar 5.0<br /><br />

Las Nuevas caracter&iacute;sticas incluidas son:<br />
* Mejora en los gr&aacute;ficos de cuadros de comandos<br />
* Nuevo Cliente de Correo para comunicaci&oacute;n mas refinada<br />
* Constructor de M&oacute;dulos para extender la funcionalidad de SugarCRM<br />
* Mejora en el Estudio de Sugar para personalizar la funcionalidad de SugarCRM<br /><br />

Para m&aacute;s informaci&oacute;n sobre esta versi&oacute;n, por favor visite la Universidad de Sugar.<br />
EOQ
;


















$dashletStrings['JotPadDashlet'] = array('LBL_TITLE'            => 'Bloc de notas',
                                         'LBL_DESCRIPTION'      => 'Un dashlet para guardar sus notas',
                                         'LBL_SAVING'           => 'Guardando Bloc de notas ...',
                                         'LBL_SAVED'            => 'Guardado',
                                         'LBL_CONFIGURE_TITLE'  => 'Titulo',
                                         'LBL_CONFIGURE_HEIGHT' => 'Altura (1 - 300)',
                                         'LBL_DBLCLICK_HELP'    => 'Haga doble click abajo para editar.',
                                         'LBL_DEFAULT_TEXT'     => $defaultText,
);
?> 
