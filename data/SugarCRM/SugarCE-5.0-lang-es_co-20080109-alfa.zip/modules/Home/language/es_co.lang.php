<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Inicio',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Contacto',
  'LBL_FIRST_NAME' => 'Nombre:',
  'LBL_LAST_NAME' => 'Apellidos:',
  'LBL_LIST_LAST_NAME' => 'Apellidos',
  'LBL_PHONE' => 'Teléfono:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'Mi Pipeline',
  'LBL_PIPELINE_FORM_TITLE' => 'Pipeline por Etapas de Venta',
  'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'ROI Campaña',
  'LBL_MY_CLOSED_OPPORTUNITIES_GAUGE' => 'Mi Indicador de Oportunidades Cerradas',  
  'LNK_NEW_CONTACT' => 'Nuevo Contacto',
  'LNK_NEW_ACCOUNT' => 'Nueva Cuenta',
  'LNK_NEW_OPPORTUNITY' => 'Nueva Oportunidad',
  
  
  
  'LNK_NEW_LEAD' => 'Nuevo Candidato',
  'LNK_NEW_CASE' => 'Nuevo Caso',
  'LNK_NEW_NOTE' => 'Nueva Nota o Archivo Adjunto',
  'LNK_NEW_CALL' => 'Programar Llamada',
  'LNK_NEW_EMAIL' => 'Archivar Correo',
  'LNK_COMPOSE_EMAIL' => 'Redactar Correo',
  'LNK_NEW_MEETING' => 'Programar Reunión',
  'LNK_NEW_TASK' => 'Nueva Tarea',
  'LNK_NEW_BUG' => 'Informar Bug',
  'LBL_ADD_BUSINESSCARD' => 'Nueva Tarjeta de Negocios',
  'ERR_ONE_CHAR' => 'Por favor, indique al menos un número o letra para su búsqueda...',
  'LBL_OPEN_TASKS' => 'Mis Tareas Pendientes',
  'LBL_SEARCH_RESULTS' => 'Resultados de Búsqueda',  
  'LBL_SEARCH_RESULTS_IN' => 'en', 
  'LNK_NEW_SEND_EMAIL' => 'Redactar Correo',
  'LBL_NO_RESULTS_IN_MODULE' => '-- Sin Resultados --',
  'LBL_NO_RESULTS' => '<h2>No se han encontrado resultados. Por favor, realice una nueva búsqueda.</h2><br>',
  'LBL_NO_RESULTS_TIPS' => '<h3>Trucos para la Búsqueda:</h3><ul><li>Asegúrese que ha seleccionado las categorías adecuadas más arriba.</li><li>Amplíe sus criterios de búsqueda.</li><li>Si aun así no obtiene resultados, pruebe con la búsqueda avanzada de ese módulo.</li></ul>',
  
  'LBL_RELOAD_PAGE' => 'Por favor, <a href="javascript: window.location.reload()">recargue la ventana</a> para usar este Dashlet.',
  'LBL_ADD_DASHLETS' => 'Agregar Dashlets',
  'LBL_ADD_PAGE' => 'Agregar P&aacute;gina',
  'LBL_DELETE_PAGE' => 'Eliminar P&aacute;gina',
  'LBL_CHANGE_LAYOUT' => 'Cambiar Dise&ntilde;o',
  'LBL_RENAME_PAGE' => 'Renombrar p&aacute;gina',  
  'LBL_CLOSE_DASHLETS' => 'Cerrar',
  'LBL_CLOSE_SITEMAP' => 'Cerrar',  
  'LBL_OPTIONS' => 'Opciones', 
  // dashlet search fields
  'LBL_TODAY'=>'Hoy',
  'LBL_YESTERDAY' => 'Ayer', 
  'LBL_TOMORROW'=>'Mañana',
  'LBL_LAST_WEEK'=>'La Semana Pasada',
  'LBL_NEXT_WEEK'=>'La Próxima Semana',
  'LBL_LAST_7_DAYS'=>'Últimos 7 Días',
  'LBL_NEXT_7_DAYS'=>'Siguientes 7 Días',
  'LBL_LAST_MONTH'=>'Último Mes',
  'LBL_NEXT_MONTH'=>'Siguiente Mes',
  'LBL_LAST_QUARTER'=>'Úlimo Trimestre',
  'LBL_THIS_QUARTER'=>'Este Trimestre',
  'LBL_LAST_YEAR'=>'Último Año',
  'LBL_NEXT_YEAR'=>'Próximo Año',
  'LBL_THIS_MONTH' => 'Este Mes',
  'LBL_THIS_YEAR' => 'Este Año',
  'LBL_LAST_30_DAYS' => 'Últimos 30 Días',
  'LBL_NEXT_30_DAYS' => 'Próximos 30 días',
  'LBL_THIS_MONTH' => 'Este Mes',
  'LBL_THIS_YEAR' => 'Este Año',
  'LBL_LAST_30_DAYS' => 'Últimos 30 Días',
  'LBL_NEXT_30_DAYS' => 'Próximos 30 Días',
  'LBL_MODULES' => 'Modulos',
  'LBL_CHARTS' => 'Gr&aacute;ficos',
  'LBL_TOOLS' => 'Herramientas',
  'LBL_SEARCH_RESULTS' => 'Resultados de la B&uacute;squeda',  
  
  // Dashlet Categories
  'dashlet_categories_dom' => array(
      'Module Views' => 'Vistas del Módulo',
      'Portal' => 'Portal',
      'Charts' => 'Gráficos',
      'Tools' => 'Herramientas',
      'Miscellaneous' => 'Varios'),
  'LBL_MAX_DASHLETS_REACHED' => 'Ha alcanzado el número máximo de dashlets que su administrador ha establecido. Por favor, quite un dashlet poder añadir más.',
  'LBL_ADDING_DASHLET' => 'Agregar Dashlet ...',
  'LBL_ADDED_DASHLET' => 'Dashlet Agregado',
  'LBL_REMOVE_DASHLET_CONFIRM' => '¿Está seguro de que desea quitar el Dashlet?',
  'LBL_REMOVING_DASHLET' => 'Quitando Dashlet ...',
  'LBL_REMOVED_DASHLET' => 'Dashlet Quitado',
  'LBL_DASHLET_CONFIGURE_GENERAL' => 'General',
  'LBL_DASHLET_CONFIGURE_FILTERS' => 'Filtros',
  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Sólo Mis Ítems',
  'LBL_DASHLET_CONFIGURE_TITLE' => 'Título',
  'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Mostrar Filas',
//  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Sólo Mis Ítems',

  'LBL_DASHLET_DELETE' => 'Eliminar Dashlet',
  'LBL_DASHLET_REFRESH' => 'Actualizar Dashlet',
  'LBL_DASHLET_EDIT' => 'Editar Dashlet', 
  
  'LBL_TRAINING_TITLE' => 'Formación',
  
    'LBL_CREATING_NEW_PAGE' => 'Creando Nueva p&aacute;gina...',
  'LBL_NEW_PAGE_FEEDBACK' => 'Usted ha creado una nueva p&aacute;gina. Usted puede agregar nuevo contenido con la opci&oacute;n de Agregar Dashlet.',
  'LBL_DELETE_PAGE_CONFIRM' => 'Esta usted seguro que quiere eliminar esta p&aacute;gina?',
  'LBL_SAVING_PAGE_TITLE' => 'Guardando Titulo de P&aacute;gina...',  
  'LBL_RETRIEVING_PAGE' => 'Recuperando P&aacute;gina...',
  
  // Default out-of-box names for tabs
  'LBL_HOME_PAGE_1_NAME' => 'Mi Sugar',
  'LBL_HOME_PAGE_2_NAME' => 'P&aacute;gina de Ventas',
  'LBL_HOME_PAGE_3_NAME' => 'P&aacute;gina de Marketing & Soporte',
  
  'LBL_CLOSE_SITEMAP' =>'Cerrar',
  
  'LBL_SEARCH' => 'Buscar',
  'LBL_CLEAR' => 'Limpiar', 
  
  'LBL_BASIC_CHARTS' => 'Gr&aacute;ficos Basicos',
  'LBL_REPORT_CHARTS' => 'Gr&aacute;ficos de Reportes',
  
  'LBL_MY_FAVORITE_REPORT_CHARTS' => 'Mis Reportes Favoritos',
  'LBL_GLOBAL_REPORT_CHARTS' => 'Reportes del Equipo Global',
  'LBL_MY_TEAM_REPORT_CHARTS' => 'Mis reportes de equipo',
  'LBL_MY_SAVED_REPORT_CHARTS' => 'Mis reportes Guardados',
  
  'LBL_DASHLET_SEARCH' => 'Encontrar Dashlet',
  
);


?>
