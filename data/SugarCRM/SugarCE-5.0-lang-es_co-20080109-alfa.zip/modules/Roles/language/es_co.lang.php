<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_ROLE' => 'Rol: ',
  'LBL_LANGUAGE' => 'Lenguaje: ',
  'LBL_MODULE_NAME' => 'Roles',
  'LBL_MODULE_TITLE' => 'Roles: Inicio',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Roles',
  'LBL_LIST_FORM_TITLE' => 'Lista de Roles',
  'LNK_NEW_ROLE' => 'Crear Rol',
  'LNK_ROLES' => 'Roles',
  'LBL_NAME' => 'Nombre: ',
  'LBL_DESCRIPTION' => 'Descripción: ',
  'LBL_ALLOWED_MODULES' => 'Módulos Permitidos: ',
  'LBL_DISALLOWED_MODULES' => 'Módulos No Permitidos: ',
  'LBL_ASSIGN_MODULES' => 'Editar Módulos: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Roles',
  'LBL_USERS' => 'Usuarios',
  'LBL_USERS_SUBPANEL_TITLE' => 'Usuarios',
);


?>