<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Seguimiento de Incidencias',
  'LBL_MODULE_TITLE' => 'Seguimiento de Incidencias: Inicio',
  'LBL_MODULE_ID' => 'Incidencias',  
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda de Incidencias',
  'LBL_LIST_FORM_TITLE' => 'Lista de Incidencias',
  'LBL_NEW_FORM_TITLE' => 'Nueva Incidencia',
  'LBL_CONTACT_BUG_TITLE' => 'Contacto-Incidencia:',
  'LBL_SUBJECT' => 'Asunto:',
  'LBL_BUG' => 'Incidencia:',
  'LBL_BUG_NUMBER' => 'Número de Incidencia:',
  'LBL_NUMBER' => 'Número:',
  'LBL_STATUS' => 'Estado:',
  'LBL_PRIORITY' => 'Prioridad:',
  'LBL_DESCRIPTION' => 'Descripción:',
  'LBL_CONTACT_NAME' => 'Contacto:',
  'LBL_BUG_SUBJECT' => 'Asunto de la Incidencia:',
  'LBL_CONTACT_ROLE' => 'Rol:',
  'LBL_LIST_NUMBER' => 'Núm.',
  'LBL_LIST_SUBJECT' => 'Asunto',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_LIST_PRIORITY' => 'Prioridad',
  'LBL_LIST_RELEASE' => 'Release',
  'LBL_LIST_RESOLUTION' => 'Resolución',
  'LBL_LIST_LAST_MODIFIED' => 'Modificado',
  'LBL_INVITEE' => 'Contactos',
  'LBL_TYPE' => 'Tipo:',
  'LBL_LIST_TYPE' => 'Tipo',
  'LBL_RESOLUTION' => 'Resolución:',
  'LBL_RELEASE' => 'Release:',
  'LNK_NEW_BUG' => 'Informe de Incidencia',
  'LNK_BUG_LIST' => 'Incidencias',
  'NTC_REMOVE_INVITEE' => '¿Está seguro de que desea quitar este contacto de la incidencia?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => '¿Está seguro de que desea mover esta incidencia fuera de esta cuenta?',
  'ERR_DELETE_RECORD' => 'Debe especificar un número de registro para eliminar esta incidencia.',
  'LBL_LIST_MY_BUGS' => 'Mis Incidencias Asignadas',
  'LBL_FOUND_IN_RELEASE' => 'Encontrado en Lanzamiento:',
  'LBL_FIXED_IN_RELEASE' => 'Corregido en Lanzamiento:',
  'LBL_LIST_FIXED_IN_RELEASE' => 'Corregido en Lanzamiento',  
  'LBL_WORK_LOG' => 'Registro de Trabajo:',
  'LBL_SOURCE' => 'Fuente:',
  'LBL_PRODUCT_CATEGORY' => 'Categoría:',
  'LBL_CREATED_BY' => 'Creado por:',
  'LBL_DATE_CREATED' => 'Fecha de creación:',
  'LBL_MODIFIED_BY' => 'Modificado por:',
  'LBL_DATE_LAST_MODIFIED' => 'Fecha de modifiación:',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Contacto',
  'LBL_LIST_ACCOUNT_NAME' => 'Cuenta',
  'LBL_LIST_PHONE' => 'Teléfono',
  'NTC_DELETE_CONFIRMATION' => '¿Está seguro de que desea quitar este contacto de esta incidencia?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Seguimiento de Incidencias',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Actividades',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Historial',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contactos',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Cuentas',
  'LBL_CASES_SUBPANEL_TITLE' => 'Casos',
  'LBL_SYSTEM_ID' => 'ID Sistema',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Usuario Asignado',
  'LNK_BUG_REPORTS' => 'Informes de Incidencias',
);
?>
