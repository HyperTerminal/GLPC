<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004 - 2007 SugarCRM Inc.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 * the terms of the GNU General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * Software distributed WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is: SugarCRM Enterprise
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): Euclides Rodriguez EJ Web Solutions (euclides.rodriguez@gmail.com).
 ********************************************************************************/
/*********************************************************************************
 * Monday 07/january/2008
 ********************************************************************************/

$mod_strings = array(
	'DESC_MODULES_INSTALLED'					=> 'Los siguientes módulos han sido instalados:',
	'DESC_MODULES_QUEUED'						=> 'Los siguientes módulos están listos para ser instalados:',
	
	'ERR_UW_CANNOT_DETERMINE_GROUP'				=> 'No se ha podido determinar el Grupo',
	'ERR_UW_CANNOT_DETERMINE_USER'				=> 'No se ha podido determinar el Propietario',
	'ERR_UW_CONFIG_WRITE'						=> 'Error al actualizar config.php con la información de la nueva versión.',
	'ERR_UW_CONFIG'								=> 'Por favor, de permisos de escritura para su archivo config.php, y recargue esta página.',
	'ERR_UW_DIR_NOT_WRITABLE'					=> 'Directorio no escribible',
	'ERR_UW_FILE_NOT_COPIED'					=> 'Archivo no copiado',
	'ERR_UW_FILE_NOT_DELETED'					=> 'Problema al quitar el paquete ',
	'ERR_UW_FILE_NOT_READABLE'					=> 'El archivo no ha podido ser leído.',
	'ERR_UW_FILE_NOT_WRITABLE'					=> 'El archivo no ha podido ser movido o escrito',
	'ERR_UW_FLAVOR_2'							=> 'Edición de la Actualización: ',
	'ERR_UW_FLAVOR'								=> 'Edición del Sistema SugarCRM: ',
	'ERR_UW_LOG_FILE_UNWRITABLE'				=> './upgradeWizard.log no ha podido ser creado/escrito.  Por favor, corrija los permisos en su directorio de SugarCRM.', 
	'ERR_UW_MBSTRING_FUNC_OVERLOAD'				=> 'mbstring.func_overload está establecido a un valor mayor que 1.  Por favor, cambie esto en su archivo php.ini y reinicie su servidor web.', 
	'ERR_UW_MYSQL_VERSION'						=> 'SugarCRM requiere MySQL versión 4.1.2 o mayor.  Encontrada: ',
	'ERR_UW_NO_FILE_UPLOADED'					=> '¡Por favor, especifique un archivo e inténtelo de nuevo!',
	'ERR_UW_NO_FILES'							=> 'Ha ocurrido un error, no se han encontrado archivos para comprobar.',
	'ERR_UW_NO_MANIFEST'						=> 'El archivo zip no contiene un archivo manifest.php.  No se puede continuar.',
	'ERR_UW_NO_VIEW'							=> 'La vista especificada no es válida.',
	'ERR_UW_NO_VIEW2'							=> 'La vista no ha sido definida.  Por favor, vaya al inicio de Administración para navegar a esta página.',
	'ERR_UW_NOT_VALID_UPLOAD'					=> 'No es una subida de fichero válida.',
	'ERR_UW_NO_CREATE_TMP_DIR'					=> 'No ha podido crearse el directorio temporal. Compruebe los permisos de ficheros.',
	'ERR_UW_ONLY_PATCHES'						=> 'Sólo puede subir parches en esta página.',
	'ERR_UW_PREFLIGHT_ERRORS'					=> 'Se han encontrado errores durante la comprobación previa',
	'ERR_UW_UPLOAD_ERR'							=> '¡Ha ocurrido un error al subir el archivo, por favor inténtelo de nuevo!<br>\n',
	'ERR_UW_VERSION'							=> 'Versión del Sistema SugarCRM: ',
	'ERR_UW_WRONG_TYPE'							=> 'Esta página no es para ejecutar ',
	'ERR_UW_PHP_FILE_ERRORS'					=> array(
													1 => 'El archivo subido excede el límite definido por la directiva upload_max_filesize en php.ini.',
													2 => 'El archivo subido excede el límite definido por la directiva MAX_FILE_SIZE especificada en el formulario HTML.',
													3 => 'El archivo ha sido sólo parcialmente subido.',
													4 => 'No se ha subido ningún archivo.',
													5 => 'Error desconocido.',
													6 => 'Falta una carpeta temporal.',
													7 => 'Error al escribir el archivo.',
													8 => 'El archivo subido ha sido bloqueado por su extensión.',
												),
	
	'LBL_BUTTON_BACK'							=> 'Atrás',
	'LBL_BUTTON_CANCEL'							=> 'Cancelar',
	'LBL_BUTTON_DELETE'							=> 'Eliminar Paquete',
	'LBL_BUTTON_DONE'							=> 'Hecho',
	'LBL_BUTTON_INSTALL'						=> 'Inspección para Actualización',
	'LBL_BUTTON_NEXT'							=> 'Siguiente',
	'LBL_BUTTON_RECHECK'						=> 'Comprobar de nuevo',

	'LBL_UPLOAD_UPGRADE'						=> 'Subir una actualización: ',

	'LBL_UW_BACKUP_FILES_EXIST_TITLE'			=> 'Copia de seguridad',
	'LBL_UW_BACKUP_FILES_EXIST'					=> 'La copia de seguridad de los archivos de esta actualización pueden encontrarse en',
	'LBL_UW_BACKUP'								=> 'Copia de seguridad',
	'LBL_UW_CANCEL_DESC'						=> 'El Asistente de Actualizaciones ha sido cancelado.  Todos los archivos temporales y el archivo zip subido han sido eliminados.<br><br>Presione "Siguiente" para iniciar de nuevo el Asistente de Actualizaciones.',
	'LBL_UW_CHARSET_SCHEMA_CHANGE'				=> 'Cambios de Juego de Caracteres en el Esquema',
	'LBL_UW_CHECK_ALL'							=> 'Comprobar Todo',
	'LBL_UW_CHECKLIST'							=> 'Pasos de la Actualización',
	'LBL_UW_COMMIT_ADD_TASK_DESC_1'				=> "Las copias de seguridad de todos los archivos sobrescritos están en el siguiente directorio: \n",
	'LBL_UW_COMMIT_ADD_TASK_DESC_2'				=> "Combinar manualmente los siguientes archivos:\n",
	'LBL_UW_COMMIT_ADD_TASK_NAME'				=> 'Proceso de Actualización: Combinar Manualmente Archivos',
	'LBL_UW_COMMIT_ADD_TASK_OVERVIEW'			=> 'Por favor, utilice cualquier el método diff que le sea más familiar para combinar estos archivos.  Hasta que no haya completado este proceso, su instalación de SugarCRM estará en un estado incierto, y la actualización no será completa.',
	'LBL_UW_COMPLETE'							=> 'Completado',

	'LBL_UW_COMPLIANCE_ALL_OK'					=> 'Todos los requerimientos del sistema han sido satisfechos',
	'LBL_UW_COMPLIANCE_CALLTIME'				=> 'Configuración de PHP: Paso por Referencia en Tiempo de LLamada',
	'LBL_UW_COMPLIANCE_CURL'					=> 'Módulo cURL',
	'LBL_UW_COMPLIANCE_IMAP'					=> 'Módulo IMAP',
	'LBL_UW_COMPLIANCE_MBSTRING'				=> 'Módulo MBStrings',
	'LBL_UW_COMPLIANCE_MBSTRING_FUNC_OVERLOAD'	=> 'Parámetro mbstring.func_overload de MBStrings',
	'LBL_UW_COMPLIANCE_MEMORY'					=> 'Configuración de PHP: Límite de Memoria',
	'LBL_UW_COMPLIANCE_MSSQL_MAGIC_QUOTES'		=> 'MS SQL Server & PHP Magic Quotes GPC',
	'LBL_UW_COMPLIANCE_MYSQL'					=> 'Versión Mínima de MySQL',
	'LBL_UW_COMPLIANCE_PHP_INI'					=> 'Ruta de php.ini',
	'LBL_UW_COMPLIANCE_PHP_VERSION'				=> 'Versión Mínima de PHP',
	'LBL_UW_COMPLIANCE_SAFEMODE'				=> 'Configuración de PHP: Modo Seguro',
	'LBL_UW_COMPLIANCE_TITLE'					=> 'Comprobación de Configuración del Servidor',
	'LBL_UW_COMPLIANCE_TITLE2'					=> 'Configuración Detectada',
	'LBL_UW_COMPLIANCE_XML'						=> 'Análisis XML',

	'LBL_UW_COPIED_FILES_TITLE'					=> 'Archivos Copiados con Éxito',
	'LBL_UW_CUSTOM_TABLE_SCHEMA_CHANGE'			=> 'Cambios al Esquema en Tablas Personalizadas',

	'LBL_UW_DB_CHOICE1'							=> 'El Asistente de Actualizaciones ejecutará el SQL',
	'LBL_UW_DB_CHOICE2'							=> 'Consultas de SQL Lanzadas Manualmente',
	'LBL_UW_DB_INSERT_FAILED'					=> 'Fallo en INSERT - los resultados comparados difieren',
	'LBL_UW_DB_ISSUES_PERMS'					=> 'Privilegios de Base de datos',
	'LBL_UW_DB_ISSUES'							=> 'Problemas de Base de datos',
	'LBL_UW_DB_METHOD'							=> 'Método de Actualización en Base de Datos',
	'LBL_UW_DB_NO_ADD_COLUMN'					=> 'ALTER TABLE [table] ADD COLUMN [column]',
	'LBL_UW_DB_NO_CHANGE_COLUMN'				=> 'ALTER TABLE [table] CHANGE COLUMN [column]',
	'LBL_UW_DB_NO_CREATE'						=> 'CREATE TABLE [table]',
	'LBL_UW_DB_NO_DELETE'						=> 'DELETE FROM [table]',
	'LBL_UW_DB_NO_DROP_COLUMN'					=> 'ALTER TABLE [table] DROP COLUMN [column]',
	'LBL_UW_DB_NO_DROP_TABLE'					=> 'DROP TABLE [table]',
	'LBL_UW_DB_NO_ERRORS'						=> 'Todos los Privilegios Disponibles',
	'LBL_UW_DB_NO_INSERT'						=> 'INSERT INTO [table]',
	'LBL_UW_DB_NO_SELECT'						=> 'SELECT [x] FROM [table]',
	'LBL_UW_DB_NO_UPDATE'						=> 'UPDATE [table]',
	'LBL_UW_DB_PERMS'							=> 'Privilegio Necesario',

	'LBL_UW_DESC_MODULES_INSTALLED'				=> 'Las siguientes actualizaciones se han instalado:',
	'LBL_UW_END_DESC'							=> 'Enhorabuena, su sistema ha sido actualizado.',
	'LBL_UW_END_DESC2'							=> 'Si ha escogido ejecutar manualmente cualquier paso como las combinaciones de archivos o las consultas SQL, por favor hágalo ahora.  Su sistema estará en un estado inestable hasta que estos pasos se hayan completado.',
	'LBL_UW_END_LOGOUT'							=> 'Por favor, cierre su sesión si planea realizar más actualizaciones además de este parche/nivel de actualización.',
	'LBL_UW_END_LOGOUT2'						=> 'Cerrar sesión',
	'LBL_UW_REPAIR_INDEX'						=> 'Para mejoras en el rendimiento de base de datos, por favor ejecute el <a href="index.php?module=Administration&action=RepairIndex" target="_blank">script de Reparación de Índices</a>.',	

	'LBL_UW_FILE_DELETED'						=> " ha sido eliminado.<br>",
	'LBL_UW_FILE_GROUP'							=> 'Grupo',
	'LBL_UW_FILE_ISSUES_PERMS'					=> 'Permisos de Archivo',
	'LBL_UW_FILE_ISSUES'						=> 'Problemas con Archivos',
	'LBL_UW_FILE_NEEDS_DIFF'					=> 'El Archivo Requiere un Diff Manual',
	'LBL_UW_FILE_NO_ERRORS'						=> '<b>Todos los Archivos son Escribibles</b>',
	'LBL_UW_FILE_OWNER'							=> 'Propietario',
	'LBL_UW_FILE_PERMS'							=> 'Permisos',
	'LBL_UW_FILE_UPLOADED'						=> ' ha sido subido',
	'LBL_UW_FILE'								=> 'Nombre de Archivo',
	'LBL_UW_FILES_QUEUED'						=> 'Las siguientes actualizaciones están listas para ser instaladas:',
	'LBL_UW_FILES_REMOVED'						=> "Los siguientes archivos serán quitados del sistema:<br>\n",

	'LBL_UW_FROZEN'								=> 'Debe realizar los siguientes pasos antes de continuar.',
	'LBL_UW_HIDE_DETAILS'						=> 'Ocultar Detalles',
	'LBL_UW_IN_PROGRESS'						=> 'En Progreso',
	'LBL_UW_INCLUDING'							=> 'Incluyendo',
	'LBL_UW_INCOMPLETE'							=> 'Incompleto',
	'LBL_UW_INSTALL'							=> 'INSTALACIÓN de Archivo',
	'LBL_UW_MANUAL_MERGE'						=> 'Combinación de Archivos',
	'LBL_UW_MODULE_READY_UNINSTALL'				=> "El módulo está listo para ser desinstalado.  Haga clic en \"Proceder\" para proceder con la instalación.<br>\n",
	'LBL_UW_MODULE_READY'						=> "El módulo está listo para ser instalado.  Haga clic en \"Proceder\" para proceder con la instalación.",
	'LBL_UW_NO_INSTALLED_UPGRADES'				=> 'No se han detectado Actualizaciones registradas.',
	'LBL_UW_NONE'								=> 'Ninguno',
	'LBL_UW_NOT_AVAILABLE'						=> 'No disponible',
	'LBL_UW_OVERWRITE_DESC'						=> "Todos los archivos cambiados serán sobrescritos - incluyendo cualquier personalización al código fuente y cambios las plantillas que haya podido realizar. ¿Está seguro de que desea proceder?",
	'LBL_UW_OVERWRITE_FILES_CHOICE1'			=> 'Sobrescribir Todos los Archivos',
	'LBL_UW_OVERWRITE_FILES_CHOICE2'			=> 'Combinación Manual - Preservar Todo',
	'LBL_UW_OVERWRITE_FILES'					=> 'Método de Combinación',
	'LBL_UW_PATCH_READY'						=> 'El parche está preparado para ser procesado. Haga clic en el botón "Proceder" para completar el proceso de actualización.',
	'LBL_UW_PATCH_READY2'						=> '<h2>Aviso: Se han Encontrado Diseños Personalizados</h2><br />Los siguientes archivos tienen campos nuevos o diseños de pantalla modificados aplicados vía el Estudio. El parche que va a instalar también contiene cambios a los archivos. Para <u>cada archivo</u> puede:<br><ul><li>[<b>Por defecto</b>] Mantener su versión dejando en blanco la casilla. Las modificaciones contenidas en el parche serán ignoradas.</li>o<li>Aceptar los archivos actualizados marcando la casilla. Sus diseños necesitarán ser aplicados de nuevo vía el Estudio.</li></ul>',

	'LBL_UW_PREFLIGHT_ADD_TASK'					=> '¿Crear Tarea para Combinación Manual?',
	'LBL_UW_PREFLIGHT_COMPLETE'					=> 'Comprobaciones Previas',
	'LBL_UW_PREFLIGHT_DIFF'						=> 'Diferenciados ',
	'LBL_UW_PREFLIGHT_EMAIL_REMINDER'			=> 'Enviarse a si mismo un Email Recordatorio para la Combinación Manual?',
	'LBL_UW_PREFLIGHT_FILES_DESC'				=> 'Los siguientes archivos han sido modificados.  Desmarque los ítems que requieren una combinación manual. <i>Los cambios de diseño detectados son desmarcados automáticamente; marque los que deberían ser sobrescritos.',
	'LBL_UW_PREFLIGHT_NO_DIFFS'					=> 'No se Requiere Combinación Manual de Archivos.',
	'LBL_UW_PREFLIGHT_NOT_NEEDED'				=> 'No es necesario.',
	'LBL_UW_PREFLIGHT_PRESERVE_FILES'			=> 'Archivos Auto-preservados:',
	'LBL_UW_PREFLIGHT_TESTS_PASSED'				=> 'Todos los tests de inspección previa han sido satisfactorios. Presione "Siguiente" para proceder con estos cambios.',
	'LBL_UW_PREFLIGHT_TOGGLE_ALL'				=> 'Cambiar Todos los Archivos',

	'LBL_UW_REBUILD_TITLE'						=> 'Reconstruir Resultado',
	'LBL_UW_SCHEMA_CHANGE'						=> 'Cambios en el Esquema',

	'LBL_UW_SHOW_COMPLIANCE'					=> 'Mostrar Configuración Detectada',
	'LBL_UW_SHOW_DB_PERMS'						=> 'Mostrar Permisos de Base de datos que Faltan',
	'LBL_UW_SHOW_DETAILS'						=> 'Mostrar Detalles',
	'LBL_UW_SHOW_DIFFS'							=> 'Mostrar Archivos que Requieren Combinanción Manual',
	'LBL_UW_SHOW_NW_FILES'						=> 'Mostrar Archivos con Permisos Incorrectos',
	'LBL_UW_SHOW_SCHEMA'						=> 'Mostrar Script de Cambios al Esquema',
	'LBL_UW_SHOW_SQL_ERRORS'					=> 'Mostrar Consultas Erróneas',
	'LBL_UW_SHOW'								=> 'Mostrar',

	'LBL_UW_SKIPPED_FILES_TITLE'				=> 'Archivos Omitidos',
	'LBL_UW_SKIPPING_FILE_OVERWRITE'			=> 'Omitiendo Sobrescritura de Archivos - Seleccionada Combinación Manual.',
	'LBL_UW_SQL_RUN'							=> 'Comprobar cuando se haya ejecutado el SQL manualmente',
	'LBL_UW_START_DESC'							=> 'Bienvenido al Asistente de Actualizaciones de SugarCRM. Este asistente está diseñado para asistir a los administradores en la actualización de sus instancias de SugarCRM.  Por favor, siga con atención las instrucciones indicadas.',
	'LBL_UW_START_DESC2'						=> 'Recomendamos encarecidamente que la actualización se realice contra una instancia clonada de su servidor en producción.  Por favor, haga una copia de su base de datos y de sus archivos de sistema (todos los archivos de su carpeta de SugarCRM) antes de realizar esta operación.', 
	'LBL_UW_START_UPGRADED_UW_DESC'				=> 'El nuevo Asistente de Actualizaciones continuará con el proceso de instalación. Por favor, continue con su actualización.',
	'LBL_UW_START_UPGRADED_UW_TITLE'			=> 'Bienvenido al nuevo Asistente de Actualizaciones',

	'LBL_UW_SYSTEM_CHECK_CHECKING'				=> 'Realizando comprobaciones. Espere, por favor.  Esto podría tardar unos 30 segundos.',
	'LBL_UW_SYSTEM_CHECK_FILE_CHECK_START'		=> 'Buscando todos los archivos a comprobar.',
	'LBL_UW_SYSTEM_CHECK_FILES'					=> 'Archivos',
	'LBL_UW_SYSTEM_CHECK_FOUND'					=> 'Encontrados',

	'LBL_UW_TITLE_CANCEL'						=> 'Cancelar',
	'LBL_UW_TITLE_COMMIT'						=> 'Realizar Actualización',
	'LBL_UW_TITLE_END'							=> 'Informe',
	'LBL_UW_TITLE_PREFLIGHT'					=> 'Comprobaciones Previas',
	'LBL_UW_TITLE_START'						=> 'Iniciar',
	'LBL_UW_TITLE_SYSTEM_CHECK'					=> 'Comprobaciones del Sistema',
	'LBL_UW_TITLE_UPLOAD'						=> 'Subir Actualización',
	'LBL_UW_TITLE'								=> 'Asistente de Actualizaciones',
	'LBL_UW_UNINSTALL'							=> 'Desinstalar',
	
);
?>
