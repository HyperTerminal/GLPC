<?php
// $Id: manifest.php,v 1.0 2007/12/26 19:59:23 eucrod Exp $
// manifest file for information regarding application of new code
$manifest = array(
	// only install on the following regex sugar versions (if empty, no check) 
    'acceptable_sugar_versions' =>
    array (
		'exact_matches' => array (
		),
		'regex_matches' => array (
			'5\.0[e-z]?'
		),
    ),
    'acceptable_sugar_flavors' =>
    array (
        0 => 'CE',
    ),

    // name of new code
    'name' => 'Paquete Espa&ntilde;ol (Colombia)',

    // description of new code
    'description' => 'Paquete de lenguaje Espa&ntilde;ol (Colombia)',

    // author of new code
    'author' => 'Euclides Rodriguez',

    // date published
    'published_date' => '2007/12/26',

    // version of code
    'version' => '5.0 CE',

    // type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',

    // icon for displaying in UI (path to graphic contained within zip package)
    'icon' => 'include/images/flag-es_CO.jpg',
    
    'is_uninstallable' => TRUE,
    
);



$installdefs = array(
	'id'=> 'es_co',
	);
?>
