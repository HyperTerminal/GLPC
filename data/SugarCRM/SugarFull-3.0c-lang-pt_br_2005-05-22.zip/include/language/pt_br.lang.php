<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' => 
  array (
    'Home' => 'Principal',
    'Dashboard' => 'Painel',
    'Contacts' => 'Contatos',
    'Accounts' => 'Contas',
    'Opportunities' => 'Oportunidades',
    'Cases' => 'Ocorr�ncias',
    'Notes' => 'Anota��es',
    'Calls' => 'Chamadas',
    'Emails' => 'Emails',
    'Meetings' => 'Compromissos',
    'Tasks' => 'Tarefas',
    'Calendar' => 'Agenda',
    'Leads' => 'Potenciais',

    'Quotes' => 'Cota��es',
    'Products' => 'Produtos',
    'Reports' => 'Relat�rios',
    'Forecasts' => 'Previs�es',

    'Activities' => 'Atividades',
    'Bugs' => 'Bugs',
    'Feeds' => 'RSS',
    'iFrames' => 'Meu Portal',
    'TimePeriods'=>'Per�odos',
    'Project'=>'Projetos',
    'ProjectTask'=>'Tarefas de Projetos',
    'Campaigns'=>'Campanhas',
    'Documents'=>'Documentos',
  ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' => 
  array (
    '' => '',
    'Analyst' => 'Analista',
    'Competitor' => 'Concorrente',
    'Customer' => 'Cliente',
    'Integrator' => 'Integrador',
    'Investor' => 'Investidor',
    'Partner' => 'Parceiro',
    'Press' => 'Imprensa',
    'Prospect' => 'Poss�vel Cliente',
    'Reseller' => 'Revendedor',
    'Other' => 'Outro',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' => 
  array (
    '' => '',
    'Apparel' => 'T�xtil',
    'Banking' => 'Banco',
    'Biotechnology' => 'Biotecnologia',
    'Chemicals' => 'Qu�mica',
    'Communications' => 'Comunica��es',
    'Construction' => 'Constru��o',
    'Consulting' => 'Consultoria',
    'Education' => 'Ensino',
    'Electronics' => 'Eletr�nicos',
    'Energy' => 'Energia',
    'Engineering' => 'Engenharia',
    'Entertainment' => 'Entretenimento',
    'Environmental' => 'Ambiental',
    'Finance' => 'Financeira',
    'Government' => 'Governo',
    'Healthcare' => 'Sa�de',
    'Hospitality' => 'Hotelaria',
    'Insurance' => 'Seguros',
    'Machinery' => 'Maquin�rio',
    'Manufacturing' => 'Manufatura',
    'Media' => 'Meios de Comunica��o',
    'Not For Profit' => 'Sem Fins Lucrativos',
    'Recreation' => 'Recrea��o',
    'Retail' => 'Revenda/Varejo',
    'Shipping' => 'Envio',
    'Technology' => 'Tecnologia',
    'Telecommunications' => 'Telecomunica��es',
    'Transportation' => 'Transportes',
    'Utilities' => 'Servi�os P�blicos (Utilities)',
    'Other' => 'Outro',
    'Food & Beverage' => 'Alimentos & Bebidas',
  ),
  'lead_source_default_key' => 'Self Generated',
  'lead_source_dom' => 
  array (
    '' => '',
    'Cold Call' => 'Ativo (Cold Call)',
    'Existing Customer' => 'Cliente Existente',
    'Self Generated' => 'Auto Gerada',
    'Employee' => 'Colaborador',
    'Partner' => 'Parceiro',
    'Public Relations' => 'Rela��es P�blicas',
    'Direct Mail' => 'Mala Direta',
    'Conference' => 'Confer�ncia',
    'Trade Show' => 'Feira/Evento',
    'Web Site' => 'Site Web',
    'Word of mouth' => 'Boca-a-boca',
    'Other' => 'Outro',
  ),
  'opportunity_type_dom' => 
  array (
    '' => '',
    'Existing Business' => 'Neg�cios Existentes',
    'New Business' => 'Novos Neg�cios',
  ),
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Decisor Principal',
    'Business Decision Maker' => 'Decisor de Neg�cios',
    'Business Evaluator' => 'Avaliador de Neg�cios',
    'Technical Decision Maker' => 'Decisor T�cnico',
    'Technical Evaluator' => 'Avaliador T�cnico',
    'Executive Sponsor' => 'Patrocinador Executivo',
    'Influencer' => 'Influenciador',
    'Other' => 'Outro',
  ),
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Contact' => 'Contato Principal',
    'Alternate Contact' => 'Contato Alternativo',
  ),
  'sales_stage_default_key' => 'Prospecting',
  'sales_stage_dom' => 
  array (
    'Prospecting' => 'Prospec��o',
    'Qualification' => 'Qualifica��o',
    'Needs Analysis' => 'An�lise Necessidades',
    'Value Proposition' => 'Proposi��o Valor',
    'Id. Decision Makers' => 'Identific. Decisores',
    'Perception Analysis' => 'An�lise Percep��o',
    'Proposal/Price Quote' => 'Proposta/Pre�o',
    'Negotiation/Review' => 'Negocia��o/Revis�o',
    'Closed Won' => 'Ganhamos',
    'Closed Lost' => 'Perdemos',
  ),
  'activity_dom' => 
  array (
    'Call' => 'Chamada',
    'Meeting' => 'Compromisso',
    'Task' => 'Tarefa',
    'Email' => 'Email',
    'Note' => 'Anota��o',
  ),
  'salutation_dom' => 
  array (
    '' => '',
    'Mr.' => 'Sr.',
    'Ms.' => 'Srta.',
    'Mrs.' => 'Sra.',
    'Dr.' => 'Dr.',
    'Prof.' => 'Prof.',
  ),
  //time is in seconds; the greater the time the longer it takes;
  'reminder_max_time' => 3600,
  'reminder_time_options' => 
  array( 
    60=> '1 minuto antes',
    300=> '5 minutos antes',
    600=> '10 minutos antes',
    900=> '15 minutos antes',
    1800=> '30 minutos antes',
    3600=> '1 hora antes',
  ),
  'task_priority_default' => 'Medium',
  'task_priority_dom' => 
  array (
    'High' => 'Alta',
    'Medium' => 'M�dia',
    'Low' => 'Baixa',
  ),
  'task_status_default' => 'Not Started',
  'task_status_dom' => 
  array (
    'Not Started' => 'N�o Iniciada',
    'In Progress' => 'Em Progresso',
    'Completed' => 'Terminada',
    'Pending Input' => 'Informa��o Pendente',
    'Deferred' => 'Adiada',
  ),
  'meeting_status_default' => 'Planned',
  'meeting_status_dom' => 
  array (
    'Planned' => 'Planejada',
    'Held' => 'Realizada',
    'Not Held' => 'N�o Realizada',
  ),
  'call_status_default' => 'Held',
  'call_status_dom' => 
  array (
    'Planned' => 'Planejada',
    'Held' => 'Realizada',
    'Not Held' => 'N�o Realizada',
  ),
  'call_direction_default' => 'Outbound',
  'call_direction_dom' => 
  array (
    'Inbound' => 'Entrada',
    'Outbound' => 'Sa�da',
  ),
  'lead_status_dom' => 
  array (
    '' => '',
    'New' => 'Novo',
    'Assigned' => 'Atribu�do',
    'In Process' => 'Em processo',
    'Converted' => 'Convertido',
    'Recycled' => 'Reciclado',
    'Dead' => 'Inoperante',
  ),
  'lead_status_noblank_dom' => 
  array (
    'New' => 'Novo',
    'Assigned' => 'Atribu�do',
    'In Process' => 'Em processo',
    'Converted' => 'Convertido',
    'Recycled' => 'Reciclado',
    'Dead' => 'Inoperante',
  ),
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' => 
  array (
    'New' => 'Novo',
    'Assigned' => 'Atribu�do',
    'Closed' => 'Encerrado',
    'Pending Input' => 'Informa��o Pendente',
    'Rejected' => 'Rejeitado',
    'Duplicate' => 'Duplicado',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' => 
  array (
    'P1' => 'Alta',
    'P2' => 'M�dia',
    'P3' => 'Baixa',
  ),
  'user_status_dom' => 
  array (
    'Active' => 'Ativo',
    'Inactive' => 'Inativo',
  ),
  'employee_status_dom' =>
  array (
    'Active' => 'Ativo',
    'Terminated' => 'Desligado',
    'Leave of Absence' => 'Licen�a',
  ),
  'messenger_type_dom' =>
  array (
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
    'AOL' => 'AOL',
  ),
  'project_task_priority_options' => 
  array (
    'High' => 'Alta',
    'Medium' => 'M�dia',
    'Low' => 'Baixa',
  ),
  'project_task_status_options' => 
  array (
    'Not Started' => 'N�o Iniciada',
    'In Progress' => 'Em Andamento',
    'Completed' => 'Conclu�da',
    'Pending Input' => 'Aguardando Entrada',
    'Deferred' => 'Adiada',
  ),
  'project_task_utilization_options' => 
  array (
    '0' => 'nada',
    '25' => '25',
    '50' => '50',
    '75' => '75',
    '100' => '100',
  ),
  'record_type_default_key' => 'Accounts',
  'record_type_display' => 
  array (
    'Accounts' => 'Contas',
    'Opportunities' => 'Oportunidades',
    'Cases' => 'Ocorr�ncias',
    'Leads' => 'Potenciais',

    'ProductTemplates' => 'Produto',
    'Quotes' => 'Cota��o',

    'Bugs' => 'Bug',
    'Project' => 'Projeto',
    'ProjectTask' => 'Tarefa do Projeto',

  ),
//       it is the key for the default record_type_module value
  'record_type_display_notes' => 
  array (
    'Accounts' => 'Conta',
    'Opportunities' => 'Oportunidade',
    'Cases' => 'Ocorr�ncia',
    'Leads' => 'Potencial',

    'ProductTemplates' => 'Produto',
    'Quotes' => 'Cota��o',

    'Bugs' => 'Bug',
    'Emails' => 'Email',
    'Project' => 'Projeto',
    'ProjectTask' => 'Tarefa do Projeto',
  ),
  'product_status_default_key' => 'Ship',
  'product_status_quote_key' => 'Quotes',
  'product_status_dom' => 
  array (
    'Quotes' => 'Cotado',
    'Orders' => 'Pedido',
    'Ship' => 'Enviado',
  ),
  'pricing_formula_default_key' => 'Fixed',
  'pricing_formula_dom' => 
  array (
    'Fixed' => 'Pre�o Fixo',
    'ProfitMargin' => 'Margem de Lucro',
    'PercentageMarkup' => 'Lucro sobre Custo',
    'PercentageDiscount' => 'Desconto da Lista',
    'IsList' => 'Mesmo da Lista',
  ),
  'product_template_status_dom' => 
  array (
    'Available' => 'Em Estoque',
    'Unavailable' => 'Fora de Estoque',
  ),
  'tax_class_dom' => 
  array (
    'Taxable' => 'Taxado',
    'Non-Taxable' => 'Isento',
  ),
  'support_term_dom' => 
  array (
    '+6 months' => 'Seis meses',
    '+1 year' => 'Um ano',
    '+2 years' => 'Dois anos',
  ),
  'quote_type_dom' => 
  array (
    'Quotes' => 'Cota��es',
    'Orders' => 'Pedidos',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' => 
  array (
    'Draft' => 'Rascunho',
    'Negotiation' => 'Negocia��o',
    'Delivered' => 'Entregue',
    'On Hold' => 'Suspenso',
    'Confirmed' => 'Confirmado',
    'Closed Accepted' => 'Fechamento Aceito',
    'Closed Lost' => 'Fechamento Perdido',
    'Closed Dead' => 'Fechamento Inoperante',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' => 
  array (
    'Pending' => 'Pendente',
    'Confirmed' => 'Confirmado',
    'On Hold' => 'Suspenso',
    'Shipped' => 'Entregue',
    'Cancelled' => 'Cancelado',
  ),
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' => 
  array (
    '' => '',
    'Primary Decision Maker' => 'Decisor Principal',
    'Business Decision Maker' => 'Decisor de Neg�cios',
    'Business Evaluator' => 'Avaliador de Neg�cios',
    'Technical Decision Maker' => 'Decisor T�cnico',
    'Technical Evaluator' => 'Avaliador T�cnico',
    'Executive Sponsor' => 'Patrocinador Executivo',
    'Influencer' => 'Influenciador',
    'Other' => 'Outro',
  ),
  'layouts_dom' => 
  array (
    'Standard' => 'Padr�o',
    'Terms' => 'Termos de Pagamento'
  ),
  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' => 
  array (
    'Urgent' => 'Urgente',
    'High' => 'Alto',
    'Medium' => 'M�dio',
    'Low' => 'Baixo',
  ),
  'bug_resolution_default_key' => '',
  'bug_resolution_dom' => 
  array (
    '' => '',
    'Accepted' => 'Aceito',
    'Duplicate' => 'Duplicado',
    'Fixed' => 'Corrigido',
    'Out of Date' => 'Obsoleto',
    'Invalid' => 'Inv�lido',
    'Later' => 'Tardio',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' => 
  array (
    'New' => 'Novo',
    'Assigned' => 'Atribu�do',
    'Closed' => 'Encerrado',
    'Pending' => 'Pendeite',
    'Rejected' => 'Rejeitado',
  ),
  'bug_type_default_key' => 'Bug',
  'bug_type_dom' => 
  array (
    'Defect' => 'Defeito',
    'Feature' => 'Caracter�stica',
  ),
  'source_default_key' => '',
  'source_dom' => 
  array (
    '' => '',
    'Internal' => 'Interno',
    'Forum' => 'Forum',
    'Web' => 'Web',
  ),
  'product_category_default_key' => '',
  'product_category_dom' => 
  array (
    '' => '',
    'Accounts' => 'Contas',
    'Activities' => 'Atividades',
    'Calendar' => 'Agenda',
    'Calls' => 'Chamadas',
    'Cases' => 'Ocorr�ncias',
    'Contacts' => 'Contatos',
    'Currencies' => 'Moedas',
    'Dashboard' => 'Painel',
    'Emails' => 'Emails',
    'Feeds' => 'Feeds',
    'Help' => 'Ajuda',
    'Home' => 'Principal',
    'Leads' => 'Potenciais',
    'Meetings' => 'Compromissos',
    'Notes' => 'Anota��es',
    'Opportunities' => 'Oportunidades',
    'Quotes' => 'Cota��es',
    'Releases' => 'Vers�es',
    'Users' => 'Usu�rios',
    'Outlook Plugin' => 'Outlook Plugin',
    'Upgrade' => 'Atualizar',
    'Studio' => 'Est�dio',
  ),
  'campaign_status_dom' =>
  array (
    '' => '',
        'Planning' => 'Planejamento',
        'Active' => 'Ativa',
        'Inactive' => 'Inativa',
        'Complete' => 'Finalizada',
  ),
  'campaign_type_dom' =>
  array (
        '' => '',
        'Telesales' => 'Televendas',
        'Mail' => 'Mala Direta',
        'Email' => 'Email',
        'Print' => 'Impresso',
        'Web' => 'Web',
        'Radio' => 'R�dio',
        'Television' => 'Televis�o',
  ),
  'notifymail_sendtype' => 
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => 
  array (
    '-12' => '(GMT - 12) International Date Line West',
    '-11' => '(GMT - 11) Midway Island, Samoa',
    '-10' => '(GMT - 10) Hawaii',
    '-9' => '(GMT - 9) Alaska',
    '-8' => '(GMT - 8) San Francisco',
    '-7' => '(GMT - 7) Phoenix',
    '-6' => '(GMT - 6) Saskatchewan',
    '-5' => '(GMT - 5) New York',
    '-4' => '(GMT - 4) Santiago',
    '-3' => '(GMT - 3) Buenos Aires',
    '-2' => '(GMT - 2) Mid-Atlantic',
    '-1' => '(GMT - 1) Azores',
    '0' => '(GMT)',
    '1' => '(GMT + 1) Madrid',
    '2' => '(GMT + 2) Athens',
    '3' => '(GMT + 3) Moscow',
    '4' => '(GMT + 4) Kabul',
    '5' => '(GMT + 5) Ekaterinburg',
    '6' => '(GMT + 6) Astana',
    '7' => '(GMT + 7) Bangkok',
    '8' => '(GMT + 8) Perth',
    '9' => '(GMT + 9) Seol',
    '10' => '(GMT + 10) Brisbane',
    '11' => '(GMT + 11) Solomone Is.',
    '12' => '(GMT + 12) Auckland',
  ),
  'dom_cal_month_long' => 
  array (
    '0' => '',
    '1' => 'Janeiro',
    '2' => 'Fevereiro',
    '3' => 'Mar�o',
    '4' => 'Abril',
    '5' => 'Maio',
    '6' => 'Junho',
    '7' => 'Julho',
    '8' => 'Agosto',
    '9' => 'Setembro',
    '10' => 'Outubro',
    '11' => 'Novembro',
    '12' => 'Dezembro',
  ),
  'dom_report_types' => 
  array (
    'tabular' => 'Linhas e Colunas',
    'summary' => 'Totalizado',
    'detailed_summary' => 'Totalizado com Detalhes',
  ),
  'dom_email_types' => 
  array (
    'out' => 'Enviado',
    'archived' => 'Arquivado',
    'draft' => 'Rascunho',
  ),
  'forecast_schedule_status_dom' =>
  array (
    'Active' => 'Ativa',
    'Inactive' => 'Inativa',
  ),
  'forecast_type_dom' =>
  array (
    'Direct' => 'Direto',
    'Rollup' => 'Agregado',
  ),  	
  'document_category_dom' =>
  array (
    '' => '',
    'Marketing' => 'Marketing',
    'Knowledege Base' => 'Base Conhecimento',
    'Sales' => 'Vendas',    
  ),  
  'document_subcategory_dom' =>
  array (
    '' => '',
    'Marketing Collateral' => 'Acess�rios',
    'Product Brochures' => 'Brochuras Produtos',
    'FAQ' => 'FAQ',
  ),  
  'document_status_dom' =>
  array (
    'Active' => 'Ativo',
    'Draft' => 'Rascunho',
    'FAQ' => 'FAQ',
    'Expired' => 'Expirado',
    'Under Review' => 'Em Revis�o',
    'Pending' => 'Pendente',
  ),
  'dom_meeting_accept_options' =>
  array (
    'accept' => 'Aceitar',
    'decline' => 'Recusar',
    'tentative' => 'Tentar',
  ),
  'dom_meeting_accept_status' =>
  array (
    'accept' => 'Aceito',
    'decline' => 'Recusado',
    'tentative' => 'Tentativa',
   ),
);

$app_strings = array (
  'LBL_SERVER_RESPONSE_TIME' => 'Tempo de resposta do servidor:',
  'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'segundos.',
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Minha conta',
  'LBL_EMPLOYEES' => 'RH',
  'LBL_ADMIN' => 'Admin',
  'LBL_LOGOUT' => 'Sair',
  'LBL_SEARCH' => 'Pesquisar',
  'LBL_LAST_VIEWED' => '�ltimos acessos',
  'NTC_WELCOME' => 'Bem-vindo',
  'NTC_SUPPORT_SUGARCRM' => 'Colabore com o projeto SugarCRM com uma doa��o atrav�s do PayPal - � r�pido, gr�tis e seguro!',
  'NTC_NO_ITEMS_DISPLAY' => 'nada',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Salvar [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Editar [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplicar [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplicar',
  'LBL_DELETE_BUTTON_TITLE' => 'Excluir [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Excluir',
  'LBL_NEW_BUTTON_TITLE' => 'Novo [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Alterar [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Cancelar [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Pesquisar [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Limpar [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Selecionar [Alt+T]',
  'LBL_ADD_BUTTON' => 'Incluir',
  'LBL_ADD_BUTTON_TITLE' => 'Incluir [Alt+A]',
  'LBL_ADD_BUTTON_KEY' => 'A',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Salvar',
  'LBL_EDIT_BUTTON_LABEL' => 'Editar',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplicar',
  'LBL_DELETE_BUTTON_LABEL' => 'Excluir',
  'LBL_NEW_BUTTON_LABEL' => 'Novo',
  'LBL_CHANGE_BUTTON_LABEL' => 'Alterar',
  'LBL_CANCEL_BUTTON_LABEL' => 'Cancelar',
  'LBL_SEARCH_BUTTON_LABEL' => 'Buscar',
  'LBL_CLEAR_BUTTON_LABEL' => 'Limpar',
  'LBL_NEXT_BUTTON_LABEL' => 'Pr�ximo',
  'LBL_SELECT_BUTTON_LABEL' => 'Selecionar',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Selecione Contato [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Visualizar PDF',
  'LBL_VIEW_PDF_BUTTON_TITLE' => 'Imprimir como PDF [Alt+P]',
  'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
  'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Criar Oportunidade a partir da Cota��o',
  'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Criar Oportunidade a partir da Cota��o [Alt+O]',
  'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Selecione Contato',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Selecione Usu�rio [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Selecione Usu�rio',
  'LBL_CREATE_BUTTON_LABEL' => 'Criar',
  'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'Selecionar Relat�rios',
  'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'Selecionar a partir de Relat�rios',
  'LBL_DONE_BUTTON_KEY' => 'X',
  'LBL_DONE_BUTTON_TITLE' => 'Feito [Alt+X]',
  'LBL_DONE_BUTTON_LABEL' => 'Feito',
  'LBL_SHORTCUTS' => 'Atalhos',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_TEAM' => 'Equipe',
  'LBL_LIST_USER_NAME' => 'Nome do Usu�rio',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Fone',
  'LBL_LIST_CONTACT_NAME' => 'Nome Contato',
  'LBL_LIST_CONTACT_ROLE' => 'Fun��o do Contato',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Conta',
  'LBL_USER_LIST' => 'Lista de Usu�rio',
  'LBL_CONTACT_LIST' => 'Lista de Contato',
  'LBL_RELATED_RECORDS' => 'Registros Relacionados',
  'LBL_MASS_UPDATE' => 'Atualiza��o em Massa',
  'LNK_ADVANCED_SEARCH' => 'Avan�ada',
  'LNK_BASIC_SEARCH' => 'B�sica',
  'LNK_EDIT' => 'edit',
  'LNK_REMOVE' => 'rem',
  'LNK_DELETE' => 'exc',
  'LNK_LIST_START' => 'In�cio',
  'LNK_LIST_NEXT' => 'Pr�ximo',
  'LNK_LIST_PREVIOUS' => 'Anterior',
  'LNK_LIST_END' => 'Final',
  'LBL_LIST_OF' => 'de',
  'LBL_OR' => 'OU',
  'LBL_BY' => 'por',
  'LNK_PRINT' => 'Imprimir',
  'LNK_HELP' => 'Ajuda',
  'LNK_ABOUT' => 'Sobre',
  'NTC_REQUIRED' => 'Indica campo obrigat�rio',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_YEAR_FORMAT' => '(yyyy)',
  'NTC_DATE_FORMAT' => '(aaaa-mm-dd)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(aaaa-mm-dd 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Tem certeza que deseja excluir este registro?',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro precisa ser espec�ficado para excluir o contato.',
  'ERR_CREATING_TABLE' => 'Erro criando tabela: ',
  'ERR_CREATING_FIELDS' => 'Erro preenchendo campos de detalhe adicional: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Faltam campos obrigat�rios:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'n�o � um endere�o de email v�lido.',
  'ERR_INVALID_DATE_FORMAT' => 'O formato da data deve ser: aaaa-mm-dd',
  'ERR_INVALID_MONTH' => 'Por favor informe um m�s v�lido.',
  'ERR_INVALID_DAY' => 'Por favor informe um dia v�lido.',
  'ERR_INVALID_YEAR' => 'Por favor informe um ano v�lido (4 d�gitos).',
  'ERR_INVALID_DATE' => 'Por favor informe uma data v�lida.',
  'ERR_INVALID_HOUR' => 'Por favor informe uma hora v�lido.',
  'ERR_INVALID_TIME' => 'Por favor informe um hor�rio v�lido.',
  'ERR_INVALID_AMOUNT' => 'Por favor informe um valor v�lido.',
  'NTC_CLICK_BACK' => 'Por favor clique o bot�o voltar do navegador e corrija o erro.',
  'LBL_LIST_ASSIGNED_USER' => 'Atribu�do a',
  'LBL_ASSIGNED_TO' => 'Atribu�do a:',
  'LBL_DATE_MODIFIED' => '�ltima Altera��o:',
  'LBL_DATE_ENTERED' => 'Criado:',
  'LBL_CURRENT_USER_FILTER' => 'Apenas meus itens:',
  'NTC_LOGIN_MESSAGE' => 'Por favor autentique-se na aplica��o.',
  'LBL_NONE' => '--Nada--',
  'LBL_BACK' => 'Voltar',
  'LBL_IMPORT' => 'Importar',
  'LBL_EXPORT' => 'Exportar',
  'LBL_EXPORT_ALL' => 'Exportar Todos',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Salvar e Criar Novo [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Salvar e Criar Novo',
  'LBL_NAME' => 'Nome',
  'LBL_TEAM' => 'Equipe:',
  'LBL_CHECKALL' => 'Marcar Todos',
  'LBL_CLEARALL' => 'Desmarcar Todos',
  'LBL_SUBJECT' => 'Assunto',
  'LBL_ENTER_DATE' => 'Entre com a Data',
  'LBL_CREATED' => 'Criado por',
  'LBL_MODIFIED' => 'Alterado por',
  'LBL_DELETED'=>'Exclu�do',
  'LBL_TEAM_ID'=>'Equipe ID:',
  'LBL_ID'=>'ID',  'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Escrever Email [Alt+E]',
  'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'E',
  'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Escrever Email',
  'ERR_OPPORTUNITY_NAME_MISSING' => 'O nome da oportunidade n�o foi informado. Por favor entre com o nome da oportunidade abaixo.',
  'ERR_OPPORTUNITY_NAME_DUPE' => 'Uma oportunidade com o nome %s j� existe. Por favor entre com novo nome abaixo.',
  'LBL_OPPORTUNITY_NAME' => 'Nome da Oportunidade',
  'LBL_DELETE' => 'Excluir',
  'LBL_UPDATE' => 'Atualizar',
  'LBL_STATUS_UPDATED'=>'Seu status para este evento foi atualizado!',
  'LBL_STATUS'=>'Status:',
  'LBL_CLOSE_WINDOW'=>'Fechar Janela',

);


?>
