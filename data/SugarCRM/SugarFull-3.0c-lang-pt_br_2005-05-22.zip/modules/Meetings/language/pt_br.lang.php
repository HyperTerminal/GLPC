<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Compromissos',
  'LBL_MODULE_TITLE' => 'Compromissos: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Compromissos',
  'LBL_LIST_FORM_TITLE' => 'Lista de Compromissos',
  'LBL_NEW_FORM_TITLE' => 'Agendar Compromisso',
  'LBL_SCHEDULING_FORM_TITLE' => 'Agendamento',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_CONTACT' => 'Nome do Contato',
  'LBL_LIST_RELATED_TO' => 'Relacionado a',
  'LBL_LIST_DATE' => 'Data In�cio',
  'LBL_LIST_TIME' => 'Hora In�cio',
  'LBL_LIST_CLOSE' => 'Encerrado',
  'LBL_SUBJECT' => 'Assunto: ',
  'LBL_STATUS' => 'Situa��o:',
  'LBL_LOCATION' => 'Local:',
  'LBL_DATE_TIME' => 'Data & Hora In�cio:',
  'LBL_DATE' => 'Data In�cio:',
  'LBL_TIME' => 'Hora In�cio:',
  'LBL_DURATION' => 'Dura��o:',
  'LBL_DURATION_HOURS' => 'Duration Hours:',
  'LBL_DURATION_MINUTES' => 'Duration Minutes:',
  'LBL_HOURS_MINS' => '(horas/minutos)',
  'LBL_CONTACT_NAME' => 'Nome do Contato: ',
  'LBL_MEETING' => 'Compromisso:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planejada',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_CALL_LIST' => 'Chamadas',
  'LNK_MEETING_LIST' => 'Compromissos',
  'LNK_TASK_LIST' => 'Tarefas',
  'LNK_NOTE_LIST' => 'Anota��es',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoje',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir o compromisso.',
  'NTC_REMOVE_INVITEE' => 'Tem certeza que deseja remover este convidado do compromisso?',
  'LBL_INVITEE' => 'Convidados',
  'LNK_NEW_APPOINTMENT' => 'Novo Compromisso',
  'LBL_ADD_INVITEE' => 'Adicionar Convites',
  'LBL_NAME' => 'Nome',
  'LBL_FIRST_NAME' => 'Primeiro Nome',
  'LBL_LAST_NAME' => '�ltimo Nome',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Fone',
  'LBL_REMINDER' => 'Lembrete:',
  'LBL_SEND_BUTTON_TITLE'=>'Enviar Convites [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'Enviar Convites',
  'LBL_REMINDER_TIME'=>'Tempo do Lembrete',
  'LBL_MODIFIED_BY'=>'Modificado por',
  'LBL_CREATED_BY'=>'Criado por',
  'LBL_DATE_END'=>'Data Final',
  'LBL_SEARCH_BUTTON'=> 'Pesquisa',
  'LBL_ADD_BUTTON'=> 'Incluir',
);


?>
