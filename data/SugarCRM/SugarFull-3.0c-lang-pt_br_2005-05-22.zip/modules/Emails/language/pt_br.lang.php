<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Emails',
  'LBL_ARCHIVED_MODULE_NAME' => ' Emails Arquivados',
  'LBL_MODULE_NAME_NEW' => 'Arquivar Email',
  'LBL_MODULE_TITLE' => 'Emails: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Emails',
  'LBL_LIST_FORM_TITLE' => 'Lista de Emails',
  'LBL_NEW_FORM_TITLE' => 'Rastrear Email',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_TYPE' => 'Tipo',
  'LBL_LIST_CONTACT' => 'Contato',
  'LBL_LIST_RELATED_TO' => 'Relacionada a',
  'LBL_LIST_DATE' => 'Data do Envio',
  'LBL_LIST_TIME' => 'Hora do Envio',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir o email.',
  'LBL_DATE_SENT' => 'Data do Envio:',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_BODY' => 'Corpo:',
  'LBL_DATE_AND_TIME' => 'Data & Hora do Envio:',
  'LBL_DATE' => 'Data do Envio:',
  'LBL_TIME' => 'Hora do Envio:',
  'LBL_CONTACT_NAME' => ' Nome do Contato: ',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => 'Tem certeza que deseja remover este destinat�rio do email?',
  'LBL_INVITEE' => 'Destinat�rios',

  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_CALL_LIST' => 'Chamadas',
  'LNK_MEETING_LIST' => 'Compromissos',
  'LNK_TASK_LIST' => 'Tarefas',
  'LNK_NOTE_LIST' => 'Anota��es',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_NEW_SEND_EMAIL' => 'Escrever Email',
  'LNK_ARCHIVED_EMAIL_LIST' => 'Emails Arquivados',
  'LNK_SENT_EMAIL_LIST' => 'Emails Enviados',
  'LNK_ALL_EMAIL_LIST' => 'Todos Emails',
  'LNK_NEW_ARCHIVE_EMAIL' => 'Novo Email Arquivado',
  'LNK_VIEW_CALENDAR' => 'Hoje',

  'LBL_COMPOSE_MODULE_NAME' => 'Escrever Email',
  'LBL_SENT_MODULE_NAME' => 'Enviar Emails',
  'LBL_SEND' => 'ENVIAR',
  'LBL_SEARCH_FORM_SENT_TITLE' => 'Pesquisar Emails Enviados',
  'LBL_LIST_FORM_SENT_TITLE' => 'Enviar Emails',
  'LBL_SEND_BUTTON_LABEL' => 'Enviar',
  'LBL_SEND_BUTTON_TITLE' => 'Enviar [Alt+E]',
'LBL_SEND_BUTTON_KEY' => 'E',
  'LBL_SAVE_AS_DRAFT_BUTTON_TITLE' => 'Salvar Rascunho',
  'LBL_SAVE_AS_DRAFT_BUTTON_KEY' => 'Salvar Rascunho [Alt+R]',
  'LBL_SAVE_AS_DRAFT_BUTTON_LABEL' => 'Savar Rascunho',
  'LBL_LIST_TO_ADDR' => 'Para',
  'LBL_TO_ADDRS' => 'Para',
  'LBL_FROM' => 'De:',
  'LBL_LIST_FROM_ADDR' => 'De',
  'LNK_NEW_EMAIL_TEMPLATE' => 'Novo Modelo de Email',
  'LNK_EMAIL_TEMPLATE_LIST' => 'Modelos de Email',
  'LBL_USE_TEMPLATE' => 'Usar Modelo:',
  'LBL_BCC' => 'CCo:',
  'LBL_CC' => 'Cc:',
  'LBL_TO' => 'Para:',
  'LBL_ERROR_SENDING_EMAIL' => 'Erro enviando email',
  'LBL_MESSAGE_SENT' => 'Mensagem Enviada',
  'LNK_DRAFTS_EMAIL_LIST' => 'Rascunho',
  'LBL_SEARCH_FORM_DRAFTS_TITLE' => 'Localizar Rascunhos',
  'LBL_LIST_FORM_DRAFTS_TITLE' => 'Rascunho',
  'LBL_ATTACHMENTS' => 'Anexos:',
  'LBL_ADD_FILE' => 'Adicionar Arquivo',
  'LBL_ADD_ANOTHER_FILE' => 'Adicionar Outro Arquivo',
  'LBL_EMAIL_ATTACHMENT' => 'Anexo de Email',
  'LBL_CONTACT_FIRST_NAME' => 'Primeiro Nome do Contato',
  'LBL_CONTACT_LAST_NAME' => '�ltimo Nome do Contato',
  'ERR_NOT_ADDRESSED' => 'Email deve ter um endere�o Para, CC ou BCC',
  'LBL_NOTE_SEMICOLON' => 'Nota: Utiliza ponto-e-v�rgula como separador para m�ltiplos endere�os de email.',
  'WARNING_SETTINGS_NOT_CONF' => 'Aviso: Suas op��es de email n�o est�o configuradas para enviar mensagens.',
  'LBL_EDIT_MY_SETTINGS' => 'Editar Minhas Configura��es',
  'LBL_NOT_SENT' => 'Erro de Envio',
  'LBL_LIST_CREATED' => 'Criado',
'LBL_EMAIL_SELECTOR'=>'Selecionar',
'LBL_CREATED_BY'=>'Criado por',
'LBL_DESCRIPTION'=>'Descri��o',
'LBL_FROM_NAME'=>'Nome De',
'LBL_LIST_CONTACT_NAME'=>'Nome do Contato',
'LBL_LIST_DATE_SENT'=>'Data Enviada',
'LBL_MODIFIED_BY'=>'Alterado por',

);


?>
