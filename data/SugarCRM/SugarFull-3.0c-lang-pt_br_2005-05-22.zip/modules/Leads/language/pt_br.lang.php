<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Clientes Potenciais',
  'LBL_INVITEE' => 'Relat�rios Diretos',
  'LBL_MODULE_TITLE' => 'Clientes Potenciais: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Clientes Potenciais',
  'LBL_LIST_FORM_TITLE' => 'Lista de Clientes Potenciais',
  'LBL_NEW_FORM_TITLE' => 'Novo Cliente Potencial',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Oportunidade-Potencial:',
  'LBL_CONTACT' => 'Potencial:',
  'LBL_BUSINESSCARD' => 'Converter Potencial',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => '�ltimo Nome',
  'LBL_LIST_CONTACT_NAME' => 'Nome do Potencial',
  'LBL_LIST_TITLE' => 'T�tulo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_PHONE' => 'Fone',
  'LBL_LIST_CONTACT_ROLE' => 'Perfil',
  'LBL_LIST_FIRST_NAME' => 'Primeiro Nome',
  'LBL_LIST_REFERED_BY' => 'Indicado Por',
  'LBL_LIST_LEAD_SOURCE' => 'Fonte do Cliente Potencial',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DATE_ENTERED' => 'Data Cria��o',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Descri��o da Fonte do Cliente Potencial',
  'LBL_LIST_MY_LEADS' => 'Meus Clientes Potenciais',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Utilizando um contato existente',
  'LBL_CREATED_CONTACT' => 'Criado um novo contato',
  'LBL_EXISTING_OPPORTUNITY' => 'Utilizada uma oportunidade existente',
  'LBL_CREATED_OPPORTUNITY' => 'Criada uma nova oportunidade',
  'LBL_EXISTING_ACCOUNT' => 'Usada uma conta existente',
  'LBL_CREATED_ACCOUNT' => 'Criada uma nova conta',
  'LBL_CREATED_CALL' => 'Criada uma nova chamada',
  'LBL_CREATED_MEETING' => 'Criado um novo compromisso',
  'LBL_BACKTOLEADS' => 'Voltar para Clientes Potenciais',
  'LBL_CONVERTLEAD' => 'Converter Cliente Potencial',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome do Cliente Potencial:',
  'LBL_CONTACT_INFORMATION' => 'Informa��o do Cliente Potencial',
  'LBL_FIRST_NAME' => 'Primeiro Nome:',
  'LBL_OFFICE_PHONE' => 'Fone Escrit�rio:',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
  'LBL_OPPORTUNITY_NAME' => 'Nome da Oportunidade:', 
  'LBL_OPPORTUNITY_AMOUNT' => 'Valor da Oportunidade:',
  'LBL_ANY_PHONE' => 'Outro Fone:',
  'LBL_PHONE' => 'Fone:',
  'LBL_LAST_NAME' => '�ltimo Nome:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_HOME_PHONE' => 'Particular:',
  'LBL_LEAD_SOURCE' => 'Fonte:',
  'LBL_STATUS' => 'Status:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Descri��o da Fonte do Cliente Potencial:',
  'LBL_STATUS_DESCRIPTION' => 'Descri��o do Status:',
  'LBL_OTHER_PHONE' => 'Outro Fone:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro Email:',
  'LBL_ANY_EMAIL' => 'Outro Email:',
  'LBL_REPORTS_TO' => 'Reporta-se a:',
  'LBL_DO_NOT_CALL' => 'N�o Chamar:',
  'LBL_EMAIL_OPT_OUT' => 'N�o Deseja Emails:',
  'LBL_PRIMARY_ADDRESS' => 'Endere�o Principal:',
  'LBL_ALTERNATE_ADDRESS' => 'Outro Endere�o:',
  'LBL_ANY_ADDRESS' => 'Outro Endere�o:',
  'LBL_REFERED_BY' => 'Indicado Por:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Rua do Endere�o Principal',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Cidade do Endere�o Principal',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Estado do Endere�o Principal',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'CEP do Endere�o Principal',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Pa�s do Endere�o Principal',
  'LBL_ALT_ADDRESS_STREET' => 'Rua do Endere�o Alternativo',
  'LBL_ALT_ADDRESS_CITY' => 'Cidade do Endere�o Alternativo',
  'LBL_ALT_ADDRESS_STATE' => 'Estado do Endere�o Alternativo',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'CEP do do Endere�o Alternativo',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Pa�s do Endere�o Alternativo',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o da Descri��o',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o do Endere�o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_CONTACT_ROLE' => 'Perfil:',
  'LBL_OPP_NAME' => 'Nome da Oportunidade:',
  'LBL_IMPORT_VCARD' => 'Importar vCard',
  'LNK_IMPORT_VCARD' => 'Criar de vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Criar automaticamente novo cliente potencial importando um vCard a partir do seu sistema de arquivos.',
  'LBL_DUPLICATE' => 'Clientes Potenciais Similares',
  'MSG_DUPLICATE' => 'Clientes Potenciais similares foram encontrados. Por favor, marque a caixa de qualquer cliente potencial que voc� gostaria de associar com os registros que ir�o ser criados nessa convers�o. Uma vez que esteja pronto, por favor, pressione pr�ximo.',
  'LBL_ADD_BUSINESSCARD' => 'Adicionar Cart�o de Visitas',
  'LNK_NEW_APPOINTMENT' => 'Novo Compromisso',
  'LNK_NEW_LEAD' => 'Novo Cliente Potencial',
  'LNK_LEAD_LIST' => 'Clientes Potenciais',
  'NTC_DELETE_CONFIRMATION' => 'Tem certeza que deseja excluir este registro?',
  'NTC_REMOVE_CONFIRMATION' => 'Tem certeza que deseja remover este cliente potencial desta ocorr�ncia?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Are you sure you want to remove this record as a direct report?',
  'ERR_DELETE_RECORD' => 'en_us A record number must be specified to delete the lead.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copy primary address to alternate address',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copy alternate address to primary address',
  'LNK_NEW_CONTACT' => 'Create Contact',
  'LNK_NEW_NOTE' => 'Create Note',
  'LNK_NEW_ACCOUNT' => 'Create Account',
  'LNK_NEW_OPPORTUNITY' => 'Create Opportunity',
  'LNK_SELECT_ACCOUNT' => 'Select Account',
  'LBL_SALUTATION' => 'Salutation',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Creating an opportunity requires an account.\\n Please either create a new one or select an existing one.',
  'LBL_CONVERTLEAD_TITLE' => 'Convert Lead [Alt+V]',
  'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
  'LBL_PORTAL_NAME' => 'Nome do Portal:',
  'LBL_NEW_PORTAL_PASSWORD' => 'Nova Senha do Portal:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'Senha do Portal est� configurada:',
  'LBL_PORTAL_ACTIVE' => 'Portal Ativo:',
  'LBL_PORTAL_INFORMATION' => 'Informa��o do Portal',
  'LBL_PORTAL_APP'=> 'Aplica��o do Portal',
  'LBL_ACCOUNT_DESCRIPTION'=> 'Descri��o da Conta',
  'LBL_CONVERTED'=> 'Convertido',
  'LBL_REPORTS_TO_ID'=>'Reporta-se a ID',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Selecionar Potenciais Marcados',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Selecionar Potenciais Marcados',
  'LBL_INVALID_EMAIL'=>'Email Inv�lido:',
  'LBL_CONVERTED_CONTACT' => 'Contato Convertido:',
  'LBL_CONVERTED_ACCOUNT'=>'Conta Convertida:',
  'LBL_CONVERTED_OPP'=>'Oportunidade Convertida:',

);


?>
