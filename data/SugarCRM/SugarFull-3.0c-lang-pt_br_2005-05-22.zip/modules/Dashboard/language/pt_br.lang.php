<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Painel',
  'LBL_MODULE_TITLE' => 'Painel: Principal',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Total Funil por Est�gio da Venda',
  'LBL_SALES_STAGE_FORM_DESC' => 'Mostra totais aculumados das oportunidades por est�gios de vendas selecionados, de usu�rios selecionados, dentro de um per�odo previsto.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline por M�s por Resultado',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Mostra totais acumulados das oportunidades por m�s e resultado para usu�rios selecionados, onde a data prevista estiver dentro de um per�odo. Resultado � baseado no est�gio de vendas.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Total Funil por Fonte da Oportunidade',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Mostra totais acumulados das oportunidade por fonte da oportunidade para usu�rios selecionados.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Todas Oportunidades por Fonte por Resultado',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Mostra totais acumulados das oportunidades por fonte, resultado e usu�rios selecionados, onda a data prevista estiver dentro de um per�odo. Resultado � baseado no est�gio de vendas.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Mostra totais acumulados das oportunidades por est�gio de vendas selecionado para suas oportunidades onde a data prevista estiver dentro de um per�odo.',
  'LBL_DATE_RANGE' => 'Intervalo de datas �<br>',
  'LBL_DATE_RANGE_TO' => 'at�',
  'ERR_NO_OPPS' => 'Por favor crie algumas Oportunidades para ver o gr�fico de Oporunidades.',
  'LBL_TOTAL_PIPELINE' => 'Total do Funil � ',
  'LBL_ALL_OPPORTUNITIES' => 'Valor total de todas oportunidade � ',
  'LBL_OPP_SIZE' => 'Tamanho da Oportunidade em R$1K',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Nada',
  'LBL_LEAD_SOURCE_OTHER' => 'Outro',
  'LBL_EDIT' => 'Editar',
  'LBL_REFRESH' => 'Atualizar',
  'LBL_CREATED_ON' => '�ltima execu��o ',
  'LBL_OPPS_WORTH' => 'valor das oportunidades',
  'LBL_OPPS_IN_STAGE' => 'oportunidades cujo est�gio de vendas �',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'oportunidades cuja a fonte �',
  'LBL_OPPS_OUTCOME' => 'oportunidades cujo resultado �',
  'LBL_ROLLOVER_DETAILS' => 'Selecione a barra para detalhes.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Selecione a wedge para detalhes.',
  'LBL_USERS' => 'Usu�rios',
  'LBL_SALES_STAGES' => 'Est�gio Vendas',
  'LBL_LEAD_SOURCES' => 'Fonte da Oportunidade',
  'LBL_DATE_START' => 'Data In�cio',
  'LBL_DATE_END' => 'Data Fim',
  'LBL_YEAR' => 'Ano:',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_QUOTE' => 'Nova Cota��o',
  'LNK_NEW_LEAD' => 'Novo Cliente Potencial',
  'LNK_NEW_CASE' => 'Nova Ocorr�ncia',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_ISSUE' => 'Reportar Bug',
  'LBL_MONTH_BY_OUTCOME' => 'Funil por M�s por Resultado',
  'LNK_NEW_EMAIL' => 'Novo Email',
);


?>
