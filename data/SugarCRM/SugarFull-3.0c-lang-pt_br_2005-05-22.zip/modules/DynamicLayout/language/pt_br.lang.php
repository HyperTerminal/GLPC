<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_ADVANCED' => 'Avan�ado:',
  'DESC_USING_LAYOUT_TITLE' => 'Usando o Editor de Layout',
  'DESC_USING_LAYOUT_SHORTCUTS' => 'Atalhos:',
  'DESC_USING_LAYOUT_TOOLBAR' => 'Barra de Ferramentas:',
  'DESC_USING_LAYOUT_EDIT_ROWS' => 'Editar Linhas:',
  'DESC_USING_LAYOUT_SELECT_FILE' => 'Selecionar Arquivo:',
  'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Editar Campos:',
  'DESC_USING_LAYOUT_ADD_FIELD' => 'Adicionar Campo:',
  'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Remover um item:',
  'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Exibir c�digo HTML:',
  'DESC_USING_LAYOUT_BLK1' => 'O editor de Layout permite voc� rearranjar campos, tabs e paineis nas tabs para customizar as telas de acordo com suas necessidades. Inicialmente selecione a view da p�gina que voc� deseja customizar atrav�s do atalho "Selecionar Arquivo".',
  'DESC_USING_LAYOUT_BLK2' => ' permite voc� selecionar uma pagina diferente para editar; edi��es da pagina atual ser�o perdidas caso n�o sejam salvas. Caso voc� n�o tenha certeza qual arquivo deseja editar, selecione o box "Editar interativamente"; isto ir� adicionar um box de edi��o em todas as p�ginas edit�veis da aplica��o. Navegue pela aplica��o at� a p�gina que deseja editar, clique no box de edi��o, e voc� ser� habilitado a editar a apresenta��o deste arquivo.',
  'DESC_USING_LAYOUT_BLK3' => ' arraste e rearranje campos individuais ou seus r�tulos. Selecione o �tem ',
  'DESC_USING_LAYOUT_BLK4' => ' pr�ximo ao campo ou r�tulo que voc� deseja mover, e clique na al�a do �tem onde voc� deseja que o campo ou r�tulo fique localizado. Isto ir� mover o �tem da localiza��o anterior para nova localiza��o. Caso haja um campo ou r�tulo no local de destino os dois itens ir�o trocar de posi��o. Mover sub-pain�is � igual a mover campos; selecione a aba do sub-painel fonte e a aba destino que ambos ir�o trocar de localiza��o. Para remover um campo ou formul�rio da tela, arraste o �tem para a �rea da Caixa de Ferramentas no lado esquerdo da barra de menu.',
  'DESC_USING_LAYOUT_BLK5' => ' altera para visualiza��o que permite incluir ou remover linhas nos pain�is de detalhes. Pressionando o + adiciona a linha abaixo da selecionada, e pressionando � remove a linha.',
  'DESC_USING_LAYOUT_BLK6' => 'A Caixa de ferramentas prov� um espa�o de trabalho para adicionar novos campos e r�tulos para os formul�rios, temporariamente reter �tens que foram removidos do formul�riop=, e descartar os �tens.',
  'DESC_USING_LAYOUT_BLK7' => ' abre a sele��o para especificar o tipo de campo que voc� deseja incluir e o r�tulo correspondente. Pessionando o bot�o Adicionar o campo e o r�tulo � colocado na �rea de trabalho da Caixa de Ferramenta. A partir daqui o campo pode ser adicionado selecionando a aba do novo �tem e arrastando para sua destina��o.',
  'DESC_USING_LAYOUT_BLK8' => ' � alcan�ado selecionando sua aba e clicando no texto "Arraste �tens indesejados aqui". Isto ir� depositar o item selecionado na �rea de trabalho da Caixa de Ferramentas.',
  'DESC_USING_LAYOUT_BLK9' => ' seleciona a apresenta��o do c�digo html que acompanha cada campo. Ao mesmo tempo que isto pode ser muito informativo, tamb�m consome bastante CPU, e somente deve ser utilizado quando necess�rio.',
  'DESC_USING_LAYOUT_BLK10' => 'Para salvar as altera��es, pressione o bot�o "Salvar layout". Para descartar as altera��es clique em outra tab na aplica��o e todas as altera��es da p�gina editada ser�o descartadas.',
  'NO_RECORDS_LISTVIEW' => 'Para editar uma "list view" � necess�rio pelo menos uma linha da dados. Por favor, crie um registro para esta "list view" antes de tentar editar.',
);


?>
