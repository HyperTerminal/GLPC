<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Ocorr�ncias',
  'LBL_MODULE_TITLE' => 'Ocorr�ncias: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Ocorr�ncias',
  'LBL_LIST_FORM_TITLE' => 'Lista de Ocorr�ncias',
  'LBL_NEW_FORM_TITLE' => 'Nova Ocorr�ncias',
  'LBL_CONTACT_CASE_TITLE' => 'Contato-Ocorr�ncia:',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_CASE' => 'Ocorr�ncia:',
  'LBL_CASE_NUMBER' => 'Ocorr�ncia #:',
  'LBL_NUMBER' => 'N�mero:',
  'LBL_STATUS' => 'Situa��o:',
  'LBL_PRIORITY' => 'Prioridade:',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_RESOLUTION' => 'Resolu��o:',
  'LBL_CONTACT_NAME' => 'Nome do Contato:',
  'LBL_CASE_SUBJECT' => 'Assunto da Ocorr�ncia:',
  'LBL_CONTACT_ROLE' => 'Papel:',
  'LBL_LIST_NUMBER' => 'N�m.',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_STATUS' => 'Situa��o',
  'LBL_LIST_PRIORITY' => 'Prioridade',
  'LBL_LIST_LAST_MODIFIED' => '�ltima Altera��o',
  'LBL_INVITEE' => 'Contatos',
  'LNK_NEW_CASE' => 'Nova Ocorr�ncia',
  'LNK_CASE_LIST' => 'Ocorr�ncias',
  'NTC_REMOVE_INVITEE' => 'Tem certeza que quer remover este contato da Ocorr�ncia?',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a Ocorr�ncia.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Tem certeza que quer remover esta Ocorr�ncia a partir deste bug?',
  'LBL_LIST_CLOSE' => 'Fechar',
  'LBL_LIST_MY_CASES' => 'Minhas Ocorr�ncias Abertas',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
);


?>
