<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tarefas',
  'LBL_TASK' => 'Tarefas: ',
  'LBL_MODULE_TITLE' => ' Tarefas: Principal',
  'LBL_SEARCH_FORM_TITLE' => ' Pesquisar Tarefas',
  'LBL_LIST_FORM_TITLE' => ' Lista de Tarefas',
  'LBL_NEW_FORM_TITLE' => ' Nova Tarefa',
  'LBL_NEW_FORM_SUBJECT' => 'Assunto:',
  'LBL_NEW_FORM_DUE_DATE' => 'Data Devida:',
  'LBL_NEW_FORM_DUE_TIME' => 'Hora Devida:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Encerrar',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_CONTACT' => 'Contato',
  'LBL_LIST_PRIORITY' => 'Prioridade',
  'LBL_LIST_RELATED_TO' => 'Relacionada a',
  'LBL_LIST_DUE_DATE' => 'Data Devida',
  'LBL_LIST_DUE_TIME' => 'Hora Devida',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_STATUS' => 'Situa��o:',
  'LBL_DUE_DATE' => 'Data Devida:',
  'LBL_DUE_TIME' => 'Hora Devida:',
  'LBL_PRIORITY' => 'Prioridade:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Data & Hora Devidas:',
  'LBL_START_DATE_AND_TIME' => 'Data & Hora Inicio:',
  'LBL_START_DATE' => 'Data Inicio:',
  'LBL_START_TIME' => 'Hora Final:',
  'DATE_FORMAT' => '(aaaa-mm-dd 24:00)',
  'LBL_NONE' => 'nada',
  'LBL_CONTACT' => 'Contato:',
  'LBL_PHONE' => 'Fone:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome do Contato: ',
  'LBL_LIST_COMPLETE' => 'Completar:',
  'LBL_LIST_STATUS' => 'Situa��o:',
  'LBL_DATE_DUE_FLAG' => 'Sem Data Devida',
  'LBL_DATE_START_FLAG' => 'Sem Data Inicio',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a tarefa.',
  'ERR_INVALID_HOUR' => 'Por favor informe uma hora entre 00:00 e 24:00',
  'LBL_DEFAULT_STATUS' => 'N�o Iniciada',
  'LBL_DEFAULT_PRIORITY' => 'M�dio',
  'LBL_LIST_MY_TASKS' => 'Minhas Tarefas Abertas',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_CALL_LIST' => 'Chamadas',
  'LNK_MEETING_LIST' => 'Compromissos',
  'LNK_TASK_LIST' => 'Tarefas',
  'LNK_NOTE_LIST' => 'Anota��es',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoje',
  'LBL_CONTACT_FIRST_NAME' => 'Primeiro Nome do Contato',
  'LBL_CONTACT_LAST_NAME' => '�ltimo Nome do Contato',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Nova Ocorr�ncia',
);


?>
