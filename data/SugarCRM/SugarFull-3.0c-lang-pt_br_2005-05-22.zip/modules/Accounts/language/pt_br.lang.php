<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contas',
  'LBL_MODULE_TITLE' => 'Contas: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Conta',
  'LBL_LIST_FORM_TITLE' => 'Lista de Contas',
  'LBL_NEW_FORM_TITLE' => 'Nova Conta',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organiza��es Membros',
  'LBL_BUG_FORM_TITLE' => 'Contas',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_CITY' => 'Cidade',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Estado',
  'LBL_LIST_PHONE' => 'Fone',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Contato',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Informa��o da Conta',
  'LBL_ACCOUNT' => 'Conta:',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
  'LBL_PHONE' => 'Fone:',
  'LBL_PHONE_ALT' => 'Fone Alternativo:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'C�digo Bolsa:',
  'LBL_OTHER_PHONE' => 'Outro Fone:',
  'LBL_ANY_PHONE' => 'Fone qualquer:',
  'LBL_MEMBER_OF' => 'Membro de:',
  'LBL_PHONE_OFFICE' => 'Fone Escrit�rio:',
  'LBL_PHONE_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Funcion�rios:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro Email:',
  'LBL_ANY_EMAIL' => 'Email qualquer:',
  'LBL_OWNERSHIP' => 'Propriedade:',
  'LBL_RATING' => 'Avalia��o:',
  'LBL_INDUSTRY' => 'Neg�cio:',
  'LBL_SIC_CODE' => 'C�digo SIC:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Receita Anual:',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o de Endere�o',
  'LBL_BILLING_ADDRESS' => 'Endere�o Cobran�a:',
  'LBL_BILLING_ADDRESS_STREET' => 'Rua Endere�o de Cobran�a:',
  'LBL_BILLING_ADDRESS_CITY' => 'Cidade Endere�o de Cobran�a:',
  'LBL_BILLING_ADDRESS_STATE' => 'Estado Endere�o de Cobran�a:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'CEP Endere�o de Cobran�a:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Pa�s Endere�o de Cobran�a:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Rua Endere�o de Entrega:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Cidade Endere�o de Entrega:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Estado Endere�o de Entrega:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'CEP Endere�o de Entrega:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Pa�s Endere�o de Entrega:',
  'LBL_SHIPPING_ADDRESS' => 'Endere�o Entrega:',
  'LBL_DATE_MODIFIED' => 'Data Modifica��o:',
  'LBL_DATE_ENTERED' => 'Data Inclus�o:',
  'LBL_ANY_ADDRESS' => 'Endere�o qualquer:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copiar endere�o cobran�a para endere�o entrega',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copiar endere�o entrega para endere�o cobran�a',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Tem certeza que deseja remover este registro como uma organiza��o membro?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Tem certeza que deseja excluir esse registro?',
  'LBL_DUPLICATE' => 'Poss�vel Conta Duplicada',
  'MSG_SHOW_DUPLICATES' => 'Criando este contato pode duplicar um contato. Voc� pode clicar em Criar Contato para continuar ou escolher Cancelar',
  'MSG_DUPLICATE' => 'Criando esta conta pode duplicar uma conta. Voc� pode clicar em Criar Conta para continuar ou escolher Cancelar',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_ACCOUNT_LIST' => 'Contas',
  'LBL_INVITEE' => 'Contatos',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a conta.',
  'NTC_DELETE_CONFIRMATION' => 'Deseja exluir esse registro?',
  'LBL_SAVE_ACCOUNT' => 'Salvar Conta',
  'LNK_NEW_CONTACT' => 'Novo Contato',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Nova Ocorr�ncia',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
);


?>
