<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

// $Id: en_us.lang.php,v 1.54 2005/02/25 06:35:07 majed Exp $





$mod_strings = array (
  'LBL_MODULE_NAME' => 'Administra��o',
  'LBL_MODULE_TITLE' => 'Administra��o: Principal',
  'LBL_NEW_FORM_TITLE' => 'Novo Usu�rio',
  'LNK_NEW_USER' => 'Novo Usu�rio',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir o usu�rio.',
  'LBL_CONFIGURE_SETTINGS_TITLE' => 'Definir Configura��es',
  'LBL_CONFIGURE_SETTINGS' => 'Definir configura��es do sistema',
  'LBL_UPGRADE_TITLE' => 'Atualizar',
  'LBL_UPGRADE' => 'Atualizar Sugar Sales',
  'LBL_MANAGE_USERS_TITLE' => 'Gerenciar Usu�rios',
  'LBL_MANAGE_USERS' => 'Gerenciar contas de usu�rios e senhas',
  'LBL_ADMINISTRATION_HOME_TITLE' => 'Administra��o do Sistema',
  'LBL_NOTIFY_TITLE' => 'Op��es de Notifica��es via E-mail',
  'LBL_NOTIFY_FROMADDRESS' => 'Endere�o "De":',
  'LBL_MAIL_SMTPSERVER' => 'Servidor SMTP:',
  'LBL_MAIL_SMTPPORT' => 'porta SMTP:',
  'LBL_MAIL_SENDTYPE' => 'MTA (Mail Transfer Agent):',
  'LBL_MAIL_SMTPUSER' => 'Usu�rio SMTP:',
  'LBL_MAIL_SMTPPASS' => 'Senha SMTP:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Utilizar Autentica��o SMTP?',
  'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Enviar notifica��es por padr�o?',
  'LBL_NOTIFY_SUBJECT' => 'Assunto do E-mail:',
  'LBL_NOTIFY_ON' => 'Notifica��es ligadas?',
  'LBL_NOTIFY_FROMNAME' => 'Nome "De":',
  'LBL_CURRENCY' => 'Configurar Moedas e Cota��es de Moedas',
  'LBL_RELEASE' => 'Gerenciar vers�es e releases',
  'LBL_LAYOUT' => 'Incluir, remover, alterar campos e paineis na aplica��o',
  'LBL_MANAGE_CURRENCIES' => 'Moedas',
  'LBL_MANAGE_RELEASES' => 'Releases',
  'LBL_MANAGE_LAYOUT' => 'Layout dos Campos',
  'LBL_MANAGE_OPPORTUNITIES' => 'Oportunidades',
  'LBL_UPGRADE_CURRENCY' => 'Atualizar valores de cota��es em ',
  'LBL_BACKUP' => 'Backup',
  'DESC_BACKUP' => 'Backup da aplica��o e banco de dados do Sugar',
  'LBL_EDIT_CUSTOM_FIELDS' => 'Editar Campos Personalizados',
  'DESC_EDIT_CUSTOM_FIELDS' => 'Edita campos personalizados criados em Layout de Campos',
  'LBL_DROPDOWN_EDITOR' => 'Listas Suspensas',
  'DESC_DROPDOWN_EDITOR' => 'Incluir, excluir ou atualizar Listas Suspensas na aplica��o',
  'LBL_IFRAME' => 'Portal',
  'DESC_IFRAME' => 'Incluir Guias que podem mostrar qualquer site',
  'LBL_BUG_TITLE' => 'Bug Tracker',
  'LBL_TIMEZONE' => 'Time Zone',
  'LBL_STUDIO_TITLE' => 'Estudio',
  'LBL_CONFIGURE_TABS' => 'Configurar Guias',
  'LBL_CHOOSE_WHICH' => 'Escolher quais Guias ser�o mostradas no sistema',
  'LBL_DISPLAY_TABS' => 'Mostrar Guias',
  'LBL_HIDE_TABS' => 'Esconder Guias',
  'LBL_EDIT_TABS' => 'Editar Guias',
  'LBL_UPGRADE_DB_TITLE' => 'Atualizar banco de dados',
  'LBL_UPGRADE_DB' => 'Atualizando o banco de dados utilizando o �ltimo script sql incluido',
  'LBL_UPGRADE_DB_BEGIN' => 'Iniciando Atualiza��o',
  'LBL_UPGRADE_DB_COMPLETE' => 'Atualiza��o Completa',
  'LBL_UPGRADE_VERSION' => 'Atualizando informa��es da vers�o',
  'LBL_UPGRADE_DB_FAIL' => 'Atualiza��o n�o conclu�da',
  'LBL_FORECAST_TITLE'=> 'Previs�o',
  'LBL_PORTAL_TITLE' => 'Portal Self-Service do Cliente',
  'LBL_PORTAL_ON' => 'Habilitar Integra��o com Portal Self-Service?',
  'LBL_PORTAL_ON_DESC' => 'Permitir que Ocorr�ncias, Anota��es e outros dados sejam acess�veis pelo cliente atrav�s do sistema de portal self-service.',
  'LBL_NOTIFICATION_ON_DESC' => 'Enviar notifica��es via e-mail quando registros forem atribu�dos.',
  'LBL_UPGRADE_CONFIG_TITLE' => 'Atualizar arquivo de configura��o',
  'LBL_UPGRADE_CONFIG' => 'Atualizar arquivo de configura��es para armazenar variaveis em array.',
  'BTN_PERFORM_UPGRADE' => 'Executar Atualiza��o',
  'LBL_PERFORM_UPGRADE' => 'Configurar Atualiza��o',
  'LBL_CONFIG_CHECK' => 'Verificar Configura��o',
  'MSG_CONFIG_FILE_UP_TO_DATE' => 'Seu arquivo de configura��es est� atualizado com o �ltimo formato.',
  'MSG_CONFIG_FILE_READY_FOR_UPGRADE' => 'Seu arquivo de configura��o antigo est� pronto para ser atualizado. � altamente recomendado fazer um backup do arquivo config.php antes da atualiza��o',
  'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'Por favor d� direitos de grava��o no arquivo config.php para poder ser atualizado para o �ltimo formato.',
  'MSG_CONFIG_FILE_UPGRADE_SUCCESS' => 'Seu arquivo de configura��o foi atualizado com sucesso.',
  'MSG_CONFIG_FILE_UPGRADE_FAILED' => 'N�o foi poss�vel atualizar seu arquivo de configura��o.',
  'LBL_UPGRADE_DROPDOWN' => 'Atualizar r�tulos personalizados e listas suspensas para o novo formato ',
  'LBL_UPGRADE_DROPDOWN_TITLE' => 'Atualizar r�tulos personalizados',
  'LBL_UPGRADE_CUSTOM_FIELDS' => 'Atualizar campos personalizados para melhorar efici�ncia',
  'LBL_UPGRADE_CUSTOM_FIELDS_TITLE' => 'Atualizar campos personalizados',
  'LBL_ALLOW_USER_TABS' => 'Permite usu�rios configurar Guias',
  'LBL_RENAME_TABS'=>'Renomear Guias',
  'LBL_CHANGE_NAME_TABS'=>'Alterar o r�tulo das guias.',
  'LBL_MASS_EMAIL_MANAGER_DESC'=> 'Gerencia a fila de emails em massa',
  'LBL_MASS_EMAIL_MANAGER_TITLE'=> 'Gerenciar Email em Massa',
  'LBL_MANAGE_ROLES_TITLE' => 'Gerenciar Direitos',
  'LBL_MANAGE_ROLES' => 'Gerenciar associa��o de direitos e propriedades',
  'LBL_IMPORT_CUSTOM_FIELDS_TITLE' => 'Importar Estrutura de Campos Personalizados',
  'LBL_EXPORT_CUSTOM_FIELDS_TITLE' => 'Exportar Estrutura de Campos Personalizados',
  'LBL_EXTERNAL_DEV_TITLE'=> 'Migrar Campos Personalizados',
  'LBL_EXTERNAL_DEV_DESC'=> 'Migrar campos personalizados de um sistema para outro',
  'LBL_IMPORT_CUSTOM_FIELDS'=> 'Importar defini��es de campos personalizados de um arquivo .sugar',
  'LBL_EXPORT_CUSTOM_FIELDS'=> 'Exportar defini��es de campos personalizados para um arquivo .sugar', 
  'LBL_IMPORT_CUSTOM_FIELDS_STRUCT'=> ' Estrutura de Campos Personalizados (CustomFieldStruct.sugar)',
  'LBL_IMPORT_CUSTOM_FIELDS_DESC'=> ' <br>Importar um arquivo .sugar que foi exportado em outra m�quina. Isto ir� fazer com que a estrutura de campos desta m�quina combine com o da outra m�quina. � recomendado exportar a estrutura atual antes de importar um novo. Ap�s importar a Estrutura de Campos Personalizados, o sistema ir� automaticamente executar a atualiza��o e informar as mudan�as que ser�o feitas no banco de dados. Caso voc� concorde com as altera��es, clique no link abaixo para executar o modo de n�o simula��o. Caso deseje reverter o processo, simplesmente importe a estrutura backup, exportada previamente. <br> Aten��o: Isto ir� remover qualquer estrutura customizada que n�o esteja no arquivo .sug, assim como quaisquer dados gravados nesses campos personalizados.',

  'LBL_UPGRADE_TEAM_EXISTS' => 'Equipe j� existente',
  'LBL_UPGRADE_TEAM_CREATE' => 'Equipes criadas para -',
  'LBL_UPGRADE_TEAMS' => 'Criar equipes para usu�rios ',
  'LBL_UPGRADE_TEAM_TITLE' => 'Atualizar equipes',

  'LBL_UPGRADE_QUOTES' => 'Atualizar cota��es para utilizar grupo de cota��o ',
  'LBL_UPGRADE_QUOTES_TITLE' => 'Atualizar cota��es',
  'LBL_UPGRADE_QUOTE_CURRENT_PRODUCT' => 'Produto Atual -',
  'LBL_UPGRADE_QUOTE_CURRENT_QUOTE' => 'Cota��o Atual -',
  'LBL_UPGRADE_NO_QUOTE' => 'N�o existem cota��es',
  'LBL_UPGRADE_NEW_GROUP' => 'Criado novo Grupo',
  'LBL_UPGRADE_ADDED_TO_GROUP' => 'Adicionado do Grupo',
  'LBL_UPGRADE_ALREADY_EXISTS_IN_GROUP' => 'J� existende no grupo:',
  'LBL_UPGRADE_ALREADY_EXISTS_GROUP' => 'um grupo j� existe',
  'LBL_UPGRADE_NOT_UPGRADING' => 'N�o tentando atualizar',


  'LNK_NEW_TEAM' => 'Nova Equipe',
  'LNK_NEW_PRODUCT' => 'Novo Produto',
  'LBL_MANAGE_TEAMS_TITLE' => 'Gerenciar Equipes',
  'LBL_MANAGE_TEAMS' => 'Gerenciar propriedades e membros de equipes',
  'LBL_PRICE_LIST_TITLE' => 'Administra��o do Catalogo de Produtos',
  'LBL_PRODUCTS_TITLE' => 'Catalogo de Produtos',
  'LBL_PRODUCTS' => 'Entrar �tens no cat�logo de produtos',
  'LBL_MANUFACTURERS_TITLE' => 'Fabricantes',
  'LBL_MANUFACTURERS' => 'Configurar lista de fabricantes',
  'LBL_PRODUCT_CATEGORIES_TITLE' => 'Categoria de Produtos',
  'LBL_PRODUCT_CATEGORIES' => 'Atualizar a lista de categorias de produtos',
  'LBL_PRODUCT_TYPES_TITLE' => 'Tipos de Produtos',
  'LBL_UPGRADE_FOR_PRODUCT'=> 'para Produto',
  'LBL_PRODUCT_TYPES' => 'Configurar a lista de tipos de produtos',
  'LBL_QUOTES_ORDERS_TITLE' => 'Cota��es e Administra��o de Pedidos',
  'LBL_SHIPPERS_TITLE' => 'M�todos de Entrega',
  'LBL_SHIPPERS' => 'Configurar a lista de metodos de entrega dispon�veis',
  'LBL_TAXRATES_TITLE' => 'Impostos',
  'LBL_TAXRATES' => 'Configurar a lista de impostos dispon�veis',
  'LBL_MANAGE_TIMEPERIODS_TITLE' => 'Gerenciar Per�odos',
  'LBL_MANAGE_TIMEPERIODS' => 'Gerenciar per�odos',
  'LBL_MANAGE_LICENSE_TITLE'  => 'Gerenciar Licen�as',
  'LBL_MANAGE_LICENSE'        => 'Gerenciar propriedades da licen�a',
  'LBL_LICENSE_USERS'         => 'N�mero de Usu�rios',
  'LBL_LICENSE_EXPIRE_DATE'   => 'Data de Expira��o',
  'LBL_LICENSE_KEY'           => 'Chave de Download',
);


?>
