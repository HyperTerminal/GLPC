<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Modelos de Email',
  'LBL_MODULE_TITLE' => 'Modelos de Email: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Modelos de Email',
  'LBL_LIST_FORM_TITLE' => 'Lista de Modelos de Email',
  'LBL_NEW_FORM_TITLE' => 'Novo Modelo de Email',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_DESCRIPTION' => 'Descri��o',
  'LBL_LIST_DATE_MODIFIED' => '�ltima Modifica��o',
  'LBL_NAME' => 'Nome:',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_CLOSE' => 'Fechado:',
  'LBL_RELATED_TO' => 'Relacionado a:',
  'LBL_BODY' => 'Corpo:',
  'LBL_PUBLISH' => 'Publicado:',
  'LBL_COLON' => ':',
  'LNK_NEW_EMAIL_TEMPLATE' => 'Novo Modelo de Email',
  'LNK_EMAIL_TEMPLATE_LIST' => 'Modelos de Email',
  'LNK_IMPORT_NOTES' => 'Importar Anota��es',
  'LNK_VIEW_CALENDAR' => 'Hoje',
  'LNK_CHECK_EMAIL' => 'Verificar Mail',
  'LNK_NEW_SEND_EMAIL' => 'Escrever Email',
  'LNK_ARCHIVED_EMAIL_LIST' => 'Emails Arquivados',
  'LNK_SENT_EMAIL_LIST' => 'Enviar Emails',
  'LNK_NEW_EMAIL' => 'Arquivar Email',
  'LBL_INSERT_VARIABLE' => 'Inserir Vari�vel:',
  'LBL_INSERT' => 'Inserir',
  'LNK_DRAFTS_EMAIL_LIST' => 'Rascunho',
  'LNK_ALL_EMAIL_LIST' => 'Todos Emails',
  'LNK_NEW_ARCHIVE_EMAIL' => 'Novo Email Arquivado',
);


?>
