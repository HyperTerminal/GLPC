<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional End User
 * License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.3 2005/04/28 21:51:25 nate Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Recursos Humanos',
  'LBL_MODULE_TITLE' => 'Recursos Humanos: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Colaboradores',
  'LBL_LIST_FORM_TITLE' => 'Colaboradores',
  'LBL_NEW_FORM_TITLE' => 'Novo Colaborador',
  'LBL_EMPLOYEE' => 'Colaboradores:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Redefinir para Prefer�ncias Padr�o',
  'LBL_TIME_FORMAT' => 'Formato de Hora:',
  'LBL_DATE_FORMAT' => 'Formato de Data:',
  'LBL_TIMEZONE' => 'Time Zone:',
  'LBL_CURRENCY' => 'Moeda:',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => '�ltimo Nome',
  'LBL_LIST_EMPLOYEE_NAME' => 'Nome do Colaborador',
  'LBL_LIST_DEPARTMENT' => 'Departamento',
  'LBL_LIST_REPORTS_TO_NAME' => 'Reporta-se a',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Fone Principal',
  'LBL_LIST_USER_NAME' => 'Nome do Usu�rio',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Novo Colaborador [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Novo Colaborador',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Erroro:',
  'LBL_PASSWORD' => 'Senha:',
  'LBL_EMPLOYEE_NAME' => 'Nome do Colaborador:',
  'LBL_USER_NAME' => 'Nome do Usu�rio:',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_LAST_NAME' => 'Sobrenome:',
  'LBL_EMPLOYEE_SETTINGS' => 'Configura��es do Colaborador',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Linguagem:',
  'LBL_ADMIN' => 'Administrador:',
  'LBL_EMPLOYEE_INFORMATION' => 'Informa��o do Colaborador',
  'LBL_OFFICE_PHONE' => 'Fone Comercial:',
  'LBL_REPORTS_TO' => 'Reporta-se a:',
  'LBL_OTHER_PHONE' => 'Outro:',
  'LBL_OTHER_EMAIL' => 'Outro Email:',
  'LBL_NOTES' => 'Anota��es:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_TITLE' => 'Fun��o:',
  'LBL_ANY_PHONE' => 'Outro Fone:',
  'LBL_ANY_EMAIL' => 'Outro Email:',
  'LBL_ADDRESS' => 'Endere�o:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_NAME' => 'Nome:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_OTHER' => 'Outro:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Fone Residencial:',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o do Endere�o',
  'LBL_EMPLOYEE_STATUS' => 'Status:',
  'LBL_PRIMARY_ADDRESS' => 'Endere�o Principal:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Novo Usu�rio [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Novo Usu�rio',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Cor Favorita:',
  'LBL_MESSENGER_ID' => 'IM Nome:',
  'LBL_MESSENGER_TYPE' => 'IM Tipo:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'O nome do colaborador ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' j� existe. N�o � permitido duplicar nomes. Altere o nome para ser um nome unico.',
  'ERR_LAST_ADMIN_1' => 'O nome do colaborador "',
  'ERR_LAST_ADMIN_2' => '" � o �ltimo com acesso de administrador. Pelo menos um colaborador deve ser o administrador.',
  'LNK_NEW_EMPLOYEE' => 'Novo Colaborador',
  'LNK_EMPLOYEE_LIST' => 'Colaboradores',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a conta.',

  'LBL_DEFAULT_TEAM' => 'Equipe Padr�o:',
  'LBL_DEFAULT_TEAM_TEXT' => 'Selecione a equipe padr�o para novos registros',
  'LBL_MY_TEAMS' => 'Minhas Equipes',
  'LBL_LIST_DESCRIPTION' => 'Descri��o',
  'LNK_EDIT_TABS'=>'Editar Guias',
  'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => 'Tem certeza que deseja remover essa associa��o de colaborador?',

  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',

);


?>
