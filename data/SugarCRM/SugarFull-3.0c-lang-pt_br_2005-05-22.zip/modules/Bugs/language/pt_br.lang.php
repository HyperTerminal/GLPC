<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Bug Tracker',
  'LBL_MODULE_TITLE' => 'Bug Tracker: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Bug',
  'LBL_LIST_FORM_TITLE' => 'Lista de Bugs',
  'LBL_NEW_FORM_TITLE' => 'Novo Bug',
  'LBL_CONTACT_BUG_TITLE' => 'Bug-Contato:',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_BUG' => 'Defeito:',
  'LBL_BUG_NUMBER' => 'Bug #:',
  'LBL_NUMBER' => 'N�mero:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Prioridade:',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_CONTACT_NAME' => 'Nome do Contato:',
  'LBL_BUG_SUBJECT' => 'Assunto do Bug:',
  'LBL_CONTACT_ROLE' => 'Regra:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Prioridade',
  'LBL_LIST_RELEASE' => 'Release',
  'LBL_LIST_RESOLUTION' => 'Resolu��o',
  'LBL_LIST_LAST_MODIFIED' => '�ltima Altera��o',
  'LBL_INVITEE' => 'Contatos',
  'LBL_TYPE' => 'Tipo:',
  'LBL_LIST_TYPE' => 'Tipo',
  'LBL_RESOLUTION' => 'Resolu��o:',
  'LBL_RELEASE' => 'Release:',
  'LNK_NEW_BUG' => 'Reportar Bug',
  'LNK_BUG_LIST' => 'Bugs',
  'NTC_REMOVE_INVITEE' => 'Tem certeza que deseja remover este contato deste bug?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Tem certeza que deseja remover este bug desta conta?',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir o bug',
  'LBL_LIST_MY_BUGS' => 'Meus Bugs Atribu�dos',
  'LBL_FOUND_IN_RELEASE' => 'Encontrado na Release',
  'LBL_FIXED_IN_RELEASE' => 'Corrigido na Release',
  'LBL_WORK_LOG' => 'Work Log',
  'LBL_SOURCE' => 'Fonte',
  'LBL_PRODUCT_CATEGORY' => 'Categoria',
  'LBL_CREATED_BY' => 'Criado por:',
  'LBL_DATE_CREATED' => 'Criado em::',
  'LBL_MODIFIED_BY' => '�ltima altera��o por:',
  'LBL_DATE_LAST_MODIFIED' => '�ltima Altera��o em:',
  'LBL_LIST_EMAIL_ADDRESS' => 'Endere�o de Email',
  'LBL_LIST_CONTACT_NAME' => 'Nome do Contato',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_PHONE' => 'Fone',
  'NTC_DELETE_CONFIRMATION' => 'Tem certeza que deseja exclu�r este contato deste bug?',
  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' => 
  array (
    'Urgent' => 'Urgente',
    'High' => 'Alto',
    'Medium' => 'M�dio',
    'Low' => 'Baixo',
  ),
  'bug_resolution_default_key' => '',
  'bug_resolution_dom' => 
  array (
    '' => '',
    'Accepted' => 'Aceito',
    'Duplicate' => 'Duplicado',
    'Fixed' => 'Corrigido',
    'Out of Date' => 'Obsoleto',
    'Invalid' => 'Inv�lido',
    'Later' => 'Atrasado',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' => 
  array (
    'New' => 'Novo',
    'Assigned' => 'Atribu�do',
    'Closed' => 'Fechado',
    'Pending' => 'Pendente',
    'Rejected' => 'Rejeitado',
  ),
  'bug_type_default_key' => 'Bug',
  'bug_type_dom' => 
  array (
    'Defect' => 'Defeito',
    'Feature' => 'Caracter�stica',
  ),
);


?>
