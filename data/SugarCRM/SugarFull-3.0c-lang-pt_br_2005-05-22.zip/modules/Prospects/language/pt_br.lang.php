<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional End User
 * License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.5 2005/04/27 23:35:48 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Prospectos',
  'LBL_INVITEE' => 'Relat�rios Diretos',
  'LBL_MODULE_TITLE' => 'Prospectos: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Prospectos',
  'LBL_LIST_FORM_TITLE' => 'Lista de Prospectos',
  'LBL_NEW_FORM_TITLE' => 'Novo Prospecto',
  'LBL_PROSPECT' => 'Prospecto:',
  'LBL_BUSINESSCARD' => 'Cart�o de Visitas',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => '�ltimo Nome',
  'LBL_LIST_PROSPECT_NAME' => 'Nome do Prospecto',
  'LBL_LIST_TITLE' => 'Cargo',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Outro Email',
  'LBL_LIST_PHONE' => 'Fone',
  'LBL_LIST_PROSPECT_ROLE' => 'Perfil',
  'LBL_LIST_FIRST_NAME' => 'Primeiro Nome',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_PROSPECT' => 'Usado num contato existente',
  'LBL_CREATED_PROSPECT' => 'Criado um novo contato',
  'LBL_EXISTING_ACCOUNT' => 'Usada uma conta existente',
  'LBL_CREATED_ACCOUNT' => 'Criada uma nova conta',
  'LBL_CREATED_CALL' => 'Criada uma nova chamada',
  'LBL_CREATED_MEETING' => 'Criado um novo compromisso',
  'LBL_ADDMORE_BUSINESSCARD' => 'Incluir outro cart�o de visitas',
  'LBL_ADD_BUSINESSCARD' => 'Criar de Cart�o de Visitas',
  'LBL_NAME' => 'Name:',
  'LBL_PROSPECT_NAME' => 'Nome do Prospecto:',
  'LBL_PROSPECT_INFORMATION' => 'Informa��o do Prospecto',
  'LBL_FIRST_NAME' => 'Primeiro Nome:',
  'LBL_OFFICE_PHONE' => 'Fone Comercial',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
  'LBL_ANY_PHONE' => 'Outro Fone:',
  'LBL_PHONE' => 'Fone:',
  'LBL_LAST_NAME' => '�ltimo Nome:',
  'LBL_MOBILE_PHONE' => 'Celular:',
  'LBL_HOME_PHONE' => 'Principal:',
  'LBL_OTHER_PHONE' => 'Outro Fone:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Rua Endere�o Prim�rio:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Cidade Endere�o Prim�rio:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Pa�s  Endere�o Prim�rio:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Estado  Endere�o Prim�rio:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'CEP  Endere�o Prim�rio:',
  'LBL_ALT_ADDRESS_STREET' => 'Rua Endere�o Alternativo:',
  'LBL_ALT_ADDRESS_CITY' => 'Cidade Endere�o Alternativo:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Pa�s Endere�o Alternativo:',
  'LBL_ALT_ADDRESS_STATE' => 'Estado Endere�o Alternativo:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'CEP Endere�o Alternativo:',
  'LBL_TITLE' => 'Cargo:',
  'LBL_DEPARTMENT' => 'Departamento:',
  'LBL_BIRTHDATE' => 'Data Nascimento:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Outro Email:',
  'LBL_ANY_EMAIL' => 'Email qualquer:',
  'LBL_ASSISTANT' => 'Assistente:',
  'LBL_ASSISTANT_PHONE' => 'Fone do Assistente:',
  'LBL_DO_NOT_CALL' => 'N�o Chamar:',
  'LBL_EMAIL_OPT_OUT' => 'N�o Deseja Emails:',
  'LBL_PRIMARY_ADDRESS' => 'Endere�o Principal:',
  'LBL_ALTERNATE_ADDRESS' => 'Endere�o Alternativo:',
  'LBL_ANY_ADDRESS' => 'Outro Endere�o:',
  'LBL_CITY' => 'Cidade:',
  'LBL_STATE' => 'Estado:',
  'LBL_POSTAL_CODE' => 'CEP:',
  'LBL_COUNTRY' => 'Pa�s:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_ADDRESS_INFORMATION' => 'Informa��o de Endere�o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_PROSPECT_ROLE' => 'Papel:',
  'LBL_OPP_NAME' => 'Nome da Oportunidade:',
  'LBL_IMPORT_VCARD' => 'Importar vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Criar novo contato automaticamente importando um vCard de seus arquivos.',
  'LBL_DUPLICATE' => 'Prospectos Possivelmente Duplicados',
  'MSG_SHOW_DUPLICATES' => 'Criando este contato pode duplicar um contato. Voc� pode clicar em Criar Contato para continuar ou escolher Cancelar.',
  'MSG_DUPLICATE' => 'Criando este contato pode duplicar um contato. Voc� pode selecionar um contado da lista abaixo ou clicar em Criar Contato para continuar criando com os dados entrados previamente.',
  'LNK_PROSPECT_LIST' => 'Contatos',
  'LNK_IMPORT_VCARD' => 'Criar de vCard',
  'LNK_NEW_PROSPECT' => 'Novo Prospecto',
  'LNK_NEW_ACCOUNT' => 'Nova Conta',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_NEW_CASE' => 'Nova Ocorr�ncia',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_APPOINTMENT' => 'Novo Compromisso',
  'NTC_DELETE_CONFIRMATION' => 'Tem certeza que deseja excluir este registro?',
  'NTC_REMOVE_CONFIRMATION' => 'Tem certeza que deseja remover este contato desta ocorr�ncia?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Tem certeza que deseja remover este registro como um reporter direto?',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir o contato.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copiar endere�o principal para endere�o alternativo',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copiar endere�o alternativo para endere�o principal',
  'LBL_SALUTATION' => 'Sauda��o',
  'LBL_SAVE_PROSPECT' => 'Salvar Contato',
  'LBL_CREATED_OPPORTUNITY' =>'Criada uma nova oportunidade',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Criar uma oportunidade requer uma conta.\n Por favor, cria uma nova ou selecione uma existente.',
  'LNK_SELECT_ACCOUNT' => "Selecionar Conta",
  'LNK_NEW_PROSPECT' => 'Novo Prospecto',
  'LNK_PROSPECT_LIST' => 'Prospectos',  
  'LNK_NEW_CAMPAIGN' => 'Nova Campanha',
  'LNK_CAMPAIGN_LIST' => 'Campanhas',
  'LNK_NEW_PROSPECT_LIST' => 'Nova Lista de Prospectos',
  'LNK_PROSPECT_LIST_LIST' => 'Lista de Prospectos',
  'LNK_IMPORT_PROSPECT' => 'Importar Prospectos',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Selecionar Prospectos Marcados',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Selecionar Prospectos Marcados',
  'LBL_INVALID_EMAIL'=>'Email Inv�lido:',
);


?>
