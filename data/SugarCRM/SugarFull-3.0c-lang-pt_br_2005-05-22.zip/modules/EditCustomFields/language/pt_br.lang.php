<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional End User
 * License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
// $Id: en_us.lang.php,v 1.10 2005/04/20 05:06:33 bob Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Editar Campo Personalizado',
	'LBL_ADD_FIELD'=> 'Incluir Campo:',
	'LBL_MODULE_TITLE' => 'Editar Campo Personalizado',
	'LBL_MODULE_SELECT' => 'Modulo para Editar',
	'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Modulo',
	'COLUMN_TITLE_NAME' => 'Nome do Campo',
	'COLUMN_TITLE_LABEL' => 'R�tulo do Campo',
	'COLUMN_TITLE_DATA_TYPE' => 'Tipo de Dado',
	'COLUMN_TITLE_MAX_SIZE' => 'Tamanho M�ximo',
	'COLUMN_TITLE_REQUIRED_OPTION' => 'Campo Obrigat�rio',
	'COLUMN_TITLE_DEFAULT_VALUE' => 'Valor Padr�o',
	'COLUMN_TITLE_EXT1' => 'Meta Campo Extra 1',
	'COLUMN_TITLE_EXT2' => 'Meta Campo Extra 2',
	'COLUMN_TITLE_EXT3' => 'Meta Campo Extra 3',
	'LBL_DROP_DOWN_LIST' => 'Lista Suspensa',
	'MSG_DELETE_CONFIRM' => 'Tem certeza que deseja excluir esse item?',
	'POPUP_INSERT_HEADER_TITLE' => 'Incluir Campo Personalizado',
	'POPUP_EDIT_HEADER_TITLE' => 'Editar Campo Personalizado',
	'LNK_SELECT_CUSTOM_FIELD' => 'Selecionar Campo Personalizado',
);
?>
