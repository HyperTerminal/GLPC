<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Chamadas',
  'LBL_MODULE_TITLE' => 'Chamadas: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Chamadas',
  'LBL_LIST_FORM_TITLE' => 'Lista de Chamadas',
  'LBL_NEW_FORM_TITLE' => 'Agendar Chamada',
  'LBL_LIST_CLOSE' => 'Fechar',
  'LBL_LIST_SUBJECT' => 'Assunto',
  'LBL_LIST_CONTACT' => 'Contato',
  'LBL_LIST_RELATED_TO' => 'Relacionada a',
  'LBL_LIST_DATE' => 'Data In�cio',
  'LBL_LIST_TIME' => 'Hora In�cio',
  'LBL_LIST_DURATION' => 'Dura��o',
  'LBL_LIST_DIRECTION' => 'Dire��o',
  'LBL_SUBJECT' => 'Assunto:',
  'LBL_REMINDER' => 'Lembrete:',
  'LBL_CONTACT_NAME' => 'Contato:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informa��o de Descri��o',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_STATUS' => 'Situa��o:',
  'LBL_DIRECTION' => 'Dire��o:',
  'LBL_DATE' => 'Data In�cio:',
  'LBL_DURATION' => 'Dura��o:',
  'LBL_DURATION_HOURS' => 'Duration Horas:',
  'LBL_DURATION_MINUTES' => 'Duration Minutos:',
  'LBL_HOURS_MINUTES' => '(horas/minutos)',
  'LBL_CALL' => 'Chamada:',
  'LBL_DATE_TIME' => 'Data & Hora In�cio:',
  'LBL_TIME' => 'Hora In�cio:',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planejada',
  'LNK_NEW_CALL' => 'Nova Chamada',
  'LNK_NEW_MEETING' => 'Novo Compromisso',
  'LNK_NEW_TASK' => 'Nova Tarefa',
  'LNK_NEW_NOTE' => 'Nova Anota��o',
  'LNK_NEW_EMAIL' => 'Novo Email',
  'LNK_CALL_LIST' => 'Chamadas',
  'LNK_MEETING_LIST' => 'Compromissos',
  'LNK_TASK_LIST' => 'Tarefas',
  'LNK_NOTE_LIST' => 'Anota��es',
  'LNK_EMAIL_LIST' => 'Emails',
  'LNK_VIEW_CALENDAR' => 'Hoje',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a chamada.',
  'NTC_REMOVE_INVITEE' => 'Tem certeza que quer remover este convidado da chamada?',
  'LBL_INVITEE' => 'Convidados',
  'LBL_RELATED_TO' => 'Relacionado a:',
  'LNK_NEW_APPOINTMENT' => 'Novo Compromisso',
  'LBL_SCHEDULING_FORM_TITLE' => 'Agendamento',
  'LBL_ADD_INVITEE' => 'Incluir Convites',
  'LBL_NAME' => 'Nome',
  'LBL_FIRST_NAME' => 'Primeiro Nome',
  'LBL_LAST_NAME' => '�ltimo Nome',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Fone',
  'LBL_REMINDER' => 'Lembrete:',
  'LBL_SEND_BUTTON_TITLE'=>'Enviar Convites [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'Enviar Convites',
  'LBL_DATE_END'=>'Data Final',
  'LBL_TIME_END'=>'Hora Final',
  'LBL_REMINDER_TIME'=>'Tempo do Lembrete',

   'LBL_SEARCH_BUTTON'=> 'Pesquisar',
   'LBL_ADD_BUTTON'=> 'Incluir',

);


?>
