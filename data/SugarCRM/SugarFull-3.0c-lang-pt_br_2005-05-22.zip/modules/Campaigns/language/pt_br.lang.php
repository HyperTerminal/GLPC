<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional End User
 * License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.10 2005/04/29 21:19:58 joey Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Campanhas',
  'LBL_MODULE_TITLE' => 'Campanhas: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Campanhas',
  'LBL_LIST_FORM_TITLE' => 'Lista de Campanhas',
  'LBL_CAMPAIGN_NAME' => 'Nome:',
  'LBL_CAMPAIGN' => 'Campanha:',
  'LBL_NAME' => 'Nome: ',
  'LBL_INVITEE' => 'Contatos',
  'LBL_LIST_CAMPAIGN_NAME' => 'Campanha',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_TYPE' => 'Tipo',
  'LBL_LIST_END_DATE' => 'Data Final',
  'LBL_DATE_ENTERED' => 'Data Entrada',
  'LBL_DATE_MODIFIED' => 'Data Altera��o',
  'LBL_MODIFIED' => 'Alterada por: ',
  'LBL_CREATED' => 'Criada por: ',
  'LBL_TEAM' => 'Equipe: ',
  'LBL_ASSIGNED_TO' => 'Atribu�do a: ',
  'LBL_CAMPAIGN_START_DATE' => 'Data de In�cio: ',
  'LBL_CAMPAIGN_END_DATE' => 'Data de Encerramento: ',
  'LBL_CAMPAIGN_STATUS' => 'Status: ',
  'LBL_CAMPAIGN_BUDGET' => 'Or�amento: ',
  'LBL_CAMPAIGN_EXPECTED_COST' => 'Custo Esperado: ',
  'LBL_CAMPAIGN_ACTUAL_COST' => 'Custo Real: ',
  'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Receita Esperada: ',
  'LBL_CAMPAIGN_TYPE' => 'Tipo: ',
  'LBL_CAMPAIGN_OBJECTIVE' => 'Objetivo: ',
  'LBL_CAMPAIGN_CONTENT' => 'Descri��o: ',
  'LNK_NEW_CAMPAIGN' => 'Nova Campanha',
  'LNK_CAMPAIGN_LIST' => 'Campanhas',
  'LNK_NEW_PROSPECT' => 'Novo Prospecto',
  'LNK_PROSPECT_LIST' => 'Prospectos',
  'LNK_NEW_PROSPECT_LIST' => 'Nova Lista de Prospectos',
  'LNK_PROSPECT_LIST_LIST' => 'Lista de Prospectos',
  'LBL_MODIFIED_BY' => 'Alterado por: ',
  'LBL_CREATED_BY' => 'Criado por: ',
  'LBL_DATE_CREATED' => 'Data Cria��o: ',
  'LBL_DATE_LAST_MODIFIED' => 'Data Altera��o: ',
  'LBL_TRACKER_KEY' => 'Tracker: ',
  'LBL_TRACKER_URL' => 'Tracker URL: ',
  'LBL_TRACKER_TEXT' => 'Tracker Link Texto: ',
  'LBL_TRACKER_COUNT' => 'Tracker Contador: ',
  'LBL_REFER_URL' => 'Tracker URL Redirecionamento: ',
);


?>
