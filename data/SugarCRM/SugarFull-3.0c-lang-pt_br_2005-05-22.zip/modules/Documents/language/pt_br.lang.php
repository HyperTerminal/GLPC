<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Professional End User
 * License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.10 2005/04/29 06:50:17 clint Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Documentos',
	'LBL_MODULE_TITLE' => 'Documentos: Principal',
	'LNK_NEW_DOCUMENT' => 'Novo Documento',
	'LNK_DOCUMENT_LIST'=> 'Lista de Documentos',
	'LBL_DOC_REV_HEADER' => 'Revis�es do Documento',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'Id Documento',	
	'LBL_NAME' => 'Nome do Documento',
	'LBL_DESCRIPTION' => 'Descri��o',
	'LBL_CATEGORY' => 'Categoria',
	'LBL_SUBCATEGORY' => 'Sub Categoria',
	'LBL_STATUS' => 'Status', 
	'LBL_CREATED_BY'=> 'Criado por',
	'LBL_DATE_ENTERED'=> 'Data Entrada',
	'LBL_DATE_MODIFIED'=> 'Data Altera��o',
	'LBL_DELETED' => 'Exclu�do',
	'LBL_MODIFIED'=> 'Alterado por',
	'LBL_CREATED'=> 'Criado por',
	
	'LBL_REVISION_NAME' => 'N�mero da Revis�o',
	'LBL_FILENAME' => 'Nome do Arquivo',
	'LBL_MIME' => 'Tipo Mime',
	'LBL_REVISION' => 'Revis�o',
	'LBL_DOCUMENT' => 'Documento Relacionado',
	'LBL_LATEST_REVISION' => '�ltima Revis�o',
	'LBL_CHANGE_LOG'=> 'Registro de Altera��o',
	'LBL_ACTIVE_DATE'=> 'Data de Publica��o',
	'LBL_EXPIRATION_DATE' => 'Data de Expira��o',
	'LBL_FILE_EXTENSION'  => 'Extens�o do Arquivo',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Nome Documento:',
	'LBL_FILENAME' => 'Nome Arquivo:',
	'LBL_DOC_VERSION' => 'Revis�o:',
	'LBL_CATEGORY_VALUE' => 'Categoria:',
	'LBL_SUBCATEGORY_VALUE'=> 'Sub Categoria:',
	'LBL_DOC_STATUS'=> 'Status:',
	'LBL_LAST_REV_CREATOR' => 'Revis�o Criada por:',
	'LBL_LAST_REV_DATE' => 'Data da Revis�o:',
	'LBL_DOWNNLOAD_FILE'=> 'Transferir Arquivo:',
	

	'LBL_TEAM'=> 'Time:',

	'LBL_DOC_DESCRIPTION'=>'Descri��o:',
	'LBL_DOC_ACTIVE_DATE'=> 'Data de Publica��o:',
	'LBL_DOC_EXP_DATE'=> 'Data de Expira��o:',
	
	//document list view.	
	'LBL_LIST_FORM_TITLE' => 'Lista de Documentos',	
	'LBL_LIST_DOCUMENT' => 'Documento',
	'LBL_LIST_CATEGORY' => 'Categoria',
	'LBL_LIST_SUBCATEGORY' => 'Sub Categoria',
	'LBL_LIST_REVISION' => 'Revis�o',
	'LBL_LIST_LAST_REV_CREATOR' => 'Publicado por',
	'LBL_LIST_LAST_REV_DATE' => 'Data Revis�o',
	'LBL_LIST_VIEW_DOCUMENT'=>'Visualizar',
	'LBL_LIST_ACTIVE_DATE' => 'Data Publica��o',
	'LBL_LIST_EXP_DATE' => 'Data Expira��o',
	
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Revis�es',
	'LBL_REV_LIST_ENTERED' => 'Data de Cria��o',
	'LBL_REV_LIST_CREATED' => 'Criado por',
	'LBL_REV_LIST_LOG'=> 'Registro de Altera��es',
	
	'LBL_CURRENT_DOC_VERSION'=> 'Revis�o Atual:',
	'LBL_CHANGE_LOG'=> 'Registro de Altera��es:',
	'LBL_SEARCH_FORM_TITLE'=> 'Pesquisar Documentos',
	//document search form.
	'LBL_SF_DOCUMENT' => 'Documento:',
	'LBL_SF_CATEGORY' => 'Categoria:',
	'LBL_SF_SUBCATEGORY'=> 'Sub Categoria:',
	'LBL_SF_ACTIVE_DATE' => 'Data de Publica��o:',
	'LBL_SF_EXP_DATE'=> 'Data de Expira��o:',
	
	'DEF_CREATE_LOG' => 'Documento Criado',
	
	//error messages
	'ERR_DOC_NAME'=>'Nome Documento',
	'ERR_DOC_ACTIVE_DATE'=>'Data de Publica��o',
	'ERR_DOC_EXP_DATE'=> 'Data de Expira��o',
	'ERR_FILENAME'=> 'Nome do Arquivo',
	'ERR_DOC_VERSION'=> 'Vers�o do Documento',
	'ERR_DELETE_CONFIRM'=> 'Tem certeza que deseja excluir essa revis�o do documento?',
	'ERR_DELETE_LATEST_VERSION'=> 'Voc� n�o possue permiss�o para excluir a �ltima revis�o do documento.',

);


?>
