<?php
/**
 * Default English language strings
 *
 * PHP version 4
 *
 * The contents of this file are subject to the SugarCRM Professional End User
 * License Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/EULA.  By installing or using this file, You have
 * unconditionally agreed to the terms and conditions of the License, and You
 * may not use this file except in compliance with the License.  Under the
 * terms of the license, You shall not, among other things: 1) sublicense,
 * resell, rent, lease, redistribute, assign or otherwise transfer Your
 * rights to the Software, and 2) use the Software for timesharing or service
 * bureau purposes such as hosting the Software for commercial gain and/or for
 * the benefit of a third party.  Use of the Software may be subject to
 * applicable fees and any use of the Software without first paying applicable
 * fees is strictly prohibited.  You do not have the right to remove SugarCRM
 * copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 */

// $Id: en_us.lang.php,v 1.18.2.2 2005/05/09 22:37:40 ajay Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Tarefas do Projeto',
	'LBL_MODULE_TITLE' => 'Tarefas do Projeto: Principal',
	'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Tarefas do Projeto',
	'LBL_LIST_FORM_TITLE'=> 'Lista de Tarefas do Projeto',
	
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Data Entrada:',
	'LBL_DATE_MODIFIED' => 'Data Alterada:',
	'LBL_ASSIGNED_USER_ID' => 'Atribuido a:',
	'LBL_MODIFIED_USER_ID' => 'Id Usu�rio Modificador:',
	'LBL_CREATED_BY' => 'Criado por:',
	'LBL_TEAM_ID' => 'Equipe:',
	'LBL_NAME' => 'Nome:',
	'LBL_STATUS' => 'Status:',
	'LBL_DATE_DUE' => 'Data Devida:',
	'LBL_TIME_DUE' => 'Hora Devida:',
	'LBL_DATE_START' => 'Data Inicial:',
	'LBL_TIME_START' => 'Hora Inicial:',
	'LBL_PARENT_ID' => 'Projeto:',
	'LBL_PRIORITY' => 'Prioridade:',
	'LBL_DESCRIPTION' => 'Descri��o:',
	'LBL_ORDER_NUMBER' => 'Ordem:',
	'LBL_TASK_NUMBER' => 'N�mero da Tarefa:',
	'LBL_DEPENDS_ON_ID' => 'Depende de:',
	'LBL_MILESTONE_FLAG' => 'Marco:',
	'LBL_ESTIMATED_EFFORT' => 'Esfor�o Estimado (hrs):',
	'LBL_ACTUAL_EFFORT' => 'Esfor�o Real (hrs):',
	'LBL_UTILIZATION' => 'Utiliza��o (%):',
	'LBL_PERCENT_COMPLETE' => 'Progresso (%):',
	'LBL_DELETED' => 'Exclu�do:',

	'LBL_LIST_ORDER_NUMBER' => 'Ordem',
	'LBL_LIST_NAME' => 'Nome',
	'LBL_LIST_PARENT_NAME' => 'Projeto',
	'LBL_LIST_PERCENT_COMPLETE' => 'Progresso (%)',
	'LBL_LIST_STATUS' => 'Status',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Atribu�do a',
	'LBL_LIST_DATE_DUE' => 'Data Devida',
	'LBL_LIST_DATE_START' => 'Data Inicial',
	'LBL_LIST_PRIORITY' => 'Prioridade',
	
	'LBL_PROJECT_NAME' => 'Nome do Projeto',
	
	'LBL_LIST_MY_PROJECT_TASKS' => 'Minhas Tarefas de Projeto Abertas',
	'LBL_LIST_CLOSE' => 'Fechar',

	'LNK_NEW_PROJECT'	=> 'Novo Projeto',
	'LNK_PROJECT_LIST'	=> 'Lista de Projetos',
	'LNK_NEW_PROJECT_TASK'	=> 'Nova Tarefa de Projeto',
	'LNK_PROJECT_TASK_LIST'	=> 'Tarefas de Projetos',

);
?>
