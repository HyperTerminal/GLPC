<?php
/*********************************************************************************
 *The contents of this file are subject to the SugarCRM Professional End User License Agreement
 *("License") which can be viewed at http://www.sugarcrm.com/EULA.
 *By installing or using this file, You have unconditionally agreed to the terms and conditions of the License, and You may
 *not use this file except in compliance with the License. Under the terms of the license, You
 *shall not, among other things: 1) sublicense, resell, rent, lease, redistribute, assign or
 *otherwise transfer Your rights to the Software, and 2) use the Software for timesharing or
 *service bureau purposes such as hosting the Software for commercial gain and/or for the benefit
 *of a third party.  Use of the Software may be subject to applicable fees and any use of the
 *Software without first paying applicable fees is strictly prohibited.  You do not have the
 *right to remove SugarCRM copyrights from the source code or user interface.
 * All copies of the Covered Code must include on each user interface screen:
 * (i) the "Powered by SugarCRM" logo and
 * (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for requirements.
 *Your Warranty, Limitations of liability and Indemnity are expressly stated in the License.  Please refer
 *to the License for the specific language governing these rights and limitations under the License.
 *Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: sync_lang.php $
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Oportunidades',
  'LBL_MODULE_TITLE' => 'Oportunidades: Principal',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Oportunidades',
  'LBL_LIST_FORM_TITLE' => 'Lista de Oportunidades',
  'LBL_OPPORTUNITY_NAME' => 'Nome da Oportunidade:',
  'LBL_OPPORTUNITY' => 'Oportunidade:',
  'LBL_NAME' => 'Nome da Oportunidade',
  'LBL_INVITEE' => 'Contatos',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Oportunidade',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome da Conta',
  'LBL_LIST_AMOUNT' => 'Valor',
  'LBL_LIST_DATE_CLOSED' => 'Data Prevista',
  'LBL_LIST_SALES_STAGE' => 'Est�gio Vendas',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Oportunidade - Atualizar Cota��es',
  'UPDATE_DOLLARAMOUNTS' => 'Atualizar Valores em U.S. Dollar',
  'UPDATE_VERIFY' => 'Verificar Valores',
  'UPDATE_VERIFY_TXT' => 'Verifica se os valores nas oportunidades s�o v�lidos com somente dados num�ricos (0-9) e ponto decimal (.)',
  'UPDATE_FIX' => 'Corrigir Valores',
  'UPDATE_FIX_TXT' => 'Tenta corrigir qualquer valor inv�lido criando um valor com casas decimais a partir do valor atual. Ser� feito o backup de qualquer valor alterado no banco de dados. Caso voc� execute este procedimento e receba uma mensagem de problemas, n�o execute novamente antes de restaurar o backup, pois de outra forma o backup pode ser sobrescrito com dados inv�lidos.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Atualiza os valores em U.S. Dollar nas oportunidades baseado na taxa de cota��o atual. Este valor ser� utilizado para calcular os Gr�ficos e Listas com Valores de Cota��es.',
  'UPDATE_CREATE_CURRENCY' => 'Criando Nova Cota��o:',
  'UPDATE_VERIFY_FAIL' => 'Verifica��o de Registros Falhou:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Valor Corrente:',
  'UPDATE_VERIFY_FIX' => 'Executando Corre��es pode trazer',
  'UPDATE_INCLUDE_CLOSE' => 'Incluir Registros Fechados',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Novo Valor:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nova Moeda:',
  'UPDATE_DONE' => 'Feito',
  'UPDATE_BUG_COUNT' => 'Encontrados Bugs e Tentativas de Resolver:',
  'UPDATE_BUGFOUND_COUNT' => 'Bugs Encontrados:',
  'UPDATE_COUNT' => 'Registros Atualizados:',
  'UPDATE_RESTORE_COUNT' => 'Valores de Registros Restaurados:',
  'UPDATE_RESTORE' => 'Restaurar Valores',
  'UPDATE_RESTORE_TXT' => 'Restaurar valores a partir do backup criado durante a Resolu��o.',
  'UPDATE_FAIL' => 'Imposs�vel atualizar - ',
  'UPDATE_NULL_VALUE' => 'Valor � nulo definindo como 0 -',
  'UPDATE_MERGE' => 'Mesclar Moedas',
  'UPDATE_MERGE_TXT' => 'Mescla multiplas moedas em uma moeda �nica. Caso voc� seja informado que existem m�ltiplos registros de moedas para a mesma moeda, voc� pode optar por mescl�-ros. Isto tamb�m ira mesclar moedas para todos os demais m�dulos.',
  'LBL_ACCOUNT_NAME' => 'Nome da Conta:',
  'LBL_AMOUNT' => 'Valor:',
  'LBL_CURRENCY' => 'Moeda:',
  'LBL_DATE_CLOSED' => 'Data Prevista:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_NEXT_STEP' => 'Pr�ximo Passo:',
  'LBL_LEAD_SOURCE' => 'Fonte:',
  'LBL_SALES_STAGE' => 'Est�gio Venda:',
  'LBL_PROBABILITY' => 'Probabilidade (%):',
  'LBL_DESCRIPTION' => 'Descri��o:',
  'LBL_DUPLICATE' => 'Possivel Oportunidade Duplicada',
  'MSG_DUPLICATE' => 'Criando esta oportunidade pode duplicar uma oportunidade. Voc� pode selecionar uma oportunidade da lista abaixo ou clicar em Criar Oportunidade para continuar criando com os dados entrados previamente.',
  'LBL_NEW_FORM_TITLE' => 'Nova Oportunidade',
  'LNK_NEW_OPPORTUNITY' => 'Nova Oportunidade',
  'LNK_OPPORTUNITY_LIST' => 'Oportunidades',
  'ERR_DELETE_RECORD' => 'Um n�mero de registro deve ser especificado para excluir a oportunidade.',
  'LBL_TOP_OPPORTUNITIES' => 'Minhas Melhores Oportunidades',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Tem certeza que quer remover este contato desta oportunidade?',
  'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Tem certeza que deseja remover essa oportunidade deste projeto?',
  'LBL_AMOUNT_BACKUP'=>'Valor Backup',

);


?>
