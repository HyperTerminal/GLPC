<?PHP

// manifest file for information regarding application of new code
$manifest = array(
    // only install on the following regex sugar versions (if empty, no check)
    'acceptable_sugar_versions' => array (
        'exact_matches' => array (),
        'regex_matches' => array (  0 => '3\\.5\\.1*' ),
    ),

    // name of new code
    'name' => 'da_dk language pack',

    // description of new code
    'description' => 'Danish translation for all SugarCRM version',

    // author of new code
    'author' => 'Morten Amby of ALCO Company',

    // date published
    'published_date' => '2005/11/3',

    // version of code
    'version' => '0.1',

    // uninstallable
    'is_uninstallable' => 'Yes',

    // type of code (valid choices are: full, langpack, module, patch, theme )
    'type' => 'langpack',

    // icon for displaying in UI (path to graphic contained within zip package)
    'icon' => 'include/images/flag-da_dk.gif',
);



$installdefs = array(
                'id'=> 'danish',
                'image_dir'=>'<basepath>/images',
                'copy' => array(
                            array('from'=> '<basepath>/include',
                                  'to'=> 'include',
                                 ),
                            array('from'=> '<basepath>/modules',
                                  'to'=> 'modules',
                                 ),
                          ),        
               );
?>
