<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.16 2006/03/15 20:10:22 roger Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Fejlrapportering',
  'LBL_MODULE_TITLE' => 'Fejlrapportering: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Fejls&oslash;gning',
  'LBL_LIST_FORM_TITLE' => 'Fejlliste',
  'LBL_NEW_FORM_TITLE' => 'Ny fejlrapport',
  'LBL_CONTACT_BUG_TITLE' => 'Kontakt-Fejlrapport:',
  'LBL_SUBJECT' => 'Emne:',
  'LBL_BUG' => 'Fejl:',
  'LBL_BUG_NUMBER' => 'Fejlnummer:',
  'LBL_NUMBER' => 'Nummer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Prioritet:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_CONTACT_NAME' => 'Kontaktnavn:',
  'LBL_BUG_SUBJECT' => 'Fejlemne:',
  'LBL_CONTACT_ROLE' => 'Rolle:',
  'LBL_LIST_NUMBER' => 'Nr.',
  'LBL_LIST_SUBJECT' => 'Emne',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Prioritet',
  'LBL_LIST_RELEASE' => 'Udgave',
  'LBL_LIST_RESOLUTION' => 'L&oslash;sning',
  'LBL_LIST_LAST_MODIFIED' => 'Sidst &aelig;ndret',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_TYPE' => 'Type:',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_RESOLUTION' => 'L&oslash;sning:',
  'LBL_RELEASE' => 'Udgave:',
  'LNK_NEW_BUG' => 'Rapporter fejl',
  'LNK_BUG_LIST' => 'Fejl',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p&arin; du &oslash;nsker at fjerne denne bruger fra fejlrapporten?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne denne fejlrapport fra denne konto?',
  'ERR_DELETE_RECORD' => 'Et element-id skal specificeres for at slette denne fejlrapport.',
  'LBL_LIST_MY_BUGS' => 'Mine tildelte fejl',
  
  'LBL_FOUND_IN_RELEASE' => 'Fundet i udgave:',
  'LBL_FIXED_IN_RELEASE' => 'Rettet i udgave:',
  'LBL_WORK_LOG' => 'Arbejdslogbog:',
  'LBL_SOURCE' => 'Kilde:',
  'LBL_PRODUCT_CATEGORY' => 'Kategori:',
  
  'LBL_CREATED_BY' => 'Oprettet af:',
  'LBL_DATE_CREATED' => 'Oprettet d.:',
  'LBL_MODIFIED_BY' => 'Sidst &aelig;ndret af:',
  'LBL_DATE_LAST_MODIFIED' => '&Aelig;ndret d.:',

  'LBL_LIST_EMAIL_ADDRESS' => 'E-mail adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktnavn',
  'LBL_LIST_ACCOUNT_NAME' => 'Kontonavn',
  'LBL_LIST_PHONE' => 'Telefon',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&arin; du &oslash;nsker at fjerne denne kontakt fra fejlrapporten?',
  
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Fejlrapportering',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Konti',
  'LBL_CASES_SUBPANEL_TITLE' => 'Sager',
  'LBL_SYSTEM_ID' => 'System ID',
    
  );


?>
