<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.41 2006/01/17 22:54:35 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD' => 'Et datanummer skal angives for at slette denne konto.',
	'LBL_ACCOUNT_ID' => 'Konto ID:',
	'LBL_CASE_ID' => 'Sag ID:',
	'LBL_CLOSE' => 'Luk:',
	'LBL_COLON' => ':',
	'LBL_CONTACT_ID' => 'Kontakt ID:',
	'LBL_CONTACT_NAME' => 'Kontakt:',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Noter',
	'LBL_DESCRIPTION' => 'Beskrivelse',
	'LBL_EMAIL_ADDRESS' => 'E-mail adresse:',
	'LBL_FILE_MIME_TYPE' => 'Filtype',
	'LBL_FILE_URL' => 'Fil-URL',
	'LBL_FILENAME' => 'Vedh&aelig;ftning:',
	'LBL_LEAD_ID' => 'Emne ID:',
	'LBL_LIST_CONTACT_NAME' => 'Kontakt',
	'LBL_LIST_DATE_MODIFIED' => 'Sidste &aelig;ndring',
	'LBL_LIST_FILENAME' => 'Vedh&aelig;ftning',
	'LBL_LIST_FORM_TITLE' => 'Noteliste',
	'LBL_LIST_RELATED_TO' => 'Relateret til',
	'LBL_LIST_SUBJECT' => 'Emne',
	'LBL_LIST_STATUS' => 'Status',
	'LBL_LIST_CONTACT' => 'Kontakt',
	'LBL_MODULE_NAME' => 'Noter',
	'LBL_MODULE_TITLE' => 'Noter: Hjem',
	'LBL_NEW_FORM_TITLE' => 'Opret note eller vedh&aelig;ftning',
	'LBL_NOTE_STATUS' => 'Note',
	'LBL_NOTE_SUBJECT' => 'Note emne:',
	'LBL_NOTE' => 'Note:',
	'LBL_OPPORTUNITY_ID' => 'Mulighed ID:',
	'LBL_PARENT_ID' => 'For&aelig;ldre ID:',
	'LBL_PARENT_TYPE' => 'For&aelig;ldretype',
	'LBL_PHONE' => 'Telefon:',
	'LBL_PORTAL_FLAG' => 'Vis i portal?',
	'LBL_PRODUCT_ID' => 'Produkt ID:',
	'LBL_QUOTE_ID' => 'Tilbud ID:',
	'LBL_RELATED_TO' => 'Relateret til:',
	'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i noter',
	'LBL_STATUS' => 'Status',
	'LBL_SUBJECT' => 'Emne:',
	'LNK_CALL_LIST' => 'Opkald',
	'LNK_EMAIL_LIST' => 'E-mails',
	'LNK_IMPORT_NOTES' => 'Importer noter',
	'LNK_MEETING_LIST' => 'M&oslash;der',
	'LNK_NEW_CALL' => 'Skemal&aelig;g opkald',
	'LNK_NEW_EMAIL' => 'Arkiver e-mail',
	'LNK_NEW_MEETING' => 'Skemal&aelig;g m&oslash;de',
	'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
	'LNK_NEW_TASK' => 'Opret opgave',
	'LNK_NOTE_LIST' => 'Noter',
	'LNK_TASK_LIST' => 'Opgaver',
	'LNK_VIEW_CALENDAR' => 'I dag',
	'LBL_MEMBER_OF' => 'Medlem af:',
);

?>
