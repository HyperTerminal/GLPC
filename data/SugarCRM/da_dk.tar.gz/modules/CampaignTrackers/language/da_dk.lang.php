<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.3 2006/03/15 00:07:47 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_ID'=>'Id',
	'LBL_TRACKER_KEY'=>'Sporhund n&oslash;gle',
	'LBL_TRACKER_URL'=>'Sporhund URL',
	'LBL_TRACKER_NAME'=>'Sporhund navn',
	'LBL_CAMPAIGN_ID'=>'Kampagne-id',
	'LBL_DATE_ENTERED'=>'Oprettet d.',
	'LBL_DATE_MODIFIED'=>'&Aelig;ndret d.',
	'LBL_MODIFIED_USER_ID'=>'&Aelig;ndret Bruger-idModified User Id',
	'LBL_CREATED_BY'=>'Oprettet af',
	'LBL_DELETED'=>'Slettet',
	'LBL_CAMPAIGN'=>'Kampagne',
	'LBL_OPTOUT'=>'Frav&aelig;lg',
	
	'LBL_MODULE_NAME'=>'Kampagne sporhunde',
	'LBL_EDIT_CAMPAIGN_NAME'=>'Kampagnenavn:',
	'LBL_EDIT_TRACKER_NAME'=>'Sporhund navn:',
	'LBL_EDIT_TRACKER_URL'=>'Sporhund URL:',
	
	'LBL_SUBPANEL_TRACKER_NAME'=>'Navn',
	'LBL_SUBPANEL_TRACKER_URL'=>'URL',
	'LBL_SUBPANEL_TRACKER_KEY'=>'N&oslash;gle',
	'LBL_EDIT_MESSAGE_URL'=>'URL til kampagnemeddelelse:',
	'LBL_EDIT_TRACKER_KEY'=>'Sporhund n&oslash;gle:',
	'LBL_EDIT_OPT_OUT'=>'Frav&aelig;lg link?',
	'LNK_CAMPAIGN_LIST'=>'Kampagner',
);

?>
