<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.52 2006/03/08 21:10:52 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Muligheder',
  'LBL_MODULE_TITLE' => 'Muligheder: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i muligheder',
  'LBL_LIST_FORM_TITLE' => 'Mulighedsliste',
  'LBL_OPPORTUNITY_NAME' => 'Mulighedsnavn:',
  'LBL_OPPORTUNITY' => 'Mulighed:',
  'LBL_NAME' => 'Mulighedsnavn',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Mulighed',
  'LBL_LIST_ACCOUNT_NAME' => 'Kontonavn',
  'LBL_LIST_AMOUNT' => 'M&aelig;ngde',
  'LBL_LIST_DATE_CLOSED' => 'Luk',
  'LBL_LIST_SALES_STAGE' => 'Salgsstadie',
  'LBL_ACCOUNT_ID'=>'Konto ID',
  'LBL_CURRENCY_ID'=>'Valuta ID',
  'LBL_TEAM_ID' =>'Hold ID',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Mulighed - Valuta opdatering',
  'UPDATE_DOLLARAMOUNTS' => 'Opdater U.S. Dollar m&aelig;ngder',
  'UPDATE_VERIFY' => 'Verificer m&aelig;ngder',
  'UPDATE_VERIFY_TXT' => 'Verificerer at m&aelig;ngdev&aelig;rdierne i mulighederne er gyldige decimaltal kun med nummeriske karakterer(0-9) og decimaler(.)V',
  'UPDATE_FIX' => 'Ret m&aelig;ngder',
  'UPDATE_FIX_TXT' => 'Fors&oslash;ger at rette alle ugyldige m&aelig;ngder ved at oprette et gyldigt decimal fra den nuv&aelig;rende m&aelig;ngde. Dette vil foretage en backup af alle m&aelig;ngder som bliver &aelig;ndret til databasefelter amount_backup. Hvis du k&oslash;rer dette og bem&aelig;rker fejl, m&aring; du ikke k&oslash;re dette igen f&oslash;r end du har repareret de gamle data, da de ellers raske data i backuppen kan risikere at blive overskrevet med skadet data.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Opdater U.S. Dollar m&aelig;ngderne for muligheder baseret p&aring; de nuv&aelig;rende vekselkurser. Denne v&aelig;rdi vil blive brugt til at kalkulere grafer og listevisninger af valutam&aelig;ngder.',
  'UPDATE_CREATE_CURRENCY' => 'Opretter ny valuta:',
  'UPDATE_VERIFY_FAIL' => 'Kunne ikke verificeres:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Nuv&aelig;rende m&aelig;ngde:',
  'UPDATE_VERIFY_FIX' => 'En k&oslash;rt rettelse ville give',
  'UPDATE_INCLUDE_CLOSE' => 'Inkluder afsluttede elementer',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Ny m&aelig;ngde:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Ny valuta:',
  'UPDATE_DONE' => 'F&aelig;rdig',
  'UPDATE_BUG_COUNT' => 'Fejl blev fundet og fors&oslash;gt rettet:',
  'UPDATE_BUGFOUND_COUNT' => 'Fejl blev fundet:',
  'UPDATE_COUNT' => 'Elementer opdateret:',
  'UPDATE_RESTORE_COUNT' => 'Elementv&aelig;rdi genskabt:',
  'UPDATE_RESTORE' => 'Genskab m&aelig;ngder',
  'UPDATE_RESTORE_TXT' => 'Genskaber m&aelig;ngder fra de backups der blev foretaget under rettelsen.',
  'UPDATE_FAIL' => 'Kunne ikke opdatere - ',
  'UPDATE_NULL_VALUE' => 'M&aelig;ngde er NULL s&aelig;tter den til 0 -',
  'UPDATE_MERGE' => 'Sammensmelt valutaer',
  'UPDATE_MERGE_TXT' => 'Sammensmelt flere valutaer til en enkelt valuta. Hvis du ligger m&aelig;rke til at der er flere valuta elementer der tilh&oslash;rer den samme valuta, kan du v&aelig;lge at smelte dem sammen. Dette vil ogs&aring; smelte dem sammen i alle andre moduler.',
  'LBL_ACCOUNT_NAME' => 'Kontonavn:',
  'LBL_AMOUNT' => 'M&aelig;ngde:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_DATE_CLOSED' => 'Forventet afslutningsdato:',
  'LBL_TYPE' => 'Type:',
  'LBL_NEXT_STEP' => 'N&aelig;ste skridt:',
  'LBL_LEAD_SOURCE' => 'Emnekilde:',
  'LBL_SALES_STAGE' => 'Salgsstadie:',
  'LBL_PROBABILITY' => 'Sandsynlighed (%):',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_DUPLICATE' => 'Possible Duplicate Opportunity',
  'MSG_DUPLICATE' => 'Ved at oprette denne mulighed risikerer du at oprette en duplikat. Du kan enten v&aelig;lge en mulighed fra listen nedenfor eller du kan v&aelig;lge at forts&aelig;tte som hidtil.',
  'LBL_NEW_FORM_TITLE' => 'Opret mulighed',
  'LNK_NEW_OPPORTUNITY' => 'Opret mulighed',



  'LNK_OPPORTUNITY_LIST' => 'Muligheder',
  'ERR_DELETE_RECORD' => 'Et datanummer skal angives for at slette muligheden.',
  'LBL_TOP_OPPORTUNITIES' => 'Mine vigtigste &aring;bne muligheder',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne denne kontakt fra muligheden?',
	'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Er du sikker p&aring; du vil fjerne denne mulighed fra projektet?',
	'LBL_AMOUNT_BACKUP'=>'M&aelig;ngde backup',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Muligheder',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
    'LBL_RAW_AMOUNT'=>'R&aring; m&aelig;ngde',
	
    'LBL_LEADS_SUBPANEL_TITLE' => 'Emner',
    'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',



    'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekter',
	    'LBL_ASSIGNED_TO_NAME' => 'Tildelt brugernavn:',
	    





);

?>
