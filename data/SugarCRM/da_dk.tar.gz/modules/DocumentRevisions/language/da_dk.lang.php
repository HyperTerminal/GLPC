<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.2 2006/02/28 01:01:22 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumentrevision',
	
	'LNK_NEW_DOCUMENT' => 'Opret dokument',
	'LNK_DOCUMENT_LIST'=> 'Dokumentliste',

	//vardef labels
	'LBL_REVISION_NAME' => 'Revisionsnummer',
	'LBL_FILENAME' => 'Filnavn',
	'LBL_MIME' => 'Filtype',
	'LBL_REVISION' => 'Revision',
	'LBL_DOCUMENT' => 'Relateret dokument',
	'LBL_LATEST_REVISION' => 'Seneste revision',
	'LBL_CHANGE_LOG'=> '&Aelig;ndringslogbog',
	'LBL_ACTIVE_DATE'=> 'Dato for publivering',
	'LBL_EXPIRATION_DATE' => 'Udl&oslash;bsdato',
	'LBL_FILE_EXTENSION'  => 'Filendelse',
	'LBL_DET_CREATED_BY' => 'Oprettet af:',
	'LBL_DET_DATE_CREATED' => 'Oprettet d.:',
	
	'LBL_DOC_NAME' => 'Dokumentnavn:',
	'LBL_DOC_VERSION' => 'Revision:',
	
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Revision',
	'LBL_REV_LIST_ENTERED' => 'Oprettet d.',
	'LBL_REV_LIST_CREATED' => 'Oprettet af',
	'LBL_REV_LIST_LOG'=> '&Aelig;ndringslogbog',
	'LBL_REV_LIST_FILENAME' => 'Filnavn',
	
	'LBL_CURRENT_DOC_VERSION'=> 'Seneste revision:',
	'LBL_CHANGE_LOG'=> '&Aelig;ndringslogbog:',
	'LBL_SEARCH_FORM_TITLE'=> 'S&oslash;g i dokumenter',
	
	//error messages
	'ERR_FILENAME'=> 'Filnavn',
	'ERR_DOC_VERSION'=> 'Dokument udgave',
	'ERR_DELETE_CONFIRM'=> '&Oslash;nsker du at slette denne revision af dokumentet?',
	'ERR_DELETE_LATEST_VERSION'=> 'Du har ikke tilladelser til at slette den seneste revision af et dokument.',
);


?>
