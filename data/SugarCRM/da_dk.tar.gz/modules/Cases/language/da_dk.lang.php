<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.37 2006/03/23 00:59:58 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD'					=> 'Et datanummer skal angive for at slette kontoen.',
	
	'LBL_ACCOUNT_ID'					=> 'Konto-id',
	'LBL_ACCOUNT_NAME'					=> 'Kontonavn:',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'		=> 'Aktiviteter',
	'LBL_BUGS_SUBPANEL_TITLE'			=> 'Fejlrapporteringer',
	'LBL_CASE_NUMBER'					=> 'Sagsnummer:',
	'LBL_CASE_SUBJECT'					=> 'Sag emne:',
	'LBL_CASE'							=> 'Sag:',
	'LBL_CONTACT_CASE_TITLE'			=> 'Kontakt-Sag:',
	'LBL_CONTACT_NAME'					=> 'Kontaktnavn:',
	'LBL_CONTACT_ROLE'					=> 'Rolle:',
	'LBL_CONTACTS_SUBPANEL_TITLE'		=> 'Kontakter',
	'LBL_DEFAULT_SUBPANEL_TITLE'		=> 'Sager',
	'LBL_DESCRIPTION'					=> 'Beskrivelse:',
	'LBL_HISTORY_SUBPANEL_TITLE'		=> 'Historie',
	'LBL_INVITEE'						=> 'Kontakter',
	'LBL_MEMBER_OF'						=> 'Konto',
	'LBL_MODULE_NAME'					=> 'Sager',
	'LBL_MODULE_TITLE'					=> 'Sager: Hjem',
	'LBL_NEW_FORM_TITLE'				=> 'Ny sag',
	'LBL_NUMBER'						=> 'Nummer:',
	'LBL_PRIORITY'						=> 'Prioritet:',
	'LBL_RESOLUTION'					=> 'L&oslash;sning:',
	'LBL_SEARCH_FORM_TITLE'				=> 'S&oslash;g i sager',
	'LBL_STATUS'						=> 'Status:',
	'LBL_SUBJECT'						=> 'Emne:',
	'LBL_SYSTEM_ID'						=> 'System-ID',
	
	'LBL_LIST_ACCOUNT_NAME'				=> 'Kontonavn',
	'LBL_LIST_ASSIGNED'					=> 'Tildelt til',
	'LBL_LIST_CLOSE'					=> 'Luk',
	'LBL_LIST_FORM_TITLE'				=> 'Sagsliste',
	'LBL_LIST_LAST_MODIFIED'			=> 'Sidst &aelig;ndret',
	'LBL_LIST_MY_CASES'					=> 'Mine &aring;bne sager',
	'LBL_LIST_NUMBER'					=> 'Nr.',
	'LBL_LIST_PRIORITY'					=> 'Prioritet',
	'LBL_LIST_STATUS'					=> 'Status',
	'LBL_LIST_SUBJECT'					=> 'Emne',
	
	'LNK_CASE_LIST'						=> 'Sager',
	'LNK_NEW_CASE'						=> 'Opret sag',
	
	'NTC_REMOVE_FROM_BUG_CONFIRMATION'	=> 'Er du sikker p&aring; du &oslash;nsker at fjerne den sag fra fejlrapporten?',
	'NTC_REMOVE_INVITEE'				=> 'Er du sikker p&aring; du &oslash;nsker at fjerne denne kontakt fra sagen?',

);


?>
