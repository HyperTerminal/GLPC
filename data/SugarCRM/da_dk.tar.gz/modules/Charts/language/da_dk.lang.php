<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.2 2006/01/17 22:50:47 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
    'ERR_NO_OPPS' => 'Venligst opret nogle muligheder for at se grafen for muligheder.',
    'LBL_ALL_OPPORTUNITIES' => 'Den totale m&aelig;ngde muligheder er ',
    'LBL_CREATED_ON' => 'Sidst k&oslash;rt p&aring; ',
    'LBL_DATE_END' => 'Slutdato:',
    'LBL_DATE_RANGE_TO' => 'til',
    'LBL_DATE_RANGE' => 'Dato omr&aring;de er',
    'LBL_DATE_START' => 'Startdato:',
    'LBL_EDIT' => 'Rediger',
    'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Viser akkumuleret m&aelig;ngde muligheder fordelt pr. valgt emnekilde pr. udbytte for valgte brugere. Udbyttet er basseret p&aring; om det er afsluttet og vundet, afsluttet og tabt eller enhver anden v&aelig;rdi.',
    'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Alle muligheder pr. emnekilde pr. udbytte',
    'LBL_LEAD_SOURCE_FORM_DESC' => 'Viser akkumuleret m&aelig;ngde muligheder fordelt pr. valgt emnekilde for valgte brugere.',
    'LBL_LEAD_SOURCE_FORM_TITLE' => 'Alle muligheder pr. emnekilde',
    'LBL_LEAD_SOURCE_OTHER' => 'Andre',
    'LBL_LEAD_SOURCES' => 'Emnekilder:',
    'LBL_MODULE_NAME' => 'Dashboard',
    'LBL_MODULE_TITLE' => 'Dashboard: Hjem',
    'LBL_MONTH_BY_OUTCOME_DESC' => 'Viser akkumuleret m&aelig;ngde muligheder pr. m&aring;ned fordelt p&aring; udbytte ved valgte brugere hvor forventet afslutningsdato ligger indenfor det angivede dato omr&aring;de. Udbyttet er basseret p&aring; om det er afsluttet og vundet, afsluttet og tabt eller enhver anden v&aelig;rdi.',
    'LBL_OPP_SIZE' => 'Mulighedsst&oslash;rrelse i',
    'LBL_OPP_THOUSANDS'=> 'K',
    'LBL_OPPS_IN_LEAD_SOURCE' => 'muligheder hvor emnekilden er',
    'LBL_OPPS_IN_STAGE' => ' hvor salgsstadiet er',
    'LBL_OPPS_OUTCOME' => ' hvor udbyttet er',
    'LBL_OPPS_WORTH' => 'mulighedernes v&aelig;rdi',
    'LBL_PIPELINE_FORM_TITLE_DESC' => 'Viser akkumulerede v&aelig;rdier pr. valgt salgsstadie for dine muligheder hvor den forventede afslutningsdato ligger indenfor det angivede datoomr&aring;de.',
    'LBL_REFRESH' => 'Opdater',
    'LBL_ROLLOVER_DETAILS' => 'F&oslash;r musen over en bar for detaljer.',
    'LBL_ROLLOVER_WEDGE_DETAILS' => 'F&oslash;r musen over en kagestykket for detaljer.',
    'LBL_SALES_STAGE_FORM_DESC' => 'Viser akkumuleret m&aelig;ngde muligheder pr. valgt salgsstadie for valgte brugere hvor den forventede afslutningsdato ligger indenfor det angivede datoomr&aring;de.',
    'LBL_SALES_STAGE_FORM_TITLE' => 'Pipeline pr. salgsstadie',
    'LBL_SALES_STAGES' => 'Salgsstadier:',
    'LBL_TOTAL_PIPELINE' => 'Pipeline total er ',
    'LBL_USERS' => 'Users:',
    'LBL_YEAR_BY_OUTCOME' => 'Pipeline pr. m&aring;ned pr. udbytte',
    'LBL_YEAR' => '&Aring;rstal:',
    'LNK_NEW_ACCOUNT' => 'Opret konto',
    'LNK_NEW_CALL' => 'Skemal&aelig;g opkald',
    'LNK_NEW_CASE' => 'Opret sag',
    'LNK_NEW_CONTACT' => 'Opret kontakt',
    'LNK_NEW_ISSUE' => 'Rapporter fejl',
    'LNK_NEW_LEAD' => 'Opret emne',
    'LNK_NEW_MEETING' => 'Skemal&aelig;g m&oslash;de',
    'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
    'LNK_NEW_OPPORTUNITY' => 'Opret mulighed',
    'LNK_NEW_QUOTE' => 'Opret tilbud',
    'LNK_NEW_TASK' => 'Opret opgave',
    'NTC_NO_LEGENDS' => 'Ingen',
);


?>
