<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * English language file for History
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
 
// $Id: en_us.lang.php,v 1.3 2006/01/17 22:50:55 majed Exp $

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Historie',
  'LBL_MODULE_TITLE' => 'Historie: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i historie',
  'LBL_LIST_FORM_TITLE' => 'Historie',
  'LBL_LIST_SUBJECT' => 'Emne',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Relateret til',
  'LBL_LIST_DATE' => 'Dato',
  'LBL_LIST_TIME' => 'Starttidspunkt',
  'LBL_LIST_CLOSE' => 'Luk',
  'LBL_SUBJECT' => 'Emne:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Placering:',
  'LBL_DATE_TIME' => 'Startdato og tidspunkt:',
  'LBL_DATE' => 'Startdato:',
  'LBL_TIME' => 'Starttidspunkt:',
  'LBL_DURATION' => 'Varrighed:',
  'LBL_HOURS_MINS' => '(timer/minutter)',
  'LBL_CONTACT_NAME' => 'Kontaktnavn: ',
  'LBL_MEETING' => 'M&oslash;de:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelsesinformation',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planlagt',
  'LNK_NEW_CALL' => 'Skemal&aelig;g opkald',
  'LNK_NEW_MEETING' => 'Skemal&aelig;g m&oslash;de',
  'LNK_NEW_TASK' => 'Opret opgave',
  'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
  'LNK_NEW_EMAIL' => 'Arkiver e-mail',
  'LNK_CALL_LIST' => 'Opkald',
  'LNK_MEETING_LIST' => 'M&oslash;der',
  'LNK_TASK_LIST' => 'Opgaver',
  'LNK_NOTE_LIST' => 'Noter',
  'LNK_EMAIL_LIST' => 'E-mails',
  'ERR_DELETE_RECORD' => 'Et datanummer skal angives for at slette denne konto.',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p&aring; du vil fjerne denne inviterede fra m&oslash;det?',
  'LBL_INVITEE' => 'Inviterede',
  'LBL_LIST_DIRECTION' => 'Retning',
  'LBL_DIRECTION' => 'Retning',
  'LNK_NEW_APPOINTMENT' => 'Ny aftale',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_OPEN_ACTIVITIES' => '&Aring;bne aktiviteter',
  'LBL_HISTORY' => 'Historie',
  'LBL_UPCOMING' => 'Mine opkomne aftaler',
  'LBL_TODAY' => 'gennem ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Opret opgave [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Opret opgave',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Skemal&aelig;g m&oslash;de [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Skemal&aelig;g m&oslash;de',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Skemal&aelig;g opkald [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Skemal&aelig;g opkald',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Opret note eller vedh&aelig;ftning [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Opret note eller vedh&aelig;ftning',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arkiver e-mail [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arkiver e-mail',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DUE_DATE' => 'Forfaldsdato',
  'LBL_LIST_LAST_MODIFIED' => 'Sidst &aelig;ndret',
  'NTC_NONE_SCHEDULED' => 'Ingen skemalagte.',
  'appointment_filter_dom' => array(
  	 'today' => 'i dag'
  	,'tomorrow' => 'imorgen'
  	,'this Saturday' => 'denne uge'
  	,'next Saturday' => 'n&aelig;ste uge'
  	,'last this_month' => 'denne m&aring;ned'
  	,'last next_month' => 'n&aelig;ste m&aring;ned'
  ),
  'LNK_IMPORT_NOTES'=>'Importer noter',
  'NTC_NONE'=>'Ingen',
	'LBL_ACCEPT_THIS'=>'Accepter?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Historie',
);

?>
