<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Default English language strings
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */

// $Id: en_us.lang.php,v 1.28 2006/01/17 22:54:37 majed Exp $

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projekt',
	'LBL_MODULE_TITLE' => 'Projekter: Hjem',
	'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i projekter',
    'LBL_LIST_FORM_TITLE' => 'Projektliste',
    'LBL_HISTORY_TITLE' => 'Historie',

	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Dato oprettet:',
	'LBL_DATE_MODIFIED' => 'Dato &aelig;ndret:',
	'LBL_ASSIGNED_USER_ID' => 'Tildelt til:',
	'LBL_MODIFIED_USER_ID' => '&AElig;ndret bruger Id:',
	'LBL_CREATED_BY' => 'Oprettet af:',
	'LBL_TEAM_ID' => 'Hold:',
	'LBL_NAME' => 'Navn:',
	'LBL_DESCRIPTION' => 'Beskrivelse:',
	'LBL_DELETED' => 'Slettet:',

	'LBL_TOTAL_ESTIMATED_EFFORT' => 'Total estimeret indsats (timer):',
	'LBL_TOTAL_ACTUAL_EFFORT' => 'Total reel indsats (timer):',

	'LBL_LIST_NAME' => 'Navn',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Tildelt til',
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Total estimeret indsats (timer)',
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Total reel indsats (timer)',

	'LBL_PROJECT_SUBPANEL_TITLE' => 'Projekter',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Projekt opgave',
	'LBL_CONTACT_SUBPANEL_TITLE' => 'Kontakter',
	'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Konti',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Muligheder',
	'LBL_QUOTE_SUBPANEL_TITLE' => 'Tilbud',

	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Er du sikker p&aring; du &oslash;nsker at fjerne denne kontakt fra projektet?',
	
	'LNK_NEW_PROJECT'	=> 'Opret projekt',
	'LNK_PROJECT_LIST'	=> 'Projektliste',
	'LNK_NEW_PROJECT_TASK'	=> 'Opret projekt opgave',
	'LNK_PROJECT_TASK_LIST'	=> 'Projekt opgaver',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projekter',
	'LBL_ACTIVITIES_TITLE'=>'Aktiviteter',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
	'LBL_QUICK_NEW_PROJECT'	=> 'Nyt projekt',
	
	'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Projejt opgaver',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Konti',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Muligheder',



);
?>
