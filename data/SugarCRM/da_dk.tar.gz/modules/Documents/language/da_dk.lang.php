<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.19 2006/03/28 05:26:47 andy Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumenter',
	'LBL_MODULE_TITLE' => 'Dokumenter: Hjem',
	'LNK_NEW_DOCUMENT' => 'Opret dokument',
	'LNK_DOCUMENT_LIST'=> 'Dokumentliste',
	'LBL_DOC_REV_HEADER' => 'Dokumentrevisioner',
	'LBL_SEARCH_FORM_TITLE'=> 'S&oslash;g i dokumenter',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'Dokument Id',	
	'LBL_NAME' => 'Dokumentnavn',
	'LBL_DESCRIPTION' => 'Beskrivelse',
	'LBL_CATEGORY' => 'Kategori',
	'LBL_SUBCATEGORY' => 'Underkategori',
	'LBL_STATUS' => 'Status', 
	'LBL_CREATED_BY'=> 'Oprettet af',
	'LBL_DATE_ENTERED'=> 'Oprettet d.',
	'LBL_DATE_MODIFIED'=> '&Aelig;ndret d.',
	'LBL_DELETED' => 'Slettet',
	'LBL_MODIFIED'=> '&Aelig;ndret af',
	'LBL_CREATED'=> 'Oprettet af',
	'LBL_RELATED_DOCUMENT_ID'=>'Relateret Dokument Id',
	'LBL_RELATED_DOCUMENT_REVISION_ID'=>'Relateret Dokumentrevision Id',
	'LBL_IS_TEMPLATE'=>'Er en skabelon',
	'LBL_TEMPLATE_TYPE'=>'Dokumenttype',
	
	'LBL_REVISION_NAME' => 'Revisionsnummer',
	'LBL_FILENAME' => 'Filnavn',
	'LBL_MIME' => 'Filtype',
	'LBL_REVISION' => 'Revision',
	'LBL_DOCUMENT' => 'Relateret dokument',
	'LBL_LATEST_REVISION' => 'Seneste revision',
	'LBL_CHANGE_LOG'=> '&Aelig;ndringslogbog',
	'LBL_ACTIVE_DATE'=> 'Dato for publicering',
	'LBL_EXPIRATION_DATE' => 'Udl&oslash;bsdato',
	'LBL_FILE_EXTENSION'  => 'Filendelse',
	
	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Uspecificeret',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Dokumentnavn:',
	'LBL_FILENAME' => 'Filnavn:',
	'LBL_DOC_VERSION' => 'Revision:',
	'LBL_CATEGORY_VALUE' => 'Kategori:',
	'LBL_SUBCATEGORY_VALUE'=> 'Underkategori:',
	'LBL_DOC_STATUS'=> 'Status:',
	'LBL_LAST_REV_CREATOR' => 'Revision oprettet af:',
	'LBL_LAST_REV_DATE' => 'Revisionsdato:',
	'LBL_DOWNNLOAD_FILE'=> 'Download fil:',
	'LBL_DET_RELATED_DOCUMENT'=>'Relateret dokument:',
	'LBL_DET_RELATED_DOCUMENT_VERSION'=>"Relateret dokuments revision:",
	'LBL_DET_IS_TEMPLATE'=>'Skabelon? :',
	'LBL_DET_TEMPLATE_TYPE'=>'Dokumenttype:',



	'LBL_DOC_DESCRIPTION'=>'Beskrivelse:',
	'LBL_DOC_ACTIVE_DATE'=> 'Dato for publicering:',
	'LBL_DOC_EXP_DATE'=> 'Udl&oslash;bsdato:',
	
	//document list view.	
	'LBL_LIST_FORM_TITLE' => 'Dokumentliste',	
	'LBL_LIST_DOCUMENT' => 'Dokument',
	'LBL_LIST_CATEGORY' => 'Kategori',
	'LBL_LIST_SUBCATEGORY' => 'Underkategori',
	'LBL_LIST_REVISION' => 'Revision',
	'LBL_LIST_LAST_REV_CREATOR' => 'Publiceret af',
	'LBL_LIST_LAST_REV_DATE' => 'Revisionsdato',
	'LBL_LIST_VIEW_DOCUMENT'=>'Vis',
	'LBL_LIST_ACTIVE_DATE' => 'Dato for publicering',
	'LBL_LIST_EXP_DATE' => 'Udl&oslash;bsdato',
	'LBL_LIST_STATUS'=>'Status',
	
	//document search form.
	'LBL_SF_DOCUMENT' => 'Dokumentnavn:',
	'LBL_SF_CATEGORY' => 'Kategori:',
	'LBL_SF_SUBCATEGORY'=> 'Underkategori:',
	'LBL_SF_ACTIVE_DATE' => 'Dato for publicering:',
	'LBL_SF_EXP_DATE'=> 'Udl&oslash;bsdato:',
	
	'DEF_CREATE_LOG' => 'Dokument oprettet d.',
	
	//error messages
	'ERR_DOC_NAME'=>'Dokumentnavn',
	'ERR_DOC_ACTIVE_DATE'=>'Dato for publicering',
	'ERR_DOC_EXP_DATE'=> 'Udl&oslash;bsdato',
	'ERR_FILENAME'=> 'Filnavn',
	'ERR_DOC_VERSION'=> 'Dokumentudgave',
	'ERR_DELETE_CONFIRM'=> '&Oslash;nsker du at slette denne revision af dokumentet?',
	'ERR_DELETE_LATEST_VERSION'=> 'Du har ikke tilladelser til at slette den seneste revision af et dokument.',
	'LNK_NEW_MAIL_MERGE' => 'Mail sammensmeltning',
	'LBL_MAIL_MERGE_DOCUMENT' => 'Mail sammensmeltnings skabelon:',
	
	'LBL_TREE_TITLE' => 'Dokumenter',
	//sub-panel vardefs.
	'LBL_LIST_DOCUMENT_NAME'=>'Dokumentnavn',
	'LBL_CONTRACT_NAME'=>'Kontraktnavn:',
	'LBL_LIST_IS_TEMPLATE'=>'Skabelon?',
	'LBL_LIST_TEMPLATE_TYPE'=>'Dokumenttype',
	'LBL_LIST_SELECTED_REVISION'=>'Valgt revision',
	'LBL_LIST_LATEST_REVISION'=>'Seneste revision',
);


?>
