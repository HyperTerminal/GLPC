<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.50 2006/01/17 22:54:33 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'M&oslash;der',
  'LBL_MODULE_TITLE' => 'M&oslash;der: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i m&oslash;der',
  'LBL_LIST_FORM_TITLE' => 'M&oslash;deliste',
  'LBL_NEW_FORM_TITLE' => 'Skemal&aelig;g m&oslash;de',
  'LBL_SCHEDULING_FORM_TITLE' => 'Skemal&aelig;gning',
  'LBL_LIST_SUBJECT' => 'Emne',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Relateret til',
  'LBL_LIST_DATE' => 'Startdato',
  'LBL_LIST_TIME' => 'Starttidspunkt',
  'LBL_LIST_CLOSE' => 'Luk',
  'LBL_SUBJECT' => 'Emne:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Lokation:',
  'LBL_DATE_TIME' => 'Startdato og tidspunkt:',
  'LBL_DATE' => 'Startdato:',
  'LBL_TIME' => 'Starttidspunkt:',
   'LBL_HOURS_ABBREV' => 't',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_DURATION' => 'Varrighed:',
  'LBL_DURATION_HOURS' => 'Varrighed timer:',
  'LBL_DURATION_MINUTES' => 'Varrighed minutter:',
  'LBL_HOURS_MINS' => '(timer/minutter)',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_MEETING' => 'M&oslash;de:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelsesinformation',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planlagt',
'LNK_NEW_CALL'=>'Skemal&aelig;g opkald',
'LNK_NEW_MEETING'=>'Skemal&aelig;g m&oslash;de',
'LNK_NEW_TASK'=>'Opret opgave',
'LNK_NEW_NOTE'=>'Opret note eller vedh&aelig;ftning',
'LNK_NEW_EMAIL'=>'Arkiver e-mail',
'LNK_CALL_LIST'=>'Opkald',
'LNK_MEETING_LIST'=>'M&oslash;der',
'LNK_TASK_LIST'=>'Opgaver',
'LNK_NOTE_LIST'=>'Noter',
'LNK_EMAIL_LIST'=>'E-mails',

  'LNK_VIEW_CALENDAR' => 'I dag',
  'ERR_DELETE_RECORD' => 'Et datanummer skal angives for at slette dette m&oslash;de.',
  'NTC_REMOVE_INVITEE' => 'Er du sikker p&aring; du &oslash;nsker at fjern denne inviterede fra m&oslash;det?',
  'LBL_INVITEE' => 'Inviterede',
  'LNK_NEW_APPOINTMENT' => 'Opret aftale',

  'LBL_ADD_INVITEE' => 'Tilf&oslash;j inviterede',
  'LBL_NAME' => 'Navn',
  'LBL_FIRST_NAME' => 'Fornavn',
  'LBL_LAST_NAME' => 'Efternavn',
  'LBL_EMAIL' => 'E-mail',
  'LBL_PHONE' => 'Telefon kontor:',
  'LBL_REMINDER' => 'P&aring;mindelse:',
  'LBL_SEND_BUTTON_TITLE'=>'Send invitationer [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'Send invitationer',
  'LBL_REMINDER_TIME'=>'P&aring;mindelsestid',
  'LBL_MODIFIED_BY'=>'&Aring;ndret af',
  'LBL_CREATED_BY'=>'Oprettet af',
  'LBL_DATE_END'=>'Slutdato',
	
  'LBL_SEARCH_BUTTON'=> 'S&oslash;g',
  'LBL_ADD_BUTTON'=> 'Tilf&oslash;j',
  'LBL_DEL'=> 'Slet',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'M&oslash;der',
  'LBL_LIST_STATUS'=>'Status',
  'LBL_LIST_DUE_DATE'=>'Forfaldsdato',
  'LBL_LIST_DATE_MODIFIED'=>'&AElig;ndret den',
  
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_USERS_SUBPANEL_TITLE' => 'Brugere',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Noter',
	'LBL_OUTLOOK_ID' => 'Outlook ID',
);


?>
