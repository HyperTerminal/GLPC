<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.6 2006/01/17 22:54:33 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_STEP_1' => 'Skridt 1: V&aelig;lg modul og skabelon',
  'LBL_MAILMERGE_MODULE' => 'V&aelig;lg modul: ',
  'LBL_MAILMERGE_SELECTED_MODULE' => 'Valgt modul: ',
  'LBL_MAILMERGE_TEMPLATES' => 'V&aelig;lg skabelon: ',
  'LBL_STEP_2' => 'Skridt 2: V&aelig;lg objekter til sammensmeltning',
  'LBL_MAILMERGE_OBJECTS' => 'Valgte objekter: ',
  'LBL_STEP_3' => 'S&aelig;t kontaktassociation',
  'LBL_STEP_4' => 'Gennemse og f&aelig;rdigg&oslash;r',
  'LBL_SELECTED_MODULE' => 'Valgt modul: ',
  'LBL_SELECTED_TEMPLATE' => 'Valgt skabelon: ',
  'LBL_SELECTED_ITEMS' => 'Valgte elementer: ',
  'LBL_STEP_5' => 'Mailsammensmeltning f&aelig;rdig',
  'LBL_MERGED_FILE' => 'Sammensmeltning fil: ',
  'LNK_NEW_MAILMERGE' => 'Begynd mail sammensmeltning',
  'LNK_UPLOAD_TEMPLATE' => 'Upload skabelon',
  'LBL_DOC_NAME' => 'Dokumentnavn:',
  'LBL_FILENAME' => 'Filnavn:',
  'LBL_DOC_VERSION' => 'Revision:',
  'LBL_DOC_DESCRIPTION'=>'Beskrivelse:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_RELATIONSHIP' => 'S&aelig;t kontaktforhold',
  'LBL_FINISH' => 'Start sammensmeltning',
  'LBL_NEXT' => 'N&aelig;ste >',
  'LBL_BACK' => '< Tilbage',
  'LBL_START' => 'Start igen',
  'LBL_TEMPLATE_NOTICE' => 'Skabeloner er Microsoft Word Dokumenter som indeholder sammensmeltningsfelter der er blevet uploaded og gemt i dokumentmodulet.',
  'LBL_CONTAINS_CONTACT_INFO' => 'Valgte skabelon indeholder kontaktinformationer.',
  'LBL_ADDIN_NOTICE' => 'Dette kr&aelig;ver installation af Sugar Mail Meger add-in til Microsoft Word.',
  'LBL_BROWSER_NOTICE' => 'Du skal IE 6.0 eller h&oslash;jere for at foretage sammensmeltningen.',
);


?>
