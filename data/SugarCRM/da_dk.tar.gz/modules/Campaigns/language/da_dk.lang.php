<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.33 2006/03/24 23:01:56 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kampagner',
  'LBL_MODULE_TITLE' => 'Kampagner: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i kampagner',
  'LBL_LIST_FORM_TITLE' => 'Kampagneliste',
  'LBL_CAMPAIGN_NAME' => 'Navn:',
  'LBL_CAMPAIGN' => 'Kampagne:',
  'LBL_NAME' => 'Navn: ',
  'LBL_INVITEE' => 'Kontakter',
  'LBL_LIST_CAMPAIGN_NAME' => 'Kampagne',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_TYPE' => 'Type',
  'LBL_LIST_END_DATE' => 'Slut dato',
  'LBL_DATE_ENTERED' => 'Indtastet d.',
  'LBL_DATE_MODIFIED' => '&Aelig;ndret d.',
  'LBL_MODIFIED' => '&Aelig;ndret af: ',
  'LBL_CREATED' => 'Oprettet af: ',
  'LBL_TEAM' => 'Hold: ',
  'LBL_ASSIGNED_TO' => 'Tildelt til: ',
  'LBL_CAMPAIGN_START_DATE' => 'Startdato: ',
  'LBL_CAMPAIGN_END_DATE' => 'Slutdato: ',
  'LBL_CAMPAIGN_STATUS' => 'Status: ',
  'LBL_CAMPAIGN_BUDGET' => 'Budget: ',
  'LBL_CAMPAIGN_EXPECTED_COST' => 'Forventet omkostning: ',
  'LBL_CAMPAIGN_ACTUAL_COST' => 'Reel omkostning: ',
  'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Forventet overskud: ',
  'LBL_CAMPAIGN_TYPE' => 'Type: ',
  'LBL_CAMPAIGN_OBJECTIVE' => 'M&aring;l: ',
  'LBL_CAMPAIGN_CONTENT' => 'Beskrivelse: ',
  'LNK_NEW_CAMPAIGN' => 'Opret kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagner',
  'LNK_NEW_PROSPECT' => 'Opret udsigt',
  'LNK_PROSPECT_LIST' => 'Udsigter',
  'LNK_NEW_PROSPECT_LIST' => 'Opret udsigtsliste',
  'LNK_PROSPECT_LIST_LIST' => 'Udsigtsliste',
  'LBL_MODIFIED_BY' => '&Aelig;ndret af: ',
  'LBL_CREATED_BY' => 'Oprettet af: ',
  'LBL_DATE_CREATED' => 'Oprettet d.: ',
  'LBL_DATE_LAST_MODIFIED' => '&Aelig;ndret d.: ',
  'LBL_TRACKER_KEY' => 'Sporhund: ',
  'LBL_TRACKER_URL' => 'Sporhund URL: ',
  'LBL_TRACKER_TEXT' => 'Sporhund link tekst: ',
  'LBL_TRACKER_COUNT' => 'Sporhund antal: ',
  'LBL_REFER_URL' => 'Sporhund redelegerings-URL: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kampagner',
  'LBL_EMAIL_CAMPAIGNS_TITLE' =>'E-mail kampagner',
  'LBL_NEW_FORM_TITLE' => 'Ny kampagne',
  'LBL_TRACKED_URLS'=>'Sporhund URL\'er',
  'LBL_TRACKED_URLS_SUBPANEL_TITLE'=>'Sporhund URL\'er',

  'LBL_PROSPECT_LIST_SUBPANEL_TITLE' => 'Udsigtsliste',
  'LBL_EMAIL_MARKETING_SUBPANEL_TITLE' => 'E-mail markedsf&oslash;ring',
  'LNK_NEW_EMAIL_TEMPLATE' => 'Opret e-mail skabelon',
  'LNK_EMAIL_TEMPLATE_LIST' => 'E-mail skabeloner',
  'LBL_TRACK_BUTTON_TITLE' =>'Vis status',
  'LBL_TRACK_BUTTON_KEY' =>'T',
  'LBL_TRACK_BUTTON_LABEL' =>'Vis status',
  'LBL_QUEUE_BUTTON_TITLE'=>'Send e-mails',
  'LBL_QUEUE_BUTTON_KEY'=>'u',
  'LBL_QUEUE_BUTTON_LABEL'=>'Send e-mails',
  'LBL_TEST_BUTTON_TITLE'=>'Send test',
  'LBL_TEST_BUTTON_KEY'=>'e',
  'LBL_TEST_BUTTON_LABEL'=>'Send test',

  'LBL_TODETAIL_BUTTON_TITLE'=>'Vis detaljer',
  'LBL_TODETAIL_BUTTON_KEY'=>'T',
  'LBL_TODETAIL_BUTTON_LABEL'=>'Vis detaljer',
  
  'LBL_DEFAULT'=>'Alle m&aring;llister',
  'LBL_MESSAGE_QUEUE_TITLE'=>'Meddelelsesk&oslash;',
  'LBL_LOG_ENTRIES_TITLE'=>'Reaktioner',
  
  'LBL_LOG_ENTRIES_TARGETED_TITLE'=>'Meddelelse afsendt/Fors&oslash;gt',
  'LBL_LOG_ENTRIES_SEND_ERROR_TITLE'=>'Meddelelse kunne ikke sendes,Andre',  
  'LBL_LOG_ENTRIES_INVALID_EMAIL_TITLE'=>'Meddelelse kunne ikke sendes,Ugyldig e-mail adresse',
  'LBL_LOG_ENTRIES_LINK_TITLE'=>'Klik-igennem link',  
  'LBL_LOG_ENTRIES_VIEWED_TITLE'=>'Vist meddelelse',
  'LBL_LOG_ENTRIES_REMOVED_TITLE'=>'Fravalgt',
  'LBL_LOG_ENTRIES_LEAD_TITLE'=>'Emner oprettet',
  'LBL_LOG_ENTRIES_CONTACT_TITLE'=>'Kontakter oprettet',
  
  'LBL_BACK_TO_CAMPAIGNS'=>'Tilbage til kampagner',
  //error messages.
  'ERR_NO_EMAIL_MARKETING'=>'Der skal v&aelig;re mindst en aktiv e-mail markedsf&oslash;ringsmeddelelses associeret med kampagnen.',
  'ERR_NO_TARGET_LISTS'=>'Der skal v&aelig;re mindst en aktiv udsigtsliste associeret med kampagnen.',
  'ERR_NO_TEST_TARGET_LISTS'=>'Der skal v&aelig;re mindst en udsigtsliste af typen Test associeret med kampagnen.',  
  'ERR_SENDING_NOW'=>'Meddelelser er ved at blive leveret, venligst fors&oslash;g dette senere.',
  'ERR_MESS_NOT_FOUND_FOR_LIST'=>'Ingen e-mail makedsf&oslash;ringsmeddelelses fundet for denne udsigtsliste',
  'ERR_MESS_DUPLICATE_FOR_LIST'=>'Flere e-mail makedsf&oslash;ringsmeddelelser er defineret for denne udsigtsliste',
  'ERR_FIX_MESSAGES'=>'Venligst ret f&oslash;lgende fejl f&oslash;r end du forts&aelig;tter',
  
  'LBL_TRACK_DELETE_BUTTON_KEY'=>'D',
  'LBL_TRACK_DELETE_BUTTON_TITLE'=>'Slet test elementer',
  'LBL_TRACK_DELETE_BUTTON_LABEL'=>'Slet test elementer',
  'LBL_TRACK_DELETE_CONFIRM'=>'Denne option vil slette logbogsindl&aelig;g oprettet af testk&oslash;rslen. &Oslash;nsker du at forts&aelig;tte?',
  'ERR_NO_MAILBOX'=>"F&oslash;lgende markedsf&oslash;ringsmeddelelse har ikke en associeret mailboks.<BR>Venligst ret dette f&oslash;r end du forts&aelig;tter.",
  'LBL_LIST_TO_ACTIVITY'=>'Vis status',
  'LBL_CURRENCY_ID'=>'Valuta ID',
  'LBL_CURRENCY'=>'Valuta',
);


?>
