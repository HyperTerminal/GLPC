<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.14 2006/01/17 22:54:37 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Udsigter',
  'LBL_INVITEE' => 'Direkte rapporter',
  'LBL_MODULE_TITLE' => 'Udsigter: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i udsigter',
  'LBL_LIST_FORM_TITLE' => 'Udsigtsliste',
  'LBL_NEW_FORM_TITLE' => 'Ny udsigt',
  'LBL_PROSPECT' => 'Udsigt:',
  'LBL_BUSINESSCARD' => 'Visitkort',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_LIST_PROSPECT_NAME' => 'Udsigtsnavn',
  'LBL_LIST_TITLE' => 'Titel',
  'LBL_LIST_EMAIL_ADDRESS' => 'E-mail',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Anden e-mail',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_PROSPECT_ROLE' => 'Rolle',
  'LBL_LIST_FIRST_NAME' => 'Fornavn',
  'LBL_ASSIGNED_TO_NAME'=>'Tildelt til navn',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_PROSPECT' => 'Benyttede en eksisterende kontakt',
  'LBL_CREATED_PROSPECT' => 'Opret en ny kontakt',
  'LBL_EXISTING_ACCOUNT' => 'Benyttede en eksisterende konto',
  'LBL_CREATED_ACCOUNT' => 'Oprettede en ny konto',
  'LBL_CREATED_CALL' => 'Oprettede et nyt opkald',
  'LBL_CREATED_MEETING' => 'Oprettede et nyt m&oslash;de',
  'LBL_ADDMORE_BUSINESSCARD' => 'Tilf&oslash;j et visitkort til',
  'LBL_ADD_BUSINESSCARD' => 'Indtast visitkort',
  'LBL_NAME' => 'Navn:',
  'LBL_PROSPECT_NAME' => 'Udsigtsnavn:',
  'LBL_PROSPECT_INFORMATION' => 'Udsigtsinformation',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_OFFICE_PHONE' => 'Telefon kontor:',
  'LBL_ACCOUNT_NAME' => 'Kontonavm:',
  'LBL_ANY_PHONE' => 'Alle telefonnumre:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_HOME_PHONE' => 'Hjem:',
  'LBL_OTHER_PHONE' => 'Anden telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Prim&aelig;r adresse gade:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Prim&aelig;r adresse by:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Prim&aelig;r adresse land:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Prim&aelig;r adresse stat:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Prim&aelig;r adresse postnummer:',
  'LBL_ALT_ADDRESS_STREET' => 'Alternativ adresse gade:',
  'LBL_ALT_ADDRESS_CITY' => 'Alternativ adresse by:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Alternativ adresse land:',
  'LBL_ALT_ADDRESS_STATE' => 'Alternativ adresse stat:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Alternativ adresse postnummer:',
  'LBL_TITLE' => 'Titel:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_BIRTHDATE' => 'F&oslash;dselsdag:',
  'LBL_EMAIL_ADDRESS' => 'E-mail:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Anden e-mail:',
  'LBL_ANY_EMAIL' => 'Alle e-mail adresser:',
  'LBL_ASSISTANT' => 'Assistent:',
  'LBL_ASSISTANT_PHONE' => 'Assistent telefon:',
  'LBL_DO_NOT_CALL' => 'Undlad opkald:',
  'LBL_EMAIL_OPT_OUT' => 'E-mail fravalgt:',
  'LBL_PRIMARY_ADDRESS' => 'Prim&aelig;r adresse:',
  'LBL_ALTERNATE_ADDRESS' => 'Anden adresse:',
  'LBL_ANY_ADDRESS' => 'Alle adresser:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelsesinformation',
  'LBL_ADDRESS_INFORMATION' => 'Adresse information',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_PROSPECT_ROLE' => 'Rolle:',
  'LBL_OPP_NAME' => 'Mulighedsnavn:',
  'LBL_IMPORT_VCARD' => 'Importer vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatisk opret en ny kontakt ved at et vCard fra dit filsystem.',
  'LBL_DUPLICATE' => 'Mulige duplikerede udsigter',
  'MSG_SHOW_DUPLICATES' => 'Oprettelse af denne kontakt kan resultere i en duplikat. Du kan enten v&aelig;lge Opret udsigt for at forts&aelig;tte med at oprette denne kontakt eller du kan klikke p&aring; Annuller.',
  'MSG_DUPLICATE' => 'Oprettelse af denne kontakt kan resultere i en duplikat. Du kan enten v&aelig;lge en kontakt fra nedenst&aring;ende liste eller du kan klikke p&aring; Opret udsigt for at oprette den nye kontakt.',
  'LNK_PROSPECT_LIST' => 'Udsigter',
  'LNK_IMPORT_VCARD' => 'Opret fra vCard',
  'LNK_NEW_PROSPECT' => 'Opret udsigt',
  'LNK_NEW_ACCOUNT' => 'Opret konto',
  'LNK_NEW_OPPORTUNITY' => 'Opret mulighed',
  'LNK_NEW_CASE' => 'Opret sag',
  'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
  'LNK_NEW_CALL' => 'Skemal&aelig;g opkald',
  'LNK_NEW_EMAIL' => 'Arkiver e-mail',
  'LNK_NEW_MEETING' => 'Skemal&aelig;g m&oslash;de',
  'LNK_NEW_TASK' => 'Opret opgave',
  'LNK_NEW_APPOINTMENT' => 'Opret aftale',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at slette dette element?',
  'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne denne kontakt fra sagen?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne dette element som en direkte rapport?',
  'ERR_DELETE_RECORD' => 'Et datanummer skal angives for at slette denne kontakt.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopier prim&aelig;r adresse til alternativ adresse',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopier alternativ adresse til prim&aelig;r adresse',
  'LBL_SALUTATION' => 'Hilsen',
  'LBL_SAVE_PROSPECT' => 'Gem udsigt',
  'LBL_CREATED_OPPORTUNITY' =>'Oprettede en ny mulighed',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Oprettelse af en mulighed kr&aelig;ver en konto.\n Venligst enten opret en ny eller v&aelig;lg en eksisterende.',
  'LNK_SELECT_ACCOUNT' => "V&aelig;lg konto",
  'LNK_NEW_PROSPECT' => 'Opret udsigt',
  'LNK_PROSPECT_LIST' => 'Udsigter',  
  'LNK_NEW_CAMPAIGN' => 'Opret kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagner',
  'LNK_NEW_PROSPECT_LIST' => 'Opret udsigtsliste',
  'LNK_PROSPECT_LIST_LIST' => 'Udsigtslister',
  'LNK_IMPORT_PROSPECT' => 'Importer udsigter',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'V&aelig;lg afkrydsede kontakter',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'V&aelig;lg afkrydsede udsigter',
  'LBL_INVALID_EMAIL'=>'Ugyldig e-mail:',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Udsigter',

  'LBL_CONVERT_BUTTON_KEY' => 'V',
  'LBL_CONVERT_BUTTON_TITLE' => 'Konverter udsigt',
  'LBL_CONVERT_BUTTON_LABEL' => 'Konverter udsigt',
  'LBL_CONVERTPROSPECT'=>'Konverter udsigt',
  'LNK_NEW_CONTACT'=>'Ny kontakt',
  'LBL_CREATED_CONTACT'=>"Oprettede en ny kontakt",
  'LBL_BACKTO_PROSPECTS'=>'Tilbage til udsigter',
  'LBL_CAMPAIGNS'=>'Kampagner',
  'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagne logbog',
  'LBL_TRACKER_KEY'=>'Sporhundsn&oslash;gle',
  'LBL_LEAD_ID'=>'Emne Id',
  'LBL_CONVERTED_LEAD'=>'Konverteret emne',
  'LBL_ACCOUNT_NAME'=>'Kontonavn',
  'LBL_EDIT_ACCOUNT_NAME'=>'Kontonavn:',
);
?>
