<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.16 2006/01/12 23:29:19 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Udsigtslister',
  'LBL_MODULE_TITLE' => 'Udsigtslister: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i udsigtslister',
  'LBL_LIST_FORM_TITLE' => 'Udsigtslister',
  'LBL_PROSPECT_LIST_NAME' => 'Navn:',
  'LBL_NAME' => 'Navn: ',
  'LBL_ENTRIES' => 'Total indl&aelig;g: ',
  'LBL_LIST_PROSPECT_LIST_NAME' => 'Udsigtsliste',
  'LBL_LIST_ENTRIES' => 'Udsigter i liste',
  'LBL_LIST_DESCRIPTION' => 'beskrivelse',
  'LBL_LIST_TYPE_NO' => 'Type',
  'LBL_LIST_END_DATE' => 'Slutdato',
  'LBL_DATE_ENTERED' => 'Dato indtastet',
  'LBL_DATE_MODIFIED' => 'Dato &aelig;ndret',
  'LBL_MODIFIED' => '&AElig;ndret af: ',
  'LBL_CREATED' => 'Oprettet af: ',
  'LBL_TEAM' => 'Hold: ',
  'LBL_ASSIGNED_TO' => 'Tildelt til: ',
  'LBL_DESCRIPTION' => 'Beskrivelse: ',
  'LNK_NEW_CAMPAIGN' => 'Opret kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagner',
  'LNK_NEW_PROSPECT_LIST' => 'Opret udsigtsliste',
  'LNK_PROSPECT_LIST_LIST' => 'Udsigtslister',
  'LBL_MODIFIED_BY' => '&AElig;ndret af: ',
  'LBL_CREATED_BY' => 'Oprettet af: ',
  'LBL_DATE_CREATED' => 'Oprettet den: ',
  'LBL_DATE_LAST_MODIFIED' => '&AElig;ndret den: ',
  'LNK_NEW_PROSPECT' => 'Opret udsigt',
  'LNK_PROSPECT_LIST' => 'Udsigter',

  'LBL_PROSPECT_LISTS_SUBPANEL_TITLE' => 'Udsigtslister',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
  'LBL_LEADS_SUBPANEL_TITLE' => 'Emner',
  'LBL_PROSPECTS_SUBPANEL_TITLE'=>'Udsigter',
  'LBL_COPY_PREFIX' =>'Kopi af',
  'LBL_USERS_SUBPANEL_TITLE' =>'Brugere',
  'LBL_TYPE' => 'Type',
  'LBL_LIST_TYPE' => 'Type:',  
  'LBL_LIST_TYPE_LIST_NAME'=>'Type',
  'LBL_NEW_FORM_TITLE'=>'Ny udsigtsliste',
  'LBL_MARKETING_MESSAGE'=>'E-mail markedsf&oslash;ringsmeddelelse',
  'LBL_DOMAIN_NAME'=>'Dom&aelig;nenavn',
  'LBL_DOMAIN'=>'Ingen e-mails til dom&aelig;ne:',
);


?>
