<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /var/cvsroot/sugarcrm/modules/EmailTemplates/language/en_us.lang.php,v 1.26 2006/03/28 05:06:22 andy Exp $
 * Description: Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_ADD_ANOTHER_FILE'		=> 'Tilf&oslash;j en anden fil',
	'LBL_ADD_DOCUMENT'			=> 'Tilf&oslash;j et Sugar Dokument',
	'LBL_ADD_FILE'				=> 'Tilf&oslash;j en fil',
	'LBL_ATTACHMENTS'			=> 'Vedh&aelig;ftninger',
	'LBL_BODY'					=> 'Body:',
	'LBL_CLOSE'					=> 'Afslut:',
	'LBL_COLON'					=> ':',
	'LBL_CONTACT_AND_OTHERS'	=> 'Kontakt/Emne/Udsigt',
	'LBL_DESCRIPTION'			=> 'Beskrivelse:',
	'LBL_EDIT_ALT_TEXT'			=> 'Rediger plan tekst',
	'LBL_EMAIL_ATTACHMENT'		=> 'E-mail vedh&aelig;ftning',
	'LBL_HTML_BODY'				=> 'HTML Body',
	'LBL_INSERT_VARIABLE'		=> 'Inds&aelig;t variabel:',
	'LBL_INSERT_URL_REF'		=> 'Inds&aelig;t URL-reference',
	'LBL_INSERT_TRACKER_URL'	=> 'Inds&aelig;t sporhunds-URL:',	
	'LBL_INSERT'				=> 'Inds&aelig;t',
	'LBL_LIST_DATE_MODIFIED'	=> 'Sidst &aelig;ndret',
	'LBL_LIST_DESCRIPTION'		=> 'Beskrivelse',
	'LBL_LIST_FORM_TITLE'		=> 'E-mail skabelonsliste',
	'LBL_LIST_NAME'				=> 'Navn',
	'LBL_MODULE_NAME'			=> 'E-mail skabeloner',
	'LBL_MODULE_TITLE'			=> 'E-mail skabeloner: Hjem',
	'LBL_NAME'					=> 'Navm:',
	'LBL_NEW_FORM_TITLE'		=> 'Opret e-mail skabelon',
	'LBL_PUBLISH'				=> 'Publicer:',
	'LBL_RELATED_TO'			=> 'Relateret til:',
	'LBL_SEARCH_FORM_TITLE'		=> 'S&oslash;g i e-mail skabeloner',
	'LBL_SHOW_ALT_TEXT'			=> 'Vis plan tekst',
	'LBL_SUBJECT'				=> 'Emne:',
	'LBL_TEAM'					=> 'Hold:',
	'LBL_TEAMS_LINK'			=> 'Hold',
	'LBL_TEXT_BODY'				=> 'Tekst body',
	'LNK_ALL_EMAIL_LIST'		=> 'Alle e-mails',
	'LNK_ARCHIVED_EMAIL_LIST'	=> 'Arkiverede e-mails',
	'LNK_CHECK_EMAIL'			=> 'Tjek mail',
	'LNK_DRAFTS_EMAIL_LIST'		=> 'Alle udkast',
	'LNK_EMAIL_TEMPLATE_LIST'	=> 'E-mail skabeloner',
	'LNK_IMPORT_NOTES'			=> 'Importer noter',
	'LNK_NEW_ARCHIVE_EMAIL'		=> 'Opret arkiveret e-mail',
	'LNK_NEW_EMAIL_TEMPLATE'	=> 'Opret e-mail skabelon',
	'LNK_NEW_EMAIL'				=> 'Arkiver e-mail',
	'LNK_NEW_SEND_EMAIL'		=> 'Skriv e-mail',
	'LNK_SENT_EMAIL_LIST'		=> 'Sendte e-mails',
	'LNK_VIEW_CALENDAR'			=> 'I dag',
	// for Inbox
	'LBL_NEW'					=> 'nye',
	'LNK_CHECK_MY_INBOX'		=> 'Tjek min mail',
	'LNK_GROUP_INBOX'			=> 'Gruppe indbakke',
	'LNK_MY_ARCHIVED_LIST'		=> 'Mine arkiverede',
	'LNK_MY_DRAFTS'				=> 'Mine udkast',
	'LNK_MY_INBOX'				=> 'Min indbakke',




	'LBL_DEFAULT_LINK_TEXT'		=> 'Default link text.'
);
?>
