<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.46 2006/03/10 20:14:59 ajay Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Konti',
  'LBL_MODULE_TITLE' => 'Konti: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Kontos&oslash;gning',
  'LBL_LIST_FORM_TITLE' => 'Kontoliste',
  'LBL_NEW_FORM_TITLE' => 'Ny konto',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Medlemsorganisationer',
  'LBL_BUG_FORM_TITLE' => 'Konti',
  'LBL_LIST_ACCOUNT_NAME' => 'Kontonavn',
  'LBL_LIST_CITY' => 'By',
  'LBL_LIST_WEBSITE' => 'Hjemmeside',
  'LBL_LIST_STATE' => 'Stat',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'E-mail adresse',
  'LBL_LIST_CONTACT_NAME' => 'Kontaktnavn',
  'LBL_BILLING_ADDRESS_STREET_2' =>'Betalingsadresse gade 1',
  'LBL_BILLING_ADDRESS_STREET_3' =>'Betalingsadresse gade 3',
  'LBL_BILLING_ADDRESS_STREET_4' =>'Betalingsadresse gade 4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Leveringsadresse gade 2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Leveringsadresse gade 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Leveringsadresse gade 4',
  
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Konto information',
  'LBL_ACCOUNT' => 'Konto:',
  'LBL_ACCOUNT_NAME' => 'Kontonavn:',
  'LBL_PHONE' => 'Tlf. nr.:',
  'LBL_PHONE_ALT' => 'Alternativt tlf. nr.:',
  'LBL_WEBSITE' => 'Hjemmeside:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Aktiesymbol:',
  'LBL_OTHER_PHONE' => 'Andet tlf. nr:',
  'LBL_ANY_PHONE' => 'Alle telefonnumre:',
  'LBL_MEMBER_OF' => 'Medlem af:',
  'LBL_PHONE_OFFICE' => 'Tlf. nr kontor:',
  'LBL_PHONE_FAX' => 'Tlf. nr. fax:',
  'LBL_EMAIL' => 'E-mail:',
  'LBL_EMPLOYEES' => 'Ansatte:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Anden e-mail:',
  'LBL_ANY_EMAIL' => 'Alle e-mail adresser:',
  'LBL_OWNERSHIP' => 'Ejerskab:',
  'LBL_RATING' => 'Bed&oslash;mmelse:',
  'LBL_INDUSTRY' => 'Industri:',
  'LBL_SIC_CODE' => 'SIC kode:',
  'LBL_TYPE' => 'Type:',
  'LBL_ANNUAL_REVENUE' => '&Aring;rligt resultat:',
  'LBL_ADDRESS_INFORMATION' => 'Adresseinformation',
  'LBL_BILLING_ADDRESS' => 'Betalingsadresse:',
  'LBL_BILLING_ADDRESS_STREET' => 'Betalingsadresse gade:',
  'LBL_BILLING_ADDRESS_CITY' => 'Betalingadresse by:',
  'LBL_BILLING_ADDRESS_STATE' => 'Betalingsadresse stat:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Betalingsadresse postnummer:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Betalingsadresse land:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Leveringsadresse gade:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Leveringsadresse by',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Leveringsadresse stat:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Leveringsadresse postnummer:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Leveringsadresse land:',
  'LBL_SHIPPING_ADDRESS' => 'Leveringsadresse:',
  'LBL_DATE_MODIFIED' => '&AElig;ndret d.:',
  'LBL_DATE_ENTERED' => 'Indtastet d.:',
  'LBL_ANY_ADDRESS' => 'Alle adresser:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_PUSH_CONTACTS_BUTTON_TITLE' => 'Kopier...',
  'LBL_PUSH_CONTACTS_BUTTON_LABEL' => 'Kopier til kontakter',
  'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelsesinformation',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'NTC_COPY_BILLING_ADDRESS' => 'Kopier betalingsadresse til leveringsadresse',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Kopier leveringsadresse til betalingsadresse',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne dette element som en medlemsorganisation?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne dette element?',
  'LBL_DUPLICATE' => 'Mulig duplikat af konto',
  'MSG_SHOW_DUPLICATES' => 'Oprettelse af denne kontakt kan muligvis resultere i en duplikat af en eksisterende kontakt. Du kan enten v&aelig;lge at klikke p&aring; Opret konto for at forts&aelig;tte eller du kan klikke p&aring; annuller.',
  'MSG_DUPLICATE' => 'Oprettelse af denne konto kan muligvis resultere i en duplikat af en eksisterende konto. Du kan enten v&aelig;lge en konto fra nedenst&aring;ende liste eller du kan v&aelig;lge Opret konto for at forts&aelig;tte med de tidligere indtastede data.',
  'LNK_NEW_ACCOUNT' => 'Opret konto',



  'LNK_ACCOUNT_LIST' => 'Kontoliste',
  'LBL_INVITEE' => 'Kontakter',
  'ERR_DELETE_RECORD' => 'Et element-id skal specificeres for at slette denne konto.',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at slette dette element?',
  'LBL_SAVE_ACCOUNT' => 'Gem konto',
  'LBL_BUG_FORM_TITLE' => 'Konti',
	'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Er du sikker p&aring; du &oslash;nsker at slette denne konto fra dette projekt?',
	'LBL_USERS_ASSIGNED_LINK'=>'Tildelte brugere',
	'LBL_USERS_MODIFIED_LINK'=>'&AElig;ndrede brugere',
	'LBL_USERS_CREATED_LINK'=>'Oprettet af brugere',
	'LBL_TEAMS_LINK'=>'Hold',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Konti',
	'LBL_PRODUCTS_TITLE'=>'Produkter',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
	'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'Medlemsorganisationer',
	'LBL_NAME'=>'Navn:',
	
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Muligheder',
	'LBL_LEADS_SUBPANEL_TITLE' => 'Emner',
	'LBL_CASES_SUBPANEL_TITLE' => 'Sager',






	'LBL_MEMBER_ORG_SUBPANEL_TITLE' => 'Medlemsorganisationer',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Fejlrapporteringer',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekter',
    'LBL_ASSIGNED_TO_NAME' => 'Tildelt brugers navn:',

);


?>
