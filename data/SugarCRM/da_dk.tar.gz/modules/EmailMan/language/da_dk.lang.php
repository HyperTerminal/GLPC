<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.13.4.1 2006/05/04 02:17:20 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'ERR_INT_ONLY_EMAIL_PER_RUN'				=> 'Kun nummeriske v&aelig;rdier er tilladt for antallet af e-mails sendt pr. bunke',
	'LBL_ATTACHMENT_AUDIT'						=> ' blev sendt. Den blev ikke duplikeret lokalt for at spare diskplads.',
	'LBL_CONFIGURE_SETTINGS'					=> 'Konfigurer',
	'LBL_CUSTOM_LOCATION'						=> 'Brugerdefineret',
	'LBL_DEFAULT_LOCATION'						=> 'Standard',
	'LBL_EMAIL_DEFAULT_CLIENT'					=> 'Skriv e-mail meddelelse i dette format',
	'LBL_EMAIL_DEFAULT_EDITOR'					=> 'Skriv e-mails ved hj&aelig;lp af denne klient',
	'LBL_EMAIL_PER_RUN_REQ'						=> 'Antal af e-mails sendt pr. bunke:',
	'LBL_EMAIL_USER_TITLE'						=> 'Bruger e-mail standarder',
	'LBL_EMAILS_PER_RUN'						=> 'Antal e-mails sendt pr. bunke:',
	'LBL_ID'									=> 'Id',
	'LBL_LIST_CAMPAIGN'							=> 'Kampagne',
	'LBL_LIST_FORM_PROCESSED_TITLE'				=> 'Gennemf&oslash;rt',
	'LBL_LIST_FORM_TITLE'						=> 'K&oslash;',
	'LBL_LIST_FROM_EMAIL'						=> 'Fra e-mail',
	'LBL_LIST_FROM_NAME'						=> 'Fra navn',
	'LBL_LIST_IN_QUEUE'							=> 'Under behandling',
	'LBL_LIST_MESSAGE_NAME'						=> 'Markedsf&oslash;ringsmeddelelse',
	'LBL_LIST_RECIPIENT_EMAIL'					=> 'Modtager e-mail',
	'LBL_LIST_RECIPIENT_NAME'					=> 'Modtagernavn',
	'LBL_LIST_SEND_ATTEMPTS'					=> 'Afsnedingsfors&oslash;g',
	'LBL_LIST_SEND_DATE_TIME'					=> 'Send den',
	'LBL_LIST_USER_NAME'						=> 'Brugernavn',
	'LBL_LOCATION_ONLY'							=> 'Placering',
	'LBL_LOCATION_TRACK'						=> 'Placering af kampagnesporhundefile (s&aring;som campaign_tracker.php)',
	'LBL_MAIL_SENDTYPE'							=> 'Mail Transfer Agent:',
	'LBL_MAIL_SMTPAUTH_REQ'						=> 'Benyt SMTP Authentication?',
	'LBL_MAIL_SMTPPASS'							=> 'SMTP Adgangskode:',
	'LBL_MAIL_SMTPPORT'							=> 'SMTP Port:',
	'LBL_MAIL_SMTPSERVER'						=> 'SMTP Server:',
	'LBL_MAIL_SMTPUSER'							=> 'SMTP Brugernavn:',
	'LBL_MARKETING_ID'							=> 'Markedsf&oslash;rings Id',
	'LBL_MODULE_NAME'							=> 'E-mail indstillinger',
	'LBL_MODULE_TITLE'							=> 'Udg&aring;ende e-mail k&oslash; administration',
	'LBL_NOTIFICATION_ON_DESC' 					=> 'Afsender notifikationsmeddelelser n&aring;r elementer bliver tildelt.',
	'LBL_NOTIFY_FROMADDRESS' 					=> '"Fra" adresse:',
	'LBL_NOTIFY_FROMNAME' 						=> '"Fra" navn:',
	'LBL_NOTIFY_ON'								=> 'Notifikationer sl&aring;et til?',
	'LBL_NOTIFY_SEND_BY_DEFAULT'				=> 'Send notfikationer som standard for nye brugere?',
	'LBL_NOTIFY_TITLE'							=> 'E-mail notifikationsmuligheder',
	'LBL_OLD_ID'								=> 'Gammelt Id',
	'LBL_OUTBOUND_EMAIL_TITLE'					=> 'Udg&aring;ende e-mail muligheder',
	'LBL_RELATED_ID'							=> 'Relateret Id',
	'LBL_RELATED_TYPE'							=> 'Relateret type',
	'LBL_SEARCH_FORM_PROCESSED_TITLE'			=> 'Gennemf&oslash;rte s&oslash;gningen',
	'LBL_SEARCH_FORM_TITLE'						=> 'S&oslash;gning i k&oslash;',
	'LBL_VIEW_PROCESSED_EMAILS'					=> 'Vis gennemf&oslash;rte e-mails',
	'LBL_VIEW_QUEUED_EMAILS'					=> 'Vis e-mails sat i k&oslash;',
	'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE'	=> 'V&aelig;rdi i Config.php indstillingen site_url',
	'TXT_REMOVE_ME_ALT'							=> 'For at fjerne dig selv fra denne mailliste g&aring; til',
	'TXT_REMOVE_ME_CLICK'						=> 'klik her',
	'TXT_REMOVE_ME'								=> 'For at fjerne dig selv fra denne mailliste ',
);

?>
