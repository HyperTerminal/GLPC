<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.9 2006/03/19 02:03:13 andy Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME'=>'System Settings',
	'LBL_MODULE_TITLE'=>'User Interface',
	'ADMIN_EXPORT_ONLY'=>'Admin export only',
	'DISABLE_EXPORT'=>'Disable export',
	'DEFAULT_CURRENCY_NAME'=>'Currency name',
	'DEFAULT_CURRENCY_SYMBOL'=>'Currency symbol',
	'DEFAULT_CURRENCY_ISO4217'=>'ISO 4217 currency code',
	'DEFAULT_CURRENCY'=>'Default Currency',
	'EXPORT'=>'Export',
	'QUOTES_CURRENT_LOGO'=>'Logo used in Quotes ',
	'NEW_QUOTE_LOGO'=>'Upload new Quote logo (867x74)',
	'CURRENT_LOGO'=>'Current logo in use',
	'NEW_LOGO'=>'Upload new logo (212x40)',
	'DEFAULT_SYSTEM_SETTINGS'=>'User Interface',
	'DEFAULT_DATE_FORMAT'=>'Default date format',
	'DEFAULT_TIME_FORMAT'=>'Default time format',
	'DEFAULT_THEME'=> 'Default theme',
	'LIST_ENTRIES_PER_LISTVIEW'=>'Listview items per page',
	'LIST_ENTRIES_PER_SUBPANEL'=>'Subpanel items per page',
	'DISPLAY_LOGIN_NAV'=>'Display tabs on login screen',
	'DISPLAY_RESPONSE_TIME'=>'Display server response times',
	'ADVANCED'=>'Advanced',
	'VERIFY_CLIENT_IP'=>'Validate user IP address',
	'LOG_MEMORY_USAGE'=>'Log memory usage',
	'LOG_SLOW_QUERIES'=> 'Log slow queries',
	'SLOW_QUERY_TIME_MSEC'=>'Slow query time threshold (msec)',
	'UPLOAD_MAX_SIZE'=>'Maximum upload size',
	'STACK_TRACE_ERRORS'=>'Display stack trace of errors',
	'IMAGES'=>'Logos',
	'DEFAULT_LANGUAGE'=>'Default language',
	'LBL_RESTORE_BUTTON_LABEL'=>'Restore',
	'LBL_PORTAL_ON_DESC' => 'Allows Case, Note and other data to be accessible by an external customer self-service portal system.',
	'LBL_PORTAL_ON' => 'Enable self-service portal integration?',
	'LBL_PORTAL_TITLE' => 'Customer Self-Service Portal',
	'LBL_PROXY_AUTH'=>'Authentication?',
	'LBL_PROXY_HOST'=>'Proxy Host',
	'LBL_PROXY_ON_DESC'=>'Configure proxy server address and authentication settings',
	'LBL_PROXY_ON'=>'Use proxy server?',
	'LBL_PROXY_PASSWORD'=>'Password',
	'LBL_PROXY_PORT'=>'Port',
	'LBL_PROXY_TITLE'=>'Proxy Settings',
	'LBL_PROXY_USERNAME'=>'User Name',
	'LBL_SKYPEOUT_ON_DESC' => 'Allows users to click on phone numbers to call using SkypeOut&reg;. The numbers must be formatted properly to make use of this feature. That is, it must be "+"  "The Country Code" "The Number", like +1 (555) 555-1234. For more information, see the Skype FAQ at <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>	',
	'LBL_SKYPEOUT_ON' => 'Enable SkypeOut&reg; integration?',
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
	'LBL_MAILMERGE' => 'Mail Merge',
	'LBL_ENABLE_MAILMERGE' => 'Enable mail merge?',
	'LBL_MAILMERGE_DESC' => 'This flag should be checked only if you have the Sugar Plug-in for Microsoft&reg; Word&reg;.',
	'LBL_LOGVIEW' => 'Configure Log Settings',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'System Settings',
	'LBL_MAIL_SMTPAUTH_REQ'				=> 'Use SMTP Authentication?',
	'LBL_MAIL_SMTPPASS'					=> 'SMTP Password:',
	'LBL_MAIL_SMTPPORT'					=> 'SMTP Port:',
	'LBL_MAIL_SMTPSERVER'				=> 'SMTP Server:',
	'LBL_MAIL_SMTPUSER'					=> 'SMTP Username:',
	'LBL_NOTIFY_FROMADDRESS' => '"From" Address:',
	'LBL_NOTIFY_SUBJECT' => 'Email subject:',
	'DEFAULT_NUMBER_GROUPING_SEP'			=> '1000s separator',
	'DEFAULT_DECIMAL_SEP'					=> 'Decimal symbol',
);


?>
