<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
********************************************************************************/
/*********************************************************************************
* $Id: en_us.lang.php,v 1.34 2006/01/17 22:54:33 majed Exp $
* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributor(s): ______________________________________..
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
    'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
    //END DON'T CONVERT
    'ERR_DELETE_RECORD' => 'da_dk Et datanummer skal angives for at slette dette emne.',
    'LBL_ACCOUNT_DESCRIPTION'=> 'Kontobeskrivelse',
    'LBL_ACCOUNT_ID'=>'Konto ID',
    'LBL_ACCOUNT_NAME' => 'Kontonavn:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteter',
    'LBL_ADD_BUSINESSCARD' => 'Tilf&oslash;j visitkort',
    'LBL_ADDRESS_INFORMATION' => 'Adresse information',
    'LBL_ALT_ADDRESS_CITY' => 'Alt. adresse by',
    'LBL_ALT_ADDRESS_COUNTRY' => 'Alt. adresse land',
    'LBL_ALT_ADDRESS_POSTALCODE' => 'Alt. adresse postnummer',
    'LBL_ALT_ADDRESS_STATE' => 'Alt. adresse stat',
    'LBL_ALT_ADDRESS_STREET_2' => 'Alt. adresse gade 2',
    'LBL_ALT_ADDRESS_STREET_3' => 'Alt. adresse gade 3',
    'LBL_ALT_ADDRESS_STREET' => 'Alt. adresse gade',
    'LBL_ALTERNATE_ADDRESS' => 'Anden adresse:',
    'LBL_ANY_ADDRESS' => 'Alle adresser:',
    'LBL_ANY_EMAIL' => 'Alle e-mail adresser:',
    'LBL_ANY_PHONE' => 'Alle telefonnumre:',
    'LBL_ASSIGNED_TO_NAME' => 'Tildelt til navn',
    'LBL_BACKTOLEADS' => 'Tilbage til emner',
    'LBL_BUSINESSCARD' => 'Konverter emner',
    'LBL_CITY' => 'By:',
    'LBL_CONTACT_ID' => 'Kontakt ID',
    'LBL_CONTACT_INFORMATION' => 'Emne information',
    'LBL_CONTACT_NAME' => 'Emnenavn:',
    'LBL_CONTACT_OPP_FORM_TITLE' => 'Emne-Mulighed:',
    'LBL_CONTACT_ROLE' => 'Rolle:',
    'LBL_CONTACT' => 'Emne:',
    'LBL_CONVERTED_ACCOUNT'=>'Konverteret konto:',
    'LBL_CONVERTED_CONTACT' => 'Konverteret kontakt:',
    'LBL_CONVERTED_OPP'=>'Konverteret mulighed:',
    'LBL_CONVERTED'=> 'Konverteret',
    'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
    'LBL_CONVERTLEAD_TITLE' => 'Konverter emne [Alt+V]',
    'LBL_CONVERTLEAD' => 'Konverter emne',
    'LBL_COUNTRY' => 'Land:',
    'LBL_CREATED_ACCOUNT' => 'Oprettede en ny konto',
    'LBL_CREATED_CALL' => 'Oprettede et nyt opkald',
    'LBL_CREATED_CONTACT' => 'Oprettede en ny kontakt',
    'LBL_CREATED_MEETING' => 'Oprettede et nyt m&oslash;de',
    'LBL_CREATED_OPPORTUNITY' => 'Oprettede en ny mulighed',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Emne',
    'LBL_DEPARTMENT' => 'Afdeling:',
    'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelsesinformation',
    'LBL_DESCRIPTION' => 'Beskrivelse:',
    'LBL_DO_NOT_CALL' => 'Undlad telefonopkald:',
    'LBL_DUPLICATE' => 'Lignende emner',
    'LBL_EMAIL_ADDRESS' => 'E-mail:',
    'LBL_EMAIL_OPT_OUT' => 'E-mail fravalg:',
    'LBL_EXISTING_ACCOUNT' => 'Anvendte en eksisterende konto',
    'LBL_EXISTING_CONTACT' => 'Anvendte en eksisterende kontakt',
    'LBL_EXISTING_OPPORTUNITY' => 'Anvendte en eksisterende mulighed',
    'LBL_FAX_PHONE' => 'Fax:',
    'LBL_FIRST_NAME' => 'Fornavn:',
    'LBL_FULL_NAME' => 'Fulde navn:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'Historie',
    'LBL_HOME_PHONE' => 'Telefon hjem:',
    'LBL_IMPORT_VCARD' => 'Importer vCard',
    'LBL_IMPORT_VCARDTEXT' => 'Automatisk opret et nyt emne ved at importere et vCard fra dit filsystem.',
    'LBL_INVALID_EMAIL'=>'Ugyldig e-mail:',
    'LBL_INVITEE' => 'Direkte rapporter',
    'LBL_LAST_NAME' => 'Efternavn:',
    'LBL_LEAD_SOURCE_DESCRIPTION' => 'Emnekilde beskrivelse:',
    'LBL_LEAD_SOURCE' => 'Emnekilde:',
    'LBL_LIST_ACCOUNT_NAME' => 'Kontonavn',
    'LBL_LIST_CONTACT_NAME' => 'Emnenavn',
    'LBL_LIST_CONTACT_ROLE' => 'Rolle',
    'LBL_LIST_DATE_ENTERED' => 'Dato for oprettelse',
    'LBL_LIST_EMAIL_ADDRESS' => 'E-mail',
    'LBL_LIST_FIRST_NAME' => 'Fornavn',
    'LBL_LIST_FORM_TITLE' => 'Emneliste',
    'LBL_LIST_LAST_NAME' => 'Efternavn',
    'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Emnekilde beskrivelse',
    'LBL_LIST_LEAD_SOURCE' => 'Emnekilde',
    'LBL_LIST_MY_LEADS' => 'Mine emner',
    'LBL_LIST_NAME' => 'Navn',
    'LBL_LIST_PHONE' => 'Telefon kontor',
    'LBL_LIST_REFERED_BY' => 'Refereret til af',
    'LBL_LIST_STATUS' => 'Status',
    'LBL_LIST_TITLE' => 'Titel',
    'LBL_MOBILE_PHONE' => 'Mobil:',
    'LBL_MODULE_NAME' => 'Emner',
    'LBL_MODULE_TITLE' => 'Emner: Hjem',
    'LBL_NAME' => 'Navn:',
    'LBL_NEW_FORM_TITLE' => 'Nyt emne',
    'LBL_NEW_PORTAL_PASSWORD' => 'Nyt portaladgangskode:',
    'LBL_OFFICE_PHONE' => 'Telefon kontor:',
    'LBL_OPP_NAME' => 'Mulighedsnavn:',
    'LBL_OPPORTUNITY_AMOUNT' => 'Mulighed m&aelig;ngde:',
    'LBL_OPPORTUNITY_ID'=>'Mulighed ID',
    'LBL_OPPORTUNITY_NAME' => 'Mulighedsnavn:',
    'LBL_OTHER_EMAIL_ADDRESS' => 'Anden e-mail:',
    'LBL_OTHER_PHONE' => 'Anden telefon:',
    'LBL_PHONE' => 'Telefon:',
    'LBL_PORTAL_ACTIVE' => 'Portal aktiv:',
    'LBL_PORTAL_APP'=> 'Portal applikation',
    'LBL_PORTAL_INFORMATION' => 'Portalinformation',
    'LBL_PORTAL_NAME' => 'Portalnavn:',
    'LBL_PORTAL_PASSWORD_ISSET' => 'Portal adgangskode er sat:',
    'LBL_POSTAL_CODE' => 'Postnummer:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Prim&aelig;r adresse by',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Prim&aelig;r adresse land',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Prim&aelig;r adresse postnummer',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Prim&aelig;r adresse stat',
    'LBL_PRIMARY_ADDRESS_STREET_2'=>'Prim&aelig;r adresse gade 2',
    'LBL_PRIMARY_ADDRESS_STREET_3'=>'Prim&aelig;r adresse gade 3',   
    'LBL_PRIMARY_ADDRESS_STREET' => 'Prim&aelig;r adresse gade',
    'LBL_PRIMARY_ADDRESS' => 'Prim&aelig;r adresse:',
    'LBL_REFERED_BY' => 'Refereret til af:',
    'LBL_REPORTS_TO_ID'=>'Rapporterer til ID',
    'LBL_REPORTS_TO' => 'Rapporterer til:',
    'LBL_SALUTATION' => 'Hilsen',
    'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i emner',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'V&aelig;lg afkrydsede emner',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'V&aelig;lg afkrydsede emner',
    'LBL_STATE' => 'Stat:',
    'LBL_STATUS_DESCRIPTION' => 'Statusbeskrivelse:',
    'LBL_STATUS' => 'Status:',
    'LBL_TITLE' => 'Titel:',
    'LNK_IMPORT_VCARD' => 'Opret fra vCard',
    'LNK_LEAD_LIST' => 'Emner',
    'LNK_NEW_ACCOUNT' => 'Opret konto',
    'LNK_NEW_APPOINTMENT' => 'Opret aftale',
    'LNK_NEW_CONTACT' => 'Opret kontakt',
    'LNK_NEW_LEAD' => 'Opret emne',
    'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
    'LNK_NEW_OPPORTUNITY' => 'Opret mulighed',
    'LNK_SELECT_ACCOUNT' => 'V&aelig;lg konto',
    'MSG_DUPLICATE' => 'Lignende emner er blevet fundet. Venligst s&aelig;t kryds ved de emner du &oslash;nsker at associere med de elementer der vil blive oprettet fra konverteringen. Efter du er f&aelig;rdig, venligst tryk p&aring; n&aelig;ste.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopier alternativ adresse til prim&aelig;r adresse',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Kopier prim&aelig;r adresse til alternativ adresse',
    'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at slette dette element?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Oprettelse af en mulighed kr&aelig;ver en konto.\n Venligst enten opret en ny konto eller v&aelig;lg en eksisterende.',
    'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne dette emne fra denne sag?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne dette element som en direkte rapport?',
    'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagner',
    'LBL_TARGET_OF_CAMPAIGNS'=>'Succesfuld kampagne:',
    'LBL_TARGET_BUTTON_LABEL'=>'M&aring;lsat',
    'LBL_TARGET_BUTTON_TITLE'=>'M&aring;lsat',
    'LBL_TARGET_BUTTON_KEY'=>'T',
    'LBL_CAMPAIGN_ID'=>'Kampagne Id',
);


?>
