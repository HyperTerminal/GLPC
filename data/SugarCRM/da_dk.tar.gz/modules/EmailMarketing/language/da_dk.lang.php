<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.19 2006/01/17 22:50:48 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'E-mail markedsf&oslash;ring',
  'LBL_MODULE_TITLE' => 'E-mail markedsf&oslash;ring: Hjem',
  'LBL_LIST_FORM_TITLE' => 'E-mail markedsf&oslash;ringskampagner',
  'LBL_PROSPECT_LIST_NAME' => 'Navn:',
  'LBL_NAME' => 'Navn: ',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_FROM_ADDR' => 'Fra e-mail',
  'LBL_LIST_DATE_START' => 'Startdato',
  'LBL_LIST_TEMPLATE_NAME' => 'E-mail skabelon',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_STATUS'	=>	'Status',
  'LBL_STATUS_TEXT'	=>	'Status:' ,
  
  'LBL_DATE_ENTERED' => 'Oprettet den',
  'LBL_DATE_MODIFIED' => '&Aelig;ndret den',
  'LBL_MODIFIED' => '&Aelig;ndret af: ',
  'LBL_CREATED' => 'Oprettet af: ',
  'LBL_MESSAGE_FOR'	=> 'Send denne meddelelse til:',
  'LBL_MESSAGE_FOR_ID'	=> 'Meddelelse for',
  
  'LBL_FROM_NAME' => 'Fra navn: ',
  'LBL_FROM_ADDR' => 'Fra e-mail adresse: ',
  'LBL_DATE_START' => 'Startdato',
  'LBL_TIME_START' => 'Starttid',
  'LBL_START_DATE_TIME' => 'Startdato & tid: ',
  'LBL_TEMPLATE' => 'E-mail skabelon: ',
  
  'LBL_MODIFIED_BY' => '&Aelig;ndret af: ',
  'LBL_CREATED_BY' => 'Oprettet af: ',
  'LBL_DATE_CREATED' => 'Oprettet den: ',
  'LBL_DATE_LAST_MODIFIED' => '&Aelig;ndret den: ',

  'LNK_NEW_CAMPAIGN' => 'Opret kampagne',
  'LNK_CAMPAIGN_LIST' => 'Kampagner',
  'LNK_NEW_PROSPECT_LIST' => 'Opret udsigtsliste',
  'LNK_PROSPECT_LIST_LIST' => 'Udsigtslister',
  'LNK_NEW_PROSPECT' => 'Opret udsigt',
  'LNK_PROSPECT_LIST' => 'Udsigter',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'E-mail markedsf&oslash;ring',
  'LBL_CREATE_EMAIL_TEMPLATE'=>	'Opret',
  'LBL_EDIT_EMAIL_TEMPLATE'=>	'Rediger',
  'LBL_FROM_MAILBOX'=>'Fra mailbox',
  'LBL_FROM_MAILBOX_NAME'=>'Benyt mailbox:',
  'LBL_PROSPECT_LIST_SUBPANEL_TITLE'=>'Udsigtslister',	
  'LBL_ALL_PROSPECT_LISTS'=>'Alle udsigtslister i denne kampagne.',
  'LBL_RELATED_PROSPECT_LISTS'=>'Alle udsigtslister relateret til denne meddelelse.',
  'LBL_PROSPECT_LIST_NAME'=>'Udsigtslistenavn',
  'LBL_LIST_PROSPECT_LIST_NAME'=>'Udsigt lister',
  'LBL_MODULE_SEND_TEST'=>'Kampagne: Send test',
  'LBL_MODULE_SEND_EMAILS'=>'Kampagne: Send e-mails',
  'LBL_SCHEDULE_MESSAGE_TEST'=>'Venligst v&aelig;lg kampagnemeddelelserne du &oslash;nsker at sende test:',
  'LBL_SCHEDULE_MESSAGE_EMAILS'=>'Venligst v&aelig;lg kampagnemeddelelserne du &oslash;nsker at skemal&aelig;gge til at sende for en specifik startdato og tid:',
  'LBL_SCHEDULE_BUTTON_TITLE'=>'Send',
  'LBL_SCHEDULE_BUTTON_LABEL'=>'Send',
  'LBL_SCHEDULE_BUTTON_KEY'=>'T',
  
  
  
);
?>
