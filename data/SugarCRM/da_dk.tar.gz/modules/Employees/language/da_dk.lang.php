<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.4 2006/01/17 22:50:55 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Medarbejdere',
  'LBL_MODULE_TITLE' => 'Medarbejdere: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'S&oslash;g i medarbejdere',
  'LBL_LIST_FORM_TITLE' => 'Medarbejdere',
  'LBL_NEW_FORM_TITLE' => 'Ny medarbejder',
  'LBL_EMPLOYEE' => 'Medarbejdere:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Nulstil til standard indstillinger',
  'LBL_TIME_FORMAT' => 'Tidsformat:',
  'LBL_DATE_FORMAT' => 'Datoformat:',
  'LBL_TIMEZONE' => 'Nuv&aelig;rende tid:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_LIST_EMPLOYEE_NAME' => 'Ansattes navn',
  'LBL_LIST_DEPARTMENT' => 'Afdeling',
  'LBL_LIST_REPORTS_TO_NAME' => 'Rapporterer til',
  'LBL_LIST_EMAIL' => 'E-mail',
  'LBL_LIST_PRIMARY_PHONE' => 'Prim&aelig;r telefon',
  'LBL_LIST_USER_NAME' => 'Brugernavn',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Ansat status',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Ny ansat [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Ny ansat',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fejl:',
  'LBL_PASSWORD' => 'Adgangskode:',
  'LBL_EMPLOYEE_NAME' => 'Ansattes navn:',
  'LBL_USER_NAME' => 'Brugernavn:',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_EMPLOYEE_SETTINGS' => 'Indstillinger for medarbejder',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Sprog:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_EMPLOYEE_INFORMATION' => 'Medarbejderinformation',
  'LBL_OFFICE_PHONE' => 'Kontor telefon:',
  'LBL_REPORTS_TO' => 'Rapporterer til:',
  'LBL_OTHER_PHONE' => 'Andre:',
  'LBL_OTHER_EMAIL' => 'Anden e-mail:',
  'LBL_NOTES' => 'Noter:',
  'LBL_DEPARTMENT' => 'Afdeling:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Alle telefoner:',
  'LBL_ANY_EMAIL' => 'Alle e-mails:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'By:',
  'LBL_STATE' => 'Stat:',
  'LBL_POSTAL_CODE' => 'Postnummer:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Navn:',
  'LBL_MOBILE_PHONE' => 'Mobil:',
  'LBL_OTHER' => 'Andre:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'E-mail:',
  'LBL_HOME_PHONE' => 'Hjemmetelefon:',
  'LBL_ADDRESS_INFORMATION' => 'Adresseinformation',
  'LBL_EMPLOYEE_STATUS' => 'Medarbejderstatus:',
  'LBL_PRIMARY_ADDRESS' => 'Prim&aelig;r adresse:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Opret bruger [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Opret bruger',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Favorit farve:',
  'LBL_MESSENGER_ID' => 'IM navn:',
  'LBL_MESSENGER_TYPE' => 'IM type:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Den ansattes navn ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' eksisterer allerede. Duplikater af ansattes navne er ikke tillad. &AElig;ndre navnet til at v&aelig;re unikt.',
  'ERR_LAST_ADMIN_1' => 'Den ansattes navn "',
  'ERR_LAST_ADMIN_2' => '" er den sidste ansatte med administratoradgang. Mindst en medarbejder skal v&aelig;re en administrator.',
  'LNK_NEW_EMPLOYEE' => 'Opret medarbejder',
  'LNK_EMPLOYEE_LIST' => 'Medarbejdere',
  'ERR_DELETE_RECORD' => 'Et datanummer skal angives for at slette denne konto.',








  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',

);


?>
