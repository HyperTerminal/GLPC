<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.16 2006/01/17 22:50:47 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'Valutaer',
  'LBL_CURRENCY' => 'Valuta',
  'LBL_ADD' => 'Tilf&oslash;j',
  'LBL_MERGE' => 'Sammensmelt',
  'LBL_MERGE_TXT' => 'Venligst afkryds valutaerne du &oslash;nsker at rette til den valgte valuta. Dette vil slette alle afkrydsede valutaer og gentildele alle associerede v&aelig;rdier til den valgte valuta.',
  'LBL_US_DOLLAR' => 'U.S. Dollar',
  'LBL_DELETE' => 'Slet',
  'LBL_LIST_SYMBOL' => 'Valutasymbol',
  'LBL_LIST_NAME' => 'Valutanavn',
  'LBL_LIST_ISO4217' => 'ISO 4217 Code',
  'LBL_UPDATE' => 'Opdater',
  'LBL_LIST_RATE' => 'Vekselkurs',
  'LBL_LIST_STATUS' => 'Status',
  'LNK_NEW_CONTACT' => 'Ny kontakt',
  'LNK_NEW_ACCOUNT' => 'Ny konto',
  'LNK_NEW_OPPORTUNITY' => 'Ny mulighed',
  'LNK_NEW_CASE' => 'Ny sag',
  'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
  'LNK_NEW_CALL' => 'Nyt opkald',
  'LNK_NEW_EMAIL' => 'Ny e-mail',
  'LNK_NEW_MEETING' => 'Nyt m&oslash;de',
  'LNK_NEW_TASK' => 'Opret opgave',
  'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at slette dette element? Det ville muligvis v&aelig;re bedre at deaktivere dem, ellers vil alle andre associerede elementer konverteret til standard valutaen.',
  'currency_status_dom' => 
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Ikke aktiv',
  ),
);


?>
