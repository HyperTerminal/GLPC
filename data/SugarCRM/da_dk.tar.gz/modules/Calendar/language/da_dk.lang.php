<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.20 2006/01/17 22:50:46 majed Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'=>'Kalender',
  'LBL_MODULE_TITLE'=>'Kalender',
  'LNK_NEW_CALL' => 'Skemal&aelig;g opkald',
  'LNK_NEW_MEETING' => 'Skemal&aelig;g m&oslash;de',
  'LNK_NEW_APPOINTMENT' => 'Opret aftale',
  'LNK_NEW_TASK' => 'Opret opgave',
  'LNK_CALL_LIST' => 'Opkald',
  'LNK_MEETING_LIST' => 'M&oslash;der',
  'LNK_TASK_LIST' => 'Opgaver',
  'LNK_VIEW_CALENDAR' => 'I dag',
  'LBL_MONTH' => 'M&aring;ned',
  'LBL_DAY' => 'Dag',
  'LBL_YEAR' => '&Aring;r',
  'LBL_WEEK' => 'Uge',
  'LBL_PREVIOUS_MONTH' => 'Forrige m&aring;ned',
  'LBL_PREVIOUS_DAY' => 'Forrige dag',
  'LBL_PREVIOUS_YEAR' => 'Forrige &aring;r',
  'LBL_PREVIOUS_WEEK' => 'Forrige uge',
  'LBL_NEXT_MONTH' => 'N&aelig;ste m&aring;ned',
  'LBL_NEXT_DAY' => 'N&aelig;ste dag',
  'LBL_NEXT_YEAR' => 'N&aelig;ste &aring;r',
  'LBL_NEXT_WEEK' => 'N&aelig;ste uge',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Planlagt',
  'LBL_BUSY' => 'Optaget',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'Brugerkalendere',
  'LBL_SHARED' => 'Delt',
  'LBL_PREVIOUS_SHARED' => 'Forrige',
  'LBL_NEXT_SHARED' => 'N&aelig;ste',
  'LBL_SHARED_CAL_TITLE' => 'Delt kalender',
  'LBL_USERS' => 'Bruger',
  'LBL_REFRESH' => 'Opdater',
  'LBL_EDIT' => 'Rediger',
  'LBL_SELECT_USERS' => 'V&aelig;lg brugere til visning af kalender',
  'LBL_FILTER_BY_TEAM' => 'Filtre brugerliste efter hold:',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"s&oslash;n",
"man",
"tir",
"ons",
"tor",
"fre",
"l&oslash;r",
),
'dom_cal_weekdays_long'=>array(
"s&oslash;n",
"man",
"tir",
"ons",
"tor",
"fre",
"l&oslash;r",
),
'dom_cal_month'=>array(
"",
"jan",
"feb",
"mar",
"apr",
"maj",
"Jun",
"jul",
"aug",
"sep",
"okt",
"nov",
"dec",
),
'dom_cal_month_long'=>array(
"",
"januar",
"februar",
"marts",
"april",
"maj",
"juni",
"juli",
"august",
"september",
"oktober",
"november",
"december",
)
);
?>
