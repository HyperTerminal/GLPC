<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.109.2.1 2006/05/05 19:35:01 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_CONFIRM_DELETE'		=> 'Er du sikker p&aring; du vil slette denne mappe?',




	'ERR_ARCHIVE_EMAIL'			=> 'Fejl: V&aelig;lg e-mails der skal arkiveres.',
	'ERR_DATE_START'			=> 'Startdato',
	'ERR_DELETE_RECORD'			=> 'Fejl: Et datanummer skal angives dor at slette kotntoen.',	
	'ERR_NOT_ADDRESSED'			=> 'Fejl: E-mail skal have en Til, CC eller BCC adresse',
	'ERR_TIME_START'			=> 'Starttidspunkt',
	'LBL_ACCOUNTS_SUBPANEL_TITLE'=> 'Konti',
	'LBL_ADD_ANOTHER_FILE'		=> 'Tilf&oslash;j en fil til',
	'LBL_ADD_DOCUMENT'			=> 'Tilf&oslash;j et Sugar Dokument',
	'LBL_ADD_FILE'				=> 'Tilf&oslash;j en fil',
	'LBL_ARCHIVED_EMAIL'		=> 'Arkiveret e-mail',
	'LBL_ARCHIVED_MODULE_NAME'	=> 'Opret arkiverede e-mails',
	'LBL_ATTACHMENTS'			=> 'Vedh&aelig;ftninger:',
	'LBL_BCC'					=> 'Bcc:',
	'LBL_BODY'					=> 'Body:',
	'LBL_BUGS_SUBPANEL_TITLE'	=> 'Fejl',
	'LBL_CC'					=> 'Cc:',
	'LBL_COLON'					=> ':',
	'LBL_COMPOSE_MODULE_NAME'	=> 'Skriv e-mail',
	'LBL_CONTACT_FIRST_NAME'	=> 'Kontakt fornavn',
	'LBL_CONTACT_LAST_NAME'		=> 'Kontakt efternavn',
	'LBL_CONTACT_NAME'			=> 'Kontakt:',
	'LBL_CONTACTS_SUBPANEL_TITLE'=> 'Kontakter',
	'LBL_CREATED_BY'			=> 'Oprettet af',
	'LBL_DATE_AND_TIME'			=> 'Dato & tid sendt:',
	'LBL_DATE_SENT'				=> 'Dato sendt:',
	'LBL_DATE'					=> 'Dato sendt:',
	'LBL_DESCRIPTION'			=> 'Beskrivelse',
	'LBL_EDIT_ALT_TEXT'			=> 'Rediger plan tekst',
	'LBL_EDIT_MY_SETTINGS'		=> '&AElig;ndre mine indstillinger. ',
	'LBL_EMAIL_ATTACHMENT'		=> 'E-mail vedh&aelig;ftning',
	'LBL_EMAIL_EDITOR_OPTION'	=> 'Send HTML e-mail',
	'LBL_EMAIL_SELECTOR'		=> 'V&aelig;lg',
	'LBL_EMAIL'					=> 'E-mail:',
	'LBL_EMAILS_ACCOUNTS_REL'	=> 'E-mails:Konti',
	'LBL_EMAILS_BUGS_REL'		=> 'E-mails:Fejl',
	'LBL_EMAILS_CASES_REL'		=> 'E-mails:Sager',
	'LBL_EMAILS_CONTACTS_REL'	=> 'E-mails:Kontakter',
	'LBL_EMAILS_LEADS_REL'		=> 'E-mails:Emner',
	'LBL_EMAILS_OPPORTUNITIES_REL'=> 'E-mails:Muligheder',
	'LBL_EMAILS_PROJECT_REL'	=> 'E-mails:Projekter',
	'LBL_EMAILS_PROJECTTASK_REL'=> 'E-mails:Projekt opgave',
	'LBL_EMAILS_PROSPECT_REL'	=> 'E-mails:Udsigt',
	'LBL_EMAILS_TASKS_REL'		=> 'E-mails:Opgaver',
	'LBL_EMAILS_USERS_REL'		=> 'E-mails:Brugere',
	'LBL_ERROR_SENDING_EMAIL'	=> 'Fejl ved afsendelse af e-mail',
	'LBL_FROM_NAME'				=> 'Fra navn',
	'LBL_FROM'					=> 'Fra:',
	'LBL_HTML_BODY'				=> 'HTML Body',
	'LBL_INVITEE'				=> 'Modtagere',
	'LBL_LEADS_SUBPANEL_TITLE'	=> 'Emner',
	'LBL_MESSAGE_SENT'			=> 'Meddelelse sendt',
	'LBL_MODIFIED_BY'			=> '&Aelig;ndret af',
	'LBL_MODULE_NAME_NEW'		=> 'Arkiver e-mail',
	'LBL_MODULE_NAME'			=> 'Alle e-mails',
	'LBL_MODULE_TITLE'			=> 'E-mails: ',
	'LBL_NEW_FORM_TITLE'		=> 'Arkiver e-mail',
	'LBL_NOT_SENT'				=> 'Afsendingsfejl',
	'LBL_NOTE_SEMICOLON'		=> 'Bem&aelig;rk: Brug semikolon til at adskille flere e-mail adresser.',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Muligheder',
	'LBL_PROJECT_SUBPANEL_TITLE'=> 'Projekter',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE'=> 'Projekt opgaver',
	'LBL_SAVE_AS_DRAFT_BUTTON_KEY'=> 'R',
	'LBL_SAVE_AS_DRAFT_BUTTON_LABEL'=> 'Gem udkast',
	'LBL_SAVE_AS_DRAFT_BUTTON_TITLE'=> 'Gem udkast [Alt+R]',
	'LBL_SEARCH_FORM_DRAFTS_TITLE'=> 'S&oslash;g i udkast',
	'LBL_SEARCH_FORM_SENT_TITLE'=> 'S&oslash;g i sendte e-mails',
	'LBL_SEARCH_FORM_TITLE'		=> 'S&oslash;g i e-mails',
	'LBL_SEND_ANYWAYS'			=> 'Denne e-mail har intet emne. Send/gem alligevel?',
	'LBL_SEND_BUTTON_KEY'		=> 'S',
	'LBL_SEND_BUTTON_LABEL'		=> 'Send',
	'LBL_SEND_BUTTON_TITLE'		=> 'Send [Alt+S]',
	'LBL_SEND'					=> 'SEND',
	'LBL_SENT_MODULE_NAME'		=> 'Sendte e-mails',
	'LBL_SHOW_ALT_TEXT'			=> 'Vis plan tekst',
	'LBL_SIGNATURE'				=> 'Signatur',
	'LBL_SUBJECT'				=> 'Emne:',
	'LBL_TEXT_BODY'				=> 'Tekst body',
	'LBL_TIME'					=> 'Afsendt:',
	'LBL_TO_ADDRS'				=> 'Til',
	'LBL_TO'					=> 'Til:',
	'LBL_USE_TEMPLATE'			=> 'Brug skabelon:',
	'LBL_USERS_SUBPANEL_TITLE'	=> 'Brugere',
	'LBL_USERS'					=> 'Brugere',

	'LNK_ALL_EMAIL_LIST'		=> 'Alle e-mails',
	'LNK_ARCHIVED_EMAIL_LIST'	=> 'Arkiverede e-mails',
	'LNK_CALL_LIST'				=> 'Opkald',
	'LNK_DRAFTS_EMAIL_LIST'		=> 'Alle udkast',
	'LNK_EMAIL_LIST'			=> 'E-mails',
	'LNK_EMAIL_TEMPLATE_LIST'	=> 'E-mail skabeloner',
	'LNK_MEETING_LIST'			=> 'M&oslash;der',
	'LNK_NEW_ARCHIVE_EMAIL'		=> 'Opret arkiveret e-mail',
	'LNK_NEW_CALL'				=> 'Skemal&aelig;g opkald',
	'LNK_NEW_EMAIL_TEMPLATE'	=> 'Opret e-mail skabelon',
	'LNK_NEW_EMAIL'				=> 'Arkiver e-mail',
	'LNK_NEW_MEETING'			=> 'Skemal&aelig;g m&oslash;de',
	'LNK_NEW_NOTE'				=> 'Opret note eller vedh&aelig;ftning',
	'LNK_NEW_SEND_EMAIL'		=> 'Skriv e-mail',
	'LNK_NEW_TASK'				=> 'Opret opgave',
	'LNK_NOTE_LIST'				=> 'Noter',
	'LNK_SENT_EMAIL_LIST'		=> 'Sendte e-mails',
	'LNK_TASK_LIST'				=> 'Opgaver',
	'LNK_VIEW_CALENDAR'			=> 'I dag',

	'LBL_LIST_ASSIGNED'			=> 'Tildelt',
	'LBL_LIST_CONTACT_NAME'		=> 'Kontaktnavn',
	'LBL_LIST_CONTACT'			=> 'Kontakt',
	'LBL_LIST_CREATED'			=> 'Oprettet',
	'LBL_LIST_DATE_SENT'		=> 'Afsendt',
	'LBL_LIST_DATE'				=> 'Afsendt',
	'LBL_LIST_FORM_DRAFTS_TITLE'=> 'Udkast',
	'LBL_LIST_FORM_SENT_TITLE'	=> 'Sendte e-mails',
	'LBL_LIST_FORM_TITLE'		=> 'E-mail liste',
	'LBL_LIST_FROM_ADDR'		=> 'Fra',
	'LBL_LIST_RELATED_TO'		=> 'Relateret til',
	'LBL_LIST_SUBJECT'			=> 'Emne',
	'LBL_LIST_TIME'				=> 'Afsendt',
	'LBL_LIST_TO_ADDR'			=> 'Til',
	'LBL_LIST_TYPE'				=> 'Type',

	'NTC_REMOVE_INVITEE'		=> 'Er du sikker p&aring; du vil fjerne denne modtager fra e-mailen?',
	'WARNING_SETTINGS_NOT_CONF'	=> 'Advarsel: Dine e-mail indstillinger er ikke konfigureret til at kunne sende e-mails.',
	'WARNING_NO_UPLOAD_DIR'		=> 'Vedh&aelig;ftninger kan risikere at fejle: Ingen v&aelig;rdi for "upload_tmp_dir" blev fundet.  Venligst ret dette i din php.ini fil.',
	'WARNING_UPLOAD_DIR_NOT_WRITABLE'	=> 'Vedh&aelig;ftninger kan risikere at fejle: En ugyldig v&aelig;rdi for "upload_tmp_dir" blev fundet.  Venligst ret dette i din php.ini fil.',

	// for InboundEmail
	'LBL_BUTTON_CHECK'			=> 'Tjek mail',
	'LBL_BUTTON_CHECK_TITLE'	=> 'Tjek for ny mail [Alt+C]',
	'LBL_BUTTON_CHECK_KEY'		=> 'c',
	'LBL_BUTTON_FORWARD'		=> 'Videresend',
	'LBL_BUTTON_FORWARD_TITLE'	=> 'Videresend denne e-mail [Alt+F]',
	'LBL_BUTTON_FORWARD_KEY'	=> 'f',
	'LBL_BUTTON_REPLY_KEY'		=> 'r',
	'LBL_BUTTON_REPLY_TITLE'	=> 'Besvar [Alt+R]',
	'LBL_BUTTON_REPLY'			=> 'Besvar',
	'LBL_CASES_SUBPANEL_TITLE'	=> 'Sager',
	'LBL_INBOUND_TITLE'			=> 'Indg&aring;ende e-mail',
	'LBL_INTENT'				=> 'Hensigt',
	'LBL_MESSAGE_ID'			=> 'Meddelelse ID',
	'LBL_REPLY_TO_ADDRESS'		=> 'Besvar-til adresse',
	'LBL_REPLY_TO_NAME'			=> 'Besvar-til navn',

	'LBL_LIST_BUG'				=> 'Fejl',
	'LBL_LIST_CASE'				=> 'Sager',
	'LBL_LIST_CONTACT'			=> 'Kontakter',
	'LBL_LIST_LEAD'				=> 'Emner',
	'LBL_LIST_TASK'				=> 'Opgaver',

	// for Inbox
	'LBL_ALL'					=> 'Alle',
	'LBL_ASSIGN_WARN'			=> 'Sikker at alle 3 muligheder er valgt.',
	'LBL_BACK_TO_GROUP'			=> 'Tilbage til gruppe indbakke',
	'LBL_BUTTON_DISTRIBUTE_KEY'	=> 'a',
	'LBL_BUTTON_DISTRIBUTE_TITLE'=> 'Tildel [Alt+A]',
	'LBL_BUTTON_DISTRIBUTE'		=> 'Tildel',
	'LBL_BUTTON_GRAB_KEY'		=> 't',
	'LBL_BUTTON_GRAB_TITLE'		=> 'Tag fra gruppe [Alt+T]',
	'LBL_BUTTON_GRAB'			=> 'Tag fra gruppe',
	'LBL_CREATE_BUG'			=> 'Opret fejlrapport',
	'LBL_CREATE_CASE'			=> 'Opret sag',
	'LBL_CREATE_CONTACT'		=> 'Opret kontakt',
	'LBL_CREATE_LEAD'			=> 'Opret emne',
	'LBL_CREATE_TASK'			=> 'Opret opgave',
	'LBL_DIST_TITLE'			=> 'Opgave',
	'LBL_LOCK_FAIL_DESC'		=> 'Det valgte elemenet er p&aring; nuv&aelig;rende tidspunkt ikke tilg&aelig;ngeligt.',
	'LBL_LOCK_FAIL_USER'		=> ' har taget ejerskab.',
	'LBL_MASS_DELETE_ERROR'		=> 'Ingen afkrydsede elementer blev godkendt til sletning.',
	'LBL_NEW'					=> 'nye',
	'LBL_NEXT_EMAIL'			=> 'N&aelig;ste e-mail',
	'LBL_NO_GRAB_DESC'			=> 'Der var ingen elementer tilg&aelig;ngelige. Pr&oslash;v igen om et &oslash;jeblik.',
	'LBL_QUICK_REPLY'			=> 'Besvar',
	'LBL_REPLIED'				=> 'Besvaret',
	'LBL_SELECT_TEAM'			=> 'V&aelig;lg hold',
	'LBL_TAKE_ONE_TITLE'		=> 'Reps',
	'LBL_TITLE_SEARCH_RESULTS'	=> 'Resultater af s&oslash;gning',
	'LBL_TO'					=> 'Til: ',
	'LBL_TOGGLE_ALL'			=> 'Skift alle',
	'LBL_UNKNOWN'				=> 'Ukendt',
	'LBL_UNREAD_HOME'			=> 'Ul&aelig;ste e-mails',
	'LBL_UNREAD'				=> 'Ul&aelig;st',
	'LBL_USE_ALL'				=> 'Alle resultater af s&oslash;gning',
	'LBL_USE_CHECKED'			=> 'Kun afkrydsede',
	'LBL_USE_MAILBOX_INFO'		=> 'Brug mailboks fra: Adresse',
	'LBL_USE'					=> 'Tildel:',
	'LBL_USER_SELECT'			=> 'V&aelig;lg brugere',
	'LBL_USING_RULES'			=> 'Regler i brug:',
	'LBL_WARN_NO_DIST'			=> 'Ingen distributionsmetode valgt',
	'LBL_WARN_NO_USERS'			=> 'Ingen brugere er valgt',

	'LBL_LIST_STATUS'			=> 'Status',
	'LBL_LIST_TITLE_GROUP_INBOX'=> 'Gruppe indbakke',
	'LBL_LIST_TITLE_MY_DRAFTS'	=> 'Mine udkast',
	'LBL_LIST_TITLE_MY_INBOX'	=> 'Min indbakke',
	'LBL_LIST_TITLE_MY_SENT'	=> 'Mine sendte',
	'LBL_LIST_TITLE_MY_ARCHIVES'=> 'Mine arkiverede',

	'LNK_CHECK_MY_INBOX'		=> 'Tjek min mail',
	'LNK_DATE_SENT'				=> 'Afsendt',
	'LNK_GROUP_INBOX'			=> 'Gruppe indbakke',
	'LNK_MY_DRAFTS'				=> 'Mine udkast',
	'LNK_MY_INBOX'				=> 'Min indbakke',
	'LNK_QUICK_REPLY'			=> 'Besvar',
	'LNK_MY_ARCHIVED_LIST'		=> 'Mine arkiverede',

	// advanced search
	'LBL_ASSIGNED_TO'			=> 'Tildelt til:',
	'LBL_MEMBER_OF'				=> 'For&aelig;ldre',
	'LBL_QUICK_CREATE'			=> 'Hurtigoprettelse',
	'LBL_STATUS'				=> 'E-mail status:',
	'LBL_TYPE'					=> 'Type:',
);
?>
