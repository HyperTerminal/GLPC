<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.34 2006/03/08 00:35:39 chris Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Ny kontakt',
  'LBL_FIRST_NAME' => 'Fornavn:',
  'LBL_LAST_NAME' => 'Efternavn:',
  'LBL_LIST_LAST_NAME' => 'Efternavn',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL_ADDRESS' => 'E-mail:',
  'LBL_PIPELINE_FORM_TITLE' => 'Min pipeline',
  'LNK_NEW_CONTACT' => 'Opret kontakt',
  'LNK_NEW_ACCOUNT' => 'Opret konto',
  'LNK_NEW_OPPORTUNITY' => 'Opret mulighed',



  'LNK_NEW_LEAD' => 'Opret emne',
  'LNK_NEW_CASE' => 'Opret sag',
  'LNK_NEW_NOTE' => 'Opret note eller vedh&aelig;ftning',
  'LNK_NEW_CALL' => 'Skemal&aelig;g opkald',
  'LNK_NEW_EMAIL' => 'Arkiver e-mail',
  'LNK_COMPOSE_EMAIL' => 'Skriv e-mail',
  'LNK_NEW_MEETING' => 'Skemal&aelig;g m&oslash;de',
  'LNK_NEW_TASK' => 'Opret opgave',
  'LNK_NEW_BUG' => 'Rapporter fejl',
  'LBL_ADD_BUSINESSCARD' => 'Indtast visitkort',
  'ERR_ONE_CHAR' => 'Venligst indtast mindst et bogstav eller tal i din s&oslash;gning ...',
  'LBL_OPEN_TASKS' => 'Mine &aring;bne opgaver',
  'LBL_SEARCH_RESULTS' => 'Resultater af s&oslash;gning',
  'LNK_NEW_SEND_EMAIL' => 'Skriv e-mail',
);


?>
