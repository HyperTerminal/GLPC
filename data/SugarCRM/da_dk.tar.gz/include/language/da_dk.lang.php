<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: en_us.lang.php,v 1.307.2.1 2006/05/04 23:43:03 wayne Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'language_pack_name' => 'DK Dansk',
  'moduleList' =>
  array (
    'Home' => 'Hjem',
    'Dashboard' => 'Dashboard',
    'Contacts' => 'Kontakter',
    'Accounts' => 'Konti',
    'Opportunities' => 'Muligheder',
    'Cases' => 'Sager',
    'Notes' => 'Noter',
    'Calls' => 'Opkald',
    'Emails' => 'Post',
    'Meetings' => 'M&oslash;der',
    'Tasks' => 'Opgaver',
    'Calendar' => 'Kalender',
    'Leads' => 'Emner',








    'Activities' => 'Aktiviteter',
    'Bugs' => 'Fejlrapportering',
    'Feeds' => 'RSS',
    'iFrames'=>'Min portal',
    'TimePeriods'=>'Tidszoner',
    'Project'=>'Projekter',
    'ProjectTask'=>'Projekt opgaver',
    'Campaigns'=>'Kampagner',
    'Documents'=>'Dokumenter',
    'Sync'=>'Synkronisering',






    'Users' => 'Brugere',
    'Releases' => 'Udgivelser',    
    'Prospects' => 'Udsigter',
    'Queues' => 'Gennemgangsr&aelig;kkef&oslash;lge',
    'EmailMarketing' => 'Email-markedsf&oslash;ring',
    'EmailTemplates' => 'Email-skabeloner',
    'ProspectLists' => 'Udsigtsliste',
        ),
  'moduleListSingular' =>
  array (
    'Home' => 'Hjem',
    'Dashboard' => 'Dashboard',
    'Contacts' => 'Kontakt',
    'Accounts' => 'Konti',
    'Opportunities' => 'Mulighed',
    'Cases' => 'Sag',
    'Notes' => 'Notat',
    'Calls' => 'Opkald',
    'Emails' => 'E-mail',
    'Meetings' => 'M&oslash;de',
    'Tasks' => 'Opgave',
    'Calendar' => 'Kalender',
    'Leads' => 'Emne',







    'Activities' => 'Aktivitet',
    'Bugs' => 'Fejlrapportering',
    'Feeds' => 'RSS',
    'iFrames'=>'Min portal',
    'TimePeriods'=>'Tidzone',
    'Project'=>'Projekt',
    'ProjectTask'=>'Projekt opgave',
    'Campaigns'=>'Kampagner',
    'Documents'=>'Dokument',
    'Sync'=>'Synkroniser',






    'Users' => 'Bruger'
        ),        

  'checkbox_dom'=> array(
  	''=>'',
  	'1'=>'Ja',
  	'2'=>'Nej',
  ),
          
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' =>
  array (
    '' => '',
    'Analyst' => 'Analyst',
    'Competitor' => 'Konkurrent',
    'Customer' => 'Kunde',
    'Integrator' => 'Integrator',
    'Investor' => 'Investor',
    'Partner' => 'Partner',
    'Press' => 'Presse',
    'Prospect' => 'Udsigt',
    'Reseller' => 'Forhandler',
    'Other' => 'Andre',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' =>
  array (
    '' => '',
    'Apparel' => 'Bekl&aelig;dning',
    'Banking' => 'Bank',
    'Biotechnology' => 'Bioteknologi',
    'Chemicals' => 'Kemikalier',
    'Communications' => 'Kommunikation',
    'Construction' => 'Konstruktion',
    'Consulting' => 'Konsulent',
    'Education' => 'Uddannelse',
    'Electronics' => 'Elektronik',
    'Energy' => 'Energi',
    'Engineering' => 'Ingeni&oslash;r',
    'Entertainment' => 'Underholdning',
    'Environmental' => 'Milj&oslash;',
    'Finance' => 'Finans',
    'Government' => 'Regering',
    'Healthcare' => 'Sundhed',
    'Hospitality' => 'Restaurent/Hotel',
    'Insurance' => 'Forsikring',
    'Machinery' => 'Maskinel',
    'Manufacturing' => 'Produktion',
    'Media' => 'Medie',
    'Not For Profit' => 'Nonprofit',
    'Recreation' => 'Rekreation',
    'Retail' => 'Forhandler',
    'Shipping' => 'Logistik',
    'Technology' => 'Teknologi',
    'Telecommunications' => 'Telekommunikation',
    'Transportation' => 'Transport',
    'Utilities' => 'Almennyttigt foretagende',
    'Other' => 'Andre',
  ),
  'source_default_key' => 'Selvgennereret',
  'lead_source_dom' =>
  array (
    '' => '',
    'Cold Call' => 'Koldt opkald',
    'Existing Customer' => 'Eksisterende kunde',
    'Self Generated' => 'Selvgennereret',
    'Employee' => 'Ansat',
    'Partner' => 'Partner',
    'Public Relations' => 'Public Relations',
    'Direct Mail' => 'Direct Mail',
    'Conference' => 'Konference',
    'Trade Show' => 'Handelsmesse',
    'Web Site' => 'Hjemmeside',
    'Word of mouth' => 'Mund-til-mund',
    'Email' => 'E-mail',
    'Other' => 'Andre',
  ),
  'opportunity_type_dom' =>
  array (
    '' => '',
    'Existing Business' => 'Eksisterende foretagende',
    'New Business' => 'Nyt foretagende',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim&aelig;r beslutningstager',
    'Business Decision Maker' => 'Forretnings beslutningstager',
    'Business Evaluator' => 'Forretnings evaluator',
    'Technical Decision Maker' => 'Teknisk beslutningstager',
    'Technical Evaluator' => 'Teknisk evaluator',
    'Executive Sponsor' => 'Executive sponsor',
    'Influencer' => 'Influenter',
    'Other' => 'Andre',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Contact' => 'Prim&aelig;r kontakt',
    'Alternate Contact' => 'Alternativ kontakt',
  ),
  'payment_terms' =>
  array (
  	'' => '', 
	'Net 15' => 'Netto 15 dage',
	'Net 30' => 'Netto 30 dage',
  ),  
  'sales_stage_default_key' => 'Prospecting',
  'sales_stage_dom' =>
  array (
    'Prospecting' => 'M&aring;ls&aelig;ttelse',
    'Qualification' => 'Kvalifikation',
    'Needs Analysis' => 'Analyser n&oslash;dvendig',
    'Value Proposition' => 'V&aelig;rdifuldt forslag',
    'Id. Decision Makers' => 'Id. Beslutningstagere',
    'Perception Analysis' => 'Opfattelsesanalyser',
    'Proposal/Price Quote' => 'Forslag/Prisforesp&oslash;rgelse',
    'Negotiation/Review' => 'Forhandling/Overblik',
    'Closed Won' => 'Afsluttet gevinst',
    'Closed Lost' => 'Afsluttet tab',
  ),
  'sales_probability_dom' => // keys must be the same as sales_stage_dom
  array (
    'Prospecting' => '10',
    'Qualification' => '20',
    'Needs Analysis' => '25',
    'Value Proposition' => '30',
    'Id. Decision Makers' => '40',
    'Perception Analysis' => '50',
    'Proposal/Price Quote' => '65',
    'Negotiation/Review' => '80',
    'Closed Won' => '100',
    'Closed Lost' => '0',
  ),
  'activity_dom' =>
  array (
    'Call' => 'Opkald',
    'Meeting' => 'M&oslash;de',
    'Task' => 'Opgave',
    'Email' => 'E-mail',
    'Note' => 'Notat',
  ),
  'salutation_dom' =>
  array (
    '' => '',
    'Mr.' => 'Hr.',
    'Ms.' => 'Fr.',
    'Mrs.' => 'Fr.',
    'Dr.' => 'Dr.',
    'Prof.' => 'PhD.',
  ),
  //time is in seconds; the greater the time the longer it takes;
  'reminder_max_time'=>3600,
  'reminder_time_options' => array( 60=> '1 minut f&oslash;r',
  								  300=> '5 minutter f&oslash;r',
  								  600=> '10 minutter f&oslash;r',
  								  900=> '15 minutter f&oslash;r',
  								  1800=> '30 minutter f&oslash;r',
  								  3600=> '1 time f&oslash;r',
								 ),

  'task_priority_default' => 'Medium',
  'task_priority_dom' =>
  array (
    'High' => 'H&oslash;j',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
  'task_status_default' => 'Ikke startet',
  'task_status_dom' =>
  array (
    'Not Started' => 'Ikke startet',
    'In Progress' => 'Under behandling',
    'Completed' => 'Fuldf&oslash;rt',
    'Pending Input' => 'Venter p&aring; input',
    'Deferred' => 'Udskudt',
  ),
  'meeting_status_default' => 'Planlagt',
  'meeting_status_dom' =>
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Afholdt',
    'Not Held' => 'Ikke afholdt',
  ),
  'call_status_default' => 'Planlagt',
  'call_status_dom' =>
  array (
    'Planned' => 'Planlagt',
    'Held' => 'Afholdt',
    'Not Held' => 'Ikke afholdt',
  ),
  'call_direction_default' => 'Ud af huset',
  'call_direction_dom' =>
  array (
    'Inbound' => 'Internt',
    'Outbound' => 'Ud af huset',
  ),
  'lead_status_dom' =>
  array (
    '' => '',
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'In Process' => 'Iganv&aelig;rende',
    'Converted' => 'Konverteret',
    'Recycled' => 'Genbrugt',
    'Dead' => 'D&oslash;dt',
  ),
  'lead_status_noblank_dom' =>
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'In Process' => 'Igangv&aelig;rende',
    'Converted' => 'Konverteret',
    'Recycled' => 'Genbrugt',
    'Dead' => 'D&oslash;dt',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'Ny',
  'case_status_dom' =>
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'Closed' => 'Afsluttet',
    'Pending Input' => 'Venter p&aring; input',
    'Rejected' => 'Afvist',
    'Duplicate' => 'Duplikat',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' =>
  array (
    'P1' => 'H&oslash;j',
    'P2' => 'Medium',
    'P3' => 'Lav',
  ),
  'user_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Inactive' => 'Ikke aktiv',
  ),
  'employee_status_dom' =>
  array (
    'Active' => 'Aktiv',
    'Terminated' => 'Afskediget',
    'Leave of Absence' => 'Orlov',
  ),
  'messenger_type_dom' =>
  array (
    'MSN' => 'MSN',
    'Yahoo!' => 'Yahoo!',
    'AOL' => 'AOL',
  ),

	'project_task_priority_options' => array (
		'High' => 'H&oslash;j',
		'Medium' => 'Medium',
		'Low' => 'Lav',
	),
	'project_task_status_options' => array (
		'Not Started' => 'Ikke startet',
		'In Progress' => 'Under behandling',
		'Completed' => 'Afsluttet',
		'Pending Input' => 'Venter p&aring; input',
		'Deferred' => 'Afvist',
	),
	'project_task_utilization_options' => array (
		'0' => 'ingen',
		'25' => '25',
		'50' => '50',
		'75' => '75',
		'100' => '100',
	),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' =>
  array (
    'Accounts' => 'Konti',
    'Opportunities' => 'Mulighed',
    'Cases' => 'Sag',
    'Leads' => 'Emne',
    'Contacts' => 'Kontakter', // cn (11/22/2005) added to support Emails




    'Bugs' => 'Fejl',
    'Project' => 'Projekter',
    'ProjectTask' => 'Projekt opgave',
    'Tasks' => 'Opgave',
  ),

  'record_type_display_notes' =>
  array (
    'Accounts' => 'Konti',
	'Contacts' => 'Kontakt',
    'Opportunities' => 'Mulighed',
    'Cases' => 'Sag',
    'Leads' => 'Emne',






    'Bugs' => 'Fejl',
    'Emails' => 'E-mail',
    'Project' => 'Projekt',
    'ProjectTask' => 'Projekt opgave',
    'Meetings' => 'M&oslash;de',
    'Calls' => 'Opkald'
  ),






































	
  'quote_type_dom' =>
  array (
    'Quotes' => 'Tilbud',
    'Orders' => 'Ordre',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' =>
  array (
    'Draft' => 'Udkast',
    'Negotiation' => 'Forhandling',
    'Delivered' => 'Afleveret',
    'On Hold' => 'Sat i bero',
    'Confirmed' => 'Bekr&aelig;ftet',
    'Closed Accepted' => 'Afsluttet med accept',
    'Closed Lost' => 'Afsluttet tab',
    'Closed Dead' => 'Afsluttet d&oslash;dt',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' =>
  array (
    'Pending' => 'Afventer',
    'Confirmed' => 'Bekr&aelig;ftet',
    'On Hold' => 'Sat i bero',
    'Shipped' => 'Afsendt',
    'Cancelled' => 'Annulleret',
  ),

//Note:  do not translate quote_relationship_type_default_key
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Prim&aelig;r beslutningstager',
    'Business Decision Maker' => 'Forretnings beslutningstager',
    'Business Evaluator' => 'Forretnings evaluator',
    'Technical Decision Maker' => 'Teknisk beslutningstager',
    'Technical Evaluator' => 'Teknisk evaluator',
    'Executive Sponsor' => 'Executive sponsor',
    'Influencer' => 'Influenter',
    'Other' => 'Andre',
  ),
  'layouts_dom' =>
  array (
    'Standard' => 'Foreslag/Tilbud',
    'Invoice' => 'Faktura',
    'Terms' => 'Betalingsbetingelser'
  ),

  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' =>
  array (
    'Urgent' => 'Haster',
    'High' => 'H&oslash;j',
    'Medium' => 'Medium',
    'Low' => 'Lav',
  ),
   'bug_resolution_default_key' => '',
  'bug_resolution_dom' =>
  array (
  	'' => '',
  	'Accepted' => 'Accepteret',
    'Duplicate' => 'Duplikat',
    'Fixed' => 'Ordnet',
    'Out of Date' => 'Uddateret',
    'Invalid' => 'Ugydlig',
    'Later' => 'Senere',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' =>
  array (
    'New' => 'Ny',
    'Assigned' => 'Tildelt',
    'Closed' => 'Afsluttet',
    'Pending' => 'Afventer',
    'Rejected' => 'Afvist',
  ),
   'bug_type_default_key' => 'Fejl',
  'bug_type_dom' =>
  array (
    'Defect' => 'Defekt',
    'Feature' => 'Feature',
  ),

  'source_default_key' => '',
  'source_dom' =>
  array (
	'' => '',
  	'Internal' => 'Intern',
  	'Forum' => 'Forum',
  	'Web' => 'Web',
  	'InboundEmail' => 'E-mail'
  ),

  'product_category_default_key' => '',
  'product_category_dom' =>
  array (
	'' => '',
  	'Accounts' => 'Konti',
  	'Activities' => 'Aktiviteter',
  	'Bug Tracker' => 'Fejlrapportering',
  	'Calendar' => 'Kalender',
  	'Calls' => 'Opkald',
  	'Campaigns' => 'Kampagner',  	
  	'Cases' => 'Sager',
  	'Contacts' => 'Kontakter',
  	'Currencies' => 'Valutaer',
  	'Dashboard' => 'Dashboard',
  	'Documents' => 'Dokumenter',
  	'Emails' => 'Post',
  	'Feeds' => 'Nyheder',
  	'Forecasts' => 'Forudsigelser',  	
  	'Help' => 'Hj&aelig;lp',
  	'Home' => 'Hjem',
  	'Leads' => 'Emner',
  	'Meetings' => 'M&oslash;der',
  	'Notes' => 'Noter',
  	'Opportunities' => 'Muligheder',
  	'Outlook Plugin' => 'Outlook plugin',
  	'Product Catalog' => 'Produktkatalog',  	
  	'Products' => 'Produkter',  	
  	'Projects' => 'Projekter',  	
  	'Quotes' => 'Tilbud',
  	'Releases' => 'Udgivelser',
  	'RSS' => 'RSS',
  	'Studio' => 'Studio',
  	'Upgrade' => 'Opgradering',
  	'Users' => 'Brugere',
  ),

  /*Added entries 'Queued' and 'Sending' for 4.0 release..*/
  'campaign_status_dom' =>
  array (
    	'' => '',
        'Planning' => 'Planl&aelig;gning',
        'Active' => 'Aktiv',
        'Inactive' => 'Ikke aktiv',
        'Complete' => 'F&aelig;rdiggjort',
        'In Queue' => 'I k&oslash;',
        'Sending'=> 'Afsender',
  ),
  'campaign_type_dom' =>
  array (
        '' => '',
        'Telesales' => 'Telefonsalg',
        'Mail' => 'Brevpost',
        'Email' => 'E-mail',
        'Print' => 'Print',
        'Web' => 'Web',
        'Radio' => 'Radio',
        'Television' => 'TV',
        ),



  'notifymail_sendtype' =>
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => array('-12'=>'(GMT - 12) International Date Line West',
  							'-11'=>'(GMT - 11) Midway Island, Samoa',
  							'-10'=>'(GMT - 10) Hawaii',
  							'-9'=>'(GMT - 9) Alaska',
  							'-8'=>'(GMT - 8) San Francisco',
  							'-7'=>'(GMT - 7) Phoenix',
  							'-6'=>'(GMT - 6) Saskatchewan',
  							'-5'=>'(GMT - 5) New York',
  							'-4'=>'(GMT - 4) Santiago',
  							'-3'=>'(GMT - 3) Buenos Aires',
  							'-2'=>'(GMT - 2) Mid-Atlantic',
  							'-1'=>'(GMT - 1) Azores',
  							'0'=>'(GMT)',
  							'1'=>'(GMT + 1) Madrid',
  							'2'=>'(GMT + 2) Athens',
  							'3'=>'(GMT + 3) Moscow',
  							'4'=>'(GMT + 4) Kabul',
  							'5'=>'(GMT + 5) Ekaterinburg',
  							'6'=>'(GMT + 6) Astana',
  							'7'=>'(GMT + 7) Bangkok',
  							'8'=>'(GMT + 8) Perth',
  							'9'=>'(GMT + 9) Seol',
  							'10'=>'(GMT + 10) Brisbane',
  							'11'=>'(GMT + 11) Solomone Is.',
  							'12'=>'(GMT + 12) Auckland',
  							),
      'dom_cal_month_long'=>array(
                '0'=>"",
                '1'=>"januar",
                '2'=>"februar",
                '3'=>"marts",
                '4'=>"april",
                '5'=>"maj",
                '6'=>"juni",
                '7'=>"juli",
                '8'=>"august",
                '9'=>"september",
                '10'=>"oktober",
                '11'=>"november",
                '12'=>"december",
        ),

        'dom_report_types'=>array(
                'tabular'=>'R&aelig;kker og kolonner',
                'summary'=>'Opsummering',
                'detailed_summary'=>'Detaljeret opsummering',
        ),
	'dom_email_types'=> array(
		'out'		=> 'Afsendt',
		'archived'	=> 'Arkiveret',
		'draft'		=> 'Udkast',
		'inbound'	=> 'Interne',
	),
	'dom_email_status' => array (
		'archived'	=> 'Arkiveret',
		'closed'	=> 'Afsluttet',
		'draft'		=> 'I udkast',
		'read'		=> 'L&aelig;st',
		'replied'	=> 'Besvaret',
		'sent'		=> 'Afsendt',
		'send_error'=> 'Afsendingsfejl',
		'unread'	=> 'Ikke l&aelig;st',
	),
		
	'dom_email_server_type' => array(	''			=> '--Ingen--',
										'imap'		=> 'IMAP',
										'pop3'		=> 'POP3',
	),
	'dom_mailbox_type'		=> array(/*''			=> '--None Specified--',*/
									 'pick'		=> 'Opret [v&aelig;lg]',
									 'bug'		=> 'Opret fejl',
					 				 'support'	=> 'Opret sag',
					 				 'contact'  => 'Opret kontakt',
					 				 'sales'	=> 'Opret emne',
					 				 'task'		=> 'Opret opgave',
					 				 'bounce'	=> 'Annuller ekspedition',
	),
	'dom_email_distribution'=> array(''				=> '--Ingen--',
									 'direct'		=> 'Direkte delegering',
									 'roundRobin'	=> 'Rundsending',
									 'leastBusy'	=> 'Mindst travle',
	),
	'dom_email_errors'		=> array(1 => 'V&aelig;lg kun en bruger n&aring; du har valgt direkte delegering.',
									 2 => 'Du skal v&aelig;lge Kun Valgte Elementer ved direkte delegering.',
	),
	'dom_email_bool'		=> array('bool_true' => 'Ja',
								 	 'bool_false' => 'Nej',
	),
	'dom_int_bool'			=> array(1 => 'Ja',
								 	 0 => 'Nej',
	),
	'dom_switch_bool'		=> array ('on' => 'Ja',
										'off' => 'Nej',
										'' => 'Nej', ),
	'dom_email_link_type'	=> array(	''			=> 'Standard e-mail klient',
										'sugar'		=> 'SugarCRM e-mail klient',
										'mailto'	=> 'Ekstern e-mail klient'),

	'dom_email_editor_option'=> array(	''			=> 'Standard e-mail format',
										'html'		=> 'HTML e-mail',
										'plain'		=> 'Plan tekst e-mail'),

	
	'schedulers_times_dom'	=> array(	'ikke k&oslash;rt'		=> 'Efter k&oslash;rselstidspunkt, ikke eksekveret',
										'ready'			=> 'Klar',
										'in progress'	=> 'Under behandling',
										'failed'		=> 'Fejlet',
										'completed'		=> 'F&aelig;rdig',
										'no curl'		=> 'Ikke k&oslash;rt: Ingen cURL tilg&aelig;ngelig',
	),

	'forecast_schedule_status_dom' =>
  	array (
    'Active' => 'Aktiv',
    'Inactive' => 'Ikke aktiv',
  ),
	'forecast_type_dom' =>
  	array (
    'Direct' => 'Direkte',
    'Rollup' => 'Tilbagevending',
  ),  
	
	'document_category_dom' =>
  	array (
  	'' => '',
    'Marketing' => 'Markedsf&oslash;ring',
    'Knowledege Base' => 'VIdensbase',
    'Sales' => 'Salg',    
  ),  

	'document_subcategory_dom' =>
  	array (
  	'' => '',
    'Marketing Collateral' => 'Markedsf&oslash;ring oprindelse',
    'Product Brochures' => 'Produktbrochure',
	'FAQ' => 'FAQ',
  ),  
  
	'document_status_dom' =>
  	array (
    'Active' => 'Aktiv',
    'Draft' => 'Udkast',
	'FAQ' => 'FAQ',
	'Expired' => 'Udl&oslash;bet',
	'Under Review' => 'Under gennemsyn',
	'Pending' => 'Afventer',
  ),
  'document_template_type_dom' =>
  array(
  	''=>'',
  	'mailmerge'=>'E-mail sammensmeltning',
  	'eula'=>'EULA',
  	'nda'=>'NDA',
  	'license'=>'Licensaftale',
  ),
	'dom_meeting_accept_options' =>
  	array (
	'accept' => 'Accepter',
	'decline' => 'Afvis',
	'tentative' => 'Afventer',
  ),
	'dom_meeting_accept_status' =>
  	array (
	'accept' => 'Accepteret',
	'decline' => 'Afvist',
	'tentative' => 'Afventer',
	'none'		=> 'Ingen',
  ),




















































































































































































































































































































































































































// deferred
/*// QUEUES MODULE DOMs
'queue_type_dom' => array(
	'Users' => 'Users',



	'Mailbox' => 'Mailbox',
),		   
*/

//prospect list type dom
  'prospect_list_type_dom' =>
  array (
    'default' => 'Standard',
    'seed' => 'Fr&oslash;',
    'exempt_domain' => 'Udelukkelsesliste - Pr. dom&aelig;ne',
    'exempt_address' => 'Udelukkelsesliste - Pr. e-mail adresse',
    'exempt' => 'Udelukkelsesliste - Pr. id',
    'test' => 'Test',
  ),
  
  'email_marketing_status_dom' => 
  array (
  	'' => '',
  	'active'=>'Aktiv',
  	'inactive'=>'Ikke aktiv'
  ),

  'campainglog_activity_type_dom' =>
  array (
  	''=>'',
    'targeted' => 'Besked sendt/Fors&oslash;gt',
    'send error'=>'Fejl under afsending,Andet',
    'invalid email'=>'Fejl under afsending,Ugyldig e-mail adresse',
    'link'=>'Click-thru Link',
    'viewed'=>'Viste meddelelse',
    'removed'=>'Fravalgt',
    'lead'=>'Emner oprettet',
    'contact'=>'Kontakter oprettet',        
  ),

  'campainglog_target_type_dom' =>
  array (
    'Contacts' => 'Kontakter',
    'Users'=>'Brugere',
    'Prospects'=>'Udsigt',
    'Leads'=>'Emner',
  ),



































);

$app_strings = array (





	










	
	'ERR_CREATING_FIELDS' => 'Fejl ved ved udfyldning af ekstra-detalje felterne: ',
	'ERR_CREATING_TABLE' => 'Fejl ved oprettelse af tabel: ',
	'ERR_DELETE_RECORD' => 'Et identificeringsnummer skal angives for at slette kontakten.',
	'ERR_INVALID_AMOUNT' => 'Venligst angiv en gyldig m&aelig;ngde.',
	'ERR_INVALID_DATE_FORMAT' => 'Datoformatet skal v&aelig;re: ',
	'ERR_INVALID_DATE' => 'Venligst angiv en gyldig dato.',
	'ERR_INVALID_DAY' => 'Venligst angiv en gyldig dag.',
	'ERR_INVALID_EMAIL_ADDRESS' => 'ikke en gyldig e-mail adresse.',
	'ERR_INVALID_HOUR' => 'Venligst angiv en gyldig time.',
	'ERR_INVALID_MONTH' => 'Venligst angiv en gyldig m&aring;ned.',
	'ERR_INVALID_TIME' => 'Venligst angiv en gyldig tid.',
	'ERR_INVALID_YEAR' => 'Venligst angiv et gyldigt &aring;rstal (4 cifret).',
	'ERR_MISSING_REQUIRED_FIELDS' => 'Manglende p&aring;kr&aelig;vede felter:',
	'ERR_INVALID_VALUE' => 'Ugyldig v&aelig;rdi:',
	'ERR_NOTHING_SELECTED' =>'Venligst foretag et valg f&oslash;r du forts&aelig;tter.',
	'ERR_OPPORTUNITY_NAME_DUPE' => 'En mulighed med navnet %s eksisterer allerede. Venligst angiv et nyt navn nedenfor.',
	'ERR_OPPORTUNITY_NAME_MISSING' => 'Der blev ikke angivet et navn til muligheden. Venligst indtast et navn nedenfor.',
	'ERR_SELF_REPORTING' => 'En bruger kan ikke rapportere til den selv.',
	'ERR_SQS_NO_MATCH_FIELD' => 'Intet match for felt: ',
	'ERR_SQS_NO_MATCH' =>'Intet match',
	
	'LBL_ACCOUNT'=>'Konto',
	'LBL_ACCOUNTS'=>'Konti',
	'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
	'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Vis oversigt',
	'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'Vis oversigt [Alt+H]',
	'LBL_ADD_BUTTON_KEY' => 'A',
	'LBL_ADD_BUTTON_TITLE' => 'Tilf&oslash;j [Alt+A]',
	'LBL_ADD_BUTTON' => 'Tilf&oslash;j',
	'LBL_ADD_DOCUMENT' => 'Tilf&oslash;j dokument',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'Tilf&oslash;j til m&aring;lliste',
	'LBL_ADD_TO_PROSPECT_LIST_BUTTON_TITLE' => 'Tilf&oslash;j til m&aring;lliste',
	'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'Klik for at lukke',
	'LBL_ADDITIONAL_DETAILS_CLOSE' => 'Luk',
	'LBL_ADDITIONAL_DETAILS' => 'Ekstra detaljer',
	'LBL_ADMIN' => 'Admin',
	'LBL_ALT_HOT_KEY' => 'Alt+',
	'LBL_ARCHIVE' => 'Arkiver',
	'LBL_ASSIGNED_TO_USER'=>'Tildelt til bruger',
	'LBL_ASSIGNED_TO' => 'Tildelt til:',
	'LBL_BACK' => 'Tilbage',
	'LBL_BILL_TO_ACCOUNT'=>'Tildel regning til konto',
	'LBL_BILL_TO_CONTACT'=>'Tildel regning til kontakt',
	'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
	'LBL_BUGS'=>'Fejl',
	'LBL_BY' => 'af',
	'LBL_CALLS'=>'Opkald',
	'LBL_CAMPAIGNS_SEND_QUEUED' => 'Afsend ventende kampagne e-mails',
	'LBL_CANCEL_BUTTON_KEY' => 'X',
	'LBL_CANCEL_BUTTON_LABEL' => 'Annuller',
	'LBL_CANCEL_BUTTON_TITLE' => 'Annuller [Alt+X]',
	'LBL_CASE'=>'Sag',
	'LBL_CASES'=>'Sager',
	'LBL_CHANGE_BUTTON_KEY' => 'G',
	'LBL_CHANGE_BUTTON_LABEL' => '&AElig;ndre',
	'LBL_CHANGE_BUTTON_TITLE' => '&AElig;ndre [Alt+G]',
	'LBL_CHARSET' => 'ISO-8859-1',
	'LBL_CHECKALL' => 'Afkryds alle',
	'LBL_CLEAR_BUTTON_KEY' => 'C',
	'LBL_CLEAR_BUTTON_LABEL' => 'Ryd',
	'LBL_CLEAR_BUTTON_TITLE' => 'Ryd [Alt+C]',
	'LBL_CLEARALL' => 'Ryd alle',
	'LBL_CLOSE_WINDOW'=>'Luk vindue',
	'LBL_CLOSEALL_BUTTON_KEY' => 'Q',
	'LBL_CLOSEALL_BUTTON_LABEL' => 'Luk alle',
	'LBL_CLOSEALL_BUTTON_TITLE' => 'Luk alle [Alt+I]',
	'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
	'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Skriv e-mail',
	'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Skriv e-mail [Alt+L]',
	'LBL_CONTACT_LIST' => 'Kontaktliste',
	'LBL_CONTACT'=>'Kontakt',
	'LBL_CONTACTS'=>'Kontakter',
	'LBL_CREATE_BUTTON_LABEL' => 'Opret',
	'LBL_CREATED_BY_USER'=>'Oprettet af bruger',
	'LBL_CREATED' => 'Oprettet af',
	'LBL_CURRENT_USER_FILTER' => 'Kun mine indl&aelig;g:',
	'LBL_DATE_ENTERED' => 'Oprettet d.:',
	'LBL_DATE_MODIFIED' => '&AElig;ndret d.:',
	'LBL_DELETE_BUTTON_KEY' => 'D',
	'LBL_DELETE_BUTTON_LABEL' => 'Slet',
	'LBL_DELETE_BUTTON_TITLE' => 'Slet [Alt+D]',
	'LBL_DELETE_BUTTON' => 'Slet',
	'LBL_DELETE' => 'Slet',
	'LBL_DELETED'=>'Slettet',
	'LBL_DIRECT_REPORTS'=>'Direkte rapporter',
	'LBL_DONE_BUTTON_KEY' => 'X',
	'LBL_DONE_BUTTON_LABEL' => 'F&aelig;rdig',
	'LBL_DONE_BUTTON_TITLE' => 'F&aelig;rdig [Alt+X]',
	'LBL_DST_NEEDS_FIXIN' => 'Programmet kr&aelig;ver et Daylight Saving Time fix.  Venligst g&aring; til <a href="index.php?module=Administration&action=DstFix">reparer</a> linket i  Admin-konsollen og tilf&oslash;j Daylight Saving Time fixet.',
	'LBL_DUPLICATE_BUTTON_KEY' => 'U',
	'LBL_DUPLICATE_BUTTON_LABEL' => 'Dupliker',
	'LBL_DUPLICATE_BUTTON_TITLE' => 'Dupliker [Alt+U]',
	'LBL_DUPLICATE_BUTTON' => 'Dupliker',
	'LBL_EDIT_BUTTON_KEY' => 'E',
	'LBL_EDIT_BUTTON_LABEL' => 'Rediger',
	'LBL_EDIT_BUTTON_TITLE' => 'Rediger [Alt+E]',
	'LBL_EDIT_BUTTON' => 'Rediger',
	'LBL_VIEW_BUTTON_KEY' => 'V',
	'LBL_VIEW_BUTTON_LABEL' => 'Vis',
	'LBL_VIEW_BUTTON_TITLE' => 'Vis [Alt+V]',
	'LBL_VIEW_BUTTON' => 'View',
	'LBL_EMAIL_PDF_BUTTON_KEY' => 'M',
	'LBL_EMAIL_PDF_BUTTON_LABEL' => 'E-mail som PDF',
	'LBL_EMAIL_PDF_BUTTON_TITLE' => 'E-mail som PDF [Alt+M]',
	'LBL_EMAILS'=>'E-mails',
	'LBL_EMPLOYEES' => 'Ansatte',
	'LBL_ENTER_DATE' => 'Indtast dato',
	'LBL_EXPORT_ALL' => 'Eksporter alt',
	'LBL_EXPORT' => 'Eksporter',
	'LBL_HIDE'=>'Skjul',
	'LBL_ID'=>'ID',
	'LBL_IMPORT_PROSPECTS'=>'Importer m&aring;l',
	'LBL_IMPORT' => 'Importer',
	'LBL_LAST_VIEWED' => 'Seneste visninger',
	'LBL_LEADS'=>'Emner',
	
	'LBL_LIST_ACCOUNT_NAME' => 'Kontonavn',
	'LBL_LIST_ASSIGNED_USER' => 'Bruger',
	'LBL_LIST_CONTACT_NAME' => 'Kontakts navn',
	'LBL_LIST_CONTACT_ROLE' => 'Kontakts rolle',
	'LBL_LIST_EMAIL' => 'E-mail',
	'LBL_LIST_NAME' => 'Navn',
	'LBL_LIST_OF' => 'af',
	'LBL_LIST_PHONE' => 'Telefon',
	'LBL_LIST_USER_NAME' => 'Brugernavn',
	'LBL_LISTVIEW_MASS_UPDATE_CONFIRM' => 'Er du sikker p&aring; du &oslash;nsker at opdatere hele listen?',
	'LBL_LISTVIEW_NO_SELECTED' => 'Venligst v&aelig;lg mindst et element for at forts&aelig;tte.',
	'LBL_LISTVIEW_OPTION_CURRENT' => 'Nuv&aelig;rende side',
	'LBL_LISTVIEW_OPTION_ENTIRE' => 'Hele listen',
	'LBL_LISTVIEW_OPTION_SELECTED' => 'Valgte r&aelig;kker',
	'LBL_LISTVIEW_SELECTED_OBJECTS' => 'Valgte: ',
	
	'LBL_LOGOUT' => 'Log af',
	'LBL_MAILMERGE_KEY' => 'M',
	'LBL_MAILMERGE' => 'E-mail sammensmeltning',
	'LBL_MASS_UPDATE' => 'Masse opdatering',
	'LBL_MEETINGS'=>'M&oslash;der',
	'LBL_MEMBERS'=>'Medlemmer',
	'LBL_MODIFIED_BY_USER'=>'&AElig;ndret af bruger',
	'LBL_MODIFIED' => '&AElig;ndret af',
	'LBL_MY_ACCOUNT' => 'Min konto',
	'LBL_NAME' => 'Navn',
	'LBL_NEW_BUTTON_KEY' => 'N',
	'LBL_NEW_BUTTON_LABEL' => 'Opret',
	'LBL_NEW_BUTTON_TITLE' => 'Opret [Alt+N]',
	'LBL_NEXT_BUTTON_LABEL' => 'N&aelig;ste',
	'LBL_NONE' => '--Ingen--',
	'LBL_NOTES'=>'Noter',
	'LBL_OPENALL_BUTTON_KEY' => 'O',
	'LBL_OPENALL_BUTTON_LABEL' => '&Aring;ben alle',
	'LBL_OPENALL_BUTTON_TITLE' => '&Aring;ben alle [Alt+O]',
	'LBL_OPENTO_BUTTON_KEY' => 'T',
	'LBL_OPENTO_BUTTON_LABEL' => '&Aring;ben til: ',
	'LBL_OPENTO_BUTTON_TITLE' => '&Aring;ben til: [Alt+T]',
	'LBL_OPPORTUNITIES'=>'Muligheder',
	'LBL_OPPORTUNITY_NAME' => 'Mulighed navn',
	'LBL_OPPORTUNITY'=>'Mulighed',
	'LBL_OR' => 'ELLER',
	'LBL_PERCENTAGE_SYMBOL' => '%',
	'LBL_PRODUCT_BUNDLES'=>'Produktsammens&aelig;tninger',
	'LBL_PRODUCT_BUNDLES'=>'Produktsammens&aelig;tninger',
	'LBL_PRODUCTS'=>'Produkter',
	'LBL_PROJECT_TASKS'=>'Projekt opgaver',
	'LBL_PROJECTS'=>'Projekter',
	'LBL_PROJECTS'=>'Projekter',
	'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
	'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Opret mulighed fra tilbud',
	'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Opret mulighed fra tilbud [Alt+O]',
	'LBL_QUOTES_SHIP_TO'=>'Tilbud sendes til',
	'LBL_QUOTES'=>'Tilbud',
	'LBL_RELATED_RECORDS' => 'Relaterede elementer',
	'LBL_REMOVE' => 'Fjern',
	'LBL_REQUIRED_SYMBOL' => '*',
	'LBL_SAVE_BUTTON_KEY' => 'S',
	'LBL_SAVE_BUTTON_LABEL' => 'Gem',
	'LBL_SAVE_BUTTON_TITLE' => 'Gem [Alt+S]',
	'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
	'LBL_SAVE_NEW_BUTTON_LABEL' => 'Gem og opret ny',
	'LBL_SAVE_NEW_BUTTON_TITLE' => 'Gem og opret ny [Alt+V]',
	'LBL_SEARCH_BUTTON_KEY' => 'Q',
	'LBL_SEARCH_BUTTON_LABEL' => 'S&oslash;g',
	'LBL_SEARCH_BUTTON_TITLE' => 'S&oslash;g [Alt+Q]',
	'LBL_SEARCH' => 'S&oslash;g',
	'LBL_SELECT_BUTTON_KEY' => 'T',
	'LBL_SELECT_BUTTON_LABEL' => 'V&aelig;lg',
	'LBL_SELECT_BUTTON_TITLE' => 'V&aelig;lg [Alt+T]',
	'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
	'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'V&aelig;lg kontakt',
	'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'V&aelig;lg kontakt [Alt+T]',
	'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'V&aelig;lg fra rapporter',
	'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'V&aelig;lg rapporter',
	'LBL_SELECT_USER_BUTTON_KEY' => 'U',
	'LBL_SELECT_USER_BUTTON_LABEL' => 'V&aelig;lg bruger',
	'LBL_SELECT_USER_BUTTON_TITLE' => 'V&aelig;lg bruger [Alt+U]',
	'LBL_SERVER_RESPONSE_RESOURCES' => 'Ressurser anvendt til at konstruere denne side (foresp&oslash;rgsler, filer)',
	'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'sekunder.',
	'LBL_SERVER_RESPONSE_TIME' => 'Server respons tid:',
	'LBL_SHIP_TO_ACCOUNT'=>'Send til konto',
	'LBL_SHIP_TO_CONTACT'=>'Send til kontakt',
	'LBL_SHORTCUTS' => 'Genveje',
	'LBL_SHOW'=>'Vis',
	'LBL_SQS_INDICATOR' => '',
	'LBL_STATUS_UPDATED'=>'Din status for denne begivenhed er blevet opdateret!',
	'LBL_STATUS'=>'Status:',
	'LBL_SUBJECT' => 'Emne',
	'LBL_SYNC' => 'Synkroniser',
	'LBL_SYNC' => 'Synkroniser',
	'LBL_TASKS'=>'Opgaver',
	'LBL_TEAMS_LINK'=>'Hold',
	'LBL_THOUSANDS_SYMBOL' => 'K',
	'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
	'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arkiver e-mail',
	'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Arkiver e-mail [Alt+K]',
	'LBL_UNAUTH_ADMIN' => 'Uautoriseret adgang til administrationen',
	'LBL_UNDELETE_BUTTON_LABEL' => 'Fortryd sletning',
	'LBL_UNDELETE_BUTTON_TITLE' => 'Fortryd sletning [Alt+D]',
	'LBL_UNDELETE_BUTTON' => 'Fortryd sletning',
	'LBL_UNDELETE' => 'Fortryd sletning',
	'LBL_UNSYNC' => 'Tilbagesynkroniser',
	'LBL_UPDATE' => 'Opdater',
	'LBL_USER_LIST' => 'Opdater liste',
	'LBL_USERS_SYNC'=>'Brugeres synkronisering',
	'LBL_USERS'=>'Brugere',
	'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
	'LBL_VIEW_PDF_BUTTON_LABEL' => 'Udskriv som PDF',
	'LBL_VIEW_PDF_BUTTON_TITLE' => 'Udskriv som PDF [Alt+P]',
	
	'LNK_ABOUT' => 'Om',
	'LNK_ADVANCED_SEARCH' => 'Avanceret',
	'LNK_BASIC_SEARCH' => 'Basis',
	'LNK_DELETE_ALL' => 'slet alt',
	'LNK_DELETE' => 'slet',
	'LNK_EDIT' => 'rediger',
	'LNK_GET_LATEST'=>'Hent seneste',
	'LNK_GET_LATEST_TOOLTIP'=>'Erstart med seneste version',
	'LNK_HELP' => 'Hj&aelig;lp',
	'LNK_LIST_END' => 'Slutning',
	'LNK_LIST_NEXT' => 'N&aelig;ste',
	'LNK_LIST_PREVIOUS' => 'Forrige',
	'LNK_LIST_RETURN' => 'G&aring; tilbage til liste',
	'LNK_LIST_START' => 'Begyndelse',
	'LNK_LOAD_SIGNED'=>'Signeret',
	'LNK_LOAD_SIGNED_TOOLTIP'=>'Erstat med signeret dokument',
	'LNK_PRINT' => 'Udskriv',
	'LNK_REMOVE' => 'fjern',
	'LNK_RESUME' => 'Resume',
	'LNK_VIEW_CHANGE_LOG' => 'Vis Change Log',
	
	'NTC_CLICK_BACK' => 'Venligst klik browserens \'Tilbage\'-knap og ret fejlen.',
	'NTC_DATE_FORMAT' => '(dd-mm-yyyy)',
	'NTC_DATE_TIME_FORMAT' => '(24:00 dd-mm-yyyy)',
	'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Er du sikker p&aring; du &oslash;nsker at slette valgte element(er)?',
	'NTC_DELETE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at slette dette element?',
	'NTC_LOGIN_MESSAGE' => 'Venligst indtast dit brugervan og din adgangskode.',
	'NTC_NO_ITEMS_DISPLAY' => 'ingen',
	'NTC_REMOVE_CONFIRMATION' => 'Er du sikker p&aring; du &oslash;nsker at fjerne denne forbindelse?',
	'NTC_REQUIRED' => 'Indikerer p&aring;kr&aelig;vede felter',
	'NTC_SUPPORT_SUGARCRM' => 'St&oslash;t SugarCRM open source projektet med et bel&oslash;b gennem PayPal - det er hurtigt, gratis og sikkert!',
	'NTC_TIME_FORMAT' => '(24:00)',
	'NTC_WELCOME' => 'Velkommen',
	'NTC_YEAR_FORMAT' => '(yyyy)',
	'LOGIN_LOGO_ERROR'=> 'Venligst erstat SugarCRM-logoerne.',
	'ERROR_FULLY_EXPIRED'=> "Din virksomheds licens til SugarCRM har v&aelig;ret udl&oslash;bet i mere end 30 dage og skal opdateres. Kun administratorer kan logge sig p&aring; systemet.",
	'ERROR_LICENSE_EXPIRED'=> "Din virksomheds licens til SugarCRM skal opdateres. Kun administratorer kan logge sig p&aring; systemet.",
);
?>
