<?PHP
$manifest = array( 
	'name' => 'British Language file for SugarCE 5.0.0a',
	'description' => 'Auto-Translated from US to British',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'acceptable_sugar_versions' =>
		  array (),
	'acceptable_sugar_flavors' =>
		  array('CE'),
	'author' => 'Stephen Solberg',
        'version' => '5.0.0a',
	'published_date' => '2008/01/11',
	'icon' => 'include/images/flag-en_gb.gif',
      );

$installdefs = array(
	'id'=> 'en_gb',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
array('from'=> '<basepath>/include','to'=>'include',),
array('from'=> '<basepath>/modules','to'=>'modules'),

                        )
 );
?>
