#!/bin/sh

SugarCRM=/var/sugarce 

DictFile=$(cat en_gb-dictionary.lang.txt)
langDir=include/language
langUSTemplate=$SugarCRM/$langDir/en_us.notify_template.html
langUSDict=$SugarCRM/$langDir/en_us.lang.php

test -d ${SugarCRM} || ( echo can not find ${SugarCRM}; exit 1)

for file in `cd ${SugarCRM}/modules; find . -type f -name en_us.lang.php`; do
	dir=$(dirname $file)
	dir=modules/$dir
	file=modules/$file
	test -d $dir  || ( echo creating $dir ; mkdir -p $dir )
	test -f $file || ( echo copying ${SugarCRM}/$file; cp ${SugarCRM}/$file $dir )
	echo Translating $dir/en_gb.lang.php
	perl -p -i.bak -e "$DictFile" $file
	rm ${file}.bak
	mv $file $dir/en_gb.lang.php 
	echo
done

test -d $langDir || ( echo creating $langDir ; mkdir -p $langDir )

if [ ! -f $langUSTemplate ]; then
	echo error can not copy $langUSTemplate
else
	echo creating $langDir/en_gb.notify_template.html
	cp $langUSTemplate $langDir/en_gb.notify_template.html
fi

if [ ! -f $langUSDict ]; then
	echo error can not copy $langUSDict
else
	echo translating $langDir/en_gb.lang.php
	cp $langUSDict $langDir
	perl -p -i.bak -e 's/US English/UK English/g' $langDir/en_us.lang.php
	rm $langDir/en_us.lang.php.bak
	mv $langDir/en_us.lang.php $langDir/en_gb.lang.php
fi

