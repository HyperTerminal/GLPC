﻿<?php
/********************************************************************************* 
 * : fi_fi.lang.php,version 7.1.2008 hvuolle Exp $
 * Description:  Finnish language pack for SugarCRM 6.2.0 
 * This language pack is original work (not derived)
 * Author:    Henri Vuolle, henri.vuolle@kiwai.fi, Finland/Tampere
 * Web:       http://www.kiwai.fi, henri.vuolle@kiwai.fi/info@kiwai.fi
 * Copyright: Copyright (C) 2011-2012 Henri Vuolle / J2EE Technology Solutions. 
 * All Rights Reserved.
 * License : GNU General Public License version 3
 **********************************************************************************/


// manifest file for information regarding application of new code
/********************************************************************************* 
 * : fi_fi.lang.php,version 7.1.2008 hvuolle Exp $
 * Description:  Finnish language pack for SugarCRM 6.2.0 
 * This language pack is original work (not derived)
 * Author:    Henri Vuolle, henri.vuolle@kiwai.fi, Finland/Tampere
 * Web:       http://www.kiwai.fi, henri.vuolle@kiwai.fi/info@kiwai.fi
 * Copyright: Copyright (C) 2011-2012 Henri Vuolle / J2EE Technology Solutions. 
 * All Rights Reserved.
 * License : GNU General Public License version 3
 **********************************************************************************/


// manifest file for information regarding application of new code
$manifest = array( 
	'name' => 'Finnish (FI) - Language Pack',
    	'description' => 'Language Pack Finnish',
	'type' => 'langpack',
	'is_uninstallable' => true,
	'version' => '6.1.4',
	'acceptable_sugar_flavors' => array (0 => 'CE'),
	'author' => 'Henri Vuolle & J2EE Technology Solutions',
	'acceptable_sugar_versions' => array ('exact_matches' => array (0 => '6.2.0RC2'), "regex_matches" => array (0 => "6.1.[0-9][a-z]?")), 
	'published_date' => '2011/27/05'
);

$installdefs = array(
	'id'=> 'fi_fi',
	'copy' => array(
		array('from'=> 'fi_fi/include','to'=> 'include'),
		array('from'=> 'fi_fi/modules','to'=> 'modules')
	)
	
);
?>
