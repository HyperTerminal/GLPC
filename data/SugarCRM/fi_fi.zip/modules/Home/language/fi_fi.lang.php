<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Etusivu',
  'LBL_MODULES_TO_SEARCH' => 'Haettavat modulit',
  'LBL_NEW_FORM_TITLE' => 'Uusi kontakti',
  'LBL_FIRST_NAME' => 'Etunimi:',
  'LBL_LAST_NAME' => 'Sukunimi:',
  'LBL_LIST_LAST_NAME' => 'Sukunimi',
  'LBL_PHONE' => 'Puhelin:',
  'LBL_EMAIL_ADDRESS' => 'SÃ¤hkÃ¶postiosoite:',
  'LBL_MY_PIPELINE_FORM_TITLE' => 'oma pipeline',
  'LBL_PIPELINE_FORM_TITLE' => 'Pipeline myyntivaiheen mukaan',
  'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'Kampanjan ROI',
  'LBL_MY_CLOSED_OPPORTUNITIES_GAUGE' => 'Voitetut, suljetut myyntimahdollisuuteni',
  'LNK_NEW_CONTACT' => 'Luo kontakti',
  'LNK_NEW_ACCOUNT' => 'Luo asiakas',
  'LNK_NEW_OPPORTUNITY' => 'Luo myyntimahdollisuus',
  'LNK_NEW_LEAD' => 'Luo liidi',
  'LNK_NEW_CASE' => 'Luo palvelupyyntÃ¶',
  'LNK_NEW_NOTE' => 'Luo muistio tai liite',
  'LNK_NEW_CALL' => 'Kirjaa puhelu',
  'LNK_NEW_EMAIL' => 'Arkistoi sÃ¤hkÃ¶posti',
  'LNK_COMPOSE_EMAIL' => 'Luo sÃ¤hkÃ¶posti',
  'LNK_NEW_MEETING' => 'Ajoita kokous',
  'LNK_NEW_TASK' => 'Luo tehtÃ¤vÃ¤',
  'LNK_NEW_BUG' => 'Raportoi bugi',
  'LBL_ADD_BUSINESSCARD' => 'Luo kÃ¤yntikortti',
  'ERR_ONE_CHAR' => 'Ole hyvÃ¤ ja anna ainakin yksi kirjain, tai numero suorittaaksesi haun ...',
  'LBL_OPEN_TASKS' => 'Avoimet tehtÃ¤vÃ¤ni',
  'LBL_SEARCH_RESULTS' => 'Hakutulokset',
  'LBL_SEARCH_RESULTS_IN' => ' ',
  'LNK_NEW_SEND_EMAIL' => 'Luo sÃ¤hkÃ¶posti',
  'LBL_NO_ACCESS' => 'You do not have access to this area.  Contact your site administrator to obtain access',
  'LBL_NO_RESULTS_IN_MODULE' => '-- Ei hakutuloksia --',
  'LBL_NO_RESULTS' => '<h2>Ei hakutuloksia. Ole hyvÃ¤ ja suorita haku uudelleen.</h2><br>',
  'LBL_NO_RESULTS_TIPS' => '<h3>HakuvinkkejÃ¤:</h3><ul><li>Varmista, ettÃ¤ hakuun on valittu oikeat kategoriat.</li><li>Laajenna hakuehtoja.</li><li>Jos et edelleenkÃ¤Ã¤n lÃ¶ydÃ¤ etsimÃ¤Ã¤si koita hakea edistyneen haun avulla.</li></ul>',

  'LBL_RELOAD_PAGE' => 'Ole hyvÃ¤ <a href="javascript: window.location.reload()"> ja lataa sivu uudelleen</a> kÃ¤yttÃ¤Ã¤ksesi dashlettia.',
  'LBL_ADD_DASHLETS' => 'LisÃ¤Ã¤ dashletteja',
  'LBL_ADD_PAGE' => 'LisÃ¤Ã¤ sivu',
  'LBL_DEL_PAGE' => 'Poista sivu',
  'LBL_WEBSITE_TITLE' => 'Www',
  'LBL_RSS_TITLE' => 'UutissyÃ¶tteet',
  'LBL_DELETE_PAGE' => 'Poista sivu',
  'LBL_CHANGE_LAYOUT' => 'Muuta layoutia',
  'LBL_RENAME_PAGE' => 'NimeÃ¤ uudelleen',
  'LBL_CLOSE_DASHLETS' => 'Sulje',
  'LBL_CLOSE_SITEMAP' => 'Sulje',
  'LBL_OPTIONS' => 'Asetukset',
  // dashlet search fields
  'LBL_TODAY'=>'TÃ¤nÃ¤Ã¤n',
  'LBL_YESTERDAY' => 'Eilen',
  'LBL_TOMORROW'=>'Huomenna',
  'LBL_LAST_WEEK'=>'Viime viikko',
  'LBL_NEXT_WEEK'=>'Seuraava viikko',
  'LBL_LAST_7_DAYS'=>'Viimeiset 7 pÃ¤ivÃ¤Ã¤',
  'LBL_NEXT_7_DAYS'=>'Seuraavat 7 pÃ¤ivÃ¤Ã¤',
  'LBL_LAST_MONTH'=>'Viime kuussa',
  'LBL_NEXT_MONTH'=>'Seuraava kuukausi',
  'LBL_LAST_QUARTER'=>'Viime kvartaali',
  'LBL_THIS_QUARTER'=>'TÃ¤mÃ¤ kvartaali',
  'LBL_LAST_YEAR'=>'Viime vuosi',
  'LBL_NEXT_YEAR'=>'Seuraava vuosi',
  'LBL_LAST_30_DAYS' => 'Viimeiset 30 pÃ¤ivÃ¤Ã¤',
  'LBL_NEXT_30_DAYS' => 'Seuraavat 30 pÃ¤ivÃ¤Ã¤',
  'LBL_THIS_MONTH' => 'TÃ¤ssÃ¤ kuussa',
  'LBL_THIS_YEAR' => 'TÃ¤nÃ¤ vuonna',

  'LBL_MODULES' => 'Modulit',
  'LBL_CHARTS' => 'Kuvaajat',
  'LBL_TOOLS' => 'TyÃ¶kalut',
  'LBL_WEB' => 'Web',
  'LBL_SEARCH_RESULTS' => 'Hakutulokset',

  // Dashlet Categories
  'dashlet_categories_dom' => array(
      'Module Views' => 'ModulinÃ¤kymÃ¤t',
      'Portal' => 'Portaali',
      'Charts' => 'Kuvaajat',
      'Tools' => 'TyÃ¶kalut',
      'Miscellaneous' => 'Muuta'),
  'LBL_MAX_DASHLETS_REACHED' => 'Sinulla on kÃ¤ytÃ¶ssÃ¤ mÃ¤Ã¤ritelty maksimi mÃ¤Ã¤rÃ¤ dashletteja. Ole hyvÃ¤ ja poista jokin lisÃ¤tÃ¤ksesi uuden.',
  'LBL_ADDING_DASHLET' => 'LisÃ¤tÃ¤Ã¤n Sugar dashlettia ...',
  'LBL_ADDED_DASHLET' => 'LisÃ¤tty',
  'LBL_REMOVE_DASHLET_CONFIRM' => 'Haluatko varmasti poistaa dashletin kÃ¤ytÃ¶stÃ¤?',
  'LBL_REMOVING_DASHLET' => 'Poistetaan ...',
  'LBL_REMOVED_DASHLET' => 'Poistettu',
  'LBL_DASHLET_CONFIGURE_GENERAL' => 'Yleiset',
  'LBL_DASHLET_CONFIGURE_FILTERS' => 'Suodattimet',
  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Vain omat',
  'LBL_DASHLET_CONFIGURE_TITLE' => 'Otsikko',
  'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'NÃ¤ytÃ¤ rivit',

  'LBL_DASHLET_DELETE' => 'Poista Sugar dashletti',
  'LBL_DASHLET_REFRESH' => 'PÃ¤ivitÃ¤ Dashlet',
  'LBL_DASHLET_EDIT' => 'Muokkaa dashlettia',

  'LBL_TRAINING_TITLE' => 'Koulutus',

  'LBL_CREATING_NEW_PAGE' => 'Luodaan uutta sivua...',
  'LBL_NEW_PAGE_FEEDBACK' => 'Uusi sivu luotu. Voit nyt lisÃ¤tÃ¤ haluamasi dashletit.',
  'LBL_DELETE_PAGE_CONFIRM' => 'Haluatko varmasti poistaa sivun?',
  'LBL_SAVING_PAGE_TITLE' => 'Tallennetaan sivun otsikkoa...',
  'LBL_RETRIEVING_PAGE' => 'Haetaan sivua...',

  // Default out-of-box names for tabs
  'LBL_HOME_PAGE_1_NAME' => 'Oma Sugar',
  'LBL_HOME_PAGE_2_NAME' => 'Myynti',
  'LBL_HOME_PAGE_3_NAME' => 'Tuki',
  'LBL_HOME_PAGE_6_NAME' => 'Markkinointi',//bug 16510, separate the support and marketing page from each other
  'LBL_HOME_PAGE_4_NAME' => 'Seuranta',
  'LBL_CLOSE_SITEMAP' =>'Sulje',

  'LBL_SEARCH' => 'Hae',
  'LBL_CLEAR' => 'TyhjennÃ¤',

  'LBL_BASIC_CHARTS' => 'Peruskaaviot',
  'LBL_REPORT_CHARTS' => 'Raporttikuvaajat',

  'LBL_MY_FAVORITE_REPORT_CHARTS' => 'Suosikkiraportit',
  'LBL_GLOBAL_REPORT_CHARTS' => 'Globaalit tiimiraportit',
  'LBL_MY_TEAM_REPORT_CHARTS' => 'Oman tiimini raportit',
  'LBL_MY_SAVED_REPORT_CHARTS' => 'Tallennetut raporttini',

  'LBL_DASHLET_SEARCH' => 'Etsi dashletteja',

//ABOUT page
  'LBL_VERSION' => 'Versio',
  'LBL_BUILD' => 'Build',


  'LBL_VIEWLICENSE_COM' => '<P>This program is free software; you can redistribute it and/or modify it under the terms of the <a href="LICENSE.txt" target="_blank" class="body"> GNU Affero General Public License version 3</a> as published by the Free Software Foundation, including the additional permission set forth in the source code header.</P>',
  'LBL_ADD_TERM_COM' => '<P>The interactive user interfaces in modified source and object code versions of this program must display Appropriate Legal Notices, as required under Section 5 of the GNU Affero General Public License version 3. In accordance with Section 7(b) of the GNU General Public License version 3, these Appropriate Legal Notices must retain the display of the &quot;Powered by SugarCRM&quot; logo. If the display of the logo is not reasonably feasible for technical reasons, the Appropriate Legal Notices must display the words &quot;Powered by SugarCRM&quot;.</P>',

 
  'LBL_SUGAR_COMMUNITY_EDITION' => 'Sugar Community Edition',
  'LBL_SUGAR_PROFESSIONAL' => "Sugar Professional",
  'LBL_SUGAR_ENTERPRISE' => "Sugar Enterprise",
  'LBL_AND' => "ja",
  'LBL_ARE' => "ovat",
  'LBL_TRADEMARKS' => 'tuotemerkkejÃ¤',
  'LBL_OF' => 'of',
  'LBL_FOUNDERS' => 'Founders',
  'LBL_JOIN_SUGAR_COMMUNITY' => 'Join the Sugar Community',
  'LBL_DETAILS_SUGARFORGE' => 'Collaborate and develop Sugar extensions',
  'LBL_DETAILS_SUGAREXCHANGE' => 'Buy and sell certified Sugar extensions',
  'LBL_TRAINING' => 'Training',
  'LBL_DETAILS_TRAINING' => 'Learn about Sugar using online and interactive learning content',
  'LBL_FORUMS' => 'Forums',
  'LBL_DETAILS_FORUMS' => 'Discuss Sugar with expert community users and developers',
  'LBL_WIKI' => 'Wiki',
  'LBL_DETAILS_WIKI' => 'Search the knowledge base of user and developer topics',
  'LBL_DEVSITE' => 'Developer Site',
  'LBL_DETAILS_DEVSITE' => 'Discover resources, tutorials, and helpful links to get you up to speed on Sugar development',
  'LBL_GET_SUGARCRM_RSS' => 'Get SugarCRM RSS',
  'LBL_SUGARCRM_NEWS' => 'SugarCRM News',
  'LBL_SUGARCRM_TRAINING_NEWS' => 'SugarCRM Training News',
  'LBL_SUGARCRM_FORUMS' => 'SugarCRM Forums',
  'LBL_SUGARFORGE_NEWS' => 'SugarForge News',
  'LBL_ALL_NEWS' => 'All News',
  'LBL_LINK_CURRENT_CONTRIBUTORS' => 'Click this link for a current list of Sugar contributors!',
  'LBL_SOURCE_CODE' => 'Source Code',
  'LBL_SOURCE_SUGAR' => 'Sugar - The world\'s most popular sales force automation application created by SugarCRM Inc.',
  'LBL_SOURCE_XTEMPLATE' => 'XTemplate - A template engine for PHP created by Barnabás Debreceni',
  'LBL_SOURCE_NUSOAP' => 'NuSOAP - A set of PHP classes that allow developers to create and consume web services created by NuSphere Corporation and Dietrich Ayala',
  'LBL_SOURCE_JSCALENDAR' => 'JS Calendar - A calendar for entering dates created by Mihai Bazon',
  'LBL_SOURCE_PHPPDF' => 'PHP PDF - A library for creating PDF documents created by Wayne Munro',
  'LBL_SOURCE_JSONPHP' => 'JSON.php - A PHP script to convert to and from JSON data format by Michal Migurski.',
  'LBL_SOURCE_JSON' => 'JSON.js - A JSON parser and JSON stringifier in JavaScript.',
  'LBL_SOURCE_HTTP_WEBDAV_SERVER' => 'HTTP_WebDAV_Server - A WebDAV Server Implementation in PHP.',
  'LBL_SOURCE_JS_O_LAIT' => 'JavaScript O Lait - A library of reusable modules and components to enhance JavaScript by Jan-Klaas Kollhof.',
  'LBL_SOURCE_PCLZIP' => 'PclZip - library offers compression and extraction functions for Zip formatted archives by Vincent Blavet',
  'LBL_SOURCE_SMARTY' => 'Smarty - A template engine for PHP.',
  'LBL_SOURCE_OVERLIBMWS' => 'Overlibmws - JavaScript library for client-side windowing.',
  'LBL_SOURCE_YAHOO_UI_LIB' => 'Yahoo! User Interface Library - The UI Library Utilities facilitate the implementation of rich client-side features.',
  'LBL_SOURCE_PHPMAILER' => 'PHPMailer - A full featured email transfer class for PHP',
  'LBL_SOURCE_CRYPT_BLOWFISH' => 'Crypt_Blowfish - Allows for quick two-way blowfish encryption without requiring the MCrypt PHP extension.',
  'LBL_SOURCE_HTML_SAFE' => 'HTML_Safe - A parser that strips down all potentially dangerous content within HTML',
  'LBL_SOURCE_XML_HTMLSAX3' => 'XML_HTMLSax3 - A SAX parser for HTML and other badly formed XML documents',
  'LBL_SOURCE_YAHOO_UI_LIB_EXT' => 'Yahoo! UI Extensions Library - Extensions to the Yahoo! User Interface Library by Jack Slocum',
  'LBL_SOURCE_JSMIN' => 'JSMin - filter which removes comments and unnecessary whitespace from JavaScript files.',
  'LBL_SOURCE_SWFOBJECT' => 'SWFObject - Javascript Flash Player detection and embed script.',
  'LBL_SOURCE_TINYMCE' => 'TinyMCE - A WYSIWYG editor control for web browsers that enables the user to edit HTML contents',
  'LBL_SOURCE_EXT' => 'Ext - A client-side JavaScript framework for building web applications.',
  'LBL_SOURCE_RECAPTCHA' => 'reCAPTCHA - A free CAPTCHA service that helps to digitize books, newspapers and old time radio shows.', 
  'LBL_SOURCE_TCPDF' => 'TCPDF - A PHP class for generating PDF documents.',
  'LBL_SOURCE_CSSMIN' => 'CssMin - A css parser and minifier.',
  'LBL_SOURCE_PHPSAML' => 'PHP-SAML - A simple SAML toolkit for PHP.',


  'LBL_DASHLET_TITLE' => 'Omat sivut',
  'LBL_DASHLET_OPT_TITLE' => 'Otsikko',
  'LBL_DASHLET_OPT_URL' => 'Www-sivun osoite',
  'LBL_DASHLET_OPT_HEIGHT' => 'Dashletin korkeus (pikseleinÃ¤)',
  'LBL_DASHLET_SUGAR_NEWS' => 'Sugar uutiset',
  'LBL_DASHLET_DISCOVER_SUGAR_PRO' => 'Discover Sugar',

);


?>
