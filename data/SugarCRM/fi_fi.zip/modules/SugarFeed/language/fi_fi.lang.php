<?php
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'Tiimi',
  'LBL_TEAM_ID' => 'Tiimin Id',
  'LBL_ASSIGNED_TO_ID' => 'Vastuuhenkilö',
  'LBL_ASSIGNED_TO_NAME' => 'Vastuuhenkilö',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Luonti pvm',
  'LBL_DATE_MODIFIED' => 'Muokkaus pvm',
  'LBL_MODIFIED' => 'Muokkaaja',
  'LBL_MODIFIED_ID' => 'Muokkaaja',
  'LBL_MODIFIED_NAME' => 'Muokkaaja',
  'LBL_CREATED' => 'Tekijä',
  'LBL_CREATED_ID' => 'Tekijä',
  'LBL_DESCRIPTION' => 'Kuvaus',
  'LBL_DELETED' => 'Poistettu',
  'LBL_NAME' => 'Nimi',
  'LBL_SAVING'=>'Tallennetaan...',
  'LBL_SAVED'=>'Tallennettu',
  'LBL_CREATED_USER' => 'Tekijä',
  'LBL_MODIFIED_USER' => 'Muokkaaja',
  'LBL_LIST_FORM_TITLE' => 'Sugar syötteet',
  'LBL_MODULE_NAME' => 'Sugar syötteet',
  'LBL_MODULE_TITLE' => 'Sugar syötteet',
  'LBL_DASHLET_DISABLED' => 'Varoitus: The Sugar Feed system is disabled, no new feed entries will be posted until it is activated',
  'LBL_ADMIN_SETTINGS' => 'Sugar syötteiden asetukset',
  'LBL_RECORDS_DELETED' => 'All previous Sugar Feed entries have been removed, if the Sugar Feed system is enabled, new entries will be generated automatically.',
  'LBL_CONFIRM_DELETE_RECORDS' => 'Are you sure you wish to delete all of the Sugar Feed entries?',
  'LBL_FLUSH_RECORDS' => 'Delete Feed Entries',
  'LBL_ENABLE_FEED' => 'Enable Sugar Feed',
  'LBL_ENABLE_MODULE_LIST' => 'Activate Feeds For',
  'LBL_HOMEPAGE_TITLE' => 'Omat sugar syötteet',
  'LNK_NEW_RECORD' => 'Luo sugar syöte',
  'LNK_LIST' => 'Sugar syötteet',
  'LBL_SEARCH_FORM_TITLE' => 'Hae sugar syötteitä',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historia',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteetit',
  'LBL_SUGAR_FEED_SUBPANEL_TITLE' => 'Sugar syötteet',
  'LBL_NEW_FORM_TITLE' => 'Uusi Sugar syöte',
  'LBL_ALL'=>'Kaikki',
  'LBL_USER_FEED' => 'Käyttäjö�n syötteet',
  'LBL_ENABLE_USER_FEED' => 'Aktivoi käyttäjien syötteet',
  'LBL_TO'=>'Lähetä tiimille',
  'LBL_IS'=>'on',
  'LBL_DONE'=>'Valmis',
  'LBL_TITLE'=>'Titteli',
  'LBL_ROWS'=>'Rivit',
  'LBL_CATEGORIES'=>'Modulit',
  'LBL_TIME_LAST_WEEK'=>'Viime viikko',
  'LBL_TIME_WEEKS'    =>'Viikot',
  'LBL_TIME_DAYS'     =>'Päivät',
  'LBL_TIME_YESTERDAY'=>'Eilinen',
  'LBL_TIME_HOURS'    =>'Tunnit',
  'LBL_TIME_HOUR'     =>'Tunnit',
  'LBL_TIME_MINUTES'  =>'Minuutit',
  'LBL_TIME_MINUTE'   =>'Minuutit',
  'LBL_TIME_SECONDS'  =>'Sekunnit',
  'LBL_TIME_SECOND'   =>'Sekunti',
  'LBL_TIME_AGO'      =>'sitten',

  'CREATED_CONTACT'=>'Luotiin <b>UUSI</b> kontakti',
  'CREATED_OPPORTUNITY'=>'Luotiin <b>UUSI</b> myyntimahdollisuus',
  'CREATED_CASE'=>'Luotiin <b>UUSI</b> palvelupyyntö',
  'CREATED_LEAD'=>'Luotiin <b>UUSI</b> liidi',
  'FOR'=>'for',
  'CLOSED_CASE'=>'<b>SULJETTIIN</b> palvelupyyntö ',
  'CONVERTED_LEAD'=>'<b>MUUNNETTIIN</b> liidi',
  'WON_OPPORTUNITY'=>'on <b>VOITTANUT</b> myyntimahdollisuuden',
  'WITH' => 'kanssa',

  'LBL_LINK_TYPE_Link' => 'Linkki',
  'LBL_LINK_TYPE_Image' => 'Kuva',
  'LBL_LINK_TYPE_YouTube' => 'YouTube&#153;',
  
  'LBL_SELECT' => 'Valitse',  
  'LBL_POST' => 'Postita', 
);
?>
