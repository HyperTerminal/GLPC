<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/


$mod_strings = array (
    'LNK_NEW_CALL' => 'Kirjaa puhelu',
    'LNK_NEW_MEETING' => 'Ajoita kokous',
    'LNK_NEW_TASK' => 'Luo tehtäv�',
    'LNK_NEW_NOTE' => 'Luo muistio tai liite',
    'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
    'LNK_CALL_LIST' => 'Puhelut',
    'LNK_MEETING_LIST' => 'tapaamiset',
    'LNK_TASK_LIST' => 'Tehtävät',
    'LNK_NOTE_LIST' => 'Muistiot',
    'LNK_EMAIL_LIST' => 'Sähköpostit',
    'LBL_ADD_FIELD'=> 'Lisää kenttä:',
	'LBL_MODULE_SELECT' => 'Muokattava moduli',
	'LBL_SEARCH_FORM_TITLE' => 'Modulin haku',
	'COLUMN_TITLE_NAME' => 'Kentän nimi',
    'COLUMN_TITLE_DISPLAY_LABEL' => 'Näytettävä labeli',
    'COLUMN_TITLE_LABEL_VALUE' => 'Labelin arvo',
	'COLUMN_TITLE_LABEL' => 'Järjestelmä labeli',
	'COLUMN_TITLE_DATA_TYPE' => 'Data Tyyppi',
	'COLUMN_TITLE_MAX_SIZE' => 'Max koko',
	'COLUMN_TITLE_HELP_TEXT' => 'Apuateksti',
    'COLUMN_TITLE_COMMENT_TEXT' => 'Kommenttiteksti',
	'COLUMN_TITLE_REQUIRED_OPTION' => 'Pakollinen kenttä',
	'COLUMN_TITLE_DEFAULT_VALUE' => 'Oletusarvo',
	'COLUMN_TITLE_DEFAULT_EMAIL' => 'Oletusarvo',
	'COLUMN_TITLE_EXT1' => 'Extra Meta Field 1',
	'COLUMN_TITLE_EXT2' => 'Extra Meta Field 2',
	'COLUMN_TITLE_EXT3' => 'Extra Meta Field 3',
	'COLUMN_TITLE_FRAME_HEIGHT' => 'IFramen korkeus',
	'COLUMN_TITLE_HTML_CONTENT' =>'HTML',
	'COLUMN_TITLE_URL'=>'Oletus URL',
	'COLUMN_TITLE_AUDIT' =>'Auditoidaan',
	'COLUMN_TITLE_REPORTABLE' => 'Raportoitavissa',
	'COLUMN_TITLE_MIN_VALUE' => 'Min arvo',
	'COLUMN_TITLE_MAX_VALUE' => 'Max arvo',
	'COLUMN_TITLE_LABEL_ROWS' => 'Rivit',
	'COLUMN_TITLE_LABEL_COLS' => 'Kolumnit',
	'COLUMN_TITLE_DISPLAYED_ITEM_COUNT'=>'# Items displayed',
	'COLUMN_TITLE_AUTOINC_NEXT' => 'Auto Increment Next Value',
    'COLUMN_DISABLE_NUMBER_FORMAT' => 'Disable Format',
	'LBL_DROP_DOWN_LIST' => 'Pudotusvalikko',
	'LBL_RADIO_FIELDS'=> 'Radio kentät',
	'LBL_MULTI_SELECT_LIST'=> 'Monivalintalista',
	'COLUMN_TITLE_PRECISION'=> 'Tarkkuus',
	'MSG_DELETE_CONFIRM' => 'Are you sure you want to delete this item?',
	'POPUP_INSERT_HEADER_TITLE' => 'Lisää Custom Field',
	'POPUP_EDIT_HEADER_TITLE' => 'Muokkaa Custom Field',
	'LNK_SELECT_CUSTOM_FIELD' => 'Valitse Custom Field',
	'LNK_REPAIR_CUSTOM_FIELD' => 'Korjaa Custom Fields',
	'LBL_MODULE' => 'Moduli',
	'COLUMN_TITLE_MASS_UPDATE'=>'Joukkopäivitys',
    'COLUMN_TITLE_IMPORTABLE'=>'Importable',
    'COLUMN_TITLE_DUPLICATE_MERGE'=>'Sisällytetään duplikaattien yhdistämiseen',
    'LBL_LABEL'=>'Label',
    'LBL_DATA_TYPE'=>'Data Tyyppi',
    'LBL_DEFAULT_VALUE'=>'Oletusarvo',
    'LBL_AUDITED'=>'Auditoitu',
    'LBL_REPORTABLE'=>'Raportoitavissa',
    'ERR_RESERVED_FIELD_NAME' => "Reserved Keyword",
	'ERR_SELECT_FIELD_TYPE' => 'Valitse kentän tyyppi',
    'LBL_BTN_ADD' => 'Lisää',
    'LBL_BTN_EDIT' => 'Muokkaa',
    'LBL_GENERATE_URL' => 'Generoi URL',
	'LBL_DEPENDENT_CHECKBOX'=>'Dependent',
	'LBL_DEPENDENT_TRIGGER'=>'Trigger',
    'LBL_CALCULATED'=>'Laskettu arvo',
    'LBL_FORMULA'=>'Kaava',
    'LBL_DYNAMIC_VALUES_CHECKBOX' => 'Dependent',
    'LBL_BTN_EDIT_VISIBILITY'=>'Edit Visibility',
    'LBL_LINK_TARGET'=>'Avaa linkki kohteeseen',
    'LBL_IMAGE_WIDTH' => 'Leveys',
    'LBL_IMAGE_HEIGHT' => 'Korkeus',
    'LBL_IMAGE_BORDER' => 'Reunus',

);


?>
