<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

/*********************************************************************************

* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributor(s): ______________________________________..
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
    //END DON'T CONVERT
    'ERR_DELETE_RECORD' => 'Anna tietueen numero poistaaksesi kontaktin.',
    'LBL_ACCOUNT_ID' => 'Asiakas ID:',
    'LBL_ACCOUNT_NAME' => 'Asiakkaan nimi:',
    'LBL_CAMPAIGN'     => 'Kampanja:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteetit',
    'LBL_ADD_BUSINESSCARD' => 'Lisää käyntikortti',
    'LBL_ADDMORE_BUSINESSCARD' => 'lisää toinen käyntikortti',
    'LBL_ADDRESS_INFORMATION' => 'Osoitetiedot',
    'LBL_ALT_ADDRESS_CITY' => 'Vaihtoehtoinen osoite Kaupunki/kunta:',
    'LBL_ALT_ADDRESS_COUNTRY' => 'Vaihtoehtoinen osoite Maa:',
    'LBL_ALT_ADDRESS_POSTALCODE' => 'Vaihtoehtoinen osoite Postinumero:',
    'LBL_ALT_ADDRESS_STATE' => 'Vaihtoehtoinen osoite Maakunta/lääni:',
    'LBL_ALT_ADDRESS_STREET_2' => 'Vaihtoehtoinen osoite Katuosoite 2:',
    'LBL_ALT_ADDRESS_STREET_3' => 'Vaihtoehtoinen osoite Katuosoite 3:',
    'LBL_ALT_ADDRESS_STREET' => 'Vaihtoehtoinen osoite Katuosoite:',
    'LBL_ALTERNATE_ADDRESS' => 'Toinen osoite:',
    'LBL_ALT_ADDRESS' => 'Toinen osoite:',
    'LBL_ANY_ADDRESS' => 'Mikä vain osoite:',
    'LBL_ANY_EMAIL' => 'Mikä vain sähköpostiosoite:',
    'LBL_ANY_PHONE' => 'Mikä vain puhelin:',
    'LBL_ASSIGNED_TO_NAME' => 'Vastuuhenkilö:',
    'LBL_ASSIGNED_TO_ID' => 'Vastuuhenkilö',
    'LBL_ASSISTANT_PHONE' => 'Assistentin puhelin:',
    'LBL_ASSISTANT' => 'Assistentti:',
    'LBL_BIRTHDATE' => 'Syntymäpäivä:',
    'LBL_BUSINESSCARD' => 'Käyntikortti',
    'LBL_CITY' => 'Kaupunki:',
    'LBL_CAMPAIGN_ID' => 'Kampanja ID',
    'LBL_CONTACT_INFORMATION' => 'Kontaktin yhteenveto',
    'LBL_CONTACT_NAME' => 'Kontaktin nimi:',
    'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakti-Myyntimahdollisuus:',
    'LBL_CONTACT_ROLE' => 'Rooli:',
    'LBL_CONTACT' => 'Kontakti:',
    'LBL_COUNTRY' => 'Maa:',
    'LBL_CREATED_ACCOUNT' => 'Uusi asiakas luotu',
    'LBL_CREATED_CALL' => 'Uusi puhelu luotu',
    'LBL_CREATED_CONTACT' => 'Uusi puhelu luotu',
    'LBL_CREATED_MEETING' => 'Uusi tapaaminen luotu',
    'LBL_CREATED_OPPORTUNITY' =>'Uusi myyntimahdollisuus luotu',
    'LBL_DATE_MODIFIED' => 'Muokkaus pvm:',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kontaktit',
    'LBL_DEPARTMENT' => 'Osasto:',
    'LBL_DESCRIPTION_INFORMATION' => 'Kuvaus',
    'LBL_DESCRIPTION' => 'Kuvaus:',
    'LBL_DIRECT_REPORTS_SUBPANEL_TITLE'=>'Raportoi suoraan',
    'LBL_DO_NOT_CALL' => 'Ei saa soittaa:',
    'LBL_DUPLICATE' => 'Mahdollinen duplikaatti kontakti',
    'LBL_EMAIL_ADDRESS' => 'Sähköpostiosoite:',
    'LBL_EMAIL_OPT_OUT' => 'Estä viestien lähetys:',
    'LBL_EMPTY_VCARD' => 'Ole hyvä ja valitse vCard tiedosto',
    'LBL_EXISTING_ACCOUNT' => 'Käytettiin olemassa olevaa asiakasta',
    'LBL_EXISTING_CONTACT' => 'Käytettiin olemassa olevaa kontaktia',
    'LBL_EXISTING_OPPORTUNITY'=> 'Käytettiin olemassa olevaa myyntimahdollisuutta',
    'LBL_FAX_PHONE' => 'Faksi:',
    'LBL_FIRST_NAME' => 'Etunimi:',
    'LBL_FULL_NAME' => 'Koko nimi:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
    'LBL_HOME_PHONE' => 'Etusivu:',
    'LBL_ID' => 'Relaatio ID:',
    'LBL_IMPORT_VCARD' => 'Tuo vCard',
    'LBL_VCARD' => 'vCard',
    'LBL_IMPORT_VCARDTEXT' => 'Luo uusi kontakti automaattisesti, kun tuot vCard - käyntikortin järjestelmään.',
    'LBL_INVALID_EMAIL'=>'Viallinen sähköpostiosoite:',
    'LBL_INVITEE' => 'Raportoi suoraan',
    'LBL_LAST_NAME' => 'Sukunimi:',
    'LBL_LEAD_SOURCE' => 'Liidin lähde:',
    'LBL_LIST_ACCEPT_STATUS' => 'Hyväksy tila',
    'LBL_LIST_ACCOUNT_NAME' => 'Asiakkaan nimi',
    'LBL_LIST_CONTACT_NAME' => 'Kontaktin nimi',
    'LBL_LIST_CONTACT_ROLE' => 'Rooli',
    'LBL_LIST_EMAIL_ADDRESS' => 'Sähkäposti',
    'LBL_LIST_FIRST_NAME' => 'Etunimi',
    'LBL_LIST_FORM_TITLE' => 'Kontaktit',
    'LBL_VIEW_FORM_TITLE' => 'Kontakti',
    'LBL_LIST_LAST_NAME' => 'Sukunimi',
    'LBL_LIST_NAME' => 'Nimi',
    'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Muu sähköpostiosoite',
    'LBL_LIST_PHONE' => 'Toimiston puhelin',
    'LBL_LIST_TITLE' => 'Asema',
    'LBL_MOBILE_PHONE' => 'GSM:',
    'LBL_MODIFIED' => 'Muokkaaja:',
    'LBL_MODULE_NAME' => 'Kontaktit',
    'LBL_MODULE_TITLE' => 'Kontaktit: Etusivu',
    'LBL_NAME' => 'Nimi:',
    'LBL_NEW_FORM_TITLE' => 'Uusi kontakti',
    'LBL_NEW_PORTAL_PASSWORD' => 'Portaalin uusi salasana:',
    'LBL_NOTE_SUBJECT' =>'Muistion aihe',
    'LBL_OFFICE_PHONE' => 'Toimiston puhelin:',
    'LBL_OPP_NAME' => 'Myyntimahdollisuuden nimi:',
    'LBL_OPPORTUNITY_ROLE_ID'=>'Myyntimahdollisuuden roolin ID:',
    'LBL_OPPORTUNITY_ROLE'=>'Myyntimahdollisuuden rooli',
    'LBL_OTHER_EMAIL_ADDRESS' => 'Muu sähköpostiosoite:',
    'LBL_OTHER_PHONE' => 'Muu puhelin:',
    'LBL_PHONE' => 'Puhelin:',
    'LBL_PORTAL_ACTIVE' => 'Portaali aktiivinen:',
    'LBL_PORTAL_APP'=>'Portaalisovellus:',
    'LBL_PORTAL_INFORMATION' => 'Portaalin tietoja',
    'LBL_PORTAL_NAME' => 'Portaalin nimi:',
    'LBL_PORTAL_PASSWORD_ISSET' => 'Portaalin salasana asetettu:',
    'LBL_STREET' => 'Katuosoite',
    'LBL_POSTAL_CODE' => 'Postinumero:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Ensisijainen osoite Kaupunki/kunta:',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Ensisijainen osoite Maa:',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Ensisijainen osoite Postinumero:',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Ensisijainen osoite Maakunta/l��ni:',
    'LBL_PRIMARY_ADDRESS_STREET_2' => 'Ensisijainen osoite Katuosoite 2:',
    'LBL_PRIMARY_ADDRESS_STREET_3' => 'Ensisijainen osoite Katuosoite 3:',
    'LBL_PRIMARY_ADDRESS_STREET' => 'Ensisijainen osoite Katuosoite:',
    'LBL_PRIMARY_ADDRESS' => 'Ensisijainen osoite:',
    'LBL_PRODUCTS_TITLE'=>'Tuotteet',
    'LBL_RELATED_CONTACTS_TITLE'=>'Liittyv�t kontaktit',
    'LBL_REPORTS_TO_ID'=>'Raportoi hlölle ID:',
    'LBL_REPORTS_TO' => 'Raportoi hlölle:',
    'LBL_RESOURCE_NAME' => 'Resurssin nimi',
    'LBL_SALUTATION' => 'Tervehdys:',
    'LBL_SAVE_CONTACT' => 'Tallenna kontakti',
    'LBL_SEARCH_FORM_TITLE' => 'Kontaktin haku',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Valitse merkityt kontaktit',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Valitse merkityt kontaktit',
    'LBL_STATE' => 'Maakunta/lääni:',
    'LBL_SYNC_CONTACT' => 'Synkronoi Outlook&reg;:',
    'LBL_PROSPECT_LIST' => 'Prospektilista',
    'LBL_TITLE' => 'Asema:',
    'LNK_CONTACT_LIST' => 'Kontaktit',
    'LNK_IMPORT_VCARD' => 'Luo vCardin avulla',
    'LNK_NEW_ACCOUNT' => 'Luo asiakas',
    'LNK_NEW_APPOINTMENT' => 'Luo tapaaminen',
    'LNK_NEW_CALL' => 'Kirjaa puhelu',
    'LNK_NEW_CASE' => 'Luo palvelupyyntö',
    'LNK_NEW_CONTACT' => 'Luo kontakti',
    'LNK_NEW_EMAIL' => 'Arkistoi sähköposti',
    'LNK_NEW_MEETING' => 'Ajoita tapaaminen',
    'LNK_NEW_NOTE' => 'Luo muistio',
    'LNK_NEW_OPPORTUNITY' => 'Luo myyntimahdollisuus',
    'LNK_NEW_TASK' => 'Luo tehtävä',
    'LNK_SELECT_ACCOUNT' => "Valitse asiakas",
    'MSG_DUPLICATE' => 'The contact record you are about to create might be a duplicate of a contact record that already exists. Contact records containing similar names and/or email addresses are listed below.<br>Click Save to continue creating this new contact, or click Cancel to return to the module without creating the contact.',
    'MSG_SHOW_DUPLICATES' => 'The contact record you are about to create might be a duplicate of a contact record that already exists. Contact records containing similar names and/or email addresses are listed below.<br>Click Save to continue creating this new contact, or click Cancel to return to the module without creating the contact.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopioi vaihtoehtoinen osoite ensisijaiseen osoitteeseen',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Kopioi ensisijainen osoite vaihtoehtoiseen osoitteeseen',
    'NTC_DELETE_CONFIRMATION' => 'Haluatko varmasti poistaa valitun tietueen?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Myyntimahdollisuuden luonti vaatii  asiakkaan.\n Ole hyvä ja luo uusi, tai valitse olemassa oleva asiakas.',
    'NTC_REMOVE_CONFIRMATION' => 'Haluatko varmasti poistaa kontaktin palvelupyynnöstä?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Haluatko poistaa tietueen suorana raporttina?',

	'LBL_USER_PASSWORD' => 'Salasana:',

	'LBL_LEADS_SUBPANEL_TITLE' => 'Liidit',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
	'LBL_COPY_ADDRESS_CHECKED' => 'Kopioi osoite merkittyihin kontakteihin',

	'LBL_CASES_SUBPANEL_TITLE' => 'Palvelupyynnöt',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Bugit',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projektit',	
	'LBL_TARGET_OF_CAMPAIGNS' => 'Kampanjat, joissa kohteena :',
	'LBL_CAMPAIGNS'	=>	'Kampanjat',
	'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampanjat',
	'LBL_LIST_CITY' => 'Kaupunki/kunta',
	'LBL_LIST_STATE' => 'Maakunta/lääni',
	'LBL_HOMEPAGE_TITLE' => 'Omat kontaktini',
    'LBL_OPPORTUNITIES' => 'Myyntimahdollisuudet',

	'LBL_CHECKOUT_DATE'=>'Päivä, jolloin otettu  käyttöön',
    'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
    'LBL_PROJECT_SUBPANEL_TITLE' => 'Projektit',
    'LBL_CAMPAIGNS_SUBPANEL_TITLE' => 'Kampanjat',
    'LNK_IMPORT_CONTACTS' => 'Tuo kontakteja',
)
?>