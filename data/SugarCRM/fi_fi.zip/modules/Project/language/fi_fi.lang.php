<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2011 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/




$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projektit',
	'LBL_MODULE_TITLE' => 'Projektit: Etusivu',
	'LBL_SEARCH_FORM_TITLE' => 'Projektien haku',
    'LBL_LIST_FORM_TITLE' => 'Projektit',
    'LBL_HISTORY_TITLE' => 'Historia',

	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Luonti pvm:',
	'LBL_DATE_MODIFIED' => 'Muokkaus pvm:',
	'LBL_ASSIGNED_USER_ID' => 'Vastuuhenkilö:',
    'LBL_ASSIGNED_USER_NAME' => 'Vastuuhenkilö:',
	'LBL_MODIFIED_USER_ID' => 'Muokkaaja:',
	'LBL_CREATED_BY' => 'Tekijä:',
	'LBL_TEAM_ID' => 'Tiimi:',
	'LBL_NAME' => 'Nimi:',
    'LBL_PDF_PROJECT_NAME' => 'Projektin Nimi:',
	'LBL_DESCRIPTION' => 'Kuvaus:',
	'LBL_DELETED' => 'Poistetti:',
    'LBL_DATE' => 'Pvm:',
	'LBL_DATE_START' => 'Aloitus pvm:',
	'LBL_DATE_END' => 'Lopetus pvm:',
	'LBL_PRIORITY' => 'Prioriteetti:',
    'LBL_STATUS' => 'Tila:',
    'LBL_MY_PROJECTS' => 'Omat projektit',
    'LBL_MY_PROJECT_TASKS' => 'Omat projektitehtävät',
    
	'LBL_TOTAL_ESTIMATED_EFFORT' => 'Arvioidut kokonaistunnit:',
	'LBL_TOTAL_ACTUAL_EFFORT' => 'Toteutuneet kokonaistunnit:',

	'LBL_LIST_NAME' => 'Nimi',
    'LBL_LIST_DAYS' => 'päivää',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Vastuuhenkilö',
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Arvioidut kokonaistunnit',
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Toteutuneet kokonaistunnit',
    'LBL_LIST_UPCOMING_TASKS' => 'Tulevat tehtävät (1 viikko)',
    'LBL_LIST_OVERDUE_TASKS' => 'Myöhästyneet tehtävät',
    'LBL_LIST_OPEN_CASES' => 'Avoimet palvelupyynnöt',
    'LBL_LIST_END_DATE' => 'Lopetus pvm',
    'LBL_LIST_TEAM_ID' => 'Tiimi',
    

	'LBL_PROJECT_SUBPANEL_TITLE' => 'Projektit',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Projektitehtävät',
	'LBL_CONTACT_SUBPANEL_TITLE' => 'Kontaktit',
	'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Asiakkaat',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
	'LBL_QUOTE_SUBPANEL_TITLE' => 'Tarjouspyynnöt',

    // quick create label
    'LBL_NEW_FORM_TITLE' => 'Uusi projekti',

	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Haluatko varmasti poistaa kontaktin projektista?',

	'LNK_NEW_PROJECT'	=> 'Luo projekti',
	'LNK_PROJECT_LIST'	=> 'Projektit',
	'LNK_NEW_PROJECT_TASK'	=> 'Luo projektitehtävä',
	'LNK_PROJECT_TASK_LIST'	=> 'Projektitehtävät',
	
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projektit',
	'LBL_ACTIVITIES_TITLE'=>'Aktiviteetit',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktiviteetit',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
	'LBL_QUICK_NEW_PROJECT'	=> 'Uusi projekti',
	
	'LBL_PROJECT_TASKS_SUBPANEL_TITLE' => 'Projektitehtävät',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktit',
	'LBL_ACCOUNTS_SUBPANEL_TITLE' => 'Asiakkaat',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Myyntimahdollisuudet',
    'LBL_CASES_SUBPANEL_TITLE' => 'Palvelupyynnöt',
    'LBL_BUGS_SUBPANEL_TITLE' => 'Bugit',
    'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Tuotteet',
    

    'LBL_TASK_ID' => 'ID',
    'LBL_TASK_NAME' => 'Tehtävän nimi',
    'LBL_DURATION' => 'Kesto',
    'LBL_ACTUAL_DURATION' => 'Todellinen kesto',
    'LBL_START' => 'Aloita',
    'LBL_FINISH' => 'Lopeta',
    'LBL_PREDECESSORS' => 'Edeltäjät',
    'LBL_PERCENT_COMPLETE' => '% valmiina',
    'LBL_MORE'  => 'lisää...',

    'LBL_PERCENT_BUSY' => '% varattu',
    'LBL_TASK_ID_WIDGET' => 'id',
    'LBL_TASK_NAME_WIDGET' => 'kuvaus',
    'LBL_DURATION_WIDGET' => 'kesto',
    'LBL_START_WIDGET' => 'aloitus pvm',
    'LBL_FINISH_WIDGET' => 'lopetus pvm',
    'LBL_PREDECESSORS_WIDGET' => 'edeltäjät_',
    'LBL_PERCENT_COMPLETE_WIDGET' => 'prosenttia valmiina',
    'LBL_EDIT_PROJECT_TASKS_TITLE'=> 'Muokkaa projektitehtävää',
    
    'LBL_OPPORTUNITIES' => 'Myyntimahdollisuudet',
	'LBL_LAST_WEEK' => 'Edellinen',
	'LBL_NEXT_WEEK' => 'Seuraava',
	'LBL_PROJECTRESOURCES_SUBPANEL_TITLE' => 'Projektin resurssit',
	'LBL_PROJECTTASK_SUBPANEL_TITLE' => 'Projektitehtävä',
	'LBL_HOLIDAYS_SUBPANEL_TITLE' => 'Loma-ajat',
	'LBL_PROJECT_INFORMATION' => 'Projektin esikatselu',
);
?>