<?php
/********************************************************************************* 
 * : fi_fi.lang.php,version 11.1.2008 msuominen Exp $
 * Description:  Finnish language pack for SugarCRM 5.0 
 * This language pack is original work (not derived)
 * Author:    Markku Suominen, markku.suominen@antamis.com
 * Web:       http://www.antamis.fi, http;//www.antamis.com, crm@antamis.com
 * Copyright: Copyright (C) 2004 - 2008 Markku Suominen / Antamis Finland Oy. 
 * All Rights Reserved.
 * License : GNU General Public License version 3
 **********************************************************************************/
$mod_strings = array(
'LBL_TEAM'=>'Tiimi',



);
