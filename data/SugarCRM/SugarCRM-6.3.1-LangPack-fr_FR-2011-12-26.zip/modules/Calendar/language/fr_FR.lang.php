<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * Contributor(s): www.synolia.com - sugar@synolia.com
 * You can contact SYNOLIA at 51 avenue Jean Jaures 69007 - LYON FRANCE
 * or at email address contact@synolia.com.
 ********************************************************************************/














$mod_strings = array (
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINS_ABBREV' => 'm',
  'LBL_INFO_DESC' => 'Description',
  'LBL_MODULE_NAME' => 'Calendrier',
  'LBL_MODULE_TITLE' => 'Calendrier',
  'LNK_NEW_CALL' => 'Planifier Appel',
  'LNK_NEW_MEETING' => 'Planifier Réunion',
  'LNK_NEW_APPOINTMENT' => 'Planifier Rendez-vous',
  'LNK_NEW_TASK' => 'Créer Tâche',
  'LNK_CALL_LIST' => 'Appels',
  'LNK_MEETING_LIST' => 'Réunions',
  'LNK_TASK_LIST' => 'Tâches',
  'LNK_VIEW_CALENDAR' => 'Aujourd&#39;hui',
  'LNK_IMPORT_CALLS' => 'Import des Appels',
  'LNK_IMPORT_MEETINGS' => 'Import des Réunions',
  'LNK_IMPORT_TASKS' => 'Import des Tâches',
  'LBL_MONTH' => 'Mois',
  'LBL_DAY' => 'Jour',
  'LBL_YEAR' => 'Année',
  'LBL_WEEK' => 'Semaine',
  'LBL_PREVIOUS_MONTH' => 'Mois Précédent',
  'LBL_PREVIOUS_DAY' => 'Jour Précédent',
  'LBL_PREVIOUS_YEAR' => 'Année Précédente',
  'LBL_PREVIOUS_WEEK' => 'Sem. précédente',
  'LBL_NEXT_MONTH' => 'Mois Suivant',
  'LBL_NEXT_DAY' => 'Jour Suivant',
  'LBL_NEXT_YEAR' => 'Année Suivante',
  'LBL_NEXT_WEEK' => 'Sem. suivante',
  'LBL_SCHEDULED' => 'Planifié',
  'LBL_BUSY' => 'Occupé',
  'LBL_CONFLICT' => 'Conflit',
  'LBL_USER_CALENDARS' => 'Calendriers des utilisateurs',
  'LBL_SHARED' => 'Partagé',
  'LBL_PREVIOUS_SHARED' => 'Précédent',
  'LBL_NEXT_SHARED' => 'Suivant',
  'LBL_SHARED_CAL_TITLE' => 'Calendrier partagé',
  'LBL_USERS' => 'Assigné à  ',
  'LBL_REFRESH' => 'Rafraîchir',
  'LBL_EDIT_USERLIST' => 'Liste des Utilisateurs',
  'LBL_SELECT_USERS' => 'Selectionner les utilisateurs à afficher sur le calendrier',
  'LBL_FILTER_BY_TEAM' => 'Filtrer la liste des utilisateurs par Equipe:',
  'LBL_ASSIGNED_TO_NAME' => 'Assigné à',
  'LBL_DATE' => 'Date et Heure de début',
  'LBL_CREATE_MEETING' => 'Planifier Réunion',
  'LBL_CREATE_CALL' => 'Planifier Appel',
  'LBL_YES' => 'Oui',
  'LBL_NO' => 'Non',
  'LBL_SETTINGS' => 'Paramètres',
  'LBL_CREATE_NEW_RECORD' => 'Créer une activité',
  'LBL_LOADING' => 'Chargement .....',
  'LBL_SAVING' => 'Sauvegarde .....',
  'LBL_CONFIRM_REMOVE' => 'Etes vous sûr de vouloir supprimer cet enregistrement ?',
  'LBL_EDIT_RECORD' => 'Editer activité',
  'LBL_ERROR_SAVING' => 'Erreur lors de la sauvegarde',
  'LBL_ERROR_LOADING' => 'Erreur lors du chargement',
  'LBL_GOTO_DATE' => 'Aller à la date',
  'NOTICE_DURATION_TIME' => 'La durée doit être supérieure à 0',
  'LBL_STYLE_BASIC' => 'Basique',
  'LBL_STYLE_ADVANCED' => 'Avancée',
  'LBL_INFO_TITLE' => 'Informations complémentaires',
  'LBL_INFO_START_DT' => 'Date de début',
  'LBL_INFO_DUE_DT' => 'Date d&#39;échéance',
  'LBL_INFO_DURATION' => 'Durée',
  'LBL_INFO_NAME' => 'Sujet',
  'LBL_INFO_RELATED_TO' => 'Relatif à',
  'LBL_NO_USER' => 'Aucune correspondance pour le champ : Assigné à',
  'LBL_SUBJECT' => 'Sujet',
  'LBL_DURATION' => 'Durée',
  'LBL_STATUS' => 'Statut',
  'LBL_DATE_TIME' => 'Date et Heure',
  'LBL_SETTINGS_TITLE' => 'Paramètres',
  'LBL_SETTINGS_TIME_STARTS' => 'Heure début :',
  'LBL_SETTINGS_TIME_ENDS' => 'Heure fin :',
  'LBL_SETTINGS_CALENDAR_STYLE' => 'Style du Calendrier :',
  'LBL_SETTINGS_CALLS_SHOW' => 'Voir les appels :',
  'LBL_SETTINGS_TASKS_SHOW' => 'Voir les tâches :',
  'LBL_SAVE_BUTTON' => 'Sauvegarder',
  'LBL_DELETE_BUTTON' => 'Supprimer',
  'LBL_APPLY_BUTTON' => 'Appliquer',
  'LBL_SEND_INVITES' => 'Envoyer Invitations',
  'LBL_CANCEL_BUTTON' => 'Annuler',
  'LBL_CLOSE_BUTTON' => 'Clôturer',
  'LBL_GENERAL_TAB' => 'Détails',
  'LBL_PARTICIPANTS_TAB' => 'Participants',
);

