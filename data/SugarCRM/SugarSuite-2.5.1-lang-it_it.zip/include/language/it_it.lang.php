<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.131 2005/03/01 20:06:41 lzammarchi Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

//the left value is the key stored in the db and the right value is the display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array (
//e.g. auf Deutsch 'Contacts'=>'Contakten',
  'moduleList' =>
  array (
    'Home' => 'Home',
    'Dashboard' => 'Dashboard',
    'Contacts' => 'Contatti',
    'Accounts' => 'Aziende',
    'Opportunities' => 'Opportunit&#224;',
    'Cases' => 'Casi',
    'Notes' => 'Note',
    'Calls' => 'Chiamate',
    'Emails' => 'Email',
    'Meetings' => 'Meeting',
    'Tasks' => 'Attivit&#224;',
    'Calendar' => 'Calendario',
    'Leads' => 'Lead',





    'Activities' => 'Attivit&#224;',
    'Bugs' => 'Tracker Problemi',
    'Feeds' => 'RSS',
    'iFrames'=>'Il Mio Portale'
  ),
  //e.g. en fran�ais 'Analyst'=>'Analyste',
  'account_type_dom' =>
  array (
    '' => '',
    'Analyst' => 'Analista',
    'Competitor' => 'Concorrente',
    'Customer' => 'Cliente',
    'Integrator' => 'Integratore',
    'Investor' => 'Investitore',
    'Partner' => 'Partner',
    'Press' => 'Stampa',
    'Prospect' => 'Prospect',
    'Reseller' => 'Rivenditore',
    'Other' => 'Altro',
  ),
  //e.g. en espa�ol 'Apparel'=>'Ropa',
  'industry_dom' =>
  array (
    '' => '',
    'Apparel' => 'Tessile',
    'Banking' => 'Bancario',
    'Biotechnology' => 'Biotecnologia',
    'Chemicals' => 'Chimico',
    'Communications' => 'Communicazione',
    'Construction' => 'Costruzioni',
    'Consulting' => 'Consulenza',
    'Education' => 'Educazione',
    'Electronics' => 'Elettronica',
    'Energy' => 'Energia',
    'Engineering' => 'Ingegneria',
    'Entertainment' => 'Cultura',
    'Environmental' => 'Ambiente',
    'Finance' => 'Finanza',
    'Government' => 'Pubblica Amministrazione',
    'Healthcare' => 'Sanit&#224;',
    'Hospitality' => 'Ospedaliero',
    'Insurance' => 'Assicurazioni',
    'Machinery' => 'Industria Compon.',
    'Manufacturing' => 'Manufatturiero',
    'Media' => 'Media',
    'Not For Profit' => 'No Profit',
    'Recreation' => 'Svago',
    'Retail' => 'Dettaglio',
    'Shipping' => 'Transporti',
    'Technology' => 'Tecnologia',
    'Telecommunications' => 'Telecommunicazioni',
    'Transportation' => 'Viaggi & Turismo',
    'Utilities' => 'Servizi & Utility',
    'Other' => 'Altro',
  ),
  'lead_source_dom' =>
  array (
    '' => '',
    'Cold Call' => 'Chiamata non preventivata',
    'Existing Customer' => 'Cliente esistente',
    'Self Generated' => 'Auto Generata',
    'Employee' => 'Dipendente',
    'Partner' => 'Partner',
    'Public Relations' => 'Pubbliche Relazione',
    'Direct Mail' => 'Direct Mailing',
    'Conference' => 'Conferenza',
    'Trade Show' => 'Trade Show',
    'Web Site' => 'Web Site',
    'Word of mouth' => 'Passa Parola',
    'Other' => 'Altro',
  ),
  'opportunity_type_dom' =>
  array (
    '' => '',
    'Existing Business' => 'Business Esistente',
    'New Business' => 'Nuovo Business',
  ),
  //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
  'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
  'opportunity_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Decision Maker Principale',
    'Business Decision Maker' => 'Decision Maker Business',
    'Business Evaluator' => 'Consulente di Business',
    'Technical Decision Maker' => 'Decision Maker Tecnico',
    'Technical Evaluator' => 'Consulente Tecnico',
    'Executive Sponsor' => 'Sponsor',
    'Influencer' => 'Esercita influenza',
    'Other' => 'Altro',
  ),
  //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
  'case_relationship_type_default_key' => 'Primary Contact',
  'case_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Contact' => 'Contatto Principale',
    'Alternate Contact' => 'Altro Contatto',
  ),
  'sales_stage_dom' =>
  array (
    'Prospecting' => 'Prospecting',
    'Qualification' => 'Qualificazione',
    'Needs Analysis' => 'Analisi Requisiti',
    'Value Proposition' => 'Proposta di Valore',
    'Id. Decision Makers' => 'Id. Decision Makers',
    'Perception Analysis' => 'Analisi di Percezione',
    'Proposal/Price Quote' => 'Proposta/Offerta Economica',
    'Negotiation/Review' => 'Negoziazione/Esame Proposta',
    'Closed Won' => 'Chiusa Vinta',
    'Closed Lost' => 'Chiusa Persa',
  ),

  'activity_dom' =>
  array (
    'Call' => 'Chiamate',
    'Meeting' => 'Meeting',
    'Task' => 'Attivit&#224;',
    'Email' => 'Email',
    'Note' => 'Note',
  ),
  'salutation_dom' =>
  array (
    '' => '',
    'Mr.' => 'Sig.',
    'Ms.' => 'Sig.ra',
    'Mrs.' => 'Sig.ra',
    'Dr.' => 'Dott.',
    'Eng.' => 'Ing.',
    'Prof.' => 'Prof.',
  ),

  'task_priority_default' => 'Media',
  'task_priority_dom' =>
  array (
    'High' => 'Alta',
    'Medium' => 'Media',
    'Low' => 'Bassa',
  ),
  'task_status_default' => 'Not Started',
  'task_status_dom' =>
  array (
    'Not Started' => 'Non Partita',
    'In Progress' => 'In Corso',
    'Completed' => 'Completata',
    'Pending Input' => 'In Attesa di Input',
    'Deferred' => 'Rimandato',
  ),
  'meeting_status_default' => 'Planned',
  'meeting_status_dom' =>
  array (
    'Planned' => 'Pianificato',
    'Held' => 'Confermato',
    'Not Held' => 'Non Confermato',
  ),
  'call_status_default' => 'Held',
  'call_status_dom' =>
  array (
    'Planned' => 'Pianificata',
    'Held' => 'Confermata',
    'Not Held' => 'Non Confermata',
  ),
  'call_direction_default' => 'Outbound',
  'call_direction_dom' =>
  array (
    'Inbound' => 'Ricevuta',
    'Outbound' => 'In Uscita',
  ),
  'lead_status_dom' =>
  array (
    '' => '',
    'New' => 'Nuovo',
    'Assigned' => 'Assegnato',
    'In Process' => 'In Corso',
    'Converted' => 'Convertito',
    'Recycled' => 'Riciclato',
    'Dead' => 'Perduto',
  ),
  'lead_status_noblank_dom' =>
  array (
    'New' => 'Nuovo',
    'Assigned' => 'Assegnato',
    'In Process' => 'In Corso',
    'Converted' => 'Convertito',
    'Recycled' => 'Riciclato',
    'Dead' => 'Perduto',
  ),
  //Note:  do not translate case_status_default_key
//       it is the key for the default case_status_dom value
  'case_status_default_key' => 'New',
  'case_status_dom' =>
  array (
    'New' => 'Nuovo',
    'Assigned' => 'Assegnato',
    'Closed' => 'Chiuso',
    'Pending Input' => 'In Attesa di Input',
    'Rejected' => 'Respinto',
    'Duplicate' => 'Duplicato',
  ),
  'case_priority_default_key' => 'P2',
  'case_priority_dom' =>
  array (
    'P1' => 'Alta',
    'P2' => 'Media',
    'P3' => 'Bassa',
  ),
  'user_status_dom' =>
  array (
    'Active' => 'Attivo',
    'Inactive' => 'Non Attivo',
  ),
  //Note:  do not translate record_type_default_key
//       it is the key for the default record_type_module value
  'record_type_default_key' => 'Accounts',
  'record_type_display' =>
  array (
    'Accounts' => 'Azienda',
    'Opportunities' => 'Opportunit&#224;',
    'Cases' => 'Caso',
    'Leads' => 'Lead',




    'Bugs' => 'Bug',
  ),

  'record_type_display_notes' =>
  array (
    'Accounts' => 'Account',
    'Opportunities' => 'Opportunit##224;',
    'Cases' => 'Caso',
    'Leads' => 'Lead',




    'Bugs' => 'Bug',
    'Emails' => 'Email',
  ),







































  'quote_type_dom' =>
  array (
    'Quotes' => 'Offerta',
    'Orders' => 'Ordine',
  ),
  'default_quote_stage_key' => 'Draft',
  'quote_stage_dom' =>
  array (
    'Draft' => 'Bozza',
    'Negotiation' => 'Negoziazione',
    'Delivered' => 'Emesso',
    'On Hold' => 'In Pausa',
    'Confirmed' => 'Confermato',
    'Closed Accepted' => 'Chiuso Accettato',
    'Closed Lost' => 'Chiuso Perduto',
    'Closed Dead' => 'Chiuso Perso',
  ),
  'default_order_stage_key' => 'Pending',
  'order_stage_dom' =>
  array (
    'Pending' => 'In Corso',
    'Confirmed' => 'Confermato',
    'On Hold' => 'In Pasusa',
    'Shipped' => 'Spedito',
    'Cancelled' => 'Annullato',
  ),

//Note:  do not translate quote_relationship_type_default_key
//       it is the key for the default quote_relationship_type_dom value
  'quote_relationship_type_default_key' => 'Primary Decision Maker',
  'quote_relationship_type_dom' =>
  array (
    '' => '',
    'Primary Decision Maker' => 'Decision Maker Principale',
    'Business Decision Maker' => 'Decision Maker Business',
    'Business Evaluator' => 'Consulente di Business',
    'Technical Decision Maker' => 'Decision Maker Tecnico',
    'Technical Evaluator' => 'Consulente Tecnico',
    'Executive Sponsor' => 'Sponsor',
    'Influencer' => 'Esercita Influenza',
    'Other' => 'Altro',
  ),
  'layouts_dom' =>
  array (
    'Standard' => 'Standard',
  ),

  'bug_priority_default_key' => 'Medium',
  'bug_priority_dom' =>
  array (
    'Urgent' => 'Urgente',
    'High' => 'Alta',
    'Medium' => 'Media',
    'Low' => 'Bassa',
  ),
   'bug_resolution_default_key' => '',
  'bug_resolution_dom' =>
  array (
  	'' => '',
  	'Accepted' => 'Accettato',
    'Duplicate' => 'Duplicato',
    'Fixed' => 'Corretto',
    'Out of Date' => 'Scaduto',
    'Invalid' => 'Non valido',
    'Later' => 'Ritardo',
  ),
  'bug_status_default_key' => 'New',
  'bug_status_dom' =>
  array (
    'New' => 'Nuovo',
    'Assigned' => 'Assegnato',
    'Closed' => 'Chiuso',
    'Pending' => 'In Corso',
    'Rejected' => 'Rifiutato',
  ),
   'bug_type_default_key' => 'Bug',
  'bug_type_dom' =>
  array (
    'Defect' => 'Difetto',
    'Feature' => 'Caratteristica',
  ),

  'source_default_key' => '',
  'source_dom' =>
  array (
	'' => '',
  	'Internal' => 'Interno',
  	'Forum' => 'Forum',
  	'Web' => 'Web',
  ),

  'product_category_default_key' => '',
  'product_category_dom' =>
  array (
	'' => '',
  	'Accounts' => 'Aziende',
  	'Activities' => 'Attivit&#224;',
  	'Calendar' => 'Calendario',
  	'Calls' => 'Chiamate',
  	'Cases' => 'Casi',
  	'Contacts' => 'Contatti',
  	'Currencies' => 'Valute',
  	'Dashboard' => 'Dashboard',
  	'Emails' => 'Email',
  	'Feeds' => 'Feeds',
  	'Help' => 'Help',
  	'Home' => 'Home',
  	'Leads' => 'Lead',
  	'Meetings' => 'Meeting',
  	'Notes' => 'Note',
  	'Opportunities' => 'Opportunit&#224;',
  	'Quotes' => 'Offerte',
  	'Releases' => 'Release',
  	'Users' => 'Utenti',
  	'Outlook Plugin' => 'Plugin di Outlook',
  	'Upgrade' => 'Aggiorna',
  	'Studio' => 'Studio',
  ),




  'notifymail_sendtype' =>
  array (
    'sendmail' => 'sendmail',
    'SMTP' => 'SMTP',
  ),
  'dom_timezones' => array('-12'=>'(GMT - 12) International Date Line West',
  							'-11'=>'(GMT - 11) Midway Island, Samoa',
  							'-10'=>'(GMT - 10) Hawaii',
  							'-9'=>'(GMT - 9) Alaska',
  							'-8'=>'(GMT - 8) San Francisco',
  							'-7'=>'(GMT - 7) Phoenix',
  							'-6'=>'(GMT - 6) Saskatchewan',
  							'-5'=>'(GMT - 5) New York',
  							'-4'=>'(GMT - 4) Santiago',
  							'-3'=>'(GMT - 3) Buenos Aires',
  							'-2'=>'(GMT - 2) Mid-Atlantic',
  							'-1'=>'(GMT - 1) Azores',
  							'+0'=>'(GMT)',
  							'+1'=>'(GMT + 1) Madrid,Paris,Rome',
  							'+2'=>'(GMT + 2) Athens',
  							'+3'=>'(GMT + 3) Moscow',
  							'+4'=>'(GMT + 4) Kabul',
  							'+5'=>'(GMT + 5) Ekaterinburg',
  							'+6'=>'(GMT + 6) Astana',
  							'+7'=>'(GMT + 7) Bangkok',
  							'+8'=>'(GMT + 8) Perth',
  							'+9'=>'(GMT + 9) Seol',
  							'+10'=>'(GMT + 10) Brisbane',
  							'+11'=>'(GMT + 11) Solomone Is.',
  							'+12'=>'(GMT + 12) Auckland',
  							),
      'dom_cal_month_long'=>array(
                '0'=>"",
                '1'=>"Gennaio",
                '2'=>"Febbraio",
                '3'=>"Marzo",
                '4'=>"Aprile",
                '5'=>"Maggio",
                '6'=>"Giugno",
                '7'=>"Luglio",
                '8'=>"Agosto",
                '9'=>"Settembre",
                '10'=>"Ottobre",
                '11'=>"Novembre",
                '12'=>"Dicembre",
        ),

        'dom_report_types'=>array(
                'tabular'=>'Righe e Colonnes',
                'summary'=>'Sommario',
                'detailed_summary'=>'Sommario Dettagliato',
        ),
        'dom_email_types'=>array(
                'out'=>'Inviato',
                'archived'=>'Archiviato',
                'draft'=>'Bozza',
        ),


);

$app_strings = array (
  'LBL_CHARSET' => 'ISO-8859-1',
  'LBL_BROWSER_TITLE' => 'SugarCRM - Commercial Open Source CRM',
  'LBL_MY_ACCOUNT' => 'Il Mio Account',
  'LBL_ADMIN' => 'Amministra',
  'LBL_LOGOUT' => 'Logout',
  'LBL_SEARCH' => 'Cerca',
  'LBL_LAST_VIEWED' => 'Ultime visualizzazioni',
  'NTC_WELCOME' => 'Benvenuto',
  'NTC_SUPPORT_SUGARCRM' => 'Supporta il progetto open source SugarCRM con una donazione PayPal - &#232; veloce e sicuro!',
  'NTC_NO_ITEMS_DISPLAY' => 'nessuno',
  'LBL_ALT_HOT_KEY' => 'Alt+',
  'LBL_SAVE_BUTTON_TITLE' => 'Salva [Alt+S]',
  'LBL_EDIT_BUTTON_TITLE' => 'Modifica [Alt+E]',
  'LBL_EDIT_BUTTON' => 'Modifica',
  'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplica [Alt+U]',
  'LBL_DUPLICATE_BUTTON' => 'Duplica',
  'LBL_DELETE_BUTTON_TITLE' => 'Cancella [Alt+D]',
  'LBL_DELETE_BUTTON' => 'Cancella',
  'LBL_NEW_BUTTON_TITLE' => 'Crea [Alt+N]',
  'LBL_CHANGE_BUTTON_TITLE' => 'Cambia [Alt+G]',
  'LBL_CANCEL_BUTTON_TITLE' => 'Annulla [Alt+X]',
  'LBL_SEARCH_BUTTON_TITLE' => 'Cerca [Alt+Q]',
  'LBL_CLEAR_BUTTON_TITLE' => 'Pulisci [Alt+C]',
  'LBL_SELECT_BUTTON_TITLE' => 'Seleziona [Alt+T]',
  'LBL_SAVE_BUTTON_KEY' => 'S',
  'LBL_EDIT_BUTTON_KEY' => 'E',
  'LBL_DUPLICATE_BUTTON_KEY' => 'U',
  'LBL_DELETE_BUTTON_KEY' => 'D',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_CHANGE_BUTTON_KEY' => 'G',
  'LBL_CANCEL_BUTTON_KEY' => 'X',
  'LBL_SEARCH_BUTTON_KEY' => 'Q',
  'LBL_CLEAR_BUTTON_KEY' => 'C',
  'LBL_SELECT_BUTTON_KEY' => 'T',
  'LBL_SAVE_BUTTON_LABEL' => 'Salva',
  'LBL_EDIT_BUTTON_LABEL' => 'Modifica',
  'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplica',
  'LBL_DELETE_BUTTON_LABEL' => 'Cancella',
  'LBL_NEW_BUTTON_LABEL' => 'Crea',
  'LBL_CHANGE_BUTTON_LABEL' => 'Cambia',
  'LBL_CANCEL_BUTTON_LABEL' => 'Annulla',
  'LBL_SEARCH_BUTTON_LABEL' => 'Cerca',
  'LBL_CLEAR_BUTTON_LABEL' => 'Pulisci',
  'LBL_NEXT_BUTTON_LABEL' => 'Successivo',
  'LBL_SELECT_BUTTON_LABEL' => 'Seleziona',
  'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Seleziona Contatto [Alt+T]',
  'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
  'LBL_VIEW_PDF_BUTTON_LABEL' => 'Stampa come PDF',
  'LBL_VIEW_PDF_BUTTON_TITLE' => 'Stampa come PDF [Alt+P]',
  'LBL_VIEW_PDF_BUTTON_KEY' => 'P',
  'LBL_QUOTE_TO_OPPORTUNITY_LABEL' => 'Crea Opportunit&#224; da un\'Offerta',
  'LBL_QUOTE_TO_OPPORTUNITY_TITLE' => 'Crea Opportunit&#224; da un\'Offerta [Alt+O]',
  'LBL_QUOTE_TO_OPPORTUNITY_KEY' => 'O',
  'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Seleziona Contatto',
  'LBL_SELECT_USER_BUTTON_TITLE' => 'Seleziona Utente [Alt+U]',
  'LBL_SELECT_USER_BUTTON_KEY' => 'U',
  'LBL_SELECT_USER_BUTTON_LABEL' => 'Seleziona Utente',
  'LBL_CREATE_BUTTON_LABEL' => 'Crea',
  'LBL_SHORTCUTS' => 'Azioni Veloci',
  'LBL_LIST_NAME' => 'Nome',



  'LBL_LIST_USER_NAME' => 'Nome Utente',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_CONTACT_NAME' => 'Nome Contatto',
  'LBL_LIST_CONTACT_ROLE' => 'Ruolo Contatto',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Account',
  'LBL_USER_LIST' => 'Lista Utenti',
  'LBL_CONTACT_LIST' => 'Lista Contatti',
  'LBL_RELATED_RECORDS' => 'Record Collegati',
  'LBL_MASS_UPDATE' => 'Aggiornamento di Massa',
  'LNK_ADVANCED_SEARCH' => 'Avanzata',
  'LNK_BASIC_SEARCH' => 'Normale',
  'LNK_EDIT' => 'modifica',
  'LNK_REMOVE' => 'elimina',
  'LNK_DELETE' => 'cancella',
  'LNK_LIST_START' => 'Inizio',
  'LNK_LIST_NEXT' => 'Successivo',
  'LNK_LIST_PREVIOUS' => 'Precedente',
  'LNK_LIST_END' => 'Fine',
  'LBL_LIST_OF' => 'di',
  'LBL_OR' => 'O',
  'LBL_BY' => 'da',
  'LNK_PRINT' => 'Stampa',
  'LNK_HELP' => 'Guida',
  'LNK_ABOUT' => 'Informazioni',
  'NTC_REQUIRED' => 'Indica che il campo &#232; richiesto',
  'LBL_REQUIRED_SYMBOL' => '*',
  'LBL_CURRENCY_SYMBOL' => '$',
  'LBL_PERCENTAGE_SYMBOL' => '%',
  'LBL_THOUSANDS_SYMBOL' => 'K',
  'NTC_YEAR_FORMAT' => '(aaaa)',
  'NTC_DATE_FORMAT' => '(aaaa-mm-gg)',
  'NTC_TIME_FORMAT' => '(24:00)',
  'NTC_DATE_TIME_FORMAT' => '(aaaa-mm-gg 24:00)',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'ERR_DELETE_RECORD' => 'Il numero di un record deve essere specificato per cancellare il contatto.',
  'ERR_CREATING_TABLE' => 'Errore nella creazione della tabella: ',
  'ERR_CREATING_FIELDS' => 'Errore nel riempimento di dettagli nei campi aggiuntivi: ',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Campi richiesti mancanti:',
  'ERR_INVALID_EMAIL_ADDRESS' => 'indirizzo email non valido.',
  'ERR_INVALID_DATE_FORMAT' => 'Il formato della data deve essere: aaaa-mm-gg',
  'ERR_INVALID_MONTH' => 'Per favore inserisci un mese valido.',
  'ERR_INVALID_DAY' => 'Per favore inserisci un giorno valido.',
  'ERR_INVALID_YEAR' => 'Per favore inserici un anno a 4 cifre.',
  'ERR_INVALID_DATE' => 'Per favore inserici una data valida.',
  'ERR_INVALID_HOUR' => 'Per favore inserici un\'ora valida.',
  'ERR_INVALID_TIME' => 'Per favore inserici un\'ora valida.',
  'ERR_INVALID_AMOUNT' => 'Per favore inserici un importo corretto.',
  'NTC_CLICK_BACK' => 'Per favore clicca il bottone indietro del browser e correggi l\'errore.',
  'LBL_LIST_ASSIGNED_USER' => 'Utente',
  'LBL_ASSIGNED_TO' => 'Assegnato a:',
  'LBL_DATE_MODIFIED' => 'Ultima Modifica:',
  'LBL_DATE_ENTERED' => 'Crea:',
  'LBL_CURRENT_USER_FILTER' => 'Solo I Miei:',
  'NTC_LOGIN_MESSAGE' => 'Per favore inserisci la tua username e password.',
  'LBL_NONE' => '--Nessuno--',
  'LBL_BACK' => 'Indietro',
  'LBL_IMPORT' => 'Importa',
  'LBL_EXPORT' => 'Esporta',
  'LBL_EXPORT_ALL' => 'Esporta Tutti',
  'LBL_SAVE_NEW_BUTTON_TITLE' => 'Salva & Crea Nuovo [Alt+V]',
  'LBL_SAVE_NEW_BUTTON_KEY' => 'V',
  'LBL_SAVE_NEW_BUTTON_LABEL' => 'Salva & Crea Nuovo',
  'LBL_NAME' => 'Nome',



  'LBL_CHECKALL' => 'Controlla Tutti',
  'LBL_CLEARALL' => 'Cancella Tutti',
  'LBL_SUBJECT' => 'Oggeto',
  'LBL_ENTER_DATE' => 'Inserisci Data',
  'LBL_CREATED' => 'Creato Da',
  'LBL_MODIFIED' => 'Modificato Da',
  'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Componi Email [Alt+E]',
  'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'E',
  'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Componi Email',
  'ERR_OPPORTUNITY_NAME_MISSING' => 'Il nome dell\'opportinit&#224; non � stata inserita.  Please enter an opportunity name below.',
  'ERR_OPPORTUNITY_NAME_DUPE' => 'Un\'opportinit&#224; con questo nome esiste gi&#224;.  Per favore usa sotto un altro nome.',
  'LBL_OPPORTUNITY_NAME' => 'Nome Opportinit&#224;',
  'LBL_DELETE' => 'Elimina',
  'LBL_UPDATE' => 'Aggiorna',
);

?>
