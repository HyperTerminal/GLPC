<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): 
 ********************************************************************************/
 /*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Amministrazione',
	'LBL_MODULE_TITLE' => 'Amministrazione: Home',
	'LBL_NEW_FORM_TITLE' => 'Crea Account',
	'LNK_NEW_USER' => 'Crea Utente',
	'ERR_DELETE_RECORD' => 'Devi specficare il numero del record per cancellare l\'account.',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Configurazione',
	'LBL_CONFIGURE_SETTINGS' => 'Configura le impostazioni del sistema',
	'LBL_UPGRADE_TITLE' => 'Aggiorna',
	'LBL_UPGRADE' => 'Aggiorna Suite Sugar',
	'LBL_MANAGE_USERS_TITLE' => 'Gestione Utenti',
	'LBL_MANAGE_USERS' => 'Gestione account utenti e password',
	'LBL_ADMINISTRATION_HOME_TITLE' => 'Sistema',
	'LBL_NOTIFY_TITLE' => 'Opzioni di Notfica E-mail',
	'LBL_NOTIFY_FROMADDRESS' => 'Indirizzo "Mittente":',
	'LBL_MAIL_SMTPSERVER' => 'Server SMTP:',
	'LBL_MAIL_SMTPPORT' => 'Porta SMTP:',
	'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
	'LBL_MAIL_SMTPUSER' => 'Username SMTP:',
	'LBL_MAIL_SMTPPASS' => 'Password SMTP:',
	'LBL_MAIL_SMTPAUTH_REQ' => 'Usa Autentificazione SMTP?',
	'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Invia notifiche per default?',
	'LBL_NOTIFY_SUBJECT' => 'Oggetto E-mail:',
	'LBL_NOTIFY_ON' => 'Notifiche Attive?',
	'LBL_NOTIFY_FROMNAME' => 'Nome "Mittente":',
	'LBL_CURRENCY' => 'Impostazione Valute e Tassi di conversione',
	'LBL_RELEASE' => 'Gestione release e versioni',
	'LBL_LAYOUT' => 'Aggiungi, rimuovi e cambia campi, il layout dei campi e i pannelli nell\'applicazione',
	'LBL_MANAGE_CURRENCIES' => 'Valute',
	'LBL_MANAGE_RELEASES' => 'Release',
	'LBL_MANAGE_LAYOUT' => 'Layout Campi',
	'LBL_MANAGE_OPPORTUNITIES' => 'Opportunit&#224;',
	'LBL_UPGRADE_CURRENCY' => 'Aggiorna importi valuta in ',
	'LBL_BACKUP' => 'Backup',
	'DESC_BACKUP' => 'Backup della tua applicazione Sugar e del database',
	'LBL_CUSTOMIZE_FIELDS' => 'Personalizza Campi',
	'DESC_CUSTOMIZE_FIELDS' => 'Personalizza le etichette dei campi in tutte le lingue disponibili',
	'LBL_DROPDOWN_EDITOR' => 'Editor Dropdown',
	'DESC_DROPDOWN_EDITOR' => 'Aggiungi, rimuovi, cambia gli elenchi dropdown nell\'applicazione',
	'LBL_IFRAME'=> 'Portale',
	'DESC_IFRAME' => 'Aggiungi le tabs che puoi visualizzare in ogni sito web',
	'LBL_BUG_TITLE' => 'Tracker Problemi',
	'LBL_TIMEZONE' => 'Time Zone',
	'LBL_STUDIO_TITLE' => 'Studio',
	'LBL_CONFIGURE_TABS' => 'Configura Tabs',
	'LBL_CHOOSE_WHICH'=>'Scegli quali tab devono essere visualizzate nel sistema',
	'LBL_DISPLAY_TABS'=>'Visualizza Tabs',
	'LBL_HIDE_TABS'=>'Nascondi Tabs',
	'LBL_EDIT_TABS'=>'Modifica Tabs',
	'LBL_UPGRADE_DB_TITLE' => 'Aggiorna database',
	'LBL_UPGRADE_DB' => 'Aggiorna il formato del database dalla versione 2.0.x alla 2.5 ',
	'LBL_UPGRADE_DB_BEGIN' => 'Inizia Aggiornamento',
	'LBL_UPGRADE_DB_COMPLETE' => 'Aggiornamento Completo',
	'LBL_UPGRADE_VERSION'=>'Aggiornamento informazioni di versione',
	'LBL_UPGRADE_DB_FAIL' => 'Aggiornamento Fallito',
	'LBL_PORTAL_TITLE' => 'Portale Self-Service Clienti',
	'LBL_PORTAL_ON' => 'Abilita l\'integrazione del Portale Self-Service',
	'LBL_PORTAL_ON_DESC' => 'Permette la pubblicazione di casi, note e altri dati per essere accedibile all\'esterno dai clienti.',
	'LBL_NOTIFICATION_ON_DESC' => 'Invia notifiche via email quando record sono assegnati.',
	'LBL_UPGRADE_CONFIG_TITLE' => 'Aggiorna file di configurazione',
	'LBL_UPGRADE_CONFIG' => 'Aggiorna il file di configurazione per memorizzare le variabili in una matrice.',
	'BTN_PERFORM_UPGRADE' => 'Effettua Aggiornamento',
	'LBL_PERFORM_UPGRADE' => 'Aggiorna Configurazione',
	'LBL_CONFIG_CHECK' => 'Controlla configurazione',
	'MSG_CONFIG_FILE_UP_TO_DATE' => 'Il tuo file di configurazione &#232; aggiornato all\'ultima versione.',
	'MSG_CONFIG_FILE_READY_FOR_UPGRADE' => 'La tua vecchia configurazione &#232; pronta per l\'aggiornamento.  E\' altamente consigliato effettuare un backup della configurazione .php prima di effettuare l\'aggiornamento.',
	'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'Per favore rendi il tuo file di configurazione scrivibile in modo che la configurazione possa essere aggiornata all\'ultimo formato.',
	'MSG_CONFIG_FILE_UPGRADE_SUCCESS' => 'Il tuo file di configurazione &#232; stato aggiornato con successo.',
	'MSG_CONFIG_FILE_UPGRADE_FAILED' => 'Impossible aggiornare il tuo file di configurazione.',
	'LBL_UPGRADE_DROPDOWN' => 'Aggiorna le liste dropdown per supportare il nuovo formato di lingua ',
	'LBL_UPGRADE_DROPDOWN_TITLE' => 'Aggiorna dropdown',
	'LBL_ALLOW_USER_TABS' => 'Permetti agli utenti di configurare le tab',





































);
?>
