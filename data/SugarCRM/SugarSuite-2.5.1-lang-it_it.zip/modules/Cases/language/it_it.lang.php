<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Casi',
  'LBL_MODULE_TITLE' => 'Casi: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Casi',
  'LBL_LIST_FORM_TITLE' => 'Lista Casi',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Caso',
  'LBL_CONTACT_CASE_TITLE' => 'Contatto-Caso:',
  'LBL_SUBJECT' => 'Oggetto:',
  'LBL_CASE' => 'Caso:',
  'LBL_CASE_NUMBER' => 'Numero Caso:',
  'LBL_NUMBER' => 'Numero:',
  'LBL_STATUS' => 'Stato:',
  'LBL_PRIORITY' => 'Priorit&#224;:',
  'LBL_ACCOUNT_NAME' => 'Nome Azienda:',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_RESOLUTION' => 'Risoluzione:',
  'LBL_CONTACT_NAME' => 'Nome Contatto:',
  'LBL_CASE_SUBJECT' => 'Oggetto Caso:',
  'LBL_CONTACT_ROLE' => 'Ruolo:',
  'LBL_LIST_NUMBER' => 'Num.',
  'LBL_LIST_SUBJECT' => 'Oggetto',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda',
  'LBL_LIST_STATUS' => 'Stato',
  'LBL_LIST_PRIORITY' => 'Priorit&#224;',
  'LBL_LIST_LAST_MODIFIED' => 'Ultima Modifica',
  'LBL_INVITEE' => 'Contatti',
  'LNK_NEW_CASE' => 'Crea Caso',
  'LNK_CASE_LIST' => 'Casi',
  'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler rimuovere il contatto da questo caso?',
  'ERR_DELETE_RECORD' => 'Il numero del record deve essere specificato per cancellare l\'azienda.',
  'NTC_REMOVE_FROM_BUG_CONFIRMATION' => 'Sei sicuro di volere rimuovere questo caso dal problema?',
  'LBL_LIST_CLOSE' => 'Chiudi',
  'LBL_LIST_MY_CASES' => 'I Miei Casi Aperti',

);


?>
