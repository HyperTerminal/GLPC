<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Release',
  'LBL_MODULE_TITLE' => 'Release: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Release',
  'LBL_LIST_FORM_TITLE' => 'Lista Release',
  'LBL_NEW_FORM_TITLE' => 'Nuova Release',
  'LBL_RELEASE' => 'Release:',
  'LBL_LIST_NAME' => 'Release',
  'LBL_NAME' => 'Versione Release :',
  'LBL_LIST_LIST_ORDER' => 'Ordine',
  'LBL_LIST_ORDER' => 'Ordine:',
  'LBL_LIST_STATUS' => 'Stato',
  'LBL_STATUS' => 'Stato:',
  'LNK_NEW_RELEASE' => 'Lista Release',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'ERR_DELETE_RECORD' => 'Il numero del record deve essere specificato per cancellare la release.',
  'NTC_STATUS' => 'Imposta lo stato a Non Attivo per rimuovere questa release dalla lista dropdown delle Release',
  'NTC_LIST_ORDER' => 'Imposta l\'ordine di questa release nella lista dropdown delle Release',
  'release_status_dom' =>
  array (
    'Active' => 'Attivo',
    'Inactive' => 'Non Attivo',
  ),
);


?>
