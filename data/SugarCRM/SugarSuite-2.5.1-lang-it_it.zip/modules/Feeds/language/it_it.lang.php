<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'RSS',
  'LBL_MODULE_TITLE' => 'RSS: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Ricerca RSS News Feed',
  'LBL_LIST_FORM_TITLE' => 'Lista RSS News Feed',
  'LBL_MY_LIST_FORM_TITLE' => 'Le RSS News Feeds',
  'LBL_NEW_FORM_TITLE' => 'Nuovo RSS News Feed',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'ERR_DELETE_RECORD' => 'Un numero di record deve essere specificato per cancellare il contatto.',
  'LNK_NEW_FEED' => 'Nuovo RSS News Feed',
  'LNK_FEED_LIST' => 'All RSS News Feeds',
  'LNK_MY_FEED_LIST' => 'Mio RSS News Feeds',
  'LBL_TITLE' => 'Titolo',
  'LBL_RSS_URL' => "URL RSS",
  'LBL_ONLY_MY'=>"Solo I Miei Preferiti",
  'LBL_VISIT_WEBSITE' => 'Visita Sito Web',
  'LBL_LAST_UPDATED' => 'Ultimo Aggiornamento',
  'LBL_DELETE_FAVORITES' =>'Cancella da preferiti',
  'LBL_DELETE_FAV_BUTTON_TITLE' =>'Cancella da preferiti [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' =>'Cancella da preferiti',
  'LBL_ADD_FAV_BUTTON_TITLE' =>'Aggiungi a preferiti [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' =>'[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' =>'Aggiungi a preferiti',
  'LBL_MOVE_UP' =>'Sposta Su',
  'LBL_MOVE_DOWN' => 'Sposta Gi&#249;',
  'LBL_FEED_NOT_AVAILABLE'=>'Feed non disponibile',
);


?>
