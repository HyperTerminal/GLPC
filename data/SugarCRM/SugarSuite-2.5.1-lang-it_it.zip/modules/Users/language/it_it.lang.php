<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Utenti',
  'LBL_MODULE_TITLE' => 'Utenti: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Utente',
  'LBL_LIST_FORM_TITLE' => 'Utenti',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Utente',
  'LBL_USER' => 'Utenti:',
  'LBL_LOGIN' => 'Login',
  'LBL_RESET_PREFERENCES' => 'Ripristina le preferenze di Default',
  'LBL_TIME_FORMAT' => 'Formato Ora:',
  'LBL_DATE_FORMAT' => 'Formato Data:',
  'LBL_TIMEZONE' => 'Ora Corrente:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => 'Cognome',
  'LBL_LIST_USER_NAME' => 'User Name',
  'LBL_LIST_DEPARTMENT' => 'Dipartimento',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Telefono Principale',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_USER_BUTTON_TITLE' => 'Nuovo Utente [Alt+N]',
  'LBL_NEW_USER_BUTTON_LABEL' => 'Nuovo Utente',
  'LBL_NEW_USER_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Errore:',
  'LBL_PASSWORD' => 'Password:',
  'LBL_USER_NAME' => 'User Name:',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_LAST_NAME' => 'Cognome:',
  'LBL_USER_SETTINGS' => 'Impostazioni Utente',
  'LBL_THEME' => 'Tema:',
  'LBL_LANGUAGE' => 'Lingua:',
  'LBL_ADMIN' => 'Amministratore:',
  'LBL_USER_INFORMATION' => 'Informazioni Utente',
  'LBL_OFFICE_PHONE' => 'Telefono Ufficio:',
  'LBL_REPORTS_TO' => 'Riporta A:',
  'LBL_OTHER_PHONE' => 'Altro:',
  'LBL_OTHER_EMAIL' => 'Altra Email:',
  'LBL_NOTES' => 'Note:',
  'LBL_DEPARTMENT' => 'Dipartimento:',
  'LBL_STATUS' => 'Stato:',
  'LBL_TITLE' => 'Titolo:',
  'LBL_ANY_PHONE' => 'Nessun Telefono:',
  'LBL_ANY_EMAIL' => 'Nessuna Email:',
  'LBL_ADDRESS' => 'Indirizzo:',
  'LBL_CITY' => 'Citt&#224;:',
  'LBL_STATE' => 'Provincia:',
  'LBL_POSTAL_CODE' => 'CAP:',
  'LBL_COUNTRY' => 'Nazione:',
  'LBL_NAME' => 'Nome:',
  'LBL_MOBILE_PHONE' => 'Cellulare:',
  'LBL_OTHER' => 'Altro:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Telefono Casa:',
  'LBL_ADDRESS_INFORMATION' => 'Informazioni Indirizzo',
  'LBL_PRIMARY_ADDRESS' => 'Indirizzo Principale:',
  'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Cambia Password [Alt+P]',
  'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
  'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Cambia Password',
  'LBL_LOGIN_BUTTON_TITLE' => 'Login [Alt+L]',
  'LBL_LOGIN_BUTTON_KEY' => 'L',
  'LBL_LOGIN_BUTTON_LABEL' => 'Login',
  'LBL_CHANGE_PASSWORD' => 'Cambia Password',
  'LBL_OLD_PASSWORD' => 'Vecchia Password:',
  'LBL_NEW_PASSWORD' => 'Nuova Password:',
  'LBL_CONFIRM_PASSWORD' => 'Conferma Password:',
  'ERR_ENTER_OLD_PASSWORD' => 'Per favore inserisci la tua vecchia password.',
  'ERR_ENTER_NEW_PASSWORD' => 'Per favore inserisci la tua nuova password.',
  'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Per favore inserisci la conferma della tua password.',
  'ERR_REENTER_PASSWORDS' => 'Per favore reinserisci le password.  La \\"nuova password\\" e la \\"password confermata\\" con coincidono.',
  'ERR_INVALID_PASSWORD' => 'Devi inserire username e password corretti.',
  'ERR_PASSWORD_CHANGE_FAILED_1' => 'Cambio della password non eseguita per ',
  'ERR_PASSWORD_CHANGE_FAILED_2' => ' fallita.  La nuova password deve essere impostata.',
  'ERR_PASSWORD_INCORRECT_OLD' => 'La vecchia password dell\'utente $this->user_name non &#232; valida. Reinserisci la password.',
  'ERR_USER_NAME_EXISTS_1' => 'Username ',
  'ERR_USER_NAME_EXISTS_2' => ' gi&#224; presente. La duplicazione delle username non &#232; permesso. Le username devono essere uniche.',
  'ERR_LAST_ADMIN_1' => 'L\'utente con Username "',
  'ERR_LAST_ADMIN_2' => '" &#232; l\'ultimo amministratore che ha avuto accesso al sistem.  Almeno un utente deve essere amministratore.',
  'LNK_NEW_USER' => 'Crea Utente',
  'LNK_USER_LIST' => 'Utenti',
  'ERR_DELETE_RECORD' => 'Deve essere specificato il numero del record per cancellare l\'account.',
  'LBL_RECEIVE_NOTIFICATIONS' => 'Notifiche Assegnamenti:',
  'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Ricevi una e-mail di notifica quando un record &#232; assegnato all\'utente.',
  'LBL_ADMIN_TEXT' => 'Grants administrator privileges to this user',
  'LBL_PORTAL_ONLY' => 'Utente Solo Portale:',
  'LBL_PORTAL_ONLY_TEXT' => 'Definisce un Utente Portale, l\'utente non pu&#242; effettuare login cpm SugarCRM web interface. This user is only used for portal webservices. Normal users cannot be used for portal webservices.',
  'LBL_TIME_FORMAT_TEXT' => 'Imposta il formato di visualizzazione delle ore',
  'LBL_DATE_FORMAT_TEXT' => 'Imposta il formato di visualizzazione delle date',
  'LBL_TIMEZONE_TEXT' => 'Imposta l\'ora corrente',
  'LBL_GRIDLINE' => 'Mostra Linee nelle Griglie:',
  'LBL_GRIDLINE_TEXT' => 'Mostra nelle viste dei dettagli le linee nelle griglie',
  'LBL_CURRENCY_TEXT' => 'Seleziona la valuta di default',
  'LBL_DISPLAY_TABS'=>'Mostra Tabs',
  'LBL_HIDE_TABS'=>'Nascondi Tabs',
  'LBL_EDIT_TABS'=>'Modifica Tabs',
  'LBL_CHOOSE_WHICH'=>'Scegli quali tab devono essere visualizzate',








  'LBL_MAIL_OPTIONS_TITLE' => 'Opzioni E-mail',
  'LBL_MAIL_FROMNAME' => 'Nome "Mittente":',
  'LBL_MAIL_FROMADDRESS' => 'Indirizzo "Mittente":',
  'LBL_MAIL_SMTPSERVER' => 'Server SMTP:',
  'LBL_MAIL_SMTPPORT' => 'Porta SMTP:',
  'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
  'LBL_MAIL_SMTPUSER' => 'Username SMTP:',
  'LBL_MAIL_SMTPPASS' => 'Password SMTP:',
  'LBL_MAIL_SMTPAUTH_REQ' => 'Autentificazione SMTP?',

);


?>
