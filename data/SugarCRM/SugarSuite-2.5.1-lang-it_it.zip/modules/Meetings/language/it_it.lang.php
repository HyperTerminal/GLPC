<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Meeting',
  'LBL_MODULE_TITLE' => 'Meeting: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Meeting',
  'LBL_LIST_FORM_TITLE' => 'Lista Meeting',
  'LBL_NEW_FORM_TITLE' => 'Pianifica Meeting',
  'LBL_LIST_SUBJECT' => 'Oggetto',
  'LBL_LIST_CONTACT' => 'Nome Contatto',
  'LBL_LIST_RELATED_TO' => 'Riferito a',
  'LBL_LIST_DATE' => 'Data di inizio',
  'LBL_LIST_TIME' => 'Ora di inizio',
  'LBL_LIST_CLOSE' => 'Chiudi',
  'LBL_SUBJECT' => 'Oggetto: ',
  'LBL_STATUS' => 'Stato:',
  'LBL_LOCATION' => 'Luogo:',
  'LBL_DATE_TIME' => 'Date & Ora di Inizio:',
  'LBL_DATE' => 'Data di Inizio:',
  'LBL_TIME' => 'Ora di Inizio:',
  'LBL_DURATION' => 'Durata:',
  'LBL_DURATION_HOURS' => 'Durata Ore:',
  'LBL_DURATION_MINUTES' => 'Durata Minuti:',
  'LBL_HOURS_MINS' => '(ore/minuti)',
  'LBL_CONTACT_NAME' => 'Nome Contatto: ',
  'LBL_MEETING' => 'Meeting:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informazioni Descrittive',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Pianificato',
'LNK_NEW_CALL'=>'Pianifica Chiamata',
'LNK_NEW_MEETING'=>'Pianifica Meeting',
'LNK_NEW_TASK'=>'Crea Attvitit&#224;',
'LNK_NEW_NOTE'=>'Crea Nota o Allegato',
'LNK_NEW_EMAIL'=>'Archivia Email',
'LNK_CALL_LIST'=>'Chiamate',
'LNK_MEETING_LIST'=>'Meeting',
'LNK_TASK_LIST'=>'Attivit&#224;',
'LNK_NOTE_LIST'=>'Note',
'LNK_EMAIL_LIST'=>'Email',

  'LNK_VIEW_CALENDAR' => 'Oggi',
  'ERR_DELETE_RECORD' => 'Il numero del record deve essere specificato per cancellare il meeting.',
  'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler rimuovere questo invito dal meeting?',
  'LBL_INVITEE' => 'Inviti',
  'LNK_NEW_APPOINTMENT' => 'Crea Appuntamento',
);


?>
