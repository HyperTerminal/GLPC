<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/
 
$mod_strings = array (
'LBL_ADVANCED'=> 'Avanzato:',
'DESC_USING_LAYOUT_TITLE' => 'Utilizzo del Editor di Layout',
'DESC_USING_LAYOUT_SHORTCUTS' => 'Azioni Veloci:',
'DESC_USING_LAYOUT_TOOLBAR' => 'Toolbar:',
'DESC_USING_LAYOUT_EDIT_ROWS' => 'Modifica Righe:',
'DESC_USING_LAYOUT_SELECT_FILE' => 'Seleziona File:',
'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Modifica Campi:',
'DESC_USING_LAYOUT_ADD_FIELD' => 'Aggiungi Campo:',
'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Rimuovi oggetto:',
'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Visualizza codice HTML:',
'DESC_USING_LAYOUT_BLK1' => 'L\'editor di Layout editor permette di riorganizzare campi, tabs, e panelli sulle tabs al fine di personalizzare lo schermo secondo le tue necessit&#224;. Seleziona prima la vista che vuoi personalizzare utilizzando l\'azione &#034;Seleziona File&#034;.',
'DESC_USING_LAYOUT_BLK2' => ' permette di selezionare differenti pagine da modificare; modifiche sulla pagina corrente saranno perse se non salvate. Se non sei sicuro quale file da modificare puoi controllare il box �Edit in place�; questo aggiunger� un box edit a tutte le schermate modificabili dell\'azpplicazione. Muoviti all\'interno dell\'applicazione fino alla pagina da modificare, clicca su edit box, e ti verr&#224; visualizzata la schermata da modificare relativa al file.',
'DESC_USING_LAYOUT_BLK3' => ' drag and rearrange individual fields or their labels. Select the item handle ',
'DESC_USING_LAYOUT_BLK4' => ' next to the field or label you want to move, and click on the item handle where you want the field or label located. This will move the item from its previous location to its new location. If there was already a field or label at the destination the two items will swap positions. Moving sub-panels is the same as moving fields; select on the source sub-panel handle and destination handle and the two will switch locations. To remove a field or form from the screen, drag the item to the Toolbox area in the left menu bar.',
'DESC_USING_LAYOUT_BLK5' => ' changes the view to allow the addition and removal of rows in the details panel. Pressing the + adds a row below the one selected, and pressing the � removes that row.',
'DESC_USING_LAYOUT_BLK6' => 'The Toolbox provides a workspace to add new fields and labels to a form, temporarily retain items that have been removed from a form, and discard items.',
'DESC_USING_LAYOUT_BLK7' => ' opens a selection display to specify the type of field you want to add and the label that goes with it. Pressing the Add button puts the new field and its label in the Toolbox workspace. From here the field can be added by selecting the new items handle and the handle for its destination.',
'DESC_USING_LAYOUT_BLK8' => ' is accomplished by selecting its handle and clicking on the text �Drag unwanted items here�. This will deposit the selected item in the Toolbox workspace.',
'DESC_USING_LAYOUT_BLK9' => ' selection field displays the html that comprises each field. While this can be informative it is very CPU intensive, and should only be used when necessary.',
'DESC_USING_LAYOUT_BLK10' => 'To save changes press the �Save Layout� button. To discard changes click on another tab in the application and all changes will be discarded for the page being edited.',
'NO_RECORDS_LISTVIEW'=>'In order to edit a list view there must be at least one row of data.  Please create a record for this list view before attempting to edit.',
);
?>
