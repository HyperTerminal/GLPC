<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Attivit&#224;',
  'LBL_MODULE_TITLE' => 'Attivit&#224;: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Attivit&#224;',
  'LBL_LIST_FORM_TITLE' => 'Lista Attivit&#224;',
  'LBL_LIST_SUBJECT' => 'Oggetto',
  'LBL_LIST_CONTACT' => 'Contatto',
  'LBL_LIST_RELATED_TO' => 'Relativo a',
  'LBL_LIST_DATE' => 'Data',
  'LBL_LIST_TIME' => 'Ora Inizio',
  'LBL_LIST_CLOSE' => 'Chiuso',
  'LBL_SUBJECT' => 'Oggetto:',
  'LBL_STATUS' => 'Stato:',
  'LBL_LOCATION' => 'Localit&#224;:',
  'LBL_DATE_TIME' => 'Data & Ora di Inizio:',
  'LBL_DATE' => 'Data Inizio:',
  'LBL_TIME' => 'Ora Inizio:',
  'LBL_DURATION' => 'Durata:',
  'LBL_HOURS_MINS' => '(ore/minuti)',
  'LBL_CONTACT_NAME' => 'Nome Contatto: ',
  'LBL_MEETING' => 'Meeting:',
  'LBL_DESCRIPTION_INFORMATION' => 'Altro',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Pianificato',
  'LNK_NEW_CALL' => 'Pianifica Chiamata',
  'LNK_NEW_MEETING' => 'Pianifica Meeting',
  'LNK_NEW_TASK' => 'Crea Attivit&#224;',
  'LNK_NEW_NOTE' => 'Crea Nota o Allegato',
  'LNK_NEW_EMAIL' => 'Archivia Email',
  'LNK_CALL_LIST' => 'Chiamate',
  'LNK_MEETING_LIST' => 'Meeting',
  'LNK_TASK_LIST' => 'Attivit&#224',
  'LNK_NOTE_LIST' => 'Note',
  'LNK_EMAIL_LIST' => 'Email',
  'ERR_DELETE_RECORD' => 'Devi specificare un numero record per eliminare l\'account.',
  'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler rimuovere questo invito dal meeting?',
  'LBL_INVITEE' => 'Inviti',
  'LBL_LIST_DIRECTION' => 'Direzioni',
  'LBL_DIRECTION' => 'Direzione',
  'LNK_NEW_APPOINTMENT' => 'Nuovo Appointment',
  'LNK_VIEW_CALENDAR' => 'Oggi',
  'LBL_OPEN_ACTIVITIES' => 'Attivit&#224; Aperte',
  'LBL_HISTORY' => 'Storico',
  'LBL_UPCOMING' => 'I Miei Prossimi Appuntamenti',
  'LBL_TODAY' => 'per ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Crea Attivit&#224; [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Crea Attivit&#224;',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Pianifica Meeting [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Pianifica Meeting',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Pianifica Chiamata [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Pianifica Chiamata',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Crea Nota o Allegato [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Crea Nota o Allegato ',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archivia Email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Archivia Email',
  'LBL_LIST_STATUS' => 'Stato',
  'LBL_LIST_DUE_DATE' => 'Data Prevista',
  'LBL_LIST_LAST_MODIFIED' => 'Ultma Modifica',
  'NTC_NONE_SCHEDULED' => 'Nessuna pianificazione.',
  'appointment_filter_dom' => array(
  	 'today' => 'oggi'
  	,'tomorrow' => 'domani'
  	,'this Saturday' => 'questa settimana'
  	,'next Saturday' => 'prossima settimana'
  	,'last this_month' => 'questo mese'
  	,'last next_month' => 'prossimo mese'
  ),
  'LNK_IMPORT_NOTES'=>'Importa Note',
);


?>
