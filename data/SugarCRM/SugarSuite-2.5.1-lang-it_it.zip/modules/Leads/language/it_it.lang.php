<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Lead',
  'LBL_INVITEE' => 'Direct Report',
  'LBL_MODULE_TITLE' => 'Lead: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Lead',
  'LBL_LIST_FORM_TITLE' => 'Lista Lead',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Lead',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Lead-Opportunit&#224;:',
  'LBL_CONTACT' => 'Lead:',
  'LBL_BUSINESSCARD' => 'Converti Lead',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => 'Cognome',
  'LBL_LIST_CONTACT_NAME' => 'Nome Lead',
  'LBL_LIST_TITLE' => 'Titolo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_CONTACT_ROLE' => 'Ruolo',
  'LBL_LIST_FIRST_NAME' => 'Nome',
  'LBL_LIST_REFERED_BY' => 'Riportato Da',
  'LBL_LIST_LEAD_SOURCE' => 'Fonte Lead',
  'LBL_LIST_STATUS' => 'Stato',
  'LBL_LIST_DATE_ENTERED' => 'Data Creazione',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Descrizione Fonte Lead',
  'LBL_LIST_MY_LEADS' => 'I Miei Lead',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Utilizzato un contatto esistente',
  'LBL_CREATED_CONTACT' => 'Creato un nuovo contatto',
  'LBL_EXISTING_OPPORTUNITY' => 'Utilizzata una opportunit&#224; esistente',
  'LBL_CREATED_OPPORTUNITY' => 'Crea una nuova opportunit&#224;',
  'LBL_EXISTING_ACCOUNT' => 'Utilizzato un\'azienda esistente',
  'LBL_CREATED_ACCOUNT' => 'Creata una nuova azienda',
  'LBL_CREATED_CALL' => 'Creata una nuova chiamata',
  'LBL_CREATED_MEETING' => 'Creato un nuovo meeting',
  'LBL_BACKTOLEADS' => 'Torna ai Lead',
  'LBL_CONVERTLEAD' => 'Converti Lead',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome Lead:',
  'LBL_CONTACT_INFORMATION' => 'Informazioni Lead',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_OFFICE_PHONE' => 'Telefono Ufficio:',
  'LBL_ACCOUNT_NAME' => 'Nome Azienda:',
  'LBL_OPPORTUNITY_NAME' => 'Nome Opportunit&#224;:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Valore Opportunit&#224;:',
  'LBL_ANY_PHONE' => 'Nessun Telefono:',
  'LBL_PHONE' => 'Telefono:',
  'LBL_LAST_NAME' => 'Cognome:',
  'LBL_MOBILE_PHONE' => 'Cellulare:',
  'LBL_HOME_PHONE' => 'Home:',
  'LBL_LEAD_SOURCE' => 'Fonte Lead:',
  'LBL_STATUS' => 'Stato:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Descrizione Fonte Lead:',
  'LBL_STATUS_DESCRIPTION' => 'Descrizione Stato:',
  'LBL_OTHER_PHONE' => 'Altro Telefono:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Titolo:',
  'LBL_DEPARTMENT' => 'Dipartimento:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Altra Email:',
  'LBL_ANY_EMAIL' => 'Nessuna Email:',
  'LBL_REPORTS_TO' => 'Riferisce A:',
  'LBL_DO_NOT_CALL' => 'Non Chiamare:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Indirizzo Principale:',
  'LBL_ALTERNATE_ADDRESS' => 'Altro Indirizzo:',
  'LBL_ANY_ADDRESS' => 'Nessun Indirizzo:',
  'LBL_REFERED_BY' => 'Riferito Da:',
  'LBL_CITY' => 'Citt&#224;:',
  'LBL_STATE' => 'Provincia:',
  'LBL_POSTAL_CODE' => 'CAP:',
  'LBL_COUNTRY' => 'Nazione:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Indirizzo Principale Via',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Indirizzo Principale Citt&#224;',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Indirizzo Principale Provincia',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Indirizzo Principale CAP',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Indirizzo Principale Nazione',
  'LBL_ALT_ADDRESS_STREET' => 'Altro Indirizzo Via',
  'LBL_ALT_ADDRESS_CITY' => 'Altro Indirizzo Citt&#224;',
  'LBL_ALT_ADDRESS_STATE' => 'Altro Indirizzo Provincia',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Altro Indirizzo CAP',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Altro Indirizzo Nazioni',
  'LBL_DESCRIPTION_INFORMATION' => 'Informazioni Descrittive',
  'LBL_ADDRESS_INFORMATION' => 'Informazioni Indirizzi',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_CONTACT_ROLE' => 'Ruolo:',
  'LBL_OPP_NAME' => 'Nome Opportunit&#224;:',
  'LBL_IMPORT_VCARD' => 'Importa vCard',
  'LNK_IMPORT_VCARD' => 'Crea Da vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Crea automaticamente un nuovo lead importando una vCard da file.',
  'LBL_DUPLICATE' => 'Lead Simili',
  'MSG_DUPLICATE' => 'Lead simili sono stati trovati. Per favore seleziona ogni leads che vuoi associare con il Record che verr&#224; creato da questa conversione. Al termine della selezione premi Avanti.',
  'LBL_ADD_BUSINESSCARD' => 'Aggiungi Business Card',
  'LNK_NEW_APPOINTMENT' => 'Crea Appuntamento',
  'LNK_NEW_LEAD' => 'Crea Lead',
  'LNK_LEAD_LIST' => 'Lead',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'NTC_REMOVE_CONFIRMATION' => 'Sei sicuro di voler rimuovere il lead da questo caso?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Sei sicuro di voler rimuovere questo record dal direct report?',
  'ERR_DELETE_RECORD' => 'Il numero del record deve essere specificato per cancellare il lead.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copia indirizzo principale su altro indirizzo',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copia altro indirizzo su indirizzo principale',
  'LNK_NEW_CONTACT' => 'Crea Contatto',
  'LNK_NEW_NOTE' => 'Crea Nota o Allegato',
  'LNK_NEW_ACCOUNT' => 'Create Azienda',
  'LNK_NEW_OPPORTUNITY' => 'Crea Opportunit&#224;',
  'LNK_SELECT_ACCOUNT' => 'Seleziona Azienda',
  'LBL_SALUTATION' => 'Titolo',
   'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'La creazione di un\'opportinit&#224; richiede un account.\n Crea un nuova azienda o seleziona una preesstente.',
);


?>
