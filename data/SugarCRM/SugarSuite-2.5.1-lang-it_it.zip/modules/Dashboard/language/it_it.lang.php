<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Dashboard',
  'LBL_MODULE_TITLE' => 'Dashboard: Home',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Totale in Portafoglio per Stadio di Vendita',
  'LBL_SALES_STAGE_FORM_DESC' => 'Mostra il totale delle opportunit&#224; nello stadio di vendita per gli utenti selezionati con data prevista di chiusura definita nell\'intervallo specificato.',
  'LBL_YEAR_BY_OUTCOME' => 'Pipeline Per Mese e Per Risultato',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Mostra il totale delle opportunit&#224; per mese e per esito per gli utenti selezionati con data prevista di chiusura definita nell\'intervallo specificato. L\'esito &#232; specificato in base al valore della fase di vendita "Chiusa vinta", "Chiusa persa" o altro valore.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Totale in Portafoglio per Fonte Lead',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Mostra il totale delle opportunit&#224; per le fonti per per gli utenti selezionati.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Tutte le opportunit&#224; per Origine e per Esito',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Mostra la somma delle opportunit&#224; per origine e per esito per gli utenti selezionati con quando la data di chiusura attesa è nel range di date specificato. L\'esito &#232; specificato in base al valore della fase di vendita "Chiusa vinta", "Chiusa persa" o altro valore.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Mostra la somma delle opportunit&#224; per stadio di vendita quando la data di chiusura attesa &#232; nell\'intervallo specificato.',
  'LBL_DATE_RANGE' => 'Periodo dal ',
  'LBL_DATE_RANGE_TO' => 'al',
  'ERR_NO_OPPS' => 'Per favore crea qualche opportunit&#224;�per vedere il grafico delle opportunit&#224;.',
  'LBL_TOTAL_PIPELINE' => 'Totale in Portafoglio ',
  'LBL_ALL_OPPORTUNITIES' => 'La somma dei valori di tutte le opportunit&#224; &#232; ',
  'LBL_OPP_SIZE' => 'Unit&#224; di Misura Opportunit&#224; = ',
  'LBL_OPP_THOUSANDS' => 'K',
  'NTC_NO_LEGENDS' => 'Nessuno',
  'LBL_LEAD_SOURCE_OTHER' => 'Altro',
  'LBL_EDIT' => 'Modifica',
  'LBL_REFRESH' => 'Ricalcola',
  'LBL_CREATED_ON' => 'Ultima elaborazione ',
  'LBL_OPPS_WORTH' => 'opportunit&#224; del valore di',
  'LBL_OPPS_IN_STAGE' => 'nello stadio di vendita ',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'opportunit&#224; da',
  'LBL_OPPS_OUTCOME' => 'con esito',
  'LBL_ROLLOVER_DETAILS' => 'Posizione il cursore del mouse su una barra per dettagli.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Posiziona il cursore del mouse su uno spicchio di torta per dettagli.',
  'LBL_USERS' => 'Utenti:',
  'LBL_SALES_STAGES' => 'Fase di vendita:',
  'LBL_LEAD_SOURCES' => 'Fonte del lead:',
  'LBL_DATE_START' => 'Data di inizio:',
  'LBL_DATE_END' => 'Data di fine:',
  'LBL_YEAR' => 'Anno:',
  'LNK_NEW_CONTACT' => 'Nuovo Contatto',
  'LNK_NEW_ACCOUNT' => 'Nuova Azienda',
  'LNK_NEW_OPPORTUNITY' => 'Nuova Opportunit&#224;',
  'LNK_NEW_QUOTE' => 'Crea Offerta',
  'LNK_NEW_LEAD' => 'Crea Lead',
  'LNK_NEW_CASE' => 'Nuovo Caso',
  'LNK_NEW_NOTE' => 'Nuova Nota o Allegato',
  'LNK_NEW_CALL' => 'Nuova Chiamata',
  'LNK_NEW_MEETING' => 'Nuovo Meeting',
  'LNK_NEW_TASK' => 'Nuovo Attivit&#224;',
  'LNK_NEW_ISSUE' => 'Segnala Problema',
);


?>
