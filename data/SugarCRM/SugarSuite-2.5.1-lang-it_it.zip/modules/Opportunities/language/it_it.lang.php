<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Opportunit&#224;',
  'LBL_MODULE_TITLE' => 'Opportunit&#224;: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Opportunit&#224;',
  'LBL_LIST_FORM_TITLE' => 'Lista Opportunit&#224;',
  'LBL_OPPORTUNITY_NAME' => 'Nome Opportunit&#224;:',
  'LBL_OPPORTUNITY' => 'Opportunit&#224;:',
  'LBL_NAME' => 'Nome Opportunit&#224;',
  'LBL_INVITEE' => 'Contatti',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Opportunit&#224;',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda',
  'LBL_LIST_AMOUNT' => 'Importo',
  'LBL_LIST_DATE_CLOSED' => 'Chiudi',
  'LBL_LIST_SALES_STAGE' => 'Stadio di Vendita',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Opportunit&#224; - Aggiornamento Valuta',
  'UPDATE_DOLLARAMOUNTS' => 'Aggiorna Importi Dollari U.S.A.',
  'UPDATE_VERIFY' => 'Verifica Importi',
  'UPDATE_VERIFY_TXT' => 'Verifica che i valori degli importi delle opportunit&#224; siano numeri decimali corretti con solo caratteri numerici (0-9) e decimali(.)',
  'UPDATE_FIX' => 'Aggiusta Importi',
  'UPDATE_FIX_TXT' => 'Attempts to fix any invalid amounts by creating a valid decimal from the current amount. This will backup any amounts it modifies into a database field amount_backup. If you run this and notice bugs, do not rerun this without restoring from the backup as it may overwrite the backup with new invalid data.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Update the U.S. Dollar amounts for opportunities based on the current set currency rates. This value is used to calculate Graphs and List View Currency Amounts.',
  'UPDATE_CREATE_CURRENCY' => 'Creazione Nuova Valuta:',
  'UPDATE_VERIFY_FAIL' => 'Verifica dei Record Fallita:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Importo Attuale:',
  'UPDATE_VERIFY_FIX' => 'Running Fix would give',
  'UPDATE_INCLUDE_CLOSE' => 'Includi Record Chiusi',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nuovo Importo:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nuova Valuta:',
  'UPDATE_DONE' => 'Fatto',
  'UPDATE_BUG_COUNT' => 'Problemi Trovati e  Found and Tentativo di Risoluzione:',
  'UPDATE_BUGFOUND_COUNT' => 'Trovati Problemi:',
  'UPDATE_COUNT' => 'Record Aggiornati:',
  'UPDATE_RESTORE_COUNT' => 'Record Importi Ripristinati:',
  'UPDATE_RESTORE' => 'Ripristina Importi',
  'UPDATE_RESTORE_TXT' => 'Restores amount values from the backups created during Fix.',
  'UPDATE_FAIL' => 'Non posso aggiornare - ',
  'UPDATE_NULL_VALUE' => 'L\'Importo &#232; NULLO impostandolo a 0 -',
  'UPDATE_MERGE' => 'Unici Valute',
  'UPDATE_MERGE_TXT' => 'Unisci pi&#249; valute in una singola valuta. Se noti che ci sono pi&#249; record per la stessa valuta puoi scegliere di unirle assieme. Questa operazione unir&#224; le valute per tutti i moduli.',
  'LBL_ACCOUNT_NAME' => 'Nome Azienda:',
  'LBL_AMOUNT' => 'Importo:',
  'LBL_CURRENCY' => 'Valuta:',
  'LBL_DATE_CLOSED' => 'Data di Chiusura Prevista:',
  'LBL_TYPE' => 'Tipo:',
  'LBL_NEXT_STEP' => 'Prossimo Passo:',
  'LBL_LEAD_SOURCE' => 'Fonte del Lead:',
  'LBL_SALES_STAGE' => 'Stadio di Vendita:',
  'LBL_PROBABILITY' => 'Probabilit&#224; (%):',
  'LBL_DESCRIPTION' => 'Descrizione',
  'LBL_DUPLICATE' => 'Possibile Opportunit&#224; Duplicata',
  'MSG_DUPLICATE' => 'Creando questa Opportunit&#224; pu&#242; essere potenzialmente creata un\'pportunit&#224; duplicata. Puoi anche selezionare un\'opportunit&#224; dalla lista sotto o puoi cliccare su Crea Nuova Opportunit&#224; per continuare creando una nuova opportunit&#224; con i dati precedentemente inseriti.',
  'LBL_NEW_FORM_TITLE' => 'Crea Opportunit&#224;',
  'LNK_NEW_OPPORTUNITY' => 'Crea Opportunit&#224;',
  'LNK_OPPORTUNITY_LIST' => 'Opportunit&#224;',
  'ERR_DELETE_RECORD' => 'Il numero del record deve essere specificato per cancellare opportunit&#224;.',
  'LBL_TOP_OPPORTUNITIES' => 'Le Miei Migliori Opportunit&#224;',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Sei sicuro di voler rimuovere questo contatto da questa Opportunit&#224;?',
);


?>
