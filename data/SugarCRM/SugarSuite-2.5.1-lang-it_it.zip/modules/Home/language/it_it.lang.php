<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_NEW_FORM_TITLE' => 'Nuovo Contatto',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_LAST_NAME' => 'Cognome:',
  'LBL_LIST_LAST_NAME' => 'Cognome',
  'LBL_PHONE' => 'Telefono:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_PIPELINE_FORM_TITLE' => 'La Mia Pipeline',
  'LNK_NEW_CONTACT' => 'Crea Contatto',
  'LNK_NEW_ACCOUNT' => 'Crea Azienda',
  'LNK_NEW_OPPORTUNITY' => 'Crea Opportunit&#224;',



  'LNK_NEW_LEAD' => 'Crea Lead',
  'LNK_NEW_CASE' => 'Crea Caso',
  'LNK_NEW_NOTE' => 'Crea Nota o Allegato',
  'LNK_NEW_CALL' => 'Pianifica Chiamata',
  'LNK_NEW_EMAIL' => 'Archivia Email',
  'LNK_NEW_MEETING' => 'Pianifica Meeting',
  'LNK_NEW_TASK' => 'Crea Attivit&#224;',
  'LNK_NEW_BUG' => 'Segnala Problema',
  'LBL_ADD_BUSINESSCARD' => 'Inserisci Biglietto da Visita',
  'ERR_ONE_CHAR' => 'Per favore inserisci almeno una lettera o un numero per la tua ricerca ...',
  'LBL_OPEN_TASKS' => 'Attivit&#224; Aperte',
);


?>
