<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Contatti',
  'LBL_INVITEE' => 'Direct Reports',
  'LBL_MODULE_TITLE' => 'Contatti: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Contatto',
  'LBL_LIST_FORM_TITLE' => 'Lista Contatti',
  'LBL_NEW_FORM_TITLE' => 'Nuovo Contatto',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Contatto-Opportunit&#224;:',
  'LBL_CONTACT' => 'Contatto:',
  'LBL_BUSINESSCARD' => 'Biglietto da Visita',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_LIST_LAST_NAME' => 'Cognome',
  'LBL_LIST_CONTACT_NAME' => 'Nome Contatto',
  'LBL_LIST_TITLE' => 'Titolo',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Altra Email',
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_CONTACT_ROLE' => 'Ruolo',
  'LBL_LIST_FIRST_NAME' => 'Nome',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Usato un contatto esistente',
  'LBL_CREATED_CONTACT' => 'Creato un nuovo contatto',
  'LBL_EXISTING_ACCOUNT' => 'Utilizzata azienda esistente',
  'LBL_CREATED_ACCOUNT' => 'Creato una nuova azienda',
  'LBL_CREATED_CALL' => 'Creata una nuova chiamata',
  'LBL_CREATED_MEETING' => 'Creato un nuovo meeting',
  'LBL_ADDMORE_BUSINESSCARD' => 'Aggiunto un altro biglietto da visita',
  'LBL_ADD_BUSINESSCARD' => 'Inserisci Biglietto da Visita',
  'LBL_NAME' => 'Nome:',
  'LBL_CONTACT_NAME' => 'Nome Contatto:',
  'LBL_CONTACT_INFORMATION' => 'Informazione Contatto',
  'LBL_FIRST_NAME' => 'Nome:',
  'LBL_OFFICE_PHONE' => 'Telefono Ufficio:',
  'LBL_ACCOUNT_NAME' => 'Nome Azienda:',
  'LBL_ANY_PHONE' => 'Nessun Telefono:',
  'LBL_PHONE' => 'Telefono:',
  'LBL_LAST_NAME' => 'Cognome:',
  'LBL_MOBILE_PHONE' => 'Cellulare:',
  'LBL_HOME_PHONE' => 'Casa:',
  'LBL_LEAD_SOURCE' => 'Fonte Lead:',
  'LBL_OTHER_PHONE' => 'Altro Telefono:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Indirizzo Principale Via:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Indirizzo Principale Citt&#224;:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Indirizzo Principale Provincia:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Indirizzo Principale Nazione:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Indirizzo Principale CAP:',
  'LBL_ALT_ADDRESS_STREET' => 'Altro Indirizzo Via:',
  'LBL_ALT_ADDRESS_CITY' => 'Altro Indirizzo Citt&#224;:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Altro Indirizzo Provincia:',
  'LBL_ALT_ADDRESS_STATE' => 'Altro Indirizzo Nazione:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Altro Indirizzo CAP:',
  'LBL_TITLE' => 'Titolo:',
  'LBL_DEPARTMENT' => 'Dipartimento:',
  'LBL_BIRTHDATE' => 'Compleanno:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Altra Email:',
  'LBL_ANY_EMAIL' => 'Nessuna Email:',
  'LBL_REPORTS_TO' => 'Riporta A:',
  'LBL_ASSISTANT' => 'Assistente:',
  'LBL_PORTAL_NAME' => 'Nome Portale:',
  'LBL_NEW_PORTAL_PASSWORD' => 'Nuova Password Portale:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'La Password Del Portale E\' Impostata:',
  'LBL_PORTAL_ACTIVE' => 'Portale Attivo:',
  'LBL_PORTAL_INFORMATION' => 'Informazione Portale',
  'LBL_ASSISTANT_PHONE' => 'Telefono Assistente:',
  'LBL_DO_NOT_CALL' => 'Non Chiamare:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Indirizzo Principale:',
  'LBL_ALTERNATE_ADDRESS' => 'Altro Indirizzo:',
  'LBL_ANY_ADDRESS' => 'Nessun Inirizzo:',
  'LBL_CITY' => 'Citt&#224;:',
  'LBL_STATE' => 'Stato:',
  'LBL_POSTAL_CODE' => 'CAP:',
  'LBL_COUNTRY' => 'Nazione:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informazione Descrittiva',
  'LBL_ADDRESS_INFORMATION' => 'Informazioni Indirizzo',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'LBL_CONTACT_ROLE' => 'Ruolo:',
  'LBL_OPP_NAME' => 'Nome Opportunit&#224;:',
  'LBL_IMPORT_VCARD' => 'Importa vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automaticamente crea un nuovo contatto dall\'importazione della vCardv caricata da file.',
  'LBL_DUPLICATE' => 'Possibile Contatti Duplicati',
  'MSG_SHOW_DUPLICATES' => 'Creando questo contatto si pu&#242; potenzialmente creare un contatto duplicato. Poi cliccare su Crea Contatto per continuare con i dati precedentemente inseriti o abbandonare cliccando Annulla.',
  'MSG_DUPLICATE' => 'Creando questo contatto si pu&#242; potenzialmente creare un contatto duplicato. Puoi selezionare un contatto dalla lista sotto o puoi cliccare su Crea Contatto per continuare per continuare con i dati precedentemente inseriti.',
  'LNK_CONTACT_LIST' => 'Contatti',
  'LNK_IMPORT_VCARD' => 'Crea Da vCard',
  'LNK_NEW_CONTACT' => 'Crea Contatto',
  'LNK_NEW_ACCOUNT' => 'Crea Azienda',
  'LNK_NEW_OPPORTUNITY' => 'Crea Opportunit&#224;',
  'LNK_NEW_CASE' => 'Crea Caso',
  'LNK_NEW_NOTE' => 'Crea Nota o Allegato',
  'LNK_NEW_CALL' => 'Pianifica Chiamata',
  'LNK_NEW_EMAIL' => 'Archivia Email',
  'LNK_NEW_MEETING' => 'Pianifica Meeting',
  'LNK_NEW_TASK' => 'Crea Attviti&#224;',
  'LNK_NEW_APPOINTMENT' => 'Crea Appuntamento',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'NTC_REMOVE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record da questo caso?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Sei sicuro di voler rimuovere questo record da un report diretto?',
  'ERR_DELETE_RECORD' => 'Il numero del record deve essere specificato per cancellare il contatyo.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Copia indirizzo principale su altro indirizzo',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Copia altro indirizzo su indirizzo principale',
  'LBL_SALUTATION' => 'Saluto',
  'LBL_SAVE_CONTACT' => 'Salva Contatto',
);


?>
