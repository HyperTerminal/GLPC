<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aziende',
  'LBL_MODULE_TITLE' => 'Aziende: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Azienda',
  'LBL_LIST_FORM_TITLE' => 'Lista Aziende',
  'LBL_NEW_FORM_TITLE' => 'Nuova Azienda',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Membri del gruppo',
  'LBL_BUG_FORM_TITLE' => 'Aziende',
  'LBL_LIST_ACCOUNT_NAME' => 'Nome Azienda',
  'LBL_LIST_CITY' => 'Citt&#224;',
  'LBL_LIST_WEBSITE' => 'Website',
  'LBL_LIST_STATE' => 'Provincia',
  'LBL_LIST_PHONE' => 'Telefono',
  'LBL_LIST_EMAIL_ADDRESS' => 'Indirizzo Email',
  'LBL_LIST_CONTACT_NAME' => 'Nome del Contatto',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Informazioni Azienda',
  'LBL_ACCOUNT' => 'Azienda:',
  'LBL_ACCOUNT_NAME' => 'Nome Azienda:',
  'LBL_PHONE' => 'Telefono:',
  'LBL_PHONE_ALT' => 'Altro Telefono:',
  'LBL_WEBSITE' => 'Website:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Simbolo Ticker:',
  'LBL_OTHER_PHONE' => 'Altro Telefono:',
  'LBL_ANY_PHONE' => 'Nessun Telefono:',
  'LBL_MEMBER_OF' => 'Membro di:',
  'LBL_PHONE_OFFICE' => 'Telefono Ufficio:',
  'LBL_PHONE_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_EMPLOYEES' => 'Dipendenti:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Altra Email:',
  'LBL_ANY_EMAIL' => 'Nessuna Email:',
  'LBL_OWNERSHIP' => 'Proprietario:',
  'LBL_RATING' => 'Valutazione:',
  'LBL_INDUSTRY' => 'Industria:',
  'LBL_SIC_CODE' => 'Codice SIC :',
  'LBL_TYPE' => 'Tipo:',
  'LBL_ANNUAL_REVENUE' => 'Fatturato Annuo:',
  'LBL_ADDRESS_INFORMATION' => 'Indirizzo',
  'LBL_BILLING_ADDRESS' => 'Indirizzo Fatturazione:',
  'LBL_BILLING_ADDRESS_STREET' => 'Billing Address Street:',
  'LBL_BILLING_ADDRESS_CITY' => 'Billing Address City:',
  'LBL_BILLING_ADDRESS_STATE' => 'Billing Address State:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Billing Address Postal Code:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Billing Address Country:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Shipping Address Street:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Shipping Address City:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Shipping Address State:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Shipping Address Postal Code:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Shipping Address Country:',
  'LBL_SHIPPING_ADDRESS' => 'Indirizzo di Spedizione:',
  'LBL_DATE_MODIFIED' => 'Data Modifica:',
  'LBL_DATE_ENTERED' => 'Data Inserimento:',
  'LBL_ANY_ADDRESS' => 'Nessun Indirizzo:',
  'LBL_CITY' => 'Citt&#224;:',
  'LBL_STATE' => 'Provincia:',
  'LBL_POSTAL_CODE' => 'CAP:',
  'LBL_COUNTRY' => 'Nazione:',
  'LBL_DESCRIPTION_INFORMATION' => 'Altro',
  'LBL_DESCRIPTION' => 'Descrizione:',
  'NTC_COPY_BILLING_ADDRESS' => 'Copia indirizzo di fatturazione su indirizzo di spedizione',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Copia indirizzo di spedizione su indirizzo di fatturazione',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record dal gruppo?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'LBL_DUPLICATE' => 'Possibile Azienda Duplicata',
  'MSG_SHOW_DUPLICATES' => 'Creando questo contatto puoi potenzialmente creare un contatto duplicato. Puoi anche cliccare su Crea Azienda per continuare a create questa nuova azienda con i dati precedentemente inseriti o puoi cliccare su Annulla.',
  'MSG_DUPLICATE' => 'Creando questo contatto puoi potenzialmente creare un contatto duplicato. Puoi selezionare un\'azienda dalla lista sotto o cliccare su Crea Azienda per continuare a creare una nuova azienda con i dati precedentemente inseriti.',
  'LNK_NEW_ACCOUNT' => 'Crea Azienda',
  'LNK_ACCOUNT_LIST' => 'Aziende',
  'LBL_INVITEE' => 'Contatti',
  'ERR_DELETE_RECORD' => 'Devi specificare un numero record per cancellare l\'azienda.',
  'NTC_DELETE_CONFIRMATION' => 'Sei sicuro di voler cancellare questo record?',
  'LBL_SAVE_ACCOUNT' => 'Salva Azienda',
  'LBL_BUG_FORM_TITLE' => 'Aziende',

);


?>
