<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'=>'Calendario',
  'LBL_MODULE_TITLE'=>'Calendario',
  'LNK_NEW_CALL' => 'Pianifica Chiamata',
  'LNK_NEW_MEETING' => 'Pianifica Meeting',
  'LNK_NEW_APPOINTMENT' => 'Crea Appuntamento',
  'LNK_NEW_TASK' => 'Crea Attivit&#224;',
  'LNK_CALL_LIST' => 'Chiamate',
  'LNK_MEETING_LIST' => 'Meeting',
  'LNK_TASK_LIST' => 'Attivit&#224;',
  'LNK_VIEW_CALENDAR' => 'Oggi',
  'LBL_MONTH' => 'Mese',
  'LBL_DAY' => 'Giorno',
  'LBL_YEAR' => 'Anno',
  'LBL_WEEK' => 'Settimana',
  'LBL_PREVIOUS_MONTH' => 'Mese Precedente',
  'LBL_PREVIOUS_DAY' => 'Giorno Precedente',
  'LBL_PREVIOUS_YEAR' => 'Anno Precedente',
  'LBL_PREVIOUS_WEEK' => 'Settimana Precedente',
  'LBL_NEXT_MONTH' => 'Mese Successivo',
  'LBL_NEXT_DAY' => 'Giorno Successivo',
  'LBL_NEXT_YEAR' => 'Anno Successivo',
  'LBL_NEXT_WEEK' => 'Settimana Successiva',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Pianificato',
  'LBL_BUSY' => 'Occupato',
  'LBL_CONFLICT' => 'Sovrapposto',
  'LBL_USER_CALENDARS' => 'Calendari Utenti',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"Dom",
"Lun",
"Mar",
"Mer",
"Gio",
"Ven",
"Sab",
),
'dom_cal_weekdays_long'=>array(
"Domenica",
"Luned&#236;",
"Marted&#236;",
"Mercoled&#236;",
"Gioved&#236;",
"Venerd&#236;",
"Sabato",
),
'dom_cal_month'=>array(
"",
"Gen",
"Feb",
"Mar",
"Apr",
"Mag",
"Giu",
"Lug",
"Ago",
"Set",
"Ott",
"Nov",
"Dic",
),
'dom_cal_month_long'=>array(
"",
"Gennaio",
"Febbraio",
"Marzo",
"Aprile",
"Maggio",
"Giugno",
"Luglio",
"Agosto",
"Settembre",
"Ottobre",
"Novembre",
"Dicembre",
)
);
?>
