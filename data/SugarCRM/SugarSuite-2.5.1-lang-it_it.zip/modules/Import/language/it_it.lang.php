<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'La Cartella ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' non esiste o non &#232; scrivibile',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Il file non &#232; stato caricato correttamente. Questo pu&#242; dipendere dal valore troppo piccolo del parametro \'upload_max_filesize\' nel php.ini. Contatta il tuo amministratore di rete.',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Il file &#232; troppo grande. Max:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Byte. Modifica $sugar_config[\'upload_maxsize\'] in config.php',
  'LBL_MODULE_NAME' => 'Importa',
  'LBL_TRY_AGAIN' => 'Prova ancora',
  'LBL_ERROR' => 'Errore:',
  'ERR_MULTIPLE' => 'Pi&#249; colonne sono state definite con lo stesso nome di campo.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Mancati i campi richiesti:',
  'ERR_SELECT_FULL_NAME' => 'Non puoi selezionare il Nome Completo quando il Nome e Cognome sono selezionati.',
  'ERR_SELECT_FILE' => 'Seleziona il file da caricare.',
  'LBL_SELECT_FILE' => 'Seleziona file:',
  'LBL_CUSTOM' => 'Personalizza',
  'LBL_CUSTOM_CSV' => 'Personalizza Comma Delimited File',
  'LBL_CUSTOM_TAB' => 'Personalizza Tab Delimited File',
  'LBL_DONT_MAP' => '-- Non associare questo campo --',
  'LBL_STEP_1_TITLE' => 'Passo 1: Seleziona la sorgente dei dati',
  'LBL_WHAT_IS' => 'Quale &#232; la fonte dei dati?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Le Mie Sorgenti Salvate:',
  'LBL_PUBLISH' => 'pubblica',
  'LBL_DELETE' => 'cancella',
  'LBL_PUBLISHED_SOURCES' => 'Sorgenti Pubblicate:',
  'LBL_UNPUBLISH' => 'cancella-pubblicazione',
  'LBL_NEXT' => 'Avanti >',
  'LBL_BACK' => '< Indietro',
  'LBL_STEP_2_TITLE' => 'Passo 2: Carica File Esportato',
  'LBL_HAS_HEADER' => 'Con Intestazioni:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'Ora scegli quale fine deve essere importato:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 and 2000 possono esportare dati in formato <b>Valori Separati da Virgola (CSV)</b> che pu&#242; essere utilizzato per importare dati nel sistema. Per esportare i tuoi dati da Outlook, segui i passi qui sotto:',
  'LBL_OUTLOOK_NUM_1' => 'Esegui <b>Outlook</b>',
  'LBL_OUTLOOK_NUM_2' => 'Seleziona il menu <b>File</b>, poi l\'opzione <b>Importa ed Esporta ...</b>',
  'LBL_OUTLOOK_NUM_3' => 'Scegli <b>Esporta in un file</b> e clicca <b>Avanti</b>',
  'LBL_OUTLOOK_NUM_4' => 'Scegli <b>Valori Separati da Virgola (Windows)</b> e clicca <b>Avanti</b>.<br>  Nota: Potrebbe esserti richiesto di installare il componente di esportazione',
  'LBL_OUTLOOK_NUM_5' => 'Seleziona la cartella <b>Contatti</b> e clicca <b>Avanti</b>. Puoi selezionare anche altre cartelle dei contatti se i tuoi contatti sono memorizzati in altre cartelle',
  'LBL_OUTLOOK_NUM_6' => 'Scegli un nome al file e <b>Avanti</b>',
  'LBL_OUTLOOK_NUM_7' => 'Clicca <b>Fine</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! can export data in the <b>Comma Separated Values</b> format which can be used to import data into the system. To export your data from Act!, follow the steps below:',
  'LBL_ACT_NUM_1' => 'Esegui <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'Select the <b>File</b> menu, the <b>Data Exchange</b> menu option, then the <b>Export...</b> menu option',
  'LBL_ACT_NUM_3' => 'Select the file type <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'Choose a filename and location for the exported data and click <b>Next</b>',
  'LBL_ACT_NUM_5' => 'Select <b>Contacts records only</b>',
  'LBL_ACT_NUM_6' => 'Click the <b>Options...</b> button',
  'LBL_ACT_NUM_7' => 'Select <b>Comma</b> as the field separator character',
  'LBL_ACT_NUM_8' => 'Check the <b>Yes, export field names</b> checkbox and click <b>OK</b>',
  'LBL_ACT_NUM_9' => 'Click <b>Next</b>',
  'LBL_ACT_NUM_10' => 'Select <b>All Records</b> and then Click <b>Finish</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com can export data in the <b>Comma Separated Values</b> format which can be used to import data into the system. To export your data from Salesforce.com, follow the steps below:',
  'LBL_SF_NUM_1' => 'Open your browser, go to http://www.salesforce.com, and login with your email address and password',
  'LBL_SF_NUM_2' => 'Click on the <b>Reports</b> tab on the top menu',
  'LBL_SF_NUM_3' => '<b>To export Accounts:</b> Click on the <b>Active Accounts</b> link<br><b>To export Contacts:</b> Click on the <b>Mailing List</b> link',
  'LBL_SF_NUM_4' => 'On <b>Step 1: Select your report type</b>, select <b>Tabular Report</b>click <b>Next</b>',
  'LBL_SF_NUM_5' => 'On <b>Step 2: Select the report columns</b>, choose the columns you want to export and click <b>Next</b>',
  'LBL_SF_NUM_6' => 'On <b>Step 3: Select the information to summarize</b>, just click <b>Next</b>',
  'LBL_SF_NUM_7' => 'On <b>Step 4: Order the report columns</b>, just click <b>Next</b>',
  'LBL_SF_NUM_8' => 'On <b>Step 5: Select your report criteria</b>, under <b>Start Date</b>, choose a date far enough in the past to include all your Accounts. You can also export a subset of Accounts using more advanced criteria. When you are done, click <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'A report will be generated, and the page should display <b>Report Generation Status: Complete.</b> Now click <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => 'On <b>Export Report:</b>, for <b>Export File Format:</b>, choose <b>Comma Delimited .csv</b>. Click <b>Export</b>.',
  'LBL_SF_NUM_11' => 'A dialog will pop up for you to save the export file to your computer.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Molte applicazioni permettono di esportare dati in formato testo <b>Comma Delimited Value (.csv o .txt)</b>. In molti casi le applicazioni seguono i seguenti passi:',
  'LBL_CUSTOM_NUM_1' => 'Esegui l\'applicazione ed apri il file dati',
  'LBL_CUSTOM_NUM_2' => 'Seleziona l\'opzione del menu <b>Salva Come...</b> or <b>Esporta...</b>',
  'LBL_CUSTOM_NUM_3' => 'Salva il file nel formato <b>CSV</b> o <b>Comma Separated Values</b>',
  'LBL_IMPORT_TAB_TITLE' => 'Molte applicazioni permettono di esportare dati in formato testo <b>Tab Delimited Value (.tsv o .tab o .txt)</b>. In molti casi le applicazioni seguono i seguenti passi:',
  'LBL_TAB_NUM_1' => 'Esegui l\'applicazione ed apri il file dati',
  'LBL_TAB_NUM_2' => 'Seleziona l\'opzione del menu <b>Salva Come...</b> or <b>Esporta...</b>',
  'LBL_TAB_NUM_3' => 'Salva il file nel formato <b>TSV</b> o <b>Tab Separated Values</b>',
  'LBL_STEP_3_TITLE' => 'Passo 3: Conferma i Campi ed Importa',
  'LBL_SELECT_FIELDS_TO_MAP' => 'Nella lista sotto seleziona dal tuo file di importazione i campi che dovrebbero essere importati associandoli con quelli del sistema. Quando avrai terminato, clicca <b>Importa Ora</b>:',
  'LBL_DATABASE_FIELD' => 'Campo Database',
  'LBL_HEADER_ROW' => 'Intestazione Riga',
  'LBL_ROW' => 'Riga',
  'LBL_SAVE_AS_CUSTOM' => 'Salva come Template Personalizzato:',
  'LBL_CONTACTS_NOTE_1' => 'Almeno uno dei due campi Cognome o Nome Completo devono essere collgati.',
  'LBL_CONTACTS_NOTE_2' => 'Se Nome Completo &#232; collegato, allora Nome e Cognome sono ingnoati.',
  'LBL_CONTACTS_NOTE_3' => 'Se Nome Completo &#232; collegato, allora i dati in Nome Completo saranno spezzati in Nome e Cognome quando saranno inseriti nel database.',
  'LBL_CONTACTS_NOTE_4' => 'I campi che terminano in Indirizzo Via 2 e Indirizzo Via 3 saranno concatenati assieme nel campo Indirizzo Via quando saranno inseriti nel database.',
  'LBL_ACCOUNTS_NOTE_1' => 'Il nome dell\'azienda deve essere collegato.',
  'LBL_ACCOUNTS_NOTE_2' => 'Fields ending in Address Street 2 and Address Street 3 are concatenated together with the main Address Street Field when inserted into the database.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Nome Opportunit&#224;, Nome Azienda, Data di Chiusura e Stadio di Vendita sono campi necessari.',
  'LBL_IMPORT_NOW' => 'Importa Ora',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Non posso importare il file per la lettura',
  'LBL_NOT_SAME_NUMBER' => 'Non ci sono gli stessi numero di campi per linea nel tuo file',
  'LBL_NO_LINES' => 'Nel tuo file di importazione non ci sono linee di testo',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Il file di importazione &#232; gi&#224; stato processato o non esiste',
  'LBL_SUCCESS' => 'Completato:',
  'LBL_SUCCESSFULLY' => 'Importazione Completata',
  'LBL_LAST_IMPORT_UNDONE' => 'La tua ultima importazione e&#232; stata annullata.',
  'LBL_NO_IMPORT_TO_UNDO' => 'Non ci sono importazioni da annullare.',
  'LBL_FAIL' => 'Fallita:',
  'LBL_RECORDS_SKIPPED' => 'records skipped because they were missing one or more required fields',
  'LBL_IDS_EXISTED_OR_LONGER' => 'records skipped because the id\'s either existed or where longer than 36 characters',
  'LBL_RESULTS' => 'Risultati',
  'LBL_IMPORT_MORE' => 'Importa Ancora',
  'LBL_FINISHED' => 'Finito',
  'LBL_UNDO_LAST_IMPORT' => 'Annulla Ultima Importazione',
  'LBL_LAST_IMPORTED'=>'Ultimi Importati',
  'ERR_MULTIPLE_PARENTS' => 'Puoi avere definito un solo ID Padre',
);

$mod_list_strings = Array(
'notes_import_fields' => Array(
	"contact_id"=>"Contact ID"
        ,"date_modified_only"=>"Date Modified (U.S. Format)"
        ,"time_modified_only"=>"Time Modified (Time)"
        ,"date_entered_only"=>"Date Entered (U.S. Format)"
        ,"time_entered_only"=>"Time Entered"
	,"account_id"=>"Parent ID (Account)"
        ,"opportunity_id"=>"Parent ID (Opportunity)"
        ,"acase_id"=>"Parent ID (Case)"
        ,"lead_id"=>"Parent ID (Lead)"




	,"name"=>"Subject"
	,"description"=>"Note"
),
'contacts_import_fields' => Array(
	"id"=>"Contact ID"
	,"assigned_real_user_name"=>"Assigned User's Real Name"
        ,"date_modified_only"=>"Date Modified (U.S. Date)"
        ,"time_modified_only"=>"Time Modified (Time)"
        ,"date_entered_only"=>"Date Entered (U.S. Date)"
        ,"time_entered_only"=>"Time Entered (Time)"
	,"first_name"=>"First Name"
	,"last_name"=>"Last Name"
	,"salutation"=>"Salutation"
	,"lead_source"=>"Lead Source"
	,"birthdate"=>"Birthdate"
	,"do_not_call"=>"Do Not Call"
	,"email_opt_out"=>"Email Opt Out"
	,"primary_address_street_2"=>"Primary Address Street 2"
	,"primary_address_street_3"=>"Primary Address Street 3"
	,"alt_address_street_2"=>"Other Address Street 2"
	,"alt_address_street_3"=>"Other Address Street 3"
	,"full_name"=>"Full Name"
	,"account_name"=>"Account Name"
	,"account_id"=>"Account ID"
	,"title"=>"Title"
	,"department"=>"Department"
	,"birthdate"=>"Birthdate"
	,"do_not_call"=>"Do Not Call"
	,"phone_home"=>"Phone (Home)"
	,"phone_mobile"=>"Phone (Mobile)"
	,"phone_work"=>"Phone (Work)"
	,"phone_other"=>"Phone (Other)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (Other)"
	,"assistant"=>"Assistant"
	,"assistant_phone"=>"Assistant Phone"
	,"primary_address_street"=>"Primary Address Street"
	,"primary_address_city"=>"Primary Address City"
	,"primary_address_state"=>"Primary Address State"
	,"primary_address_postalcode"=>"Primary Address Postalcode"
	,"primary_address_country"=>"Primary Address Country"
	,"alt_address_street"=>"Other Address Street"
	,"alt_address_city"=>"Other Address City"
	,"alt_address_state"=>"Other Address State"
	,"alt_address_postalcode"=>"Other Address Postalcode"
	,"alt_address_country"=>"Other Address Country"
	,"description"=>"Description"

	),

'accounts_import_fields' => Array(
	"id"=>"Account ID",
	"name"=>"Account Name",
	"website"=>"Website",
	"industry"=>"Industry",
	"account_type"=>"Type",
	"ticker_symbol"=>"Ticker Symbol",
	"parent_name"=>"Member of",
	"employees"=>"Employees",
	"ownership"=>"Ownership",
	"phone_office"=>"Phone",
	"phone_fax"=>"Fax",
	"phone_alternate"=>"Other Phone",
	"email1"=>"Email",
	"email2"=>"Other Email",
	"rating"=>"Rating",
	"sic_code"=>"SIC Code",
	"annual_revenue"=>"Annual Revenue",
	"billing_address_street"=>"Billing Address Street",
	"billing_address_street_2"=>"Billing Address Street 2",
	"billing_address_street_3"=>"Billing Address Street 3",
	"billing_address_street_4"=>"Billing Address Street 4",
	"billing_address_city"=>"Billing Address City",
	"billing_address_state"=>"Billing Address State",
	"billing_address_postalcode"=>"Billing Address Postalcode",
	"billing_address_country"=>"Billing Address Country",
	"shipping_address_street"=>"Shipping Address Street",
	"shipping_address_street_2"=>"Shipping Address Street 2",
	"shipping_address_street_3"=>"Shipping Address Street 3",
	"shipping_address_street_4"=>"Shipping Address Street 4",
	"shipping_address_city"=>"Shipping Address City",
	"shipping_address_state"=>"Shipping Address State",
	"shipping_address_postalcode"=>"Shipping Address Postalcode",
	"shipping_address_country"=>"Shipping Address Country",
	"description"=>"Description"
	),

'opportunities_import_fields' => Array(
		"id"=>"Account ID"
                , "name"=>"Opportunity Name"
                , "account_name"=>"Account Name"
                , "opportunity_type"=>"Opportunity Type"
                , "lead_source"=>"Lead Source"
                , "amount"=>"Amount"
                , "date_closed"=>"Date Closed"
                , "next_step"=>"Next Step"
                , "sales_stage"=>"Sales Stage"
                , "probability"=>"Probability"
                , "description"=>"Description"
                ),

'leads_import_fields' => Array(
                "refered_by"=>"Referred By"
                ,"salutation"=>"Salutation"
                ,"first_name"=>"First Name"
                ,"last_name"=>"Last Name"
                ,"lead_source"=>"Lead Source"
                ,"lead_source_description"=>"Lead Source Description"
                ,"title"=>"Title"
                ,"department"=>"Department"
                ,"do_not_call"=>"Do Not Call"
	,"phone_home"=>"Phone (Home)"
	,"phone_mobile"=>"Phone (Mobile)"
	,"phone_work"=>"Phone (Work)"
	,"phone_other"=>"Phone (Other)"
	,"phone_fax"=>"Fax"
	,"email1"=>"Email"
	,"email2"=>"Email (Other)"
        ,"email_opt_out"=>"Email Opt Out"
	,"primary_address_street_2"=>"Primary Address Street 2"
	,"primary_address_street_3"=>"Primary Address Street 3"
	,"alt_address_street_2"=>"Other Address Street 2"
	,"alt_address_street_3"=>"Other Address Street 3"
	,"primary_address_street"=>"Primary Address Street"
	,"primary_address_city"=>"Primary Address City"
	,"primary_address_state"=>"Primary Address State"
	,"primary_address_postalcode"=>"Primary Address Postalcode"
	,"primary_address_country"=>"Primary Address Country"
	,"alt_address_street"=>"Other Address Street"
	,"alt_address_city"=>"Other Address City"
	,"alt_address_state"=>"Other Address State"
	,"alt_address_postalcode"=>"Other Address Postalcode"
	,"alt_address_country"=>"Other Address Country"
	,"full_name"=>"Full Name"
	,"description"=>"Description"
        ,"status"=>"Status"
        ,"status_description"=>"Status Description"
        ,"account_name"=>"Account Name"
        ,"account_description"=>"Description"
        ),






















































);

?>
