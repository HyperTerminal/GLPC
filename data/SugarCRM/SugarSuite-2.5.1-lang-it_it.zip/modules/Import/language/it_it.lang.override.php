<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.override.php,v 1.3 2005/03/04 17:08:54 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_list_strings['contacts_import_fields']['nish_flag'] = 'NISH Rep';
$mod_list_strings['contacts_import_fields']["primary_address_type"] = '1&#176; Indirizzo Tipo';
$mod_list_strings['contacts_import_fields']["alt_address_type"] = '2&#176; Indirizzo Tipo';

$mod_list_strings['contacts_import_fields']["primary_address_type"] = '1&#176; Indirizzo Tipo';
$mod_list_strings['contacts_import_fields']["primary_address_street"] = "1&#176; Indirizzo Via";
$mod_list_strings['contacts_import_fields']["primary_address_street_2"] = "1&#176; Indirizzo Via 2";
$mod_list_strings['contacts_import_fields']["primary_address_street_3"] = "1&#176; Indirizzo Via 3";
$mod_list_strings['contacts_import_fields']["primary_address_street_4"] = "1&#176; Indirizzo Via 4";
$mod_list_strings['contacts_import_fields']["primary_address_city"] = "1&#176; Indirizzo Citt&#224;";
$mod_list_strings['contacts_import_fields']["primary_address_state"] = "1&#176; Indirizzo Provincia";
$mod_list_strings['contacts_import_fields']["primary_address_postalcode"] = "1&#176; Indirizzo CAP";
$mod_list_strings['contacts_import_fields']["primary_address_country"] = "1&#176; Indirizzo Nazione";
$mod_list_strings['contacts_import_fields']["alt_address_type"] = '2&#176; Indirizzo Tipo';
$mod_list_strings['contacts_import_fields']["alt_address_street"] = "2&#176; Indirizzo Via";
$mod_list_strings['contacts_import_fields']["alt_address_street_2"] = "2&#176; Indirizzo Via 2";
$mod_list_strings['contacts_import_fields']["alt_address_street_3"] = "2&#176; Indirizzo Via 3";
$mod_list_strings['contacts_import_fields']["alt_address_street_4"] = "2&#176; Indirizzo Via 4";
$mod_list_strings['contacts_import_fields']["alt_address_city"] = "2&#176; Indirizzo Citt&#224;";
$mod_list_strings['contacts_import_fields']["alt_address_state"] = "2&#176; Indirizzo Provincia";
$mod_list_strings['contacts_import_fields']["alt_address_postalcode"] = "2&#176; Indirizzo CAP";
$mod_list_strings['contacts_import_fields']["alt_address_country"] = "2&#176; Indirizzo Nazione";

$mod_list_strings['accounts_import_fields']["billing_address_type"] = '1&#176; Indirizzo Tipo';
$mod_list_strings['accounts_import_fields']["billing_address_street"] = "1&#176; Indirizzo Via";
$mod_list_strings['accounts_import_fields']["billing_address_street_2"] = "1&#176; Indirizzo Via 2";
$mod_list_strings['accounts_import_fields']["billing_address_street_3"] = "1&#176; Indirizzo Via 3";
$mod_list_strings['accounts_import_fields']["billing_address_street_4"] = "1&#176; Indirizzo Via 4";
$mod_list_strings['accounts_import_fields']["billing_address_city"] = "1&#176; Indirizzo Citt&#224;";
$mod_list_strings['accounts_import_fields']["billing_address_state"] = "1&#176; Indirizzo Provincia";
$mod_list_strings['accounts_import_fields']["billing_address_postalcode"] = "1&#176; Indirizzo CAP";
$mod_list_strings['accounts_import_fields']["billing_address_country"] = "1&#176; Indirizzo Nazione";
$mod_list_strings['accounts_import_fields']["shipping_address_type"] = '2&#176; Indirizzo Tipo';
$mod_list_strings['accounts_import_fields']["shipping_address_street"] = "2&#176; Indirizzo Via";
$mod_list_strings['accounts_import_fields']["shipping_address_street_2"] = "2&#176; Indirizzo Via 2";
$mod_list_strings['accounts_import_fields']["shipping_address_street_3"] = "2&#176; Indirizzo Via 3";
$mod_list_strings['accounts_import_fields']["shipping_address_street_4"] = "2&#176; Indirizzo Via 4";
$mod_list_strings['accounts_import_fields']["shipping_address_city"] = "2&#176; Indirizzo Citt&#224;";
$mod_list_strings['accounts_import_fields']["shipping_address_state"] = "2&#176; Indirizzo Provincia";
$mod_list_strings['accounts_import_fields']["shipping_address_postalcode"] = "2&#176; Indirizzo CAP";
$mod_list_strings['accounts_import_fields']["shipping_address_country"] = "2&#176; Indirizzo Nazione";

$mod_list_strings['accounts_import_fields']["alt3_address_type"] = '3&#176; Indirizzo Tipo';
$mod_list_strings['accounts_import_fields']["alt3_address_street"] = '3&#176; Indirizzo Via';
$mod_list_strings['accounts_import_fields']["alt3_address_city"] = '3&#176; Indirizzo Citt&#224;';
$mod_list_strings['accounts_import_fields']["alt3_address_state"] = '3&#176; Indirizzo Provincia';
$mod_list_strings['accounts_import_fields']["alt3_address_postalcode"] = '3&#176; Indirizzo CAP';
$mod_list_strings['accounts_import_fields']["alt3_address_country"] = '3&#176; Indirizzo Nazione';
$mod_list_strings['accounts_import_fields']["alt4_address_type"] = '4&#176; Indirizzo Tipo';
$mod_list_strings['accounts_import_fields']["alt4_address_street"] = '4&#176; Indirizzo Via';
$mod_list_strings['accounts_import_fields']["alt4_address_city"] = '4&#176; Indirizzo Citt&#224;';
$mod_list_strings['accounts_import_fields']["alt4_address_state"] = '4&#176; Indirizzo Provincia';
$mod_list_strings['accounts_import_fields']["alt4_address_postalcode"] = '4&#176; Indirizzo CAP';
$mod_list_strings['accounts_import_fields']["alt4_address_country"] = '4&#176; Indirizzo Nazione';
$mod_list_strings['accounts_import_fields']["nish_rep_id"] = 'NISH Rep';
$mod_list_strings['accounts_import_fields']["operations_rep_id"] = 'Operations Rep ID';
$mod_list_strings['accounts_import_fields']["contract_rep_id"] = 'Contract Rep ID';
$mod_list_strings['accounts_import_fields']["account_rep_id"] = 'Account Rep ID';


$mod_list_strings['opportunities_import_fields']['procurement_agency_id'] = 'Agenzia Provvigioni';
$mod_list_strings['opportunities_import_fields']["assigned_from_id"] = 'Assegnato Da';
$mod_list_strings['opportunities_import_fields']['scope'] = 'Scopo';
$mod_list_strings['opportunities_import_fields']['current_contractor_id'] = 'ID Contractor Attuale';
$mod_list_strings['opportunities_import_fields']['sol_URL_1'] = 'Sol URL 1';
$mod_list_strings['opportunities_import_fields']['comments'] = 'Commenti';

?>
