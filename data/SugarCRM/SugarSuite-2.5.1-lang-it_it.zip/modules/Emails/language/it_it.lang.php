<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: it_it.lang.php,v 1.30 2005/03/01 00:00:00 lzammarchi Exp $
 * Description:  Defines the Italian language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Luca Zammarchi.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Tutte le Email',
  'LBL_ARCHIVED_MODULE_NAME' => 'Email Archiviate',
  'LBL_MODULE_NAME_NEW' => 'Archio Email',
  'LBL_MODULE_TITLE' => 'Email: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Email',
  'LBL_LIST_FORM_TITLE' => 'Lista Email',
  'LBL_NEW_FORM_TITLE' => 'Archivia Email',
  'LBL_LIST_SUBJECT' => 'Oggetto',
  'LBL_LIST_TYPE' => 'Tipo',
  'LBL_LIST_CONTACT' => 'Contatto',
  'LBL_LIST_RELATED_TO' => 'Riferito ',
  'LBL_LIST_DATE' => 'Data Invio',
  'LBL_LIST_TIME' => 'Ora Invio',
  'ERR_DELETE_RECORD' => 'Devi specificare il numero del record per cancellare l\'azienda.',
  'LBL_DATE_SENT' => 'Data Invio:',
  'LBL_SUBJECT' => 'Oggetto:',
  'LBL_BODY' => 'Messaggio:',
  'LBL_DATE_AND_TIME' => 'Data & Ora di Invio:',
  'LBL_DATE' => 'Date di Invio:',
  'LBL_TIME' => 'Ora di Invio:',
  'LBL_CONTACT_NAME' => 'Nome Contatto:',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => 'Sei sicuro di voler cancellare questo destinatario dalla email?',
  'LBL_INVITEE' => 'Destinatari',

'LNK_NEW_CALL'=>'Pianifica Chiamata',
'LNK_NEW_MEETING'=>'Pianifica Meeting',
'LNK_NEW_TASK'=>'Crea Attivit&#224;',
'LNK_NEW_NOTE'=>'Crea Nota o Allegato',
'LNK_NEW_EMAIL'=>'Archivia Email',
'LNK_CALL_LIST'=>'CHiamate',
'LNK_MEETING_LIST'=>'Meeting',
'LNK_TASK_LIST'=>'Attivit&#224;',
'LNK_NOTE_LIST'=>'Note',
'LNK_EMAIL_LIST'=>'Email',
'LNK_NEW_SEND_EMAIL'=>'Componi Email',
'LNK_ARCHIVED_EMAIL_LIST'=>'Email Archiviate',
'LNK_SENT_EMAIL_LIST'=>'Emails Inviate',
'LNK_ALL_EMAIL_LIST'=>'Tutte le Email',
'LNK_NEW_ARCHIVE_EMAIL'=>'Crea Una Mail Da Archiviare',
'LNK_VIEW_CALENDAR' => 'Oggi',

  'LBL_COMPOSE_MODULE_NAME' => 'Componi Email',
  'LBL_SENT_MODULE_NAME' => 'Email Inviate',
  'LBL_SEND' => 'INVIA',
  'LBL_SEARCH_FORM_SENT_TITLE' => 'Cerca Email Inviate',
  'LBL_LIST_FORM_SENT_TITLE' => 'Email Inviate',
  'LBL_SEND_BUTTON_LABEL'=>'Invia',
'LBL_SEND_BUTTON_TITLE' => 'Invia [Alt+S]',
'LBL_SAVE_AS_DRAFT_BUTTON_TITLE'=>'Salva Bozza',
'LBL_SAVE_AS_DRAFT_BUTTON_KEY'=>'Salva Bozza [Alt+R]',
'LBL_SAVE_AS_DRAFT_BUTTON_LABEL'=>'Salva Bozza',
'LBL_LIST_TO_ADDR'=>'A',
'LBL_TO_ADDRS'=>'A',
'LBL_FROM'=>'Da:',
'LBL_LIST_FROM_ADDR'=>'Da',





"LBL_BCC"=>"CcN:",
"LBL_CC"=>"Cc:",
"LBL_TO"=>"AA:",
"LBL_ERROR_SENDING_EMAIL"=>"Errore nell\'invio della posta",
"LBL_MESSAGE_SENT"=>"Messaggio Inviato",
'LNK_DRAFTS_EMAIL_LIST'=>'Bozza',
'LBL_SEARCH_FORM_DRAFTS_TITLE'=>'Cerca Bozze',
'LBL_LIST_FORM_DRAFTS_TITLE'=>'Bozza',
'LBL_ATTACHMENTS'=>'Allegati:',
'LBL_ADD_FILE'=>'Aggiungi File',
'LBL_ADD_ANOTHER_FILE'=>'Aggiungi Altro File',
'LBL_EMAIL_ATTACHMENT'=>'Allegato Email',
'LBL_CONTACT_FIRST_NAME'=>'Nome Contatto',
'LBL_CONTACT_LAST_NAME'=>'Cognome Contatto',
'ERR_NOT_ADDRESSED'=>'Il messaggio Email deve avere almeno un indirizzo nei campi A, CC, CCN',
'LBL_NOTE_SEMICOLON'=>'Nota: Usa compe separatore il punto e virgola per indirizzi email multipli.',
'WARNING_SETTINGS_NOT_CONF'=>'Attenzione: le impostazione email non sono state configurate per inviare posta.',
'LBL_EDIT_MY_SETTINGS'=>'Modifica Le Mie Impostazioni',
'LBL_NOT_SENT'=>'Errore Invio',
'LBL_LIST_CREATED'=>'Creato',

);


?>
