<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Epost Markedsf�ring',
  'LBL_MODULE_TITLE' => 'Epost Markedsf�ring: Hjem',
  'LBL_LIST_FORM_TITLE' => 'Epost Markedsf�ring Kampanjer',
  'LBL_PROSPECT_LIST_NAME' => 'Navn:',
  'LBL_NAME' => 'Navn: ',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_FROM_ADDR' => 'Fra Epost',
  'LBL_LIST_DATE_START' => 'Start Dato',
  'LBL_LIST_TEMPLATE_NAME' => 'Epost Mal',
  'LBL_LIST_STATUS' => 'Status',
  
  'LBL_DATE_ENTERED' => 'Dato Opprettet',
  'LBL_DATE_MODIFIED' => 'Dato Endret',
  'LBL_MODIFIED' => 'Endret Av: ',
  'LBL_CREATED' => 'Opprettet Av: ',

  'LBL_FROM_NAME' => 'Fra Navn: ',
  'LBL_FROM_ADDR' => 'Fra Epost Adresse: ',
  'LBL_DATE_START' => 'Start Dato',
  'LBL_TIME_START' => 'Start Tid',
  'LBL_START_DATE_TIME' => 'Start Dato & Tid: ',
  'LBL_TEMPLATE' => 'Epost Mal: ',
  
  'LBL_MODIFIED_BY' => 'Endret av: ',
  'LBL_CREATED_BY' => 'Opprettet Av: ',
  'LBL_DATE_CREATED' => 'Opprettet dato: ',
  'LBL_DATE_LAST_MODIFIED' => 'Endret dato: ',

  'LNK_NEW_CAMPAIGN' => 'Opprett Kampanje',
  'LNK_CAMPAIGN_LIST' => 'Kampanjer',
  'LNK_NEW_PROSPECT_LIST' => 'Lag Prospekt Liste',
  'LNK_PROSPECT_LIST_LIST' => 'Prospekt Liste',
  'LNK_NEW_PROSPECT' => 'Opprett Prospekt',
  'LNK_PROSPECT_LIST' => 'Prospekter',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Epost Markedsf�ring',
);
?>
