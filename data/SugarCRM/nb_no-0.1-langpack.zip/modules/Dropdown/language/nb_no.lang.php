<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Dropdown/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
'LBL_KEY' => 'N�kkel',
'LBL_VALUE' => 'Verdi',
'LBL_ADD' => 'Legg til',
'LBL_MOVE' => 'Flytt',
'LBL_INSERT' => 'Inserter',
'LBL_EDIT' => 'Endre',
'LBL_DELETE' => 'Slett',
'LBL_DROPDOWN' => 'Rullegardinmeny:',
'LBL_LANGUAGE' => 'Spr�k:',
'LBL_MODULE_NAME' => 'Rullegardingmeny',
'LBL_MODULE_TITLE' => 'Rullegardinmeny: Hjem',
'LBL_SEARCH_FORM_TITLE' => 'Velg Rullegardinmeny',
'LBL_LIST_FORM_TITLE' => 'Rullegardinmeny Liste',
'LBL_ACCOUNT_NAME' => 'Virksomhet Navn:',
'LNK_NEW_DROPDOWN' => 'Lag Rullegardinmeny',
'LNK_DROPDOWNS' => 'Rullegardinmenyer',
'LNK_UP' => 'Opp',
'LNK_DOWN' => 'Ned',
'LNK_INSERT' => 'Inserter',
'LNK_EDIT' => 'Endre',
'LNK_DELETE' => 'Slett',
);




?>
