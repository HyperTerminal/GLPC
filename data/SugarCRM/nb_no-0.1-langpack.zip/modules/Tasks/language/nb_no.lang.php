<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Tasks/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:16 psv Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Oppgaver',
'LBL_TASK' => 'Oppgaver: ',
'LBL_MODULE_TITLE' => ' Oppgaver : Hjem',
'LBL_SEARCH_FORM_TITLE' => ' S�k Oppgave',
'LBL_LIST_FORM_TITLE' => ' Oppgaveliste',
'LBL_NEW_FORM_TITLE' => ' Ny Oppgave',
'LBL_NEW_FORM_SUBJECT' => 'Vedr�rende:',
'LBL_NEW_FORM_DUE_DATE' => 'Sluttdato:',
'LBL_NEW_FORM_DUE_TIME' => 'Tid:',
'LBL_NEW_TIME_FORMAT' => '(24:00)',
'LBL_LIST_CLOSE' => 'Avslutt',
'LBL_LIST_SUBJECT' => 'Vedr�rende',
'LBL_LIST_CONTACT' => 'Kontakt',
'LBL_LIST_PRIORITY' => 'Prioritet',
'LBL_LIST_RELATED_TO' => 'Relatert til',
'LBL_LIST_DUE_DATE' => 'Sluttdato',
'LBL_LIST_DUE_TIME' => 'Tid',
'LBL_SUBJECT' => 'Vedr�rende:',
'LBL_STATUS' => 'Status:',
'LBL_DUE_DATE' => 'Sluttdato:',
'LBL_DUE_TIME' => 'Fullf�res innen:',
'LBL_PRIORITY' => 'Prioritet:',
'LBL_COLON' => ':',
'LBL_DUE_DATE_AND_TIME' => 'Sluttdato og tid:',
'LBL_START_DATE_AND_TIME' => 'Start Date & Time:',
'LBL_START_DATE' => 'Start Dato:',
'LBL_START_TIME' => 'Start Tid:',
'DATE_FORMAT' => '(����-mm-dd 24:00)',
'LBL_NONE' => 'ingen',
'LBL_CONTACT' => 'Kontakt:',
'LBL_PHONE' => 'Telefon:',
'LBL_EMAIL' => 'Epost:',
'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
'LBL_DESCRIPTION' => 'Beskrivelse:',
'LBL_NAME' => 'Navn:',
'LBL_CONTACT_NAME' => 'Kontakt Navn: ',
'LBL_LIST_COMPLETE' => 'Slutt:',
'LBL_LIST_STATUS' => 'Status:',
'LBL_DATE_DUE_FLAG' => 'Ingen Fullf�res Dato',
'LBL_DATE_START_FLAG' => 'Ingen Start Dato',
'ERR_DELETE_RECORD' => 'Et Postnummer m� oppgis for � slette Oppgaven.',
'ERR_INVALID_HOUR' => 'Angi tid mellom 0 og 24',
'LBL_DEFAULT_STATUS' => 'Ikke p�begynt',
'LBL_DEFAULT_PRIORITY' => 'Medium',
'LBL_LIST_MY_TASKS' => 'Mine �pne Oppgaver',
'LNK_NEW_CALL' => 'Ny Samtale',
'LNK_NEW_MEETING' => 'Nytt M�te',
'LNK_NEW_TASK' => 'Ny Oppgave',
'LNK_NEW_NOTE' => 'Nytt Notat',
'LNK_NEW_EMAIL' => 'Ny Epost',
'LNK_CALL_LIST' => 'Samtaler',
'LNK_MEETING_LIST' => 'M�ter',
'LNK_TASK_LIST' => 'Oppgaver',
'LNK_NOTE_LIST' => 'Notater',
'LNK_EMAIL_LIST' => 'Eposter',
'LNK_VIEW_CALENDAR' => 'I dag',
'LBL_CONTACT_FIRST_NAME' => 'Kontakt Fornavn',
'LBL_CONTACT_LAST_NAME' => 'Kontakt Etternavn',
);

?>
