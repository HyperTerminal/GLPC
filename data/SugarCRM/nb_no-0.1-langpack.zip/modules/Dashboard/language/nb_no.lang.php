<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Dashboard/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
'ERR_NO_OPPS' => 'Lag noen Mulige Salg f�r du kan se Salgsdiagram.',
'LBL_ALL_OPPORTUNITIES' => 'Total sum for alle Salgs Muligheter er ',
'LBL_CREATED_ON' => 'Sist kj�rt ',
'LBL_DATE_END' => 'Avslutter Dato',
'LBL_DATE_RANGE_TO' => 'til',
'LBL_DATE_RANGE' => 'Dato periode er',
'LBL_DATE_START' => 'Begynner Dato',
'LBL_EDIT' => 'Endre',
'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Viser Salgs Mulighet bel�p summert basert p� Mulighetens kilde (lead) og resultat for de valgte brukere hvor forventet avslutningsdato er innenfor spesifisert dato-periode. Resultat er basert p� om salgs-status er Lukket Vunnet, Lukket Tapt eller Annen verdi.',
'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Alle Salgsmuligheter, basert p� Mulighets-kilde og resultat',
'LBL_LEAD_SOURCE_FORM_DESC' => 'Viser summert salgsmulighet bel�p basert p� valgt mulighets-kilde for valgte brukere.',
'LBL_LEAD_SOURCE_FORM_TITLE' => 'Total Pipeline utfra Kilde',
'LBL_LEAD_SOURCE_OTHER' => 'Andre',
'LBL_LEAD_SOURCES' => 'Kilde referanser',
'LBL_MODULE_NAME' => 'Oversikt',
'LBL_MODULE_TITLE' => 'Oversikt: Hjem',
'LBL_MONTH_BY_OUTCOME_DESC' => 'Viser Salgs Mulighet bel�p summert basert p� m�ned for de valgte brukere hvor forventet avslutningsdato er innenfor spesifisert dato-periode. Resultat er basert p� om salgs-status er Lukket Vunnet, Lukket Tapt eller Annen verdi.',
'LBL_OPP_SIZE' => 'Salgs-st�rrelse i $1K',
'LBL_OPP_THOUSANDS' => 'K',
'LBL_OPPS_IN_LEAD_SOURCE' => 'salgsmuligheter hvor mulighetskilde er',
'LBL_OPPS_IN_STAGE' => 'salgsmuligheter hvor salgs fase er',
'LBL_OPPS_OUTCOME' => 'salgsmuligheter hvor resultat er',
'LBL_OPPS_WORTH' => 'salgsmuligheters verdi',
'LBL_PIPELINE_FORM_TITLE_DESC' => 'Viser oppsumerte bel�p for Salgs faser for dine Salgsmuligheter hvor forventet avsluttningsdato er innenfor de spesifiserte datoene.',
'LBL_REFRESH' => 'Oppdater',
'LBL_ROLLOVER_DETAILS' => 'F�r musen over en kolonne for mer detaljer.',
'LBL_ROLLOVER_WEDGE_DETAILS' => 'F�r musen over kanten for detaljer.',
'LBL_SALES_STAGE_FORM_DESC' => 'Viser oppsumerte Salgs Mulighet bel�p basert p� valgte salgs faser med forventet avluttningsdato innenfor det spesifiserte datointervallet.',
'LBL_SALES_STAGE_FORM_TITLE' => 'Total Pipeline utfra Salgsfase',
'LBL_SALES_STAGES' => 'Salgs faser',
'LBL_TOTAL_PIPELINE' => 'Total i Pipeline er',
'LBL_USERS' => 'Brukere',
'LBL_YEAR_BY_OUTCOME' => 'Pipeline for M�ned for Resultat',
'LBL_YEAR' => '�r:',
'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
'LNK_NEW_CALL' => 'Ny Samtale',
'LNK_NEW_CASE' => 'Ny Sak',
'LNK_NEW_CONTACT' => 'Ny Kontakt',
'LNK_NEW_ISSUE' => 'Rapporter Bug',
'LNK_NEW_LEAD' => 'Opprett Mulighet',
'LNK_NEW_MEETING' => 'Nytt M�te',
'LNK_NEW_NOTE' => 'Nytt Notat',
'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
'LNK_NEW_QUOTE' => 'Opprett Pristilbud',
'LNK_NEW_TASK' => 'Ny Oppgave',
'NTC_NO_LEGENDS' => 'Ingen',
);



?>
