<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	'LBL_LIST_CAMPAIGN'=> 'Kampanje',
	'LBL_LIST_FORM_PROCESSED_TITLE'=>'Behandlet',
	'LBL_LIST_FORM_TITLE'=>'K�',
	'LBL_LIST_FROM_EMAIL'=>'Fra Epost',
	'LBL_LIST_FROM_NAME'=>'Fra Navn',
	'LBL_LIST_IN_QUEUE'=>'Under Behandling',
	'LBL_LIST_RECIPIENT_EMAIL'=>'Mottaker Epost',
	'LBL_LIST_RECIPIENT_NAME'=>'Mottaker Navn',
	'LBL_LIST_SEND_ATTEMPTS'=>'Sende Fors�k',
	'LBL_LIST_SEND_DATE_TIME'=>'Sendt',
	'LBL_LIST_USER_NAME'=>'Bruker Navn',
	'LBL_MODULE_TITLE' => 'Epost K� Administrasjon',
	'LBL_SEARCH_FORM_PROCESSED_TITLE'=>'Behandlet S�k',
	'LBL_SEARCH_FORM_TITLE'=>'K� S�k',
	'LBL_VIEW_PROCESSED_EMAILS'=>'Se Bahandlet Epost',
	'LBL_VIEW_QUEUED_EMAILS'=>'Se Epost i K�',
);

?>
