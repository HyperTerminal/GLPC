<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Users/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:16 psv Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Brukere',
'LBL_MODULE_TITLE' => 'Brukere : Hjem',
'LBL_SEARCH_FORM_TITLE' => 'S�k Bruker',
'LBL_LIST_FORM_TITLE' => 'Brukerliste',
'LBL_NEW_FORM_TITLE' => 'Ny Bruker',
'LBL_USER' => 'Bruker:',
'LBL_LOGIN' => 'Logg inn',
'LBL_RESET_PREFERENCES' => 'Gjennopprett til Orginale Instillinger',
'LBL_TIME_FORMAT' => 'Tids Format:',
'LBL_DATE_FORMAT' => 'Dato Format:',
'LBL_TIMEZONE' => 'Tid n�:',
'LBL_CURRENCY' => 'Valuta:',
'LBL_LIST_NAME' => 'Navn',
'LBL_LIST_TITLE' => 'Title',
'LBL_LIST_LAST_NAME' => 'Etternavn',
'LBL_LIST_USER_NAME' => 'Brukernavn',
'LBL_LIST_DEPARTMENT' => 'Avdeling',
'LBL_LIST_EMAIL' => 'Epost',
'LBL_LIST_PRIMARY_PHONE' => 'Prim�r Telefon',
'LBL_LIST_ADMIN' => 'Admin',
'LBL_NEW_USER_BUTTON_TITLE' => 'Ny Bruker [Alt+N]',
'LBL_NEW_USER_BUTTON_LABEL' => 'Ny Bruker',
'LBL_NEW_USER_BUTTON_KEY' => 'N',
'LBL_ERROR' => 'Feil:',
'LBL_PASSWORD' => 'Passord:',
'LBL_USER_NAME' => 'Brukernavn:',
'LBL_FIRST_NAME' => 'Fornavn:',
'LBL_LAST_NAME' => 'Etternavn:',
'LBL_USER_SETTINGS' => 'Brukerinnstillinger',
'LBL_THEME' => 'Tema:',
'LBL_LANGUAGE' => 'Spr�k:',
'LBL_ADMIN' => 'Admin:',
'LBL_USER_INFORMATION' => 'Brukerinformasjon',
'LBL_OFFICE_PHONE' => 'Firmatelefon:',
'LBL_REPORTS_TO' => 'Rapporterer til:',
'LBL_REPORTS_TO_NAME' => 'Rapporterer Til (navn):',
'LBL_OTHER_PHONE' => 'Annen Tlf.:',
'LBL_OTHER_EMAIL' => 'Annen Epost:',
'LBL_NOTES' => 'Notater:',
'LBL_DEPARTMENT' => 'Avdeling:',
'LBL_STATUS' => 'Status:',
'LBL_TITLE' => 'Tittel:',
'LBL_ANY_PHONE' => 'Telefon:',
'LBL_ANY_EMAIL' => 'Epost:',
'LBL_ADDRESS' => 'Adresse:',
'LBL_CITY' => 'By:',
'LBL_STATE' => 'Fylke:',
'LBL_POSTAL_CODE' => 'Postnr:',
'LBL_COUNTRY' => 'Land:',
'LBL_NAME' => 'Navn:',
'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
'LBL_OTHER' => 'Annet:',
'LBL_FAX' => 'Faks:',
'LBL_EMAIL' => 'Epost:',
'LBL_EMAIL_OTHER' => 'Annen Epost:',
'LBL_HOME_PHONE' => 'Hjemmetelefon:',
'LBL_ADDRESS_INFORMATION' => 'Adresse Informasjon',
'LBL_PRIMARY_ADDRESS' => 'Prim�r Adresse:',
'LBL_CHANGE_PASSWORD_BUTTON_TITLE' => 'Endre Passord[Alt+P]',
'LBL_CHANGE_PASSWORD_BUTTON_KEY' => 'P',
'LBL_CHANGE_PASSWORD_BUTTON_LABEL' => 'Endre Passord',
'LBL_LOGIN_BUTTON_TITLE' => 'Logg inn [Alt+L]',
'LBL_LOGIN_BUTTON_KEY' => 'L',
'LBL_LOGIN_BUTTON_LABEL' => 'Logg inn',
'LBL_CHANGE_PASSWORD' => 'Endre Passord',
'LBL_OLD_PASSWORD' => 'Gammelt Passord:',
'LBL_NEW_PASSWORD' => 'Nytt Passord:',
'LBL_CONFIRM_PASSWORD' => 'Bekreft Passord:',
'LBL_EMPLOYEE_STATUS' => 'Ansatt Status:',
'LBL_MESSENGER_TYPE' => 'IM Type:',
'LBL_MESSENGER_ID' => 'IM Navn:',
'ERR_ENTER_OLD_PASSWORD' => 'Angi gammelt Passord.',
'ERR_ENTER_NEW_PASSWORD' => 'Angi Nytt Passord.',
'ERR_ENTER_CONFIRMATION_PASSWORD' => 'Bekreft Passord.',
'ERR_REENTER_PASSWORDS' => 'Angi Passord igjen.  \"Nytt Passord\" og \"Bekreft Passord\" stemte ikke overens.',
'ERR_INVALID_PASSWORD' => 'Du m� skrive et gyldig Brukernavn og Passord.',
'ERR_PASSWORD_CHANGE_FAILED_1' => 'Endring av Passord mislykktes for ',
'ERR_PASSWORD_CHANGE_FAILED_2' => ' mislyktes. Det nye Passordet m� oppgis.',
'ERR_PASSWORD_INCORRECT_OLD' => 'Feil gammelt Passord for Bruker $this->user_name. Skriv Passord igjen.',
'ERR_USER_NAME_EXISTS_1' => 'Brukernavnet ',
'ERR_USER_NAME_EXISTS_2' => ' finnes allerede. Samme brukernavn er ikke tillat.
Skriv et unikt brukernavn.',
'ERR_LAST_ADMIN_1' => 'Brukernavnet ',
'ERR_LAST_ADMIN_2' => ' er den eneste Administrator.  Minst en Bruker skal ha Administrator rettigheter.
Kontroller Admin bruker innstillingene.',
'LNK_NEW_USER' => 'Ny Bruker',
'LNK_USER_LIST' => 'Brukere',
'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for � slette Virksomheten.',
'LBL_RECEIVE_NOTIFICATIONS' => 'Tilordnings Notifikasjon:',
'LBL_RECEIVE_NOTIFICATIONS_TEXT' => 'Motta Epost n�r en oppgave blir tilordnet deg.',
'LBL_ADMIN_TEXT' => 'Gi administrator rettigheter til denne brukeren',
'LBL_PORTAL_ONLY' => 'Bruker kun for Portal:',
'LBL_PORTAL_ONLY_TEXT' => 'Brukeren er en portal-bruker og kan ikke logge inn via web grensesnittet. 
Denne brukeren er KUN for portaltjenesten. Normale brukere kan IKKE brukes til portaltjenesten.',
'LBL_TIME_FORMAT_TEXT' => 'Avgj�r hvordan tidspunkt vises',
'LBL_DATE_FORMAT_TEXT' => 'Avgj�r hvordan datoer vises',
'LBL_TIMEZONE_TEXT' => 'Sett n�v�rende tid.',
'LBL_GRIDLINE' => 'Vis m�nsterlinjer:',
'LBL_GRIDLINE_TEXT' => 'Kontrollerer m�nsterlinjer for detaljlister',
'LBL_CURRENCY_TEXT' => 'Velg standard valuta',
'LBL_DISPLAY_TABS' => 'Vis faner',
'LBL_HIDE_TABS' => 'Skjul faner',
'LBL_EDIT_TABS' => 'Endre faner',
'LBL_REMOVED_TABS' => 'Admin Fjern Faner',
'LBL_CHOOSE_WHICH' => 'Velg hvilke faner som vises',
'LBL_MAIL_OPTIONS_TITLE' => 'E-post Instillinger',
'LBL_MAIL_FROMNAME' => '"Fra" Navn:',
'LBL_MAIL_FROMADDRESS' => '"Fra" Adresse:',
'LBL_MAIL_SMTPSERVER' => 'SMTP Server:',
'LBL_MAIL_SMTPPORT' => 'SMTP Port:',
'LBL_MAIL_SENDTYPE' => 'Mail Transfer Agent:',
'LBL_MAIL_SMTPUSER' => 'SMTP Brukernavn:',
'LBL_MAIL_SMTPPASS' => 'SMTP Passord:',
'LBL_MAIL_SMTPAUTH_REQ' => 'Bruk SMTP Autentisering?',
'LBL_CALENDAR_OPTIONS' => 'Kalender Opsjoner',
'LBL_PUBLISH_KEY' => 'Publiserings Tast:',
'LBL_CHOOSE_A_KEY' => 'Velg en tast for � forhindre uautorisert publisering av din kalender',
'LBL_YOUR_PUBLISH_URL' => 'Publiser her:',
'LBL_YOUR_QUERY_URL' => 'Din Link (URL):',
'LBL_REMINDER' => 'Standard P�minnelse:',
'LBL_REMINDER_TEXT' => 'Standard tid for p�minnelse om kommende Samtale eller M�te',
'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Select Checked Users',
'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Select Checked Users',
'LBL_LIST_STATUS' => 'Status',
'LBL_MAX_TAB' => 'Antall Faner som kan vises :',
'LBL_SEARCH_URL' => 'S�keside:',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Brukere',
'LBL_ADDRESS_STREET' => 'Adresse - Gate/ vei:',
'LBL_ADDRESS_CITY' => 'Adresse - By/ Sted:',
'LBL_ADDRESS_COUNTRY' => 'Adresse - Land:',
'LBL_ADDRESS_STATE' => 'Adresse - Fylke:',
'LBL_ADDRESS_POSTALCODE' => 'Adresse - Postnummer:',
'LBL_PHONE' => 'Tlf:',
'LBL_WORK_PHONE' => 'Tlf Arbeid:',
'LBL_FAX_PHONE' => 'Faks:',
'LBL_DESCRIPTION' => 'Beskrivelse:',
'LBL_IS_ADMIN' => 'Er Administrator',
);

?>
