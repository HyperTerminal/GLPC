<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Meetings/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'M�ter',
'LBL_MODULE_TITLE' => 'M�ter : Hjem',
'LBL_SEARCH_FORM_TITLE' => 'S�k M�te',
'LBL_LIST_FORM_TITLE' => 'M�teliste',
'LBL_NEW_FORM_TITLE' => 'Avtal M�te',
'LBL_SCHEDULING_FORM_TITLE' => 'Tidsplan',
'LBL_LIST_SUBJECT' => 'Vedr�rende',
'LBL_LIST_CONTACT' => 'Kontakt Navn',
'LBL_LIST_RELATED_TO' => 'Relatert til',
'LBL_LIST_DATE' => 'Start Dato',
'LBL_LIST_TIME' => 'Start Tid',
'LBL_LIST_CLOSE' => 'Avslutt',
'LBL_SUBJECT' => 'Vedr�rende: ',
'LBL_STATUS' => 'Status:',
'LBL_LOCATION' => 'Sted:',
'LBL_DATE_TIME' => 'Start Dato & Tid:',
'LBL_DATE' => 'Start Dato:',
'LBL_TIME' => 'Start Tid:',
'LBL_DURATION' => 'Varighet',
'LBL_DURATION_HOURS' => 'Varighet Timer:',
'LBL_DURATION_MINUTES' => 'Varighet Minutter:',
'LBL_HOURS_MINS' => '(timer/minutter)',
'LBL_CONTACT_NAME' => 'Kontakt Navn: ',
'LBL_MEETING' => 'M�te:',
'LBL_DESCRIPTION_INFORMATION' => 'Beskrivelse',
'LBL_DESCRIPTION' => 'Beskrivelse:',
'LBL_COLON' => ':',
'LBL_DEFAULT_STATUS' => 'Planlagt',
'LNK_NEW_CALL' => 'Ny Samtale',
'LNK_NEW_MEETING' => 'Nytt M�te',
'LNK_NEW_TASK' => 'Ny Oppgave',
'LNK_NEW_NOTE' => 'Nytt Notat',
'LNK_NEW_EMAIL' => 'Ny Epost',
'LNK_CALL_LIST' => 'Samtaler',
'LNK_MEETING_LIST' => 'M�ter',
'LNK_TASK_LIST' => 'Oppgaver',
'LNK_NOTE_LIST' => 'Notater',
'LNK_EMAIL_LIST' => 'Epost',
'LNK_VIEW_CALENDAR' => 'I dag',
'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for � slette m�tet.',
'NTC_REMOVE_INVITEE' => 'Er du sikker p� � slette deltageren fra M�te?',
'LBL_INVITEE' => 'Inviterte',
'LNK_NEW_APPOINTMENT' => 'Lag Avtale',
'LBL_ADD_INVITEE' => 'Legg til Deltager',
'LBL_NAME' => 'Navn',
'LBL_FIRST_NAME' => 'Fornavn',
'LBL_LAST_NAME' => 'Etternavn',
'LBL_EMAIL' => 'Epost',
'LBL_PHONE' => 'Telefon Arbeid:',
'LBL_REMINDER' => 'P�minnelse:',
'LBL_SEND_BUTTON_TITLE' => 'Send M�teinvitasjon til Deltakerene [Alt+I]',
'LBL_SEND_BUTTON_KEY' => 'I',
'LBL_SEND_BUTTON_LABEL' => 'Send M�teinvitasjon',
'LBL_REMINDER_TIME' => 'P�minnelse Tid',
'LBL_MODIFIED_BY' => 'Endret Av',
'LBL_CREATED_BY' => 'Opprettet Av',
'LBL_DATE_END' => 'Slutt Dato',
'LBL_SEARCH_BUTTON' => 'S�k',
'LBL_ADD_BUTTON' => 'Legg til',
'LBL_DEL' => 'Fjern',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'M�ter',
'LBL_LIST_STATUS' => 'Status',
'LBL_LIST_DUE_DATE' => 'Utf�res Innen Dato',
'LBL_LIST_DATE_MODIFIED' => 'Dato Endret',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontaktet',
'LBL_USERS_SUBPANEL_TITLE' => 'Brukere',
);



?>
