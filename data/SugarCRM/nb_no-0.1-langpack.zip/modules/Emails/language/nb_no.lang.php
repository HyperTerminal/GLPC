<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Emails/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:
 ********************************************************************************/

$mod_strings = array (
'LBL_MODULE_NAME' => 'Epost',
'LBL_ARCHIVED_MODULE_NAME' => 'Arkivert Epost',
'LBL_MODULE_NAME_NEW' => 'Arkiver Epost',
'LBL_MODULE_TITLE' => 'Epost : Hjem',
'LBL_SEARCH_FORM_TITLE' => 'S�k Epost',
'LBL_LIST_FORM_TITLE' => 'Epost liste',
'LBL_NEW_FORM_TITLE' => 'Oppf�lgings Epost',
'LBL_LIST_SUBJECT' => 'Vedr�rende',
'LBL_LIST_TYPE' => 'Type',
'LBL_LIST_CONTACT' => 'Kontakt',
'LBL_LIST_RELATED_TO' => 'Relatert til',
'LBL_LIST_DATE' => 'Sendt Dato',
'LBL_LIST_TIME' => 'Sendt Tid',
'ERR_DELETE_RECORD' => 'Et Postnummer skal oppgis for � slette Virksomheten.',
'LBL_DATE_SENT' => 'Sendt Dato:',
'LBL_SUBJECT' => 'Vedr�rende:',
'LBL_BODY' => 'Innhold:',
'LBL_DATE_AND_TIME' => 'Sendt Dato & Tid:',
'LBL_DATE' => 'Sendt Dato:',
'LBL_TIME' => 'Sendt Tid:',
'LBL_CONTACT_NAME' => ' Kontakt Navn: ',
'LBL_EMAIL' => 'Epost:',
'LBL_COLON' => ':',
'NTC_REMOVE_INVITEE' => 'Er du sikker p� � slette denne mottakeren fra Epost?',
'LBL_INVITEE' => 'Mottakere',

'LNK_NEW_CALL' => 'Ny Samtale',
'LNK_NEW_MEETING' => 'Nytt M�te',
'LNK_NEW_TASK' => 'Ny Oppgave',
'LNK_NEW_NOTE' => 'Nytt Notat',
'LNK_NEW_EMAIL' => 'Ny Epost',
'LNK_CALL_LIST' => 'Samtaler',
'LNK_MEETING_LIST' => 'M�ter',
'LNK_TASK_LIST' => 'Oppgaver',
'LNK_NOTE_LIST' => 'Notater',
'LNK_EMAIL_LIST' => 'Eposter',
'LNK_NEW_SEND_EMAIL' => 'Opprett Epost',
'LNK_ARCHIVED_EMAIL_LIST' => 'Arkivert Epost',
'LNK_SENT_EMAIL_LIST' => 'Sendt Epost',
'LNK_ALL_EMAIL_LIST' => 'All Epost',
'LNK_NEW_ARCHIVE_EMAIL' => 'Arkiver Epost',
'LNK_VIEW_CALENDAR' => 'I dag',

'LBL_COMPOSE_MODULE_NAME' => 'Opprett Epost',
'LBL_SENT_MODULE_NAME' => 'Sendt Epost',
'LBL_SEND' => 'SEND',
'LBL_SEARCH_FORM_SENT_TITLE' => 'S�k Sendt Epost',
'LBL_LIST_FORM_SENT_TITLE' => 'Sendr Epost',
'LBL_SEND_BUTTON_LABEL' => 'Send',
'LBL_SEND_BUTTON_TITLE' => 'Send [Alt+S]',
'LBL_SEND_BUTTON_KEY' => 'S',
'LBL_SAVE_AS_DRAFT_BUTTON_TITLE' => 'Lagre Kladd [Alt+R]',
'LBL_SAVE_AS_DRAFT_BUTTON_KEY' => 'R',
'LBL_SAVE_AS_DRAFT_BUTTON_LABEL' => 'Lagre Kladd',
'LBL_LIST_TO_ADDR' => 'Til',
'LBL_TO_ADDRS' => 'Til',
'LBL_FROM' => 'Fra:',
'LBL_LIST_FROM_ADDR' => 'Fra',
'LNK_NEW_EMAIL_TEMPLATE' => 'Lag Epost Mal',
'LNK_EMAIL_TEMPLATE_LIST' => 'Epost Maler',
'LBL_USE_TEMPLATE' => 'Bruk Mal:',
'LBL_BCC' => 'Bcc:',
'LBL_CC' => 'Kopi:',
'LBL_TO' => 'Til:',
'LBL_ERROR_SENDING_EMAIL' => 'Feil ved sending av epost',
'LBL_MESSAGE_SENT' => 'Melding Sendt',
'LNK_DRAFTS_EMAIL_LIST' => 'Kladd',
'LBL_SEARCH_FORM_DRAFTS_TITLE' => 'S�k Kladd',
'LBL_LIST_FORM_DRAFTS_TITLE' => 'Kladd',
'LBL_ATTACHMENTS' => 'Vedlegg:',
'LBL_ADD_FILE' => 'Legg til Fil',
'LBL_ADD_ANOTHER_FILE' => 'Legg til enda en Fil',
'LBL_EMAIL_ATTACHMENT' => 'Epost Vedlegg',
'LBL_CONTACT_FIRST_NAME' => 'Kontakt Fornavn',
'LBL_CONTACT_LAST_NAME' => 'Kontakt Etternavn',
'ERR_NOT_ADDRESSED' => 'En Epost m� ha Til, Kopi eller Bcc adresse',
'LBL_NOTE_SEMICOLON' => 'Merk: Bruk semi-kolon (;) mellom flere epostadresser.',
'WARNING_SETTINGS_NOT_CONF' => 'Advarsel: Epostinstillingene dine er ikke satt opp skikkelig for sending av epost.',
'LBL_EDIT_MY_SETTINGS' => 'Endre Mine Instillinger',
'LBL_NOT_SENT' => 'Feil ved sending',
'LBL_LIST_CREATED' => 'Opprettet',
'LBL_EMAIL_SELECTOR' => 'Valgt',
'LBL_CREATED_BY' => 'Opprettet av',
'LBL_DESCRIPTION' => 'Beskrivelse',
'LBL_FROM_NAME' => 'Fra Navn',
'LBL_LIST_CONTACT_NAME' => 'Kontakt Navn',
'LBL_LIST_DATE_SENT' => 'Dato Sendt',
'LBL_MODIFIED_BY' => 'Endret av',
'LBL_HTML_BODY' => 'HTML Hoveddel (body)',
'LBL_TEXT_BODY' => 'Tekst Hoveddel (body)',
'LBL_EDIT_ALT_TEXT' => 'Endre Alt Tekst',
'LBL_SHOW_ALT_TEXT' => 'Vis Alt Tekst',
'LBL_USERS' => 'Brukere',
'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakter',
'LBL_USERS_SUBPANEL_TITLE' => 'Brukere',
);
?>
