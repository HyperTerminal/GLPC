<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/EmailTemplates/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Epost Mal',
  'LBL_MODULE_TITLE' => 'Epost Mal: Hjem',
  'LBL_SEARCH_FORM_TITLE' => 'Epost Mal S�k',
  'LBL_LIST_FORM_TITLE' => 'Epost Mal Liste',
  'LBL_NEW_FORM_TITLE' => 'Lag Epost Mal',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_LIST_DESCRIPTION' => 'Beskrivelse',
  'LBL_LIST_DATE_MODIFIED' => 'Sist Endret',
  'LBL_NAME' => 'Navn:',
  'LBL_DESCRIPTION' => 'Beskrivelse:',
  'LBL_SUBJECT' => 'Tittel:',
  'LBL_CLOSE' => 'Steng:',
  'LBL_RELATED_TO' => 'Relatert Til:',
  'LBL_BODY' => 'Hoveddel:',
  'LBL_PUBLISH' => 'Publiser:',
  'LBL_COLON' => ':',

'LNK_NEW_EMAIL_TEMPLATE'=>'Opprett Epost Mal',
'LNK_EMAIL_TEMPLATE_LIST'=>'Epost Maler',
'LNK_IMPORT_NOTES'=>'Importer Notater',
'LNK_VIEW_CALENDAR' => 'I dag',
'LNK_CHECK_EMAIL'=>'Sjekk Epost',
'LNK_NEW_SEND_EMAIL'=>'Skriv ny Epost',
'LNK_ARCHIVED_EMAIL_LIST'=>'Arkivert Epost',
'LNK_SENT_EMAIL_LIST'=>'Sendt Epost',
'LNK_NEW_EMAIL'=>'Arkiver Epost',
'LBL_INSERT_VARIABLE'=>'Legg inn variabel:',
'LBL_INSERT'=>'Legg inn',
'LNK_DRAFTS_EMAIL_LIST'=>'Kladd',
'LNK_ALL_EMAIL_LIST'=>'Alle Eposter',
'LNK_NEW_ARCHIVE_EMAIL'=>'Opprett Arkivert Epost',
'LBL_CONTACT_AND_OTHERS'=>'Kontakt/Prospect/etc',
'LBL_HTML_BODY'=>'HTML Hoveddel (body)',
'LBL_TEXT_BODY'=>'Tekst Hoveddel (body)',
'LBL_EDIT_ALT_TEXT'=>'Endre Alt Tekst',
'LBL_SHOW_ALT_TEXT'=>'Vis Alt Tekst',

);


?>
