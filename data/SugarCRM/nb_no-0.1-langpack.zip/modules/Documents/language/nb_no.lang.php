<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Id: nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumenter',
	'LBL_MODULE_TITLE' => 'Dokumenter: Hjem',
	'LNK_NEW_DOCUMENT' => 'Opprett Dokument',
	'LNK_DOCUMENT_LIST'=> 'Dokument Liste',
	'LBL_DOC_REV_HEADER' => 'Dokument Versjon',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'Dokument Id',	
	'LBL_NAME' => 'Dokument Navn',
	'LBL_DESCRIPTION' => 'Beskrivelse',
	'LBL_CATEGORY' => 'Kategori',
	'LBL_SUBCATEGORY' => 'Underkategori',
	'LBL_STATUS' => 'Status', 
	'LBL_CREATED_BY'=> 'Opprettet Av',
	'LBL_DATE_ENTERED'=> 'Dato Opprettet',
	'LBL_DATE_MODIFIED'=> 'Dato Endret',
	'LBL_DELETED' => 'Slettet',
	'LBL_MODIFIED'=> 'Endret Av',
	'LBL_CREATED'=> 'Opprettet Av',
	
	'LBL_REVISION_NAME' => 'Versjons Nummer',
	'LBL_FILENAME' => 'Filnavn',
	'LBL_MIME' => 'MIME Type',
	'LBL_REVISION' => 'Versjon',
	'LBL_DOCUMENT' => 'Relatert Dokument',
	'LBL_LATEST_REVISION' => 'Siste Rersjon',
	'LBL_CHANGE_LOG'=> 'Endre Logg',
	'LBL_ACTIVE_DATE'=> 'Plubliserings Dato',
	'LBL_EXPIRATION_DATE' => 'Utl�psdato',
	'LBL_FILE_EXTENSION'  => 'Filtype',
	
	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Uspesifiesert',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Dokument Navn:',
	'LBL_FILENAME' => 'Fil Navn:',
	'LBL_DOC_VERSION' => 'Versjon:',
	'LBL_CATEGORY_VALUE' => 'Kategori:',
	'LBL_SUBCATEGORY_VALUE'=> 'Underkategori:',
	'LBL_DOC_STATUS'=> 'Status:',
	'LBL_LAST_REV_CREATOR' => 'Versjon Opprettet Av:',
	'LBL_LAST_REV_DATE' => 'Versjons Dato:',
	'LBL_DOWNNLOAD_FILE'=> 'Last Ned Fil:',
	



	'LBL_DOC_DESCRIPTION'=>'Beskrivelse:',
	'LBL_DOC_ACTIVE_DATE'=> 'Publiserings Dato:',
	'LBL_DOC_EXP_DATE'=> 'Utl�psdato:',
	
	//document list view.	
	'LBL_LIST_FORM_TITLE' => 'Dokument Liste',	
	'LBL_LIST_DOCUMENT' => 'Dokument',
	'LBL_LIST_CATEGORY' => 'Kategori',
	'LBL_LIST_SUBCATEGORY' => 'Underkategori',
	'LBL_LIST_REVISION' => 'Versjon',
	'LBL_LIST_LAST_REV_CREATOR' => 'Publisert av',
	'LBL_LIST_LAST_REV_DATE' => 'Versjonsdato',
	'LBL_LIST_VIEW_DOCUMENT'=>'Se p�',
	'LBL_LIST_ACTIVE_DATE' => 'Publiseringsdato',
	'LBL_LIST_EXP_DATE' => 'Utl�psdato',
	
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Versjoner',
	'LBL_REV_LIST_ENTERED' => 'Dato Opprettet',
	'LBL_REV_LIST_CREATED' => 'Opprettet av',
	'LBL_REV_LIST_LOG'=> 'Endringslogg',
	
	'LBL_CURRENT_DOC_VERSION'=> 'Gjeldende Versjon:',
	'LBL_CHANGE_LOG'=> 'Endre Log:',
	'LBL_SEARCH_FORM_TITLE'=> 'Dokument S�k',
	//document search form.
	'LBL_SF_DOCUMENT' => 'Dokument Navn:',
	'LBL_SF_CATEGORY' => 'Kategori:',
	'LBL_SF_SUBCATEGORY'=> 'Underkategori:',
	'LBL_SF_ACTIVE_DATE' => 'Publiseringsdato:',
	'LBL_SF_EXP_DATE'=> 'Utl�psdato:',
	
	'DEF_CREATE_LOG' => 'Dokument Opprettet',
	
	//error messages
	'ERR_DOC_NAME'=>'Dokument Navn',
	'ERR_DOC_ACTIVE_DATE'=>'Publiseringsdato',
	'ERR_DOC_EXP_DATE'=> 'Utl�psdato',
	'ERR_FILENAME'=> 'Fil navn',
	'ERR_DOC_VERSION'=> 'Dokument Versjon',
	'ERR_DELETE_CONFIRM'=> '�nsker du � slette denne versjonen av dokumentet?',
	'ERR_DELETE_LATEST_VERSION'=> 'Det er ikke tillatt � slette siste versjon av et dokument.',

);


?>
