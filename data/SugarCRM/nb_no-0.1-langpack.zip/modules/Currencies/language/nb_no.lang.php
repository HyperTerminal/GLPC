<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /cvsroot/langpack-no/langpack-no/modules/Currencies/language/nb_no.lang.php,v 1.1 2005/10/23 17:07:15 psv Exp $
 * Description:
 ********************************************************************************/


$mod_strings = array (
'LBL_LIST_FORM_TITLE' => 'Valutaer',
'LBL_CURRENCY' => 'Valuta',
'LBL_ADD' => 'Legg til',
'LBL_MERGE' => 'Sl� sammen',
'LBL_MERGE_TXT' => 'Vennligst velg de valutaene du vil assiosiere med den valgte valutaen. Dette vil fjerne alle markerte valutaer og assosiere de med den valgte valutaen.',
'LBL_US_DOLLAR' => 'U.S. Dollar',
'LBL_DELETE' => 'Slett',
'LBL_LIST_SYMBOL' => 'Valuta Symbol',
'LBL_LIST_NAME' => 'Valuta Navn',
'LBL_LIST_ISO4217' => 'ISO 4217 Kode',
'LBL_UPDATE' => 'Oppdater',
'LBL_LIST_RATE' => 'Vekslingskurs',
'LBL_LIST_STATUS' => 'Status',
'LNK_NEW_CONTACT' => 'Ny Kontakt',
'LNK_NEW_ACCOUNT' => 'Ny Virksomhet',
'LNK_NEW_OPPORTUNITY' => 'Ny Salgs Mulighet',
'LNK_NEW_CASE' => 'Ny Sak',
'LNK_NEW_NOTE' => 'Opprett Notat',
'LNK_NEW_CALL' => 'Ny Samtale',
'LNK_NEW_EMAIL' => 'Ny Epost',
'LNK_NEW_MEETING' => 'Nytt M�te',
'LNK_NEW_TASK' => 'Opprett Oppgave',
'NTC_DELETE_CONFIRMATION' => 'Sikker p� at du vil slette denne valutaen?  Det er muligens bedre � endre status til inaktiv. Ellers vil ethvert element som bruker denne valutaen bli endret til US. Dollars n�r de blir brukt..',
'currency_status_dom' => 
array (
'Active' => 'Aktiv',
'Inactive' => 'Inaktiv',
),
);

?>
