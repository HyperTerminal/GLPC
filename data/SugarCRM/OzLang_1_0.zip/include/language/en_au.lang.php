<?php
include('en_us.lang.php');
?>
