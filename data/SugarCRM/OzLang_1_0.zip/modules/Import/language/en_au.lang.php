<?php
include('en_us.lang.php');
$contacts_import_fields["primary_address_postalcode"]="Primary Address Postcode";
$contacts_import_fields["alt_address_postalcode"]="Other Address Postcode";
$accounts_import_fields["billing_address_postalcode"]="Billing Address Postcode";
$accounts_import_fields["shipping_address_postalcode"]="Shipping Address Postcode";
$leads_import_fields["primary_address_postalcode"]="Primary Address Postcode";
$leads_import_fields["alt_address_postalcode"]="Other Address Postcode";
?>
