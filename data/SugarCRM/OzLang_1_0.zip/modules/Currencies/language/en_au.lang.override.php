<?php
$mod_strings[LBL_US_DOLLAR] = 'Aust. Dollar';
$mod_strings[LBL_US_DOLLAR_SYMBOL] = '$';
$mod_strings[LBL_US_DOLLAR_ISO4217] = 'AUD';
$mod_strings['NTC_DELETE_CONFIRMATION'] = 'Are you sure you want to delete this record? It may be better to set the status to inactive otherwise any record using this currency will be converted to Australian Dollars when they are acceessed.';
?>
