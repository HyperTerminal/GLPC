<?php
include('en_us.lang.php');
$mod_strings['LBL_PRIMARY_ADDRESS_POSTALCODE'] = 'Primary Address Postcode:';
$mod_strings['LBL_ALT_ADDRESS_POSTALCODE'] = 'Alternate Address Postcode:';
$mod_strings['LBL_POSTAL_CODE'] = 'Postcode:';

?>
