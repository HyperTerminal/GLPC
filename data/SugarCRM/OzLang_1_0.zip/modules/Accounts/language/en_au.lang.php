<?php
include('en_us.lang.php');
$mod_strings['LBL_BILLING_ADDRESS_POSTALCODE'] = 'Billing Address Postcode:';
$mod_strings['LBL_SHIPPING_ADDRESS_POSTALCODE'] = 'Shipping Address Postcode:';
$mod_strings['LBL_POSTAL_CODE'] = 'Postcode:';
?>
