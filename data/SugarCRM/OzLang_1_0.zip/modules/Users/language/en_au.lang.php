<?php
include('en_us.lang.php');
$mod_strings['LBL_POSTAL_CODE'] = 'Postcode:';
?>
