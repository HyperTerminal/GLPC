<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'Waluty',
  'LBL_CURRENCY' => 'Waluta',
  'LBL_ADD' => 'Dodaj',
  'LBL_MERGE' => 'Połącz',
  'LBL_MERGE_TXT' => 'Proszę zaznaczyć waluty, które chcesz zmapować na wybraną walutę. To usunie wszystkie zaznaczone waluty i przypisze wartości im przypisane wybranej walucie.',
  'LBL_US_DOLLAR' => 'Dolar amerykański',
  'LBL_DELETE' => 'Usuń',
  'LBL_LIST_SYMBOL' => 'Symbol waluty',
  'LBL_LIST_NAME' => 'Nazwa waluty',
  'LBL_LIST_ISO4217' => 'Kod ISO 4217',
  'LBL_UPDATE' => 'Aktualizuj',
  'LBL_LIST_RATE' => 'Przelicznik',
  'LBL_LIST_STATUS' => 'Status',
  'LNK_NEW_CONTACT' => 'Nowy kontakt',
  'LNK_NEW_ACCOUNT' => 'Nowy klient',
  'LNK_NEW_OPPORTUNITY' => 'Nowa szansa',
  'LNK_NEW_CASE' => 'Utwórz sprawę',
  'LNK_NEW_NOTE' => 'Utwórz notatkę lub załącznik',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę tel.',
  'LNK_NEW_EMAIL' => 'Utwórz email',
  'LNK_NEW_MEETING' => 'Nowe spotkanie',
  'LNK_NEW_TASK' => 'Utwórz zadanie',
  'NTC_DELETE_CONFIRMATION' => 'Czy na pewno usunąć tą walutę? Może lepiej zaznaczyć ją jako nie aktywną. W przeciwnym wypadku wszystkie wpisy używające tej waluty zostaną zamienione na złotówki w momencie otwarcia.',
  'currency_status_dom' => 
  array (
    'Active' => 'Aktywna',
    'Inactive' => 'Nie aktywna',
  ),
);


?>
