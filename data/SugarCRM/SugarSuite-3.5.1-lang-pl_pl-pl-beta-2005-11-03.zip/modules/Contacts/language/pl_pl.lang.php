<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Kontakty',
  'LBL_INVITEE' => 'Direct Reports',
  'LBL_MODULE_TITLE' => 'Kontakty: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukiwanie kontaktów',
  'LBL_LIST_FORM_TITLE' => 'Lista kontaktów',
  'LBL_NEW_FORM_TITLE' => 'Nowy kontakt',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Contact-Opportunity:',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_BUSINESSCARD' => 'Wizytówka',
  'LBL_LIST_NAME' => 'Nazwa',
  'LBL_LIST_LAST_NAME' => 'Nazwisko',
  'LBL_LIST_CONTACT_NAME' => 'Nazwisko kontaktowe',
  'LBL_LIST_TITLE' => 'Tytuł',
  'LBL_LIST_ACCOUNT_NAME' => 'Nazwa klienta',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email 1',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Email 2',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_CONTACT_ROLE' => 'Rola',
  'LBL_LIST_FIRST_NAME' => 'Imię',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Użyto istniejący kontakt',
  'LBL_CREATED_CONTACT' => 'Dodano nowy kontakt',
  'LBL_EXISTING_ACCOUNT' => 'Użyto istniejącego klienta',
  'LBL_EXISTING_OPPORTUNITY'=> 'Użyto istniejącą szansę',
  'LBL_CREATED_ACCOUNT' => 'Dodano nowego klienta',
  'LBL_CREATED_CALL' => 'Zaplanowano nową rozmowę tel.',
  'LBL_CREATED_MEETING' => 'Zaplanowano nowe spotkanie',
  'LBL_ADDMORE_BUSINESSCARD' => 'Dodaj następną wizytówkę',
  'LBL_ADD_BUSINESSCARD' => 'Dodaj wizytówkę',
  'LBL_NAME' => 'Nazwa:',
  'LBL_CONTACT_NAME' => 'Nazwisko kontaktowe:',
  'LBL_CONTACT_INFORMATION' => 'Informacje kontaktowe',
  'LBL_FIRST_NAME' => 'Imię:',
  'LBL_OFFICE_PHONE' => 'Telefon 1:',
  'LBL_ACCOUNT_NAME' => 'Nazwa klienta:',
  'LBL_ACCOUNT_ID' => 'ID klienta',

  'LBL_ANY_PHONE' => 'Tel. 4:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Nazwisko:',
  'LBL_MOBILE_PHONE' => 'Telefon komórkowy:',
  'LBL_HOME_PHONE' => 'Telefon domowy:',
  'LBL_LEAD_SOURCE' => 'Źródło pozyskania:',
  'LBL_OTHER_PHONE' => 'Telefon 2:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Ulica:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Miasto:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Państwo:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Województwo:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Kod pocztowy:',
  'LBL_ALT_ADDRESS_STREET' => 'Ulica:',
  'LBL_ALT_ADDRESS_CITY' => 'Miasto:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Państwo:',
  'LBL_ALT_ADDRESS_STATE' => 'Województwo:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Kod pocztowy:',
  'LBL_TITLE' => 'Tytuł:',
  'LBL_DEPARTMENT' => 'Dział:',
  'LBL_BIRTHDATE' => 'Data urodzenia:',
  'LBL_EMAIL_ADDRESS' => 'Email 1:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email 2:',
  'LBL_ANY_EMAIL' => 'Email 3:',
  'LBL_REPORTS_TO' => 'Odpowiada przed:',
  'LBL_ASSISTANT' => 'Asystent:',
  'LBL_PORTAL_NAME' => 'Portal Name:',
  'LBL_NEW_PORTAL_PASSWORD' => 'New Portal Password:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Password Is Set:',
  'LBL_PORTAL_ACTIVE' => 'Portal Active:',
  'LBL_PORTAL_INFORMATION' => 'Portal Information',
  'LBL_ASSISTANT_PHONE' => 'Tel. asystenta:',
  'LBL_DO_NOT_CALL' => 'Nie dzwonić:',
  'LBL_EMAIL_OPT_OUT' => 'Wypisany z mailingu:',
  'LBL_PRIMARY_ADDRESS' => 'Adres podstawowy:',
  'LBL_ALTERNATE_ADDRESS' => 'Adres dodatkowy:',
  'LBL_ANY_ADDRESS' => 'Adres:',
  'LBL_CITY' => 'Miasto:',
  'LBL_STATE' => 'Województwo:',
  'LBL_PORTAL_APP'=>'Portal Application',
  'LBL_POSTAL_CODE' => 'Kod pocztowy:',
  'LBL_COUNTRY' => 'Państwo:',
  'LBL_DESCRIPTION_INFORMATION' => 'Opis',
  'LBL_ADDRESS_INFORMATION' => 'Informacje adresowe',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_CONTACT_ROLE' => 'Rola:',
  'LBL_REPORTS_TO_ID'=>'Reports to ID',
  'LBL_OPP_NAME' => 'Nazwa szansy:',
  'LBL_IMPORT_VCARD' => 'Importuj vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatycznie utwórz nowy kontakt poprzez import vCard ze swojego komputera.',
  'LBL_DUPLICATE' => 'Możliwość zdublowania kontaktów',
  'MSG_SHOW_DUPLICATES' => 'Istnieje możliwość utworzenia kopii tego kontaktu. Możesz kliknąć Utwórz kontakt aby kontynuować lub klinknij Anuluj.',
  'MSG_DUPLICATE' => 'Istnieje możliwość utworzenia kopii tego kontaktu. Możesz wybrać kontakt z listy poniżej lub kliknąć Utwórz kontakt aby utworzyć nowy.',
  'LNK_CONTACT_LIST' => 'Kontakty',
  'LNK_IMPORT_VCARD' => 'Utwórz z vCard',



  'LNK_NEW_CONTACT' => 'Dodaj kontakt',
  'LNK_NEW_ACCOUNT' => 'Dodaj klienta',
  'LNK_NEW_OPPORTUNITY' => 'Nowa szansa',
  'LNK_NEW_CASE' => 'Utwórz sprawę',
  'LNK_NEW_NOTE' => 'Utwórz notatkę',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę tel.',
  'LNK_NEW_EMAIL' => 'Dodaj email',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Utwórz zadanie',
  'LNK_NEW_APPOINTMENT' => 'Zaplanuj spotkanie',
  'NTC_DELETE_CONFIRMATION' => 'Czy na pewno usunąć ten wpis?',
  'NTC_REMOVE_CONFIRMATION' => 'Czy na pewno usunąć ten kontakt ze sprawy?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Are you sure you want to remove this record as a direct report?',
  'ERR_DELETE_RECORD' => 'Musi być wprowadzony numer rekordu aby usunąć kontakt.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Skopuj adres podstawowy jako dodatkowy',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Skopuj adres dodatkowy jako podstawowy',
  'LBL_SALUTATION' => 'Tytuł',
  'LBL_SAVE_CONTACT' => 'Zapisz kontakt',
  'LBL_CREATED_OPPORTUNITY' =>'Utworzono nową szansę',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Utworzenie szansy wymaga klienta. Utwórz nowego lub wybierz już istniejącego.',
  'LNK_SELECT_ACCOUNT' => "Wybierz klienta",
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Wybierz zaznaczone kontakty',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Wybierz zaznaczone kontakty',
  'LBL_INVALID_EMAIL'=>'Błędny email:',
  'LBL_NOTE_SUBJECT' =>'Temat notatki',
  'LBL_PRIMARY_ADDRESS_STREET_2' => 'Primary Address Street 2',
  'LBL_PRIMARY_ADDRESS_STREET_3' => 'Primary Address Street 3',
  'LBL_ALT_ADDRESS_STREET_2' => 'Alternate Address Street 2',
  'LBL_ALT_ADDRESS_STREET_3' => 'Alternate Address Street 3',
   'LBL_SYNC_CONTACT' => 'Synchronizuj kontakty:',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kontakty',
   'LBL_PRODUCTS_TITLE'=>'Produkty',
   'LBL_RELATED_CONTACTS_TITLE'=>'Powiązane kontakty',
  'LBL_DATE_MODIFIED' => 'Data modyfikacji',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
  'LBL_DIRECT_REPORTS_SUBPANEL_TITLE'=>'Direct Reports',
  'LBL_OPPORTUNITY_ROLE'=>'Opportunity Role',
);

?>
