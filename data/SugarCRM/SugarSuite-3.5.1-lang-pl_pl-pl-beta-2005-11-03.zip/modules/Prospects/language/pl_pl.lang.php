<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Możliwości',
  'LBL_INVITEE' => 'Direct Reports',
  'LBL_MODULE_TITLE' => 'Możliwości: Strona Główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
  'LBL_LIST_FORM_TITLE' => 'Lista możliwości',
  'LBL_NEW_FORM_TITLE' => 'Dodaj mozliwość',
  'LBL_PROSPECT' => 'Możliwość:',
  'LBL_BUSINESSCARD' => 'Wizytówka',
  'LBL_LIST_NAME' => 'Imię',
  'LBL_LIST_LAST_NAME' => 'Nazwisko',
  'LBL_LIST_PROSPECT_NAME' => 'Prospect Name',
  'LBL_LIST_TITLE' => 'Tytuł',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Inny Email',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_PROSPECT_ROLE' => 'Rola',
  'LBL_LIST_FIRST_NAME' => 'Imię',
  'LBL_ASSIGNED_TO_NAME'=>'Assigned To Name',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_PROSPECT' => 'Użyto istniejący kontakt',
  'LBL_CREATED_PROSPECT' => 'Utworzono nowy kontakt',
  'LBL_EXISTING_ACCOUNT' => 'Użytko istniejącego klienta',
  'LBL_CREATED_ACCOUNT' => 'Utworzono nowego klienta',
  'LBL_CREATED_CALL' => 'Utworzono nową rozmowę',
  'LBL_CREATED_MEETING' => 'Utworzono nowe spotkanie',
  'LBL_ADDMORE_BUSINESSCARD' => 'Dodaj kolejną wizytówkę',
  'LBL_ADD_BUSINESSCARD' => 'Wprowadź wizytówkę',
  'LBL_NAME' => 'Imię:',
  'LBL_PROSPECT_NAME' => 'Prospect Name:',
  'LBL_PROSPECT_INFORMATION' => 'Informacje',
  'LBL_FIRST_NAME' => 'Imię:',
  'LBL_OFFICE_PHONE' => 'Telefon do biura:',
  'LBL_ACCOUNT_NAME' => 'Nazwa klienta:',
  'LBL_ANY_PHONE' => 'Telefon:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_LAST_NAME' => 'Nazwisko:',
  'LBL_MOBILE_PHONE' => 'Komórka:',
  'LBL_HOME_PHONE' => 'Dom:',
  'LBL_OTHER_PHONE' => 'Telefon:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Ulica:',
  'LBL_PRIMARY_ADDRESS_CITY' => 'Miasto:',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Kraj:',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Województwo:',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Kod:',
  'LBL_ALT_ADDRESS_STREET' => 'Ulica:',
  'LBL_ALT_ADDRESS_CITY' => 'Miasto:',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Kraj:',
  'LBL_ALT_ADDRESS_STATE' => 'Województwo:',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Kod:',
  'LBL_TITLE' => 'Tytuł:',
  'LBL_DEPARTMENT' => 'Oddział:',
  'LBL_BIRTHDATE' => 'Data urodzenia:',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email:',
  'LBL_ANY_EMAIL' => 'Email:',
  'LBL_ASSISTANT' => 'Assystent:',
  'LBL_ASSISTANT_PHONE' => 'Telefon asystenta:',
  'LBL_DO_NOT_CALL' => 'Nie dzwonić:',
  'LBL_EMAIL_OPT_OUT' => 'Email Opt Out:',
  'LBL_PRIMARY_ADDRESS' => 'Adres:',
  'LBL_ALTERNATE_ADDRESS' => 'Adres:',
  'LBL_ANY_ADDRESS' => 'Adres:',
  'LBL_CITY' => 'Miasto:',
  'LBL_STATE' => 'Województwo:',
  'LBL_POSTAL_CODE' => 'Kod:',
  'LBL_COUNTRY' => 'Kraj:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informacje',
  'LBL_ADDRESS_INFORMATION' => 'Informacje adresowe',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_PROSPECT_ROLE' => 'Rola:',
  'LBL_OPP_NAME' => 'Nazwa szansy:',
  'LBL_IMPORT_VCARD' => 'Importuj vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Automatycznie utwórz nowy kontakt przez import vCard ze swojego komputera.',
  'LBL_DUPLICATE' => 'Możliwy duplikat',
  'MSG_SHOW_DUPLICATES' => 'Utworzenie tego kontaktu może spowodować zduplikowanie wpisów.',
  'MSG_DUPLICATE' => 'Utworzenie tego kontaktu może spowodować zduplikowanie wpisów.',
  'LNK_PROSPECT_LIST' => 'Możliwości',
  'LNK_IMPORT_VCARD' => 'Utwórz z vCard',
  'LNK_NEW_PROSPECT' => 'Dodaj możliwość',
  'LNK_NEW_ACCOUNT' => 'Dodaj klienta',
  'LNK_NEW_OPPORTUNITY' => 'Dodaj szanse',
  'LNK_NEW_CASE' => 'Dodaj sprawę',
  'LNK_NEW_NOTE' => 'Dodaj notatkę lub załącznik',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę',
  'LNK_NEW_EMAIL' => 'Zarchiwizuj email',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Dodaj zadanie',
  'LNK_NEW_APPOINTMENT' => 'Dodaj termin',
  'NTC_DELETE_CONFIRMATION' => 'Czy na pewno usunąć ten wpis?',
  'NTC_REMOVE_CONFIRMATION' => 'Czy na pewno usunąć ten kontakt ze sprawy?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Are you sure you want to remove this record as a direct report?',
  'ERR_DELETE_RECORD' => 'Musi zostać wybrany wpis.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Skopiuj adres podstawowy jako alternatywny',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Skopiuj adres alternatywny jako podstawowy',
  'LBL_SALUTATION' => 'Tytuł',
  'LBL_SAVE_PROSPECT' => 'Zapisz',
  'LBL_CREATED_OPPORTUNITY' =>'Utworzono nową szansę',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Utworzenie nowej szansy wymaga klienta.\n Wybierz już istniejącego lub dodaj nowego.',
  'LNK_SELECT_ACCOUNT' => 'Wybierz klienta',
  'LNK_NEW_PROSPECT' => 'Utwórz możliwość',
  'LNK_PROSPECT_LIST' => 'Możliwości',  
  'LNK_NEW_CAMPAIGN' => 'Utwórz kampanię',
  'LNK_CAMPAIGN_LIST' => 'Kampanie',
  'LNK_NEW_PROSPECT_LIST' => 'Utwórz listę możliwości',
  'LNK_PROSPECT_LIST_LIST' => 'Listy możliwości',
  'LNK_IMPORT_PROSPECT' => 'Importuj możliwości',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Wybierz zaznaczone możliwości',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Wybierz zaznaczone możliwości',
  'LBL_INVALID_EMAIL'=>'Błędny email:',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Możliwości',
);


?>
