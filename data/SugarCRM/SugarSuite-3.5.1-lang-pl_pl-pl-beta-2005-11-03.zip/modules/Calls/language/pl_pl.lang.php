<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Rozmowy telefoniczne',
  'LBL_MODULE_TITLE' => 'Rozmowy telefoniczne: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukiwanie rozmów',
  'LBL_LIST_FORM_TITLE' => 'Lista rozmów',
  'LBL_NEW_FORM_TITLE' => 'Zaplanuj rozmowę tel.',
  'LBL_LIST_CLOSE' => 'Zamknij',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Odnosi się do',
  'LBL_LIST_DATE' => 'Data rozpoczęcia',
  'LBL_LIST_TIME' => 'Czas rozpoczęcia',
  'LBL_LIST_DURATION' => 'Czas trwania',
  'LBL_LIST_DIRECTION' => 'Kierunek',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_REMINDER' => 'Przypomnienie:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_DESCRIPTION_INFORMATION' => 'Opis',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_STATUS' => 'Status:',
  'LBL_DIRECTION' => 'Kierunek:',
  'LBL_DATE' => 'Data rozpoczęcia:',
  'LBL_DURATION' => 'Czas trwania:',
  'LBL_DURATION_HOURS' => 'Godziny trwania:',
  'LBL_DURATION_MINUTES' => 'Minuty trwania:',
  'LBL_HOURS_MINUTES' => '(godziny/minuty)',
  'LBL_CALL' => 'Rozmowa tel.:',
  'LBL_DATE_TIME' => 'Data i czas rozpoczęcia:',
  'LBL_TIME' => 'Czas rozpoczęcia:',
  'LBL_HOURS_ABBREV' => 'h',
  'LBL_MINSS_ABBREV' => 'm',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planned',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę tel.',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Utwórz zadanie',
  'LNK_NEW_NOTE' => 'Utwórz notatkę lub załącznik',
  'LNK_NEW_EMAIL' => 'Dołącz email',
  'LNK_CALL_LIST' => 'Rozmowy',
  'LNK_MEETING_LIST' => 'Spotkania',
  'LNK_TASK_LIST' => 'Zadania',
  'LNK_NOTE_LIST' => 'Notatki',
  'LNK_EMAIL_LIST' => 'Emaile',
  'LNK_VIEW_CALENDAR' => 'Dziś',
  'ERR_DELETE_RECORD' => 'Musi być wprowadzony numer rekordu aby usunąć wpis.',
  'NTC_REMOVE_INVITEE' => 'Czy na pewno chcesz usunąć to zaproszenie z rozmowy?',
  'LBL_INVITEE' => 'Zaproszenia',
  'LBL_RELATED_TO' => 'Odnosi się do:',
  'LNK_NEW_APPOINTMENT' => 'Zaplanuj spotkanie',
	'LBL_SCHEDULING_FORM_TITLE' => 'Planowanie',
  'LBL_ADD_INVITEE' => 'Dodaj zaproszenie',
  'LBL_NAME' => 'Nazwa',
  'LBL_FIRST_NAME' => 'Imię',
  'LBL_LAST_NAME' => 'Nazwisko',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Telefon',
  'LBL_REMINDER' => 'Przypomnienie:',
  'LBL_SEND_BUTTON_TITLE'=>'Wyślij zaproszenia [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'Wyślij zaproszenia',
	'LBL_DATE_END'=>'Data zakończenia',
	'LBL_TIME_END'=>'Czas zakończenia',
	'LBL_REMINDER_TIME'=>'Czas przypomnienia',
   'LBL_SEARCH_BUTTON'=> 'Szukaj',
   'LBL_ADD_BUTTON'=> 'Dodaj',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Rozmowy telefoniczne',
   'LBL_LOG_CALL'=> 'Dziennik rozmów',
   'LNK_SELECT_ACCOUNT'=> 'Wybierz klienta',
   'LNK_NEW_ACCOUNT'=> 'Nowy klient',
   'LNK_NEW_OPPORTUNITY'=> 'Nowa szansa',
    'LBL_DEL' => 'Usuń',
);


?>
