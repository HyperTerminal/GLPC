<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for the Accounts module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Klienci',
  'LBL_MODULE_TITLE' => 'Klienci: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Szukaj klienta',
  'LBL_LIST_FORM_TITLE' => 'Lista klientów',
  'LBL_NEW_FORM_TITLE' => 'Nowy klient',
  'LBL_MEMBER_ORG_FORM_TITLE' => 'Organizacje klienta',
  'LBL_BUG_FORM_TITLE' => 'Klienci',
  'LBL_LIST_ACCOUNT_NAME' => 'Nazwa klienta',
  'LBL_LIST_CITY' => 'Miasto',
  'LBL_LIST_WEBSITE' => 'Strona WWW',
  'LBL_LIST_STATE' => 'Województwo',
  'LBL_LIST_PHONE' => 'Telefon',
  'LBL_LIST_EMAIL_ADDRESS' => 'Email',
  'LBL_LIST_CONTACT_NAME' => 'Nazwisko kontaktowe',
  'LBL_BILLING_ADDRESS_STREET_2' =>'Adres fakturowania Ulica 2',
  'LBL_BILLING_ADDRESS_STREET_3' =>'Adres fakturowania Ulica 3',
  'LBL_BILLING_ADDRESS_STREET_4' =>'Adres fakturowania Ulica 4',
  'LBL_SHIPPING_ADDRESS_STREET_2' => 'Adres dostawy Ulica 2',
  'LBL_SHIPPING_ADDRESS_STREET_3' => 'Adres dostawy Ulica 3',
  'LBL_SHIPPING_ADDRESS_STREET_4' => 'Adres dostawy Ulica 4',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_website' => 'LBL_LIST_WEBSITE',
  'db_billing_address_city' => 'LBL_LIST_CITY',
//END DON'T CONVERT
  'LBL_ACCOUNT_INFORMATION' => 'Informacje o kliencie',
  'LBL_ACCOUNT' => 'Klient:',
  'LBL_ACCOUNT_NAME' => 'Nazwa klienta:',
  'LBL_PHONE' => 'Tel. 1:',
  'LBL_PHONE_ALT' => 'Tel. 2:',
  'LBL_WEBSITE' => 'Strona WWW:',
  'LBL_FAX' => 'Fax:',
  'LBL_TICKER_SYMBOL' => 'Ticker Symbol:',
  'LBL_OTHER_PHONE' => 'Tel. 3:',
  'LBL_ANY_PHONE' => 'Tel. 4:',
  'LBL_MEMBER_OF' => 'Członek:',
  'LBL_PHONE_OFFICE' => 'Tel. 5:',
  'LBL_PHONE_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email 1:',
  'LBL_EMPLOYEES' => 'Pracownicy:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'Email 2:',
  'LBL_ANY_EMAIL' => 'Email 3:',
  'LBL_OWNERSHIP' => 'Ownership:',
  'LBL_RATING' => 'Rating:',
  'LBL_INDUSTRY' => 'Przemysł:',
  'LBL_SIC_CODE' => 'SIC Code:',
  'LBL_TYPE' => 'Typ:',
  'LBL_ANNUAL_REVENUE' => 'Roczny przychód:',
  'LBL_ADDRESS_INFORMATION' => 'Informacje adresowe',
  'LBL_BILLING_ADDRESS' => 'Adres fakturowania:',
  'LBL_BILLING_ADDRESS_STREET' => 'Ulica:',
  'LBL_BILLING_ADDRESS_CITY' => 'Miasto:',
  'LBL_BILLING_ADDRESS_STATE' => 'Województwo:',
  'LBL_BILLING_ADDRESS_POSTALCODE' => 'Kod pocztowy:',
  'LBL_BILLING_ADDRESS_COUNTRY' => 'Państwo:',
  'LBL_SHIPPING_ADDRESS_STREET' => 'Ulica:',
  'LBL_SHIPPING_ADDRESS_CITY' => 'Miasto:',
  'LBL_SHIPPING_ADDRESS_STATE' => 'Województwo:',
  'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Kod pocztowy:',
  'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Państwo:',
  'LBL_SHIPPING_ADDRESS' => 'Adres korespondencyjny:',
  'LBL_DATE_MODIFIED' => 'Data modyfikacji:',
  'LBL_DATE_ENTERED' => 'Data wprowadzenia:',
  'LBL_ANY_ADDRESS' => 'Adres:',
  'LBL_CITY' => 'Miasto:',
  'LBL_STATE' => 'Województwo:',
  'LBL_POSTAL_CODE' => 'Kod pocztowy:',
  'LBL_COUNTRY' => 'Państwo:',
  'LBL_DESCRIPTION_INFORMATION' => 'Opis',
  'LBL_DESCRIPTION' => 'Opis:',
  'NTC_COPY_BILLING_ADDRESS' => 'Skopiuj adres fakturowania do adresu korespondencyjnego',
  'NTC_COPY_SHIPPING_ADDRESS' => 'Skopiuj adres korespondencyjny do adresu fakturowania',
  'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Czy na pewno usunąć ten rekord z organizacji klienta?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Czy jesteś pewien, że chcesz usunąć tego klienta?',
  'LBL_DUPLICATE' => 'Możliwość zdublowania klienta',
  'MSG_SHOW_DUPLICATES' => 'Istnieje porawdopodobieństwo utworzenia kopii już wprowadzonego klienta. Możesz nacisnąć "Dodaj klienta", aby dokończyć operację lub naciskąć "Anuluj".',
  'MSG_DUPLICATE' => 'Istnieje porawdopodobieństwo utworzenia kopii już wprowadzonego klienta. Możesz wybrać klienta z listy poniżej lub kliknąć "Dodaj klienta" aby utworzyć nowego klienta.',
  'LNK_NEW_ACCOUNT' => 'Dodaj klienta',
  'LNK_ACCOUNT_LIST' => 'Klienci',
  'LBL_INVITEE' => 'Kontakty',
  'ERR_DELETE_RECORD' => 'Musi być wprowadzony nr rekordu aby usunąć klienta.',
  'NTC_DELETE_CONFIRMATION' => 'Czy na pewno chcesz usunąć tego klienta?',
  'LBL_SAVE_ACCOUNT' => 'Zapisz klienta',
  'LBL_BUG_FORM_TITLE' => 'Klienci',
  'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Czy na pewno usunąć tego klienta z tego projektu?',
	'LBL_USERS_ASSIGNED_LINK'=>'Przydzieleni użytkownicy',
	'LBL_USERS_MODIFIED_LINK'=>'Zmienieni użytkownicy',
	'LBL_USERS_CREATED_LINK'=>'Stworzone przez użytkowników',
	'LBL_TEAMS_LINK'=>'Zespoły',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Klienci',
	'LBL_PRODUCTS_TITLE'=>'Produkty',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
	'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'Organizacje członkowskie',
	'LBL_NAME'=>'Nazwa:',
);


?>
