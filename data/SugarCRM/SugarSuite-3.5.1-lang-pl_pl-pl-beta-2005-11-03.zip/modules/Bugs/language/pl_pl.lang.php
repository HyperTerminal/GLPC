<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Bug Tracker',
  'LBL_MODULE_TITLE' => 'Bug Tracker: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Szukaj błędów',
  'LBL_LIST_FORM_TITLE' => 'Lista błędów',
  'LBL_NEW_FORM_TITLE' => 'Nowy błąd',
  'LBL_CONTACT_BUG_TITLE' => 'Contact-Bug:',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_BUG' => 'Błąd:',
  'LBL_BUG_NUMBER' => 'Nr błędu:',
  'LBL_NUMBER' => 'Numer:',
  'LBL_STATUS' => 'Status:',
  'LBL_PRIORITY' => 'Priorytet:',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_CONTACT_NAME' => 'Nazwisko kontaktowe:',
  'LBL_BUG_SUBJECT' => 'Temat błędu:',
  'LBL_CONTACT_ROLE' => 'Rola:',
  'LBL_LIST_NUMBER' => 'Nr',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_PRIORITY' => 'Priorytet',
  'LBL_LIST_RELEASE' => 'Wydanie',
  'LBL_LIST_RESOLUTION' => 'Resolution',
  'LBL_LIST_LAST_MODIFIED' => 'Ostatnio zmodyfikowany',
  'LBL_INVITEE' => 'Kontakty',
  'LBL_TYPE' => 'Typ:',
  'LBL_LIST_TYPE' => 'Typ',
  'LBL_RESOLUTION' => 'Resolution:',
  'LBL_RELEASE' => 'Wydanie:',
  'LNK_NEW_BUG' => 'Zgłoś błąd',
  'LNK_BUG_LIST' => 'Błędy',
  'NTC_REMOVE_INVITEE' => 'Czy na pewno usunąć ten kontakt z błędu?',
  'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Czy na pewno usunąć ten błąd od klienta?',
  'ERR_DELETE_RECORD' => 'Musi zostać wprowadzony numer rekordu aby usunąć błąd.',
  'LBL_LIST_MY_BUGS' => 'Błędy przypisane do mnie:',

  'LBL_FOUND_IN_RELEASE' => 'Znalezione w wydaniu:',
  'LBL_FIXED_IN_RELEASE' => 'Poprawione w wydaniu:',
  'LBL_WORK_LOG' => 'Dziennik pracy:',
  'LBL_SOURCE' => 'Źródło:',
  'LBL_PRODUCT_CATEGORY' => 'Kategoria:', 
  'LBL_CREATED_BY' => 'Utworzony przez:',
  'LBL_DATE_CREATED' => 'Data utworzenia:',
  'LBL_MODIFIED_BY' => 'Ostatnio zmieniany przez:',
  'LBL_DATE_LAST_MODIFIED' => 'Data modyfikacji:',
  'LBL_LIST_EMAIL_ADDRESS' => 'Adres email',
  'LBL_LIST_CONTACT_NAME' => 'Nazwisko kontaktowe',
  'LBL_LIST_ACCOUNT_NAME' => 'Nazwa klienta',
  'LBL_LIST_PHONE' => 'Telefon',
  'NTC_DELETE_CONFIRMATION' => 'Czy na pewno usunąć ten kontakt z błędu?',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Bug Tracker',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
  );


?>
