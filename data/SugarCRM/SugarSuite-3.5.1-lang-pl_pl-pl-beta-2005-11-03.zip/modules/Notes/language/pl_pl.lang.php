<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Notatki',
  'LBL_MODULE_TITLE' => 'Notatki: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
  'LBL_LIST_FORM_TITLE' => 'Lista notatek',
  'LBL_NEW_FORM_TITLE' => 'Dodaj Notatkę',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_CONTACT_NAME' => 'Osoba Kont.',
  'LBL_LIST_RELATED_TO' => 'Podlega',
  'LBL_LIST_DATE_MODIFIED' => 'Ostatnia modyfikacja',
  'LBL_LIST_FILENAME' => 'Załącznik',
  'LBL_NOTE' => 'Notatka:',
  'LBL_NOTE_SUBJECT' => 'Temat:',
  'LBL_CONTACT_NAME' => 'Osoba Kontaktowa:',
  'LBL_PHONE' => 'Tel.:',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_FILENAME' => 'Załącznik:',
  'LBL_FILE_MIME_TYPE' => 'Type',
  'LBL_FILE_URL' => 'URL',
  'LBL_CLOSE' => 'Zamknij:',
  'LBL_RELATED_TO' => 'Podlega:',
  'LBL_PARENT_TYPE' => 'Typ nadrzędny',
  'LBL_EMAIL_ADDRESS' => 'Email:',
  'LBL_COLON' => ':',
  'ERR_DELETE_RECORD' => 'Wskaż rekord do usunięcia.',

'LNK_NEW_CALL'=>'Dodaj Rozmowę tel.',
'LNK_NEW_MEETING'=>'Dodaj Spotkanie',
'LNK_NEW_TASK'=>'Dodaj Zadanie',
'LNK_NEW_NOTE'=>'Dodaj Notatkę',
'LNK_NEW_EMAIL'=>'Dodaj E-mail',
'LNK_CALL_LIST'=>'Dodaj Rozmowę tel.',
'LNK_MEETING_LIST'=>'Lista Spotkań',
'LNK_TASK_LIST'=>'Lista Zadań',
'LNK_NOTE_LIST'=>'Lista Notatek',
'LNK_EMAIL_LIST'=>'Lista E-maili',
'LNK_IMPORT_NOTES'=>'Import notatek',
'LNK_VIEW_CALENDAR' => 'Dzisiaj',
  'LBL_PORTAL_FLAG'=>'Wyświetlić w Portalu?',
'LBL_DEFAULT_SUBPANEL_TITLE' => 'Notatki',
'LBL_STATUS'=>'Status',
'LBL_NOTE_STATUS'=>'Notatka',
'LBL_DESCRIPTION' => 'Opis',
);
?>
