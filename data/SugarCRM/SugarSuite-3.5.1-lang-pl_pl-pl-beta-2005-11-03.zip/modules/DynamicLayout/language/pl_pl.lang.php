<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
'LBL_ADVANCED'=> 'Zaawansowane:',
'DESC_USING_LAYOUT_TITLE' => 'Używając edytora wyglądu',
'DESC_USING_LAYOUT_SHORTCUTS' => 'Skróty:',
'DESC_USING_LAYOUT_TOOLBAR' => 'Pasek narzędziowy:',
'DESC_USING_LAYOUT_EDIT_ROWS' => 'Edytuj wiersze:',
'DESC_USING_LAYOUT_SELECT_FILE' => 'Wybierz plik:',
'DESC_USING_LAYOUT_EDIT_FIELDS' => 'Edytuj wygląd:',
'DESC_USING_LAYOUT_ADD_FIELD' => 'Dodaj pole:',
'DESC_USING_LAYOUT_REMOVE_ITEM' => 'Usuń obiekt:',
'DESC_USING_LAYOUT_DISPLAY_HTML' => 'Wyświetl kod HTML:',
'DESC_USING_LAYOUT_BLK1' => 'Edytor wyglądu pozwala zarządzać polami, zakładkami i panelami aby dostosować ekrany do swoich potrzeb. Najpierw wybierz widok strony, którą chcesz dostosować używając skrótu "Wybierz plik".',
'DESC_USING_LAYOUT_BLK2' => ' pozwala wybrać inną stronę do edycji. Zmiany na obecnej stronie zostaną utracone, jeżeli nie zostały zapisane. Jeżeli nie jesteś pewien, który plik edytować możesz zaznaczyć "Edyduj w miejscu", doda to panel edycji do wszystkich miejsc, które można zmieniać w aplikacji. Przejdź na stronę, którą chcesz zmienić, a następnie kliknij panel edycji.',
'DESC_USING_LAYOUT_BLK3' => ' przesuń i zmień pojedyncze pola lub ich etykiety. Wybierz uchwyt ',
'DESC_USING_LAYOUT_BLK4' => ' obok pola lub etykiety, którą chcesz przesunąć i kliknij uchwyt miejsca, w którym ma się znaleźć przeniesiony obiekt. Jeżeli w wyznaczonym miejscu już znajdował się jakiś element, obiekty zamienią się miejscami. Aby usunąć pole z ekranu przeciągnij je na pasek narzędziowy z lewej strony paska menu.',
'DESC_USING_LAYOUT_BLK5' => ' zmienia widok pozwalając na dodawanie i usówanie wierszy w panelu szczegółów.',
'DESC_USING_LAYOUT_BLK6' => 'Pasek narzędziowy dostarcza miejsca na dodawanie nowych pól i etykiet do formularza oraz tymczasowe przechowywanie elementów usuniętych.',
'DESC_USING_LAYOUT_BLK7' => ' otwiera widok wyboru typu pola, które chcesz dodać i jego etykiety. Naciśnięcie przycisku "Dodaj" umieszcza nowe pole w pasku narzędziowym, skąd może być przeniesione w miejsce docelowe.',
'DESC_USING_LAYOUT_BLK8' => ' jest wykonywane przez wybór jego uchwytu i kliknięcie na tekst "Przenieś niepotrzebne elementy tutaj".',
'DESC_USING_LAYOUT_BLK9' => ' pole to wyświetla HTML opisujący każde pole. O ile akcja ta dostarcza wielu informacji, o tyle bardzo wykorzystuje procesor i powinna być wykonywana tylko w razie konieczności.',
'DESC_USING_LAYOUT_BLK10' => 'Aby zapisać zmiany kliknij "Zapisz wygląd". Aby zaniechać zmian wybierz inną zakładkę, a wszystkie wprowadzone zmiany zostaną utracone.',
'NO_RECORDS_LISTVIEW'=>'Aby edytować widok listy, zawierać ona musi przynajmniej jeden wiersz danych.',
'LBL_EDIT_LAYOUT'=>'Edytuj wygląd',
'LBL_EDIT_ROWS'=>'Edytuj wiersze',
'LBL_EDIT_COLUMNS'=>'Edytuj kolumny',
'LBL_EDIT_LABELS'=>'Edytuj etykiety',
'LBL_EDIT_FIELDS'=>'Edytuj pola',
'LBL_ADD_FIELDS'=>'Dodaj pola',
'LBL_DISPLAY_HTML'=>'Wyświetl kod HTML',
'LBL_SELECT_FILE'=> 'Wybierz plik',
);
?>
