<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Szanse',
  'LBL_MODULE_TITLE' => 'Szanse: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
  'LBL_LIST_FORM_TITLE' => 'Lista szans',
  'LBL_OPPORTUNITY_NAME' => 'Nazwa:',
  'LBL_OPPORTUNITY' => 'Szansa:',
  'LBL_NAME' => 'Nazwa',
  'LBL_INVITEE' => 'Uczestnicy',
  'LBL_LIST_OPPORTUNITY_NAME' => 'Szansa',
  'LBL_LIST_ACCOUNT_NAME' => 'Klient',
  'LBL_LIST_AMOUNT' => 'Przychody',
  'LBL_LIST_DATE_CLOSED' => 'Zakończone',
  'LBL_LIST_SALES_STAGE' => 'Etapy sprzedaży',
  'LBL_ACCOUNT_ID'=>'ID klienta',
  'LBL_CURRENCY_ID'=>'ID waluty',
  'LBL_TEAM_ID' =>'ID zespołu',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
  'db_name' => 'LBL_NAME',
  'db_amount' => 'LBL_LIST_AMOUNT',
  'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
//END DON'T CONVERT
  'UPDATE' => 'Opportunity - Aktualizuj waluty',
  'UPDATE_DOLLARAMOUNTS' => 'Aktualizuj przychody w USD',
  'UPDATE_VERIFY' => 'Weryfikuj przychody',
  'UPDATE_VERIFY_TXT' => 'Weryfikuje tylko te wartości, które zapisane są w postaci cyfrowej (cyfry 0-9) oraz w postaci dziesiętnej. ',
  'UPDATE_FIX' => 'Napraw Przychody',
  'UPDATE_FIX_TXT' => 'Próba naprawienia wartości przychodów poprzez przekształcenie znalezionych wartości do postaci liczbowej. Obecne wartości zostaną zapisane w kopii bezpieczeństwa. Jeśli operacja spowoduje powstanie błędów możesz przywrócić poprzednie wartości z kopii bezpieczeństwa. Nie ponawiaj tej operacji po wykryciu nieprawidłowości. Grozi to nadpisaniem kopii bezpieczeństwa błędnymi danymi!.',
  'UPDATE_DOLLARAMOUNTS_TXT' => 'Aktualizuje przychody z Szans w oparciu o przelicznik do waluty bazowej (USD). Wartości te są używane do sporządzania wykresów oraz zestawień wartości.',
  'UPDATE_CREATE_CURRENCY' => 'Tworzenie nowej waluty:',
  'UPDATE_VERIFY_FAIL' => 'Błąd weryfikacji:',
  'UPDATE_VERIFY_CURAMOUNT' => 'Bierzące przychody:',
  'UPDATE_VERIFY_FIX' => 'Running Fix would give',
  'UPDATE_INCLUDE_CLOSE' => 'Dodaj zamknięte',
  'UPDATE_VERIFY_NEWAMOUNT' => 'Nowy przychód:',
  'UPDATE_VERIFY_NEWCURRENCY' => 'Nowa waluta:',
  'UPDATE_DONE' => 'Zadanie wykonane.',
  'UPDATE_BUG_COUNT' => 'Znaleziono problem, trwa próba naprawienia:',
  'UPDATE_BUGFOUND_COUNT' => 'Znalezione problemy:',
  'UPDATE_COUNT' => 'Rekord zaktualizowany:',
  'UPDATE_RESTORE_COUNT' => 'Odzyskano przychód:',
  'UPDATE_RESTORE' => 'Odzyskiwanie przychodu',
  'UPDATE_RESTORE_TXT' => 'Odzyskiwanie wartości przychodów z kopii bezpieczeństwa.',
  'UPDATE_FAIL' => 'Nie mogę zaktualizować - ',
  'UPDATE_NULL_VALUE' => 'Wartość przychodu nieznana ustawiam na 0 -',
  'UPDATE_MERGE' => 'Połącz waluty',
  'UPDATE_MERGE_TXT' => 'Łączy wiele walut w pojedynczą walutę. Użyj tej funkcji jeśli Twoje dane zawierają różne oznaczenia tej samej waluty np.: PLN, PLZ, ZŁ, zł. ',
  'LBL_ACCOUNT_NAME' => 'Nazwa klienta:',
  'LBL_AMOUNT' => 'Przychody:',
  'LBL_CURRENCY' => 'Waluta:',
  'LBL_DATE_CLOSED' => 'Spodziewana data zak.:',
  'LBL_TYPE' => 'Typ:',
  'LBL_NEXT_STEP' => 'Następny krok:',
  'LBL_LEAD_SOURCE' => 'Źródło pozyskania:',
  'LBL_SALES_STAGE' => 'Etap sprzedaży:',
  'LBL_PROBABILITY' => 'Prawdopodobieństwo (%):',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_DUPLICATE' => 'Prawdopodobnie taka Szansa już istnieje',
  'MSG_DUPLICATE' => 'Utworzenie tej Szansy spowoduje powstanie duplikatu już istniejącej. Możesz wybrać istniejącą Szansę z listy lub kontynuować klikając [Dodaj Szansę]. Operacja ta utworzy nową Szansę wykorzystując dane, które wprowadziłeś za pomocą formularza. ',
  'LBL_NEW_FORM_TITLE' => 'Dodaj Szansę',
  'LNK_NEW_OPPORTUNITY' => 'Dodaj Szansę',
  'LNK_OPPORTUNITY_LIST' => 'Szanse',
  'ERR_DELETE_RECORD' => 'Wskaż rekord do usunięcia.',
  'LBL_TOP_OPPORTUNITIES' => '10 moich najważniejszych Szans',
  'NTC_REMOVE_OPP_CONFIRMATION' => 'Czy na pewno usunąć Osoby kontaktowe z tej Szansy?',
  'OPPORTUNITY_REMOVE_PROJECT_CONFIRM' => 'Czy na pewno usunąć Szansę z tego Projektu?',
  'LBL_AMOUNT_BACKUP'=>'Amount Backup',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Szanse',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
    'LBL_RAW_AMOUNT'=>'Raw Amount'

);

?>
