<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Wszyskie emaile',
  'LBL_ARCHIVED_MODULE_NAME' => 'Zarchiwizowane emaile',
  'LBL_MODULE_NAME_NEW' => 'Nowy email',
  'LBL_MODULE_TITLE' => 'Emaile: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj email',
  'LBL_LIST_FORM_TITLE' => 'Lista emaili',
  'LBL_NEW_FORM_TITLE' => 'Nowy email',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_TYPE' => 'Typ',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Odnosi się do',
  'LBL_LIST_DATE' => 'Data wysłania',
  'LBL_LIST_TIME' => 'Czas wysłania',
  'ERR_DELETE_RECORD' => 'Musi być wprowadzony numer rekordu aby usunąć klienta.',
  'LBL_DATE_SENT' => 'Data wysłania:',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_BODY' => 'Treść:',
  'LBL_DATE_AND_TIME' => 'Data i czas wysłania:',
  'LBL_DATE' => 'Data wysłania:',
  'LBL_TIME' => 'Czas wysłania:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_EMAIL' => 'Email:',
  'LBL_COLON' => ':',
  'NTC_REMOVE_INVITEE' => 'Czy na pewno chcesz usunąć tego odbiorcę?',
  'LBL_INVITEE' => 'Odbiorcy',

'LNK_NEW_CALL'=>'Zaplanuj rozmowę tel.',
'LNK_NEW_MEETING'=>'Zaplanuj spotkanie',
'LNK_NEW_TASK'=>'Nowe zadanie',
'LNK_NEW_NOTE'=>'Utwórz notatkę lub załącznik',
'LNK_NEW_EMAIL'=>'Utwórz email',
'LNK_CALL_LIST'=>'Rozmowy',
'LNK_MEETING_LIST'=>'Spotkania',
'LNK_TASK_LIST'=>'Zadania',
'LNK_NOTE_LIST'=>'Notatki',
'LNK_EMAIL_LIST'=>'Emaile',
'LNK_NEW_SEND_EMAIL'=>'Utwórz email',
'LNK_ARCHIVED_EMAIL_LIST'=>'Zarchiwizowane emaile',
'LNK_SENT_EMAIL_LIST'=>'Wysłane emaile',
'LNK_ALL_EMAIL_LIST'=>'Wszystkie emaile',
'LNK_NEW_ARCHIVE_EMAIL'=>'Nowy zarchiwizowany email',
'LNK_VIEW_CALENDAR' => 'Dziś',

  'LBL_COMPOSE_MODULE_NAME' => 'Utwórz email',
  'LBL_SENT_MODULE_NAME' => 'Wysłane emaile',
  'LBL_SEND' => 'Wyślij',
  'LBL_SEARCH_FORM_SENT_TITLE' => 'Przeszukaj wysłane emaile',
  'LBL_LIST_FORM_SENT_TITLE' => 'Wysłane emaile',
'LBL_SEND_BUTTON_LABEL'=>'Wyślij',
'LBL_SEND_BUTTON_TITLE' => 'Wyślij [Alt+S]',
'LBL_SEND_BUTTON_KEY' => 'S',
'LBL_SAVE_AS_DRAFT_BUTTON_TITLE'=>'Zapisz szkic [Alt+R]',
'LBL_SAVE_AS_DRAFT_BUTTON_KEY'=>'R',
'LBL_SAVE_AS_DRAFT_BUTTON_LABEL'=>'Zapisz szkic',
'LBL_LIST_TO_ADDR'=>'Do',
'LBL_TO_ADDRS'=>'Do',
'LBL_FROM'=>'Od:',
'LBL_LIST_FROM_ADDR'=>'Od',
'LNK_NEW_EMAIL_TEMPLATE'=>'Utwórz szablon listu',
'LNK_EMAIL_TEMPLATE_LIST'=>'Szablony listów',
"LBL_USE_TEMPLATE"=>"Użyj szablonu:",
"LBL_BCC"=>"UDW:",
"LBL_CC"=>"DW:",
"LBL_TO"=>"Do:",
"LBL_ERROR_SENDING_EMAIL"=>"Błąd przy wysyłaniu wiadomości",
"LBL_MESSAGE_SENT"=>"Wiadomość wysłana",
'LNK_DRAFTS_EMAIL_LIST'=>'Szkice',
'LBL_SEARCH_FORM_DRAFTS_TITLE'=>'Przeszukaj szkice',
'LBL_LIST_FORM_DRAFTS_TITLE'=>'Szkic',
'LBL_ATTACHMENTS'=>'Załączniki:',
'LBL_ADD_FILE'=>'Dodaj plik',
'LBL_ADD_ANOTHER_FILE'=>'Dodaj kolejny plik',
'LBL_EMAIL_ATTACHMENT'=>'Załącznik wiadomości',
'LBL_CONTACT_FIRST_NAME'=>'Imię osoby kontaktowej',
'LBL_CONTACT_LAST_NAME'=>'Nazwisko osoby kontaktowej',
'ERR_NOT_ADDRESSED'=>'Wiadomość musi być zaadresowana',
'LBL_NOTE_SEMICOLON'=>'Notatka: Użyj średnika jako znaku oddzielającego wiele adresów email.',
'WARNING_SETTINGS_NOT_CONF'=>'Ostrzeżenie: Twoje ustawienia nie zostały skonfigurowane do wysyłania wiadomości.',
'LBL_EDIT_MY_SETTINGS'=>'Edytuj moje ustawienia',
'LBL_NOT_SENT'=>'Błąd wysyłania',
'LBL_LIST_CREATED'=>'Utworzony',
'LBL_EMAIL_SELECTOR'=>'Wybierz',
'LBL_CREATED_BY'=>'Utworzony przez',
'LBL_DESCRIPTION'=>'Opis',
'LBL_FROM_NAME'=>'Nazwa "Od"',
'LBL_LIST_CONTACT_NAME'=>'Nazwa kontaktu',
'LBL_LIST_DATE_SENT'=>'Data wysłania',
'LBL_MODIFIED_BY'=>'Zmieniony przez',
'LBL_HTML_BODY'=>'HTML',
'LBL_TEXT_BODY'=>'Tekst',
'LBL_EDIT_ALT_TEXT'=>'Edytuj tekst alternatywny',
'LBL_SHOW_ALT_TEXT'=>'Wyświetl tekst alternatywny',
'LBL_USERS'=>'Użytkownicy',
);


?>
