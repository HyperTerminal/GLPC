<?php
/**
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Zadania',
	'LBL_MODULE_TITLE' => 'Zadania: Strona Główna',
	'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
	'LBL_LIST_FORM_TITLE'=> 'Lista zadań',
	
	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Data wprowadzenia:',
	'LBL_DATE_MODIFIED' => 'Data modyfikacji:',
	'LBL_ASSIGNED_USER_ID' => 'Przypisany do:',
	'LBL_MODIFIED_USER_ID' => 'Modified User Id:',
	'LBL_CREATED_BY' => 'Utworzony przez:',
	'LBL_TEAM_ID' => 'Grupa:',
	'LBL_NAME' => 'Nazwa:',
	'LBL_STATUS' => 'Status:',
	'LBL_DATE_DUE' => 'Data płatności:',
	'LBL_TIME_DUE' => 'Czas płatności:',
	'LBL_DATE_START' => 'Data rozpoczęcia:',
	'LBL_TIME_START' => 'Czas rozpoczęcia:',
	'LBL_PARENT_ID' => 'Projekt:',
	'LBL_PRIORITY' => 'Priorytet:',
	'LBL_DESCRIPTION' => 'Opis:',
	'LBL_ORDER_NUMBER' => 'Kolejność:',
	'LBL_TASK_NUMBER' => 'Numer zadania:',
	'LBL_DEPENDS_ON_ID' => 'Zależy od:',
	'LBL_MILESTONE_FLAG' => 'Kamień milowy:',
	'LBL_ESTIMATED_EFFORT' => 'Szacowane nakłady (godz.):',
	'LBL_ACTUAL_EFFORT' => 'Aktualne nakłady (godz.):',
	'LBL_UTILIZATION' => 'Utylizacja (%):',
	'LBL_PERCENT_COMPLETE' => 'Postęp (%):',
	'LBL_DELETED' => 'Usunięty:',

	'LBL_LIST_ORDER_NUMBER' => 'Kolejność',
	'LBL_LIST_NAME' => 'Nazwa',
	'LBL_LIST_PARENT_NAME' => 'Projekt',
	'LBL_LIST_PERCENT_COMPLETE' => 'Postęp (%)',
	'LBL_LIST_STATUS' => 'Status',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Przypisany do',
	'LBL_LIST_DATE_DUE' => 'Termin płatności',
	'LBL_LIST_DATE_START' => 'Data rozpoczęcia',
	'LBL_PROJECT_NAME' => 'Nazwa projektu',

	'LNK_NEW_PROJECT'	=> 'Utwórz projekt',
	'LNK_PROJECT_LIST'	=> 'Lista projeków',
	'LNK_NEW_PROJECT_TASK'	=> 'Dodaj zadanie',
	'LNK_PROJECT_TASK_LIST'	=> 'Zadania',
	
	'LBL_LIST_MY_PROJECT_TASKS' => 'Moje otwarte zadania',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Zadania',

	'LBL_ACTIVITIES_TITLE'=>'Działania',
	'LBL_HISTORY_TITLE'=>'Historia',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia', 

);
?>
