<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
	//module
	'LBL_MODULE_NAME' => 'Dokumety',
	'LBL_MODULE_TITLE' => 'Dokumenty: Strona główna',
	'LNK_NEW_DOCUMENT' => 'Utwórz dokument',
	'LNK_DOCUMENT_LIST'=> 'Lista dokumentów',
	'LBL_DOC_REV_HEADER' => 'Wersja dokumentu',
	//vardef labels
	'LBL_DOCUMENT_ID' => 'Sygnatura dokumentu',	
	'LBL_NAME' => 'Nazwa dokumentu',
	'LBL_DESCRIPTION' => 'Opis',
	'LBL_CATEGORY' => 'Kategoria',
	'LBL_SUBCATEGORY' => 'Podkategoria',
	'LBL_STATUS' => 'Status', 
	'LBL_CREATED_BY'=> 'Utworzony przez',
	'LBL_DATE_ENTERED'=> 'Data wprowadzenia',
	'LBL_DATE_MODIFIED'=> 'Data modyfikacji',
	'LBL_DELETED' => 'Usunięty',
	'LBL_MODIFIED'=> 'Zmodyfikowany przez',
	'LBL_CREATED'=> 'Utworzony przez',
	'LBL_REVISION_NAME' => 'Numer wersji',
	'LBL_FILENAME' => 'Nazwa pliku',
	'LBL_MIME' => 'Typ MIME',
	'LBL_REVISION' => 'Wersja',
	'LBL_DOCUMENT' => 'Połączone dokumenty',
	'LBL_LATEST_REVISION' => 'Najnowsza wersja',
	'LBL_CHANGE_LOG'=> 'Dziennik zmian',
	'LBL_ACTIVE_DATE'=> 'Data publikacji',
	'LBL_EXPIRATION_DATE' => 'Data wygaśnięcia',
	'LBL_FILE_EXTENSION'  => 'Rozszeżenie pliku',
	'LBL_CAT_OR_SUBCAT_UNSPEC'=>'Niezdefiniowane',
	//document edit and detail view
	'LBL_DOC_NAME' => 'Nazwa dokumentu:',
	'LBL_FILENAME' => 'Nazwa pliku:',
	'LBL_DOC_VERSION' => 'Wersja:',
	'LBL_CATEGORY_VALUE' => 'Kategoria:',
	'LBL_SUBCATEGORY_VALUE'=> 'Podkategoria:',
	'LBL_DOC_STATUS'=> 'Status:',
	'LBL_LAST_REV_CREATOR' => 'Wersja utworzona przez:',
	'LBL_LAST_REV_DATE' => 'Data wersji:',
	'LBL_DOWNNLOAD_FILE'=> 'Plik do ściągnięcia:',
	'LBL_DOC_DESCRIPTION'=>'Opis:',
	'LBL_DOC_ACTIVE_DATE'=> 'Data publikacji:',
	'LBL_DOC_EXP_DATE'=> 'Data wygaśnięcia:',
	//document list view.	
	'LBL_LIST_FORM_TITLE' => 'Lista dokumentów',	
	'LBL_LIST_DOCUMENT' => 'Dokument',
	'LBL_LIST_CATEGORY' => 'Kategoria',
	'LBL_LIST_SUBCATEGORY' => 'Podkategoria',
	'LBL_LIST_REVISION' => 'Wersja',
	'LBL_LIST_LAST_REV_CREATOR' => 'Data opublikowania',
	'LBL_LIST_LAST_REV_DATE' => 'Data wersji',
	'LBL_LIST_VIEW_DOCUMENT'=>'Zobacz',
	'LBL_LIST_ACTIVE_DATE' => 'Data opublikowania',
	'LBL_LIST_EXP_DATE' => 'Data wygaśnięcia',
	//document revisions.
	'LBL_REV_LIST_REVISION' => 'Wersje',
	'LBL_REV_LIST_ENTERED' => 'Data utworzenia',
	'LBL_REV_LIST_CREATED' => 'Utworzony przez',
	'LBL_REV_LIST_LOG'=> 'Lista zmian',
	'LBL_CURRENT_DOC_VERSION'=> 'Aktualna wersja:',
	'LBL_CHANGE_LOG'=> 'Lista zmian:',
	'LBL_SEARCH_FORM_TITLE'=> 'Szukaj dokumentu',
	//document search form.
	'LBL_SF_DOCUMENT' => 'Nazwa dokumentu:',
	'LBL_SF_CATEGORY' => 'Kategoria:',
	'LBL_SF_SUBCATEGORY'=> 'Podkategoria:',
	'LBL_SF_ACTIVE_DATE' => 'Data publikacji:',
	'LBL_SF_EXP_DATE'=> 'Data wygaśnięcia:',
	'DEF_CREATE_LOG' => 'Dokument utworzony',
	//error messages
	'ERR_DOC_NAME'=>'Nazwa dokumentu',
	'ERR_DOC_ACTIVE_DATE'=>'Data publikacji',
	'ERR_DOC_EXP_DATE'=> 'Data wygaśnięcia',
	'ERR_FILENAME'=> 'Nazwa pliku',
	'ERR_DOC_VERSION'=> 'Wersja dokumentu',
	'ERR_DELETE_CONFIRM'=> 'Czy na pewno usunąć tą wersję dokumentu?',
	'ERR_DELETE_LATEST_VERSION'=> 'Nie masz uprawnień do usówania najnowszej wersji dokumentu.',
);
?>
