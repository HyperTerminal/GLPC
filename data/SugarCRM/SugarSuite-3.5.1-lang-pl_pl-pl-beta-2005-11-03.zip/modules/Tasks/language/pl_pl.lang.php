<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
   'LBL_MODULE_NAME' => 'Zadania',
  'LBL_TASK' => 'Zadania: ',
  'LBL_MODULE_TITLE' => ' Zadania: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => ' Wyszukaj',
  'LBL_LIST_FORM_TITLE' => ' Lista zadań',
  'LBL_NEW_FORM_TITLE' => ' Dodaj zadanie',
  'LBL_NEW_FORM_SUBJECT' => 'Temat:',
  'LBL_NEW_FORM_DUE_DATE' => 'Data płatn.:',
  'LBL_NEW_FORM_DUE_TIME' => 'Czas płatn.:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Zamknij',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_CONTACT' => 'Osoba kontaktowa',
  'LBL_LIST_PRIORITY' => 'Priorytet',
  'LBL_LIST_RELATED_TO' => 'Podlega',
  'LBL_LIST_DUE_DATE' => 'Data płatności',
  'LBL_LIST_DUE_TIME' => 'Czas płatności',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_STATUS' => 'Status:',
  'LBL_DUE_DATE' => 'Data płatności:',
  'LBL_DUE_TIME' => 'Czas płatności:',
  'LBL_PRIORITY' => 'Priorytet:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Data i czas płatn.:',
  'LBL_START_DATE_AND_TIME' => 'Data i Czas rozpoczęcia:',
  'LBL_START_DATE' => 'Data rozpoczęcia:',
  'LBL_START_TIME' => 'Czas rozpoczęcia:',
  'DATE_FORMAT' => '(yyyy-mm-dd)',
  
  'LBL_NONE' => 'none',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'Email:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informacje',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_NAME' => 'Nazwa:',
  'LBL_CONTACT_NAME' => 'Osoba kontaktowa: ',
  'LBL_LIST_COMPLETE' => 'Ukończone:',
  'LBL_LIST_STATUS' => 'Status:',
  'LBL_DATE_DUE_FLAG' => 'Brak daty płatności',
  'LBL_DATE_START_FLAG' => 'Brak daty rozpoczęcia',
  'ERR_DELETE_RECORD' => 'Wskaż rekord, który chcesz usunąć.',
  'ERR_INVALID_HOUR' => 'Wpisz proszę godzinę pomiędzy 0 a 24',
  'LBL_DEFAULT_STATUS' => 'Nie rozpoczęte',
  'LBL_DEFAULT_PRIORITY' => 'Średni',
  'LBL_LIST_MY_TASKS' => 'Moje otwarte zadania',
  'LNK_NEW_CALL' => 'Dodaj Rozmowę tel.',
  'LNK_NEW_MEETING' => 'Dodaj Spotkanie',
  'LNK_NEW_TASK' => 'Dodaj Zadanie',
  'LNK_NEW_NOTE' => 'Dodaj Notatkę',
  'LNK_NEW_EMAIL' => 'Dodaj Email',
  'LNK_CALL_LIST' => 'Lista Rozmów tel.',
  'LNK_MEETING_LIST' => 'Lista Spotkań',
  'LNK_TASK_LIST' => 'Lista Zadań',
  'LNK_NOTE_LIST' => 'Lista Notatek',
  'LNK_EMAIL_LIST' => 'Lista E-maili',
  'LNK_VIEW_CALENDAR' => 'Dziś:',
  'LBL_CONTACT_FIRST_NAME'=>'Kontakt - Imię',
  'LBL_CONTACT_LAST_NAME'=>'Kontakt - Nazwisko',
);


?>
