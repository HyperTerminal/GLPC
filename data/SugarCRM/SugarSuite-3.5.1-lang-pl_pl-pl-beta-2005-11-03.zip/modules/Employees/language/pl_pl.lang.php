<?php
/*******************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Pracownicy',
  'LBL_MODULE_TITLE' => 'Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
  'LBL_LIST_FORM_TITLE' => 'Pracownicy',
  'LBL_NEW_FORM_TITLE' => 'Nowy pracownik',
  'LBL_EMPLOYEE' => 'Pracownicy:',
  'LBL_LOGIN' => 'Nazwa użytkownika',
  'LBL_RESET_PREFERENCES' => 'Ustawienia domyślne',
  'LBL_TIME_FORMAT' => 'Format czasu:',
  'LBL_DATE_FORMAT' => 'Format daty:',
  'LBL_TIMEZONE' => 'Aktualny czas:',
  'LBL_CURRENCY' => 'Waluta:',
  'LBL_LIST_NAME' => 'Imię',
  'LBL_LIST_LAST_NAME' => 'Nazwisko',
  'LBL_LIST_EMPLOYEE_NAME' => 'Imię pracownika',
  'LBL_LIST_DEPARTMENT' => 'Departament',
  'LBL_LIST_REPORTS_TO_NAME' => 'Podlega',
  'LBL_LIST_EMAIL' => 'Email',
  'LBL_LIST_PRIMARY_PHONE' => 'Telefon',
  'LBL_LIST_USER_NAME' => 'Nazwa użytkownika',
  'LBL_LIST_EMPLOYEE_STATUS' => 'Status pracownika',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Nowy pracownik [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Nowy pracownik',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Błąd:',
  'LBL_PASSWORD' => 'Hasło:',
  'LBL_EMPLOYEE_NAME' => 'Imię pracownika:',
  'LBL_USER_NAME' => 'User Name:',
  'LBL_FIRST_NAME' => 'Imię:',
  'LBL_LAST_NAME' => 'Nazwisko:',
  'LBL_EMPLOYEE_SETTINGS' => 'Ustawienia',
  'LBL_THEME' => 'Szablon:',
  'LBL_LANGUAGE' => 'Język:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_EMPLOYEE_INFORMATION' => 'Informacje',
  'LBL_OFFICE_PHONE' => 'Telefon biurowy:',
  'LBL_REPORTS_TO' => 'Podlega:',
  'LBL_OTHER_PHONE' => 'Inny:',
  'LBL_OTHER_EMAIL' => 'Inny email:',
  'LBL_NOTES' => 'Uwagi:',
  'LBL_DEPARTMENT' => 'Departament:',
  'LBL_TITLE' => 'Tytuł:',
  'LBL_ANY_PHONE' => 'Dowolny telefon:',
  'LBL_ANY_EMAIL' => 'Dowolny email:',
  'LBL_ADDRESS' => 'Adres:',
  'LBL_CITY' => 'Miasto:',
  'LBL_STATE' => 'Stan:',
  'LBL_POSTAL_CODE' => 'Kod pocztowy:',
  'LBL_COUNTRY' => 'Kraj:',
  'LBL_NAME' => 'Name:',
  'LBL_MOBILE_PHONE' => 'Komórka:',
  'LBL_OTHER' => 'Inny:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'Email:',
  'LBL_HOME_PHONE' => 'Telefon domowy:',
  'LBL_ADDRESS_INFORMATION' => 'Dane adresowe',
  'LBL_EMPLOYEE_STATUS' => 'Status pracownika:',
  'LBL_PRIMARY_ADDRESS' => 'Główny adres:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Nowy użytkownik [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Nowy użytkownik',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Ulubiony kolor:',
  'LBL_MESSENGER_ID' => 'Nazwa komunikatora:',
  'LBL_MESSENGER_TYPE' => 'Typ komunikatora:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Pracownik ',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' już istnieje. Zmień nazwę pracownika na unikalną.',
  'ERR_LAST_ADMIN_1' => 'Pracownik "',
  'ERR_LAST_ADMIN_2' => '" jest ostatnim pracownikiem z prawami administracyjnymi. Przynajmniej jeden pracownik musi być administratorem.',
  'LNK_NEW_EMPLOYEE' => 'Stwórz pracownika',
  'LNK_EMPLOYEE_LIST' => 'Pracownicy',
  'ERR_DELETE_RECORD' => 'Musi być wprowadzony numer rekordu aby usunąć klienta.',

  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',

);
?>
