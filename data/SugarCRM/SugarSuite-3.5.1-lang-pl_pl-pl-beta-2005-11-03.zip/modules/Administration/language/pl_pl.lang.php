<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Administracja',
	'LBL_MODULE_TITLE' => 'Administracja: Strona główna',
	'LBL_NEW_FORM_TITLE' => 'Utwórz konto',
	'LNK_NEW_USER' => 'Utwórz użytkownika',
	'ERR_DELETE_RECORD' => 'Musi być wprowadzony numer rekordu, aby usunąć wpis.',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Ustawienia',
	'LBL_CONFIGURE_SETTINGS' => 'Skonfiguruj ustawienia systemu',
	'LBL_UPGRADE_TITLE' => 'Aktualizacja',
	'LBL_UPGRADE' => 'Aktualizuj Sugar Suite',
	'LBL_MANAGE_USERS_TITLE' => 'Zarządzanie użytkownikami',
	'LBL_MANAGE_USERS' => 'Zarządzaj użytkownikami i hasłami',
	'LBL_ADMINISTRATION_HOME_TITLE' => 'System',
	'LBL_NOTIFY_TITLE' => 'Opcje powiadamiania email\'em',
	'LBL_NOTIFY_FROMADDRESS' => 'Adres "Od":',
	'LBL_MAIL_SMTPSERVER' => 'Serwer SMTP:',
	'LBL_MAIL_SMTPPORT' => 'Port SMTP:',
	'LBL_MAIL_SENDTYPE' => 'System poczty:',
	'LBL_MAIL_SMTPUSER' => 'Nazwa użytkownika SMTP:',
	'LBL_MAIL_SMTPPASS' => 'Hasło SMTP:',
	'LBL_MAIL_SMTPAUTH_REQ' => 'Używaj autoryzacji SMTP?',
	'LBL_NOTIFY_SEND_BY_DEFAULT' => 'Wysyłaj powiadomienia domyślnie?',
	'LBL_NOTIFY_SUBJECT' => 'Temat email\'a:',
	'LBL_NOTIFY_ON' => 'Powiadomienia włączone?',
	'LBL_NOTIFY_FROMNAME' => 'Nazwa "Od":',
	'LBL_CURRENCY' => 'Ustaw waluty i przeliczniki',
	'LBL_RELEASE' => 'Zarządzaj wydaniami i wersjami',
	'LBL_LAYOUT' => 'Dodaj, usuń, zmień pola i wygląd paneli w aplikacji',
	'LBL_MANAGE_CURRENCIES' => 'Waluty',
	'LBL_MANAGE_RELEASES' => 'Wydania',
	'LBL_MANAGE_LAYOUT' => 'Ustawienia pól',
	'LBL_MANAGE_OPPORTUNITIES' => 'Szanse',
	'LBL_UPGRADE_CURRENCY' => 'Aktualizuj wartości walut w ',
	'LBL_EDIT_CUSTOM_FIELDS' => 'Edytuj pola definiowalne',
	'DESC_MODULES_QUEUED' => 'Następujące moduły są w kolejce do zainstalowania:',
	'DESC_FILES_QUEUED' => 'Następujące uaktualnienia są w kolejce do zainstalowania:',
	'DESC_MODULES_INSTALLED' => 'Następujace moduły zostały zainstalowane:',
	'DESC_FILES_INSTALLED' => 'Następujące uaktualnienia zostały zainstalowane:',
	'DESC_EDIT_CUSTOM_FIELDS' => 'Edytuj pola definiowalne',
	'LBL_DROPDOWN_EDITOR' => 'Edytor list rozwijanych',
	'DESC_DROPDOWN_EDITOR' => 'Dodaj, usuń lub zmień listy rozwijane w aplikacji',
	'LBL_IFRAME'=> 'Portal',
	'DESC_IFRAME' => 'Dodaj zakładki które mogą wyświetlić dowolną stronę',
	'LBL_BUG_TITLE' => 'Bug Tracker',
	'LBL_TIMEZONE' => 'Strefa czasowa',
	'LBL_STUDIO_TITLE' => 'Studio',
	'LBL_UPLOAD_MODULE' => 'Załaduj moduł: ',
	'LBL_UPLOAD_UPGRADE' => 'Załaduj uaktualnienie: ',
	'LBL_CONFIGURE_TABS' => 'Ustawienia zakładek',
	'LBL_CHOOSE_WHICH'=>'Wybierz, które zakładki są wyświetlane',
	'LBL_DISPLAY_TABS'=>'Wyświetlane zakładki',
	'LBL_HIDE_TABS'=>'Ukryte zakładki',
	'LBL_EDIT_TABS'=>'Edytuj zakładki',
	'LBL_UPGRADE_DB_TITLE' => 'Aktualizuj bazę danych',
	'LBL_UPGRADE_DB' => 'Aktualizuj bazę danych z wersji 2.0.x do 2.5 ',
	'LBL_UPGRADE_DB_BEGIN' => 'Rozpoczęcie aktualizacji',
	'LBL_UPGRADE_DB_COMPLETE' => 'Aktualizacja zakończona',
	'LBL_UPGRADE_VERSION'=>'Aktualizowanie informacji o systemie',
	'LBL_UPGRADE_DB_FAIL' => 'Aktualizacja się nie powiodła',
	'LBL_FORECAST_TITLE'=> 'Prognoza',
	'LBL_PORTAL_TITLE' => 'Customer Self-Service Portal',
	'LBL_PORTAL_ON' => 'Enable Self-Service Portal Integration?',
	'LBL_PORTAL_ON_DESC' => 'Allows Case, Note and other data to be accessible by an external customer self-service portal system.',
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut&reg;',
	'LBL_SKYPEOUT_ON' => 'Włącz integrację ze SkypeOut&reg; ?',
   	'LBL_SKYPEOUT_ON_DESC' => 'Pozwól użytkownikom kliknąć numer telefonu aby zadzwonić używając SkypeOut&reg;. Numery muszą być poprawnie sformatowane by użyć tej funckcjonalności. To znaczy musi być "+"  "Kod kraju" "Numer". Aby uzyskać więcej informacji na temat formatowania zobacz <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">Skype&reg; FAQ</a>    ',
	'LBL_NOTIFICATION_ON_DESC' => 'Wysyłaj powiadomienia email\'em kiedy wpisy są przyznawane.',
    'LBL_UPGRADE_WIZARD' => 'Kreator aktualizacji do zarządzania uaktualnieniami',
    'LBL_UPGRADE_WIZARD_TITLE' => 'Kreator aktualizacji',
    'LBL_MODULE_LOADER' => 'Dodaj lub usuń moduły do SugarCRM',
    'LBL_MODULE_LOADER_TITLE' => 'Wgrywanie modułów',
	'LBL_ALLOW_USER_TABS' => 'Pozwól użytkownikom konfigurować zakładki',
	'LBL_RENAME_TABS'=>'Zmień nazwe zakładek',
	'LBL_CHANGE_NAME_TABS'=>'Zmień etykietę zakładek.',
	'LBL_MASS_EMAIL_MANAGER_DESC'=> 'Zarządzaj kolejką mailingu',
	'LBL_MASS_EMAIL_MANAGER_TITLE'=> 'Menager mailingu',
	'LBL_MANAGE_ROLES_TITLE' => 'Zarządzanie rolami',
	'LBL_MANAGE_ROLES' => 'Zarządzaj członkostwem w rolach i właściwościami',
    'LBL_BACKUPS_TITLE' => 'Kopie zapasowe',
    'LBL_BACKUPS' => 'Wykonaj kopię zapasową',
	'LBL_IMPORT_CUSTOM_FIELDS_TITLE' => 'Importuj strukturę pól definiowalnych',
	'LBL_EXPORT_CUSTOM_FIELDS_TITLE' => 'Eksportuj strukturę pól definiowalnych',
	'LBL_EXTERNAL_DEV_TITLE'=> 'Przenieś pola definiowalne',
	'LBL_EXTERNAL_DEV_DESC'=> 'Przenieś strukturę pól definiowalnych z jednego systemu do drugiego',
	'LBL_IMPORT_CUSTOM_FIELDS'=> 'Importuj definicje pól definiowalnych z pliku .sugar', 
	'LBL_EXPORT_CUSTOM_FIELDS'=> 'Eksportuj definicje pól definiowalnych do pliku .sugar', 
	'LBL_IMPORT_CUSTOM_FIELDS_STRUCT'=> ' Struktura pól definiowalnych (SugarCustomFieldStruct.sug)',
	'LBL_IMPORT_CUSTOM_FIELDS_DESC'=> ' <br>Zaimportuj plik .sug, który został wyeksportowany z innego systemu. To spowoduje, że struktura pól definiowalnych w tym systemie będzie taka sama jak w innym systemie. Polecane jest wyeksportowanie aktualnej struktury przed importem nowej. Po imporcie, system automatycznie uruchomi aktualizację pól definiowalnych informując o tym jakie zmiany zajdą w bazie danych. Jeżeli akceptujesz te zmiany uruchom tryb "nie symulacji" na dole. Jeżeli chcesz przywrócić poprzedni stan, po prostu zaimportuj wcześniej wyeksportowaną strukturę.<br>Ostrzeżenie: Operacja usunie wszystkie poprzednio zdefiniowane pola i dane w nich zawarte.',
	'LBL_REBUILD_AUDIT_TITLE' => 'Rebuild Audit',
	'LBL_REBUILD_AUDIT_DESC' => 'Rebuilds audit table.',
	'LBL_REBUILD_EXTENSIONS_TITLE' => 'Rebuild Extensions',
	'LBL_REBUILD_EXTENSIONS_DESC' => 'Rebuild extensions including extended vardefs, language packs, menus, and administration',
   'LBL_REBUILD_CONFIG' =>'Przebuduj plik konfiguracyjny',
   'LBL_REBUILD_CONFIG_DESC' =>'Przebuduj config.php przez aktualizację wersji i dodanie domyślnych wartości jeżeli nie są zadeklarowane.',
   'BTN_REBUILD_CONFIG' =>'Przebuduj',
   'LBL_CONFIG_CHECK' =>'Sprawdź konfigurację',
   'MSG_CONFIG_FILE_READY_FOR_REBUILD' => 'Plik config.php jest gotowy do przebudowy.',
   'MSG_MAKE_CONFIG_FILE_WRITABLE' => 'Przyznaj plikowi config.php prawa do zapisu i spróbuj ponownie.',
   'MSG_CONFIG_FILE_REBUILD_SUCCESS' => 'Plik config.php został przebudowany.',
   'MSG_CONFIG_FILE_REBUILD_FAILED' => 'Plik config.php nie może być przebudowany.',
	'LBL_REPAIR_DATABASE' =>'Napraw bazę danych',
	'LBL_REPAIR_DATABASE_DESC' =>'Napraw bazę danych na podstawie wartości zawartych w vardefs (Tylko MYSQL)',
	'LBL_REPAIR_DISPLAYSQL' =>'Wyświetl zapytania SQL',
	'LBL_REPAIR_DATABASE_TEXT'=>'Narzędzia te pozwalają uaktualnić bazę danych by zgadzała się ze zmianami wprowadzonymi do vardefs i powiązań. <br>Możesz wybrać spośród 3 opcji: <br>Wyświetlić zapytania SQL, które mają być wykonane <br> Wyeksportować zapytania SQL do pliku<br> Wykonać zapytania SQL.',
	'LBL_REPAIR_EXPORTSQL' =>'Eksportuj zapytania SQL',
	'LBL_REPAIR_EXECUTESQL' =>'Wykonaj zapytania SQL',
	'LBL_SUGAR_UPDATE_TITLE'=>'Aktualizacje SugarCRM',
	'LBL_SUGAR_UPDATE'=>'Sprawdź najnowsze uaktualnienia.',
	'LBL_UPDATE_TITLE'=>'Włącz uaktualnienia SugarCRM:',
	'LBL_UPDATE_CHECK_TYPE'=>'Sprawdź uaktualnienia',
	'LBL_UPDATE_CHECK_AUTO'=>'Automatycznie',
	'LBL_UPDATE_CHECK_MANUAL'=>'Ręcznie',
	'LBL_CHECK_NOW_TITLE' =>'Sprawdź teraz',
	'LBL_CHECK_NOW_LABEL' =>'Sprawdź teraz',
	'LBL_SEND_STAT'=>'Rapotrowanie statystyk wykorzystania włączone.',	
	'LBL_CONFIGURE_UPDATER'=>'Konfiguruj uaktualnienia SugarCRM',
	'HEARTBEAT_MESSAGE'=>"<BR>Gdy jest to włączone twój system będzie samoczynie wysyłał do SugarCRM Inc. anonimowe statystyki dotyczące twojej instalacji, które pozwolą ustalić wzorce wykorzystania SugarCRM i rozwijać produkt. W zamian administrator będzie otrzymywał powiadomienia o dostępnych aktualizacjach.",
	'LBL_ERROR_VERSION_INFO'=>'Błąd podczas pobierania informacji o wersji, spróbuj ponownie później.',
	'LBL_REBUILD_REL_TITLE'=>'Przebuduj powiązania',
	'LBL_REBUILD_REL_DESC'=>'Przebudowuje meta informacje o powiązaniach i czyści plik cache.',
	'LBL_UPGRADE_CUSTOM_LABELS_TITLE'=>'Uaktualnij etykiety definiowalne',
	'LBL_UPGRADE_CUSTOM_LABELS_DESC'=>'Uaktualnia format etykiet pól definiowalnych w każdym pliku językowym.',
);
?>
