<?php
/**
 * English language file for History
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2005 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Historia',
  'LBL_MODULE_TITLE' => 'Historia: Strona g��wna',
  'LBL_SEARCH_FORM_TITLE' => 'Szukaj w historii',
  'LBL_LIST_FORM_TITLE' => 'Historia',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Odnosi si� do',
  'LBL_LIST_DATE' => 'Data',
  'LBL_LIST_TIME' => 'Pocz�tek',
  'LBL_LIST_CLOSE' => 'Zamknij',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Po�o�enie:',
  'LBL_DATE_TIME' => 'Pocz�tkowa data i czas:',
  'LBL_DATE' => 'Pocz�tkowa data:',
  'LBL_TIME' => 'Pocz�tkowy czas:',
  'LBL_DURATION' => 'Czas trwania:',
  'LBL_HOURS_MINS' => '(godziny/minuty)',
  'LBL_CONTACT_NAME' => 'Kontakt: ',
  'LBL_MEETING' => 'Spotkanie:',
  'LBL_DESCRIPTION_INFORMATION' => 'Opis',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Zaplanowane',
  'LNK_NEW_CALL' => 'Zaplanuj rozmow�',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Dodaj zadanie',
  'LNK_NEW_NOTE' => 'Dodaj notatk� lub za��cznik',
  'LNK_NEW_EMAIL' => 'Zarchiwizuj email',
  'LNK_CALL_LIST' => 'Rozmowy',
  'LNK_MEETING_LIST' => 'Spotkania',
  'LNK_TASK_LIST' => 'Zadania',
  'LNK_NOTE_LIST' => 'Notatki',
  'LNK_EMAIL_LIST' => 'Emaile',
  'ERR_DELETE_RECORD' => 'A record number must be specified to delete the account.',
  'NTC_REMOVE_INVITEE' => 'Are you sure you want to remove this invitee from the meeting?',
  'LBL_INVITEE' => 'Zaproszeni',
  'LBL_LIST_DIRECTION' => 'Kierunek',
  'LBL_DIRECTION' => 'Kierunek',
  'LNK_NEW_APPOINTMENT' => 'Dodaj termin',
  'LNK_VIEW_CALENDAR' => 'Dzi�',
  'LBL_OPEN_ACTIVITIES' => 'Rozpocz�te dzia�ania',
  'LBL_HISTORY' => 'Historia',
  'LBL_UPCOMING' => 'Zbli�aj�ce si� terminy',
  'LBL_TODAY' => 'do ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Dodaj zadanie [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Dodaj zadanie',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Zaplanuj spotkanie [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Zaplanuj spotkanie',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Zaplanuj rozmowe [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Zaplanuj rozmowe',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Dodaj notatk� lub za��cznik [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Dodaj notatk� lub za��cznik',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Zarchiwizuj email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Zarchiwizuj email',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DUE_DATE' => 'Due Date',
  'LBL_LIST_LAST_MODIFIED' => 'Ostatnio zmienione',
  'NTC_NONE_SCHEDULED' => 'Nie zaplanowane.',
  'appointment_filter_dom' => array(
  	 'today' => 'dzi�'
  	,'tomorrow' => 'jutro'
  	,'this Saturday' => 'w tym tygodniu'
  	,'next Saturday' => 'w nast�pnym tygodniu'
  	,'last this_month' => 'w tym miesi�cu'
  	,'last next_month' => 'w nast�pnym miesi�cu'
  ),
  'LNK_IMPORT_NOTES'=>'Importuj notatki',
  'NTC_NONE'=>'None',
	'LBL_ACCEPT_THIS'=>'Akceptuj?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Historia',
);

?>
