<?php
/**
 * Default English language strings
 *
 * PHP version 4
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Projekt',
	'LBL_MODULE_TITLE' => 'Projekty: Strona Główna',
	'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
        'LBL_LIST_FORM_TITLE' => 'Lista projektów',
    'LBL_HISTORY_TITLE' => 'Historia',

	'LBL_ID' => 'Id:',
	'LBL_DATE_ENTERED' => 'Data wprowadzenia:',
	'LBL_DATE_MODIFIED' => 'Data modyfikacji:',
	'LBL_ASSIGNED_USER_ID' => 'Przypisany do:',
	'LBL_MODIFIED_USER_ID' => 'Modified UserId:',
	'LBL_CREATED_BY' => 'Utworzony przez:',
	'LBL_TEAM_ID' => 'Grupa:',
	'LBL_NAME' => 'Nazwa:',
	'LBL_DESCRIPTION' => 'Opis:',
	'LBL_DELETED' => 'Usunięty:',

	'LBL_TOTAL_ESTIMATED_EFFORT' => 'Szacowane nakłady (godz.):',
	'LBL_TOTAL_ACTUAL_EFFORT' => 'Aktualne nakłady (godz.):',

	'LBL_LIST_NAME' => 'Nazwa',
	'LBL_LIST_ASSIGNED_USER_ID' => 'Przypisany do',
	'LBL_LIST_TOTAL_ESTIMATED_EFFORT' => 'Szacowane nakłady (godz.)',
	'LBL_LIST_TOTAL_ACTUAL_EFFORT' => 'Aktualne nakłady (godz.)',

	'LBL_PROJECT_SUBPANEL_TITLE' => 'Projekty',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE' => 'Zadania',
	'LBL_CONTACT_SUBPANEL_TITLE' => 'Kontakty',
	'LBL_ACCOUNT_SUBPANEL_TITLE' => 'Konta',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Szanse',
	'LBL_QUOTE_SUBPANEL_TITLE' => 'Quotes',

	'CONTACT_REMOVE_PROJECT_CONFIRM' => 'Czy na pewno usunąć Kontakt z tego projektu?',

	'LNK_NEW_PROJECT'	=> 'Dodaj projekt',
	'LNK_PROJECT_LIST'	=> 'Lista projektów',
	'LNK_NEW_PROJECT_TASK'	=> 'Dodaj zadanie',
	'LNK_PROJECT_TASK_LIST'	=> 'Zadania',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Projekty',
	'LBL_ACTIVITIES_TITLE'=>'Działania',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
);
?>
