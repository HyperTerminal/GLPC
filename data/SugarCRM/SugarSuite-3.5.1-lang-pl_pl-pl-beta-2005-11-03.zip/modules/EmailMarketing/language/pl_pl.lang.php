<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Marketing emailowy',
  'LBL_MODULE_TITLE' => 'Marketing emailowy: Strona domowa',
  'LBL_LIST_FORM_TITLE' => 'Kampanie marketingowe',
  'LBL_PROSPECT_LIST_NAME' => 'Nazwa:',
  'LBL_NAME' => 'Nazwa: ',
  'LBL_LIST_NAME' => 'Zazwa',
  'LBL_LIST_FROM_ADDR' => 'Email "Od"',
  'LBL_LIST_DATE_START' => 'Data rozpoczęcia',
  'LBL_LIST_TEMPLATE_NAME' => 'Szablon listu',
  'LBL_LIST_STATUS' => 'Status',
  
  'LBL_DATE_ENTERED' => 'Data wprowadzenia',
  'LBL_DATE_MODIFIED' => 'Data modyfikacji',
  'LBL_MODIFIED' => 'Zmodyfikowana przez: ',
  'LBL_CREATED' => 'Utworzona przez: ',

  'LBL_FROM_NAME' => 'Nazwa "Od": ',
  'LBL_FROM_ADDR' => 'Email "Od": ',
  'LBL_DATE_START' => 'Data rozpoczęcia',
  'LBL_TIME_START' => 'Czas rozpoczęcia',
  'LBL_START_DATE_TIME' => 'Data i czas rozpoczęcia: ',
  'LBL_TEMPLATE' => 'Szablon listu: ',
  
  'LBL_MODIFIED_BY' => 'Zmodyfikowana przez: ',
  'LBL_CREATED_BY' => 'Utworzona przez: ',
  'LBL_DATE_CREATED' => 'Data utworzenia: ',
  'LBL_DATE_LAST_MODIFIED' => 'Data modyfikacji: ',

  'LNK_NEW_CAMPAIGN' => 'Utwórz kampanię',
  'LNK_CAMPAIGN_LIST' => 'Kampanie',
  'LNK_NEW_PROSPECT_LIST' => 'Utwórz listę możliwości',
  'LNK_PROSPECT_LIST_LIST' => 'Lista możliwości',
  'LNK_NEW_PROSPECT' => 'Nowa możliwość',
  'LNK_PROSPECT_LIST' => 'Możliwośći',
  'LBL_DEFAULT_SUBPANEL_TITLE'=>'Marketing emailowy',

);
?>
