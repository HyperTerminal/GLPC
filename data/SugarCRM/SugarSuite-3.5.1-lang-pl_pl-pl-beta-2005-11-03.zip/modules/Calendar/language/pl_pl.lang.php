<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME'=>'Kalendarz',
  'LBL_MODULE_TITLE'=>'Kalendarz: Strona główna',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę tel.',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_APPOINTMENT' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Utwórz zadanie',
  'LNK_CALL_LIST' => 'Rozmowy',
  'LNK_MEETING_LIST' => 'Spotkania',
  'LNK_TASK_LIST' => 'Zadania',
  'LNK_VIEW_CALENDAR' => 'Dziś',
  'LBL_MONTH' => 'Miesiąc',
  'LBL_DAY' => 'Dzień',
  'LBL_YEAR' => 'Rok',
  'LBL_WEEK' => 'Tydzień',
  'LBL_PREVIOUS_MONTH' => 'Poprzedni miesiąc',
  'LBL_PREVIOUS_DAY' => 'Poprzedni dzień',
  'LBL_PREVIOUS_YEAR' => 'Poprzedni rok',
  'LBL_PREVIOUS_WEEK' => 'Poprzedni tydzień',
  'LBL_NEXT_MONTH' => 'Następny miesiąc',
  'LBL_NEXT_DAY' => 'Następny dzień',
  'LBL_NEXT_YEAR' => 'Następny rok',
  'LBL_NEXT_WEEK' => 'Następny tydzień',
  'LBL_AM' => 'AM',
  'LBL_PM' => 'PM',
  'LBL_SCHEDULED' => 'Zaplanowany',
  'LBL_BUSY' => 'Zajęty',
  'LBL_CONFLICT' => 'Konflikt',
  'LBL_USER_CALENDARS' => 'Kalendarze użytkownika',
  'LBL_SHARED' => 'Dzielony',
  'LBL_PREVIOUS_SHARED' => 'Poprzedni',
  'LBL_NEXT_SHARED' => 'Następny',
  'LBL_SHARED_CAL_TITLE' => 'Kalendarz dzielony',
  'LBL_USERS' => 'Użytkownik',
  'LBL_REFRESH' => 'Odświerz',
  'LBL_EDIT' => 'Edytuj',
  'LBL_SELECT_USERS' => 'Wybierz użytkowników dla których wyświetlić kalendarz',
  'LBL_FILTER_BY_TEAM' => 'Filtruj użytkowników wg zespołu:',
);

$mod_list_strings = array(
'dom_cal_weekdays'=>array(
"Nie",
"Pon",
"Wt",
"Śr",
"Czw",
"Pią",
"Sob",
),
'dom_cal_weekdays_long'=>array(
"Niedziela",
"Poniedziałek",
"Wtorek",
"Środa",
"Czwartek",
"Piątek",
"Sobota",
),
'dom_cal_month'=>array(
"",
"Sty",
"Lut",
"Mar",
"Kwi",
"Maj",
"Cze",
"Lip",
"Sie",
"Wrz",
"Paź",
"Lis",
"Gru",
),
'dom_cal_month_long'=>array(
"",
"Styczeń",
"Luty",
"Marzec",
"Kwiecień",
"Maj",
"Czerwiec",
"Lipiec",
"Sierpień",
"Wrzesień",
"Październik",
"Listopad",
"Grudzień",
)
);
?>
