<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
 
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Spotkania',
  'LBL_MODULE_TITLE' => 'Spotkania: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
  'LBL_LIST_FORM_TITLE' => 'Lista spotkań',
  'LBL_NEW_FORM_TITLE' => 'Kalendarz',
  'LBL_SCHEDULING_FORM_TITLE' => 'Planowanie',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_CONTACT' => 'Osoba kont.',
  'LBL_LIST_RELATED_TO' => 'Podlega',
  'LBL_LIST_DATE' => 'Data rozp.',
  'LBL_LIST_TIME' => 'Data zak.',
  'LBL_LIST_CLOSE' => 'Zamknij',
  'LBL_SUBJECT' => 'Temat: ',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Położenie:',
  'LBL_DATE_TIME' => 'Data i czas rozp.:',
  'LBL_DATE' => 'Data rozp.:',
  'LBL_TIME' => 'Czas rozp.:',
  'LBL_DURATION' => 'Okres trwania:',
  'LBL_DURATION_HOURS' => 'Godziny:',
  'LBL_DURATION_MINUTES' => 'Minuty:',
  'LBL_HOURS_MINS' => '(godz./min.)',
  'LBL_CONTACT_NAME' => 'Osoba kont.: ',
  'LBL_MEETING' => 'Spotkanie:',
  'LBL_DESCRIPTION_INFORMATION' => 'Informacje dodatkowe',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planowane',
  
'LNK_NEW_CALL'=>'Dodaj Rozmowę tel.',
'LNK_NEW_MEETING'=>'Dodaj Spotkanie',
'LNK_NEW_TASK'=>'Dodaj Zadanie',
'LNK_NEW_NOTE'=>'Dodaj Notatkę',
'LNK_NEW_EMAIL'=>'Dodaj E-mail',
'LNK_CALL_LIST'=>'Lista Rozmów',
'LNK_MEETING_LIST'=>'Lista Spotkań',
'LNK_TASK_LIST'=>'Lista Zadań',
'LNK_NOTE_LIST'=>'Lista Notatek',
'LNK_EMAIL_LIST'=>'Lista e-maili',

  'LNK_VIEW_CALENDAR' => 'Dziś',
  'ERR_DELETE_RECORD' => 'Wskaż rekord do skasowania.',
  'NTC_REMOVE_INVITEE' => 'Czy na pewno chcesz usunąć uczestnika spotkania?',
  'LBL_INVITEE' => 'Uczestnicy',
  'LNK_NEW_APPOINTMENT' => 'Nowe spotkanie',

  'LBL_ADD_INVITEE' => 'Dodaj uczestnika',
  'LBL_NAME' => 'Nazwa',
  'LBL_FIRST_NAME' => 'Imię',
  'LBL_LAST_NAME' => 'Nazwisko',
  'LBL_EMAIL' => 'Email',
  'LBL_PHONE' => 'Telefon',
  'LBL_REMINDER' => 'Przypomnij:',
  'LBL_SEND_BUTTON_TITLE'=>'Wyślij zaproszenie [Alt+I]',
  'LBL_SEND_BUTTON_KEY'=>'I',
  'LBL_SEND_BUTTON_LABEL'=>'Wyślij zaproszenie',
  'LBL_REMINDER_TIME'=>'Czas przypomnienia',
  'LBL_MODIFIED_BY'=>'Zmodyfikowany przez',
  'LBL_CREATED_BY'=>'Utworzony przez',
  'LBL_DATE_END'=>'Data zakończenia',
	
  'LBL_SEARCH_BUTTON'=> 'Szukaj',
  'LBL_ADD_BUTTON'=> 'Dodaj',
  'LBL_DEL'=> 'Usuń',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Spotkania',
  'LBL_LIST_STATUS'=>'Status',
  'LBL_LIST_DUE_DATE'=>'Due Date',
  'LBL_LIST_DATE_MODIFIED'=>'Data modyfikacji',
);


?>
