<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Działania',
  'LBL_MODULE_TITLE' => 'Działania: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj działanie',
  'LBL_LIST_FORM_TITLE' => 'Lista działań',
  'LBL_LIST_SUBJECT' => 'Temat',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_RELATED_TO' => 'Odnosi się do',
  'LBL_LIST_DATE' => 'Data',
  'LBL_LIST_TIME' => 'Rozpoczęcie',
  'LBL_LIST_CLOSE' => 'Zamknij',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_STATUS' => 'Status:',
  'LBL_LOCATION' => 'Miejsce:',
  'LBL_DATE_TIME' => 'Data i czas rozpoczęcia:',
  'LBL_DATE' => 'Data rozpoczęcia:',
  'LBL_TIME' => 'Czas rozpoczęcia:',
  'LBL_DURATION' => 'Czas trwania:',
  'LBL_HOURS_MINS' => '(godziny/minuty)',
  'LBL_CONTACT_NAME' => 'Nazwisko kontaktowe: ',
  'LBL_MEETING' => 'Spotkanie:',
  'LBL_DESCRIPTION_INFORMATION' => 'Opis',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_COLON' => ':',
  'LBL_DEFAULT_STATUS' => 'Planned',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę tel.',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Utwórz zadanie',
  'LNK_NEW_NOTE' => 'Utwórz notatkę lub załącznik',
  'LNK_NEW_EMAIL' => 'Zachowaj email',
  'LNK_CALL_LIST' => 'Rozmowy tel.',
  'LNK_MEETING_LIST' => 'Spotkania',
  'LNK_TASK_LIST' => 'Zadania',
  'LNK_NOTE_LIST' => 'Notatki',
  'LNK_EMAIL_LIST' => 'Email\'e',
  'ERR_DELETE_RECORD' => 'Musi być wprowadzony numer rekordu, aby usunąć ten wpis.',
  'NTC_REMOVE_INVITEE' => 'Czy na pewno usunąć te zaproszenie ze spotkania?',
  'LBL_INVITEE' => 'Zaproszenia',
  'LBL_LIST_DIRECTION' => 'Kierunek',
  'LBL_DIRECTION' => 'Kierunek',
  'LNK_NEW_APPOINTMENT' => 'Nowe spotkanie',
  'LNK_VIEW_CALENDAR' => 'Dziś',
  'LBL_OPEN_ACTIVITIES' => 'Rozpoczęte działania',
  'LBL_HISTORY' => 'Historia',
  'LBL_UPCOMING' => 'Zbliżające się spotkania',
  'LBL_TODAY' => 'through ',
  'LBL_NEW_TASK_BUTTON_TITLE' => 'Utwórz zadanie [Alt+N]',
  'LBL_NEW_TASK_BUTTON_KEY' => 'N',
  'LBL_NEW_TASK_BUTTON_LABEL' => 'Utwórz zadanie',
  'LBL_SCHEDULE_MEETING_BUTTON_TITLE' => 'Zaplanuj spotkanie [Alt+M]',
  'LBL_SCHEDULE_MEETING_BUTTON_KEY' => 'M',
  'LBL_SCHEDULE_MEETING_BUTTON_LABEL' => 'Zaplanuj spotkanie',
  'LBL_SCHEDULE_CALL_BUTTON_TITLE' => 'Zaplanuj rozmowę tel. [Alt+C]',
  'LBL_SCHEDULE_CALL_BUTTON_KEY' => 'C',
  'LBL_SCHEDULE_CALL_BUTTON_LABEL' => 'Zaplanuj rozmowę tel.',
  'LBL_NEW_NOTE_BUTTON_TITLE' => 'Utwórz notatkę lub załącznik [Alt+T]',
  'LBL_NEW_NOTE_BUTTON_KEY' => 'T',
  'LBL_NEW_NOTE_BUTTON_LABEL' => 'Utwórz notatkę lub załącznik',
  'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Zachowaj email [Alt+K]',
  'LBL_TRACK_EMAIL_BUTTON_KEY' => 'K',
  'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Zachowaj email',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DUE_DATE' => 'Due Date',
  'LBL_LIST_LAST_MODIFIED' => 'Ostatnio zmodyfikowany',
  'NTC_NONE_SCHEDULED' => 'Nie zaplanowany.',
  'appointment_filter_dom' => array(
  	 'today' => 'dziś'
  	,'tomorrow' => 'jutro'
  	,'this Saturday' => 'w tym tygodniu'
  	,'next Saturday' => 'w następnym tygodniu'
  	,'last this_month' => 'w tym miesiącu'
  	,'last next_month' => 'w następnym miesiącu'
  ),
  'LNK_IMPORT_NOTES'=>'Zaimportuj notatki',
  'NTC_NONE'=>'Brak',
	'LBL_ACCEPT_THIS'=>'Zaakceptować?',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Otwarte działania',
);


?>
