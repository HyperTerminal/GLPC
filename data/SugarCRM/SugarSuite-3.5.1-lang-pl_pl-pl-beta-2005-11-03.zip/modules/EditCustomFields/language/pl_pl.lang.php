<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
	'LBL_MODULE_NAME' => 'Edycja pól definiowalnych',
	'LBL_ADD_FIELD'=> 'Dodaj pole:',
	'LBL_MODULE_TITLE' => 'Edytuj pola definiowalne',
	'LBL_MODULE_SELECT' => 'Moduł do edycji',
	'LBL_SEARCH_FORM_TITLE' => 'Moduł wyszukiwania',
	'COLUMN_TITLE_NAME' => 'Nazwa pola',
	'COLUMN_TITLE_LABEL' => 'Etykieta pola',
	'COLUMN_TITLE_DATA_TYPE' => 'Typ danych',
	'COLUMN_TITLE_MAX_SIZE' => 'Maksymalny rozmiar',
	'COLUMN_TITLE_REQUIRED_OPTION' => 'Wymagane',
	'COLUMN_TITLE_DEFAULT_VALUE' => 'Wartość domyślna',
	'COLUMN_TITLE_EXT1' => 'Dodatkowe pole META 1',
	'COLUMN_TITLE_EXT2' => 'Dodatkowe pole META 2',
	'COLUMN_TITLE_EXT3' => 'Dodatkowe pole META 3',
	'COLUMN_TITLE_AUDIT' =>'Audit ?',
	'LBL_DROP_DOWN_LIST' => 'Lista rozwijana',
	'MSG_DELETE_CONFIRM' => 'Czy jesteś pewien, że chcesz usunąć ten element?',
	'POPUP_INSERT_HEADER_TITLE' => 'Dodaj pole definiowalne',
	'POPUP_EDIT_HEADER_TITLE' => 'Edytuj pole definiowalne',
	'LNK_SELECT_CUSTOM_FIELD' => 'Wybierz pole definiowalne',
);
?>
