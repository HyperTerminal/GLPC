<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Zestawienia',
  'LBL_MODULE_TITLE' => 'Zestawienia: Strona domowa',
  'LBL_SALES_STAGE_FORM_TITLE' => 'Wykres wg. etapów sprzedaży',
  'LBL_SALES_STAGE_FORM_DESC' => 'Wartość skumulowana projektów według etapów sprzedaży dla wybranych użytkowników w określonym przedziale czasowym.',
  'LBL_YEAR_BY_OUTCOME' => 'Wyniki miesięcznie',
  'LBL_MONTH_BY_OUTCOME_DESC' => 'Globalne, skumulowane wartości przychodów miesięcznie, wg. projektów (dla wybranych użytkowników), dla których spodziewana data zakończenia mieści się w wybranym przedziale czasowym. Wynik liczony jest dla projektów posiadający status Zakończony sukcesem, zakończony porażką i pozostałych.',
  'LBL_LEAD_SOURCE_FORM_TITLE' => 'Zestawienie projektów wg. źródeł pozyskania klienta',
  'LBL_LEAD_SOURCE_FORM_DESC' => 'Pokazuje skumulowane wartości projektów dla wybranych użytkowników w podziale na źródła pozyskania klienta.',
  'LBL_LEAD_SOURCE_BY_OUTCOME' => 'Wszyskie proj. źródła wg. wyników',
  'LBL_LEAD_SOURCE_BY_OUTCOME_DESC' => 'Globalne, skumulowane wyniki dla wybranych źródeł pozyskania klienta, wybranych użytkowników, w wybranym przedziale czasowym, dla wszystkich statusów procesu sprzedaży.',
  'LBL_PIPELINE_FORM_TITLE_DESC' => 'Skumulowane wyniki wg. etapów sprzedaży moich projektów których zakończenie mieści się w wybranym przedziale czasowym.',
  'LBL_DATE_RANGE' => 'Przedział czasowy od:',
  'LBL_DATE_RANGE_TO' => 'do:',
  'ERR_NO_OPPS' => 'Żeby zobaczyć zestawienia wartości przychodów z projektów, musisz utworzyć co najmniej jeden z nich.',
  'LBL_TOTAL_PIPELINE' => 'Wartość całkowita: ',
  'LBL_ALL_OPPORTUNITIES' => 'Całkowite przychody z proj. ',
  'LBL_OPP_SIZE' => 'Wartość projektu w PLN ',
  'LBL_OPP_THOUSANDS'=> 'tys. ',
  'NTC_NO_LEGENDS' => 'Brak',
  'LBL_LEAD_SOURCE_OTHER' => 'Inne',
  'LBL_EDIT' => 'Popraw',
  'LBL_REFRESH' => 'Odśwież',
  'LBL_CREATED_ON' => 'Ostatnia aktual.: ',
  'LBL_OPPS_WORTH' => 'szanse warte',
  'LBL_OPPS_IN_STAGE' => ' gdzie etap sprzedaży jest',
  'LBL_OPPS_IN_LEAD_SOURCE' => 'szanse gdzie źródłem pozyskania klienta jest',
  'LBL_OPPS_OUTCOME' => ' gdzie przychód jest',
  'LBL_ROLLOVER_DETAILS' => 'Najedź na pasek aby uzyskać szczegóły.',
  'LBL_ROLLOVER_WEDGE_DETAILS' => 'Najedź na fragment koła aby uzyskać szczegóły.',
  'LBL_USERS' => 'Użytkownicy:',
  'LBL_SALES_STAGES' => 'Etapy sprzedaży:',
  'LBL_LEAD_SOURCES' => 'Źródła klientów:',
  'LBL_DATE_START' => 'Data rozp.:',
  'LBL_DATE_END' => 'Data zak.:',
  'LBL_YEAR' => 'Rok:',
  'LNK_NEW_CONTACT' => 'Nowy kontakt',
  'LNK_NEW_ACCOUNT' => 'Nowy klient',
  'LNK_NEW_OPPORTUNITY' => 'Nowa szansa',
  'LNK_NEW_QUOTE' => 'Nowa wycena',
  'LNK_NEW_LEAD' => 'Nowy potencjalny klient',
  'LNK_NEW_CASE' => 'Nowa sprawa',
  'LNK_NEW_NOTE' => 'Utwórz notatkę lub załącznik',
  'LNK_NEW_CALL' => 'Zaplanuj rozmowę tel.',
  'LNK_NEW_MEETING' => 'Zaplanuj spotkanie',
  'LNK_NEW_TASK' => 'Nowe zadanie',
   'LNK_NEW_ISSUE' => 'Zgłoś błąd',
);


?>
