<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Folder ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' nie istnieje lub nie ma odpowiednich praw do zapisu',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Nie udało się wysłać pliku, spróbuj ponownie',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Plik jest za duży. Maks.:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Bajtów. Zmień wartość $upload_maxsize w pliku config.php',
  'LBL_MODULE_NAME' => 'Import',
  'LBL_TRY_AGAIN' => 'Spróbuj ponownie',
  'LBL_ERROR' => 'Błąd:',
  'ERR_MULTIPLE' => 'Kilka kolumn zdefiniowałeś jako źródło dla pojedynczej kolumny.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Wypełnij wartości w polach wymaganych:',
  'ERR_SELECT_FULL_NAME' => 'Nie możesz wybrać pełnej nazwy kiedy wybrałeś Imię i Nazwisko.',
  'ERR_SELECT_FILE' => 'Wybierz plik do wysłania.',
  'LBL_SELECT_FILE' => 'Wybierz plik:',
  'LBL_CUSTOM' => 'Własny',
  'LBL_CUSTOM_CSV' => 'Własny plik rozdzielany przecinkami',
  'LBL_CUSTOM_TAB' => 'Własny plik rozdzielany tabulatorami',
  'LBL_DONT_MAP' => '-- Nie mapuj tego pola! --',
  'LBL_STEP_1_TITLE' => 'Krok 1: Wybierz źródło',
  'LBL_WHAT_IS' => 'Co jest źródłem danych?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_ACT' => 'Act!',
  'LBL_ACT_2005' => 'Act! 2005',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Moje zapisane źródła:',
  'LBL_PUBLISH' => 'publikuj',
  'LBL_DELETE' => 'kasuj',
  'LBL_PUBLISHED_SOURCES' => 'Opublikowane źródło:',
  'LBL_UNPUBLISH' => 'Cofnij publikowanie',
  'LBL_NEXT' => 'Dalej >',
  'LBL_BACK' => '< Cofnij',
  'LBL_STEP_2_TITLE' => 'Krok 2: Wyślij plik do eksportu',
  'LBL_HAS_HEADER' => 'Nagłówek:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOW_CHOOSE' => 'Wybierz plik do importu:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98, 2000, XP, 2003 potrafi eksportować dane w formacie <b>Comma Separated Values</b>, który może być użyty do przeniesienia danych. Żeby wyeksportować dane z Outlooka wykonaj następujące kroki:',
  'LBL_OUTLOOK_NUM_1' => 'Uruchom <b>MS Outlook</b> ',
  'LBL_OUTLOOK_NUM_2' => 'Z Menu wybierz <b>Plik</b>, <b>Import i Export ...</b> ',
  'LBL_OUTLOOK_NUM_3' => 'Wybierz <b>Eksportuj do pliku</b> kliknij <b>[Dalej]</b> ',
  'LBL_OUTLOOK_NUM_4' => 'Wybierz <b>Comma Separated Values (Windows)</b> kliknij <b>[Dalej]</b>.<br> Uwaga: System może upomnieć się o doinstalowanie modułu eksportu. ',
  'LBL_OUTLOOK_NUM_5' => 'Wybierz folder <b>Kontakty</b> i kliknij <b>[Dalej]</b>. Możesz wybrać dowolny folder w którym przechowujesz kontakty.',
  'LBL_OUTLOOK_NUM_6' => 'Wybierz Nazwę Pliku i kliknij <b>[Dalej]</b>',
  'LBL_OUTLOOK_NUM_7' => 'Kliknij <b>[Zakończ]</b>',
  'LBL_IMPORT_ACT_TITLE' => 'Act! Potrafi eksportować dane w formacie  <b>Comma Separated Values</b> dane takie możesz zaimportować do SugarSales. Żeby wyeksportować dane z programu ACT! wykonaj poniższe czynności:',
  'LBL_ACT_NUM_1' => 'Uruchom <b>ACT!</b>',
  'LBL_ACT_NUM_2' => 'Z menu wybierz <b>Plik</b> <b>Wymiana danych</b>, <b>Eksport...</b>',
  'LBL_ACT_NUM_3' => 'Wybierz format pliku: <b>Text-Delimited</b>',
  'LBL_ACT_NUM_4' => 'Wprowadź nazwę pliku i położenie, następnie kliknij <b>[Dalej]</b>',
  'LBL_ACT_NUM_5' => 'Wybierz <b>Tylko Kontakty</b>',
  'LBL_ACT_NUM_6' => 'Kliknij <b>Opcje...</b>',
  'LBL_ACT_NUM_7' => 'Wybierz <b>Comma</b> jako znak oddzielający pola',
  'LBL_ACT_NUM_8' => 'Zaznacz checkbox <b>Tak, eksportuj nazwy pól</b>, kliknij <b>[OK]</b>',
  'LBL_ACT_NUM_9' => 'Kliknij <b>[Dalej]</b>',
  'LBL_ACT_NUM_10' => 'Wybierz <b>Wszystkie Rekordy</b>, kliknij <b>[Zakończ]</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com potrafi eksportować do formatu <b>Comma Separated Values</b>. Żeby wyeksportować dane postępuj zgodnie z poniższą instrukcją:',
  'LBL_SF_NUM_1' => 'Uruchom przeglądarkę, idź do <b>http://www.salesforce.com</b>, zaloguj się na swoje konto.',
  'LBL_SF_NUM_2' => 'Kliknij zakładkę <b>Reports</b> w górnym menu. ',
  'LBL_SF_NUM_3' => 'Żeby wyeksportować konta kliknij link: <b>Active Accounts</b>. <br>Żeby wyeksportować kontakty kliknij link: <b>Mailing List</b> ',
  'LBL_SF_NUM_4' => '<b>Krok 1: Wybierz typ raportu</b>, wybierz <b>Tabular Report</b> kliknij <b>Next</b>',
  'LBL_SF_NUM_5' => '<b>Krok 2: Wybierz kolumny raportu </b>, wybierz kolumny jakie chcesz wyeksportować i kliknij <b>Next</b>',
  'LBL_SF_NUM_6' => '<b>Krok 3: Wybierz rodzaj informacji do podsumowania </b>, kliknij <b>Next</b>',
  'LBL_SF_NUM_7' => '<b>Krok 4: Uporządkuj kolumny raportu </b>, kliknij <b>Next</b>',
  'LBL_SF_NUM_8' => '<b>Krok 5: Określ kryteria raportu</b>, Określ dokładne kryteria danych przeznaczonych do eksportu. Możesz w tym celu wykorzystać narzędzia zaawansowanego określania kryteriów. Po zakończeniu kliknij <b>Run Report</b>',
  'LBL_SF_NUM_9' => 'Raport zostanie wygenerowany; na stronie powinien pojawić się komunikat: <b>Report Generation Status: Complete.</b> kliknij <b>Export to Excel</b>',
  'LBL_SF_NUM_10' => '<b>Export Report:</b>, wybierz format pliku <b>Comma Delimited .csv</b>. Kliknij <b>Export</b>.',
  'LBL_SF_NUM_11' => 'Pojawi się komunikat monitujący o zapisanie pliku na Twoim komputerze..',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Wiele aplikacji pozwala na eksport w formacie <b>Comma Delimited text file (.csv)</b>. Generalnie obsługa eksportu w większości aplikacji składa się z następujących kroków:',
  'LBL_CUSTOM_NUM_1' => 'Uruchom aplikację, wskaż lub  załaduj źródło danych.',
  'LBL_CUSTOM_NUM_2' => 'Wybierz <b>Save As...</b> lub <b>Export...</b> z menu',
  'LBL_CUSTOM_NUM_3' => 'Zapisz plik w formacie <b>CSV</b> lub <b>Comma Separated Values</b> .',
  
  'LBL_IMPORT_TAB_TITLE' => 'Many applications will allow you to export data into a <b>Tab Delimited text file (.tsv or .tab)</b>. Generally most applications follow these general steps:',
  'LBL_TAB_NUM_1' => 'Launch the application and Open the data file',
  'LBL_TAB_NUM_2' => 'Select the <b>Save As...</b> or <b>Export...</b> menu option',
  'LBL_TAB_NUM_3' => 'Save the file in a <b>TSV</b> or <b>Tab Separated Values</b> format',
  'LBL_STEP_3_TITLE' => 'Step 3: Confirm Fields and Import',
  'LBL_SELECT_FIELDS_TO_MAP' => 'In the list below, select the fields in your import file that should be imported into each field in the system. When you are finished, click <b>Import Now</b>:',
  'LBL_DATABASE_FIELD' => 'Pole bazy danych',
  'LBL_HEADER_ROW' => 'Nagłówek',
  'LBL_ROW' => 'Row',
  'LBL_SAVE_AS_CUSTOM' => 'Zapisz jako Custom Mapping:',
  'LBL_CONTACTS_NOTE_1' => 'Jedno z pól Nazwisko lub Pełna Nazwa musi być zmapowane.',
  'LBL_CONTACTS_NOTE_2' => 'Jeśli zmapowane jest pole Pełna Nazwa, pola Imię i Nazwisko są ignorowane.',
  'LBL_CONTACTS_NOTE_3' => 'Jeśli zmapowałeś pole Pełna Nazwa, jego zawartość zostanie rozbita na Imię i Nazwisko po zakończeniu importu.',
  'LBL_CONTACTS_NOTE_4' => 'Ostatnie pola adresu 2 i 3 są łączone w pole Ulica adresu głównego podczas dodawania do bazy.',
  'LBL_ACCOUNTS_NOTE_1' => 'Nazwa klienta musi być zmapowana.',
  'LBL_ACCOUNTS_NOTE_2' => 'Ostatnie pola adresu 2 i 3 są łączone w pole Ulica adresu głównego podczas dodawania do bazy.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Nazwa Projektu, Nazwa Klienta, Data Zakończenia, oraz Etap Sprzedaży są polami wymaganymi.',
  'LBL_IMPORT_NOW' => 'Importuj',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Nie mogę otworzyć pliku do importu.',
  'LBL_NOT_SAME_NUMBER' => 'Twój plik zawiera niespójną ilość pól w poszczególnych liniach.',
  'LBL_NO_LINES' => 'Twój plik importu jest pusty.',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Wskazany przez Ciebie plik nie istnieje lub został już zaimportowany',
  'LBL_SUCCESS' => 'Sukces:',
  'LBL_SUCCESSFULLY' => 'Poprawnie zaimportowano dane',
  'LBL_LAST_IMPORT_UNDONE' => 'Operacja ostatniego importu anulowana',
  'LBL_NO_IMPORT_TO_UNDO' => 'Nie można cofnąć operacji importu.',
  'LBL_FAIL' => 'Błąd:',
  'LBL_RECORDS_SKIPPED' => 'rekord pominięty ze wzgledu na brak lub niespójność danych',
  'LBL_IDS_EXISTED_OR_LONGER' => 'rekord pominięty. Rekord o identycznym ID istnieje lub jest dłuższy niż 36 znaków',
  'LBL_RESULTS' => 'Wyniki',
  'LBL_IMPORT_MORE' => 'Importuj następne',
  'LBL_FINISHED' => 'Zakończone',
  'LBL_UNDO_LAST_IMPORT' => 'Cofnij ostatni import',
  'LBL_LAST_IMPORTED'=>'Last Imported',
  'ERR_MULTIPLE_PARENTS' => 'You can only have one Parent ID defined',
);



?>
