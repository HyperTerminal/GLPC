<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * Portions created by Maciej Jonakowski are Copyright (C) Maciej Jonakowski
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_ASSIGNED_TO_NAME' => 'Assigned To Name',
  'LBL_MODULE_NAME' => 'Potencjalni Klienci',
  'LBL_INVITEE' => 'Podlega',
  'LBL_MODULE_TITLE' => 'Potencjalni Klienci: Strona główna',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukaj',
  'LBL_LIST_FORM_TITLE' => 'Lista',
  'LBL_NEW_FORM_TITLE' => 'Dodaj Potencjalnego kl.',
  'LBL_CONTACT_OPP_FORM_TITLE' => 'Projekty-Potencjalni kl.:',
  'LBL_CONTACT' => 'Potencjalny kl.:',
  'LBL_BUSINESSCARD' => 'Convert Lead',
  'LBL_LIST_NAME' => 'Nazwa',
  'LBL_LIST_LAST_NAME' => 'Nazwisko',
  'LBL_LIST_CONTACT_NAME' => 'Potencjalny kl.',
  'LBL_LIST_TITLE' => 'Tytuł',
  'LBL_LIST_ACCOUNT_NAME' => 'Nazwa klienta',
  'LBL_LIST_EMAIL_ADDRESS' => 'E-mail',
  'LBL_CONTACT_ID' => 'ID kontaktu',
  'LBL_ACCOUNT_ID'=>'ID klienta',
  'LBL_OPPORTUNITY_ID'=>'ID szansy',
  'LBL_LIST_PHONE' => 'Tel.',
  'LBL_LIST_CONTACT_ROLE' => 'Funkcja',
  'LBL_LIST_FIRST_NAME' => 'Imię',
  'LBL_LIST_REFERED_BY' => 'Wskazany przez',
  'LBL_LIST_LEAD_SOURCE' => 'Źródło',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_LIST_DATE_ENTERED' => 'Data utworzenia',
  'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Uwagi do źródła pozyskania',
  'LBL_LIST_MY_LEADS' => 'Moi potencjalni',
//DON'T CONVERT THESE THEY ARE MAPPINGS
  'db_last_name' => 'LBL_LIST_LAST_NAME',
  'db_first_name' => 'LBL_LIST_FIRST_NAME',
  'db_title' => 'LBL_LIST_TITLE',
  'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
  'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
  'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',
//END DON'T CONVERT
  'LBL_EXISTING_CONTACT' => 'Użyto istniejący kontakt',
  'LBL_CREATED_CONTACT' => 'Dodano nową Osobę kont.',
  'LBL_EXISTING_OPPORTUNITY' => 'Użyto istniejący projekt',
  'LBL_CREATED_OPPORTUNITY' => 'Dodano nowy projekt',
  'LBL_EXISTING_ACCOUNT' => 'Użyto istniejącego klienta',
  'LBL_CREATED_ACCOUNT' => 'Dodano nowego klienta',
  'LBL_CREATED_CALL' => 'Dodano nową rozmowę',
  'LBL_CREATED_MEETING' => 'Dodano nowe spotkanie',
  'LBL_BACKTOLEADS' => 'Powrót do Potencjalnych kl.',
  'LBL_CONVERTLEAD' => 'Przekształć w Klienta.',
  'LBL_NAME' => 'Nazwa:',
  'LBL_CONTACT_NAME' => 'Potencjalny Klient:',
  'LBL_CONTACT_INFORMATION' => 'Informacje podstawowe',
  'LBL_FIRST_NAME' => 'Imię:',
  'LBL_OFFICE_PHONE' => 'tel. biuro:',
  'LBL_ACCOUNT_NAME' => 'Nazwa klienta:',
  'LBL_OPPORTUNITY_NAME' => 'Projekt:',
  'LBL_OPPORTUNITY_AMOUNT' => 'Wartość projektu:',
  'LBL_ANY_PHONE' => 'Dowolny tel.?:',
  'LBL_PHONE' => 'Tel.:',
  'LBL_LAST_NAME' => 'Nazwisko:',
  'LBL_MOBILE_PHONE' => 'Tel. kom.:',
  'LBL_HOME_PHONE' => 'Tel dom.:',
  'LBL_LEAD_SOURCE' => 'Źródło pozyskania:',
  'LBL_STATUS' => 'Status:',
  'LBL_LEAD_SOURCE_DESCRIPTION' => 'Informacje o pozyskaniu:',
  'LBL_STATUS_DESCRIPTION' => 'Opis:',
  'LBL_OTHER_PHONE' => 'Tel. 2:',
  'LBL_FAX_PHONE' => 'Fax:',
  'LBL_TITLE' => 'Tytuł:',
  'LBL_DEPARTMENT' => 'Wydział:',
  'LBL_EMAIL_ADDRESS' => 'E-mail:',
  'LBL_OTHER_EMAIL_ADDRESS' => 'E-mail 2:',
  'LBL_ANY_EMAIL' => 'Użyć dowolny e-mail?:',
  'LBL_REPORTS_TO' => 'Podlega:',
  'LBL_DO_NOT_CALL' => 'Nie dzwonić?:',
  'LBL_EMAIL_OPT_OUT' => 'E-mail opcjonalny:',
  'LBL_PRIMARY_ADDRESS' => 'Adres podstawowy:',
  'LBL_ALTERNATE_ADDRESS' => 'Adres alternatywny:',
  'LBL_ANY_ADDRESS' => 'Dowolny adres?:',
  'LBL_REFERED_BY' => 'Wskazany przez:',
  'LBL_CITY' => 'Miejscowość:',
  'LBL_STATE' => 'Woj.:',
  'LBL_POSTAL_CODE' => 'Kod poczt.:',
  'LBL_COUNTRY' => 'Kraj:',
  'LBL_PRIMARY_ADDRESS_STREET' => 'Adres podstawowy - ulica',
  'LBL_PRIMARY_ADDRESS_STREET_2'=>'Adres podstawowy - ulica 2',
  'LBL_PRIMARY_ADDRESS_STREET_3'=>'Adres podstawowy - ulica 3',   
  'LBL_PRIMARY_ADDRESS_CITY' => 'Adres podstawowy - miasto',
  'LBL_PRIMARY_ADDRESS_STATE' => 'Adres podstawowy - stan',
  'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Adres podstawowy - kod pocztowy',
  'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Adres podstawowy - kraj',
  'LBL_ALT_ADDRESS_STREET' => 'Adres alt. ulica',
  'LBL_ALT_ADDRESS_STREET_2' => 'Adres alt. ulica 2',
  'LBL_ALT_ADDRESS_STREET_3' => 'Adres alt. ulica 3',
  'LBL_ALT_ADDRESS_CITY' => 'Adres alt. miasto',
  'LBL_ALT_ADDRESS_STATE' => 'Adres alt. stan',
  'LBL_ALT_ADDRESS_POSTALCODE' => 'Adres alt. kod pocztowy',
  'LBL_ALT_ADDRESS_COUNTRY' => 'Adres alt. kraj',
  'LBL_DESCRIPTION_INFORMATION' => 'Dodatkowe informacje',
  'LBL_ADDRESS_INFORMATION' => 'Informacje adresowe',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_CONTACT_ROLE' => 'Funkcja:',
  'LBL_OPP_NAME' => 'Projekt:',
  'LBL_IMPORT_VCARD' => 'Importuj vCard',
  'LNK_IMPORT_VCARD' => 'Utwórz z vCard',
  'LBL_IMPORT_VCARDTEXT' => 'Utwórz automatycznie poprzez import Vcards.',
  'LBL_DUPLICATE' => 'Podobni Potencjalni Klienci',
  'MSG_DUPLICATE' => 'Znaleziono podobnych Potencjalnych Klientów. Sprawdź czy wybrani do konwersji Potencjalni Klienci nie istnieją w systemie. Możesz kontynuować konwersję klikając [Dalej].',
  'LBL_ADD_BUSINESSCARD' => 'Dodaj Business Card',
  'LNK_NEW_APPOINTMENT' => 'Dodaj Spotkanie',
  'LNK_NEW_LEAD' => 'Dodaj Potencjalnego klienta',
  'LNK_LEAD_LIST' => 'Lista Potencjalnych Klientów',
  'NTC_DELETE_CONFIRMATION' => 'Czy na pewno skasować dane?',
  'NTC_REMOVE_CONFIRMATION' => 'Usunąć klienta ze zdarzenia?',
  'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Usunąć informacje o przełożonym?',
  'ERR_DELETE_RECORD' => 'pl_pl Wskaż rekord do usunięcia.',
  'NTC_COPY_PRIMARY_ADDRESS' => 'Kopiuj adres podstawowy do alternatywnego',
  'NTC_COPY_ALTERNATE_ADDRESS' => 'Kopiuj adres alternatywny do podstawowego',
  'LNK_NEW_CONTACT' => 'Dodaj Osobę kontaktową',
  'LNK_NEW_NOTE' => 'Dodaj Notatkę',
  'LNK_NEW_ACCOUNT' => 'Dodaj Klienta',
  'LNK_NEW_OPPORTUNITY' => 'Dodaj Zadanie',
  'LNK_SELECT_ACCOUNT' => 'Wybierz Klienta',
  'LBL_SALUTATION' => 'Tytuł',
  'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Utworzenie szansy wymaga klienta.\n Wybierz już istniejącego lub utwórz nowego.',
  'LBL_CONVERTLEAD_TITLE' => 'Przekształć w Klienta [Alt+V]',
  'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
  'LBL_PORTAL_NAME' => 'Nazwa portalu:',
  'LBL_NEW_PORTAL_PASSWORD' => 'Nowe hasło portalu:',
  'LBL_PORTAL_PASSWORD_ISSET' => 'Hasło portalu jest ustawione:',
  'LBL_PORTAL_ACTIVE' => 'Portal aktywny:',
  'LBL_PORTAL_INFORMATION' => 'Informacje',
  'LBL_PORTAL_APP'=> 'Portal Application',
  'LBL_ACCOUNT_DESCRIPTION'=> 'Opis konta',
  'LBL_CONVERTED'=> 'Converted',
  'LBL_REPORTS_TO_ID'=>'Podlega ID',
  'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Select Checked Leads',
  'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Select Checked Leads',
  'LBL_INVALID_EMAIL'=>'Niepoprawny email:',
  'LBL_CONVERTED_CONTACT' => 'Converted Contact:',
  'LBL_CONVERTED_ACCOUNT'=>'Converted Account:',
  'LBL_CONVERTED_OPP'=>'Converted Opportunity:',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Potencjalni klienci',
  'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Działania',
  'LBL_HISTORY_SUBPANEL_TITLE'=>'Historia',
);


?>
