<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: Defines the Polish language pack for this module.
 * Portions created by Bartosz Sobolewski are Copyright (C) CorNet.
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Szablony emaili',
  'LBL_MODULE_TITLE' => 'Szablony emaili: Strona domowa',
  'LBL_SEARCH_FORM_TITLE' => 'Przeszukaj szablony emaili',
  'LBL_LIST_FORM_TITLE' => 'Lista szablonów emaili',
  'LBL_NEW_FORM_TITLE' => 'Utwórz szablon',
  'LBL_LIST_NAME' => 'Nazwa',
  'LBL_LIST_DESCRIPTION' => 'Opis',
  'LBL_LIST_DATE_MODIFIED' => 'Data modyfikacji',
  'LBL_NAME' => 'Nazwa:',
  'LBL_DESCRIPTION' => 'Opis:',
  'LBL_SUBJECT' => 'Temat:',
  'LBL_CLOSE' => 'Zamknij:',
  'LBL_RELATED_TO' => 'Odnosi się do:',
  'LBL_BODY' => 'Treść:',
  'LBL_PUBLISH' => 'Opublikuj:',
  'LBL_COLON' => ':',

'LNK_NEW_EMAIL_TEMPLATE'=>'Utwórz szablon emaila',
'LNK_EMAIL_TEMPLATE_LIST'=>'Szablony emaili',
'LNK_IMPORT_NOTES'=>'Importuj notatki',
'LNK_VIEW_CALENDAR' => 'Dziś',
'LNK_CHECK_EMAIL'=>'Sprawdź pocztę',
'LNK_NEW_SEND_EMAIL'=>'Utwórz email',
'LNK_ARCHIVED_EMAIL_LIST'=>'Zarchiwizowane emaile',
'LNK_SENT_EMAIL_LIST'=>'Wysłane emaile',
'LNK_NEW_EMAIL'=>'Zarchiwizuj email',
'LBL_INSERT_VARIABLE'=>'Wstaw zmienną:',
'LBL_INSERT'=>'Wstaw',
'LNK_DRAFTS_EMAIL_LIST'=>'Szkic',
'LNK_ALL_EMAIL_LIST'=>'Wszystkie emaile',
'LNK_NEW_ARCHIVE_EMAIL'=>'Utwórz zarchiwizowany email',
'LBL_CONTACT_AND_OTHERS'=>'Kontakt/Prawdopodobny klient/Możliwość',
'LBL_HTML_BODY'=>'HTML',
'LBL_TEXT_BODY'=>'Tekst',
'LBL_EDIT_ALT_TEXT'=>'Edytuj tekst alternatywny',
'LBL_SHOW_ALT_TEXT'=>'Wyświetl tekst alternatywny',

);


?>
