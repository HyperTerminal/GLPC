<?php 
$manifest = array( 
	'name' => 'Deutsche Sprachversion',
	'description' => 'Einsetzbar für Version 5.0*',
	'type' => 'langpack',
	'is_uninstallable' => 'Yes',
	'version' => '2.2',
	'acceptable_sugar_flavors' => array ("CE", "PRO","ENT"),
	'published_date' => '150608',
	'author' => 'Genius4U Ltd / simplicity gmbh / iscongroup',
	'acceptable_sugar_versions' => array ("5.0.0*"),
);

$installdefs = array(
	'id'=> 'ge_ge',
	'image_dir'=>'<basepath>/images',
	'copy' => array(
	array('from'=> '<basepath>/include','to'=> 'include',),
        array('from'=> '<basepath>/install','to'=> 'install',),
	array('from'=> '<basepath>/portal','to'=> 'portal',),
	array('from'=> '<basepath>/jscalendar','to'=> 'jscalendar',),
	array('from'=> '<basepath>/modules','to'=> 'modules'))
);
?>
