<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	'LBL_SEND_DATE_TIME'						=> 'Sendedatum',
	'LBL_IN_QUEUE'								=> 'In Warteschlange?',
	'LBL_IN_QUEUE_DATE'							=> 'Warteschlange Datum',

	'ERR_INT_ONLY_EMAIL_PER_RUN'				=> 'Nur ganzzahlige Werte zulässig für Anzahl E-Mails pro Batch.',

	'LBL_ATTACHMENT_AUDIT'						=> ' wurde gesendet. Es wurde nicht lokal dupliziert um Speicher zu sparen.',
	'LBL_CONFIGURE_SETTINGS'					=> 'Konfigurieren',
	'LBL_CUSTOM_LOCATION'						=> 'Benutzerdefiniert',
	'LBL_DEFAULT_LOCATION'						=> 'Standard',
	
	'LBL_DISCLOSURE_TITLE'						=> 'Vertraulichkeitshinweis an jede E-Mail anhängen',
	'LBL_DISCLOSURE_TEXT_TITLE'					=> 'Inhalt Vertraulichkeitshinweis',
	'LBL_DISCLOSURE_TEXT_SAMPLE'				=> 'Dieses E-Mail sowie angehängte Anlagen sind vertraulich und nur für die benannte Person oder Firma bestimmt. Sollten Sie dieses E-Mail irrtümlicherweise erhalten haben, benachrichtigen Sie bitte den Absender und entfernen Sie das E-Mail nebst Anlagen von Ihrem System. Vielen Dank.',
	
	'LBL_EMAIL_DEFAULT_CHARSET'					=> 'E-Mail Nachrichten mit diesem Zeichensatz erstellen',
	'LBL_EMAIL_DEFAULT_CLIENT'					=> 'E-Mail Nachrichten in diesem Format erstellen',
	'LBL_EMAIL_DEFAULT_EDITOR'					=> 'E-Mail Nachrichten mit diesem Client erstellen',
	'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS'		=> 'Verknüpfte Notizen und Anhänge mit den E-Mails löschen',
	'LBL_EMAIL_GMAIL_DEFAULTS'					=> 'Gmail Standardwerte füllen',
	'LBL_EMAIL_PER_RUN_REQ'						=> 'Anzahl Mails gesendet pro Batch:',
	'LBL_EMAIL_SMTP_SSL'						=> 'SMTP über SSL aktivieren',
	'LBL_EMAIL_USER_TITLE'						=> 'Benutzer E-Mail Standard',
	'LBL_EMAILS_PER_RUN'						=> 'Anzahl Mails gesendet pro Batch:',
	'LBL_ID'									=> 'ID',
	'LBL_LIST_CAMPAIGN'							=> 'Kampagne',
	'LBL_LIST_FORM_PROCESSED_TITLE'				=> 'Verarbeitet',
	'LBL_LIST_FORM_TITLE'						=> 'Warteschlange',
	'LBL_LIST_FROM_EMAIL'						=> 'Von E-Mail',
	'LBL_LIST_FROM_NAME'						=> 'Von Name',
	'LBL_LIST_IN_QUEUE'							=> 'In Arbeit',
	'LBL_LIST_MESSAGE_NAME'						=> 'Marketing Nachricht',
	'LBL_LIST_RECIPIENT_EMAIL'					=> 'Empfänger E-Mail',
	'LBL_LIST_RECIPIENT_NAME'					=> 'Emfpänger Name',
	'LBL_LIST_SEND_ATTEMPTS'					=> 'Sendeversuche',
	'LBL_LIST_SEND_DATE_TIME'					=> 'Senden Ein',
	'LBL_LIST_USER_NAME'						=> 'Benutzername',
	'LBL_LOCATION_ONLY'							=> 'Ort',
	'LBL_LOCATION_TRACK'						=> 'Speicherort der Kampagnentracking Dateien (z.B. campaign_tracker.php)',
    'LBL_CAMP_MESSAGE_COPY'                     => 'Kopien der Kampagnen Nachrichten behalten:',
	'LBL_MAIL_SENDTYPE'							=> 'E-Mail Transfer Agent:',
	'LBL_MAIL_SMTPAUTH_REQ'						=> 'SMTP Authentfiizierung verwenden?',
	'LBL_MAIL_SMTPPASS'							=> 'SMTP Passwort:',
	'LBL_MAIL_SMTPPORT'							=> 'SMTP Port:',
	'LBL_MAIL_SMTPSERVER'						=> 'SMTP Server:',
	'LBL_MAIL_SMTPUSER'							=> 'SMTP User-Name:',
	'LBL_MARKETING_ID'							=> 'Marketing ID',
    'LBL_MODULE_ID'                             => 'EmailMan',
	'LBL_MODULE_NAME'							=> 'E-Mail Einstellungen',
	'LBL_CAMP_MODULE_NAME'						=> 'Kampagnen E-Mail Einstellungen',
	'LBL_MODULE_TITLE'							=> 'Ausgehende E-Mail Warteschlange Verwaltung',
	'LBL_NOTIFICATION_ON_DESC' 					=> 'Versendet eine Benachrichtigung wenn ein Eintrag einem Benutzer zugewiesen wird.',
	'LBL_NOTIFY_FROMADDRESS' 					=> '\'Von\' Adresse:',
	'LBL_NOTIFY_FROMNAME' 						=> '\'Von\' Name:',
	'LBL_NOTIFY_ON'								=> 'Benachrichtigung ein?',
	'LBL_NOTIFY_SEND_BY_DEFAULT'				=> 'Benachrichtigung für neue Benutzer als Standard setzen?',
	'LBL_NOTIFY_TITLE'							=> 'E-Mail Benachrichtigungs Optionen',
	'LBL_OLD_ID'								=> 'Alte ID',
	'LBL_OUTBOUND_EMAIL_TITLE'					=> 'Ausgehende E-Mail Optionen',
	'LBL_RELATED_ID'							=> 'Verknüpfte ID',
	'LBL_RELATED_TYPE'							=> 'Verknüpfter Typ',
	'LBL_SAVE_OUTBOUND_RAW'						=> 'Ausgehende E-Mails als Quelltext speichern',
	'LBL_SEARCH_FORM_PROCESSED_TITLE'			=> 'Verarbeitet Suche',
	'LBL_SEARCH_FORM_TITLE'						=> 'Suche Warteschlange',
	'LBL_VIEW_PROCESSED_EMAILS'					=> 'Verarbeitete E-Mails anzeigen',
	'LBL_VIEW_QUEUED_EMAILS'					=> 'E-Mail Warteschlange anzeigen',
	'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE'	=> 'Wert von site_url in config.php',
	'TXT_REMOVE_ME_ALT'							=> 'Zum Abmelden von dieser E-Mail Liste gehen Sie zu',
	'TXT_REMOVE_ME_CLICK'						=> 'hier klicken',
	'TXT_REMOVE_ME'								=> 'Um sich von der E-Mail Liste abzumelden',
	'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER'		=> 'Benachrichtigung senden wenn E-Mail Adresse zugewiesen wurde?',

	'LBL_SECURITY_TITLE'						=> 'E-Mail Sicherheitseinstellungen',
	'LBL_SECURITY_DESC'							=> 'Wählen Sie was NICHT erlaubt sein soll bei eingehenden E-Mails oder im E-Mail Modul angezeigt werden soll.',
	'LBL_SECURITY_APPLET'						=> 'Applet Tag',
	'LBL_SECURITY_BASE'							=> 'Base Tag',
	'LBL_SECURITY_EMBED'						=> 'Embed Tag',
	'LBL_SECURITY_FORM'							=> 'Form Tag',
	'LBL_SECURITY_FRAME'						=> 'Frame Tag',
	'LBL_SECURITY_FRAMESET'						=> 'Frameset Tag',
	'LBL_SECURITY_IFRAME'						=> 'iFrame Tag',
	'LBL_SECURITY_IMPORT'						=> 'Import Tag',
	'LBL_SECURITY_LAYER'						=> 'Layer Tag',
	'LBL_SECURITY_LINK'							=> 'Link Tag',
	'LBL_SECURITY_OBJECT'						=> 'Object Tag',
	'LBL_SECURITY_OUTLOOK_DEFAULTS'				=> 'Wählen Sie Standard Minimum Sicherheitsmaßnahmen',
	'LBL_SECURITY_PRESERVE_RAW'					=> 'Original E-Mail Quellcode wird gespeichert, inklusive möglicherweise schädlichem Inhalt. Mit dieser Option wird der Quellcode nur in der Datenbank gespeichert, ungefilterter Inhalt wird nicht im SugarCRM UI angezeigt. <br /><span class="error">Es kann zu einer Gefährdung des Systems führen.</span>',
	'LBL_SECURITY_SCRIPT'						=> 'Script Tag',
	'LBL_SECURITY_STYLE'						=> 'Style Tag',
	'LBL_SECURITY_TOGGLE_ALL'					=> 'Alle Optionen umschalten',
	'LBL_SECURITY_XMP'							=> 'mp Tag',
    'LBL_YES'                                   => 'Ja',
    'LBL_NO'                                    => 'Nein',
    'LBL_PREPEND_TEST'                          => '[Test]: ',
);

?>
