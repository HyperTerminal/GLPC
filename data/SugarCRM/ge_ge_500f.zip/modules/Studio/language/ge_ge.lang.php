<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 */





$mod_strings = array (
'LBL_EDIT_LAYOUT'=>'Layout bearbeiten',
'LBL_EDIT_ROWS'=>'Zeilen bearbeiten',
'LBL_EDIT_COLUMNS'=>'Spalten bearbeiten',
'LBL_EDIT_LABELS'=>'Bezeichnungen bearbeiten',
'LBL_EDIT_FIELDS'=>'Benutzerfelder bearbeiten',
'LBL_ADD_FIELDS'=>'Benutzerdefinierte Felder hinzufügen',
'LBL_DISPLAY_HTML'=>'HTML Code zeigen',
'LBL_SELECT_FILE'=> 'Datei auswählen',
'LBL_SAVE_LAYOUT'=> 'Layout speichern',
'LBL_SELECT_A_SUBPANEL' => 'Ein Subpanel auswählen',
'LBL_SELECT_SUBPANEL' => 'Subpanel auswählen',
'LBL_MODULE_TITLE' => 'Studio',
'LBL_TOOLBOX' => 'Toolbox',
'LBL_STAGING_AREA' => 'Arbeitsbereich (Elemente hierher ziehen)',
'LBL_SUGAR_FIELDS_STAGE' => 'Sugar Felder (klicken Sie auf das Element um es zum Arbeitsbereich hinzuzufügen)',
'LBL_SUGAR_BIN_STAGE' => 'Sugar Bin (klicken Sie auf das Element um es zum Arbeitsbereich hinzuzufügen)',
'LBL_VIEW_SUGAR_FIELDS' => 'Sugar Felder anzeigen',
'LBL_VIEW_SUGAR_BIN' => 'Sugar Bin anzeigen', 
'LBL_FAILED_TO_SAVE' => 'Fehler beim Speichern',
'LBL_CONFIRM_UNSAVE' => 'Änderungen werden nicht gespeichert. Wollen Sie weitermachen?',
'LBL_PUBLISHING' => 'Veröffentlichen ...',
'LBL_PUBLISHED' => 'Veröffentlicht',
'LBL_FAILED_PUBLISHED' => 'Fehler beim Veröffentlichen',
'LBL_DROP_HERE' => '[Hierher ziehen]',

//CUSTOM FIELDS
'LBL_NAME'=>'Name',
'LBL_LABEL'=>'Bezeichnung',
'LBL_MASS_UPDATE'=>'Massenänderung',
'LBL_AUDITED'=>'Audit',
'LBL_CUSTOM_MODULE'=>'Module',
'LBL_DEFAULT_VALUE'=>'Standard Wert',
'LBL_REQUIRED'=>'Erforderlich',
'LBL_DATA_TYPE'=>'Typ:',


'LBL_HISTORY'=>'Verlauf',

//WIZARDS
//STUDIO WIZARD
'LBL_SW_WELCOME'=>'<h2>Willkommen im Studio!</h2><br> Was möchten Sie heute machen?<br><b> Bitte wählen Sie eine der folgenden Optionen.</b>',
'LBL_SW_EDIT_MODULE'=>'Modul bearbeiten',
'LBL_SW_EDIT_DROPDOWNS'=>'Auswahllisten bearbeiten',
'LBL_SW_EDIT_TABS'=>'Tabs konfigurieren',
'LBL_SW_RENAME_TABS'=>'Tabs umbenennen',
'LBL_SW_EDIT_GROUPTABS'=>'Gruppen-Tabs konfigurieren',
'LBL_SW_EDIT_PORTAL'=>'Portal bearbeiten',
'LBL_SW_EDIT_WORKFLOW'=>'Worklfow bearbeiten',
'LBL_SW_REPAIR_CUSTOMFIELDS'=>'Benutzerdefinierte Felder reparieren',
'LBL_SW_MIGRATE_CUSTOMFIELDS'=>'Benutzerdefinierte Felder migrieren',


//SELECT MODULE WIZARD
'LBL_SMW_WELCOME'=>'<h2>Willkommen im Studio!</h2><br><b>Bitte wählen Sie ein Modul.',

//SELECT MODULE ACTION
'LBL_SMA_WELCOME'=>'<h2>Modul bearbeiten</h2>Was möchten Sie mit dem Modul machen?<br><b>Bitte wählen Sie eine Aktion die Sie durchführen möchten.</b>',
'LBL_SMA_EDIT_CUSTOMFIELDS'=>'Benutzerfelder bearbeiten',
'LBL_SMA_EDIT_LAYOUT'=>'Layout bearbeiten',
'LBL_SMA_EDIT_LABELS' =>'Bezeichnungen bearbeiten',

//Manager Backups History
'LBL_MB_PREVIEW'=>'Vorschau',
'LBL_MB_RESTORE'=>'Wiederherstellen',
'LBL_MB_DELETE'=>'Löschen',
'LBL_MB_COMPARE'=>'Vergleichen',
'LBL_MB_WELCOME'=> '<h2>Verlauf</h2><br>Hier können Sie früher publizierte Versionen der Datei anzeigen, die Sie im Moment bearbeiten. Sie können sie miteinander vergleichen und frühere Versionen wiederherstellen. Falls Sie eine Datei wiederherstellen, wird diese zu Ihrer Arbeitsdatei. Sie müssen sie publizieren bevor sie für alle sichtbar ist.<br>Was möchten Sie heute machen?<br><b>Bitte wählen Sie aus den Optionen unten.</b>',

//EDIT DROP DOWNS
'LBL_ED_CREATE_DROPDOWN'=> 'Auswahlliste erstellen',
'LBL_ED_WELCOME'=>'<h2>Auswahllisten Editor</h2><br><b>Sie können entweder eine existierende Auswahlliste bearbeiten oder eine neue erstellen.',
'LBL_DROPDOWN_NAME' => 'Auswahllisten Name:',
'LBL_DROPDOWN_LANGUAGE' => 'Auswahlliste Sprache:',

//EDIT CUSTOM FIELDS
'LBL_EC_WELCOME'=>'<h2>Benutzerdefinierte Feld Editor</h2><br><b>Sie können entweder ein bestehendes Feld anzeigen und anpassen, ein neues Feld erstellen oder den Cache der eigenen Felder löschen.</b>',
'LBL_EC_VIEW_CUSTOMFIELDS'=> 'Eigene Felder anzeigen',
'LBL_EC_CREATE_CUSTOMFIELD'=>'Neues benutzerdefiniertes Feld',
'LBL_EC_CLEAR_CACHE'=>'Cache löschen',

//SELECT MODULE
'LBL_SM_WELCOME'=> '<h2>Verlauf</h2><br><b>Bitte wählen Sie die Datei, die Sie anzeigen möchten.</b>',
//END WIZARDS

//DROP DOWN EDITOR
'LBL_DD_DISPALYVALUE'=>'Anzeigewert',
'LBL_DD_DATABASEVALUE'=>'Datenbank Wert',
'LBL_DD_ALL'=>'Alle',

//BUTTONS
'LBL_BTN_SAVE'=>'Speichern',
'LBL_BTN_SAVEPUBLISH'=>'Speichern & Veröffentlichen',
'LBL_BTN_HISTORY'=>'Verlauf',
'LBL_BTN_NEXT'=>'Weiter',
'LBL_BTN_BACK'=>'Zurück',
'LBL_BTN_ADDCOLS'=>'Spalten hinzufügen',
'LBL_BTN_ADDROWS'=>'Zeilen hinzufügen',
'LBL_BTN_UNDO'=>'Rückgängig',
'LBL_BTN_REDO'=>'Wiederholen',
'LBL_BTN_ADDCUSTOMFIELD'=>'Benutzerdefiniertes Feld hinzufügen',
'LBL_BTN_TABINDEX'=>'Tab Reihenfolge bearbeiten',

//TABS
'LBL_TAB_SUBTABS'=>'Sub Tabs',
'LBL_MODULES'=>'Module',
//nsingh: begin bug#15095 fix
'LBL_MODULE_NAME' => 'Administration',
'LBL_CONFIGURE_GROUP_TABS' => 'Gruppen-Tabs konfigurieren',
 //end bug #15095 fix
'LBL_GROUP_TAB_WELCOME'=>'Das Gruppen Reiter Layout wird verwendet, wen ein Benutzer die Option in Mein Konto -> Layout Optionen auswählt.',
'LBL_RENAME_TAB_WELCOME'=>'Auf eine Reiterbeschreibung in der Tabelle klicken um den Reiter umzubennenen.',
'LBL_DELETE_MODULE'=>'Modul löschen',
'LBL_ADD_GROUP'=>'Gruppe hinzufügen',
'LBL_NEW_GROUP'=>'Neue Gruppe',
'LBL_RENAME_TABS'=>'Tabs umbenennen',

//LIST VIEW EDITOR
'LBL_DEFAULT'=>'Standard',
'LBL_ADDITIONAL'=>'Zusätzlich',
'LBL_AVAILABLE'=>'Verfügbar',
'LBL_LISTVIEW_DESCRIPTION'=>'Unten werden 3 Spalten angezeigt. Die Standard Spalte enthält die Felder, die in der Listenansicht standardmäßig angezeigt werden, die zusätzliche Spalte enthält Felder die der Benutzer wählen kann um eine eigene Ansicht zu erstellen und die verfügbaren Spalten sind Spalten für den Administrator, um entweder Spalten zu den Standard oder den zusätzlichen Spalten hinzuzufügen damit Benutzer sie verwenden können.', 
'LBL_LISTVIEW_EDIT'=>'Listenansicht Editor',

//ERRORS
'ERROR_ALREADY_EXISTS'=> 'Fehler: Feld bereits vorhanden',
'ERROR_INVALID_KEY_VALUE'=> "Fehler: Ungültiger Schlüsselwert: [ \']",

//SUGAR PORTAL
'LBL_SW_SUGARPORTAL'=>'Sugar Portal',
'LBL_SMP_WELCOME'=>'Wählen Sie aus der Liste ein Modul das Sie bearbeiten wollen',
'LBL_SP_WELCOME'=>'Willkommen beim Studio für das Sugar Portal. Sie können hier entweder Module bearbeiten oder zu einer Portalinstanz synchronisieren.<br> Bitte aus der Liste auswählen.',
'LBL_SP_SYNC'=>'Portal Sync',
'LBL_SYNCP_WELCOME'=>'Bitte die URL für Ihre Portalinstanz eintragen, dann Start betätigen.<br> Sie werden nach Username und Kennwort gefragt.<br> Bitte Daten eintragen, dann Start betätigen.',
'LBL_LISTVIEWP_DESCRIPTION'=>'Es gibt unten zwei Spalten: Standard zeigt die Felder die standardmäßig angezeigt werden und Verfügbar zeigt weitere verfügbare Felder. Einfach ein Feld zwischen die Spalten ziehen. Um eine andere Reihenfolge zu erzielen, ziehen die Spaltenwerte in die richtige Position.',
'LBL_SP_STYLESHEET'=>'Style Sheet hochladen',
'LBL_SP_UPLOADSTYLE'=>'Bitte ein Style Sheet von Ihrem Computer auswählen.<br> Wenn Sie das nächste Mal mit dem Portal synchronisieren, wird das Style Sheet übertragen.',
'LBL_SP_UPLOADED'=> 'Hochgeladen',
'ERROR_SP_UPLOADED'=>'Bitte sicherstellen, dass Sie ein css Style Sheet hochladen.',
'LBL_SP_PREVIEW'=>'Hier ist ein Entwurf, wie Ihr Style Sheet aussehen wird',

);
?>
