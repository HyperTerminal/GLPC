<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Datenformat',
  'LBL_MODULE_TITLE' => 'Datenformate: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Datenformat Suche',
  'LBL_LIST_FORM_TITLE' => 'Datenformat Liste',
  'LBL_LIST_NAME' => 'Datenformat Name',
  'LBL_LIST_QUERY_NAME' => 'Abfragename',
  'LBL_LIST_OUTPUT_DEFAULT' => 'Standard Ausgabe',
  'LBL_LIST_LIST_ORDER_Y' => 'Y Reihenfolge',
  'LBL_LIST_LIST_ORDER_X' => 'X Reihenfolge',
  'LBL_LIST_VISIBLE' => 'Sichtbar?',
  'LBL_LIST_EXPORTABLE' => 'Exportierbar?',
  'LBL_LIST_HEADER' => 'Kopfzeile zeigen?',
  'LBL_NAME' => 'Datenformat Name:',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_TYPE' => 'Typ:',
  'LBL_PARENT_DATASET' => 'Eltern Datenformat:',
  'LBL_QUERY_NAME' => 'Abfragename:',
  'LBL_OUTPUT_DEFAULT' => 'Standard Ausgabeart:',
  'LBL_LIST_ORDER_Y' => 'Slot Reihenfolge Y-Achse:',
  'LBL_LIST_ORDER_X' => 'Slot Reihenfolge X-Achse:',
  'LBL_HEADER' => 'Kopfzeile zeigen:',
  'LBL_EXPORTABLE' => 'Exportierbar (Nur CSV Datei):',
  'LBL_VISIBLE' => 'Sichtbares Datenformat:',
  'LBL_TABLE_WIDTH' => 'Tabellenbreite %:',
  'LBL_FONT_SIZE' => 'Font Größe:',
  'LBL_REPORT_NAME' => 'Berichtsname:',
  'LBL_PRESPACE_X' => 'Pre-Space Side:',
  'LBL_PRESPACE_Y' => 'Mit vorherigem Dateformat kombinieren:',
  'LBL_TABLE_WIDTH_TYPE' => 'Tabellenbreite Typ:',
  'LBL_BODY_TEXT_COLOR' => 'Textkörper Farbe:',
  'LBL_HEADER_TEXT_COLOR' => 'Kopftext Farbe:',
  'LBL_HEADER_BACK_COLOR' => 'Kopf Hintergrundfarbe:',
  'LBL_BODY_BACK_COLOR' => 'Inhalt Hintergrundfarbe:',
  'LBL_USE_PREV_HEADER' => 'Gruppe mit vorherigem Kopf:',
  'LBL_CHILD_NAME' => 'Unter/Kind Abfrage:',
  'LBL_CUSTOM_LAYOUT' => 'Benutzerdefiniertes Layout:',
  
  
  
  
  
  
  'LNK_LIST_REPORTMAKER' => 'Enterprise Berichtsliste',
  'LNK_NEW_REPORTMAKER' => 'Bericht erstellen',
  'LNK_LIST_DATASET' => 'Datenformat Liste',
  'LNK_NEW_DATASET' => 'Datenformat erstellen',
  'LNK_NEW_CUSTOMQUERY' => 'Neue benutzerdefinierte Abfrage',
  'LNK_CUSTOMQUERIES' => 'Benutzerdefinierte Abfragen',
  'LNK_NEW_QUERYBUILDER' => 'Abfrage erstellen',
  'LNK_QUERYBUILDER' => 'Abfragewerkzeug',
  'LBL_ALL_REPORTS' => 'Alle Berichte',
  
  'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag löschen wollen?',
  'ERR_DELETE_RECORD' => 'Es muss die Datensatznummer angegeben werden, um das Produkt zu löschen.',

  'LBL_LAYOUT_TYPE' => 'Layout Typ:',
  'LBL_LAYOUT_PARENT_VALUE' => 'Standardwert:',
  'LBL_LAYOUT_DISPLAY_TYPE' => 'Anzeigeart:',
  'LBL_LAYOUT_LIST_ORDER_X' => 'Reihenfolge X auflisten:',
  'LBL_LAYOUT_LIST_ORDER_Z' => 'Reihenfolge Z auflisten:',
  'LBL_MODIFY_HEAD' => 'Kopfeigenschaften ändern:',
  'LBL_MODIFY_BODY' => 'Inhaltseigenschaften ändern:',
  
  'LBL_BG_COLOR' => 'Hintergrundfarbe:',
  'LBL_WRAP' => 'Text umschließen:',
  'LBL_DISPLAY_TYPE' => 'Anzeigeart:',
  'LBL_STYLE' => 'Font Stil:',
  'LBL_DISPLAY_NAME' => 'Anzeigename:',
  'LBL_FORMAT_TYPE' => 'Format Typ:',
  'LBL_FORMAT' => 'Format:',
  'LBL_CELL_SIZE' => 'Zellenbreite:',
  'LBL_HIDE_COLUMN' => 'Spalte in Bericht verbergen:',
  
  'LBL_FINISHED_BUTTON' => 'Beendet',
  'CONFIRM_LAYOUT_DISABLE' => 'Deaktivieren des benutzerdefinierten Layouts entfernt alle bestehenden benutzerdefinierten Layouteigenschaften',
);


?>
