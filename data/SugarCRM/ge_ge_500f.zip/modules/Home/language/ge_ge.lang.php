<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Home',
  'LBL_NEW_FORM_TITLE' => 'Neuer Kontakt',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL_ADDRESS' => 'E-Mail:',
  'LBL_MY_PIPELINE_FORM_TITLE' => 'Meine Pipeline',
  'LBL_PIPELINE_FORM_TITLE' => 'Meine Pipeline nach Verkaufsphasen',
  'LBL_CAMPAIGN_ROI_FORM_TITLE' => 'Kampagne ROI',
  'LBL_MY_CLOSED_OPPORTUNITIES_GAUGE' => 'Meine abgeschlossenen Verkaufschancen',
  'LNK_NEW_CONTACT' => 'Neuer Kontakt',
  'LNK_NEW_ACCOUNT' => 'Neue Firma',
  'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',

  'LNK_NEW_QUOTE' => 'Neues Angebot',

  'LNK_NEW_LEAD' => 'Neuer Interessent',
  'LNK_NEW_CASE' => 'Neuer Fall',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Anlage',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_EMAIL' => 'E-Mail archivieren',
  'LNK_COMPOSE_EMAIL' => 'Neue E-Mail',
  'LNK_NEW_MEETING' => 'Neues Meeting',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_BUG' => 'Neuer Fehler',
  'LBL_ADD_BUSINESSCARD' => 'Eingabe Visitenkarte',
  'ERR_ONE_CHAR' => 'Bitte geben Sie wenigstens einen Buchstaben oder eine Zahl für Ihre Suche ein...',
  'LBL_OPEN_TASKS' => 'Meine offenen Aufgaben',
  'LBL_SEARCH_RESULTS' => 'Suchergebnisse',
  'LBL_SEARCH_RESULTS_IN' => 'in', 
  'LNK_NEW_SEND_EMAIL' => 'Neue E-Mail',
  'LBL_NO_RESULTS_IN_MODULE' => '-- Keine Resultate --',
  'LBL_NO_RESULTS' => '<h2>Suche ergab keinen Treffer. Bitte wiederholen.</h2><br>',
  'LBL_NO_RESULTS_TIPS' => '<h3>Such Tipps:</h3><ul><li>Stellen Sie sicher, dass Sie die richtigen Kategorien gewählt haben.</li><li>Dehnen Sie Ihre Suchkriterien aus.</li><li>Falls Sie weiterhin keine Resultate finden, versuchen Sie es mit der Erweiterten Suche in diesem Moduls..</li></ul>',
  
  'LBL_RELOAD_PAGE' => 'Bitte <a href="javascript: window.location.reload()">laden Sie das Fenster neu</a> um das Dashlet zu verwenden.',
  'LBL_ADD_DASHLETS' => 'Dashlets hinzufügen',
  'LBL_ADD_PAGE' => 'Seite hinzufügen',
  'LBL_DELETE_PAGE' => 'Seite löschen',
  'LBL_CHANGE_LAYOUT' => 'Ansicht ändern',
  'LBL_RENAME_PAGE' => 'Seite umbennenen',
  'LBL_CLOSE_DASHLETS' => 'Schließen',
  'LBL_CLOSE_SITEMAP' => 'Schließen',
  'LBL_OPTIONS' => 'Optionen', 
  // dashlet search fields
  'LBL_TODAY'=>'Heute',
  'LBL_YESTERDAY' => 'Gestern', 
  'LBL_TOMORROW'=>'Morgen',
  'LBL_LAST_WEEK'=>'Letzte Woche',
  'LBL_NEXT_WEEK'=>'Nächste Woche',
  'LBL_LAST_7_DAYS'=>'Letzten 7 Tage',
  'LBL_NEXT_7_DAYS'=>'Nächsten 7 Tage',
  'LBL_LAST_MONTH'=>'Letzten Monat',
  'LBL_NEXT_MONTH'=>'Nächster Monat',
  'LBL_LAST_QUARTER'=>'Letzes Quartal',
  'LBL_THIS_QUARTER'=>'Dieses Quartal',
  'LBL_LAST_YEAR'=>'Letztes Jahr',
  'LBL_NEXT_YEAR'=>'Nächstes Jahr',
  'LBL_THIS_MONTH' => 'Diesen Monat',
  'LBL_THIS_YEAR' => 'Dieses Jahr',
  'LBL_LAST_30_DAYS' => 'Letzten 30 Tage',
  'LBL_NEXT_30_DAYS' => 'Nächsten 30 Tage',
  'LBL_THIS_MONTH' => 'Diesen Monat',
  'LBL_THIS_YEAR' => 'Dieses Jahr',
  'LBL_LAST_30_DAYS' => 'Letzten 30 Tage',
  'LBL_NEXT_30_DAYS' => 'Nächsten 30 Tage',
  'LBL_MODULES' => 'Module',
  'LBL_CHARTS' => 'Diagramme',
  'LBL_TOOLS' => 'Werkzeuge',
  'LBL_SEARCH_RESULTS' => 'Suchergebnisse',
  
  // Dashlet Categories
  'dashlet_categories_dom' => array(
      'Module Views' => 'Modul Ansicht',
      'Portal' => 'Portal',
      'Charts' => 'Diagramme',
      'Tools' => 'Werkzeuge',
      'Miscellaneous' => 'Miscellaneous'),
  'LBL_MAX_DASHLETS_REACHED' => 'Sie haben die maximal Anzahl Dashlets, die der System Administrator gesetzt hat, erreicht. Bitte löschen Sie ein Dashlet um ein neues hinzuzufügen.',
  'LBL_ADDING_DASHLET' => 'Dashlet wird hinzugefügt ...',
  'LBL_ADDED_DASHLET' => 'Dashlet hinzugefügt',
  'LBL_REMOVE_DASHLET_CONFIRM' => 'Wollen Sie dieses Dashlet wirklich löschen?',
  'LBL_REMOVING_DASHLET' => 'Dashlet wird entfernt ...',
  'LBL_REMOVED_DASHLET' => 'Dashlet entfernt',
  'LBL_DASHLET_CONFIGURE_GENERAL' => 'Allgemein',
  'LBL_DASHLET_CONFIGURE_FILTERS' => 'Filter',
  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Nur meine Einträge',
  'LBL_DASHLET_CONFIGURE_TITLE' => 'Titel',
  'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Zeilen zeigen',
//  'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Nur meine Einträge',

  'LBL_DASHLET_DELETE' => 'Dashlet löschen',
  'LBL_DASHLET_REFRESH' => 'Dashlet neu laden',
  'LBL_DASHLET_EDIT' => 'Dashlet bearbeiten', 

  'LBL_TRAINING_TITLE' => 'Training',

  'LBL_CREATING_NEW_PAGE' => 'Neue Seite erstellen...',
  'LBL_NEW_PAGE_FEEDBACK' => 'Neue Seite erstellt. Sie können neue Inhalte über die Option \'Dashlet hinzufügen\' hinzufügen.',
  'LBL_DELETE_PAGE_CONFIRM' => 'Wollen Sie diese Seite wirklich löschen?',
  'LBL_SAVING_PAGE_TITLE' => 'Seitentitel speichern...',  
  'LBL_RETRIEVING_PAGE' => 'Seite laden...',
  
  // Default out-of-box names for tabs
  'LBL_HOME_PAGE_1_NAME' => 'Mein Sugar',
  'LBL_HOME_PAGE_2_NAME' => 'Verkaufsseite',
  'LBL_HOME_PAGE_3_NAME' => 'Marketing- & Supportseite',
  
  'LBL_CLOSE_SITEMAP' =>'Schließen',
  
  'LBL_SEARCH' => 'Suchen',
  'LBL_CLEAR' => 'Leeren', 
  
  'LBL_BASIC_CHARTS' => 'Basisdiagramme',
  'LBL_REPORT_CHARTS' => 'Bericht Diagramme',
  
  'LBL_MY_FAVORITE_REPORT_CHARTS' => 'Meine Favoritenberichte',
  'LBL_GLOBAL_REPORT_CHARTS' => 'Globale Teamberichte',
  'LBL_MY_TEAM_REPORT_CHARTS' => 'Meine Teamberichte',
  'LBL_MY_SAVED_REPORT_CHARTS' => 'Meine gespeicherten Berichte',
  
  'LBL_DASHLET_SEARCH' => 'Finde Dashlet',

//ABOUT page
  'LBL_VERSION' => 'Version',
  'LBL_BUILD' => 'Build',
  'LBL_VIEWLICENSE_COM' => '<P>Dieses Programm ist freie Software; Sie können es unter der <a href="LICENSE.txt" target="_blank" class="body"> GNU General Public License Version 3</a> wie von der „Free Software Foundation“ publiziert, ändern und/oder weitergeben – inklusive der zusätzlichen Berechtigungen in den Kopfzeilen des Quelltextes.</P>',
  'LBL_ADD_TERM_COM' => '<P>Die interaktiven Benutzeroberflächen in modifizierten Quell- und Objektcode Versionen dieses Programms müssen entsprechende rechtliche Hinweise enthalten wie dies unter Abschnitt 5 der GNU General Public License Version 3 verlangt wird. In Übereinstimmung mit Abschnitt 7(b) der GNU General Public License Version 3, müssen diese entsprechenden rechtlichen Hinweise das &quot;Powered by SugarCRM&quot; Logo enthalten. Wenn dies aus technischen Gründen nicht möglich ist, muss der rechtliche Hinweis die Worte &quot;Powered by SugarCRM&quot; enthalten.</P>',
  'LBL_SUGAR_COMMUNITY_EDITION' => 'Sugar Community Edition',
  'LBL_SUGAR_PROFESSIONAL' => "Sugar Professional",
  'LBL_SUGAR_ENTERPRISE' => "Sugar Enterprise",
  'LBL_AND' => "und",
  'LBL_ARE' => "sind",
  'LBL_TRADEMARKS' => 'Schutzmarken',
  'LBL_OF' => 'von',
  'LBL_FOUNDERS' => 'Gründer',
  'LBL_JOIN_SUGAR_COMMUNITY' => 'Treten Sie der Sugar Gemeinschaft bei',
  'LBL_SUBSCRIBE_SUGARBUZZ' => 'Abonnieren Sie den SugarBuzz Newsletter',
  'LBL_DETAILS_SUGARFORGE' => 'Arbeiten Sie zusammen mit anderen und erstellen Sie Sugar Erweiterungen',
  'LBL_DETAILS_SUGAREXCHANGE' => 'Kaufen und verkaufen Sie geprüfte Sugar Erweiterungen',
  'LBL_TRAINING' => 'Training',
  'LBL_DETAILS_TRAINING' => 'Erfahren Sie mehr über Sugar mittels des interaktiven online Inhalts',
  'LBL_FORUMS' => 'Forums',
  'LBL_DETAILS_FORUMS' => 'Diskutieren Sie mit Experten und Entwicklern im Forum',
  'LBL_WIKI' => 'Wiki',
  'LBL_DETAILS_WIKI' => 'Suchen Sie in der Wissensbasis nach Benutzer- und Entwicklerthemen',
  'LBL_DEVSITE' => 'Entwickler Seite',
  'LBL_DETAILS_DEVSITE' => 'Finden Sie Ressourcen, Lehrgänge und hilfreiche Links um schnell Fortschritte beim Entwickeln von Sugar zu machen',
  'LBL_GET_SUGARCRM_RSS' => 'Holen Sie sich SugarCRM RSS',
  'LBL_SUGARCRM_NEWS' => 'SugarCRM Neuigkeiten',
  'LBL_SUGARCRM_TRAINING_NEWS' => 'SugarCRM Training Neuigkeiten',
  'LBL_SUGARCRM_FORUMS' => 'SugarCRM Forums',
  'LBL_SUGARFORGE_NEWS' => 'SugarForge Neuigkeiten',
  'LBL_ALL_NEWS' => 'Alle Neuigkeiten',
  'LBL_LINK_CURRENT_CONTRIBUTORS' => 'Klicken Sie hier für eine aktuelle Liste der Sugar Beitragenden!',
  'LBL_SOURCE_CODE' => 'Quelltext',
  'LBL_SOURCE_SUGAR' => 'Sugar – das weltweit am besten bekannte Vetriebssteuerungssystem – kreiert von SugarCRM Inc.',
  'LBL_SOURCE_XTEMPLATE' => 'Xtemplate – Eine Template Engine für PHP, erstellt von Barnabás Debreceni.',
  'LBL_SOURCE_LOG4PHP' => 'Log4php - Eine PHP Portierung von Log4j, dem bekanntesten Java logging Framework, erstellt von Ceki Gülcü',
  'LBL_SOURCE_NUSOAP' => 'NuSOAP – Eine Sammlung von PHP Klassen die es Entwicklern erlaubt, Webservices zu erstellen und zu verwenden. Erstellt von der NuSphere Corporation und Dietrich Ayala.',
  'LBL_SOURCE_JSCALENDAR' => 'JS Calendar – Ein Kalender zum Eintragen von Daten, erstellt von Mihai Bazon.',
  'LBL_SOURCE_PHPPDF' => 'PHP PDF – Eine Bibliothek zum Erstellen von PDF Dokumenten. Erstellt von Wayne Munro.',
  'LBL_SOURCE_DOMIT' => 'DOMIT! - Ein xml Parser für PHP, basierend auf dem Document Object Model (DOM) Level 2 Spec.',
  'LBL_SOURCE_DOMITRSS' => 'DOMIT RSS – Ein RSS feed basierend auf dem DOMIT pure PHP XML Parser.',
  'LBL_SOURCE_PNGBEHAVIOR' => 'PNG Behavior – ermöglicht PNG Grafiken im Internet Explorer.',
  'LBL_SOURCE_JSONPHP' => 'JSON.php – Ein PHP script um von und zu JSON Daten zu konvertieren. Von Michal Migurski.',
  'LBL_SOURCE_JSON' => 'JSON.js – Ein JSON Parser und JSON “stringifier“ in JavaScript.',
  'LBL_SOURCE_HTTP_WEBDAV_SERVER' => 'HTTP WebDAV Server – Eine WebDAV Server Implementation in PHP.',
  'LBL_SOURCE_JS_O_LAIT' => 'JavaScript O Lait – Eine Bibliothek von wiederverwendbaren Modulen und Komponenten zur Erweiterung von JavaScript von Jan-Klaas Kollhof.',
  'LBL_SOURCE_PCLZIP' => 'PclZip – eine Bibliothek die Kompressions- und Extrahierungsfunktionen für Zip Archive liefert. Von Vincent Blavet.',
  'LBL_SOURCE_SMARTY' => 'Smarty – Eine Template Engine für PHP.',
  'LBL_SOURCE_OVERLIBMWS' => 'Overlibmws – Eine JavaScript Bibliothek für Clientseitiges Windowing.',
  'LBL_SOURCE_WICK' => 'WICK: Web Input Completion Kit - JavaScript type ahead control',
  'LBL_SOURCE_YAHOO_UI_LIB' => 'Yahoo! User Interface Library – Die UI Biblitheks Utilities erleichtern die Implementation von umfassenden Clientseitigen Features.',
  'LBL_SOURCE_PHPMAILER' => 'PHPMailer – Eine funktionsstarke E-Mail Transfer Klasse für PHP.',
  'LBL_SOURCE_CRYPT_BLOWFISH' => 'Crypt_Blowfish – Erlaubt eine schnelle zweiseitige Blowfish Verschlüsselung ohne die Mcrypt PHP Erweiterung.',
  'LBL_SOURCE_PHP_COMPAT' => 'PHP_Combat – Ergänzt fehlende Funktionalität von älteren PHP Versionen.',
  'LBL_SOURCE_HTML_SAFE' => 'HTML_Safe – Ein Parser der jeden potentiell gefährlichen Inhalt aus HTML Code entfernt.',
  'LBL_SOURCE_XML_HTMLSAX3' => 'XML_HTMLSax3 - Ein SAX Parser für HTML und andere schlecht geformte XML Dokumente.',
  'LBL_SOURCE_YAHOO_UI_LIB_EXT' => 'Yahoo! UI Extensions Library - Erweiterungen zu der Yahoo! User Interface Library von Jack Slocum.',
  'LBL_SOURCE_JSMIN' => 'JSMin – Ein Filter der Kommentare und unnötigen Leerraum aus JavaScript Dateien entfernt.',
  'LBL_SOURCE_SWFOBJECT' => 'SWFObject – JavaScript Flash Player Erkennungs- und Einbettungsscript',
  'LBL_SOURCE_TINYMCE' => 'TinyMCE – Ein WYSIWYG Editor für Webbrowser der es ermöglicht HTML Inhalte zu bearbeiten.',
  'LBL_SOURCE_EXT' => 'Ext – Ein clientseitiges JavaScript Framework um Webapplikationen zu erstellen',
);


?>
