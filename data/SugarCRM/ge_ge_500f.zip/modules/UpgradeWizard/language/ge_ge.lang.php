<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc. All Rights
 * Reserved. Contributor(s): ______________________________________..
 * *******************************************************************************/

$mod_strings = array(
	'DESC_MODULES_INSTALLED'					=> 'Die folgenden Module wurden installiert:',
	'DESC_MODULES_QUEUED'						=> 'Die folgenden Module können installiert werden:',

	'ERR_UW_CANNOT_DETERMINE_GROUP'				=> 'Gruppe kann nicht bestimmt werden',
	'ERR_UW_CANNOT_DETERMINE_USER'				=> 'Besitzer kann nicht bestimmt werden',
	'ERR_UW_CONFIG_WRITE'						=> 'Fehler beim Aktualisieren der config.php mit neuen Versionsinformationen.',
	'ERR_UW_CONFIG'								=> 'Bitte setzten Sie Schreibrechte für die config.php Datei und laden Sie diese Seite erneut.',
	'ERR_UW_DIR_NOT_WRITABLE'					=> 'Verzeichnis nicht beschreibbar',
	'ERR_UW_FILE_NOT_COPIED'					=> 'Datei nicht kopiert',
	'ERR_UW_FILE_NOT_DELETED'					=> 'Problem beim Entfernen eines Paketes',
	'ERR_UW_FILE_NOT_READABLE'					=> 'Datei kann nicht gelesen werden.',
	'ERR_UW_FILE_NOT_WRITABLE'					=> 'Datei kann nicht verschoben oder geschrieben werden',
	'ERR_UW_FLAVOR_2'							=> 'Upgrade Edition:',
	'ERR_UW_FLAVOR'								=> 'SugarCRM System Edition:',
	'ERR_UW_LOG_FILE_UNWRITABLE'				=> './upgradeWizard.log konnte nicht erstellt/geschrieben werden. Bitte überprüfen Sie die Dateiberechtigungen in Ihrem SugarCRM Verzeichnis.',
	'ERR_UW_MBSTRING_FUNC_OVERLOAD'				=> 'mbstring.func_overload Wert ist höher als 1.  Bitte in php.ini ändern und danach den Webserver neu starten.',
	'ERR_UW_MYSQL_VERSION'						=> 'SugarCRM benötigt MySQL Version 4.1.2 oder neuer. Gefunden:',
	'ERR_UW_NO_FILE_UPLOADED'					=> 'Bitte geben Sie eine Datei an und versuchen Sie es erneut!',
	'ERR_UW_NO_FILES'							=> 'Ein Fehler ist aufgetreten, keine Dateien für die Überprüfung gefunden.',
	'ERR_UW_NO_MANIFEST'						=> 'In der zip Datei fehlt die manifest.php Datei. Abbruch.',
	'ERR_UW_NO_VIEW'							=> 'Ungültige Ansicht angegeben',
	'ERR_UW_NO_VIEW2'							=> 'Ansicht nicht definiert. Bitte gehen Sie auf die Administrations Home Ansicht um auf diese Seite zu gelangen.',
	'ERR_UW_NOT_VALID_UPLOAD'					=> 'Kein gültiges Upload.',
	'ERR_UW_NO_CREATE_TMP_DIR'					=> 'Das temporäre Verzeichnis konnte nicht erstellt werden. Überprüfen Sie die Berechtigungen.',
	'ERR_UW_ONLY_PATCHES'						=> 'Auf dieser Seite können Sie nur Patches hochladen.',
	'ERR_UW_PREFLIGHT_ERRORS'					=> 'Fehler gefunden während den letzten Kontrollen',
	'ERR_UW_UPLOAD_ERR'							=> 'Beim Upload der Datei ist ein Fehler aufgetreten, bitte versuchen Sie es erneut!<br>\n',
	'ERR_UW_VERSION'							=> 'SugarCRM System Version: ',
	'ERR_UW_WRONG_TYPE'							=> 'Diese Seite ist nicht zum Anzeigen',
	'ERR_UW_PHP_FILE_ERRORS'					=> array(
													1 => 'Die hochgeladene Datei ist größer als upload_max_filesize in php.ini.',
													2 => 'Die hochgeladene Datei ist größer als die MAX_FILE_SIZE Direktive, die im HTML Fomular angegeben wurde.',
													3 => 'Die hochgeladene Datei wurde nur teilweise hochgeladen.',
													4 => 'Keine Datei hochgeladen.',
													5 => 'Unbekannter Fehler.',
													6 => 'Ein temporäres Verzeichnis fehlt.',
													7 => 'Datei konnte nicht geschrieben werden.',
													8 => 'Datei-Upload gestoppt wegen Datei Erweiterung.',
												),
	'LBL_BUTTON_BACK'							=> 'Zurück',
	'LBL_BUTTON_CANCEL'							=> 'Abbrechen',
	'LBL_BUTTON_DELETE'							=> 'Paket löschen',
	'LBL_BUTTON_DONE'							=> 'Fertig',
	'LBL_BUTTON_INSTALL'						=> 'Letzte Kontrollen',
	'LBL_BUTTON_NEXT'							=> 'Weiter',
	'LBL_BUTTON_RECHECK'						=> 'Nachprüfung',

	'LBL_UPLOAD_UPGRADE'						=> 'Upgrade hochladen:',

	'LBL_UW_BACKUP_FILES_EXIST_TITLE'			=> 'Datei Backup',
	'LBL_UW_BACKUP_FILES_EXIST'					=> 'Gesicherte Dateien von diesem Upgrade finden Sie in',
	'LBL_UW_BACKUP'								=> 'Datei BACKUP',
	'LBL_UW_CANCEL_DESC'						=> 'Der Upgrade Wizard wurde abgebrochen. Alle temporären Dateien und die hochgeladene zip Datei wurden gelöscht.<br><br>Klicken Sie auf \'Fertig\' um den Upgrade Wizard wieder zu starten.',
	'LBL_UW_CHARSET_SCHEMA_CHANGE'				=> 'Zeichensatz Schema Änderungen',
	'LBL_UW_CHECK_ALL'							=> 'Alle markieren',
	'LBL_UW_CHECKLIST'							=> 'Upgrade Schritte',
	'LBL_UW_COMMIT_ADD_TASK_DESC_1'				=> "Sicherungen der überschriebenen Dateien sind in folgendem Verzeichnis: \n",
	'LBL_UW_COMMIT_ADD_TASK_DESC_2'				=> "Führen Sie die folgenden Dateien manuell zusammen:\n",
	'LBL_UW_COMMIT_ADD_TASK_NAME'				=> 'Upgrade Prozess: Dateien manuell zusammenführen',
	'LBL_UW_COMMIT_ADD_TASK_OVERVIEW'			=> 'Bitte verwenden Sie die Vergleichsmethode die Sie am besten kennen, um diese Dateien zusammenzuführen. Bis dieser Schritt fertig ist, ist Ihre SugarCRM Installation in einem unsicheren Zustand und das Upgrade ist nicht beendet.',
	'LBL_UW_COMPLETE'							=> 'Fertig',
	'LBL_UW_CONTINUE_CONFIRMATION'              => 'Diese Sugar Version enthält eine neue Lizenzvereinbarung.  Wollen Sie weitermachen?',
	'LBL_UW_COMPLIANCE_ALL_OK'					=> 'Alle erforderlichen System Einstellungen erfüllt',
	'LBL_UW_COMPLIANCE_CALLTIME'				=> 'PHP Einstellungen: Call Time Pass By Reference',
	'LBL_UW_COMPLIANCE_CURL'					=> 'cURL Modul',
	'LBL_UW_COMPLIANCE_IMAP'					=> 'IMAP Modul',
	'LBL_UW_COMPLIANCE_MBSTRING'				=> 'MBStrings Modul',
	'LBL_UW_COMPLIANCE_MBSTRING_FUNC_OVERLOAD'	=> 'MBStrings mbstring.func_overload Parameter',
	'LBL_UW_COMPLIANCE_MEMORY'					=> 'PHP Einstellungen: Memory Limit',
	'LBL_UW_COMPLIANCE_MSSQL_MAGIC_QUOTES'		=> 'MS SQL Server & PHP Magic Quotes GPC',
	'LBL_UW_COMPLIANCE_MYSQL'					=> 'Minimale MySQL Version',
	'LBL_UW_COMPLIANCE_PHP_INI'					=> 'Speicherort der php.ini',
	'LBL_UW_COMPLIANCE_PHP_VERSION'				=> 'Minimale PHP Version',
	'LBL_UW_COMPLIANCE_SAFEMODE'				=> 'PHP Einstellungen: Safe Mode',
	'LBL_UW_COMPLIANCE_TITLE'					=> 'Server Einstellungen Check',
	'LBL_UW_COMPLIANCE_TITLE2'					=> 'Gefundene Einstellungen',
	'LBL_UW_COMPLIANCE_XML'						=> 'XML Parsing',

	'LBL_UW_COPIED_FILES_TITLE'					=> 'Dateien erfolgreich kopiert',
	'LBL_UW_CUSTOM_TABLE_SCHEMA_CHANGE'			=> 'Eigene Tabellen Schema Änderungen',

	'LBL_UW_DB_CHOICE1'							=> 'Upgrade Wizard Runs SQL',
	'LBL_UW_DB_CHOICE2'							=> 'Manuelle SQL Abfragen',
	'LBL_UW_DB_INSERT_FAILED'					=> 'INSERT fehlgeschlagen - verglichene Resultate unterschiedlich',
	'LBL_UW_DB_ISSUES_PERMS'					=> 'Datenbank Berechtigungen',
	'LBL_UW_DB_ISSUES'							=> 'Datenbank Issues',
	'LBL_UW_DB_METHOD'							=> 'Datenbank Aktualisierungsmethode',
	'LBL_UW_DB_NO_ADD_COLUMN'					=> 'ALTER TABLE [table] ADD COLUMN [column]',
	'LBL_UW_DB_NO_CHANGE_COLUMN'				=> 'ALTER TABLE [table] CHANGE COLUMN [column]',
	'LBL_UW_DB_NO_CREATE'						=> 'CREATE TABLE [tabelle]',
	'LBL_UW_DB_NO_DELETE'						=> 'DELETE FROM [tabelle]',
	'LBL_UW_DB_NO_DROP_COLUMN'					=> 'ALTER TABLE [table] DROP COLUMN [column]',
	'LBL_UW_DB_NO_DROP_TABLE'					=> 'DROP TABLE [tabelle]',
	'LBL_UW_DB_NO_ERRORS'						=> 'Alle Berechtigungen verfügbar',
	'LBL_UW_DB_NO_INSERT'						=> 'INSERT INTO [tabelle]',
	'LBL_UW_DB_NO_SELECT'						=> 'SELECT [x] FROM [tabelle]',
	'LBL_UW_DB_NO_UPDATE'						=> 'UPDATE [tabelle]',
	'LBL_UW_DB_PERMS'							=> 'Notwendige Berechtigungen',

	'LBL_UW_DESC_MODULES_INSTALLED'				=> 'Die folgenden Upgrades wurden installiert:',
	'LBL_UW_END_DESC'							=> 'Gratulation, Ihr System ist jetzt aktualisiert.',
	'LBL_UW_END_DESC2'							=> 'Falls Sie einige Schritte manuell durchzuführen - wie Dateizusammenführungen oder SQL Abfragen - tun Sie dies jetzt. Ihr System ist in einem instabilen Zustand bis Sie diese Schritte durchgeführt haben.',
	'LBL_UW_END_LOGOUT'							=> 'Bitte melden Sie sich von Ihrem Konto ab, falls Sie planen weiter als dieser Patch/Upgarde Level zu aktualisieren.',
	'LBL_UW_END_LOGOUT2'						=> 'Abmelden',
	'LBL_UW_REPAIR_INDEX'						=> 'Für eine verbesserte Leistung der Datenbank, führen Sie bitte das <a href="index.php?module=Administration&action=RepairIndex" target="_blank">Repair Index</a> Script aus.',

	'LBL_UW_FILE_DELETED'						=> "wurde entfernt.<br>",
	'LBL_UW_FILE_GROUP'							=> 'Gruppe',
	'LBL_UW_FILE_ISSUES_PERMS'					=> 'Datei Berechtigungen',
	'LBL_UW_FILE_ISSUES'						=> 'Datei Issues',
	'LBL_UW_FILE_NEEDS_DIFF'					=> 'Datei benötigt manuellen Vergleich',
	'LBL_UW_FILE_NO_ERRORS'						=> '<b>Alle Dateien schreibbar</b>',
	'LBL_UW_FILE_OWNER'							=> 'Eigentümer',
	'LBL_UW_FILE_PERMS'							=> 'Berechtigungen',
	'LBL_UW_FILE_UPLOADED'						=> 'wurde hochgeladen',
	'LBL_UW_FILE'								=> 'Dateiname',
	'LBL_UW_FILES_QUEUED'						=> 'Die folgenden Upgrades können lokal installiert werden:',
	'LBL_UW_FILES_REMOVED'						=> "Die folgenden Dateien werden aus dem System entfernt:<br>\n",

	'LBL_UW_FROZEN'								=> 'Erforderliche Schritte müssen beendet werden bevor es weitergehen kann.',
	'LBL_UW_HIDE_DETAILS'						=> 'Details verstecken',
	'LBL_UW_IN_PROGRESS'						=> 'In Bearbeitung',
	'LBL_UW_INCLUDING'							=> 'Einschließend',
	'LBL_UW_INCOMPLETE'							=> 'Unvollständig',
	'LBL_UW_INSTALL'							=> 'Datei INSTALL',
	'LBL_UW_MANUAL_MERGE'						=> 'Datei zusammenführen',
	'LBL_UW_MODULE_READY_UNINSTALL'				=> "Modul ist bereit für die Deinstallation. Klicken Sie auf \'Ausführen\' um mit dem Prozess fortzufahren.<br>\n",
	'LBL_UW_MODULE_READY'						=> "Modul ist bereit für die Installation. Klicken Sie auf \'Ausführen\' um mit der Installation fortzufahren.",
	'LBL_UW_NO_INSTALLED_UPGRADES'				=> 'Keine aufgezeichneten Upgrades gefunden.',
	'LBL_UW_NONE'								=> 'Kein(e)',
	'LBL_UW_NOT_AVAILABLE'						=> 'Nicht verfügbar',
	'LBL_UW_OVERWRITE_DESC'						=> "Alle geänderten Dateien werden überschrieben - inklusive allfälliger Anpassungen am Code und den Vorlagen, die Sie gemacht haben. Möchten Sie wirklich fortfahren?",
	'LBL_UW_OVERWRITE_FILES_CHOICE1'			=> 'Alle Datein überschreiben',
	'LBL_UW_OVERWRITE_FILES_CHOICE2'			=> 'Manuelles Zusammenführen - Alle behalten',
	'LBL_UW_OVERWRITE_FILES'					=> 'Zusammenführungsmethode',
	'LBL_UW_PATCH_READY'						=> 'Der Patch ist bereit. Klicken Sie auf \'Ausführen\' um den Upgrade Prozess abzuschließen.',
	'LBL_UW_PATCH_READY2'						=> '<h2>Notiz: Eigene Layouts gefunden</h2><br /> Für die folgenden Dateien wurden via Studio neue Felder oder geänderte Layouts erstellt. Der Patch den Sie installieren möchten, enthält ebenfalls Änderungen an diesen Dateien. <u>Jede Datei</u> können Sie:<br><ul><li>[<b>Standard</b>]  Ihre Version beibehalten indem Sie die Checkbox leer lassen. Die Änderungen des Patches werden ignoriert.</li>or<li>Die aktualisierten Dateien akzeptieren indem Sie die Checkboxen aktivieren. Ihre Layouts müssen mit Hilfe des Studios erneut angewendet werden.</li></ul>',

	'LBL_UW_PREFLIGHT_ADD_TASK'					=> 'Aufgabe für manuelles Zusammenführen erstellen?',
	'LBL_UW_PREFLIGHT_COMPLETE'					=> 'Letzte Kontrollen',
	'LBL_UW_PREFLIGHT_DIFF'						=> 'Differenziert',
	'LBL_UW_PREFLIGHT_EMAIL_REMINDER'			=> 'Sich selbst eine Erinnerung für das manuelle Zusammenführen e-mailen?',
	'LBL_UW_PREFLIGHT_FILES_DESC'				=> 'Die folgenden Dateien wurden geändert. Deaktivieren Sie die Elemente, die manuell zusammengeführt werden müssen. <i>Gefundene Änderungen an Layouts werden automatisch deaktiviert; wählen Sie die aus, die überschrieben werden sollen.',
	'LBL_UW_PREFLIGHT_NO_DIFFS'					=> 'Keine manuelle Dateizusammenführung erforderlich.',
	'LBL_UW_PREFLIGHT_NOT_NEEDED'				=> 'Nicht benötigt.',
	'LBL_UW_PREFLIGHT_PRESERVE_FILES'			=> 'Auto-erhaltende Dateien:',
	'LBL_UW_PREFLIGHT_TESTS_PASSED'				=> 'Alle Kontrollen durchgeführt. Klicken Sie auf \'Weiter\'.',
	'LBL_UW_PREFLIGHT_TOGGLE_ALL'				=> 'Alle Dateien de-/aktivieren',

	'LBL_UW_REBUILD_TITLE'						=> 'Rebuild Resultat',
	'LBL_UW_SCHEMA_CHANGE'						=> 'Schema Änderungen',

	'LBL_UW_SHOW_COMPLIANCE'					=> 'Gefundene Einstellungen anzeigen',
	'LBL_UW_SHOW_DB_PERMS'						=> 'Fehlende Datenbank Berechtigungen anzeigen',
	'LBL_UW_SHOW_DETAILS'						=> 'Details zeigen',
	'LBL_UW_SHOW_DIFFS'							=> 'Dateien anzeigen, die manuell zusammengeführt werden müssen',
	'LBL_UW_SHOW_NW_FILES'						=> 'Dateien mit falschen Berechtigungen anzeigen',
	'LBL_UW_SHOW_SCHEMA'						=> 'Schema Änderungsskript anzeigen',
	'LBL_UW_SHOW_SQL_ERRORS'					=> 'Falsche Abfragen anzeigen',
	'LBL_UW_SHOW'								=> 'Zeigen',

	'LBL_UW_SKIPPED_FILES_TITLE'				=> 'Übersprungene Dateien',
	'LBL_UW_SKIPPING_FILE_OVERWRITE'			=> 'Datei überschreiben übersprungen - Manuelle Zusammenführung gewählt',
	'LBL_UW_SQL_RUN'							=> 'Überprüfen Sie wann SQL manuell gelaufen ist',
	'LBL_UW_START_DESC'							=> 'Willkommen beim SugarCRM Upgrade Wizard. Dieser Wizard wurde entwickelt, um Administratoren beim Upgrade der SugarCRM Instanz zu helfen. Bitte folgen Sie den Instruktionen.',
	'LBL_UW_START_DESC2'						=> 'Wir empfehlen, die Aktualisierung auf einer geklonten Instanz des produktiven Servers durchzuführen. Bitte sichern Sie die Datenbank und die Systemdateien (alle Dateien im SugarCRM Verzeichnis), bevor Sie die Aktualisierung durchführen.',
	'LBL_UW_START_UPGRADED_UW_DESC'				=> 'Der neue Upgrade Wizard wird nun den Upgrade Prozess fortsetzen. Bitte fahren Sie mit dem Upgrade fort.',
	'LBL_UW_START_UPGRADED_UW_TITLE'			=> 'Willkommen beim neuen Upgrade Wizard',

	'LBL_UW_SYSTEM_CHECK_CHECKING'				=> 'Überprüfung läuft, bitte warten. Dies kann bis zu 30 Sekunden dauern.',
	'LBL_UW_SYSTEM_CHECK_FILE_CHECK_START'		=> 'Alle passenden Dateien für den Check finden',
	'LBL_UW_SYSTEM_CHECK_FILES'					=> 'Dateien',
	'LBL_UW_SYSTEM_CHECK_FOUND'					=> 'Gefunden',

	'LBL_UW_TITLE_CANCEL'						=> 'Abbrechen',
	'LBL_UW_TITLE_COMMIT'						=> 'Upgrade ausführen',
	'LBL_UW_TITLE_END'							=> 'Nachkontrolle',
	'LBL_UW_TITLE_PREFLIGHT'					=> 'Letzte Kontrollen',
	'LBL_UW_TITLE_START'						=> 'Start',
	'LBL_UW_TITLE_SYSTEM_CHECK'					=> 'System Checks',
	'LBL_UW_TITLE_UPLOAD'						=> 'Upgrade hochladen',
	'LBL_UW_TITLE'								=> 'Upgrade Wizard',
	'LBL_UW_UNINSTALL'							=> 'Deinstallieren',
	//500 upgrade labels
	'LBL_UW_ACCEPT_THE_LICENSE' 				=> 'Lizenz annehmen',
	'LBL_UW_CONVERT_THE_LICENSE' 				=> 'Lizenz umwandeln',
	'LBL_UW_CUSTOMIZED_OR_UPGRADED_MODULES'     => 'Upgrade/Eigene Module',
	'LBL_UW_FOLLOWING_MODULES_CUSTOMIZED'       => 'Die folgende Module sind selbst entwickelt und werden beibehalten',
	'LBL_UW_FOLLOWING_MODULES_UPGRADED'         => 'Die folgende Module sind mit Studio angepasst worden und wurden aktualisiert',



	'LBL_START_UPGRADE_IN_PROGRESS'             => 'Startvorgang in Arbeit',
	'LBL_SYSTEM_CHECKS_IN_PROGRESS'             => 'System wird überprüft',
	'LBL_LICENSE_CHECK_IN_PROGRESS'             => 'Lizenzen werden überprüft',
	'LBL_PREFLIGHT_CHECK_IN_PROGRESS'           => 'Preflight Check im Gang',
	'LBL_COMMIT_UPGRADE_IN_PROGRESS'            => 'Commit Upgrade im Gang',
	'LBL_UPGRADE_SUMMARY_IN_PROGRESS'			=> 'Upgrade Zusammenfassung wird erstellt',
	'LBL_UPGRADE_IN_PROGRESS'                   => 'im Gang',
	'LBL_UPGRADE_TIME_ELAPSED'                  => 'Zeit abgelaufen',
	'LBL_UPGRADE_CANCEL_IN_PROGRESS'			=> 'Aktualisierung Cancel und Cleanup im Gange',
    'LBL_UPGRADE_TAKES_TIME_HAVE_PATIENCE'      => 'Das Upgrade kann einige Zeit dauern',
    'LBL_UPLOADE_UPGRADE_IN_PROGRESS'           => 'Upload Checks im Gang',
    'LBL_UPLOADING_UPGRADE_PACKAGE'      		=> 'Upgrade Paket wird hochgeladen...',
    'LBL_UW_DORP_THE_OLD_SCHMEA' 				=> 'Wollen Sie dass Sugar die alten 451 Schemata entfernt?',
	'LBL_UW_DROP_SCHEMA_UPGRADE_WIZARD'			=> 'Upgrade Wizard entfernt das alte 451 Schema',
	'LBL_UW_DROP_SCHEMA_MANUAL'					=> 'Drop Schema Post Upgrade',
	'LBL_UW_DROP_SCHEMA_METHOD'					=> 'Altes Schema Lösch Methode',
	'LBL_UW_SHOW_OLD_SCHEMA_TO_DROP'			=> 'Zeige altes Schema das entfernt werden kann',
	'LBL_UW_SKIPPED_QUERIES_ALREADY_EXIST'      => 'Übersprungene Abfragen',
	'ERROR_FLAVOR_VERSION_INCOMPATIBLE'         => 'Version und Edition sind nicht kompatibel',
	'LBL_SUGAR_VERSION'                         => 'SugarCRM System Version:',
	'LBL_UPGRADE_VERSION' 						=> 'Version aktualisieren:',
	'MODULE_NOT_LOADED'                         => 'Modul ist nicht geladen',
	'MODULE_PATCH_CAN_NOT_BE_LOADED'			=> 'kann nicht geladen werden',

 );
?>
