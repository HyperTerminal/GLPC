<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	'ERR_ADD_RECORD' => 'Sie müssen eine Datensatznummer angeben, um einen Benutzer zu diesem Team hinzuzufügen.',
	'ERR_DELETE_RECORD' => 'Sie müssen eine Datensatznummer angeben um dieses Team zu löschen.',

	'LBL_DESCRIPTION' => 'Beschreibung:',
	'LBL_GLOBAL_TEAM_DESC' => 'Global sichtbar',
	'LBL_INVITEE' => 'Teammitglieder',
	'LBL_LIST_DEPARTMENT' => 'Abteilung',
	'LBL_LIST_DESCRIPTION' => 'Beschreibung',
	'LBL_LIST_FORM_TITLE' => 'Team Liste',
	'LBL_LIST_NAME' => 'Name',
	'LBL_LIST_REPORTS_TO' => 'Berichtet an',
	'LBL_LIST_TITLE' => 'Titel',
	'LBL_MODULE_NAME' => 'Teams',
	'LBL_MODULE_TITLE' => 'Teams: Home',
	'LBL_NAME' => 'Team Name:',
	'LBL_NEW_FORM_TITLE' => 'Neues Team',
	'LBL_PRIVATE' => 'Privat',
	'LBL_PRIVATE_TEAM_FOR' => 'Privates Team für:',
	'LBL_SEARCH_FORM_TITLE' => 'Team Suche',
	'LBL_TEAM_MEMBERS' => 'Teammitglieder',
	'LBL_TEAM' => 'Teams',
	'LBL_USERS_SUBPANEL_TITLE' => 'Benutzer',
	'LBL_USERS'=>'Benutzer',

	'LNK_LIST_TEAM' => 'Teams',
	'LNK_LIST_TEAMNOTICE' => 'Team Notizen',
	'LNK_NEW_TEAM' => 'Neues Team',

	'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => 'Sind Sie sicher, dass Sie die Mitgliedschaft dieses Benutzers beenden wollen?',
);


?>
