<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	// DON'T CONVERT THESE THEY ARE MAPPINGS
	'db_name' => 'LBL_LIST_ACCOUNT_NAME',
	'db_website' => 'LBL_LIST_WEBSITE',
	'db_billing_address_city' => 'LBL_LIST_CITY',
	// END DON'T CONVERT

	'LBL_CONTRACTS'=>'Verträge',
	'LBL_CONTRACTS_SUBPANEL_TITLE'=>'Verträge',
	'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Produkte',
	'LBL_QUOTES_SUBPANEL_TITLE' => 'Angebote',
	'LNK_ACCOUNT_REPORTS' => 'Firmenberichte',

	// Dashlet Categories
	'LBL_CHARTS'    => 'Diagramme',
	'LBL_DEFAULT' => 'Ansichten',
	'LBL_MISC'    => 'Verschiedenes',
	'LBL_UTILS'    => 'Werkzeuge',
	// END Dashlet Categories

	'ACCOUNT_REMOVE_PROJECT_CONFIRM' => 'Möchten Sie diese Firma wirklich aus dem Projekt entfernen?',
	'ERR_DELETE_RECORD' => 'Es muss die Datensatznummer angegeben werden, um diesen Datensatz löschen zu können.',
	'LBL_ACCOUNT_INFORMATION' => 'Firmeninformation',
	'LBL_ACCOUNT_NAME' => 'Firmenname:',
	'LBL_ACCOUNT' => 'Firma:',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivitäten',
	'LBL_ADDRESS_INFORMATION' => 'Adressinformation',
	'LBL_ANNUAL_REVENUE' => 'Jahresumsatz:',
	'LBL_ANY_ADDRESS' => 'Irgendeine Adresse:',
	'LBL_ANY_EMAIL' => 'Irgendeine E-Mail:',
	'LBL_ANY_PHONE' => 'Irgendeine Telefonnummer:',
	'LBL_ASSIGNED_TO_NAME' => 'Zugewiesen an:',
	'LBL_ASSIGNED_TO_ID' => 'Zugewiesen an:',
	'LBL_BILLING_ADDRESS_CITY' => 'Rechnungsadresse Stadt:',
	'LBL_BILLING_ADDRESS_COUNTRY' => 'Rechnungsadresse Land:',
	'LBL_BILLING_ADDRESS_POSTALCODE' => 'Rechnungsadresse PLZ:',
	'LBL_BILLING_ADDRESS_STATE' => 'Rechnungsadresse Bundesland:',
	'LBL_BILLING_ADDRESS_STREET_2' =>'Rechnungsadresse Strasse 2',
	'LBL_BILLING_ADDRESS_STREET_3' =>'Rechnungsadresse Strasse 3',
	'LBL_BILLING_ADDRESS_STREET_4' =>'Rechnungsadresse Strasse 4',
	'LBL_BILLING_ADDRESS_STREET' => 'Rechnungsadresse Strasse:',
	'LBL_BILLING_ADDRESS' => 'Rechnungsadresse::',
	'LBL_BUG_FORM_TITLE' => 'Firmen',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Fehler',
	'LBL_CAMPAIGN_ID' => 'Kampagne ID',
	'LBL_CASES_SUBPANEL_TITLE' => 'Fälle',
	'LBL_CITY' => 'Stadt:',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte',
	'LBL_COUNTRY' => 'Land:',
	'LBL_DATE_ENTERED' => 'Erstellt:',
	'LBL_DATE_MODIFIED' => 'Geändert am:',
	'LBL_MODIFIED_ID'=>'Geändert von ID',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Firmen',
	'LBL_DESCRIPTION_INFORMATION' => 'Beschreibungsinformation',
	'LBL_DESCRIPTION' => 'Beschreibung:',
	'LBL_DUPLICATE' => 'Firma möglicherweise doppelt',
	'LBL_EMAIL' => 'E-Mail:',
	//'LBL_EMAIL_ADDRESSES' => 'E-Mail Adressen',
	'LBL_EMPLOYEES' => 'Mitarbeiter:',
	'LBL_FAX' => 'Fax:',
	'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf',
	'LBL_HOMEPAGE_TITLE' => 'Meine Firmen',
	'LBL_INDUSTRY' => 'Branche:',
	'LBL_INVITEE' => 'Kontakte',
	'LBL_LEADS_SUBPANEL_TITLE' => 'Interessenten',
	'LBL_LIST_ACCOUNT_NAME' => 'Firmenname',
	'LBL_LIST_CITY' => 'Stadt',
	'LBL_LIST_CONTACT_NAME' => 'Kontakt:',
	'LBL_LIST_EMAIL_ADDRESS' => 'E-Mail Adresse',
	'LBL_LIST_FORM_TITLE' => 'Firmen Liste',
	'LBL_LIST_PHONE' => 'Telefon',
	'LBL_LIST_STATE' => 'Bundesland',
	'LBL_LIST_WEBSITE' => 'Webseite',
	'LBL_MEMBER_OF' => 'Mitglied von:',
	'LBL_MEMBER_ORG_FORM_TITLE' => 'Mitgliedsorganisationen',
	'LBL_MEMBER_ORG_SUBPANEL_TITLE'=>'Mitgliedsorganisationen',
	'LBL_MODULE_NAME' => 'Firmen',
	'LBL_MODULE_TITLE' => 'Firmen: Home',
	'LBL_MODULE_ID'=> 'Firmen',
	'LBL_NAME'=>'Name:',
	'LBL_NEW_FORM_TITLE' => 'Neue Firma',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Verkaufschancen',
	'LBL_OTHER_EMAIL_ADDRESS' => 'Weitere E-Mail:',
	'LBL_OTHER_PHONE' => 'Weiteres Telefon:',
	'LBL_OWNERSHIP' => 'Eigentümer:',
	'LBL_PARENT_ACCOUNT_ID' => 'ID Mutterfirma',
	'LBL_PHONE_ALT' => 'Weiteres Telefon:',
	'LBL_PHONE_FAX' => 'Telefon/Fax:',
	'LBL_PHONE_OFFICE' => 'Telefon Büro:',
	'LBL_PHONE' => 'Telefon:',
	'LBL_POSTAL_CODE' => 'PLZ:',
	'LBL_PRODUCTS_TITLE'=>'Produkte',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekte',
	'LBL_PUSH_BILLING' => 'Rechnungsinfos',
	'LBL_PUSH_CONTACTS_BUTTON_LABEL' => 'Kopie an Kontakte',
	'LBL_PUSH_CONTACTS_BUTTON_TITLE' => 'Kopie...',
	'LBL_PUSH_SHIPPING' => 'Versandinfos',
	'LBL_RATING' => 'Einstufung:',
	'LBL_SAVE_ACCOUNT' => 'Firma speichern',
	'LBL_SEARCH_FORM_TITLE' => 'Firmen Suche',
	'LBL_SHIPPING_ADDRESS_CITY' => 'Lieferadresse Stadt:',
	'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Lieferadresse Land:',
	'LBL_SHIPPING_ADDRESS_POSTALCODE' => 'Lieferadresse PLZ:',
	'LBL_SHIPPING_ADDRESS_STATE' => 'Lieferadresse Bundesland:',
	'LBL_SHIPPING_ADDRESS_STREET_2' => 'Lieferadresse Strasse 2:',
	'LBL_SHIPPING_ADDRESS_STREET_3' => 'Lieferadresse Strasse 3:',
	'LBL_SHIPPING_ADDRESS_STREET_4' => 'Lieferadresse Strasse 4:',
	'LBL_SHIPPING_ADDRESS_STREET' => 'Lieferadresse Strasse:',
	'LBL_SHIPPING_ADDRESS' => 'Lieferadresse:',
	'LBL_SIC_CODE' => 'SIC Code:',
	'LBL_STATE' => 'Bundesland:',
	'LBL_TEAMS_LINK'=>'Teams',
	'LBL_TICKER_SYMBOL' => 'Wertpapier Kennnummer (WKN):',
	'LBL_TYPE' => 'Typ:',
	'LBL_USERS_ASSIGNED_LINK'=>'Zugew. Benutzer',
	'LBL_USERS_CREATED_LINK'=>'Erstellt von Benutzern',
	'LBL_USERS_MODIFIED_LINK'=>'Bearbeitet von Benutzern',
	'LBL_VIEW_FORM_TITLE' => 'Firmen Listenansicht',
	'LBL_WEBSITE' => 'Webseite:',
	'LBL_CREATED_ID'=>'Erstellt von ID:',
	'LBL_CAMPAIGNS' =>'Kampagnen',

	'LNK_ACCOUNT_LIST' => 'Firmen',
	'LNK_NEW_ACCOUNT' => 'Neue Firma',

	'MSG_DUPLICATE' => 'Diese Firma könnte bereits existieren (Duplikat!). Sie können entweder eine Firma aus der untenstehenden Liste auswählen oder auf Speichern klicken und die neue Firma mit den zuvor eingegebenen Daten erstellen.',
	'MSG_SHOW_DUPLICATES' => 'Diese Firma könnte bereits existieren (Duplikat!). Sie können entweder eine Firma aus der untenstehenden Liste auswählen oder auf Speichern klicken und die neue Firma mit den zuvor eingegebenen Daten erstellen.',
	'NTC_COPY_BILLING_ADDRESS' => 'Rechnungsadresse auf Lieferadresse kopieren',
	'NTC_COPY_BILLING_ADDRESS2' => 'Auf Lieferadresse kopieren',
	'NTC_COPY_SHIPPING_ADDRESS' => 'Lieferadresse auf Rechnungsadresse kopieren',
	'NTC_COPY_SHIPPING_ADDRESS2' => 'Auf Rechnungsadresse kopieren',
	'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag löschen wollen?',
	'NTC_REMOVE_ACCOUNT_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag entfernen wollen?',
	'NTC_REMOVE_MEMBER_ORG_CONFIRMATION' => 'Sind Sie sicher dass Sie diesen Eintrag als Mitgliedsorganisation entfernen wollen?',
);
?>
