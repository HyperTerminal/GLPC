<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  TODO: To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array(

	'LBL_ASSIGN_TEAM'		=> 'Einem Team zuordnen',


	'ERR_BAD_LOGIN_PASSWORD'=> 'Login oder Passwort stimmen nicht',
	'ERR_BODY_TOO_LONG'		=> '\rTextkörper zu lang um die GANZE E-Mail zu speichern. Gekürzt.',
	'ERR_INI_ZLIB'			=> 'Konnte Zlib Komprimierung nicht temporär ausschalten. "Test Settings" könnte nicht funktionieren.',
	'ERR_MAILBOX_FAIL'		=> 'Konnte keine Postfächer finden.',
	'ERR_NO_IMAP'			=> 'Keine IMAP Libraries gefunden. Bitte korrigieren bevor Sie mit eingehenden E-Mails weiterarbeiten können.',
	'ERR_NO_OPTS_SAVED'		=> 'Für Ihren eingehenden E-Mail Mailbox wurden keine Optimums gespeichert . Überprüfen Sie die Einstellungen.',
	'ERR_TEST_MAILBOX'		=> 'Bitte prüfen Sie Ihre Einstellungen und versuchen Sie es noch einmal.',

	'LBL_APPLY_OPTIMUMS'	=> 'Optimums anwenden',
	'LBL_ASSIGN_TO_USER'	=> 'Mit Benutzer verknüpfen',
	'LBL_AUTOREPLY_OPTIONS'	=> 'Auto-Antwort Optionen',
	'LBL_AUTOREPLY'			=> 'Auto-Antwort Vorlage',
	'LBL_BASIC'				=> 'Basis Setup',
	'LBL_CASE_MACRO'		=> 'Anfrage Macro',
	'LBL_CASE_MACRO_DESC'	=> 'Setzen Sie das Macro, das verwendet wird, um importierte E-Mails Anfragen zuzuweisen.',
	'LBL_CASE_MACRO_DESC2'	=> 'Sezten Sie irgendeinen Wert, aber behalten Sie das <b>"%1"</b>.',
	'LBL_CERT_DESC'			=> 'Validierung des Mailserver Sicherheitszertifikats erzwingen - nicht verwenden, wenn selbstzertifiziert.',
	'LBL_CERT'				=> 'Zertifikat validieren',
	'LBL_CLOSE_POPUP'		=> 'Fenster schließen',
	'LBL_CREATE_NEW_GROUP'	=> '--Postfach Gruppe beim Speichern erzeugen--',
	'LBL_CREATE_TEMPLATE'	=> 'Erstellen',
	'LBL_DEFAULT_FROM_ADDR'	=> 'Standard:',
	'LBL_DEFAULT_FROM_NAME'	=> 'Standard:',
	'LBL_DELETE_SEEN'		=> 'Gelesene Emails nach Import löschen',
	'LBL_EDIT_TEMPLATE'		=> 'Bearbeiten',
	'LBL_EMAIL_OPTIONS'		=> 'E-Mail Bearbeitungs Optionen',
	'LBL_FILTER_DOMAIN_DESC'=> 'Keine Auto-Antwort E-Mails an folgende Domain senden.',
	'LBL_FILTER_DOMAIN'		=> 'Keine Auto-Antwort an diese Domain',
	'LBL_FIND_OPTIMUM_KEY'	=> 'f',
	'LBL_FIND_OPTIMUM_MSG'	=> '<br>Suche Optimum Verbindungseinstellungen',
	'LBL_FIND_OPTIMUM_TITLE'=> 'Suche Optimum Konfiguration',
	'LBL_FIND_SSL_WARN'		=> 'SSL Test benötigt einen Moment. Haben Sie bitte Geduld.',
	'LBL_FORCE_DESC'		=> 'Einige IMAP/POP3 Server benötigen spezielle Schalter. Erzwingen Sie bitte eine negative Schaltung bei der Verbindung (z. Bsp. /notls)',
	'LBL_FORCE'				=> 'Erzwinge Negativ',
	'LBL_FOUND_MAILBOXES'	=> 'Folgende Postfächer gefunden:<br>Klicken Sie auf eines um es auszuwählen:',
	'LBL_FOUND_OPTIMUM_MSG'	=> '<br>Optimum Einstellungen wurden gefunden. Bitte den Button unten anklicken um diese zu übernehmen.',
	'LBL_FROM_ADDR'			=> '"Von" Adresse',
	'LBL_FROM_NAME_ADDR'	=> 'Antwort Name/E-Mail:',
	'LBL_FROM_NAME'			=> '"Von" Name',
	'LBL_GROUP_QUEUE'		=> 'An Gruppe zuweisen',
    'LBL_HOME'              => 'Home',
	'LBL_LIST_MAILBOX_TYPE'	=> 'Postfach Nutzung',
	'LBL_LIST_NAME'			=> 'Name:',
	'LBL_LIST_GLOBAL_PERSONAL'			=> 'Gruppe/Personal',
	'LBL_LIST_SERVER_URL'	=> 'Mail Server:',
	'LBL_LIST_STATUS'		=> 'Status:',
	'LBL_LOGIN'				=> 'Benutzername',
	'LBL_MAILBOX_DEFAULT'	=> 'Posteingang',
	'LBL_MAILBOX_SSL_DESC'	=> 'Verwende SSL beim Verbinden. Wenn das nicht funktioniert, prüfen Sie dass Ihre PHP Installation "--with-imap-ssl" in der Konfiguration beinhaltet.',
	'LBL_MAILBOX_SSL'		=> 'Verwende SSL',
	'LBL_MAILBOX_TYPE'		=> 'Mögliche Aktionen',
	'LBL_MAILBOX'			=> 'Überwachter Ordner',
	'LBL_MARK_READ_DESC'	=> 'Nachrichten auf Server als gelesen markieren; nicht löschen.',
	'LBL_MARK_READ_NO'		=> 'E-Mails werden nach Import als gelöscht markiert',
	'LBL_MARK_READ_YES'		=> 'E-Mails bleiben nach Import auf Server',
	'LBL_MARK_READ'			=> 'Nachrichten auf Server lassen',
	'LBL_MAX_AUTO_REPLIES'	=> 'Anzahl Auto-Antworten',
	'LBL_MAX_AUTO_REPLIES_DESC'	=> 'Setzen Sie die maximale Anzahl von Auto-Antworten für eine eindeutige E-Mail Adresse während 24 Stunden',
	'LBL_MODULE_NAME'		=> 'Einstellungen eingehende E-Mails',
	'LBL_MODULE_TITLE'		=> 'Eingehende E-Mails',
	'LBL_NAME'				=> 'Name',
    'LBL_NONE'              => 'Kein(e)',
	'LBL_NO_OPTIMUMS'		=> 'Konnte die Optimum Einstellungen nicht finden. Bitte überprüfen Sie Ihre Einstellungen und versuchen Sie es erneut.',
	'LBL_ONLY_SINCE_DESC'	=> 'Beim Verwenden von POP3 kann PHP nicht nach gelesen/ungelesen filtern. Diese Markierung erlaubt es, nach Nachrichten seit der letzten Mailbox Anfrage zu suchen. Dies verbessert die Performance signifikat, wenn Ihr Mailserver IMAP nicht unterstützt.',
	'LBL_ONLY_SINCE_NO'		=> 'Nein. Prüfe alle E-Mails auf dem Mailserver.',
	'LBL_ONLY_SINCE_YES'	=> 'Ja.',
	'LBL_ONLY_SINCE'		=> 'Importieren nur seit letztem Abruf:',
	'LBL_OUTBOUND_SERVER'	=> 'Ausgehende Mail Server',
	'LBL_PASSWORD_CHECK'	=> 'Passwort Überprüfung',
	'LBL_PASSWORD'			=> 'Passwort',
	'LBL_POP3_SUCCESS'		=> 'Ihre POP3 Test Verbindung war erfolgreich.',
	'LBL_POPUP_FAILURE'		=> 'Testverbindung fehlerhaft. Der Fehler wird unten angezeigt.',
	'LBL_POPUP_SUCCESS'		=> 'Testverbindung erfolgreich. Ihre Einstellungen funktionieren.',
	'LBL_POPUP_TITLE'		=> 'Teste Einstellungen',
	'LBL_PORT'				=> 'Mail Server Port',
	'LBL_QUEUE'				=> 'Postfach Warteschlange',
	'LBL_REPLY_NAME_ADDR'	=> 'Antwort Name/E-Mail',
	'LBL_REPLY_TO_NAME'		=> '"Antwort" Name',
	'LBL_REPLY_TO_ADDR'		=> '"Antwort" E-Mail',
	'LBL_SAME_AS_ABOVE'		=> 'Bestehende Name/E-Mail verwenden',
	'LBL_SAVE_RAW'			=> 'Quellcode speichern',
	'LBL_SAVE_RAW_DESC_1'	=> 'Wählen Sie "Ja',
	'LBL_SAVE_RAW_DESC_2'	=> 'Grosse Anhänge können bei konservativ oder nicht korrekt konfigurierten Datenbanken zu Fehlern führen.',
	'LBL_SERVER_OPTIONS'	=> 'Erweiterte Einstellungen',
	'LBL_SERVER_TYPE'		=> 'Mail Server Protokoll',
	'LBL_SERVER_URL'		=> 'Mail Server Adresse',
	'LBL_SSL_DESC'			=> 'Falls Ihr Mail Server SSL Verbindungen unterstützt, so werden beim Import der E-Mails SSL Verbindungen erzwungen.',
	'LBL_SSL'				=> 'Verwende SSL',
	'LBL_STATUS'			=> 'Status',
	'LBL_SYSTEM_DEFAULT'	=> 'System Vorgabe',
	'LBL_TEST_BUTTON_KEY'	=> 't',
	'LBL_TEST_BUTTON_TITLE'	=> 'Test [Alt+T]',
	'LBL_TEST_SETTINGS'		=> 'Teste Einstellungen',
	'LBL_TEST_SUCCESSFUL'	=> 'Verbindung erfolgreich beendet.',
	'LBL_TEST_WAIT_MESSAGE'	=> 'Einen Moment bitte...',
	'LBL_TLS_DESC'			=> 'Verwende TLS beim Verbinden zum Mailserver - verwenden Sie dies nur, wenn Ihr Mailserver dieses Protokoll unterstützt.',
	'LBL_TLS'				=> 'Verwende TLS',
	'LBL_WARN_IMAP_TITLE'	=> 'Eingehende E-Mails deaktiviert',
	'LBL_WARN_IMAP'			=> 'Warnungen:',
	'LBL_WARN_NO_IMAP'		=> 'Diese System hat keine IMAP c-Client Bibliotheken im PHP Modul integriert (--with-imap=/pfad/to/imap_c-client-library). Bitte kontaktieren Sie den Administrator zur Lösung dieses Problems.',

	'LNK_CREATE_GROUP'		=> 'Neue Gruppe',
	'LNK_LIST_CREATE_NEW'	=> 'Neues Postfach überwachen',
	'LNK_LIST_MAILBOXES'	=> 'Alle Postfächer',
	'LNK_LIST_QUEUES'		=> 'Alle Warteschlangen',
	'LNK_LIST_SCHEDULER'	=> 'Geplante Aufgaben',
	'LNK_LIST_TEST_IMPORT'	=> 'Teste E-Mail Import',
	'LNK_NEW_QUEUES'		=> 'Neue Warteschlange',
	'LNK_SEED_QUEUES'		=> 'Seed Warteschlangen der Teams',
	'LBL_IS_PERSONAL'       => 'Persönliche Mailbox',
	'LBL_GROUPFOLDER_ID'	=> 'Gruppenordner ID',
	'LBL_ASSIGN_TO_GROUP_FOLDER' => 'An Gruppenordner zuweisen',
);

?>
