<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/


$mod_strings = array (
	'LBL_MODULE_NAME' => 'Benutzerfelder bearbeiten',
	'LBL_ADD_FIELD'=> 'Feld hinzufügen:',
	'LBL_MODULE_TITLE' => 'Benutzerfelder bearbeiten',
	'LBL_MODULE_SELECT' => 'Modul zum Bearbeiten',
	'LBL_SEARCH_FORM_TITLE' => 'Suche Modul',
	'COLUMN_TITLE_NAME' => 'Feldname',
    'COLUMN_TITLE_DISPLAY_LABEL' => 'Anzeigebezeichnung',
	'COLUMN_TITLE_LABEL' => 'Systembezeichnung',
	'COLUMN_TITLE_DATA_TYPE' => 'Datentyp',
	'COLUMN_TITLE_MAX_SIZE' => 'Max. Größe',
	'COLUMN_TITLE_HELP_TEXT' => 'Hilfe Text',
    'COLUMN_TITLE_COMMENT_TEXT' => 'Text kommentieren',
	'COLUMN_TITLE_REQUIRED_OPTION' => 'Erforderliches Feld',
	'COLUMN_TITLE_DEFAULT_VALUE' => 'Standard Wert',
	'COLUMN_TITLE_DEFAULT_EMAIL' => 'Standard Wert',
	'COLUMN_TITLE_EXT1' => 'Extra Meta Feld 1',
	'COLUMN_TITLE_EXT2' => 'Extra Meta Feld 2',
	'COLUMN_TITLE_EXT3' => 'Extra Meta Feld 3',
	'COLUMN_TITLE_HTML_CONTENT' =>'HTML',
	'COLUMN_TITLE_URL'=>'Standard URL',
	'COLUMN_TITLE_AUDIT' =>'Audit',
	'COLUMN_TITLE_REPORTABLE' => 'Für Berichte',
	'COLUMN_TITLE_MIN_VALUE' => 'Min. Wert',
	'COLUMN_TITLE_MAX_VALUE' => 'Max. Wert',
	'COLUMN_TITLE_DISPLAYED_ITEM_COUNT'=>'# Elemente angezeigt',
    'COLUMN_DISABLE_NUMBER_FORMAT' => 'Format deaktivieren',
	'LBL_DROP_DOWN_LIST' => 'Auswahlliste',
	'LBL_RADIO_FIELDS'=> 'Radio-Buttons',
	'LBL_MULTI_SELECT_LIST'=> 'Mehrfach Auswahlliste',
	'COLUMN_TITLE_PRECISION'=> 'Genauigkeit',
	'MSG_DELETE_CONFIRM' => 'Möchten Sie diesen Eintrag wirklich löschen?',
	'POPUP_INSERT_HEADER_TITLE' => 'Benutzerdefiniertes Feld hinzufügen',
	'POPUP_EDIT_HEADER_TITLE' => 'Benutzerdefiniertes Feld bearbeiten',
	'LNK_SELECT_CUSTOM_FIELD' => 'Benutzerdefiniertes Feld auswählen',
	'LNK_REPAIR_CUSTOM_FIELD' => 'Benutzerdefinierte Felder reparieren',
	'LBL_MODULE' => 'Module',
	'COLUMN_TITLE_MASS_UPDATE'=>'Massenänderung',
    'COLUMN_TITLE_DUPLICATE_MERGE'=>'Dubletten zusammenführen',
    'LBL_LABEL'=>'Bezeichnung',
    'LBL_DATA_TYPE'=>'Datentyp',
    'LBL_DEFAULT_VALUE'=>'Standard Wert',
    'LBL_AUDITED'=>'Auditiert',
    'LBL_REPORTABLE'=>'Für Berichte',
    'ERR_RESERVED_FIELD_NAME' => "Reservierter Schlüsselbegriff",
	'ERR_SELECT_FIELD_TYPE' => 'Bitte eine Feldtyp auswählen',
    'LBL_BTN_ADD' => 'Hinzufügen',
    'LBL_BTN_EDIT' => 'Bearbeiten',
    
);
?>
