<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Enterprise Berichte',
  'LBL_MODULE_TITLE' => 'Enterprise Berichte',
  'LBL_SEARCH_FORM_TITLE' => 'Enterprise Berichte: Suche',
  'LBL_LIST_FORM_TITLE' => 'Alle Enterprise Berichte',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_QUERY_NAME' => 'Abfrage',
  'LBL_LIST_PUBLISHED' => 'Veröffentlicht',
  'LBL_LIST_SCHEDULED' => 'Gebucht',
  'LBL_LIST_TYPE' => 'Typ:',
  'LBL_LIST_MODULE_TITLE' => 'Module',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_PARENT_DATASET' => 'Eltern Datenset:',
  'LBL_QUERY_NAME' => 'Abfragename:',
  'LBL_TYPE' => 'Berichtsart:',
  'LBL_SCHEDULED' => 'Bericht terminieren:',
  'LBL_PUBLISHED' => 'Bericht veröffentlichen:',
  'LBL_NAME' => 'Berichtsname:',
  'LBL_TITLE' => 'Berichtstitel:',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_TABLE_WIDTH' => 'Tabellenbreite %:',
  'LBL_TABLE_HEIGHT' => 'Tabellenhöhe %:',
  'LBL_FONT_SIZE' => 'Font Größe:',

  'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag löschen wollen?',
  'ERR_DELETE_RECORD' => 'Es muss die Datensatznummer angegeben werden, um das Produkt zu löschen.',
  'LBL_CURRENCY' => 'Währung',
  
  'LNK_LIST_REPORTMAKER' => 'Enterprise Berichtsliste',
  'LNK_NEW_REPORTMAKER' => 'Bericht erstellen',
  'LNK_LIST_DATASET' => 'Datenformat Liste',
  'LNK_NEW_DATASET' => 'Datenformat erstellen',
  'LNK_NEW_CUSTOMQUERY' => 'Neue benutzerdefinierte Abfrage',
  'LNK_CUSTOMQUERIES' => 'Benutzerdefinierte Abfragen',
  'LNK_NEW_QUERYBUILDER' => 'Abfrage erstellen',
  'LNK_QUERYBUILDER' => 'Abfragewerkzeug',
  'LNK_ADVANCED_REPORTING' => 'Enterprise Berichtswesen',
  'LBL_ALL_REPORTS' => 'Alle Berichte',
  
  'LBL_ADD_DATA_SET'=>'Ein neues Datenset hinzufügen',
  'LBL_EDIT_DATA_SET'=>'Datenset aktualisieren',
  'LBL_DATA_SET'=>'Datenset:',
  'LBL_LIST_ORDER_Y'=>'Vertikale Positionierung:',
  'LBL_LIST_ORDER_X'=>'Horizontale Positionierung:',
  'LBL_REPORT_ALIGN' => 'Bericht Ausrichtung:', 
    
  //for subpanel under the reports
  'LBL_ADD_BUTTON_TITLE' => 'Auswählen [Alt+A]',
  'LBL_ADD_BUTTON_KEY' => 'A',
  'LBL_ADD_BUTTON_LABEL' => 'Auswählen',
  'LBL_NEW_BUTTON_TITLE' => 'Hinzufügen [Alt+N]',
  'LBL_NEW_BUTTON_KEY' => 'N',
  'LBL_NEW_BUTTON_LABEL' => 'Neuen erstellen',  
  'LBL_DETAILS_BUTTON_TITLE' => 'Berichtsdetails [Alt+D]',
  'LBL_DETAILS_BUTTON_KEY' => 'D',
  'LBL_DETAILS_BUTTON_LABEL' => 'Berichtsdetails',  
  'LBL_EDIT_BUTTON_TITLE' => 'Bericht bearbeiten [Alt+E]',
  'LBL_EDIT_BUTTON_KEY' => 'N',
  'LBL_EDIT_BUTTON_LABEL' => 'bearb.',  
  'LBL_RUN_BUTTON_TITLE' => 'Bericht ausführen [Alt+R]',
  'LBL_RUN_BUTTON_KEY' => 'Entwurf speichern [Alt+R]',
  'LBL_RUN_BUTTON_LABEL' => 'Bericht ausführen', 
  
  
	'LNK_UP' => 'Hinauf',
	'LNK_DOWN' => 'Hinunter', 
	
	
	'LBL_NONE'=>'Nicht terminiert',
 	'LBL_SCHEDULE_EMAIL' => 'Gebucht',
	'LBL_HELLO' => 'Hallo',	
	'LBL_SCHEDULED_REPORT_MSG_INTRO' => 'Im Anhang finden Sie einen von Sugar automatisch generiererten Bericht. Dieser Bericht wurde erstellt am ', 
	'LBL_SCHEDULED_REPORT_MSG_BODY1' => 'und gespeichert unter dem Namen "', 
	'LBL_SCHEDULED_REPORT_MSG_BODY2' => "\". Wenn Sie Ihre Berichtseinstellungen ändern wollen melden Sie sich bei Sugar an und klicken auf den  \"Berichte\" Reiter.\n\n", 
);


?>
