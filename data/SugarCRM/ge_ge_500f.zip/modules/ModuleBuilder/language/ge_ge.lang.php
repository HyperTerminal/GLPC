<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
$mod_strings = array(
'help'=>array(
	'package'=>array(
			'create'=>'Geben Sie dem Paket einen <b>Namen</b>. Der Name muss alphanumerisch sein und darf keine Leerzeichen enthalten (Beispiel: OP_Verwaltung)<br/><br/> Sie können einen <b>Autor</b> und eine <b>Beschreibung</b> angeben. <br/><br/>Klicken Sie auf <b>Speichern</b> um das Paket zu erstellen.',
			'modify'=>'Sie können <b>Name</b>, <b>Autor</b> und <b>Bezeichnung</b> des Pakets ändern, so wie auch alle enthaltenen Module ansehen und ändern.<br><br>Sie können das Paket auch <b>publizieren</b> und <b>veröffentlichen</b> aber auch die Anpassungen <b>exportieren</b>.',
			'name'=>'Dies ist der <b>Name</b> des aktuellen Pakets.<br/><br/>Der Name muss alphanumerisch sein und darf keine Leerzeichen enthalten. (Beispiel: OP_Verwaltung)',
			'author'=>'Dies ist der <b>Autor</b>, der während der Installation als der Name der Entität die das Paket erstellt hat, gezeigt wird. Der Autor kann eine Person oder eine Firma sein.',
			'description'=>'Das ist die <b>Beschreibung</b> des Pakets die während der Installation angezeigt wird.',
			'publishbtn'=>'Klicken Sie auf <b>Publizieren</b> um alle Daten zu speichern und um eine .zip Datei zu erstellen, die eine installierbare Version des Pakets enthält.<br><br>Verwenden Sie den Punkt <b>Module verwalten</b> um die .zip Datei hochzuladen und das Paket zu installieren.',
			'deploybtn'=>'Klicken Sie auf <b>Veröffentlichen</b> um alle eingegebenen Daten zu speichern und um das Paket inklusive aller Module in der aktuellen Instanz zu installieren.',
			'duplicatebtn'=>'Klicken Sie auf <b>Duplizieren</b> um den Inhalt des Pakets auf ein neues Paket zu übertragen und dieses anzuzeigen <br/><br/>Für das neue Paket wird automatisch ein Name erzeugt, indem eine Nummer an den Namen des Pakets aus dem es erzeugt wurde, angefügt wird. Sie können das neue Paket umbenennen indem Sie einen neuen <b>Namen</b> eingeben und auf <b>Speichern</b>.',
			'exportbtn'=>'Klicken Sie auf <b>Export</b> um eine .zip Datei für das Paket zu erstellen, das Ihre Anpassungen enthält.<br><br> Die erzeugte Datei enthält den Code für die Anpassungen und ist keine installierbare Version des Pakets.<br><br>Benutzen Sie den Punkt <b>Module verwalten</b> um das Paket zu importieren und die Anpassungen für neue Pakete verfügbar zu machen.',
			'deletebtn'=>'Klicken Sie auf <b>Löschen</b> um dieses Paket und alle damit verbundenen Dateien zu löschen.',
			'savebtn'=>'Klicken Sie auf <b>Speichern</b> um alle eingegebenen Daten bezüglich dieses Pakets zu speichern.',
			'existing_module'=>'Klicken Sie auf den <b>Modulnamen</b>, um die Eigenschaften zu bearbeiten und um die mit dem Modul verbundenen Felder, Beziehungen und Layouts anzupassen.',
			'new_module'=>'Klicken Sie auf <b>Neues Modul</b> um ein neues Modul für dieses Paket zu erstellen.',
			'key'=>'Dieser 5stellige alphanumerische <b>Schlüssel</b> wird allen Verzeichnissen, Klassennamen und Datenbanknamen in allen Modulen des aktuellen Pakets vorangestellt <br><br>Auf diese Art und Weise soll die Eindeutigkeit von Tabellennamen erreicht werden.',
			'readme'=>'Klicken Sie um einen <b>Liesmich</b> Text für dieses Paket zu erstellen.<br><br>Dieser Text ist zum Zeitpunkt der Installation verfügbar.',
	),
	'main'=>array(


	),
	'module'=>array(

		'create'=>'Definieren Sie einen <b>Namen</b> für das Modul. Diese <b>Bezeichnung</b> scheint im Navigationsreiter auf. <br/><br/>Wenn Sie einen Navigationsreiter für das Modul sehen wollen, markieren Sie die <b>Navigation Tab</b> Checkbox.<br/><br/>Markieren Sie die <b>Team Sicherheit</b> Checkbox um im jeweiligen Modul ein Teamauswahlfeld zu haben.<br/><br/>Dann wählen Sie den Modultyp den Sie erstellen wollen.<br/><br/>Wählen Sie einen Vorlagetyp. Jede Vorlage enthält einen speziellen Satz an Feldern aber auch vordefinierte Layouts, die Sie als Grundlage für Ihr Modul verwenden können.<br/><br/>Klicken Sie auf <b>Speichern</b> um das Modul zu erstellen.',




		'modify'=>'Sie können die Moduleigenschaften verändern oder die mit dem Modul verbundenen <b>Felder</b>, <b>Beziehungen</b> und <b>Layouts</b> anpassen.',
		'team_security'=>'Das Markieren der <b>Team Kontrolle</b> Checkbox aktiviert die Team Kontrolle für dieses Modul.<br/><br/>Wenn die Team Kontrolle aktiviert ist, wird das Team Auswahlfeld in den Datensätzen sichtbar.',
		'reportable'=>'Durch das Markieren dieser Option können Berichte für dieses Modul erstellt werden.',
		'assignable'=>'Wenn dieses Kästchen markiert wird, können Datensätze bestimmten Benutzern zugewiesen werden.',
		'has_tab'=>'Das Markieren von <b>Navigations Tab</b> erstellt einen Naviagtions Reiter für das Modul.',
		'acl'=>'Das Markieren dieser Option aktiviert die Zugangskontrolle für dieses Modul, inklusive der Kontrolle auf Feldebene.',
		'studio'=>'Wenn dieses Kästchen markiert ist, können Administratoren dieses Modul im Studio anpassen.',
		'audit'=>'Wenn Sie dieses Kästchen markieren, wird die Audit Funktion für dieses Modul aktiviert.Änderungen von definierten Feldern werden für eine spätere Kontrolle aufgezeichnet.',
		'viewfieldsbtn'=>'Klicken Sie auf <b>Felder anzeigen</b> um die Felder zu sehen die mit diesem Modul verbunden sind, und um eigene Felder zu erstellen oder zu ändern.',
		'viewrelsbtn'=>'Klicken Sie auf <b>Beziehungen anzeigen</b> um die Beziehungen zu sehen die mit diesem Modul verbunden sind, und um neue Beziehungen zu erstellen.',
		'viewlayoutsbtn'=>'Klicken Sie auf <b>Layouts bearbeiten</b> um die Layouts für das Modul anzusehen und die Feldanordnung innerhalb des Layouts anzupassen.',
		'duplicatebtn'=>'Klicken Sie auf <b>Duplizieren</b> um den Inhalt des Pakets auf ein neues Paket zu übertragen und dieses anzuzeigen <br/><br/>Für das neue Paket wird automatisch ein Name erzeugt, indem eine Nummer an den Namen des Pakets aus dem es erzeugt wurde, angefügt wird. <br><br>Sie können das neue Paket umbenennen, indem Sie einen neuen <b>Namen</b> eingeben und auf <b>Speichern</b> drücken.',
		'deletebtn'=>'Klicken Sie auf <b>Löschen</b> um dieses Modul zu löschen.',
		'name'=>'Dies ist der <b>Name</b> des aktuellen Moduls.<br/><br/>Der Name muss alphanumerisch sein, muss mit einem Buchstaben beginnen und darf keine Leerzeichen enthalten. (Beispiel: OP_Verwaltung)',
		'label'=>'Das ist die <b>Bezeichnung</b> die im Navigationsreiter des Moduls aufscheint.',
		'savebtn'=>'Drücken Sie auf <b>Speichern</b> um alle eingegebenen Daten in Bezug auf dieses Modul zu speichern.',
		'type_basic'=>'Die <b>Basis</b> Vorlage liefert typische Standardfelder wie Name, Zugewiesen an, Team, Erstellungsdatum und Beschreibung.',
		'type_company'=>'Die <b>Firma</b> Vorlage liefert organisationstypische Felder wie z.B. Firmenname, Branche oder Rechnungsadresse.<br/><br/>Verwenden Sie diese Vorlage, um ein Modul zu erstellen, das dem Standardmodul “Firmen“ ähnlich ist.',
		'type_issue'=>'Die <b>Problem</b> Vorlage liefert Felder für Störfälle oder Supportanfragen mit Feldern wie z.B. Nummer, Status, Priorität und Beschreibung.<br/><br/>Verwenden Sie diese Vorlage, um Module zu erstellen, die dem Standardmodulen “Fälle“ und “Fehlerverfolgung“ ähnlich sind.',
		'type_person'=>'Die <b>Person</b> Vorlage stellt Felder für Individuen zur Verfügung – z.B. Anrede, Titel, Name, Adresse oder Telefonnummer. <br/><br/>Verwenden Sie diese Vorlage für Module ähnlich den Interessenten bzw. Kontaktpersonen.',

	),
	'dropdowns'=>array(
		'default' => 'Alle Auswahllisten der Applikation sind hier aufgeführt.<br><br> Um eine bestehende Auswahlliste zu ändern, klicken Sie auf den Namen der Auswahlliste. <br><br>Ändern Sie im Formular  <b>Auswahllisten bearbeiten</b> in der Leiste rechts und drücken Sie auf <b>Speichern</b>. Ändern Sie was immer notwendig ist und drücken Sie auf <b>Speichern</b>.<br><br>Um eine neue Auswahlliste zu erstellen, klicken Sie auf <b>Auswahlliste hinzufügen.</b> Geben Sie die Eigenschaften in <b>Auswahllisten bearbeiten</b> ein und klicken Sie auf <b>Speichern</b>.'
	),
	'listViewEditor'=>array(
		'modify'	=> 'Die <b>Standard</b> Spalte enthält Felder, die als Standard in der Listendarstellung angezeigt werden. <br/><br/>Die <b>Verfügbar</b> Spalte enthält Felder, die der Benutzer auswählen kann, um die Listendarstellung zu ändern.  <br/><br/>Die <b>Verborgen</b> Spalte enthält Felder die Sie als Admin zu den beiden anderen Spalten hinzufügen können.',
		'savebtn'	=> 'Klicken Sie auf <b>Speichern & Veröffentlichen</b> um Ihre Änderungen zu speichern und sie innerhalb des Moduls zu aktivieren.',
		'Hidden' 	=> 'Verborgene Felder sind für Benutzer aktuell in der Listenansicht nicht verfügbar.',
		'Available' => 'Verfügbare Felder werden standardmäßig nicht angezeigt, können aber vom Benutzer zur Listenansicht hinzugefügt werden.',
		'Default'	=> 'Standard Ansichten werden Benutzern präsentiert, die noch keine individuellen Listenansichten erstellt haben.'
	),
	'searchViewEditor'=>array(
		'modify'	=> 'Die <b>Standard</b> Spalte enthält Felder die in der Suche angezeigt werden. <br/><br/>Die <b>Verborgen</b> Spalte enthält Felder die für Sie als Admin verfügbar sind, um sie zur Ansicht hinzuzufügen.',
		'savebtn'	=> 'Klicken auf <b>Speichern & Veröffentlichen</b> speichert alle Änderungen und aktiviert sie.',
		'Hidden' 	=> 'Verborgene Felder sind solche, die in der Suche nicht angezeigt werden.',
		'Default'	=> 'Standardfelder werden in der Suchansicht angezeigt.'
	),
	'layoutEditor'=>array(
		'default'	=> 'Ändern Sie das angezeigte Layout indem Sie Elemente und Felder zwischen den beiden Bereichen auf dieser Seite ziehen und fallenlassen.<br/><br/>Die linke Spalte <b>(Toolbox)</b> enthält nützliche Elemente und Werkzeuge für das Bearbeiten des Moduls.<br/><br/>Die rechte Spalte, genannt <b>Aktuelles Layout</b> bzw. <b>Layout Vorschau</b>, enthält das Layout des Moduls.<br/><br/>Wird <b>Aktuelles Layout</b> angezeigt, dann arbeiten Sie mit einer Kopie, die dem derzeit von den Benutzern verwendeten Original entspricht.<br/><br/>Wird <b>Layout Vorschau</b> angezeigt, dann arbeiten Sie mit einer bereits einmal gespeicherten Kopie. Bemerkung: Wenn ein anderer Benutzer zwischenzeitlich das gleiche Layout veröffentlicht, dann muss Ihre Version nicht die derzeit aktuelle sein.',
		'saveBtn'	=> 'Klicken Sie auf <b>Speichern</b> um die Änderungen am Layout zu sichern. Wenn Sie die Änderungen nicht veröffentlichen bevor Sie das Studio verlassen, werden die Änderungen nicht sichtbar. Wenn Sie in das Studio zurückkehren, sehen Sie das Layout mit den gesicherten Änderungen. Das Layout wird nicht im Modul dargestellt, bis Sie nicht <b>Speichern & Veröffentlichen</b> drücken.',
		'publishBtn'=> 'Klicken Sie <b>Speichern & Veröffentlichen</b> um das Layout zu veröffentlichen.<br><br>Nach dem Veröffentlichen wird das Layout sofort im Modul sichtbar.',
		'toolbox'	=> 'Die <b>Toolbox</b> enthält eine Reihe von nützlichen Werkzeugen zum Bearbeiten des Layouts, wie z.B. den <b>Papierkorb</b>, zusätzliche Layout Elemente und die für dieses Modul verfügbaren Felder.<br/><br/>Alle Elemente können aus der und in die Toolbox sowie in den Papierkorb gezogen werden.<br/><br/>Wenn Sie eine neue Zeile oder ein Panel in das Layout ziehen, wird es dort platziert wo Sie es \'fallen lassen\'<br/><br/>Ein <b>Filler</b> Feld erstellt eine leere Position wo es platziert wird.<br/><br/>Durch das Ziehen und Loslassen eines Felds auf eine besetzte Position, tauschen diese Felder Ihren Platz.',
		'panels'	=> 'Dieser Bereich zeigt, wie die Maske aussehen wird, wenn die Änderungen veröffentlicht wurden.<br/><br/>Sie können Elemente wie z.B. Felder oder Zeilen positionieren, indem Sie sie mit der Maus ziehen und loslassen.<br/><br/>Sie können Elemente löschen indem Sie sie in den <b>Papierkorb</b> ziehen oder Sie können neue Elemente hinzufügen, indem Sie sie aus der <b>Toolbox</b> links in die gewünschte Position ziehen und loslassen.',
		'delete'	=> 'Ziehen Sie irgendein Element mit der Maus hierher, um es vom Layout zu entfernen',
	),
	'fieldsEditor'=>array(
		'default'	=> 'Alle Felder die für das aktuelle Modul verfügbar sind, sind hier aufgeführt.<br><br> Die Felder die im Standard inkludiert sind, können Sie im Bereich <b>Standard</b> sehen.<br><br>Benutzerdefinierte Felder sind im Bereich <b>Benutzerdefiniert</b>.<br><br>Um Felder zu bearbeiten, klicken Sie auf den <b>Feldnamen</b>. Ändern Sie die Eigenschaften im <b>Eigenschaften</b> Formular in der rechten Leiste und drücken Sie  <b>Speichern</b>. <br/><br/>Wenn die Eigenschaften angezeigt werden, können Sie schnell ein neues Feld erstellen indem Sie auf die Schaltfläche <b>Klonen</b> drücken. Ändern Sie wie notwendig und klicken Sie auf  <b>Speichern</b>.<br><br>Um ein neues Feld zu erstellen klicken Sie auf <b>Feld hinzufügen.</b>. Geben Sie die Attribute des Felds im <b>Eigenschaften</b> Formular ein und drücken Sie  <b>Speichern</b>. Das neue Feld erscheint im Bereich <b>Benutzerdefiniert</b> .<br><br>Um die Feldbezeichnungen zu ändern klicken Sie auf <b>Bezeichnungen bearbeiten</b>.',
	),
	'exportcustom'=>array(
	    'exportHelp'=>'Exportieren Sie Studio Anpassungen indem Sie Pakete erstellen, die durch <b>Module verwalten</b> in eine andere Instanz hochgeladen werden können.<br><br>Geben Sie zuerst einen <b>Paketnamen</b>.  Sie können auch einen <b>Autor</b> bzw. eine <b>Beschreibung</b> zum Paket hinzufügen.<br><br>Wählen Sie die Module die Anpassungen zum Export enthalten. (Es werden nur Module mit existenten Anpassungen angezeigt.)<br><br>Klicken Sie auf <b>Export</b> um eine .zip Datei für das Paket zu erstellen, dass die Anpassungen enthält.',
	    'exportCustomBtn'=>'Klicken Sie auf <b>Export</b> um eine .zip Datei für das Paket zu erstellen, das Ihre Anpassungen enthält und das Sie exportieren wollen.',
	    'name'=>'Das ist der <b>Name</b> des Pakets. Der Name wird bei der Installation angezeigt.',
	    'author'=>'Dies ist der <b>Autor</b>, der während der Installation als der Name der Entität die das Paket erstellt hat, gezeigt wird. Der Autor kann eine Person oder eine Firma sein.',
	    'description'=>'Das ist die <b>Beschreibung</b> des Pakets die während der Installation angezeigt wird.',
	),
	'studioWizard'=>array(
		'mainHelp' 	=> 'Willkommen im Bereich für <b>Entwickler Werkzeuge</b>.<br/><br/>Benutzen Sie die Werkzeuge in diesem Bereich um Standard und angepasste Module und Felder zu bearbeiten bzw. zu erstellen.',
		'studioBtn'	=> 'Benutzen Sie das <b>Studio</b>, um installierte Module anzupassen.',
		'mbBtn'		=> 'Verwenden Sie den <b>Module Builder</b> um neue Module zu erstellen.',
		'sugarPortalBtn' => 'Benutzen Sie den <b>Sugar Portal Editor</b> um das Sugar Portal zu verwalten und anzupassen.',
		'dropDownEditorBtn' => 'Verwenden Sie den <b>Auswahllisten Editor</b> um globale Auswahllisten für Auswahlfelder zu erstellen und zu ändern.',
		'appBtn' 	=> 'Im Applikationsmodus können Sie verschiedene Parameter des Programms verändern, zum Beispiel wie viele TPS Berichte auf der Homepage angezeigt werden.',
		'backBtn'	=> 'Zurück zum vorherigen Schritt.',
		'studioHelp'=> 'Im <b>Studio</b> können Sie die Darstellung der Masken ändern, bestimmen welche Daten verfügbar sein sollen und  benutzerdefinierte Felder für die <i>installierten</i> Module erstellen.',
		'moduleBtn'	=> 'Klicken Sie um das Modul zu bearbeiten.',
		'moduleHelp'=> 'Wählen Sie die Modulkomponente die Sie bearbeiten möchten.',
		'fieldsBtn'	=> 'Definieren Sie über die Kontrolle der <b>Felder</b>, welche Informationen in dem Modul gespeichert werden.<br/><br/>Sie können hier neue Felder erstellen und ändern um Informationen zu speichern.',
		'labelsBtn' => 'Bearbeiten der <b>Bezeichnungen</b> die bei den Feldern im Modul angezeigt werden.'	,
		'layoutsBtn'=> 'Passen Sie die folgenden Modul <b>Layouts</b> an: Bearbeitungs-, Detail-, Listen- und Suchansicht.',
		'subpanelBtn'=> 'Bestimmen Sie welche Information in den <b>Subpanels</b> des Moduls erscheinen soll.',
		'layoutsHelp'=> 'Wählen Sie ein <b>Layout</b> zum Bearbeiten.',
		'subpanelHelp'=> 'Wählen Sie ein <b>Subpanel</b> zum Bearbeiten.',
		'labelsHelp'=> 'Die aktuellen Bezeichnungen aller <b>Felder</b> im aktuellen Modul werden in der rechten Spalte angezeigt.<br><br>Klicken Sie in ein Feld, ändern den Namen und drücken dann <b>Speichern</b>.',
        'newPackage'=>'Klicken Sie auf <b>Neues Paket</b> um ein neues Paket zu erstellen.',
        'exportBtn' => 'Klicken Sie auf <b>Anpassungen exportieren</b> um ein Paket zu erstellen, dass die im Studio erstellten Anpassungen für spezifische Module enthält.',
        'mbHelp'    => '<b>Willkommen im Module Builder.</b><br/><br/>Benutzen Sie den <b>Module Builder</b> um Pakete zu erstellen, die benutzerdefinierte Module enthalten – basierend auf Standard oder angepassten Objekten.<br/><br/>Um zu beginnen, klicken Sie auf <b>Neues Paket</b> um ein neues Paket zu erstellen oder wählen Sie ein Paket zum Bearbeiten aus.',
	    'viewBtnEditView' => 'Bearbeiten Sie die <b>Bearbeitungsansicht</b> des Moduls.',
	    'viewBtnDetailView' => 'Bearbeiten Sie die <b>Detailansicht</b> des Moduls.',
	    'viewBtnListView' => 'Bearbeiten Sie die <b>Listenansicht</b> des Moduls.',
	    'searchBtn' => 'Bearbeiten Sie die <b>Suchansicht</b> des Moduls.',
		'viewBtnQuickCreate' =>  'Bearbeiten Sie die <b>Schnellerfassungsansicht</b> des Moduls.',
	    'searchHelp'=> 'Wählen Sie eine <b>Suchansicht</b> zum Bearbeiten.',
	    'BasicSearchBtn' => 'Bearbeiten Sie das <b>Einfache Suche</b> Formulars das in dem “Einfache Suche“ Reiter im Suchbereich des Moduls aufscheint.',
	    'AdvancedSearchBtn' => 'Bearbeiten Sie hier das <b>Erweiterte Suchformular</b> an. Dieses erscheint unter dem “Erweiterte Suche“ Reiter im Suchbereich des Moduls.',
	    'portalHelp' => 'Das <b>Sugar Portal</b> verwalten und anpassen.',
	    'SPUploadCSS' => 'Laden Sie ein <b>Style Sheet</b> für das Sugar Portal hoch.',
	    'SPSync' => '<b>Synchronisieren</b> von Änderungen an die Sugar Portal Instanz.',
	    'Layouts' => 'Bearbeiten Sie das <b>Layout</b> des Sugar Portal Moduls.',
	    'portalLayoutHelp' => 'Die Module innerhalb des Sugar Portals sind in diesem Bereich<br><br>Wählen Sie ein Modul um die <b>Layouts</b> zu bearbeiten.',
		'relationshipsHelp' => 'Sie können dieses Modul zu anderen Modulen im selben Paket oder zu bereits installierten Modulen in Beziehung setzen.<br/><br/>Um eine neue Beziehung zu erstellen klicken Sie auf <b>Beziehung hinzufügen</b>. Die Eigenschaften der Beziehung sind in dem Formular in der Leiste rechts zusehen. Benützen Sie die <b>Verknüpfen mit</b> Auswahlliste um ein Modul auszuwählen, dass Sie mit diesem verbinden wollen.<br><br>Geben Sie eine <b>Bezeichung</b> an - diese wird als Titel auf dem Subpanel des verbundenen Moduls angezeigt.<br><br>Die Beziehung zwischen den Modulen wird über Subpanels verwaltet, die jeweils unter der Detailansicht des Moduls angezeigt werden.<br><br>Für das Subpanel des verknüpften Moduls können Sie unter Umständen verschiedenene Layouts wählen, dies hängt vom Modul ab das für die Beziehung ausgewählt wurde. <br/><br/> Klicken Sie auf  <b>Speichern</b> um die Beziehung zu erstellen. Klicken Sie auf <b>Löschen</b> um die ausgewählte Beziehung zu löschen.<br/><br/>Um eine existente Beziehung zu bea',
		'editDropDownBtn' => 'Ein globales Auswahlfeld bearbeiten',
		'addDropDownBtn' => 'Ein neues globales Auswahlfeld erstellen',
	),
	'portalSync'=>array(
	    'default' => 'Geben Sie die <b>Sugar Portal URL</b> jener Instanz ein, die Sie aktualisieren wollen und klicken Sie auf <b>Ausführen</b>.<br><br>Anschließend geben Sie einen gültigen Sugar Benutzernamen und Passwort ein und drücken auf <b>Sync starten</b>.<br><br>Die Anpassungen des Sugar Portal <b>Layouts</b>, zusammen mit dem <b>Style Sheet</b> wenn eines hochgeladen wurde, werden zur angegebenen Portal Instanz transferiert.',
	),
	'portalStyle'=>array(
	    'default' => 'Hier können Sie das Aussehen des Sugar Portals anpassen.',
	),
),

'assistantHelp'=>array(
	'package'=>array(
			//custom begin
			'nopackages'=>'Um ein neues Projekt zu starten, klicken Sie auf <b>Neues Paket</b> und erstellen Sie ein Paket dass Ihre neuen Module enthalten wird. <br/><br/>Jedes Paket kann ein oder mehrere Module beinhalten<br/><br/>Zum Beispiel könnten Sie ein einzelnes Modul erstellen, dass mit dem Standard Firmenmodul verknüpft ist. Oder Sie erstellen ein Paket mit mehreren Modulen die als Projekt zusammen arbeiten, und untereinander sowie zu bereits existierenden Modulen verknüpft sind.',
			'somepackages'=>'Ein <b>Paket</b> ist ein Container für selbst erstellte Module die Teil eines Projekts sind . Das Paket kann ein oder mehrere benutzerdefinierte  <b>Module</b> enthalten, die eine Relation untereinander oder zu existierenden Modulen haben können.<br/><br/>Nachdem Sie ein Paket für Ihr Projekt erstellt haben, können Sie direkt Module für dieses Paket erstellen oder Sie können die begonnene Arbeit zu einem späteren Zeitpunkt fortsetzen.<br><br>Wenn das Projekt fertig ist, können Sie das Paket <b>Anwenden</b> um die benutzerdefinierten Module in der Applikation zu installieren.',
			'afterSave'=>'Ihr neues Paket muss zumindest ein Modul enthalten. Sie können ein oder mehrere benutzerdefinierte Module für das Paket erstellen.<br/><br/>Klicken Sie auf <b>Neues Modul</b> um ein Modul für dieses Paket zu erstellen.<br/><br/> Nachdem Sie zumindest ein Modul erstellt haben, können Sie es für Ihre Instanz oder die anderer Benutzer veröffentlichen.<br/><br/> Um das Paket in einem Schritt in Ihre Instanz zu veröffentlichen, klicken Sie auf <b>Veröffentlichen</b>.<br><br>Klicken Sie auf <b>Publizieren</b> um das Paket als .zip Datei zu speichern. Nachdem die .zip Datei gespeichert wurde, benutzen Sie <b>Module verwalten</b>, um das Paket in Ihre Instanz hochzuladen und zu installieren.<br/><br/>Sie können die Datei auch an andere Benutzer weitergeben, damit diese sie in deren Instanz installieren.',
			'create'=>'Ein <b>Paket</b> ist ein Container für selbst erstellte Module die Teil eines Projekts sind . Das Paket kann ein oder mehrere benutzerdefinierte  <b>Module</b> enthalten, die eine Relation untereinander oder zu existierenden Modulen haben können.<br/><br/>Nachdem Sie ein Paket für Ihr Projekt erstellt haben, können Sie direkt Module für dieses Paket erstellen oder Sie können die begonnene Arbeit zu einem späteren Zeitpunkt fortsetzen.',
			),
	'main'=>array(
		'welcome'=>'Benutzen Sie die <b>Entwickler Werkzeuge</b> um Standard und angepasste Module zu erstellen und zu verwalten<br/><br/>Um Module in der Applikation zu verwalten, klicken Sie auf <b>Studio</b>. <br/><br/>Um neue Module zu erstellen, klicken Sie auf <b>Module Builder</b>.',
		'studioWelcome'=>'Alle derzeit installierten Module, egal ob Standard oder hochgeladen, können im Studio angepasst werden.'
	),
	'module'=>array(
		'somemodules'=>"Wenn das aktuelle Paket zumindest ein Modul enthält, können Sie die Module im Paket in Ihrer Instanz <b>Veröffentlichen</b> oder Sie können das Paket <b>Publizieren</b> um es mittels <b>Module verwalten</b> in dieser oder einer anderen Instanz zu installieren.<br/><br/>Um das Paket direkt innerhalb Ihrer Instanz zu installieren, klicken Sie <b>Veröffentlichen</b>.<br><br>Um eine .zip Datei zu erstellen, die mittels <b>Module verwalten</b> in Ihre oder eine andere Instanz hochgeladen und installiert werden kann, klicken Sie auf <b>Publizieren</b>.<br/><br/> Sie können die Module für dieses Paket iin Abschnitten erarbeiten und sie veröffentlichen oder publizieren wann immer Sie soweit sind.<br/><br/>Nachdem Sie ein Paket veröffentlicht oder publiziert haben, können Sie Änderungen anbringen bzw. Ihre Module weiter anpassen. Danach veröffentlichen oder publizieren Sie Ihr paket nochmals." ,
		'editView'=> 'Hier können Sie existierende Felder bearbeiten. Sie können existierende Felder löschen oder verfügbare aus der Leiste links hinzufügen.',
		'create'=>'Wenn Sie den <b>Typ</b> des Moduls auswählen das Sie erstellen wollen, denken Sie bitte an die Arten der Felder die Sie in dem Modul haben möchten. <br/><br/>Jede Modulvorlage beinhaltet eine Gruppe von Feldern die zu dem im Titel beschriebenen Modul gehören.<br/><br/><b>Basis</b> - Enthält Basisfelder die in Standardmodulen vorkommen wie z.B. Name, zugewiesen an, Team, Erstellungsdatum oder Beschreibungsfelder.<br/><br/> <b>Firma</b> - Stellt organisationsspezifische Felder wie Firmenname, Branche oder Rechnungsadresse zur Verfügung. Verwenden Sie diese Vorlage, um Module zu erstellen, die dem Standard Firmenmodul ähnlich sind.<br/><br/> <b>Person</b> - Stellt Felder für Individuen zur Verfügung – z.B. Anrede, Titel, Name, Adresse oder Telefonnummer. Verwenden Sie diese Vorlage für Module ähnlich zu Interessenten bzw. Kontaktpersonen.<br/><br/> <b>Problem</b> - Für Störfälle oder Supportanfragen mit Feldern wie z.B. Nummer, Status, Priorität und Beschreibung.<br/><br/>Bemerkung: Nachdem Sie das Modul erstell',
		'afterSave'=>'Passen Sie das Modul Ihren Vorstellungen an indem Sie Felder erstellen oder bearbeiten, Beziehungen zu anderen Modulen erstellen und die Felder auf den Layouts organisieren.<br/><br/>Um die Standardfelder anzusehen bzw. um benutzerdefinierte Felder zu verwalten, klicken Sie auf <b>Felder ansehen</b>.<br/><br/>Um Beziehungen zu anderen Modulen (egal ob bestehend oder selbst erstellt) zu erstellen und zu verwalten, klicken Sie auf <b>Beziehungen ansehen</b>.<br/><br/>Um die Layouts der Module zu bearbeiten, klicken Sie auf <b>Layouts ansehen</b>. Sie können die Bearbeitungs-, Detail- und Listenansicht für das Modul ändern – genauso wie Sie das auch mit einem mitgelieferten Modul tun würden.<br/><br/> Um ein Modul mit den selben Eigenschaften wie das angezeigte zu erstellen, klicken Sie auf <b>Duplizieren</b>. Sie können das neue Modul weiter anpassen.',
		'viewfields'=>'Die Felder in dem Modul können gemäß Ihren Wünschen angepasst werden.<br/><br/>Sie können keine Standardfelder löschen aber Sie können sie aus den entsprechenden Layouts entfernen.<br/><br/>Sie können auch die Bezeichnungen der Standardfelder ändern. Die anderen Eigenschaften der Standardfelder sind nicht änderbar. Allerdings können Sie sehr schnell neue Felder mit den gleichen Eigenschaften erstellen, indem Sie im <b>Eigenschaften</b> Formular auf <b>Klonen</b>  drücken. Geben Sie irgendwelchen neuen Eigenschaften ein und drücken Sie <b>Speichern</b>.<br/><br/>Nachdem ein Modul einmal installiert ist, können nicht mehr alle Eigenschaften geändert werden. Setzen Sie daher alle Eigenschaften für Standard und selbst erstellte Felder bevor Sie das Paket mit dem neuen Modul installieren.',
		'viewrelationships'=>'Sie können N-M Beziehungen zwischen diesem und anderen Modulen in dem Paket, und/oder zwischen dem aktuellen Modul und bereits installierten Modulen erstellen<br><br>(Um 1-n und 1-1 Beziehungen herzustellen, erstellen Sie <b>Relate</b> und <b>Flex Relate</b> Felder für die jeweiligen Module.)',
		'viewlayouts'=>'Über die <b>Bearbeitungsansicht</b> bestimmen Sie, welche Felder für die Dateneingabe zur Verfügung stehen. Die Ausgabe wird über die  <b>Detailansicht</b> bestimmt. Die Ansichten müssen nicht gleich sein. <br/><br/>Das Formular zur Schnellerstellung wird angezeigt, wenn die Schaltfläche <b>Erstellen</b> in einem Subpanel geklickt wird. Standardmäßig ist das Formular zur <b>Schnellerstellung</b> das gleiche wie die <b>Bearbeitungsansicht</b>. Allerdings können Sie dieses Formular auch nach Ihren Wünschen konfigurieren.<br><br>Die Modulsicherheit bestimmen Sie über die Gestaltung des Layouts sowie über die <b>Rollenverwaltung</b>.<br><br>',
		'existingModule' =>'Nachdem Sie das Modul erstellt bzw. angepasst haben, können Sie weitere Module erstellen oder zum Paket zurückkehren um es zu  <b>publizieren</b> oder <b>anzuwenden</b>.<br><br>Um ein neues Modul zu erstellen klicken Sie auf <b>Duplizieren</b>, dies erstellt ein Modul mit den gleichen Eigenschaften wie das gerade bearbeitete. Oder Sie gehen zurück zum Paket und wählen <b>Neues Modul</b>.<br><br> Wenn Sie bereit sind, das Paket mit dem Modul zu <b>publizieren</b> oder <b>anzuwenden</b> gehen Sie zurück zum Paket um diese Funktion durchzuführen. Sie können Pakete publizieren und anwenden wenn diese zumindest ein Modul enthalten.',
		'labels'=> 'Bezeichnungen können sowohl für Standardfelder als auch für eigenerstellte Felder geändert werden. Der Feldinhalt (die Daten) werden davon nicht beeinflusst.',
	),
	'listViewEditor'=>array(
		'modify'	=> 'Auf der linken Seite werden drei Spalten angezeigt. Die “Standard“ Spalte enthält Felder die standardmäßig in der Listenansicht angezeigt werden, die “Verborgen“ Spalte enthält Felder die Benutzer verwenden können, um sich eine eigene angepasste Listenansicht zu erstellen, die “Versteckt“ Spalte enthält Felder die für Sie als Admin verfügbar sind um sie entweder zur Standard oder zur Verfügbar Spalte hinzuzufügen.',
		'savebtn'	=> 'Das Klicken auf <b>Speichern</b> speichert alle Änderungen und aktiviert sie.',
		'Hidden' 	=> 'Verborgene Felder sind für Benutzer nicht verfügbar und können nicht in Listenansichten verwendet werden.',
		'Available' => 'Verfügbare Felder die nicht standarmäßig angezeigt werden, können durch den Benutzer sichtbar gemacht werden.',
		'Default'	=> 'Standard Ansichten werden Benutzern präsentiert, die noch keine individuellen Listenansichten erstellt haben'
	),
	'searchViewEditor'=>array(
		'modify'	=> 'Auf der linken Seite werden zwei Spalten angezeigt. Die “Standard“ Spalte enthält Felder die in der Suche angezeigt werden, die “Verborgen“ Spalte enthält Felder die für Sie als Admin verfügbar sind um sie zur Ansicht hinzuzufügen.',
		'savebtn'	=> 'Klicken auf <b>Speichern & Veröffentlichen</b> speichert alle Änderungen und aktiviert sie.',
		'Hidden' 	=> 'Verborgene Felder sind solche, die in der Suche nicht angezeigt werden.',
		'Default'	=> 'Standardfelder werden in der Suchansicht angezeigt.',
		'multiselect_field_warning'=>'<br>Bitte beachten Sie: Wenn Sie in diesem Modul Mehrfachauswahlfelder haben, dann kann ein Hinzufügen zum \'Standardbereich\' der Suchmaske zu Geschwindigkeitsnachteilen führen.<br>'
	),
	'layoutEditor'=>array(
		'default'	=> 'Auf der linken Seite werden zwei Spalten angezeigt. In der rechten Spalte, genannt aktuelles Layout bzw. Layout Vorschau, ändern Sie das Layout des Moduls. Die linke Spalte (Toolbox) enthält nützliche Elemente und Werkzeuge für das Bearbeiten des Moduls. <br/><br/>Wenn die Arbeitsfläche “Aktuelles Layout“ anzeigt, dann arbeiten Sie an einer Kopie des derzeit “live“ angezeigten Layouts.<br/><br/>Wird “Layout Vorschau“ angezeigt, dann arbeiten Sie mit einer bereits einmal gespeicherten Kopie, die nicht mehr dem derzeit von den Benutzern verwendeten Original entsprechen muss.',
		'saveBtn'	=> 'Wenn Sie auf diese Schaltfläche klicken, wird das Layout mit Ihren Änderungen gespeichert. Wenn Sie zu einem späteren Zeitpunkt weitermachen, beginnen Sie bei diesem veränderten Layout. Allerdings wird Ihr Layout nicht von anderen gesehen bis Sie nicht auf “Speichern und Publizieren“ drücken.',
		'publishBtn'=> 'Drücken Sie auf diese Schaltfläche um das Layout zu veröffentlichen. Dies bedeutet, dass das Layout sofort für andere Benutzer verfügbar ist.',
		'toolbox'	=> 'Die Toolbox enthält eine Reihe von nützlichen Funktionen um Layouts zu bearbeiten – einen Papierkorb, einen Satz zusätzlicher Elemente sowie alle verfügbaren Felder. Diese können in das Layout gezogen und positioniert werden.',
		'panels'	=> 'Diese Ansicht zeigt, wie Ihr Layout für Benutzer aussieht wenn es angewendet ist.<br/><br/>Sie können Elemente wie z.B. Felder oder Zeilen positionieren, indem Sie sie mit der Maus ziehen und loslassen; Sie können Elemente löschen indem Sie sie in den Papierkorb ziehen oder Sie können neue Elemente hinzufügen, indem Sie sie aus der Toolbox links in die gewünschte Position ziehen und loslassen.'
	),
	'dropdownEditor'=>array(
		'default'	=> 'Auf der linken Seite werden zwei Spalten angezeigt. In der rechten Spalte, genannt aktuelles Layout bzw. Layout Vorschau, ändern Sie das Layout des Moduls. Die linke Spalte (Toolbox) enthält nützliche Elemente und Werkzeuge für das Bearbeiten des Moduls. <br/><br/>Wenn die Arbeitsfläche “Aktuelles Layout“ anzeigt, dann arbeiten Sie an einer Kopie des derzeit “live“ angezeigten Layouts.<br/><br/>Wird “Layout Vorschau“ angezeigt, dann arbeiten Sie mit einer bereits einmal gespeicherten Kopie, die nicht mehr dem derzeit von den Benutzern verwendeten Original entsprechen muss.',
		'dropdownaddbtn'=> 'Das Klicken auf diese Schaltfläche fügt einen neuen Eintrag zur Auswahlliste hinzu.',
	),
	'exportcustom'=>array(
	    'exportHelp'=>'Exportieren Sie Studio Anpassungen indem Sie Pakete erstellen, die durch <b>Module verwalten</b> in eine andere Instanz hochgeladen werden können.<br><br>Geben Sie zuerst einen <b>Paketnamen</b>.  Sie können auch einen <b>Autor</b> bzw. eine <b>Beschreibung</b> zum Paket hinzufügen.<br><br>Wählen Sie die Module die Anpassungen zum Export enthalten. (Es werden nur Module mit existenten Anpassungen angezeigt.)<br><br>Klicken Sie auf <b>Export</b> um eine .zip Datei für das Paket zu erstellen, dass die Anpassungen enthält.',
	    'exportCustomBtn'=>'Klicken Sie auf <b>Export</b> um eine .zip Datei für das Paket zu erstellen, das Ihre Anpassungen enthält und das Sie exportieren wollen.',
	    'name'=>'Das ist der <b>Name</b> des Pakets. Der Name wird bei der Installation angezeigt.',
	    'author'=>'Dies ist der <b>Autor</b>, der während der Installation als der Name der Entität die das Paket erstellt hat, gezeigt wird. Der Autor kann eine Person oder eine Firma sein.',
	    'description'=>'Das ist die <b>Beschreibung</b> des Pakets die während der Installation angezeigt wird.',
	),
	'studioWizard'=>array(
		'mainHelp' 	=> 'Willkommen im Bereich für <b>Entwickler Werkzeuge</b1>.<br/><br/>Benutzen Sie die Werkzeuge in diesem Bereich um Standard- und angepasste Module und Felder zu bearbeiten bzw. zu erstellen.',
		'studioBtn'	=> 'Benutzen Sie das <b>Studio</b>, um installierte Module anzupassen indem Sie die Feldanordnung ändern, aus verfügbaren Felder auswählen oder neue Datenfelder erstellen.',
		'mbBtn'		=> 'Verwenden Sie den <b>Module Builder</b> um neue Module zu erstellen.',
		'appBtn' 	=> 'Verwenden Sie den Applikationsmodus um verschiedene Parameter des Programms zu verändern, zum Beispiel wie viele TPS Berichte auf der Homepage angezeigt werden.',
		'backBtn'	=> 'Zurück zum vorherigen Schritt.',
		'studioHelp'=> 'Benutzen Sie das <b>Studio</b>, um installierte Module anzupassen.',
		'moduleBtn'	=> 'Klicken Sie um das Modul zu bearbeiten.',
		'moduleHelp'=> 'Wählen Sie die Modulkomponente die Sie bearbeiten möchten.',
		'fieldsBtn'	=> 'Definieren Sie über die Kontrolle der <b>Felder</b>, welche Informationen in dem Modul gespeichert werden.<br/><br/>Sie können hier benutzerdefinierte Felder erstellen und ändern.',
		'labelsBtn' => 'Drücken Sie auf <b>Speichern</b> um die benutzerdefinierten Bezeichnungen zu speichern.'	,
		'layoutsBtn'=> 'Passen Sie die <b>Layouts</b> der Bearbeitungs-, Detail-, Listen- und Suchansichten an..',
		'subpanelBtn'=> 'Bearbeiten Sie, welche Information in den Subpanels dieses Moduls gezeigt wird',
		'layoutsHelp'=> 'Wählen Sie ein <b>Layout zum Bearbeiten</b>.<br/<br/>Um ein Layout zu ändern das Eingabefelder enthält, klicken Sie auf <b>Bearbeitungsansicht</b>.<br/><br/>Um ein Layout zu ändern dass vorher eingegebene Daten darstellt, klicken Sie auf  <b>Detailansicht</b>.<br/><br/>Um die Spalten zu ändern die in der Standardliste erscheinen, klicken Sie auf <b>Listenansicht</b>.<br/><br/>Um die Standard und erweiterten Suchformulare zu ändern, klicken Sie auf <b>Suche</b>.',
		'subpanelHelp'=> 'Wählen Sie ein <b>Subpanel</b> zum Bearbeiten.',
		'searchHelp' => 'Wählen Sie ein <b>Suche</b> Layout zum Bearbeiten.',
		'labelsBtn'	=> 'Bearbeiten Sie die <b>Feldbezeichnungen</b> die für Werte in diesem Modul angezeigt werden sollen.',
        'newPackage'=>'Klicken Sie auf <b>Neues Paket</b> um ein neues Paket zu erstellen.',
        'mbHelp'    => '<b>Willkommen im Module Builder.</b><br/><br/>Benutzen Sie den <b>Module Builder</b> um Pakete zu erstellen, die benutzerdefinierte Module enthalten – basierend auf Standard oder angepassten Objekten<br/><br/>Um zu beginnen, klicken Sie auf <b>Neues Paket</b> um ein neues Paket zu erstellen oder wählen Sie ein Paket zum Bearbeiten aus.<br/><br/>Ein <b>Paket</b> ist ein Container für selbst erstellte Module die Teil eines Projekts sind . Das Paket kann ein oder mehrere benutzerdefinierte  <b>Module</b> enthalten, die eine Relation untereinander oder zu existierenden Modulen haben können.<br/><br/>Zum Beispiel könnten Sie ein einzelnes Modul erstellen, dass mit dem Standard Firmenmodul verknüpft ist. Oder Sie erstellen ein Paket mit mehreren Modulen die als Projekt zusammen arbeiten, und untereinander sowie zu bereits existierenden Modulen verbunden sind.',
        'exportBtn' => 'Klicken Sie auf <b>Anpassungen exportieren</b> um ein Paket zu erstellen, dass die im Studio erstellten Anpassungen für spezifische Module enthält.',
	),


),
//HOME
'LBL_HOME_EDIT_DROPDOWNS'=>'Auswahllisten bearbeiten',

//ASSISTANT
'LBL_AS_SHOW' => 'Assistenten in Zukunft anzeigen.',
'LBL_AS_IGNORE' => 'Assistenten in Zukunft ignorieren.',
'LBL_AS_SAYS' => 'Assistent sagt:',


//STUDIO2
'LBL_MODULEBUILDER'=>'Modul Builder',
'LBL_STUDIO' => 'Studio',
'LBL_DROPDOWNEDITOR' => 'Auswahllisten bearbeiten',
'LBL_DEVELOPER_TOOLS' => 'Entwickler Werkzeuge',
'LBL_SUGARPORTAL' => 'Sugar Portal Editor',
'LBL_SYNCPORTAL' => 'Portal Synchronieren',
'LBL_PACKAGE_LIST' => 'Paket Liste',
'LBL_HOME' => 'Home',
'LBL_NONE'=>'-Kein(e)-',

'LBL_ADD_FIELDS'=>'Benutzerdefinierte Felder hinzufügen',
'LBL_AVAILABLE_SUBPANELS'=>'Verfügbare Subpanels',
'LBL_ADVANCED'=>'Erweitert',
'LBL_ADVANCED_SEARCH'=>'Erweiterte Suche',
'LBL_BASIC'=>'Einfach',
'LBL_BASIC_SEARCH'=>'Einfache Suche',
'LBL_CURRENT_LAYOUT'=>'Aktuelles Layout',
'LBL_DISPLAY_HTML'=>'HTML Code zeigen',
'LBL_DETAILVIEW'=>'Detailansicht',
'LBL_DROP_HERE' => '[Hierher ziehen]',
'LBL_EDIT'=>'Bearbeiten',
'LBL_EDIT_LAYOUT'=>'Layout bearbeiten',
'LBL_EDIT_ROWS'=>'Zeilen bearbeiten',
'LBL_EDIT_COLUMNS'=>'Spalten bearbeiten',
'LBL_EDIT_LABELS'=>'Bezeichnungen bearbeiten',
'LBL_EDIT_FIELDS'=>'Benutzerfelder bearbeiten',
'LBL_EDIT_PORTAL'=>'Portal bearbeiten für',
'LBL_EDIT_FIELDS'=>'Felder bearbeiten',
'LBL_EDITVIEW'=>'Bearbeitungsansicht',
'LBL_FILLER'=>'(filler)',
'LBL_FIELDS'=>'Felder',
'LBL_FAILED_TO_SAVE' => 'Fehler beim Speichern',
'LBL_FAILED_PUBLISHED' => 'Fehler beim Veröffentlichen',
'LBL_LAYOUT_PREVIEW'=>'Layout Vorschau',
'LBL_LAYOUTS'=>'Layouts',
'LBL_LISTVIEW'=>'Listenansicht',
'LBL_MODULES'=>'Module',
'LBL_MODULE_TITLE' => 'Studio',
'LBL_NEW_PACKAGE' => 'Neues Paket',
'LBL_NEW_PANEL'=>'Neues Panel',
'LBL_NEW_ROW'=>'Neue Zeile',
'LBL_PUBLISHING' => 'Veröffentlichen ...',
'LBL_PUBLISHED' => 'Veröffentlicht',
'LBL_RELATIONSHIPS'=>'Beziehungen',
'LBL_SELECT_FILE'=> 'Datei auswählen',
'LBL_SAVE_LAYOUT'=> 'Layout speichern',
'LBL_SELECT_A_SUBPANEL' => 'Ein Subpanel auswählen',
'LBL_SELECT_SUBPANEL' => 'Subpanel auswählen',
'LBL_SUBPANELS' => 'Subpanels',
'LBL_SUBPANEL' => 'Subpanel',
'LBL_SEARCH_FORMS' => 'Suchformulare',
'LBL_SEARCH'=>'Suchen',
'LBL_STAGING_AREA' => 'Arbeitsbereich (Elemente hierher ziehen)',
'LBL_SUGAR_FIELDS_STAGE' => 'Sugar Felder (klicken Sie auf das Element um es zum Arbeitsbereich hinzuzufügen)',
'LBL_SUGAR_BIN_STAGE' => 'Sugar Bin (klicken Sie auf das Element um es zum Arbeitsbereich hinzuzufügen)',
'LBL_TOOLBOX' => 'Toolbox',
'LBL_VIEW_SUGAR_FIELDS' => 'Sugar Felder anzeigen',
'LBL_VIEW_SUGAR_BIN' => 'Sugar Bin anzeigen',
'LBL_QUICKCREATE' => 'Schnellerstellung',
'LBL_EDIT_DROPDOWNS' => 'Globale Auswahlliste bearbeiten',
'LBL_ADD_DROPDOWN' => 'Neuen globale Auswahlliste hinzufügen',
'LBL_BLANK' => '-leer-',
'LBL_TAB_ORDER' => 'Tab Reihenfolge',

'LBL_DROPDOWN_TITLE_NAME' => 'Auswahllisten Name:',
'LBL_DROPDOWN_LANGUAGE' => 'Auswahlliste Sprache:',
'LBL_DROPDOWN_ITEMS' => 'Auswahllisten Elemente',
'LBL_DROPDOWN_ITEM_NAME' => 'Elementname',
'LBL_DROPDOWN_ITEM_LABEL' => 'Anzeigebezeichnung',

//STUDIO QUESTIONS
'LBL_QUESTION_FUNCTION' => 'Wählen Sie eine Funktion oder Komponente aus.',
'LBL_QUESTION_MODULE1' => 'Wählen Sie ein Modul aus.',
'LBL_QUESTION_EDIT' => 'Wählen Sie ein Modul zum Bearbeiten aus.',
'LBL_QUESTION_LAYOUT' => 'Wählen Sie ein Layout zum Bearbeiten aus.',
'LBL_QUESTION_SUBPANEL' => 'Wählen Sie ein Subpanel zum Bearbeiten aus.',
'LBL_QUESTION_SEARCH' => 'Wählen Sie ein Such Layout zum Bearbeiten aus.',
'LBL_QUESTION_MODULE' => 'Wählen Sie eine Modulkomponente zum Bearbeiten aus.',
'LBL_QUESTION_PACKAGE' => 'Wählen Sie ein Paket zum Bearbeiten aus, oder erstellen ein neues.',
'LBL_QUESTION_EDITOR' => 'Werkzeug auswählen.',
'LBL_QUESTION_DROPDOWN' => 'Wählen Sie eine Auswahlliste zu Bearbeiten aus, oder erstellen Sie eine neue.',
//CUSTOM FIELDS
'LBL_RELATE_TO'=>'Verbinden mit',
'LBL_NAME'=>'Name',
'LBL_LABELS'=>'Bezeichnungen',
'LBL_MASS_UPDATE'=>'Massenänderung',
'LBL_AUDITED'=>'Audit',
'LBL_CUSTOM_MODULE'=>'Module',
'LBL_DEFAULT_VALUE'=>'Standard Wert',
'LBL_REQUIRED'=>'Erforderlich',
'LBL_DATA_TYPE'=>'Typ:',
'LBL_HCUSTOM'=>'CUSTOM',
'LBL_HDEFAULT'=>'DEFAULT',
'LBL_LANGUAGE'=>'Sprache:',


//SECTION
'LBL_SECTION_EDLABELS' => 'Bezeichnungen bearbeiten',
'LBL_SECTION_PACKAGES' => 'Pakete',
'LBL_SECTION_PACKAGE' => 'Paket',
'LBL_SECTION_MODULES' => 'Module',
'LBL_SECTION_PORTAL' => 'Portal',
'LBL_SECTION_DROPDOWNS' => 'Auswahllisten',
'LBL_SECTION_PROPERTIES' => 'Eigenschaften',
'LBL_SECTION_DROPDOWNED' => 'Auswahllisten bearbeiten',
'LBL_SECTION_HELP' => 'Hilfe',
'LBL_SECTION_ACTION' => 'Aktion',
'LBL_SECTION_MAIN' => 'Wichtig',
'LBL_SECTION_EDPANELLABEL' => 'Panel Bezeichung bearbeiten',
'LBL_SECTION_FIELDEDITOR' => 'Feld Editor',
'LBL_SECTION_DEPLOY' => 'Veröffentlichen',
'LBL_SECTION_MODULE' => 'Module',
//WIZARDS

//LIST VIEW EDITOR
'LBL_DEFAULT'=>'Standard',
'LBL_HIDDEN'=>'Verborgen',
'LBL_AVAILABLE'=>'Verfügbar',
'LBL_LISTVIEW_DESCRIPTION'=>'Unten werden drei Spalten angezeigt. Die <b>Standard</b> Spalte enthält Felder, die als Standard in der Listendarstellung angezeigt werden.  Die <b>Zusätzlich</b> Spalte enthält Felder, die der Benutzer auswählen kann, um die Listendarstellung zu ändern.  Die <b>Verfügbar</b> Spalte enthält Felder die Sie als Admin zu den beiden anderen Spalten hinzufügen können',
'LBL_LISTVIEW_EDIT'=>'Listenansicht Editor',

//Manager Backups History
'LBL_MB_PREVIEW'=>'Vorschau',
'LBL_MB_RESTORE'=>'Wiederherstellen',
'LBL_MB_DELETE'=>'Löschen',
'LBL_MB_COMPARE'=>'Vergleichen',

//END WIZARDS

//BUTTONS
'LBL_BTN_ADD'=>'Hinzufügen',
'LBL_BTN_SAVE'=>'Speichern',
'LBL_BTN_SAVE_CHANGES'=>'Änderungen speichern',
'LBL_BTN_DONT_SAVE'=>'Änderungen verwerfen',
'LBL_BTN_CANCEL'=>'Abbrechen',
'LBL_BTN_UPLOAD'=>'Hochladen',
'LBL_BTN_SAVEPUBLISH'=>'Speichern & Veröffentlichen',
'LBL_BTN_NEXT'=>'Weiter',
'LBL_BTN_BACK'=>'Zurück',
'LBL_BTN_CLONE'=>'Klonen',
'LBL_BTN_ADDCOLS'=>'Spalten hinzufügen',
'LBL_BTN_ADDROWS'=>'Zeilen hinzufügen',
'LBL_BTN_ADDFIELD'=>'Feld hinzufügen',
'LBL_BTN_ADDDROPDOWN'=>'Auswahlliste hinzufügen',
'LBL_BTN_EDLABELS'=>'Bezeichnungen bearbeiten',
'LBL_BTN_UNDO'=>'Rückgängig',
'LBL_BTN_REDO'=>'Wiederholen',
'LBL_BTN_ADDCUSTOMFIELD'=>'Benutzerdefiniertes Feld hinzufügen',
'LBL_BTN_EXPORT'=>'Anpassungen exportieren',
'LBL_BTN_DUPLICATE'=>'Duplizieren',
'LBL_BTN_PUBLISH'=>'Publizieren',
'LBL_BTN_DEPLOY'=>'Veröffentlichen',
'LBL_BTN_EXP'=>'Exportieren',
'LBL_BTN_DELETE'=>'Löschen',
'LBL_BTN_VIEW_LAYOUTS'=>'Layouts anzeigen',
'LBL_BTN_VIEW_FIELDS'=>'Felder anzeigen',
'LBL_BTN_VIEW_RELATIONSHIPS'=>'Beziehungen anzeigen',
'LBL_BTN_ADD_RELATIONSHIP'=>'Beziehung hinzufügen',
//TABS


//ERRORS
'ERROR_ALREADY_EXISTS'=> 'Fehler: Feld bereits vorhanden',
'ERROR_INVALID_KEY_VALUE'=> "Fehler: Ungültiger Schlüsselwert: [ \']",




//SUGAR PORTAL
'LBL_PORTAL'=>'Portal',
'LBL_SYNCP_WELCOME'=>'Bitte geben Sie die URL der Portal Instanz ein, die Sie aktualisieren wollen.',
'LBL_SP_UPLOADSTYLE'=>'Wählen Sie ein <b>Style Sheet</b> zum Hochladen von Ihrem Computer.<br><br>Dieses Stylesheet wird beim nächsten Sync im Sugar Portal implementiert.',
'LBL_SP_UPLOADED'=> 'Hochgeladen',
'ERROR_SP_UPLOADED'=>'Bitte sicherstellen, dass Sie ein css Style Sheet hochladen.',
'LBL_SP_PREVIEW'=>'Hier ist eine Vorschau, wie Ihr Sugar Portal beim Verwenden des Style Sheet aussehen wird.',
'LBL_PORTALSITE'=>'Sugar Portal URL: ',
'LBL_PORTAL_GO'=>'Start',
'LBL_UP_STYLE_SHEET'=>'Style Sheet hochladen',
'LBL_QUESTION_SUGAR_PORTAL' => 'Wählen Sie ein Sugar Portal Layout zum Bearbeiten aus.',
'LBL_QUESTION_PORTAL' => 'Wählen Sie ein Portal Layout zum Bearbeiten aus.',
'LBL_SUGAR_PORTAL'=>'Sugar Portal',

//PORTAL PREVIEW
'LBL_CASES'=>'Fälle',
'LBL_NEWSLETTERS'=>'Newsletter',
'LBL_BUG_TRACKER'=>'Fehlerverfolgung',
'LBL_MY_ACCOUNT'=>'Mein Konto',
'LBL_LOGOUT'=>'Abmelden',
'LBL_CREATE_NEW'=>'Neuen erstellen',
'LBL_LIST'=>'Liste',
'LBL_LOW'=>'Niedrig',
'LBL_MEDIUM'=>'Mittel',
'LBL_HIGH'=>'Hoch',
'LBL_NUMBER'=>'Nummer:',
'LBL_PRIORITY'=>'Priorität:',
'LBL_SUBJECT'=>'Betreff',
'LBL_DESCRIPTION'=>'Beschreibung:',




//PACKAGE AND MODULE BUILDER
'LBL_PACKAGE_NAME'=>'Paketname:',
'LBL_MODULE_NAME'=>'Modulname:',
'LBL_AUTHOR'=>'Autor:',
'LBL_DESCRIPTION'=>'Beschreibung:',
'LBL_KEY'=>'Schlüssel:',
'LBL_ADD_README'=>'Lies mich',
'LBL_MODULES'=>'Module:',
'LBL_LAST_MODIFIED'=>'Geändert am:',
'LBL_NEW_MODULE'=>'Neues Modul',
'LBL_LABEL'=>'Bezeichnung:',
'LBL_LABEL_TITLE'=>'Bezeichnung',
'LBL_WIDTH'=>'Breite',
'LBL_PACKAGE'=>'Paket:',
'LBL_TYPE'=>'Typ:',
'LBL_TEAM_SECURITY'=>'Team Kontrolle',
'LBL_ASSIGNABLE'=>'Zuweisbar',
'LBL_PERSON'=>'Person',
'LBL_COMPANY'=>'Firma',
'LBL_ISSUE'=>'Problem',
'LBL_NAV_TAB'=>'Navigations Tab',
'LBL_CREATE'=>'Erstellen',
'LBL_LIST'=>'Liste',
'LBL_LIST_VIEW'=>'Listenansicht',
'LBL_HISTORY'=>'Verlauf',
'LBL_ACTIVITIES'=>'Aktivitäten',
'LBL_SEARCH'=>'Suchen',
'LBL_NEW'=>'Neu',
'LBL_TYPE_BASIC'=>'einfach',
'LBL_TYPE_COMPANY'=>'Firma',
'LBL_TYPE_PERSON'=>'Person',
'LBL_TYPE_ISSUE'=>'Problem',
'LBL_RSUB'=>'Das ist das Subpanel das in Ihrem Modul angezeigt wird',
'LBL_MSUB'=>'Dies ist das Subpanel das von Ihrem Modul im verknünpfte Modul gezeigt wird.',

//EXPORT CUSTOMS
'LBL_EC_TITLE'=>'Anpassungen exportieren',
'LBL_EC_NAME'=>'Paketname:',
'LBL_EC_AUTHOR'=>'Autor:',
'LBL_EC_DESCRIPTION'=>'Beschreibung:',
'LBL_EC_KEY'=>'Schlüssel:',
'LBL_EC_CHECKERROR'=>'Wählen Sie ein Modul aus.',
'LBL_EC_CUSTOMFIELD'=>'Angepasste Feld(er)',
'LBL_EC_CUSTOMLAYOUT'=>'Angepasstes Layout(s)',
'LBL_EC_NOCUSTOM'=>'Kein Modul wurde angepasst.',
'LBL_EC_EMPTYCUSTOM'=>'hat keine Anpassungen.',
'LBL_EC_EXPORTBTN'=>'Exportieren',
'LBL_MODULE_DEPLOYED' => 'Das Modul wurde veröffentlicht.',
'LBL_UNDEFINED' => 'undefiniert',

//AJAX STATUS
'LBL_AJAX_FAILED_DATA' => 'Daten nicht erfolgreich geholt',
'LBL_AJAX_TIME_DEPENDENT' => 'Eine zeitabhängige Aktion wird gerade durchgeführt. Bitte warten und in ein paar Sekunden nochmals versuchen',
'LBL_AJAX_LOADING' => 'Lade...',
'LBL_AJAX_DELETING' => 'Lösche...',
'LBL_AJAX_BUILDPROGRESS' => 'Aufbau läuft...',
'LBL_AJAX_DEPLOYPROGRESS' => 'Veröffentlichung läuft...',

//JS
'LBL_JS_REMOVE_PACKAGE' => 'Sind Sie sicher das Sie diese Paket löschen wollen? Dies löscht alle Dateien die mit diiesem Paket verbunden sind.',

'LBL_DEPLOY_IN_PROGRESS' => 'Paket wird veröffentlicht',
'LBL_JS_VALIDATE_NAME'=>'Name – Muss alphanumerisch ohne Leerzeichen sein und mit einem Buchstaben beginnen.',
'LBL_JS_VALIDATE_LABEL'=>'Bitte geben Sie eine Bezeichnung ein die als Anzeigenamen für dies Modul verwendet wird.',
'LBL_JS_VALIDATE_TYPE'=>'Bitte wählen Sie den Modultyp, den Sie erstellen möchten, aus der Liste oben aus.',
'LBL_JS_VALIDATE_REL_NAME'=>'Name – Muss alphanumerisch ohne Leerzeichen sein',
'LBL_JS_VALIDATE_REL_LABEL'=>'Bezeichnung – Bitte wählen Sie eine Bezeichnung die oberhalb des Subpanels angezeigt wird.',

//CONFIRM
'LBL_CONFIRM_FIELD_DELETE'=>'Wenn Sie ein benutzerdefiniertes Feld löschen, werden alle zugehörigen Daten ebenfalls gelöscht. Allerdings müssen Sie dieses Feld auch aus allen Ansichten die es enthalten, entfernen.',
'LBL_CONFIRM_RELATIONSHIP_DELETE'=>'Sind Sie sicher dass Sie diese Beziehung löschen wollen?',
'LBL_CONFIRM_DONT_SAVE' => 'Seit dem letzten Speichern wurden Änderungen vorgenommen. Möchten Sie jetzt speichern?',
'LBL_CONFIRM_DONT_SAVE_TITLE' => 'Änderungen speichern?',
);

