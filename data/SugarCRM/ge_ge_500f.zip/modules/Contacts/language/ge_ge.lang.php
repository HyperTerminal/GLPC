<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
********************************************************************************/
/*********************************************************************************

* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_email2' => 'LBL_LIST_OTHER_EMAIL_ADDRESS',
    //END DON'T CONVERT

    'LNK_CONTACT_REPORTS' => 'Kontaktberichte',

    'ERR_DELETE_RECORD' => 'Um einen Kontakt zu löschen, muss die Nummer des Datensatzes angegeben werden.',
    'LBL_ACCOUNT_ID' => 'Firma ID',
    'LBL_ACCOUNT_NAME' => 'Firmenname:',
    'LBL_CAMPAIGN'     => 'Kampagne:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivitäten',
    'LBL_ADD_BUSINESSCARD' => 'Eingabe Visitenkarte',
    'LBL_ADDMORE_BUSINESSCARD' => 'Weitere Visitenkarte anlegen',
    'LBL_ADDRESS_INFORMATION' => 'Adressinformation',
    'LBL_ALT_ADDRESS_CITY' => '2. Adresse Stadt:',
    'LBL_ALT_ADDRESS_COUNTRY' => '2. Adresse Land:',
    'LBL_ALT_ADDRESS_POSTALCODE' => '2. Adresse PLZ:',
    'LBL_ALT_ADDRESS_STATE' => '2. Adresse Bundesland:',
    'LBL_ALT_ADDRESS_STREET_2' => '2. Adresse Strasse 2:',
    'LBL_ALT_ADDRESS_STREET_3' => '2. Adresse Strasse 3:',
    'LBL_ALT_ADDRESS_STREET' => '2. Adresse Strasse:',
    'LBL_ALTERNATE_ADDRESS' => 'Weitere Adresse:',
    'LBL_ANY_ADDRESS' => 'Irgendeine Adresse:',
    'LBL_ANY_EMAIL' => 'Irgendeine E-Mail:',
    'LBL_ANY_PHONE' => 'Irgendeine Telefonnummer:',
    'LBL_ASSIGNED_TO_NAME' => 'Zugewiesen an:',
    'LBL_ASSIGNED_TO_ID' => 'Zugew. Benutzer',
    'LBL_ASSISTANT_PHONE' => 'Telefonnr. Assistent:',
    'LBL_ASSISTANT' => 'Assistent:',
    'LBL_BIRTHDATE' => 'Geburtstag:',
    'LBL_BUSINESSCARD' => 'Visitenkarte',
    'LBL_CITY' => 'Stadt:',
    'LBL_CAMPAIGN_ID' => 'Kampagne ID',
    'LBL_CONTACT_INFORMATION' => 'Kontakt Information',
    'LBL_CONTACT_NAME' => 'Name:',
    'LBL_CONTACT_OPP_FORM_TITLE' => 'Kontakt-Verkaufschance:',
    'LBL_CONTACT_ROLE' => 'Beruf:',
    'LBL_CONTACT' => 'Kontakt:',
    'LBL_COUNTRY' => 'Land:',
    'LBL_CREATED_ACCOUNT' => 'Neue Firma angelegt',
    'LBL_CREATED_CALL' => 'Neuer Anruf angelegt',
    'LBL_CREATED_CONTACT' => 'Neuer Kontakt angelegt',
    'LBL_CREATED_MEETING' => 'Neues Meeting angelegt',
    'LBL_CREATED_OPPORTUNITY' =>'Neue Verkaufschance erstellt',
    'LBL_DATE_MODIFIED' => 'Geändert am:',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Kontakte',
    'LBL_DEPARTMENT' => 'Abteilung:',
    'LBL_DESCRIPTION_INFORMATION' => 'Beschreibungsinformation',
    'LBL_DESCRIPTION' => 'Beschreibung:',
    'LBL_DIRECT_REPORTS_SUBPANEL_TITLE'=>'Direkt-Unterstellte',
    'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
    'LBL_DUPLICATE' => 'Mögliche doppelte Kontakte',
    'LBL_EMAIL_ADDRESS' => 'E-Mail:',
    'LBL_EMAIL_OPT_OUT' => 'Keine E-Mails senden:',
    'LBL_EXISTING_ACCOUNT' => 'Vorhandene Firma ausgewählt',
    'LBL_EXISTING_CONTACT' => 'Vorhandener Kontakt ausgewählt',
    'LBL_EXISTING_OPPORTUNITY'=> 'Vorhandene Verkaufschance benutzt',
    'LBL_FAX_PHONE' => 'Fax:',
    'LBL_FIRST_NAME' => 'Vorname:',
    'LBL_FULL_NAME' => 'Ganzer Name:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf',
    'LBL_HOME_PHONE' => 'Privat:',
    'LBL_ID' => 'ID:',
    'LBL_IMPORT_VCARD' => 'vCard importieren',
    'LBL_VCARD' => 'vCard',
    'LBL_IMPORT_VCARDTEXT' => 'Durch Import einer vCard neuen Kontakt automatisch anlegen.',
    'LBL_INVALID_EMAIL'=>'Ungültige E-Mail:',
    'LBL_INVITEE' => 'Direkt-Unterstellte',
    'LBL_LAST_NAME' => 'Nachname:',
    'LBL_LEAD_SOURCE' => 'Quelle:',
    'LBL_LIST_ACCEPT_STATUS' => 'Status',
    'LBL_LIST_ACCOUNT_NAME' => 'Firmenname',
    'LBL_LIST_CONTACT_NAME' => 'Kontakt:',
    'LBL_LIST_CONTACT_ROLE' => 'Rolle',
    'LBL_LIST_EMAIL_ADDRESS' => 'E-Mail',
    'LBL_LIST_FIRST_NAME' => 'Vorname',
    'LBL_LIST_FORM_TITLE' => 'Kontakt Liste',
    'LBL_VIEW_FORM_TITLE' => 'Kontakt Ansicht',
    'LBL_LIST_LAST_NAME' => 'Nachname',
    'LBL_LIST_NAME' => 'Name',
    'LBL_LIST_OTHER_EMAIL_ADDRESS' => 'Weitere E-Mail',
    'LBL_LIST_PHONE' => 'Telefon Büro',
    'LBL_LIST_TITLE' => 'Titel',
    'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
    'LBL_MODIFIED' => 'Geändert von:',
    'LBL_MODULE_NAME' => 'Kontakte',
    'LBL_MODULE_TITLE' => 'Kontakte: Home',
    'LBL_NAME' => 'Name:',
    'LBL_NEW_FORM_TITLE' => 'Neuer Kontakt',
    'LBL_NEW_PORTAL_PASSWORD' => 'Neues Portal Passwort:',
    'LBL_NOTE_SUBJECT' =>'Betreff Notiz',
    'LBL_OFFICE_PHONE' => 'Bürotelefon:',
    'LBL_OPP_NAME' => 'Verkaufschance Name:',
    'LBL_OPPORTUNITY_ROLE_ID'=>'Verkaufschance Rollen ID:',
    'LBL_OPPORTUNITY_ROLE'=>'Verkaufschance Rolle',
    'LBL_OTHER_EMAIL_ADDRESS' => 'Weitere E-Mail:',
    'LBL_OTHER_PHONE' => 'Weiteres Telefon:',
    'LBL_PHONE' => 'Telefon:',
    'LBL_PORTAL_ACTIVE' => 'Portal Aktiv:',
    'LBL_PORTAL_APP'=>'Portal Anwendung',
    'LBL_PORTAL_INFORMATION' => 'Portal Information',
    'LBL_PORTAL_NAME' => 'Portal Name:',
    'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Password ist gesetzt:',
    'LBL_POSTAL_CODE' => 'PLZ:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Hauptadresse Stadt:',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Hauptadresse Land:',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Hauptadresse PLZ:',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Hauptadresse Bundesland:',
    'LBL_PRIMARY_ADDRESS_STREET_2' => 'Hauptadresse Strasse 2:',
    'LBL_PRIMARY_ADDRESS_STREET_3' => 'Hauptadresse Strasse 3:',
    'LBL_PRIMARY_ADDRESS_STREET' => 'Hauptadresse Strasse:',
    'LBL_PRIMARY_ADDRESS' => 'Hauptadresse:',
    'LBL_PRODUCTS_TITLE'=>'Produkte',
    'LBL_RELATED_CONTACTS_TITLE'=>'Verknüpfte Kontakte',
    'LBL_REPORTS_TO_ID'=>'Berichtet an ID',
    'LBL_REPORTS_TO' => 'Berichtet an:',
    'LBL_RESOURCE_NAME' => 'Ressourcenname',
    'LBL_SALUTATION' => 'Anrede:',
    'LBL_SAVE_CONTACT' => 'Kontakt speichern',
    'LBL_SEARCH_FORM_TITLE' => 'Kontakte Suche',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Markierte Kontakte auswählen',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Markierte Kontakte auswählen',
    'LBL_STATE' => 'Bundesland:',
    'LBL_SYNC_CONTACT' => 'Sync mit Outlook®:',

    'LBL_TEAM_ID' => 'Team ID:',

    'LBL_TITLE' => 'Titel:',
    'LNK_CONTACT_LIST' => 'Kontakte',
    'LNK_IMPORT_VCARD' => 'vCard importieren',
    'LNK_NEW_ACCOUNT' => 'Neue Firma',
    'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
    'LNK_NEW_CALL' => 'Neuer Anruf',
    'LNK_NEW_CASE' => 'Neuer Fall',
    'LNK_NEW_CONTACT' => 'Neuer Kontakt',
    'LNK_NEW_EMAIL' => 'E-Mail archivieren',
    'LNK_NEW_MEETING' => 'Neues Meeting',
    'LNK_NEW_NOTE' => 'Neue Notiz',
    'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
    'LNK_NEW_TASK' => 'Neue Aufgabe',
    'LNK_SELECT_ACCOUNT' => "Firma auswählen",
    'MSG_DUPLICATE' => 'Dieser Kontakt könnte bereits existieren (Duplikat!). Sie können entweder einen Kontakt aus der untenstehenden Liste auswählen oder auf Speichern klicken und den neuen Kontakt  mit den zuvor eingegebenen Daten erstellen.',
    'MSG_SHOW_DUPLICATES' => 'Dieser Kontakt könnte bereits existieren (Duplikat!). Sie können entweder einen Kontakt aus der untenstehenden Liste auswählen oder auf Speichern klicken und den neuen Kontakt  mit den zuvor eingegebenen Daten erstellen.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Weitere Adresse in Hauptadresse kopieren',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Hauptadresse in weitere Adresse kopieren',
    'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag löschen wollen?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Zum erstellen einer Verkaufschance benötigen Sie eine Firma. Bitte erstellen Sie eine Firma oder wählen Sie eine existierende aus.',
    'NTC_REMOVE_CONFIRMATION' => 'Möchten Sie diesen Kontakt wirklich von diesem Fall entfernen?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Möchten Sie diesen Eintrag wirklich als direkten Bericht entfernen?',

	'LBL_USER_PASSWORD' => 'Passwort:',

	'LBL_LEADS_SUBPANEL_TITLE' => 'Interessenten',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE' => 'Verkaufschancen',

	'LBL_QUOTES_SUBPANEL_TITLE' => 'Angebote',
	'LBL_PRODUCTS_SUBPANEL_TITLE' => 'Produkte',

	'LBL_CASES_SUBPANEL_TITLE' => 'Fälle',
	'LBL_BUGS_SUBPANEL_TITLE' => 'Fehler',
	'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekte',
	'LBL_COPY_ADDRESS_CHECKED' => 'Adresse zu gewählten Kontakten kopieren',
	'LBL_TARGET_OF_CAMPAIGNS' => 'Kampagnen (Ziele von):',
	'LBL_CAMPAIGNS'	=>	'Kampagnen',
	'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagnen',
	'LBL_LIST_CITY' => 'Stadt',
	'LBL_LIST_STATE' => 'Bundesland',
	'LBL_HOMEPAGE_TITLE' => 'Meine Kontakte',


	'LBL_PORTAL_PASSWORD' => 'Portal Passwort',
	'LBL_CONFIRM_PORTAL_PASSWORD' => 'Portal Passwort bestätigen',

	'LBL_CHECKOUT_DATE'=>'Datum ausgecheckt',
)
?>
