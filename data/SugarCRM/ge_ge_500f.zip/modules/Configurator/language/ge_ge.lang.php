<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	'ADMIN_EXPORT_ONLY'=>'Nur ein Admin darf exportieren',
	'ADVANCED'=>'Erweitert',
	'CURRENT_LOGO'=>'Aktuelles Logo',
	'DEFAULT_CURRENCY_ISO4217'=>'ISO 4217 Währungs Code',
	'DEFAULT_CURRENCY_NAME'=>'Währungsname',
	'DEFAULT_CURRENCY_SYMBOL'=>'Währungssymbol',
	'DEFAULT_CURRENCY'=>'Standardwährung',
	'DEFAULT_DATE_FORMAT'=>'Standard Datumsformat',
	'DEFAULT_DECIMAL_SEP'					=> 'Dezimalzeichen',
	'DEFAULT_LANGUAGE'=>'Standardsprache',
	'DEFAULT_NUMBER_GROUPING_SEP'			=> '1000er Trennzeichen',
	'DEFAULT_SYSTEM_SETTINGS'=>'Benutzer Interface',
	'DEFAULT_THEME'=> 'Standard Theme',
	'DEFAULT_TIME_FORMAT'=>'Standard Zeitformat',
	'DISABLE_EXPORT'=>'Exporte deaktivieren',
	'DISPLAY_LOGIN_NAV'=>'Tabs auf dem Login Screen anzeigen',
	'DISPLAY_RESPONSE_TIME'=>'Server Antwortzeiten anzeigen',
	'EXPORT'=>'Exportieren',
	'EXPORT_CHARSET' => 'Standard Export Zeichensatz',
	'EXPORT_DELIMITER' => 'Export Trennzeichen',
	'IMAGES'=>'Logos',
	'LBL_CONFIGURE_SETTINGS_TITLE' => 'Systemeinstellungen',
	'LBL_ENABLE_MAILMERGE' => 'Serienbriefe aktivieren?',
	'LBL_LOGVIEW' => 'Log Einstellungen konfigurieren',
	'LBL_MAIL_SMTPAUTH_REQ'				=> 'SMTP Authentfiizierung verwenden?',
	'LBL_MAIL_SMTPPASS'					=> 'SMTP Passwort:',
	'LBL_MAIL_SMTPPORT'					=> 'SMTP Port:',
	'LBL_MAIL_SMTPSERVER'				=> 'SMTP Server:',
	'LBL_MAIL_SMTPUSER'					=> 'SMTP User-Name:',
	'LBL_MAILMERGE_DESC' => 'Diese Option sollte nur markiert sein, wenn Sie das Sugar Plug-in für Microsoft® Word® besitzen.',
	'LBL_MAILMERGE' => 'Serienbrief',
	'LBL_MODULE_NAME'=>'Systemeinstellungen',
    'LBL_MODULE_ID'  => 'Konfigurator',
	'LBL_MODULE_TITLE'=>'Benutzer Interface',
	'LBL_NOTIFY_FROMADDRESS' => '\'Von\' Adresse:',
	'LBL_NOTIFY_SUBJECT' => 'E-Mail Betreff:',
	'LBL_PORTAL_ON_DESC' => 'Erlaubt es einem externen Kunden auf Fälle, Notizen und andere Daten über das Selbstbedienungsportal zuzugreifen.',
	'LBL_PORTAL_ON' => 'Selbstbedienungsportal Integration einschalten?',
	'LBL_PORTAL_TITLE' => 'Kunden Selbstbedienungsportal',
	'LBL_PROXY_AUTH'=>'Zugangsinformationen?',
	'LBL_PROXY_HOST'=>'Proxy Host',
	'LBL_PROXY_ON_DESC'=>'Proxy Server Adresse und Authentifizierungs Einstellungen konfigurieren',
	'LBL_PROXY_ON'=>'Proxy Server verwenden',
	'LBL_PROXY_PASSWORD'=>'Passwort',
	'LBL_PROXY_PORT'=>'Port',
	'LBL_PROXY_TITLE'=>'Proxy Einstellungen',
	'LBL_PROXY_USERNAME'=>'Benutzername',
	'LBL_RESTORE_BUTTON_LABEL'=>'Wiederherstellen',
	'LBL_SKYPEOUT_ON_DESC' => 'Ermöglicht es Benutzern auf Telefon Nummer zu klicken um Anrufe direkt mit SkypeOut® zu tätigen. Die Nummer müssen korrekt formatiert sein. Dies heißt:  "+" "Ländervorwahl" "Telefon Nummer", Beispiel +49 (123) 123-4568." Für weitere Informationen beachten Sie die Skype FAQ auf <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>", like +1 (555) 555-1234. For more information, see the Skype FAQ at <a href="http://www.skype.com/help/faq/skypeout.html#calling" target="skype">skype&reg; faq</a>	',
	'LBL_SKYPEOUT_ON' => 'SkypeOut® Integration aktivieren?',
	'LBL_SKYPEOUT_TITLE' => 'SkypeOut®',
	'LBL_USE_REAL_NAMES'	=> 'Vollständigen Namen anzeigen (nicht Benutzername)',
	'LIST_ENTRIES_PER_LISTVIEW'=>'Anzahl Einträge pro Seite',
	'LIST_ENTRIES_PER_SUBPANEL'=>'Anzahl Einträge pro Seite auf Subpanels',
	'LOG_MEMORY_USAGE'=>'Memory Verbrauch loggen',
	'LOG_SLOW_QUERIES'=> 'Langsame Abfragen loggen',
    'NEW_LOGO'=>'Neues Logo hochladen (212x40 pixel)',
    'NEW_LOGO_HELP'=>'Das Bildformat kann entweder .jpg oder .png sein.<BR>Die empfohlene Größe ist 212x40 px.',
    'NEW_QUOTE_LOGO'=>'Neues Angebot Logo hochladen (867x74)',
    'NEW_QUOTE_LOGO_HELP'=>'Das verlangte Bildformat ist .jpg.<BR>Die empfohlene Größe ist 867x74 px.',
    'QUOTES_CURRENT_LOGO'=>'Aktuelles Logo in den Angeboten',
	'SLOW_QUERY_TIME_MSEC'=>'Grenzwert (in msec) damit eine Abfrage als langsam gilt',
	'STACK_TRACE_ERRORS'=>'Zeige stack trace of errors',
	'UPLOAD_MAX_SIZE'=>'Maximale Dateigröße beim Upload',
	'VERIFY_CLIENT_IP'=>'Benutzer IP Adresse validieren',
    'LOCK_HOMEPAGE' => 'Anpassung des Homepage Layouts durch Benutzer verhindern',
    'LOCK_SUBPANELS' => 'Anpassung der Subpanel Layouts durch Benutzer verhindern',
    'MAX_DASHLETS' => 'Maximale Anzahl Dashlets auf der Homepage',
	'SYSTEM_NAME'=>'Systemname',

    'LBL_OC_STATUS'                     => 'Standard Offline Client Status',
    'DEFAULT_OC_STATUS'                 => 'Offline Client standardmäßig aktivieren',
    'LBL_OC_STATUS_DESC' => 'Markieren Sie dieses Kästchen, wenn jeder Benutzer Zugang zum Offline Client haben soll. Andernfalls können Sie den Zugang auf Benutzerebene konfigurieren.',
    'SESSION_TIMEOUT' => 'Portal Sitzung Timeout',
    'SESSION_TIMEOUT_UNITS' => 'Sekunden',

    'LBL_LDAP_TITLE'=>'LDAP Authentifizierung Support',
    'LBL_LDAP_ENABLE'=>'LDAP aktiveren',
    'LBL_LDAP_SERVER_HOSTNAME'=> 'Server:',
    'LBL_LDAP_SERVER_PORT'=> 'Port Nummer:',    
    'LBL_LDAP_ADMIN_USER'=> 'Authentifizierter Benutzer:',
    'LBL_LDAP_ADMIN_USER_DESC'=>'Wird verwendet um nach dem Sugar Benutzer zu suchen. [Muss u.U. voll qualifiziert werden] Falls nicht angegeben wird anonym verbunden.',
    'LBL_LDAP_ADMIN_PASSWORD'=> 'Authentifiziertes  Passwort:',
    'LBL_LDAP_AUTO_CREATE_USERS'=>'Benutzer autom. erstellen:',
    'LBL_LDAP_BASE_DN'=>'Basis DN:',
    'LBL_LDAP_LOGIN_ATTRIBUTE'=>'Login Attribute:',
    'LBL_LDAP_BIND_ATTRIBUTE'=>'Bind Attribute:',
    'LBL_LDAP_BIND_ATTRIBUTE_DESC'=>'Um die LDAP Benutzerbeispiele zu binden:[<b>AD:</b> userPrincipalName] [<b>openLDAP:</b> userPrincipalName] [<b>Mac OS X:</b> uid]',
    'LBL_LDAP_LOGIN_ATTRIBUTE_DESC'=>'Um die LDAP Benutzerbeispiele zu suchen:[<b>AD:</b> userPrincipalName] [<b>openLDAP:</b> dn] [<b>Mac OS X:</b> dn]',
    'LBL_LDAP_SERVER_HOSTNAME_DESC'=>'Beispiel: ldap.example.com',
    'LBL_LDAP_SERVER_PORT_DESC'=>'Beispiel: 389',
    'LBL_LDAP_BASE_DN_DESC'=>'Beispiel: DC=SugarCRM,DC=com',
    'LBL_LDAP_AUTO_CREATE_USERS_DESC'=> 'Falls ein authentifizierter Benuzter nicht existiert, wird einer in Sugar erstellt.',
    'LBL_LDAP_ENC_KEY'	=> 'Kodierungsschlüssel:',
    'DEVELOPER_MODE'=>'Entwickler Modus:',
    'LBL_LDAP_ENC_KEY_DESC'	=> 'Für SOAP Authentifizierung bei Benutzung von LDAP.',
    'LDAP_ENC_KEY_NO_FUNC_DESC' => 'Die php_mcrypt muss in der php.ini aktiviert sein.',
    'LBL_ALL' => 'Alle',
    'LBL_MARK_POINT' => 'Markierungspunkt',
    'LBL_NEXT_' => 'Weiter>>',
    'LBL_REFRESH_FROM_MARK' => 'Ab Marke aktualisieren',
    'LBL_SEARCH' => 'Suche:',
    'LBL_REG_EXP' => 'Reg Exp:',
    'LBL_IGNORE_SELF' => 'Ignoriere Eigene:',
    'LBL_MARKING_WHERE_START_LOGGING'=>'Markieren von wo Logging gestartet wird',
    'LBL_DISPLAYING_LOG'=>'Log anzeigen',
    'LBL_YOUR_PROCESS_ID'=>'Ihre Prozess ID',
    'LBL_YOUR_IP_ADDRESS'=>'Ihre IP Adresse lautet',
    'LBL_IT_WILL_BE_IGNORED'=>'wird es ignoriert',
    'LBL_LOG_NOT_CHANGED'=>'Der Log wurde nicht geändert',
    'LBL_ALERT_JPG_IMAGE' => 'Das Dateiformat für das Bild muss JPEG sein. Laden Sie eine neue Datei mit der Endung .jpg hoch.',
    'LBL_ALERT_TYPE_IMAGE' => 'Das Dateiformat für das Bild muss JPEG oder PNG sein. Laden Sie eine neue Datei mit der Endung .jpg oder .png hoch.',
    'LBL_ALERT_SIZE_RATIO' => 'Das Seitenverhältnis des Bildes sollte zwischen 1:1 und 10:1 sein. Die Größe des Bildes wird geändert.',
    'LBL_ALERT_SIZE_RATIO_QUOTES' => 'Das Seitenverhältnis des Bildes muss zwischen 3:1 und 20:1 sein. Laden Sie eine neue Datei hoch.',
    'ERR_ALERT_FILE_UPLOAD' => 'Fehler während des Hochladens des Bildes.',
);


?>
