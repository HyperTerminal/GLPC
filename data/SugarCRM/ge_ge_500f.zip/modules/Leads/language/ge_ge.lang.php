<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
********************************************************************************/
/*********************************************************************************

* Description:  Defines the English language pack for the base application.
* Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
* All Rights Reserved.
* Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_last_name' => 'LBL_LIST_LAST_NAME',
    'db_first_name' => 'LBL_LIST_FIRST_NAME',
    'db_title' => 'LBL_LIST_TITLE',
    'db_email1' => 'LBL_LIST_EMAIL_ADDRESS',
    'db_account_name' => 'LBL_LIST_ACCOUNT_NAME',
    'db_email2' => 'LBL_LIST_EMAIL_ADDRESS',

    //END DON'T CONVERT
    'ERR_DELETE_RECORD' => 'Die Datensatznummer muss angegeben werden, um diesen Datensatz löschen zu können.',
    'LBL_ACCOUNT_DESCRIPTION'=> 'Firma Beschreibung',
    'LBL_ACCOUNT_ID'=>'Firma ID',
    'LBL_ACCOUNT_NAME' => 'Firmenname:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivitäten',
    'LBL_ADD_BUSINESSCARD' => 'vCard hinzufügen',
    'LBL_ADDRESS_INFORMATION' => 'Adressinformation',
    'LBL_ALT_ADDRESS_CITY' => '2. Adresse Ort',
    'LBL_ALT_ADDRESS_COUNTRY' => '2. Adresse Land',
    'LBL_ALT_ADDRESS_POSTALCODE' => '2. Adresse Postleitzahl',
    'LBL_ALT_ADDRESS_STATE' => '2. Adresse Bundesland',
    'LBL_ALT_ADDRESS_STREET_2' => '2. Adresse Strasse 2',
    'LBL_ALT_ADDRESS_STREET_3' => '2. Adresse Strasse 3',
    'LBL_ALT_ADDRESS_STREET' => '2. Adresse Strasse',
    'LBL_ALTERNATE_ADDRESS' => 'Weitere Adresse:',
    'LBL_ANY_ADDRESS' => 'Irgendeine Adresse:',
    'LBL_ANY_EMAIL' => 'Irgendeine E-Mail:',
    'LBL_ANY_PHONE' => 'Irgendeine Telefonnummer:',
    'LBL_ASSIGNED_TO_NAME' => 'Zugewiesen an',
    'LBL_ASSIGNED_TO_ID' => 'Zugewiesen an:',
    'LBL_BACKTOLEADS' => 'Zurück zu den Interessenten',
    'LBL_BUSINESSCARD' => 'Interessent umwandeln',
    'LBL_CITY' => 'Stadt:',
    'LBL_CONTACT_ID' => 'Kontakt ID',
    'LBL_CONTACT_INFORMATION' => 'Informationen',
    'LBL_CONTACT_NAME' => 'Name:',
    'LBL_CONTACT_OPP_FORM_TITLE' => 'Interessent:',
    'LBL_CONTACT_ROLE' => 'Beruf:',
    'LBL_CONTACT' => 'Interessent:',
    'LBL_CONVERTED_ACCOUNT'=>'Umgewandelt in Firma:',
    'LBL_CONVERTED_CONTACT' => 'Umgewandelt in Kontakt:',
    'LBL_CONVERTED_OPP'=>'Umgewandelt in Verkaufschance:',
    'LBL_CONVERTED'=> 'Umgewandelt',
    'LBL_CONVERTLEAD_BUTTON_KEY' => 'V',
    'LBL_CONVERTLEAD_TITLE' => 'Interessent umwandeln [Alt-V]',
    'LBL_CONVERTLEAD' => 'Interessent umwandeln',
    'LBL_COUNTRY' => 'Land:',
    'LBL_CREATED_ACCOUNT' => 'Neue Firma angelegt',
    'LBL_CREATED_CALL' => 'Neuer Anruf angelegt',
    'LBL_CREATED_CONTACT' => 'Neuer Kontakt angelegt',
    'LBL_CREATED_MEETING' => 'Neues Meeting angelegt',
    'LBL_CREATED_OPPORTUNITY' => 'Neue Verkaufschance erstellt',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Interessenten',
    'LBL_DEPARTMENT' => 'Abteilung:',
    'LBL_DESCRIPTION_INFORMATION' => 'Beschreibungsinformation',
    'LBL_DESCRIPTION' => 'Beschreibung:',
    'LBL_DO_NOT_CALL' => 'Nicht anrufen:',
    'LBL_DUPLICATE' => 'Ähnlicher Interessenten',
    'LBL_EMAIL_ADDRESS' => 'E-Mail:',
    'LBL_EMAIL_OPT_OUT' => 'Keine E-Mails senden:',
    'LBL_EXISTING_ACCOUNT' => 'Vorhandene Firma ausgewählt',
    'LBL_EXISTING_CONTACT' => 'Vorhandener Kontakt ausgewählt',
    'LBL_EXISTING_OPPORTUNITY' => 'Vorhandene Verkaufschance benutzt',
    'LBL_FAX_PHONE' => 'Fax:',
    'LBL_FIRST_NAME' => 'Vorname:',
    'LBL_FULL_NAME' => 'Ganzer Name:',
    'LBL_HISTORY_SUBPANEL_TITLE'=>'Verlauf',
    'LBL_HOME_PHONE' => 'Telefon privat:',
    'LBL_IMPORT_VCARD' => 'vCard importieren',
    'LBL_VCARD' => 'vCard',
    'LBL_IMPORT_VCARDTEXT' => 'Erstellen Sie einen neuen Interessenten, indem Sie eine vCard von Ihrem Computer importieren.',
    'LBL_INVALID_EMAIL'=>'Ungültige E-Mail:',
    'LBL_INVITEE' => 'Direkt-Unterstellte',
    'LBL_LAST_NAME' => 'Nachname:',
    'LBL_LEAD_SOURCE_DESCRIPTION' => 'Beschreibung Quelle:',
    'LBL_LEAD_SOURCE' => 'Quelle:',
    'LBL_LIST_ACCOUNT_NAME' => 'Firmenname',
    'LBL_LIST_CONTACT_NAME' => 'Name',
    'LBL_LIST_CONTACT_ROLE' => 'Rolle',
    'LBL_LIST_DATE_ENTERED' => 'Erstellt am:',
    'LBL_LIST_EMAIL_ADDRESS' => 'E-Mail',
    'LBL_LIST_FIRST_NAME' => 'Vorname',
    'LBL_VIEW_FORM_TITLE' => 'Interessenten Ansicht',    
    'LBL_LIST_FORM_TITLE' => 'Interessenten Liste',
    'LBL_LIST_LAST_NAME' => 'Nachname',
    'LBL_LIST_LEAD_SOURCE_DESCRIPTION' => 'Beschreibung Quelle',
    'LBL_LIST_LEAD_SOURCE' => 'Quelle',
    'LBL_LIST_MY_LEADS' => 'Meine Interessenten',
    'LBL_LIST_NAME' => 'Name',
    'LBL_LIST_PHONE' => 'Telefon Büro',
    'LBL_LIST_REFERED_BY' => 'Empfohlen von',
    'LBL_LIST_STATUS' => 'Status',
    'LBL_LIST_TITLE' => 'Titel',
    'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
    'LBL_MODULE_NAME' => 'Interessenten',
    'LBL_MODULE_TITLE' => 'Interessenten: Home',
    'LBL_NAME' => 'Name:',
    'LBL_NEW_FORM_TITLE' => 'Neuer Interessent',
    'LBL_NEW_PORTAL_PASSWORD' => 'Neues Portal Passwort:',
    'LBL_OFFICE_PHONE' => 'Bürotelefon:',
    'LBL_OPP_NAME' => 'Verkaufschance Name:',
    'LBL_OPPORTUNITY_AMOUNT' => 'Verkaufschance Betrag:',
    'LBL_OPPORTUNITY_ID'=>'Verkaufschance ID',
    'LBL_OPPORTUNITY_NAME' => 'Verkaufschance Name:',
    'LBL_OTHER_EMAIL_ADDRESS' => 'Weitere E-Mail:',
    'LBL_OTHER_PHONE' => 'Weiteres Telefon:',
    'LBL_PHONE' => 'Telefon:',
    'LBL_PORTAL_ACTIVE' => 'Portal Aktiv:',
    'LBL_PORTAL_APP'=> 'Portal Anwendung',
    'LBL_PORTAL_INFORMATION' => 'Portal Information',
    'LBL_PORTAL_NAME' => 'Portal Name:',
    'LBL_PORTAL_PASSWORD_ISSET' => 'Portal Password ist gesetzt:',
    'LBL_POSTAL_CODE' => 'PLZ:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Hauptadresse Ort',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Hauptadresse Land',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Hauptadresse PLZ',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Hauptadresse Bundesland',
    'LBL_PRIMARY_ADDRESS_STREET_2'=>'Hauptadresse Strasse 2',
    'LBL_PRIMARY_ADDRESS_STREET_3'=>'Hauptadresse Strasse 3',   
    'LBL_PRIMARY_ADDRESS_STREET' => 'Hauptadresse Strasse',
    'LBL_PRIMARY_ADDRESS' => 'Hauptadresse:',
    'LBL_REFERED_BY' => 'Empfohlen von:',
    'LBL_REPORTS_TO_ID'=>'Berichtet an ID',
    'LBL_REPORTS_TO' => 'Berichtet an:',
    'LBL_SALUTATION' => 'Anrede',
    'LBL_MODIFIED'=>'Geändert von',
	'LBL_MODIFIED_ID'=>'Geändert von ID',
	'LBL_CREATED'=>'Erstellt von:',
	'LBL_CREATED_ID'=>'Erstellt von ID:',    
    'LBL_SEARCH_FORM_TITLE' => 'Interessenten Suche',
    'LBL_SELECT_CHECKED_BUTTON_LABEL' => 'Markierte Interessenten auswählen',
    'LBL_SELECT_CHECKED_BUTTON_TITLE' => 'Markierte Interessenten auswählen',
    'LBL_STATE' => 'Bundesland:',
    'LBL_STATUS_DESCRIPTION' => 'Beschreibung:',
    'LBL_STATUS' => 'Status:',
    'LBL_TITLE' => 'Titel:',
    'LNK_IMPORT_VCARD' => 'vCard importieren',
    'LNK_LEAD_LIST' => 'Interessenten',
    'LNK_NEW_ACCOUNT' => 'Neue Firma',
    'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
    'LNK_NEW_CONTACT' => 'Neuer Kontakt',
    'LNK_NEW_LEAD' => 'Neuer Interessent',
    'LNK_NEW_NOTE' => 'Neue Notiz oder Anlage',
    'LNK_NEW_OPPORTUNITY' => 'Neue Verkaufschance',
    'LNK_SELECT_ACCOUNT' => 'Firma auswählen',
    'MSG_DUPLICATE' => 'Es wurden gleichlautende Interessenten gefunden. Bitte wählen Sie die Interessenten aus, die Sie mit diesem neu zu erstellenden Datensatz verbinden wollen. Anschließend drücken Sie auf Weiter.',
    'NTC_COPY_ALTERNATE_ADDRESS' => 'Weitere Adresse in Hauptadresse kopieren',
    'NTC_COPY_PRIMARY_ADDRESS' => 'Hauptadresse in weitere Adresse kopieren',
    'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag löschen wollen?',
    'NTC_OPPORTUNITY_REQUIRES_ACCOUNT' => 'Zum Erstellen einer Verkaufschance benötigen Sie eine Firma. Bitte erstellen Sie eine Firma oder wählen Sie eine existierende aus.',
    'NTC_REMOVE_CONFIRMATION' => 'Möchten Sie diesen Interessenten wirklich aus diesem Fall löschen?',
    'NTC_REMOVE_DIRECT_REPORT_CONFIRMATION' => 'Möchten Sie diesen Eintrag wirklich als direkten Bericht entfernen?',
    'LBL_CAMPAIGN_LIST_SUBPANEL_TITLE'=>'Kampagnen',
    'LBL_TARGET_OF_CAMPAIGNS'=>'Erfolgreiche Kampagne:',
    'LBL_TARGET_BUTTON_LABEL'=>'Gezielt',
    'LBL_TARGET_BUTTON_TITLE'=>'Gezielt',
    'LBL_TARGET_BUTTON_KEY'=>'T',
    'LBL_CAMPAIGN_ID'=>'Kampagnen ID',
    'LBL_CAMPAIGN' => 'Kampagne:',
  	'LBL_LIST_ASSIGNED_TO_NAME' => 'Zugew. Benutzer',  	

	'LNK_LEAD_REPORTS' => 'Interessentenberichte',

    'LBL_THANKS_FOR_SUBMITTING_LEAD' =>'Vielen Dank für die Eingabe.',
    'LBL_SERVER_IS_CURRENTLY_UNAVAILABLE' =>'Es tut uns leid, der Server ist im Moment nicht erreichbar, versuchen Sie es bitte später noch einmal.',
    'LBL_ASSISTANT_PHONE' => 'Telefon Assistent(in)',
    'LBL_ASSISTANT' => 'Assistent(in)',
);


?>
