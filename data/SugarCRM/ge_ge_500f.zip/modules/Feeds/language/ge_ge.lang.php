<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'RSS',
  'LBL_MODULE_ID' => 'Feeds',  
  'LBL_MODULE_TITLE' => 'RSS: Home',
  'LBL_SEARCH_FORM_TITLE' => 'RSS-Suche',
  'LBL_LIST_FORM_TITLE' => 'RSS-Liste',
  'LBL_MY_LIST_FORM_TITLE' => 'Meine RSS News Feeds',
  'LBL_NEW_FORM_TITLE' => 'Neuer RSS News Feed',
//END DON'T CONVERT
  'NTC_DELETE_CONFIRMATION' => 'Sind Sie sicher, dass Sie diesen Eintrag löschen wollen?',
  'ERR_DELETE_RECORD' => 'Um einen Kontakt zu löschen, muss die Nummer des Datensatzes angegeben werden.',
  'LNK_NEW_FEED' => 'Neuer RSS News Feed',
  'LNK_FEED_LIST' => 'Alle RSS News Feeds',
  'LNK_MY_FEED_LIST' => 'Meine RSS News Feeds',
  'LBL_TITLE' => 'Titel',
  'LBL_RSS_URL' => "RSS URL",
  'LBL_ONLY_MY'=>"Nur meine Favoriten",
  'LBL_VISIT_WEBSITE' => 'Webseite besuchen',
  'LBL_LAST_UPDATED' => 'Zuletzt bearbeitet am',
  'LBL_DELETE_FAVORITES' =>'Aus den Favoriten löschen',
  'LBL_DELETE_FAV_BUTTON_TITLE' =>'Aus den Favoriten löschen [Alt+D]',
  'LBL_DELETE_FAV_BUTTON_KEY' => '[Alt+D]',
  'LBL_DELETE_FAV_BUTTON_LABEL' =>'Aus den Favoriten löschen',
  'LBL_ADD_FAV_BUTTON_TITLE' =>'zu Favoriten hinzufügen [Alt+A]',
  'LBL_ADD_FAV_BUTTON_KEY' =>'[Alt+A]',
  'LBL_ADD_FAV_BUTTON_LABEL' =>'Zu Favoriten hinzufügen',
  'LBL_MOVE_UP' =>'Nach oben',
  'LBL_MOVE_DOWN' => 'Nach unten',
  'LBL_FEED_NOT_AVAILABLE'=>'Feed nicht verfügbar',
  'LBL_REFRESH_CACHE'=>'Hier klicken um Cache zu erneuern',
  'LBL_TILE'=>'Titel',
  'LBL_URL'=>'URL',
  'LBL_DESCRIPTION'=>'Beschreibung',
);


?>
