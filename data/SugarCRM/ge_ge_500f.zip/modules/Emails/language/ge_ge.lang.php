<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	'LBL_FW'					=> 'FW:',
	'LBL_RE'					=> 'RE:',

	'LBL_BUTTON_CREATE'					=> 'Erstellen',
	'LBL_BUTTON_EDIT'					=> 'Bearbeiten',
	'LBL_QS_DISABLED'                   => '(Schnellsuche ist für dieses Modul nicht verfügbar. Bitte verwenden Sie die \'Auswahl \' Schaltfläche.)',  
	'LBL_SIGNATURE_PREPEND'				=> 'Signatur oberhalb der Antwort?',
    'LBL_EMAIL_DEFAULT_DESCRIPTION' 	=> 'Hier ist das Angebot das Sie angefragt haben (Sie können diesen Text ändern)',
    'LBL_EMAIL_QUOTE_FOR' => 'Angebot für:',
    'LBL_QUOTE_LAYOUT_DOES_NOT_EXIST_ERROR' => 'Angebotsvorlagedatei exisitert nicht: $layout',
    'LBL_QUOTE_LAYOUT_REGISTERED_ERROR' => 'Angebotsvorlage ist nicht in Modules/Quotes/Layouts.php registriert',


	'LBL_CONFIRM_DELETE'		=> 'Möchten Sie diesen Ordner wirklich löschen?',

	'LBL_QUOTES_SUBPANEL_TITLE'	=> 'Angebote',
	'LBL_EMAILS_QUOTES_REL'		=> 'E-Mails: Angebote',
    'LBL_ERROR_SELECT_REPORT'   => 'Bitte einen Bericht auswählen',

	'ERR_ARCHIVE_EMAIL'			=> 'Fehler: E-Mails zum Archivieren auswählen.',
	'ERR_DATE_START'			=> 'Startdatum',
	'ERR_DELETE_RECORD'			=> 'Fehler: Um diese Firma zu löschen, muss eine Datensatznummer angegeben werden.',
	'ERR_NOT_ADDRESSED'			=> 'Fehler: E-Mail muss eine An:, CC: oder BCC: Adresse haben',
	'ERR_TIME_START'			=> 'Startzeit',
	'LBL_ACCOUNTS_SUBPANEL_TITLE'=> 'Firmen',
	'LBL_ADD_ANOTHER_FILE'		=> 'Weitere Datei hinzufügen',
    'LBL_ADD_DASHLETS'          => 'Dashlets hinzufügen',
	'LBL_ADD_DOCUMENT'			=> 'Dokument aus Sugar hinzufügen',
	'LBL_ADD_ENTRIES'           => 'Einträge hinzufügen',
	'LBL_ADD_FILE'				=> 'Datei aus dem Dateisystem hinzufügen',
	'LBL_ARCHIVED_EMAIL'		=> 'Archivierte E-Mails',
	'LBL_ARCHIVED_MODULE_NAME'	=> 'Archivierte E-Mails',
	'LBL_ATTACHMENTS'			=> 'Anhänge:',
	'LBL_BCC'					=> 'Bcc:',
	'LBL_BODY'					=> 'Text:',
	'LBL_BUGS_SUBPANEL_TITLE'	=> 'Fehler',
	'LBL_CC'					=> 'Cc:',
	'LBL_COLON'					=> ':',
	'LBL_COMPOSE_MODULE_NAME'	=> 'Neue E-Mail',
	'LBL_CONTACT_FIRST_NAME'	=> 'Kontakt Vorname',
	'LBL_CONTACT_LAST_NAME'		=> 'Kontakt Nachname',
	'LBL_CONTACT_NAME'			=> 'Kontakt:',
	'LBL_CONTACTS_SUBPANEL_TITLE'=> 'Kontakte',
	'LBL_CREATED_BY'			=> 'Erstellt von:',
	'LBL_DATE_AND_TIME'			=> 'Sendetag & -zeit :',
	'LBL_DATE_SENT'				=> 'Sendetag:',
	'LBL_DATE'					=> 'Sendetag:',
    'LBL_DELETE_FROM_SERVER'    => 'Nachricht vom Server löschen',
	'LBL_DESCRIPTION'			=> 'Beschreibung',
	'LBL_EDIT_ALT_TEXT'			=> 'Als Text bearbeiten',
	'LBL_EDIT_MY_SETTINGS'		=> 'Meine Einstellungen bearbeiten',
	'LBL_EMAIL_ATTACHMENT'		=> 'E-Mail Anhang',
	'LBL_EMAIL_EDITOR_OPTION'	=> 'HTML E-Mails versenden',
	'LBL_EMAIL_SELECTOR'		=> 'Auswählen',
	'LBL_EMAIL'					=> 'E-Mail:',
	'LBL_EMAILS_ACCOUNTS_REL'	=> 'E-Mails:Firmen',
	'LBL_EMAILS_BUGS_REL'		=> 'E-Mails:Fehler',
	'LBL_EMAILS_CASES_REL'		=> 'E-Mails:Fälle',
	'LBL_EMAILS_CONTACTS_REL'	=> 'E-Mails:Kontakte',
	'LBL_EMAILS_LEADS_REL'		=> 'E-Mails:Interessenten',
	'LBL_EMAILS_OPPORTUNITIES_REL'=> 'E-Mails:Verkaufschancen',
    'LBL_EMAILS_NOTES_REL'      => 'E-Mails:Notizen',
	'LBL_EMAILS_PROJECT_REL'	=> 'E-Mails:Projekt',
	'LBL_EMAILS_PROJECT_TASK_REL'=> 'E-Mails:Projektaufgabe',
	'LBL_EMAILS_PROSPECT_REL'	=> 'E-Mails:Zielkontakt',
	'LBL_EMAILS_TASKS_REL'		=> 'E-Mails:Aufgaben',
	'LBL_EMAILS_USERS_REL'		=> 'E-Mails:Benutzer',
	'LBL_ERROR_SENDING_EMAIL'	=> 'Fehler beim Senden der E-Mail',
	'LBL_FORWARD_HEADER'		=> 'Anfang weitergeleitete Nachricht:',
	'LBL_FROM_NAME'				=> 'Von Name',
	'LBL_FROM'					=> 'Von:',
	'LBL_HTML_BODY'				=> 'HTML Body',
	'LBL_INVITEE'				=> 'Empfänger',
	'LBL_LEADS_SUBPANEL_TITLE'	=> 'Interessenten',
	'LBL_MESSAGE_SENT'			=> 'Mail gesendet',
	'LBL_MODIFIED_BY'			=> 'Geändert von',
	'LBL_MODULE_NAME_NEW'		=> 'E-Mail archivieren',
	'LBL_MODULE_NAME'			=> 'E-Mails',
	'LBL_MODULE_TITLE'			=> 'E-Mails:',
	'LBL_NEW_FORM_TITLE'		=> 'E-Mail archivieren',
	'LBL_NONE'                  => 'Kein(e)',
	'LBL_NOT_SENT'				=> 'Sende-Fehler',
	'LBL_NOTE_SEMICOLON'		=> 'Bemerkung: Verwenden Sie Kommas oder Semikolons als Trennzeichen für mehrere E-Mail Adressen.',
	'LBL_NOTES_SUBPANEL_TITLE'	=> 'Anhänge',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Verkaufschancen',
	'LBL_PROJECT_SUBPANEL_TITLE'=> 'Projekte',
	'LBL_PROJECT_TASK_SUBPANEL_TITLE'=> 'Projektaufgaben',
    'LBL_RAW'                  => 'Unbearbeitetes Mail',
	'LBL_SAVE_AS_DRAFT_BUTTON_KEY'=> 'Entwurf speichern [Alt+R]',
	'LBL_SAVE_AS_DRAFT_BUTTON_LABEL'=> 'Entwurf speichern',
	'LBL_SAVE_AS_DRAFT_BUTTON_TITLE'=> 'Entwurf speichern',
	'LBL_SEARCH_FORM_DRAFTS_TITLE'=> 'Entwürfe durchsuchen',
	'LBL_SEARCH_FORM_SENT_TITLE'=> 'Durchsuche gesendete E-Mails',
	'LBL_SEARCH_FORM_TITLE'		=> 'E-Mail Suche',
	'LBL_SEND_ANYWAYS'			=> 'Diese E-Mail hat kein Betreff. Trotzdem speichern/senden?',
	'LBL_SEND_BUTTON_KEY'		=> 'S',
	'LBL_SEND_BUTTON_LABEL'		=> 'Senden',
	'LBL_SEND_BUTTON_TITLE'		=> 'Versenden [Alt+S]',
	'LBL_SEND'					=> 'Versenden',
	'LBL_SENT_MODULE_NAME'		=> 'Gesendete E-Mail',
	'LBL_SHOW_ALT_TEXT'			=> 'Als Text zeigen',
	'LBL_SIGNATURE'				=> 'Unterschrift',
	'LBL_SUBJECT'				=> 'Betreff:',
	'LBL_TEXT_BODY'				=> 'Textkörper',
	'LBL_TIME'					=> 'Sendezeit:',
	'LBL_TO_ADDRS'				=> 'An',
	'LBL_USE_TEMPLATE'			=> 'Vorlage benutzen:',
	'LBL_USERS_SUBPANEL_TITLE'	=> 'Benutzer',
	'LBL_USERS'					=> 'Benutzer',

	'LNK_ALL_EMAIL_LIST'		=> 'E-Mails',
	'LNK_ARCHIVED_EMAIL_LIST'	=> 'Archivierte E-Mails',
	'LNK_CALL_LIST'				=> 'Anrufe',
	'LNK_DRAFTS_EMAIL_LIST'		=> 'Alle Entwürfe',
	'LNK_EMAIL_LIST'			=> 'E-Mails',
	'LBL_EMAIL_RELATE'          => 'Verbinden mit',
	'LNK_EMAIL_TEMPLATE_LIST'	=> 'E-Mail Vorlagen',
	'LNK_MEETING_LIST'			=> 'Meetings',
	'LNK_NEW_ARCHIVE_EMAIL'		=> 'E-Mail archivieren',
	'LNK_NEW_CALL'				=> 'Neuer Anruf',
	'LNK_NEW_EMAIL_TEMPLATE'	=> 'Neue E-Mail Vorlage',
	'LNK_NEW_EMAIL'				=> 'E-Mail archivieren',
	'LNK_NEW_MEETING'			=> 'Neues Meeting',
	'LNK_NEW_NOTE'				=> 'Neue Notiz oder Anlage',
	'LNK_NEW_SEND_EMAIL'		=> 'Neue E-Mail',
	'LNK_NEW_TASK'				=> 'Neue Aufgabe',
	'LNK_NOTE_LIST'				=> 'Notizen',
	'LNK_SENT_EMAIL_LIST'		=> 'Gesendete E-Mail',
	'LNK_TASK_LIST'				=> 'Aufgaben',
	'LNK_VIEW_CALENDAR'			=> 'Heute',

	'LBL_LIST_ASSIGNED'			=> 'Zugewiesen',
	'LBL_LIST_CONTACT_NAME'		=> 'Kontakt:',
	'LBL_LIST_CREATED'			=> 'Erstellt',
	'LBL_LIST_DATE_SENT'		=> 'Sendedatum',
	'LBL_LIST_DATE'				=> 'Sendedatum',
	'LBL_LIST_FORM_DRAFTS_TITLE'=> 'Entwurf',
	'LBL_LIST_FORM_SENT_TITLE'	=> 'Gesendete E-Mail',
	'LBL_LIST_FORM_TITLE'		=> 'E-Mail Liste',
	'LBL_LIST_FROM_ADDR'		=> 'Von',
	'LBL_LIST_RELATED_TO'		=> 'Gehört zu',
	'LBL_LIST_SUBJECT'			=> 'Betreff',
	'LBL_LIST_TIME'				=> 'Sendezeit',
	'LBL_LIST_TO_ADDR'			=> 'An',
	'LBL_LIST_TYPE'				=> 'Typ:',

	'NTC_REMOVE_INVITEE'		=> 'Möchten Sie diesen Empfänger wirklich von der E-Mail entfernen?',
	'WARNING_SETTINGS_NOT_CONF'	=> 'Warnung: Ihre E-Mail Einstellungen sind zum Senden von Mails nicht konfiguriert.',
	'WARNING_NO_UPLOAD_DIR'		=> 'Anhänge werde nicht funktionieren: Kein Wert für "upload_tmp_dir" gefunden. Bitte korrigieren Sie Ihre php.ini Datei.',
	'WARNING_UPLOAD_DIR_NOT_WRITABLE'	=> 'Anhänge werde nicht funktionieren: Ein inkorrekter oder unbrauchbarer Wert für "upload_tmp_dir" wurde gefunden. Bitte korrigieren Sie Ihre php.ini Datei.',

    // for All emails
    'LBL_BUTTON_RAW_TITLE'   => 'Unbearbeitete E-Mail anzeigen [Alt+E]',
    'LBL_BUTTON_RAW_KEY'     => 'e',
    'LBL_BUTTON_RAW_LABEL'   => 'Unbearbeitete anzeigen',
    'LBL_BUTTON_RAW_LABEL_HIDE' => 'Unbearbeitete verbergen',

	// for InboundEmail
	'LBL_BUTTON_CHECK'			=> 'E-Mails holen',
	'LBL_BUTTON_CHECK_TITLE'	=> 'Auf neue E-Mails prüfen [Alt + C]',
	'LBL_BUTTON_CHECK_KEY'		=> 'c',
	'LBL_BUTTON_FORWARD'		=> 'Vorwärts',
	'LBL_BUTTON_FORWARD_TITLE'	=> 'Diese E-Mail weiterleiten [Alt + F]',
	'LBL_BUTTON_FORWARD_KEY'	=> 'f',
	'LBL_BUTTON_REPLY_KEY'		=> 'r',
	'LBL_BUTTON_REPLY_TITLE'	=> 'Antworten [Alt+R]',
	'LBL_BUTTON_REPLY'			=> 'Antworten',
	'LBL_CASES_SUBPANEL_TITLE'	=> 'Fälle',
	'LBL_INBOUND_TITLE'			=> 'Eingehende E-Mails',
	'LBL_INTENT'				=> 'Absicht',
	'LBL_MESSAGE_ID'			=> 'Nachricht ID',
	'LBL_REPLY_HEADER_1'		=> 'Am',
	'LBL_REPLY_HEADER_2'		=> 'geschrieben:',
	'LBL_REPLY_TO_ADDRESS'		=> 'Antwort-an Adresse',
	'LBL_REPLY_TO_NAME'			=> 'Antwort-an Name',

	'LBL_LIST_BUG'				=> 'Fehler',
	'LBL_LIST_CASE'				=> 'Fälle',
	'LBL_LIST_CONTACT'			=> 'Kontakte',
	'LBL_LIST_LEAD'				=> 'Interessenten',
	'LBL_LIST_TASK'				=> 'Aufgaben',
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Zugew. Benutzer',

	// for Inbox
	'LBL_ALL'					=> 'Alle',
	'LBL_ASSIGN_WARN'			=> 'Stellen Sie sicher, dass alle 2 Optionen gewählt sind.',
	'LBL_BACK_TO_GROUP'			=> 'Zurück zum Gruppen Posteingang',
	'LBL_BUTTON_DISTRIBUTE_KEY'	=> 'a',
	'LBL_BUTTON_DISTRIBUTE_TITLE'=> 'Zuweisen [Alt+A]',
	'LBL_BUTTON_DISTRIBUTE'		=> 'Zuweisen',
	'LBL_BUTTON_GRAB_KEY'		=> 't',
	'LBL_BUTTON_GRAB_TITLE'		=> 'Von Gruppe nehmen [Alt+T]',
	'LBL_BUTTON_GRAB'			=> 'Von Gruppe nehmen',
	'LBL_CREATE_BUG'			=> 'Neuer Fehler',
	'LBL_CREATE_CASE'			=> 'Neuer Fall',
	'LBL_CREATE_CONTACT'		=> 'Neuer Kontakt',
	'LBL_CREATE_LEAD'			=> 'Neuer Interessent',
	'LBL_CREATE_TASK'			=> 'Neue Aufgabe',
	'LBL_DIST_TITLE'			=> 'Aufgabe',
	'LBL_LOCK_FAIL_DESC'		=> 'Das gewählte Item ist momentan nicht verfügbar.',
	'LBL_LOCK_FAIL_USER'		=> 'hat Eigentum übernommen.',
	'LBL_MASS_DELETE_ERROR'		=> 'Es wurden keine Einträge zum löschen markiert.',
	'LBL_NEW'					=> 'Neu',
	'LBL_NEXT_EMAIL'			=> 'Nächster freier Eintrag',
	'LBL_NO_GRAB_DESC'			=> 'Es waren keine Elemente verfügbar. Versuchen Sie es später noch einmal.',
	'LBL_QUICK_REPLY'			=> 'Antworten',
	'LBL_REPLIED'				=> 'Beantwortet',
	'LBL_SELECT_TEAM'			=> 'Teams auswählen',
	'LBL_TAKE_ONE_TITLE'		=> 'Reps',
	'LBL_TITLE_SEARCH_RESULTS'	=> 'Suchergebnisse',
	'LBL_TO'					=> 'An:',
	'LBL_TOGGLE_ALL'			=> 'Alle umschalten',
	'LBL_UNKNOWN'				=> 'Unbekannt',
	'LBL_UNREAD_HOME'			=> 'Ungelesene E-Mails',
	'LBL_UNREAD'				=> 'Ungelesen',
	'LBL_USE_ALL'				=> 'Alle Suchergebnisse',
	'LBL_USE_CHECKED'			=> 'Nur markierte',
	'LBL_USE_MAILBOX_INFO'		=> 'Mailbox E-Mail benutzen',
	'LBL_USE'					=> 'Zuweisen:',
	'LBL_ASSIGN_SELECTED_RESULTS_TO' => 'Ausgewählte Resultate zuweisen an:',
	'LBL_USER_SELECT'			=> 'Benutzer auswählen',
	'LBL_USING_RULES'			=> 'Regeln verwenden:',
	'LBL_WARN_NO_DIST'			=> 'Keine Verteilmethode gewählt',
	'LBL_WARN_NO_USERS'			=> 'Keine Benutzer ausgewählt',

	'LBL_LIST_STATUS'			=> 'Status',
	'LBL_LIST_TITLE_GROUP_INBOX'=> 'Gruppen Posteingang',
	'LBL_LIST_TITLE_MY_DRAFTS'	=> 'Meine Entwürfe',
	'LBL_LIST_TITLE_MY_INBOX'	=> 'Mein Posteingang',
	'LBL_LIST_TITLE_MY_SENT'	=> 'Meine gesendeten E-Mails',
	'LBL_LIST_TITLE_MY_ARCHIVES'=> 'Meine archvierten E-mails',

	'LNK_CHECK_MY_INBOX'		=> 'Meine E-Mails überprüfen',
	'LNK_DATE_SENT'				=> 'Sendedatum',
	'LNK_GROUP_INBOX'			=> 'Gruppen Posteingang',
	'LNK_MY_DRAFTS'				=> 'Meine Entwürfe',
	'LNK_MY_INBOX'				=> 'Mein Posteingang',
	'LNK_QUICK_REPLY'			=> 'Antworten',
	'LNK_MY_ARCHIVED_LIST'		=> 'Mein Archiv',

	// advanced search
	'LBL_ASSIGNED_TO'			=> 'Zugewiesen an:',
	'LBL_MEMBER_OF'				=> 'Vorläufer',
	'LBL_QUICK_CREATE'			=> 'Schnellerfassung',
	'LBL_STATUS'				=> 'E-Mail Status:',
	'LBL_TYPE'					=> 'Typ:',
);
