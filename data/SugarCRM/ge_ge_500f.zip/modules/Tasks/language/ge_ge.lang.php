<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aufgaben',
  'LBL_TASK' => 'Aufgaben:',
  'LBL_MODULE_TITLE' => 'Aufgaben: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Aufgaben Suche',
  'LBL_LIST_FORM_TITLE' => 'Aufgaben Liste',
  'LBL_NEW_FORM_TITLE' => 'Neue Aufgabe',
  'LBL_NEW_FORM_SUBJECT' => 'Betreff:',
  'LBL_NEW_FORM_DUE_DATE' => 'Fällig am:',
  'LBL_NEW_FORM_DUE_TIME' => 'Fällig um:',
  'LBL_NEW_TIME_FORMAT' => '(24:00)',
  'LBL_LIST_CLOSE' => 'Schließen',
  'LBL_LIST_SUBJECT' => 'Betreff',
  'LBL_LIST_CONTACT' => 'Kontakt',
  'LBL_LIST_PRIORITY' => 'Priorität',
  'LBL_LIST_RELATED_TO' => 'Gehört zu',
  'LBL_LIST_DUE_DATE' => 'Fällig am',
  'LBL_LIST_DUE_TIME' => 'Fällig um:',
  'LBL_SUBJECT' => 'Betreff:',
  'LBL_STATUS' => 'Status:',
  'LBL_DUE_DATE' => 'Fällig am:',
  'LBL_DUE_TIME' => 'Fällig um:',
  'LBL_PRIORITY' => 'Priorität:',
  'LBL_COLON' => ':',
  'LBL_DUE_DATE_AND_TIME' => 'Erledigen bis:',
  'LBL_START_DATE_AND_TIME' => 'Startdatum und -zeit:',
  'LBL_START_DATE' => 'Startdatum:',
  'LBL_LIST_START_DATE' => 'Startdatum',
  'LBL_START_TIME' => 'Beginn:',
  'LBL_LIST_START_TIME' => 'Startzeit',  
  'DATE_FORMAT' => '(jjjj-mm-tt)',
  'LBL_NONE' => 'Kein(e)',
  'LBL_CONTACT' => 'Kontakt:',
  'LBL_EMAIL_ADDRESS' => 'E-Mail Adresse:',
  'LBL_PHONE' => 'Telefon:',
  'LBL_EMAIL' => 'E-Mail:',
  'LBL_DESCRIPTION_INFORMATION' => 'Beschreibungsinformation',
  'LBL_DESCRIPTION' => 'Beschreibung:',
  'LBL_NAME' => 'Name:',
  'LBL_CONTACT_NAME' => 'Kontakt:',
  'LBL_LIST_COMPLETE' => 'Abgeschlossen:',
  'LBL_LIST_STATUS' => 'Status',
  'LBL_DATE_DUE_FLAG' => 'Kein Fälligkeitsdatum',
  'LBL_DATE_START_FLAG' => 'Kein Startdatum',
  'ERR_DELETE_RECORD' => 'Die Nummer eines Eintrages muss angegeben werden um einen Kontakt zu löschen!',
  'ERR_INVALID_HOUR' => 'Bitte geben Sie eine Stunde zwischen 0 Uhr und 24 Uhr ein',
  'LBL_DEFAULT_STATUS' => 'Nicht begonnen',
  'LBL_DEFAULT_PRIORITY' => 'Mittel',
  'LBL_LIST_MY_TASKS' => 'Meine offenen Aufgaben',
  'LNK_NEW_CALL' => 'Neuer Anruf',
  'LNK_NEW_MEETING' => 'Neues Meeting',
  'LNK_NEW_TASK' => 'Neue Aufgabe',
  'LNK_NEW_NOTE' => 'Neue Notiz oder Anlage',
  'LNK_NEW_EMAIL' => 'E-Mail archivieren',
  'LNK_CALL_LIST' => 'Anrufe',
  'LNK_MEETING_LIST' => 'Meetings',
  'LNK_TASK_LIST' => 'Aufgaben',
  'LNK_NOTE_LIST' => 'Notizen',
  'LNK_EMAIL_LIST' => 'E-Mails',
  'LNK_VIEW_CALENDAR' => 'Heute',
  'LBL_CONTACT_FIRST_NAME'=>'Kontakt Vorname',
  'LBL_CONTACT_LAST_NAME'=>'Kontakt Nachname',
  'LBL_LIST_ASSIGNED_TO_NAME' => 'Zugew. Benutzer',
  'LBL_ASSIGNED_TO_NAME'=>'Zugewiesen an:'

);


?>
