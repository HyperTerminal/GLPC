<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_MODULE_NAME' => 'Mitarbeiter',
  'LBL_MODULE_TITLE' => 'Mitarbeiter: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Mitarbeiter suchen',
  'LBL_LIST_FORM_TITLE' => 'Mitarbeiter',
  'LBL_NEW_FORM_TITLE' => 'Neuer Mitarbeiter',
  'LBL_EMPLOYEE' => 'Mitarbeiter:',
  'LBL_LOGIN' => 'Anmelden',
  'LBL_RESET_PREFERENCES' => 'Zurücksetzen auf Voreinstellungen',
  'LBL_TIME_FORMAT' => 'Zeitformat:',
  'LBL_DATE_FORMAT' => 'Datumsformat:',
  'LBL_TIMEZONE' => 'Aktuelle Zeit',
  'LBL_CURRENCY' => 'Währung',
  'LBL_LIST_NAME' => 'Name',
  'LBL_LIST_LAST_NAME' => 'Nachname',
  'LBL_LIST_EMPLOYEE_NAME' => 'Mitarbeiter Name',
  'LBL_LIST_DEPARTMENT' => 'Abteilung',
  'LBL_LIST_REPORTS_TO_NAME' => 'Berichtet an',
  'LBL_LIST_EMAIL' => 'E-Mail',
  'LBL_LIST_PRIMARY_PHONE' => 'Telefon',
  'LBL_LIST_USER_NAME' => 'Benutzername',
  'LBL_LIST_ADMIN' => 'Admin',
  'LBL_NEW_EMPLOYEE_BUTTON_TITLE' => 'Neuer Mitarbeiter [Alt+N]',
  'LBL_NEW_EMPLOYEE_BUTTON_LABEL' => 'Neuer Mitarbeiter',
  'LBL_NEW_EMPLOYEE_BUTTON_KEY' => 'N',
  'LBL_ERROR' => 'Fehler:',
  'LBL_PASSWORD' => 'Passwort:',
  'LBL_EMPLOYEE_NAME' => 'Mitarbeiter Name:',
  'LBL_USER_NAME' => 'Benutzername:',
  'LBL_FIRST_NAME' => 'Vorname:',
  'LBL_LAST_NAME' => 'Nachname:',
  'LBL_EMPLOYEE_SETTINGS' => 'Mitarbeiter Einstellungen',
  'LBL_THEME' => 'Thema:',
  'LBL_LANGUAGE' => 'Sprache:',
  'LBL_ADMIN' => 'Administrator:',
  'LBL_EMPLOYEE_INFORMATION' => 'Mitarbeiter Information',
  'LBL_OFFICE_PHONE' => 'Bürotelefon:',
  'LBL_REPORTS_TO' => 'Berichtet an:',
  'LBL_OTHER_PHONE' => 'Andere:',
  'LBL_OTHER_EMAIL' => 'Weitere E-Mail:',
  'LBL_NOTES' => 'Notizen:',
  'LBL_DEPARTMENT' => 'Abteilung:',
  'LBL_TITLE' => 'Titel:',
  'LBL_ANY_PHONE' => 'Irgendeine Telefonnummer:',
  'LBL_ANY_EMAIL' => 'Irgendeine E-Mail:',
  'LBL_ADDRESS' => 'Adresse:',
  'LBL_CITY' => 'Stadt:',
  'LBL_STATE' => 'Bundesland:',
  'LBL_POSTAL_CODE' => 'PLZ:',
  'LBL_COUNTRY' => 'Land:',
  'LBL_NAME' => 'Name:',
  'LBL_MOBILE_PHONE' => 'Mobiltelefon:',
  'LBL_OTHER' => 'Andere:',
  'LBL_FAX' => 'Fax:',
  'LBL_EMAIL' => 'E-Mail:',
  'LBL_HOME_PHONE' => 'Telefon privat:',
  'LBL_ADDRESS_INFORMATION' => 'Adressinformation',
  'LBL_EMPLOYEE_STATUS' => 'Mitarbeiter Status:',
  'LBL_PRIMARY_ADDRESS' => 'Hauptadresse:',
  'LBL_CREATE_USER_BUTTON_TITLE' => 'Benutzer anlegen [Alt+N]',
  'LBL_CREATE_USER_BUTTON_LABEL' => 'Neuer Benutzer',
  'LBL_CREATE_USER_BUTTON_KEY' => 'N',
  'LBL_FAVORITE_COLOR' => 'Bevorzugte Farbe:',
  'LBL_MESSENGER_ID' => 'IM Name:',
  'LBL_MESSENGER_TYPE' => 'IM Typ:',
  'ERR_EMPLOYEE_NAME_EXISTS_1' => 'Der Name des Mitarbeiters',
  'ERR_EMPLOYEE_NAME_EXISTS_2' => ' ist schon vorhanden. <\T>Doppelte Mitarbeiternamen sind nicht zulässig.<\T> Ändern Sie den Mitarbeiternamen.',
  'ERR_LAST_ADMIN_1' => 'Der Name des Mitarbeiters "',
  'ERR_LAST_ADMIN_2' => '" ist der letzte Mitarbeiter mit Administratorzugriff. Mindestens ein Mitarbeiter muss Administratorstatus haben.',
  'LNK_NEW_EMPLOYEE' => 'Mitarbeiter erstellen',
  'LNK_EMPLOYEE_LIST' => 'Mitarbeiter',
  'ERR_DELETE_RECORD' => 'Es muss die Datensatznummer angegeben werden, um diesen Datensatz zu löschen.',

  'LBL_DEFAULT_TEAM' => 'Standard Team:',
  'LBL_DEFAULT_TEAM_TEXT' => 'Wählen Sie das Standard Team für neue Einträge',
  'LBL_MY_TEAMS' => 'Meine Teams',
  'LBL_LIST_DESCRIPTION' => 'Beschreibung',
  'LNK_EDIT_TABS'=>'Tabs bearbeiten',
  'NTC_REMOVE_TEAM_MEMBER_CONFIRMATION' => 'Sind Sie sicher dass Sie die Mitgliedschaft dieses Mitarbeiters beenden wollen?',

  'LBL_LIST_EMPLOYEE_STATUS' => 'Status',

  'LBL_SUGAR_LOGIN' => 'Ist Sugar Benutzer',  
  'LBL_RECEIVE_NOTIFICATIONS' => 'Meldung wenn zugewiesen',  
  'LBL_IS_ADMIN' => 'Ist Administrator',  
  'LBL_GROUP' => 'Gruppen Benutzer',
  'LBL_PORTAL_ONLY'	=> 'Nur Portal Benutzer',
);


?>
