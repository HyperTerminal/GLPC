<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
    //DON'T CONVERT THESE THEY ARE MAPPINGS
    'db_sales_stage' => 'LBL_LIST_SALES_STAGE',
    'db_name' => 'LBL_NAME',
    'db_amount' => 'LBL_LIST_AMOUNT',
    'db_date_closed' => 'LBL_LIST_DATE_CLOSED',
    //END DON'T CONVERT

    'LBL_CONTRACTS'=>'Verträge',
    'LBL_CONTRACTS_SUBPANEL_TITLE'=>'Verträge',

    'ERR_DELETE_RECORD' => 'Um das Angebot zu löschen, muss eine Datensatznummer angegeben werden.',
    'LBL_ACCOUNT_ID'=>'Firma ID',
    'LBL_ACCOUNT_NAME' => 'Firmenname:',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'=>'Aktivitäten',
    'LBL_ADD_COMMENT' => 'Kommentar hinzufügen',
    'LBL_ADD_GROUP' => 'Gruppe hinzufügen',
    'LBL_ADD_ROW' => 'Zeile hinzufügen',
    'LBL_ADDRESS_INFORMATION' => 'Adressinformation',
    'LBL_AMOUNT'=>'Betrag:',
    'LBL_ANY_ADDRESS' => 'Irgendeine Adresse:',
    'LBL_BILL_TO' => 'Rech. an',
    'LBL_BILLING_ACCOUNT_NAME' => 'Rechnungadresse Firmenname:',
    'LBL_BILLING_ACCOUNT' => 'Firma:',
    'LBL_BILLING_ADDRESS_CITY' => 'Rechnungsadresse Stadt',
    'LBL_BILLING_ADDRESS_COUNTRY' => 'Rechnungsadresse Land',
    'LBL_BILLING_ADDRESS_POSTAL_CODE' => 'Rechnungsadresse PLZ',
    'LBL_BILLING_ADDRESS_STATE' => 'Rechnungsadresse Bundesland',
    'LBL_BILLING_ADDRESS_STREET' => 'Rechnungsadresse',
    'LBL_BILLING_ADDRESS' => 'Rechnungsadresse::',
    'LBL_BILLING_CONTACT_NAME' => 'Rechnungadresse Kontaktname:',
    'LBL_BILLING_CONTACT' => 'Kontakt:',
    'LBL_BUNDLE_NAME' => 'Gruppenname',
    'LBL_BUNDLE_STAGE' => 'Gruppen Stufe:',
    'LBL_CALC_GRAND' => 'Gesamtsumme anzeigen:',
    'LBL_CHECK_DATA'=>"Ungültige Eingabe: Bitte überprüfen Sie Ihre Daten und stellen Sie sicher dass Sie gültige Zahlen haben (0-9 oder \'.\')",
    'LBL_CITY' => 'Stadt:',
    'LBL_CONTACT_NAME' => 'Name:',
    'LBL_CONTACT_QUOTE_FORM_TITLE' => 'Kontakt-Angebot:',
    'LBL_CONTACT_ROLE' => 'Kontakt Rolle:',
    'LBL_COUNTRY' => 'Land:',
    'LBL_CREATED_BY'=>'Erstellt von:',
    'LBL_CURRENCY' => 'Währung',
    'LBL_DATE_QUOTE_CLOSED' => 'Tatsächliches Abschlussdatum:',
    'LBL_DATE_QUOTE_EXPECTED_CLOSED' => 'Gültig bis:',
    'LBL_DEFAULT_SUBPANEL_TITLE' => 'Angebote',
    'LBL_DELETE_GROUP' => 'Gruppe löschen',
    'LBL_DESCRIPTION_INFORMATION' => 'Beschreibungsinformation',
    'LBL_DESCRIPTION' => 'Beschreibung:',
    'LBL_DUPLICATE' => 'Mögliches doppeltes Angebot',
    'LBL_EMAIL_QUOTE_FOR' => 'Angebot für:',
    'LBL_EMAIL_DEFAULT_DESCRIPTION' => 'Hier ist das Angebot das Sie angefragt haben (Sie können diesen Text ändern)',
    'LBL_EMAIL_ATTACHMENT' => 'E-Mail Anhang:',
    'LBL_HISOTRY_SUBPANEL_TITLE'=>'Verlauf',
    'LBL_INVITEE' => 'Kontakte',
    'LBL_INVOICE'=>'Rechnung',
    'LBL_LEAD_SOURCE'=>'Quelle:',
    'LBL_LINE_ITEM_INFORMATION' => 'Zeilenelemente',
    'LBL_LIST_ACCOUNT_NAME' => 'Firmenname',
    'LBL_LIST_AMOUNT' => 'Betrag',
    'LBL_LIST_ASSIGNED_TO_NAME' => 'Zugew. Benutzer',
    'LBL_LIST_COST_PRICE' => 'Einstandspreis',
    'LBL_LIST_DATE_QUOTE_CLOSED' => 'Tatsächlicher Abschluss',
    'LBL_LIST_DATE_QUOTE_EXPECTED_CLOSED' => 'Gültig bis',
    'LBL_LIST_DISCOUNT_PRICE' => 'VK-Preis',
    'LBL_LIST_FORM_TITLE' => 'Angebotsliste',
    'LBL_LIST_GRAND_TOTAL' => 'Gesamtbetrag',
    'LBL_LIST_LIST_PRICE' => 'Liste',
    'LBL_LIST_MANUFACTURER_PART_NUM' => 'Herst. Teilenr.',
    'LBL_LIST_PRICING_FACTOR' => 'Faktor',
    'LBL_LIST_PRICING_FORMULA' => 'Preisformel',
    'LBL_LIST_PRODUCT_NAME' => 'Produkt',
    'LBL_LIST_QUANTITY' => 'Menge',
    'LBL_LIST_QUOTE_NAME' => 'Betreff',
    'LBL_LIST_QUOTE_NUM' => 'Nummer',
    'LBL_LIST_QUOTE_STAGE' => 'Stufe',
    'LBL_LIST_TAXCLASS' => 'Steuerklasse',
    'LBL_MODIFIED_BY'=>'Geändert von',
    'LBL_MODULE_NAME' => 'Angebote',
    'LBL_MODULE_TITLE' => 'Angebote: Home',
    'LBL_NAME' => 'Angebot Name',
    'LBL_NEW_FORM_TITLE' => 'Neues Angebot',
    'LBL_NEXT_STEP'=>'Nächster Schritt:',
    'LBL_OPPORTUNITY_NAME' => 'Verkaufschance Name:',
    'LBL_ORDER_STAGE'=>'Auftragsphase',
    'LBL_ORIGINAL_PO_DATE' =>  'Ursprüngl. Bestelldatum:',
    'LBL_PAYMENT_TERMS' =>  'Zahlungskonditionen:',
    'LBL_PDF_BILLING_ADDRESS' => 'Rech. an',
    'LBL_PDF_CURRENCY' => 'Währung',
    'LBL_PDF_GRAND_TOTAL' => 'Gesamtbetrag',
    'LBL_PDF_INVOICE_NUMBER' => 'Rechnungsnummer',
    'LBL_PDF_INVOICE_TITLE' => 'Rechnung',
    'LBL_PDF_ITEM_EXT_PRICE' => 'Ext. Preis',
    'LBL_PDF_ITEM_LIST_PRICE' => 'Listpreis',
    'LBL_PDF_ITEM_PRODUCT' => 'Produkt',
    'LBL_PDF_ITEM_QUANTITY' => 'Menge',
    'LBL_PDF_ITEM_UNIT_PRICE' => 'VK-Preis',
    'LBL_PDF_PART_NUMBER' => 'Teilenummer:',
    'LBL_PDF_QUOTE_CLOSE' => 'Gültig bis:',
    'LBL_PDF_QUOTE_DATE' => 'Datum:',
    'LBL_PDF_QUOTE_NUMBER' => 'Angebotsnummer:',
    'LBL_PDF_QUOTE_TITLE' => 'Angebot',
    'LBL_PDF_SALES_PERSON' => 'Verkäufer:',
    'LBL_PDF_SHIPPING_ADDRESS' => 'Lief. an:',
    'LBL_PDF_SHIPPING_COMPANY' => 'Versender:',
    'LBL_PDF_SHIPPING' => 'Lieferung:',
    'LBL_PDF_SUBTOTAL' => 'Zwischensumme:',
    'LBL_PDF_TAX_RATE' => 'Steuersatz:',
    'LBL_PDF_TAX' => 'Steuer:',
    'LBL_PDF_TOTAL' => 'Gesamt:',
    'LBL_POSTAL_CODE' => 'PLZ:',
    'LBL_PROJECTS_SUBPANEL_TITLE' => 'Projekte',
    'LBL_PROPOSAL'=>'Angebot',
    'LBL_PURCHASE_ORDER_NUM' => 'Bestellnummer:',
    'LBL_QUOTE_NAME' => 'Betreff:',
    'LBL_QUOTE_NUM' => 'Angebotsnummer:',
    'LBL_QUOTE_STAGE' => 'Angebotsphase:',
    'LBL_QUOTE_TYPE'=>'Angebotsart',
    'LBL_QUOTE' => 'Angebot:',
    'LBL_QUOTE_LAYOUT_DOES_NOT_EXIST_ERROR' => 'Angebotsvorlagedatei exisitert nicht: $layout',
    'LBL_QUOTE_LAYOUT_REGISTERED_ERROR' => 'Angebotsvorlage ist nicht in Modules/Quotes/Layouts.php registriert',
    'LBL_REMOVE_COMMENT' => 'Kommentar entfernen',
    'LBL_REMOVE_ROW' => 'Zeile entfernen',
    'LBL_RENAME_ERROR' => 'FEHLER: Kann PDF nicht nach $destination verschieben. Versuchen Sie das Verzeichnis durch den Webserver beschreibbar zu machen',
    'LBL_SALES_STAGE'=>'Angebotsphase:',
    'LBL_SEARCH_FORM_TITLE' => 'Angebot Suche',
    'LBL_SHIP_TO' => 'Lief. an:',
    'LBL_SHIPPING_ACCOUNT_NAME' => 'Lieferadresse Firmenname',
    'LBL_SHIPPING_ACCOUNT' => 'Firma:',
    'LBL_SHIPPING_ADDRESS_CITY' => 'Lieferadresse Stadt',
    'LBL_SHIPPING_ADDRESS_COUNTRY' => 'Lieferadresse Land',
    'LBL_SHIPPING_ADDRESS_POSTAL_CODE' => 'Lieferadresse PLZ',
    'LBL_SHIPPING_ADDRESS_STATE' => 'Lieferadresse Bundesland',
    'LBL_SHIPPING_ADDRESS_STREET' => 'Lieferadresse',
    'LBL_SHIPPING_ADDRESS' => 'Lieferadresse:',
    'LBL_SHIPPING_CONTACT_NAME' => 'Lieferadresse Kontaktname:',
    'LBL_SHIPPING_CONTACT' => 'Kontakt:',
    'LBL_SHIPPING_PROVIDER' => 'Versender:',
    'LBL_SHIPPING_USDOLLAR'=>'Lieferung (Euro)',
    'LBL_SHIPPING' => 'Lieferung:',
    'LBL_SHOW_LINE_NUMS' => 'Zeilennummern anzeigen:',
    'LBL_STATE' => 'Bundesland:',
    'LBL_SUBTOTAL_USDOLLAR'=>'Zwischensumme (Euro)',
    'LBL_SUBTOTAL' => 'Zwischensumme:',
    'LBL_SYSTEM_ID' => 'System ID',
    'LBL_TAX_USDOLLAR'=>'Steuer (Euro)',
    'LBL_TAX' => 'Steuer:',
    'LBL_TAXRATE' => 'Steuersatz:',
    'LBL_TOTAL_USDOLLAR'=>'Gesamt (Euro)',
    'LBL_TOTAL' => 'Gesamt:',
    'LBL_TYPE'=>'Typ:',
    'LNK_NEW_QUOTE' => 'Neues Angebot',
    'LNK_QUOTE_LIST' => 'Angebote',
    'MSG_DUPLICATE' => 'Sie erstellen eine doppeltes Angebot. Sie können entweder ein Angebot aus der Liste unten auswählen, oder Sie klicken auf Speichern um mit der Bearbeitung dieses Angebots fortzufahren.',
    'NTC_COPY_BILLING_ADDRESS' => 'Rechnungsadresse auf Lieferadresse kopieren',
    'NTC_COPY_SHIPPING_ADDRESS' => 'Lieferadresse auf Rechnungsadresse kopieren',
    'NTC_COPY_BILLING_ADDRESS2' => 'Auf Lieferadresse kopieren',
    'NTC_COPY_SHIPPING_ADDRESS2' => 'Auf Rechnungsadresse kopieren',  
    'NTC_REMOVE_COMMENT_CONFIRMATION' => 'Möchten Sie diesen Kommentar wirklich aus dem Angebot entfernen?',  
    'NTC_REMOVE_PRODUCT_CONFIRMATION' => 'Möchten Sie diese Artikelzeile wirklich aus dem Angebot entfernen?',
    'NTC_REMOVE_QUOTE_CONFIRMATION' => 'Möchten Sie diesen Kontakt wirklich aus dem Angebot entfernen?',
    'QUOTE_REMOVE_PROJECT_CONFIRM' => 'Möchten Sie dieses Angebot wirklich aus dem Projekt entfernen?',

	'LNK_QUOTE_REPORTS' => 'Angebotsberichte',

	'LBL_ASSIGNED_TO_NAME'=>'Zugewiesen an:',
	'PDF_FORMAT'=>'PDF Format:',
	'LBL_ASSIGNED_TO_ID'=>'Bearbeiter',
);
?>
