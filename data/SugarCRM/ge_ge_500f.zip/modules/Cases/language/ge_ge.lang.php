<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD'					=> 'Es muss die Datensatznummer angegeben werden, um diesen Datensatz zu löschen.',

	'LBL_ACCOUNT_ID'					=> 'Firma ID',
	'LBL_ACCOUNT_NAME'					=> 'Firmenname:',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'		=> 'Aktivitäten',
	'LBL_BUGS_SUBPANEL_TITLE'			=> 'Fehler',
	'LBL_CASE_NUMBER'					=> 'Fallnummer:',
	'LBL_CASE_SUBJECT'					=> 'Betreff:',
	'LBL_CASE'							=> 'Fall:',
	'LBL_CONTACT_CASE_TITLE'			=> 'Kontakt:',
	'LBL_CONTACT_NAME'					=> 'Name:',
	'LBL_CONTACT_ROLE'					=> 'Beruf:',
	'LBL_CONTACTS_SUBPANEL_TITLE'		=> 'Kontakte',
	'LBL_DEFAULT_SUBPANEL_TITLE'		=> 'Fälle',
	'LBL_DESCRIPTION'					=> 'Beschreibung:',
	'LBL_HISTORY_SUBPANEL_TITLE'		=> 'Verlauf',
	'LBL_INVITEE'						=> 'Kontakte',
	'LBL_MEMBER_OF'						=> 'Firma',
	'LBL_MODULE_NAME'					=> 'Fälle',
	'LBL_MODULE_TITLE'					=> 'Fälle: Home',
	'LBL_NEW_FORM_TITLE'				=> 'Neuer Fall',
	'LBL_NUMBER'						=> 'Nummer:',
	'LBL_PRIORITY'						=> 'Priorität:',
	'LBL_PROJECTS_SUBPANEL_TITLE' 		=> 'Projekte',
	'LBL_RESOLUTION'					=> 'Lösung:',
	'LBL_SEARCH_FORM_TITLE'				=> 'Fälle Suche',
	'LBL_STATUS'						=> 'Status:',
	'LBL_SUBJECT'						=> 'Betreff:',
	'LBL_SYSTEM_ID'						=> 'System ID',
	'LBL_LIST_ASSIGNED_TO_NAME' 		=> 'Zugew. Benutzer',
	'LBL_LIST_ACCOUNT_NAME'				=> 'Firmenname',
	'LBL_LIST_ASSIGNED'					=> 'Zugewiesen an',
	'LBL_LIST_CLOSE'					=> 'Schließen',
	'LBL_LIST_FORM_TITLE'				=> 'Fälle Liste',
	'LBL_LIST_LAST_MODIFIED'			=> 'Geändert am:',
	'LBL_LIST_MY_CASES'					=> 'Meine offenen Fälle',
	'LBL_LIST_NUMBER'					=> 'Nr.',
	'LBL_LIST_PRIORITY'					=> 'Priorität',
	'LBL_LIST_STATUS'					=> 'Status',
	'LBL_LIST_SUBJECT'					=> 'Betreff',
	'LBL_LIST_ASSIGNED_TO_NAME'   		=> 'Zugew. Benutzer',

	'LNK_CASE_LIST'						=> 'Fälle',
	'LNK_NEW_CASE'						=> 'Neuer Fall',
	'NTC_REMOVE_FROM_BUG_CONFIRMATION'	=> 'Möchten Sie diesen Fall wirklich entfernen?',
	'NTC_REMOVE_INVITEE'				=> 'Möchten Sie diesen Kontakt wirklich von diesem Fall entfernen?',
	'LBL_LIST_DATE_CREATED'			=> 'Erstellt am:',
	'LBL_ASSIGNED_TO_NAME' => 'Zugewiesen an',
	'LBL_TYPE'=>'Typ:',
	'LBL_WORK_LOG'=>'Arbeits Log',


	'LNK_CASE_REPORTS' => 'Fallberichte',
	'LBL_SHOW_IN_PORTAL' => 'Zeige im Portal',
	'LBL_CREATE_KB_DOCUMENT' => 'Artikel erstellen',

);


?>
