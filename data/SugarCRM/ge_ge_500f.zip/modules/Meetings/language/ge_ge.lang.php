<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
	'ERR_DELETE_RECORD' => 'Die Datensatznummer muß angegeben werden, um diesen Eintrag löschen.',
	
	'LBL_ACCEPT_THIS'=>'Bestätigen?',  
	'LBL_ADD_BUTTON'=> 'Hinzufügen',
	'LBL_ADD_INVITEE' => 'Teilnehmer hinzufügen',
	'LBL_BLANK'	=> ' ',
	'LBL_COLON' => ':',
	'LBL_CONTACT_NAME' => 'Kontakt:',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Kontakte',
	'LBL_CREATED_BY'=>'Erstellt von:',
	'LBL_DATE_END'=>'Enddatum',
	'LBL_DATE_TIME' => 'Startdatum und -zeit:',
	'LBL_DATE' => 'Startdatum:',
	'LBL_DEFAULT_STATUS' => 'Geplant',
	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Meetings',
	'LBL_DEL'=> 'Löschen',
	'LBL_DESCRIPTION_INFORMATION' => 'Beschreibungsinformation',
	'LBL_DESCRIPTION' => 'Beschreibung:',
	'LBL_DURATION_HOURS' => 'Stunden:',
	'LBL_DURATION_MINUTES' => 'Minuten:',
	'LBL_DURATION' => 'Dauer:',
	'LBL_EMAIL' => 'E-Mail',
	'LBL_FIRST_NAME' => 'Vorname',
	'LBL_HISTORY_SUBPANEL_TITLE' => 'Notizen',
	'LBL_HOURS_ABBREV' => 'St.',
	'LBL_HOURS_MINS' => '(Stunden/Minuten)',
	'LBL_INVITEE' => 'Teilnehmer',
	'LBL_LAST_NAME' => 'Nachname',
	'LBL_ASSIGNED_TO_NAME'=>'Zugewiesen an:',
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Zugew. Benutzer',
	'LBL_LIST_CLOSE' => 'Schließen',
	'LBL_LIST_CONTACT' => 'Kontakt',
	'LBL_LIST_DATE_MODIFIED'=>'Geändert am',
	'LBL_LIST_DATE' => 'Startdatum',
	'LBL_LIST_DUE_DATE'=>'Fällig am',
	'LBL_LIST_FORM_TITLE' => 'Meetingliste',
	'LBL_LIST_MY_MEETINGS' => 'Meine Meetings',
	'LBL_LIST_RELATED_TO' => 'Gehört zu',
	'LBL_LIST_STATUS'=>'Status',
	'LBL_LIST_SUBJECT' => 'Betreff',
	'LBL_LIST_TIME' => 'Startzeit',
	
	'LBL_LOCATION' => 'Ort:',
	'LBL_MEETING' => 'Meeting:',
	'LBL_MINSS_ABBREV' => 'min',
	'LBL_MODIFIED_BY'=>'Geändert von',
	'LBL_MODULE_NAME' => 'Meetings',
	'LBL_MODULE_TITLE' => 'Meetings: Home',
	'LBL_NAME' => 'Name',
	'LBL_NEW_FORM_TITLE' => 'Neuer Termin',
	'LBL_OUTLOOK_ID' => 'Outlook ID',
	'LBL_PHONE' => 'Telefon Büro:',
	'LBL_REMINDER_TIME'=>'Erinnerungs Zeitpunkt',
	'LBL_REMINDER' => 'Erinnerung:',
	'LBL_SCHEDULING_FORM_TITLE' => 'Planung',
	'LBL_SEARCH_BUTTON'=> 'Suchen',
	'LBL_SEARCH_FORM_TITLE' => 'Meetings Suche',
	'LBL_SEND_BUTTON_KEY'=>'I',
	'LBL_SEND_BUTTON_LABEL'=>'Einladungen senden',
	'LBL_SEND_BUTTON_TITLE'=>'Einladungen senden [Alt-I]',
	'LBL_STATUS' => 'Status:',
	'LBL_SUBJECT' => 'Betreff:',
	'LBL_TIME' => 'Beginn:',
	'LBL_USERS_SUBPANEL_TITLE' => 'Benutzer',
	
	'LNK_CALL_LIST'=>'Anrufe',
	'LNK_EMAIL_LIST'=>'E-Mails',
	'LNK_MEETING_LIST'=>'Meetings',
	'LNK_NEW_APPOINTMENT' => 'Neuer Termin',
	'LNK_NEW_CALL'=>'Neuer Anruf',
	'LNK_NEW_EMAIL'=>'E-Mail archivieren',
	'LNK_NEW_MEETING'=>'Neues Meeting',
	'LNK_NEW_NOTE'=>'Neue Notiz oder Anlage',
	'LNK_NEW_TASK'=>'Neue Aufgabe',
	'LNK_NOTE_LIST'=>'Notizen',
	'LNK_TASK_LIST'=>'Aufgaben',
	'LNK_VIEW_CALENDAR' => 'Heute',
	
	'NTC_REMOVE_INVITEE' => 'Möchten Sie diesen Teilnehmer wirklich aus diesem Meeting entfernen?',
);
?>
