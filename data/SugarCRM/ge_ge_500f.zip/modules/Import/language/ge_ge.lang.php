<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Enterprise Subscription
 * Agreement ("License") which can be viewed at
 * http://www.sugarcrm.com/crm/products/sugar-enterprise-eula.html
 * By installing or using this file, You have unconditionally agreed to the
 * terms and conditions of the License, and You may not use this file except in
 * compliance with the License.  Under the terms of the license, You shall not,
 * among other things: 1) sublicense, resell, rent, lease, redistribute, assign
 * or otherwise transfer Your rights to the Software, and 2) use the Software
 * for timesharing or service bureau purposes such as hosting the Software for
 * commercial gain and/or for the benefit of a third party.  Use of the Software
 * may be subject to applicable fees and any use of the Software without first
 * paying applicable fees is strictly prohibited.  You do not have the right to
 * remove SugarCRM copyrights from the source code or user interface.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *  (i) the "Powered by SugarCRM" logo and
 *  (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * Your Warranty, Limitations of liability and Indemnity are expressly stated
 * in the License.  Please refer to the License for the specific language
 * governing these rights and limitations under the License.  Portions created
 * by SugarCRM are Copyright (C) 2004-2007 SugarCRM, Inc.; All Rights Reserved.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributors: Genius4U Ltd., simplicity GmbH, iscongroup kft.
 ********************************************************************************/

$mod_strings = array (
  'LBL_IMPORT_MODULE_NO_DIRECTORY' => 'Das Verzeichnis ',
  'LBL_IMPORT_MODULE_NO_DIRECTORY_END' => ' existiert nicht, oder ist nicht beschreibbar',
  'LBL_IMPORT_MODULE_ERROR_NO_UPLOAD' => 'Datei konnte nicht hochgeladen werden. Möglicherweise ist der Parameter \'upload_max_filesize\' in Ihrer php.ini Datei zu niedrig gesetzt',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE' => 'Datei ist zu groß. Max:',
  'LBL_IMPORT_MODULE_ERROR_LARGE_FILE_END' => 'Bytes. Ändern Sie $sugar_config[\'upload_maxsize\'] in Ihrer config.php',
  'LBL_MODULE_NAME' => 'Import',
  'LBL_TRY_AGAIN' => 'Wiederholen',
  'LBL_ERROR' => 'Fehler:',
  'ERR_MULTIPLE' => 'Es wurden mehrere Spalten mit dem gleichen Feldnamen definiert.',
  'ERR_MISSING_REQUIRED_FIELDS' => 'Erforderliche Felder fehlen:',
  'ERR_SELECT_FULL_NAME' => 'Wenn Vorname und Nachname ausgewählt sind, kann \'Ganzer Name\' nicht selektiert werden.',
  'ERR_SELECT_FILE' => 'Datei zum Hochladen auswählen.',
  'LBL_SELECT_FILE' => 'Datei auswählen:',
  'LBL_CUSTOM' => 'Benutzerdefiniert',
  'LBL_CUSTOM_CSV' => 'Benutzerdefinierte Komma-getrennte Datei',
  'LBL_CSV' => 'Komma-getrennte Datei',
  'LBL_TAB' => 'Tab-getrennte Datei',
  'LBL_CUSTOM_DELIMETED' => 'Benutzerdefinierte Getrennte Datei',
  'LBL_CUSTOM_DELIMETER' => 'Benutzerdefiniertes Trennzeichen:',
  'LBL_CUSTOM_TAB' => 'Benutzerdefinierte Tab-getrennte Datei',
  'LBL_DONT_MAP' => '-- Dieses Feld nicht zuweisen --',
  'LBL_STEP_1_TITLE' => 'Schitt 1: Wählen Sie die Datenquelle',
  'LBL_WHAT_IS' => 'Was ist die Datenquelle?',
  'LBL_MICROSOFT_OUTLOOK' => 'Microsoft Outlook',
  'LBL_SALESFORCE' => 'Salesforce.com',
  'LBL_MY_SAVED' => 'Meine gespeicherten Datenquellen:',
  'LBL_PUBLISH' => 'publizieren',
  'LBL_DELETE' => 'löschen',
  'LBL_PUBLISHED_SOURCES' => 'Publizierte Datenquellen:',
  'LBL_UNPUBLISH' => 'Publikation aufheben',
  'LBL_NEXT' => 'Weiter >',
  'LBL_BACK' => '< Zurück',
  'LBL_STEP_2_TITLE' => 'Schritt 2: Exportdatei hochladen',
  'LBL_HAS_HEADER' => 'Hat Überschrift:',
  'LBL_NUM_1' => '1.',
  'LBL_NUM_2' => '2.',
  'LBL_NUM_3' => '3.',
  'LBL_NUM_4' => '4.',
  'LBL_NUM_5' => '5.',
  'LBL_NUM_6' => '6.',
  'LBL_NUM_7' => '7.',
  'LBL_NUM_8' => '8.',
  'LBL_NUM_9' => '9.',
  'LBL_NUM_10' => '10.',
  'LBL_NUM_11' => '11.',
  'LBL_NUM_12' => '12.',
  'LBL_NOTES' => 'Notizen:',
  'LBL_NOW_CHOOSE' => 'Wählen Sie jetzt die Datei für den Import:',
  'LBL_IMPORT_OUTLOOK_TITLE' => 'Microsoft Outlook 98 und 2000 können Daten als <b>Komma getrennte</b> Datei exportieren, die zum Datenimport ins System geeignet ist. Zum Exportieren Ihrer Daten aus Outlook folgen Sie den nachstehenden Anweisungsschritten:',
  'LBL_OUTLOOK_NUM_1' => '<b>Outlook</b> starten',
  'LBL_OUTLOOK_NUM_2' => 'Das <b>Datei</b> Manü wählen und dann die <b>Importieren/Exportieren ...</b> Menüoption',
  'LBL_OUTLOOK_NUM_3' => '<b>Exportieren in eine Datei</b> auswählen und Weiter klicken',
  'LBL_OUTLOOK_NUM_4' => '<b>Komma-getrennte Werte (Windows)</b> auswählen und <b>Weiter</b> klicken.<br> Anmerkung: Möglicherweise werden Sie zum Installieren der Exportkomponente aufgefordert',
  'LBL_OUTLOOK_NUM_5' => 'Wählen Sie den <b>Kontakte</b> Ordner und klicken Sie <b>Weiter</b>. Sie können verschiedene Kontakte-Ordner wählen, wenn Ihre Kontakte in mehreren Ordnern gespeichert sind',
  'LBL_OUTLOOK_NUM_6' => 'Wählen Sie einen Dateinamen und klicken Sie <b>Weiter</b>',
  'LBL_OUTLOOK_NUM_7' => 'Klicken Sie auf <b>Fertigstellen</b>',
  'LBL_IMPORT_SF_TITLE' => 'Salesforce.com kann Daten im <b>Komma getrennte Werte</b> Format speichern, welches sich zum Datenimport ins System eignet. Zum Datenexport aus Salesforce.com, folgen Sie diesen Anweisungsschritten:',
  'LBL_SF_NUM_1' => 'Öffnen Sie Ihren Browser, gehen Sie auf http://www.salesforce.com, und melden Sie sich mit Ihrer E-Mail Adresse und Passwort an',
  'LBL_SF_NUM_2' => 'Klicken Sie auf den <b>Berichte</b> Reiter im Hauptmenü',
  'LBL_SF_NUM_3' => '<b>Zum Exportieren von Firmen:</b> Klicken Sie auf <b>Aktive Firmen</b> <br><b>Zum Exportieren von Kontakten:</b> Klicken Sie auf <b>Mailing List</b>',
  'LBL_SF_NUM_4' => 'Bei <b>Schritt 1: Wählen Sie den Berichtstyp</b>, wählen Sie <b>Reiter Berichte</b> und klicken Sie auf <b>Weiter</b>',
  'LBL_SF_NUM_5' => 'Bei <b>Step 2: Wählen Sie die Bericht Spalten</b>, wählen Sie die Spalten, die Sie exportieren wollen und klicken Sie auf <b>Weiter</b>',
  'LBL_SF_NUM_6' => 'Bei <b>Step 3: Select the information to summarize</b>, klicken Sie <b>Weiter</b>',
  'LBL_SF_NUM_7' => 'Bei <b>Schritt 4: Spalten sortieren</b>, klicken Sie einfach auf <b>Weiter</b>',
  'LBL_SF_NUM_8' => 'Bei <b>Step 5: Wählen Sie die Kriterien</b>, unter <b>Start Datum</b>, wählen Sie ein Datum weit genug in der Vergangenheit, so dass alle Ihre Firmen mit eingeschlossen sind. Sie können auch eine Teilmenge Ihrer Firmen exportieren, indem Sie erweiterte Kriterien nutzen. Wenn die Auswahl fertig ist, klicken Sie auf <b>Bericht ausführen</b>',
  'LBL_SF_NUM_9' => 'Ein Bericht wird erstellt und es sollte angezeigt werden <b>Report Generation Status: Complete.</b> Jetzt klicken Sie auf <b>Exportieren nach Excel</b>',
  'LBL_SF_NUM_10' => 'Bei <b>Export Bericht:</b>, für <b>Export Datenformat:</b>, wählen Sie <b>Komma-getrennte .csv</b>. Klicken Sie auf <b>Exportieren</b>.',
  'LBL_SF_NUM_11' => 'Ein Dialog erscheint, mit dem Sie die Export-Datei auf Ihrem Computer speichern können.',
  'LBL_IMPORT_CUSTOM_TITLE' => 'Viele Anwendungen erlauben den Datenexport in eine <b>Komma getrennte Textdatei (.csv)</b> indem man diesen allgemeinen Anweisungen folgt:',
  'LBL_CUSTOM_NUM_1' => 'Starten Sie das Programm und öffnen Sie die Daten-Datei',
  'LBL_CUSTOM_NUM_2' => 'Wählen Sie <b>Speichern unter...</b> oder <b>Exportieren...</b> im Menü',
  'LBL_CUSTOM_NUM_3' => 'Speichern Sie die Datei im <b>CSV</b> oder <b>Komma-getrennte Werte</b> Format',
  'LBL_IMPORT_TAB_TITLE' => 'Viele Anwendungen erlauben den Datenexport in eine <b>Tab getrennte Textdatei (.csv oder .tab)</b> indem man diesen allgemeinen Anweisungen folgt:',
  'LBL_TAB_NUM_1' => 'Starten Sie das Programm und öffnen Sie die Daten-Datei',
  'LBL_TAB_NUM_2' => 'Wählen Sie <b>Speichern unter...</b> oder <b>Exportieren...</b> im Menü',
  'LBL_TAB_NUM_3' => 'Speichern Sie die Datei im <b>TSV</b> oder <b>Tab-getrennte Werte</b> Format',
  'LBL_STEP_3_TITLE' => 'Schritt 3: Bestätigen Sie Felder und Import',
  'LBL_SELECT_FIELDS_TO_MAP' => 'In der nachstehenden Liste wählen Sie die Felder Ihrer Importdatei, die in die einzelnen Felder im System importiert werden sollen. Wenn Sie fertig sind, klicken Sie <b>Jetzt importieren</b>:',
  'LBL_DATABASE_FIELD' => 'Datenbank Feld',
  'LBL_HEADER_ROW' => 'Titelzeile',
  'LBL_ROW' => 'Zeile',
  'LBL_SAVE_AS_CUSTOM' => 'Als benutzerspezifische Zuordnung speichern:',
  'LBL_CONTACTS_NOTE_1' => 'Entweder Nachname oder Ganzer Name müssen zugeordnet werden.',
  'LBL_CONTACTS_NOTE_2' => 'Wenn der \'Ganze Name\' zugeordnet ist, dann werden Vorname und Nachname ignoriert.',
  'LBL_CONTACTS_NOTE_3' => 'Wenn der \'Ganze Name\' zugeordnet ist, werden die Daten beim Einstellen in die Datenbank in Vorname und Nachname aufgeteilt.',
  'LBL_CONTACTS_NOTE_4' => 'Felder, die auf Adresse 2 und Adresse 3 enden, werden beim Einstellen in die Datenbank an das Haupt-Adresse Feld angehängt.',
  'LBL_ACCOUNTS_NOTE_1' => 'Firmename muss zugeordnet werden.',
  'LBL_ACCOUNTS_NOTE_2' => 'Felder, die auf Adresse 2 und Adresse 3 enden, werden beim Einstellen in die Datenbank an das Haupt-Adresse Feld angehängt.',
  'LBL_OPPORTUNITIES_NOTE_1' => 'Verkaufschancen Name, Firmenname, Abschlussdatum und Verkaufsphase sind Pflichtfelder.',
  'LBL_IMPORT_NOW' => 'Jetzt importieren',
  'LBL_' => '',
  'LBL_CANNOT_OPEN' => 'Kann die Importdatei nicht zum Lesen öffnen',
  'LBL_NOT_SAME_NUMBER' => 'Die Anzahl Felder pro Zeile in Ihrer Datei stimmt nicht überein',
  'LBL_NO_LINES' => 'Ihre Importdatei enthält keine Datensätze',
  'LBL_FILE_ALREADY_BEEN_OR' => 'Die Importdatei wurde schon verarbeitet oder existiert nicht',
  'LBL_SUCCESS' => 'Erfolg:',
  'LBL_SUCCESSFULLY' => 'Erfolgreich importiert',
  'LBL_LAST_IMPORT_UNDONE' => 'Ihr letzter Import wurde rückgängig gemacht',
  'LBL_NO_IMPORT_TO_UNDO' => 'Import rückgängig machen nicht möglich',
  'LBL_FAIL' => 'Fehler:',
  'LBL_RECORDS_SKIPPED' => 'Datensätze wurden ignoriert, weil ein oder mehrere Pflichtfelder fehlten',
  'LBL_IDS_EXISTED_OR_LONGER' => 'Datensätze wurden ignoriert, weil die IDs schon vorhanden waren oder weil sie länger waren als 36 Zeichen',
  'LBL_RESULTS' => 'Resultat',
  'LBL_IMPORT_MORE' => 'Weitere importieren',
  'LBL_FINISHED' => 'Beendet',
  'LBL_UNDO_LAST_IMPORT' => 'Letzten Import rückgängig machen',
  'LBL_LAST_IMPORTED'=>'Zuletzt importiert',
  'ERR_MULTIPLE_PARENTS' => 'Sie können nur eine Eltern-ID definieren',
  'LBL_DUPLICATES' => 'Dubletten gefunden',
  'LBL_DUPLICATE_LIST' => 'Liste der Dubletten herunterladen',
  'LBL_UNIQUE_INDEX' => 'Index für Duplikatvergleich wählen',
  'LBL_VERIFY_DUPS' => 'Doppelte Einträge nach gewählten Indizes überprüfen',
  'LBL_INDEX_USED' => 'Verwendete Indizes',
  'LBL_INDEX_NOT_USED' => 'Nicht verwendete Indizes',
  'LBL_IMPORT_MODULE_ERROR_NO_MOVE' => 'Die Datei wurde nicht erfolgreich hochgeladen. Überprüfen Sie die Datei Berechtigungen im Cache Verzeichnis Ihrer Sugar Installation.',

);
?>
