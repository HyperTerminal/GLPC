<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Naloge',
'LBL_TASK'                                         => 'Naloge: ',
'LBL_MODULE_TITLE'                                 => 'Naloge: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje po nalogah',
'LBL_LIST_FORM_TITLE'                              => 'Seznam nalog',
'LBL_NEW_FORM_TITLE'                               => 'Ustvari nalogo',
'LBL_NEW_FORM_SUBJECT'                             => 'Zadeva:',
'LBL_NEW_FORM_DUE_DATE'                            => 'Datum zapadlosti:',
'LBL_NEW_FORM_DUE_TIME'                            => 'Čas zapadlosti:',
'LBL_NEW_TIME_FORMAT'                              => '(24:00)',
'LBL_LIST_CLOSE'                                   => 'Končaj',
'LBL_LIST_SUBJECT'                                 => 'Zadeva',
'LBL_LIST_CONTACT'                                 => 'Kontakt',
'LBL_LIST_PRIORITY'                                => 'Prioriteta',
'LBL_LIST_RELATED_TO'                              => 'Povezano z',
'LBL_LIST_DUE_DATE'                                => 'Datum zapadlosti',
'LBL_LIST_DUE_TIME'                                => 'Čas zapadlosti',
'LBL_SUBJECT'                                      => 'Zadeva:',
'LBL_STATUS'                                       => 'Status:',
'LBL_DUE_DATE'                                     => 'Datum zapadlosti:',
'LBL_DUE_TIME'                                     => 'Čas zapadlosti:',
'LBL_PRIORITY'                                     => 'Prioriteta:',
'LBL_COLON'                                        => ':',
'LBL_DUE_DATE_AND_TIME'                            => 'Datum in čas zapadlosti:',
'LBL_START_DATE_AND_TIME'                          => 'Datum in čas začetka:',
'LBL_START_DATE'                                   => 'Datum začetka:',
'LBL_LIST_START_DATE'                              => 'Datum začetka',
'LBL_START_TIME'                                   => 'Čas začetka:',
'LBL_LIST_START_TIME'                              => 'Čas začetka',
'DATE_FORMAT'                                      => '(llll-mm-dd)',
'LBL_NONE'                                         => 'Nič',
'LBL_CONTACT'                                      => 'Kontakt:',
'LBL_EMAIL_ADDRESS'                                => 'e-poštni naslov:',
'LBL_PHONE'                                        => 'Telefon:',
'LBL_EMAIL'                                        => 'E-pošta:',
'LBL_DESCRIPTION_INFORMATION'                      => 'Opisne informacije',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_NAME'                                         => 'Ime:',
'LBL_CONTACT_NAME'                                 => 'Ime kontakta ',
'LBL_LIST_COMPLETE'                                => 'Končano:',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_DATE_DUE_FLAG'                                => 'Ni datuma zapadlosti',
'LBL_DATE_START_FLAG'                              => 'Ni datuma začetka',
'ERR_DELETE_RECORD'                                => 'Za izbris kontakta morate definirati številko zapisa.',
'ERR_INVALID_HOUR'                                 => 'Prosim vnesite uro med 0 in 24',
'LBL_DEFAULT_STATUS'                               => 'Se ni začelo',
'LBL_DEFAULT_PRIORITY'                             => 'srednja',
'LBL_LIST_MY_TASKS'                                => 'Moje odprte Naloge',
'LNK_NEW_CALL'                                     => 'Načrtuj klic',
'LNK_NEW_MEETING'                                  => 'Načrtuj sestanek',
'LNK_NEW_TASK'                                     => 'Ustvari nalogo',
'LNK_NEW_NOTE'                                     => 'Ustvari opombo ali priponko',
'LNK_NEW_EMAIL'                                    => 'Arhiviranje e-pošte',
'LNK_CALL_LIST'                                    => 'Klici',
'LNK_MEETING_LIST'                                 => 'Sestanek',
'LNK_TASK_LIST'                                    => 'Naloge',
'LNK_NOTE_LIST'                                    => 'Opombe',
'LNK_EMAIL_LIST'                                   => 'E-pošta',
'LNK_VIEW_CALENDAR'                                => 'Danes',
'LNK_IMPORT_TASKS'                                 => 'Uvozi naloge',
'LBL_CONTACT_FIRST_NAME'                           => 'Ime kontakta',
'LBL_CONTACT_LAST_NAME'                            => 'Priimek kontakta',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljeno uporabniku',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_LIST_DATE_MODIFIED'                           => 'Datum spremembe',
'LBL_CONTACT_ID'                                   => 'ID kontakta:',
'LBL_PARENT_ID'                                    => 'Nadrejeni ID:',
'LBL_CONTACT_PHONE'                                => 'Telefon kontakta:',
'LBL_PARENT_NAME'                                  => 'Nadrejeni tip:',
'LBL_ACTIVITIES_REPORTS'                           => 'Poročilo aktivnosti',
'LBL_TASK_INFORMATION'                             => 'Pregled naloge',
);?>
