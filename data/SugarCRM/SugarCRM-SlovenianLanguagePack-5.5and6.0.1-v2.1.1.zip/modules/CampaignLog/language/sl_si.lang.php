<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_LIST_ID'                                      => 'Seznam pričakovanj, ID',
'LBL_ID'                                           => 'ID',
'LBL_TARGET_TRACKER_KEY'                           => 'Ključ iskanja Tarč',
'LBL_TARGET_ID'                                    => 'ID Tarče',
'LBL_TARGET_TYPE'                                  => 'Tip Tarče',
'LBL_ACTIVITY_TYPE'                                => 'Tip aktivnosti',
'LBL_ACTIVITY_DATE'                                => 'Datum aktivnosti',
'LBL_RELATED_ID'                                   => 'Povezani Id',
'LBL_RELATED_TYPE'                                 => 'Povezan tip',
'LBL_DELETED'                                      => 'Izbrisano',
'LBL_MODULE_NAME'                                  => 'Potek Kampanje',
'LBL_LIST_RECIPIENT_EMAIL'                         => 'Naslovnikov e-poštni naslov',
'LBL_LIST_RECIPIENT_NAME'                          => 'Naslovnikovo ime',
'LBL_ARCHIVED'                                     => 'Arhivirano',
'LBL_HITS'                                         => 'Zadetki',
'LBL_CAMPAIGN_NAME'                                => 'Ime:',
'LBL_CAMPAIGN'                                     => 'Kampanja:',
'LBL_NAME'                                         => 'Ime: ',
'LBL_INVITEE'                                      => 'Kontakti',
'LBL_LIST_CAMPAIGN_NAME'                           => 'Kampanja',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_TYPE'                                    => 'Tip',
'LBL_LIST_END_DATE'                                => 'Datum zaključka',
'LBL_DATE_ENTERED'                                 => 'Datum vstopa',
'LBL_DATE_MODIFIED'                                => 'Datum spremembe',
'LBL_MODIFIED'                                     => 'Spremenil: ',
'LBL_CREATED'                                      => 'Ustvaril: ',
'LBL_TEAM'                                         => 'Ekipa: ',
'LBL_ASSIGNED_TO'                                  => 'Dodeljeno: ',
'LBL_CAMPAIGN_START_DATE'                          => 'Datum začetka: ',
'LBL_CAMPAIGN_END_DATE'                            => 'Datum konca: ',
'LBL_CAMPAIGN_STATUS'                              => 'Status: ',
'LBL_CAMPAIGN_BUDGET'                              => 'Proračun: ',
'LBL_CAMPAIGN_EXPECTED_COST'                       => 'Pričakovani stroški: ',
'LBL_CAMPAIGN_ACTUAL_COST'                         => 'Dejanski stroški: ',
'LBL_CAMPAIGN_EXPECTED_REVENUE'                    => 'Pričakovani prihodki: ',
'LBL_CAMPAIGN_TYPE'                                => 'Tip: ',
'LBL_CAMPAIGN_OBJECTIVE'                           => 'Cilj: ',
'LBL_CAMPAIGN_CONTENT'                             => 'Opis: ',
'LBL_CREATED_LEAD'                                 => 'Ustvarjen potencial',
'LBL_CREATED_CONTACT'                              => 'Ustvarjen kontakt',
'LBL_LIST_FORM_TITLE'                              => 'Ciljne Kampanje',
'LBL_LIST_ACTIVITY_DATE'                           => 'Datum aktivnosti',
'LBL_LIST_CAMPAIGN_OBJECTIVE'                      => 'Cilji Kampanje',
'LBL_RELATED'                                      => 'Povezano',
'LBL_CLICKED_URL_KEY'                              => 'Kliknjen URL Ključ',
'LBL_URL_CLICKED'                                  => 'URL Kliknjen',
'LBL_MORE_INFO'                                    => 'Več informacij',
'LBL_CAMPAIGNS'                                    => 'Kampanje',
);?>
