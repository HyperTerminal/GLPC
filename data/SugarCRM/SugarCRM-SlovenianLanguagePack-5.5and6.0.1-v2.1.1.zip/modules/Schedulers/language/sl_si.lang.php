<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_OOTB_WORKFLOW'                                => 'Procesiraj Naloge delovnega toka',
'LBL_OOTB_REPORTS'                                 => 'Poženi generiranje poročila o načrtovanih nalogah',
'LBL_OOTB_IE'                                      => 'Preveri prihajujoče E-nabiralnike',
'LBL_OOTB_BOUNCE'                                  => 'Poženi nočni proces odbitih (bounced) kampanjskih mailov',
'LBL_OOTB_CAMPAIGN'                                => 'Poženi nočne masovne Email kampanje',
'LBL_OOTB_PRUNE'                                   => 'Očisti bazo podatkov 1. v mesecu',
'LBL_OOTB_TRACKER'                                 => 'Prune tracker tabelo',
'LBL_UPDATE_TRACKER_SESSIONS'                      => 'Posodobi tracker_sessions tabelo',
'LBL_LIST_JOB_INTERVAL'                            => 'Interval:',
'LBL_LIST_LIST_ORDER'                              => 'Urniki:',
'LBL_LIST_NAME'                                    => 'Urnik:',
'LBL_LIST_RANGE'                                   => 'Obseg:',
'LBL_LIST_REMOVE'                                  => 'Odstrani:',
'LBL_LIST_STATUS'                                  => 'Status:',
'LBL_LIST_TITLE'                                   => 'Seznam urnika:',
'LBL_LIST_EXECUTE_TIME'                            => 'Zagnal se bo ob:',
'LBL_SUN'                                          => 'Nedelja',
'LBL_MON'                                          => 'Ponedeljek',
'LBL_TUE'                                          => 'Torek',
'LBL_WED'                                          => 'Sreda',
'LBL_THU'                                          => 'Četrtek',
'LBL_FRI'                                          => 'Petek',
'LBL_SAT'                                          => 'Sobota',
'LBL_ALL'                                          => 'Vsak dan',
'LBL_EVERY_DAY'                                    => 'Vsak dan ',
'LBL_AT_THE'                                       => 'v ',
'LBL_EVERY'                                        => 'Vsak ',
'LBL_FROM'                                         => 'Od ',
'LBL_ON_THE'                                       => 'na ',
'LBL_RANGE'                                        => ' do ',
'LBL_AT'                                           => ' pri ',
'LBL_IN'                                           => ' v ',
'LBL_AND'                                          => 'in',
'LBL_MINUTES'                                      => 'minute ',
'LBL_HOUR'                                         => 'ure',
'LBL_HOUR_SING'                                    => 'ura',
'LBL_MONTH'                                        => 'Mesec',
'LBL_OFTEN'                                        => 'Čim pogosteje.',
'LBL_MIN_MARK'                                     => 'minutna oznaka',
'LBL_MINS'                                         => 'min',
'LBL_HOURS'                                        => 'ure',
'LBL_DAY_OF_MONTH'                                 => 'datum',
'LBL_MONTHS'                                       => 'mes.',
'LBL_DAY_OF_WEEK'                                  => 'dan',
'LBL_CRONTAB_EXAMPLES'                             => 'The above uses standard crontab notation.',
'LBL_ALWAYS'                                       => 'Vedno',
'LBL_CATCH_UP'                                     => 'Execute If Missed',
'LBL_CATCH_UP_WARNING'                             => 'Uncheck if this job may take more than a moment to run.',
'LBL_DATE_TIME_END'                                => 'Date & Time End',
'LBL_DATE_TIME_START'                              => 'Date & Time Start',
'LBL_INTERVAL'                                     => 'Interval',
'LBL_JOB'                                          => 'Job',
'LBL_LAST_RUN'                                     => 'Last Successful Run',
'LBL_MODULE_NAME'                                  => 'Sugar Scheduler',
'LBL_MODULE_TITLE'                                 => 'Schedulers',
'LBL_NAME'                                         => 'Job Name',
'LBL_NEVER'                                        => 'Never',
'LBL_NEW_FORM_TITLE'                               => 'New Schedule',
'LBL_PERENNIAL'                                    => 'perpetual',
'LBL_SEARCH_FORM_TITLE'                            => 'Scheduler Search',
'LBL_SCHEDULER'                                    => 'Scheduler:',
'LBL_STATUS'                                       => 'Status',
'LBL_TIME_FROM'                                    => 'Active From',
'LBL_TIME_TO'                                      => 'Active To',
'LBL_WARN_CURL_TITLE'                              => 'cURL opozorilo:',
'LBL_WARN_CURL'                                    => 'Opozorilo:',
'LBL_WARN_NO_CURL'                                 => 'This system does not have the cURL libraries enabled/compiled into the PHP module (--with-curl=/path/to/curl_library).  Please contact your administrator to resolve this issue.  Without the cURL functionality, the Scheduler cannot thread its jobs.',
'LBL_BASIC_OPTIONS'                                => 'Osnovne nastavitve',
'LBL_ADV_OPTIONS'                                  => 'Advanced Options',
'LBL_TOGGLE_ADV'                                   => 'Advanced Options',
'LBL_TOGGLE_BASIC'                                 => 'Basic Options',
'LNK_LIST_SCHEDULER'                               => 'Schedulers',
'LNK_NEW_SCHEDULER'                                => 'Create Scheduler',
'LNK_LIST_SCHEDULED'                               => 'Scheduled Jobs',
'SOCK_GREETING'                                    => 'This is the interface for SugarCRM Schedulers Service. 
[ Available daemon commands: start|restart|shutdown|status ]
To quit, type &#039;quit&#039;.  To shutdown the service &#039;shutdown&#039;.
',
'ERR_DELETE_RECORD'                                => 'You must specify a record number to delete the schedule.',
'ERR_CRON_SYNTAX'                                  => 'Napačna Cron sintaksa',
'NTC_DELETE_CONFIRMATION'                          => 'Are you sure you want to delete this record?',
'NTC_STATUS'                                       => 'Set status to Inactive to remove this schedule from the Scheduler dropdown lists',
'NTC_LIST_ORDER'                                   => 'Set the order this schedule will appear in the Scheduler dropdown lists',
'LBL_CRON_INSTRUCTIONS_WINDOWS'                    => 'To Setup Windows Scheduler',
'LBL_CRON_INSTRUCTIONS_LINUX'                      => 'To Setup Crontab',
'LBL_CRON_LINUX_DESC'                              => 'Add this line to your crontab: ',
'LBL_CRON_WINDOWS_DESC'                            => 'Create a batch file with the following commands: ',
'LBL_NO_PHP_CLI'                                   => 'If your host does not have the PHP binary available, you can use wget or curl to launch your Jobs.&lt;br&gt;for wget: &lt;b&gt;*    *    *    *    *    wget --quiet --non-verbose http://sugardevel.agenda.si/doba/cron.php &gt; /dev/null 2&gt;&1&lt;/b&gt;&lt;br&gt;for curl: &lt;b&gt;*    *    *    *    *    curl --silent http://sugardevel.agenda.si/doba/cron.php &gt; /dev/null 2&gt;&1',
'LBL_JOBS_SUBPANEL_TITLE'                          => 'Job Log',
'LBL_EXECUTE_TIME'                                 => 'Execute Time',
'LBL_REFRESHJOBS'                                  => 'Refresh Jobs ',
'LBL_POLLMONITOREDINBOXES'                         => 'Check Inbound Mail Accounts',
'LBL_RUNMASSEMAILCAMPAIGN'                         => 'Run Nightly Mass Email Campaigns',
'LBL_POLLMONITOREDINBOXESFORBOUNCEDCAMPAIGNEMAILS' => 'Run Nightly Process Bounced Campaign Emails',
'LBL_PRUNEDATABASE'                                => 'Prune Database on 1st of Month',
'LBL_TRIMTRACKER'                                  => 'Prune Tracker Tables',
);?>
