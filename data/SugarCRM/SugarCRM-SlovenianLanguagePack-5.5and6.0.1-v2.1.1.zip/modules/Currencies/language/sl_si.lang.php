<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Denarne valute',
'LBL_LIST_FORM_TITLE'                              => 'Denarne valute',
'LBL_CURRENCY'                                     => 'Denarne valute',
'LBL_ADD'                                          => 'Dodaj',
'LBL_MERGE'                                        => 'Poveži',
'LBL_MERGE_TXT'                                    => 'Prosimo označite valute, ki bi jih radi povezali z izbrano valuto. To bo zbrisalo vse valute s kljukico in ponovno dodelilo vrednosti v povezavi z izbrano valuto.',
'LBL_US_DOLLAR'                                    => 'Ameriški dolar',
'LBL_DELETE'                                       => 'Izbris',
'LBL_LIST_SYMBOL'                                  => 'Simbol denarne valute',
'LBL_LIST_NAME'                                    => 'Ime denarne valute',
'LBL_LIST_ISO4217'                                 => 'ISO 4217 Koda',
'LBL_LIST_ISO4217_HELP'                            => 'Vnesite 3 znake dolgo ISO 4217 kodo, ki definira ime in simbol valute',
'LBL_UPDATE'                                       => 'Posodobi',
'LBL_LIST_RATE'                                    => 'Pretvorbeno razmerje',
'LBL_LIST_RATE_HELP'                               => 'Menjalni tečaj 0.5 za Euro, pomeni da 10 USD = 5 €.',
'LBL_LIST_STATUS'                                  => 'Status',
'LNK_NEW_CONTACT'                                  => 'Nov kontakt',
'LNK_NEW_ACCOUNT'                                  => 'Nov partner',
'LNK_NEW_OPPORTUNITY'                              => 'Nova priložnost',
'LNK_NEW_CASE'                                     => 'Nova reklamacija',
'LNK_NEW_NOTE'                                     => 'Ustvari opombo ali priponko',
'LNK_NEW_CALL'                                     => 'Nov klic',
'LNK_NEW_EMAIL'                                    => 'Nova e-pošta',
'LNK_NEW_MEETING'                                  => 'Nov sestanek',
'LNK_NEW_TASK'                                     => 'Ustvari nalogo',
'NTC_DELETE_CONFIRMATION'                          => 'Ste prepričani, da želite izbrisati ta vnos? Vsak vnos ki uporablja to denarno valuto, bo pretvorjen v prednastavljeno sistemsko valuto. Morda je bolje, da jo nastavite kot neaktivno.',
'LBL_BELOW_MIN'                                    => 'Menjalni tečaj mora biti več kot 0',


'currency_status_dom' => array(
'Active'                                           => 'Aktivno',
'Inactive'                                         => 'Neaktivno',
),
);?>
