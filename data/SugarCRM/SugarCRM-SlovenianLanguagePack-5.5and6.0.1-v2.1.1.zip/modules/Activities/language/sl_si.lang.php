<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Aktivnosti',
'LBL_MODULE_TITLE'                                 => 'Aktivnosti: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje Aktivnosti',
'LBL_LIST_FORM_TITLE'                              => 'Seznam Aktivnosti',
'LBL_LIST_SUBJECT'                                 => 'Predmet',
'LBL_LIST_CONTACT'                                 => 'Kontakt',
'LBL_LIST_RELATED_TO'                              => 'Povezano z',
'LBL_LIST_DATE'                                    => 'Datum',
'LBL_LIST_TIME'                                    => 'Čas začetka',
'LBL_LIST_CLOSE'                                   => 'Zaprto',
'LBL_SUBJECT'                                      => 'Predmet:',
'LBL_STATUS'                                       => 'Status:',
'LBL_LOCATION'                                     => 'Lokacija:',
'LBL_DATE_TIME'                                    => 'Datum in čas začetka:',
'LBL_DATE'                                         => 'Datum začetka:',
'LBL_TIME'                                         => 'Čas začetka:',
'LBL_DURATION'                                     => 'Trajanje:',
'LBL_DURATION_MINUTES'                             => 'Trajanje v minutah:',
'LBL_HOURS_MINS'                                   => '(ure/minute)',
'LBL_CONTACT_NAME'                                 => 'Ime kontakta: ',
'LBL_MEETING'                                      => 'Sestanek:',
'LBL_DESCRIPTION_INFORMATION'                      => 'Opisne informacije',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_COLON'                                        => ':',
'LBL_DEFAULT_STATUS'                               => 'Načrtovano',
'LNK_NEW_CALL'                                     => 'Načrtuj klic',
'LNK_NEW_MEETING'                                  => 'Načrtuj sestanek',
'LNK_NEW_TASK'                                     => 'Ustvari Nalogo',
'LNK_NEW_NOTE'                                     => 'Ustvari Opombo ali Priponko',
'LNK_NEW_EMAIL'                                    => 'Ustvari arhivirano E-pošto',
'LNK_CALL_LIST'                                    => 'Klici',
'LNK_MEETING_LIST'                                 => 'Sestanki',
'LNK_TASK_LIST'                                    => 'Naloge',
'LNK_NOTE_LIST'                                    => 'Opombe',
'LNK_EMAIL_LIST'                                   => 'E-pošta',
'ERR_DELETE_RECORD'                                => 'Za izbris Partnerja je potrebno specificirati Številko vnosa.',
'NTC_REMOVE_INVITEE'                               => 'Ste prepričani, da želite odstraniti osebo iz seznama povabljenih na sestanek?',
'LBL_INVITEE'                                      => 'Povabljeni',
'LBL_LIST_DIRECTION'                               => 'Smer',
'LBL_DIRECTION'                                    => 'Smer',
'LNK_NEW_APPOINTMENT'                              => 'Nov sestanek',
'LNK_VIEW_CALENDAR'                                => 'Danes',
'LBL_OPEN_ACTIVITIES'                              => 'Odpri aktivnosti',
'LBL_HISTORY'                                      => 'Zgodovina',
'LBL_UPCOMING'                                     => 'Prihajajoči sestanki',
'LBL_TODAY'                                        => 'skozi',
'LBL_NEW_TASK_BUTTON_TITLE'                        => 'Ustvari nalogo [Alt+N]',
'LBL_NEW_TASK_BUTTON_KEY'                          => 'Ustvari nalogo',
'LBL_NEW_TASK_BUTTON_LABEL'                        => 'Ustvari nalogo',
'LBL_SCHEDULE_MEETING_BUTTON_TITLE'                => 'Načrtuj sestanek [Alt+M]',
'LBL_SCHEDULE_MEETING_BUTTON_KEY'                  => 'Načrtuj sestanek',
'LBL_SCHEDULE_MEETING_BUTTON_LABEL'                => 'Načrtuj sestanek',
'LBL_SCHEDULE_CALL_BUTTON_TITLE'                   => 'Načrtuj klic [Alt+C]',
'LBL_SCHEDULE_CALL_BUTTON_KEY'                     => 'Načrtuj klic',
'LBL_SCHEDULE_CALL_BUTTON_LABEL'                   => 'Načrtuj klic',
'LBL_NEW_NOTE_BUTTON_TITLE'                        => 'Dodaj opombo ali priponko [Alt+T]',
'LBL_NEW_NOTE_BUTTON_KEY'                          => 'Dodaj opombo ali priponko',
'LBL_NEW_NOTE_BUTTON_LABEL'                        => 'Dodaj opombo ali priponko',
'LBL_TRACK_EMAIL_BUTTON_TITLE'                     => 'Arhiviraj e-pošto [Alt+K]',
'LBL_TRACK_EMAIL_BUTTON_KEY'                       => 'Arhiviraj E-pošto',
'LBL_TRACK_EMAIL_BUTTON_LABEL'                     => 'Arhiviraj E-pošto',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_DUE_DATE'                                => 'Datum zapadlosti',
'LBL_LIST_LAST_MODIFIED'                           => 'Nazadnje spremenjeno',
'NTC_NONE_SCHEDULED'                               => 'Nič ni načrtovano.',
'LNK_IMPORT_CALLS'                                 => 'Uvozi klice',
'LNK_IMPORT_MEETINGS'                              => 'Uvozi sestanke',
'LNK_IMPORT_TASKS'                                 => 'Uvozi naloge',
'LNK_IMPORT_NOTES'                                 => 'Uvozi opombe',
'NTC_NONE'                                         => 'Nič',
'LBL_ACCEPT_THIS'                                  => 'Sprejmi?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Odpre aktivnosti',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',


'appointment_filter_dom' => array(
'today'                                            => 'danes',
'tomorrow'                                         => 'jutri',
'this Saturday'                                    => 'ta teden',
'next Saturday'                                    => 'naslednji teden',
'last this_month'                                  => 'ta mesec',
'last next_month'                                  => 'naslednji mesec',
),
);?>
