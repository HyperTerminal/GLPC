<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_STEP_1'                                       => 'Prvi korak: Izberite modul in predlogo',
'LBL_MAILMERGE_MODULE'                             => 'Izberite modul: ',
'LBL_MAILMERGE_SELECTED_MODULE'                    => 'Izberite modul: ',
'LBL_MAILMERGE_TEMPLATES'                          => 'Izberite predlogo: ',
'LBL_STEP_2'                                       => '2. korak: Izberite objekte za spojitev',
'LBL_MAILMERGE_OBJECTS'                            => 'Izberite objekte: ',
'LBL_STEP_3'                                       => 'Nastavi povezavo s Kontakti',
'LBL_STEP_4'                                       => 'Pregled in zaključek',
'LBL_SELECTED_MODULE'                              => 'Izbran modul: ',
'LBL_SELECTED_TEMPLATE'                            => 'Izbrana predloga: ',
'LBL_SELECTED_ITEMS'                               => 'Izbrani predmeti: ',
'LBL_STEP_5'                                       => 'Končano spajanje e-Pošte',
'LBL_MERGED_FILE'                                  => 'Združena datoteka: ',
'LNK_NEW_MAILMERGE'                                => 'Začni s spajanjem e-pošte',
'LNK_UPLOAD_TEMPLATE'                              => 'Naloži predlogo',
'LBL_DOC_NAME'                                     => 'Ime dokumenta:',
'LBL_FILENAME'                                     => 'Ime datoteke:',
'LBL_DOC_VERSION'                                  => 'Pregled:',
'LBL_DOC_DESCRIPTION'                              => 'Opis:',
'LBL_LIST_NAME'                                    => 'Ime',
'LBL_LIST_RELATIONSHIP'                            => 'Nastavi povezanost s Kontaktom',
'LBL_FINISH'                                       => 'Začni s spajanjem',
'LBL_NEXT'                                         => 'Naprej &gt;',
'LBL_BACK'                                         => '&lt; Nazaj',
'LBL_START'                                        => 'Začni ponovno',
'LBL_TEMPLATE_NOTICE'                              => 'Predloge so Microsoft Word dokumenti, ki zajemajo združevalna polja, ki so bila naložena in shranjena v modul Dokumenti.',
'LBL_CONTAINS_CONTACT_INFO'                        => 'Izbrana predloga vsebuje povezano ',
'LBL_ADDIN_NOTICE'                                 => 'Zahteva instalacijo Sugar Mail Merge add-in v Microsoft Word.',
'LBL_BROWSER_NOTICE'                               => 'Uporabljati morate IE 6.0 ali novejši, da lahko izvedete spajanje.',
);?>
