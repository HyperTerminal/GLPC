<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Koledar',
'LBL_MODULE_TITLE'                                 => 'Koledar',
'LNK_NEW_CALL'                                     => 'Načrtuj klic',
'LNK_NEW_MEETING'                                  => 'Načrtuj sestanek',
'LNK_NEW_APPOINTMENT'                              => 'Ustvari sestanek',
'LNK_NEW_TASK'                                     => 'Ustvari Nalogo',
'LNK_CALL_LIST'                                    => 'Klici',
'LNK_MEETING_LIST'                                 => 'Sestanki',
'LNK_TASK_LIST'                                    => 'Naloge',
'LNK_VIEW_CALENDAR'                                => 'Danes',
'LNK_IMPORT_CALLS'                                 => 'Uvozi klice',
'LNK_IMPORT_MEETINGS'                              => 'Uvozi sestanke',
'LNK_IMPORT_TASKS'                                 => 'Uvozi naloge',
'LBL_MONTH'                                        => 'Mesec',
'LBL_DAY'                                          => 'Dan',
'LBL_YEAR'                                         => 'Leto',
'LBL_WEEK'                                         => 'Teden',
'LBL_PREVIOUS_MONTH'                               => 'Prejšnji mesec',
'LBL_PREVIOUS_DAY'                                 => 'Prejšnji dan',
'LBL_PREVIOUS_YEAR'                                => 'Prejšnje leto',
'LBL_PREVIOUS_WEEK'                                => 'Prejšnji teden',
'LBL_NEXT_MONTH'                                   => 'Naslednji mesec',
'LBL_NEXT_DAY'                                     => 'Naslednji dan',
'LBL_NEXT_YEAR'                                    => 'Naslednje leto',
'LBL_NEXT_WEEK'                                    => 'Naslednji teden',
'LBL_AM'                                           => 'Dopoldne',
'LBL_PM'                                           => 'Popoldne',
'LBL_SCHEDULED'                                    => 'Planirano',
'LBL_BUSY'                                         => 'Zaseden',
'LBL_CONFLICT'                                     => 'Konflikt',
'LBL_USER_CALENDARS'                               => 'Koledarji uporabnikov',
'LBL_SHARED'                                       => 'Dano v skupno rabo',
'LBL_PREVIOUS_SHARED'                              => 'Prejšnji',
'LBL_NEXT_SHARED'                                  => 'Naslednji',
'LBL_SHARED_CAL_TITLE'                             => 'Skupni koledar',
'LBL_USERS'                                        => 'Uporabnik',
'LBL_REFRESH'                                      => 'Osveži',
'LBL_EDIT'                                         => 'Uredi',
'LBL_SELECT_USERS'                                 => 'Izberite uporabnike za prikaz koledarja',
'LBL_FILTER_BY_TEAM'                               => 'Filtriraj seznam uporabnikov po timih:',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno ',
'LBL_DATE'                                         => 'Začetni datum in čas',
);?>
