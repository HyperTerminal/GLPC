<?php
/*********************************************************************************

*********************************************************************************/
$mod_strings = array (
  'ShowActiveUsers' => 'Prikaži aktivne uporabnike',
  'ShowLastModifiedRecords' => 'Zadnjih 10 spremenjenih vnosov',
  'ShowTopUser' => 'Naj uporabnik',
  'ShowMyModuleUsage' => 'Moja uporabna modulov',
  'ShowMyWeeklyActivities' => 'Moje tedenske aktivnosti',
  'ShowTop3ModulesUsed' => 'Moji 3 najbolj uporabjeni moduli',
  'ShowLoggedInUserCount' => 'Število aktivnih uporabnikov',
  'ShowMyCumulativeLoggedInTime' => 'Moj skupni čas prijave (ta teden)',
  'ShowUsersCumulativeLoggedInTime' => 'Skupni čas prijave uporabnikov  (ta teden)',
  'action' => 'Aktivnost',
  'active_users' => 'Število aktivnih uporabnikov',
  'date_modified' => 'Datum zadnje aktivnosti',
  'different_modules_accessed' => 'Število modulov, ki so bili uporabljeni',
  'first_name' => 'Ime',
  'item_id' => 'ID',
  'item_summary' => 'Naziv',
  'last_action' => 'Zadnja aktivnost Datum/Čas',
  'last_name' => 'Priimek',
  'module_name' => 'Ime modula',
  'records_modified' => 'Skupno spremenjenih vnosov',
  'top_module' => 'Najbolj uporaben modul',
  'total_count' => 'Skupno število ogledov strani',
  'total_login_time' => 'Čas (hh:mm:ss)',
  'user_name' => 'Uporabniško ime',
  'users' => 'Uporabniki',
  'LBL_ENABLE' => 'Vklopljeno',
  'LBL_MODULE_NAME_TITLE' => 'Sledilniki (Trackers)',
  'LBL_TRACKER_SETTINGS' => 'Nastavitve sledilnika',
  'LBL_TRACKER_QUERIES_DESC' => 'Poizvedbe sledilnika',
  'LBL_TRACKER_QUERIES_HELP' => 'Track SQL statements when &quot;Log slow queries&quot; is enabled and the query execution time exceeds the &quot;Slow query time threshold&quot; value',
  'LBL_TRACKER_PERF_DESC' => 'Tracker Performance',
  'LBL_TRACKER_PERF_HELP' => 'Track database roundtrips, files accessed and memory usage',
  'LBL_TRACKER_SESSIONS_DESC' => 'Seja sledilnika',
  'LBL_TRACKER_SESSIONS_HELP' => 'Track active users and users’ session information',
  'LBL_TRACKER_DESC' => 'Aktivnosti sledilnika',
  'LBL_TRACKER_HELP' => 'Track user’s page views (modules and records accessed) and record saves',
  'LBL_TRACKER_PRUNE_INTERVAL' => 'Number of days of Tracker data to store when Scheduler prunes the tables',
  'LBL_TRACKER_PRUNE_RANGE' => 'Število dni',
);


?>