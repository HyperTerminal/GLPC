<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Dokumenti',
'LBL_MODULE_TITLE'                                 => 'Dokumenti: domov',
'LNK_NEW_DOCUMENT'                                 => 'Ustvari dokument',
'LNK_DOCUMENT_LIST'                                => 'Seznam dokumentov',
'LBL_DOC_REV_HEADER'                               => 'Revizije dokumentov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje dokumentov',
'LBL_DOCUMENT_ID'                                  => 'ID dokumenta',
'LBL_NAME'                                         => 'Ime dokumenta',
'LBL_DESCRIPTION'                                  => 'Opis',
'LBL_CATEGORY'                                     => 'Kategorija',
'LBL_SUBCATEGORY'                                  => 'Podkategorija',
'LBL_STATUS'                                       => 'Status',
'LBL_CREATED_BY'                                   => 'Ustvaril',
'LBL_DATE_ENTERED'                                 => 'Datum vnosa',
'LBL_DATE_MODIFIED'                                => 'Datum spremembe',
'LBL_DELETED'                                      => 'Izbrisano',
'LBL_MODIFIED'                                     => 'Spremenjeni po IDju',
'LBL_MODIFIED_USER'                                => 'Spremenil',
'LBL_CREATED'                                      => 'Ustvaril',
'LBL_REVISIONS'                                    => 'Revizije',
'LBL_RELATED_DOCUMENT_ID'                          => 'ID povezanih dokumentov',
'LBL_RELATED_DOCUMENT_REVISION_ID'                 => 'ID revizij povezanih dokumentov',
'LBL_IS_TEMPLATE'                                  => 'Je predloga',
'LBL_TEMPLATE_TYPE'                                => 'Tip Dokumenta',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_REVISION_NAME'                                => 'Število revizije',
'LBL_MIME'                                         => 'Tip MIME',
'LBL_REVISION'                                     => 'Revizija',
'LBL_DOCUMENT'                                     => 'Povezan dokument',
'LBL_LATEST_REVISION'                              => 'Zadnja revizija',
'LBL_CHANGE_LOG'                                   => 'Spremeni dnevnik (log)',
'LBL_ACTIVE_DATE'                                  => 'Datum objave',
'LBL_EXPIRATION_DATE'                              => 'Datum veljevnosti (do)',
'LBL_FILE_EXTENSION'                               => 'Končnica datoteke',
'LBL_LAST_REV_MIME_TYPE'                           => 'Zadnja revizija MIME tipa',
'LBL_CAT_OR_SUBCAT_UNSPEC'                         => 'Nedefinirano',
'LBL_NEW_FORM_TITLE'                               => 'Nov dokument',
'LBL_DOC_NAME'                                     => 'Ime dokumenta:',
'LBL_FILENAME'                                     => 'Ime datoteke:',
'LBL_DOC_VERSION'                                  => 'Revizija:',
'LBL_CATEGORY_VALUE'                               => 'Kategorija:',
'LBL_SUBCATEGORY_VALUE'                            => 'Podkategorija:',
'LBL_DOC_STATUS'                                   => 'Status:',
'LBL_LAST_REV_CREATOR'                             => 'Revizijo ustvaril:',
'LBL_LASTEST_REVISION_NAME'                        => 'Ime zadnje revizije:',
'LBL_SELECTED_REVISION_NAME'                       => 'Ime izbrane revizije:',
'LBL_CONTRACT_STATUS'                              => 'Status pogodbe:',
'LBL_CONTRACT_NAME'                                => 'Ime pogodbe:',
'LBL_LAST_REV_DATE'                                => 'Datum revizije:',
'LBL_DOWNNLOAD_FILE'                               => 'Prenesi datoteko:',
'LBL_DET_RELATED_DOCUMENT'                         => 'Povezan Dokument:',
'LBL_DET_RELATED_DOCUMENT_VERSION'                 => 'Povezana revizija Dokumenta:',
'LBL_DET_IS_TEMPLATE'                              => 'Predloga? :',
'LBL_DET_TEMPLATE_TYPE'                            => 'Tip Dokumenta:',
'LBL_DOC_DESCRIPTION'                              => 'Opis:',
'LBL_DOC_ACTIVE_DATE'                              => 'Datum objave:',
'LBL_DOC_EXP_DATE'                                 => 'Datum veljavnosti (do):',
'LBL_LIST_FORM_TITLE'                              => 'Seznam Dokumentov',
'LBL_LIST_DOCUMENT'                                => 'Dokument',
'LBL_LIST_CATEGORY'                                => 'Kategorija',
'LBL_LIST_SUBCATEGORY'                             => 'Podkategorija',
'LBL_LIST_REVISION'                                => 'Revizija',
'LBL_LIST_LAST_REV_CREATOR'                        => 'Objavil',
'LBL_LIST_LAST_REV_DATE'                           => 'Datum revizije',
'LBL_LIST_VIEW_DOCUMENT'                           => 'Pogled',
'LBL_LIST_DOWNLOAD'                                => 'Prenesi',
'LBL_LIST_ACTIVE_DATE'                             => 'Datum objave',
'LBL_LIST_EXP_DATE'                                => 'Datum veljavnosti (do)',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LINKED_ID'                                    => 'Povezan ID',
'LBL_SELECTED_REVISION_ID'                         => 'ID izbrane revizije',
'LBL_LATEST_REVISION_ID'                           => 'ID zadnje revizije',
'LBL_SELECTED_REVISION_FILENAME'                   => 'Ime datoteke izbrane revizije',
'LBL_FILE_URL'                                     => 'URL datoteke',
'LBL_REVISIONS_PANEL'                              => 'Podrobnosti revizije',
'LBL_REVISIONS_SUBPANEL'                           => 'Revizije',
'LBL_SF_DOCUMENT'                                  => 'Ime dokumenta:',
'LBL_SF_CATEGORY'                                  => 'Kategorija:',
'LBL_SF_SUBCATEGORY'                               => 'Podkategorija:',
'LBL_SF_ACTIVE_DATE'                               => 'Datum objave:',
'LBL_SF_EXP_DATE'                                  => 'Datum veljavnosti (do):',
'DEF_CREATE_LOG'                                   => 'Dokument ustvarjen',
'ERR_DOC_NAME'                                     => 'Ime Dokumenta',
'ERR_DOC_ACTIVE_DATE'                              => 'Datum objave',
'ERR_DOC_EXP_DATE'                                 => 'Datum veljavnosti (do)',
'ERR_FILENAME'                                     => 'Ime datoteke',
'ERR_DOC_VERSION'                                  => 'Verzija dokumenta',
'ERR_DELETE_CONFIRM'                               => 'Želite izbrisati revizijo Dokumenta?',
'ERR_DELETE_LATEST_VERSION'                        => 'Nimate dovoljenja za izbris zadnje revizije Dokumenta.',
'LNK_NEW_MAIL_MERGE'                               => 'Združi e-pošto',
'LBL_MAIL_MERGE_DOCUMENT'                          => 'Predloga spajanje e-pošte:',
'LBL_TREE_TITLE'                                   => 'Dokumenti',
'LBL_LIST_DOCUMENT_NAME'                           => 'Ime dokumenta',
'LBL_LIST_IS_TEMPLATE'                             => 'Predloga?',
'LBL_LIST_TEMPLATE_TYPE'                           => 'Tip dokumenta',
'LBL_LIST_SELECTED_REVISION'                       => 'Izbrana revizija',
'LBL_LIST_LATEST_REVISION'                         => 'Zadnja revizija',
'LBL_CONTRACTS_SUBPANEL_TITLE'                     => 'Povezane pogodbe',
'LBL_LAST_REV_CREATE_DATE'                         => 'Datum zadnja ustvarjene revizije',
'LBL_CONTRACTS'                                    => 'Pogodbe',
'LBL_CREATED_USER'                                 => 'Ustvarjen uporabnik',
'LBL_THEREVISIONS_SUBPANEL_TITLE'                  => 'Revizije',
'LBL_DOCUMENT_INFORMATION'                         => 'Pregled dokumenta',
);?>
