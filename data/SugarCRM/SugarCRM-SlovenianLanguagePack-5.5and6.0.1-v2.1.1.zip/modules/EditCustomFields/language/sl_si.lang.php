<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Uredi prilagojena polja',
'LBL_ADD_FIELD'                                    => 'Dodaj polje:',
'LBL_MODULE_TITLE'                                 => 'Uredi prilagojeno polje',
'LBL_MODULE_SELECT'                                => 'Uredi modul',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje modula',
'COLUMN_TITLE_NAME'                                => 'Ime polja',
'COLUMN_TITLE_DISPLAY_LABEL'                       => 'Prikaz oznake',
'COLUMN_TITLE_LABEL_VALUE'                         => 'Vredost oznake',
'COLUMN_TITLE_LABEL'                               => 'Oznaka polja',
'COLUMN_TITLE_DATA_TYPE'                           => 'Tip datuma',
'COLUMN_TITLE_MAX_SIZE'                            => 'Max velikost',
'COLUMN_TITLE_HELP_TEXT'                           => 'Tekst za pomoč',
'COLUMN_TITLE_COMMENT_TEXT'                        => 'Komentar',
'COLUMN_TITLE_REQUIRED_OPTION'                     => 'Obvezno polje',
'COLUMN_TITLE_DEFAULT_VALUE'                       => 'Prednastavljena vrednost',
'COLUMN_TITLE_DEFAULT_EMAIL'                       => 'Prednastavljena vrednost',
'COLUMN_TITLE_EXT1'                                => 'Dodatno meta polje 1',
'COLUMN_TITLE_EXT2'                                => 'Dodatno meta polje 2',
'COLUMN_TITLE_EXT3'                                => 'Dodatno meta polje 3',
'COLUMN_TITLE_FRAME_HEIGHT'                        => 'IFrame višina',
'COLUMN_TITLE_HTML_CONTENT'                        => 'HTML',
'COLUMN_TITLE_URL'                                 => 'Prednastavljen URL',
'COLUMN_TITLE_AUDIT'                               => 'Pregled',
'COLUMN_TITLE_REPORTABLE'                          => 'Za poročanje',
'COLUMN_TITLE_MIN_VALUE'                           => 'Min vrednost',
'COLUMN_TITLE_MAX_VALUE'                           => 'Max vrednost',
'COLUMN_TITLE_LABEL_ROWS'                          => 'Vrstic',
'COLUMN_TITLE_LABEL_COLS'                          => 'Stolpcev',
'COLUMN_TITLE_DISPLAYED_ITEM_COUNT'                => 'število prikazanih predmetov',
'COLUMN_TITLE_AUTOINC_NEXT'                        => 'Avto increment naslednje vrednosti',
'COLUMN_DISABLE_NUMBER_FORMAT'                     => 'Onemogoči obliko',
'LBL_DROP_DOWN_LIST'                               => 'Spustni seznam',
'LBL_RADIO_FIELDS'                                 => 'Radio polja',
'LBL_MULTI_SELECT_LIST'                            => 'Večizbirni seznam',
'COLUMN_TITLE_PRECISION'                           => 'Natančnost',
'MSG_DELETE_CONFIRM'                               => 'Ste prepričani, da želite izbrisati ta predmet?',
'POPUP_INSERT_HEADER_TITLE'                        => 'Dodaj prilagojeno polje',
'POPUP_EDIT_HEADER_TITLE'                          => 'Uredi prilagojeno polje',
'LNK_SELECT_CUSTOM_FIELD'                          => 'Izberi prilagojeno polje',
'LNK_REPAIR_CUSTOM_FIELD'                          => 'Popravi prilagojeno polje',
'LBL_MODULE'                                       => 'Modul',
'COLUMN_TITLE_MASS_UPDATE'                         => 'Masovno posodobi',
'COLUMN_TITLE_IMPORTABLE'                          => 'Uvozljivo',
'COLUMN_TITLE_DUPLICATE_MERGE'                     => 'Združi duplikate',
'LBL_LABEL'                                        => 'Oznaka',
'LBL_DATA_TYPE'                                    => 'Tip podatkov',
'LBL_DEFAULT_VALUE'                                => 'Prednastavljena vrednost',
'LBL_AUDITED'                                      => 'Preverjeno',
'LBL_REPORTABLE'                                   => 'Za poročanje',
'ERR_RESERVED_FIELD_NAME'                          => 'Rezervirana besedna zveza',
'ERR_SELECT_FIELD_TYPE'                            => 'Prosimo, izberite tip polja',
'LBL_BTN_ADD'                                      => 'Dodaj',
'LBL_BTN_EDIT'                                     => 'Uredi',
'LBL_GENERATE_URL'                                 => 'Generiraj URL',
'LBL_DEPENDENT_CHECKBOX'                           => 'Odvisen',
'LBL_DEPENDENT_TRIGGER'                            => 'Sprožilec',
'LBL_BTN_EDIT_VISIBILITY'                          => 'Uredi vidljivost',
'LBL_LINK_TARGET'                                  => 'Odpri povezavo v',
'LBL_IMAGE_WIDTH'                                  => 'širina',
'LBL_IMAGE_HEIGHT'                                 => 'višina',
'LBL_IMAGE_BORDER'                                 => 'border',
);?>
