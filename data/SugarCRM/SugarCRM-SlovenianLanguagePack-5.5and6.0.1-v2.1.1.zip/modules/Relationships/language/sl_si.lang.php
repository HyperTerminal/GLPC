<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_ID'                                           => 'ID Povezave',
'LBL_RELATIONSHIP_NAME'                            => 'Ime Povezave',
'LBL_LHS_MODULE'                                   => 'Ime LHS modula',
'LBL_LHS_TABLE'                                    => 'Ime LHS tabele',
'LBL_LHS_KEY'                                      => 'Ime LHS ključa',
'LBL_RHS_MODULE'                                   => 'Ime RHS modula',
'LBL_RHS_TABLE'                                    => 'Ime RHS tabele',
'LBL_RHS_KEY'                                      => 'Ime LHS ključa',
'LBL_JOIN_TABLE'                                   => 'Združi ime tabele',
'LBL_JOIN_KEY_LHS'                                 => 'Združi LHS ključ',
'LBL_JOIN_KEY_RHS'                                 => 'Združi RHS ključ',
'LBL_RELATIONSHIP_TYPE'                            => 'Tip razmerja',
'LBL_RELATIONSHIP_ROLE_COLUMN'                     => 'Ime vloge povezave',
'LBL_RELATIONSHIP_ROLE_COLUMN_VALUE'               => 'Vrednost vloge povezave',
'LBL_REVERSE'                                      => 'Obratno',
'LBL_DELETED'                                      => 'Zbrisano',
);?>
