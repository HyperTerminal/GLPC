<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Projektne naloge',
'LBL_MODULE_TITLE'                                 => 'Projektne naloge: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje po projektnih nalogah',
'LBL_LIST_FORM_TITLE'                              => 'Seznam projektnih nalog',
'LBL_EDIT_TASK_IN_GRID_TITLE'                      => 'Uredi nalogo v mreži',
'LBL_ID'                                           => 'Id:',
'LBL_PROJECT_TASK_ID'                              => 'ID projektne naloge:',
'LBL_PROJECT_ID'                                   => 'ID projakta:',
'LBL_DATE_ENTERED'                                 => 'Datum vnosa:',
'LBL_DATE_MODIFIED'                                => 'Datum spremembe:',
'LBL_ASSIGNED_USER_ID'                             => 'Dodeljeno:',
'LBL_MODIFIED_USER_ID'                             => 'Spremenil uporabnik ID:',
'LBL_CREATED_BY'                                   => 'Ustvaril:',
'LBL_TEAM_ID'                                      => 'Ekipa:',
'LBL_NAME'                                         => 'Ime:',
'LBL_STATUS'                                       => 'Status:',
'LBL_DATE_DUE'                                     => 'Datum zaključka:',
'LBL_TIME_DUE'                                     => 'Čas zaključka:',
'LBL_RESOURCE'                                     => 'Vir:',
'LBL_PREDECESSORS'                                 => 'Predhodniki:',
'LBL_DATE_START'                                   => 'Datum začetka:',
'LBL_DATE_FINISH'                                  => 'Datum zaključka:',
'LBL_TIME_START'                                   => 'Čas začetka:',
'LBL_TIME_FINISH'                                  => 'Čas zaključka:',
'LBL_DURATION'                                     => 'Trajanje:',
'LBL_DURATION_UNIT'                                => 'Enota trajanja:',
'LBL_ACTUAL_DURATION'                              => 'Dejasnko trajanje:',
'LBL_PARENT_ID'                                    => 'Projekt:',
'LBL_PARENT_TASK_ID'                               => 'Id nadrejene naloge: ',
'LBL_PERCENT_COMPLETE'                             => 'Napredek (%):',
'LBL_PRIORITY'                                     => 'Prioriteta:',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_ORDER_NUMBER'                                 => 'Vrstni red:',
'LBL_TASK_NUMBER'                                  => 'Številka naloge:',
'LBL_TASK_ID'                                      => 'ID naloge:',
'LBL_DEPENDS_ON_ID'                                => 'Odvisno je od:',
'LBL_MILESTONE_FLAG'                               => 'Prelomnica:',
'LBL_ESTIMATED_EFFORT'                             => 'Predvideno dela (ure):',
'LBL_ACTUAL_EFFORT'                                => 'Dejansko potrošen čas (ure):',
'LBL_UTILIZATION'                                  => 'Izkoristek (%):',
'LBL_DELETED'                                      => 'Izbrisano:',
'LBL_LIST_ORDER_NUMBER'                            => 'vrstni red',
'LBL_LIST_NAME'                                    => 'Ime',
'LBL_LIST_DAYS'                                    => 'dni',
'LBL_LIST_PARENT_NAME'                             => 'Projekt',
'LBL_LIST_PERCENT_COMPLETE'                        => 'Napredek (%)',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_DURATION'                                => 'Trajanje',
'LBL_LIST_ACTUAL_DURATION'                         => 'Dejansko trajanje',
'LBL_LIST_ASSIGNED_USER_ID'                        => 'Dodeljeno',
'LBL_LIST_DATE_DUE'                                => 'Datum zaključka',
'LBL_LIST_DATE_START'                              => 'datum začetka',
'LBL_LIST_DATE_FINISH'                             => 'Datum zaključka',
'LBL_LIST_PRIORITY'                                => 'Prioriteta',
'LBL_LIST_CLOSE'                                   => 'Končano',
'LBL_PROJECT_NAME'                                 => 'Ime projekta',
'LNK_NEW_PROJECT'                                  => 'Ustvari projekt',
'LNK_PROJECT_LIST'                                 => 'Seznam projektov',
'LNK_NEW_PROJECT_TASK'                             => 'Ustvari projektno nalogo',
'LNK_PROJECT_TASK_LIST'                            => 'Projektna naloga',
'LBL_LIST_MY_PROJECT_TASKS'                        => 'Moje odprte projektne naloge',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Projektne naloge',
'LBL_NEW_FORM_TITLE'                               => 'Nova projektna naloga',
'LBL_ACTIVITIES_TITLE'                             => 'Aktivnosti',
'LBL_HISTORY_TITLE'                                => 'Zgodovina',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'DATE_JS_ERROR'                                    => 'Prosim vnesite datum v povezavi z vnešenim časom',
'LBL_ASSIGNED_USER_NAME'                           => 'Dodeljeno osebi',
'LBL_PARENT_NAME'                                  => 'Ime nadrejenega',
'LBL_LIST_PROJECT_NAME'                            => 'Projekti',
);?>
