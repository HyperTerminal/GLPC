<?php
/*********************************************************************************

*********************************************************************************/
$mod_strings = array (
  'LBL_FIELD_NAME' => 'Polje',
  'LBL_OLD_NAME' => 'Stara vrednost',
  'LBL_NEW_VALUE' => 'Nova vrednost',
  'LBL_CREATED_BY' => 'Spremenil',
  'LBL_LIST_DATE' => 'Datum spremembe',
  'LBL_AUDITED_FIELDS' => 'Polja za pregled v modulu: ',
  'LBL_NO_AUDITED_FIELDS_TEXT' => 'Ni polj za pregled v tem modulu',
);


?>