<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_DELETE_RECORD'                                => 'Za izbris je potrebno specificirati številko vnosa.',
'LBL_ACCOUNT_ID'                                   => 'ID Partnerja',
'LBL_ACCOUNT_NAME'                                 => 'Ime Partnerja:',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Partnerji',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_ATTACH_NOTE'                                  => 'Dodaj zaznamek',
'LBL_BUGS_SUBPANEL_TITLE'                          => 'Hrošči',
'LBL_CASE_NUMBER'                                  => 'Število Reklamacije:',
'LBL_CASE_SUBJECT'                                 => 'Predmet Reklamacije:',
'LBL_CASE'                                         => 'Reklamacija:',
'LBL_CONTACT_CASE_TITLE'                           => 'Kontakt za Reklamacijo:',
'LBL_CONTACT_NAME'                                 => 'Ime Kontakta:',
'LBL_CONTACT_ROLE'                                 => 'Vloga:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Reklamacije',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_FILENANE_ATTACHMENT'                          => 'Priponka',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'LBL_INVITEE'                                      => 'Kontakti',
'LBL_MEMBER_OF'                                    => 'Partner',
'LBL_MODULE_NAME'                                  => 'Reklamacije',
'LBL_MODULE_TITLE'                                 => 'Reklamacije: Domov',
'LBL_NEW_FORM_TITLE'                               => 'Nova Reklamacija',
'LBL_NUMBER'                                       => 'Številka:',
'LBL_PRIORITY'                                     => 'Prioriteta:',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projekti',
'LBL_RESOLUTION'                                   => 'Rešitev:',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje Reklamacij',
'LBL_STATUS'                                       => 'Status:',
'LBL_SUBJECT'                                      => 'Predmet:',
'LBL_SYSTEM_ID'                                    => 'ID sistema',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',
'LBL_LIST_ACCOUNT_NAME'                            => 'Ime Partnerja',
'LBL_LIST_ASSIGNED'                                => 'Dodeljeno',
'LBL_LIST_CLOSE'                                   => 'Zapri',
'LBL_LIST_FORM_TITLE'                              => 'Seznam Reklamacij',
'LBL_LIST_LAST_MODIFIED'                           => 'Nazadnje spremenjeno',
'LBL_LIST_MY_CASES'                                => 'Moje odprte Reklamacije',
'LBL_LIST_NUMBER'                                  => 'Številka',
'LBL_LIST_PRIORITY'                                => 'Prioriteta',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_SUBJECT'                                 => 'Predmet',
'LNK_CASE_LIST'                                    => 'Reklamacije',
'LNK_NEW_CASE'                                     => 'Ustvari Reklamacijo',
'NTC_REMOVE_FROM_BUG_CONFIRMATION'                 => 'ste prepričani, da bi radi odstranili to Reklamacijo s seznama?',
'NTC_REMOVE_INVITEE'                               => 'Ste prepričani, da želite odstraniti kontakt z Reklamacije?',
'LBL_LIST_DATE_CREATED'                            => 'Datum nastanka',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno',
'LBL_TYPE'                                         => 'Tip',
'LBL_WORK_LOG'                                     => 'delovni dnevnik',
'LNK_IMPORT_CASES'                                 => 'Uvozi reklamacije',
'LBL_CREATED_USER'                                 => 'Ustvarjen uporabnik',
'LBL_MODIFIED_USER'                                => 'Uporabnik spremenjen',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projetki',
'LBL_CASE_INFORMATION'                             => 'Pregled reklamacije',
);?>
