<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'db_name'                                          => 'Ime',
'db_website'                                       => 'Spletna stran',
'db_billing_address_city'                          => 'Mesto',
'LBL_CHARTS'                                       => 'Grafi',
'LBL_DEFAULT'                                      => 'Pogledi',
'LBL_MISC'                                         => 'Razno',
'LBL_UTILS'                                        => 'Orodja',
'ACCOUNT_REMOVE_PROJECT_CONFIRM'                   => 'Ste prepričani, da želite odstraniti Partnerja iz projekta?',
'ERR_DELETE_RECORD'                                => 'Za brisanje Partnerja je potrebno specificirati število zapisa.',
'LBL_ACCOUNT_INFORMATION'                          => 'Informacije o Partnerju',
'LBL_ACCOUNT_NAME'                                 => 'Naziv partnerja:',
'LBL_ACCOUNT'                                      => 'Partner:',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_ADDRESS_INFORMATION'                          => 'Informacije o naslovu',
'LBL_ANNUAL_REVENUE'                               => 'Letni prihodki:',
'LBL_ANY_ADDRESS'                                  => 'Katerikoli naslov:',
'LBL_ANY_EMAIL'                                    => 'Katerakoli E-pošta:',
'LBL_ANY_PHONE'                                    => 'Katerikoli telefon:',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_ASSIGNED_TO_ID'                               => 'Dodeljeno uporabniku:',
'LBL_BILLING_ADDRESS_CITY'                         => 'Mesto:',
'LBL_BILLING_ADDRESS_COUNTRY'                      => 'Regija:',
'LBL_BILLING_ADDRESS_POSTALCODE'                   => 'Poštna številka:',
'LBL_BILLING_ADDRESS_STATE'                        => 'Država:',
'LBL_BILLING_ADDRESS_STREET_2'                     => 'Ulica 2:',
'LBL_BILLING_ADDRESS_STREET_3'                     => 'Ulica 3:',
'LBL_BILLING_ADDRESS_STREET_4'                     => 'Ulica 4:',
'LBL_BILLING_ADDRESS_STREET'                       => 'Ulica:',
'LBL_BILLING_ADDRESS'                              => 'Naslov za račun:',
'LBL_BUG_FORM_TITLE'                               => 'Partnerji',
'LBL_BUGS_SUBPANEL_TITLE'                          => 'Hrošči',
'LBL_CALLS_SUBPANEL_TITLE'                         => 'Klici',
'LBL_CAMPAIGN_ID'                                  => 'ID Kampanje',
'LBL_CASES_SUBPANEL_TITLE'                         => 'Reklamacije',
'LBL_CITY'                                         => 'Mesto:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_COUNTRY'                                      => 'Regija:',
'LBL_DATE_ENTERED'                                 => 'Datum vnosa:',
'LBL_DATE_MODIFIED'                                => 'Datum spremembe:',
'LBL_MODIFIED_ID'                                  => 'Spremenil Id',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Partnerji',
'LBL_DESCRIPTION_INFORMATION'                      => 'Opisne informacije',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_DUPLICATE'                                    => 'Mogoča podvojitev Partnerja',
'LBL_EMAIL'                                        => 'E-pošta:',
'LBL_EMAIL_OPT_OUT'                                => 'Odjavljena E-pošta:',
'LBL_EMPLOYEES'                                    => 'Zaposleni:',
'LBL_FAX'                                          => 'Fax:',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'LBL_HOMEPAGE_TITLE'                               => 'Moji Partnerji',
'LBL_INDUSTRY'                                     => 'Panoga:',
'LBL_INVALID_EMAIL'                                => 'Napačen Email:',
'LBL_INVITEE'                                      => 'Kontakti',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciali',
'LBL_LIST_ACCOUNT_NAME'                            => 'Ime Partnerja',
'LBL_LIST_CITY'                                    => 'Mesto',
'LBL_LIST_CONTACT_NAME'                            => 'Ime Kontakta',
'LBL_LIST_EMAIL_ADDRESS'                           => 'E-poštni naslov',
'LBL_LIST_FORM_TITLE'                              => 'Seznam partnerjev',
'LBL_LIST_PHONE'                                   => 'Telefon',
'LBL_LIST_STATE'                                   => 'Država',
'LBL_LIST_WEBSITE'                                 => 'Spletna stran',
'LBL_MEETINGS_SUBPANEL_TITLE'                      => 'Sestanki',
'LBL_MEMBER_OF'                                    => 'Član:',
'LBL_MEMBER_ORG_FORM_TITLE'                        => 'Članske organizacije',
'LBL_MEMBER_ORG_SUBPANEL_TITLE'                    => 'Članske organizacije',
'LBL_MODULE_NAME'                                  => 'Partnerji',
'LBL_MODULE_TITLE'                                 => 'Partnerji: Domov',
'LBL_MODULE_ID'                                    => 'Partnerji',
'LBL_NAME'                                         => 'Naziv:',
'LBL_NEW_FORM_TITLE'                               => 'Nov Partner',
'LBL_OPPORTUNITIES_SUBPANEL_TITLE'                 => 'Priložnosti',
'LBL_OTHER_EMAIL_ADDRESS'                          => 'Drugi mail:',
'LBL_OTHER_PHONE'                                  => 'Drugi telefon:',
'LBL_OWNERSHIP'                                    => 'Lastništvo:',
'LBL_PARENT_ACCOUNT_ID'                            => 'ID nadrejenega Partnerja',
'LBL_PHONE_ALT'                                    => 'Alternativni telefon:',
'LBL_PHONE_FAX'                                    => 'Telefon, Fax:',
'LBL_PHONE_OFFICE'                                 => 'Telefon pisarna:',
'LBL_PHONE'                                        => 'Telefon:',
'LBL_POSTAL_CODE'                                  => 'Poštna številka:',
'LBL_PRODUCTS_TITLE'                               => 'Proizvodi',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projekti',
'LBL_PUSH_BILLING'                                 => 'Obračunaj',
'LBL_PUSH_CONTACTS_BUTTON_LABEL'                   => 'Kopiraj v Kontakte',
'LBL_PUSH_CONTACTS_BUTTON_TITLE'                   => 'Kopiraj...',
'LBL_PUSH_SHIPPING'                                => 'Pošlji',
'LBL_RATING'                                       => 'Ocena:',
'LBL_SAVE_ACCOUNT'                                 => 'Shrani Partnerja',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje Partnerja',
'LBL_SHIPPING_ADDRESS_CITY'                        => 'Naslov pošiljanja, mesto:',
'LBL_SHIPPING_ADDRESS_COUNTRY'                     => 'Naslov pošiljanja, regija:',
'LBL_SHIPPING_ADDRESS_POSTALCODE'                  => 'Naslov pošiljanja, poštna številka:',
'LBL_SHIPPING_ADDRESS_STATE'                       => 'Naslov pošiljanja, država:',
'LBL_SHIPPING_ADDRESS_STREET_2'                    => 'Naslov pošiljanja, ulica 2',
'LBL_SHIPPING_ADDRESS_STREET_3'                    => 'Naslov pošiljanja, ulica 3',
'LBL_SHIPPING_ADDRESS_STREET_4'                    => 'Naslov pošiljanja, ulica 4',
'LBL_SHIPPING_ADDRESS_STREET'                      => 'Naslov pošiljanja, ulica:',
'LBL_SHIPPING_ADDRESS'                             => 'Naslov pošiljanja:',
'LBL_SIC_CODE'                                     => 'Šifra dejavnosti:',
'LBL_STATE'                                        => 'Država:',
'LBL_TASKS_SUBPANEL_TITLE'                         => 'Naloge',
'LBL_TEAMS_LINK'                                   => 'Ekipe',
'LBL_TICKER_SYMBOL'                                => 'Kratica:',
'LBL_TYPE'                                         => 'Tip:',
'LBL_USERS_ASSIGNED_LINK'                          => 'Dodeljeni uporabniki',
'LBL_USERS_CREATED_LINK'                           => 'Ustvarili uporabniki',
'LBL_USERS_MODIFIED_LINK'                          => 'Spremenjeni uporabniki',
'LBL_VIEW_FORM_TITLE'                              => 'Partnerji pogled',
'LBL_WEBSITE'                                      => 'Spletna stran:',
'LBL_CREATED_ID'                                   => 'Ustvaril ID',
'LBL_CAMPAIGNS'                                    => 'Kampanje',
'LNK_ACCOUNT_LIST'                                 => 'Partnerji',
'LNK_NEW_ACCOUNT'                                  => 'Ustvari Partnerja',
'LNK_IMPORT_ACCOUNTS'                              => 'Uvozi partnerje',
'MSG_DUPLICATE'                                    => 'Podvajate Partnerja. Lahko izberete partnerja iz spodnjega seznama, ali pa kliknite Shrani za podvojitev Partnerja',
'MSG_SHOW_DUPLICATES'                              => 'Podvajate Partnerja. Kliknite Shrani za podvojitev Partnerja, ali pa klikni Prekliči.',
'NTC_COPY_BILLING_ADDRESS'                         => 'Kopiraj naslov za obračunavanje v naslov za pošiljanje',
'NTC_COPY_BILLING_ADDRESS2'                        => 'Kopiranje v Pošiljanje',
'NTC_COPY_SHIPPING_ADDRESS'                        => 'Kopiraj naslov za pošiljanje v naslov za obračunavanje',
'NTC_COPY_SHIPPING_ADDRESS2'                       => 'Kopiraj v Obračunavanje',
'NTC_DELETE_CONFIRMATION'                          => 'Ste prepričani, da želite izbrisati ta vnos?',
'NTC_REMOVE_ACCOUNT_CONFIRMATION'                  => 'Ste prepričani, da želite odstraniti ta vnos??',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'               => 'Ste prepričani, da želite odstraniti ta vnos članske organizacije?',
'LBL_ASSIGNED_USER_NAME'                           => 'Dodeljeno:',
'LBL_PROSPECT_LIST'                                => 'Seznam tarč',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Partnerji',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projekti',
'LBL_EMAIL_ADDRESS' => 'Email naslov',
);?>
