<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Spajanje zapisov',
'LBL_MODULE_TITLE'                                 => 'Spajanje zapisov: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje spajanja',
'LBL_LIST_FORM_TITLE'                              => 'Seznam spajanj',
'LBL_LBL_MERGE_RECORDS_STEP_1'                     => '1. korak: Poišči zapise za spojitev',
'LBL_AVAIL_FIELDS'                                 => 'Polja na voljo',
'LBL_FILTER_COND'                                  => 'Pogoj filtra',
'LBL_SELECTED_FIELDS'                              => 'Izbrana polja',
'LBL_MERGE_RECORDS_WITH'                           => 'Spoji zapise z',
'LBL_MERGE_VALUE_OVER'                             => 'Spoji vrednost večjo kot',
'LBL_NEXT_STEP_TITLE'                              => 'Premik na naslednji korak[Ctrl+N]',
'LBL_NEXT_STEP_BUTTON_KEY'                         => 'naslednji korak',
'LBL_NEXT_STEP_BUTTON_LABEL'                       => 'naslednji korak &gt;',
'LBL_PERFORM_MERGE_BUTTON_TITLE'                   => 'Spoji[Ctrl+P]',
'LBL_PERFORM_MERGE_BUTTON_KEY'                     => 'Spoji',
'LBL_PERFORM_MERGE_BUTTON_LABEL'                   => 'Spoji',
'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE'              => 'Shrani spojitev[Ctrl+S]',
'LBL_SAVE_MERGED_RECORD_BUTTON_KEY'                => 'Shrani spojitev',
'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL'              => 'Shrani spojitev',
'LBL_STEP2_FORM_TITLE'                             => 'Zapisi najdeni za združitev:',
'LBL_SELECT_ERROR'                                 => 'Ni mogoče nadaljevati pred izbiro.',
'LBL_SELECT_PRIMARY'                               => 'Izberi primarni zapis za spojitev.',
'LBL_CHANGE_PARENT'                                => 'Določi kot primarno',
'LBL_REMOVE_FROM_MERGE'                            => 'Odstrani',
'LBL_DIFF_COL_VALUES'                              => 'Stolpci katerih vrednosti v primarni vrstici se razlikujejo od vrednosti v spjalnih vrsticah:',
'LBL_SAME_COL_VALUES'                              => 'Stolpci, katerih vrednosti so podobne čez vse vrstice:',
'ERR_EXCEEDS_MAX'                                  => 'Združujete lahko največ pet zapisov. Presežki zapisov so bili ignorirani.',
'LBL_DELETE_MESSAGE'                               => 'To dejanje bo izbrisalo naslednje zapise:',
'LBL_PROCEED'                                      => 'Nadaljujem?',
'LBL_STEP1_DIRECTIONS'                             => 'Poiščite dvojnike. Če se najdejo možni dvojniki, lahko označite katere zapise boste združili s tremutnim zapisom.',
);?>
