<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_ADD_ANOTHER_FILE'                             => 'Dodaj še eno datoteko',
'LBL_ADD_DOCUMENT'                                 => 'Dodaj Sugar dokument',
'LBL_ADD_FILE'                                     => 'Dodaj datoteko',
'LBL_ATTACHMENTS'                                  => 'Priponke',
'LBL_BODY'                                         => 'Vsebina:',
'LBL_CLOSE'                                        => 'Zapri:',
'LBL_COLON'                                        => ':',
'LBL_CONTACT_AND_OTHERS'                           => 'Kontakt/Potencial/Tarča',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_EDIT_ALT_TEXT'                                => 'Uredi navadno besedilo',
'LBL_EMAIL_ATTACHMENT'                             => 'E-poštna priponka',
'LBL_HTML_BODY'                                    => 'HTML vsebina',
'LBL_INSERT_VARIABLE'                              => 'Vstavi spremenljivko:',
'LBL_INSERT_URL_REF'                               => 'Vstavi URL referenco',
'LBL_INSERT_TRACKER_URL'                           => 'Vstavi URL sledilca klikov:',
'LBL_INSERT'                                       => 'Vstavi',
'LBL_LIST_DATE_MODIFIED'                           => 'Nazadnje spremenjeno',
'LBL_LIST_DESCRIPTION'                             => 'Opis',
'LBL_LIST_FORM_TITLE'                              => 'Seznam E-poštnih predlog',
'LBL_LIST_NAME'                                    => 'Ime',
'LBL_MODULE_NAME'                                  => 'E-poštne predloge',
'LBL_MODULE_TITLE'                                 => 'E-poštne predloge: Domov',
'LBL_NAME'                                         => 'Ime:',
'LBL_NEW_FORM_TITLE'                               => 'Ustvari E-poštno predlogo',
'LBL_PUBLISH'                                      => 'Objavi:',
'LBL_RELATED_TO'                                   => 'Povezano z:',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje E-poštnih predlog',
'LBL_SHOW_ALT_TEXT'                                => 'Prikaži navadno besedilo',
'LBL_SUBJECT'                                      => 'Zadeva:',
'LBL_SUGAR_DOCUMENT'                               => 'Sugar dokument',
'LBL_TEAMS'                                        => 'Ekipe',
'LBL_TEAMS_LINK'                                   => 'Ekipe',
'LBL_TEXT_BODY'                                    => 'Vsebina',
'LBL_USERS'                                        => 'Uporabniki',
'LNK_ALL_EMAIL_LIST'                               => 'Vsa e-pošta',
'LNK_ARCHIVED_EMAIL_LIST'                          => 'Arhivirana e-pošta',
'LNK_CHECK_EMAIL'                                  => 'Preveri e-pošto',
'LNK_DRAFTS_EMAIL_LIST'                            => 'Vsi osnutki',
'LNK_EMAIL_TEMPLATE_LIST'                          => 'Vse e-poštne predloge',
'LNK_IMPORT_NOTES'                                 => 'Uvozi opombe',
'LNK_NEW_ARCHIVE_EMAIL'                            => 'Ustvari arhivirano e-pošto',
'LNK_NEW_EMAIL_TEMPLATE'                           => 'Ustvari e-poštno predlogo',
'LNK_NEW_EMAIL'                                    => 'Arhiviraj e-pošto',
'LNK_NEW_SEND_EMAIL'                               => 'Sestavi e-pošto',
'LNK_SENT_EMAIL_LIST'                              => 'Pošlji e-pošto',
'LNK_VIEW_CALENDAR'                                => 'Danes',
'LBL_NEW'                                          => 'Novo',
'LNK_CHECK_MY_INBOX'                               => 'Preveri e-pošto',
'LNK_GROUP_INBOX'                                  => 'Skupna e-pošta',
'LNK_MY_ARCHIVED_LIST'                             => 'Moji arhivi',
'LNK_MY_DRAFTS'                                    => 'Moji osnutki',
'LNK_MY_INBOX'                                     => 'Moja e-pošta',
'LBL_LIST_BASE_MODULE'                             => 'Osnovni modul:',
'LBL_TEXT_ONLY'                                    => 'Samo tekst',
'LBL_SEND_AS_TEXT'                                 => 'Pošlji samo tekst',
'LBL_ACCOUNT'                                      => 'Račun',
'LBL_BASE_MODULE'                                  => 'Osnovni modul',
'LBL_FROM_NAME'                                    => 'Od',
'LBL_PLAIN_TEXT'                                   => 'Navaden tekst',
'LBL_CREATED_BY'                                   => 'Ustvaril',
'LBL_FROM_ADDRESS'                                 => 'Od naslova',
'LBL_PUBLISHED'                                    => 'Objavljeno',
'LBL_ACTIVITIES_REPORTS'                           => 'Poročilo aktivnosti',
'LNK_VIEW_MY_INBOX'                                => 'Poglej mojo e-pošto',
);?>
