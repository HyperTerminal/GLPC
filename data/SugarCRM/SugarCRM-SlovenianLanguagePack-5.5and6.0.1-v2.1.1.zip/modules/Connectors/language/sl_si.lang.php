<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_ADD_MODULE'                                   => 'Dodaj',
'LBL_ADDRCITY'                                     => 'Mesto',
'LBL_ADDRCOUNTRY'                                  => 'Država',
'LBL_ADDRCOUNTRY_ID'                               => 'ID države',
'LBL_ADDRSTATEPROV'                                => 'Provinca',
'LBL_ADMINISTRATION'                               => 'Administracija povezovalnika',
'LBL_ADMINISTRATION_MAIN'                          => 'Nastavitve povezovalnika',
'LBL_AVAILABLE'                                    => 'Na voljo',
'LBL_BACK'                                         => '&lt; Back',
'LBL_COMPANY_ID'                                   => 'ID podjetja',
'LBL_CONFIRM_CONTINUE_SAVE'                        => 'Some required fields have been left blank.  Proceed to save changes?',
'LBL_CONNECTOR'                                    => 'Povezovalnik',
'LBL_CONNECTOR_FIELDS'                             => 'Polja povezovalnika',
'LBL_DATA'                                         => 'Podatki',
'LBL_DEFAULT'                                      => 'Privzeto',
'LBL_DELETE_MAPPING_ENTRY'                         => 'Ste prepričani, da želi izbrisati vnos?',
'LBL_DISABLED'                                     => 'Onemogočeno',
'LBL_DUNS'                                         => 'DUNS',
'LBL_EMPTY_BEANS'                                  => 'Nisem našel rezultatov, ki se ujemajo s poizvedbo.',
'LBL_ENABLED'                                      => 'Omogočeno',
'LBL_FINSALES'                                     => 'Finsales',
'LBL_MARKET_CAP'                                   => 'Market Cap',
'LBL_MERGE'                                        => 'Združevanje',
'LBL_MODIFY_DISPLAY_TITLE'                         => 'Omogoči povezovalnike',
'LBL_MODIFY_DISPLAY_DESC'                          => 'Select which modules are enabled for each connector.',
'LBL_MODIFY_DISPLAY_PAGE_TITLE'                    => 'Connector Settings: Enable Connectors',
'LBL_MODULE_FIELDS'                                => 'Module Fields',
'LBL_MODIFY_MAPPING_TITLE'                         => 'Map Connector Fields',
'LBL_MODIFY_MAPPING_DESC'                          => 'Map connector fields to module fields in order to determine what connector data can be viewed and merged into the module records.',
'LBL_MODIFY_MAPPING_PAGE_TITLE'                    => 'Connector Settings: Map Connector Fields',
'LBL_MODIFY_PROPERTIES_TITLE'                      => 'Set Connector Properties',
'LBL_MODIFY_PROPERTIES_DESC'                       => 'Configure the properties for each connector, including URLs and API keys.',
'LBL_MODIFY_PROPERTIES_PAGE_TITLE'                 => 'Connector Settings: Set Connector Properties',
'LBL_MODIFY_SEARCH_TITLE'                          => 'Manage Connector Search',
'LBL_MODIFY_SEARCH'                                => 'Iskanje',
'LBL_MODIFY_SEARCH_DESC'                           => 'Select the connector fields to use to search for data for each module.',
'LBL_MODIFY_SEARCH_PAGE_TITLE'                     => 'Connector Settings: Manage Connector Search',
'LBL_MODULE_NAME'                                  => 'Connectors',
'LBL_NO_PROPERTIES'                                => 'There are no configurable properties for this connector.',
'LBL_PARENT_DUNS'                                  => 'Parent DUNS',
'LBL_PREVIOUS'                                     => '&lt; Back',
'LBL_QUOTE'                                        => 'Quote',
'LBL_RECNAME'                                      => 'Ime podjetja',
'LBL_RESET_TO_DEFAULT'                             => 'Reset to Default',
'LBL_RESET_TO_DEFAULT_CONFIRM'                     => 'Are you sure you want to reset to the default configuration?',
'LBL_RESET_BUTTON_TITLE'                           => 'Reset [Alt+R]',
'LBL_RESULT_LIST'                                  => 'Data List',
'LBL_RUN_WIZARD'                                   => 'Run Wizard',
'LBL_SAVE'                                         => 'Save',
'LBL_SEARCHING_BUTTON_LABEL'                       => 'Searching...',
'LBL_SHOW_IN_LISTVIEW'                             => 'Show In Merge Listview',
'LBL_SMART_COPY'                                   => 'Smart Copy',
'LBL_SUMMARY'                                      => 'Summary',
'LBL_STEP1'                                        => 'Search and View Data',
'LBL_STEP2'                                        => 'Merge Records with',
'LBL_TEST_SOURCE'                                  => 'Test Connector',
'LBL_TEST_SOURCE_FAILED'                           => 'Test Failed',
'LBL_TEST_SOURCE_RUNNING'                          => 'Performing Test...',
'LBL_TEST_SOURCE_SUCCESS'                          => 'Test Successful',
'LBL_TITLE'                                        => 'Data Merge',
'LBL_ULTIMATE_PARENT_DUNS'                         => 'Ultimate Parent DUNS',
'ERROR_RECORD_NOT_SELECTED'                        => 'Error: Please select a record from the list before proceeding.',
'ERROR_EMPTY_WRAPPER'                              => 'Error: Unable to retrieve wrapper instance for the source [{$source_id}]',
'ERROR_EMPTY_SOURCE_ID'                            => 'Error: Source Id not specified or empty.',
'ERROR_EMPTY_RECORD_ID'                            => 'Error: Record Id not specified or empty.',
'ERROR_NO_ADDITIONAL_DETAIL'                       => 'Error: No additional details were found for the record.',
'ERROR_NO_SEARCHDEFS_DEFINED'                      => 'No modules have been enabled for this connector.  Select a module for this connector in the Enable Connectors page.',
'ERROR_NO_SEARCHDEFS_MAPPED'                       => 'Error: There are no connectors enabled that have search fields defined.',
'ERROR_NO_SOURCEDEFS_FILE'                         => 'Error: No sourcedefs.php file could be found.',
'ERROR_NO_SOURCEDEFS_SPECIFIED'                    => 'Error: No sources were specified from which to retrieve data.',
'ERROR_NO_CONNECTOR_DISPLAY_CONFIG_FILE'           => 'Error: There are no connectors mapped to this module.',
'ERROR_NO_SEARCHDEFS_MAPPING'                      => 'Error: There are no search fields defined for the module and connector.  Please contact the system administrator.',
'ERROR_NO_FIELDS_MAPPED'                           => 'Error: You must map at least one Connector field to a module field for each module entry.',
'ERROR_NO_DISPLAYABLE_MAPPED_FIELDS'               => 'Error: There are no module fields that have been mapped for display in the results.  Please contact the system administrator.',
);?>
