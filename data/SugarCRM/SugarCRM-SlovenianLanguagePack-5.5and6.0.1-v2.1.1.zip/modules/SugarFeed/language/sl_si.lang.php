<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_TEAM'                                         => 'Ekipa',
'LBL_TEAM_ID'                                      => 'ID ekipe',
'LBL_ASSIGNED_TO_ID'                               => 'Dodeljeno Id-ju',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno ',
'LBL_ID'                                           => 'ID',
'LBL_DATE_ENTERED'                                 => 'Ustvarjeno dne',
'LBL_DATE_MODIFIED'                                => 'Spremenjeno dne',
'LBL_MODIFIED'                                     => 'Spremenil',
'LBL_MODIFIED_ID'                                  => 'Spremenil Id',
'LBL_MODIFIED_NAME'                                => 'Spremenil',
'LBL_CREATED'                                      => 'Ustvaril',
'LBL_CREATED_ID'                                   => 'Ustvaril Id',
'LBL_DESCRIPTION'                                  => 'Opis',
'LBL_DELETED'                                      => 'Zbrisano',
'LBL_NAME'                                         => 'Ime',
'LBL_SAVING'                                       => 'Shranjevanje...',
'LBL_SAVED'                                        => 'Shranjeno',
'LBL_CREATED_USER'                                 => 'Ustvaril uporabnik',
'LBL_MODIFIED_USER'                                => 'Spremenil uporabnik',
'LBL_LIST_FORM_TITLE'                              => 'Sugar Feed List',
'LBL_MODULE_NAME'                                  => 'Sugar Feed',
'LBL_MODULE_TITLE'                                 => 'Sugar Feed',
'LBL_DASHLET_DISABLED'                             => 'Warning: The Sugar Feed system is disabled, no new feed entries will be posted until it is activated',
'LBL_ADMIN_SETTINGS'                               => 'Sugar Feed Settings',
'LBL_RECORDS_DELETED'                              => 'All previous Sugar Feed entries have been removed, if the Sugar Feed system is enabled, new entries will be generated automatically.',
'LBL_CONFIRM_DELETE_RECORDS'                       => 'Are you sure you wish to delete all of the Sugar Feed entries?',
'LBL_FLUSH_RECORDS'                                => 'Delete Feed Entries',
'LBL_ENABLE_FEED'                                  => 'Enable Sugar Feed',
'LBL_ENABLE_MODULE_LIST'                           => 'Activate Feeds For',
'LBL_HOMEPAGE_TITLE'                               => 'My Sugar Feed',
'LNK_NEW_RECORD'                                   => 'Create Sugar Feed',
'LNK_LIST'                                         => 'Sugar Feed',
'LBL_SEARCH_FORM_TITLE'                            => 'Search Sugar Feed',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Poglej zgodovino',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_SUGAR_FEED_SUBPANEL_TITLE'                    => 'Sugar Feed',
'LBL_NEW_FORM_TITLE'                               => 'New Sugar Feed',
'LBL_ALL'                                          => 'Vse',
'LBL_USER_FEED'                                    => 'User Feed',
'LBL_ENABLE_USER_FEED'                             => 'Activate User Feed',
'LBL_TO'                                           => 'Pošlji',
'LBL_IS'                                           => '&nbsp;',
'LBL_DONE'                                         => 'Narejeno',
'LBL_TITLE'                                        => 'Naslov',
'LBL_ROWS'                                         => 'Vrstic',
'LBL_CATEGORIES'                                   => 'Moduli',
'LBL_TIME_LAST_WEEK'                               => 'Prejšnji teden',
'LBL_TIME_WEEKS'                                   => 'Tednov',
'LBL_TIME_DAYS'                                    => 'Dni',
'LBL_TIME_YESTERDAY'                               => 'Včeraj',
'LBL_TIME_HOURS'                                   => 'Ur',
'LBL_TIME_HOUR'                                    => 'Ura',
'LBL_TIME_MINUTES'                                 => 'Minut',
'LBL_TIME_MINUTE'                                  => 'Munuta',
'LBL_TIME_SECONDS'                                 => 'Sekund',
'LBL_TIME_SECOND'                                  => 'Sekunda',
'LBL_TIME_AGO'                                     => 'nazaj',
'CREATED_CONTACT'                                  => 'ustvaril <b>NOV</b> kontakt',
'CREATED_OPPORTUNITY'                              => 'ustvaril <b>NOVO</b> priložnost',
'CREATED_CASE'                                     => 'ustvaril <b>NOV</b> primer',
'CREATED_LEAD'                                     => 'ustvaril <b>NOV</b> potencial',
'FOR'                                              => 'za',
'CLOSED_CASE'                                      => '<b>ZAPRL</b> primer',
'CONVERTED_LEAD'                                   => '<b>PRETVORIL</b> potencial',
'WON_OPPORTUNITY'                                  => '<b>DOBIL</b> priložnost',
'WITH'                                             => 'z/s',
'LBL_LINK_TYPE_Link'                               => 'Povezava',
'LBL_LINK_TYPE_Image'                              => 'Slika',
'LBL_LINK_TYPE_YouTube'                            => 'YouTube™',
'LBL_SELECT'                                       => 'Izberi',
'LBL_POST'                                         => 'Objavi',
);?>
