<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Hrošči',
'LBL_MODULE_TITLE'                                 => 'Sledilec hroščev: Domov',
'LBL_MODULE_ID'                                    => 'Hrošči',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje hroščev',
'LBL_LIST_FORM_TITLE'                              => 'Seznam hroščev',
'LBL_NEW_FORM_TITLE'                               => 'Nov hrošč',
'LBL_CONTACT_BUG_TITLE'                            => 'Kontakt hrošča:',
'LBL_SUBJECT'                                      => 'Predmet:',
'LBL_BUG'                                          => 'Hrošč:',
'LBL_BUG_NUMBER'                                   => 'Številka hrošča:',
'LBL_NUMBER'                                       => 'Številka:',
'LBL_STATUS'                                       => 'Status:',
'LBL_PRIORITY'                                     => 'Prioriteta:',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_CONTACT_NAME'                                 => 'Ime Kontakta:',
'LBL_BUG_SUBJECT'                                  => 'Predmet Hrošča:',
'LBL_CONTACT_ROLE'                                 => 'Vloga:',
'LBL_LIST_NUMBER'                                  => 'Številka',
'LBL_LIST_SUBJECT'                                 => 'Predmet',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_PRIORITY'                                => 'Prioriteta',
'LBL_LIST_RELEASE'                                 => 'Izdaja',
'LBL_LIST_RESOLUTION'                              => 'Rešitev',
'LBL_LIST_LAST_MODIFIED'                           => 'Nazadnje spremenjeno',
'LBL_INVITEE'                                      => 'Kontakti',
'LBL_TYPE'                                         => 'Tip:',
'LBL_LIST_TYPE'                                    => 'Tip',
'LBL_RESOLUTION'                                   => 'Rešitev:',
'LBL_RELEASE'                                      => 'Izdaja:',
'LNK_NEW_BUG'                                      => 'Poročaj o hrošču',
'LNK_BUG_LIST'                                     => 'Hrošči',
'NTC_REMOVE_INVITEE'                               => 'Ste prepričani, da želite odstraniti ta kontakt s Hrošča?',
'NTC_REMOVE_ACCOUNT_CONFIRMATION'                  => 'Ste prepričani, da želite odstraniti hrošča s tega partnerja?',
'ERR_DELETE_RECORD'                                => 'Za izbris hrošča je potrebno definirati številko zapisa.',
'LBL_LIST_MY_BUGS'                                 => 'Moji dodeljeni hrošči',
'LNK_IMPORT_BUGS'                                  => 'Uvozi hrošče',
'LBL_FOUND_IN_RELEASE'                             => 'Najdeni v izdaji:',
'LBL_FIXED_IN_RELEASE'                             => 'Popravljeni v izdaji:',
'LBL_LIST_FIXED_IN_RELEASE'                        => 'Popravljeni v izdaji',
'LBL_WORK_LOG'                                     => 'Delovni dnevnik:',
'LBL_SOURCE'                                       => 'Vir:',
'LBL_PRODUCT_CATEGORY'                             => 'Kategorija:',
'LBL_CREATED_BY'                                   => 'Ustvaril:',
'LBL_DATE_CREATED'                                 => 'Datum nastanka:',
'LBL_MODIFIED_BY'                                  => 'Nazadnje spremenil:',
'LBL_DATE_LAST_MODIFIED'                           => 'Datum spremembe:',
'LBL_LIST_EMAIL_ADDRESS'                           => 'E-poštni naslov',
'LBL_LIST_CONTACT_NAME'                            => 'Ime Kontakta',
'LBL_LIST_ACCOUNT_NAME'                            => 'Ime Partnerja',
'LBL_LIST_PHONE'                                   => 'Telefon',
'NTC_DELETE_CONFIRMATION'                          => 'Ste prepričani, da želite odstraniti ta Kontakt iz tega hrošča?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Sledilec hroščev',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Partnerji',
'LBL_CASES_SUBPANEL_TITLE'                         => 'Zadeve',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projekti',
'LBL_SYSTEM_ID'                                    => 'ID sistema',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno',
'LBL_BUG_INFORMATION'                              => 'Pregled hrošča',
);?>
