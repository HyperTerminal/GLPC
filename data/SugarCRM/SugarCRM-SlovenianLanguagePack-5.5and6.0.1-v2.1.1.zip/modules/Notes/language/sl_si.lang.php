<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_DELETE_RECORD'                                => 'Za izbris Partnerja morate določit številko zapisa.',
'LBL_ACCOUNT_ID'                                   => 'ID Partnerja:',
'LBL_CASE_ID'                                      => 'ID Reklamacije:',
'LBL_CLOSE'                                        => 'Zapri:',
'LBL_COLON'                                        => ':',
'LBL_CONTACT_ID'                                   => 'ID Kontakta:',
'LBL_CONTACT_NAME'                                 => 'Kontakt:',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Opombe',
'LBL_DESCRIPTION'                                  => 'Opis',
'LBL_EMAIL_ADDRESS'                                => 'E-poštni naslov:',
'LBL_EMAIL_ATTACHMENT'                             => 'Email priponka',
'LBL_FILE_MIME_TYPE'                               => 'Tip MIME',
'LBL_FILE_URL'                                     => 'URL datoteke',
'LBL_FILENAME'                                     => 'Priponka:',
'LBL_LEAD_ID'                                      => 'ID Osebe:',
'LBL_LIST_CONTACT_NAME'                            => 'Kontakt',
'LBL_LIST_DATE_MODIFIED'                           => 'Zadnje spremenjeno',
'LBL_LIST_FILENAME'                                => 'Priponka',
'LBL_LIST_FORM_TITLE'                              => 'Seznam Opomb',
'LBL_LIST_RELATED_TO'                              => 'Povezano z',
'LBL_LIST_SUBJECT'                                 => 'Predmet',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_CONTACT'                                 => 'Kontakt',
'LBL_MODULE_NAME'                                  => 'Opombe',
'LBL_MODULE_TITLE'                                 => 'Opombe: Domov',
'LBL_NEW_FORM_TITLE'                               => 'Ustvari opombo ali priponko',
'LBL_NOTE_STATUS'                                  => 'Opomba',
'LBL_NOTE_SUBJECT'                                 => 'Predmet opombe:',
'LBL_NOTES_SUBPANEL_TITLE'                         => 'Priponka',
'LBL_NOTE'                                         => 'Opomba:',
'LBL_OPPORTUNITY_ID'                               => 'ID Priložnosti:',
'LBL_PARENT_ID'                                    => 'Nadrejeni ID:',
'LBL_PARENT_TYPE'                                  => 'Nadrejeni tip',
'LBL_PHONE'                                        => 'Telefon:',
'LBL_PORTAL_FLAG'                                  => 'Prikaži na portalu?',
'LBL_EMBED_FLAG'                                   => 'Vključim v č-pošto?',
'LBL_PRODUCT_ID'                                   => 'ID proizvoda:',
'LBL_QUOTE_ID'                                     => 'ID navedka:',
'LBL_RELATED_TO'                                   => 'Povezano z:',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje po opombah',
'LBL_STATUS'                                       => 'Status',
'LBL_SUBJECT'                                      => 'Zadeva:',
'LNK_CALL_LIST'                                    => 'Klici',
'LNK_EMAIL_LIST'                                   => 'E-pošta',
'LNK_IMPORT_NOTES'                                 => 'Uvozi opombe',
'LNK_MEETING_LIST'                                 => 'Sestanki',
'LNK_NEW_CALL'                                     => 'Zabeleži klic',
'LNK_NEW_EMAIL'                                    => 'Arhiviraj e-pošto',
'LNK_NEW_MEETING'                                  => 'Načrtuj sestanek',
'LNK_NEW_NOTE'                                     => 'Ustvari opombo ali priponko',
'LNK_NEW_TASK'                                     => 'Ustvari nalogo',
'LNK_NOTE_LIST'                                    => 'Opombe',
'LNK_TASK_LIST'                                    => 'Naloge',
'LNK_VIEW_CALENDAR'                                => 'Danes',
'LBL_MEMBER_OF'                                    => 'Član:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',
'LBL_REMOVING_ATTACHMENT'                          => 'Odstranjevanje priponke...',
'ERR_REMOVING_ATTACHMENT'                          => 'Odstranjevanje priponke ni uspelo...',
'LBL_CREATED_BY'                                   => 'Ustvaril',
'LBL_MODIFIED_BY'                                  => 'Spremenil',
'LBL_SEND_ANYWAYS'                                 => 'To E-sporočilo nima zadeve. Pošljem/shranim kljub temu?',
'LBL_LIST_EDIT_BUTTON'                             => 'Uredi',
'LBL_ACTIVITIES_REPORTS'                           => 'Poročilo aktivnosti',
'LBL_PANEL_DETAILS'                                => 'Podrobnosti',
'LBL_NOTE_INFORMATION'                             => 'Pregled opomb',
);?>
