<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Priložnosti',
'LBL_MODULE_TITLE'                                 => 'Priložnosti: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje priložnosti',
'LBL_VIEW_FORM_TITLE'                              => 'Pogled priložnosti',
'LBL_LIST_FORM_TITLE'                              => 'Seznam priložnosti',
'LBL_OPPORTUNITY_NAME'                             => 'Ime priložnosti:',
'LBL_OPPORTUNITY'                                  => 'Priložnost:',
'LBL_NAME'                                         => 'Ime priložnosti',
'LBL_INVITEE'                                      => 'Kontakti',
'LBL_CURRENCIES'                                   => 'Valute',
'LBL_LIST_OPPORTUNITY_NAME'                        => 'Priložnost',
'LBL_LIST_ACCOUNT_NAME'                            => 'Ime partnerja',
'LBL_LIST_AMOUNT'                                  => 'Obseg priložnosti',
'LBL_LIST_AMOUNT_USDOLLAR'                         => 'Obseg',
'LBL_LIST_DATE_CLOSED'                             => 'Zaprto',
'LBL_LIST_SALES_STAGE'                             => 'Status prodaje',
'LBL_ACCOUNT_ID'                                   => 'ID Partnerja',
'LBL_CURRENCY_ID'                                  => 'ID denarne valute',
'LBL_CURRENCY_NAME'                                => 'Ime valute',
'LBL_CURRENCY_SYMBOL'                              => 'Simbol valute',
'db_sales_stage'                                   => 'Stopnja prodaje',
'db_name'                                          => 'Ime',
'db_amount'                                        => 'Količina',
'db_date_closed'                                   => 'Datum zaključka',
'UPDATE'                                           => 'Posodobitev priložnosti-denarne valute',
'UPDATE_DOLLARAMOUNTS'                             => 'Posodobitev obsega v evrih',
'UPDATE_VERIFY'                                    => 'Preveri zneske',
'UPDATE_VERIFY_TXT'                                => 'Preveri, če so valutne vrednosti v priložnostih veljavni decimalni zapisi z numeričnimi (0-9) črkovnimi zapisi in decimalkami(.)',
'UPDATE_FIX'                                       => 'Fiksne vrednosti',
'UPDATE_FIX_TXT'                                   => 'Poskuša vse napačne vrednosti na način da kreira veljaven decimalni zapis trenutne vrednosti. Vsaka spremenjena vrednost se varnostno shrani v amount_backup bazno polje. Če pri zagonu  opazite napake, ne zaganjajte ponovno preden povrnete originalne vrednosti, saj se lahko zgodi, da se bodo varnostni zapisi prepisali z novimi neuporabnimi podatki.',
'UPDATE_DOLLARAMOUNTS_TXT'                         => 'Posodobi vrednosti v evrih za priložnosti, osnovane na trenutnih podatkih o vrednosti valut. ta vrednost je uporabljena pri kalkulaciji grafov in v zapisu vrednosti.',
'UPDATE_CREATE_CURRENCY'                           => 'Ustvarjanje novega denarja:',
'UPDATE_VERIFY_FAIL'                               => 'Preverjanje zapisa je bilo neuspešno:',
'UPDATE_VERIFY_CURAMOUNT'                          => 'Trenutna vrednost:',
'UPDATE_VERIFY_FIX'                                => 'Zagon popravka bi dal',
'UPDATE_INCLUDE_CLOSE'                             => 'Vključi tudi zaprte zapise',
'UPDATE_VERIFY_NEWAMOUNT'                          => 'Nova vrednost:',
'UPDATE_VERIFY_NEWCURRENCY'                        => 'Nova denarna valuta:',
'UPDATE_DONE'                                      => 'Urejeno',
'UPDATE_BUG_COUNT'                                 => 'Hrošči najdeni, izveden poskus reševanja hroščev:',
'UPDATE_BUGFOUND_COUNT'                            => 'Najdeni hrošči:',
'UPDATE_COUNT'                                     => 'Posodobljeni zapisi?:',
'UPDATE_RESTORE_COUNT'                             => 'Zapisi vrednosti povrnjeni v prejšnje stanje:',
'UPDATE_RESTORE'                                   => 'Povrni vrednosti v prvotno stanje',
'UPDATE_RESTORE_TXT'                               => 'Povrne vrednosti iz shranjenega varnostnega zapisa v postopku posodobitve.',
'UPDATE_FAIL'                                      => 'Posodobitev neuspešna - ',
'UPDATE_NULL_VALUE'                                => 'Količina je NULL nastavljam na 0 -',
'UPDATE_MERGE'                                     => 'Združi valute',
'UPDATE_MERGE_TXT'                                 => 'Združi več denarnih valut v eno samo. Če je več zapisov valut, jih lahko združite v eno. To bo vplivalo tudi na prikaz v drugih modulih.',
'LBL_ACCOUNT_NAME'                                 => 'Ime Partnerja:',
'LBL_AMOUNT'                                       => 'Vrednost:',
'LBL_AMOUNT_USDOLLAR'                              => 'Količina USD:',
'LBL_CURRENCY'                                     => 'Denarna valuta:',
'LBL_DATE_CLOSED'                                  => 'Pričakovan datum zaključka:',
'LBL_TYPE'                                         => 'Tip:',
'LBL_CAMPAIGN'                                     => 'Kampanja:',
'LBL_NEXT_STEP'                                    => 'Naslednji korak:',
'LBL_LEAD_SOURCE'                                  => 'Vir potencialov:',
'LBL_SALES_STAGE'                                  => 'Status prodaje:',
'LBL_PROBABILITY'                                  => 'Verjetnost (%):',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_DUPLICATE'                                    => 'Možno podvajanje priložnosti',
'MSG_DUPLICATE'                                    => 'podvajate Priložnost. Lahko izberete Priložnost iz spodnjega seznama ali pa kliknite shrani ter ustvarite podvojeno Priložnost.',
'LBL_NEW_FORM_TITLE'                               => 'Ustvari priložnost',
'LNK_NEW_OPPORTUNITY'                              => 'Ustvari priložnost',
'LNK_OPPORTUNITY_LIST'                             => 'Priložnosti',
'ERR_DELETE_RECORD'                                => 'Za izbris priložnosti je potrebno definirati številko zapisa.',
'LBL_TOP_OPPORTUNITIES'                            => 'Moje najboljše priložnosti',
'NTC_REMOVE_OPP_CONFIRMATION'                      => 'Ste prepričani, da želite odstraniti ta Kontakt iz Priložnosti?',
'OPPORTUNITY_REMOVE_PROJECT_CONFIRM'               => 'Ste prepričani, da želite odstraniti to Priložnost iz projekta?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Priložnosti',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'LBL_RAW_AMOUNT'                                   => 'Izvorna vrednost',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciali',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projekti',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',
'LBL_MY_CLOSED_OPPORTUNITIES'                      => 'Moje zaprte priložnosti',
'LBL_TOTAL_OPPORTUNITIES'                          => 'Skupno prIložnosti',
'LBL_CLOSED_WON_OPPORTUNITIES'                     => 'Zaprte dobljene priložnosti',
'LBL_ASSIGNED_TO_ID'                               => 'Dodeljeno ID-ju',
'LBL_CREATED_ID'                                   => 'Ustvaril ID',
'LBL_MODIFIED_ID'                                  => 'Spremenil ID',
'LBL_MODIFIED_NAME'                                => 'Spremenil uporabnik',
'LBL_CREATED_USER'                                 => 'Uporabnik ustvarjen',
'LBL_MODIFIED_USER'                                => 'Uporabnik spremenjen',
'LBL_CAMPAIGN_OPPORTUNITY'                         => 'Kampanja',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projekti',
'LABEL_PANEL_ASSIGNMENT'                           => 'Naloga',
'LNK_IMPORT_OPPORTUNITIES'                         => 'Uvozi proložnosti',
);?>
