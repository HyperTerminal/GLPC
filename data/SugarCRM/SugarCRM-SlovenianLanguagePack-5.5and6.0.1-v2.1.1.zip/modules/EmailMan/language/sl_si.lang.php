<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_SEND_DATE_TIME'                               => 'Datum pošiljanja',
'LBL_IN_QUEUE'                                     => 'V čakanju?',
'LBL_IN_QUEUE_DATE'                                => 'Datum postavitve v čakalno vrsto',
'ERR_INT_ONLY_EMAIL_PER_RUN'                       => 'Dovoljena so le cela števila za število e-sporočil poslanih na paket',
'LBL_ATTACHMENT_AUDIT'                             => 'je bilo poslano. Ni bilo shranjeno lokalno zaradi varčevanja s prostorom na disku.',
'LBL_CONFIGURE_SETTINGS'                           => 'Nastavi',
'LBL_CUSTOM_LOCATION'                              => 'Uporabniško definirano',
'LBL_DEFAULT_LOCATION'                             => 'Prednastavljeno',
'LBL_DISCLOSURE_TITLE'                             => 'Prilepi uvodno sporočilo na vsako e-poštno sporočilo',
'LBL_DISCLOSURE_TEXT_TITLE'                        => 'Vsebina uvodnega sporočila',
'LBL_DISCLOSURE_TEXT_SAMPLE'                       => 'OBVESTILO: To e-sporočilo je namenjeno izključno naslovnikom in lahko vsebuje zaupne informacije. Vsako nepooblaščeno pregledovanje, uporaba, razkritje ali distribucija so prepovedani. Če niste naslovnik tega e-sporočila, prosimo uničite vse kopije sporočila in obvestite pošiljatelja, da lahko popravimo naše zapise. Hvala.',
'LBL_EMAIL_DEFAULT_CHARSET'                        => 'Sestavi e-poštna sporočila v tej črkovni kodi',
'LBL_EMAIL_DEFAULT_EDITOR'                         => 'Sestavi e-poštna sporočila s tem odjemalcem',
'LBL_EMAIL_DEFAULT_DELETE_ATTACHMENTS'             => 'Izbriši povezane opombe in priponke z izbrisanimi e-sporočili',
'LBL_EMAIL_GMAIL_DEFAULTS'                         => 'Predizpolni Gmail nastavitve',
'LBL_EMAIL_PER_RUN_REQ'                            => 'Število e-sporočil poslano v enem paketu:',
'LBL_EMAIL_SMTP_SSL'                               => 'Omogoči SMTP preko SSL',
'LBL_EMAIL_USER_TITLE'                             => 'Prednastavitve uporabnika e-pošte',
'LBL_EMAIL_OUTBOUND_CONFIGURATION'                 => 'Konfiguracija odhodne pošte',
'LBL_EMAILS_PER_RUN'                               => 'Število e-sporočil poslano v enem paketu:',
'LBL_ID'                                           => 'ID',
'LBL_LIST_CAMPAIGN'                                => 'Kampanja',
'LBL_LIST_FORM_PROCESSED_TITLE'                    => 'Procesirano',
'LBL_LIST_FORM_TITLE'                              => 'Vrsta',
'LBL_LIST_FROM_EMAIL'                              => 'Iz e-naslova',
'LBL_LIST_FROM_NAME'                               => 'Od Ime',
'LBL_LIST_IN_QUEUE'                                => 'V procesu',
'LBL_LIST_MESSAGE_NAME'                            => 'Marketing sporočilo',
'LBL_LIST_RECIPIENT_EMAIL'                         => 'Prejemnikov e-naslov',
'LBL_LIST_RECIPIENT_NAME'                          => 'Prejemnikovo ime',
'LBL_LIST_SEND_ATTEMPTS'                           => 'Poskusi pošiljanja',
'LBL_LIST_SEND_DATE_TIME'                          => 'Poslano',
'LBL_LIST_USER_NAME'                               => 'Uporabniško ime',
'LBL_LOCATION_ONLY'                                => 'Lokacija',
'LBL_LOCATION_TRACK'                               => 'Mesto kampanjskih datotek za sledenje klikov (primer: campaign_tracker.php)',
'LBL_CAMP_MESSAGE_COPY'                            => 'Obdrži kopije kampanjskih sporočil:',
'LBL_CAMP_MESSAGE_COPY_DESC'                       => 'Would you like to store complete copies of &lt;bold&gt;EACH&lt;/bold&gt; email message sent during all campaigns?  &lt;bold&gt;We recommend and default to no&lt;/bold&gt;.  Choosing no will store only the template that is sent and the needed variables to recreate the individual message.',
'LBL_MAIL_SENDTYPE'                                => 'poštni strežnik MTA:',
'LBL_MAIL_SMTPAUTH_REQ'                            => 'Uporabi SMTP avtentikacijo?',
'LBL_MAIL_SMTPPASS'                                => 'SMTP geslo:',
'LBL_MAIL_SMTPPORT'                                => 'SMTP vrata:',
'LBL_MAIL_SMTPSERVER'                              => 'SMTP strežnik:',
'LBL_MAIL_SMTPUSER'                                => 'SMTP uporabniško ime:',
'LBL_CHOOSE_EMAIL_PROVIDER'                        => 'Izberite vašega ponudnika e-pošte',
'LBL_YAHOOMAIL_SMTPPASS'                           => 'Yahoo! Mail geslo',
'LBL_YAHOOMAIL_SMTPUSER'                           => 'Yahoo! Mail ID',
'LBL_GMAIL_SMTPPASS'                               => 'Gmail geslo',
'LBL_GMAIL_SMTPUSER'                               => 'Gmail Email naslov',
'LBL_EXCHANGE_SMTPPASS'                            => 'Exchange geslo',
'LBL_EXCHANGE_SMTPUSER'                            => 'Exchange uporabniško ime',
'LBL_EXCHANGE_SMTPPORT'                            => 'Exchange strežniška vrata',
'LBL_EXCHANGE_SMTPSERVER'                          => 'Exchange strežnik',
'LBL_EMAIL_LINK_TYPE'                              => 'Email klient',
'LBL_EMAIL_LINK_TYPE_HELP'                         => '&lt;b&gt;Sugar Mail Client:&lt;/b&gt; Send emails using the email client in the Sugar application.&lt;br&gt;&lt;b&gt;External Mail Client:&lt;/b&gt; Send email using an email client outside of the Sugar application, such as Microsoft Outlook.',
'LBL_MARKETING_ID'                                 => 'Marketing Id',
'LBL_MODULE_ID'                                    => 'EmailMan',
'LBL_MODULE_NAME'                                  => 'E-poštne nastavitve',
'LBL_CONFIGURE_CAMPAIGN_EMAIL_SETTINGS'            => 'Mail nastavitve za kampanje',
'LBL_MODULE_TITLE'                                 => 'Upravljanje z odhodnimi e-sporočili v vrsti',
'LBL_NOTIFICATION_ON_DESC'                         => 'Pošlje obvestila ko so zapisi dodeljeni.',
'LBL_NOTIFY_FROMADDRESS'                           => '&quot;Od&quot;  naslov:',
'LBL_NOTIFY_FROMNAME'                              => '&quot;Od&quot;  ime:',
'LBL_NOTIFY_ON'                                    => 'Vključeno obveščanje?',
'LBL_NOTIFY_SEND_BY_DEFAULT'                       => 'Prednastavi pošiljanje obvestil za nove uporabnike?',
'LBL_NOTIFY_TITLE'                                 => 'Možnosti obveščanja po E-pošti',
'LBL_OLD_ID'                                       => 'Star Id',
'LBL_OUTBOUND_EMAIL_TITLE'                         => 'Možnosti odhodnih sporočil',
'LBL_RELATED_ID'                                   => 'Povezan ID',
'LBL_RELATED_TYPE'                                 => 'Povezan tip',
'LBL_SAVE_OUTBOUND_RAW'                            => 'Shrani odhodna izvorna E-sporočila',
'LBL_SEARCH_FORM_PROCESSED_TITLE'                  => 'Procesirano iskanje',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje po čakalni vrsti',
'LBL_VIEW_PROCESSED_EMAILS'                        => 'Preglej procesirana E-sporočila',
'LBL_VIEW_QUEUED_EMAILS'                           => 'Poglej sporočila v čakalni vrsti',
'TRACKING_ENTRIES_LOCATION_DEFAULT_VALUE'          => 'vrednost Config.php nastavitve site_url',
'TXT_REMOVE_ME_ALT'                                => 'Za odstranitev vašega naslova s tega seznama pojdite na',
'TXT_REMOVE_ME_CLICK'                              => 'kliknite tukaj',
'TXT_REMOVE_ME'                                    => 'Za odstranitev vašega naslova s tega seznama e-naslovov ',
'LBL_NOTIFY_SEND_FROM_ASSIGNING_USER'              => 'Pošlji obvestilo iz dodeljenega uporabnikovega E-naslova?',
'LBL_SECURITY_TITLE'                               => 'E-poštne varnostne nastaqvitve',
'LBL_SECURITY_DESC'                                => 'Preverite naslednje, ki NE SME biti dovoljeno z dohodno e-pošto ali prikazano v e-mail modulu.',
'LBL_SECURITY_APPLET'                              => 'Applet tag',
'LBL_SECURITY_BASE'                                => 'Osnovni zavihek',
'LBL_SECURITY_EMBED'                               => 'Embed tag',
'LBL_SECURITY_FORM'                                => 'Form tag',
'LBL_SECURITY_FRAME'                               => 'Frame tag',
'LBL_SECURITY_FRAMESET'                            => 'Frameset tag',
'LBL_SECURITY_IFRAME'                              => 'iFrame tag',
'LBL_SECURITY_IMPORT'                              => 'Uvozi tag',
'LBL_SECURITY_LAYER'                               => 'Layer tag',
'LBL_SECURITY_LINK'                                => 'Povezani tag',
'LBL_SECURITY_OBJECT'                              => 'Object tag',
'LBL_SECURITY_OUTLOOK_DEFAULTS'                    => 'Select Outlook default minimum security precautions (errors on the side of correct display).',
'LBL_SECURITY_SCRIPT'                              => 'Script tag',
'LBL_SECURITY_STYLE'                               => 'Style tag',
'LBL_SECURITY_TOGGLE_ALL'                          => 'Vse možnosti',
'LBL_SECURITY_XMP'                                 => 'Xmp tag',
'LBL_YES'                                          => 'Da',
'LBL_NO'                                           => 'Ne',
'LBL_PREPEND_TEST'                                 => '[Test]: ',
'LBL_SEND_ATTEMPTS'                                => 'Število poskusov pošiljanja',
'LBL_OUTGOING_SECTION_HELP'                        => 'Nastavite privzeti odhodni poštni strežnik za email obvestila in opozorila delovnih tokov.',
'LBL_ALLOW_DEFAULT_SELECTION'                      => 'Dovoli uporabnikom , da uporabijo ta račun za odhodno pošto:',
'LBL_ALLOW_DEFAULT_SELECTION_HELP'                 => 'When this option selected, all users will be able to send emails using the same outgoing&lt;br&gt; mail account used to send system notifications and alerts.  If the option is not selected,&lt;br&gt; users can still use the outgoing mail server after providing their own account information.',
);?>
