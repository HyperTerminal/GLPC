<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_REPLY_ADDR'                                   => '&quot;Odgovori&quot; na naslov:',
'LBL_REPLY_NAME'                                   => '&quot;Odgovori&quot; na ime:',
'LBL_MODULE_NAME'                                  => 'E-poštni Marketing',
'LBL_MODULE_TITLE'                                 => 'E-poštni Marketing: Domov',
'LBL_LIST_FORM_TITLE'                              => 'E-poštne Marketing Kampanje',
'LBL_NAME'                                         => 'Ime: ',
'LBL_LIST_NAME'                                    => 'Ime',
'LBL_LIST_FROM_ADDR'                               => 'Od',
'LBL_LIST_DATE_START'                              => 'Datum začetka',
'LBL_LIST_TEMPLATE_NAME'                           => 'E-poštna predloga',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_STATUS'                                       => 'Status',
'LBL_STATUS_TEXT'                                  => 'Status:',
'LBL_TEMPLATE_NAME'                                => 'Ime predloge',
'LBL_DATE_ENTERED'                                 => 'Datum vnosa',
'LBL_DATE_MODIFIED'                                => 'Datum spremembe',
'LBL_MODIFIED'                                     => 'Spremenil: ',
'LBL_CREATED'                                      => 'Ustvaril: ',
'LBL_MESSAGE_FOR'                                  => 'Pošlji to sporočilo:',
'LBL_MESSAGE_FOR_ID'                               => 'Sporočilo za',
'LBL_FROM_NAME'                                    => '&quot;Od&quot; ime: ',
'LBL_FROM_ADDR'                                    => '&quot;Od&quot; e-poštni naslov: ',
'LBL_DATE_START'                                   => 'Datum začetka',
'LBL_TIME_START'                                   => 'Čas začetka',
'LBL_START_DATE_TIME'                              => 'Datum in čas začetka: ',
'LBL_TEMPLATE'                                     => 'E-poštna predloga: ',
'LBL_MODIFIED_BY'                                  => 'Spremenil: ',
'LBL_CREATED_BY'                                   => 'Ustvaril: ',
'LBL_DATE_CREATED'                                 => 'Datum nastanka: ',
'LBL_DATE_LAST_MODIFIED'                           => 'Datum spremembe: ',
'LNK_NEW_CAMPAIGN'                                 => 'Ustvari kampanjo',
'LNK_CAMPAIGN_LIST'                                => 'Kampanje',
'LNK_NEW_PROSPECT_LIST'                            => 'Ustvari seznam tarč',
'LNK_PROSPECT_LIST_LIST'                           => 'Seznam tarč',
'LNK_NEW_PROSPECT'                                 => 'Ustvari Tarčo',
'LNK_PROSPECT_LIST'                                => 'Tarče',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'E-poštni marketing',
'LBL_CREATE_EMAIL_TEMPLATE'                        => 'Ustvari',
'LBL_EDIT_EMAIL_TEMPLATE'                          => 'Uredi',
'LBL_FROM_MAILBOX'                                 => 'Iz E-poštnega predala',
'LBL_FROM_MAILBOX_NAME'                            => 'Uporabi E-poštni predal:',
'LBL_PROSPECT_LIST_SUBPANEL_TITLE'                 => 'Seznam tarč',
'LBL_ALL_PROSPECT_LISTS'                           => 'Vsi seznami tarč v kampanji.',
'LBL_RELATED_PROSPECT_LISTS'                       => 'Vsi seznami tarč povezani s tem spoočilom.',
'LBL_PROSPECT_LIST_NAME'                           => 'Ime seznama tarč',
'LBL_LIST_PROSPECT_LIST_NAME'                      => 'Seznam tarč',
'LBL_MODULE_SEND_TEST'                             => 'Kampanja: Pošlji test',
'LBL_MODULE_SEND_EMAILS'                           => 'Kampanja: Pošlji E-sporočilo',
'LBL_SCHEDULE_MESSAGE_TEST'                        => 'Prosim izberite kampanjska sporočila, ki bi jih želeli testirati:',
'LBL_SCHEDULE_MESSAGE_EMAILS'                      => 'Prosim izberite kampanjska sporočila, ki bi jih radi tempirali za distribucijo na določen čas in datum:',
'LBL_SCHEDULE_BUTTON_TITLE'                        => 'Pošlji',
'LBL_SCHEDULE_BUTTON_LABEL'                        => 'Pošlji',
'LBL_SCHEDULE_BUTTON_KEY'                          => 'T',
);?>
