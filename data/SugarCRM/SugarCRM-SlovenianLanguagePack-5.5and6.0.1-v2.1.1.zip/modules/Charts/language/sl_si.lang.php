<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_NO_OPPS'                                      => 'Prosimo ustvarite nekaj Priložnosti za prikaz grafov Priložnosti.',
'LBL_ALL_OPPORTUNITIES'                            => 'Skupno število Priložnosti je: ',
'LBL_CHART_TYPE'                                   => 'Tip grafa:',
'LBL_CREATED_ON'                                   => 'Zadnjič zagnano ',
'LBL_DATE_END'                                     => 'Datum konca:',
'LBL_DATE_RANGE_TO'                                => 'do',
'LBL_DATE_RANGE'                                   => 'Obseg dni je',
'LBL_DATE_START'                                   => 'Datum začetka:',
'LBL_EDIT'                                         => 'Uredi',
'LBL_LEAD_SOURCE_BY_OUTCOME_DESC'                  => 'Prikaže skupne vrednosti Priložnosti po izbranem viru Potencialov glede na končni rezultat za izbrane uporabnike. Rezultat je osnovan glede na uspešno ali neuspešno prodajo ter druge vrednosti.',
'LBL_LEAD_SOURCE_BY_OUTCOME'                       => 'Vse Priložnosti po virih Potencialov, glede na rezultat',
'LBL_LEAD_SOURCE_FORM_DESC'                        => 'Prikaže skupne vrednosti Priložnosti izbranega vira Potencialov za izbrane uporabnike.',
'LBL_LEAD_SOURCE_FORM_TITLE'                       => 'Vse Priložnosti po virih Potencialov',
'LBL_LEAD_SOURCE_OTHER'                            => 'Drugo',
'LBL_LEAD_SOURCES'                                 => 'Viri Potencialov:',
'LBL_MODULE_NAME'                                  => 'Nadzorna plošča',
'LBL_MODULE_TITLE'                                 => 'Nadzorna plošča: Domov',
'LBL_MONTH_BY_OUTCOME_DESC'                        => 'Prikaže skupne vrednosti Priložnosti po mesecih glede na rezultat za izbrane uporabnike, kjer je pričakovan datum zaključka v določenem časovnem obdobju. Rezultat je osnovan na uspešnosti prodaje.',
'LBL_NUMBER_OF_OPPS'                               => 'Število priložnosti',
'LBL_OPP_SIZE'                                     => 'Obseg Priložnosti',
'LBL_OPP_THOUSANDS'                                => 'K',
'LBL_OPPS_IN_LEAD_SOURCE'                          => 'Priložnosti, kjer je vir Potencialov',
'LBL_OPPS_IN_STAGE'                                => ' Kjer je status prodajnega postopka',
'LBL_OPPS_OUTCOME'                                 => ' Kjer je rezultat prodaje',
'LBL_OPPS_WORTH'                                   => 'Vrednost Priložnosti',
'LBL_PIPELINE_FORM_TITLE_DESC'                     => 'Prikaže skupne vrednosti po izbranem prodajnem statusu za Priložnosti, katere naj bi se zaključile v določenem časovnem obdobju.',
'LBL_CAMPAIGN_ROI_TITLE_DESC'                      => 'Prikaže odziv Kampanje glede na povrnjeno vrednost investicije (ROI).',
'LBL_REFRESH'                                      => 'Osveži',
'LBL_ROLLOVER_DETAILS'                             => 'Premakni se preko stolpca za podrobnosti.',
'LBL_ROLLOVER_WEDGE_DETAILS'                       => 'Premakni se preko zatika za podrobnosti.',
'LBL_SALES_STAGE_FORM_DESC'                        => 'Prikaže vrednost skupnih priložnosti po izbranih statusih prodaje za izbrane uporabnike, kjer je pričakovan datum zaključka v določenem časovnem obdobju.',
'LBL_SALES_STAGE_FORM_TITLE'                       => 'Graf prodajni lijak glede na status prodaje',
'LBL_SALES_STAGES'                                 => 'Statusi prodaje:',
'LBL_TOTAL_PIPELINE'                               => 'Prodajni lijak skupaj je',
'LBL_USERS'                                        => 'Uporabniki:',
'LBL_YEAR_BY_OUTCOME'                              => 'Prodajni lijak po mesecih glede na izkupiček',
'LBL_YEAR'                                         => 'Leto:',
'LNK_NEW_ACCOUNT'                                  => 'Ustvari Partnerja',
'LNK_NEW_CALL'                                     => 'načrtuj Klic',
'LNK_NEW_CASE'                                     => 'Ustvari Reklamacijo',
'LNK_NEW_CONTACT'                                  => 'Ustvari Kontakt',
'LNK_NEW_ISSUE'                                    => 'poročilo o Napaki',
'LNK_NEW_LEAD'                                     => 'Ustvari Potencial',
'LNK_NEW_MEETING'                                  => 'Načrtuj Sestanek',
'LNK_NEW_NOTE'                                     => 'Ustvari Opombo ali Priponko',
'LNK_NEW_OPPORTUNITY'                              => 'Ustvari Priložnost',
'LNK_NEW_QUOTE'                                    => 'Ustvari Opombo',
'LNK_NEW_TASK'                                     => 'Ustvari Nalogo',
'NTC_NO_LEGENDS'                                   => 'Nič',
'LBL_TITLE'                                        => 'Naslov:',
'LBL_MY_MODULES_USED_SIZE'                         => 'Število dostopov',
);?>
