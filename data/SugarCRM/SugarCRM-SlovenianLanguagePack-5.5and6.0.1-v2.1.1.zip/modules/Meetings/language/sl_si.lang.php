<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ERR_DELETE_RECORD'                                => 'Za brisanje sestanka mora biti definirana številka zapisa.',
'LBL_ACCEPT_THIS'                                  => 'Sprejmi?',
'LBL_ADD_BUTTON'                                   => 'Dodaj',
'LBL_ADD_INVITEE'                                  => 'Povabi še',
'LBL_COLON'                                        => ':',
'LBL_CONTACT_NAME'                                 => 'Kontakt:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_CREATED_BY'                                   => 'Ustvaril',
'LBL_DATE_END'                                     => 'Datum zaključka',
'LBL_DATE_TIME'                                    => 'Čas in datum zaključka:',
'LBL_DATE'                                         => 'Datum začetka:',
'LBL_DEFAULT_STATUS'                               => 'Načrtovano',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Sestanki',
'LBL_DEL'                                          => 'Zbriši',
'LBL_DESCRIPTION_INFORMATION'                      => 'Informacije o opisu',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_DURATION_HOURS'                               => 'Trajanje v urah:',
'LBL_DURATION_MINUTES'                             => 'Trajanje v minutah:',
'LBL_DURATION'                                     => 'Trajanje:',
'LBL_EMAIL'                                        => 'E-pošta',
'LBL_FIRST_NAME'                                   => 'Ime',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Opombe',
'LBL_HOURS_ABBREV'                                 => 'ur',
'LBL_HOURS_MINS'                                   => '(ure/minute)',
'LBL_INVITEE'                                      => 'Povabljeni',
'LBL_LAST_NAME'                                    => 'Priimek',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',
'LBL_LIST_CLOSE'                                   => 'Zapri',
'LBL_LIST_CONTACT'                                 => 'Kontakt',
'LBL_LIST_DATE_MODIFIED'                           => 'Spremenjeno dne',
'LBL_LIST_DATE'                                    => 'Datum začetka',
'LBL_LIST_DIRECTION'                               => 'Smer',
'LBL_LIST_DUE_DATE'                                => 'Datum zaključka',
'LBL_LIST_FORM_TITLE'                              => 'Seznam sestankov',
'LBL_LIST_MY_MEETINGS'                             => 'Moji sestanki',
'LBL_LIST_RELATED_TO'                              => 'Povezano z',
'LBL_LIST_STATUS'                                  => 'Status',
'LBL_LIST_SUBJECT'                                 => 'Predmet',
'LBL_LIST_TIME'                                    => 'Čas začetka',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciali',
'LBL_LOCATION'                                     => 'Lokacija:',
'LBL_MEETING'                                      => 'Sestanek:',
'LBL_MINSS_ABBREV'                                 => 'Spremenil',
'LBL_MODIFIED_BY'                                  => 'Spremenil',
'LBL_MODULE_NAME'                                  => 'Sestanki',
'LBL_MODULE_TITLE'                                 => 'Sestanki: Domov',
'LBL_NAME'                                         => 'Ime',
'LBL_NEW_FORM_TITLE'                               => 'Načrtuj sestanek',
'LBL_OUTLOOK_ID'                                   => 'Outlook ID',
'LBL_PHONE'                                        => 'Telefon, pisarna:',
'LBL_REMINDER_TIME'                                => 'Čas opomnika',
'LBL_REMINDER'                                     => 'Opomnik:',
'LBL_SCHEDULING_FORM_TITLE'                        => 'Načrtovanje',
'LBL_SEARCH_BUTTON'                                => 'Iskanje',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje sestankov',
'LBL_SEND_BUTTON_KEY'                              => 'Pošlji povabila',
'LBL_SEND_BUTTON_LABEL'                            => 'Pošlji povabila',
'LBL_SEND_BUTTON_TITLE'                            => 'Pošlji povabila [Alt+I]',
'LBL_STATUS'                                       => 'Status:',
'LBL_SUBJECT'                                      => 'Zadeva:',
'LBL_TIME'                                         => 'Datum začetka:',
'LBL_USERS_SUBPANEL_TITLE'                         => 'Uporabniki',
'LBL_ACTIVITIES_REPORTS'                           => 'Poročilo aktivnosti',
'LNK_CALL_LIST'                                    => 'Klici',
'LNK_EMAIL_LIST'                                   => 'E-pošta',
'LNK_MEETING_LIST'                                 => 'Sestanki',
'LNK_NEW_APPOINTMENT'                              => 'Ustvari sestanek',
'LNK_NEW_CALL'                                     => 'Načrtuj Klic',
'LNK_NEW_EMAIL'                                    => 'Arhiviraj E-pošto',
'LNK_NEW_MEETING'                                  => 'Načrtuj Sestanek',
'LNK_NEW_NOTE'                                     => 'Ustvari opombo ali priponko',
'LNK_NEW_TASK'                                     => 'Ustvari nalogo',
'LNK_NOTE_LIST'                                    => 'Opombe',
'LNK_TASK_LIST'                                    => 'Naloge',
'LNK_VIEW_CALENDAR'                                => 'Danes',
'LNK_IMPORT_MEETINGS'                              => 'Uvozi sestanke',
'NTC_REMOVE_INVITEE'                               => 'Ste prepričani, da želite odstraniti povabljenca s sestanka?',
'LBL_CREATED_USER'                                 => 'Uporabnik ustvarjen',
'LBL_MODIFIED_USER'                                => 'Uporabnik spremenjen',
'NOTICE_DURATION_TIME'                             => 'Čas trajanja mora biti večji od 0',
'LBL_MEETING_INFORMATION'                          => 'Pregled sestanka',
);?>
