<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Projekt',
'LBL_MODULE_TITLE'                                 => 'Projekti: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje po projektih',
'LBL_LIST_FORM_TITLE'                              => 'Seznam projektov',
'LBL_HISTORY_TITLE'                                => 'Zgodovina',
'LBL_ID'                                           => 'Id:',
'LBL_DATE_ENTERED'                                 => 'Datum vnosa:',
'LBL_DATE_MODIFIED'                                => 'Datum spremembe:',
'LBL_ASSIGNED_USER_ID'                             => 'Dodeljeno:',
'LBL_ASSIGNED_USER_NAME'                           => 'Dodeljeno:',
'LBL_MODIFIED_USER_ID'                             => 'Spremenil (ID):',
'LBL_CREATED_BY'                                   => 'Ustvaril:',
'LBL_TEAM_ID'                                      => 'Ekipa:',
'LBL_NAME'                                         => 'Ime:',
'LBL_PDF_PROJECT_NAME'                             => 'Ime projekta:',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_DELETED'                                      => 'Zbrisano:',
'LBL_DATE'                                         => 'Datum:',
'LBL_DATE_START'                                   => 'Datum začetka:',
'LBL_DATE_END'                                     => 'Datum zaključka:',
'LBL_PRIORITY'                                     => 'Prioriteta:',
'LBL_STATUS'                                       => 'Status:',
'LBL_MY_PROJECTS'                                  => 'Moji projekti',
'LBL_MY_PROJECT_TASKS'                             => 'Moje projektne naloge',
'LBL_TOTAL_ESTIMATED_EFFORT'                       => 'Skupno predvideno dela (ure):',
'LBL_TOTAL_ACTUAL_EFFORT'                          => 'Skupni dejanski čas dela (ure):',
'LBL_LIST_NAME'                                    => 'Ime',
'LBL_LIST_DAYS'                                    => 'dni',
'LBL_LIST_ASSIGNED_USER_ID'                        => 'Dodeljeno',
'LBL_LIST_TOTAL_ESTIMATED_EFFORT'                  => 'Skupno predvideno delo (ure)',
'LBL_LIST_TOTAL_ACTUAL_EFFORT'                     => 'Skupaj dejanski porabljen čas (ure)',
'LBL_LIST_UPCOMING_TASKS'                          => 'Prihajajoče naloge (1 teden)',
'LBL_LIST_OVERDUE_TASKS'                           => 'Zapadle naloge',
'LBL_LIST_OPEN_CASES'                              => 'Odprti primeri',
'LBL_LIST_END_DATE'                                => 'Datum zaključka',
'LBL_LIST_TEAM_ID'                                 => 'Ekipa',
'LBL_PROJECT_SUBPANEL_TITLE'                       => 'Projekti',
'LBL_PROJECT_TASK_SUBPANEL_TITLE'                  => 'Projektne naloge',
'LBL_CONTACT_SUBPANEL_TITLE'                       => 'Kontakti',
'LBL_ACCOUNT_SUBPANEL_TITLE'                       => 'Partnerji',
'LBL_OPPORTUNITY_SUBPANEL_TITLE'                   => 'Priložnosti',
'LBL_QUOTE_SUBPANEL_TITLE'                         => 'Navedki',
'LBL_NEW_FORM_TITLE'                               => 'Nov projekt',
'CONTACT_REMOVE_PROJECT_CONFIRM'                   => 'Ste prepričani, da želite odstraniti Kontakt iz tega projekta?',
'LNK_NEW_PROJECT'                                  => 'Ustvari projekt',
'LNK_PROJECT_LIST'                                 => 'Seznam projektov',
'LNK_NEW_PROJECT_TASK'                             => 'Ustvari novo projektno nalogo',
'LNK_PROJECT_TASK_LIST'                            => 'Projektne naloge',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Projekti',
'LBL_ACTIVITIES_TITLE'                             => 'Aktivnosti',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'LBL_QUICK_NEW_PROJECT'                            => 'Nov projekt',
'LBL_PROJECT_TASKS_SUBPANEL_TITLE'                 => 'Projektne naloge',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_ACCOUNTS_SUBPANEL_TITLE'                      => 'Partnerji',
'LBL_OPPORTUNITIES_SUBPANEL_TITLE'                 => 'Priložnosti',
'LBL_CASES_SUBPANEL_TITLE'                         => 'Reklamacije',
'LBL_BUGS_SUBPANEL_TITLE'                          => 'Hrošči',
'LBL_PRODUCTS_SUBPANEL_TITLE'                      => 'Produkti',
'LBL_TASK_ID'                                      => 'ID',
'LBL_TASK_NAME'                                    => 'Ime naloge',
'LBL_DURATION'                                     => 'Trajanje',
'LBL_ACTUAL_DURATION'                              => 'Dejansko trajanje',
'LBL_START'                                        => 'Začetek',
'LBL_FINISH'                                       => 'Konec',
'LBL_PREDECESSORS'                                 => 'Predhodniki',
'LBL_PERCENT_COMPLETE'                             => '% končano',
'LBL_MORE'                                         => 'Več...',
'LBL_PERCENT_BUSY'                                 => '% zasedeno',
'LBL_TASK_ID_WIDGET'                               => 'id',
'LBL_TASK_NAME_WIDGET'                             => 'opis',
'LBL_DURATION_WIDGET'                              => 'trajanje',
'LBL_START_WIDGET'                                 => 'Datum začetka',
'LBL_FINISH_WIDGET'                                => 'Datum zaključka',
'LBL_PREDECESSORS_WIDGET'                          => 'predhodniki',
'LBL_PERCENT_COMPLETE_WIDGET'                      => 'procentov končano',
'LBL_EDIT_PROJECT_TASKS_TITLE'                     => 'Uredi projektne naloge',
'LBL_OPPORTUNITIES'                                => 'Priložnosti',
'LBL_LAST_WEEK'                                    => 'Prejšnji teden',
'LBL_NEXT_WEEK'                                    => 'Naslednji teden',
'LBL_PROJECTRESOURCES_SUBPANEL_TITLE'              => 'Viri prijekta',
'LBL_PROJECTTASK_SUBPANEL_TITLE'                   => 'Projektna naloga',
'LBL_HOLIDAYS_SUBPANEL_TITLE'                      => 'Dopusti',
'LBL_PROJECT_INFORMATION'                          => 'Pregled projekta',
);?>
