<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_EDIT_LAYOUT'                                  => 'uredi izgled',
'LBL_EDIT_ROWS'                                    => 'Uredi vrstice',
'LBL_EDIT_COLUMNS'                                 => 'Uredi stolpce',
'LBL_EDIT_LABELS'                                  => 'Uredi nalepke',
'LBL_EDIT_FIELDS'                                  => 'Uredi prilagojena polja',
'LBL_ADD_FIELDS'                                   => 'Dodaj prilagojena polja',
'LBL_DISPLAY_HTML'                                 => 'Prikaži HTML kodo',
'LBL_SELECT_FILE'                                  => 'Izberi datoteko',
'LBL_SAVE_LAYOUT'                                  => 'Shrani izgled',
'LBL_SELECT_A_SUBPANEL'                            => 'Shrani podpanel',
'LBL_SELECT_SUBPANEL'                              => 'Izberi podpanel',
'LBL_MODULE_TITLE'                                 => 'Studio',
'LBL_TOOLBOX'                                      => 'Orodjarna',
'LBL_STAGING_AREA'                                 => 'Počivališče (povleci in spusti predmete sem)',
'LBL_SUGAR_FIELDS_STAGE'                           => 'Sugar Polja (klik za dodati v počivališče)',
'LBL_SUGAR_BIN_STAGE'                              => 'Sugar Koš (klik za dodati v počivališče)',
'LBL_VIEW_SUGAR_FIELDS'                            => 'Pregled Sugar polj',
'LBL_VIEW_SUGAR_BIN'                               => 'Pregled Sugar koša',
'LBL_FAILED_TO_SAVE'                               => 'Shranjevanje ni uspelo',
'LBL_CONFIRM_UNSAVE'                               => 'Spremembe ne bodo shranjene. Ste prepričani, da želite nadaljevati?',
'LBL_PUBLISHING'                                   => 'Objavljam ...',
'LBL_PUBLISHED'                                    => 'Objavljeno',
'LBL_FAILED_PUBLISHED'                             => 'Objava ni uspela',
'LBL_DROP_HERE'                                    => '[Odloži tukaj]',
'LBL_NAME'                                         => 'Ime',
'LBL_LABEL'                                        => 'Nalepka',
'LBL_MASS_UPDATE'                                  => 'Masovno posodabljanje',
'LBL_AUDITED'                                      => 'Pregled',
'LBL_CUSTOM_MODULE'                                => 'Modul',
'LBL_DEFAULT_VALUE'                                => 'Prednastavljena vrednost',
'LBL_REQUIRED'                                     => 'Obvezno',
'LBL_DATA_TYPE'                                    => 'Tip',
'LBL_HISTORY'                                      => 'Zgodovina',
'LBL_SW_WELCOME'                                   => '&lt;h2&gt;Dobrodošli v Studiu!&lt;/h2&gt;&lt;br&gt; Kaj bi radi počeli danes?&lt;br&gt;&lt;b&gt; Prosim izberite iz spodnjih možnosti.&lt;/b&gt;',
'LBL_SW_EDIT_MODULE'                               => 'Uredi modul',
'LBL_SW_EDIT_DROPDOWNS'                            => 'Uredi Spustne menije',
'LBL_SW_EDIT_TABS'                                 => 'Nastavi zavihke',
'LBL_SW_RENAME_TABS'                               => 'Preimenuj zavihke',
'LBL_SW_EDIT_GROUPTABS'                            => 'Nastavi skupinske zavihke',
'LBL_SW_EDIT_PORTAL'                               => 'Uredi portal',
'LBL_SW_EDIT_WORKFLOW'                             => 'Uredi delovni tok',
'LBL_SW_REPAIR_CUSTOMFIELDS'                       => 'Popravi prilagojena polja',
'LBL_SW_MIGRATE_CUSTOMFIELDS'                      => 'Prenesi prilagojena polja',
'LBL_SMW_WELCOME'                                  => '&lt;h2&gt;Dobrodošli v studiu!&lt;/h2&gt;&lt;br&gt;&lt;b&gt;Prosim izberite modul iz spodnjega seznama.',
'LBL_SMA_WELCOME'                                  => '&lt;h2&gt;Uredi modul&lt;/h2&gt;Kaj bi radi počeli s tem modulom?&lt;br&gt;&lt;b&gt;prosim izberite dejanje, ki ga želite',
'LBL_SMA_EDIT_CUSTOMFIELDS'                        => 'Uredi prilagojena polja',
'LBL_SMA_EDIT_LAYOUT'                              => 'Uredi izgled',
'LBL_SMA_EDIT_LABELS'                              => 'uredi nalepke',
'LBL_MB_PREVIEW'                                   => 'Pregled',
'LBL_MB_RESTORE'                                   => 'Obnovi',
'LBL_MB_DELETE'                                    => 'izbriši',
'LBL_MB_COMPARE'                                   => 'Primerjaj',
'LBL_MB_WELCOME'                                   => '&lt;h2&gt;Zgodovina&lt;/h2&gt;&lt;br&gt; Zgodovina omogoča, da vidite prejšnje objavljene različice datoteke, s katero trenutno delate. Lahko primerjate ali obnovite prejšnje verzije. Če se odločite za obnovitev, bo stara različica postala vaša delovna datoteka. Objaviti jo morate preden je na pogled ostalim. &lt;br&gt; Kaj bi radi počeli danes?&lt;br&gt;&lt;b&gt; Prosim izberite med spodnjimi možnostmi.&lt;/b&gt;',
'LBL_ED_CREATE_DROPDOWN'                           => 'Ustvari spustni meni',
'LBL_ED_WELCOME'                                   => '&lt;h2&gt;Urejanje spustnih menijev&lt;/h2&gt;&lt;br&gt;&lt;b&gt;Lahko uredite obstoječi spustni meni ali ustvarite novega.',
'LBL_DROPDOWN_NAME'                                => 'Ime spustnega menija:',
'LBL_DROPDOWN_LANGUAGE'                            => 'Jezik spustnega menija:',
'LBL_TABGROUP_LANGUAGE'                            => 'Jezik skupinskega zavihka:',
'LBL_EC_WELCOME'                                   => '&lt;h2&gt;Urejanje prilagojenih polj&lt;/h2&gt;&lt;br&gt;&lt;b&gt;Lahko pogledatein urejate obstoječa prilagojena polja, ustvarite novega, ali počistite prilagojena polja v spominu.',
'LBL_EC_VIEW_CUSTOMFIELDS'                         => 'Poglej prilagojena polja',
'LBL_EC_CREATE_CUSTOMFIELD'                        => 'Ustvari prilagojena polja',
'LBL_EC_CLEAR_CACHE'                               => 'Počisti spomin',
'LBL_SM_WELCOME'                                   => '&lt;h2&gt;History&lt;/h2&gt;&lt;br&gt;&lt;b&gt;Prosim izberite datoteko za pogled.&lt;/b&gt;',
'LBL_DD_DISPALYVALUE'                              => 'Prikaži vrednost',
'LBL_DD_DATABASEVALUE'                             => 'Vrednost v bazi',
'LBL_DD_ALL'                                       => 'Vse',
'LBL_BTN_SAVE'                                     => 'Shrani',
'LBL_BTN_SAVEPUBLISH'                              => 'Shrani in objavi',
'LBL_BTN_HISTORY'                                  => 'Zgodovina',
'LBL_BTN_NEXT'                                     => 'Naprej',
'LBL_BTN_BACK'                                     => 'Nazaj',
'LBL_BTN_ADDCOLS'                                  => 'Dodaj stolpce',
'LBL_BTN_ADDROWS'                                  => 'Dodaj Vrstice',
'LBL_BTN_UNDO'                                     => 'Korak nazaj',
'LBL_BTN_REDO'                                     => 'Korak naprej',
'LBL_BTN_ADDCUSTOMFIELD'                           => 'Dodaj prilagojeno polje',
'LBL_BTN_TABINDEX'                                 => 'Uredi vrstni red zavihkov',
'LBL_TAB_SUBTABS'                                  => 'podzavihki',
'LBL_MODULES'                                      => 'Moduli',
'LBL_MODULE_NAME'                                  => 'Administracija',
'LBL_CONFIGURE_GROUP_TABS'                         => 'Nastavi skupinske zavihke',
'LBL_GROUP_TAB_WELCOME'                            => 'The Group Tab layout below will be used whenever a user chooses to use Grouped Tabs instead of the usual Module Tabs in My Account&gt;Layout Options.',
'LBL_RENAME_TAB_WELCOME'                           => 'Click on any tab&#039;s Display Value in the table below to rename the tab.',
'LBL_DELETE_MODULE'                                => 'Zbriši modul',
'LBL_DISPLAY_OTHER_TAB_HELP'                       => 'Select to display the &quot;Other&quot; tab in the navigation bar.  By default, the &quot;Other&quot; tab displays any modules not already included in other groups.',
'LBL_TAB_GROUP_LANGUAGE_HELP'                      => 'To set the tab group labels for other available languages, select a language, edit the labels and click Save & Deploy to make the changes for that language.',
'LBL_ADD_GROUP'                                    => 'Dodaj skupino',
'LBL_NEW_GROUP'                                    => 'Nova skupina',
'LBL_RENAME_TABS'                                  => 'Preimenuj zavihke',
'LBL_DISPLAY_OTHER_TAB'                            => 'Prikaži &#039;drug&#039; zavihek',
'LBL_DEFAULT'                                      => 'Prednastavljeno',
'LBL_ADDITIONAL'                                   => 'Dodatno',
'LBL_AVAILABLE'                                    => 'Na voljo',
'LBL_LISTVIEW_DESCRIPTION'                         => 'Prikazani so trije stolpci. Prednastavljen stolpec vsebuje polja, ki so že v osnovi prikazana na seznamu, Dodatni stolpec vsebuje polja, ki jih lahko uporabnik uporabi za ustvarjanje prilagojenega pogleda. Stolpci na voljo pa so tisti, ki jih lahko kot administrator dodate k prednastavljenimi ali dodatnimi stolpci za uporabo uporabnikom, so na voljo, vendar še niso trenutno uporabljena.',
'LBL_LISTVIEW_EDIT'                                => 'Urejanje prikaza seznamov',
'ERROR_ALREADY_EXISTS'                             => 'Napaka: Polje že obstaja',
'ERROR_INVALID_KEY_VALUE'                          => 'napaka: Napačna vrednost ključa: [&#039;]',
'LBL_SW_SUGARPORTAL'                               => 'Sugar Portal',
'LBL_SMP_WELCOME'                                  => ' Prosim izberite modul, ki ga želite urejati s spodnjega seznama',
'LBL_SP_WELCOME'                                   => 'Dobrodošli v Studio za Sugar Portal. Lahko izberete modul za urejeanje tu, ali v instanci portala.&lt;br&gt; Prosim izberite iz spodnjega seznama.',
'LBL_SP_SYNC'                                      => 'Portal Sync',
'LBL_SYNCP_WELCOME'                                => 'Prosim vnesite URL do instance portala, ki ga želite posodobiti&lt;br&gt; Prikazalo se vam bo prijavno okno. &lt;br&gt; Vnesite uporabniško ime in geslo in pričnite s sinhronizacijo.',
'LBL_LISTVIEWP_DESCRIPTION'                        => 'Spodaj sta prikazana dva stolpca: Prednastavljen, kjer so polja, ki bodo prikazana, ter Na voljo, kjer so polja, ki ne bodo prikazana v osnovi, so pa na voljo za prikaz. Z miško primite in povlečite polja med stolpci. S pomočjo drag&drop tehnologije jih lahko tudi poljubno razporejate.',
'LBL_SP_STYLESHEET'                                => 'Upload a Style Sheet',
'LBL_SP_UPLOADSTYLE'                               => 'Click on the browse button and select a style sheet from your computer to upload.&lt;br&gt; The next time you sync down to portal it will bring down the style sheet along with it.',
'LBL_SP_UPLOADED'                                  => 'Uploaded',
'ERROR_SP_UPLOADED'                                => 'Please ensure that you are uploading a css style sheet.',
'LBL_SP_PREVIEW'                                   => 'Here is a preview of what your style sheet will look like',
);?>
