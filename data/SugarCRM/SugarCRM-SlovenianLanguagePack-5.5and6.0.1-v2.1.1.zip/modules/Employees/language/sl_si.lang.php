<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Zaposleni',
'LBL_MODULE_TITLE'                                 => 'Zaposleni: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje zaposlenih',
'LBL_LIST_FORM_TITLE'                              => 'Zaposleni',
'LBL_NEW_FORM_TITLE'                               => 'Nov zaposleni',
'LBL_EMPLOYEE'                                     => 'Zaposleni:',
'LBL_LOGIN'                                        => 'Prijava',
'LBL_RESET_PREFERENCES'                            => 'Resetiranje na prednastavljene preference',
'LBL_TIME_FORMAT'                                  => 'Oblika časovnega zapisa:',
'LBL_DATE_FORMAT'                                  => 'Datumski zapis:',
'LBL_TIMEZONE'                                     => 'Trenutni čas:',
'LBL_CURRENCY'                                     => 'Denarna valuta:',
'LBL_LIST_NAME'                                    => 'Ime',
'LBL_LIST_LAST_NAME'                               => 'Priimek',
'LBL_LIST_EMPLOYEE_NAME'                           => 'Ime zaposlenega',
'LBL_LIST_DEPARTMENT'                              => 'Oddelek',
'LBL_LIST_REPORTS_TO_NAME'                         => 'Poroča',
'LBL_LIST_EMAIL'                                   => 'E-pošta',
'LBL_LIST_PRIMARY_PHONE'                           => 'Primarni telefon',
'LBL_LIST_USER_NAME'                               => 'Uporabniško ime',
'LBL_LIST_ADMIN'                                   => 'Administrator',
'LBL_NEW_EMPLOYEE_BUTTON_TITLE'                    => 'Nov zaposleni [Alt+N]',
'LBL_NEW_EMPLOYEE_BUTTON_LABEL'                    => 'Nov zaposleni',
'LBL_NEW_EMPLOYEE_BUTTON_KEY'                      => 'N',
'LBL_ERROR'                                        => 'Napaka:',
'LBL_PASSWORD'                                     => 'Geslo:',
'LBL_EMPLOYEE_NAME'                                => 'Ime zaposlenega:',
'LBL_USER_NAME'                                    => 'Ime uporabnika:',
'LBL_FIRST_NAME'                                   => 'Ime:',
'LBL_LAST_NAME'                                    => 'Priimek:',
'LBL_EMPLOYEE_SETTINGS'                            => 'Nastavitve zaposlenega',
'LBL_THEME'                                        => 'Tema:',
'LBL_LANGUAGE'                                     => 'Jezik:',
'LBL_ADMIN'                                        => 'Administrator:',
'LBL_EMPLOYEE_INFORMATION'                         => 'Informacija o zaposlenem',
'LBL_OFFICE_PHONE'                                 => 'Pisarniški telefon:',
'LBL_REPORTS_TO'                                   => 'Poroča:',
'LBL_REPORTS_TO_NAME'                              => 'Poroča osebi',
'LBL_OTHER_PHONE'                                  => 'Drugo:',
'LBL_OTHER_EMAIL'                                  => 'Drugi e-poštni naslov:',
'LBL_NOTES'                                        => 'Opombe:',
'LBL_DEPARTMENT'                                   => 'Oddelek:',
'LBL_TITLE'                                        => 'Naziv:',
'LBL_ANY_ADDRESS'                                  => 'Katerikoli naslov:',
'LBL_ANY_PHONE'                                    => 'Katerikoli telefon:',
'LBL_ANY_EMAIL'                                    => 'Katerikoli e-poštni naslov:',
'LBL_ADDRESS'                                      => 'Naslov:',
'LBL_CITY'                                         => 'Mesto:',
'LBL_STATE'                                        => 'Država:',
'LBL_POSTAL_CODE'                                  => 'Poštna številka:',
'LBL_COUNTRY'                                      => 'Regija:',
'LBL_NAME'                                         => 'Ime:',
'LBL_MOBILE_PHONE'                                 => 'Mobilni telefon:',
'LBL_OTHER'                                        => 'Drugo:',
'LBL_FAX'                                          => 'Fax:',
'LBL_EMAIL'                                        => 'E-pošta:',
'LBL_HOME_PHONE'                                   => 'Domači telefon:',
'LBL_WORK_PHONE'                                   => 'Službeni telefon:',
'LBL_ADDRESS_INFORMATION'                          => 'Informacije o naslovu',
'LBL_EMPLOYEE_STATUS'                              => 'Status zaposlenega:',
'LBL_PRIMARY_ADDRESS'                              => 'Primarni naslov:',
'LBL_SAVED_SEARCH'                                 => 'Nastavitve postavitve',
'LBL_CREATE_USER_BUTTON_TITLE'                     => 'Ustvari Novega uporabnika [Alt+N]',
'LBL_CREATE_USER_BUTTON_LABEL'                     => 'Ustvari uporabnika',
'LBL_CREATE_USER_BUTTON_KEY'                       => 'N',
'LBL_FAVORITE_COLOR'                               => 'Najljubša barva:',
'LBL_MESSENGER_ID'                                 => 'IM Ime:',
'LBL_MESSENGER_TYPE'                               => 'IM Tip:',
'ERR_EMPLOYEE_NAME_EXISTS_1'                       => 'Ime zaposlenega ',
'ERR_EMPLOYEE_NAME_EXISTS_2'                       => 'že obstaja. Podvojena imena niso dovoljena. Spremenite ime tako da bo izvirno.',
'ERR_LAST_ADMIN_1'                                 => 'Ime zaposlenega&quot;',
'ERR_LAST_ADMIN_2'                                 => '&quot; je zadnji zaposleni z administratorskim dostopom. Vsaj en zaposleni mora biti administrator.',
'LNK_NEW_EMPLOYEE'                                 => 'Ustvari zaposlenega',
'LNK_EMPLOYEE_LIST'                                => 'Zaposleni',
'ERR_DELETE_RECORD'                                => 'Določite številko zapisa za brisanje računa.',
'LBL_LIST_EMPLOYEE_STATUS'                         => 'Status',
'LBL_SUGAR_LOGIN'                                  => 'Je Sugar uporabnik',
'LBL_RECEIVE_NOTIFICATIONS'                        => 'Obvesti ob dodeljeni Nalogi',
'LBL_IS_ADMIN'                                     => 'Je administrator',
'LBL_GROUP'                                        => 'Skupni uporabnik',
'LBL_PORTAL_ONLY'                                  => 'Samo uporabnik portala',
'LBL_PHOTO'                                        => 'Slika',
);?>
