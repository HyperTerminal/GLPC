<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'ACCOUNT_REMOVE_PROJECT_CONFIRM'                   => 'Ste prepričani, da želite odstraniti partnerja s tega projekta?',
'ERR_DELETE_RECORD'                                => 'Števika vnosa mora biti definirana za izbris Partnerja.',
'LBL_ACCOUNT_NAME'                                 => 'Ime podjetja:',
'LBL_ACCOUNT'                                      => 'Podjetje:',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_ADDRESS_INFORMATION'                          => 'Informacije o naslovu',
'LBL_ANNUAL_REVENUE'                               => 'Letni zaslužek:',
'LBL_ANY_ADDRESS'                                  => 'Katerikoli naslov:',
'LBL_ANY_EMAIL'                                    => 'Katerikoli E-pošta:',
'LBL_ANY_PHONE'                                    => 'Katerikoli telefon:',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_RATING'                                       => 'Ocena',
'LBL_ASSIGNED_USER'                                => 'Dodeljeno:',
'LBL_ASSIGNED_TO_ID'                               => 'Dodeljeno:',
'LBL_BILLING_ADDRESS_CITY'                         => 'Naslov za obračun, Mesto:',
'LBL_BILLING_ADDRESS_COUNTRY'                      => 'Naslov za obračun, Regija:',
'LBL_BILLING_ADDRESS_POSTALCODE'                   => 'Naslov za obračun, Poštna številka:',
'LBL_BILLING_ADDRESS_STATE'                        => 'Naslov za obračun, Država:',
'LBL_BILLING_ADDRESS_STREET_2'                     => 'Naslov za obračun, Ulica 2',
'LBL_BILLING_ADDRESS_STREET_3'                     => 'Naslov za obračun, Ulica 3',
'LBL_BILLING_ADDRESS_STREET_4'                     => 'Naslov za obračun, Ulica 4',
'LBL_BILLING_ADDRESS_STREET'                       => 'Naslov za obračun, Ulica:',
'LBL_BILLING_ADDRESS'                              => 'Naslov za obračun:',
'LBL_ACCOUNT_INFORMATION'                          => 'Informacije o podjetju',
'LBL_CITY'                                         => 'Mesto:',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_COUNTRY'                                      => 'Regija:',
'LBL_DATE_ENTERED'                                 => 'Vnešeno dne:',
'LBL_DATE_MODIFIED'                                => 'Spremenjeno dne:',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Partnerji',
'LBL_DESCRIPTION_INFORMATION'                      => 'Opisne informacije',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_DUPLICATE'                                    => 'Mogoče podvojen partner',
'LBL_EMAIL'                                        => 'E-pošta:',
'LBL_EMPLOYEES'                                    => 'Zaposleni:',
'LBL_FAX'                                          => 'Fax:',
'LBL_INDUSTRY'                                     => 'Panoga:',
'LBL_LIST_ACCOUNT_NAME'                            => 'Ime Partnerja',
'LBL_LIST_CITY'                                    => 'Mesto',
'LBL_LIST_EMAIL_ADDRESS'                           => 'E-poštni naslov',
'LBL_LIST_PHONE'                                   => 'Telefon',
'LBL_LIST_STATE'                                   => 'Država',
'LBL_LIST_WEBSITE'                                 => 'Spletna stran',
'LBL_MEMBER_OF'                                    => 'Član:',
'LBL_MEMBER_ORG_FORM_TITLE'                        => 'Članske organizacije',
'LBL_MEMBER_ORG_SUBPANEL_TITLE'                    => 'Članske organizacije',
'LBL_NAME'                                         => 'Ime:',
'LBL_OTHER_EMAIL_ADDRESS'                          => 'Druga E-pošta:',
'LBL_OTHER_PHONE'                                  => 'Drugi telefon:',
'LBL_OWNERSHIP'                                    => 'Lastništvo:',
'LBL_PARENT_ACCOUNT_ID'                            => 'Nadrejeni partner ID',
'LBL_PHONE_ALT'                                    => 'Alternativni telefon:',
'LBL_PHONE_FAX'                                    => 'Fax številka:',
'LBL_PHONE_OFFICE'                                 => 'Telefon v pisarni:',
'LBL_PHONE'                                        => 'Telefon:',
'LBL_EMAIL_ADDRESS'                                => 'Email naslovi',
'LBL_POSTAL_CODE'                                  => 'Poštna številka:',
'LBL_PUSH_BILLING'                                 => 'Pošlji račun',
'LBL_PUSH_SHIPPING'                                => 'Pošlji',
'LBL_SAVE_ACCOUNT'                                 => 'Shrani Partnerja',
'LBL_SHIPPING_ADDRESS_CITY'                        => 'Naslov za pošiljanje, Mesto:',
'LBL_SHIPPING_ADDRESS_COUNTRY'                     => 'Naslov za pošiljanje,  Regija:',
'LBL_SHIPPING_ADDRESS_POSTALCODE'                  => 'Naslov za pošiljanje, poštna številka:',
'LBL_SHIPPING_ADDRESS_STATE'                       => 'Naslov za pošiljanje, Država:',
'LBL_SHIPPING_ADDRESS_STREET_2'                    => 'Naslov za pošiljanje, Ulica 2',
'LBL_SHIPPING_ADDRESS_STREET_3'                    => 'Naslov za pošiljanje, Ulica 3',
'LBL_SHIPPING_ADDRESS_STREET_4'                    => 'Naslov za pošiljanje, Ulica 4',
'LBL_SHIPPING_ADDRESS_STREET'                      => 'Naslov za pošiljanje, Ulica:',
'LBL_SHIPPING_ADDRESS'                             => 'Naslov za pošiljanje:',
'LBL_STATE'                                        => 'Država:',
'LBL_TICKER_SYMBOL'                                => 'Ločilo:',
'LBL_TYPE'                                         => 'Tip:',
'LBL_USERS_ASSIGNED_LINK'                          => 'Dodeljeni uporabniki',
'LBL_USERS_CREATED_LINK'                           => 'Ustvarili uporabniki',
'LBL_USERS_MODIFIED_LINK'                          => 'Spremenili uporabniki',
'LBL_VIEW_FORM_TITLE'                              => 'Pogled Partnerja',
'LBL_WEBSITE'                                      => 'Spletna stran:',
'LNK_ACCOUNT_LIST'                                 => 'Partnerji',
'LNK_NEW_ACCOUNT'                                  => 'Ustvari Partnerja',
'MSG_DUPLICATE'                                    => 'Vnos tega partnerja lahko potencialno pomeni podvajanje partnerjev. Lahko izberete partnerja iz spodnjega seznama ali pa pritisnete Shrani in nadaljuj in s tem ustvarite novega partnerja. ',
'MSG_SHOW_DUPLICATES'                              => 'Vnos tega partnerja lahko potencialno pomeni podvajanje partnerjev. Lahko pritisnete Shrani in nadaljuj in s tem ustvarite novega partnerja ali pa pritisnete Prekliči.',
'NTC_COPY_BILLING_ADDRESS'                         => 'Kopiraj naslov za obračun v naslov za pošiljanje',
'NTC_COPY_BILLING_ADDRESS2'                        => 'Kopiraj v pošiljanje',
'NTC_COPY_SHIPPING_ADDRESS'                        => 'Kopiraj naslov za pošiljanje v naslov za obračun',
'NTC_COPY_SHIPPING_ADDRESS2'                       => 'Kopiraj v obračun',
'NTC_DELETE_CONFIRMATION'                          => 'Ste prepričani, da želite izbrisati izbran vnos?',
'NTC_REMOVE_ACCOUNT_CONFIRMATION'                  => 'Ste prepričani, da želite odstraniti izbran vnos?',
'NTC_REMOVE_MEMBER_ORG_CONFIRMATION'               => 'Ste prepričani, da želite odstraniti izbran vnos, kot organizacijskega člana?',
);?>
