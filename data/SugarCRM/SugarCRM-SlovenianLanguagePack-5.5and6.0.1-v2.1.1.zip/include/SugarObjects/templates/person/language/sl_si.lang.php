<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_SALUTATION'                                   => 'Pozdrav',
'LBL_NAME'                                         => 'Ime',
'LBL_FIRST_NAME'                                   => 'Ime',
'LBL_LAST_NAME'                                    => 'Priimek',
'LBL_TITLE'                                        => 'Naziv',
'LBL_DEPARTMENT'                                   => 'Oddelek',
'LBL_DO_NOT_CALL'                                  => 'Ne kliči!',
'LBL_HOME_PHONE'                                   => 'Domači telefon',
'LBL_MOBILE_PHONE'                                 => 'Mobilni telefon',
'LBL_OFFICE_PHONE'                                 => 'Službeni telefon',
'LBL_OTHER_PHONE'                                  => 'Drugi telefon',
'LBL_FAX_PHONE'                                    => 'Fax',
'LBL_EMAIL_ADDRESS'                                => 'E-poštni naslov(i)',
'LBL_PRIMARY_ADDRESS'                              => 'Primarni naslov',
'LBL_PRIMARY_ADDRESS_STREET'                       => 'Primaren naslov',
'LBL_PRIMARY_ADDRESS_STREET_2'                     => 'Primarni naslov  2:',
'LBL_PRIMARY_ADDRESS_STREET_3'                     => 'Primarni naslov  3:',
'LBL_PRIMARY_ADDRESS_CITY'                         => 'Mesto',
'LBL_PRIMARY_ADDRESS_STATE'                        => 'Država',
'LBL_PRIMARY_ADDRESS_POSTALCODE'                   => 'Poštna koda',
'LBL_PRIMARY_ADDRESS_COUNTRY'                      => 'Primarni naslov Regija:',
'LBL_ALT_ADDRESS_STREET'                           => 'Drugi naslov',
'LBL_ALT_ADDRESS_STREET_2'                         => 'Ostali naslovi 2:',
'LBL_ALT_ADDRESS_STREET_3'                         => 'Ostali naslovi 3:',
'LBL_ALT_ADDRESS_CITY'                             => 'Mesto',
'LBL_ALT_ADDRESS_STATE'                            => 'Država',
'LBL_ALT_ADDRESS_POSTALCODE'                       => 'Poštna številka',
'LBL_ALT_ADDRESS_COUNTRY'                          => 'Regija',
'LBL_COUNTRY'                                      => 'Regija',
'LBL_STREET'                                       => 'Drugi naslov',
'LBL_CITY'                                         => 'Mesto',
'LBL_STATE'                                        => 'Država',
'LBL_POSTALCODE'                                   => 'Poštna številka',
'LBL_POSTAL_CODE'                                  => 'Poštna številka',
'LBL_CONTACT_INFORMATION'                          => 'Informacije o kontaktu',
'LBL_ADDRESS_INFORMATION'                          => 'Naslov(i)',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno',
'LBL_OTHER_EMAIL_ADDRESS'                          => 'Drugi email',
'LBL_ASSISTANT'                                    => 'Asistent',
'LBL_ASSISTANT_PHONE'                              => 'Asistentov telefon',
'LBL_WORK_PHONE'                                   => 'Službeni telefon',
'LNK_IMPORT_VCARD'                                 => 'Ustvari iz vKartice',
);?>
