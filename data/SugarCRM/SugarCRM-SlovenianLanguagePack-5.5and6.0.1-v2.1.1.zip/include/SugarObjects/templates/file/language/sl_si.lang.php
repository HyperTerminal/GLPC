<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Dokumenti',
'LBL_MODULE_TITLE'                                 => 'Dokumenti: Domov',
'LNK_NEW_DOCUMENT'                                 => 'Ustvari dokument',
'LNK_DOCUMENT_LIST'                                => 'Seznam dokumentov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje dokumentov',
'LBL_DOCUMENT_ID'                                  => 'ID dokumenta',
'LBL_NAME'                                         => 'Ime dokumenta',
'LBL_DESCRIPTION'                                  => 'Opis',
'LBL_CATEGORY'                                     => 'Kategorija',
'LBL_SUBCATEGORY'                                  => 'Pod-kategorija',
'LBL_STATUS'                                       => 'Stanje',
'LBL_IS_TEMPLATE'                                  => 'Je predloga',
'LBL_TEMPLATE_TYPE'                                => 'Tip dokumenta',
'LBL_REVISION_NAME'                                => 'Število različice',
'LBL_MIME'                                         => 'MIME tip',
'LBL_REVISION'                                     => 'Različica',
'LBL_DOCUMENT'                                     => 'Povezan dokument',
'LBL_LATEST_REVISION'                              => 'Zadnja različica',
'LBL_CHANGE_LOG'                                   => 'Zgodovina sprememb',
'LBL_ACTIVE_DATE'                                  => 'Datum objave',
'LBL_EXPIRATION_DATE'                              => 'Datum veljavnosti',
'LBL_FILE_EXTENSION'                               => 'Končnica datoteke',
'LBL_CAT_OR_SUBCAT_UNSPEC'                         => 'Nedefiniran',
'LBL_NEW_FORM_TITLE'                               => 'Nov dokument',
'LBL_DOC_NAME'                                     => 'Ime dokumenta:',
'LBL_FILENAME'                                     => 'Ime datoteke:',
'LBL_DOC_VERSION'                                  => 'Različica:',
'LBL_CATEGORY_VALUE'                               => 'Kategorija:',
'LBL_SUBCATEGORY_VALUE'                            => 'Pod-kategorija:',
'LBL_DOC_STATUS'                                   => 'Stanje:',
'LBL_DET_TEMPLATE_TYPE'                            => 'Tip dokumenta:',
'LBL_DOC_DESCRIPTION'                              => 'Opis:',
'LBL_DOC_ACTIVE_DATE'                              => 'Datum objave:',
'LBL_DOC_EXP_DATE'                                 => 'Datum veljavnosti:',
'LBL_LIST_FORM_TITLE'                              => 'Seznam dokumentov:',
'LBL_LIST_DOCUMENT'                                => 'Dokument',
'LBL_LIST_CATEGORY'                                => 'Kategorija',
'LBL_LIST_SUBCATEGORY'                             => 'Pod-kategorija',
'LBL_LIST_REVISION'                                => 'Različica',
'LBL_LIST_LAST_REV_CREATOR'                        => 'Objavil',
'LBL_LIST_LAST_REV_DATE'                           => 'Datum različice',
'LBL_LIST_VIEW_DOCUMENT'                           => 'Poglej',
'LBL_LIST_DOWNLOAD'                                => 'Prenesi',
'LBL_LIST_ACTIVE_DATE'                             => 'Datum objave',
'LBL_LIST_EXP_DATE'                                => 'Datum veljavnosti',
'LBL_LIST_STATUS'                                  => 'Stanje',
'LBL_SF_DOCUMENT'                                  => 'Ime dokumenta:',
'LBL_SF_CATEGORY'                                  => 'Kategorija:',
'LBL_SF_SUBCATEGORY'                               => 'Pod-kategorija:',
'LBL_SF_ACTIVE_DATE'                               => 'Datum objave:',
'LBL_SF_EXP_DATE'                                  => 'Datum veljavnosti:',
'DEF_CREATE_LOG'                                   => 'Dokument ustvarjen',
'ERR_DOC_NAME'                                     => 'Ime dokumenta',
'ERR_DOC_ACTIVE_DATE'                              => 'Datum objave',
'ERR_DOC_EXP_DATE'                                 => 'Datum veljavnosti',
'ERR_FILENAME'                                     => 'Ime datoteke',
'LBL_TREE_TITLE'                                   => 'Dokumenti',
'LBL_LIST_DOCUMENT_NAME'                           => 'Ime dokumenta',
);?>
