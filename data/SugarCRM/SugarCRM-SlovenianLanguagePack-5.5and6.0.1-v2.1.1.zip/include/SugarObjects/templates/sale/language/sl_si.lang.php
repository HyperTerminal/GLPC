<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
* The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/

/*********************************************************************************
 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings= array (
'LBL_MODULE_NAME'                                  => 'Prodaja',
'LBL_MODULE_TITLE'                                 => 'Prodaja: Domov',
'LBL_SEARCH_FORM_TITLE'                            => 'Iskanje prodaje',
'LBL_VIEW_FORM_TITLE'                              => 'Pogled prodaje',
'LBL_LIST_FORM_TITLE'                              => 'Seznam prodaje',
'LBL_SALE_NAME'                                    => 'Ime prodaje:',
'LBL_SALE'                                         => 'Prodaja:',
'LBL_NAME'                                         => 'Ime prodaje:',
'LBL_LIST_SALE_NAME'                               => 'Ime',
'LBL_LIST_ACCOUNT_NAME'                            => 'Ime partnerja',
'LBL_LIST_AMOUNT'                                  => 'Količina',
'LBL_LIST_DATE_CLOSED'                             => 'Zapri',
'LBL_LIST_SALE_STAGE'                              => 'Stopnja prodaje',
'LBL_ACCOUNT_ID'                                   => 'ID partnerja',
'LBL_CURRENCY_ID'                                  => 'ID valute',
'db_sales_stage'                                   => 'LBL_SEZNAM_PRODAJA_FAZA',
'db_name'                                          => 'LBL_IME',
'db_amount'                                        => 'LBL_SEZNAM_VREDNOST',
'db_date_closed'                                   => 'LBL_SEZNAM_DATUM_ZAPRTO',
'UPDATE'                                           => '&quot;Prodaja - valuta&quot; posodobitev',
'UPDATE_DOLLARAMOUNTS'                             => 'Posodobi količine US dolarja',
'UPDATE_VERIFY'                                    => 'Preveri količine',
'UPDATE_VERIFY_TXT'                                => 'Preveri, da so količine v prodaji samo veljavna decimalna števila (0-9) in dclimalke (.)',
'UPDATE_FIX'                                       => 'Popravi količine',
'UPDATE_FIX_TXT'                                   => 'Poskus popravljanja katerekoli vrednosti z ustvarjanjem veljavne decimalke iz sedanje vrednosti. Katerikoli spremenjen znesek je vrnjen v znesek_ backup database field. Če to zaženete in obvestite hrošča, nikakor ponovno ne zaženite preden povrnete podatke iz arhiva, saj lahko prepiše backupa z napačnimi podatki.',
'UPDATE_DOLLARAMOUNTS_TXT'                         => 'Posodobite zneske v ameriških dolarjih za prodajo, ki je zasnovana na trenutnih tečajih valut. Vrednosti so uporabljene za kalkulacijo grafov in seznama pogledov.',
'UPDATE_CREATE_CURRENCY'                           => 'Ustvarjanje nove valute:',
'UPDATE_VERIFY_FAIL'                               => 'Shrani napačno verifikacijo:',
'UPDATE_VERIFY_CURAMOUNT'                          => 'Trenutni znesek:',
'UPDATE_VERIFY_FIX'                                => 'Aktivacija popravkov bo dala',
'UPDATE_INCLUDE_CLOSE'                             => 'Vključi zaprta poročila',
'UPDATE_VERIFY_NEWAMOUNT'                          => 'Novi znesek:',
'UPDATE_VERIFY_NEWCURRENCY'                        => 'Nova valuta:',
'UPDATE_DONE'                                      => 'Narejeno',
'UPDATE_BUG_COUNT'                                 => 'Najdeni so hrošči, ki se že rešujejo:',
'UPDATE_BUGFOUND_COUNT'                            => 'Najdeni so hrošči:',
'UPDATE_COUNT'                                     => 'Zapisi posodobljeni:',
'UPDATE_RESTORE_COUNT'                             => 'Vrednosti v zapisih so ponovno shranjene:',
'UPDATE_RESTORE'                                   => 'Ponovno shrani zneske',
'UPDATE_RESTORE_TXT'                               => 'Ponovno shrani vrednosti iz backupa, ki je ustvarjen v času popravkov.',
'UPDATE_FAIL'                                      => 'Posodobitev ni uspela -',
'UPDATE_NULL_VALUE'                                => 'Znesek je NIČ nastavlja se na 0 -',
'UPDATE_MERGE'                                     => 'Združi valute',
'UPDATE_MERGE_TXT'                                 => 'Združi različne valute v eno valuto. Če so tam zapisi večih valut za eno samo valuto, jih združite. To bo pravtako združilo vse valute, tudi za druge module.',
'LBL_ACCOUNT_NAME'                                 => 'Ime Partnerja:',
'LBL_AMOUNT'                                       => 'Znesek:',
'LBL_AMOUNT_USDOLLAR'                              => 'Znesek v USD:',
'LBL_CURRENCY'                                     => 'Valuta:',
'LBL_DATE_CLOSED'                                  => 'Pričakovan datum zaključka:',
'LBL_TYPE'                                         => 'Tip:',
'LBL_CAMPAIGN'                                     => 'Kampanja:',
'LBL_LEADS_SUBPANEL_TITLE'                         => 'Potenciali',
'LBL_PROJECTS_SUBPANEL_TITLE'                      => 'Projekti',
'LBL_NEXT_STEP'                                    => 'Naslednji korak:',
'LBL_LEAD_SOURCE'                                  => 'Vir potencialov:',
'LBL_SALES_STAGE'                                  => 'Faza prodaje:',
'LBL_PROBABILITY'                                  => 'Verjetnost (%):',
'LBL_DESCRIPTION'                                  => 'Opis:',
'LBL_DUPLICATE'                                    => 'Možna podvojitev prodaje',
'MSG_DUPLICATE'                                    => 'Prodajni zapis, ki ga želite ustvariti je mogoče dvojnik prodajnega zapisa, ki že obstaja. Prodajni zapisi, ki vsebujejo podobna imena so našteti spodaj. &lt;br&gt;Kliknite Shrani za nadaljevanje ustvarjanja nove prodaje, ali pa kliknite Prekliči za vrnitev v modul, brez ustvarjanja nove prodaje.',
'LBL_NEW_FORM_TITLE'                               => 'Ustvari prodajo',
'LNK_NEW_SALE'                                     => 'Ustvari prodajo',
'LNK_SALE_LIST'                                    => 'Prodaja',
'ERR_DELETE_RECORD'                                => 'Če želite izbrisati to prodajo, morate definirati številko zapisa.',
'LBL_TOP_SALES'                                    => 'Moje TOP odprte prodaje',
'NTC_REMOVE_OPP_CONFIRMATION'                      => 'ALi ste prepričani, da želite odstraniti ta kontakt iz prodaje?',
'SALE_REMOVE_PROJECT_CONFIRM'                      => 'ALi ste prepričani, da želite odstraniti to prodajo iz projekta?',
'LBL_DEFAULT_SUBPANEL_TITLE'                       => 'Prodaja',
'LBL_ACTIVITIES_SUBPANEL_TITLE'                    => 'Aktivnosti',
'LBL_HISTORY_SUBPANEL_TITLE'                       => 'Zgodovina',
'LBL_RAW_AMOUNT'                                   => 'Osnovni znesek',
'LBL_CONTACTS_SUBPANEL_TITLE'                      => 'Kontakti',
'LBL_ASSIGNED_TO_NAME'                             => 'Dodeljeno:',
'LBL_LIST_ASSIGNED_TO_NAME'                        => 'Dodeljen uporabnik',
'LBL_MY_CLOSED_SALES'                              => 'Moje zaprte prodaje',
'LBL_TOTAL_SALES'                                  => 'Skupna prodaja',
'LBL_CLOSED_WON_SALES'                             => 'Zaprte dobljene prodaje',
'LBL_ASSIGNED_TO_ID'                               => 'Dodeljeno IDju',
'LBL_CREATED_ID'                                   => 'Ustvarjeno z ID',
'LBL_MODIFIED_ID'                                  => 'Spremenjeno z ID',
'LBL_MODIFIED_NAME'                                => 'Spremenjeno s strani uporabnika',
'LBL_SALE_INFORMATION'                             => 'Prodajne informacije',
'LBL_CURRENCY_NAME'                                => 'Ime valute',
'LBL_CURRENCY_SYMBOL'                              => 'Simbol valute',
);?>
