<?php
/*
 *
 */
$manifest = array(
    // Check if Translation Module is applicable with current version of SugarCRM
    'acceptable_sugar_versions' => array (
        'exact_matches' => array (),
        'regex_matches' => array (  
         0 => '6\.*\.*', 
         1 => '5\.5\.*'
         ),
    ),
    // Language Pack : Name
    'name' => 'Slovenian Language Pack',
    // Language Pack : Description
    'description' => 'Slovenski prevod za SugarCRM 6',
    // Language Pack : Author
    'author' => 'Sebastijan Šilec',
    // Language Pack : Date Published
    'published_date' => '2010-09-07',
    // Language Pack : Version
    'version' => '2.0',
    // Language Pack : Is Uninstallable
    'is_uninstallable' => 'Yes',
    // Language Pack : Type of Code
    'type' => 'langpack',
);/* Redpill AB
 * Installation definitions
 */
$installdefs = array(
	/* 
	 * Language Pack ID
	 */
	'id'=> 'ag_translation',
	/* 
	 * Define how to copy files
	 */
	'copy' => array(
	array(	'from'	=> '<basepath>/include',
			'to'	=> 'include'),
	array(	'from'	=> '<basepath>/modules',
			'to'	=> 'modules'),
	array(	'from'	=> '<basepath>/jscalendar',
			'to'	=> 'jscalendar'),
	),
);
?>