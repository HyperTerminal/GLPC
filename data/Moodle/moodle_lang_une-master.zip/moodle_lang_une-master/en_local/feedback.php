<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    mod
 * @subpackage feedback
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cannotmapfeedback'] = 'Database problem, unable to map feedback to site';
$string['drop_feedback'] = 'Remove from this site';
$string['feedback:mapcourse'] = 'Map site to global feedback activities';
$string['filter_by_course'] = 'Filter by site';
$string['mapcourse'] = 'Map feedback to sites';
$string['mapcourse_help'] = 'By default, feedback forms created on your homepage are available system-wide and will appear in all sites using the feedback block. You can force the feedback form to appear by making it a sticky block or limit the courses in which a feedback form will appear by mapping it to specific sites.';
$string['mapcourseinfo'] = 'This is a site-wide feedback that is available to all sites using the feedback block. You can however limit the sites to which it will appear by mapping them. Search the site and map it to this feedback.';
$string['mapcoursenone'] = 'No sites mapped. Feedback available to all sites';
$string['mapcourses'] = 'Map feedback to sites';
$string['mapcourses_help'] = 'Once you have selected the relevant site(s) from your search, you can associate them with this feedback using map site(s). Multiple sites may be selected by holding down the Apple or Ctrl key whilst clicking on the site names. A site may be disassociated from a feedback at any time.';
$string['mappedcourses'] = 'Mapped sites';
$string['search_course'] = 'Search site';
$string['searchcourses'] = 'Search sites';
$string['searchcourses_help'] = 'Search for the code or name of the site(s) that you wish to associate with this feedback.';
$string['sort_by_course'] = 'Sort by site';
$string['url_for_continue_help'] = 'By default after a feedback is submitted the target of the continue button is the site page. You can define here another target URL for this continue button.';
$string['viewcompleted_help'] = 'You may view completed feedback forms, searchable by site and/or by question. Feedback responses may be exported to Excel.';
