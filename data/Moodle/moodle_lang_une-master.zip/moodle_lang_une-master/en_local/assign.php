<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle-stage.une.edu.au
 *
 * @package    mod
 * @subpackage assign
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activityoverview'] = 'Assignment status (click to expand)';
$string['preventsubmissionsshort'] = 'Force Submission';
$string['noonlinesubmissions'] = 'Check assignment details for submission requirements';

$string['feedbackavailabletext'] = 'Feedback has been left for your assignment. This may mean a comment has been left for you or your assignment has received a grade/regrade.

Please note that grading may still be in progress and this feedback may not be released to you yet. If you have any questions about it please direct these to your Unit Coordinator';
$string['feedbackavailablehtml'] = 'Feedback has been left for your assignment. This may mean a comment has been left for you or your assignment has received a grade/regrade.<br /><br />

Please note that grading may still be in progress and this feedback may not be released to you yet. If you have any questions about it please direct these to your Unit Coordinator';
