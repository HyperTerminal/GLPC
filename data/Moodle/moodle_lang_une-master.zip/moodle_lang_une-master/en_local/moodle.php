<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle-stage.une.edu.au
 *
 * @package    core
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['activities_help'] = 'Activities, such as forums, quizzes and wikis, enable interactive content to be added.';
$string['addcreator'] = 'Add site creator';
$string['addedtogroupnotenrolled'] = 'Not added to group "{$a}", because not enrolled here';
$string['addnewcourse'] = 'Add a new site';
$string['adminhelpassigncreators'] = 'Site creators can create new sites';
$string['adminhelpassignstudents'] = 'Go into a site and add students from the admin menu';
$string['adminhelpcourses'] = 'Define sites and categories and assign people to them, edit pending sites';
$string['administrationsite'] = 'Moodle admin';
$string['administratordescription'] = 'Administrators can usually do anything on the site, in all sites.';
$string['areyousuretorestorethisinfo'] = 'Later in this process you will have a choice of adding this backup to an existing site or creating a completely new site.';
$string['autosubscribe'] = 'Forum auto-subscribe (';
$string['autosubscribeno'] = 'No: don\'t automatically subscribe me to emails from that forum';
$string['autosubscribeyes'] = 'Yes: when I post, subscribe me to emails from that forum';
$string['availability_help'] = 'This setting determines whether the course appears in the list of sites. Apart from teachers and administrators, users are not allowed to enter the site.';
$string['availablecourses'] = 'Available sites';
$string['backtocourselisting'] = 'Back to site listing';
$string['backupcoursefileshelp'] = 'If enabled then site files will be included in automated backups';
$string['backupfailed'] = 'Some of your sites weren\'t saved!';
$string['backupincludemoduleshelp'] = 'Choose whether you want to include site modules, with or without user data, in automated backups';
$string['backupkeephelp'] = 'How many recent backups for each site do you want to keep? (older ones will be deleted automatically)';
$string['backuplogshelp'] = 'If enabled, then logs will be included in automated backups';
$string['backupsavetohelp'] = 'Full path to the directory where you want to save the backup files<br />(leave blank to save in its site/course default dir)';
$string['backupsitefileshelp'] = 'If enabled then system-wide files used in sites will be included in automated backups';
$string['backupusershelp'] = 'Select whether you want to include all the users in the server or only the needed users for each site';
$string['bycourseorder'] = 'By site order';
$string['categories'] = 'Our sites';
$string['categorycontents'] = 'Subcategories and sites';
$string['category_help'] = 'This setting determines the category in which the site will appear in the list of sites.';
$string['checkingcourse'] = 'Checking site';
$string['childcoursenotfound'] = 'Child site not found!';
$string['childcourses'] = 'Child sites';
$string['choosecourse'] = 'Choose a site';
$string['continuetocourse'] = 'Click here to enter';
$string['copyingcoursefiles'] = 'Copying site files';
$string['copyingsitefiles'] = 'Copying system-wide files used in site';
$string['course'] = 'Site';
$string['courseadministration'] = 'Site administration';
$string['courseapprovedemail'] = 'Your requested site, {$a->name}, has been approved and you have been made a {$a->teacher}. To access your new site, go to {$a->url}';
$string['courseapprovedemail2'] = 'Your requested site, {$a->name}, has been approved. To access your new site, go to {$a->url}';
$string['courseapprovedfailed'] = 'Failed to save the site as approved!';
$string['courseapprovedsubject'] = 'Your site has been approved!';
$string['courseavailable'] = 'This site is available to students';
$string['courseavailablenot'] = 'This site is not available to students';
$string['coursebackup'] = 'Site backup';
$string['coursecategories'] = 'Our sites';
$string['coursecategory'] = 'Site categories';
$string['coursecategorydeleted'] = 'Deleted site category {$a}';
$string['coursecompletion'] = 'Unit completion';
$string['coursecompletions'] = 'Unit completions';
$string['coursecreators'] = 'Site creator';
$string['coursecreatorsdescription'] = 'Site creators can create new sites';
$string['coursedeleted'] = 'Deleted site {$a}';
$string['coursefiles'] = 'Shared files';
$string['coursefilesedit'] = 'Edit shared files';
$string['coursefileswarning'] = 'Site files are deprecated since Moodle 2.0, please use external repositories instead as much as possible.';
$string['coursefileswarning_help'] = 'This area should be used sparingly. The simplest option is usually just to manage resources as you add them to each area in the site.';
$string['courseformatdata'] = 'Site format data';
$string['courseformats'] = 'Site formats';
$string['coursegrades'] = 'Grades';
$string['coursehelpcategory'] = 'Position the site on the site listing and may make it easier for students to find it.';
$string['coursehelpforce'] = 'Force the site group mode to every activity in the course.';
$string['coursehelpformat'] = 'The site main page will be displayed in this format.';
$string['coursehelphiddensections'] = 'How the hidden sections are displayed to students.';
$string['coursehelpmaximumupload'] = 'Define the largest size of file that can be uploaded in this site, limited by the system-wide setting.';
$string['coursehelpnewsitemsnumber'] = 'Number of recent items appearing on the site home page, in a news box down the right-hand side <br/>(0 means the news box won\'t appear).';
$string['coursehelpnumberweeks'] = 'Number of weeks/topics displayed on the site main page.';
$string['coursehidden'] = 'This site is currently unavailable to students';
$string['courseimportnotaught'] = 'You don\'t seem to be an editing teacher in any other sites, there are no courses for you to import from.';
$string['courseinfo'] = 'Site info';
$string['courselegacyfiles'] = 'Shared files';
$string['courselegacyfiles_help'] = 'The Shared Files area provides some backward compatibility with Moodle 1.9 and earlier. All files in this area are always accessible to all participants in the site (whether you link to them or not) and there is no way to know where any of these files are being used in Moodle. If you use this area to store files, you can expose yourself to a number of privacy and security issues, as well as experiencing missing files in backups, imports and any time content is shared or re-used. It is therefore recommended that you do not use this area unless you really know what you are doing. The link below provides more information about all this and will show you some better ways to manage files in Moodle 2.';
$string['coursemessage'] = 'Message site users';
$string['coursenotaccessible'] = 'This site does not allow public access';
$string['courseoverview'] = 'Site overview';
$string['courseoverviewgraph'] = 'Site overview graph';
$string['courseprofiles'] = 'Site profiles';
$string['coursereject'] = 'Reject a site request';
$string['courserejected'] = 'Site has been rejected and the requester has been notified';
$string['courserejectemail'] = 'Sorry, but we\'ve declined your request for a site. Here\'s why: {$a}';
$string['courserejectreason'] = 'Outline your reasons for rejecting this site<br />(this will be emailed to the requester)';
$string['courserejectsubject'] = 'Your site has been rejected';
$string['coursereport'] = 'Site report';
$string['coursereports'] = 'Site reports';
$string['courserequest'] = 'Site request';
$string['courserequestdetails'] = 'Details of the site you are requesting';
$string['courserequestfailed'] = 'For some reason, your site request could not be saved';
$string['courserequestintro'] = 'Use this form to request a site to be created for you.<br />Try and fill in as much information as you can to allow<br />the administrators to understand your reasons for wanting this site.';
$string['courserequestreason'] = 'Reasons for wanting this site';
$string['courserequestsuccess'] = 'Successfully saved your site request. We\'ll get back to you by email as soon as we can';
$string['courserestore'] = 'Site restore';
$string['courses'] = 'Sites';
$string['coursescategory'] = 'Sites in the same category';
$string['coursesectionsummaries'] = 'Site section categories';
$string['coursesettings'] = 'Default settings';
$string['coursesmovedout'] = 'Sites moved out from {$a}';
$string['coursespending'] = 'Sites pending approval';
$string['coursestart'] = 'Start';
$string['coursestaught'] = 'Sites I have managed';
$string['coursesummary'] = 'Summary';
$string['coursesummary_help'] = 'The summary is displayed in the list of sites. A site search searches  summary text in addition to site names.';
$string['courseupdates'] = 'Site updates';
$string['courseuploadlimit'] = 'Upload limit';
$string['creatingcoursemodules'] = 'Creating site modules';
$string['creatingcourseroles'] = 'Creating site level role assignments and overrides';
$string['creatingnewcourse'] = 'Creating new site';
$string['currentcourseadding'] = 'Current site, adding data to it';
$string['currentcoursedeleting'] = 'Current site, deleting it first';
$string['defaultcoursestudentdescription'] = 'Students generally have fewer privileges.';
$string['defaultcoursesummary'] = 'Write a concise and interesting paragraph here that explains what this site is for or about';
$string['defaultcourseteacherdescription'] = 'Teachers can do anything within a site, including changing the activities and grading students.';
$string['deletecategorycheck'] = 'Are you absolutely sure you want to completely delete this category <b>\'{$a}\'</b>?<br />This will move all sites it previously contained into the parent category if there is one, or into Miscellaneous.';
$string['deletecategorycheck2'] = 'If you delete this category, you need to choose what to do with the sites and subcategories it contains.';
$string['deletecourse'] = 'Delete a site';
$string['deletecoursecheck'] = 'Are you absolutely sure you want to completely delete this site and all the data it contains?';
$string['deletingexistingcoursedata'] = 'Deleting existing site data';
$string['editcoursesettings'] = 'Edit site settings';
$string['emaildisplaycourse'] = 'Allow only other site members to see my email address';
$string['entercourse'] = 'Click to enter';
$string['existingcourse'] = 'Existing site';
$string['existingcourseadding'] = 'Existing site, adding data to it';
$string['existingcoursedeleting'] = 'Existing site, deleting it first';
$string['existingcreators'] = 'Existing site creators';
$string['expirynotifyemail'] = 'The following students in this site are expiring after exactly {$a->threshold} days: {$a->current} The following students in this site are expiring in less than {$a->threshold} days: {$a->past} You may go to the following page to extend their enrolment period: {$a->extendurl}';
$string['expirynotifystudentsemail'] = 'Dear {$a->studentstr}: This is a notification that your enrolment in the site {$a->course} will expire in {$a->threshold} days. Please contact {$a->teacherstr} for any further enquiries.';
$string['expirynotifystudents_help'] = 'If an enrolment duration has been specified, then this setting determines whether students receive email notification when they are about to be unenrolled from the site.';
$string['expirythreshold_help'] = 'If an enrolment duration has been specified, then this setting determines the number of days notice given before students are unenrolled from the site.';
$string['findmorecourses'] = 'Find more...';
$string['format_help'] = 'The site format determines the layout of the site page. * SCORM format - For displaying a SCORM package in the first section of the site page (as an alternative to using the SCORM/AICC module) * Social format - A forum is displayed on the site page * Topics format - The site page is organised into topic sections * Weekly format - The site page is organised into weekly sections, with the first week starting on the site start date';
$string['frontpagecourselist'] = 'List of sites';
$string['fulllistofcourses'] = 'All sites';
$string['fullnamecourse'] = 'Site full name';
$string['fullnamecourse_help'] = 'The full name of the site is displayed at the top of each page in the site and in the list of sites.';
$string['guestuserinfo'] = 'This user is a special user that allows read-only access to some areas.';
$string['hiddensections_help'] = 'This setting determines whether hidden sections are displayed to students in collapsed form (perhaps for a site in weekly format to indicate holidays) or are completely hidden.';
$string['idnumbercourse'] = 'Site ID number';
$string['idnumbercourse_help'] = 'The ID number of a course is only used when matching the site against external systems and is not displayed anywhere on the site. If the site has an official code name it may be entered, otherwise the field can be left blank.';
$string['importdata'] = 'Import site data';
$string['importdataexported'] = 'Exported data from \'from\' site successfully.<br /> Continue to import into your \'to\' site.';
$string['importdatafinished'] = 'Import complete! Continue to your site';
$string['importdatafrom'] = 'Find a site in Moodle from which to import data:';
$string['includecoursefiles'] = 'Include files from "shared files"';
$string['includecourseusers'] = 'Include site users';
$string['includesitefiles'] = 'Include system-wide files used in this site';
$string['managecourses'] = 'Manage sites';
$string['maximumupload_help'] = 'This setting determines the largest size of file that can be uploaded to the site, limited by the system-wide setting set by an administrator. Activity modules also include a maximum upload size setting for further restricting the file size.';
$string['memberincourse'] = 'People in the site';
$string['messageprovider:courserequestapproved'] = 'Site creation request approval notification';
$string['messageprovider:courserequested'] = 'Site creation request notification';
$string['messageprovider:courserequestrejected'] = 'Site creation request rejection notification';
$string['movecourseto'] = 'Move site to:';
$string['moveselectedcoursesto'] = 'Move selected sites to...';
$string['mycourses'] = 'My sites';
$string['newcourse'] = 'New site';
$string['newsitemsnumber_help'] = 'This setting determines how many recent items appear in the latest news block on the site page. If set to "0 news items" then the latest news block will not be displayed.';
$string['nocourses'] = 'No sites';
$string['nocoursesfound'] = 'No sites were found with the words \'{$a}\'';
$string['nocoursesyet'] = 'No sites in this category';
$string['nofilesyet'] = 'No files have been uploaded to your site yet';
$string['noimagesyet'] = 'No images have been uploaded to your site yet';
$string['nomorecourses'] = 'No more matching sites could be found';
$string['noneditingteacherdescription'] = 'Non-editing teachers can teach in sites and grade students, but may not alter activities.';
$string['nopendingcourses'] = 'There are no sites pending approval';
$string['nopotentialcreators'] = 'No potential site creators';
$string['nosite'] = 'Could not find system-level site';
$string['nostudentsyet'] = 'No students enrolled in this site yet';
$string['noteachersyet'] = 'No teachers in this site yet';
$string['notenrolled'] = '{$a} is not enrolled in this area.';
$string['notenrolledprofile'] = 'This profile is not available because this user is not enrolled in this area.';
$string['noteuserschangednonetocourse'] = '<strong>Note:</strong> Site users need to be restored when restoring user data (in activities, files or messages). This setting has been changed for you.';
$string['novalidcourses'] = 'No valid sites to be shown';
$string['numberofcourses'] = 'Number of sites';
$string['parentcoursenotfound'] = 'Parent site not found!';
$string['potentialcreators'] = 'Potential site creators';
$string['profilenotshown'] = 'This profile description will not be shown until this person is enrolled in at least one site.';
$string['removecreator'] = 'Remove site creator';
$string['requestcourse'] = 'Request a site';
$string['requestedcourses'] = 'Requested sites';
$string['requestreason'] = 'Reason for site request';
$string['resetcourse'] = 'Reset site';
$string['resetinfo'] = 'This page allows you to empty a site of user data, while retaining the activities and other settings. Please be warned that by choosing items below and submitting this page you will delete your chosen user data from this site forever!';
$string['resortcoursesbyname'] = 'Re-sort by name';
$string['resources_help'] = 'Resource types enable almost any kind of web content to be inserted into the site.';
$string['restorecoursenow'] = 'Restore this site now!';
$string['rolerenaming_help'] = 'This setting allows the displayed names for roles used in the site to be changed. Only the displayed name is changed - role permissions are not affected. New role names will appear on the site participants page and elsewhere within the site. The renamed role name may also appear as part of the course listings.';
$string['savechangesandreturntocourse'] = 'Save and return';
$string['scalestandard_help'] = 'A standard scale is available system-wide.';
$string['scalestip'] = 'To create custom scales, use the \'Scales...\' link in your site settings menu.';
$string['scalestip2'] = 'To create custom scales, click the Grades link in the site settings menu, then choose Edit, Scales.';
$string['searchcourses'] = 'Search sites';
$string['shortnamecollisionwarning'] = '[*] = This shortname is already in use by a site and will need to be changed upon approval';
$string['shortnamecourse'] = 'Sites short name';
$string['shortnamecourse_help'] = 'The short name is displayed in the navigation and is used in the subject line of site email messages.';
$string['shortnametaken'] = 'Short name is already used for another site ({$a})';
$string['showallcourses'] = 'Show all sites';
$string['showblockcourse'] = 'Show list of sites containing block';
$string['showgrades_help'] = 'Many activities in the site allow grades to be set. This setting determines whether a student can view a list of all their grades for the site via a grades link in the site settings block.';
$string['showlistofcourses'] = 'Show list of sites';
$string['showmodulecourse'] = 'Show list of sites containing activity';
$string['showreports_help'] = 'Activity reports are available for each participant that show their activity in the site. As well as listings of their contributions, such as forum posts or assignment submissions, these reports also include access logs. This setting determines whether a student can view their own activity reports via their profile page.';
$string['site'] = 'Global';
$string['sitefilesused'] = 'Site files used in this site';
$string['sitehome'] = 'Moodle home';
$string['sitelegacyfiles'] = 'Shared files';
$string['sitenews'] = 'Moodle news';
$string['someallowguest'] = 'Some sites may allow guest access';
$string['starpending'] = '([*] = site pending approval)';
$string['startdate'] = 'Site start date';
$string['startdate_help'] = 'This setting determines the start of the first week for a site in weekly format. It also determines the earliest date that logs of site activities are available for.';
$string['statsnodata'] = 'There is no available data for that combination of site and time period.';
$string['statsnodatauser'] = 'There is no available data for that combination of site, user and time period.';
$string['statsreport11'] = 'Most active sites';
$string['statsreport12'] = 'Most active sites (weighted)';
$string['statsreport13'] = 'Most participatory sites (enrolments)';
$string['statsreport14'] = 'Most participatory sites (views/posts)';
$string['statsreport9'] = 'Logins (home)';
$string['studentnotallowed'] = 'Sorry, but you can not enter this site as \'{$a}\'';
$string['summary_help'] = 'The idea of a summary is a short text to prepare students for the activities within the topic or week. The text is shown on the site page under the section name.';
$string['thereareno'] = 'There are no {$a} in this site';
$string['updatethiscourse'] = 'Update this site';
$string['usingexistingcourse'] = 'Using existing site';
$string['viewallcourses'] = 'View all sites';
$string['viewallcoursescategories'] = 'View all sites and categories';
$string['virusfound'] = 'Attention administrator! Moodle has found a virus in a file uploaded by {$a->user} for the site {$a->course}. Here is the output of the scan:';
$string['virusfoundlater'] = 'A file you uploaded on {$a->date} with the filename {$a->filename} for  {$a->course} has since been found to contain a virus. Here is a summary of what has happened to your file: {$a->action} If this was submitted work, you may want to resubmit it so that your tutor can see it.';
$string['virusfoundlateradmin'] = 'Attention administrator! A file that was uploaded on {$a->date} with the filename {$a->filename} for  {$a->course} by the user {$a->user} has since been found to contain a virus. Here is a summary of what has happened to the file: {$a->action} The user has also been notified.';
$string['withselectedusers_help'] = '* Send message - For sending a message to one or more participants * Add a new note - For adding a note to a selected participant * Add a common note - For adding the same note to more than one participant * Extend enrolment (individual) - For extending a selected student\'s access to the site, even when an enrolment period is set * Extend enrolment (common) - For extending more than one student\'s access to the site by the same amount';
$string['writingcoursedata'] = 'Writing site data';
$string['youneedtoenrol'] = 'To perform that action you need to enrol in this site.';
