<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle-stage.une.edu.au
 *
 * @package    core
 * @subpackage blog
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addnewentry'] = 'Add a post';
$string['assocdescription'] = 'If you are writing about a site and/or activity modules, select them here.';
$string['associatewithcourse'] = 'Blog about {$a->coursename}';
$string['associationunviewable'] = 'This entry cannot be viewed by others until a site is associated with it or the \'Publish to\' field is changed';
$string['blogaboutthiscourse'] = 'Add an entry about this site';
$string['blogentries'] = 'Blog posts';
$string['blogentriesabout'] = 'Blog posts about {$a}';
$string['blogentriesbygroupaboutcourse'] = 'Blog posts about {$a->course} by {$a->group}';
$string['blogentriesbygroupaboutmodule'] = 'Blog posts about {$a->mod} by {$a->group}';
$string['blogentriesbyuseraboutcourse'] = 'Blog posts about {$a->course} by {$a->user}';
$string['blogentriesbyuseraboutmodule'] = 'Blog posts about this {$a->mod} by {$a->user}';
$string['blogentrybyuser'] = 'Blog post by {$a}';
$string['cannotviewcourseblog'] = 'You do not have the required permissions to view blogs in this site';
$string['cannotviewcourseorgroupblog'] = 'You do not have the required permissions to view blogs in this site/group';
$string['configexternalblogcrontime'] = 'How often Moodle checks the external blogs for new posts.';
$string['configuseblogassociations'] = 'Enables the association of blog entries with sites and site modules.';
$string['configuseexternalblogs'] = 'Enables users to specify external blog feeds. Moodle regularly checks these blog feeds and copies new posts to the local blog of that user.';
$string['courseblog'] = 'Site blog: {$a}';
$string['courseblogdisable'] = 'Site blogs are not enabled';
$string['courseblogs'] = 'Users can only see blogs for people who share a site';
$string['deleteblogassociations_help'] = 'If ticked then blog entries will no longer be associated with this course or any site activities or resources. The blog entries themselves will not be deleted.';
$string['editentry'] = 'Edit a blog post';
$string['emptybody'] = 'Blog post body can\'t be empty';
$string['emptytitle'] = 'Blog post title can\'t be empty';
$string['entrybody'] = 'Body';
$string['entrybodyonlydesc'] = 'Description';
$string['entryerrornotyours'] = 'This post is not yours';
$string['entrysaved'] = 'Your post has been saved';
$string['entrytitle'] = 'Title';
$string['entryupdated'] = 'Blog post updated';
$string['filterblogsby'] = 'Filter posts by';
$string['groupblogentries'] = 'Blog posts associated with {$a->coursename} by group {$a->groupname}';
$string['linktooriginalentry'] = 'Link to original blog post';
$string['mustassociatecourse'] = 'If you are publishing to site or group members, you must associate a course with this entry';
$string['noentriesyet'] = 'No visible posts here';
$string['nosuchentry'] = 'No such blog post';
$string['notallowedtoedit'] = 'You are not allowed to edit this post';
$string['numberofentries'] = 'Posts: {$a}';
$string['pagesize'] = 'Blog posts per page';
$string['publishtocourse'] = 'Users sharing a site with you';
$string['publishtocourseassoc'] = 'Members of the associated site';
$string['publishtogroupassoc'] = 'Your group members in the associated site';
$string['publishto_help'] = 'There are 3 options: * Yourself (draft) - Only you and the administrators can see this entry * Anyone in UNE Moodle - Only UNE staff and students can read this entry * Anyone in the world - Anyone, including guests, could read this entry';
$string['publishtosite'] = 'Anyone in UNE Moodle';
$string['relatedblogentries'] = 'Related blog posts';
$string['siteblogs'] = 'All Moodle users can see all blog posts';
$string['updateentrywithid'] = 'Updating post';
$string['userblogentries'] = 'Blog posts by {$a}';
$string['viewallblogentries'] = 'All posts about this {$a}';
$string['viewallmodentries'] = 'View all posts about this {$a->type}';
$string['viewallmyentries'] = 'View all my posts';
$string['viewblogentries'] = 'Posts about this {$a->type}';
$string['viewblogsfor'] = 'View all posts for...';
$string['viewcourseblogs'] = 'View everyone\'s posts for this site';
$string['viewentriesbyuseraboutcourse'] = 'View entries about this site by {$a}';
$string['viewgroupblogs'] = 'View posts for group...';
$string['viewgroupentries'] = 'Group posts';
$string['viewmodblogs'] = 'View posts for module...';
$string['viewmodentries'] = 'Module posts';
$string['viewmyentries'] = 'My posts';
$string['viewmyentriesaboutcourse'] = 'View my entries about this site';
$string['viewmyentriesaboutmodule'] = 'View my posts for this {$a}';
$string['viewsiteentries'] = 'View all posts';
$string['viewuserentries'] = 'View all posts by {$a}';
