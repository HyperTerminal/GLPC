<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage role
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['archetypecoursecreator'] = 'ARCHETYPE: Site creator';
$string['assignroles_help'] = 'By assigning a role to a user in a context, you are granting them the permissions contained in that role, for the current context and all lower contexts. For example, if a user is assigned the role of student in a site, they will also have the role of student for all activities and blocks within the site.';
$string['backup:backupcourse'] = 'Backup sites';
$string['blog:associatecourse'] = 'Associate blog entries with sites';
$string['course:changecategory'] = 'Change site category';
$string['course:changefullname'] = 'Change site full name';
$string['course:changeidnumber'] = 'Change site site ID number';
$string['course:changeshortname'] = 'Change site short name';
$string['course:changesummary'] = 'Change site summary';
$string['course:create'] = 'Create sites';
$string['course:delete'] = 'Delete sites';
$string['course:enrolconfig'] = 'Configure enrol instances in sites';
$string['course:enrolreview'] = 'Review site enrolments';
$string['course:markcomplete'] = 'Mark users as complete in site completion';
$string['course:publish'] = 'Publish a site into hub';
$string['course:request'] = 'Request new sites';
$string['course:reset'] = 'Reset site';
$string['course:update'] = 'Update site settings';
$string['course:view'] = 'View sites without participation';
$string['course:viewcoursegrades'] = 'View site grades';
$string['course:viewhiddencourses'] = 'View hidden sites';
$string['course:visibility'] = 'Hide/show sites';
$string['deletecourseoverrides'] = 'Delete all overrides in site';
$string['frontpageuserdescription'] = 'All logged in users in the frontpage site.';
$string['globalroleswarning'] = 'WARNING! Any roles you assign from this page will apply to the assigned users throughout the entire system, including the front page and all the sites.';
$string['legacy:coursecreator'] = 'LEGACY ROLE: Site creator';
$string['managerdescription'] = 'Managers can access sites and modify them, they usually do not participate in sites.';
$string['restore:restorecourse'] = 'Restore sites';
$string['restore:viewautomatedfilearea'] = 'Restore sites from automated backups';
$string['site:approvecourse'] = 'Approve site creation';
$string['site:backup'] = 'Backup sites';
$string['site:import'] = 'Import other site into a site';
$string['site:restore'] = 'Restore sites';
