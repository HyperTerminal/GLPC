<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    enrol
 * @subpackage self
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['groupkey_help'] = 'In addition to restricting access to the site to only those who know the key, use of a group enrolment key means users are automatically added to the group when they enrol in the site. To use a group enrolment key, an enrolment key must be specified in the site settings as well as the group enrolment key in the group settings.';
$string['longtimenosee_help'] = 'If users haven\'t accessed a site for a long time, then they are automatically unenrolled. This parameter specifies that time limit.';
$string['password_help'] = 'An enrolment key enables access to the site to be restricted to only those who know the key. If the field is left blank, any user may enrol in the site. If an enrolment key is specified, any user attempting to enrol will be required to supply the key. Note that a user only needs to supply the enrolment key ONCE, when they enrol.';
$string['pluginname_desc'] = 'The self enrolment plugin allows users to choose which sites they want to participate in. The sites may be protected by an enrolment key. Internally the enrolment is done via the manual enrolment plugin which has to be enabled in the same site.';
$string['requirepassword_desc'] = 'Require enrolment key in new sites and prevent removing of enrolment key from existing sites.';
$string['self:unenrol'] = 'Unenrol users from site';
$string['self:unenrolself'] = 'Unenrol self from the site';
$string['sendcoursewelcomemessage'] = 'Send welcome message';
$string['sendcoursewelcomemessage_help'] = 'If enabled, users receive a welcome message via email when they self-enrol.';
$string['status_desc'] = 'Allow users to self enrol into site by default.';
$string['status_help'] = 'This setting determines whether a user can enrol (and also unenrol if they have the appropriate permission) themselves from the site.';
$string['unenrolselfconfirm'] = 'Do you really want to unenrol yourself from "{$a}"?';
