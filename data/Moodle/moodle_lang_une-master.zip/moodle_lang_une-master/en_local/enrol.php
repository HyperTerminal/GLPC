<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage enrol
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['actenrolshhdr'] = 'Available site enrolment plugins';
$string['assignnotpermitted'] = 'You do not have permission or can not assign roles in this site.';
$string['defaultenrol'] = 'Add instance to new sites';
$string['defaultenrol_desc'] = 'It is possible to add this plugin to all new site by default.';
$string['enrolme'] = 'Enrol me here';
$string['enrolmentnewuser'] = '{$a->user} has enrolled in  "{$a->course}"';
$string['enrolnotpermitted'] = 'You do not have permission or are not allowed to enrol someone in this site';
$string['errorenrolcohort'] = 'Error creating cohort sync enrolment instance in this site.';
$string['errorenrolcohortusers'] = 'Error enrolling cohort members in this site.';
$string['extremovedaction_help'] = 'Select action to carry out when user enrolment disappears from external enrolment source. Please note that some user data and settings are purged  during site unenrolment.';
$string['extremovedsuspend'] = 'Disable site enrolment';
$string['extremovedsuspendnoroles'] = 'Disable site enrolment and remove roles';
$string['extremovedunenrol'] = 'Unenrol user from site';
$string['noguestaccess'] = 'This site requires you to login with your UNE account. Please press Continue to try logging in with your UNE details.';
$string['notenrollable'] = 'You can not enrol yourself in this site.';
$string['otheruserdesc'] = 'The following users are not enrolled in this site but do have roles, inherited or assigned within it.';
$string['rolefromcategory'] = '{$a->role} (Inherited from site category)';
$string['rolefrommetacourse'] = '{$a->role} (Inherited from parent site)';
$string['rolefromsystem'] = '{$a->role} (Assigned at system level)';
$string['rolefromthiscourse'] = '{$a->role} (Assigned in this site)';
$string['unassignnotpermitted'] = 'You do not have permission to unassign roles in this site';
$string['unenrolconfirm'] = 'Do you really want to unenrol user "{$a->user}" from site "{$a->course}"?';
$string['unenrolnotpermitted'] = 'You do not have permission or can not unenrol this user from this site.';
