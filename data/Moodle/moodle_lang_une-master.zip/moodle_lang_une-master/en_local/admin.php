<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage admin
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allowcoursethemes'] = 'Allow per-site themes';
$string['configallowcategorythemes'] = 'If you enable this, then themes can be set at the category level. This will affect all child categories and sites unless they have specifically set their own theme. WARNING: Enabling category themes may affect performance.';
$string['configallowcoursethemes'] = 'If you enable this, then sites will be allowed to set their own themes. Site themes override all other theme choices (system, user, or category themes)';
$string['configallowuserthemes'] = 'If you enable this, then users will be allowed to set their own themes. User themes override site themes (but not site themes)';
$string['configallusersaresitestudents'] = 'For activities on the front page of Moodle, should ALL users be considered as students? If you answer "Yes", then any confirmed user account will be allowed to participate as a student in those activities. If you answer "No", then only users who are already a participant in at least one site will be able to take part in those front page activities. Only admins and specially assigned teachers can act as teachers for these front page activities.';
$string['configautologinguests'] = 'Should visitors be logged in as guests automatically when entering sites with guest access?';
$string['configcourserequestnotify'] = 'Type username of user to be notified when new sites requested.';
$string['configcourserequestnotify2'] = 'Users who will be notified when a site is requested. Only users who can approve site requests are listed here.';
$string['configcoursesperpage'] = 'Enter the number of sites to be display per page in a site listing.';
$string['configdefaultallowedmodules'] = 'For the sites which fall into the above category, which modules do you want to allow by default <strong>when the site is created</strong>?';
$string['configdefaultrequestcategory'] = 'Sites requested by users will be automatically placed in this category.';
$string['configdefaultrequestedcategory'] = 'Default category to put sites that were requested into, if they\'re approved.';
$string['configdefaultuserroleid'] = 'All logged in users will be given the capabilities of the role you specify here, at the site level, in ADDITION to any other roles they may have been given. The default is the Authenticated user role. Note that this will not conflict with other roles they have, it just ensures that all users have capabilities that are not assignable at the site level (eg post blog entries, manage own calendar, etc).';
$string['configenablecourserequests'] = 'This will allow any user to request a site be created.';
$string['configenablestats'] = 'If you choose \'yes\' here, Moodle\'s cronjob will process the logs and gather some statistics. Depending on the amount of traffic on your site, this can take awhile. If you enable this, you will be able to see some interesting graphs and statistics about each of your sites, or on a system-wide basis.';
$string['configforcelogin'] = 'Normally, the front page of the site and the site listings (but not sites) can be read by people without logging in to the site. If you want to force people to log in before they do ANYTHING on the site, then you should enable this setting.';
$string['configgradebookroles'] = 'This setting allows you to control who appears on the gradebook. Users need to have at least one of these roles in a course to be shown in the gradebook for that site.';
$string['confighiddenuserfields'] = 'Select which user information fields you wish to hide from other users other than site teachers/admins. This will increase student privacy. Hold CTRL key to select multiple fields.';
$string['configmaxbytes'] = 'This specifies a maximum size that uploaded files can be throughout the whole site. This setting is limited by the PHP settings post_max_size and upload_max_filesize, as well as the Apache setting LimitRequestBody. In turn, maxbytes limits the range of sizes that can be chosen at site level or module level. If \'Server Limit\' is chosen, the server maximum allowed by the server will be used.';
$string['configmycoursesperpage'] = 'Maximum number of sites to display in any list of a user\'s own courses';
$string['confignavcourselimit'] = 'Limits the number of sites shown to the user when they are either not logged in or are not enrolled in any courses.';
$string['confignavshowallcourses'] = 'Setting this ensures that all sites in Moodle are shown in the navigation at all times.';
$string['confignavshowcategories'] = 'Show categories in the navigation bar and navigation blocks. This does not occur with courses the user is currently enrolled in, they will still be listed under My Sites without categories.';
$string['configopentogoogle'] = 'If you enable this setting, then Google will be allowed to enter your site as a Guest. In addition, people coming in to Moodle via a Google search will automatically be logged in as a Guest. Note that this only provides transparent access to sites that already allow guest access.';
$string['configprofilesforenrolledusersonly'] = 'To prevent misuse by spammers, profile descriptions of users who are not yet enrolled in any course are hidden. New users must enrol in at least one site before they can add a profile description.';
$string['configrequestedstudentname'] = 'Word for student used in requested sites';
$string['configrequestedstudentsname'] = 'Word for students used in requested sites';
$string['configrequestedteachername'] = 'Word for teacher used in requested sites';
$string['configrequestedteachersname'] = 'Word for teachers used in requested sites';
$string['configrestrictbydefault'] = 'Should new sites that are created that fall into the above category have their modules restricted by default?';
$string['configrestrictmodulesfor'] = 'Which sites should have <strong>the setting</strong> for disabling some activity modules? Note that this setting only applies to teachers, administrators will still be able to add any activity to a site.';
$string['configsectionrequestedcourse'] = 'Site requests';
$string['configstatsuserthreshold'] = 'This setting specifies the minimum number of enrolled users for a site to be included in statistics calculations.';
$string['configuseblogassociations'] = 'Should users be able to organize their blog by associating entries with sites and site modules?';
$string['configvisiblecourses'] = 'Display sites in hidden categories normally';
$string['coursecontact'] = 'Site contacts';
$string['coursecontact_desc'] = 'This setting allows you to control who appears on the site description. Users need to have at least one of these roles in a site to be shown on the site description.';
$string['coursemgmt'] = 'Add/edit sites';
$string['courseoverview'] = 'Site overview';
$string['courserequestnotify'] = 'Site request notification';
$string['courserequestnotifyemail'] = 'User {$a->user} requested a new site at {$a->link}';
$string['courserequests'] = 'Site requests';
$string['courserequestspending'] = 'Pending site requests';
$string['courses'] = 'Manage sites';
$string['coursesperpage'] = 'Sites per page';
$string['creatornewroleid'] = 'Creators\' role in new sites';
$string['defaultrequestcategory'] = 'Default category for site requests';
$string['enablecourseajax'] = 'Enable AJAX site editing';
$string['enablecourseajax_desc'] = 'Allow AJAX when editing main site pages. Note that the site format and the theme must support AJAX editing and the user has to enable AJAX in their profiles, too.';
$string['enablecourserequests'] = 'Enable site requests';
$string['enrolinstancedefaults_desc'] = 'Default enrolment settings';
$string['guestroleid_help'] = 'This role is automatically assigned to the guest user. It is also temporarily assigned to not enrolled users that enter the site via guest enrolment plugin.';
$string['legacyfilesinnewcourses'] = 'Shared Files in new courses';
$string['legacyfilesinnewcourses_help'] = 'By default Shared Files areas are available only in upgraded sites. Please note some features like single activity backup/restore are not compatible with this settings.';
$string['mycoursesperpage'] = 'Number of sites';
$string['navcourselimit'] = 'Site limit';
$string['navshowallcourses'] = 'Show all sites';
$string['stickyblockscourseview'] = 'Site page';
