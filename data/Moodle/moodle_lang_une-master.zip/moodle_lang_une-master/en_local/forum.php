<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    mod
 * @subpackage forum
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['allowsallsubscribe'] = 'This forum allows everyone to choose whether or not to receive emails';
$string['allsubscribe'] = 'Receive emails from all forums';
$string['allunsubscribe'] = 'Cease receiving emails from all forums';
$string['cannotaddteacherforumto'] = 'Could not add converted teacher forum instance to section 0 in the site';
$string['cannotcreateinstanceforteacher'] = 'Could not create new module instance for the teacher forum';
$string['cannotmovetonotfound'] = 'Target forum not found.';
$string['configlongpost'] = 'Any post over this length (in characters not including HTML) is considered long. Posts displayed on the site front page, social format site pages, or user profiles are shortened to a natural break somewhere between the forum_shortpost and forum_longpost values.';
$string['configmaxbytes'] = 'Default maximum size for all forum attachments on the site (subject to site limits and other local settings)';
$string['confirmsubscribe'] = 'Do you really want to subscribe to receive emails from forum \'{$a}\'?';
$string['confirmunsubscribe'] = 'Do you really want to unsubscribe from receiving emails from forum \'{$a}\'?';
$string['disallowsubscribe'] = 'Email subscriptions not allowed';
$string['disallowsubscribeteacher'] = 'Email subscriptions not allowed (except for teachers)';
$string['everyonecanchoose'] = 'Everyone can choose to receive emails';
$string['everyonecannowchoose'] = 'Everyone can now choose to receive emails';
$string['everyoneisnowsubscribed'] = 'Everyone is now subscribed to receive emails from this forum';
$string['everyoneissubscribed'] = 'Everyone is subscribed receive emails from this forum';
$string['existingsubscribers'] = 'Existing email subscribers';
$string['forcessubscribe'] = 'This forum forces everyone to receive emails';
$string['forum:initialsubscriptions'] = 'Initial email subscription';
$string['forum:managesubscriptions'] = 'Manage email subscriptions';
$string['forum:viewsubscribers'] = 'View email subscribers';
$string['introblog'] = 'The posts in this forum were copied here automatically from blogs of users in this site because those blog entries are no longer available';
$string['invalidforcesubscribe'] = 'Invalid force email subscription mode';
$string['messageprovider:digests'] = 'Subscribed email forum digests';
$string['messageprovider:posts'] = 'Subscribed email forum posts';
$string['namenews_help'] = 'The news forum is a special forum for announcements that is automatically created when a site is created. A site can have only one news forum. Only teachers and administrators can post in the news forum. The "Latest news" block will display recent discussions from the news forum.';
$string['noonecansubscribenow'] = 'Email subscriptions are now disallowed';
$string['nopermissiontosubscribe'] = 'You do not have the permission to view forum email subscribers';
$string['nosubscribers'] = 'There are no email subscribers yet for this forum';
$string['nowallsubscribed'] = 'All forums in {$a} have email subscriptions.';
$string['nowallunsubscribed'] = 'No forums in {$a} have email subscriptions.';
$string['potentialsubscribers'] = 'Potential email subscribers';
$string['resetsubscriptions'] = 'Delete all forum email subscriptions';
$string['showsubscribers'] = 'Show/edit current email subscribers';
$string['subscribe'] = 'Subscribe to receive emails from this forum';
$string['subscribeall'] = 'Subscribe everyone to receive emails from this forum';
$string['subscribed'] = 'Subscribed to receive email';
$string['subscribenone'] = 'Cease email subscriptions for everyone';
$string['subscribers'] = 'Email subscribers';
$string['subscribersto'] = 'Email subscribers to \'{$a}\'';
$string['subscription'] = 'Email subscription';
$string['subscriptionauto'] = 'Auto email subscription (opt-out)';
$string['subscriptiondisabled'] = 'No one will ever receive emails';
$string['subscriptionforced'] = 'Everyone will receive emails';
$string['subscriptionmode'] = 'Email subscription';
$string['subscriptionmode_help'] = 'When a participant is subscribed to a forum it means they will receive email copies of forum posts. There are 4 subscription mode options: * Optional subscription - Participants can choose whether to be subscribed * Everyone will receive emails - Everyone will receive emails and can\'t opt-out * Auto subscription - Everyone is subscribed initially but can choose to opt-out at any time * No one will ever receive emails - Subscriptions are not allowed';
$string['subscriptionoptional'] = 'Optional email subscription (opt-in)';
$string['subscriptions'] = 'Email subscriptions';
$string['unsubscribe'] = 'Stop receiving emails from this forum';
$string['unsubscribeall'] = 'Stop receiving emails from all forums';
$string['unsubscribealldone'] = 'All your forum email subscriptions were removed, you might still receive notifications from forums with forced subscription. If you do not want to receive any emails from this server please go to your profile and disable email address there.';
$string['unsubscribed'] = 'Won\'t receive emails';
$string['unsubscribeshort'] = 'Stop receiving emails';
