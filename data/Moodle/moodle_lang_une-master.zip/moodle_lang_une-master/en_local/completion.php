<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage completion
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addcourseprerequisite'] = 'Add site prerequisite';
$string['completion_help'] = 'If enabled, activity completion is tracked, either manually or automatically, based on certain conditions. Multiple conditions may be set if desired. If so, the activity will only be considered complete when ALL conditions are met. A tick next to the activity name on the site page indicates when the activity is complete.';
$string['completionicons_help'] = 'A tick next an activity name may be used to indicate when the activity is complete. If a dotted tick is shown, you can click it to tick the box when you think you have completed the activity. (Clicking it again removes the tick if you change your mind.) The tick is optional and is simply a way of tracking your progress. If a blank tick box is shown, a tick will appear automatically when you have completed the activity according to conditions set by the teacher.';
$string['completionstartonenrolhelp'] = 'Begin tracking a student\'s progress in site completion after enrolment';
$string['configenablecompletion'] = 'When enabled, this lets you turn on completion tracking (progress) features at site level.';
$string['coursecomplete'] = 'Site complete';
$string['coursecompleted'] = 'Site completed';
$string['coursegrade'] = 'Site grade';
$string['courseprerequisites'] = 'Site prerequisites';
$string['coursesavailable'] = 'Sites available';
$string['coursesavailableexplaination'] = '<em>Site completion criteria must be set for a site to appear in this list</em>';
$string['deletecoursecompletiondata'] = 'Delete site completion data';
$string['editcoursecompletionsettings'] = 'Edit site completion settings';
$string['err_nocourses'] = 'Site completion is not enabled for any other sites, so none can be displayed. You can enable site completion in the site settings.';
$string['err_nograde'] = 'A pass grade has not been set for this site. To enable this criteria type you must create a pass grade for this site.';
$string['err_noroles'] = 'There are no roles with the capability \'moodle/course:markcomplete\' in this site. You can enable this criteria type by adding this capability to role(s).';
$string['err_nousers'] = 'There are no students on this site or group for whom completion information is displayed. (By default, completion information is displayed only for students, so if there are no students, you will see this error. Administrators can alter this option via the admin screens.)';
$string['notenroled'] = 'You are not enroled as a student in this site';
$string['unenrolingfromcourse'] = 'Unenroling from site';
$string['usealternateselector'] = 'Use the alternate site selector';
$string['viewcoursereport'] = 'View site report';
