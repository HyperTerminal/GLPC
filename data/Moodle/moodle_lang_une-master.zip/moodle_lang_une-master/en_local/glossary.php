<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    mod
 * @subpackage glossary
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['entryusedynalink_help'] = 'If system-wide glossary auto-linking has been enabled by an administrator and this checkbox is ticked, the entry will be automatically linked wherever the concept words and phrases appear throughout the rest of the site.';
$string['explainexport'] = 'Click on the button below to export glossary entries.<br />You can import it anytime you wish in this or other site.<p>Please note that attachments (e.g. images) and authors are not exported.</p>';
$string['glossarytype_help'] = 'A main glossary is a glossary in which entries from secondary glossaries can be imported. There can only be one main glossary in a site. If glossary entry import is not required, all glossaries in the site can be secondary glossaries.';
$string['isglobal_help'] = 'A global glossary has entries which are linked to from throughout the site, rather than only in the site that the glossary is in. Only administrators can set a glossary as global.';
$string['linkcategory_help'] = 'If glossary auto-linking has been enabled and this setting is enabled, the category name will be automatically linked wherever it appears throughout the rest of the site. When a participant follows a category name link, they will be taken to the "Browse by category" page of the glossary.';
$string['modulename_help'] = 'The glossary module enables participants to create and maintain a list of definitions, like a dictionary. Glossary entries may be automatically linked wherever the concept words and phrases appear throughout the site.';
$string['usedynalink_help'] = 'If site-wide glossary auto-linking has been enabled by an administrator and this setting is enabled, the "Add a new entry" form includes the option to automatically link the entry wherever the concept words and phrases appear throughout the rest of the site.';
