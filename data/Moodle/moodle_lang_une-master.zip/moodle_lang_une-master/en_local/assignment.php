<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://moodle-stage.une.edu.au
 *
 * @package    mod
 * @subpackage assignment
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['configmaxbytes'] = 'Default maximum assignment size for all assignments on the site (subject to site limits and other local settings)';
$string['coursemisconf'] = 'Site is misconfigured';
$string['emailteachers_help'] = 'If enabled, teachers receive email notification whenever students add or update an assignment submission. Only teachers who are able to grade the particular assignment are notified. So, for example, if the site uses separate groups, teachers restricted to particular groups won\'t receive notification about students in other groups.';
$string['feedbackfromteacher'] = 'Feedback from {$a}';
$string['nofiles'] = 'No files uploaded';
$string['nofilesyet'] = 'No files uploaded';
$string['nomoresubmissions'] = 'No submissions are allowed at this time';
$string['sendformarking'] = 'SEND FOR MARKING';
$string['submissiondraft'] = 'Uploaded assignment files';
$string['submitedformarking'] = 'Your assignment has been submitted and can no longer be updated';
$string['submitformarking'] = 'Send all files for marking';
$string['typeupload'] = 'Submit one or more files';
