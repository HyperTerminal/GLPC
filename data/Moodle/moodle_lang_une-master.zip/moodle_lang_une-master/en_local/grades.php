<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage grades
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['aggregationposition_help'] = 'This setting determines whether the category and site total columns are displayed first or last in the gradebook reports.';
$string['courseavg'] = 'Site average';
$string['coursegradecategory'] = 'Site grade category';
$string['coursegradedisplaytype'] = 'Site grade display type';
$string['coursegradedisplayupdated'] = 'The site grade display type has been updated.';
$string['coursegradesettings'] = 'Site grade settings';
$string['coursename'] = 'Site name';
$string['coursescales'] = 'Site scales';
$string['coursesettings'] = 'Site settings';
$string['coursetotal'] = 'Site total';
$string['errornocourse'] = 'Could not get site information';
$string['gradeoutcomescourses'] = 'Site outcomes';
$string['gradepass_help'] = 'This setting determines the minimum grade required to pass. The value is used in activity and site completion, and in the gradebook, where pass grades are highlighted in green and fail grades in red.';
$string['importcustom'] = 'Import as custom outcomes (only this site)';
$string['includescalesinaggregation_help'] = 'You can change whether scales are to be included as numbers in all aggregated grades across all gradebooks in all sites. CAUTION: changing this setting will force all aggregated grades to be recalculated.';
$string['incorrectcourseid'] = 'Site ID was incorrect';
$string['multfactor'] = 'Multiplier';
$string['multfactor_help'] = 'The multiplier is the factor by which all grades for this grade item will be multiplied, with a maximum value of the maximum grade. For example, if the multiplicator is 2 and the maximum grade is 100, then all grades less than 50 are multiplied by 2, and all grades 50 and above are changed to 100.';
$string['nocategories'] = 'Grade categories could not be added or found for this site';
$string['nocourses'] = 'There are no sites yet';
$string['nooutcomes'] = 'Outcome items must be linked to a course outcome, but there are no outcomes for this site. Would you like to add one?';
$string['noscales'] = 'Outcomes must be linked to a site scale or system-wide scale, but there are none. Would you like to add one?';
$string['outcomeassigntocourse'] = 'Assign another outcome to this site';
$string['outcomescourse'] = 'Outcomes used in site';
$string['outcomestandard_help'] = 'A standard outcome is available site-wide, for all sites.';
$string['overridesitedefaultgradedisplaytype_help'] = 'If ticked, grade letters and boundaries may be set, rather than using the system-wide defaults.';
$string['plusfactor_help'] = 'The offset is a number that is added to every grade for this grade item, after the multiplier is applied.';
$string['seeallcoursegrades'] = 'See all grades';
$string['setcategorieserror'] = 'You must first set the categories before you can give weights to them.';
$string['unenrolledusersinimport'] = 'This import included the following grades for users not currently enrolled in: {$a}';
$string['usedcourses'] = 'Used sites';
$string['weightcourse'] = 'Use weighted grades';
