<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage backup
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['backupcourse'] = 'Backup site: {$a}';
$string['backupcoursedetails'] = 'Site details';
$string['backupcoursesections'] = 'Site sections';
$string['backupsection'] = 'Backup section: {$a}';
$string['backuptypecourse'] = 'Site';
$string['choosefilefromcoursebackup'] = 'Site backup area';
$string['choosefilefromcoursebackup_help'] = 'When backup sites using default settings, backup files will be stored here';
$string['choosefilefromuserbackup_help'] = 'When backup sites with "Anonymize user information" option ticked, backup files will be stored here';
$string['coursecategory'] = 'Category the site will be restored into';
$string['coursesettings'] = 'Site settings';
$string['importcurrentstage0'] = 'Site selection';
$string['importsuccess'] = 'Import complete. Click continue to return to the site.';
$string['nomatchingcourses'] = 'There are no sites to display';
$string['norestoreoptions'] = 'There are no categories of existing sites you can restore to.';
$string['qcategory2coursefallback'] = 'The questions category "{$a->name}", originally at system/site category context in backup file, will be created at site context by restore';
$string['question2coursefallback'] = 'The questions category "{$a->name}", originally at system/site category context in backup file, will be created at site context by restore';
$string['restorecourse'] = 'Restore site';
$string['restorecoursesettings'] = 'Site settings';
$string['restoreexecutionsuccess'] = 'The site was restored successfully, clicking the continue button below will take you to view the site you restored.';
$string['restorenewcoursefullname'] = 'New site name';
$string['restorenewcourseshortname'] = 'New site short name';
$string['restoretocourse'] = 'Restore to site:';
$string['restoretocurrentcourse'] = 'Restore into this site';
$string['restoretocurrentcourseadding'] = 'Merge the backup site into this site';
$string['restoretocurrentcoursedeleting'] = 'Delete the contents of this site and then restore';
$string['restoretoexistingcourse'] = 'Restore into an existing site';
$string['restoretoexistingcourseadding'] = 'Merge the backup site into the existing site';
$string['restoretoexistingcoursedeleting'] = 'Delete the contents of the existing site and then restore';
$string['restoretonewcourse'] = 'Restore as a new site';
$string['restoringcourse'] = 'Site restoration in progress';
$string['rootsettinglogs'] = 'Include site logs';
$string['selectacourse'] = 'Select a site';
$string['setting_course_fullname'] = 'Site name';
$string['setting_course_shortname'] = 'Site short name';
$string['setting_course_startdate'] = 'Site startdate';
$string['setting_overwriteconf'] = 'Overwrite site configuration';
$string['storagecourseandexternal'] = 'Site backup filearea and the specified directory';
$string['storagecourseonly'] = 'Site backup filearea';
$string['totalcoursesearchresults'] = 'Total found : {$a}';
