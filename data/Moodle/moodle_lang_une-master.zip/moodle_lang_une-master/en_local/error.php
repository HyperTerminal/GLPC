<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://nelson.local/~myles/m2
 *
 * @package    core
 * @subpackage error
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['cannotaddcoursemodule'] = 'Could not add a new site module';
$string['cannotaddcoursemoduletosection'] = 'Could not add the new site module to that section';
$string['cannotassignrole'] = 'Cannot assign role in site';
$string['cannotcreateorfindstructs'] = 'Error finding or creating section structures for this site';
$string['cannotdeletecategorycourse'] = 'Site \'{$a}\' failed to be deleted.';
$string['cannotdeletecourse'] = 'You do not have the permission to delete this site';
$string['cannoteditsiteform'] = 'You cannot edit the system site using this form';
$string['cannotfindcourse'] = 'Cannot find site';
$string['cannothaveparentcate'] = 'Site category cannot have parent!';
$string['cannotinsertgrade'] = 'Cannot insert grade item without site id!';
$string['cannotmarktopic'] = 'Could not mark that topic for this site';
$string['cannotremovefrommeta'] = 'Could not remove the selected site from this meta site!';
$string['cannotrestoreadminorcreator'] = 'You need to be a creator or admin user to restore into new site!';
$string['cannotrestoreadminoredit'] = 'You need to be a editing teacher or admin user to restore into selected site!';
$string['cannotsetparentforcatoritem'] = 'Cannot set parent for category or site item!';
$string['cannotshowhidecoursesincategory'] = 'Cannot show/hide the sites in category {$a}.';
$string['cannotupdatesubcourse'] = 'Could not update a child site!';
$string['coursedoesnotbelongtocategory'] = 'The site doesn\'t belong to this category';
$string['coursegroupunknown'] = 'Site corresponding to group {$a} not specified';
$string['courseidnotfound'] = 'Site id doesn\'t exist';
$string['coursemisconf'] = 'Site is misconfigured';
$string['courserequestdisabled'] = 'Sorry, but requesting sites has been disabled by the administrator';
$string['destinationcmnotexit'] = 'The destination site module does not exist';
$string['groupexistforcourse'] = 'Group "{$a}" already exists for this site';
$string['groupunknown'] = 'Group {$a} not associated to specified site';
$string['idnumbertaken'] = 'ID number is already used for another site';
$string['invalidcourse'] = 'Invalid site';
$string['invalidcourseid'] = 'You are trying to use an invalid site ID: ({$a})';
$string['invalidcoursemodule'] = 'Invalid site module ID';
$string['invalidcoursenameshort'] = 'Invalid short name';
$string['invalidsection'] = 'Site module record contains invalid section';
$string['invalidshortname'] = 'That\'s an invalid short site name';
$string['loginasnoenrol'] = 'You cannot use enrol or unenrol when in site "Login as" session';
$string['loginasonecourse'] = 'You cannot enter this site.<br /> You have to terminate the "Login as" session before entering any other site.';
$string['needcoursecategroyid'] = 'Either site id or category must be specified';
$string['nocontext'] = 'Sorry, but that site is not a valid context';
$string['noinstances'] = 'There are no instances of {$a} in this site!';
$string['noparticipants'] = 'No participants found for this site';
$string['noparticipatorycms'] = 'Sorry, but you have no participatory site modules to report on';
$string['nopermissiontoimportact'] = 'You do not have the required permissions to import activities to this site';
$string['nosite'] = 'Could not find a top-level site!';
$string['notmemberofgroup'] = 'You are not a member of this site group';
$string['reportnotavailable'] = 'This type of report is only available for the frontpage site';
$string['requireloginerror'] = 'Site or activity not accessible.';
$string['shortnametaken'] = 'Short name is already used for another site';
$string['unknowncourse'] = 'Unknown site named "{$a}"';
$string['unknowncourseidnumber'] = 'Unknown site ID "{$a}"';
$string['unknowncourserequest'] = 'Unknown site request';
$string['unspecifycourseid'] = 'Must specify site id, short name or idnumber';
$string['usernotincourse'] = 'This user is not in this site!';
