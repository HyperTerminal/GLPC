<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: user.php 22688 2007-09-16 16:46:08Z landseer $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage HitCount
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_HITCOUNT', 'Contador de Hits');
define('_HITCOUNTMODSWERECOUNTING', 'M�dulos a los que se les est� contando los hits de las impresiones');
define('_HITCOUNTHITS', 'hits');
define('_HITCOUNTITEMS', 'elementos');
