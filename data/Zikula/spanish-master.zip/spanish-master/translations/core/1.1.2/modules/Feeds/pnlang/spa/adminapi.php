<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: adminapi.php 22930 2007-10-11 10:06:47Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Feeds
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_FEEDS_INVALIDPROTOCOL', 'El protocolo seleccionado no es v�lido. S�lo se permite http y https.');
define('_FEEDS_URLTOOLONG', 'La URL proporcionada es muy larga (m�x. 200 caract�res).');
