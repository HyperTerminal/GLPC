<?php
/**
 * Zikula Application Framework
 *
 * @link http://www.zikula.org
 * @version $Id: Loader.class.php 22543 2007-07-31 12:50:09Z rgasch $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author Simon Birtwistle simon@itbegins.co.uk
 * @package Zikula_Docs
 * @subpackage Tour
 */

define('_TOUR_DISPLAYNAME', 'Bienvenida');
define('_TOUR_DESCRIPTION', 'Tour a trav�s de Zikula y su configuraci�n por primera vez.');
