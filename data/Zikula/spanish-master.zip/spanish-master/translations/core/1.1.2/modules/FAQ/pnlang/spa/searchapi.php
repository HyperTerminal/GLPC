<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: searchapi.php 22139 2007-06-01 10:57:16Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage FAQ
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_FAQ_CATEGORIES', 'FAQs');
define('_FAQ_SEARCH', 'Buscar en FAQs');
define('_FAQ_SEARCHRESULTS', 'FAQs encontradas');
define('_FAQ_SEACHNONEFOUND', 'No se encontraron FAQs');
