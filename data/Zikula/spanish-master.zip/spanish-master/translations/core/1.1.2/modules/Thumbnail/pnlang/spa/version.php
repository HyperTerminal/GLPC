<?php 
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: sniffer.php 22139 2007-06-01 10:57:16Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Thumbnail
 */
 
/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_THUMBNAIL_DISPLAYNAME', 'Thumbnail');
define('_THUMBNAIL_DESCRIPTION', 'Provee facilidades en la generaci�n de im�genes miniatura usando las funciones del userapi de este m�dulo');

