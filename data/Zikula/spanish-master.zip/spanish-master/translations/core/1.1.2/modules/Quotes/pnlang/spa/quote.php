<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: quote.php 22917 2007-10-09 14:15:45Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Quotes
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_QUOTES_ERRORMSG', 'Hay muy pocas citas en la base de datos');
