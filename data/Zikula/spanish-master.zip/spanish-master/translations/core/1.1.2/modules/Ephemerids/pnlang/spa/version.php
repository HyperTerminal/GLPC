<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: ephem.php 22934 2007-10-11 15:18:57Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Ephemerids
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_EPHEMERIDS_DISPLAYNAME', 'efemerides');
define('_EPHEMERIDS_DESCRIPTION', 'Un m�dulo de \'Este d�a en la historia\'.');
