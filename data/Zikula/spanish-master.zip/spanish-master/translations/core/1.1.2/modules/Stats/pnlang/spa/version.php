<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: pnadmin.php 19209 2006-06-05 13:57:35Z drak $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Stats
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_STATS_DISPLAYNAME', 'Estadisticas');
define('_STATS_DESCRIPTION', 'Muestra las estad�sticas del sitio.');

