<?php
/**
 * Zikula Application Framework
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: user.php 22688 2007-09-16 16:46:08Z landseer $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Recommend_Us
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_RECOMMENDUS_DISPLAYNAME', 'recomendar');
define('_RECOMMENDUS_DESCRIPTION', 'M�dulo para recomendar el sitio o art�culos.');
