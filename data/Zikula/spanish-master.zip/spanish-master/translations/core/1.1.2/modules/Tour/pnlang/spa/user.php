<?php
/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_TOUR_TOUR', 'Tour de Zikula');
define('_TOUR_HOME', 'Inicio del Tour');
define('_TOUR_FTTOUR', 'Primera vez');
define('_TOUR_YOURDISTRIBUTION', 'Tu Distribuci�n');
define('_TOUR_NEWIN', 'Lo nuevo en Zikula 1.0');
define('_TOUR_BASICCONFIG', 'Configuraci�n b�sica');
define('_TOUR_EXTENSIONTOURS', 'Extensiones');
define('_TOUR_EXTENSIONS', 'Extensiones');
define('_TOUR_MODULES', 'M�dulos');
define('_TOUR_BLOCKS', 'Bloques');
define('_TOUR_THEMES', 'Themes');
define('_TOUR_PAGE', 'P�gina %p%');
define('_TOUR_START', 'Inicio');
define('_TOUR_FINISH', 'Final');