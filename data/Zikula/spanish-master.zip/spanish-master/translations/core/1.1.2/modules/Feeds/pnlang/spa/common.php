<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: admin.php 22911 2007-10-09 07:36:13Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Feeds
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_FEEDS', 'Titulares');
define('_FEEDS_FEED', 'Canal');
define('_FEEDS_FEEDS', 'Canales');
