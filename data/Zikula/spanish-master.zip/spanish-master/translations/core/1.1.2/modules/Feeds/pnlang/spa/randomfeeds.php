<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Feeds
 */

define('_FEEDS_RANDOM_APPEND', 'A�adir un nuevo canal');
define('_FEEDS_RANDOM_HINTLIST', 'Esta es la lista de canales de donde se seleccionar� uno aleatoriamente. Puedes a�adir/remover de la lista cuantos canales quieras');
