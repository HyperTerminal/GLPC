<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2004, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Frank Chestnut [Chestnut]
 * @package      Zikula_System_Modules
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_PROFILE_DISPLAYNAME', 'perfil');
define('_PROFILE_DESCRIPTION', 'Provee un panel de control para las cuentas personales para cada usuario registrado, y una interfaz para administrar los elementos de informaci�n (controles) mostrados en �l. Trabaja en un�sono con el m�dulo de Usuarios.');

