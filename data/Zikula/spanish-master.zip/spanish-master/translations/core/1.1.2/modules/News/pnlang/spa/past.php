<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: past.php 22139 2007-06-01 10:57:16Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage News
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_OLDERARTICLES', 'Art�culos antiguos');
define('_PASTARTICLES', 'Art�culos pasados');
define('_MAXNUMSTORIES', 'N�mero m�ximo de noticias a listar');
