<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: admin.php 22139 2007-06-01 10:57:16Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Sniffer
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_SNIFFER', 'Detector de navegadores');
define('_SNIFFERBASICINFO', 'Informaci�n b�sica de los navegadores');
define('_SNIFFERBROWSERNAME', 'Navegador');
define('_SNIFFERBROWSERVERSION', 'Versi�n del navegador');
define('_SNIFFEROSNAME', 'S.O.');
define('_SNIFFEROSVERSION', 'Versi�n del S.O.');
define('_SNIFFERUA', 'Agente de Usuario');
