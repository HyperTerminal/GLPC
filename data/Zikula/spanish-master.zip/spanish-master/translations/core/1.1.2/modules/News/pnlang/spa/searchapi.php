<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: searchapi.php 22692 2007-09-17 20:31:39Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage News
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_NEWS_SEARCH', 'B�squeda de Art�culos de Noticias');
define('_NEWS_SEACHNONEFOUND', 'No se encontraron art�culos');
