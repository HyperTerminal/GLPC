<?php 
/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

require_once('modules/Thumbnail/pnlang/spa/common.php');
