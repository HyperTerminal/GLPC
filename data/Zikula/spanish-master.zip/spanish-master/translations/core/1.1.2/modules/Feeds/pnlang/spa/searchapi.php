<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: user.php 21009 2007-01-08 16:37:52Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Feeds
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_FEEDS_SEARCH', 'Canales RSS');
define('_FEEDS_SEARCHRESULTS', 'encontrado');
define('_FEEDS_FROMFEED', 'Desde el Canal');
