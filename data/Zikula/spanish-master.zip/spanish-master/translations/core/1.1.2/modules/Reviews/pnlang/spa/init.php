<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: init.php 18301 2008-02-15 13:08:10Z mateo $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Reviews
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_REVIEWS_IMPORTEDNAME', 'Revisiones importadas');
define('_REVIEWS_IMPORTEDDESCRIPTION', 'Revisiones importadas de la versi�n .76x');