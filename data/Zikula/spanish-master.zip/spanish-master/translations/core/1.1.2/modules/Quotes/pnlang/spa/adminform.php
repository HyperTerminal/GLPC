<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: admin.php 19572 2006-08-04 08:07:49Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Quotes
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

require_once 'modules/Quotes/pnlang/spa/admin.php';
