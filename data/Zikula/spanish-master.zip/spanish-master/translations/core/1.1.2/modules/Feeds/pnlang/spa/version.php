<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: user.php 22930 2007-10-11 10:06:47Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Feeds
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_FEEDS_DISPLAYNAME', 'feeds');
define('_FEEDS_DESCRIPTION', 'Lector de canales RSS.');
