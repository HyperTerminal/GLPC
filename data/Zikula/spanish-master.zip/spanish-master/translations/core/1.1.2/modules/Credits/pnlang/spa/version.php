<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: user.php 22558 2007-08-05 16:24:47Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_Value_Addons
 * @subpackage Credits
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_CREDITS_DISPLAYNAME', 'creditos');
define('_CREDITS_DESCRIPTION', 'Muestra los cr�ditos, licencia, ayuda e informaci�n de contacto de los m�dulos del sistema');