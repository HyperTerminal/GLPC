<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: version.php 19998 2006-09-07 08:27:00Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Franz Skaaning
 * @package      Zikula_Themes
 * @subpackage Atom
 */

define('_ATOM_THEME_NAME', 'Atom');
define('_ATOM_DISPLAYNAME', 'Atom');
define('_ATOM_DESCRIPTION', 'El theme \'Atom\', para mostrar las p�ginas en formato Atom');
