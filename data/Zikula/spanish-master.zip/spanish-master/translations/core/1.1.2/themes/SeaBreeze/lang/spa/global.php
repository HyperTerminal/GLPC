<?php
define('_ADDSTORY','A�adir art�culo');
define('_DOWNLOAD','Descargas');
define('_EMAILTOAFRIEND', 'Recomendar a un amigo');
define('_FAQ','FAQ');
define('_FORUMS','Foros');
define('_GROUPADMIN','Grupos');
define('_HOME','Inicio');
define('_PERMISSIONS', 'Permisos');
define('_PRINTTHISSTORY', 'Imprimir este art�culo');
define('_PUBLISHED', 'Publicado');
define('_REVIEWS','An�lisis');
define('_SETTINGS','Configuraci�n');
define('_USERADMIN','Admin de usuarios');
define('_WORDSMORE', 'palabras');
