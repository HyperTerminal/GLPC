<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: init.php 22310 2007-07-04 09:12:46Z rgasch $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

// Users
define('_USER_1_a','1');
define('_USER_1_b','');
define('_USER_1_c','visitante');
define('_USER_1_d','');
define('_USER_1_e','');
define('_USER_1_f','');
define('_USER_1_g','blank.gif');
// define('_USER_1_h',''); // time()
define('_USER_1_h','');
define('_USER_1_i','');
define('_USER_1_j','');
define('_USER_1_k','');
define('_USER_1_l','');
define('_USER_1_m','0');
define('_USER_1_n','0');
define('_USER_1_o','');
define('_USER_1_p','');
define('_USER_1_q','');
define('_USER_1_r','');
define('_USER_1_s','10');
define('_USER_1_t','');
define('_USER_1_u','0');
define('_USER_1_v','0');
define('_USER_1_w','0');
define('_USER_1_x','');
define('_USER_1_y','0');
define('_USER_1_aa','');
define('_USER_1_ab','');
define('_USER_1_ac','4096');
define('_USER_1_ad','0');
define('_USER_1_ae','0');
define('_USER_1_af','1');

// Users
define('_USER_2_a','2');
define('_USER_2_b','');
define('_USER_2_c','admin');
define('_USER_2_d','');
define('_USER_2_e','');
define('_USER_2_f','');
define('_USER_2_g','blank.gif');
// define('_USER_2_h',''); // time()
define('_USER_2_h','');
define('_USER_2_i','');
define('_USER_2_j','');
define('_USER_2_k','');
define('_USER_2_l','');
define('_USER_2_m','0');
define('_USER_2_n','0');
define('_USER_2_o','');
define('_USER_2_p','');
define('_USER_2_q','');
define('_USER_2_r',md5('Password'));
define('_USER_2_s','10');
define('_USER_2_t','');
define('_USER_2_u','0');
define('_USER_2_v','0');
define('_USER_2_w','0');
define('_USER_2_x','');
define('_USER_2_y','0');
define('_USER_2_aa','');
define('_USER_2_ab','');
define('_USER_2_ac','4096');
define('_USER_2_ad','0');
define('_USER_2_ae','0');
define('_USER_2_af','1');

define('_USER_REGDISABLED', 'Disculpa! El registro de nuevas cuentas de usuario est� actualmente deshabilitado.');
