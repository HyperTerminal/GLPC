<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Software Foundation
 * @link http://www.zikula.org
 * @version $Id: version.php 22138 2007-06-01 10:19:14Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_WORKFLOW_DISPLAYNAME','Workflow');
define('_WORKFLOW_DESCRIPTION','Provee un Motor de Workflows, y una interfaz para dise�ar y administrar workflows compuestos de acciones y eventos.');

