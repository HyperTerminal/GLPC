<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: version.php 18167 2006-03-16 01:49:56Z drak $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Admin_Messages
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_ADMINMESSAGES_ACTIVEONLY', 'S�lo mensajes activos');
define('_ADMINMESSAGES_SEARCH', 'Buscar en los mensajes del administrador');
