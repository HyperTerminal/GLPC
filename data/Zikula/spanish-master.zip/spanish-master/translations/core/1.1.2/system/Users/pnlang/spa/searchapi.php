<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: searchapi.php 22138 2007-06-01 10:19:14Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package     Zikula_System_Modules
 * @subpackage  Users
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_USERS_SEARCH', 'Usuarios registrados');
define('_USERS_SEARCHNOEXTRAINFOVIEWPROFILE', 'El usuario no ha insertado informaci�n extra. Dale click en el nombre de usuario para ver su perfil completo.');

