<?php
/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_CATDISP_ACTIVE',       'Activo');
define('_CATDISP_ACTIVITYSTATUS',   'Estados de actividad');
define('_CATDISP_APPROVED',         'Aprobado');
define('_CATDISP_ARTSENTERTAINMENT',    'Arte & Entretenimiento');
define('_CATDISP_CHECKED',      'Seleccionado');
define('_CATDISP_CUSTOMIZE',        'Necesitas personalizar esto!');
define('_CATDISP_DEFAULT',      'Predeterminada');
define('_CATDISP_DEFAULTENTRIES',   'Entradas por defecto');
define('_CATDISP_DEFAULTVALUE',     'Este es un valor por defecto');
define('_CATDISP_DR',           'Dr.');
define('_CATDISP_FEMALE',       'Femenino');
define('_CATDISP_GENDER',       'G�nero');
define('_CATDISP_GENERAL',      'General');
define('_CATDISP_GLOBAL',       'Global');
define('_CATDISP_INACTIVE',         'Inactivo');
define('_CATDISP_INFORMATIONTECHNOLOGY','Tecnolog�as de la Informaci�n');
define('_CATDISP_MAG',          'Mag.');
define('_CATDISP_MALE',         'Masculino');
define('_CATDISP_MODULES',      'M�dulos');
define('_CATDISP_ONLINE',       'En l�nea');
define('_CATDISP_OTHER',        'Otro');
define('_CATDISP_PENDING',      'Pendiente');
define('_CATDISP_PENDINGSTATUSBASIC',   'Estados pendientes b�sicos');
define('_CATDISP_PENDINGSTATUS',    'Estado pendiente');
define('_CATDISP_POLITICS',         'Pol�tica');
define('_CATDISP_PROF',         'Prof.');
define('_CATDISP_REJECTED',         'Rechazado');
define('_CATDISP_SCIENCE',      'Ciencia');
define('_CATDISP_SOCIETY',      'Sociedad');
define('_CATDISP_SPORTS',       'Deportes');
define('_CATDISP_TITLE',        'T�tulo');
define('_CATDISP_USERS',        'Usuarios');
define('_CATDISP_YESNO',        'Si/No');
