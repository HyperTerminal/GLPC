<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: login.php 22138 2007-06-01 10:19:14Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_BLOCKNEWUSERREG','Registrate!');
define('_BLOCKLOSTPWD', 'Recuperar contrase�a');
define('_BLOCKEMAIL','Correo electr�nico');
define('_BLOCKNICKNAME','Usuario');
define('_BLOCKPASSWORD','Contrase�a');
define('_BLOCKREMEMBERME','Recordarme');
