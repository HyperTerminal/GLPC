<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: linklist.php 22689 2007-09-16 17:33:18Z landseer $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Blocks
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_OTHEROPTIONS','Otras opciones');
define('_SUBMISSIONS','Envios');
define('_UDOWNLOADS','Descargas');
define('_WAITINGCONT', 'Contenido en espera');
define('_WLINKS','Enlaces en espera');
define('_WREVIEWS','An�lisis en espera');
