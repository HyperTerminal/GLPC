<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2004, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: thelang.php 22285 2007-06-27 16:48:48Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Blocks
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_SELECTGUILANG','Lenguaje preferido:');
define('_SELECTLANGUAGE', 'Selecciona un lenguaje');
define('_BLOCKS_THELANG_FORMAT', 'Formato');
define('_BLOCKS_THELANG_FLAGS', 'Mostrar banderas');
define('_BLOCKS_THELANG_DROPDOWN', 'Lista desplegable');
define('_BLOCKS_THELANG_LIST', 'Lista');
