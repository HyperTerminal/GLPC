<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2004, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: thelang.php 18585 2006-04-03 19:02:46Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Blocks
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_XSLT_DOCURL', 'URL del Documento');
define('_XSLT_DOCCONTENTS', 'Contenidos del Documento');
define('_XSLT_STYLESHEETURL', 'URL de Estilos');
define('_XSLT_STYLESHEETCONTENTS', 'Contenidos de los Estilos');
