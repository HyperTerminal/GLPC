<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: admin.php 21389 2007-02-15 16:52:10Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Mark West
 * @package      Zikula_System_Modules
 * @subpackage   legal
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_LEGAL', 'Condiciones Legales');
define('_LEGAL_ACCESSIBILITYSTATEMENT', 'Pol�tica de Accesibilidad');
define('_LEGAL_PRIVACYPOLICY', 'Pol�tica de Privacidad');
define('_LEGAL_TERMSOFUSE', 'T�rminos de Uso');
