<?php
/**
 * Zikula Application Framework
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: admin.php 22138 2007-06-01 10:19:14Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @author       Mark West
 * @package      Zikula_System_Modules
 * @subpackage   AuthPN
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_AUTHPN', 'Autenticaci�n Zikula');
define('_AUTHPN_HELP', 'Lista de m�dulos separados por comas');
define('_AUTHPN_MODULES', 'M�dulos de autenticaci�n');
