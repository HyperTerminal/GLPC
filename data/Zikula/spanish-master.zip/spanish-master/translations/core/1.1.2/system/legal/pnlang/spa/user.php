<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2004, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: user.php 22138 2007-06-01 10:19:14Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_LEGAL_ASNOTACTIVE', 'Pol�tica de Accesibilidad no activada');
define('_LEGAL_PPNOTACTIVE', 'Pol�tica de Privacidad no activada');
define('_LEGAL_TOUNOTACTIVE', 'T�rminos de Uso no activados');
