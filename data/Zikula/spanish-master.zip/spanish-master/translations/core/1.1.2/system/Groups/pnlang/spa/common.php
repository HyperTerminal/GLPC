<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2004, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: version.php 21484 2007-02-22 15:44:10Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Groups
 */

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_GROUPS', 'Grupos');
