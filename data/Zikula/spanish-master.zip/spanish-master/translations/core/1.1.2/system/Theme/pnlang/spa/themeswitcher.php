<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id: themeswitcher.php 22138 2007-06-01 10:19:14Z markwest $
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Theme
*/

/**
 * translated by
 * @author Mateo Tibaquira [mateo]
 */

define('_THEME_CHANGE','Cambiar Theme');
define('_THEME_FORMAT', 'Formato de salida');
define('_THEME_IMAGEDROPDOWN', 'Lista seleccionable con previsualizaciones');
define('_THEME_SIMPLELIST', 'Lista simple');
