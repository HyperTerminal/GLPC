<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_ACTIVECAT',          '%top% aktivste Kategorien');
define('_COMMENTEDSTORIES',   '%top% kommentierte Beitr�ge');
define('_DOWNLOADEDFILES',    '%top% h�ufigste Downloads');
define('_MOSTACTIVEAUTHORS',  '%top% aktivste Autoren:');
define('_NEWSPUBLISHED',      '%top% Beitr�ge ver�ffentlicht');
define('_NEWSSENT',           '%top% Beitr�ge eingereicht');
define('_NEWSSUBMITTERS',     '%top% aktivste Beitragsautoren');
define('_NOTITLE',            'Kein Titel');
define('_READREVIEWS',        '%top% meistgelesene Reviews');
define('_READS',              '%top% gelesen');
define('_READSECTION',        '%top% meistgelesene Sektions-Beitr�ge');
define('_READSTORIES',        '%top% meistgelesene News');
define('_TOPLISTVOTES',       '%top% Stimmen');
define('_TOPWELCOME',         'Willkommen bei der Top Liste');
define('_VOTEDPOLLS',         '%top% erfolgreichste Umfragen');
define('_TOPCOMMENTS',        '%top% Kommentare.'); 
define('_TOPDOWNLOADS',       '%top% Downloads.'); 

