<?php
/**
 * crpVideo
 *
 * @copyright (c) 2007-2008, Daniele Conca
 * @link http://code.zikula.org/projects/crpvideo Support and documentation
 * @author Daniele Conca <conca.daniele@gmail.com>
 * @license GNU/GPL - v.2.1
 * @package crpVideo
 *
 * @version $Id$
 * translation by Carsten Volmer (herr.vorragend) <carsten@zikula.org> 
 */

define('_CRPVIDEO_NAME',        'crpVideo');
define('_CRPVIDEO_DISPLAYNAME', 'Videos');
define('_CRPVIDEO_DESCRIPTION', 'Wiedergabe von Videos');
