<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

// menu
define('_REVIEWS_CONFIRMDELETE', 'Soll das Review wirklich gel�scht werden?');
define('_REVIEWS_CREATE', 'Review anlegen');
define('_REVIEWS_DELETE', 'Review l�schen');
define('_REVIEWS_MODIFY', 'Review bearbeiten');
define('_REVIEWS_VIEW', 'Reviews anzeigen');

// general
define('_REVIEWS_GENERAL', 'Allgemeine Einstellungen');
