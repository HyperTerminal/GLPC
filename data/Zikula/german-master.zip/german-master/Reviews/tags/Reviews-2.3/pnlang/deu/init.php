<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_REVIEWS_IMPORTEDNAME', 'Importierte Rezensionen');
define('_REVIEWS_IMPORTEDDESCRIPTION', 'importierte Rezensionen aus PostNuke .7x');
