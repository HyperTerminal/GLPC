<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

// module title
define('_REVIEWS', 'Reviews');

// singular/plural
define('_REVIEWS_REVIEW', 'Review');
define('_REVIEWS_REVIEWS', 'Reviews');
