<?php

     define('_THEMESWITCHER', 'Theme-Switcher');
     define('_THEMESWITCHER_ALLOWUSERSTOCHANGE', 'Benutzern Theme�nderung erlauben');

?>