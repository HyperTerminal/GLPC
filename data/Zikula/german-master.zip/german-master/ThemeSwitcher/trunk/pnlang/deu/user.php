<?php

     define('_THEMESWITCHER', 'Theme Switcher');
     define('_THEMESWITCHER_CURRENTTHEMEIS', 'Aktuelles Theme ist %t%.');
     define('_THEMESWITCHER_INSTRUCTIONS', 'Das ausgew�hlte Seitentheme wird (wenn eingeloggt) das gesamte Aussehen der Seite �ndern.');
     define('_THEMESWITCHER_OTHERTHEMES', 'Andere verf�gbare Themes sind');
     define('_THEMESWITCHER_PREVIEW', 'Themevorschau');
     define('_THEMESWITCHER_USE', 'Benutze Theme');
     define('_THEMESWITCHER_SELECTTHEME', 'W�hle Theme');
?>