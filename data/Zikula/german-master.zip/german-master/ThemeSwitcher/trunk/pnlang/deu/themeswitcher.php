<?php

     define('_THEMESWITCHER_CHANGE','Wechsle Theme');
     define('_THEMESWITCHER_FORMAT', 'Ausgabeformat');
     define('_THEMESWITCHER_IMAGEDROPDOWN', 'Dropdown mit Vorschaubildern');
     define('_THEMESWITCHER_SIMPLELIST', 'Einfache Liste');

?>