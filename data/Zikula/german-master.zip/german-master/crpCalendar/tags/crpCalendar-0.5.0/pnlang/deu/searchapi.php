<?php
/**
 * crpCalendar
 *
 * @copyright (c) 2007, Daniele Conca
 * @link http://code.zikula.org/crpCalendar Support and documentation
 * @version 0.2.0
 * @author Daniele Conca <jami at cremonapalloza dot org>
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package crpCalendar
 *
 * @version $Id$
 * translation by sven schomacker (hilope)
 */

define('_CRPCALENDAR_ARCHIVE', 'Archiv');
define('_CRPCALENDAR_EVENTS', 'Terminkalender');
define('_CRPCALENDAR_SEARCH', 'Terminkalendersuche');
define('_CRPCALENDAR_SEARCHRESULTS', 'Termine gefunden');
define('_CRPCALENDAR_SEACHNONEFOUND', 'Keine Termine gefunden');
