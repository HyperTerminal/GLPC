<?php
/**
 * crpCalendar
 *
 * @copyright (c) 2007, Daniele Conca
 * @link http://code.zikula.org/crpCalendar Support and documentation
 * @version 0.2.0
 * @author Daniele Conca <jami at cremonapalloza dot org>
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package crpCalendar
 *
 * @version $Id$
 * translation by sven schomacker (hilope)
 */

define('_CRPCALENDAR_NAME', 'crpCalendar');
define('_CRPCALENDAR_CATEGORY_DESCRIPTION', 'Hauptkategorie von crpCalendar');
define('_CRPCALENDAR_DISPLAYNAME', 'crpCalendar');
define('_CRPCALENDAR_DESCRIPTION', 'Einfacher Terminkalender');
