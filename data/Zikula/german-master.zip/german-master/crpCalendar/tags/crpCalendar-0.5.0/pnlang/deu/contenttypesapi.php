<?php
/**
 * crpCalendar
 *
 * @copyright (c) 2007, Daniele Conca
 * @link http://code.zikula.org/crpcalendar Support and documentation
 * @version $Id$
 * @author Daniele Conca <jami at cremonapalloza dot org>
 * @license GNU/GPL - v.2
 * @package crpCalendar
 *
 * @version $Id$
 * translation by sven schomacker (hilope)
 */

define('_CRPCALENDAR_CONTENTENTTYPE_EVENTTITLE','crpCalendar-Termin');
define('_CRPCALENDAR_CONTENTENTTYPE_EVENTDESCR','Bitte einen Termin aus crpCalendar zur Anzeige w�hlen');

define('_CRPCALENDAR_CONTENTENTTYPE_EVENTLABEL','Bitte einen Termin zur Anzeige w�hlen');
define('_CRPCALENDAR_CONTENTENTTYPE_NOEVENT','Kein Termin');
