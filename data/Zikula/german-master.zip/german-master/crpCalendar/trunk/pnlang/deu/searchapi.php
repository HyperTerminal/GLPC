<?php
/**
 * crpCalendar
 *
 * @copyright (c) 2007,2009 Daniele Conca
 * @link http://code.zikula.org/crpcalendar Support and documentation
 * @author Daniele Conca <conca.daniele@gmail.com>
 * @license GNU/GPL - v.2.1
 * @package crpCalendar
 *
 * @version $Id$
 * translation by sven schomacker (hilope), Carsten Volmer (herr.vorragend)
 */

define('_CRPCALENDAR_ARCHIVE', 'Archiv');
define('_CRPCALENDAR_EVENTS', 'Terminkalender');
define('_CRPCALENDAR_SEARCH', 'Terminkalendersuche');
define('_CRPCALENDAR_SEARCHRESULTS', 'Termine gefunden');
define('_CRPCALENDAR_SEACHNONEFOUND', 'Keine Termine gefunden');
