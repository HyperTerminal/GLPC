<?php
/**
 * crpCalendar
 *
 * @copyright (c) 2007,2009 Daniele Conca
 * @link http://code.zikula.org/crpcalendar Support and documentation
 * @author Daniele Conca <conca.daniele@gmail.com>
 * @license GNU/GPL - v.2.1
 * @package crpCalendar
 *
 * @version $Id$
 * translation by sven schomacker (hilope), Carsten Volmer (herr.vorragend)
 */

define('_CRPCALENDAR_NAME', 'crpCalendar');
define('_CRPCALENDAR_CATEGORY_DESCRIPTION', 'Hauptkategorie von crpCalendar');
define('_CRPCALENDAR_DISPLAYNAME', 'crpCalendar');
define('_CRPCALENDAR_DESCRIPTION', 'Ein komplexer Terminkalender mit Anbindung an die Module Formicula und Locations');
