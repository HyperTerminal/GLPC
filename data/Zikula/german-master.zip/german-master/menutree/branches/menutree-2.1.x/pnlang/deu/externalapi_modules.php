<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Pawel Preneta <jusuff@jabster.pl>
 * @link http://code.zikula.org/bianor/
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package menutree
 */

define('_MT_EXT_MODULES_NAME', 'Modul-Liste');
define('_MT_EXT_MODULES_SYNTAX', '{menutree:modules[:flat]}');
