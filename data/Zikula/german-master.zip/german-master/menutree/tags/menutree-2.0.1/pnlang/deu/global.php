<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Pawel Preneta <jusuff@jabster.pl>
 * @link http://code.zikula.org/bianor/
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package menutree
 */

define('_MENUTREE_DESC','Men�-Baum');

define('_MENUTREE_DISPLAYNAME', 'menutree');
define('_MENUTREE_DESCRIPTION', 'Modul f�r '._MENUTREE_DESC. ' Block');
