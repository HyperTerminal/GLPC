<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Pawel Preneta <jusuff@jabster.pl>
 * @link http://code.zikula.org/bianor/
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package menutree
 */

define('_MT_EXT_CONTENT_NAME', 'Content Seiten-Menü');
define('_MT_EXT_CONTENT_SYNTAX', 'menutree:content[:groupby=GROUPMODE&parent=PAGEID]');
