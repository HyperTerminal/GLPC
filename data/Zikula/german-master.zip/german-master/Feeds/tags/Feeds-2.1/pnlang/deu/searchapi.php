<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_FEEDS_SEARCH', 'Feeds');
define('_FEEDS_SEARCHRESULTS', 'gefunden');
define('_FEEDS_FROMFEED', 'vom Feed');
