<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_FEEDS_NUMITEMS', 'Anzahl der Feeds zum Anzeigen (bis zum bereitgestellten Maximum des Feeds oder -1 f�r alle Artikel)');
define('_FEEDS_FEEDID', 'Feed');
define('_FEEDS_DISPLAYIMAGE', 'Feed-Bild anzeigen (wenn im Feed vorhanden)');
define('_FEEDS_DISPLAYDESCRIPTION', 'Feed-Beschreibung anzeigen (wenn im Feed vorhanden)'); 
define('_FEEDS_ALTERNATELAYOUT', 'Alternatives Layout benutzen'); 