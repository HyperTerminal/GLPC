<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_FEEDS_INVALIDPROTOCOL', 'Falsches Protokoll - nur http und https sind m�glich.');
define('_FEEDS_URLTOOLONG', 'Die angegebene URL ist zu lang (max. 200 Zeichen).');
