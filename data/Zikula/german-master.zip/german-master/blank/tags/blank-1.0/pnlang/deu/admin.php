<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_BLANKMOD_ADMIN_TITLE',         'Blank Module Administration Titel');
define('_BLANKMOD_ADMIN_CONTENT',       'Blank Module Administration Inhalt');
define('_BLANKMOD_ADMIN_CONTENT_TITLE', 'Blank Module Inhalt Titel');

