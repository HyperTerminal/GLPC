<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2001, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_BLANK_NAME',               'blank');
define('_BLANK_DISPLAYNAME',        'Leermodul');
define('_BLANK_DESCRIPTION',        'Leermodul f�r das Zikula CMS');

