<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_PENDING_DISPLAYNAME', 'PendingContent');
define('_PENDING_DESCRIPTION', 'Anzeigen von ungepr�ften bzw. wartenden Inhalte');
