<?php
// $Id: admin.php,v 1.5 2005/06/25 18:31:25 clausparkhoi Exp $
// ------------------------------------------------------------------------------------
// Translation for PostNuke pgcalendar module
// Translation by: dmm 4 support.pn-cms.de
// ------------------------------------------------------------------------------------

define('_PGCNOAUTH', 'Sie haben keine Berechtigung diese Funktion zu nutzen!');
define('_PGCPGCALENDARSETUP', 'Pagesetter calendar setup');
define('_PGCID', 'Id');
define('_PGCNAME', 'Publication name');
define('_PGCALENDAR', 'Kalender');
define('_PGCMISSINGFIELD', 'Sie m�ssen die vorgeschriebenen Felder ausf�llen');
define('_PGCMODE', 'Mode');
define('_PGCMODEDBADTYPEOFDATE', 'Mode D verlangt ein Datums Feld');
define('_PGCMODEDDBADTYPEOFDATE', 'Mode D-D verlangt zwei Datums Felder');
define('_PGCMODEDTBADTYPEOFDATE', 'Mode DT verlangt ein Datums/Zeit Feld one date/time field');
define('_PGCMODEDTTBADTYPEOFDATE', 'Mode DT-T verlangt ein Datums/Zeit Feld und ein Zeit Feld');
define('_PGCSTARTFIELD', 'Event Startfeld');
define('_PGCENDFIELD', 'Event Endfeld');
define('_PGCTEXTFIELD', 'Event Beschreibungsfeld');
define('_PGCSUBMIT', 'senden');
define('_PGCSETUPHELP', 'Bitte markieren Sie Ihren Kalender Publication Typ(en)und w�hlen sie die Felder aus, welche vom System verwendet werden sollen.');
define('_PGCSETUPHELPMODED', 'das Datum des Events (ein Daten Feld).');
define('_PGCSETUPHELPMODEDD', 'Das Start- & Endfeld des Event`s (zwei Datenfelder).');
define('_PGCSETUPHELPMODEDT', 'das Datum und die Zeit des Event`s (ein Datums- / Zeitfeld).');
define('_PGCSETUPHELPMODEDTT', 'das Event start Datum & Zeit und die Endzeit(ein Datums-/Zeitfeld date/time field und ein Zeitfeld).');
define('_PGCSETUPHELPTEXTFLD', 'Ausserdem w�hlen Sie bitte das text/html Feld (falls vorhanden)welches die Beschreibung enth�lt.');
?>