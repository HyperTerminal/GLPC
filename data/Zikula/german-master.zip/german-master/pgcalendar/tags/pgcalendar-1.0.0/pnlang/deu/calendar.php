<?php
// $Id: calendar.php,v 1.2 2005/06/27 23:11:34 clausparkhoi Exp $
// ------------------------------------------------------------------------------------
// Translation for pgcalendar block.
// Translation by: dmm 4 support.pn-cms.de
// ------------------------------------------------------------------------------------

define('_BLOCKPUBTYPE', 'Publikationstyp');
define('_BLOCKFUNCTION', 'T�tigkeit');
define('_BLOCKSHOWCOUNT', 'Anzahl der Publikationen (oder Vorgabe, falls leer)');
define('_BLOCKTEMPLATE', 'Name des templates "format" f�r die Liste');
define('_BLOCKFILTER', 'Filter f�r die Liste; wie auch in der URL verwendet -- getrennt durch "&amp;", aber ohne "filter=" (z.B. "land:eq:DE")');
?>