<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @translation: Carsten Volmer (herr.vorragend) <carsten@zikula.org>
 */

define('_NEWS_SEARCH', 'Newsbeitr�ge Suche');
define('_NEWS_SEACHNONEFOUND', 'keine Newsbeitr�ge gefunden');
