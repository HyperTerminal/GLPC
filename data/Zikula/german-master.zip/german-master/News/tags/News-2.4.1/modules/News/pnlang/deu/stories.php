<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @translation: Carsten Volmer (herr.vorragend) <carsten@zikula.org>
 */

define('_STORIESDISPLAYALL', 'alle Beitr�ge anzeigen');
define('_STORIESDISPLAYFRONTPAGE', 'nur Titelseiten-Beitr�ge anzeigen');
define('_STORIESDISPLAYNONFRONTPAGE', 'nur nicht-Titelseiten-Beitr�ge anzeigen');
define('_STORIESMAXNUM', 'maximal anzuzeigende Beitr�ge');
define('_STORIESWHICHSTORIES', 'anzuzeigende Beitr�ge');
