<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @translation: Carsten Volmer (herr.vorragend) <carsten@zikula.org>
 */

define('_OLDERARTICLES', '�ltere Beitr�ge');
define('_PASTARTICLES', 'fr�here Beitr�ge');
define('_MAXNUMSTORIES', 'maximal anzuzeigende Beitr�ge');
