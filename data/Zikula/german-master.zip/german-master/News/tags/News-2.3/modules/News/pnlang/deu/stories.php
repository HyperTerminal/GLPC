<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_STORIESCATEGORY','Kategorie');
define('_STORIESDISPLAYALL','alle Beitr�ge anzeigen');
define('_STORIESDISPLAYFRONTPAGE','nur Titelseiten-Beitr�ge anzeigen');
define('_STORIESDISPLAYNONFRONTPAGE','nur nicht-Titelseiten-Beitr�ge anzeigen');
define('_STORIESMAXNUM','maximal anzuzeigende Beitr�ge');
define('_STORIESWHICHSTORIES', 'anzuzeigende Beitr�ge');
