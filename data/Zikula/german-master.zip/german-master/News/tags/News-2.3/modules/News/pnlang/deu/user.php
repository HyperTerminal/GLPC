<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

// user navigation
define('_NEWS_ARCHIVES', 'Archiv');
define('_NEWS_FRONTPAGE', 'Einleitungsseite');

// archives
define('_NEWS_ARCHIVESFORDATE', 'Archiv f�r %month% %year%');
define('_NEWS_POSTED', 'geschrieben am');
define('_NEWS_STORIESSSORTEDBYMONTH', 'Alle Beitr�ge, sortiert nach Monat');
define('_NEWS_VIEWS', 'gelesen');
