<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_OLDERARTICLES','�ltere Beitr�ge');
define('_PASTARTICLES','fr�here Beitr�ge');
define('_MAXNUMSTORIES', 'maximal anzuzeigende Beitr�ge');
