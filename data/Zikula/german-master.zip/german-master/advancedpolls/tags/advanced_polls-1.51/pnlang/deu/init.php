<?php
/**
 * Advanced Polls module for Zikula
 *
 * @author Mark West <mark@markwest.me.uk>
 * @copyright (C) 2002-2007 by Mark West
 * @link http://www.markwest.me.uk Advanced Polls Support Site
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_3rdParty_Modules
 * @subpackage Advanced_Polls
 *
 * @version $Id$
 * translation by Carsten Volmer (herr.vorragend) <carsten@zikula.org> 
 */

define('_ADVANCEDPOLLS_CATEGORY_DESCRIPTION', 'Umfragen');
