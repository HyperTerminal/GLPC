<?php
/**
 * German Translation for PostNuke Pagesetter module
 * 
 * @package Pagesetter module
 * @subpackage Languages
 * @version $Id: adminapi.php,v 1.2 2005/07/12 22:20:12 jornlind Exp $
 * @author Jorn Lind-Nielsen 
 * @author J�rg Napp 
 * @link http://www.elfisk.de The Pagesetter Home Page
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License
 */


?>
