<?php
/**
 * German Translation for PostNuke Pagesetter module
 * 
 * @package Pagesetter module
 * @subpackage Languages
 * @version $Id: integapi.php,v 1.2 2004/05/22 21:22:25 jornlind Exp $
 * @author Jorn Lind-Nielsen 
 * @author J�rg Napp 
 * @link http://www.elfisk.de The Pagesetter Home Page
 * @copyright Copyright (C) 2003
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License
 */

define('_PGXML_UNKNOWNTAG', 'Unerwarteter XML-Tag');
define('_PGXML_STATEERROR', 'Statusfehler');

?>
