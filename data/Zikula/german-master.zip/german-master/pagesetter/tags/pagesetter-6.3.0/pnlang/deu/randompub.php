<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Pagesetter module
// Translation by: Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------
require_once 'modules/pagesetter/pnlang/deu/common.php';

define('_PGRANPUBBLOCKEDITBLOCK', 'Der Block wurde noch nicht konfiguriert.');
define('_PGRANPUBBLOCKPUBTYPE', 'Publikationstyp');
define('_PGRANPUBBLOCKTEMPLATE', "Vorlage (z.B. 'block' f�r 'News-block.html')");

?>