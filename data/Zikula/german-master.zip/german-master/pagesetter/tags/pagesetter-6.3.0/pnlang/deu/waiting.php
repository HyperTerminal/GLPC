<?php
/**
 * German Translation for PostNuke Pagesetter module
 * 
 * @package Pagesetter module
 * @subpackage Languages
 * @version $Id: waiting.php,v 1.2 2004/05/22 21:22:25 jornlind Exp $
 * @author Jorn Lind-Nielsen 
 * @author J�rg Napp 
 * @link http://www.elfisk.de The Pagesetter Home Page
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License
 */

define('_PGBLOCKWAITINGMARKSTATES', 'Bitte w�hlen Sie den Workflow f�r die zur Ver�ffentlichung stehenden Publikationen:');

?>
