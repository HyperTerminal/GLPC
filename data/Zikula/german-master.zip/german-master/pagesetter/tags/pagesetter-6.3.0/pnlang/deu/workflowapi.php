<?php
/**
 * German Translation for PostNuke Pagesetter module
 * 
 * @package Pagesetter module
 * @subpackage Languages
 * @version $Id: workflowapi.php,v 1.2 2004/05/22 21:22:25 jornlind Exp $
 * @author Jorn Lind-Nielsen 
 * @author J�rg Napp 
 * @link http://www.elfisk.de The Pagesetter Home Page
 * @copyright Copyright (C) 2003
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License
 */

define('_PGWF_FILENOTREADABLE', 'Konnte die Workflow-Definitionsdatei nicht lesen: ');
define('_PGWF_STATEERROR1', 'Unerwarteter XML-Tag');
define('_PGWF_STATEERROR2', 'im Parser-Status');
define('_PGWF_UNKNOWNPERMISSION', 'Unbekannte Berechtigung');

?>
