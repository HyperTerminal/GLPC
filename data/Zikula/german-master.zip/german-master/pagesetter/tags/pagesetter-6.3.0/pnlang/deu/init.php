<?php
/**
 * German Translation for PostNuke Pagesetter module
 * 
 * @package Pagesetter module
 * @subpackage Languages
 * @version $Id: init.php,v 1.1 2004/02/13 21:47:25 jornlind Exp $
 * @author Jorn Lind-Nielsen 
 * @author J�rg Napp 
 * @link http://www.elfisk.de The Pagesetter Home Page
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License
 */

define('_CONFIRM', 'Ok');

?>
