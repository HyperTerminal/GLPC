<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Pagesetter module
// Translation by: Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------

define('_PGREL_SELECTFROM', 'W�hlen aus');
define('_PGREL_SELECTED', 'gew�hlt');
define('_PGREL_RELATIONSFOR', 'Relevante Eintr�ge ausw�hlen');
define('_PGREL_OK', 'OK');
define('_PGREL_CANCEL', 'Abbrechen');

?>