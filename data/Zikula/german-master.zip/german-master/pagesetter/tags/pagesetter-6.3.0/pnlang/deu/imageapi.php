<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Pagesetter module
// Translation by: Henning Hraban Ramm
// ------------------------------------------------------------------------------------

define('_PGUNKNOWNIMAGEFORMAT', 'Unbekanntes Bildformat');
define('_PGUNSUPPORTEDIMAGEFORMAT', 'Bildformat nicht unterst�tzt');

?>
