<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_REFERERS_DISPLAYNAME', 'HTTP-Referer');
define('_REFERERS_DESCRIPTION', 'Anzeige von HTTP-Referer Statistiken');

