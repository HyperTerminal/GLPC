<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_STATS_ERRORCREATINGHOOK', 'System-Init-Hook konnte nicht erstellt werden');
define('_STATS_ERRORDELETINGHOOK', 'System-Init-Hook konnte nicht gel�scht werden');
define('_STATS_HOOKHINT', 'Der System-Init-Hook von Stats wurde aktiviert. �nderungen k�nnen unter (Administration -> Module -> System-Hooks) durchgef�hrt werden, indem der Stats System-Hook f�r Zikula deaktiviert wird');
