<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_STATS_DISPLAYNAME', 'Stats');
define('_STATS_DESCRIPTION', 'Anzeige von Seitenstatistiken');

