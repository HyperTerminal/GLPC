<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_STATS', 'Seitenstatistik');
define('_STATSRESET', 'Zur�cksetzen');
define('_STATSEXCLUDEIP', 'auszuschlie�ende IP-Adressen');
define('_STATSCOLLECT', 'Statistik aktivieren');
define('_STATSRESETSTATS', 'Statistik zur�cksetzen');
define('_STATSRESETSITE', 'Haupt-Statistik zur�cksetzen');
define('_STATSRESETBROWSEROS', 'Browser- und Betriebsystem-Statistik zur�cksetzen');
define('_STATSRESETSUCCEDED', 'Statistiken zur�ckgesetzt');
define('_STATS24HOUR', '24-Stunden-Einteilung f�r st�ndliche Statistik');
