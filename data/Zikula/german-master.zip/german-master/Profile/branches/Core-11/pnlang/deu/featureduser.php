<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules
 * @subpackage Profile 
 */

// Ported from : i-Block [Featured User 1.5] - Alexander Graef aka MagicX - http://www.portalzine.de 

define('_PROFILE_FEATUREDUSER_BLOCKNAME', 'Besondere Benutzer');
define('_PROFILE_FEATUREDUSER_BLOCKDESC', 'Zeige besondere Benutzer');

define('_PROFILE_REGISTEREDONDATE', 'Registriert am %date%');
