<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2002, Zikula Development Team
 * @link http://www.zikula.org
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_System_Modules 
 * @subpackage Profile 
 */

// Ported from : i-Block [Members Online 2.5] - MagicX - Portalzine.de

define('_PROFILE_LASTXUSERS_BLOCKNAME', 'Letzte X registrierte Benutzer');
define('_PROFILE_LASTXUSERS_BLOCKDESC', 'Zeige die X neuesten Registrierungen');

define('_PROFILE_HOWMANYRECENTREGUSERS', 'Anzahl der \'neuesten registrierten Benutzer\'');
