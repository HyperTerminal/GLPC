<?php

define('_TOPICS_NAME', 'Topics');
define('_TOPICS_DISPLAYNAME', 'Topics');
define('_TOPICS_DESCRIPTION', 'Anzeige der Themen');
