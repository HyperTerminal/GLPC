<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_FAQ_CATEGORIES', 'FAQs');
define('_FAQ_SEARCH', 'FAQ Suche');
define('_FAQ_SEARCHRESULTS', 'FAQs gefunden');
define('_FAQ_SEACHNONEFOUND', 'Keine FAQs gefunden');
