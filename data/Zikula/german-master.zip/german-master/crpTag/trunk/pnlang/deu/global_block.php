<?php
/**
 * crpTag
 *
 * @copyright (c) 2008-2009 Daniele Conca
 * @link http://code.zikula.org/crptag Support and documentation
 * @author Daniele Conca <conca.daniele@gmail.com>
 * @license GNU/GPL - v.2.1
 * @package crpTag
 *
 * @version $Id$
 * translation by Carsten Volmer (herr.vorragend) <carsten@zikula.org>
 */

define('_CRPTAG_TAGS','Komplette Tag-Liste');
define('_CRPTAG_SHOW_COUNTER','Tag-Z�hler anzeigen');
define('_CRPTAG_INTERVAL','Zuletzt aktualisiert: Tage');
define('_CRPTAGS_BLOCK_NO_TAGS','Keine neuen Tags: Tage');