<?php
/**
 * crpTag
 *
 * @copyright (c) 2008-2009 Daniele Conca
 * @link http://code.zikula.org/crptag Support and documentation
 * @author Daniele Conca <conca.daniele@gmail.com>
 * @license GNU/GPL - v.2.1
 * @package crpTag
 *
 * @version $Id$
 * translation by Carsten Volmer (herr.vorragend) <carsten@zikula.org>
 */

define('_CRPTAG_SECTIONS', 'Tags');
define('_CRPTAG_SEARCH', 'Tags-Suche');
define('_CRPTAG_SEARCHRESULTS', 'Gefundene Tags');
define('_CRPTAG_SEARCHNOONEFOUND', 'keine Tags gefunden');
