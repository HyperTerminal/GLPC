<?php
/**
 * crpTag
 *
 * @copyright (c) 2008-2009 Daniele Conca
 * @link http://code.zikula.org/crptag Support and documentation
 * @author Daniele Conca <conca.daniele@gmail.com>
 * @license GNU/GPL - v.2.1
 * @package crpTag
 *
 * @version $Id$
 * translation by Carsten Volmer (herr.vorragend) <carsten@zikula.org>
 */

Loader :: includeOnce('modules/crpTag/pnlang/deu/global_block.php');
