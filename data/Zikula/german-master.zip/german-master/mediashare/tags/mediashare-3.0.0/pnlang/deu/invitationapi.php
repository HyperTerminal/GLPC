<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Thomas Smiatek
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/invitation.php');


?>