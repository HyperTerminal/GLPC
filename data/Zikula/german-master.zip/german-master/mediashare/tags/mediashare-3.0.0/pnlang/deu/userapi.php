<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Daniel Neugebauer
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/common.php');

define('_MSSEARCHNONEFOUND', 'Mediashare: Suche erfolglos');
define('_MSSEARCHRESULTS', 'Objekt(e) gefunden');
define('_MSSEARCHTITLE', 'Mediashare');

?>