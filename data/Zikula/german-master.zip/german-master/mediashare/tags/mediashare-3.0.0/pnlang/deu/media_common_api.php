<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Daniel Neugebauer
// ------------------------------------------------------------------------------------

define('_MSINSFULLITEM', 'Original');
define('_MSINSPREVIEW', 'Vorschau');
define('_MSINSTHUMBNAIL', 'Thumbnail');
define('_MSINSTHUMBNAILPOPUP', 'Thumbnail (Popup)');
define('_MSINSFULLITEMURL', 'Link zum Original');
define('_MSINSFULLITEMURLPOPUP', 'Link zum Original (Popup)');
define('_MSINSALBUMURL', 'Album-Link');
define('_MSINSALBUMURLTHUMBNAIL', 'Album-Link als Thumbnail');
define('_MSINSALBUMURLPOPUP', 'Album-Link (Popup)');
define('_MSINSALBUMURLTHUMBNAILPOPUP', 'Album-Link als Thumbnail (Popup)');

define('_MSUNKNOWNITEMFORMAT', 'Unbekanntes Medienformat');

?>