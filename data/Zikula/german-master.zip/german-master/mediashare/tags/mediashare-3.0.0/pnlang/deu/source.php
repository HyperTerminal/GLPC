<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Thomas Smiatek
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/common.php');

define('_MSVIDEOWIDTHHEIGHTHELP', 'Nur f�r Videoformate notwendig');

?>