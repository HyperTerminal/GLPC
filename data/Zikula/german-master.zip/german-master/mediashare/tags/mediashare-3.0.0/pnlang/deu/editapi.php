<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Daniel Neugebauer
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/common.php');

define('_MSADDEDMEDIAITEM', 'Medienobjekt hinzugef�gt');
define('_MSEVERYBODY', 'Jeder');
define('_MSMEDIAITEMTOOBIG', 'Datei zu gro�');
define('_MSMEDIAITEMEXEEDQUOTA', 'Medienobjekt zu gro� - Gesamt-Speicherplatz w�rde �berschritten');
define('_MSTOPDESCRIPTION', 'Dies ist das Top-Album (von dem es nur eins geben kann). Sie k�nnen den Titel und andere Eigenschaften ver�ndern.');

?>