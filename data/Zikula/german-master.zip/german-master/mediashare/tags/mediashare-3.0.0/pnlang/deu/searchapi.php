<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Thomas Smiatek
// ------------------------------------------------------------------------------------

define('_MSSEARCH', 'Medien-Dateien');
define('_MSMEDIAINALBUM', 'Medien-Datei in Album: ');
