<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Thomas Smiatek
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/source.php');

define('_MSADDMEDIAINFO', '<p>Hier k�nnen Zip-Dateien �ber den Browser hochgeladen werden.</p><p>Sie k�nnen bis zu %uploadsize% kbytes pro Datei hochladen. Diese Upload-Beschr�nkungen k�nnen durch eine Limitierung des Gesamt-Speicherplatzes weiter eingeschr�nkt sein.</p><p>Sie werden auf der n�chsten Seite dazu aufgefordert, Beschreibungen, Schl�sselworte etc. zu den Objekten einzuf�gen.</p>');

?>