<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Daniel Neugebauer
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/common.php');

define('_MSBACK', 'Zur�ck');
define('_MSMEDIASHAREFINDITEM', 'Mediashare - Objekt suchen');
define('_MSSELECTFORMAT', 'Format w�hlen');
define('_MSSELECTITEM', 'Objekt w�hlen');
define('_MSSELECT', 'W�hlen');

?>