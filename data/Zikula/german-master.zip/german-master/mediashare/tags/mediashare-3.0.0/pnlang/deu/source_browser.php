<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Daniel Neugebauer
// ------------------------------------------------------------------------------------

define('_MSADDMEDIAINFO', '<p>Hier k�nnen Medienobjekte �ber den Browser hochgeladen werden.</p><p>Sie k�nnen bis zu %postsize% kbytes auf einmal hochladen, wobei keine Datei gr��er als %uploadsize% kbytes sein darf. Diese Upload-Beschr�nkungen k�nnen durch eine Limitierung des Gesamt-Speicherplatzes weiter eingeschr�nkt sein.</p><p>Sie werden auf der n�chsten Seite dazu aufgefordert, Beschreibungen, Schl�sselworte etc. zu den Objekten einzuf�gen.</p>');

?>
