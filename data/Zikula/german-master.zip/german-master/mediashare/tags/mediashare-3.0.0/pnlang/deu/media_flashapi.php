<?php
// ------------------------------------------------------------------------------------
// Translation for PostNuke Mediashare module
// Translation by: Daniel Neugebauer
// ------------------------------------------------------------------------------------

require_once('modules/mediashare/pnlang/deu/media_common_api.php');

?>