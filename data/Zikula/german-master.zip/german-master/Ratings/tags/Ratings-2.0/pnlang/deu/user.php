<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_RATING','Rating');
define('_RATING_BETHEFIRST', 'Bislang noch keine Bewertung erfolgt');
define('_RATETHISITEM','Diesen Artikel bewerten');
if (!defined('_THANKYOUFORRATING')) {
    define('_THANKYOUFORRATING', 'Danke f�r die Bewertung');
}
define('_RATING_RECORDING', 'Bewertung wird gespeichert');
