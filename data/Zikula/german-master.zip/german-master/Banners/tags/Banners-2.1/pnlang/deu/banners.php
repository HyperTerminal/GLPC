<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_BANNERSBLOCK_BTYPE','Eigene Banner-ID');
define('_BANNERSBLOCK_DEFINE',' (0,1,2) sind reserviert f�r Default-Banner. Bitte gr��ere Zahlen benutzen!');

