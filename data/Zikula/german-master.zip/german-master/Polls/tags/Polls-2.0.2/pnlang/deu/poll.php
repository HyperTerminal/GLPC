<?php
/**
 * Polls Module for Zikula
 *
 * @copyright (c) 2004, Zikula Development Team
 * @link http://www.markwest.me.uk
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 * @package Zikula_3rdParty_Modules
 * @subpackage Polls
 *
 * @version $Id$
 * translation by Carsten Volmer (herr.vorragend) <carsten@zikula.org>  
 */

define('_POLLS_DISPLAY', 'anzuzeigene Umfrage');
define('_POLLS_AJAXVOTING', 'Ajax f�r die Umfrage benutzen');
