<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare template
// Language:              Danish
// Translation by:        Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------
define('_PTMP_BOOK_TITLE', 'Buch');
define('_PTMP_BOOK_BUTTONNEXTIMG', 'N�chstes Bild');
define('_PTMP_BOOK_BUTTONPREVIMG', 'Vorheriges Bild');
define('_PTMP_BOOK_EMPTYALBUM', 'Kein Bild in diesem Album');


?>