<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare template
// Language:              German
// Translation by:        Aurelio Caliaro
// ------------------------------------------------------------------------------------
define('_PTMP_SLIDESHOW_TITLE', 'Slideshow');
define('_PTMP_SLIDESHOW_PAUSE', 'Pause');
define('_PTMP_SLIDESHOW_START', 'Start');
define('_PTMP_SLIDESHOW_BUTTONNEXTIMG', 'N�chstes Bild');
define('_PTMP_SLIDESHOW_BUTTONSTOP', 'Stop');
define('_PTMP_SLIDESHOW_BUTTONPLAY', 'Start');
define('_PTMP_SLIDESHOW_BUTTONPREVIMG', 'Vorheriges Bild');
define('_PTMP_SLIDESHOW_BUTTONTHUMBNAILS', 'Thumbnails');
define('_PTMP_SLIDESHOW_SLIDESHOWTIME', 'Anzeigezeit:');
define('_PTMP_SLIDESHOW_EMPTYALBUM', 'Album ist leer');
define('_PTMP_SLIDESHOW_SEC', 'Sek.');
?>