<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare template
// Language:              Deutsch
// Translation by:        Aurelio Caliaro
// ------------------------------------------------------------------------------------
define('_PTMP_THUMBNAILS_CLICKTOENLARGE', 'Clicke, um ganzes Bild zu sehen.');
define('_PTMP_THUMBNAILS_EMPTYALBUM', 'Dieses Album enth�lt keine weiteren Bilder.');
define('_PTMP_THUMBNAILS_TITLE', 'Thumbnails');
?>