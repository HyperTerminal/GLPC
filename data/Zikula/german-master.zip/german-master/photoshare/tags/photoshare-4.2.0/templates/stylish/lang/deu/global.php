<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare template
// Language:              English
// Translation by:        Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------
define('_PTMP_STYLISH_TITLE', 'Stylish');
define('_PTMP_STYLISH_PREVIOUS', 'Vorheriges');
define('_PTMP_STYLISH_NEXT', 'N�chstes');


?>