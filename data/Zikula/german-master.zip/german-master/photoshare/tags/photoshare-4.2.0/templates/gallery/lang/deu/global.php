<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare 'Gallery' template
// Language:              Danish
// Translation by:        Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------
define('_PTMP_GALLERY_TITLE', 'Gallerie');
define('_PTMP_GALLERY_EMPTYALBUM', 'Gallerie ist leer');
?>