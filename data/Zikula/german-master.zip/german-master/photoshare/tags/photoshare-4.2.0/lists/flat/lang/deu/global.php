<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare folder list
// Language:              German
// Translation by:        Aurelio Caliaro
// ------------------------------------------------------------------------------------
define('_PSLIST_BY', 'von');
define('_PSLIST_ITEMS', 'Bilder');
define('_PSLIST_BYDATE', 'Erstellungsdatum');
define('_PSLIST_VIEWFOLDER',  'Zeige Album');
?>