<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare folder list
// Language:              German
// Translation by:        Aurelio Caliaro
// ------------------------------------------------------------------------------------
define('_PSLIST_IMAGES', 'Bilder');
define('_PSLIST_SUBFOLDERS', 'Unteralben');
define('_PSLIST_BY', 'von');
define('_PSLIST_ITEMS', 'Bilder');
define('_PSLIST_BYDATE', 'Erstellungsdatum');
define('_PSLIST_CLICKTOVIEW', 'Klicken, um Album anzusehen');
define('_PSLIST_FOLDERS', 'Unterverzeichnisse');
?>