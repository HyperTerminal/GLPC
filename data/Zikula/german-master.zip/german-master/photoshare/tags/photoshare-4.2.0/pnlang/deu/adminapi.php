<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare PostNuke Module
// Language:              English
// Translation by:        Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------
?>