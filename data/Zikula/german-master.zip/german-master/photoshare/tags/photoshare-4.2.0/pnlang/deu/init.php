<?php
// ------------------------------------------------------------------------------------
// Translation for Photoshare PostNuke Module
// Language:              English
// Translation by:        Jorn Lind-Nielsen
// ------------------------------------------------------------------------------------
define('_PSCREATETABLEFAILED', 'konnte Datenbankverkn�pfung nicht erzeugen');
define('_PSNOGDEXTENSION', 'Ihr Server hat leider die "GD" Bibliothek nicht intalliert, daher kann Photoshare nicht installiert werden. Bitte kontaktieren Sie Ihren Web Administrator um GD zu installieren.');
define('_PSSETMODVARFAILED', 'pnSetModVar() fehlgeschlagen f�r');
define('_PSWHILEEXECUTING', 'w�hrend');
?>