<?php 
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_PAGES_LISTBLOCK', 'Seitenliste anzeigen');
define('_PAGES_NUMITEMS', 'Anzahl der anzuzeigenden Seiten in der Liste');