<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_PAGES_SECTIONS', 'Seiten');
define('_PAGES_SEARCH', 'Suche in den Seiten');
define('_PAGES_SEARCHRESULTS', 'Seiten gefunden');
define('_PAGES_SEACHNONEFOUND', 'Keine Seiten gefunden');
