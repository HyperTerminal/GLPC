<?php
/**
 * Zikula Application Framework
 *
 * @copyright (c) 2008, Zikula German Translation Team
 * @link http://www.zikula.de
 * @version $Id$
 * @license GNU/GPL - http://www.gnu.org/copyleft/gpl.html
 */

define('_PAGES_CATEGORY_DESCRIPTION', 'Zeigt statische Seiten sortiert nach Kategorien an');
