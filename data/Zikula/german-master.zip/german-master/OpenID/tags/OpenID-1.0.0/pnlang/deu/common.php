<?php
/**
 * OpenID for PostNuke
 *
 * @copyright (C) 2008, OpenID PostNuke Development Team
 * @link http://code.zikula.org/openid/
 * @version $Id$
 * @translator sven schomacker (hilope)
 * @license LGLP - see license.txt
**/