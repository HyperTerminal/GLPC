<?php
/**
 * CoType
 *
 * @copyright (C) 2007, Jorn Wildt
 * @link http://www.elfisk.dk
 * @version $Id: searchapi.php,v 1.2 2007/03/05 22:18:58 jornlind Exp $
 * @license See license.txt
 */

define('_COTYPE_SEARCH', 'CoType Dokumente');

?>