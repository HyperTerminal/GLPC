<?php
/**
 * CoType
 *
 * @copyright (C) 2007, Jorn Wildt
 * @link http://www.elfisk.dk
 * @version $Id: ajax.php,v 1.1 2007/04/02 22:20:28 jornlind Exp $
 * @license See license.txt
 */

define('_COTYPE_BOXCUTOK', 'Die Box wurde in der Zwischenablage gespeichert');

?>