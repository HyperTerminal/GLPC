<?php
/**
 * CoType
 *
 * @copyright (C) 2007, Jorn Wildt
 * @link http://www.elfisk.dk
 * @version $Id: boxapi.php,v 1.1 2007/03/20 22:27:57 jornlind Exp $
 * @license See license.txt
 */

require_once 'modules/cotype/pnlang/deu/box.php';


?>