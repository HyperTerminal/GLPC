### Language packs

If you want to help translate ElkArte to your language, there are two ways:
* clone this repository and work on it with the usual git/github workflow
* download the language packages, work on them and attach the result to a post at our community http://www.elkarte.net/
 
If the language pack doesn't exist yet, feel free to create it by yourself or ask for it to be created opening an [issue](https://github.com/elkarte/languages/issues) or posting at [our site](http://www.elkarte.net/).


### Downloads

https://github.com/elkarte/languages/releases

