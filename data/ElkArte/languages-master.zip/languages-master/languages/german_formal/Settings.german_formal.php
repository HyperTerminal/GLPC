<?php
// Version: 1.0; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.png';
$txt['theme_description'] = 'Das Standard-ElkArte-Theme.<br /><br />Autoren: ElkArte-Mitwirkende';
