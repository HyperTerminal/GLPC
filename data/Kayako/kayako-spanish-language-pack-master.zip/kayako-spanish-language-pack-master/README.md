Spanish Langauge Pack for Kayako
================================
This is Spanish language pack for Kayako Helpdesk version 4.64

You can import this language pack from Kayako's Administration Panel