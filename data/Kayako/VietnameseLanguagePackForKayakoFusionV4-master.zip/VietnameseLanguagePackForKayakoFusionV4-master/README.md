Vietnamese Language Pack For Kayako Fusion V4
=============================================

Vietnamese Language Pack for Kayako Fusion v4<br/>

I have translated the Kayako Fusion Language Pack into Vietnamese for my company need.<br/>

You are free to use it; however, do not forget to include VinaMarket.COM in your file as credit.<br/>

Thank you.<br/>
T. Q. Hoai<br/>
VinaMarket.COM (비나마켓)
