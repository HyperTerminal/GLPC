README
======

What is this Repository
-----------------------

This repository contains every language pack that I need to implement Kayako 
Fusion in my Corp.

Requirements
------------

Kayako Fusion V4

Installation
------------

Get these files and import them into your Kayako installation.

