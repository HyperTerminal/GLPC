<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("UC_LAN_0", "همه (عمومی)");
define("UC_LAN_1", "فقط مهمانان");
define("UC_LAN_2", "هیچ کس (غیر فعال)");
define("UC_LAN_3", "فقط اعضا");
define("UC_LAN_4", "فقط خواندنی");
define("UC_LAN_5", "فقط مدیر");
define("UC_LAN_6", "مدیریت کل");
define('UC_LAN_9','کاربران جدید');
define('UC_LAN_10', 'موتور های جستجو');
?>