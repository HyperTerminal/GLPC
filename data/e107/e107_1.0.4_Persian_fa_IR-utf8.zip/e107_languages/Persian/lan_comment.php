<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - COMLANguage File.
|     Translated By Persian E107 Support : E107.IR  ( Hamed Agharezae )
|     $Source: /cvsroot/e107/e107_0.7/e107_COMLANguages/English/COMLAN_comment.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "نظرات");
define("COMLAN_0", "[برگشت خورده توسط مدیر]");
define("COMLAN_1", "عدم برگشت");
define("COMLAN_2", "برگشت زدن");
define("COMLAN_3", "حذف");
define("COMLAN_4", "اطلاعات");
define("COMLAN_5", "نظرات...");
define("COMLAN_6", "شما باید برای ارسال در سایت به سیستم وارد شوید یا اگر عضو نیستید ثبت نام کنید");
define("COMLAN_7", "مدیریت کل سایت");
define("COMLAN_8", "نظر");
define("COMLAN_9", "ارسال نظر");
define("COMLAN_10", "مدیریت کل");
define("COMLAN_11", "قابل ارسال نیست-دوباره بنویسید و حروف غیر استاندارد استفاده نکنید.");
define('COMLAN_12', 'کاربر');
define("COMLAN_16", "نام کاربری: ");
define("COMLAN_99", "نظرات");
define("COMLAN_100", "اخبار");
define("COMLAN_101", "نظرسنجی");
define("COMLAN_102", "پاسخ گویی به: ");
define("COMLAN_103", "مقاله");
define("COMLAN_104", "نقد");
define("COMLAN_105", "محتوا");
define("COMLAN_106", "دانلود");
define("COMLAN_145", "ثبت نام شده: ");
define("COMLAN_194", "مهمان");
define("COMLAN_195", "کاربر ثبت نام شده");
define("COMLAN_310", "قابل ارسال نیست-این نام کاربری قبلا ثبت نام کرده است. اگر نام کاربری شماست به سیستم وارد شوید.");
define("COMLAN_312", "ارسال تکراری- قابل قبول نیست.");
define("COMLAN_313", "ماکن");
define("COMLAN_314", "مدیریت نظرات");
define("COMLAN_315", "پیگیری ها");
define("COMLAN_316", "پیگردی برای این موضوع وجود ندارد.");
define("COMLAN_317", "مدیریت پیگیری ها");
define("COMLAN_318", "ویرایش نظرات");
define("COMLAN_319", "ویرایش شد.");
define("COMLAN_320", "به روز رسانی نظرات");
define("COMLAN_321", "اینجا");
define("COMLAN_322", "براي ثبت نام كليك كنيد");
define("COMLAN_323", "خطا !");
define("COMLAN_324", 'موضوع');
define("COMLAN_325", 'پاسخ:');
define("COMLAN_326", 'پاسخ به این ');
define("COMLAN_327", 'امتیاز');
define("COMLAN_328", 'نظرات غیر فعال هستند');
define("COMLAN_329", 'اجازه داده نشده است');
define("COMLAN_330", 'IP:');
define("COMLAN_331", "در انتظار تایید");
define("COMLAN_TYPE_1", "اخبار");
define("COMLAN_TYPE_2", "دانلود");
define("COMLAN_TYPE_3", "پرسش و پاسخ همیشگی");
define("COMLAN_TYPE_4", "نظرسنجی");
define("COMLAN_TYPE_5", "اسناد");
define("COMLAN_TYPE_6", "مشکلات سیستم");
define("COMLAN_TYPE_7", "نظرات");
define("COMLAN_TYPE_8", "مشخصات کاربران");
define("COMLAN_TYPE_PAGE", "محتوا");		// Reall custom page, but use a 'non-technical' description



?>