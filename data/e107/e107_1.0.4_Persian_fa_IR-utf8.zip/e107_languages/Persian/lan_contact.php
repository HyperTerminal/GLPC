<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     Translated By Persian E107 Support : E107.IR  ( Hamed Agharezae )
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define('PAGE_NAME',     'تماس با ما');
define("LANCONTACT_01", "اطلاعات تماس");
define("LANCONTACT_02", "فرم تماس");
define("LANCONTACT_03", "نام خود را وارد کنید:");
define("LANCONTACT_04", "آدرس پست الکترونیک:");
define("LANCONTACT_05", "موضوع پیام:");
define("LANCONTACT_06", "متن پیام:");
define("LANCONTACT_07", "ارسال یک کپی به صندوق پست الکترونیک خودتان ؟ ");
define("LANCONTACT_08", "ارسال");
define("LANCONTACT_09", "با تشکر از شما , پیام شما ارسال شد.");
define("LANCONTACT_10", "در هنگام ارسال پیام خطایی رخ داده است.");
define("LANCONTACT_11", "به نظر آدرس پست الکترونیک شما صحیح وارد نشده است.\\nبررسی کنید و دوباره سعی کند.");
define("LANCONTACT_12", "پیام شما بیش از حد کوتاه است.");
define("LANCONTACT_13", "عنوان پیام خود را وارد کنید."); 
define("LANCONTACT_14", "ارسال پیام برای:");
define("LANCONTACT_15", "کد نمایشی اشتباه وارد شده است");
define("LANCONTACT_16", "کد نمایشی را وارد کنید");







?>