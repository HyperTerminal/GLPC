<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("TOP_LAN_0", "فعالترین عضو های انجمن");
define("TOP_LAN_1", "نام کاربری");
define("TOP_LAN_2", "تعداد ارسال ها");
define("TOP_LAN_3", "فعالترین کاربران در ارسال نظر");
define("TOP_LAN_4", "تعداد نظرات");
define("TOP_LAN_5", "فعالترین کاربران در ارسال به جعبه گفتگو");
define("TOP_LAN_6", "رتبه در سایت");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
//v.616
define("LAN_1", "موضوع");
define("LAN_2", "نویسنده");
define("LAN_3", "بازدید");
define("LAN_4", "تعداد پاسخ");
define("LAN_5", "آخرین ارسال");
define("LAN_6", "موضوعات");
define("LAN_7", "فعالترین موضوعات انجمن");
define("LAN_8", "فعالترین عضو های انجمن");


?>