<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("PAGE_NAME", ".این سایت فعلا تعطیل است بعدا مراجعه کنید ");
define("LAN_SITEDOWN_00", ".فعلا تعطیل است بعدا مراجعه کنید");
define("LAN_SITEDOWN_01", "سایت ما برای انجام بعضی از تغییرات فعلا تعطیل است و به زودی راه اندازی میشود لطفا بعدا مراجعه کنید");
?>