<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 11:45:50 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "امتیاز");
define("RATELAN_1", "رای");
define("RATELAN_2", "شما به این قسمت چه امتیازی میدهید ؟");
define("RATELAN_3", "با تشکر از امتیاز شما");
define("RATELAN_4", "امتیاز داده نشده");
define("RATELAN_5", "امتیاز دادن");

?>