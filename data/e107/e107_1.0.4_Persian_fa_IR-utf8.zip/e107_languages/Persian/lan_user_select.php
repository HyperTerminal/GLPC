<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "انتخاب کاربر");
define("US_LAN_2", "انتخاب رتبه کاربر");
define("US_LAN_3", "تمام کاربران");
define("US_LAN_4", "جستجوی نام کاربری");
define("US_LAN_5", "کاربر پیدا شد");
define("US_LAN_6", "جستجو");
?>