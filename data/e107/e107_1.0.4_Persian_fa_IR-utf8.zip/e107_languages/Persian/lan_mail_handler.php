<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "تولید شده توسط سیستم مدیریت محتوای e107 فارسی");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LANMAILH_2", "پیغام چند منظوره");
define("LANMAILH_3", " به درستی قالب بندی نشده است");
define("LANMAILH_4", "سرور آدرس را نپذیرفت");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LANMAILH_5", "جوابی از سرور دریافت نشد");
define("LANMAILH_6", "سرور پست الکترونیک پیدا نشد.");
define("LANMAILH_7", " صحیح است.");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 


?>