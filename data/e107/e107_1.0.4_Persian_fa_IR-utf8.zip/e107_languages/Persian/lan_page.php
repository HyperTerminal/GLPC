<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_parser_functions.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LAN_PAGE_1", "لیست صفحات غیر فعال است");
define("LAN_PAGE_2", "صفحه ای وجود ندارد");
define("LAN_PAGE_3", "صفحه مورد نظر وجود ندارد");
define("LAN_PAGE_4", "امتیاز به این صفحه");
define("LAN_PAGE_5", "با تشکر از شما برای امتیاز دادن به این صفحه");
define("LAN_PAGE_6", "شما اجازه مشاهده این صفحه را ندارید");
define("LAN_PAGE_7", "کلمه عبور اشتباه");
define("LAN_PAGE_8", "صفحه حفاظت شده توسط کلمه عبور");
define("LAN_PAGE_9", "کلمه عبور");
define("LAN_PAGE_10", "ورود");
define("LAN_PAGE_11", "لیست صفحات");
define("LAN_PAGE_12", "صفحه نا معتبر");
define("LAN_PAGE_13", "صفحه");

?>