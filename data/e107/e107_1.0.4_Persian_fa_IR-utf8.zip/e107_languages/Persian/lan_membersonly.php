<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "فقط مخصوص کاربران ثبت نام شده");

//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LAN_MEMBERS_0", "محیط دارای محدودیت دسترسی");
define("LAN_MEMBERS_1", "این محیط دارای محدودیت دسترسی است");
define("LAN_MEMBERS_2","برای دسترسی به این محیط <a href='".e_LOGIN."'>وارد سایت</a>شوید.");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LAN_MEMBERS_3","یا <a href='".e_SIGNUP."'>ثبت نام</a> کنید");
define("LAN_MEMBERS_4","برای بازگشت به صفحه اصلی اینجا کلیک کنید");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 


?>