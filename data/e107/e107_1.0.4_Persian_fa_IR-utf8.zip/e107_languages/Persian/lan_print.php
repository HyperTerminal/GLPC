<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/LAN_PRINTprint.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: mrpete $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "نسخه قابل چاپ"); }

//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LAN_PRINT_86", "شاخه:");
define("LAN_PRINT_87", "توسط ");
define("LAN_PRINT_94", "ارسال شده توسط");
define("LAN_PRINT_135", "عنوان خبر");
define("LAN_PRINT_303", "این خبر از طرف ");
define("LAN_PRINT_304", "عنوان مقاله: ");
define("LAN_PRINT_305", "عنوان فرعی مقاله: ");
define("LAN_PRINT_306", "این مقاله از طرف ");
define("LAN_PRINT_307", "چاپ این صفحه");
define("LAN_PRINT_1", " نسخه مناسب برای چاپ");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 

?>