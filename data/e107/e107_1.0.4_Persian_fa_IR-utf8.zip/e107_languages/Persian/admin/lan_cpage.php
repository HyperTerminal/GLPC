<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/22 17:08:01 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "عنوان");
define("CUSLAN_2", "نوع");
define("CUSLAN_3", "تنظیمات");
define("CUSLAN_4", "حذف این صفحه ؟");
define("CUSLAN_5", "صفحات موجود ");
define("CUSLAN_7", "نام منو");
define("CUSLAN_8", "عنوان / برچسب");
define("CUSLAN_9", "متن");
define("CUSLAN_10", "اجازه برای امتیاز دادن");
define("CUSLAN_11", "صفحه اصلی");
define("CUSLAN_12", "ایجاد صفحه");
define("CUSLAN_13", "فعال بودن نظرات");
define("CUSLAN_14", "صفحه محافظت شده توسط کلمه عبور");
define("CUSLAN_15", "کلمه عبور را برای محافظت صفحه وارد کنید");
define("CUSLAN_16", "ایجاد لینک در منوی اصلی");
define("CUSLAN_17", "نام لینک را برای ایجاد وارد کنید");
define("CUSLAN_18", "صفحه / قابل نمایش برای");
define("CUSLAN_19", "به روز رسانی صفحه");
define("CUSLAN_20", "ایجاد صفحه");
define("CUSLAN_21", "به روز رسانی منو");
define("CUSLAN_22", "ایجاد منو");
define("CUSLAN_23", "ویرایش صفحه");
define("CUSLAN_24", "ایجاد صفحه جدید");
define("CUSLAN_25", "ویرایش منو");
define("CUSLAN_26", "ایجاد منوی جدید");
define("CUSLAN_27", "صفحه در دیتابیس ذخیره شد.");
define("CUSLAN_28", "صفحه حذف شد.");
define("CUSLAN_29", "لیست صفحات در صورت عدم انتخاب");
define("CUSLAN_30", "زمان اتمام فعالیت کوکی ها (به ثانیه)");
define("CUSLAN_31", "ایجاد منو");
define("CUSLAN_32", "تبدیل صفحات/منو های قدیمی");
define("CUSLAN_33", "تنظیمات صفحه");
define("CUSLAN_34", "شروع تغییرات");
define("CUSLAN_35", "به روز رسانی صفحه سفارشی پایان یافت - به روز شد");
define("CUSLAN_36", "برای ذخیره مشخصات هر صفحه, به صفحه اول بازگردید و این صفحه را ویرایش کنید.");
define("CUSLAN_37", "به روز رسانی صفحه سفارشی");
define("CUSLAN_38", "روشن");
define("CUSLAN_39", "خاموش");
define("CUSLAN_40", "ذخیره تنظیمات");

define("CUSLAN_41", "نمایش مشخصات نویسنده و تاریخ");
define("CUSLAN_42", "هنوز هیچ صفحه ای تعریف نشده است.");
define('CUSLAN_43', 'منوی بدون عنوان: ');
define('CUSLAN_44', 'صفحه بدون عنوان');

?>