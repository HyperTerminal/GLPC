<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "تنظیمات ذخیره شد..");
define("FRTLAN_2", "تنظیم صفحه اول برای");
define("FRTLAN_6", "لینک ها");
// define("FRTLAN_7", "صفحه محتوا");
define("FRTLAN_12", "ذخیره تنظیمات");
define("FRTLAN_13", "تنظیمات صفحه اول");
define("FRTLAN_15", "دیگر (آدرس را وارد کنید):");
define("FRTLAN_16", "خطا: شاخه اصلی محتوا انتخاب نشده است.");
define("FRTLAN_17", "خطا: زیر شاخه محتوا انتخاب نشده است.");
define("FRTLAN_18", "خطا: محتوا انتخاب نشده است");
define("FRTLAN_19", "شاخه اصلی محتوا");
define("FRTLAN_20", "شاخه محتوا");
define("FRTLAN_21", "محتوا");
define("FRTLAN_22", "صفحه سفارشی");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "تمام کاربران");
define("FRTLAN_27", "مهمانان");
define("FRTLAN_28", "کاربران");
define("FRTLAN_29", "مدیران");
define("FRTLAN_31", "تمام کاربران");
define("FRTLAN_32", "رتبه های کاربران");
define("FRTLAN_33", "تنظیمات فعلی");
define("FRTLAN_34", "صفحه");

?>