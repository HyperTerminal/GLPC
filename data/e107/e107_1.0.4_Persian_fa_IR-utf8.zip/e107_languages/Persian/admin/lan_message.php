<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "پیغام های دریافت شده");
define("MESSLAN_2", "حذف پیغام");
define("MESSLAN_3", "پیغام حذف شد.");
define("MESSLAN_4", "حذف تمام پیغام ها");
define("MESSLAN_5", "تایید");
define("MESSLAN_6", "تمام پیغام ها حذف شدند.");
define("MESSLAN_7", "بدون پیغام.");
define("MESSLAN_8", "نوع پیغام");
define("MESSLAN_9", "گزارش شده در تاریخ");

define("MESSLAN_10", "ارسال شده توسط ");
define("MESSLAN_11", "در صفحه جدید ");
define("MESSLAN_12", "پیغام");
define("MESSLAN_13", "لینک");


?>