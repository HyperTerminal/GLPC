<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "ارسال نامه آگاه سازی به ");
define("UCSLAN_2", "رتبه شما تغییر یافت");
define("UCSLAN_3", "عزیز");
define("UCSLAN_4", "رتبه شما تغییر یافت به ");
define("UCSLAN_5", "شما اکنون به محیط های زیر در سایت دسترسی دارید ");
define("UCSLAN_6", "انتخاب رتبه برای کاربر");
define("UCSLAN_7", "تنظیم رتبه ها");
define("UCSLAN_8", "آگاه ساختن کاربر");
define("UCSLAN_9", "رتبه ها به روز شد.");
define("UCSLAN_10", "ملاحظات");
define('UCSLAN_12', 'اختیارات فقط در حد کاربر');

?>