<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "رتبه تمام کاربران پاک شد.");
define("UCSLAN_2", "تنظیمات ذخیره شد.");
define("UCSLAN_3", "رتبه حذف شد.");
define("UCSLAN_4", "برای تایید حذف رتبه جعبه را علامت بزنید");
define("UCSLAN_5", "تنظیمات ذخیره شد.");
define("UCSLAN_6", "رتبه ذخیره شد.");
define("UCSLAN_7", "هیچ رتبه کاربری وجود ندارد.");
define("UCSLAN_8", "رتبه های موجود");

// define("UCSLAN_9", "ویرایش");
// define("UCSLAN_10", "حذف");
define("UCSLAN_11", "برای تایید علامت بزنید");
define("UCSLAN_12", "نام رتبه :");
define("UCSLAN_13", "توضیحات رتبه :");
define("UCSLAN_14", "به روزرسانی رتبه کاربران");
define("UCSLAN_15", "ایجاد رتبه جدید");
define("UCSLAN_16", "اختصاص این رتبه به کاربر");
define("UCSLAN_17", "حذف");
define("UCSLAN_18", "پاک کردن رتبه");
define("UCSLAN_19", "اختصاص رتبه ");
define("UCSLAN_20", "به کاربر");
define("UCSLAN_21", "تنظیمات رتبه کاربران");

define("UCSLAN_22", "کاربران - برای انتقال کلیک کنید");
define("UCSLAN_23", "کاربران دارای این رتبه....");

define("UCSLAN_24", "چه کسی امکان مدیریت رتبه ها را دارد ؟ ");

define("UCSLAN_25", "شماره");
define("UCSLAN_26", "نام کاربری");
define("UCSLAN_27", "بازگشت");

?>