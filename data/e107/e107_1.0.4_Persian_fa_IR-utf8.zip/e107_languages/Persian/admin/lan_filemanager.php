<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_filemanager.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/14 23:35:15 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "آپلود شد");
define("FMLAN_2", "به");
define("FMLAN_3", "شاخه");
define("FMLAN_4", "اندازه فایل آپلودی بیشتر از اندازه تعریف شده در فایل php.ini است");
// define("FMLAN_5", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
// define("FMLAN_6", "The uploaded file was only partially uploaded.");
// define("FMLAN_7", "هیچ فایلی آپلود نشده است.");
// define("FMLAN_8", "حجم فایل 0 بایت");
// define("FMLAN_9", "نام فایل. فایل آپلود نشد");
define('FMLAN_10', 'خطا');
// define("FMLAN_11", "Probably incorrect permissions on upload directory.");

define("FMLAN_12", "فایل");
define("FMLAN_13", "فایل");
define("FMLAN_14", "پوشه");
define("FMLAN_15", "پوشه");
define("FMLAN_16", "پوشه اصلی");
define("FMLAN_17", "نام");
define("FMLAN_18", "اندازه");
define("FMLAN_19", "آخرین ویرایش در:");

define("FMLAN_21", "آپلود فایل به این پوشه");
define("FMLAN_22", "آپلود");

define("FMLAN_26", "با موفقیت");
define("FMLAN_27", "حذف شد");
define("FMLAN_28", "امکان حذف وجود ندارد");
define("FMLAN_29", "آدرس");
define("FMLAN_30", "ّبالا");
define("FMLAN_31", "پوشه");

define("FMLAN_32", "یک پوشه را انتخاب کنید :");
define("FMLAN_33", "انتخاب");
define("FMLAN_34", "انتخاب پوشه");
define("FMLAN_35", "پوشه فایل ها");

define("FMLAN_36", "پوشه منو های سفارشی");
define("FMLAN_37", "پوشه صفحات سفارشی");

define("FMLAN_38", "فایل با موفقیت انتقال داده شد به");
define("FMLAN_39", "امکان انتقال فایل نیست به");
define("FMLAN_40", "Newspost-Images پوشه");


define("FMLAN_43", "حذف فایل های انتخاب شده");


define("FMLAN_46", "عمل حذف فایل های مورد نظر را تایید کنید.");
define("FMLAN_47", "آپلود های کاربران");

define("FMLAN_48", "انتقال انتخاب شده به");
define("FMLAN_49", "عمل انتقال فایل را تایید کنید.");
define("FMLAN_50", "انتقال");
define('FMLAN_51', 'خطای ناشناخته: ‌: ');



?>