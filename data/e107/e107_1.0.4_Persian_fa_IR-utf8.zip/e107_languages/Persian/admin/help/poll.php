<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/help/poll.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/14 17:37:43 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "نظرسنجی های مورد نظر خود را در این قسمت اضافه و ویرایش کنید, عنوان نظرسنجی و گزینه ها را وارد کنید و سپس نظرسنجی را فعال کنید.<br /><br />
برای نمایش نظرسنجی ها, به قسمت مدیزیت منوها بروید و اطمینان یابید که منوی poll_menu فعال شده است.";

$ns -> tablerender("راهنمای نظرسنجی ها", $text);
?>