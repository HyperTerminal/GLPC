<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_emoticon.php,v $
|     $Revision: 1.11 $
|     $Date: 2007/05/29 19:45:31 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "فعال سازی صورتک ها");
define("EMOLAN_2", "نام");
define("EMOLAN_3", "صورتک ها");
define("EMOLAN_4", "فعال بودن صورتک ها ؟");

define("EMOLAN_5", "تصویر");
define("EMOLAN_6", "کد صورتک");
define("EMOLAN_7", "با استفاده از Space از هم جدا کنید.");

define("EMOLAN_8", "وضعیت");
define("EMOLAN_9", "تنظیمات");
define("EMOLAN_10", "فعال");
define("EMOLAN_11", "فعال کردن بسته'");

define("EMOLAN_12", "ویرایش / تنظیمات این بسته");
define("EMOLAN_13", "بسته نصب شده");

define("EMOLAN_14", "ذخیره تنظیمات");
define("EMOLAN_15", "ویرایش / تنظیمات صورتک ها");
define("EMOLAN_16", "تنظیمات صورتک ها ذخیره شد");
define("EMOLAN_17", "You have an emoticon pack present that contains spaces, which are not allowed !");
define("EMOLAN_18", "please rename the instances listed below so they no longer contain spaces:");
define("EMOLAN_19", "نام");
define("EMOLAN_20", "مکان");
define("EMOLAN_21", "خطا");
//define("EMOLAN_2", "نام");
define("EMOLAN_22", "بسته جدید شکلک یافت شد:");
define("EMOLAN_23", "xml جدید شکلک یافت شد:");
define("EMOLAN_24", "صفحه php جدید شکلک پیدا شد:");
define("EMOLAN_25", "نصب بسته صورتک جدید: ");
define("EMOLAN_26", "تکرار اسکن کردن بسته");
define("EMOLAN_27", "Error occurred processing pack: ");
define("EMOLAN_28", "ساخت XML");
define("EMOLAN_29", "XML ساخته شد: ");
define("EMOLAN_30", "خطا: ");
?>