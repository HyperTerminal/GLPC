<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db_verify.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/05/29 18:53:04 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "امکان خواندن داده های بانک اطلاعاتی نیست<br /><br />اطمینان یابید که فایل <b>core_sql.php</b> در پوشه <b>/admin/sql</b> وجود دارد.");
define("DBLAN_2", "بررسی همه");

define("DBLAN_4", "جدول");
define("DBLAN_5", "فیلد");
define("DBLAN_6", "وضعیت");
define("DBLAN_7", "توضیحات");
define("DBLAN_8", "عدم مطابقت");
define("DBLAN_9", "معمولا");
define("DBLAN_10", "باید");
define("DBLAN_11", "فیلد وجود ندارد");
define("DBLAN_12", "فیلد اضافی");
define("DBLAN_13", "جدول وجود ندارد");
define("DBLAN_14", "جداول مورد نظر براي بررسی را انتخاب کنید");
define("DBLAN_15", "شروع بررسی");
define("DBLAN_16", "بررسی SQL");
define("DBLAN_17", "بازگشت");
define("DBLAN_18", "جدول ها");
define("DBLAN_19", "تلاش برای رفع اشکال");
define("DBLAN_20", "در حال تلاش برای رفع اشکال");
define("DBLAN_21", "رفع اشکال قسمت انتخاب شده");
define("DBLAN_22", " قابل خواندن نیست");
?>