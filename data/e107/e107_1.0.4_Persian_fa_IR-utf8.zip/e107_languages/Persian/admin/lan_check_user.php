<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/01/06 20:58:08 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','بررسی دیتابیس کاربران');
define('LAN_CKUSER_02','این ابزار مشکلات مختلف دیتابیس کاربران را مشخص می کند');
define('LAN_CKUSER_03','اگر کاربران زیادی دارید, ممکن است چند دقیقه زمان ببرد, یا خارج از زمان باشد');
define('LAN_CKUSER_04','انجام');
define('LAN_CKUSER_05','بررسی برای نام ورود به سایت مشابه');
define('LAN_CKUSER_06','تابع مورد نظر برای اجرا را انتخاب کنید');
define('LAN_CKUSER_07','نام کاربری مشابه پیدا شد');
define('LAN_CKUSER_08','نام کاربری مشابه پیدا نشد');
define('LAN_CKUSER_09','نام کاربری');
define('LAN_CKUSER_10','شماره کاربری');
define('LAN_CKUSER_11','نام نمایشی');
define('LAN_CKUSER_12','بررسی برای آدرس پست الکترونیک مشابه');
define('LAN_CKUSER_13','آدرس پست الکترونیک مشابه پیدا شد');
define('LAN_CKUSER_14','آدرس پست الکترونیک');
define('LAN_CKUSER_15','آدرس پست الکترونیک مشابه پیدا نشد');
define('LAN_CKUSER_16','پیدا کردن نام کاربری مشابه');
define('LAN_CKUSER_17','تداخل نام کاربری و نام ورود به سایت');
define('LAN_CKUSER_18','کاربر A');
define('LAN_CKUSER_19','کاربر B');
define('LAN_CKUSER_20','');

?>