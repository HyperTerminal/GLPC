<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_footer.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/29 17:45:38 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "نام سایت :");
define("FOOTLAN_2", "مدیریت کل :");
define("FOOTLAN_3", "نسخه e107 فارسی :");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "قالب سایت :");
define("FOOTLAN_6", "توسط");
define("FOOTLAN_7", "اطلاعات");
define("FOOTLAN_8", "تاریخ راه اندازی سایت :");
define("FOOTLAN_9", "مشخصات سرور :");
define("FOOTLAN_10", "میزبان");
define("FOOTLAN_11", "نسخه PHP :");
define("FOOTLAN_12", "نسخه mySQL :");
define("FOOTLAN_13", "اطلاعات سایت");
define("FOOTLAN_14", "پرسش و پاسخ درباره این سیستم");
define("FOOTLAN_15", "مستندات");
define("FOOTLAN_16", "بانک اطلاعاتی");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "قالب سایت");
define("FOOTLAN_19", "تاریخ/ساعت کنونی سرور : ");
define("FOOTLAN_20", "سطح امنیتی");

?>