<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "وضعیت سیستم cache");
define("CACLAN_2", "تنظیم سیستم cache");
define("CACLAN_3", "سیستم cache");
define("CACLAN_4", "وضعیت سیستم cache تنظیم شد");
define("CACLAN_5", "خالی کردن سیستم cache");
define("CACLAN_6", "سیستم cache خالی شد");

define("CACLAN_7", "سیستم cache غیر فعال باشد");
//define("CACLAN_8", "داده های cache در MySQL ذخیره شود");
define("CACLAN_9", "داده های cache در دیسک ذخیره شود");
define("CACLAN_10", "شاخه مربوط به cache در سرور قابل نوشتن نیست اطمینان یابید سطح دسترسی این پوشه 777 باشد.");
?>