<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "خطا - دوباره ارسال کنید");
define("UDALAN_2", "تنظیمات ذخیره شد");
define("UDALAN_3", "به روز رسانی تنظیمات برای");
define("UDALAN_4", "نام");
define("UDALAN_5", "کلمه عبور");
define("UDALAN_6", "وارد کردن دوباره کلمه عبور");
define("UDALAN_7", "تغییر کلمه عبور");
define("UDALAN_8", "تغییر کلمه عبور");

?>