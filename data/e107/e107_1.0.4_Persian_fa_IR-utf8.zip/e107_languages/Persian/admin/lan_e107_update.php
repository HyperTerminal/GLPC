<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_e107_update.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/07/09 03:43:42 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "دستور");
define("LAN_UPDATE_3", "نیاز نیست");

define("LAN_UPDATE_5", "به روز رسانی موجود است");
define("LAN_UPDATE_7", "اجرا شد");
define("LAN_UPDATE_8", "به روز رسانی از");
define("LAN_UPDATE_9", "به");
define("LAN_UPDATE_10", "بسته های موجود برای به روز رسانی");
define("LAN_UPDATE_11", "به روز رسانی .617 to .7 ادامه  ");
define("LAN_UPDATE_12", "One of your tables contains duplicate entries.");


?>