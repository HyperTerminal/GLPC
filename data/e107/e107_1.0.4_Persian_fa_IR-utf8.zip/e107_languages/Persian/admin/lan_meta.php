<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_meta.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/06/07 05:04:58 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "ذخیره شد");
define("METLAN_2", " کد meta-tags را وارد کنید");
define("METLAN_3", "ذخیره کردن تنظیمات جدید");
define("METLAN_4", "به روز رسانی");
define("METLAN_5", "توضیحات سایت خود را در این قسمت وارد کنید");
define("METLAN_6", "لیست کلمات کلیدی سایت خود را در این جا وارد کنید");
define("METLAN_7", "اطلاعات کپی رایت سایت خود را در این قسمت وارد کنید");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "توضیحات");
define("METLAN_10", "کلمات اصلی");
define("METLAN_11", "کپی رایت");
define("METLAN_12", "استفاده از عنوان خبر و خلاصه خبر به عنوان توضیحات Meta در صفحات خبر");
define("METLAN_13", "نویسنده");

?>