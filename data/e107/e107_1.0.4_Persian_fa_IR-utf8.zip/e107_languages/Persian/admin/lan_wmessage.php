<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_wmessage.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/04/22 19:30:47 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "پیام برای مهمان");
// define("WMGLAN_2", "پیام برای اعضا");
// define("WMGLAN_3", "پیام برای مدیران");
// define("WMGLAN_4", "ارسال");
// define("WMGLAN_5", "ثبت پیام خوش آمد گویی");
// define("WMGLAN_6", "فعال؟");
// define("WMGLAN_7", "تنظیمات پیام خوش آمدگویی بروز شد.");

define("WMLAN_00","پیام های خوش آمد گویی");
define("WMLAN_01","ایجاد پیام جدید");
define("WMLAN_02","متن");
define("WMLAN_03","نمایش برای");
define("WMLAN_04","متن پیام");

define("WMLAN_05","در میان گذاشتن");
define("WMLAN_06","اگر علامت بزنید, پیام در داخل جعبه نمایش داده خواهد شد");
define("WMLAN_07","کد کوتاه پیام:");
// define("WMLAN_08","تنظیمات");

define("WMLAN_09","هیچ پیامی هنوز تنظیم نشده است.");
define("WMLAN_10","عنوان پیام");    

?>