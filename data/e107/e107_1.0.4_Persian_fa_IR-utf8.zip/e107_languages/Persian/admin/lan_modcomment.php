<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "مدیریت شد.");
define("MDCLAN_2", "بدون نظر ");
define("MDCLAN_3", "عضو");
define("MDCLAN_4", "مهمان");
define("MDCLAN_5", "عدم برگشت");
define("MDCLAN_6", "برگشت");

define("MDCLAN_7", "تایید");
define("MDCLAN_8", "مدیریت نظرات");
define("MDCLAN_9", "خطر ! حذف نظرات اصلی باعث حذف تمام پاسخ های آن می شود");

define("MDCLAN_10", "تنظیمات");
define("MDCLAN_11", "نظر");
define("MDCLAN_12", "نظرات");
define("MDCLAN_13", "بازگشت شد");
define("MDCLAN_14", "قفل کردن نظرات");
define("MDCLAN_15", "باز");
define("MDCLAN_16", "قفل");
define("MDCLAN_17", "نظری در انظار تایید وجود ندارد.");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>