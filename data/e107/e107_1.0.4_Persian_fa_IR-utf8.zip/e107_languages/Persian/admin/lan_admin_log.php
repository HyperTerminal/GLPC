<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "تاریخ");
define("LAN_ADMINLOG_2", "عنوان");
define("LAN_ADMINLOG_3", "شرح");
define("LAN_ADMINLOG_4", "کاربر IP");
define("LAN_ADMINLOG_5", "شناسه کاربر");
define("LAN_ADMINLOG_6", "Informative Icon");
define("LAN_ADMINLOG_7", "Informative Message");
define("LAN_ADMINLOG_8", "Notice Icon");
define("LAN_ADMINLOG_9", "Notice Message");
define("LAN_ADMINLOG_10", "آیکن اخطار");
define("LAN_ADMINLOG_11", "پیام اخطار");
define("LAN_ADMINLOG_12", "آیکن خطا");
define("LAN_ADMINLOG_13", "پیام خطای اساسی");

?>