<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/24 11:23:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "سال");
define("LANDT_02", "ماه");
define("LANDT_03", "هفته");
define("LANDT_04", "روز");
define("LANDT_05", "ساعت");
define("LANDT_06", "دقیقه");
define("LANDT_07", "ثانیه");
define("LANDT_01s", "سال");
define("LANDT_02s", "ماه");
define("LANDT_03s", "هفته");
define("LANDT_04s", "روز");
define("LANDT_05s", "ساعت");
define("LANDT_06s", "دقیقه");
define("LANDT_07s", "ثانیه");

define("LANDT_08", "دقیقه");
define("LANDT_08s", "دقیقه");
define("LANDT_09", "ثانیه");
define("LANDT_09s", "ثانیه");
define("LANDT_AGO", "قبل");


?>