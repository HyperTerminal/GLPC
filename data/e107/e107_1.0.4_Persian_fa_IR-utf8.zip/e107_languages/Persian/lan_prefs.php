<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_prefs.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/11/25 12:10:32 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "قدرت سايت توسط e107 فارسي (E107.ir)");
define("LAN_PREF_2", "قدرت سایت توسط e107 فارسی (E107.IR)");
define("LAN_PREF_3", "تمام حقوق محفوظ است - <a></a> e107.org"); 
define("LAN_PREF_4", "حذف شده.");
define("LAN_PREF_5", "انجمن های گفتگو");

?>