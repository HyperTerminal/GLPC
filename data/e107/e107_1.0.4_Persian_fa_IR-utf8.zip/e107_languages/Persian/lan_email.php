<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 19:06:54 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "پست الکترونیک"); }

define("LAN_EMAIL_1", "از طرف:");
define("LAN_EMAIL_2", "IP شخص فرستنده:");
define("LAN_EMAIL_3", "خبر از ");
define("LAN_EMAIL_4", "ارسال ایمیل");
define("LAN_EMAIL_5", "ارسال این قسمت به یک دوست");
define("LAN_EMAIL_6", "سلام دوست عزیز,به نظرم این مطلب برای شما جالب است به همین علت برای شما ارسال کردم.");
define("LAN_EMAIL_7", "ارسال به یک دوست");
define("LAN_EMAIL_8", "متن پیام");
define("LAN_EMAIL_9", "امکان ارسال نیست");
define("LAN_EMAIL_10", "نام فرستاده شد برای ");
define("LAN_EMAIL_11", "نامه الکترونیک ارسال شد.");
define("LAN_EMAIL_12", "خطا");
define("LAN_EMAIL_13", "ارسال مقاله به یک دوست");
define("LAN_EMAIL_14", "ارسال خبر به یک دوست");
define("LAN_EMAIL_15", "نام ورودی: ");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LAN_EMAIL_106", "آدرس پست الکترونیک دوست شما صحیح نیست");
define("LAN_EMAIL_185", "ارسال مقاله");
define("LAN_EMAIL_186", "ارسال خبر");
define("LAN_EMAIL_187", "آدرس پست الکترونیک دوست شما");
define("LAN_EMAIL_188", "من فکر کردم خواندن این خبر برای شما مفید است");
define("LAN_EMAIL_189", "من فکر کردم خواندن این مقاله برای شما مفید است");
define("LAN_EMAIL_190", "کد نمایشی را وارد کنید");





?>