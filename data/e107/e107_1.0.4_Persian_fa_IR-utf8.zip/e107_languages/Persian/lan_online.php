<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

//v.616
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("ONLINE_EL1", "مهمان: ");
define("ONLINE_EL2", "اعضا: ");
define("ONLINE_EL3", "حاضر در این صفحه: ");
define("ONLINE_EL4", "کاربران آنلاین");
define("ONLINE_EL5", "اعضا");
define("ONLINE_EL6", "جدیدترین عضو");
define("ONLINE_EL7", "در حال بازدید از");
define("ONLINE_EL8", "بیشترین کاربران آنلاین همزمان: ");
define("ONLINE_EL9", "در تاریخ");
define("ONLINE_EL10", "نام کاربر");
define("ONLINE_EL11", "در حال بازدید از صفحه");
define("ONLINE_EL12", "پاسخ به");
define("ONLINE_EL13", "انجمن");
define("ONLINE_EL14", "موضوع");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("ONLINE_EL15", "صفحه");
define("CLASSRESTRICTED", "صفحه دارای محدودیت دسترسی");
define("ARTICLEPAGE", "مقالات/نقد ها");
define("CHAT", "چت و گفتگو");
define("COMMENT", "نظرات");
define("DOWNLOAD", "قسمت دانلود");
define("EMAIL", "email.php");
define("FORUM", "صفحه اصلی انجمن");
define("LINKS", "لینک ها");
define("NEWS", "اخبار");
define("OLDPOLLS", "نظرسنجی های قدیمی");
define("POLLCOMMENT", "نظرسنجی");
define("PRINTPAGE", "چاپ");
define("LOGIN", "ورود به سایت");
define("SEARCH", "در حال جستجو");
define("STATS", "مشاهده آمار سایت");
define("SUBMITNEWS", "ارسال خبر");
define("UPLOAD", "آپلود فایل");
define("USERPAGE", "مشخصات کاربری");
define("USERSETTINGS", "تنظیمات کاربری");
define("ONLINE", "کاربران آنلاین");
define("LISTNEW", "آخرین آیتم جدید");
define("USERPOSTS", "ارسال های کاربران");
define("SUBCONTENT", "ارسال مقاله/نقد");
define("TOP", "عضو های فعال انجمن/فعالترین موضوعات انجمن");
define("ADMINAREA", "محیط مدیریت");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "لیست رخداد ها");
define("CALENDAR", "تقویم رخداد ها");
define("FAQ", "پرسش و پاسخ");
define("PM", "پیغام خصوصی");
define("SURVEY", "نظرسنجی");
define("ARTICLE", "مقاله");
define("CONTENT", "صفحه محتوا");
define("REVIEW", "نقد");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 

?>