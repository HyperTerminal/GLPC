<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "User Posts");

//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("UP_LAN_0", "تمام ارسال های انجمن برای ");
define("UP_LAN_1", "تمام نظرات برای ");
define("UP_LAN_2", "موضوع");
define("UP_LAN_3", "بازدید");
define("UP_LAN_4", "پاسخ ها");
define("UP_LAN_5", "آخرین ارسال");
define("UP_LAN_6", "موضوعات");
define("UP_LAN_7", "بدون نظر");
define("UP_LAN_8", "بدون ارسال");
define("UP_LAN_9", " در تاریخ ");
define("UP_LAN_10", "پاسخ");
define("UP_LAN_11", "تاریخ ارسال: ");
define("UP_LAN_12", "جستجو");
define("UP_LAN_13", "نظرات");
define("UP_LAN_14", "ارسال های انجمن");
define("UP_LAN_15", "پاسخ");
define("UP_LAN_16", "IP آدرس");
?>