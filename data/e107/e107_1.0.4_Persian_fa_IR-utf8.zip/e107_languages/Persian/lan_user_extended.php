<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_user_extended.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/28 16:22:00 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "جعبه متن");
define("UE_LAN_2", "دکمه رادیویی");
define("UE_LAN_3", "منوی افتادنی");
define("UE_LAN_4", "فیلد جدول دیتابیس");
define("UE_LAN_5", "محیط متنی");
define("UE_LAN_6", "صحیح");
define("UE_LAN_7", "تاریخ");
define("UE_LAN_8", "زبان");

define("UE_LAN_9", "نام");
define("UE_LAN_10", "نوع");
define("UE_LAN_11", "استفاده");

define("UE_LAN_HIDE", "مخفی کردن از کاربر");

define("UE_LAN_LOCATION", "مکان");
define("UE_LAN_LOCATION_DESC", "مکان کاربر");
define("UE_LAN_AIM", "آدرس AIM ");
define("UE_LAN_AIM_DESC", " آدرسAIM ");
define("UE_LAN_ICQ", " شماره ICQ ");
define("UE_LAN_ICQ_DESC", "شماره ICQ");
define("UE_LAN_YAHOO", "آدرس Yahoo!");
define("UE_LAN_YAHOO_DESC", "آدرس Yahoo!");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "آدرس MSN ");
define("UE_LAN_HOMEPAGE", "صفحه خانگی");
define("UE_LAN_HOMEPAGE_DESC", "صفحه خانگی کاربر");
define("UE_LAN_BIRTHDAY", "تاریخ تولد");
define("UE_LAN_BIRTHDAY_DESC", "تاریخ تولد کاربر");
define("UE_LAN_LANGUAGE", "زبان");
define("UE_LAN_LANGUAGE_DESC", "زبان کاربر");
define("UE_LAN_COUNTRY", "کشور");
define("UE_LAN_COUNTRY_DESC", "کشور کاربر (شامل جداول بانک اطلاعاتی)");
define("LAN_UE_FAIL_HOMEPAGE", "آدرس وب سایت وارد شده اشتباه است.");
?>