<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "ارسال خبر");
define("LAN_7", "نام کاربری: ");
define("LAN_62", "موضوع: ");
define("LAN_112", "آدرس پست الکترونیک: ");
define("LAN_133", "تشکر");
define("LAN_134", "آیتم خبری شما ثبت شد پس از بررسی مدیر فعال شده و در سایت قرار می گیرد.");
define("LAN_135", "خبر: ");
define("LAN_136", "ارسال خبر");
define("NWSLAN_6", "شاخه");
define("NWSLAN_10", "شاخه ای وجود ندارد");
define("NWSLAN_11", "شما اجازه دسترسی به این محیط را ندارید.");
define("NWSLAN_12", "دسترسی تایید نشد.");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("SUBNEWSLAN_1", "شما باید یک عنوان برای خبر انتخاب کنید .");
define("SUBNEWSLAN_2", "شما باید متن خبر خود را وارد کنید");
define("SUBNEWSLAN_3", "فایل پیوستی شما باید یا jpg باشد یا gif یا png ");
define("SUBNEWSLAN_4", "اندازه فایل از حد مجاز بزرگ تر است");
define("SUBNEWSLAN_5", "فایل تصویری");
define("SUBNEWSLAN_6", "(jpg, gif یا png)");
define('SUBNEWSLAN_7', 'شما باید نام و آدرس پست الکترونیک خود را وارد کنید');
define('SUBNEWSLAN_8', 'خطا هنگام آپلود تصویر');
?>