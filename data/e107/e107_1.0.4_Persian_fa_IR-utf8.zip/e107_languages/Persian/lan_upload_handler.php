<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/05 06:58:21 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("LANUPLOAD_1", "نوع فایل");
define("LANUPLOAD_2", "این فایل مجاز نیست و حذف شد.");
define("LANUPLOAD_3", "با موفقیت آپلود شد.");
define("LANUPLOAD_4", "پوشه مقصد وجود ندارد یا قابل .");
define("LANUPLOAD_5", "اندازه این فایل بزرگتر از حد مجار در فایل php.ini می باشد");
define("LANUPLOAD_6", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
define("LANUPLOAD_7", "The uploaded file was only partially uploaded.");
define("LANUPLOAD_8", "هیچ فایلی آپلود نشده.");
define("LANUPLOAD_9", "حجم فایل آپلود شده 0 بایت است");
define("LANUPLOAD_10", "آپلود با موفقیت انجام نشد [نام تکراری] - یک فایل با این نام وجو دارد.");
define("LANUPLOAD_11", "فایل آپلود نشد. نام فایل: ");
define("LANUPLOAD_12", "خطا");
define("LANUPLOAD_13", "پوشه آپلود موقت موجود نیست");
define("LANUPLOAD_14", "سطح دسترسی نوشتن نیست");
define("LANUPLOAD_15", "اجازه آپلود داده نشده است");
define("LANUPLOAD_16", "خطای ناشناخته");
define("LANUPLOAD_17", "فایل آپلود شده دارای نام غیر مجاز است");
define("LANUPLOAD_18", "فایل آپلود شده از از محدودیت های مجاز فراتر است");
define("LANUPLOAD_19", "بیش از حد فایل آپلود شده است - فایل های اضافه حدف شد..");
//Language Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 

?>