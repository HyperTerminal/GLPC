<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/23 23:10:14 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "ثبت نام کاربر");

define("NT_LAN_UV_1", "ثبت نام کاربر تایید شد.");
define("NT_LAN_UV_2", "رشته جلسات کاربر");
define("NT_LAN_UV_3", "نام ورودی کاربر: ");
define("NT_LAN_UV_4", "ادرس IP: ");

define("NT_LAN_LI_1", "ورود کاربر");

define("NT_LAN_LO_1", "خروج کاربر");
define("NT_LAN_LO_2", " خروج از سایت");

define("NT_LAN_FL_1", "ممنوعیت از ثبت نام اتوماتیک");
define("NT_LAN_FL_2", "ممنوعیت آدرس ip از ثبت نام");

define("NT_LAN_SN_1", "اخبار ثبت شده");

define("NT_LAN_NU_1", "به روز شد.");

define("NT_LAN_ND_1", "اخبار حذف شده");
define("NT_LAN_ND_2", "شماره اخبار حذف شده");


define("NT_LAN_CM_1", "نظر کاربر در انتظار تایید است.");

?>