<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - BANNERLANguage File.
|     Translated By Persian E107 Support : E107.IR  ( Hamed Agharezae )
|     $Source: /cvsroot/e107/e107_0.7/e107_BANNERLANguages/English/BANNERLAN_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "تبلیغات"); 
//BANNERLANguage Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("BANNERLAN_16", "نام کاربری: ");
define("BANNERLAN_17", "کلمه عبور: ");
define("BANNERLAN_18", "ادامه");
define("BANNERLAN_19", "نام کاربری و کلمه عبور خود را وارد کنید");
define("BANNERLAN_20", "امکان دریافت این جزییات از دیتابیس نیست با مدیریت تماس بگیرید.");
define("BANNERLAN_21", "آمار تبلیغات سایت");
define("BANNERLAN_22", "نام مشتری");
define("BANNERLAN_23", "شماره تبلیغ");
define("BANNERLAN_24", "تعداد جذب کلیک");
define("BANNERLAN_25", " % کلیک");
define("BANNERLAN_26", "مدت نمایش");
//BANNERLANguage Files Translated by www.Webshahr.com (Hamed)
//For Persian support www.e107.webshahr.com 
define("BANNERLAN_27", "مدت نمایش خریداری شده");
define("BANNERLAN_28", "مدت نمایش تمام شده");
define("BANNERLAN_29", "بدون تبلیغ");
define("BANNERLAN_30", "نامحدود");
define("BANNERLAN_31", "قابل اجرا نیست");
define("BANNERLAN_32", "بله");
define("BANNERLAN_33", "خیر");
define("BANNERLAN_34", "پایان");
define("BANNERLAN_35", " IP کلیک کنندگان ");
define("BANNERLAN_36", "فعال:");
define("BANNERLAN_37", "شروع:");
define("BANNERLAN_38", "خطا");

?>