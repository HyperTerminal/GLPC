<?php
define('LAN_THEME_1', 'Sebes فارسی طراحی شده توسط<a href="http://e107.org" title="E107.ORG" rel="external">E107 INC</a>');
define('LAN_THEME_2', 'نظرات : ');
define('LAN_THEME_3', 'نظرات برای این مطلب غیر فعال هستند.');
define('LAN_THEME_4', 'ادامه مطلب');
define('LAN_THEME_5', 'دنبالک : ');
define('LAN_THEME_6', ' در تاریخ ');

?>