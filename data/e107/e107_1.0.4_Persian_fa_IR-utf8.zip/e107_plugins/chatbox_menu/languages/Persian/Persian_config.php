<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/English/English_config.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/06 01:06:09 $
|     $Author: mcfly_e107 $
|     Encoding:
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "تنظیمات جعبه گفتگو به روز شد.");
define("CHBLAN_2", "مدیریت شد.");
define("CHBLAN_3", "پیغامی موجود نیست");
define("CHBLAN_4", "اعضا");
define("CHBLAN_5", "مهمان");
define("CHBLAN_6", "عدم بازگشت");
define("CHBLAN_7", "بازگشت");
define("CHBLAN_8", "حذف");
define("CHBLAN_9", "مدیریت جعبه گفتگو");
define("CHBLAN_10", "مدیریت ارسال ها");
define("CHBLAN_11", "پیغام های نمایشی در جعبه گفتگو");
define("CHBLAN_12", "تعداد پیغام های نمایشی در جعبه گفتگو");
define("CHBLAN_13", "جایگزینی لینک ها");
define("CHBLAN_14", "اگر علامت زده شود, لینک های ارسالی با رشته زیر جایگزین می شوند");
define("CHBLAN_15", "جایگزین سازی با رشته فعال است");
define("CHBLAN_16", "لینک ها با این رشته جایگزین خواهند شد.");
define("CHBLAN_17", "اصلاح کلمات بلند ");
define("CHBLAN_18", "کلمه های بیشتر از این مقدار اصلاح می شوند");
define("CHBLAN_19", "به روز رسانی تنظیمات جعبه گفتگو");
define("CHBLAN_20", "تنظیمات جعبه گفتگو");
define("CHBLAN_21", "اصلاح");
define("CHBLAN_22", "حذف ارسال های قدیمی تر از یک دوره زمانی");
define("CHBLAN_23", "حذف ارسال های قدیمی تر از ");

define("CHBLAN_24", "یک روز");
define("CHBLAN_25", "یک هفته");
define("CHBLAN_26", "یک ماه");
define("CHBLAN_27", "- حذف تمام ارسال ها -");
define("CHBLAN_28", "جعبه گفتگو اصلاح شد.");

define("CHBLAN_29", "چرخشی بودن جعبه گفتگو");
define("CHBLAN_30", "ارتفاع منو");
define("CHBLAN_31", "نمایش صورتک ها");
define("CHBLAN_32", "رتبه مدیر");

define("CHBLAN_33", "شمارش کاربران دوباره انجام شد.");
define("CHBLAN_34", "دوباره حساب کردن شمارش ارسال کاربران");
define("CHBLAN_35", "دوباره حساب کردن");

define("CHBLAN_36", "تنظیمات نمایش جعبه گفتگو");
define("CHBLAN_37", "جعبه گفتگوی معمولی");
define("CHBLAN_38", "استفاده از AJAX برای سرعت لود بالا");

?>