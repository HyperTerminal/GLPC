<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/09/18 08:57:42 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "محتوا");
define("CONT_SCH_LAN_2", "تمام شاخه های ممحتوا");
define("CONT_SCH_LAN_3", "ارسال شده در پاسخی به یک مطلب");
define("CONT_SCH_LAN_4", "در");

?>