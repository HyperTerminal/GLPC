<?php
	
define("LAN_UMENU_THEME_1", "تنظیم قالب");
define("LAN_UMENU_THEME_2", "انتخاب قالب");
define('LAN_UMENU_THEME_3', 'کاربران:');
define('LAN_UMENU_THEME_4', 'قالب هایی که کاربران امکان انتخاب آن ها را دارند مشخص کنید');
define('LAN_UMENU_THEME_5', 'به روز رسانی');
define('LAN_UMENU_THEME_6', 'قالب های مجاز برای انتخاب توسط کاربران');
define('LAN_UMENU_THEME_7', 'رتبه کاربری دارای دسترسی انتخاب قالب');
	
?>