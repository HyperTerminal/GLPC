<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/16 10:36:59 $
|     $Author: lisa_ $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF ساز");
define("PDF_PLUGIN_LAN_2", "اين پلاگين به منظور گرفتن خروجي PDF از قسمت هايي مثل خبر استفاده مي شود");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "پلاگین اماده کار است.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "پیکربندی PDF");
define("PDF_LAN_3", "فعال");
define("PDF_LAN_4", "غیرفعال");
define("PDF_LAN_5", "حاشیه صفخه از چپ");
define("PDF_LAN_6", "حاشیه صفحه از راست");
define("PDF_LAN_7", "حاشیه صفحه از بالا");
define("PDF_LAN_8", "نوع قلم");
define("PDF_LAN_9", "اندازه پیش فرض قلم");
define("PDF_LAN_10", "اندازه نام سایت");
define("PDF_LAN_11", "اندازه آدرس");
define("PDF_LAN_12", "اندازه شماره صفحه");
define("PDF_LAN_13", "نمایش لوگو در PDF ؟");
define("PDF_LAN_14", "نمایش نام سایت در pdf ؟");
define("PDF_LAN_15", "نمایش آدرس صفحه در pdf ؟");
define("PDF_LAN_16", "نمایش شماره صفحات در pdf ؟");
define("PDF_LAN_17", "به روزرسانی");
define("PDF_LAN_18", "تنظیمات ذخیره شد.");
define("PDF_LAN_19", "صفحه");
define("PDF_LAN_20", "گزارش خطا");

?>