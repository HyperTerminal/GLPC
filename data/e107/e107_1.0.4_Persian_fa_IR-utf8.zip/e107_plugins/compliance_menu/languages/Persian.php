<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/compliance_menu/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/03/22 20:58:14 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
	
define("COMPLIANCE_L1", "تایید شد توسط W3C");

?>