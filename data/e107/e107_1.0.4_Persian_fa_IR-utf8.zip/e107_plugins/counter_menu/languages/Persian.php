<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/22 18:07:49 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
	
define("COUNTER_L1", "(ورود مدیران در آمار شمارش نمی شود)");
define("COUNTER_L2", "بازدید از این صفحه امروز");
define("COUNTER_L3", "کل بازدید ها");
define("COUNTER_L4", "بازدید از این صفحه در کل");
define("COUNTER_L5", "تعداد نفرات بازدید کننده");
define("COUNTER_L6", "کل سایت");
define("COUNTER_L7", "آمارگیر");
define("COUNTER_L8", "پیام مدیر: <b>سیستم آمار سایت غیر فعال است.</b><br />برای فعال سازی, شما نیار دارید به نصب پلاگین آمار سیستم <a href='".e_ADMIN."plugin.php'>در مدیریت پلاگین ها</a>, سپس آن را فعال کنید <a href='".e_PLUGIN."log/admin_config.php'>در صفحه تنظیمات</a>.");
	
?>