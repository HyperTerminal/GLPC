<?php
define('OTHERDB_LAN_1', 'نوع بانک اطلاعاتی:');
define('OTHERDB_LAN_2', 'سرور:');
define('OTHERDB_LAN_3', 'نام کاربری بانک اطلاعاتی:');
define('OTHERDB_LAN_4', 'کلمه عبور:');
define('OTHERDB_LAN_5', 'بانک اطلاعاتی');
define('OTHERDB_LAN_6', 'جدول');
define('OTHERDB_LAN_7', 'فیلد نام کاربری:');
define('OTHERDB_LAN_8', 'فیلد کلمه عبور:');
define('OTHERDB_LAN_9', 'روش کد گذاری کلمه عبور:');
define('OTHERDB_LAN_10', 'پیکربندی ارتباط با بانک اطلاعاتی دیگر');
define('OTHERDB_LAN_11', '** اگر از بانک اطلاعاتی سیستم E107 استفاده می کنید نیاز به تکمیل فیلد های زیر نیست.');
