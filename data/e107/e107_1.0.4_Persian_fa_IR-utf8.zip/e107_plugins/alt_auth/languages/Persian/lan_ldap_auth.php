<?php
define('LDAPLAN_1', 'آدرس سرور');
define('LDAPLAN_2', 'دامنه اصلی<br />اگر LDAP است - BaseDN را وارد کنید<br />اگر AD است- دامنه را وارد کنید');
define('LDAPLAN_3', 'LDAP نام کاربری<br />نام کاربری مجاز برای جستجو در شاخه.');
define('LDAPLAN_4', 'LDAP کلمه عبور<br />کلمه عبور کاربر.');
define('LDAPLAN_5', 'نسخه LDAP');
define('LDAPLAN_6', 'پیکربندی ارتباط LDAP');
define('LDAPLAN_7', 'فیلتر جستجوی eDirectory:');
define('LDAPLAN_8', 'اطمینان یابید نام کاربری در شاخه درست استفاده شده است, <br />ie \'(objectclass=inetOrgPerson)\'');
define('LDAPLAN_9', 'فیلتر پیش فرض جستجو:');
define('LDAPLAN_10', 'خطا:  به نظر ماژول ldap در حال حاظر فعال نیست, تنظیمات شما کارایی ندارد.!');
define('LDAPLAN_11', 'نوع سرور');

