<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/22 19:49:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "تبلیغات");
define("BANNER_MENU_L2", "تنظیمات ذخیره شد");

//v.617
define("BANNER_MENU_L3", "عنوان");
define("BANNER_MENU_L4", "رشته");
define("BANNER_MENU_L5", "تنظیمات تبلیغات سایت");
define("BANNER_MENU_L6", "یک رشته را برای نمایش در منو انتخاب کنید");
define("BANNER_MENU_L7", "رشته های موجود");
define("BANNER_MENU_L8", "رشته های انتخاب شده ");
define("BANNER_MENU_L9", "حذف انتخاب شده ها");
define("BANNER_MENU_L10", "رشته های انتخاب شده به چه صورت نمایش داده شوند ؟");
define("BANNER_MENU_L11", "انتخاب نحوه نمایش...");
define("BANNER_MENU_L12", "یک رشته در یک منو");
define("BANNER_MENU_L13", "تمام رشته های انتخاب شده در یک منو");
define("BANNER_MENU_L14", "تمام زشته های انتخاب شده در منو های جداگانه");
define("BANNER_MENU_L15", "چه تعداد تبلیغ باید نمایش داده شود ؟");
define("BANNER_MENU_L16", "این قسمت توسط گزینه های 2 و 3 استفاده می شود.<br />اگر حداقل تبلیغات حاظر باشند مقدار ماکزیمم مورد استفاده قرار می گیرد.");
define("BANNER_MENU_L17", "تنظیم مقدار...");
define("BANNER_MENU_L18", "به روز رسانی تنظیمات منو");

?>