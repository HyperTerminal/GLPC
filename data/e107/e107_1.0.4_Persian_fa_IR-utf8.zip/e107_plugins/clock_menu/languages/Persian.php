<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1','تنظیمات ذخیره شد');
define('CLOCK_MENU_L2','عنوان');
define('CLOCK_MENU_L3','ذخیره تنظیمات');
define('CLOCK_MENU_L4','تنظیمات ساعت');
define('CLOCK_MENU_L5', 'دو شنبه,');
define('CLOCK_MENU_L6', 'سه شنبه,');
define('CLOCK_MENU_L7', 'چهارشنبه,');
define('CLOCK_MENU_L8', 'پنج شنبه,');
define('CLOCK_MENU_L9', 'جمعه,');
define('CLOCK_MENU_L10', 'شنبه,');
define('CLOCK_MENU_L11', 'یکشنبه,');
define('CLOCK_MENU_L12', 'ژانویه');
define('CLOCK_MENU_L13', 'فوریه');
define('CLOCK_MENU_L14', 'مارس');
define('CLOCK_MENU_L15', 'آوریل');
define('CLOCK_MENU_L16', 'مه');
define('CLOCK_MENU_L17', 'ژوئن');
define('CLOCK_MENU_L18', 'جولای');
define('CLOCK_MENU_L19', 'آگوست');
define('CLOCK_MENU_L20', 'سپتامبر');
define('CLOCK_MENU_L21', 'اکتبر');
define('CLOCK_MENU_L22', 'نوامبر');
define('CLOCK_MENU_L23', 'دسامبر');
define('CLOCK_MENU_L24', '');
?>