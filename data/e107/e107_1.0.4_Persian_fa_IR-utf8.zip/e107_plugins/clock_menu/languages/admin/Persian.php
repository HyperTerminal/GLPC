<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/admin/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "تنظیمات منوی ساعت ذخیره شد");
define("CLOCK_AD_L2", "عنوان");
define("CLOCK_AD_L3", "به روز رسانی تنظیمات منوی ساعت");
define("CLOCK_AD_L4", "تنظیمات منوی ساعت");
define("CLOCK_AD_L5", "قبل از ظهر/بعد از ظهر");
define("CLOCK_AD_L6", "اگر علامت زده شود, شما زمان را با فرمت آمریکا مشاهده خواهید کرد (0-12 قبل از ظهر/بعد از ظهر ). در غیر این صورت 'فرمت نظامی' یا فرمت 0-24 ساعت");
define("CLOCK_AD_L7", "پیشوند تاریخ");
define("CLOCK_AD_L8", "اگر زبان شما احتیاج به یک کلمه قبل از تاریخ دارد (مانند 'le' برای فرانسه یا 'den' برای آلمان...), در صورت نیاز از این قسمت استفاده کنید, و در غیر این صورت خالی رها کنید.");
define("CLOCK_AD_L9", "پسوند 1");
define("CLOCK_AD_L10", "پسوند 2");
define("CLOCK_AD_L11", "پسوند 3");
define("CLOCK_AD_L12", "پسوند 4 و بیشتر");
define("CLOCK_AD_L13", "اگر در زبان شما بعد از تاریخ نیار به یک کلمه است, این جدول ها را پر کنید (مثال: 'st' برای اول, 'nd' برای دوم, 'rd' برای سوم و 'th' برای چهارم و بیشتر برای کاربران انگلیسی). اگر نیاز نیست خالی رها کنید.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>