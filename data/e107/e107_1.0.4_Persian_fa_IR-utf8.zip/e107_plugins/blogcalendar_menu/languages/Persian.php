<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
	
define("BLOGCAL_L1", "اخبار در سال ");
define("BLOGCAL_L2", "آرشیو");
define("BLOGCAL_L3", "اخبار در ");

define("BLOGCAL_D1", "د");
define("BLOGCAL_D2", " س");
define("BLOGCAL_D3", "چ");
define("BLOGCAL_D4", "پ");
define("BLOGCAL_D5", "ج");
define("BLOGCAL_D6", "ش");
define("BLOGCAL_D7", "ی");
	
define("BLOGCAL_M1", "فروردین");
define("BLOGCAL_M2", "اردیبهشت");
define("BLOGCAL_M3", "خرداد");
define("BLOGCAL_M4", "تیر");
define("BLOGCAL_M5", "مرداد");
define("BLOGCAL_M6", "شهریور");
define("BLOGCAL_M7", "مهر");
define("BLOGCAL_M8", "آبان");
define("BLOGCAL_M9", "آذر");
define("BLOGCAL_M10", "دی");
define("BLOGCAL_M11", "بهمن");
define("BLOGCAL_M12", "اسفند");
	
define("BLOGCAL_1", "اخبار");
	
define("BLOGCAL_CONF1", "Months/row");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "ذخیره تنظیمات");
define("BLOGCAL_CONF4", "تنظیمات آرشیو");
define("BLOGCAL_CONF5", "تنظیمات ذخیره شد");
	
define("BLOGCAL_ARCHIV1", "انتخاب آرشیو");
	
?>