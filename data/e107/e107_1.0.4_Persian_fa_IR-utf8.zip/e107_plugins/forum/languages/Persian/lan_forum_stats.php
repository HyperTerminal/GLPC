<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "آمار انجمن");

define("FSLAN_1", "عمومی");
define("FSLAN_2", "تاریخ شروع به کار انجمن");
define("FSLAN_3", "شروع برای");
define("FSLAN_4", "مجموع ارسال ها");
define("FSLAN_5", "موضوعات انجمن");
define("FSLAN_6", "پاسخ های انجمن");
define("FSLAN_7", "دفعات بازدید از موضوعات انجمن");
define("FSLAN_8", "حجم دیتابیس انجمن");
define("FSLAN_9", "میانگین طول سطر ها");
define("FSLAN_10", "موضوعات محبوب و فعال");
define("FSLAN_11", "امتیاز");
define("FSLAN_12", "موضوع");
define("FSLAN_13", "پاسخ");
define("FSLAN_14", "شروع شده توسط");
define("FSLAN_15", "تاریخ");
define("FSLAN_16", " موضوعات با بیشترین بازدید");
define("FSLAN_17", "دفعات باردید");
define("FSLAN_18", "فعالترین کاربران");
define("FSLAN_19", "نام");
define("FSLAN_20", "ارسال ها");
define("FSLAN_21", "شروع کنندگان موضوعات مخبوب");
define("FSLAN_22", "فعالترین پاسخ دهندگان");
define("FSLAN_23", "آمار انجمن گفتگو");
define("FSLAN_24", "میانگین ارسال ها در هر روز");

?>