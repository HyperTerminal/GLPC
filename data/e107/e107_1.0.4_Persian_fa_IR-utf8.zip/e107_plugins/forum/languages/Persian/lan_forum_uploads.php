<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/24 20:43:34 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "آپلود های انجمن");

define('FRMUP_1','فایل آپلود شده در انجمن');
define('FRMUP_2','فایل حذف شد');
define('FRMUP_3','خطا: امکان حذف نیست');
define('FRMUP_4','حذف فایل');
define('FRMUP_5','نام فایل');
define('FRMUP_6','نتایج');
define('FRMUP_7','موجود در موضوع');
define('FRMUP_8','پیدا شد');
define('FRMUP_9','فایل آپلود شده پیدا نشد');
define('FRMUP_10','حذف');
	
?>