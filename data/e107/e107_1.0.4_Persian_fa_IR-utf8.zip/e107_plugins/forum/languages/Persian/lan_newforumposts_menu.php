<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/05/27 19:25:00 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
	
define("NFP_1", "تمام ارسال های جدید خارج از سطح دسترسی شما است, امکان مشاهده نیست.");
define("NFP_2", "بدون ارسال");
define("NFP_3", "تنظیمات ذخیره شد");
define("NFP_4", "عنوان");
define("NFP_5", "تعداد ارسال ها برای نمایش ؟");
define("NFP_6", "تعداد کاراکتر ها برای نمایش ؟");
define("NFP_7", "اصلاح متن های طولانی ؟");
define("NFP_8", "نمایش موضوعات اصلی در منو ؟");
define("NFP_9", "ذخیره تنظیمات");
define("NFP_10", "تنظیمات منوی آخرین ارسال های انجمن");
define("NFP_11", "ارسال شده توسط");
define("NFP_12", "حداکثر زمان نمایش ارسال ها");
define("NFP_13", "در حالت نرمال عدد صفر را انتخاب کنید.مگر در حالت شلوغی انجمن میتوانید برای آن مدت زمان خاصی در نظر بگیرید");
	
?>