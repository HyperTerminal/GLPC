// RU lang variables
tinyMCE.addI18n('ru.emoticons',{
	desc : 'Вставить смайлик'
});