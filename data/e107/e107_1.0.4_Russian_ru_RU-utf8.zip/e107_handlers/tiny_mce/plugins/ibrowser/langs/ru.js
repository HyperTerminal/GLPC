// RU lang variables
tinyMCE.addI18n('ru.ibrowser',{
	desc : 'Браузер Изображений'
});