<?php
/**
* PHPMailer language file.
* Russian UTF-8 Version
*/
	
$PHPMAILER_LANG = array();
	
$PHPMAILER_LANG['provide_address'] = 'Вы должны указать как минимум один почтовый адрес получателя.';
$PHPMAILER_LANG['mailer_not_supported'] = ' мейлер не поддерживается.';
$PHPMAILER_LANG['execute'] = 'Невозможно выполнить: ';
$PHPMAILER_LANG['instantiate'] = 'Невозможно инициализировать почтовые функции.';
$PHPMAILER_LANG['authenticate'] = 'Ошибка SMTP: Аутентификация не пройдена.';
$PHPMAILER_LANG['from_failed'] = 'Отправка с этого адреса не удалась: ';
$PHPMAILER_LANG['recipients_failed'] = 'Ошибка SMTP: Доставка следующим получателям не удалась: ';
$PHPMAILER_LANG['data_not_accepted'] = 'Ошибка SMTP: Данные не приняты.';
$PHPMAILER_LANG['connect_host'] = 'Ошибка SMTP: Невозможно соединиться с SMTP хостом.';
$PHPMAILER_LANG['file_access'] = 'Нет доступа к файлу: ';
$PHPMAILER_LANG['file_open'] = 'Файловая Ошибка: Невозможно открыть файл: ';
$PHPMAILER_LANG['encoding'] = 'Неизвестная кодировка: ';
$PHPMAILER_LANG['signing'] = 'Ошибка входа: ';
$PHPMAILER_LANG['smtp_error'] = 'Ошибка SMTP сервера: ';

?>