<?php
/*
+---------------------------------------------------------------+
|        e107 website system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/vekna_blue/languages/Russian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/02 18:37:50 $
|        $Author: root $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'vekna blue' by <a href='http://e107.org' rel='external'>jalist</a>, based on, and with permission from Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Читать/Комментировать");
define("LAN_THEME_3", "Комментарии отключены");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбэки:");


?>