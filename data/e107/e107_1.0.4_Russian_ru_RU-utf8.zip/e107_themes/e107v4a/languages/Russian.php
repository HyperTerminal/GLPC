<?php
/*
+---------------------------------------------------------------+
|        e107 website system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/e107v4a/languages/Russian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/02 18:27:59 $
|        $Author: root $
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "Читать/Комментировать");
define("LAN_THEME_2", "Комментарии отключены");
define("LAN_THEME_3", "Читать далее ...");
define("LAN_THEME_4", "Автор");
define("LAN_THEME_5", "на");
define("LAN_THEME_6", "e107.v4 theme by <a href='http://e107.org' rel='external'>jalist</a>");


?>