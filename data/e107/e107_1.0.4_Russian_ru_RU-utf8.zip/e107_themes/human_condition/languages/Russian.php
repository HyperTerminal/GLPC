<?php
/*
+---------------------------------------------------------------+
|        e107 website system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/human_condition/languages/Russian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/02 18:29:39 $
|        $Author: root $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' by <a href='http://e107.org' rel='external'>jalist</a>, на базе темы Wordpress, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Комментарии отключены");
define("LAN_THEME_3", "комментарии:");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбэки:");
define("LAN_THEME_6", "Автор комментария:");


?>