<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/core/languages/Russian.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/31 17:22:52 $
|        $Author: root $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Шаблон e107 Core <a href=\"http://e107.org\" title=\"e107 CMS\" rel=\"external\">e107 Inc.</a> Перевод  e107 Русский язык <a href=\"http://gnu.su\" title=\"e107 Russian localization\" rel=\"external\">e107 rus.</a>");
define("LAN_THEME_2", "Комментарии:");
define("LAN_THEME_3", "Комментарии выключены.");
define("LAN_THEME_4", "Читать польностью");
define("LAN_THEME_5", "Трекбэки");
define("LAN_THEME_8", "в");
define("LAN_THEME_9", "от ");
define("LAN_THEME_11", "Последние новости");
define("LAN_THEME_12", "Направить письмо другу");
define("LAN_THEME_13", "Создать PDF-файл");
define("LAN_THEME_14", "Печать");
define("LAN_THEME_15", "Редактировать");
define("LAN_THEME_17", "Вход");
define("LAN_THEME_18", "Имя пользователя");
define("LAN_THEME_19", "Пароль");
define("LAN_THEME_20", "Регистрация");
define("LAN_THEME_21", "Вход");
define("LAN_THEME_22", "Забыли пароль?");
define("LAN_THEME_23", "Привет!");
define("LAN_THEME_24", "Админ");
define("LAN_THEME_26", "Настройки");
define("LAN_THEME_27", "Профиль");
define("LAN_THEME_28", "Выход");
define("LAN_THEME_29", "Список новостей");
define("LAN_THEME_SING", "Вход");
define("LAN_THEME_REG", "Регистрация");
define("LAN_SEARCH", "Поиск");
define("LAN_SEARCH_SUB", "Пуск");
define("LAN_THEME_SHARE", "Поделиться");
define("LAN_THEME_VER", "e107 ");
define("CM_L13", "от");


?>