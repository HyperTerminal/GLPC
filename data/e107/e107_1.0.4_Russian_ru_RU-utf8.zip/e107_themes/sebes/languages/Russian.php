<?php
/*
+---------------------------------------------------------------+
|        e107 website system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/sebes/languages/Russian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/02 18:36:30 $
|        $Author: root $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'sebes' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Читать/Комментировать");
define("LAN_THEME_3", "Комментарии отключены");
define("LAN_THEME_4", "Читать далее ...");
define("LAN_THEME_5", "Трекбэки:");
define("LAN_THEME_6", "на");


?>