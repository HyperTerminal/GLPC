<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
	
define('CLOCK_MENU_L1', 'Конфигурация сохранена');
define('CLOCK_MENU_L2', 'Заголовок');
define('CLOCK_MENU_L3', 'Обновить настройки');
define('CLOCK_MENU_L4', 'Настройки меню Часов');
define('CLOCK_MENU_L5', 'Понедельник,');
define('CLOCK_MENU_L6', 'Вторник,');
define('CLOCK_MENU_L7', 'Среда,');
define('CLOCK_MENU_L8', 'Четверг,');
define('CLOCK_MENU_L9', 'Пятница,');
define('CLOCK_MENU_L10', 'Суббота,');
define('CLOCK_MENU_L11', 'Воскресенье,');
define('CLOCK_MENU_L12', 'Января');
define('CLOCK_MENU_L13', 'Февраля');
define('CLOCK_MENU_L14', 'Марта');
define('CLOCK_MENU_L15', 'Апреля');
define('CLOCK_MENU_L16', 'Мая');
define('CLOCK_MENU_L17', 'Июня');
define('CLOCK_MENU_L18', 'Июля');
define('CLOCK_MENU_L19', 'Августа');
define('CLOCK_MENU_L20', 'Сентября');
define('CLOCK_MENU_L21', 'Октября');
define('CLOCK_MENU_L22', 'Ноября');
define('CLOCK_MENU_L23', 'Декабря');
define('CLOCK_MENU_L24', '');
?>