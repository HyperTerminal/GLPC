<?php
/*
+---------------------------------------------------------------+
|        e107 website system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../plugins/featurebox/languages/Russian.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/03 14:33:42 $
|        $Author: andrey $
+---------------------------------------------------------------+
*/
define("FBLAN_01", "Feature Box");
define("FBLAN_02", "Этот плагин позволяет отображать поле над своими новостями с особенностями / с тем, что вам нравится. Сообщения могут быть либо случайно вращаться, либо динамически исчезать.");
define("FBLAN_03", "Конфигурировать ФьючерБокс");
define("FBLAN_04", "Feature Box плагин был успешно установлен. Для добавления сообщений, и настройки, вернитесь на главную страницу администратора и щелкните на пиктограмме окна в разделе плагинов.");
define("FBLAN_05", "Не задано ни одного сообщения для Feature Box");
define("FBLAN_06", "Существующие сообщения Feature Box");
define("FBLAN_07", "Название / Заголовок");
define("FBLAN_08", "Текст сообщения");
define("FBLAN_09", "Видимость сообщений");
define("FBLAN_10", "Создать сообщени Feature Box");
define("FBLAN_11", "Обновить сообщение Feature Box");
define("FBLAN_12", "Режим");
define("FBLAN_13", "Случайный");
define("FBLAN_14", "Отображать это сообщение только");
define("FBLAN_15", "Сообщение добавлено в базу данных");
define("FBLAN_16", "Сообщение обновлено в базе данных");
define("FBLAN_17", "Осталось незаполненных полей");
define("FBLAN_18", "Сообщение Feature Box удалено");
define("FBLAN_19", "Опции");
define("FBLAN_20", "Редактировать");
define("FBLAN_21", "Удалить");
define("FBLAN_22", "Тип отображения");
define("FBLAN_23", "В теме окне");
define("FBLAN_24", "Простой");
define("FBLAN_25", "Тема");
define("FBLAN_26", "Вы можете использовать различные шаблоны для каждого сообщения, добавлять шаблоны в e107_plugins/featurebox/templates / папку");


?>