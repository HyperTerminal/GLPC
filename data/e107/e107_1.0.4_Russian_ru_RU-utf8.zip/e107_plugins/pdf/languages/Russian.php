<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Поддержка создания PDF-документов");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Плагин готов к использованию.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Настройки PDF");
define("PDF_LAN_3", "вкл");
define("PDF_LAN_4", "выкл");
define("PDF_LAN_5", "отступ слева");
define("PDF_LAN_6", "отступ справа");
define("PDF_LAN_7", "отступ сверху");
define("PDF_LAN_8", "шрифт");
define("PDF_LAN_9", "размер шрифта по умолчанию");
define("PDF_LAN_10", "размер шрифта в имени сайта");
define("PDF_LAN_11", "размер шрифта для url страницы");
define("PDF_LAN_12", "размер шрифта для номера страницы");
define("PDF_LAN_13", "показать лого в pdf-документе?");
define("PDF_LAN_14", "показать имя сайта в pdf-документе?");
define("PDF_LAN_15", "показать url в pdf-документе?");
define("PDF_LAN_16", "показать номера страниц в pdf-документе?");
define("PDF_LAN_17", "обновить");
define("PDF_LAN_18", "Настройки PDF успешно обновлены");
define("PDF_LAN_19", "Страница");
define("PDF_LAN_20", "сообщения об ошибках");

?>