<?php
/*
+---------------------------------------------------------------+
|        e107 website system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../plugins/forum/languages/Russian/lan_forum_notify.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/13 14:59:41 $
|        $Author: andrey $
+---------------------------------------------------------------+
*/

define("NT_LAN_FT_1", "События форума");
define("NT_LAN_FO_1", "Создано тем форума");
define("NT_LAN_MP_1", "Создано сообщений форума");
define("NT_LAN_FD_1", "Удалено тем на форуме");
define("NT_LAN_FP_1", "Удалено сообщений на форуме");
define("NT_LAN_FM_1", "Тем фороума перемещено");
define("NT_LAN_FO_3", "Тема создана");
define("NT_LAN_FO_4", "Имя форума");
define("NT_LAN_FO_5", "Тема форума");
define("NT_LAN_FO_6", "Соосбщение");
define("NT_LAN_FO_7", "Новая тема форума создана");
define("NT_LAN_MP_3", "Сообщение создано");
define("NT_LAN_MP_4", "Имя форума");
define("NT_LAN_MP_6", "Сообщение");
define("NT_LAN_MP_7", "Новое сообщение сорума создано");
define("NT_LAN_FD_3", "Тема форума создана:");
define("NT_LAN_FD_4", "Название форума");
define("NT_LAN_FD_5", "Тема");
define("NT_LAN_FD_6", "Соосбщение");
define("NT_LAN_FD_7", "Тема удалена");
define("NT_LAN_FD_8", "Тема удалена");
define("NT_LAN_FP_3", "Соосбщение удалено");
define("NT_LAN_FP_4", "Имя форума");
define("NT_LAN_FP_6", "Соосбщение");
define("NT_LAN_FP_7", "Сообщение форума удалено");
define("NT_LAN_FP_8", "Сообщение форума удалено");
define("NT_LAN_FM_3", "Тема форума создана");
define("NT_LAN_FM_4", "Старая тема");
define("NT_LAN_FM_5", "Новая тема");
define("NT_LAN_FM_6", "Старое (исходное) название форума");
define("NT_LAN_FM_7", "Новое (обновленное) название форума");
define("NT_LAN_FM_8", "Тема форума перемещена");
define("NT_LAN_FM_9", "Тема форума перемещена");


?>