<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Russian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Russian_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/18 23:10:50 $
|        $Author: root $
+---------------------------------------------------------------+
*/

define("EC_LAN_RECUR_00", "Количество");
define("EC_LAN_RECUR_01", "ежегодно");
define("EC_LAN_RECUR_02", "раз в полгода");
define("EC_LAN_RECUR_03", "раз в квартал");
define("EC_LAN_RECUR_04", "раз в месяц");
define("EC_LAN_RECUR_05", "раз в четыре недели");
define("EC_LAN_RECUR_06", "раз в две недели");
define("EC_LAN_RECUR_07", "еженедельно");
define("EC_LAN_RECUR_08", "ежедневно");
define("EC_LAN_RECUR_100", "Раз в месяц в воскресение");
define("EC_LAN_RECUR_101", "Раз в месяц в понедельник");
define("EC_LAN_RECUR_102", "Раз в месяц во вторник");
define("EC_LAN_RECUR_103", "Раз в месяц в среду");
define("EC_LAN_RECUR_104", "Раз в месяц в четверг");
define("EC_LAN_RECUR_105", "Раз в месяц в пятницу");
define("EC_LAN_RECUR_106", "Раз в месяц в субботу");
define("EC_LAN_RECUR_1100", "Во-первых");
define("EC_LAN_RECUR_1200", "Во-вторых");
define("EC_LAN_RECUR_1300", "В-третьих");
define("EC_LAN_RECUR_1400", "В-четвертых");
define("NT_LAN_EC_1", "События календаря");
define("NT_LAN_EC_2", "Событие обновлено");
define("NT_LAN_EC_3", "Обновлено ");
define("NT_LAN_EC_4", "IP:");
define("NT_LAN_EC_5", "Сообщение");
define("NT_LAN_EC_6", "Календарь - событие добавлено");
define("NT_LAN_EC_7", "Новое событие добавлено");
define("NT_LAN_EC_8", "Календарь - Событие отредактировано");
define("EC_ADM_01", "Календарь - Добавить событие");
define("EC_ADM_02", "Календарь - Редактировать событие");
define("EC_ADM_03", "Календарь - Удалить событие");
define("EC_ADM_04", "Календарь - Удалить несколько событий");
define("EC_ADM_05", "Календарь - Добавить несколько событий");
define("EC_ADM_06", "Календарь - Основные настройки изменены");
define("EC_ADM_07", "Календарь - Настройки изменены (FE)");
define("EC_ADM_08", "Календарь - Категория добавлена");
define("EC_ADM_09", "Календарь - Категория изменена");
define("EC_ADM_10", "Календарь - Категория удалена");
define("EC_ADM_11", "Календарь - Старые события удалены");


?>