<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Сообщения пользователей");

define("UP_LAN_0", "Все сообщения форума для ");
define("UP_LAN_1", "Все комментарии от ");
define("UP_LAN_2", "Тема");
define("UP_LAN_3", "Просмотры"); //Views
define("UP_LAN_4", "Ответы");
define("UP_LAN_5", "Последнее сообщение");
define("UP_LAN_6", "Темы");
define("UP_LAN_7", "Нет комментариев");
define("UP_LAN_8", "Нет сообщений");
define("UP_LAN_9", " на ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Сообщено "); //Posted on
define("UP_LAN_12", "Поиск"); //Search
define("UP_LAN_13", "Комментарии");
define("UP_LAN_14", "Сообщения форума");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP адрес");
?>