<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("LAN_ADMINLOG_0", "Лог администратора");
define("LAN_ADMINLOG_1", "Дата");
define("LAN_ADMINLOG_2", "Заголовок");
define("LAN_ADMINLOG_3", "Описание");
define("LAN_ADMINLOG_4", "IP пользователя");
define("LAN_ADMINLOG_5", "ID пользователя");
define("LAN_ADMINLOG_6", "Значок информации"); 
define("LAN_ADMINLOG_7", "Сообщение информации"); 
define("LAN_ADMINLOG_8", "Значок уведомления"); 
define("LAN_ADMINLOG_9", "Сообщение уведомления"); 
define("LAN_ADMINLOG_10", "Значок предупреждения"); 
define("LAN_ADMINLOG_11", "Сообщение предупреждения"); 
define("LAN_ADMINLOG_12", "Значок ошибки");
define("LAN_ADMINLOG_13", "Сообщение ошибки"); 

?>