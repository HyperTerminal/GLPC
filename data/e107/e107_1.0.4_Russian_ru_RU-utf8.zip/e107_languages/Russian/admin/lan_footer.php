<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Сайт");
define("FOOTLAN_2", "Главный Администратор");
define("FOOTLAN_3", "Версия");
define("FOOTLAN_4", "сборка");
define("FOOTLAN_5", "Тема администратора");
define("FOOTLAN_6", "автор:");
define("FOOTLAN_7", "Информация");
define("FOOTLAN_8", "Дата установки");
define("FOOTLAN_9", "Сервер");
define("FOOTLAN_10", "хост");
define("FOOTLAN_11", "Версия PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Информация о сайте");
define("FOOTLAN_14", "Показать документацию");
define("FOOTLAN_15", "Документация");
define("FOOTLAN_16", "База данных");
define("FOOTLAN_17", "Кодировка");
define("FOOTLAN_18", "Тема сайта");
define("FOOTLAN_19", "Текущее время сервера");
define("FOOTLAN_20", "Уровень безопасности");


?>