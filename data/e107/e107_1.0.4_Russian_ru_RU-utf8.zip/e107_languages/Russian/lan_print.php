<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Страница для печати");}
define("LAN_PRINT_86", "Категория:");
define("LAN_PRINT_87", "автор");
define("LAN_PRINT_94", "Добавил"); //Posted by
define("LAN_PRINT_135", "Новость: ");
define("LAN_PRINT_303", "Источник этой новости ");
define("LAN_PRINT_304", "Заголовок: ");
define("LAN_PRINT_305", "Подзаголовок: ");
define("LAN_PRINT_306", "Источник: ");
define("LAN_PRINT_307", "Распечатать эту страницу");
define("LAN_PRINT_1", "для печати");


?>