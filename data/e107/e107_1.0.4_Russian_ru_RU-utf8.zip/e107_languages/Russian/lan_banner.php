<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Баннеры");

define("BANNERLAN_16", "Логин: ");
define("BANNERLAN_17", "Пароль: ");
define("BANNERLAN_18", "Продолжить");
define("BANNERLAN_19", "Введите логин и пароль клиента для продолжения");
define("BANNERLAN_20", "Извините, такие данные в БД не обнаружены. Пожалуйста, свяжитесь с администратором сайта для более конкретной информации.");
define("BANNERLAN_21", "Статистика Баннеров");
define("BANNERLAN_22", "Клиент");
define("BANNERLAN_23", "ID баннера");
define("BANNERLAN_24", "Переходов");
define("BANNERLAN_25", "Нажатий %");
define("BANNERLAN_26", "Показов");
define("BANNERLAN_27", "Показов приобретено");
define("BANNERLAN_28", "Показов истрачено");
define("BANNERLAN_29", "Нет баннеров");
define("BANNERLAN_30", "Неограниченно");
define("BANNERLAN_31", "Неприменимо");
define("BANNERLAN_32", "Да");
define("BANNERLAN_33", "Нет");
define("BANNERLAN_34", "Окончание:");
define("BANNERLAN_35", "Переходов с IP-адресов");
define("BANNERLAN_36", "Активно:");
define("BANNERLAN_37", "Начало:");
define("BANNERLAN_38", "Ошибка");

?>