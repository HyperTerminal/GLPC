<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_THEME_1", "'kubrick' by <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> & <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Based on original theme by Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Коментарите са забранени");
define("LAN_THEME_3", "коментари:");
define("LAN_THEME_4", "Прочети още ...");
define("LAN_THEME_5", "Проследяване:");
define("LAN_THEME_6", "на");
define("LAN_THEME_7", "от");