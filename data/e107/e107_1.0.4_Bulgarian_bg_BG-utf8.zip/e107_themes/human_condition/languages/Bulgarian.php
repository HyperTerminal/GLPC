<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_THEME_1", "'Human Condition' от <a href='http://e107.org' rel='external'>jalist</a>, базирана на тема от  Wordpress <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Коментарите са забранени");
define("LAN_THEME_3", "коментари :");
define("LAN_THEME_4", "Прочети още ...");
define("LAN_THEME_5", "Проследяване:");
define("LAN_THEME_6", "Коментар от");