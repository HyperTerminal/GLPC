<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_THEME_1", "'vekna blue' от <a href='http://e107.org' rel='external'>jalist</a>, базирана на, и с разрешението на Arach's сайта, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Прочети/Остави Коментар: ");
define("LAN_THEME_3", "Коментарите са изключени");
define("LAN_THEME_4", "Прочети още...");
define("LAN_THEME_5", "Проследяване: ");