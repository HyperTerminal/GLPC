<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("BANNER_MENU_L1", "Реклама");
define("BANNER_MENU_L2", "Настройките на меню Реклама са запазени");
define("BANNER_MENU_L3", "Заглавие");
define("BANNER_MENU_L4", "Кампания");
define("BANNER_MENU_L5", "Настройки на меню Реклама");
define("BANNER_MENU_L6", "Изберете кампания за показване в менюто");
define("BANNER_MENU_L7", "Налични кампании");
define("BANNER_MENU_L8", "Избрани кампании");
define("BANNER_MENU_L9", "Премахване на избраните");
define("BANNER_MENU_L10", "Как да бъдат показвани избраните кампании ?");
define("BANNER_MENU_L11", "Избери начин на показване ...");
define("BANNER_MENU_L12", "По една кампания в отделно меню");
define("BANNER_MENU_L13", "Всички избрани кампании в едно меню");
define("BANNER_MENU_L14", "Всички избрани кампании в различни менюта");
define("BANNER_MENU_L15", "Колко банери да бъдат показани ?");
define("BANNER_MENU_L16", "Тази настройка ще бъде ползвана само с опции 2 и 3.<br />Ако има по-малко налични банери, ще бъде използван максималният наличен брой банери.");
define("BANNER_MENU_L17", "Задай брой ...");
define("BANNER_MENU_L18", "Актуализиране на меню настройки");