<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("TRACKBACK_L1", "Конфигуриране на Проследяване");
define("TRACKBACK_L2", "Този плъгин ви позволява да използвате проследяване във постовете ви.");
define("TRACKBACK_L3", "Модула Проследяване е инсталиран.");
define("TRACKBACK_L4", "Настройките са запазени.");
define("TRACKBACK_L5", "Вкл.");
define("TRACKBACK_L6", "Изкл.");
define("TRACKBACK_L7", "Активирай проследяване");
define("TRACKBACK_L8", "Проследяване URL текст");
define("TRACKBACK_L9", "Запази Настройките");
define("TRACKBACK_L10", "Проследяване Настройки");
define("TRACKBACK_L11", "Проследи:");
define("TRACKBACK_L12", "Няма проследявания за тази публикация");
define("TRACKBACK_L13", "Редактирай проследяванията");
define("TRACKBACK_L14", "Изтрий");
define("TRACKBACK_L15", "Проследяванията изтрити.");