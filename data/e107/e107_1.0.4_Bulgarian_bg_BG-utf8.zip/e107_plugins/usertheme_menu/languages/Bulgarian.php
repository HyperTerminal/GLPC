<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_UMENU_THEME_1", "Задай тема");
define("LAN_UMENU_THEME_2", "Избери тема");
define("LAN_UMENU_THEME_3", "потребители:");
define("LAN_UMENU_THEME_4", "Активирай темите, от които потребителите ще избират");
define("LAN_UMENU_THEME_5", "Обнови");
define("LAN_UMENU_THEME_6", "Темата е достъпна до потребители");
define("LAN_UMENU_THEME_7", "Клас потребители, които могат да избират теми");