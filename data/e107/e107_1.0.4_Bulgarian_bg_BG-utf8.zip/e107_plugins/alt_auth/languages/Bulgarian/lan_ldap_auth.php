<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LDAPLAN_1", "Адрес на сървъра");
define("LDAPLAN_2", "Избери Base DN или Domain<br />При LDAP - Въведи BaseDN<br />При AD - Въведи Domain");
define("LDAPLAN_3", "LDAP Браузване потребител<br />Пълен контекст на потребител, който може да търси в директорията.");
define("LDAPLAN_4", "LDAP Браузване парола<br />Паролата за  LDAP Браузване потребител.");
define("LDAPLAN_5", "LDAP Версия");
define("LDAPLAN_6", "Конфигурирай LDAP ауторизация");
define("LDAPLAN_7", "eDirectory филтър за търсене:");
define("LDAPLAN_8", "Това ще се използва за подсигуряване, че потребителското име е в правилното дърво, <br />като '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Текущият филтър за търсене ще бъде:");

define("LDAPLAN_10", "ВНИМАНИЕ: Изглежда, че LDAP модула в момента не е наличен и насочването на ауторизационния метод към LDAP вероятно няма да работи!");
define("LDAPLAN_11", "Сървър тип");
define("LDAPLAN_13", "Обнови настройките");