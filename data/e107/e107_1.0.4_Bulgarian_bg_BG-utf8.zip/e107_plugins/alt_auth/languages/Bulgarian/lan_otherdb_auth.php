<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("OTHERDB_LAN_1", "Тип база данни:");
define("OTHERDB_LAN_2", "Сървър:");
define("OTHERDB_LAN_3", "Потребителско име:");
define("OTHERDB_LAN_4", "Парола:");
define("OTHERDB_LAN_5", "База данни");
define("OTHERDB_LAN_6", "Таблица");
define("OTHERDB_LAN_7", "Поле на потребителя:");
define("OTHERDB_LAN_8", "Поле за паролата:");
define("OTHERDB_LAN_9", "Метод за паролата:");
define("OTHERDB_LAN_10", "Конфигурирай ауторизация с друга база данни");
define("OTHERDB_LAN_11", "** Следващите полета не са задължителни, ако използвате база данни на e107");