<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_ALT_2", "Текущ ауторизационен тип");
define("LAN_ALT_3", "Избери алтернативен ауторизационен тип");
define("LAN_ALT_4", "Конфигурирай параметрите за");
define("LAN_ALT_5", "Конфигурирай параметрите за ауторизация");
define("LAN_ALT_6", "Провалено свързване");
define("LAN_ALT_7", "Ако връзката с алтернативен метод се провали, как трябва това да се обработи?");
define("LAN_ALT_8", "Потребител не е намерен");
define("LAN_ALT_9", "Ако потребителско име не е намерено с помощта на алтернативния метод, как трябва това да се обработи?");
define("LAN_ALT_10", "Провалено влизане");
define("LAN_ALT_11", "Използвай потребителската таблица на e107");

define('LAN_ALT_PAGE', 'Алтернативна ауторизация');