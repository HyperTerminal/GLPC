<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("ONLINE_EL1", "Гости:");
define("ONLINE_EL2", "Регистрирани:");
define("ONLINE_EL3", "На тази странница:");
define("ONLINE_EL4", "Онлайн");
define("ONLINE_EL5", "Регистрирани");
define("ONLINE_EL6", "Най-новият регистриран");
define("ONLINE_EL7", "преглежда:");
define("ONLINE_EL8", "Най-много онлайн:");
define("ONLINE_EL9", "на");
define("ONLINE_TRACKING_MESSAGE", "Онлайн проследяването за  потребителите е изключено. Може да го включите от [link=".e_ADMIN."users.php?options]тук[/link][br]");