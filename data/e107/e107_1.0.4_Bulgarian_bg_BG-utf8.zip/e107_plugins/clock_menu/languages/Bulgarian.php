<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("CLOCK_MENU_L1", "Настройките на меню Часовник са записани");
define("CLOCK_MENU_L2", "Заглавие");
define("CLOCK_MENU_L3", "Обновяване на настройките на менюто");
define("CLOCK_MENU_L4", "Настройки на меню Часовник");
define("CLOCK_MENU_L5", "Понеделник,");
define("CLOCK_MENU_L6", "Вторник,");
define("CLOCK_MENU_L7", "Сряда,");
define("CLOCK_MENU_L8", "Четвъртък,");
define("CLOCK_MENU_L9", "Петък,");
define("CLOCK_MENU_L10", "Събота,");
define("CLOCK_MENU_L11", "Неделя,");
define("CLOCK_MENU_L12", "Януари");
define("CLOCK_MENU_L13", "Февруари");
define("CLOCK_MENU_L14", "Март");
define("CLOCK_MENU_L15", "Април");
define("CLOCK_MENU_L16", "Май");
define("CLOCK_MENU_L17", "Юни");
define("CLOCK_MENU_L18", "Юли");
define("CLOCK_MENU_L19", "Август");
define("CLOCK_MENU_L20", "Септември");
define("CLOCK_MENU_L21", "Октомври");
define("CLOCK_MENU_L22", "Ноември");
define("CLOCK_MENU_L23", "Декември");
define("CLOCK_MENU_L24", "");