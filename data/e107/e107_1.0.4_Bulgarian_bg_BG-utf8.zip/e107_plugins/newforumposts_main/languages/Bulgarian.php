<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("NFPM_LAN_1", "Тема");
define("NFPM_LAN_2", "Автор");
define("NFPM_LAN_3", "Преглеждания");
define("NFPM_LAN_4", "Отговори");
define("NFPM_LAN_5", "Последен отговор");
define("NFPM_LAN_6", "Теми");
define("NFPM_LAN_7", "от");
define("NFPM_L1", "Този модул показва на заглавната страница списък с последните постове във форума ");
define("NFPM_L2", "Последно от Форума");
define("NFPM_L3", "За конфигуриране, моля кликнете на линка в плъгин секцията на главната страница в Администрация");
define("NFPM_L4", "В коя зона да е активно?");
define("NFPM_L5", "Неактивно");
define("NFPM_L6", "Най-отгоре на странницата");
define("NFPM_L7", "Най-отдолу на странницата");
define("NFPM_L8", "Заглавие");
define("NFPM_L9", "Брой на нови съобщения за показване?");
define("NFPM_L10", "Показване на скрол?");
define("NFPM_L11", "Височина на таблицата");
define("NFPM_L12", "Настройка на Последно от Форума");
define("NFPM_L13", "Обновяване на настройките");
define("NFPM_L14", "Настройката на Последно от Форума е обновена.");
define("NFPM_L15", "Използвай за показване на последните съобщения във форума.<br />По подразбиране са последните теми.");
define("NFPM_L16", "[потребителя е изтрит]");
define("NFPM_L17", "Нови съобщения в Популярни теми");
define("NFPM_L18", "Нови съобщения");
define("NFPM_L19", "Няма нови съобщения в Популярни теми");
define("NFPM_L20", "Няма нови съобщения");
define("NFPM_L21", "Важна тема");
define("NFPM_L22", "Заключена важна тема");
define("NFPM_L23", "Известие");
define("NFPM_L24", "Заключена тема");