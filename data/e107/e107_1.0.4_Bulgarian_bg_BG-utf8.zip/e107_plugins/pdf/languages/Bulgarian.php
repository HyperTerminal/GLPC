<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF помощ за създаване");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Този плъгин е готов за използване.");
define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF настройки");
define("PDF_LAN_3", "включено");
define("PDF_LAN_4", "изключено");
define("PDF_LAN_5", "страницата от ляво");
define("PDF_LAN_6", "страницата от дясно");
define("PDF_LAN_7", "страницата горе");
define("PDF_LAN_8", "вид на шрифта");
define("PDF_LAN_9", "размер на шрифта по подразбиране");
define("PDF_LAN_10", "размер на шрифта на името на сайта");
define("PDF_LAN_11", "размер на шрифта на url на страницата");
define("PDF_LAN_12", "размер на шрифта на номер на страницата");
define("PDF_LAN_13", "да покаже ли лого в pdf?");
define("PDF_LAN_14", "да покаже ли името на сайта в pdf?");
define("PDF_LAN_15", "да покаже ли автора на сайта url в pdf?");
define("PDF_LAN_16", "да покаже ли номера на страницата в pdf?");
define("PDF_LAN_17", "обнови");
define("PDF_LAN_18", "PDF настройките са запазени успешно");
define("PDF_LAN_19", "Страница");
define("PDF_LAN_20", "рапорт за грешки");