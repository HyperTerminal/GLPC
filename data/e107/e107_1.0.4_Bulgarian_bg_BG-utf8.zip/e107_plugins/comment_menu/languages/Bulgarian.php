<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("CM_L1", "Все още няма коментари.");
define("CM_L2", "");
define("CM_L3", "Заглавие");
define("CM_L4", "Брой коментари за показване?");
define("CM_L5", "Брой на знаци за показване?");
define("CM_L6", "Постфикс за дълги коментари?");
define("CM_L7", "Показване на заглавието на новината в менюто?");
define("CM_L8", "Настройки на меню Нови Коментари");
define("CM_L9", "Обновяване на настройките на менюто");
define("CM_L10", "Настройките на менюто са запазени");
define("CM_L11", "на");
define("CM_L12", "Отговор:");
define("CM_L13", "Публикувано от");