<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("ONLINE_L1", "Гости: ");
define("ONLINE_L2", "Регистрирани: ");
define("ONLINE_L3", "На тази странница: ");
define("ONLINE_L4", "Онлайн");
define("ONLINE_L5", "Регистрирани");
define("ONLINE_L6", "най-новият");
define("TRACKING_MESSAGE", "Проследяване на потребителя е изключено, моля включете го от [link=".e_ADMIN."users.php?options]тук[/link][br]");