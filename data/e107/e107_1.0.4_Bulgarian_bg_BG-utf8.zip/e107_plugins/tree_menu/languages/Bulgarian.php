<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("TREE_L1", "Настройка на дървовидно меню");
define("TREE_L2", "Обнови настройките на дървовидното меню");
define("TREE_L3", "Настройките на дървовидното меню са запазени.");
define("TREE_L4", "Вкл.");
define("TREE_L5", "Изкл.");
define("TREE_L6", "CSS клас за не неотваряеми линкове");
define("TREE_L7", "CSS клас за отваряеми линкове");
define("TREE_L8", "CSS клас за отворени линкове");
define("TREE_L9", "Използвай клас за празно пространство между главните линкове");