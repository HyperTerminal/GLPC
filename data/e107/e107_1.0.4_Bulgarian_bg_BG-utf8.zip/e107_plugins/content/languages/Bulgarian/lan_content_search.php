<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("CONT_SCH_LAN_1", "Публикации");
define("CONT_SCH_LAN_2", "Всички категории публикации");
define("CONT_SCH_LAN_3", "Публикувано като отговор на");
define("CONT_SCH_LAN_4", "в");