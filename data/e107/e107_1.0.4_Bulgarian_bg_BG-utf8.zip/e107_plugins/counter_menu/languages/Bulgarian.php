<?php
/*
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("COUNTER_L1", "Визитите на админите не се отчитат от брояча.");
define("COUNTER_L2", "Тази странница днес ...");
define("COUNTER_L3", "общо");
define("COUNTER_L4", "Тази странница общо ...");
define("COUNTER_L5", "уникални");
define("COUNTER_L6", "Сайт ...");
define("COUNTER_L7", "Брояч");
define("COUNTER_L8", "Системно Съобщение: <b>Статистиката на сайта не е активна.</b><br />За да я активирате, е нужно да инсталирате модул Статистика от Вашият <a href='".e_ADMIN."plugin.php'>модул менаджер</a>, след това да я активирате от <a href='".e_PLUGIN."log/admin_config.php'>настройките на екрана</a>.");