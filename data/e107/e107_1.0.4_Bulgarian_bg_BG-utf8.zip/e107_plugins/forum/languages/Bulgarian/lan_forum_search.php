<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("FOR_SCH_LAN_1", "Форум");
define("FOR_SCH_LAN_2", "Избери Форум");
define("FOR_SCH_LAN_3", "Всички Форуми");
define("FOR_SCH_LAN_4", "Цялото съобщение");
define("FOR_SCH_LAN_5", "Като част от тема");