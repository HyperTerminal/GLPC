<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Добавяне на файлове във Форума");
define("FRMUP_1", "Добавени файлове във Форума");
define("FRMUP_2", "Файла е изтрит");
define("FRMUP_3", "Грешка: Не е възможно да се изтрие файла");
define("FRMUP_4", "Изтриване на файл");
define("FRMUP_5", "Име на файл");
define("FRMUP_6", "Резултат");
define("FRMUP_7", "Намерен в тема");
define("FRMUP_8", "НЕ Е НАМЕРЕН");
define("FRMUP_9", "Не са намерени добавени файлове");
define("FRMUP_10", "Изтрий");