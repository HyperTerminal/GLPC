<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("e_PAGETITLE", "Статистика на Форума");
define("FSLAN_1", "Главна");
define("FSLAN_2", "Форума е стартиран на");
define("FSLAN_3", "Отворен от");
define("FSLAN_4", "Общо съобщения");
define("FSLAN_5", "Общо теми");
define("FSLAN_6", "Отговори");
define("FSLAN_7", "Брой преглеждания на темите");
define("FSLAN_8", "Големина на базата данни (само таблиците от форума)");
define("FSLAN_9", "Средна дължина на ред във таблицата на форума");
define("FSLAN_10", "Най-активни теми");
define("FSLAN_11", "Ранг");
define("FSLAN_12", "Тема");
define("FSLAN_13", "Отговори");
define("FSLAN_14", "Стартирана от");
define("FSLAN_15", "Дата");
define("FSLAN_16", "Най-преглеждани теми");
define("FSLAN_17", "Преглеждания");
define("FSLAN_18", "Най-много публикували");
define("FSLAN_19", "Име");
define("FSLAN_20", "Отговора");
define("FSLAN_21", "Най-много потребители стартирали теми");
define("FSLAN_22", "Най-много отговаряли");
define("FSLAN_23", "Статистика на Форума");
define("FSLAN_24", "Средно отговора на ден");