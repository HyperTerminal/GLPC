<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$PHPMAILER_LANG = array();
$PHPMAILER_LANG["provide_address"] = 'Трябва да зададете най-малко един имейл адрес за получател.';
$PHPMAILER_LANG["mailer_not_supported"] = ' имейл метод не се поддържа.';
$PHPMAILER_LANG["execute"] = 'Не мога да стартирам: ';
$PHPMAILER_LANG["instantiate"] = 'Не мога да създам обект на имейл функция.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Error: Could not authenticate.';
$PHPMAILER_LANG["from_failed"] = 'Изпращане до следния From адрес не беше успешно: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP грешка: Изпращане до следните поучатели не бше успешно: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP грешка: Данните не са приети.';
$PHPMAILER_LANG["connect_host"] = 'SMTP грешка: Невъзможно е свързването с SMTP хоста.';
$PHPMAILER_LANG["file_access"] = 'Няма достъп до файл: ';
$PHPMAILER_LANG["file_open"] = 'Файл грешка: Не мога да отворя файл: ';
$PHPMAILER_LANG["encoding"] = 'Непознат енкодинг: ';
$PHPMAILER_LANG['signing']  = 'Грешка: ';
$PHPMAILER_LANG['smtp_error'] = 'SMTP грешка: ';