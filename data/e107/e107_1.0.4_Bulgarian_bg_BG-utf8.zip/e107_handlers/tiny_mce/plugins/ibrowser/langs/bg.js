// BG lang variables
tinyMCE.addI18n('bg.ibrowser',{
	desc : 'Избор на картинки'
});