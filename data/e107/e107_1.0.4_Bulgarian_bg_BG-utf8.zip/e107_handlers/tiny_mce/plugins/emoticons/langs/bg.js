// BG lang variables

tinyMCE.addI18n('bg.emoticons',{
	desc : 'Вмъкни емоция'
});