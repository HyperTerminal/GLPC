<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("TOP_LAN_0", "Най-активни във форума");
define("TOP_LAN_1", "Име");
define("TOP_LAN_2", "Съобщения");
define("TOP_LAN_3", "Най-активни в коментари");
define("TOP_LAN_4", "Коментари");
define("TOP_LAN_5", "Най-активни в чат");
define("TOP_LAN_6", "Рейтинг за сайта");
define("LAN_1", "Тема");
define("LAN_2", "Потребител");
define("LAN_3", "Преглеждания");
define("LAN_4", "Отговори");
define("LAN_5", "Последни съобщения");
define("LAN_6", "Теми");
define("LAN_7", "Най-популярни теми");
define("LAN_8", "Най-активни потребители");