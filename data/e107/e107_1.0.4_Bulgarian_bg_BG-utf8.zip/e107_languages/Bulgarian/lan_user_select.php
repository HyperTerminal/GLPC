<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("US_LAN_1", "Избери потребител");
define("US_LAN_2", "Избери потребителски клас");
define("US_LAN_3", "Всички потребители");
define("US_LAN_4", "Намери потребителско име");
define("US_LAN_5", "Намерен(и) потребител(и)");
define("US_LAN_6", "Търси");