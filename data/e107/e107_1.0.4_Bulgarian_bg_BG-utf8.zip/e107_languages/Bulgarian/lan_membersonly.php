<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Само за Потребители");
define("LAN_MEMBERS_0", "зона с ограничен достъп");
define("LAN_MEMBERS_1", "Това е зона с ограничен достъп");
define("LAN_MEMBERS_2", "За осигуряване на достъп <a href='login.php'>се логни</a> или");
define("LAN_MEMBERS_3", "се <a href='".e_SIGNUP."'>регистрирай</a> като потребител");
define("LAN_MEMBERS_4", "Натисни тук за връщане към главната страница");