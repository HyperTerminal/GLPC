<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("ONLINE_EL1", "Гости:");
define("ONLINE_EL2", "Потребители:");
define("ONLINE_EL3", "На тази страница:");
define("ONLINE_EL4", "Онлайн");
define("ONLINE_EL5", "Потребители");
define("ONLINE_EL6", "Най-нов потребител");
define("ONLINE_EL7", "преглежда");
define("ONLINE_EL8", "най-много онлайн:");
define("ONLINE_EL9", "на");
define("ONLINE_EL10", "Име");
define("ONLINE_EL11", "Гледа страница");
define("ONLINE_EL12", "Отговаря на");
define("ONLINE_EL13", "Форум");
define("ONLINE_EL14", "Тема");
define("ONLINE_EL15", "Страница");
define("CLASSRESTRICTED", "Ограничена от клас страница");
define("ARTICLEPAGE", "Статии/Рецензии");
define("CHAT", "Чат");
define("COMMENT", "Коментари");
define("DOWNLOAD", "Файлове");
define("EMAIL", "Имейл");
define("FORUM", "Форум - Заглавна страница");
define("LINKS", "Линкове");
define("NEWS", "Новини");
define("OLDPOLLS", "Стари Анкети");
define("POLLCOMMENT", "Анкета");
define("PRINTPAGE", "Принт");
define("LOGIN", "Логва се");
define("SEARCH", "Търси");
define("STATS", "Статистика на сайта");
define("SUBMITNEWS", "Пише новина");
define("UPLOAD", "Качва файл");
define("USERPAGE", "Потребителски профили");
define("USERSETTINGS", "Потребителски настройки");
define("ONLINE", "Потребители Онлайн");
define("LISTNEW", "Списък всичко ново");
define("USERPOSTS", "Потребителски публикации");
define("SUBCONTENT", "Публикува Статия/Рецензия");
define("TOP", "Най-активни Потребители/Теми");
define("ADMINAREA", "Администрация");
define("BUGTRACKER", "е107 Грешки");
define("EVENT", "Списък събития");
define("CALENDAR", "Календар");
define("FAQ", "Faq");
define("PM", "Лични съобщения");
define("SURVEY", "Проучване");
define("ARTICLE", "Статия");
define("CONTENT", "Страница - съдържание");
define("REVIEW", "Рецензия");