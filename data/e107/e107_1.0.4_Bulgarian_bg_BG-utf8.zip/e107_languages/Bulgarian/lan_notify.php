<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("NT_LAN_US_1", "Регистрация на потребител");
define("NT_LAN_UV_1", "Регистрацията е потвърдена");
define("NT_LAN_UV_2", "Потребителско ID:");
define("NT_LAN_UV_3", "Име за вход на потребителя:");
define("NT_LAN_UV_4", "Потребителско IP:");
define("NT_LAN_LI_1", "Логнат потребител");
define("NT_LAN_LO_1", "Излязъл потребител");
define("NT_LAN_LO_2", " излезе  от сайта");
define("NT_LAN_FL_1", "Забрана поради Flood");
define("NT_LAN_FL_2", "Забрана на IP адрес за flooding");
define("NT_LAN_SN_1", "Записана е новина");
define("NT_LAN_NU_1", "Актуализирано");
define("NT_LAN_ND_1", "Изтрита новина");
define("NT_LAN_ND_2", "ID на изтритата новина");
define("NT_LAN_CM_1", "Коментари чакащи одобрение");