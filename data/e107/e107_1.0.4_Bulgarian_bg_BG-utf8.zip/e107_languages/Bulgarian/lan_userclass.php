<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("UC_LAN_0", "Всеки (public)");
define("UC_LAN_1", "Гости");
define("UC_LAN_2", "Никой (неактивно)");
define("UC_LAN_3", "Потребители");
define("UC_LAN_4", "Само за четене");
define("UC_LAN_5", "Админ");
define("UC_LAN_6", "Главен Администратор");

define('UC_LAN_9','Нови потребители');
define('UC_LAN_10', 'Търсещи машини');