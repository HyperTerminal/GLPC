<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Потребителски публикации");
define("UP_LAN_0", "Всички публикации на форума за ");
define("UP_LAN_1", "Всички коментари за ");
define("UP_LAN_2", "Тема");
define("UP_LAN_3", "Преглеждания");
define("UP_LAN_4", "Отговори");
define("UP_LAN_5", "Последни публикации");
define("UP_LAN_6", "Теми");
define("UP_LAN_7", "Няма коментари");
define("UP_LAN_8", "Няма публикации");
define("UP_LAN_9", " на ");
define("UP_LAN_10", "В отговор на");
define("UP_LAN_11", "Написано на: ");
define("UP_LAN_12", "Търсене");
define("UP_LAN_13", "Коментари");
define("UP_LAN_14", "Публикации на форума");
define("UP_LAN_15", "В отговор на");
define("UP_LAN_16", "IP Адрес");