<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Емайл");
define("LAN_EMAIL_1", "От:");
define("LAN_EMAIL_2", "IP адрес на подателя:");
define("LAN_EMAIL_3", "Изпратено от ");
define("LAN_EMAIL_4", "Изпрати емайл");
define("LAN_EMAIL_5", "Изпрати на приятел");
define("LAN_EMAIL_6", "Мисля, че ще ти бъде интересно да прочетеш това от");
define("LAN_EMAIL_7", "изпрати на приятел");
define("LAN_EMAIL_8", "Коментар");
define("LAN_EMAIL_9", "Съжаляваме - емайлът не беше изпратен");
define("LAN_EMAIL_10", "Изпратен е емайл до");
define("LAN_EMAIL_11", "Емайлът е изпратен");
define("LAN_EMAIL_12", "Грешка");
define("LAN_EMAIL_13", "Изпрати статия на приятел");
define("LAN_EMAIL_14", "Изпрати новина на приятел");
define("LAN_EMAIL_15", "Потребителско име: ");
define("LAN_EMAIL_106", "Това не изглежда да е валиден емайл адрес");
define("LAN_EMAIL_185", "Изпрати статия");
define("LAN_EMAIL_186", "Изпрати новина");
define("LAN_EMAIL_187", "Изпрати на имейл адрес");
define("LAN_EMAIL_188", "Мисля, че ще ти бъде интересно да прочетеш тази новина от");
define("LAN_EMAIL_189", "Мисля, че ще ти бъде интересно да прочетеш тази статия от");
define("LAN_EMAIL_190", "Въведи код");