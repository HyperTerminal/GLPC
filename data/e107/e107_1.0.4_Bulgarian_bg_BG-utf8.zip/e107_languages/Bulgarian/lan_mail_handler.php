<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LANMAILH_1", "Генерирано от e107 уебсайт система");
define("LANMAILH_2", "Това е multi-part съобщение в MIME формат.");
define("LANMAILH_3", " е неправилно форматирано");
define("LANMAILH_4", "Сървърът отказа адреса");
define("LANMAILH_5", "Няма отговор от сървъра");
define("LANMAILH_6", "Не мога да открия E-Mail сървър.");
define("LANMAILH_7", " изглежда е валиден.");