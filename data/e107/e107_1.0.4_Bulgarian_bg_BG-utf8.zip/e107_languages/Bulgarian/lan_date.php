<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LANDT_01", "година");
define("LANDT_02", "месец");
define("LANDT_03", "седмица");
define("LANDT_04", "ден");
define("LANDT_05", "час");
define("LANDT_06", "минута");
define("LANDT_07", "секунда");
define("LANDT_01s", "години");
define("LANDT_02s", "месеца");
define("LANDT_03s", "седмици");
define("LANDT_04s", "дни");
define("LANDT_05s", "часа");
define("LANDT_06s", "минути");
define("LANDT_07s", "секунди");
define("LANDT_08", "мин");
define("LANDT_08s", "мин");
define("LANDT_09", "сек");
define("LANDT_09s", "сек");
define("LANDT_AGO", "по-рано");