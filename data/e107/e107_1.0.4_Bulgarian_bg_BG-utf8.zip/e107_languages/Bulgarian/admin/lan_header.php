<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_head_1", "Навигация");
define("LAN_head_2", "Вашият сървър не позволява HTTP добавяне на файлове, така че е възможно потребителите да не могат да добавят файлове или аватари. За да го коригирате, настройте file_uploads на On в php.ini и рестартирайте сървъра. Ако нямате достъп до php.ini свържете се с хостинг доставчика Ви.");
define("LAN_head_3", "Вашият сървър е стартиран с базова директория която е ограничена. Това спира достъпа до файловете във вашата директория и прави невъзможно използването на файловият мениджър на сайта.");
define("LAN_head_4", "Администриране");
define("LAN_head_5", "език за показване в административната част:");
define("LAN_head_6", "Информация за модулите");