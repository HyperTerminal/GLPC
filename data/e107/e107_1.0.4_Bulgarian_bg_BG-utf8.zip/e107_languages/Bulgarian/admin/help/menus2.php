﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$caption = "Меню Помощ";
$text .= "Можете да изберете къде и в какъв ред да бъдат менютата на сайта ви от тук. Използвайте менюто Функции за да преместите всяко меню до желаната позиция.<br />Менютата в средата на екрана са неактивни, можете да ги активирате като ги маркирате и изберете областа за активиране.";
$ns -> tablerender("Меню - Помощ", $text);