﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Тази страница ви позволява да включите съобщение което ще се показва най отгоре на главната ви страница и ще е активно през цялото време. Можете да настроите различни съобщения за гостите на сайта ви, за регистрирани потребители /включени потребители и за администраторите.";
$ns -> tablerender("Начално съобщение - Помощ", $text);