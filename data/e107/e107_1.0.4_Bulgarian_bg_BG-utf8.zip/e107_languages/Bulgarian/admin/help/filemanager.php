﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да менаджирате файловете си във вашата  /files директория от тази страница. Ако получавате съобщение за грешка относно правата за запис когато качвате файла моля променете правата за писане CHMOD на директорията в която ще ги съхранявате на 777.";
$ns -> tablerender("Файл Мениджър - Помощ", $text);