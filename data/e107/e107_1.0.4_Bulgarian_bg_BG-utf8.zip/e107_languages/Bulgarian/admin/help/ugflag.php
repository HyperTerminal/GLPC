﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Ако обновявате e107 или просто искате вашият сайт да е спрян за малко просто включете функцията Затваряне на сайта за обновяване и потребителите ще бъдат пренасочвани към страницата с обяснение че сайта е затворен за обновяване. След като завършите с обновяването махнете отметката за да върнете сайта в нормалното му състояние.";
$ns -> tablerender("Затваряне на сайта", $text);