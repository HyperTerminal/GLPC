﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да разделите линковете на различни категории, това ще направи навигацията на сайта ви значително по лесна.<br /><br />Всеки линк въведен в главната категория ще се показва там.";
$ns -> tablerender("Категории Линкове - Помощ", $text);