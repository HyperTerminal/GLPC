﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
if (!defined('e107_INIT')) { exit; }
$text = "Ако вашата MySql сървър версия е стара можете да избирате между MySql метод на сортиране който е по бърз или на PHP метод за сортиране. Вижте Настройките.<br /><br />Ако вашият сайт съдържа езици като Кирилица, Китайски или Японски език трябва да използвате PHP метод на сортиране и Само на съвпаднали думи: опцията на Изкл.";
$ns -> tablerender("Търсене - Помощ", $text);