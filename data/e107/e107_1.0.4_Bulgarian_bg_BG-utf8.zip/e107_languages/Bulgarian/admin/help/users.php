﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "От тук можете да модерирате вашите потребители. Можете да обновявате настройките им, да им давате администраторски права или да им определяте даден клас както и други неща.";
$ns -> tablerender("Потребители - Помощ", $text);
unset($text);