﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$caption = "Кеширане";
$text = "Ако сте включили функцията за кеширане на сайта ще се повиши значително скороста му и ще намали заявките към MySQL базата данни.<br /><br /><b>ВАЖНО! Ако правите нова тема за сайта си или преработвате тази която ползвате трябва да изключите кеширането за да се валидират промените!</b>";
$ns -> tablerender($caption, $text);