﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да добавите нормална страница на сайта ви използвайки тази опция. Линка до новата страница ще се създаде в главното меню за навигация. Например ако създадете нова страница с линк име 'Тест', линк с име Тест ще се появи в главното ви меню на сайта при създаване на страницата.<br />Ако желаете вашата страница да има линк икона, я въведете в полето.";
$ns -> tablerender("Съдържание - Помощ", $text);