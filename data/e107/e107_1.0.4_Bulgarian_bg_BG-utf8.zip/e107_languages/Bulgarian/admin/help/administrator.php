﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$caption = "Админ Помощ на Сайта";
$text = "Използвайте тази страница да въведете нови, или да изтриете сайт администратори. Админинистратора ще има достъп само до функциите които вие посочите.";
$ns -> tablerender($caption, $text);