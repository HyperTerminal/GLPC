﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да направите настройките на чат бокса си от тук.<br />Ако поставите отметката за премахване на линковете, всеки линк въведен в чат бокса ще бъде заменен с текста който въведете в полето, това ще премахне и много дългите линкове които могат да ви създадат проблем с дизайна на сайта. Ограничаването на текста автоматично може да съкрати по дълги редове от посочените тук.";
$ns -> tablerender("Чатбокс", $text);