﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да включите пакет от емотикони който сте инсталирали на вашата е107 система. Вървете на <a href='".e_FILE."emote_create/emotecreate.php'>включи емотикони</a> и следвайте инструкциите.";
$ns -> tablerender("Икони с емоции - Помощ", $text);