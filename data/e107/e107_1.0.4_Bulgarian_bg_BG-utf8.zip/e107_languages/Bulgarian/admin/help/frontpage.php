﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$caption = "Помощ - Главна Страница";
$text = "От тук можете да изберете какво да се показва на главната страница на сайта ви, по подразбиране това са новини.";
$ns -> tablerender($caption, $text);