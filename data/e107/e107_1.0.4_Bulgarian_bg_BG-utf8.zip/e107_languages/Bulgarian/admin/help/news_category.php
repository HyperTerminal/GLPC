﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да разделите новините си на различни категории, и да определяте кой има право да чете дадена категория новини. <br /><br />Можете да качвате вашите снимки към новини, икони и др. тук ".e_THEME."-темата_която_ползвате_на_сайта_си-/images/ или themes/shared/newsicons/.";
$ns -> tablerender("Категории Новини - Помощ", $text);