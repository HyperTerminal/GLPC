﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = " Разширението за потребители ви позволява да добавяте допълнителен тип информация за потребителите на сайта като част от техният профил.";
$ns -> tablerender(" Разширени потребителски полета - Помощ", $text);