﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Ревютата са наподобяващи статии но те се показват в тяхно отделно меню.<br />За ревю на няколко страници можете да отделите всяка страница с [newpage], например <br /><code>Тест1 [newpage] Тест2</code><br /> ще създаде две страници с 'Тест1' на страница 1 и 'Тест2' на втората страница.";
$ns -> tablerender("Ревю на сайта - Помощ", $text);