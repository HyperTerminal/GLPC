﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Настройте Анкетата си от тук, просто въведете Въпрос на анкетата: и възможни отговори, натиснете Преглед, поставете отметка за активиране и сте готови.<br /><br />За да стане Анкетата видима, вървете от админ панела в Менюта и се убеете че менюто poll_menu е активирано.";
$ns -> tablerender("Анкети", $text);