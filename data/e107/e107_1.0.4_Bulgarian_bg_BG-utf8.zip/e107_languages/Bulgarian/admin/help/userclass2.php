﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$caption = "Използване на клас";
$text = "Можете да създавате или редактирате/изтривате класове от тази страница.<br />Тази функция е полезна за ограничаване на потребители до част от съдържанието на сайта ви. Например, можете да създадете клас ТЕСТ, след това създавате форум за който имат достъп само потребители с клас ТЕСТ.";
$ns -> tablerender($caption, $text);