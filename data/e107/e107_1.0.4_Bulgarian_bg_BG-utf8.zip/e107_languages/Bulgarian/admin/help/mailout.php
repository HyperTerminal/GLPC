﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "От тук можете да конфигурирате вашият емайл за сайт мейлинг функцията. Този емайл ще ви позволи да изпращате емайл известявания на всички ваши потребители.";
$ns -> tablerender("Мейл - Помощ", $text);