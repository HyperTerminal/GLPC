﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Моля качвайте вашите файлове в ".e_FILE."downloads директорията, вашите снимки в ".e_FILE."downloadimages директорията и умалените изображения в ".e_FILE."downloadthumbs директорията.<br /><br />За да качите файл за сваляне, първо създайте главна категория, след това създайте категории в главната категория, след това ще можете да създавате файлове за сваляне.";
$ns -> tablerender("Файлове - Помощ", $text);