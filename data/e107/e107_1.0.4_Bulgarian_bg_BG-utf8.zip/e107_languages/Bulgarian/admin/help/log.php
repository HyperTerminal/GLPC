﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Активирайте статистиката за логване към сайта от тази страница. Ако нямате много място на сървъра поставете отметка само на домейна за референции, така ще се записват само домейните на референции от други сайтове не целият път, пример 'http://e107bg.org' вместо 'http://e107bg.org/links.php' ";
$ns -> tablerender("Логове - Помощ", $text);