﻿<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
$text = "Можете да получавате и публикувате новини от други сайтове с помоща на RSS канал за новини от тук.<br />Въведете пълният път до RSS публикацията (например http://e107bg.org/e107_plugins/rss_menu/rss.php?news.1). Можете да добавите и път до снимка към сайта ако не ви харесва оригиналната, или няма такава. Можете да активирате и де-активирате RSS новини на сайта ви по всяко време.<br /><br />За да се виждат новините на сайта ви уверете се че, headlines_menu е активирано от меню панела ви.";
$ns -> tablerender("Новини от други сайтове", $text);