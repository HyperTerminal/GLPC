<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "e107 Благодарности");
define("CRELAN_1", "Благодарности");
define("CRELAN_2", "Тук е списъка със софтуера, използван в e107. e107 екипа от разработчици иска да благодари на всички програмисти които са позволили да използват техния софтуер в e107, и публикуват кода си под GPL Лиценз.");
define("CRELAN_3", "всички права запазени");
define("CRELAN_4", "Покажи e107 Прог. Екип");
define("CRELAN_5", "Покажи Листата със софтуер");
define("CRELAN_6", "e107 v0.7 достига до вас благодарение на ...");
define("CRELAN_7", "версия");
define("CRELAN_8", "съглашение");
define("CRELAN_9", "Лиценз");
define("CRELAN_10", "MagpieRSS доставя XML-базиран (expat) RSS парсер в PHP.");
define("CRELAN_11", "PclZip библиотеките осигуряват архивиране и разархивиране функцията за Zip архивите (WinZip, PKZIP).");
define("CRELAN_12", "PclTar осигурява архивирането на файлове или директории със или без компресия. Архивите създадени със PclTar са четими от всички gzip/tar програми и от  Windows WinZip софтуера.");
define("CRELAN_13", "TinyMCE е платформа от независим уеб базиран Javascript HTML WYSIWYG редактор реализиран с отворен код под LGPL Лиценз от Moxiecode Systems AB. Той има възможноста да конвертира HTML текстови полета и други HTML елементи.");
define("CRELAN_14", "Икони използвани в e107");
define("CRELAN_15", "Пълнофункционален емайл трансфер клас за PHP");
define("CRELAN_16", "Меню система използвана в Jayya тема");
define("CRELAN_17", "Поп-ъп инструменти за календар");
define("CRELAN_18", "PDF поддръжка");
define("CRELAN_19", "UTF-8 PDF поддръжка");
define("CRELAN_20", "");
define("CRELAN_21", "Always a pressure..err..pleasure!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Up and forward!");
define("CRELAN_30", "");