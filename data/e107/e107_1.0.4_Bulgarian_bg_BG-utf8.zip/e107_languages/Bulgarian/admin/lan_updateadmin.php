<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("UDALAN_1", "Грешка - моля опитайте отново");
define("UDALAN_2", "Настройките са запазени");
define("UDALAN_3", "Настройките са запазени за");
define("UDALAN_4", "Име");
define("UDALAN_5", "Парола");
define("UDALAN_6", "Повторете паролата");
define("UDALAN_7", "Смяна на парола");
define("UDALAN_8", "Смяна на парола за");