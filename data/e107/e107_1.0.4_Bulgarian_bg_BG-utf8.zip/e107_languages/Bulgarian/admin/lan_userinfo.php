<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Bulgarian/admin/lan_userinfo.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/16 14:43:00 $
|     $Author: veskoto $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Не е възможно да се намери IP адреса на публикувалия - няма информация.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Съобщения публикувани от IP адрес");
define("USFLAN_4", "Хост");
define("USFLAN_5", "Натисни тук за прехвърляне на IP адреса в блокирани");
define("USFLAN_6", "ID на потребителя");
define("USFLAN_7", "Информация за потребител");