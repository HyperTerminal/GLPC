<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("UGFLAN_1", "Настройките за обновяване са записани");
define("UGFLAN_2", "Затвори сайта за обновяване");
define("UGFLAN_3", "Актуализиране на настройките");
define("UGFLAN_4", "Настройки за обновяване");
define("UGFLAN_5", "Текст за показване, когато сайтът е затворен");
define("UGFLAN_6", "Остави празно за ползване на съобщението по подразбиране");
define('UGFLAN_8', 'Ограничи само за Администратори');
define('UGFLAN_9', 'Ограничи само за Главни Администратори'); 