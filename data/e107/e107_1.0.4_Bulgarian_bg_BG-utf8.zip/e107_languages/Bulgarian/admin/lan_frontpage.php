<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("FRTLAN_1", "Настройките на входната страница са запазени.");
define("FRTLAN_2", "Изберете входната страница за");
define("FRTLAN_6", "Линкове");
// define("FRTLAN_7", "Content Page");
define("FRTLAN_12", "Обновяване на настройките");
define("FRTLAN_13", "Настройки на входната страница");
define("FRTLAN_15", "Друго (напишете url):");
define("FRTLAN_16", "грешка: няма избрано съдържание в главната категория");
define("FRTLAN_17", "грешка: няма избрано съдържание в подкатегорията");
define("FRTLAN_18", "грешка: няма избрано съдържание");
define("FRTLAN_19", "съдържание в главна категория");
define("FRTLAN_20", "категория съдържание");
define("FRTLAN_21", "съдържание");
// v1.0.3
define("FRTLAN_22", "Страница");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");
define("FRTLAN_26", "всички");
define("FRTLAN_27", "Гости");
define("FRTLAN_28", "Регистрирани потребители");
define("FRTLAN_29", "Администратори");
define("FRTLAN_31", "Всички потребители");
define("FRTLAN_32", "Клас потребители");
define("FRTLAN_33", "Текущи настройки");
define("FRTLAN_34", "Страница");