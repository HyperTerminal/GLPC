<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("WMLAN_00", "Начално съобщение");
define("WMLAN_01", "Създаване");
define("WMLAN_02", "Съобщение");
define("WMLAN_03", "Видимо от");
define("WMLAN_04", "Текст на съобщението");
define("WMLAN_05", "Рамка");
define("WMLAN_06", "Ако отметнете, съобщението ще бъде оградено в рамка");
define("WMLAN_07", "Системата да ползва краткия код {WMESSAGE}:");
define("WMLAN_09", "Все още няма начални съобщения");
define("WMLAN_10", "Заглавие на съобщението");