<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("FLALAN_1", "Грешка при влизане в системата");
define("FLALAN_2", "Няма грешки при влизане в системата");
define("FLALAN_3", "Грешка(и) изтрити");
define("FLALAN_4", "Потребителя се е опитал да влезне в системата използвайки грешно потребителско име или парола");
define("FLALAN_5", "IP(та) блокирани");
define("FLALAN_6", "Време");
define("FLALAN_7", "Дата");
define("FLALAN_8", "IP адрес/ Хост");
define("FLALAN_9", "Опции");
define("FLALAN_10", "Изтрий / Блокирай грешките на IP с отметки");
define("FLALAN_11", "маркирай всички за изтриване");
define("FLALAN_12", "премахни всички отметки за изтриване");
define("FLALAN_13", "маркирай всички за блокиране");
define("FLALAN_14", "премахни всички отметки за блокиране");
define("FLALAN_15", "Следните IP адреси бяха автоматично блокирани - потребители с повече грешки при опит за влизане в системата");
define("FLALAN_16", "изтрий този списък с автоматично блокирани");
define("FLALAN_17", "Списъка с автоматично блокирани е изтрит");