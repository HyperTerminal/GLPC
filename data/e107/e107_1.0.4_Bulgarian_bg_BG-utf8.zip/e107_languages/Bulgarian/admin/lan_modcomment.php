<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("MDCLAN_1", "Редактирано.");
define("MDCLAN_2", "Няма коментари");
define("MDCLAN_3", "Потребител");
define("MDCLAN_4", "Гост");
define("MDCLAN_5", "махни блокирането");
define("MDCLAN_6", "блокиране");
define("MDCLAN_7", "одобрение");
define("MDCLAN_8", "Редактиране на коментари");
define("MDCLAN_9", "Внимание! Изтриването на коментара ще изтрие и всички отговори към него!");
define("MDCLAN_10", "опции");
define("MDCLAN_11", "коментар");
define("MDCLAN_12", "коментари");
define("MDCLAN_13", "блокиран");
define("MDCLAN_14", "заключи коментарите");
define("MDCLAN_15", "отваряне");
define("MDCLAN_16", "заключен");
define("MDCLAN_17", "За сега няма коментари чакащи одобрение");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");