<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_UPDATE_2", "Действие");
define("LAN_UPDATE_3", "Не е необходимо");
define("LAN_UPDATE_5", "Има налични обновявания");
define("LAN_UPDATE_7", "Изпълнен");
define("LAN_UPDATE_8", "Обновяване от");
define("LAN_UPDATE_9", "до");
define("LAN_UPDATE_10", "Достъпни обновявания");
define("LAN_UPDATE_11", ".617 до .7 актуализацията продължава");
define("LAN_UPDATE_12", "Някоя от таблиците ви съдържа дублирани записи.");