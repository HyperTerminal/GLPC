<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_CKUSER_01", "Проверка в базата данни на потребителите");
define("LAN_CKUSER_02", "Това ще провери за възможни промени във Вашата база данни на потребителите");
define("LAN_CKUSER_03", "Ако имате много потребители това може да отнеме известно време или дори до грешка при проверката");
define("LAN_CKUSER_04", "Продължение");
define("LAN_CKUSER_05", "Проверка за дублирани имена за логване");
define("LAN_CKUSER_06", "Изберете функция за изпълнение");
define("LAN_CKUSER_07", "Намерени са дублирани имена");
define("LAN_CKUSER_08", "Не са намерени дублирани имена");
define("LAN_CKUSER_09", "Потребителско име");
define("LAN_CKUSER_10", "Потребител ID");
define("LAN_CKUSER_11", "Име за показване");
define("LAN_CKUSER_12", "Проверка за дублирани имейли");
define("LAN_CKUSER_13", "Намерени са дублирани имейли");
define("LAN_CKUSER_14", "Имейл");
define("LAN_CKUSER_15", "Не са намерени са дублирани имейли");
define("LAN_CKUSER_16", "Намери потребители които съвпадат с името за логване на някой друг потребител");
define("LAN_CKUSER_17", "Конфликт при име за логване и име за показване");
define("LAN_CKUSER_18", "Потребител А");
define("LAN_CKUSER_19", "Потребител Б");
define("LAN_CKUSER_20", "");