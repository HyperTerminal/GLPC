<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("UCSLAN_1", "Изчистване на всички потребителски класове.");
define("UCSLAN_2", "Класът потребители е обновен.");
define("UCSLAN_3", "Класът потребители е изтрит.");
define("UCSLAN_4", "Моля сложете отметка за потвърждение на изтриването");
define("UCSLAN_5", "Класът потребители е обновен.");
define("UCSLAN_6", "Класът потребители е добавен в базата данни.");
define("UCSLAN_7", "Все още няма класове потребители.");
define("UCSLAN_8", "Съществуващи класове потребители");
define("UCSLAN_11", "поставете отметка за потвърждение");
define("UCSLAN_12", "Име на класът потребители");
define("UCSLAN_13", "Описание на класът потребители");
define("UCSLAN_14", "Обновяване на класът потребители");
define("UCSLAN_15", "Създаване на нов клас потребители");
define("UCSLAN_16", "Добавяне на потребители към класът потребители");
define("UCSLAN_17", "Премахване");
define("UCSLAN_18", "Изчистване на класът потребители");
define("UCSLAN_19", "Добавяне на потребители в");
define("UCSLAN_20", "клас потребители");
define("UCSLAN_21", "Настройки на класове потребители");
define("UCSLAN_22", "Потребители - натисни за премахване ...");
define("UCSLAN_23", "Потребители в този клас ...");
define("UCSLAN_24", "Кой може да управлява този клас потребители");
define("UCSLAN_25", "ИД");
define("UCSLAN_26", "Потребителско име");
define("UCSLAN_27", "Върни");