<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_ADMINLOG_0", "Админ лог");
define("LAN_ADMINLOG_1", "Дата");
define("LAN_ADMINLOG_2", "Заглавие");
define("LAN_ADMINLOG_3", "Описание");
define("LAN_ADMINLOG_4", "Потреб. IP");
define("LAN_ADMINLOG_5", "Потреб. ID");
define("LAN_ADMINLOG_6", "Инфо иконка");
define("LAN_ADMINLOG_7", "Инфо съобщение");
define("LAN_ADMINLOG_8", "Иконка за Забележка");
define("LAN_ADMINLOG_9", "Съобщение за Забележка");
define("LAN_ADMINLOG_10", "Предупредителна иконка");
define("LAN_ADMINLOG_11", "Предупредително съобщение");
define("LAN_ADMINLOG_12", "Иконка за грешка");
define("LAN_ADMINLOG_13", "Съобщение за фатална грешка");