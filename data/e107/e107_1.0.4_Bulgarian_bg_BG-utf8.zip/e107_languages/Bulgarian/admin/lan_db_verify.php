<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("DBLAN_1", "Невъзможно е прочитането на sql файла.<br /><br />Моля уверете се, че файл <b>core_sql.php</b> съществува в папка <strong>/admin/sql</strong>.");
define("DBLAN_2", "Проверка на всичко");
define("DBLAN_4", "Таблица");
define("DBLAN_5", "Поле");
define("DBLAN_6", "Статус");
define("DBLAN_7", "Бележки");
define("DBLAN_8", "Не-съвпадение");
define("DBLAN_9", "Към този момент");
define("DBLAN_10", "би трябвало да бъде");
define("DBLAN_11", "Липсващо поле");
define("DBLAN_12", "Допълнително поле!");
define("DBLAN_13", "Липсваща таблица!");
define("DBLAN_14", "Избор на таблици за проверка");
define("DBLAN_15", "Започни проверка");
define("DBLAN_16", "SQL проверка");
define("DBLAN_17", "Обратно");
define("DBLAN_18", "таблици");
define("DBLAN_19", "Опит за поправка");
define("DBLAN_20", "Опит за поправка на таблиците");
define("DBLAN_21", "Поправи избраното");
define("DBLAN_22", " не може да бъде прочетен");