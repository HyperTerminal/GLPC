<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("CUSLAN_1", "Заглавие");
define("CUSLAN_2", "Вид");
define("CUSLAN_3", "Опции");
define("CUSLAN_4", "Изтриване на страницата?");
define("CUSLAN_5", "Съществуващи страници");
define("CUSLAN_7", "Име на менюто");
define("CUSLAN_8", "Заглавие");
define("CUSLAN_9", "Текст");
define("CUSLAN_10", "Позволете страницата да се оценява");
define("CUSLAN_11", "Начална страница");
define("CUSLAN_12", "Създайте страница");
define("CUSLAN_13", "Позволете коментарите");
define("CUSLAN_14", "Защитена с парола страница");
define("CUSLAN_15", "моля въведете парола");
define("CUSLAN_16", "Създаване на линк в главното меню");
define("CUSLAN_17", "моля напишете име на линка");
define("CUSLAN_18", "Страницата / линка да се вижда от");
define("CUSLAN_19", "Обновете страницата");
define("CUSLAN_20", "Създайте страница");
define("CUSLAN_21", "Обновете менюто");
define("CUSLAN_22", "Създайте меню");
define("CUSLAN_23", "Редакция на страницата");
define("CUSLAN_24", "Създайте нова страница");
define("CUSLAN_25", "Редакция на менюто");
define("CUSLAN_26", "Създайте ново меню");
define("CUSLAN_27", "Страницата е запазена в базата данни.");
define("CUSLAN_28", "Страницата е изтрита");
define("CUSLAN_29", "Списък на страниците ако няма избрана страница");
define("CUSLAN_30", "Време за изтичане на cookie (в секунди)");
define("CUSLAN_31", "Създайте меню");
define("CUSLAN_32", "Преработване на стари менюта/страници");
define("CUSLAN_33", "Настройки на страницата");
define("CUSLAN_34", "Начало на обработката");
define("CUSLAN_35", "Обновяването на страниците е завършено успешно");
define("CUSLAN_36", "За да зададете настройките на всяка от Вашите страници, моля върнете се в началната страница и редактирайте.");
define("CUSLAN_37", "Обновяване на страниците");
define("CUSLAN_38", "да");
define("CUSLAN_39", "не");
define("CUSLAN_40", "Запазване на настройките");
define("CUSLAN_41", "Показване на информация за автора и датата");
define("CUSLAN_42", "Все още няма страници или менюта");
define('CUSLAN_43', 'меню без заглавие: ');
define('CUSLAN_44', 'страница без заглавие');
define('CUSLAN_45', 'Настройките са записани.');