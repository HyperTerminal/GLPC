<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("CACLAN_1", "Статус на кеша");
define("CACLAN_2", "Определете статуса на кеша");
define("CACLAN_3", "Система за кеширане на сървъра");
define("CACLAN_4", "Статус на кеш");
define("CACLAN_5", "Изчистване на кеша");
define("CACLAN_6", "Кеша е изчистен");
define("CACLAN_7", "Кеширането е спряно");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "Кешираните данни са запазени във файл");
define("CACLAN_10", "Директорията където се съхраняват кешираните данни няма права за писане. Моля променете тази директория със следните права: CHMOD 0777");