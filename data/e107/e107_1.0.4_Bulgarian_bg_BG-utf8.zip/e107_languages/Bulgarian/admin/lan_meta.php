<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("METLAN_1", "Мета таговете са обновени");
define("METLAN_2", "Напишете мета тагове");
define("METLAN_3", "Запазване на настройките");
define("METLAN_4", "Обновено");
define("METLAN_5", "въведете описанието тук");
define("METLAN_6", "въведете, списък, от, своите, ключови, думи, тук");
define("METLAN_7", "въведете своята информация за права за ползване на сайта тук");
define("METLAN_8", "Мета тагове");
define("METLAN_9", "описание");
define("METLAN_10", "ключови думи");
define("METLAN_11", "права за ползване на сайта");
define("METLAN_12", "Използвай заглавие и обобщение от новини като мета описание на страниците на новини.");
define("METLAN_13", "Автор");