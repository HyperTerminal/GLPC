<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("UCSLAN_1", "Изпращане на имейл за известяване на");
define("UCSLAN_2", "Обновяване на привилегиите");
define("UCSLAN_3", "Уважаеми");
define("UCSLAN_4", "Вашите права бяха обновени в");
define("UCSLAN_5", "Сега Вие имате достъп до следните зони на сайта:");
define("UCSLAN_6", "Определяне на клас на потребител");
define("UCSLAN_7", "Определяне на класове");
define("UCSLAN_8", "Извести потребителя");
define("UCSLAN_9", "Класовете са обновени.");
define("UCSLAN_10", "С уважение,");
define("UCSLAN_12", "Права само на потребителите");