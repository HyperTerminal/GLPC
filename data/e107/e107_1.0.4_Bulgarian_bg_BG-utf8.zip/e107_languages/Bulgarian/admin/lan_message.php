<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("MESSLAN_1", "Получени съобщения");
define("MESSLAN_2", "Изтрити съобщения");
define("MESSLAN_3", "Съобщенията са изтрити.");
define("MESSLAN_4", "Изтриване на всички съобщения");
define("MESSLAN_5", "Потвърждение");
define("MESSLAN_6", "Всички съобщения са изтрити.");
define("MESSLAN_7", "Няма съобщения.");
define("MESSLAN_8", "Вид съобщение");
define("MESSLAN_9", "Докладвано на");
define("MESSLAN_10", "Докладвано от");
define("MESSLAN_11", "отваряне в нов прозорец");
define("MESSLAN_12", "Съобщение");
define("MESSLAN_13", "Линк");