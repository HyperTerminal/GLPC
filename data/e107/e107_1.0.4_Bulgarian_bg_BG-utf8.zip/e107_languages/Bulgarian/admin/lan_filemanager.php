<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("FMLAN_1", "Качено");
define("FMLAN_2", "в");
define("FMLAN_3", "директория");
define("FMLAN_4", "Каченият файл надвишава разрешеният размер за файл в php.ini .");
define("FMLAN_10", "Грешка");
define("FMLAN_12", "файл");
define("FMLAN_13", "файла");
define("FMLAN_14", "директория");
define("FMLAN_15", "директории");
define("FMLAN_16", "Главна директория");
define("FMLAN_17", "Име");
define("FMLAN_18", "Размер");
define("FMLAN_19", "Последна Промяна");
define("FMLAN_21", "Качете файла в тази директория");
define("FMLAN_22", "Качване");
define("FMLAN_26", "Изтрит");
define("FMLAN_27", "успешно");
define("FMLAN_28", "Не може да бъде изтрит");
define("FMLAN_29", "Път");
define("FMLAN_30", "На горе");
define("FMLAN_31", "Папка");
define("FMLAN_32", "Изберете Директория");
define("FMLAN_33", "Избери");
define("FMLAN_34", "Избрана Директория");
define("FMLAN_35", "Директория Файлове");
define("FMLAN_36", "Лична Меню Директория");
define("FMLAN_37", "Лични Страници Директория");
define("FMLAN_38", "Успешно преместен файл в");
define("FMLAN_39", "Неуспех при преместване на файла в");
define("FMLAN_40", "Снимки към Новини Директория");
define("FMLAN_43", "Изтрий избраните файлове");
define("FMLAN_46", "Моля потвърдете ИЗТРИВАНЕТО на избраните файлове.");
define("FMLAN_47", "Качено от Потребители");
define("FMLAN_48", "Премести избраното в");
define("FMLAN_49", "Моля потвърдете преместването на избраният/те файл/ове.");
define("FMLAN_50", "Премести");
define("FMLAN_51", "Неидентифицирана грешка:");