<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("FOOTLAN_1", "Сайт");
define("FOOTLAN_2", "Главен Админ");
define("FOOTLAN_3", "Версия");
define("FOOTLAN_4", "Изградена");
define("FOOTLAN_5", "Тема");
define("FOOTLAN_6", "от");
define("FOOTLAN_7", "Инфо");
define("FOOTLAN_8", "Дата на инсталация");
define("FOOTLAN_9", "Сървър");
define("FOOTLAN_10", "Хост");
define("FOOTLAN_11", "PHP Версия");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Инфо за сайта");
define("FOOTLAN_14", "Покажи Документация");
define("FOOTLAN_15", "Документация");
define("FOOTLAN_16", "База Данни");
define("FOOTLAN_17", "Чарсет Енкодинг");
define("FOOTLAN_18", "Тема на сайта");
define("FOOTLAN_19", "Актуално сървърно време");
define("FOOTLAN_20", "Ниво на сигурност");