<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("BANLAN_1", "Блокиране и премахнато.");
define("BANLAN_2", "Няма блокирани.");
define("BANLAN_3", "Списък блокирани");
define("BANLAN_4", "Премахни блокиране");
define("BANLAN_5", "Напишете IP, имейл или хост");
define("BANLAN_7", "Причина за блокирането");
define("BANLAN_8", "Блокирай потребителя");
define("BANLAN_9", "Блокирани потребители в сайта");
define("BANLAN_10", "IP / Имейл / Причина");
define("BANLAN_11", "Автоматично блокиране: повече от 10 неуспешни опита за вход в системата");
define("BANLAN_12", "Внимание: обратен (reverse) DNS е забранен в момента - трябва да бъде позволен за възможност на блокиране по хост. Блокиране по IP и имейл ще функционира нормално.");
define("BANLAN_13", "Внимание: За блокиране на потребител по потребителско име, отидете на модул администрация на потребителите: ");
define("BANLAN_78", "Надвишен брой заявки (- HITS - искания в рамките на определеното време)");