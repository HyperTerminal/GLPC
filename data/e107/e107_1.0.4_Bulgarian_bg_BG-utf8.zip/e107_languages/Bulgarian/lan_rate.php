<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("RATELAN_0", "глас");
define("RATELAN_1", "гласа");
define("RATELAN_2", "как оценяваш тази публикация?");
define("RATELAN_3", "благодарим за вашият глас");
define("RATELAN_4", "не е гласувано");
define("RATELAN_5", "Гласувай");