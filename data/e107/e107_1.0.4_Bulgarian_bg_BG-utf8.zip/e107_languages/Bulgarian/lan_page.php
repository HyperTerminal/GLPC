<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("LAN_PAGE_1", "Забранено е показването на списък със страниците");
define("LAN_PAGE_2", "Все още няма създадени страници");
define("LAN_PAGE_3", "Търсената от Вас страница не съществува");
define("LAN_PAGE_4", "Оцени тази страница");
define("LAN_PAGE_5", "Благодарим за Вашия глас.");
define("LAN_PAGE_6", "Нямате права за преглеждането на тази страница");
define("LAN_PAGE_7", "Неправилна парола");
define("LAN_PAGE_8", "Защитена с парола страница");
define("LAN_PAGE_9", "Парола");
define("LAN_PAGE_10", "Изпрати");
define("LAN_PAGE_11", "Списък със страници");
define("LAN_PAGE_12", "Невалидна страница");
define("LAN_PAGE_13", "Страница");