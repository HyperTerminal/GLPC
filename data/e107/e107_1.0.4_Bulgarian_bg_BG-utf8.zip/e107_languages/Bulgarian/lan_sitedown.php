<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Сайтът е временно затворен");
define("LAN_SITEDOWN_00", "е временно затворен");
define("LAN_SITEDOWN_01", "Сайтът е временно затворен за извършване на някои подобрения. Това не би трябвало да отнеме много време. Моля изчакайте и опитайте отново. Съжаляваме за създаденото неудобство.");