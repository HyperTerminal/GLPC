<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Добавяне на новини");
define("LAN_7", "Име:");
define("LAN_62", "Заглавие на новината:");
define("LAN_112", "Имейл Адрес:");
define("LAN_133", "Благодарим ви");
define("LAN_134", "Вашата новина е записана и ще бъде прегледана от администратор на сайта в най-скоро време.");
define("LAN_135", "Новина:");
define("LAN_136", "Добави новина");
define("NWSLAN_6", "Категория");
define("NWSLAN_10", "Няма Създадени Категории");
define("NWSLAN_11", "Нямате достъп до тази зона.");
define("NWSLAN_12", "Достъпът е отказан.");
define("SUBNEWSLAN_1", "Трябва да въведете заглавие.\\n");
define("SUBNEWSLAN_2", "Трябва да въведете текст за новината.\\n");
define("SUBNEWSLAN_3", "Вашия прикачен файл може да бъде jpg, gif или png");
define("SUBNEWSLAN_4", "Файлът е прекалено голям");
define("SUBNEWSLAN_5", "Файл Картинка");
define("SUBNEWSLAN_6", "(jpg, gif или png)");
define("SUBNEWSLAN_7", "Трябва да напишете Вашето име и имейл адрес");
define("SUBNEWSLAN_8", "Грешка при качване на картинка");