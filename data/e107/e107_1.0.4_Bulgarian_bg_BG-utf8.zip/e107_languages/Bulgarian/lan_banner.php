<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Реклама");
define("BANNERLAN_16", "Потребител: ");
define("BANNERLAN_17", "Парола: ");
define("BANNERLAN_18", "Продължи");
define("BANNERLAN_19", "Моля въведете вашето клиентско име и парола за да продължите");
define("BANNERLAN_20", "Съжаляваме не е възможно намирането на въведените данни в клиентската база. Моля, свържете се с администратора на сайта за повече информация.");
define("BANNERLAN_21", "Статистика");
define("BANNERLAN_22", "Клиент");
define("BANNERLAN_23", "Банер ID");
define("BANNERLAN_24", "Кликове");
define("BANNERLAN_25", "% Клик");
define("BANNERLAN_26", "Показвания");
define("BANNERLAN_27", "Закупени показвания");
define("BANNERLAN_28", "Оставащи показвания");
define("BANNERLAN_29", "Няма банери");
define("BANNERLAN_30", "Неограничен");
define("BANNERLAN_31", "Неизвестно");
define("BANNERLAN_32", "Да");
define("BANNERLAN_33", "Не");
define("BANNERLAN_34", "Изтича:");
define("BANNERLAN_35", "Кликове - IP адреси");
define("BANNERLAN_36", "Активно:");
define("BANNERLAN_37", "Начало:");
define("BANNERLAN_38", "Грешка");