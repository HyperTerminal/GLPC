<?php
/*
 * e107 website system - Bulgarian Translation
 *
 * Copyright (C) 2005-2011 e107 Bulgaria e107.bg
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * $Id$
*/
define("PAGE_NAME", "Изглед за печат");
define("LAN_PRINT_1", "изглед за печат");
define("LAN_PRINT_86", "Категория:");
define("LAN_PRINT_87", "от ");
define("LAN_PRINT_94", "Публикувано от");
define("LAN_PRINT_135", "Новина: ");
define("LAN_PRINT_303", "Новина от ");
define("LAN_PRINT_304", "Заглавие: ");
define("LAN_PRINT_305", "Подзаглавие: ");
define("LAN_PRINT_306", "Това е от: ");
define("LAN_PRINT_307", "Разпечатай тази страница");