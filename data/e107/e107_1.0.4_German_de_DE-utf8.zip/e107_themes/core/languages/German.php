<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_themes/core/languages/German.php $ 
|     $Revision: 168 $
|     $Date: 2011-12-29 06:00:05 +0100 (Do, 29. Dez 2011) $
|     $Id: German.php 168 2011-12-29 05:00:05Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define('LAN_THEME_1', 'e107 core Theme von <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>');
define('LAN_THEME_2', 'Kommentare: ');
define('LAN_THEME_3', 'Kommentare sind abgeschaltet');
define('LAN_THEME_4', 'Den vollständigen Artikel lesen');
define('LAN_THEME_5', 'Trackbacks: '); 
define('LAN_THEME_8', 'in');
define('LAN_THEME_9', 'von');
define("LAN_THEME_11", "Neueste Nachrichten");
define("LAN_THEME_12", "An einen Freund mailen");
define("LAN_THEME_13", "PDF Datei erstellen");
define("LAN_THEME_14", "Drucken");
define("LAN_THEME_15", "Bearbeiten");
define('LAN_THEME_17', 'Login');
define('LAN_THEME_18', 'Benutzername');
define('LAN_THEME_19', 'Passwort');
define('LAN_THEME_20', 'Registrierung');
define('LAN_THEME_21', 'Login');
define('LAN_THEME_22', 'Passwort vergessen?');
define('LAN_THEME_23', 'Willkommen');
define('LAN_THEME_24', 'Admin Bereich');
define('LAN_THEME_26', 'Einstellungen');
define('LAN_THEME_27', 'Mein Profil');
define('LAN_THEME_28', 'Ausloggen');
define('LAN_THEME_29', 'Neues auflisten');
define('LAN_THEME_SING', 'Login');
define('LAN_THEME_REG', 'Registrierung');
define("LAN_SEARCH", "Suche");
define("LAN_SEARCH_SUB", "Los");
define('LAN_THEME_SHARE', 'Teilen');
define('LAN_THEME_VER', 'e107 v.');
define("CM_L13", "von");
?>