<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/pm/languages/admin/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define('ADLAN_PM', "Privates Nachrichtensystem");
define('ADLAN_PM_1', "Gehen Sie bitte in Ihren Administartionsbereich - Menü - und aktivieren sie  - private_msg -  im gewünschten Bereich. <br /><br />Falls es nötig ist, alte Nachrichten von Vorgängerversionen zu konvertieren, gehen sie bitte auf die Hauptkonfigurationsseite dieses Plugins und wählen sie den 'convert' Link.");
define('ADLAN_PM_2', "Privates Nachrichtensystem konfigurieren");
define('ADLAN_PM_3', "Einstellungen für Private Nachrichten wurden nicht gefunden, ursprünglich gesetzte Werte werden verwendet");
define('ADLAN_PM_4', "Optionen aktualisiert");
define('ADLAN_PM_5', "Limit für ausgewählte Benutzerklasse besteht bereits");
define('ADLAN_PM_6', "Limit erfolgreich hinzugefügt");
define('ADLAN_PM_7', "Limit konnte nicht hinzugefügt werden - unbekannter Fehler");
define('ADLAN_PM_8', "Limit Status aktualisiert");
define('ADLAN_PM_9', " - Limit erfolgreich entfernt");
define('ADLAN_PM_10', " - Limit konnte nicht entfernt werden - unbekannter Fehler");
define('ADLAN_PM_11', " - Limit erfolgreich aktualisiert");
define('ADLAN_PM_12', "PN Optionen");
define('ADLAN_PM_13', "PN Konvertierung");
define('ADLAN_PM_14', "PN Limits");
define('ADLAN_PM_15', "PM Limit hinzufügen");
define('ADLAN_PM_16', "Plugin Titel");
define('ADLAN_PM_17', "Zerige neue PM Animation");
define('ADLAN_PM_18', "Zeige Benutzer-Dropdownmenü");
define('ADLAN_PM_19', "Timeout für gelesene Nachrichten");
define('ADLAN_PM_20', "Timeout für ungelesene Nachrichten");
define('ADLAN_PM_21', "Popup-Benachrichtigung bei neuer PN");
define('ADLAN_PM_22', "Timout für Popupanzeige");
define('ADLAN_PM_23', "PN kann benutzt werden von");
define('ADLAN_PM_24', "Anzahl Privater Nachrichten pro Seite");
define('ADLAN_PM_25', "E-mail Benachrichtigungen für Private Nachrichten freischalten");
define('ADLAN_PM_26', "Benutzern erlauben Lesebestätigung per E-mail anzufordern");
define('ADLAN_PM_27', "Anhänge erlauben");
define('ADLAN_PM_28', "Maximale Anhanggröße");
define('ADLAN_PM_29', "Erlauben Sie es an alle Mitglieder zu verschicken");
define('ADLAN_PM_30', "Erlauben Sie es gleichzeitig mehreren Empfängern zu senden");
define('ADLAN_PM_31', "Benutzerklassenbezogenes Senden erlauben");
define('ADLAN_PM_32', "Einstellungen aktualisieren");
define('ADLAN_PM_33', "Inaktiv (Keine Limits)");
define('ADLAN_PM_34', "PN Zählung");
define('ADLAN_PM_35', "PN Box Größe");
define('ADLAN_PM_36', "Benutzerklasse");
define('ADLAN_PM_37', "Zählung Limits");
define('ADLAN_PM_38', "Größe Limits (in KB)");
define('ADLAN_PM_39', "Posteingang :");
define('ADLAN_PM_40', "Postausgang :");
define('ADLAN_PM_41', "Es sind derzeit keine Limits gesetzt.");
define('ADLAN_PM_42', "Limits aktualisieren");
define('ADLAN_PM_43', "Neues Limit hinzufügen");
define('ADLAN_PM_44', "Sekunden");
define('ADLAN_PM_45', "Limit PN von: ");
define('ADLAN_PM_46', "PN Konvertierung");
define('ADLAN_PM_47', "Es scheint, Sie haben keine Privaten Nachrichten von Vorgängerversionen, sie können das alte Plugin deinstallieren");
define('ADLAN_PM_48', "Sie haben {OLDCOUNT} Nachrichten in der älteren Version, bitte entscheiden Sie, was Sie mit diesen Nachrichten machen möchten<br /><br />Falls Sie sich für Konvertierung der Nachrichten entscheiden, werden alle erfolgreich konvertierten Nachrichten automatisch aus dem alten System entfernt.");
define('ADLAN_PM_49', "Zum neuen Privaten Nachrichtensystem konvertieren");
define('ADLAN_PM_50', "Discard alte Nachrichten");
define('ADLAN_PM_51', "PN #{PMNUM} nicht konvertiert");
define('ADLAN_PM_52', "Nachrichten konvertiert");
define('ADLAN_PM_53', "Keine Einträge zum Konvertieren gefunden.");

define('ADLAN_PM_54', "Haupteinstellungen");
define('ADLAN_PM_55', "Limits");
define('ADLAN_PM_56', "Konvertierung");
define('ADLAN_PM_57', "Bei diesem Plugin handelt es sich um ein ausgereiftes Privates-Nachrichtenssystem mit vielen Möglichkeiten.");
define('ADLAN_PM_58', "Privates Nachrichtensystem");
	
?>