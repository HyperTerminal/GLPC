<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/calendar_menu/languages/German_class.php $ 
|     $Revision: 275 $
|     $Date: 2013-03-23 21:04:26 +0100 (Sa, 23. Mrz 2013) $
|     $Id: German_class.php 275 2013-03-23 20:04:26Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'nicht');
define('EC_LAN_RECUR_01', 'jährlich');
define('EC_LAN_RECUR_02', 'halbjährlich');
define('EC_LAN_RECUR_03', 'vierteljährlich');
define('EC_LAN_RECUR_04', 'monatlich');
define('EC_LAN_RECUR_05', 'vierwöchentlich');
define('EC_LAN_RECUR_06', 'vierzehntäglich');
define('EC_LAN_RECUR_07', 'wöchentlich');
define('EC_LAN_RECUR_08', 'täglich');
define('EC_LAN_RECUR_100', 'Sonntag im Monat');
define('EC_LAN_RECUR_101', 'Montag im Monat');
define('EC_LAN_RECUR_102', 'Dienstag im Monat');
define('EC_LAN_RECUR_103', 'Mittwoch im Monat');
define('EC_LAN_RECUR_104', 'Donnerstag im Monat');
define('EC_LAN_RECUR_105', 'Freitag im Monat');
define('EC_LAN_RECUR_106', 'Samstag im Monat');

define('EC_LAN_RECUR_1100', 'Erster');
define('EC_LAN_RECUR_1200', 'Zweiter');
define('EC_LAN_RECUR_1300', 'Dritter');
define('EC_LAN_RECUR_1400', 'Vierter');


// Notify
define('NT_LAN_EC_1', 'Terminkalender Termine');
define('NT_LAN_EC_2', 'Termin aktualisiert');
define('NT_LAN_EC_3', 'Aktualisiert von');
define('NT_LAN_EC_4', 'IP Addesse');
define('NT_LAN_EC_5', 'Nachricht');
define('NT_LAN_EC_6', 'Terminkalender - Termin hinzugefügt');
define('NT_LAN_EC_7', 'Neuer Termin veröffentlicht');
define('NT_LAN_EC_8', 'Terminkalender - Termin geändert');


// Log messages
define('EC_ADM_01', 'Terminkalender - Termin hinzugefügt');
define('EC_ADM_02', 'Terminkalender - Termin geändert');
define('EC_ADM_03', 'Terminkalender - Termin gelöscht');
define('EC_ADM_04', 'Terminkalender - Massen Löschen');
define('EC_ADM_05', 'Terminkalender - Mehrere hinzugefügt');
define('EC_ADM_06', 'Terminkalender - Hauptoptionen geändert');
define('EC_ADM_07', 'Terminkalender - FE Optionen geändert');
define('EC_ADM_08', 'Terminkalender - Kategorie hinzugefügt');
define('EC_ADM_09', 'Terminkalender - Kategorie geändert');
define('EC_ADM_10', 'Terminkalender - Kategorie gelöscht');
define('EC_ADM_11', 'Terminkalender - Alte Termine gelöscht');

?>