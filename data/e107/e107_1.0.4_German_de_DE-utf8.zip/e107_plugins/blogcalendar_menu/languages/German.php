<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/blogcalendar_menu/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("BLOGCAL_L1", "News für ");
define("BLOGCAL_L2", "Archiv");

define("BLOGCAL_D1", "Mo");
define("BLOGCAL_D2", "Di");
define("BLOGCAL_D3", "Mi");
define("BLOGCAL_D4", "Do");
define("BLOGCAL_D5", "Fr");
define("BLOGCAL_D6", "Sa");
define("BLOGCAL_D7", "So");

define("BLOGCAL_M1", "Januar");
define("BLOGCAL_M2", "Februar");
define("BLOGCAL_M3", "März");
define("BLOGCAL_M4", "April");
define("BLOGCAL_M5", "Mai");
define("BLOGCAL_M6", "Juni");
define("BLOGCAL_M7", "Juli");
define("BLOGCAL_M8", "August");
define("BLOGCAL_M9", "September");
define("BLOGCAL_M10", "Oktober");
define("BLOGCAL_M11", "November");
define("BLOGCAL_M12", "Dezember");

define("BLOGCAL_1", "News Einträge");

define("BLOGCAL_CONF1", "Monat/row");
define("BLOGCAL_CONF2", "Zellenabstand");
define("BLOGCAL_CONF3", "Menuüeinstellungen aktualisieren");
define("BLOGCAL_CONF4", "Blochkalender Menükonfiguration");
define("BLOGCAL_CONF5", "Blockkalender Menäkonfiguration gespeichert");

define("BLOGCAL_ARCHIV1", "Archiv auswählen");

?>