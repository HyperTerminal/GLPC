<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/counter_menu/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("COUNTER_L1", "Adminbesuche werden nicht gezählt");
define("COUNTER_L2", "Diese Seite heute");
define("COUNTER_L3", "Insgesamt");
define("COUNTER_L4", "Diese Seite insgesamt");
define("COUNTER_L5", "einzigartig.");
define("COUNTER_L6", "Seite.");
define("COUNTER_L7", "Zähler");
define("COUNTER_L8", "Admin Nachricht: <b>Statistik Logs sind abgeschaltet.</b><br />Um es zu aktivieren, müssen Sie das Statsitik Loggin Plugin installieren in Ihrem <a href='".e_ADMIN."plugin.php'>Plugin Manager</a>, danach aktivieren Sie es bitte mittels <a href='".e_PLUGIN."log/admin_config.php'>Konfigurations-Screen</a>.");

?>