<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/alt_auth/languages/German/lan_otherdb_auth.php $ 
|     $Revision: 245 $
|     $Date: 2012-04-26 21:26:07 +0200 (Do, 26. Apr 2012) $
|     $Id: lan_otherdb_auth.php 245 2012-04-26 19:26:07Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define('OTHERDB_LAN_1', 'Datenbank Typ:');
define('OTHERDB_LAN_2', 'Server:');
define('OTHERDB_LAN_3', 'Benutzername:');
define('OTHERDB_LAN_4', 'Passwort:');
define('OTHERDB_LAN_5', 'Datenbank');
define('OTHERDB_LAN_6', 'Tabelle');
define('OTHERDB_LAN_7', 'Benutzernamen Feld:');
define('OTHERDB_LAN_8', 'Passwort Feld:');
define('OTHERDB_LAN_9', 'Passwort Methode:');
define('OTHERDB_LAN_10', 'OtherDB auth konfigurieren');
define('OTHERDB_LAN_11', '** Nachfolgende Felder werden nicht benötigt, falls Sie eine e107 Datenbank benutzen.');