<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/alt_auth/languages/German/lan_ldap_auth.php $ 
|     $Revision: 244 $
|     $Date: 2012-04-26 21:23:08 +0200 (Do, 26. Apr 2012) $
|     $Id: lan_ldap_auth.php 244 2012-04-26 19:23:08Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define('LDAPLAN_1', 'Server Adresse');
define('LDAPLAN_2', 'Basis DN oder Domain<br />Falls LDAP - Bitte BasisDN eingeben<br />Falls AD - Bitte Domain eingeben');
define('LDAPLAN_3', 'LDAP Such-Benutzer<br />Vollständiger Kontext des Benutzers, der diese Verzeichnis durchsuchen kann.');
define('LDAPLAN_4', 'LDAP Such-Passwort<br />Passwort für den LDAP Such-Benutzer.');
define('LDAPLAN_5', 'LDAP Version');
define('LDAPLAN_6', 'LDAP Auth konfigurieren');
define('LDAPLAN_7', 'eDirectory Suchfilter:');
define('LDAPLAN_8', 'Wird benutzt, um sicher zu stellen, dass der Benutzername in der richtigen Baumstruktur ist, <br />z.B '(objectclass=inetOrgPerson)'');
define('LDAPLAN_9', 'Aktuellere Suchfilter wird sein:');
define('LDAPLAN_10', 'WARNUNG: Wenn das LDAP Modul nicht verfügbar ist, wird das Setzen der auth Methode auf LDAP wahrscheinlich nicht funktionieren!');
define('LDAPLAN_11', 'Server Typ');