<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/alt_auth/languages/German/lan_alt_auth_conf.php $ 
|     $Revision: 243 $
|     $Date: 2012-04-26 21:20:15 +0200 (Do, 26. Apr 2012) $
|     $Id: lan_alt_auth_conf.php 243 2012-04-26 19:20:15Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define('LAN_ALT_2', 'Aktuelle Autorisierungsart');
define('LAN_ALT_3', 'Alternative Autorisierungsart wählen');
define('LAN_ALT_4', 'Parameter konfigurieren für');
define('LAN_ALT_5', 'Autorisierungsparameter konfigurieren');
define('LAN_ALT_6', 'Fehlerhafter Verbindungsversuch');
define('LAN_ALT_7', 'Wie soll damit umgegangen werden, wenn die Verbindung über die alternative Art fehlschlägt?');
define('LAN_ALT_8', 'Benutzer nicht gefunden Aktion');
define('LAN_ALT_9', 'Wie sollte damit umgegangen werden, wenn ein Benutzer nicht gefunden wird bei Verwendung der alternitiven Methode?');
define('LAN_ALT_10', 'Fehlerhaftes Login');
define('LAN_ALT_11', 'e107 Benutzertabelle benutzen');

define('LAN_ALT_PAGE', 'Alternative Authentifizierung');