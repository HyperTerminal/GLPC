<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/newforumposts_main/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("NFPM_LAN_1", "Eintrag");
define("NFPM_LAN_2", "Schreiber");
define("NFPM_LAN_3", "Ansichten");
define("NFPM_LAN_4", "Antworten");
define("NFPM_LAN_5", "Letzter Eintrag");
define("NFPM_LAN_6", "Einträge");
define("NFPM_LAN_7", "von");

define("NFPM_L1", "Dieses Plugin zeigt eine Liste von Neuen Forumseinträgen auf der Hauptseite");
define("NFPM_L2", "Letzte Forumeinträge"); 
define("NFPM_L3", "Zum Konfigurieren klicken Sie bitte auf der Adminhauptseite - Neue Forum Einträge -");
define("NFPM_L4", "In welchem Bereich aktivieren?");
define("NFPM_L5", "Inaktiv");
define("NFPM_L6", "Oben auf der Seite");
define("NFPM_L7", "Unten auf der Seite");
define("NFPM_L8", "Überschrift");
define("NFPM_L9", "Die Anzahl der anzuzeigenden neuen Einträge?");
define("NFPM_L10", "Anzeige im srollenden Bereich?");
define("NFPM_L11", "Layer Höhe");
define("NFPM_L12", "Konfiguration");
define("NFPM_L13", "Einstellungen aktualisieren");
define("NFPM_L14", "Einstellungen aktualisiert.");
define("NFPM_L15", "Markieren Sie hier um die letzten Forumeinträge anzeigen zu lassen.<br />Gesetzt sind letzte Forumtopics.");
define('NFPM_L16', '[Benutzer gelöscht]');
define('NFPM_L17', 'Neue Einträge in populärem Beitrag');
define('NFPM_L18', 'Neue Einträge');
define('NFPM_L19', 'Keine neuen Einträge in populärem Beitrag');
define('NFPM_L20', 'Keine neuen Einträge');
define('NFPM_L21', 'Wichtiger Beitrag');
define('NFPM_L22', 'Geschlossener wichtiger Beitrag');
define('NFPM_L23', 'Ankündigung');
define('NFPM_L24', 'Geschlossener Beitrag');

?>