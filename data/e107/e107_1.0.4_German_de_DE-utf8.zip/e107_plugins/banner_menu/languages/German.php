<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/banner_menu/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Werbung");
define("BANNER_MENU_L2", "Banner Menü Konfiguration gespeichert");

define("BANNER_MENU_L3", "Überschrift");
define("BANNER_MENU_L4", "Kampagne");
define("BANNER_MENU_L5", "Banner Menü Konfiguration");
define("BANNER_MENU_L6", "Wählen Sie die Kampagnen, die im Menü angezeigt werden sollen");
define("BANNER_MENU_L7", "Bestehende Kampagnen");
define("BANNER_MENU_L8", "Gewählte Kampagnen");
define("BANNER_MENU_L9", "Auswahl aufheben");
define("BANNER_MENU_L10", "Wie sollen die gewählten Kampagnen angezeigt werden ?");
define("BANNER_MENU_L11", "Wählen Sie die Anzeigeoption ...");
define("BANNER_MENU_L12", "Eine Kampagne in einem Menü");
define("BANNER_MENU_L13", "Alle Kampagnen in einem Menü");
define("BANNER_MENU_L14", "Alle Kampagnen in separaten Menüs");
define("BANNER_MENU_L15", "Wieviele Banner sollen angezeigt werden ?");
define("BANNER_MENU_L16", "Diese Einstellungen gelten nur in Verbindung mit Option 2 und 3.<br />Falls weniger Banner vorhanden sind, wird die maximale Anzahl gesetzt.");
define("BANNER_MENU_L17", "Anzahl setzen ...");
define("BANNER_MENU_L18", "Menüeinstellungen aktualisieren");

?>