<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/forum/languages/German/lan_forum_conf.php $ 
|     $Revision: 247 $
|     $Date: 2012-04-26 21:42:35 +0200 (Do, 26. Apr 2012) $
|     $Id: lan_forum_conf.php 247 2012-04-26 19:42:35Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

# Install LANs
define('LAN_FORUM_INSTALL_01', 'Forum');
define('LAN_FORUM_INSTALL_02', 'Dieses Plugin ist ein voll ausgestattetes Forum System.');
define('LAN_FORUM_INSTALL_03', 'Forum konfigurieren');
define('LAN_FORUM_INSTALL_04', 'Ihr Forum ist jetzt installiert');
define('LAN_FORUM_INSTALL_05', 'Forum erfolgreich aktualisiert, jetzt benutzte Version: %1$s');
define('LAN_FORUM_INSTALL_06', '[Forum]');
define('LAN_FORUM_INSTALL_07', '[mehr...]');

# Config LANs
define('FORLAN_5', 'Umfrage gelöscht.');
define('FORLAN_6', 'Thema gelöscht');
define('FORLAN_7', 'Antworten gelöscht');
define('FORLAN_8', 'Löschen abgebrochen.');
define('FORLAN_9', 'Thema verschoben.');
define('FORLAN_10', 'Verschieben abgebrochen');
define('FORLAN_11', 'Zurück zu den Foren');
define('FORLAN_12', 'Forum Konfiguration');
define('FORLAN_13', 'Sind Sie absolut sicher, dass Sie diese Umfrage löschen wollen?<br />Einmal gelöscht <b><u>,kann sie nicht wieder</u></b> hergestellt werden');
define('FORLAN_14', 'Abbrechen');
define('FORLAN_15', 'Löschen des Foreneintrags bestätigen');
define('FORLAN_16', 'Löschen der Umfrage bestätigen');
define('FORLAN_17', 'geschrieben von');
define('FORLAN_18', 'Sind Sie sich beim Löschen dieses Forum');
define('FORLAN_19', 'Themas und den zugehörigen Beiträgen absolut sicher?');
define('FORLAN_20', 'die Umfrage wird dann auch gelöscht');
define('FORLAN_21', 'Diese können, wenn sie einmal gelöscht sind');
define('FORLAN_22', 'Beitrages absolut sicher?<br /> Dieser kann, wenn er einmal gelöscht ist');
define('FORLAN_23', '<b><u>nicht</u></b> wieder hergestellt werden.');
define('FORLAN_24', 'Verschiebe das Thema zum Forum');
define('FORLAN_25', 'Verschiebe das Thema');
define('FORLAN_26', 'Antwort gelöscht');
define('FORLAN_27', 'verschoben');
define('FORLAN_28', 'Thema Titel nicht umbenennen');
define('FORLAN_29', 'Hinzufügen');
define('FORLAN_30', 'zum Titel');
define('FORLAN_31', 'Umbenennen in:');
define('FORLAN_32', 'Themaoptionen umbenennen:');