<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/tree_menu/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Tree Menü konfigurieren");
define("TREE_L2", "Tree Menu Einstellungen aktualisieren");
define("TREE_L3", "Tree Menu Konfiguration gespeichert.");
define("TREE_L4", "An");
define("TREE_L5", "Aus");
define("TREE_L6", "Css Klasse für nicht öffenbare Links");
define("TREE_L7", "Css Klasse für zu öffnende Links");
define("TREE_L8", "Css Klasse für offene Links");
define("TREE_L9", "Css Klasse zwischen den Hauptlinks");


?>