<?php
/*
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/gsitemap/languages/gsitemap_German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: gsitemap_German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Sitemap");
define("GSLAN_1", "Seiten Link");
define("GSLAN_2", "Importieren?");
define("GSLAN_3", "Typ");
define("GSLAN_4", "Name");
define("GSLAN_5", "Url");
define("GSLAN_6", "Bitte Links für Import markieren ...");
define("GSLAN_7", "Import Links");
define("GSLAN_8", "Import mit:");
define("GSLAN_9", "Priorität");
define("GSLAN_10", "Frequenz");
define("GSLAN_11", "immer");
define("GSLAN_12", "stündlich");
define("GSLAN_13", "täglich");
define("GSLAN_14", "wöchentlich");
define("GSLAN_15", "monatlich");
define("GSLAN_16", "jährlich");
define("GSLAN_17", "nie");
define("GSLAN_18", "Markierte Links importieren");
define("GSLAN_19", "Google Sitemap");
define("GSLAN_20", "Auflistung");
define("GSLAN_21", "Anleitung");
define("GSLAN_22", "Neuen Eintrag erstellen");
define("GSLAN_23", "Importieren");
define("GSLAN_24", "Google Sitemap Einträge");
define("GSLAN_25", "Name");
define("GSLAN_26", "URL");
define("GSLAN_27", "Letzter Modus");
define("GSLAN_28", "Freq.");
define("GSLAN_29", "Google Sitemap Konfiguartion");
define("GSLAN_30", "Anzeigesortierung");
define("GSLAN_31", "Sichtbar für");
define("GSLAN_32", "Wie kann Google Sitemaps genutzt werden");
define("GSLAN_33", "GSiteMap Anleitung");
define("GSLAN_34", "Estellen Sie bitte zuerst die Links die Sie in Ihrer Sitemap aufgelistet haben wollen. Sie können die meisten Links automatisch importieren indem Sie den 'Importieren' Button rechts klicken");
define("GSLAN_35", "Fall Sie sich entschieden haben, Links zu importieren, klicken Sie bitte 'Importieren' und markieren Sie danach die gewünschten Links, die Sie importieren möchten");
define("GSLAN_36", "Sie können auch individuelle Links erstellen in dem Sie auf  'Neuen Eintrag erstellen' klicken");
define("GSLAN_37", "Wenn Sie dann Einträge getätigt haben, gehen Sie bitte auf [URL] und geben Sie dort folgende URL ein: [URL2] Falls die URL nicht richtig ist, vergewissern Sie sich, dass Sie die Seiten URL in Admin -> [Voreinstellungen] korrekt eingegeben haben.");
define("GSLAN_38", "Für mehr Informationen über das Google Sitemap Protokoll, besuchen Sie bitte [URL].");
define("GSLAN_39", "Keine Links in der Sitemap - Seitenlinks importieren?");
define("GSLAN_40", "Google Sitemap Einträge");

?>