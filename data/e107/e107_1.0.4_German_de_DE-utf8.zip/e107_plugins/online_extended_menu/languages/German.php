<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/online_extended_menu/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Gäste: ");
define("ONLINE_EL2", "Mitglieder: ");
define("ONLINE_EL3", "auf dieser Seite: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Mitglieder");
define("ONLINE_EL6", "Neuestes Mitglied");
define("ONLINE_EL7", "auf Seite");

define("ONLINE_EL8", "Online Rekord: ");
define("ONLINE_EL9", "am");

define("ONLINE_TRACKING_MESSAGE", "Online User Tracking ist momentan deaktiviert, bitte aktivieren Sie es [link=".e_ADMIN."users.php?options]hier[/link][br]");
?>