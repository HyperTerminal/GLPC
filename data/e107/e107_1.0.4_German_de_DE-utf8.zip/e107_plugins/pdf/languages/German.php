<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_plugins/pdf/languages/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF Erstellung Support");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Das Plugin kann ab sofort genutzt werden.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF Voreinstellungen");
define("PDF_LAN_3", "aktiviert");
define("PDF_LAN_4", "deaktiviert");
define("PDF_LAN_5", "Seitenabstand links");
define("PDF_LAN_6", "Seitenabstand rechts");
define("PDF_LAN_7", "Seitenabstand oben");
define("PDF_LAN_8", "Schriftart");
define("PDF_LAN_9", "Gesetzte Schriftgröße");
define("PDF_LAN_10", "Schriftgröße Seitenname");
define("PDF_LAN_11", "Schriftgröße Seitenurl");
define("PDF_LAN_12", "Schriftgröße Seitennummer");
define("PDF_LAN_13", "Logo anzeigen?");
define("PDF_LAN_14", "Seitenname anzeigen?");
define("PDF_LAN_15", "Erstellungsseiten-Url anzeigen?");
define("PDF_LAN_16", "Seitennummer anzeigen?");
define("PDF_LAN_17", "Aktualisieren");
define("PDF_LAN_18", "PDF -Voreinstellungen erfolgreich aktualisiert");
define("PDF_LAN_19", "Seite");
define("PDF_LAN_20", "Fehler Anzeige");

?>