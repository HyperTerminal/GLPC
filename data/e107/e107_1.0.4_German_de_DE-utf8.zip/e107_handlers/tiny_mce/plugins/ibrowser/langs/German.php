<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_handlers/tiny_mce/plugins/ibrowser/langs/German.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: German.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
$lang_ibrowser_title= 'Bild einfügen / bearbeiten';
$lang_ibrowser_desc= 'Bild einfügen / bearbeiten';
$lang_ibrowser_library= 'Bibliothek';
$lang_ibrowser_preview= 'Vorschau';
$lang_ibrowser_img_sel= 'Bild Auswahl';
$lang_ibrowser_img_info= 'Bild Informationen';
$lang_ibrowser_img_upload= 'Bild hochladen';
$lang_ibrowser_images= 'Bild';
$lang_ibrowser_src= 'Quelle';
$lang_ibrowser_alt= 'Beschreibung';
$lang_ibrowser_size= 'Größe';
$lang_ibrowser_align= 'Textfluß';
$lang_ibrowser_height= 'Höhe';
$lang_ibrowser_width= 'Breite';
$lang_ibrowser_reset= 'Maße zurücksetzen';
$lang_ibrowser_border= 'Rahmen';
$lang_ibrowser_hspace= 'HSpace';
$lang_ibrowser_vspace= 'VSpace';
$lang_ibrowser_select= 'Speichern';
$lang_ibrowser_delete= 'Löschen';
$lang_ibrowser_cancel= 'Abbruch';
$lang_ibrowser_uploadtxt= 'Datei';
$lang_ibrowser_uploadbt= 'Hochladen';
$lang_ibrowser_marginl = 'Rand-Links';
$lang_ibrowser_marginr = 'Rand-Rechts';
$lang_ibrowser_margint = 'Rand-Oben';
$lang_ibrowser_marginb = 'Rand-Unten';
$lang_insert_image_align_default = "Standart";
$lang_insert_image_align_left = "Links";
$lang_insert_image_align_right = "Rechts";

// error messages
$lang_ibrowser_error= 'Fehler';
$lang_ibrowser_errornoimg= 'Bitte wählen Sie ein Bild aus';
$lang_ibrowser_errornodir= 'Bibliothek exsistiert physikalisch nicht';
$lang_ibrowser_errorupload= 'Es trat ein Fehler währende des Datei hochladens auf.\nBitte versuchen Sie es später noch einmal';
$lang_ibrowser_errortype= 'Falsches Bild Dateiformat';
$lang_ibrowser_errordelete= 'Löschen fehlgeschlagen';
$lang_ibrowser_confirmdelete= 'Klicken Sie OK um das Bild zu löschen!';
$lang_ibrowser_error_width_nan= 'Breite ist keine Zahl!';
$lang_ibrowser_error_height_nan= 'Höhe ist keine Zahl!';
$lang_ibrowser_error_border_nan= 'Rahmen ist keine Zahl!';
$lang_ibrowser_error_hspace_nan= 'Horizontal space ist keine Zahl!';
$lang_ibrowser_error_vspace_nan= 'Vertical space ist keine Zahl!';

?>