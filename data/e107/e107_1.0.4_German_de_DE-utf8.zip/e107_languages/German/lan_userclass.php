<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_userclass.php $ 
|     $Revision: 255 $
|     $Date: 2012-11-24 23:39:22 +0100 (Sa, 24. Nov 2012) $
|     $Id: lan_userclass.php 255 2012-11-24 22:39:22Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Jederman (öffentlich)");
define("UC_LAN_1", "Nur für Gäste");
define("UC_LAN_2", "Keiner (inactiv)");
define("UC_LAN_3", "Nur für Mitglieder");
define("UC_LAN_4", "Nur lesen");
define("UC_LAN_5", "Nur für Admin");
define("UC_LAN_6", "Hauptseiten-Admin");

define('UC_LAN_9','Neue Benutzer');
define('UC_LAN_10', 'Such-Roboter');

?>