<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_prefs.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_prefs.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "e107 Webseiten System");
define("LAN_PREF_3", "Diese Seite benutzt <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, veröffentlicht unter den Bedingungen von <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL Lizenz.");
define("LAN_PREF_4", "zensiert");
define("LAN_PREF_5", "Foren");

?>