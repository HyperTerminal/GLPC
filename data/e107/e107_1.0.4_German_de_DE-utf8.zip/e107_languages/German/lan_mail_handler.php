<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_mail_handler.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_mail_handler.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produziert vom e107 Website System");
define("LANMAILH_2", "Dies ist eine Multi-Part Message im MIME Format.");
define("LANMAILH_3", " ist nicht korrekt formatiert");
define("LANMAILH_4", "Der server hat die Adresse abgelehnt");
define("LANMAILH_5", "Server antwortet nicht");
define("LANMAILH_6", "E-mail Server kann nicht gefunden werden.");
define("LANMAILH_7", " scheint gültig zu sein.");



?>