<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_language.php $ 
|     $Revision: 241 $
|     $Date: 2012-01-16 05:40:15 +0100 (Mo, 16. Jan 2012) $
|     $Id: lan_language.php 241 2012-01-16 04:40:15Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00", "konnte nicht erstellt werden.(besteht bereits)");
define("LANG_LAN_01", "wurde gelöscht(falls bestehend) und neu erstellt.");
define("LANG_LAN_02", "konnte nicht gelöscht werden");
define("LANG_LAN_03", "Tabellen");

define("LANG_LAN_05", "Nicht installiert");
define("LANG_LAN_06", "Tabellen erstellen");
define("LANG_LAN_07", "Markiere bestehende Tabellen?");
define("LANG_LAN_08", "Ersetze bestehende Tabellen (Daten werden verloren gehen).");
define("LANG_LAN_10", "Löschen bestätigen");
define("LANG_LAN_11", "Nichtmarkierte Tabellen von oben löschen (falls diese bestehen).");
define("LANG_LAN_12", "Multi-Language Tabellen freischalten");
define("LANG_LAN_13", "Multi-Language Voreinstellungen");
define("LANG_LAN_14", "Gesetzte Sprache der Seite");
define("LANG_LAN_15", "Bitte hier markieren um Daten der gesetzten Sprache zu kopieren.(nützlich für Links, News-Kategorien etc.) ");
define("LANG_LAN_16", "Multi-language Datenbankbenutzung");
define("LANG_LAN_17", "Gesetzte Sprache - keine zusätzlichen Tabellen erfoderlich.");
define("LANG_LAN_18", "geparkte Subdomains benutzen um Sprache zu setzen:");
define("LANG_LAN_19", "z.B. de.mydomain.com um die Sprache aud Deutsch zu stellen.");
define("LANG_LAN_20", "Bitte eine Domain pro Zeile eingeben. Z.B. meinedomain.de etc. oder frei lassen um es abzuschalten");

define("LANG_LAN_21", "Sprachpakete");

define("LANG_LAN_23", "Sprachpaket (ZIP) erstellen");
define("LANG_LAN_24", "Paket erstellen");

define("LANG_LAN_AGR", "Hinweis: Bei Benutzung dieser Tools sind Sie damit einverstanden, Ihr(e) Sprachpaket(e) mit der e107 Community zu teilen.");
define("LANG_LAN_EML", "Bitte schicken Sie Ihr Sprachpaket per E-Mail an:");

define("LANG_LAN_25", "Bitte überprüfen Sie das CORE_LC und CORE_LC2 einen Inhalt in [lcpath] haben und versuchen Sie es erneut.");
define("LANG_LAN_26", "Bitte stellen Sie sicher, dass Sie die standart Verzeichnis Namen in e107_config.php (z.B. 'e107_languages/', 'e107_plugins/' etc.) benutzen und versuchen Sie es erneut.");
define("LANG_LAN_27", "Bitte überprüfen Sie Ihre Sprachdateien ('Überprüfen') und versuchen Sie es erneut.");
define("LANG_LAN_28", "Aktivieren Sie diese Box, wenn Sie ein [e107 zertifizierter Übersetzer] sind.");

define("LANG_LAN_29", "Sie sollten die verbleibenden Fehler korrigieren bevor Sie Ihr Sprachpaket beisteuern.");
define("LANG_LAN_30", "Erscheinungsdatum");
define("LANG_LAN_31", "Kompatibilität");
define("LANG_LAN_32", "Installierte Sprachen");
define("LANG_LAN_33", "Nur Fehler während der Überprüfung anzeigen");
define("LANG_LAN_34", "Bitte überprüfen und korrigieren Sie den/die verbliebenen [x] Fehler, bevor Sie ein Sprachpaket erstellen.");
?>