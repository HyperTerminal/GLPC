<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_modcomment.php $ 
|     $Revision: 257 $
|     $Date: 2012-11-24 23:45:24 +0100 (Sa, 24. Nov 2012) $
|     $Id: lan_modcomment.php 257 2012-11-24 22:45:24Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("MDCLAN_1", "Moderiert.");
define("MDCLAN_2", "Keine Kommentare für diesen Eintrag");
define("MDCLAN_3", "Mitglied");
define("MDCLAN_4", "Gast");
define("MDCLAN_5", "Blockierung aufheben");
define("MDCLAN_6", "Blockieren");

define("MDCLAN_7", "genehmigen");
define("MDCLAN_8", "Kommentare moderieren");
define("MDCLAN_9", "Warnung! Das Löschen von ganzen Kommentaren löscht auch sämtliche Antworten!");

define("MDCLAN_10", "Optionen");
define("MDCLAN_11", "Kommentar");
define("MDCLAN_12", "Kommentare");
define("MDCLAN_13", "geblockt");
define("MDCLAN_14", "Kommentare loggen");
define("MDCLAN_15", "offen");
define("MDCLAN_16", "gelogged");
define("MDCLAN_17", "Es gibt zur Zeit keine zu genehmigende Kommentare");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>