<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_filemanager.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_filemanager.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/

define("FMLAN_1", "Hochgeladen");
define("FMLAN_2", "zu");
define("FMLAN_3", "Verzeichnis");
define("FMLAN_4", "Die hochzuladende Datei überschreitet die in der php.ini festgelegte Dateigrö&szlig;e.");
//define("FMLAN_5", "Die hochzuladende Datei überschreitet die im HTML Formular festgelegte Dateigrö&szlig;e (MAX_FILE_SIZE - Anweisung).");
//define("FMLAN_6", "Die Datei wurde nur teilweise hochgeladen.");
//define("FMLAN_7", "Es wurde keine Datei hochgeladen.");
//define("FMLAN_8", "Dateigrö&szlig;e der hochgeladenen Datei ist 0 Byte");
//define("FMLAN_9", "Die Datei wurde nicht hochgeladen. Dateiname");
define('FMLAN_10', 'Fehler');
//define("FMLAN_11", "Wahrscheinlich falsche Chmod-Rechte für das Upload Verzeischnis.");
define("FMLAN_12", "Datei");
define("FMLAN_13", "Dateien");
define("FMLAN_14", "Verzeichnis");
define("FMLAN_15", "Verzeichnisse");
define("FMLAN_16", "Root Verzeichnis");
define("FMLAN_17", "Name");
define("FMLAN_18", "Grösse");
define("FMLAN_19", "Zuletzt modifiziert");

define("FMLAN_21", "Datei Upload in dieses Verzeichnis");
define("FMLAN_22", "Upload");

define("FMLAN_26", "Gelöscht");
define("FMLAN_27", "erfolgreich");
define("FMLAN_28", "kann nicht gelöscht werden");
define("FMLAN_29", "Pfad");
define("FMLAN_30", "Level höher");
define("FMLAN_31", "Ordner");
define("FMLAN_32", "Verzeichnis auswählen");
define("FMLAN_33", "Auswählen");
define("FMLAN_34", "Gewähltes Verzeichnis");
define("FMLAN_35", "Datei Verzeichnis");
define("FMLAN_36", "Custom Menü Verzeichnis");
define("FMLAN_37", "Custom Page Verzeichnis");

define("FMLAN_38", "Datei erfolgreich verschoben nach");
define("FMLAN_39", "Es ist nicht möglich die Datei zu verschieben nach");
define("FMLAN_40", "Newspost-Images Verzeichnis");
define("FMLAN_41", "In Downloads dir. verschieben");
define("FMLAN_42", "In Downloadimages dir. verschieben");
define("FMLAN_43", "Ausgewählte Dateien löschen");
define("FMLAN_44", "Bitte bestätigen Sie die ausgewählte Datei in das DOWNLOADS Verzeichnis verschieben zu wollen.");
define("FMLAN_45", "Bitte bestätigen Sie die ausgewählte Datei in das DOWNLOADIMAGES Verzeichnis verscheiben zu wollen.");
define("FMLAN_46", "Bitte bestätigen Sie die ausgewählte Datei löschen zu wollen.");
define("FMLAN_47", "Benutzer Uploads");
define("FMLAN_48", "Ausgewähltes verschieben nach");
define("FMLAN_49", "Bitte bestätigen Sie, ausgewählte Datei verschieben zu wollen.");
define("FMLAN_50", "Verschieben");
define('FMLAN_51', 'Unbekannter Fehler: ');

?>