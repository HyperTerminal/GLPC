<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_e107_update.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_e107_update.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Aktion");
define("LAN_UPDATE_3", "Nicht notwendig");

define("LAN_UPDATE_5", "Aktualisierung vorhanden");
define("LAN_UPDATE_6", "Alle aktualisieren");
define("LAN_UPDATE_7", "Ausgeführt");
define("LAN_UPDATE_8", "Aktualisierung von");
define("LAN_UPDATE_9", "bis");
define("LAN_UPDATE_10", "Vorhandene Aktualisierungen");
define("LAN_UPDATE_11", ".617 zu .7 Update fortgeführt");
define("LAN_UPDATE_12", "Eine Ihrer Tabellen beinhaltet doppelte Eintr&auml;ge.");

?>