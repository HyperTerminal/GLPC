<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_cache.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_cache.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Aktiviere das Cache System");
define("CACLAN_2", "Setze den Cache Status");
define("CACLAN_3", "Cache System");
define("CACLAN_4", "Cache Status gesetzt");
define("CACLAN_5", "Cache leeren");
define("CACLAN_6", "Cache geleert");

define("CACLAN_7", "Cache abgestellt");
//define("CACLAN_8", "Cache Daten über MySQL gespeichert");
define("CACLAN_9", "Cache Daten als Datei auf Festplatte speichern");
define("CACLAN_10", "Das Cache Verzeichnis ist nicht beschreibbar. Bitte vergewissern Sie sich, dass dieses Verzeichnis auf CHMOD 0777 gesetzt ist");

?>