<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_frontpage.php $ 
|     $Revision: 269 $
|     $Date: 2013-03-19 20:26:49 +0100 (Di, 19. Mrz 2013) $
|     $Id: lan_frontpage.php 269 2013-03-19 19:26:49Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Hauptseiten Einstellungen aktualisiert.");
define("FRTLAN_2", "Anzeige");

define("FRTLAN_6", "Links");
//define("FRTLAN_7", "Inhaltsseite");

define("FRTLAN_12", "Hauptseiten Einstellungen aktualisieren");
define("FRTLAN_13", "Hauptseiten Einstellungen");


define("FRTLAN_15", "Andere (Bitte vollständige URL angeben):");
define("FRTLAN_16", "Fehler: Es wurde keine Inhalts-Hauptkategorie gewählt");
define("FRTLAN_17", "Fehler: Es wurde keine Inhalts-Unterkategorie gewählt");
define("FRTLAN_18", "Fehler: Kein Inhalts-Eintrag gewählt");
define("FRTLAN_19", "Inhalts-Hauptkategorie");
define("FRTLAN_20", "Inhalts-Unterkategorie");
define("FRTLAN_21", "Inhalts-Eintrag");
define("FRTLAN_22", "Eigene Seite");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Alle Benutzer");
define("FRTLAN_27", "Gäste");
define("FRTLAN_28", "Mitglieder");
define("FRTLAN_29", "Administratoren");
define("FRTLAN_31", "Alle Benutzer");
define("FRTLAN_32", "Benutzerklassen");
define("FRTLAN_33", "Bestehende Einstellungen");
define("FRTLAN_34", "Seite");

?>