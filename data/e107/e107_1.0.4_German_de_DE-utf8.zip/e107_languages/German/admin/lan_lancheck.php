<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_lancheck.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_lancheck.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Sprachedateien überprüfen/bearbeiten"); //modifiziert in 0.7.6
define("LAN_CHECK_2", "Überprüfen");
define("LAN_CHECK_3", "Überprüfung von");
define("LAN_CHECK_4", "Datei fehlt!");
define("LAN_CHECK_5", "Phrase fehlt!");

define("LAN_CHECK_7", "Phrase");

define("LAN_CHECK_8", "Eine Datei fehlt...");
define("LAN_CHECK_9", " Dateien fehlen...");
define("LAN_CHECK_10", "Kritischer Fehler: ");
define("LAN_CHECK_11", "Keine Dateien fehlen !");
define("LAN_CHECK_12", "Eine Datei ist fehlerhaft...");
define("LAN_CHECK_13", " Dateien sind fehlerhaft...");
define("LAN_CHECK_14", "Alle bestehenden Datein sind gültig !");

define("LAN_CHECK_15", "Ungültige Zeichen oder Leerzeichen vor '&lt;?php' oder nach '?&gt;' gefunden");
define("LAN_CHECK_16", "Original Datei");
define("LAN_CHECK_17", "Ein Schreibfehler trat beim Speichern der Datei auf.");
define("LAN_CHECK_18", "Sprachdateien im Standardformat liegen für dieses Plugin/Theme nicht vor.");
define("LAN_CHECK_19", "Nicht-UTF-8 codierte Zeichen gefunden!");
define("LAN_CHECK_20", "Sprachpaket erstellen");
define("LAN_CHECK_21", "Erneut überprüfen");
define("LAN_CHECK_22", "Theme");
define("LAN_CHECK_23", "Fehler gefunden");
define("LAN_CHECK_24", "Zusammenfassung");
define("LAN_CHECK_25", "Themes");
define("LAN_CHECK_26", "Datei");

?>