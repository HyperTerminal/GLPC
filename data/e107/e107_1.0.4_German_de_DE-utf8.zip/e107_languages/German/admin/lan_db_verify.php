<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_db_verify.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_db_verify.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Die SQL Datei kann nicht gelesen werden<br /><br />Bitte stellen Sie sicher dass; die Datei <b>core_sql.php</b> in dem  <b>/admin/sql</b> Verzeichnis existiert.");
define("DBLAN_2", "Alles überprüfen");
define("DBLAN_4", "Tabelle");
define("DBLAN_5", "Feld");
define("DBLAN_6", "Status");
define("DBLAN_7", "Anmerkungen");
define("DBLAN_8", "Falsche Zuordnung");
define("DBLAN_9", "Momentan");
define("DBLAN_10", "sollte sein");
define("DBLAN_11", "fehlendes Feld");
define("DBLAN_12", "Extra Feld!");
define("DBLAN_13", "Tabelle fehlt!");
define("DBLAN_14", "Zu prüfende(n) Tabelle(n) auswählen");
define("DBLAN_15", "Überprüfung starten");
define("DBLAN_16", "SQL Überprüfung - Version");
define("DBLAN_17", "Zurück");
define("DBLAN_18", "Tabellen");
define("DBLAN_19", "Versuch zu korrigieren");
define("DBLAN_20", "Versuch Tabellen zu korrigieren");
define("DBLAN_21", "Korrigiere ausgewähle Items");
define("DBLAN_22", "kann nicht gelesen werden");


?>