<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_admin_log.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_admin_log.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Datum");
define("LAN_ADMINLOG_2", "Titel");
define("LAN_ADMINLOG_3", "Beschreibung");
define("LAN_ADMINLOG_4", "User IP");
define("LAN_ADMINLOG_5", "User ID");
define("LAN_ADMINLOG_6", "Information Icon");
define("LAN_ADMINLOG_7", "Information Nachricht");
define("LAN_ADMINLOG_8", "Bemerkung Icon");
define("LAN_ADMINLOG_9", "Bemerkung Nchricht");
define("LAN_ADMINLOG_10", "Warnung Icon");
define("LAN_ADMINLOG_11", "Warnung Nchricht");
define("LAN_ADMINLOG_12", "Fatal Icon");
define("LAN_ADMINLOG_13", "Fatal Fehlermeldung");

?>