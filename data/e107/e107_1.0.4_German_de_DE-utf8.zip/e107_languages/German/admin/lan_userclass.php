<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_userclass.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_userclass.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Schicke E-Mail Benachrichtigung an");
define("UCSLAN_2", "Privilegien aktualisiert");
define("UCSLAN_3", "Hallo ");
define("UCSLAN_4", "Ihre Privilegien wurden aktualisiert");
define("UCSLAN_5", "Sie haben nun Zugriff auf die folgenden Bereiche");
define("UCSLAN_6", "Klasse für Benutzer festlegen");
define("UCSLAN_7", "Klassen festlegen");
define("UCSLAN_8", "Benutzer benachrichtigen");
define("UCSLAN_9", "Klassen aktualisiert.");
define("UCSLAN_10", "Glückwunsch");
define("UCSLAN_12", "Nur für Mitglieder");


?>