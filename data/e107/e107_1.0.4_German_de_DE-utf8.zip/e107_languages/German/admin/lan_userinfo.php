<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_userinfo.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_userinfo.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Die IP Adresser des Absenders kann nicht gefunden werden - keine Information vorhanden.");
//define("USFLAN_2", "Fehler");
define("USFLAN_3", "Nachricht geschickt von IP Adresse");
define("USFLAN_4", "Host");
define("USFLAN_5", "Klicken Sie hier um diese IP Adresse auf die Verbannungs Seite zu legen");
define("USFLAN_6", "BenutzerID");
define("USFLAN_7", "Benutzer Information");

?>