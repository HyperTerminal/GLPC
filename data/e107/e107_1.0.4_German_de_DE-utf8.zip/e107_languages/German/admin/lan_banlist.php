<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_banlist.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_banlist.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Verbannung aufgehoben.");
define("BANLAN_2", "Keine Verbannungen.");
define("BANLAN_3", "Existierende Verbannungen");
define("BANLAN_4", "Verbannung aufheben");
define("BANLAN_5", "Geben Sie entweder IP, E-Mail Adresse oder Host ein");
define("BANLAN_7", "Grund");
define("BANLAN_8", "Adresse verbannen");
define("BANLAN_9", "Benutzer von Seite verbannen, per e-mail, IP, oder Host-Adresse");
define("BANLAN_10", "IP / Email / Grund");
define("BANLAN_11", "Auto-Verbannung: Mehr als 10 fehlerhafte Loginversuche");
define("BANLAN_12", "Bitte beachten: Reverse DNS ist moment abgeschaltet, es muss angestellt werden um Verbannung  des Host zu ermöglichen. Verbannung über IP und E-mail wird weiterhin funktionieren.");
define("BANLAN_13", "Anmerkung: Um einen Benutzer per Benutzername zu löschen, gehen Sie bitte zur Benutzer Adminseite: ");
define("BANLAN_78", "Zu viele Zugriffe (--ZUGRIFFE-- Anforderungen in einer bestimmten Zeit)");

?>