<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/admin/lan_footer.php $ 
|     $Revision: 180 $
|     $Date: 2012-01-01 21:08:54 +0100 (So, 01. Jan 2012) $
|     $Id: lan_footer.php 180 2012-01-01 20:08:54Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Seitenname");
define("FOOTLAN_2", "Haupt Administrator");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "Erstellt");
define("FOOTLAN_5", "Admin-Theme");
define("FOOTLAN_6", "von");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installations Datum");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Seiten Info");
define("FOOTLAN_14", "Zeige Dokumentationen");
define("FOOTLAN_15", "Dokumentationen");
define("FOOTLAN_16", "Datenbank");
define("FOOTLAN_17", "Zeichensatz");
define("FOOTLAN_18", "Seiten-Theme");
define("FOOTLAN_19", "Aktuelle Server Zeit");
define("FOOTLAN_20", "Sicherheitsstufe");
?>