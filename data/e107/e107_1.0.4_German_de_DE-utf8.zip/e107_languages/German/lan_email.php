<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - german language file
|     UTF-8 encoded
|     translated for: http://www.e107cms.de
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $HeadURL: https://svn.code.sf.net/p/e107german/code/trunk/e107_0.7/e107_languages/German/lan_email.php $ 
|     $Revision: 115 $
|     $Date: 2010-09-26 06:00:45 +0200 (So, 26. Sep 2010) $
|     $Id: lan_email.php 115 2010-09-26 04:00:45Z lars78 $
|     $Author: lars78 $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }
 
define("LAN_EMAIL_1", "Von:");
define("LAN_EMAIL_2", "IP Adresse des Absenders:");
define("LAN_EMAIL_3", "Email von ");
define("LAN_EMAIL_4", "Email senden");
define("LAN_EMAIL_5", "Email Eintrag für einem Freund");
define("LAN_EMAIL_6", "Ich denke dieser Eintrag könnte von Interesse sein von");
define("LAN_EMAIL_7", "e-Mail an");
define("LAN_EMAIL_8", "Kommentar");
define("LAN_EMAIL_9", "Sorry - E-Mail kann nicht gesendet werden");
define("LAN_EMAIL_10", "Mail versandt an");
define("LAN_EMAIL_11", "E-Mail versandt");
define("LAN_EMAIL_12", "Fehler");
define("LAN_EMAIL_13", "Email Artikel an einen Freund");
define("LAN_EMAIL_14", "Email Newseintrag an einen Freund");
define("LAN_EMAIL_15", "Benutzer Name: ");
define("LAN_EMAIL_106", "Dieses scheint keine gültige E-Mail Adresse zu sein");
define("LAN_EMAIL_185", "Artikel senden");
define("LAN_EMAIL_186", "News senden");
define("LAN_EMAIL_187", "E-Mail Adresse des Empfängers");
define("LAN_EMAIL_188", "Ich dachte diese News könnten Sie interessieren");
define("LAN_EMAIL_189", "Ich dachte dieser Artikel könnte für Sie von Interesse sein");
define("LAN_EMAIL_190", "Bitte sichtbaren Code eingeben");

?>