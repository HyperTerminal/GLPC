<?php

$lang_ibrowser_title= 'Inds&#230;t / Rediger Billede';
$lang_ibrowser_desc= 'Inds&#230;t / Rediger Billede';
$lang_ibrowser_library= 'Bibliotek';
$lang_ibrowser_preview= 'Fremvis';
$lang_ibrowser_img_sel= 'Billede valg';
$lang_ibrowser_img_info= 'Billede informationer';
$lang_ibrowser_img_upload= 'Billede upload';
$lang_ibrowser_images= 'Billeder';
$lang_ibrowser_src= 'Kilde';
$lang_ibrowser_alt= 'Beskrivelse';
$lang_ibrowser_size= 'St&#248;rrelse';
$lang_ibrowser_align= 'Tekst flow';
$lang_ibrowser_height= 'H&#248;jde';
$lang_ibrowser_width= 'Bredde';
$lang_ibrowser_reset= 'Nulstil Dimensioner';
$lang_ibrowser_border= 'Kant';
$lang_ibrowser_hspace= 'HRum';
$lang_ibrowser_vspace= 'VRum';
$lang_ibrowser_select= 'Gem';
$lang_ibrowser_delete= 'Slet';
$lang_ibrowser_cancel= 'Annuller';
$lang_ibrowser_uploadtxt= 'Fil';
$lang_ibrowser_uploadbt= 'Upload';
$lang_ibrowser_marginl = 'Margen-Venstre';
$lang_ibrowser_marginr = 'Margen-H&#248;jre';
$lang_ibrowser_margint = 'Margen-Top';
$lang_ibrowser_marginb = 'Margen-Bund';
$lang_insert_image_align_default = "Standard";
$lang_insert_image_align_left = "Venstre";
$lang_insert_image_align_right = "H&#248;jre";

// error messages
$lang_ibrowser_error= 'Fejl';
$lang_ibrowser_errornoimg= 'V&#230;lg venligst et billede';
$lang_ibrowser_errornodir= 'Bibliotek eksisterer ikke fysisk';
$lang_ibrowser_errorupload= 'En fejl opstod under fil upload.\nPr&#248;v venligst igen senere';
$lang_ibrowser_errortype= 'Forkert billede fil type';
$lang_ibrowser_errordelete= 'Slet fejlede';
$lang_ibrowser_confirmdelete= 'Klik OK for at slette billede!';
$lang_ibrowser_error_width_nan= 'Bredde er ikke et tal!';
$lang_ibrowser_error_height_nan= 'H&#248;jde er ikke et tal!';
$lang_ibrowser_error_border_nan= 'Kant er ikke et tal!';
$lang_ibrowser_error_hspace_nan= 'Horisontalt rum er ikke et tal!';
$lang_ibrowser_error_vspace_nan= 'Verticalt rum er ikke et tal!';

?>