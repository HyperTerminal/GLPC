<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/Danish/lan_alt_auth_conf.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/03/23 16:01:01 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("LAN_ALT_2", "Opdater indstillinger");
define("LAN_ALT_3", "Vælg alternativ Autoriserings Type");
define("LAN_ALT_4", "Konfigurer parametre for");
define("LAN_ALT_5", "Konfigurer autorisations parametre");
define("LAN_ALT_6", "Fejlet forbindelse handling");
define("LAN_ALT_7", "Hvis forbindelsen til alternativ metode fejler, hvordan skal det håndteres?");
define("LAN_ALT_8", "Bruger ikke fundet handling");
define("LAN_ALT_9", "Hvis brugernavn ikke findes ved brug af alternativ metode, hvordan skal det håndteres?");
define("LAN_ALT_10", "Fejl i Login");
define("LAN_ALT_11", "Brug e107 bruger table");
define("LAN_ALT_PAGE", "Alternative godkendelse");


?>