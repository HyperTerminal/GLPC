<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/alt_auth/languages/Danish/lan_ldap_auth.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/11/23 00:02:52 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Database Type:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Brugernavn:");
define("OTHERDB_LAN_4", "Kodeord:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabel");
define("OTHERDB_LAN_7", "Brugernavn Felt:");
define("OTHERDB_LAN_8", "Kodeord Felt:");
define("OTHERDB_LAN_9", "Kodeord Metode:");
define("OTHERDB_LAN_10", "Configurer otherdb auth");
define("OTHERDB_LAN_11", "** De flg. felter er ikke krævede hvis der bruges en e107 database");
?>