<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/counter_menu/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:03 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("COUNTER_L1", "Admin besøg tælles ikke");
define("COUNTER_L2", "Denne side idag");
define("COUNTER_L3", "I alt");
define("COUNTER_L4", "Denne side nogensinde");
define("COUNTER_L5", "Unikke");
define("COUNTER_L6", "Site ...");
define("COUNTER_L7", "Tæller");
define("COUNTER_L8", "Admin besked: <b>Statistik logning er slået fra.</b><br />For at aktivere, skal du installere Statistik Lognings plugin fra din <a href='".e_ADMIN."plugin.php'>plugin håndtering</a>, og aktiver den fra <a href='".e_PLUGIN."log/admin_config.php'>konfigurations delen</a>.");

?>