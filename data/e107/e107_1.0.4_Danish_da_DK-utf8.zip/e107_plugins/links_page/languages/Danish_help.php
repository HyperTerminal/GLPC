<?php
/*
+---------------------------------------------------------------+
|        e107 website system Danish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/links_page/languages/Danish_help.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/17 17:56:41 $
|        $Author: SteppeR - Admin $
+---------------------------------------------------------------+
*/
define("LAN_ADMIN_HELP_0", "Linkside´s hjælpe område");
define("LAN_ADMIN_HELP_1", "<i>Administration af links kategori siden viser alle kategorier til stede.</i><br /><br /><b> detaljeret liste </ b> <br />du se en liste over alle kategorier med deres ikon, navn og beskrivelse, optioner, og sorteringsmuligheder.<br /><br /><b>forklaring af ikoner</b><br />".LINK_ICON_LINK." : link til kategorien<br /><br />".LINK_ICON_EDIT." :redigere kategorien<br /><br />".LINK_ICON_DELETE." :Slet kategori<br /><br />".LINK_ICON_ORDER_UP." :op-knappen giver dig mulighed for at flytte kategorien elementet et hak op<br /><br />. ".LINK_ICON_ORDER_DOWN." : ned-knappen giver dig mulighed for at flytte kategorien et hak ned for<br /><br /><b>ordre</ b><br />her kan du manuelt indstille rækkefølgen af alle kategorier. Du er nødt til at ændre værdierne i valgbokse til din ønskede rækkefølge, og klik på opdater orden knappen nedenfor for at gemme den nye rækkefølge. <br />");
define("LAN_ADMIN_HELP_2", "<i>lav en link kategorier, side lader dig tilføje nye kategorier </i> <br /> <br /> Du kan uploade et nyt ikon, og efter upload tildele ikonet til kategori.");
define("LAN_ADMIN_HELP_3", "<i>administration links siden, først viser alle kategorier.</i><br /><br />".LINK_ICON_LINK." : Link til kategori<br /><br />".LINK_ICON_EDIT." : Klik på ikonet for at få vist alle links i denne kategori<br />");
define("LAN_ADMIN_HELP_4", "<i>lav et link side, lader dig tilføje et nyt link</i> <br /><br />Du kan uploade et nyt ikon, og efter upload tildele ikonet til linket.<br /><br / >åben typen lader dig definere, hvordan linket skal åbnes, når en bruger klikker på det.");
define("LAN_ADMIN_HELP_5", "<i>de indsendte links side vises alle links, der er indsendt af brugere</i><br /><br /><b>detaljeret liste</b><br />Du se linket url, navnet på den bruger, der har indsendt linket og muligheder.<br /><br /><b> forklaring af ikoner</b><br />".LINK_ICON_EDIT." : Indlæg de indsendte link til linket skabe form<br /><br /> ".LINK_ICON_DELETE." : Slet de indsendte linket<br />");
define("LAN_ADMIN_HELP_6", "<i>Indstillingssiden tillader dig at skifte den måde links_page plugin opfører sig på </i><br /><br /> generale indstillinger<br /> disse indstillinger er generalt brugt overalt i link siden.<br /><br /> personlige link managerer<br /> de personlige link managerer er priviligerede brugere som kan redigere de link som de selv har added.<br /><br /> kategori side<br /> her kan du skifte indstillinger for kategori siden.<br /><br /> links side<br /> Disse indstillinger er brugt på links siden.<br /><br /> henvisnings side<br /> Disse indstillinger er brugt i toppen af henvisnings links siden.<br /><br /> bedøm side<br /> Disse indstillinger er brugt i toppen af bedømmelses links siden.<br />");
define("LAN_ADMIN_HELP_7", "<i>rediger en link kategori side, lader dig redigere en eksisterende kategori</i><br /><br />Du kan uploade et nyt ikon, og efter upload tildele ikonet til en kategori.<br />Du kan opdatere tidsstempel af linket ved at markere feltet.");
define("LAN_ADMIN_HELP_8", "<i>denne side viser alle eksisterende links i den valgte kategori.</i><br /><br /><b>detaljeret liste </b><br />du se en liste af forbindelser med deres billede, navne, indstillinger og sortering muligheder.<br /><br /><b>forklaring af ikoner</b> <br />". LINK_ICON_LINK." : Link til hjemmesiden <br /><br />".LINK_ICON_EDIT." : Edit linket<br /> <br />".LINK_ICON_DELETE." : slet linket<br /> <br />".LINK_ICON_ORDER_UP." : Op-knappen giver dig mulighed for at flytte et link op i listen<br /> <br />. ".LINK_ICON_ORDER_DOWN." : Ned-knappen giver dig mulighed for at flytte et link ned i listen<br /><br /><b>ordre</b><br />Her kan du manuelt indstille rækkefølgen af ​​alle links. Du er nødt til at ændre værdierne i boksen til din ønskede rækkefølge, og klik på opdater knappen nedenfor for at gemme den nye rækkefølge.<br />");
define("LAN_ADMIN_HELP_9", "<i>rediger link side, lader dig redigere et eksisterende link</i><br /><br />Du kan uploade et nyt ikon, og efter upload tildele ikonet til linket.<br /><br / >åben typen lader dig definere, hvordan linket skal åbnes, når en bruger klikker på det.");
define("LAN_ADMIN_HELP_10", "<i>tilføj link side, lader dig tilføjede forslået link til de eksisterende links</i><br /><br />En kort beskrivelse tilføjes i feltet Beskrivelse.<br /><br />Du kan uploade et nyt ikon, og efter upload tildele ikonet til linket.<br /><br />åben typen lader dig definere, hvordan linket skal åbnes, når en bruger klikker på det.");


?>