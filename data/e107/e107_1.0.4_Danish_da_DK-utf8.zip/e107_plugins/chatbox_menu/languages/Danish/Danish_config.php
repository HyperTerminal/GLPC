<?php
/*
+---------------------------------------------------------------+
|        e107 website system Danish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/Danish/Danish_config.php $
|        $Revision: 1.0 $
|        $Id: 2011/04/10 18:39:24 $
|        $Author: stepper $
+---------------------------------------------------------------+
*/

define("CHBLAN_1", "Chatbox indstillinger opdateret");
define("CHBLAN_2", "Modereret.");
define("CHBLAN_3", "Ingen indlæg endnu.");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "Gæst");
define("CHBLAN_6", "fjern blokering");
define("CHBLAN_7", "bloker");
define("CHBLAN_8", "slet");
define("CHBLAN_9", "Moderat Chatboks");
define("CHBLAN_10", "Moderat indlæg");
define("CHBLAN_11", "Chatbox indlæg at vise");
define("CHBLAN_12", "mængden af indlæg, der vises i chatboksen");
define("CHBLAN_13", "Udskift links");
define("CHBLAN_14", "hvis afkrydset, vil links blive erstattet af teksten i rubrik nedenfor");
define("CHBLAN_15", "Udskift streng hvis aktiveret");
define("CHBLAN_16", "Links vil blive udskiftet med denne tekst");
define("CHBLAN_17", "Tekstombrydning tæller");
define("CHBLAN_18", "ord længere end det antal du indstiller her, vil blive pakket");
define("CHBLAN_19", "Opdater chatbox indstillinger");
define("CHBLAN_20", "Chatbox indstillinger");
define("CHBLAN_21", "Beskære");
define("CHBLAN_22", "Slet indlæg ældre end en hvis tid");
define("CHBLAN_23", "Slet indlæg ældre end");
define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En uge");
define("CHBLAN_26", "En månede");
define("CHBLAN_27", "- Slet alle indlæg -");
define("CHBLAN_28", "Chatbox besåret.");
define("CHBLAN_29", "Vis chatboxen inden for scroll sider");
define("CHBLAN_30", "Højde");
define("CHBLAN_31", "Vis smylis");
define("CHBLAN_32", "Moderator brugergruppe");
define("CHBLAN_33", "Bruger tæller genberegnes");
define("CHBLAN_34", "Genberegne bruger indlæg antal");
define("CHBLAN_35", "Genberegne");
define("CHBLAN_36", "Chatbox Visnings indstillinger");
define("CHBLAN_37", "Normal Chatbox");
define("CHBLAN_38", "Brug javascript kode til at updater indlæg dynamisk (AJAX)");


?>