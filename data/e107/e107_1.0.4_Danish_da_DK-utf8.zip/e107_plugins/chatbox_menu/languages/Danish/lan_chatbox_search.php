<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/chatbox_menu/languages/Danish/lan_chatbox_search.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:02 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatboks");

?>