<?php
/*
+---------------------------------------------------------------+
|        e107 website system Danish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Danish/lan_forum_notify.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/17 17:47:39 $
|        $Author: SteppeR - Admin $
+---------------------------------------------------------------+
*/

define("NT_LAN_FT_1", "Forum Arrangementer");
define("NT_LAN_FO_1", "Forum tråd indsendt");
define("NT_LAN_MP_1", "Forum indlæg blev indsendt");
define("NT_LAN_FD_1", "Forum tråd slettet");
define("NT_LAN_FP_1", "Forum besked slettet");
define("NT_LAN_FM_1", "Forum tråd flyttet");
define("NT_LAN_FO_3", "Forum tråd oprettet af");
define("NT_LAN_FO_4", "Forum navn");
define("NT_LAN_FO_5", "Emne");
define("NT_LAN_FO_6", "Beskeder");
define("NT_LAN_FO_7", "Ny forum tråd oprettet");
define("NT_LAN_MP_3", "Forum besked skrevet af");
define("NT_LAN_MP_4", "Forum navne");
define("NT_LAN_MP_6", "Beskeder");
define("NT_LAN_MP_7", "Ny forum besked oprettet");
define("NT_LAN_FD_3", "Forum tråd oprettet af");
define("NT_LAN_FD_4", "Forum navn");
define("NT_LAN_FD_5", "Emne");
define("NT_LAN_FD_6", "Besked");
define("NT_LAN_FD_7", "Forum tråd er slettet");
define("NT_LAN_FD_8", "Forum tråd slettet af");
define("NT_LAN_FP_3", "Forum besked skrevet af");
define("NT_LAN_FP_4", "Forum navn");
define("NT_LAN_FP_6", "Besked");
define("NT_LAN_FP_7", "Forum besked er slettet");
define("NT_LAN_FP_8", "Forum besked slettet af");
define("NT_LAN_FM_3", "Forum tråd oprettet af");
define("NT_LAN_FM_4", "Gammelt emne");
define("NT_LAN_FM_5", "Nyt emne");
define("NT_LAN_FM_6", "Gammelt (kilde) forum navn");
define("NT_LAN_FM_7", "Ny (destination) forum navn");
define("NT_LAN_FM_8", "Forum tråd er flyttet");
define("NT_LAN_FM_9", "Forum tråd er flyttet af");


?>