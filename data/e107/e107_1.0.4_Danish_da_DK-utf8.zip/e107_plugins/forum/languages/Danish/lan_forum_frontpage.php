<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Danish/lan_forum_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/18 16:58:24 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("FOR_FP_1", "Forum");

?>