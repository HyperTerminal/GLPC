<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Danish/lan_forum_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/18 15:17:11 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Vælg forum");
define("FOR_SCH_LAN_3", "Alle Forums");
define("FOR_SCH_LAN_4", "Hele indlæg");
define("FOR_SCH_LAN_5", "Som del af en tråd");

?>