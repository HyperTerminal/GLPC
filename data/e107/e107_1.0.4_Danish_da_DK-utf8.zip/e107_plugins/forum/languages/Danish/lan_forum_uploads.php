<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Danish/lan_forum_uploads.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/07/18 15:17:11 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Uploadede filer i forum');
define('FRMUP_2','Fil slettet');
define('FRMUP_3','Fejl: kan ikke slette fil');
define('FRMUP_4','Fil sletning');
define('FRMUP_5','Filnavn');
define('FRMUP_6','Resultat');
define('FRMUP_7','Fundet i tråd');
define('FRMUP_8','IKKE FUNDET');
define('FRMUP_9','Ingen uploadede filer fundet');
define('FRMUP_10','Slet');
	
?>