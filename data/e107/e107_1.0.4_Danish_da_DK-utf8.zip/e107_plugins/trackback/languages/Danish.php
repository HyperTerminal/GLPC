<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/trackback/languages/Danish.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/09/14 18:05:46 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("TRACKBACK_L1", "Konfigurer Trackback");
define("TRACKBACK_L2", "Pluginen muliggør trackback i nyhederne.");
define("TRACKBACK_L3", "Trackback er installeret og aktiv.");
define("TRACKBACK_L4", "Indstillinger gemt.");
define("TRACKBACK_L5", "Til");
define("TRACKBACK_L6", "Fra");
define("TRACKBACK_L7", "Aktiver trackback");
define("TRACKBACK_L8", "Trackback URL tekst");
define("TRACKBACK_L9", "Gem indstillinger");
define("TRACKBACK_L10", "Trackback indstillinger");
define("TRACKBACK_L11", "Trackback addresse for dette emne:");

define("TRACKBACK_L12", "Ingen Trackback til dette emne");
define("TRACKBACK_L13", "Rediger Trackback");
define("TRACKBACK_L14", "Slet");
define("TRACKBACK_L15", "Trackback sletted.");

?>