<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/comment_menu/languages/Danish.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/11/23 00:03:20 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/



define("CM_L1", "Ingen kommentarer endnu.");
define("CM_L2", "");
define("CM_L3", "Titel");
define("CM_L4", "Antal kommentarer der skal vises?");
define("CM_L5", "Antal tegn der skal vises?");
define("CM_L6", "præfiks for for lange kommentarer?");
define("CM_L7", "Vis original nyhedstitel i menuen?");
define("CM_L8", "Nye kommentarer menu konfiguration");
define("CM_L9", "Opdater menu indstillinger");
define("CM_L10", "Kommentar menu konfiguration gemt");
define("CM_L11", "d");
define("CM_L12", "Sv:");
define("CM_L13", "Skrevet af");


?>