<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/featurebox/languages/Danish.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/07/18 14:58:43 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("FBLAN_01", "Facilitet boks");
define("FBLAN_02", "Dette Plugin lader dig at vise en boks ovenover nyhederne med faciliteter eller hvad man nu ønsker. Beskederne kan enten vises tilfældigt eller dynamisk overtonet.");
define("FBLAN_03", "Konfigurer facilitet boks");
define("FBLAN_04", "Facilitet boks plugin er installeret. Tilføj beskeder og konfigurer: gå tilbage til hoved admin siden og klik på facilitet boks ikonet i plugin håndteringen.");
define("FBLAN_05", "Endnu ingen facilitet boks beskeder");
define("FBLAN_06", "Eksisterende facilitet boks beskeder");
define("FBLAN_07", "Titel / Overskrift");
define("FBLAN_08", "Besked tekst");
define("FBLAN_09", "Synlighed for beskeder");
define("FBLAN_10", "Opret facilitet boks besked");
define("FBLAN_11", "Opdater facilitet boks besked");
define("FBLAN_12", "Tilstand");
define("FBLAN_13", "Tilfældig visning af beskeder");
define("FBLAN_14", "Vis kun denne besked");
define("FBLAN_15", "Besked tilføjet.");
define("FBLAN_16", "Besked opdateret.");
define("FBLAN_17", "Felter er tomme");
define("FBLAN_18", "Facilitet boks besked slettet");
define("FBLAN_19", "Indstillinger");
define("FBLAN_20", "Rediger");
define("FBLAN_21", "Slet");
define("FBLAN_22", "Gengivelses type");
define("FBLAN_23", "I tema boksen");
define("FBLAN_24", "Enkel");
define("FBLAN_25", "Skabelon");
define("FBLAN_26", "man kan bruge forskellige skabeloner for hver besked, tilføj skabeloner til e107_plugins/featurebox/templates/ mappen");

?>