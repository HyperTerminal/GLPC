<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Danish/lan_content_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/06 22:12:03 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("CONT_FP_1", "Indholds kategori");
define("CONT_FP_2", "hovedside");

?>