<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/userlanguage_menu/languages/Danish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/09/11 17:50:08 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/








define("UTHEME_MENU_L1", "Sprogvalg");
define("UTHEME_MENU_L2", "Vælg sprog");
define("UTHEME_MENU_L3", "tabeller");
?>