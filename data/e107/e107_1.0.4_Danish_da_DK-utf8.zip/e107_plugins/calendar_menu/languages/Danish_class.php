<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Danish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Danish_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/04/04 15:18:49 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/

define("EC_LAN_RECUR_00", "Nej");
define("EC_LAN_RECUR_01", "Årligt");
define("EC_LAN_RECUR_02", "Halvårligt");
define("EC_LAN_RECUR_03", "kvartalsvis");
define("EC_LAN_RECUR_04", "månedligt");
define("EC_LAN_RECUR_05", "Ugentligt ");
define("EC_LAN_RECUR_06", "hver anden uge");
define("EC_LAN_RECUR_07", "Ugentligt ");
define("EC_LAN_RECUR_08", "dagligt");
define("EC_LAN_RECUR_100", "Søndag i måneden");
define("EC_LAN_RECUR_101", "Mandag i måneden");
define("EC_LAN_RECUR_102", "Tirsdag i måneden");
define("EC_LAN_RECUR_103", "Onsdag i måneden");
define("EC_LAN_RECUR_104", "Torsdag i måneden");
define("EC_LAN_RECUR_105", "Fredag i måneden");
define("EC_LAN_RECUR_106", "Lørdag i måneden");
define("EC_LAN_RECUR_1100", "Første");
define("EC_LAN_RECUR_1200", "Anden");
define("EC_LAN_RECUR_1300", "Tredje");
define("EC_LAN_RECUR_1400", "fjerde");
define("NT_LAN_EC_1", "Begivenhedskalenders Begivenheder");
define("NT_LAN_EC_2", "Begivenhed Opdateret");
define("NT_LAN_EC_3", "Opdateret af");
define("NT_LAN_EC_4", "Ip Adresse");
define("NT_LAN_EC_5", "Besked");
define("NT_LAN_EC_6", "Begivenhedskalender - Begivenhed tilføjet");
define("NT_LAN_EC_7", "Ny begivenhed tilføjet");
define("NT_LAN_EC_8", "Begivenhedskalender - Begivenhed modificeret");
define("EC_ADM_01", "Begivenhedskalender - Begivenhed tilføjet");
define("EC_ADM_02", "Begivenhedskalender - Begivenhed redigeret");
define("EC_ADM_03", "Begivenhedskalender - Begivenhed slettet");
define("EC_ADM_04", "Begivenhedskalender - stor Begivenhed slettet");
define("EC_ADM_05", "Begivenhedskalender - flere Begivenheder tilføjeret");
define("EC_ADM_06", "Begivenhedskalender - Hoved indstillinger ændret");
define("EC_ADM_07", "Begivenhedskalender - FE indstillinger ændret");
define("EC_ADM_08", "Begivenhedskalender - Kategori tilføjet");
define("EC_ADM_09", "Begivenhedskalender - Kategori ændret");
define("EC_ADM_10", "Begivenhedskalender - Kategori slettet");
define("EC_ADM_11", "Begivenhedskalender - Gammel begivenhed slettet");


?>