<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:02 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define('CLOCK_MENU_L1','Klok menu konfiguration gemt');
define('CLOCK_MENU_L2','Titel');
define('CLOCK_MENU_L3','Opdater menu indstillinger');
define('CLOCK_MENU_L4','Klokke menu konfiguration');
define('CLOCK_MENU_L5', 'Mandag,');
define('CLOCK_MENU_L6', 'Tirsdag,');
define('CLOCK_MENU_L7', 'Onsdag,');
define('CLOCK_MENU_L8', 'Torsdag,');
define('CLOCK_MENU_L9', 'Fredag,');
define('CLOCK_MENU_L10', 'Lørdag,');
define('CLOCK_MENU_L11', 'Søndag,');
define('CLOCK_MENU_L12', 'Januar');
define('CLOCK_MENU_L13', 'Februar');
define('CLOCK_MENU_L14', 'Marts');
define('CLOCK_MENU_L15', 'April');
define('CLOCK_MENU_L16', 'Maj');
define('CLOCK_MENU_L17', 'Juni');
define('CLOCK_MENU_L18', 'Juli');
define('CLOCK_MENU_L19', 'August');
define('CLOCK_MENU_L20', 'September');
define('CLOCK_MENU_L21', 'Oktober');
define('CLOCK_MENU_L22', 'November');
define('CLOCK_MENU_L23', 'December');
define('CLOCK_MENU_L24', '');
?>