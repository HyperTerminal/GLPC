<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/clock_menu/languages/admin/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:02 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("CLOCK_AD_L1", "Klok menu konfiguration gemt");
define("CLOCK_AD_L2", "Overskrift");
define("CLOCK_AD_L3", "Opdater menu indstillinger");
define("CLOCK_AD_L4", "Klok menu konfiguration");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Hvis markeret, vil du få vist tid med US format (0-12 AM/PM format). Ikke markeret vil du få vist 'militært' format 0-24 format");
define("CLOCK_AD_L7", "Dato prefix");
define("CLOCK_AD_L8", "Hvis sproget kræver et kort ord før datoen (Eks 'le' for fransk eller 'den' for dansk...), brug dette felt. hvis krævet, ellers lad det være tomt.");
define("CLOCK_AD_L9", "Endelse 1");
define("CLOCK_AD_L10", "Endelse 2");
define("CLOCK_AD_L11", "Endelse 3");
define("CLOCK_AD_L12", "Endelse 4 og mere");
define("CLOCK_AD_L13", "Hvis dit sprog kræver at få vist en endelse lige efter dato, udfyld disse felter med kun endelsen (Eks: 'st' for 1, 'nd' for 2, 'rd' for 3 and 'th' for 4 og mere for engelske brugere). Hvis ikke krævet lad være tom.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>