<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/lastseen/languages/Danish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/14 21:35:51 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LSP_LAN_1", "Sidst set");


?>