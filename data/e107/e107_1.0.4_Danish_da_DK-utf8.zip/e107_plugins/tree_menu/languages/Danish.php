<?php
/*
+---------------------------------------------------------------+
|        e107 website system - Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/Danish.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/10/12 17:16:15 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








define("TREE_L1", "Konfigurer træmenu");
define("TREE_L2", "Opdater træmenu indstillinger");
define("TREE_L3", "Træ menu konfiguration gemt.");
define("TREE_L4", "Til");
define("TREE_L5", "Fra");
define("TREE_L6", "CSS klasse der skal bruges til links der ikke kan åbnes");
define("TREE_L7", "CSS klasse der skal bruged til links der kan åbnes");
define("TREE_L8", "CSS klasse der skal bruges til åbnede links");
define("TREE_L9", "Brug afstandsholder klasse mellem hoved links");

?>