<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_themes/e107v4a/languages/Danish.php,v $
|        $Revision: 1.1 $
|        $Date: 2005/07/06 22:12:04 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "Læs/Skriv Kommentar:");
define("LAN_THEME_2", "Kommentarer er slået fra på dette emne");
define("LAN_THEME_3", "Læs resten...");
define("LAN_THEME_4", "Skrevet af");
define("LAN_THEME_5", "&nbsp;");
define("LAN_THEME_6", "e107.v4 tema af <a href='http://e107.org' rel='external'>jalist</a>");


?>