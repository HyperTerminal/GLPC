<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/05/15 13:50:06 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Bruger tilmelding");
define("NT_LAN_UV_1", "Bruger tilmelding verifiseret");
define("NT_LAN_UV_2", "Bruger session tekst");
define("NT_LAN_UV_3", "Bruger Login Navn:");
define("NT_LAN_UV_4", "Bruger IP:");
define("NT_LAN_LI_1", "Bruger logget ind");
define("NT_LAN_LO_1", "Bruger logget ud");
define("NT_LAN_LO_2", " logget ud fra site");
define("NT_LAN_FL_1", "Gentagen handling Banlysning");
define("NT_LAN_FL_2", "IP addresse banlyst for gentage handlinger mod site");
define("NT_LAN_SN_1", "Nyhed Tilføjet");
define("NT_LAN_NU_1", "Opdateret");
define("NT_LAN_ND_1", "Nyhed Slettet");
define("NT_LAN_ND_2", "Slettet nyheds id");
define("NT_LAN_CM_1", "En Brugerkommentar Afventer Godkendelse");


?>