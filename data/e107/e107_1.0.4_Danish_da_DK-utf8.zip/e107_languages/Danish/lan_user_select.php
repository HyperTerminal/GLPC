<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/14 16:26:54 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Vælg bruger");
define("US_LAN_2", "Vælg brugergruppe");
define("US_LAN_3", "Alle brugere");
define("US_LAN_4", "Find brugernavn");
define("US_LAN_5", "Bruger(e) fundet");
define("US_LAN_6", "Søg");
?>