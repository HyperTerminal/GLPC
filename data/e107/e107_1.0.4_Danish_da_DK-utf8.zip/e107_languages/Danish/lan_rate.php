<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_rate.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/07/06 22:12:00 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("RATELAN_0", "stem");
define("RATELAN_1", "stemmer");
define("RATELAN_2", "hvordan vil du bedømme dette emne?");
define("RATELAN_3", "tak for din stemme");
define("RATELAN_4", "ikke bedømt");
define("RATELAN_5", "Bedøm");

?>