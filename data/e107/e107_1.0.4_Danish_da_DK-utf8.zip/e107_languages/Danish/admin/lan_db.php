<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_db.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:41 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("DBLAN_1", "Kerne indstillinger er nu sikkerhedskopieret i databasen");
define("DBLAN_2", "Klik på knappen for at gemme en sikkerhedskopi af din e107 database");
define("DBLAN_3", "Sikkerhedskopier SQL database");
define("DBLAN_4", "Klik på knappen for at Kontrollere databasen");
define("DBLAN_5", "Kontroller database");
define("DBLAN_6", "Klik på knappen for at Optimere databasen");
define("DBLAN_7", "Optimer SQL databasen");
define("DBLAN_8", "Klik på knappen for at sikkerhedskopiere dine kerne indstillinger");
define("DBLAN_9", "Sikkerhedskopier indstillinger");
define("DBLAN_10", "Database værktøjer");
define("DBLAN_11", "MySQL database");
define("DBLAN_12", "optimeret");
define("DBLAN_13", "Tilbage");
define("DBLAN_14", "Færdig");
define("DBLAN_15", "Tjek for tilgængelige database opdateringer");
define("DBLAN_16", "Tjek for opdateringer");
define("DBLAN_17", "Inst. Navn");
define("DBLAN_18", "Inst. Værdi");
define("DBLAN_19", "Tryk på knappen for at åbne indstillings editoren (kun for advancerede brugere)");
define("DBLAN_20", "Indstillings Editor");
define("DBLAN_21", "Slet Markerede");
define("DBLAN_22", "Plugin: Vis og Scan");
define("DBLAN_23", "Scanning Afsluttet");
define("DBLAN_24", "Navn");
define("DBLAN_25", "Mappe");
define("DBLAN_26", "Inkluderede tilføjelser");
define("DBLAN_27", "Installeret");
define("DBLAN_28", "Tryk på knappen for at scanne plugin mapperne for ændringer");
define("DBLAN_29", "Scan plugin mapper");
define("DBLAN_30", " (Hvis en tilføjelse viset en fejl, kontroller om der er tegn eller kode udenfor PHP start/slut tegnene)");
define("DBLAN_31", "OK");
define("DBLAN_32", "Fejl");
define("DBLAN_33", "Utilgængelig");
define("DBLAN_34", "Ej kontrolleret");
define("DBLAN_35", "Klik på knappen for at kontrollere gyldigheden af bruger tabellen");
define("DBLAN_36", "Kontroller bruger tabel");


?>