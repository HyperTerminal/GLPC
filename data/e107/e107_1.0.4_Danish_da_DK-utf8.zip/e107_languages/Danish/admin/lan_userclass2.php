<?php
/*
+---------------------------------------------------------------+|        e107 website system  Language File|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_userclass2.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:01 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("UCSLAN_1", "Slettet alle brugere fra gruppen");
define("UCSLAN_2", "Gruppe brugere opdateret");
define("UCSLAN_3", "Gruppe slettet.");
define("UCSLAN_4", "Bekræft sletning af denne brugergruppe");
define("UCSLAN_5", "Gruppe opdateret.");
define("UCSLAN_6", "Gruppe gemt");
define("UCSLAN_7", "Ingen brugergrupper endnu.");
define("UCSLAN_8", "Eksisterende grupper");
define("UCSLAN_11", "Bekræft");
define("UCSLAN_12", "Gruppenavn");
define("UCSLAN_13", "Gruppebeskrivelse");
define("UCSLAN_14", "Opdater brugergruppe");
define("UCSLAN_15", "Opret en ny gruppe");
define("UCSLAN_16", "Tilføj brugere til gruppe");
define("UCSLAN_17", "Fjern");
define("UCSLAN_18", "Ryd gruppe");
define("UCSLAN_19", "Tilføj brugere til");
define("UCSLAN_20", "gruppe");
define("UCSLAN_21", "Brugergruppe indstillinger");
define("UCSLAN_22", "Brugere - klik for at flytte ...");
define("UCSLAN_23", "Brugere i denne gruppe ...");
define("UCSLAN_24", "Hvem kan adminstrere gruppe");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Brugernavne");
define("UCSLAN_27", "Tilbage");


?>