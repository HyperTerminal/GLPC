<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_links.php,v $
|        $Revision: 1.6 $
|        $Date: 2006/11/23 00:02:41 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LCLAN_1", "Indstillinger gemt");
define("LCLAN_2", "Link oprettet i databasen.");
define("LCLAN_3", "Link opdateret i databasen.");
// define("LCLAN_4", "Link slettet.");
define("LCLAN_6", "Ordnen opateret");
define("LCLAN_8", "Eksisterende links");
define("LCLAN_12", "Link afviklings type");
define("LCLAN_15", "Linknavn");
define("LCLAN_16", "Link URL");
define("LCLAN_17", "Linkbeskrivelse");
define("LCLAN_18", "Linkknap / Ikon");
define("LCLAN_19", "åben Link metode");
define("LCLAN_20", "åbn i samme vindue");
define("LCLAN_23", "åbn i nyt vindue");
define("LCLAN_24", "åbn i 600x400 mini-vindue");
define("LCLAN_25", "Linkgruppe");
define("LCLAN_26", "Dette vil gøre at linket kun er synlig, for den  brugergruppe.");
define("LCLAN_27", "Opdater Link");
define("LCLAN_28", "Opret link");
define("LCLAN_29", "Links");
define("LCLAN_30", "ryk op");
define("LCLAN_31", "ryk ned");
define("LCLAN_39", "Vis billeder");
define("LCLAN_53", "Link");
define("LCLAN_54", "slettet");
define("LCLAN_58", "Er du sikker på du vil slette dette link?");
define("LCLAN_61", "Ingen links");
define("LCLAN_62", "Linksforside");
define("LCLAN_63", "Opret nyt link");
define("LCLAN_68", "Indstillinger");
define("LCLAN_78", "Vis beskrivelse som Skærmtip");
define("LCLAN_79", "Beskrivelse vil blive vist når musen peger på linket");
define("LCLAN_80", "Aktiver udvidene under-menuer");
define("LCLAN_81", "Undermenuer vil kun blive vist ved klik på deres forælder. (Link forældre er slået fra)");
define("LCLAN_83", "Undermenu generator");
define("LCLAN_88", "Site Links Egenskaber");
define("LCLAN_89", "Billede");

define("LCLAN_91", "Flyt");
define("LCLAN_95", "Gruppe");

define("LCLAN_96", "Vist i dit tema som");


define("LINKLAN_1", "Åbner i et 800x600 vindue");
define("LINKLAN_2", "Forælder");
define("LINKLAN_3", "Ingen Forælder (Normalt Link)");
define("LINKLAN_4", "Underlink Generator");
define("LINKLAN_5", "Generer Underlinks");
define("LINKLAN_6", "Opret underlinks fra:");
define("LINKLAN_7", "Opret underlinks under hvilket link?");
define("LINKLAN_8", "Nyheds Kategorier");
define("LINKLAN_9", "Download Kategorier");
define("LINKLAN_10", "Opret Underlink");

?>