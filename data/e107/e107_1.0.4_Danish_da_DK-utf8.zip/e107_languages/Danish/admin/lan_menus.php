<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_menus.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/05/15 13:50:06 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("MENLAN_1", "Synlig for alle");
define("MENLAN_2", "Kun synlig for medlemmer");
define("MENLAN_3", "Kun synlig for administratorer");
define("MENLAN_4", "Kun synlig for :");
// define("MENLAN_5", "gruppe");
define("MENLAN_6", "Gem indstillinger");
define("MENLAN_7", "Konfigurer indstillinger for ");
define("MENLAN_8", "Indstillinger opdateret");
define("MENLAN_9", "Ny egen menu installeret");
define("MENLAN_10", "Ny menu installeret");
define("MENLAN_11", "Menu fjernet");
define("MENLAN_12", "Aktiver - vælg område");
define("MENLAN_13", "Aktiver i område");
define("MENLAN_14", "Område");
define("MENLAN_15", "Deaktiver");
define("MENLAN_16", "Konfigurer");
define("MENLAN_17", "Ryk op");
define("MENLAN_18", "Ryk ned");
define("MENLAN_19", "Flyt til Område");
define("MENLAN_20", "Synlighed");

// define("MENLAN_21", "Kun synlig for gæster");
define("MENLAN_22", "Inaktive menuer");

define("MENLAN_23", "Flyt til bunden");
define("MENLAN_24", "Flyt til toppen");
define("MENLAN_25", "Funktion ...");

define("MENLAN_26", "Menu vil kun blive <strong>VIST</strong> på flg. sider");
define("MENLAN_27", "Menu vil kun blive <strong>SKJULT</strong> på flg. sider");
define("MENLAN_28", "Skriv en side pr. linje, skrive nok af url til at kunne kende den ordentligt. hvis du behøver at slutningen af urlen passer precist, så brug et ! til sidst i sidenavnet <br />For eksempel: <strong>page.php?1!</strong>");

define("MENLAN_29", "Vælg layout");
define("MENLAN_30", "For at se menu områderne og deres positioner for specielle layouts, vælg det specielle layout her:");
define("MENLAN_31", "Standard lLayout");
define("MENLAN_32", "Nyhedstop layout");
define("MENLAN_33", "Specielt lLayout");
define("MENLAN_34", "Indlejret");
define("MENLAN_35", "Konfigurer menuer");
define("MENLAN_36", "Vælg menu(er) til aktivering");
define("MENLAN_37", "og hvor de skal aktiveres.");
define("MENLAN_38", "Hold CTRL nede for at vælge flere menuer.");


?>