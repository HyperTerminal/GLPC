<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/11/23 00:02:41 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Dato");
define("LAN_ADMINLOG_2", "Titel");
define("LAN_ADMINLOG_3", "Beskrivelse");
define("LAN_ADMINLOG_4", "Bruger IP");
define("LAN_ADMINLOG_5", "Bruger ID");
define("LAN_ADMINLOG_6", "Informativt Ikon");
define("LAN_ADMINLOG_7", "Informativ Besked");
define("LAN_ADMINLOG_8", "Notits Ikon");
define("LAN_ADMINLOG_9", "Notits Besked");
define("LAN_ADMINLOG_10", "Advarsel Ikon");
define("LAN_ADMINLOG_11", "Advarsel Besked");
define("LAN_ADMINLOG_12", "Fatal Fejl Ikon");
define("LAN_ADMINLOG_13", "Fatal Fejl Besked");

?>