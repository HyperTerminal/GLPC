<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_lancheck.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/11/23 00:02:41 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Vælg sprog til verifcering");
define("LAN_CHECK_2", "Begynd verificering");
define("LAN_CHECK_3", "Verificering af");
define("LAN_CHECK_4", "Fil mangler!");
define("LAN_CHECK_5", "Udtryk mangler!");
define("LAN_CHECK_7", "udtryk");
define("LAN_CHECK_8", "En fil mangler...");
define("LAN_CHECK_9", " filer mangler...");
define("LAN_CHECK_10", "Kritisk fejl: ");
define("LAN_CHECK_11", "Ingen fil mangler !");
define("LAN_CHECK_12", "En fil er forkert...");
define("LAN_CHECK_13", " filer er forkerte...");
define("LAN_CHECK_14", "Alle eksisterende filer er gyldige !");
define("LAN_CHECK_15", "Forbudte tegn før '<?php'");
define("LAN_CHECK_16", "Original Fil");
define("LAN_CHECK_17", "Et skrive problem opstod ved gemning af filen.");
define("LAN_CHECK_18", "Sprogfiler i standard formatet er IKKE tilgængelige til dette plugin/theme.");
define("LAN_CHECK_19", "Ikke-UTF-8 Tegn fundet!");
define("LAN_CHECK_20", "Generer sprog pakke");
define("LAN_CHECK_21", "Bekræft igen");
define("LAN_CHECK_22", "Tema");
define("LAN_CHECK_23", "Fejl fundet");
define("LAN_CHECK_24", "Resumé");
define("LAN_CHECK_25", "Temaer");
define("LAN_CHECK_26", "Fil");


?>