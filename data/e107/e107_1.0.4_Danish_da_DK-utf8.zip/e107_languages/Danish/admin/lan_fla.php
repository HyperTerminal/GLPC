<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_fla.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/21 12:58:11 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Mislykkede login forsøg");
define("FLALAN_2", "Ingen mislykkede login forsøg er blevet logget");
define("FLALAN_3", "Forsøg slettet");
define("FLALAN_4", "Bruger forsøgte at logge på med et forkert brugernavn/adgangskodeord");
define("FLALAN_5", "IP(er) banlyst");
define("FLALAN_6", "Dato");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP adresse/ Vært");
define("FLALAN_9", "Egenskaber");
define("FLALAN_10", "Slet / Banlys markerede poster");
define("FLALAN_11", "marker alle slet tjekbokse");
define("FLALAN_12", "fjern markering i alle slet tjekbokse");
define("FLALAN_13", "marker alle banlys tjekbokse");
define("FLALAN_14", "fjern markering i alle banlys tjekbokse");
define("FLALAN_15", "Følgende IP addresser er blevet autobanlyste - bruger forsøgte at logge på mere end ti gange");
define("FLALAN_16", "slet denne auto banlys liste");
define("FLALAN_17", "Auto-banlys liste slettet");
?>