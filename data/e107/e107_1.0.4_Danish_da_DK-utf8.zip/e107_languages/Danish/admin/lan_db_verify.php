<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_db_verify.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/07/06 22:12:01 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("DBLAN_1", "Kunne ikke l&aelig;se sql datafilerne<br /><br />Tjek at filen <b>core_sql.php</b> eksisterer i  <b>/admin/sql</b> mappen. !");
define("DBLAN_2", "Tjekker alle");
define("DBLAN_4", "Tabel");
define("DBLAN_5", "Felt");
define("DBLAN_6", "Status");
define("DBLAN_7", "NB");
define("DBLAN_8", "Matcher ikke");
define("DBLAN_9", "Nuværende");
define("DBLAN_10", "skal være");
define("DBLAN_11", "Manglende felt");
define("DBLAN_12", "Ekstra felt!");
define("DBLAN_13", "Manglende tabel!");
define("DBLAN_14", "Vælg tabeller til validering");
define("DBLAN_15", "Start validering");
define("DBLAN_16", "SQL validering");
define("DBLAN_17", "Tilbage");
define("DBLAN_18", "tabeller");
define("DBLAN_19", "Forsøg at reparere");
define("DBLAN_20", "Forsøger at reparere tabeller");
define("DBLAN_21", "Reparer valgte emner");
define("DBLAN_22", " kan ikke læses");


?>