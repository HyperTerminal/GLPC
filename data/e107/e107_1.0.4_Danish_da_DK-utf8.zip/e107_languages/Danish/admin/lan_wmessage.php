<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_wmessage.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/05/15 13:50:06 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
// define("WMGLAN_1", "Besked til gæster");
// define("WMGLAN_2", "Besked til medlemmer");
// define("WMGLAN_3", "Besked til administratorer");
// define("WMGLAN_4", "Godkend");
// define("WMGLAN_5", "Opret velkomstbesked");
// define("WMGLAN_6", "Aktiver?");
// define("WMGLAN_7", "Velkomstbesked opdateret");

define("WMLAN_00","Velkomstbeskeder");
define("WMLAN_01","Opret ny besked");
define("WMLAN_02","Besked");
define("WMLAN_03","Synlighed");
define("WMLAN_04","Besked tekst");

define("WMLAN_05","Omkrans");
define("WMLAN_06","Hvis markeret, vil beskeden vises inden i en boks");
define("WMLAN_07","Overgå standard system til at bruge {WMESSAGE} shortcode:");
// define("WMLAN_08","Indstillinger");

define("WMLAN_09","Ingen velkomstbeskeder indstillet endnu");
define("WMLAN_10","Besked Overskrift");

?>