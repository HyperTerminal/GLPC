<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_meta.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:41 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags opdateret i databasen");
define("METLAN_2", "Indtast yderligere metatags");
define("METLAN_3", "Indtast nye metatag indstillinger");
define("METLAN_4", "Opdateret");
define("METLAN_5", "Skriv din beskrivelse her");
define("METLAN_6", "skriv en, liste, af, nøgleord, her");
define("METLAN_7", "skriv copyright info her");
define("METLAN_8", "Metatags");

define("METLAN_9", "Beskrivelse");
define("METLAN_10", "Nøgleord");
define("METLAN_11", "Ophavsret");
define("METLAN_12", "Brug Nyheds titel og opsummering som meta-beskrivelse på nyheds sider.");
define("METLAN_13", "Forfatter");

?>