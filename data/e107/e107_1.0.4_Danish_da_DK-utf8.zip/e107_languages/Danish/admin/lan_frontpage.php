<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_frontpage.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/07/06 22:12:01 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("FRTLAN_1", "Indstillinger opdateret.");
define("FRTLAN_2", "Visning");
define("FRTLAN_6", "Links");
define("FRTLAN_12", "Opdater indstillinger");
define("FRTLAN_13", "Indstillinger");
define("FRTLAN_15", "Andet (skriv url):");
define("FRTLAN_16", "fejl: ingen indhold hovedgruppe valgt");
define("FRTLAN_17", "fejl: ingen indhold under kategori valgt");
define("FRTLAN_18", "fejl: intet indholds emne valgt");
define("FRTLAN_19", "indhold hovedgruppe");
define("FRTLAN_20", "indhold kategori");
define("FRTLAN_21", "indhold emne");
define("FRTLAN_22", "Brugerside");
define("FRTLAN_26", "alle brugere");
define("FRTLAN_27", "Gæster");
define("FRTLAN_28", "Medlemmer");
define("FRTLAN_29", "Administratorer");
define("FRTLAN_31", "Alle Brugere");
define("FRTLAN_32", "Bruger Gruppe");
define("FRTLAN_33", "Nuværende Indstillinger");
define("FRTLAN_34", "Side");


?>