<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/23 00:02:41 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Underretning");
define("NT_LAN_2", "Modtag e-mail underretning til");
define("NT_LAN_3", "fra");
define("NT_LAN_4", "Hovedadministrator");
define("NT_LAN_5", "Brugergruppe");
define("NT_LAN_6", "E-mail");
define("NU_LAN_1", "Medlem begivenhed");
define("NU_LAN_2", "Medlem tilmelding");
define("NU_LAN_3", "Medlem konto verificering");
define("NU_LAN_4", "Medlem log på");
define("NU_LAN_5", "Medlem log af");
define("NS_LAN_1", "Sikkerheds begivenheder");
define("NS_LAN_2", "IP banned for gentagne handlinger mod websted");
define("NN_LAN_1", "Nyheds begivenheder");
define("NN_LAN_2", "Nyhed indsendt af bruger");
define("NN_LAN_3", "Nyhed oprettet af admin");
define("NN_LAN_4", "Nyhed redigeret af admin");
define("NN_LAN_5", "Nyhed slettet af admin");
define("NF_LAN_1", "Fil Begivenheder");
define("NF_LAN_2", "Fil uploadet af bruger");
define("CM_LAN_1", "Kommentar Begivenheder");
define("CM_LAN_2", "Kommentar indsendt af brugeren, som afventer godkendelse");


?>