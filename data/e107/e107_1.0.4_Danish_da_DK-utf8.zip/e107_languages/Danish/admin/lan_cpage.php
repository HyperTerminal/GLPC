<?php
/*
+---------------------------------------------------------------+
|        e107 website system  UTF-8 Language File - Danish
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_cpage.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/05/16 10:39:43 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("CUSLAN_1", "Titel");
define("CUSLAN_2", "Type");
define("CUSLAN_3", "Muligheder");
define("CUSLAN_4", "Slet side?");
define("CUSLAN_5", "Eksisterende sider");
define("CUSLAN_7", "Menunavn");
define("CUSLAN_8", "Titel/overskrift");
define("CUSLAN_9", "Tekst");
define("CUSLAN_10", "Tillad bedømmelse af side");
define("CUSLAN_11", "Forside");
define("CUSLAN_12", "Opret side");
define("CUSLAN_13", "Tillad kommentarer");
define("CUSLAN_14", "Adgangskode beskyttet side");
define("CUSLAN_15", "indtast adgangskode til beskyttet side");
define("CUSLAN_16", "Opret link i hovedmenu");
define("CUSLAN_17", "indtast linlnavn");
define("CUSLAN_18", "Side/link synlig for");
define("CUSLAN_19", "Opdater side");
define("CUSLAN_20", "Opret side");
define("CUSLAN_21", "Opdater menu");
define("CUSLAN_22", "Opret menu");
define("CUSLAN_23", "Rediger side");
define("CUSLAN_24", "Opret ny side");
define("CUSLAN_25", "Rediger menu");
define("CUSLAN_26", "Opret ny menu");
define("CUSLAN_27", "Side gemt");
define("CUSLAN_28", "Side slettet");
define("CUSLAN_29", "Vis sider hvis ingen side er valgt");
define("CUSLAN_30", "Varighed for cookie (i sekunder)");
define("CUSLAN_31", "Opret menu");
define("CUSLAN_32", "Konverter gamle sider/menuer");
define("CUSLAN_33", "Side indstillinger");
define("CUSLAN_34", "Begynd konvertering");
define("CUSLAN_35", "Special side opdatering er færdig - opdateret");
define("CUSLAN_36", "Gå tilbage til forsiden hvis du vil sætte indstillingerne for hver side.");
define("CUSLAN_37", "Opdater special side");
define("CUSLAN_38", "til");
define("CUSLAN_39", "fra");
define("CUSLAN_40", "Gem indstillinger");

define("CUSLAN_41", "Vis forfatter og dato informationer");
define("CUSLAN_42", "Ingen sider defineret endnu");
define('CUSLAN_43', 'ingen titel menu: ');
define('CUSLAN_44', 'ingen titel side');

?>