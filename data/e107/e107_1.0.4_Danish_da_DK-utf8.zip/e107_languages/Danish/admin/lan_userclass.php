<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_userclass.php,v $
|        $Revision: 1.2 $
|        $Date: 2005/07/06 22:12:01 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/

define("UCSLAN_1", "Send notifikations e-mail til");
define("UCSLAN_2", "Opdateret privileger");
define("UCSLAN_3", "Kære");
define("UCSLAN_4", "Dine privileger/rettigheder er nu opdateret til ");
define("UCSLAN_5", "Du har adgang til følgende grupper");
define("UCSLAN_6", "Sæt gruppe for bruger");
define("UCSLAN_7", " Sæt gruppe");
define("UCSLAN_8", "Oplys bruger");
define("UCSLAN_9", "Grupper opdateret.");
define("UCSLAN_10", "Venlig hilsen");
define('UCSLAN_12', 'Kun Medlemmer');

?>