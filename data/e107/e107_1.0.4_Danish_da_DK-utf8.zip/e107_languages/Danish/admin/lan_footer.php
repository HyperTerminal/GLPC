<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/lan_footer.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/11/05 12:17:33 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("FOOTLAN_1", "Websted");
define("FOOTLAN_2", "Hovedadministrator");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "revision");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "af");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installationsdato");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "vært");
define("FOOTLAN_11", "PHP version");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Websted info");
define("FOOTLAN_14", "Vis dokumentation");
define("FOOTLAN_15", "Dokumentation");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Tegnsæt");
define("FOOTLAN_18", "Site Tema");
define("FOOTLAN_19", "Nuværende server tid");
define("FOOTLAN_20", "Sikringsniveau");


?>