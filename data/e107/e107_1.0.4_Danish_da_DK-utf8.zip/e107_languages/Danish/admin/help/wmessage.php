<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/wmessage.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Denne side lader dig skrive en besked der vil blive vist øverst på din forside hele tiden når den er aktiveret. Du kan lave forskellige beskeder for gæster, registrerede/logget-ind medlemmer og administratorer.";
$ns -> tablerender("Velkomstbesked hjælp", $text);
?>