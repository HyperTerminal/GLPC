<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/content.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Du kan tilføje en normal side til dit site ved at bruge denne funktion. Et link til den nye side vil blive skabt i din Hoved menu. For eksempel hvis du laver en side med link navnet 'Test', vil et link kaldet 'Test' komme fremi din link box efter den nye side er tilføjet.<br />
Hvis du vil have en overskrift på din side, så skriv den i Overskrift feltet.";
$ns -> tablerender("Indhold Hjælp", $text);
?>