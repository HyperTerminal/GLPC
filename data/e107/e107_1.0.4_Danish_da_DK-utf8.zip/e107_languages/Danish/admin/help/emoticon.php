<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/emoticon.php,v $
|        $Revision: 1.5 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Med smileys aktiveret, vil standard smiley tekst strenge blive erstattet af deres
respektive smiley billede i alt indhold på dit site.";

$ns -> tablerender("Smiley Hjælp", $text);
?>