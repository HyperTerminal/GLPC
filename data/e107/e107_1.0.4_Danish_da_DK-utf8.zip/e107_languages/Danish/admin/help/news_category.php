<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/news_category.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Du kan opdele dine nyheder i forskellige kategorier, og tillade brugerne at vise nyhederne fra en bestemt kategori. <br /><br />Upload dine nyheds iconer enten ".e_THEME."-yourtheme-/images/ eller themes/shared/newsicons/.";
$ns -> tablerender("Nyheds Kategori Hjælp", $text);
?>