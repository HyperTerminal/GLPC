<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/frontpage.php,v $
|        $Revision: 1.3 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$caption = "Forside Hjælp";
$text = "Fra denne side kan du vælge hvad der vises på forsiden af dit site, standard siden er nyheder.";
$ns -> tablerender($caption, $text);
?>