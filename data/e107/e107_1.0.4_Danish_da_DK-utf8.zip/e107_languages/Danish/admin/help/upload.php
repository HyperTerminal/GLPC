<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/admin/help/upload.php,v $
|        $Revision: 1.2 $
|        $Date: 2006/01/10 16:31:21 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/








if (!defined('e107_INIT')) { exit; }

$text = "Her fra kan du tillade / nægte brugere evnen til at uploade filer og håndtere disse filer der er blevet uploadet.";
$ns -> tablerender("Offentlige Uploads Hjælp", $text);
?>