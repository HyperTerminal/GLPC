<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/01/06 20:58:08 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','Kontroller bruger database');
define('LAN_CKUSER_02','Dette vil kontrollere for diverse potentiele problemer med din brugerdatabase');
define('LAN_CKUSER_03','Hvis du har mange brugere, kan det tage lang tid eller sågar time-out');
define('LAN_CKUSER_04','Fortsæt');
define('LAN_CKUSER_05','Kontreller for ens login navne');
define('LAN_CKUSER_06','Vælg funktioner der skal udføres');
define('LAN_CKUSER_07','Ens brugernavne fundet');
define('LAN_CKUSER_08','Ingen ens brugernavne fundet');
define('LAN_CKUSER_09','Bruger Navn');
define('LAN_CKUSER_10','Bruger ID');
define('LAN_CKUSER_11','Vist Navn');
define('LAN_CKUSER_12','Kontroller for ens email adresser');
define('LAN_CKUSER_13','Ens email adresser fundet');
define('LAN_CKUSER_14','Email adresse');
define('LAN_CKUSER_15','Ingen ens email adresser fundet');
define('LAN_CKUSER_16','Find tilfælde hvor brugernavn er en andens login navn');
define('LAN_CKUSER_17','Bruger og login navne i konflikt');
define('LAN_CKUSER_18','Bruger A');
define('LAN_CKUSER_19','Bruger B');
define('LAN_CKUSER_20','');

?>