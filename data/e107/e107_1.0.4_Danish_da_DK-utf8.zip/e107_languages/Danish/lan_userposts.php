<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|     
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_userposts.php,v $
|        $Revision: 1.3 $
|        $Date: 2005/12/14 16:16:10 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Brugerindlæg");

define("UP_LAN_0", "Alle forumindlæg for ");
define("UP_LAN_1", "Alle kommentarer for ");
define("UP_LAN_2", "Indlæg");
define("UP_LAN_3", "Vist");
define("UP_LAN_4", "Svar");
define("UP_LAN_5", "Sidste indlæg");
define("UP_LAN_6", "Indlæg");
define("UP_LAN_7", "Ingen kommentarer");
define("UP_LAN_8", "Ingen indlæg");
define("UP_LAN_9", " den ");
define("UP_LAN_10", "Sv");
define("UP_LAN_11", "Skrevet : ");
define("UP_LAN_12", "Søg");
define("UP_LAN_13", "Kommentarer");
define("UP_LAN_14", "Forum indlæg");
define("UP_LAN_15", "Sv");
define("UP_LAN_16", "IP adresse");
?>