<?php
/*+---------------------------------------------------------------+|        e107 website system  Language File||        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_top.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:00 $|        $Author: e107dk $+---------------------------------------------------------------+*/
define("PAGE_NAME", "Top Brugere");
define("TOP_LAN_0", "Top forumskribenter");
define("TOP_LAN_1", "Brugernavn");
define("TOP_LAN_2", "Indlæg");
define("TOP_LAN_3", "Top kommentarskribenter");
define("TOP_LAN_4", "Kommentarer");
define("TOP_LAN_5", "Top chatboksskribenter");
define("TOP_LAN_6", "Websted bedømmelse");
define("LAN_1", "Tråd");
define("LAN_2", "Indlæg");
define("LAN_3", "Vist");
define("LAN_4", "Svar");
define("LAN_5", "Seneste indlæg");
define("LAN_6", "Tråde");
define("LAN_7", "Mest aktive tråde");
define("LAN_8", "Top skribenter");

?>