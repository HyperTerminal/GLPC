<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File
|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_print.php,v $
|        $Revision: 1.4 $
|        $Date: 2006/11/23 00:02:40 $
|        $Author: e107dk $
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Udskrifts venlig"); }

define("LAN_PRINT_86", "Kategori:");
define("LAN_PRINT_87", "af ");
define("LAN_PRINT_94", "Oprettet af");
define("LAN_PRINT_135", "Nyhed: ");
define("LAN_PRINT_303", "Denne nyhed er fra ");
define("LAN_PRINT_304", "Titel: ");
define("LAN_PRINT_305", "Underoverskrift: ");
define("LAN_PRINT_306", "Er fra ");
define("LAN_PRINT_307", "Udskriv denne side");

define("LAN_PRINT_1", "udskrifts venlig");


?>