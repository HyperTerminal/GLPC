<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/12/04 16:20:39 $
|     $Author: e107dk $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 Powered website");
define("LAN_PREF_2", "e107 Website system");
define("LAN_PREF_3", "Dette site kører med <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>.<br /> og er frigivet under <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU GPL licensen</a>.");
define("LAN_PREF_4", "censoreret");
define("LAN_PREF_5", "Forums");

?>