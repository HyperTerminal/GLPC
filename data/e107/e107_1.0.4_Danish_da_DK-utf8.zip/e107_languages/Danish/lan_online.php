<?php
/*
+---------------------------------------------------------------+
|        e107 website system  Language File|
|        $Source: /cvsroot/e107/e107_langpacks/e107_languages/Danish/lan_online.php,v $|        $Revision: 1.2 $|        $Date: 2005/07/06 22:12:00 $|        $Author: e107dk $+---------------------------------------------------------------+
*/
define("ONLINE_EL1", "Gæster: ");
define("ONLINE_EL2", "Medlemmer: ");
define("ONLINE_EL3", "På denne side: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmer");
define("ONLINE_EL6", "Nyeste medlem");
define("ONLINE_EL7", "på");
define("ONLINE_EL8", "flest nogensinde online: ");
define("ONLINE_EL9", "den");
define("ONLINE_EL10", "Medlemsnavn");
define("ONLINE_EL11", "På side");
define("ONLINE_EL12", "Svarer på");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Indlæg");
define("ONLINE_EL15", "Side");
define("CLASSRESTRICTED", "Gruppebegrænset side");
define("ARTICLEPAGE", "Artikel/Anmeldelse");
define("CHAT", "Chat");
define("COMMENT", "Kommentarer");
define("DOWNLOAD", "Downloads");
define("EMAIL", "email.php");
define("FORUM", "Forumhoved index");
define("LINKS", "Links");
define("NEWS", "Nyheder");
define("OLDPOLLS", "Gamle afstemninger");
define("POLLCOMMENT", "Afstemning");
define("PRINTPAGE", "Udskriv");
define("LOGIN", "Log på");
define("SEARCH", "Søger");
define("STATS", "Statistik");
define("SUBMITNEWS", "Tilføj nyheder");
define("UPLOAD", "Uploads");
define("USERPAGE", "Brugerprofiler");
define("USERSETTINGS", "Brugerindstillinger");
define("ONLINE", "Brugere online");
define("LISTNEW", "Vis nyheder");
define("USERPOSTS", "Brugerindlæg");
define("SUBCONTENT", "Tilføj Artikel/Anmeldelse");
define("TOP", "Top skribenter/flest aktive tråde");
define("ADMINAREA", "Administration");
define("BUGTRACKER", "Fejlsøger");
define("EVENT", "Begivenheds liste");
define("CALENDAR", "Begivenheds kalender");
define("FAQ", "Faq");
define("PM", "Privat besked");
define("SURVEY", "Undersøgelse");
define("ARTICLE", "Artikel");
define("CONTENT", "Indholdsside");
define("REVIEW", "Anmeldelse");

?>