<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/
define("ADLAN_PM", "Asmeniniai pranešimai");
define("ADLAN_PM_1", "Norėdami aktyvuoti, prašom eikite į meniu konfigūravimo ekraną ir pasirinkite private_msg vienoje iš meniu sričių. <br /><br /> Jeigu Jums reikia konvertuoti ankstesnės versijos pranešimus, prašom eikite į pagrindinį šio įskiepio konfigūravimo puslapį ir pasirinkite nuorodą 'konvertuoti'.");
define("ADLAN_PM_2", "Konfigūruoti asmeninius pranešimus");
define("ADLAN_PM_3", "AP nustatymų nerasta, nustatytos numatytosios vertės");
define("ADLAN_PM_4", "Nustatymai pakeisti");
define("ADLAN_PM_5", "Apribojimai pasirinktai narių grupei jau egzistuoja");
define("ADLAN_PM_6", "Apribojimai sėkmingai įvesti");
define("ADLAN_PM_7", "Apribojimai neįvesti - nežinoma klaida");
define("ADLAN_PM_8", "Apribojimų būklė pakeista");
define("ADLAN_PM_9", " - Apribojimai sėkmingai panaikinti");
define("ADLAN_PM_10", " - Apribojimai nepanaikinti - nežinoma klaida");
define("ADLAN_PM_11", " - Apribojimai sėkmingai pakeisti");
define("ADLAN_PM_12", "AP nustatymai");
define("ADLAN_PM_13", "AP konvertavimas");
define("ADLAN_PM_14", "AP apribojimai");
define("ADLAN_PM_15", "Naujas AP apribojimas");
define("ADLAN_PM_16", "Įskiepio pavadinimas");
define("ADLAN_PM_17", "Rodyti naują AP animaciją");
define("ADLAN_PM_18", "Rodyti narių vardus išsiskleidžiančiame meniu");
define("ADLAN_PM_19", "PERSKAITYTI pranešimai trinami po");
define("ADLAN_PM_20", "NEPERSKAITYTI pranešimai trinami po");
define("ADLAN_PM_21", "iššokantis langas gavus naują AP");
define("ADLAN_PM_22", "iššokančio lango uždelsimas");
define("ADLAN_PM_23", "Apriboti naudojimąsi AP");
define("ADLAN_PM_24", "Kiek AP rodoma viename puslapyje");
define("ADLAN_PM_25", "Įjungti pranešimus apie naujus AP paštu");
define("ADLAN_PM_26", "Leisti nariams reikalauti patvirtinimo paštu apie perskaitytą AP");
define("ADLAN_PM_27", "Leisti siųsti priedus");
define("ADLAN_PM_28", "Maksimalus priedų dydis");
define("ADLAN_PM_29", "Leisti siųsti visiems nariams");
define("ADLAN_PM_30", "Leisti siųsti keliems adresatams");
define("ADLAN_PM_31", "Leisti siųsti narių grupei");
define("ADLAN_PM_32", "Keisti nustatymus");
define("ADLAN_PM_33", "Neaktyvus (be apribojimų)");
define("ADLAN_PM_34", "pranešimų skaičių");
define("ADLAN_PM_35", "dėžutės talpą");
define("ADLAN_PM_36", "Vartotojų grupė");
define("ADLAN_PM_37", "Maksimalus AP skaičius");
define("ADLAN_PM_38", "Talpos apribojimai (KB)");
define("ADLAN_PM_39", "Gautų AP dėžutė :");
define("ADLAN_PM_40", "Siųstų AP dėžutė :");
define("ADLAN_PM_41", "Šiuo metu nėra nustatyta jokių apribojimų.");
define("ADLAN_PM_42", "Keisti apribojimus");
define("ADLAN_PM_43", "Sukurti naujus apribojimus");
define("ADLAN_PM_44", "sekundžių");
define("ADLAN_PM_45", "Apriboti naudojimąsi AP pagal:");
define("ADLAN_PM_46", "AP konvertavimas");
define("ADLAN_PM_47", "Jūs neturite senų ankstesnės versijos pranešimų, galite išinstaliuoti senąjį įskiepį");
define("ADLAN_PM_48", "Jūs turite {OLDCOUNT} ankstesnės versijos pranešimų, prašom nuspręskite, ką norėtumėte daryti su jais.<br /><br /> Konvertuojant pranešimus, visi sėkmingai konvertuoti pranešimai bus pašalinti iš senosios sistemos.");
define("ADLAN_PM_49", "Konvertuoti į naujos versijos AP");
define("ADLAN_PM_50", "Ištrinti senus pranešimus");
define("ADLAN_PM_51", "#{PMNUM} AP nekonvertuota");
define("ADLAN_PM_52", "pranešimų konvertuota");
define("ADLAN_PM_53", "Nerasta ką konvertuoti.");
define("ADLAN_PM_54", "Pagrindiniai nustatymai");
define("ADLAN_PM_55", "Apribojimai");
define("ADLAN_PM_56", "Konvertavimas");
define("ADLAN_PM_57", "This plugin is a fully featured Private Messaging system.");
define("ADLAN_PM_58", "Private Messenger");


?>