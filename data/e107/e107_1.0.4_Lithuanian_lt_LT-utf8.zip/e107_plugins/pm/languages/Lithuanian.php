<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/
define("LAN_PM", "Asmeniniai pranešimai");
define("LAN_PM_1", "Siųsti asmeninį pranešimą");
define("LAN_PM_2", "Kam");
define("LAN_PM_3", "Peržiūrėti");
define("LAN_PM_4", "Narių grupė");
define("LAN_PM_5", "Tema");
define("LAN_PM_6", "Pranešimas");
define("LAN_PM_7", "Jausmukai");
define("LAN_PM_8", "Priedai");
define("LAN_PM_9", "Ataskaita");
define("LAN_PM_10", "Išsiųsti man laišką, kai šis AP bus perskaitytas");
define("LAN_PM_11", "Įkelti naują bylą");
define("LAN_PM_12", "Jūs turite būti registruotas/prisijungęs vartotojas, norėdamas naudoti asmeninių žinučių sistemą.");
define("LAN_PM_13", "Jūsų siųstų pranešimų dėžutė užpildyta {PERCENT}%, Jūs nebegalite siųsti naujų AP, kol neištrinsite dalies senų");
define("LAN_PM_14", "KLAIDA: Gali būti, kad AP dubliuojasi, todėl nebuvo išsiųstas");
define("LAN_PM_15", "Jums neleidžiama siųsti pranešimų narių grupėms");
define("LAN_PM_16", "Turite būti grupės narys");
define("LAN_PM_17", "Narys nerastas");
define("LAN_PM_18", "Jums neleidžiama siųsti AP:");
define("LAN_PM_19", "Jūsų siųstų pranešimų dėžutė perpildyta, Jūs nebegalite siųsti daugiau AP");
define("LAN_PM_21", "Jeigu šis AP būtų išsiųstas, Jūsų siųstų pranešimų dėžutė persipildytų. AP neišsiųstas");
define("LAN_PM_22", "Bylos įkelti nepavyko");
define("LAN_PM_23", "Jums neleidžiama siųsti priedų");
define("LAN_PM_24", "AP trinamas");
define("LAN_PM_25", "Gauti:");
define("LAN_PM_26", "Išsiųsti:");
define("LAN_PM_27", "Neperskaitytas");
define("LAN_PM_28", "n/d");
define("LAN_PM_29", "Pranešimas išsiųstas");
define("LAN_PM_30", "Pranešimas perskaitytas");
define("LAN_PM_31", "Nuo");
define("LAN_PM_32", "Gautas");
define("LAN_PM_33", "Išsiųstas");
define("LAN_PM_34", "Nėra pranešimų");
define("LAN_PM_35", "Siųsti naują pranešimą");
define("LAN_PM_36", "iš viso");
define("LAN_PM_37", "neperskaitytas (-i)");
define("LAN_PM_38", "AP išsiųstas narių grupei");
define("LAN_PM_39", "Nepavyko išsiųsti AP");
define("LAN_PM_40", "AP išsiųstas nariui");
define("LAN_PM_41", "Nepavyko įdėti AP kopijos į siųstų pranešimų dėžutę");
define("LAN_PM_42", "AP ištrintas iš gautų pranešimų dėžutės");
define("LAN_PM_43", "AP ištrintas iš siųstų pranešimų dėžutės");
define("LAN_PM_44", "{UNAME} pranešimai nebeblokuojami");
define("LAN_PM_45", "KLAIDA: AP blokavimas nepanaikintas, nežinoma klaida");
define("LAN_PM_46", "{UNAME} pranešimai neblokuojami");
define("LAN_PM_47", "Jūs sėkmingai pradėjote blokuoti {UNAME} pranešimus");
define("LAN_PM_48", "KLAIDA: Blokavimas neįjungtas, nežinoma klaida");
define("LAN_PM_49", "KLAIDA: Jūs jau blokuojate {UNAME} pranešimus");
define("LAN_PM_50", "Blokuoti nario pranešimus");
define("LAN_PM_51", "Nebeblokuoti nario pranešimų");
define("LAN_PM_52", "Trinti");
define("LAN_PM_53", "Ištrinti pasirinktą");
define("LAN_PM_54", "Cituoti");
define("LAN_PM_55", "Atsakyti");
define("LAN_PM_56", "Jums neleidžiama atsakyti į šį pranešimą");
define("LAN_PM_57", "Pranešimas nerastas");
define("LAN_PM_58", "Ats.:");
define("LAN_PM_59", "Eiti į puslapį:");
define("LAN_PM_60", "Jums neleidžiama skaityti šio pranešimo");
define("LAN_PM_61", "Be temos");
define("LAN_PM_62", "Byla [{FILENAME}] yra didesnė, nei nustatyta riba - byla neprijungta");
define("LAN_PM_63", "class:");
define("LAN_PM_64", "KLAIDA: Jums neleidžiama užblokuoti pranešimus iš svetainės administratorių");
define("LAN_PM_65", "KLAIDA: Nieko nesiųsti");
define("LAN_PM_66", "Blokuoti siuntėjai");
define("LAN_PM_67", "Nėra blokuotų vartotojų");
define("LAN_PM_68", "Vartotojo vardas");
define("LAN_PM_69", "Data blokuota");
define("LAN_PM_70", "Ištrinti vartotojo blokavimą");
define("LAN_PM_71", "- GERAS - priedas (-ai) ištrintas. - Fail - nepakankamumas (-ų)");
define("LAN_PM_72", "Vartotojas pašalintas");
define("LAN_PM_100", "Naujas AP nuo");
define("LAN_PM_101", "Jūs gavote naują asmeninį pranešimą nuo");
define("LAN_PM_102", "Pranešimas nuo:");
define("LAN_PM_103", "Pranešimo tema:");
define("LAN_PM_104", "Priedų skaičius:");
define("LAN_PM_105", "Jūs galite peržiūrėti pranešimą:");
define("LAN_PM_106", "AP perskaitė");
define("LAN_PM_107", "Asmeninis pranešimas, kurį siuntėte {UNAME}, buvo perskaitytas");
define("LAN_PM_108", "Pranešimas išsiųstas:");
define("LAN_PM_109", "Naujas pranešimas(-ai)");
define("LAN_PM_110", "gerai");
define("LAN_PM_111", "Skaityti");


?>