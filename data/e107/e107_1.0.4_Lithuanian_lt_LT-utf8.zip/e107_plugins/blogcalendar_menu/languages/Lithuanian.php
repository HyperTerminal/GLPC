<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Naujienos");
define("BLOGCAL_L2", "Archyvas");
define("BLOGCAL_D1", "pr");
define("BLOGCAL_D2", "a");
define("BLOGCAL_D3", "t");
define("BLOGCAL_D4", "k");
define("BLOGCAL_D5", "p");
define("BLOGCAL_D6", "š");
define("BLOGCAL_D7", "s");
define("BLOGCAL_M1", "Sausis");
define("BLOGCAL_M2", "Vasaris");
define("BLOGCAL_M3", "Kovas");
define("BLOGCAL_M4", "Balandis");
define("BLOGCAL_M5", "Gegužė");
define("BLOGCAL_M6", "Birželis");
define("BLOGCAL_M7", "Liepa");
define("BLOGCAL_M8", "Rugpjūtis");
define("BLOGCAL_M9", "Rugsėjis");
define("BLOGCAL_M10", "Spalis");
define("BLOGCAL_M11", "Lapkritis");
define("BLOGCAL_M12", "Gruodis");
define("BLOGCAL_1", "Naujienų pranešimai");
define("BLOGCAL_CONF1", "Mėnesiai/eilė");
define("BLOGCAL_CONF2", "Užpildymas");
define("BLOGCAL_CONF3", "Atnaujinti meniu nustatymus");
define("BLOGCAL_CONF4", "BlogCal meniu nustatymai");
define("BLOGCAL_CONF5", "BlogCal meniu nustatymai išsaugoti");
define("BLOGCAL_ARCHIV1", "Pasirinkite archyvą");


?>