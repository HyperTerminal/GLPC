<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/list_new/languages/Lithuanian.php,v $
|     $Revision: 1.5 $
|     $Date: 2007/01/03 20:14:51 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LIST_PLUGIN_1", "Sąrašas");
define("LIST_PLUGIN_2", "Šis įskiepis leidžia jums peržiūrėti pastarųjų papildymų visose e107 kategorijose sąrašą. Jūs galite peržiūrėti sąrašą su duomenimis, nuo jūsų paskutinio apsilankymo, arba peržiūrėti naujausius papildymų sąrašą. Be puslapyje meniu taip pat yra. Kiekviena sekcija yra konfigūruojama į admin srityje.");
define("LIST_PLUGIN_3", "Pagrindinio Meniu konfigūravimas");
define("LIST_PLUGIN_4", "Dabar List_new įskiepis yra paruoštas naudoti.");
define("LIST_PLUGIN_5", "sąrašas");
define("LIST_PLUGIN_6", "Įskiepis neinstaliuotas");
define("LIST_ADMIN_1", "nesenas");
define("LIST_ADMIN_2", "atnaujinti nustatymus");
define("LIST_ADMIN_3", "nustatymai atnaujinti");
define("LIST_ADMIN_4", "sekcija");
define("LIST_ADMIN_5", "meniu");
define("LIST_ADMIN_6", "puslapis");
define("LIST_ADMIN_7", "įjungta");
define("LIST_ADMIN_8", "išjungta");
define("LIST_ADMIN_9", "atidaryta");
define("LIST_ADMIN_10", "uždaryta");
define("LIST_ADMIN_11", "atnaujinti");
define("LIST_ADMIN_12", "pasirinkti");
define("LIST_ADMIN_13", "Šiame puslapyje rasite trumpą apžvalgą, kas naujausio įvyko šiose svetainės dalyse.");
define("LIST_ADMIN_14", "naujausi papildymai");
define("LIST_ADMIN_15", "nauja nuo paskutinio Jūsų apsilankymo");
define("LIST_ADMIN_16", "Šiame puslapyje rasite trumpą apžvalgą, kas naujausio įvyko šiose svetainės dalyse nuo Jūsų paskutinio apsilankymo.");
define("LIST_ADMIN_SECT_1", "sekcijos");
define("LIST_ADMIN_SECT_2", "pasirinkti kokią sekciją rodyti");
define("LIST_ADMIN_SECT_3", "");
define("LIST_ADMIN_SECT_4", "atvaizduojamas stilius");
define("LIST_ADMIN_SECT_5", "choose which sections are opened by default");
define("LIST_ADMIN_SECT_6", "");
define("LIST_ADMIN_SECT_7", "autorius");
define("LIST_ADMIN_SECT_8", "irinkti, ar autorius turi būti rodomas");
define("LIST_ADMIN_SECT_9", "");
define("LIST_ADMIN_SECT_10", "kategorija");
define("LIST_ADMIN_SECT_11", "pasirinkti ar kategorija turi būti rodomaayed");
define("LIST_ADMIN_SECT_12", "");
define("LIST_ADMIN_SECT_13", "data");
define("LIST_ADMIN_SECT_14", "pasirinkti ar data turi būti rodoma");
define("LIST_ADMIN_SECT_15", "");
define("LIST_ADMIN_SECT_16", "elementų suma");
define("LIST_ADMIN_SECT_17", "pasirinkti, kiek elementų turi būti rodoma kiekvienoje sekcijoje");
define("LIST_ADMIN_SECT_18", "");
define("LIST_ADMIN_SECT_19", "kiti veiksmai");
define("LIST_ADMIN_SECT_20", "pasirinkti tvarką, kokie skyriai turi būti rodomas");
define("LIST_ADMIN_SECT_21", "");
define("LIST_ADMIN_SECT_22", "piktograma");
define("LIST_ADMIN_SECT_23", "pasirinkite piktogramą kiekvienoje sekcijoje");
define("LIST_ADMIN_SECT_24", "");
define("LIST_ADMIN_SECT_25", "antraštė");
define("LIST_ADMIN_SECT_26", "nustatyti antraštę kiekviename skyriuje");
define("LIST_ADMIN_SECT_27", "");
define("LIST_ADMIN_OPT_1", "pagrindinis");
define("LIST_ADMIN_OPT_2", "nesenas puslapis");
define("LIST_ADMIN_OPT_3", "nesenas meniu");
define("LIST_ADMIN_OPT_4", "naujas puslapis");
define("LIST_ADMIN_OPT_5", "naujas meniu");
define("LIST_ADMIN_OPT_6", "opcijos");
define("LIST_ADMIN_MENU_2", "piktograma : numatyta");
define("LIST_ADMIN_MENU_3", "naudoti numatytąjį temą, jei jokia piktograma piktograma arba jei naudojimas yra išjungtas");
define("LIST_ADMIN_MENU_4", "");
define("LIST_ADMIN_LAN_2", "antraštė");
define("LIST_ADMIN_LAN_3", "nustatyti antraštę");
define("LIST_ADMIN_LAN_4", "");
define("LIST_ADMIN_LAN_5", "piktograma : naudojama");
define("LIST_ADMIN_LAN_6", "naudoti piktogramą kiekvienoje sekcijoje");
define("LIST_ADMIN_LAN_7", "");
define("LIST_ADMIN_LAN_8", "simboliai");
define("LIST_ADMIN_LAN_9", "pasirinkti, kiek simbolių antraštės bus rodomas");
define("LIST_ADMIN_LAN_10", "palikite tuščia, norint parodyti visą pozicijoje");
define("LIST_ADMIN_LAN_11", "postfix");
define("LIST_ADMIN_LAN_12", "pasirinkti postfix jei antraštė yra didesnis nei atitinkama suma simbolių");
define("LIST_ADMIN_LAN_13", "palikite tuščią, kad nerodo postfix");
define("LIST_ADMIN_LAN_14", "data");
define("LIST_ADMIN_LAN_15", "pažymėkite datos stilių");
define("LIST_ADMIN_LAN_16", "Norėdami gauti daugiau informacijos apie datos formatus <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime function page at php.net</a>");
define("LIST_ADMIN_LAN_17", "šiandienos data");
define("LIST_ADMIN_LAN_18", "pasirinkti laiko stilių, jei data yra šiandien");
define("LIST_ADMIN_LAN_19", "Norėdami gauti daugiau informacijos apie datos formatus <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime function page at php.net</a>");
define("LIST_ADMIN_LAN_20", "stulpeliai");
define("LIST_ADMIN_LAN_21", "pasirinkti stulpelių visumą");
define("LIST_ADMIN_LAN_22", "nustatyti, kiek stulpelių norite naudoti. į vienodo dydžio stulpelių skaičius, kurį bus atskirti puslapį");
define("LIST_ADMIN_LAN_23", "pasisveikinimo tekstas");
define("LIST_ADMIN_LAN_24", "nustatyti sveikinimo tekstą, kuris bus Sugeneruotas puslapio viršuje");
define("LIST_ADMIN_LAN_25", "");
define("LIST_ADMIN_LAN_26", "rodyti tuščią");
define("LIST_ADMIN_LAN_27", "nustatyti, jei pranešimas turi būti rodomas, kai skyriuose nėrarezultatų");
define("LIST_ADMIN_LAN_28", "");
define("LIST_ADMIN_LAN_29", "piktograma : numatyta");
define("LIST_ADMIN_LAN_30", "naudoti numatytąjį temą , jei jokia piktograma piktograma arba jei naudojimas yra išjungtas");
define("LIST_ADMIN_LAN_31", "");
define("LIST_ADMIN_LAN_32", "Laiko tarpas: dienos");
define("LIST_ADMIN_LAN_33", "daugiausia dienų vartotojai gali atsigręžti");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dienos");
define("LIST_ADMIN_LAN_36", "laiko tarpas");
define("LIST_ADMIN_LAN_37", "rodyti pasirinkitą dienų skaičių dėžutėje su atsigręžti?");
define("LIST_ADMIN_LAN_38", "");
define("LIST_ADMIN_LAN_39", "atidaryti jei yrašai egzistuoja");
define("LIST_ADMIN_LAN_40", "turėti skyriai, kuriuose yra įrašai būtų atidarytas pagal nutylėjimą?");
define("LIST_ADMIN_LAN_41", "");
define("LIST_MENU_1", "naujausi");
define("LIST_MENU_2", "parašė");
define("LIST_MENU_3", "on");
define("LIST_MENU_4", "į");
define("LIST_MENU_5", "dienos");
define("LIST_MENU_6", "peržiūrėti turinį, kiek dienų?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "naujienos");
define("LIST_NEWS_2", "naujienų įrašų nėra");
define("LIST_COMMENT_1", "komentarai");
define("LIST_COMMENT_2", "komentarų nėra");
define("LIST_COMMENT_3", "naujienos");
define("LIST_COMMENT_4", "d.u.k.");
define("LIST_COMMENT_5", "apklausos");
define("LIST_COMMENT_6", "dokumentai");
define("LIST_COMMENT_7", "bugtrack");
define("LIST_COMMENT_8", "turinys");
define("LIST_COMMENT_9", "siuntiniai");
define("LIST_COMMENT_10", "idėjos");
define("LIST_DOWNLOAD_1", "siuntiniai");
define("LIST_DOWNLOAD_2", "siuntinių nėra");
define("LIST_MEMBER_1", "nariai");
define("LIST_MEMBER_2", "narių nėra");
define("LIST_CONTENT_1", "turinys");
define("LIST_CONTENT_2", "turinio nėra");
define("LIST_CONTENT_3", "tinkamos turinio kategorijos nėra");
define("LIST_CHATBOX_1", "pokalbiai");
define("LIST_CHATBOX_2", "pokalbių pranešimų nėra");
define("LIST_CALENDAR_1", "kalendorius");
define("LIST_CALENDAR_2", "įvykių kalendoriuje nėra");
define("LIST_LINKS_1", "nuorodos");
define("LIST_LINKS_2", "nuorodų nėra");
define("LIST_FORUM_1", "diskusijos");
define("LIST_FORUM_2", "diskusijų pranešimų nėra");
define("LIST_FORUM_3", "žiūrėta:");
define("LIST_FORUM_4", "atsakymai:");
define("LIST_FORUM_5", "paskutinis pranešimas:");
define("LIST_FORUM_6", ":");


?>