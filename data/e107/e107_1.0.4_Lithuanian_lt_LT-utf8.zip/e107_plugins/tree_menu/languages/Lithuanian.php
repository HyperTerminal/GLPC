<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/tree_menu/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2013/03/16 20:10:15 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/

define("TREE_L1", "Konfigūruoti Meniu ");
define("TREE_L2", "Atnaujinti Meniu nustatymus");
define("TREE_L3", "Meniu nustatymai išsaugoti");
define("TREE_L4", "Įjungti");
define("TREE_L5", "Išjungti");
define("TREE_L6", "CSS klasę naudoti neatidaromom nuorodom");
define("TREE_L7", "CSS klasę naudoti atidaromom nuorodom");
define("TREE_L8", "CSS klasę naudoti atidarytom nuorodom");
define("TREE_L9", "Naudoti tarpinę klasę tarp pagrindinių nuorodų");


?>