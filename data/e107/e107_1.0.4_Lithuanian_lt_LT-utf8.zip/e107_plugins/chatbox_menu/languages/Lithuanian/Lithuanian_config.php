<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/chatbox_menu/languages/Lithuanian/Lithuanian_config.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/07 21:47:18 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Pokalbių kanalo duomenys atnaujinti.");
define("CHBLAN_2", "Moderuota.");
define("CHBLAN_3", "Pokalbių kanale pranešimų nėra.");
define("CHBLAN_4", "Dalyvis");
define("CHBLAN_5", "Svečias");
define("CHBLAN_6", "atblokuoti");
define("CHBLAN_7", "užblokuoti");
define("CHBLAN_8", "ištrinti");
define("CHBLAN_9", "Moderuoti pokalbių kanalą");
define("CHBLAN_10", "Moderuoti pranešimus");
define("CHBLAN_11", "Rodyti pokalbių kanalo pranešimus");
define("CHBLAN_12", "Viso pokalbių kanale rodomų pranešimų");
define("CHBLAN_13", "Pakeisti nuorodas");
define("CHBLAN_14", "jei pažymėsite, paskelbtos nuorodos bus pakeisto žemiau įvestu tekstu");
define("CHBLAN_15", "Pakeisti eilutę, jei įjungta");
define("CHBLAN_16", "nuorodos bus pakeistos šia eilute");
define("CHBLAN_17", "Žodžių limitas");
define("CHBLAN_18", "jei žodžiai bus ilgesni už čia nurodytą skaičių, jie bus perkelti");
define("CHBLAN_19", "Atnaujinti pokalbių kanalo parametrus");
define("CHBLAN_20", "Pokalbių kanalo parametrai");
define("CHBLAN_21", "Sumažinti pranešimų skaičių");
define("CHBLAN_22", "Trinti pranešimus senesnius už nurodytą laiką");
define("CHBLAN_23", "Trinti pranešimus senesnius nei");
define("CHBLAN_24", "Viena diena");
define("CHBLAN_25", "Viena savaitė");
define("CHBLAN_26", "Vienas mėnuo");
define("CHBLAN_27", "- Trinti visus pranešimus -");
define("CHBLAN_28", "Pranešimų skaičius pokalbių kanale sumažintas.");
define("CHBLAN_29", "Pokalbių kanalą rodyti slenkančiame sluoksnyje");
define("CHBLAN_30", "Sluoksnio aukštis");
define("CHBLAN_31", "Rodyti jausmukus");
define("CHBLAN_32", "Moderatoriaus vartotojo klasė");
define("CHBLAN_33", "User counts recalculated");
define("CHBLAN_34", "Recalculate user post counts");
define("CHBLAN_35", "Recalculate");
define("CHBLAN_36", "pokalbių dėžutės rodymo pasirinktys");
define("CHBLAN_37", "Normali pokalbių dėžutė");
define("CHBLAN_38", "Naudoti JavaScript  kodą į dinamiškai atnaujintą pranešimą (AJAX)");


?>