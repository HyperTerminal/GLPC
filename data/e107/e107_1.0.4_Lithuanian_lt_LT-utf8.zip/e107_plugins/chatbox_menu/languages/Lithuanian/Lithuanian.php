<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/chatbox_menu/languages/Lithuanian/Lithuanian.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/01/03 20:03:26 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "Pranešimas nepriimtas, nes toks vartotojo vardas užregistruotas. Jei tai Jūsų vardas, prašome prisijungti.");
define("CHATBOX_L2", "Pokalbiai");
define("CHATBOX_L3", "Jūs turite prisijungti, jei norite skelbti žinutes. Užsiregistruoti galite <a href='".e_SIGNUP."'>čia</a>");
define("CHATBOX_L4", "Skelbti");
define("CHATBOX_L5", "Ištaisyti");
define("CHATBOX_L6", "[užblokavo administratorius]");
define("CHATBOX_L7", "Atblokuoti");
define("CHATBOX_L8", "Informacija");
define("CHATBOX_L9", "Blokuoti");
define("CHATBOX_L10", "Trinti");
define("CHATBOX_L11", "Žinučių dar nėra.");
define("CHATBOX_L12", "Peržiūrėti visas žinutes");
define("CHATBOX_L13", "moderuoti pokalbius");
define("CHATBOX_L14", "Jausmukai");
define("CHATBOX_L15", "Pranešimas per ilgas arba tuščias");
define("CHATBOX_L16", "Anonimas");
define("CHATBOX_L17", "Pranešimas kartojasi");
define("CHATBOX_L18", "Pokalbių žinutės pakeistos");
define("CHATBOX_L19", "You may only post once every ".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." seconds");
define("CHATBOX_L20", "Pokalbiai (visi pranešimai)");
define("CHATBOX_L21", "Pranešimai");
define("CHATBOX_L22", "įjungta");
define("CHATBOX_L23", "Klaida!");
define("CHATBOX_L24", "Jūs neturite teisės matyti šio puslapio.");
define("CHATBOX_L25", "[ panešimas užblokuotas ]");
define("NT_LAN_CB_1", "Pokalbių įvykiai");
define("NT_LAN_CB_2", "Žinutė paskelbta");
define("NT_LAN_CB_3", "Paskelbė");
define("NT_LAN_CB_4", "IP adresas");
define("NT_LAN_CB_5", "Žinutė");
define("NT_LAN_CB_6", "Pokalbių žinutė paskelbta");


?>