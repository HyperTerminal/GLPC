<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/comment_menu/languages/Lithuanian.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/01/03 20:04:10 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("CM_L1", "Kol kas komentarų nėra.");
define("CM_L2", "");
define("CM_L3", "Pavadinimas");
define("CM_L4", "Kiek rodyti komentarų?");
define("CM_L5", "Kiek rodyti simbolių?");
define("CM_L6", "Taisyti per ilgus komentarus?");
define("CM_L7", "Rodyti originalius naujienų pavadinimus meniu?");
define("CM_L8", "Naujienų komentarų meniu nuostatos");
define("CM_L9", "Atnaujinti meniu nuostatas");
define("CM_L10", "Komentarų meniu nuostatos išsaugotos");
define("CM_L11", "į");
define("CM_L12", "Ats:");
define("CM_L13", "Parašė");


?>