<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/content/languages/Lithuanian/lan_content_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/01/03 20:05:40 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Turinys");
define("CONT_SCH_LAN_2", "Visos turinio kategorijos");
define("CONT_SCH_LAN_3", "Paskelbta atsakant");
define("CONT_SCH_LAN_4", "į");


?>