<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/content/languages/Lithuanian/lan_content_frontpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 20:43:59 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("CONT_FP_1", "Turinio kategorija");
define("CONT_FP_2", "pagrindinis puslapis");


?>