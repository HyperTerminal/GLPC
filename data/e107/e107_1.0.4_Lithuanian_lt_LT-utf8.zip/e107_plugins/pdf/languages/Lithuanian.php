<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/pdf/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:39:25 $
|     $Author: g3d45 $
+-----------------------------------------------------------------------------+
*/
define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF kūrimo palaikymas");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Šis įskiepis yra parengtas naudojimui.");
define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF nuostatos");
define("PDF_LAN_3", "įgalinta");
define("PDF_LAN_4", "neįgalinta");
define("PDF_LAN_5", "puslapio lygiavimas kaire");
define("PDF_LAN_6", "puslapio lygiavimas dešine");
define("PDF_LAN_7", "puslapio lygiavimas viršumi");
define("PDF_LAN_8", "šrifto šeima");
define("PDF_LAN_9", "šrifto numatytas dydis");
define("PDF_LAN_10", "šrifto dydžio svetainės pavadinimas");
define("PDF_LAN_11", "šrifto dydžio puslapio url");
define("PDF_LAN_12", "šrifto dydžio puslapio numeris");
define("PDF_LAN_13", "rodyti logo pdf?");
define("PDF_LAN_14", "rodyti svetainės pavadinimą pdf?");
define("PDF_LAN_15", "rodyti autoriaus puslapio url pdf?");
define("PDF_LAN_16", "rodyti puslapio numerius pdf?");
define("PDF_LAN_17", "atnaujinti");
define("PDF_LAN_18", "PDF nuostatos sėkmingai atnaujintos");
define("PDF_LAN_19", "Puslapis");
define("PDF_LAN_20", "pranešimai apie klaidas");


?>