<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/login_menu/languages/Lithuanian.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/01/03 20:15:23 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LOGIN_MENU_L1", "Prisijungimo vardas:");
define("LOGIN_MENU_L2", "Slaptažodis:");
define("LOGIN_MENU_L3", "Registruotis");
define("LOGIN_MENU_L4", "Pamiršote slaptažodį?");
define("LOGIN_MENU_L5", "Sveiki,");
define("LOGIN_MENU_L6", "Prisiminti mane");
define("LOGIN_MENU_L7", "Unikalus vartotojo id neatpažintas (gali būti pažeistas slapukas (cookie).<br />Please <a href=\'.e_BASE.index.php?logout\'>paspausti čia</a>.");
define("LOGIN_MENU_L8", "Atsijungti");
define("LOGIN_MENU_L9", "Prisijungimo klaida");
define("LOGIN_MENU_L10", "Vyksta priežiūros darbai; tai reiškia, kad eiliniai lankytojai nukreipiami į sitedown.php. Norėdami užbaigti šiuos darbus eikite į administravimo skyrių -> Priežiūra.");
define("LOGIN_MENU_L11", "Administravimas");
define("LOGIN_MENU_L12", "Nustatymai");
define("LOGIN_MENU_L13", "Apie mane");
define("LOGIN_MENU_L14", "naujienų pranešimas");
define("LOGIN_MENU_L15", "naujienų pranešimai");
define("LOGIN_MENU_L16", "pokalbių pranešimas");
define("LOGIN_MENU_L17", "pokalbių pranešimai");
define("LOGIN_MENU_L18", "komentaras");
define("LOGIN_MENU_L19", "komentarai");
define("LOGIN_MENU_L20", "pranešimas forume");
define("LOGIN_MENU_L21", "pranešimai forume");
define("LOGIN_MENU_L22", "naujas tinklalapio narys");
define("LOGIN_MENU_L23", "nauji tinklalapio nariai");
define("LOGIN_MENU_L24", "Spauskite čia, jei norite pamatyti kas naujo");
define("LOGIN_MENU_L25", "Nuo paskutinio jūsų apsilankymo tinklalapyje atsirado");
define("LOGIN_MENU_L26", "ne");
define("LOGIN_MENU_L27", "ir");
define("LOGIN_MENU_L28", "Prisijungti");
define("LOGIN_MENU_L29", "naujas straipsnis");
define("LOGIN_MENU_L30", "nauji straipsniai");
define("LOGIN_MENU_L31", "Rodyti naujus naujienų pranešimus");
define("LOGIN_MENU_L32", "Rodyti naujus straipsnių pranešimus");
define("LOGIN_MENU_L33", "Rodyti naujus pokalbių pranešimus");
define("LOGIN_MENU_L34", "Rodyti naujus komentarų pranešimus");
define("LOGIN_MENU_L35", "Rodyti naujus diskusijų pranešimus");
define("LOGIN_MENU_L36", "Rodyti naujus narius");
define("LOGIN_MENU_L39", "Palikti Admin");
define("LOGIN_MENU_L40", "Pakartoti registraciją el.laišku");
define("LOGIN_MENU_L41", "Prisijungimo Meniu nustatymai");


?>