<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/counter_menu/languages/Lithuanian.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:56 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Administratoriaus apsilankymai nėra skaičiuojami.");
define("COUNTER_L2", "Šiandien apsilankė");
define("COUNTER_L3", "iš viso");
define("COUNTER_L4", "Užfiksuota daugiausia");
define("COUNTER_L5", "unikalūs");
define("COUNTER_L6", "Svetainę aplankė");
define("COUNTER_L7", "Svetainės lankomumas");
define("COUNTER_L8", "Admin pranešimas: <b>Statistikos rinkimas išjungtas.</b><br /> Norėdami aktyvuoti, Jums reikia įdiegti Statistikos rinkimo įskiepį iš <a href='".e_ADMIN."plugin.php'>plugin manager</a>, then activate it from the <a href='".e_PLUGIN."log/admin_config.php'>configuration screen</a>.");


?>