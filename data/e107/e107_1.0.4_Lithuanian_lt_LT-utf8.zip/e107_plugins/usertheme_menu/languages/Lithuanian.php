<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/	
define("LAN_UMENU_THEME_1", "Nustatyti temą");
define("LAN_UMENU_THEME_2", "Pažymėti temą");
define("LAN_UMENU_THEME_3", "vartotojai:");
define("LAN_UMENU_THEME_4", "Įjunkite tas temas, kurias vartotojai gali pasirinkti");
define("LAN_UMENU_THEME_5", "Atnaujinti");
define("LAN_UMENU_THEME_6", "Temos prieinamos vartotojams");
define("LAN_UMENU_THEME_7", "Klasė, kuri gali pasirinkti temas");


?>