<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/compliance_menu/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 20:41:20 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
	
define("COMPLIANCE_L1", "W3C suderinamumas");

?>