<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/banner_menu/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/07 21:20:26 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "Reklama");
define("BANNER_MENU_L2", "Reklaminių skydelių konfigūracija išsaugota");
define("BANNER_MENU_L3", "Antraštė");
define("BANNER_MENU_L4", "Kampanija");
define("BANNER_MENU_L5", "Reklaminių skydelių konfigūracija");
define("BANNER_MENU_L6", "pasirinkite kampanijas, kurias norite rodyti meniu");
define("BANNER_MENU_L7", "galimos  kampanijos");
define("BANNER_MENU_L8", "pasirinktos kampanijos");
define("BANNER_MENU_L9", "pašalinti pasirinkimą");
define("BANNER_MENU_L10", "kaip pasirinktos kampanijos turi būti rodomos?");
define("BANNER_MENU_L11", "pasirinkite atlikimo tipą ...");
define("BANNER_MENU_L12", "viena kampanija viename meniu");
define("BANNER_MENU_L13", "visos pasirinktos kampanijos viename meniu");
define("BANNER_MENU_L14", "visos pasirinktos kampanijos atskiruose meniu");
define("BANNER_MENU_L15", "kiek skydelių turi būti rodoma?");
define("BANNER_MENU_L16", "šis nustatymas bus naudojamas tik su parinktimis 2 ir 3.<br />if mažiau skydelių yra, bus išnaudojama tiek kiek yra.");
define("BANNER_MENU_L17", "nustatyti kiekį...");
define("BANNER_MENU_L18", "Atnaujinti meniu nuostatas");


?>