<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|

|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/trackback/languages/Lithuanian.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:57 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("TRACKBACK_L1", "Konfigūruoti Kopijavimą");
define("TRACKBACK_L2", "Šis įskiepis leidžia Jums naudoti trackback Jūsų naujienų pranešimuose.");
define("TRACKBACK_L3", "Kopijavimas yra įdiegta ir įgalinta.");
define("TRACKBACK_L4", "Kopijavimo nuostatos išsaugotos.");
define("TRACKBACK_L5", "Įjungta");
define("TRACKBACK_L6", "Išjungta");
define("TRACKBACK_L7", "Aktyvuoti trackback");
define("TRACKBACK_L8", "Kopijos URL tekstas");
define("TRACKBACK_L9", "Išsaugoti nuostatas");
define("TRACKBACK_L10", "Kopijavimo nuostatos");
define("TRACKBACK_L11", "Trackback adresas šiam pranešimui:");
define("TRACKBACK_L12", "Nėra trackbacks šiam įrašui");
define("TRACKBACK_L13", "Valdyti trackbacks");
define("TRACKBACK_L14", "Trinti");
define("TRACKBACK_L15", "Kopijos ištrintos");


?>