<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/userlanguage_menu/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/07 20:44:43 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Nustatyti kalbą");
define("UTHEME_MENU_L2", "Pasirinkti kalbą");
define("UTHEME_MENU_L3", "lentelės");


?>