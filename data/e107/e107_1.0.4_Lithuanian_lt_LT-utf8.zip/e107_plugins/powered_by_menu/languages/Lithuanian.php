<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/powered_by_menu/languages/Lithuanian.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:57 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("POWEREDBY_L1", "Veikia:");


?>