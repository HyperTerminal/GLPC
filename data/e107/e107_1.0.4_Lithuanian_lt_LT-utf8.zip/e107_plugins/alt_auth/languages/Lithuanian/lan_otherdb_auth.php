<?php

define('OTHERDB_LAN_1',  "Duomenų bazės tipas:");
define('OTHERDB_LAN_2',  'Serveris:');
define('OTHERDB_LAN_3',  'vartotojo vardas:');
define('OTHERDB_LAN_4',  'Slaptažodis:');
define('OTHERDB_LAN_5',  'Duomenų bazė');
define('OTHERDB_LAN_6',  'Lentelė');
define('OTHERDB_LAN_7',  'Vartotojo vardo laukas:');
define('OTHERDB_LAN_8',  'Slaptažodžio laukas:');
define('OTHERDB_LAN_9',  'Slaptažodis metodas:');
define('OTHERDB_LAN_10', 'Konfigūruoti kitų DB auth');
define('OTHERDB_LAN_11', '** Kiti laukai nereikalingi, jei vartojate e107 duombazę');