<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/
define("LDAPLAN_1", "Serverio aadresas");
define("LDAPLAN_2", "Base DN or Domain<br />If LDAP - Enter BaseDN<br />If AD - Enter domain");
define("LDAPLAN_3", "LDAP Naršymas vartotojo <br /> Visą kontekstą vartotojas, kuris gali ieškoti katalogą.");
define("LDAPLAN_4", "LDAP Naršymo slaptažodis <br /> Slaptažodis LDAP naršymo vartotojas.");
define("LDAPLAN_5", "LDAP Versija");
define("LDAPLAN_6", "Konfigūruoti LDAP auth");
define("LDAPLAN_7", "eDirektorijos paieškos filtras:");
define("LDAPLAN_8", "Bus naudojamas siekiant užtikrinti vardą teisingame medyje,<br />ie '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Esamas paieškos filtras bus:");
define("LDAPLAN_10", "Settings Updated");
define("LDAPLAN_11", "WARNING:  It appears as if the ldap module is not currently available, setting your auth method to LDAP will probably not work!");


?>