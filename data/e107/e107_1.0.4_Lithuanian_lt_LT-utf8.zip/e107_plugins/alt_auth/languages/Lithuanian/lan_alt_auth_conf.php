<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/
define("LAN_ALT_2", "Dabartinės autorizacijos tipas");
define("LAN_ALT_3", "Pasirinkite Alternatyvų autorizacijos tipą");
define("LAN_ALT_4", "Konfigūruoti parametrus");
define("LAN_ALT_5", "Konfigūruoti autorizuotus parametrus");
define("LAN_ALT_6", "Nepavyko sujungimo veiksmas");
define("LAN_ALT_7", "Nepavykus prijungimas prie alternatyvaus metodo, kaip tai turėtų būti tvarkomi?");
define("LAN_ALT_8", "Vartotojas neranda veiksmų");
define("LAN_ALT_9", "Jei vartotojo vardas nėra nustatytas, naudojant alternatyvų metodą, kaip tai turėtų būti tvarkomi?");
define("LAN_ALT_10", "Klaidingas prisijungimas");
define("LAN_ALT_11", "Naudokite e107 vartotojo lentelę");
define("LAN_ALT_PAGE", "Alternatyvus autentiškumas");


?>