<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
define("RSS_LAN05", "Elementų kiekis (0=neaktyvūs)");
define("RSS_MENU_L1", "galima transliuoti, naudojant rss.");
define("RSS_MENU_L2", "RSS transliacijos");
define("RSS_MENU_L3", "Mūsų naujienos");
define("RSS_MENU_L4", "Mūsų komentarai");
define("RSS_MENU_L5", "Mūsų forumo temos");
define("RSS_MENU_L6", "Mūsų forumo pranešimai");
define("RSS_MENU_L7", "Mūsų mini-čiato pranešimai");
define("RSS_MENU_L8", "mūsų sistemos aptikimo klaidų pranešimai");
define("RSS_MENU_L9", "Mūsų atsisiuntimai");
define("RSS_NEWS", "Naujienos");
define("RSS_COM", "Komentarai");
define("RSS_ART", "Straipsniai");
define("RSS_REV", "Apžvalgos");
define("RSS_FT", "Forumo temos");
define("RSS_FP", "Forumo pranešimai");
define("RSS_FSP", "Specifiniai forumo pranešimai");
define("RSS_BUG", "Klaidų atsekimas");
define("RSS_FOR", "Forumas");
define("RSS_DL", "Atsisiuntimai");
define("RSS_PLUGIN_LAN_1", "RSS");
define("RSS_PLUGIN_LAN_6", "Transliacijos juostos");
define("RSS_PLUGIN_LAN_7", "Naujienų transliacija");
define("RSS_PLUGIN_LAN_8", "Atsisiuntimų transliacija");
define("RSS_PLUGIN_LAN_9", "Komentarų transliacija");
define("RSS_PLUGIN_LAN_10", "Naujienų kategorijų transliacija:");
define("RSS_PLUGIN_LAN_11", "Transliacija atsisiuntimų kategorijų:");
define("RSS_PLUGIN_LAN_14", "Komentarai");
define("RSS_LAN_ADMINMENU_1", "RSS savybės");
define("RSS_LAN_ADMINMENU_2", "Sąrašas");
define("RSS_LAN_ADMINMENU_4", "Importuoti");
define("RSS_LAN_ERROR_1", "Nekorektiška rss transliacija<br  /><br  /><a href='.e_SELF.'><grįžti į rss transliacijas</a>");
define("RSS_LAN_ERROR_2", "Jūsų e107_config.php byla ar jūsų kalbos rinkmenos tarpų ar · Â »Â ¿ï» ¿simbolių, prieš <? simbolių. Jūs turite pašalinti tai ne utf8 teksto redaktoriumi, jei norite turėti galiojantį RSS kanalą.");
define("RSS_LAN_ERROR_3", "Nėra RSS kanalų<br /> Prašome naudoti importo funkciją importuokite Prieinami RSS šaltiniai arba rankiniu būdu sukurti RSS kanalus.");
define("RSS_LAN_ERROR_4", "Kol kas nėra prieinamų rss kanalų");
define("RSS_LAN_ERROR_5", "Šitas rss kanalas neegzistuoja");
define("RSS_LAN_ERROR_6", "Nėra importuojamų rss kanalų");
define("RSS_LAN_ERROR_7", "kai kurie būtini laukai neužpildyti");
define("RSS_LAN_ADMIN_1", "Esami RSS kanalai");
define("RSS_LAN_ADMIN_2", "ID");
define("RSS_LAN_ADMIN_3", "kelias");
define("RSS_LAN_ADMIN_4", "vardas");
define("RSS_LAN_ADMIN_5", "URL");
define("RSS_LAN_ADMIN_6", "tekstas");
define("RSS_LAN_ADMIN_7", "Limitas");
define("RSS_LAN_ADMIN_8", "Matymas");
define("RSS_LAN_ADMIN_9", "Tipas");
define("RSS_LAN_ADMIN_10", "rss kanalų sukūrimas");
define("RSS_LAN_ADMIN_11", "Importuoti rss kanalus");
define("RSS_LAN_ADMIN_12", "id temos");
define("RSS_LAN_ADMIN_13", "Įtraukti Kitos-naujienos į naujienų kanalą?");
define("RSS_LAN_ADMIN_14", "Įjungti");
define("RSS_LAN_ADMIN_15", "Pasirinkite kanalą importavimui");
define("RSS_LAN_ADMIN_16", "Importuoti?");
define("RSS_LAN_ADMIN_17", "Importuoti pasirinktus kanalus");
define("RSS_LAN_ADMIN_18", "rss kanalai importuoti");
define("RSS_LAN_ADMIN_21", "aktyvus ir matomas sąraše rss kanalas");
define("RSS_LAN_ADMIN_22", "aktyvus ir nematomas sąraše rss kanalas");
define("RSS_LAN_ADMIN_23", "neaktyvus");
define("RSS_LAN_ADMIN_26", "Pasirinkti viską");
define("RSS_LAN_ADMIN_27", "Atšaukti pasirinkimą");
define("RSS_LAN_ADMIN_31", "rss kanalų limito sąrašas atnaujintas");
define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@nospam.com");
define("RSS_LAN_3", "noauthor@nospam.com");


?>