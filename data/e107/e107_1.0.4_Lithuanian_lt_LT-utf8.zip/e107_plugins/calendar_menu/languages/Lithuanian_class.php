<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Lithuanian_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/03/17 10:23:40 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/

define("EC_LAN_RECUR_00", "ne");
define("EC_LAN_RECUR_01", "metinis");
define("EC_LAN_RECUR_02", "du kartus per metus");
define("EC_LAN_RECUR_03", "ketvirtinis");
define("EC_LAN_RECUR_04", "mėnesinis");
define("EC_LAN_RECUR_05", "keturis kartus per savaitę");
define("EC_LAN_RECUR_06", "kas dvi savaitės");
define("EC_LAN_RECUR_07", "kartą per savaitę");
define("EC_LAN_RECUR_08", "per dieną");
define("EC_LAN_RECUR_100", "Mėnesio Sekmadienį");
define("EC_LAN_RECUR_101", "mėnesio Pirmadienį");
define("EC_LAN_RECUR_102", "mėnesio Antradienį");
define("EC_LAN_RECUR_103", "mėnesio Trečiadienį");
define("EC_LAN_RECUR_104", "mėnesio Ketvirtadienį");
define("EC_LAN_RECUR_105", "mėnesio Penktadienį");
define("EC_LAN_RECUR_106", "mėnesio Šeštadienį");
define("EC_LAN_RECUR_1100", "Pirmas");
define("EC_LAN_RECUR_1200", "Antras");
define("EC_LAN_RECUR_1300", "Trečias");
define("EC_LAN_RECUR_1400", "Ketvirtas");
define("NT_LAN_EC_1", "Įvykių kalendorius Įvykiai");
define("NT_LAN_EC_2", "Įvykio atnaujinumas");
define("NT_LAN_EC_3", "Atnaujinta");
define("NT_LAN_EC_4", "IP adresas");
define("NT_LAN_EC_5", "Pranešimas");
define("NT_LAN_EC_6", "Įvykių kalendorius-Įvykis pridėtas");
define("NT_LAN_EC_7", "naujas įvykis išsiųstas");
define("NT_LAN_EC_8", "Įvykių Kalendorius-Įvykis pakeistas");
define("EC_ADM_01", "Įvykio kalendorius-įvykis pridėtas");
define("EC_ADM_02", "Įvykio kalendorius-redaguoti įvykį");
define("EC_ADM_03", "Įvykio Kalendorius-ištrinti įvykį");
define("EC_ADM_04", "Įvykio Kalendorius- Bulk ištrinti");
define("EC_ADM_05", "Įvykio Kalendorius-multi prodėti");
define("EC_ADM_06", "Įvykių kalendorius - Pagrindinės funkcijos pasikeitė");
define("EC_ADM_07", "Įvykių kalendorius - FE galimybės pasikeitė");
define("EC_ADM_08", "Įvykių kalendorius-pridėtos kategorijos");
define("EC_ADM_09", "Įvykių kalendorius-kategorijos redaguotos");
define("EC_ADM_10", "Įvykių kalendorius-kategorijos panaikintos");
define("EC_ADM_11", "Įvykių kalendorius-seni įvykiai panaikinti");


?>