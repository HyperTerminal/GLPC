<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/calendar_menu/languages/Lithuanian_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/07 22:33:29 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("CM_SCH_LAN_1", "Kalendorius");


?>