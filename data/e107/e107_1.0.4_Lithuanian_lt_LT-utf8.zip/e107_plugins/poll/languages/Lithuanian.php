<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/poll/languages/Lithuanian.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/01/03 20:16:18 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("POLL_ADLAN01", "Apklausa");
define("POLL_ADLAN02", "Apklausos įskiepis leidžia panaudoti apklausas svetainės meniu ar diskusijose.");
define("POLL_ADLAN03", "Konfiguruoti apklausas");
define("POLL_ADLAN04", "Apklausos įskiepis buvo sėkmingai įdiegtas. Norint įdėti apklausas spauskite ant Apklausos piktogramos įskiepių sekcijoje (adminstratoriaus meniu) ir nepamirškite aktyvuoti meniu administratoriaus Meniu sekcijoje.");
define("POLL_ADLAN05", "Pagrindinė apklausa:");
define("POLL_ADLAN06", "Forumo tema:");
define("POLL_ADLAN07", "Reikšmė");
define("POLLAN_MENU_CAPTION", "Apklausa");
define("POLLAN_1", "Esamos apklausos");
define("POLLAN_2", "Sukurti/keisti apklausas");
define("POLLAN_3", "Apklausos klausimas");
define("POLLAN_4", "Parinktys");
define("POLLAN_5", "Keisti");
define("POLLAN_6", "Trinti");
define("POLLAN_7", "Apklausų dar nėra.");
define("POLLAN_8", "Įterpti dar vieną pasirinkimą");
define("POLLAN_9", "Leisti daugiariopus pasirinkimus?");
define("POLLAN_10", "Taip");
define("POLLAN_11", "Ne");
define("POLLAN_12", "Rodyti rezultatus");
define("POLLAN_13", "Po balsavimo");
define("POLLAN_14", "paspaudus rezultatų rodymo nuorodą - komentarai turi būti įgalinti");
define("POLLAN_15", "Leisti balsuoti šioje apklausoje");
define("POLLAN_16", "Balsų laikymo metodas");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP adresas");
define("POLLAN_19", "Vartotojo ID (tik nariai gali balsuoti)");
define("POLLAN_20", "Leisti komentuoti šią apklausą?");
define("POLLAN_21", "Peržiūrėti vėl");
define("POLLAN_22", "Atnaujinti apklausą");
define("POLLAN_23", "Sukurti apklausą");
define("POLLAN_24", "Peržiūrėti");
define("POLLAN_25", "Išvalyti laukelius");
define("POLLAN_26", "Balsai");
define("POLLAN_27", "Komentarai");
define("POLLAN_28", "Ankstesnės apklausos");
define("POLLAN_29", "Paskelbta");
define("POLLAN_30", "Pateikti");
define("POLLAN_31", "Balsai");
define("POLLAN_32", "Paspauskite norėdami pamatyti rezultatus");
define("POLLAN_33", "Ankstensių apklausų nėra.");
define("POLLAN_34", "Pavadinimas");
define("POLLAN_35", "Paskelbta");
define("POLLAN_36", "Aktyvuota");
define("POLLAN_37", "Aktyvuoti iš");
define("POLLAN_38", "to");
define("POLLAN_39", "Ačiū už balsą!");
define("POLLAN_40", "Paspauskite norėdami pamatyti rezultatus");
define("POLLAN_41", "Ši apklausa tik nariams");
define("POLLAN_42", "Ši apklausa tik administratoriams");
define("POLLAN_43", "Jums balsuoti čia neleidžiama.");
define("POLLAN_44", "Ištrinti šią apklausą?");
define("POLLAN_45", "Apklausa sėkmingai atnaujinta");
define("POLLAN_46", "Paliktas tuščias laukas (-ai)");


?>