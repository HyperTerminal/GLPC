<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_forum_viewtopic.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/23 11:06:18 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Diskusijos");
define("LAN_01", "Diskusijos");
define("LAN_02", "Eiti į puslapį");
define("LAN_03", "Eiti");
define("LAN_04", "Atgal");
define("LAN_05", "Toliau");
define("LAN_06", "Prisijungta");
define("LAN_07", "Vietovė");
define("LAN_08", "Tinklalapis");
define("LAN_09", "Apsilankymų skaičius po registracijos");
define("LAN_10", "Į viršų");
define("LAN_65", "Persikelti");
define("LAN_66", "Ši tema dabar uždaryta");
define("LAN_67", "Pranešimų");
define("LAN_194", "Svečias");
define("LAN_195", "Užsiregistravęs dalyvis");
define("LAN_321", "Moderatoriai: ");
define("LAN_389", "Prieš tai buvusi tema");
define("LAN_390", "Sekanti tema");
define("LAN_391", "sekti šią temą");
define("LAN_392", "nesekti šios temos");
define("LAN_393", "Greitas atsakymas");
define("LAN_394", "Peržiūrėti");
define("LAN_395", "Atsakyti į temą");
define("LAN_396", "Tinklalapis");
define("LAN_397", "El. paštas");
define("LAN_398", "Dosjė");
define("LAN_399", "Privati žinutė");
define("LAN_400", "Redaguoti");
define("LAN_401", "Atsakyti cituojant");
define("LAN_402", "Autorius");
define("LAN_403", "Pranešimas");
define("LAN_404", "Jokių temų prieš šią");
define("LAN_405", "Temų toliau nėra");
define("LAN_406", "Moderatorius: redaguoti");
define("LAN_435", "Moderatorius: ištrinti");
define("LAN_408", "Moderatorius: perkelti");
define("LAN_409", "Ar tikrai norite pašalinti šią temą ir visus pranešimus?");
define("LAN_410", "Ar tikrai norite pašalinti šį atsakymą?");
define("LAN_411", "paskelbė ");
define("LAN_412", "Pavadinimas");
define("LAN_413", "Pranešti");
define("LAN_414", "Pranešti apie šią temą moderatoriui");
define("LAN_415", "Temos pavadinimas");
define("LAN_416", "Įvesti pranešimą");
define("LAN_417", "Administratorius bus informuotas apie šią temą. Jūs galite parašyti žinutę paaiškinančią dėl ko ši tema nepriimtina (užgauli).");
define("LAN_418", "<b>Nenaudoti</b> šios formos susisiekimui su administratoriumi dėl kitų priežasčių.");
define("LAN_419", "Išsiųsti pranešimą");
define("LAN_420", "Paspauskite, jei pageidaujate peržiūrėti pranešimą");
define("LAN_421", "Pranešimas apie diskusijų temą nuo");
define("LAN_422", "Apie šį pranešimą buvo pranešta iš tinklalapio ");
define("LAN_423", "Žinutė negali būti išsiųsta. ");
define("LAN_424", "Moderatorius informuotas.<br />Dėkojame.");
define("LAN_425", "Žinutė nuo: ");
define("LAN_426", "Pranešimas apie: ");
define("LAN_427", "Įvyko klaida siunčiant laišką");
define("LAN_428", "Pranešimas perduotas");
define("LAN_429", "Norėdami sugrįžti į diskusijas paspauskite čia");
define("LAN_430", "balsavimas");
define("FORLAN_26", "Atsakymas ištrintas");
define("FORLAN_10", "Pradėti naują temą");
define("LAN_29", "Redaguota");
define("LAN_431", "Sindikuoti šią temą: rss 0.92");
define("LAN_432", "Sindikuoti šią temą: rss 2.0");
define("LAN_433", "Sindikuoti šią temą: RDF");
define("FORLAN_101", "Siųsti e-paštu temą");
define("FORLAN_102", "Spausdinimo vaizdas");
define("FORLAN_103", "[vartotojas ištrintas]");
define("FORLAN_104", "Tema nerasta");
define("FORLAN_HIDDEN", "HIDDEN - LOGIN AND REPLY TO REVEAL");


?>