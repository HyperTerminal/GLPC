<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/07 22:33:29 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Visi naujausi pranešimai nesusiję su Jūsų apibrėžta vartotojų grupe, todėl nedemonstruojami.");
define("NFP_2", "Pranešimų dar nėra");
define("NFP_3", "Nauji pranešimai diskusijose meniu nustatymai įrašyti");
define("NFP_4", "Antraštė");
define("NFP_5", "Kiek pranešimų rodyti?");
define("NFP_6", "Kiek simbolių rodyti?");
define("NFP_7", "Taisyti per ilgus komentarus?");
define("NFP_8", "Ar rodyti originalius temos pavadinimus meniu?");
define("NFP_9", "Atnaujinti meniu nustatymus");
define("NFP_10", "Nauji pranešimai diskusijose meniu nustatymai");
define("NFP_11", "Išsiųsta");
define("NFP_12", "Didžiausias rodomų pranešimų amžius");
define("NFP_13", "Naudokite nulį saito pabaigoje; Naudokite nustatymo dienomis vertę sumažindami duomenų bazės laiką judrioje vietoje");


?>