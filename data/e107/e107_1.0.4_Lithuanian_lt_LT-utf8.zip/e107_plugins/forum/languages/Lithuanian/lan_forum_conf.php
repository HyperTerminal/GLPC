<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_forum_conf.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/07 21:47:21 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LAN_FORUM_INSTALL_01", "Forumas");
define("LAN_FORUM_INSTALL_02", "Šis įskiepis yra visiškai matomas Forumas sistemoje");
define("LAN_FORUM_INSTALL_03", "Konfigūruoti forumą");
define("LAN_FORUM_INSTALL_04", "Jūsų forumas neinstaliuotas");
define("LAN_FORUM_INSTALL_05", "Forumas sėkmingai atnaujintas, dabar versija:% 1 $ s");
define("LAN_FORUM_INSTALL_06", "[forumas]");
define("LAN_FORUM_INSTALL_07", "[daugiau...]");
define("FORLAN_5", "Apklausa pašalinta.");
define("FORLAN_6", "Tema ištrinta");
define("FORLAN_7", "Atsakymai ištrinti");
define("FORLAN_8", "Trynimas atšauktas.");
define("FORLAN_9", "Tema perkelta.");
define("FORLAN_10", "Perkėlimas atšauktas.");
define("FORLAN_11", "Grįžti į diskusijas");
define("FORLAN_12", "Diskusijų konfigūracija");
define("FORLAN_13", "Ar tikrai norite pašalinti šią apklausą?<br /> Jei pašalinsite, tai <b><u>negalėsite</u></b> atkurti.");
define("FORLAN_14", "Atšaukti");
define("FORLAN_15", "Patvirtinti pranešimo diskusijose trynimą");
define("FORLAN_16", "Patvirtinti apklausos atšaukimą");
define("FORLAN_17", "Paskelbė");
define("FORLAN_18", "Ar tikrai norite ištrinti šią diskusiją");
define("FORLAN_19", "temą ir su ją susijusius pranešimus?");
define("FORLAN_20", "apklausa taip pat bus ištrinta");
define("FORLAN_21", "Jei ištrinsite, tai jie");
define("FORLAN_22", "pranešimą?<br />Jei ištrinsite,");
define("FORLAN_23", "negalėsite</u></b> atkurti");
define("FORLAN_24", "Perkelti temą į diskusiją");
define("FORLAN_25", "Perkelti temą");
define("FORLAN_26", "Atsakymas ištrintas");
define("FORLAN_27", "perkelta");
define("FORLAN_28", "negalima keisti pagrindinio pavadinimo");
define("FORLAN_29", "Pridėti");
define("FORLAN_30", "to titulinį");
define("FORLAN_31", "Pervardinti į:");
define("FORLAN_32", "Pervardinti pagrindines nuostatas:");


?>