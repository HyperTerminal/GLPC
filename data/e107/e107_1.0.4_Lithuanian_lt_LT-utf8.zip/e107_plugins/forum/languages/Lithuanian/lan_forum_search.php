<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_forum_search.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:56 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Diskusijos");
define("FOR_SCH_LAN_2", "Pasirinkite diskusijas");
define("FOR_SCH_LAN_3", "Visos diskusijos");
define("FOR_SCH_LAN_4", "Visas pranešimas");
define("FOR_SCH_LAN_5", "Kaip dalis temos");


?>