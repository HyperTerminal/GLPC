<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_forum_stats.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:56 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Diskusijų statistika");
define("FSLAN_1", "Bendra");
define("FSLAN_2", "Diskusijų atidaryta");
define("FSLAN_3", "Atidaro");
define("FSLAN_4", "Iš viso pranešimų");
define("FSLAN_5", "Diskusijų temos");
define("FSLAN_6", "Diskusijų pranešimai");
define("FSLAN_7", "Diskusijų temų peržiūrėta");
define("FSLAN_8", "Duombazės dydis (tik diskusijų lentelės)");
define("FSLAN_9", "Vidutinis eilutės ilgis diskusijų lentelėje");
define("FSLAN_10", "Aktyviausios temos");
define("FSLAN_11", "Reitingas");
define("FSLAN_12", "Tema");
define("FSLAN_13", "Atsakymai");
define("FSLAN_14", "Pradėjo");
define("FSLAN_15", "Data");
define("FSLAN_16", "Žiūrimiausios temos");
define("FSLAN_17", "Peržiūrėta");
define("FSLAN_18", "Top nariai");
define("FSLAN_19", "Vardas");
define("FSLAN_20", "Pranešimai");
define("FSLAN_21", "Top temų pradėjėjai");
define("FSLAN_22", "Top atsakytojai");
define("FSLAN_23", "Diskusijų statistika");
define("FSLAN_24", "Vidutiniškai pranešimų per dieną");


?>