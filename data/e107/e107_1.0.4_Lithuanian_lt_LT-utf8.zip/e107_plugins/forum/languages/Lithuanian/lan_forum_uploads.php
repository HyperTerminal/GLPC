<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:56 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Diskusijų atsiuntimai");
define("FRMUP_1", "Atsiųstos bylos diskusijose");
define("FRMUP_2", "Byla ištrinta");
define("FRMUP_3", "Kalida: neina ištrinti bylos");
define("FRMUP_4", "Bylos ištrynimas");
define("FRMUP_5", "Bylos pavadinimas");
define("FRMUP_6", "Rezultatas");
define("FRMUP_7", "Rasta temoje");
define("FRMUP_8", "NERASTA");
define("FRMUP_9", "Atsiųstų bylų nerasta");
define("FRMUP_10", "Trinti");


?>