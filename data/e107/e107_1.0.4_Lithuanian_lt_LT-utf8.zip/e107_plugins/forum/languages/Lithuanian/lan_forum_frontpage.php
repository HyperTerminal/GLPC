<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/forum/languages/Lithuanian/lan_forum_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:56 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("FOR_FP_1", "Diskusijos");


?>