<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source:  $
|     $Revision:  $
|     $Date:  $
|     $Author:  $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Tema");
define("NFPM_LAN_2", "Autorius");
define("NFPM_LAN_3", "Peržiūrėta");
define("NFPM_LAN_4", "Atsakymų");
define("NFPM_LAN_5", "Paskutinis pranešimas");
define("NFPM_LAN_6", "Temos");
define("NFPM_LAN_7", "nuo");
define("NFPM_L1", "Šis įskiepis rodo naujus pranešimus tituliniame puslapyje");
define("NFPM_L2", "Paskutiniai pranešimai forume");
define("NFPM_L3", "Norėdami nustatyti, eikite į įskiepių skyrių administratoriaus valdymo meniu");
define("NFPM_L4", "Kurioje srityje aktyvuoti?");
define("NFPM_L5", "Neaktyvus");
define("NFPM_L6", "Puslapio viršus");
define("NFPM_L7", "Puslapio apačia");
define("NFPM_L8", "Antraštė");
define("NFPM_L9", "Kiek naujų pranešimų rodyti?");
define("NFPM_L10", "Rodyti judančioje slinktyje?");
define("NFPM_L11", "Slinkties aukštis");
define("NFPM_L12", "Naujų forumo pranešimų konfigūracija");
define("NFPM_L13", "Atnaujinti naujų forumo pranešimų nustatymus");
define("NFPM_L14", "Naujų forumo pranešimų nustatymai atnaujinti.");
define("NFPM_L15", "Pažymėkite, jei norite rodyti naujausius pranešimus.<br />Paprastai rodomos naujausios pranešimų temos.");
define("NFPM_L16", "[vartotojas ištrintas]");
define("NFPM_L17", "Nauji pranešimai populiarioje temoje");
define("NFPM_L18", "Nauji pranešimai");
define("NFPM_L19", "Nėra naujų pranešimų populiarioje temoje");
define("NFPM_L20", "Nėra naujų pranešimų");
define("NFPM_L21", "karšta tema");
define("NFPM_L22", "Uždaryta karšta tema");
define("NFPM_L23", "Skelbimas");
define("NFPM_L24", "Uždaryta tema");


?>