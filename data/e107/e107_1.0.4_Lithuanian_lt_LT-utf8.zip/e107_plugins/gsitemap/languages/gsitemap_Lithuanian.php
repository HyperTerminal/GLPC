<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/gsitemap/languages/gsitemap_Lithuanian.php,v $
|     $Revision: 1.1 $
|     $Date: 2007/01/03 20:11:22 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Svetainės žemėlapis");
define("GSLAN_1", "Saito nuoroda");
define("GSLAN_2", "Importuoti?");
define("GSLAN_3", "Tipas");
define("GSLAN_4", "vardas");
define("GSLAN_5", "Url");
define("GSLAN_6", "Pažymėkite nuorodas į juos pažymėti importui ...");
define("GSLAN_7", "Importuoti nuorodas");
define("GSLAN_8", "Importuoti su:");
define("GSLAN_9", "Prioritetas");
define("GSLAN_10", "Dažnumas");
define("GSLAN_11", "visuomet");
define("GSLAN_12", "kas valandą");
define("GSLAN_13", "kas dieną");
define("GSLAN_14", "kas savaitę");
define("GSLAN_15", "kas mėnesį");
define("GSLAN_16", "kasmet");
define("GSLAN_17", "niekada");
define("GSLAN_18", "Importuoti pažymėtas nuorodas");
define("GSLAN_19", "Google saito-žemėlapis");
define("GSLAN_20", "sąrašas");
define("GSLAN_21", "Instrukcijos");
define("GSLAN_22", "Sukurti naują įvedimą");
define("GSLAN_23", "Importas");
define("GSLAN_24", "Google žemėlapio įvedimai");
define("GSLAN_25", "vardas");
define("GSLAN_26", "URL");
define("GSLAN_27", "Paskutinis modas");
define("GSLAN_28", "Klaus.");
define("GSLAN_29", "Google saito-žemėlapio konfigūravimas");
define("GSLAN_30", "Rodymo tvarka");
define("GSLAN_31", "Matomas");
define("GSLAN_32", "Kaip naudotis Google Sitemaps");
define("GSLAN_33", "GoogleSiteMap Instrukcijos");
define("GSLAN_34", "Pirma, sukurti nuorodas norite nurodyti Jūsų Sitemap. Galite importuoti dauguma jūsų nuorodų dešinėje, paspaudę mygtuką 'Importuoti'");
define("GSLAN_35", "Jeigu jūs pasirinkote importuoti saitus, spustelėkite "Importuoti" ir tada patikrinkite, ar norite importuoti nuorodas");
define("GSLAN_36", "Taip pat galite rankiniu būdu įvesti atskirų nuorodų paspaudę nuorodą Sukurkite naują įrašą'");
define("GSLAN_37", "Kai jūs turite kai kuriuos įrašus, eikite į [URL] ir įveskite šį adresą: [URL2] Jeigu pirmiau nurodytu URL neatrodo teisė su jumis, įsitikinkite, svetainės URL yra teisinga admin -> [Nuostatos]");
define("GSLAN_38", "Norėdami gauti daugiau informacijos apie protokolo Google Sitemap, eikite į [url].");
define("GSLAN_39", "Nėra Svetainės Nuorodos - importo Sitelinks?");
define("GSLAN_40", "Google Sitemap Įvedimai");


?>