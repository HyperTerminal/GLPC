<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/online_extended_menu/languages/Lithuanian.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/03/26 07:33:34 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Svečių:");
define("ONLINE_EL2", "Narių:");
define("ONLINE_EL3", "Šiame puslapyje:");
define("ONLINE_EL4", "Naršo");
define("ONLINE_EL5", "Nariai");
define("ONLINE_EL6", "Naujausias narys");
define("ONLINE_EL7", "Peržiūrinėja");
define("ONLINE_EL8", "Daugiausia naršė:");
define("ONLINE_EL9", "-");
define("ONLINE_TRACKING_MESSAGE", "Online user tracking is currently disabled, please enable it [link=".e_ADMIN."users.php?options]here[/link][br]");


?>