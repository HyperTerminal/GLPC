<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/other_news_menu/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/01/03 20:15:59 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("TD_MENU_L1", "Kitos naujienos");
define("TD_MENU_L2", "Kitos naujienos");


?>