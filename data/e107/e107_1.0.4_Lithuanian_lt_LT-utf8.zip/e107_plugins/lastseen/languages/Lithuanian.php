<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/lastseen/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/26 15:08:37 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("LSP_LAN_1", "Paskutiniai lankytojai");


?>