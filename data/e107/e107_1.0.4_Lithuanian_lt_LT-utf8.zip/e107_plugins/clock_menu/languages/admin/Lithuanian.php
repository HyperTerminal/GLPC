<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/clock_menu/languages/admin/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:18:50 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Laikrodžio meniu nuostatos išsaugotos");
define("CLOCK_AD_L2", "Pavadinimas");
define("CLOCK_AD_L3", "Atnaujinti meniu nuostatas");
define("CLOCK_AD_L4", "Laikrodžio meniu nuostatos");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Jei pažymėta, data bus vaizduojama JAV formatu (0-12 AM/PM). Jei nepažymėta - 0-24 valandų formatu");
define("CLOCK_AD_L7", "Datos priešdėlis");
define("CLOCK_AD_L8", "Jei reikalingas trumpas žodis prieš datą, įrašykite jį čia. Jei nereikalingas, palikite laukelį tuščią.");
define("CLOCK_AD_L9", "Galūnė 1");
define("CLOCK_AD_L10", "Galūnė 2");
define("CLOCK_AD_L11", "Galūnė 3");
define("CLOCK_AD_L12", "Galūnė 4 ir daugiau");
define("CLOCK_AD_L13", "Jei reikalinga trumpa galūnė skaičiaus linksniavimui, įrašykite ją čia. Jei nereikalinga, palikite laukelį tuščią.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");


?>