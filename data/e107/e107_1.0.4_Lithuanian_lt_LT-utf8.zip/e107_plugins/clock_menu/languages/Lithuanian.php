<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/clock_menu/languages/Lithuanian.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:18:50 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("CLOCK_MENU_L1", "Laikrodžio meniu nuostatos išsaugotos");
define("CLOCK_MENU_L2", "Pavadinimas");
define("CLOCK_MENU_L3", "Atnaujinti meniu nuostatas");
define("CLOCK_MENU_L4", "Laikrodžio meniu nuostatos");
define("CLOCK_MENU_L5", "Pirmadienis,");
define("CLOCK_MENU_L6", "Antradienis,");
define("CLOCK_MENU_L7", "Trečiadienis,");
define("CLOCK_MENU_L8", "Ketvirtadienis,");
define("CLOCK_MENU_L9", "Penktadienis,");
define("CLOCK_MENU_L10", "Šeštadienis,");
define("CLOCK_MENU_L11", "Sekmadienis,");
define("CLOCK_MENU_L12", "Sausio");
define("CLOCK_MENU_L13", "Vasario");
define("CLOCK_MENU_L14", "Kovo");
define("CLOCK_MENU_L15", "Balandžio");
define("CLOCK_MENU_L16", "Gegužės");
define("CLOCK_MENU_L17", "Birželio");
define("CLOCK_MENU_L18", "Liepos");
define("CLOCK_MENU_L19", "Rugpjūčio");
define("CLOCK_MENU_L20", "Rugsėjo");
define("CLOCK_MENU_L21", "Spalio");
define("CLOCK_MENU_L22", "Lapkričio");
define("CLOCK_MENU_L23", "Gruodžio");
define("CLOCK_MENU_L24", "");


?>