<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_plugins/online_menu/languages/Lithuanian.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/03/26 07:33:36 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Svečių:");
define("ONLINE_L2", "Narių:");
define("ONLINE_L3", "Šiame puslapyje:");
define("ONLINE_L4", "Naršo");
define("ONLINE_L5", "Nariai");
define("ONLINE_L6", "Naujausias");
define("TRACKING_MESSAGE", "Svetainėje narių sekimas išjungtas. Galite jį įjungti administravimo srityje[link=".e_ADMIN."users.php?options]here[/link][br]");


?>