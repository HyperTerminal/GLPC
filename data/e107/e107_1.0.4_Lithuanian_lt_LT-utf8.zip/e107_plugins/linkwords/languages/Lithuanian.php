<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Laukas paliktas tuįčias");
define("LWLAN_2", "Žodžio nuoroda išsaugota");
define("LWLAN_3", "Žodžio nuoroda atnaujinta");
define("LWLAN_4", "Žodžio nuorodos nenustatytos");
define("LWLAN_5", "Žodžiai");
define("LWLAN_6", "Nuoroda");
define("LWLAN_7", "Aktyvu?");
define("LWLAN_8", "Opcijos");
define("LWLAN_9", "taip");
define("LWLAN_10", "ne");
define("LWLAN_11", "Egzistuoja žodžiai-nuorodos");
define("LWLAN_12", "Taip");
define("LWLAN_13", "Ne");
define("LWLAN_14", "pridėti žodžius-nuorodas");
define("LWLAN_15", "Atnaujinti žodžius-nuorodas");
define("LWLAN_16", "Redaguoti");
define("LWLAN_17", "Ištrinti");
define("LWLAN_18", "Įsitikinę, kad norite pašalinti žodžio nuorodą?");
define("LWLAN_19", "Žodis-nuoroda pašalinta");
define("LWLAN_20", "Neįmanoma rasti įrašo DB įskiepyje.");
define("LWLAN_21", "Word auto nuorodą (arba kableliais atskirtų žodžių sąrašas)");
define("LWLAN_22", "Aktyvuoti?");
define("LWLAN_23", "Žodžių-nuorodų administravimas");
define("LWLAN_24", "Žodžių valdymas");
define("LWLAN_25", "Opcijos");
define("LWLAN_26", "Sritys kur reikia įjungti žodžius-nuorodas");
define("LWLAN_27", "Tai 'kontekstas' vaizduojamame tekst");
define("LWLAN_28", "Puslapiai, kuriems reikia atjungti žodžius-nuorodas");
define("LWLAN_29", "Pats formatas kaip meniu matomumo kontrolės. Vienas atitikmuo už linijos. Nurodykite dalinis arba visiškas URL. Baigtis '!' tikslaus atitikimo galutinio nuorodoje");
define("LWLAN_30", "Išsaugoti opcijas");
define("LWLAN_31", "Pridėti/redaguoti žodžius-nuorodas");
define("LWLAN_32", "Žodžių-nuorodų opcijos");
define("LWLAN_33", "užvadinimų sritys");
define("LWLAN_34", "elementų ataskaitos");
define("LWLAN_35", "Pagrindinė teksto dalis");
define("LWLAN_36", "Aprašymai (nuorodos ir kt.)");
define("LWLAN_37", "Palikimo sritys");
define("LWLAN_38", "paspaudžiamos nuorodos");
define("LWLAN_39", "Neapdirbtas tekstas");
define("LWLAN_40", "Vartotojo įrašyti pavadinimai (pvz., forumas)");
define("LWLAN_41", "Vartotojo įrašyti tekstai (pvz., forumas)");
define("LWLANINS_1", "Žodžiai-nuorodos");
define("LWLANINS_2", "Šis įskiepis bus susietas su konkrečius žodžius apibrėžta nuoroda");
define("LWLANINS_3", "Nustatyti");
define("LWLANINS_4", "Jei norite konfigūruoti, prašome spustelėkite ant šios nuorodos plugins admin tituliniame puslapyje skyriuje");


?>