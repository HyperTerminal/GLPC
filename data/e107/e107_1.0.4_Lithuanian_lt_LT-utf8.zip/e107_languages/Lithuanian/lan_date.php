<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_date.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:26 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "metai");
define("LANDT_02", "mėnuo");
define("LANDT_03", "savaitė");
define("LANDT_04", "diena");
define("LANDT_05", "valanda");
define("LANDT_06", "minutė");
define("LANDT_07", "sekundė");
define("LANDT_01s", "metai");
define("LANDT_02s", "mėnesiai");
define("LANDT_03s", "savaitės");
define("LANDT_04s", "dienos");
define("LANDT_05s", "valandos");
define("LANDT_06s", "minutės");
define("LANDT_07s", "sekundės");
define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "sek");
define("LANDT_09s", "sek");
define("LANDT_AGO", "prieš");


?>