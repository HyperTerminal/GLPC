<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:52:32 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Pasirinkti narį");
define("US_LAN_2", "Pasirinkti narių grupę");
define("US_LAN_3", "Visi nariai");
define("US_LAN_4", "Rasti nario vardą");
define("US_LAN_5", "Narys(iai) rastas");
define("US_LAN_6", "Ieškoti");


?>