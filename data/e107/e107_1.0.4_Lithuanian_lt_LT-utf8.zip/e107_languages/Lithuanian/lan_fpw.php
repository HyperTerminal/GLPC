<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_fpw.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/26 07:33:31 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Pakeisti slaptažodį");
define("LAN_02", "Atsiprašome, laiškas nebuvo išsiųstas - susisiekite su tinklalapio administratoriumi.");
define("LAN_03", "Pakeisti slaptažodį");
define("LAN_05", "Norėdami pakeisti slaptažodį, įveskite sekančią informaciją");
define("LAN_06", "Bandymas pakeisti slaptažodį");
define("LAN_07", "Kažkas iš šio IP adreso ");
define("LAN_08", "bandė pakeisti pagrindinio administratoriaus slaptažodį.");
define("LAN_09", "Slaptažodis pakeistas ");
define("LAN_112", "El. pašto adresas, kurį nurodėte prisiregistruodami ");
define("LAN_156", "Patvirtinti");
define("LAN_213", "Šio vardo/e-pašto adreso nėra duomenų bazėje.");
define("LAN_214", "Neįmanoma pakeisti slaptažodžio");
define("LAN_216", "Slaptažodžiui patvirtinti sekite šia nuoroda ...");
define("LAN_217", "Jūsų slaptažodis patvirtintas - galite prisijungti.");
define("LAN_218", "Jūsų vardas yra:");
define("LAN_219", "Su šiuo e-pašto adresu susietas slaptažodis jau buvo pakeistas ir negali būti pakeistas pakartotinai. Prašome susisiekti su tinklalapio administratoriumi.");
define("LAN_FPW1", "Vardas");
define("LAN_FPW2", "Įveskite kodą");
define("LAN_FPW3", "Įvestas netinkamas kodas");
define("LAN_FPW4", "Reikalavimas pakeisti šį slaptažodį jau buvo išsiųstas. Susisiekite su tinklalapio administratoriumi, jei negavote laiško.");
define("LAN_FPW5", "Kažkas pareikalavo pakeisti slaptažodį.");
define("LAN_FPW6", "Jums buvo išsiųstas laiškas su nuoroda, kuri pakeis Jūsų slaptažodį.");
define("LAN_FPW7", "Neteisinga nuoroda slaptažodžio pakeitimui.<br />Dėl tolesnės pagalbos susisiekite su tinklalapio administratoriumi.");
define("LAN_FPW8", "Slaptažodis vartotojui");
define("LAN_FPW9", "buvo sėkmingai pakeistas.<br /><br />Naujas slaptažodis yra:");
define("LAN_FPW10", "Prašome");
define("LAN_FPW11", "prisiregistruoti");
define("LAN_FPW12", "ir dėl saugumo iš karto pakeisti slaptažodį.");
define("LAN_FPW13", "prašome laikytis e-paštu atsiųstų intrukcijų, jei norite patvirtinti savo slaptažodį.");
define("LAN_FPW14", "šio asmens IP adresas buvo");
define("LAN_FPW15", "Tai jokiu būdu nereiškia, kad jūsų slaptažodis buvo pakeistas. Sekite žemiau pateikta nuoroda, jei norite pabaigti pakeitimo procesą.");
define("LAN_FPW16", "Jei tai ne jūs norėjote pakeisti slaptažodį ar NENORITE jo pakeisti, tiesiog ignoruokite šį laišką");
define("LAN_FPW17", "Nuoroda veiks 48 valandas.");


?>