<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_news.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Naujienos");
define("LAN_NEWS_1", "Naujienos tik atskiriems nariams");
define("LAN_NEWS_2", "Jums neleidžiama matyti šių naujienų");
define("LAN_NEWS_9", "Tik pavadinimas - <b>bus rodomas tik naujienos pavadinimas</b><br />");
define("LAN_NEWS_10", "Šis naujienų pranešimas yra <b>neaktyvus</b> (Jis bus nerodomas tituliniame puslapyje).");
define("LAN_NEWS_11", "Šis naujienų pranešimas yra  <b>aktyvuse</b> (Jis bus rodomas tituliniame puslapyje).");
define("LAN_NEWS_12", "Komentarai įjungti <b>įjungta</b>.");
define("LAN_NEWS_13", "Komentarai įjungti <b>išjungta</b>.");
define("LAN_NEWS_14", "<br />Aktyvavimo periodas:");
define("LAN_NEWS_15", "visas ilgis:");
define("LAN_NEWS_16", "b. Išplėstas ilgis:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Informacija:");
define("LAN_NEWS_19", "Dabar");
define("LAN_NEWS_23", "Naujienų rubrikos");
define("LAN_NEWS_24", "sukurti pdf šiai naujienai");
define("LAN_NEWS_25", "Redaguoti");
define("LAN_NEWS_31", "Dažni naujienų punktai");
define("LAN_NEWS_82", "Naujienos - Rubrikos");
define("LAN_NEWS_83", "Šiuo metu nėra naujienų - prašome apsilankyti vėliau.");
define("LAN_NEWS_84", "Atgal į naujienų apžvalga");
define("LAN_NEWS_85", "Atgal į rubrikų apžvalgą");
define("LAN_NEWS_86", "Senos naujienos");
define("LAN_NEWS_87", "Naujausios naujienos");
define("LAN_NEWS_462", "No news items for specified month");
define("LAN_NEWS_99", "Komentarai");
define("LAN_NEWS_100", "Įjungta");
define("LAN_NEWS_307", "Viso žinučių šioje rubrikoje:");


?>