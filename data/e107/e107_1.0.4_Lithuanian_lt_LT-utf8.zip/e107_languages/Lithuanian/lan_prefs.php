<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_prefs.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 sukurtas tinklalapis");
define("LAN_PREF_2", "e107 tiklalapio sistema");
define("LAN_PREF_3", "Ši svetainė naudoja turinio valdymo sistemą<a href='http://e107.org/' rel='external'>e107</a>, kuri yra atviro kodo ir laisvai platinama pagal <a href='http://www.gnu.org/' rel='external'>GNU</a> GPL licenziją.");
define("LAN_PREF_4", "cenzūruota");
define("LAN_PREF_5", "Diskusijos");


?>