<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_comment.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("COMLAN_0", "[blokavo administratoriaus]");
define("COMLAN_1", "Atblokuota");
define("COMLAN_2", "Blokas");
define("COMLAN_3", "Ištrinta");
define("COMLAN_4", "Info");
define("COMLAN_5", "Komentarai");
define("COMLAN_6", "Jūs turite būti prisijungęs kad pateikti pastabas šioje svetainėje, prašome prisijungti, arba, jei nesate registruotas spustelėkite");
define("COMLAN_7", "Pagrindinis svetainės administratorius");
define("COMLAN_8", "Komentarai");
define("COMLAN_9", "Patvirtinti");
define("COMLAN_10", "Administratorius");
define("COMLAN_11", "Sistema neįrašė jūsų komentarų į duomenų bazę. Pamėginkite iš naujo nenaudodami nestandartinių simbolių.");
define("COMLAN_12", "Vartotojas");
define("COMLAN_16", "Vartotojo vardas:");
define("COMLAN_99", "Komentarai");
define("COMLAN_100", "Naujienos");
define("COMLAN_101", "Apklausa");
define("COMLAN_102", "Atsakyti:");
define("COMLAN_103", "Straipsnis");
define("COMLAN_104", "Apžvalga");
define("COMLAN_105", "Turinys");
define("COMLAN_106", "Įkrauti");
define("COMLAN_145", "Prisiregistruota:");
define("COMLAN_194", "Svečias");
define("COMLAN_195", "Registruoti nariai");
define("COMLAN_310", "Neįmanoma įrašyti žinutės, nes šis vartotojo vardas jau užregistruotas. Jei tai jūsų vardas, prašome prisijungti.");
define("COMLAN_312", "Atmesta - žinutė dubliuojasi.");
define("COMLAN_313", "Vieta");
define("COMLAN_314", "Tvarkyti komentarus");
define("COMLAN_315", "Atsarginė kopija");
define("COMLAN_316", "Nėra trackback šiai naujienų žinutei.");
define("COMLAN_317", "Taisyti trackback");
define("COMLAN_318", "Taisyti komentarą");
define("COMLAN_319", "Taisyta");
define("COMLAN_320", "Atnaujinti komentarą");
define("COMLAN_321", "čia");
define("COMLAN_322", "prisijungti");
define("COMLAN_323", "Klaida");
define("COMLAN_324", "Subjektas");
define("COMLAN_325", "Ats:");
define("COMLAN_326", "Grįžti į šį");
define("COMLAN_327", "Vertinimas");
define("COMLAN_328", "Komentarai užrakinti");
define("COMLAN_329", "Nėra autoriaus");
define("COMLAN_330", "IP:");
define("COMLAN_331", "Laukiama patvirtinimo");
define("COMLAN_TYPE_1", "naujiena");
define("COMLAN_TYPE_2", "įkrauti");
define("COMLAN_TYPE_3", "DUK");
define("COMLAN_TYPE_4", "apklausa");
define("COMLAN_TYPE_5", "docs");
define("COMLAN_TYPE_6", "bugtrack");
define("COMLAN_TYPE_7", "idėjos");
define("COMLAN_TYPE_8", "vartotojo profilis");
define("COMLAN_TYPE_PAGE", "Kiekis");


?>