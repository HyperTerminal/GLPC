<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_db.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Sukurta sisteminių nuostatų atsarginė kopija duomenų bazėje.");
define("DBLAN_2", "Sukurti e107 duomenų bazės atsarginę kopiją");
define("DBLAN_3", "Sukurti atsarginę kopiją");
define("DBLAN_4", "Patikrinti e107 duomenų bazės vientisumą");
define("DBLAN_5", "Patikrinti vientisumą");
define("DBLAN_6", "Optimizuoti e107 duomenų bazę");
define("DBLAN_7", "Optimizuoti SQL duomenų bazę");
define("DBLAN_8", "Sukurti atsarginę sisteminių nuostatų kopiją duomenų bazėje");
define("DBLAN_9", "Išsaugoti nuostatas");
define("DBLAN_10", "Duomenų bazės tvarkymo įrankiai");
define("DBLAN_11", "mySQL duomenų bazė");
define("DBLAN_12", "optimizuota");
define("DBLAN_13", "Atgal");
define("DBLAN_14", "Atlikta");
define("DBLAN_15", "Patikrinti galimus duomenų bazės atnaujinimus");
define("DBLAN_16", "Patikrinti atnaujinimus");
define("DBLAN_17", "Pref. Name");
define("DBLAN_18", "Pref. Value");
define("DBLAN_19", "Spustelėkite mygtuką, kad atidarytumėte parinkčių redaktorius (tik patyrusiems vartotojams)");
define("DBLAN_20", "Nuostatų redaktorius");
define("DBLAN_21", "Ištrinti pažymėtus");
define("DBLAN_22", "Įskiepis: Peržiūrėti ir skenuoti");
define("DBLAN_23", "Skenavimas užbaigtas");
define("DBLAN_24", "Vardas");
define("DBLAN_25", "Katalogas");
define("DBLAN_26", "Įtraukti Add-ons");
define("DBLAN_27", "Įdiegta");
define("DBLAN_28", "Paspauskite mygtuką įskiepių katalogų keitimui ");
define("DBLAN_29", "Nuskenuoti įskiepių katalogus");
define("DBLAN_30", "(Jei addon rodo klaidą, patikrinkite, ar neklaidingi PHP uždarymo / atidarymo žymių simboliai)");
define("DBLAN_31", "atitinka");
define("DBLAN_32", "Klaida");
define("DBLAN_33", "Nepasiekiamas");
define("DBLAN_34", "Nepažymėtas");
define("DBLAN_35", "Paspauskite mygtuką patikrinti vartotojo lentelei");
define("DBLAN_36", "Paspauskite vartotojo lentelę");


?>