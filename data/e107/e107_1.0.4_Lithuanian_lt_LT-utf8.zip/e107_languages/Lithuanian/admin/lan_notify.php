<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Pranešimai elektroniniu paštu");
define("NT_LAN_2", "Veiksmai, po kurių išsiunčiami pranešimai");
define("NT_LAN_3", "Nesiųsti");
define("NT_LAN_4", "Administratoriui");
define("NT_LAN_5", "Grupei");
define("NT_LAN_6", "E-pašto adresu");
define("NU_LAN_1", "<b>Nariai</b>");
define("NU_LAN_2", "Naujos nario paskyros sukūrimas");
define("NU_LAN_3", "Nario paskyros patvirtinimas");
define("NU_LAN_4", "Narys prisijungė prie savo paskyros");
define("NU_LAN_5", "Narys atsijungė nuo savo paskyros");
define("NS_LAN_1", "<b>Saugos įvykiai</b>");
define("NS_LAN_2", "IP adresui uždraustas pisijungimas prie svetainės");
define("NN_LAN_1", "<b>Naujienos</b>");
define("NN_LAN_2", "Narys pasiūlė naujieną");
define("NN_LAN_3", "Administratorius įrašė naujieną");
define("NN_LAN_4", "Administratorius redagavo naujieną");
define("NN_LAN_5", "Administratorius ištrynė naujieną");
define("NF_LAN_1", "failo įvykis");
define("NF_LAN_2", "Failas įkeltas vartotojo");
define("CM_LAN_1", "Įvykių komentarai");
define("CM_LAN_2", "Komentaras išsiųstas, laukiama patvirtinimo");


?>