<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_menus.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Matoma visiems");
define("MENLAN_2", "Matoma tik nariams");
define("MENLAN_3", "Matoma tik administratoriams");
define("MENLAN_4", "Šį meniu matys:");
define("MENLAN_6", "Išsaugoti matomumo nuostatas");
define("MENLAN_7", "Matomumo nuostatų tvarkymas");
define("MENLAN_8", "Matomumo nuostatos išsaugotos");
define("MENLAN_9", "Įdiegtas naujas individualus meniu");
define("MENLAN_10", "Įdiegtas naujas meniu");
define("MENLAN_11", "Meniu išjungtas");
define("MENLAN_12", "Aktyvuoti: pasirinkite sritį");
define("MENLAN_13", "Aktyvuoti srityje ");
define("MENLAN_14", "Sritis");
define("MENLAN_15", "Išjungti");
define("MENLAN_16", "Konfigūruoti");
define("MENLAN_17", "Perkelti aukščiau");
define("MENLAN_18", "Perkelti žemiau");
define("MENLAN_19", "Perkelti į sritį Nr.");
define("MENLAN_20", "Matomumas");
define("MENLAN_22", "Neaktyvūs meniu");
define("MENLAN_23", "Perkelti į apačią");
define("MENLAN_24", "Perkelti į viršų");
define("MENLAN_25", "Parinktys ...");
define("MENLAN_26", "Šis meniu bus <strong>RODOMAS</strong> tik žemiau išvardintuose puslapiuose");
define("MENLAN_27", "Šis meniu bus <strong>PASLĖPTAS</strong> tik žemiau išvardintuose puslapiuose");
define("MENLAN_28", "Įveskite puslapių adresus. Po vieną adresą į kiekvieną eilutę.<br />Pvz:<strong>page.php?1!</strong>");
define("MENLAN_29", "Pasirinkite šabloną");
define("MENLAN_30", "Meniu sritys ir jų pozicijos pasirinktiniuose šablonuose bus parodytos, jei pasirinksite atitinkamą pasirinktinį šabloną:");
define("MENLAN_31", "Nustatytas šablonas");
define("MENLAN_32", "Naujienų šablonas");
define("MENLAN_33", "Pasirinktinis šablonas");
define("MENLAN_34", "Įdėtas");
define("MENLAN_35", "Meniu išdėstymo tvarkymas");
define("MENLAN_36", "Pasirinkite meniu ir");
define("MENLAN_37", "tuomet, pasirinkite kurioje srityje jį aktyvuoti.");
define("MENLAN_38", "Laikykite nuspaudę CTRL mygtuką, jei norite pasirinkti daugiau nei vieną meniu.");


?>