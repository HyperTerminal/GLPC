<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_userinfo.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Nepavyko rasti vartotojo IP adreso - nėra informacijos.");
define("USFLAN_3", "Laiškas išsiųstas iš IP adreso");
define("USFLAN_4", "Host");
define("USFLAN_5", "Spauskite čia norėdami perduoti IP adresą įadmin draudimų puslapį");
define("USFLAN_6", "Vartotojo ID");
define("USFLAN_7", "Vartotojo informacija");


?>