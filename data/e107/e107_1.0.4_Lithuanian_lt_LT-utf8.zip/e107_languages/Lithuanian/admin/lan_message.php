<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_message.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Gauti laiškai");
define("MESSLAN_2", "Ištrinti laišką");
define("MESSLAN_3", "Laiškas ištrintas");
define("MESSLAN_4", "Ištrinti visus laiškus");
define("MESSLAN_5", "Patvirtinti");
define("MESSLAN_6", "Visi laiškai ištrinti");
define("MESSLAN_7", "Nėra laiškų");
define("MESSLAN_8", "Laiško tipas");
define("MESSLAN_9", "Praneša apie");
define("MESSLAN_10", "Pateikė");
define("MESSLAN_11", "atidaryti naujame lange");
define("MESSLAN_12", "Laiškas");
define("MESSLAN_13", "Nuoroda");


?>