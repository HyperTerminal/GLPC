<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_upload.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("UPLLAN_1", "Atsiųsta byla išbraukta iš sąrašo.");
define("UPLLAN_2", "Nuostatos išsaugotos duomenų bazėje");
define("UPLLAN_3", "Atsiųstos bylos ID ");
define("UPLLAN_5", "Siuntėjas");
define("UPLLAN_6", "E-pašto adresas");
define("UPLLAN_7", "Svetainė");
define("UPLLAN_8", "Bylos pavadinimas");
define("UPLLAN_9", "Versija");
define("UPLLAN_10", "Byla");
define("UPLLAN_11", "Bylos dydis");
define("UPLLAN_12", "Paveiksliukas");
define("UPLLAN_13", "Aprašymas");
define("UPLLAN_14", "Demonstracinė versija");
define("UPLLAN_16", "kopijuoti bylą į naujienų katalogą");
define("UPLLAN_17", "pašalinti bylą iš sąrašo");
define("UPLLAN_18", "Detali informacija apie atsiųstą bylą");
define("UPLLAN_19", "Nėra nepatikrintų atsiųstų bylų");
define("UPLLAN_20", "Atsiųstų ir nepatikrintų bylų kiekis");
define("UPLLAN_21", "unmoderated public upload");
define("UPLLAN_22", "ID ");
define("UPLLAN_23", "Bylos pavadinimas");
define("UPLLAN_24", "Byla");
define("UPLLAN_25", "Leisti nariams siųsti bylas į svetainę?");
define("UPLLAN_26", "Nėra viešų siuntimai bus leidžiama, jei išjungtas");
define("UPLLAN_27", "nemoderuoti vieši įkrovimai");
define("UPLLAN_29", "Bylos laikymo būdas");
define("UPLLAN_30", "Pasirinkite kokiu būdu bus saugomos atsiųstos bylos: kaip normalios bylos serveryje, ar dvejetainiu kodu MySQL duomenų bazėje. <br /><b>Pažymėtina</b>, kad dvejetainiu kodu geriau yra saugoti bylas, ne didesnes kaip 500kb.");
define("UPLLAN_31", "Normalia byla serveryje");
define("UPLLAN_32", "Dvejetainiu kodu duomenų bazėje");
define("UPLLAN_33", "Maksimalus bylos dydis");
define("UPLLAN_34", "Didžiausias leidžiamas siunčiamos bylos dydis - palikus tuščią, galios php.ini nuostatose įrašytas maksimalus dydis ( dabar php.ini leidžia siųsti bylas ne didesnes kaip");
define("UPLLAN_35", "Leistini bylos formatai");
define("UPLLAN_36", "Prašome leistinus formatus rašyti po vieną į kiekvieną eilutę");
define("UPLLAN_37", "Narių, kurie gali siųsti bylas į svetainę, grupė");
define("UPLLAN_38", "Pasirinkite, tik patikimus narius");
define("UPLLAN_39", "Išsaugoti nuostatas");
define("UPLLAN_41", "<b>Dėmesio</b>: php.ini nuostatose uždrausta siųsti bylas į serverį.");
define("UPLLAN_42", "Veiksmai");
define("UPLLAN_43", "Atsiųstos bylos");
define("UPLLAN_44", "Atsiųsta byla");
define("UPLLAN_45", "Ar jūs tikrai norite pašalinti pasirinktą bylą...");
define("UPLAN_COPYTODLM", "kopijuoti į siuntinių katalogą");
define("UPLAN_IS", "yra");
define("UPLAN_ARE", "yra");
define("UPLAN_COPYTODLS", "Kopijuoti į siuntinių katalogą");
define("UPLLAN_48", "Saugumo sumetimais  failų tipai buvo perkeltas iš duomenų bazės į savo admin katalogą įsikūrusi flatfile. Naudoti, pervadinti failą e107_admin/filetypes_.php e107_admin/filetypes.php ir kablelių sąrašą failų tipų plėtinius. Neturėtų leisti. Html, txt ir tt įkelti, kaip šio tipo failą, kuris apima kenksmingą javascript užpuolikas gali įkelti. Žinoma, jūs taip pat neturėtumėte leisti PHP failus arba bet kokio kito tipo vykdomąjį scenarijų siuntinys.");


?>