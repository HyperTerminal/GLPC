<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_image.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("IMALAN_1", "Leisti iliustracijų atsiuntimą");
define("IMALAN_2", "Atsiųstos iliustracijos bus rodomos visoje svetainėjecomments  (komentaruose, chatbox etc.) to images posted using the [img] bbcode");
define("IMALAN_3", "Iliustracijos dydžio pakeitimo būdas");
define("IMALAN_4", "Paveiksliuko dydžio keitimas automatiškai naudojant GD1/2 bibliotekas arba ImageMagick");
define("IMALAN_5", "Kelias iki ImageMagick (jei pasirinkta)");
define("IMALAN_6", "Pilnas kelias iki ImageMagick iliustracijų konvertavimo įrankio");
define("IMALAN_7", "Svetainės iliustracijų nuostatos");
define("IMALAN_8", "Atnaujinti iliustracijų nuostatas");
define("IMALAN_9", "Svetainės iliustracijų nuostatos atnaujintos");
define("IMALAN_10", "Iliustracijų atsiuntimo teisės");
define("IMALAN_11", "Pasirinkti narių grupę, kuriai bus leista atsiųsti iliustracijas (jei tai leista aukščiau)");
define("IMALAN_12", "Iliustracijų pateikimo būdas");
define("IMALAN_13", "Ką daryti su atsiųstomis iliustracijomis, jei jų rodymas yra uždraustas");
define("IMALAN_14", "Rodyti paveiksliuko adresą");
define("IMALAN_15", "Nieko nerodyti");
define("IMALAN_16", "Rodyti atsiųstas kaukes");
define("IMALAN_17", "Spauskite čia");
define("IMALAN_18", "Atsiųstos iliustarcijos");
define("IMALAN_19", "Rodyti  klaidingą pranešimą");
define("IMALAN_21", "Naudoja");
define("IMALAN_22", "Paveiksliukas nenaudojamas");
define("IMALAN_23", "Kaukė");
define("IMALAN_24", "Fotografija");
define("IMALAN_25", "Ištrinti visus nenaudojamus paveiksliukus");
define("IMALAN_26", "Paveiksliukai ištrinti");
define("IMALAN_28", "ištrinta");
define("IMALAN_29", "Nėra paveiksliukų");
define("IMALAN_30", "Kiekvienas (viešas)");
define("IMALAN_31", "Tik svečiai");
define("IMALAN_32", "Tik nariai");
define("IMALAN_33", "Tik administratoriai");
define("IMALAN_34", "Naudoti Sleight režimą");
define("IMALAN_35", "Ištaiso permatomumą PNG-24 formato paveiksliukuose su alfa permatomumu IE 5 / 6 naršyklėse (galioja visai svetainei)");
define("IMALAN_36", "Patikrinti kaukės dydį ir priėjimą");
define("IMALAN_37", "Kaukės patikrinimas");
define("IMALAN_38", "Didžiausias leistinas plotis");
define("IMALAN_39", "Didžiausias leistinas aukštis");
define("IMALAN_40", "Per plati");
define("IMALAN_41", "Per aukšta");
define("IMALAN_42", "Nerasta");
define("IMALAN_43", "Ištrinti atsiųstą kaukę");
define("IMALAN_44", "Delete external reference");
define("IMALAN_45", "Nerasta");
define("IMALAN_46", "Per didelė");
define("IMALAN_47", "Viso atsiųstų kaukių");
define("IMALAN_48", "Viso išorinių (nutolusių) kaukių");
define("IMALAN_49", "Nariai su kaukėmis");
define("IMALAN_50", "Viso");
define("IMALAN_51", "Kaukė skirta nariui");
define("IMALAN_52", "Kelias į ImageMagick atrodo neteisingas");
define("IMALAN_53", "Kelias į ImageMagick atrodo teisingas, bet konvertuotas failas negali galioti");
define("IMALAN_54", "GD versija instaliuota");
define("IMALAN_55", "Neinstaliuota");


?>