<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_emoticon.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Jausmukų aktyvacija");
define("EMOLAN_2", "Pavadinimas");
define("EMOLAN_3", "Jausmukai");
define("EMOLAN_4", "Aktyvuoti jausmukus?");
define("EMOLAN_5", "Piktograma");
define("EMOLAN_6", "Jausmuko kodas");
define("EMOLAN_7", "atskirkite kelis jausmuko kodus tuščiu tarpu");
define("EMOLAN_8", "Būsena");
define("EMOLAN_9", "Nuostatos");
define("EMOLAN_10", "Aktyvi");
define("EMOLAN_11", "Aktyvuoti kolekciją'");
define("EMOLAN_12", "Redaguoti / tvarkyti šią kolekciją");
define("EMOLAN_13", "Įdiegtos kolekcijos");
define("EMOLAN_14", "Išsaugoti nuostatas");
define("EMOLAN_15", "Redaguoti / tvarkyti jausmukų kolekciją");
define("EMOLAN_16", "Jausmukų nuostatos išsaugotos");
define("EMOLAN_17", "Turite veidelių poką, kurie turi tarpus pavadinime ir  kurie neleidžiama!");
define("EMOLAN_18", "prašome pervadinti atvejus, išvardintus žemiau, jie nebegali turėti  tarpų:");
define("EMOLAN_19", "Vardas");
define("EMOLAN_20", "Vieta");
define("EMOLAN_21", "Klaida");
define("EMOLAN_22", "Rastas naujas jausmukų pakas");
define("EMOLAN_23", "New emote xml pak found:");
define("EMOLAN_24", "New emote php found:");
define("EMOLAN_25", "Instaliuokite naujas PHP šypsenėles");
define("EMOLAN_26", "Perskanuoti paketą");
define("EMOLAN_27", "Klaida įvyko apdorojant paketą:");
define("EMOLAN_28", "Generuoti XML");
define("EMOLAN_29", "XML failas sugeneruotas");
define("EMOLAN_30", "Klaida rašant XML failą");


?>