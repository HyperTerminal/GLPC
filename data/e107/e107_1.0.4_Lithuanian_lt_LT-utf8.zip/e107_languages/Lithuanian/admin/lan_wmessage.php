<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_wmessage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Pasisveikinimo žinutės");
define("WMLAN_01", "Įrašyti naują žinutę");
define("WMLAN_02", "Žinutė");
define("WMLAN_03", "Matomumas");
define("WMLAN_04", "Žinutės tekstas");
define("WMLAN_05", "Atitverti");
define("WMLAN_06", "Jei pažymėta, žinutė bus pateikta dėžutės viduje");
define("WMLAN_07", "Pakeitimui standartinės sistemos naudoti  {WMESSAGE} trumpą kodą:");
define("WMLAN_09", "Jokių pasisveikinimo žinučių dar nėra");
define("WMLAN_10", "Žinutės antraštė");


?>