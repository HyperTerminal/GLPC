<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_mailout.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "Išsaugoti pakeitimus");
define("PRFLAN_63", "Išsiųsti bandomąjį laišką");
define("PRFLAN_65", "Paspausti el.pašto siuntimui į");
define("PRFLAN_66", "El.pašto testas iš");
define("PRFLAN_67", "Tai yra testinis laiškas ir atrodo, kad jūsų elektroninio pašto nustatymai dirba ok!\n\nLinkėjimai\niš e107 svetainės sistemos.");
define("PRFLAN_68", "Laiškas negali būti išsiųstas. Atrodo, kad jūsų serveris yra neteisingai sukonfigūruotas siųsti laiškus, bandykite dar kartą naudojant SMTP, arba susisiekti su savo šeimininkus ir paprašyti juos patikrinti savo sendmail / elektroninio pašto serverio parametrus.");
define("PRFLAN_69", "Laiškas buvo sėkmingai išsiųsta, patikrinkite savo pašto dėžutę ..");
define("PRFLAN_70", "Įjungti SMTP");
define("PRFLAN_71", "Pažymint bandys naudoti SMTP serverio siųsti laiškus");
define("PRFLAN_72", "SMTP Serveris");
define("PRFLAN_73", "SMTP vartotojo Vardas");
define("PRFLAN_74", "SMTP Slaptažodis");
define("PRFLAN_75", "Laiškas negali būti išsiųstas.Prašome peržiūrėti savo SMTP parametrus arba išjungti SMTP ir bandykite dar kartą.");
define("MAILAN_01", "Nuo");
define("MAILAN_02", "Iš e-pašto adreso");
define("MAILAN_03", "Kam");
define("MAILAN_04", "Kopija");
define("MAILAN_05", "Bcc");
define("MAILAN_06", "Tema");
define("MAILAN_07", "Prikabinta byla");
define("MAILAN_08", "Išsiųsti laišką");
define("MAILAN_09", "Naudoti temos stilių");
define("MAILAN_10", "Vartotojas patvirtintas");
define("MAILAN_11", "Insert Variables");
define("MAILAN_12", "Visiems nariams");
define("MAILAN_13", "Visiems, kurie dar nepatvirtino registracijos");
define("MAILAN_14", "Rekomenduojama, kad įjungsite SMTP siųsti daug laiškų - nustatyti tolesnes nuostatas.");
define("MAILAN_15", "Nusiųsti");
define("MAILAN_16", "vartotojo vardas");
define("MAILAN_17", "prisijungimo nuoroda");
define("MAILAN_18", "vartotojo id");
define("MAILAN_19", "Tai ne admino el.pašto adresas. Prašome patikrinti savo nustatymus ir bandykite dar kartą.");
define("MAILAN_20", "Siunčiamas laiškas-kelias");
define("MAILAN_21", "Mass-Laiškų įrašai");
define("MAILAN_22", "neišsaugoti įrašai");
define("MAILAN_23", "vartotojo kalsės:");
define("MAILAN_24", "paštas (-ai) yra pasirengę būti siunčiami");
define("MAILAN_25", "Pauzė");
define("MAILAN_26", "Pause mass-mailing every");
define("MAILAN_27", "laiškai");
define("MAILAN_28", "Pauzės trukmė");
define("MAILAN_29", "sekundės");
define("MAILAN_30", "Daugiau nei 30 sekundžių naršyklės pertrauka");
define("MAILAN_31", "Sugrąžintas laiškas apdorojimui");
define("MAILAN_32", "El.pašto adresai");
define("MAILAN_33", "Ieinantis laiškas");
define("MAILAN_34", "Prisijungimo vardas");
define("MAILAN_35", "Slaptažodis");
define("MAILAN_36", "Ištrinti Sugrįžusius Laiškus po patikrinimo");
define("MAILAN_37", "veikti");
define("MAILAN_38", "atšauktiCancel");
define("MAILAN_39", "išsiųsti laišką");
define("MAILAN_40", "Reikia pervardinti<b>e107.htaccess</b> to <b>.htaccess</b> in");
define("MAILAN_41", "prieš išsiunčiant laišką iš šio puslapio");
define("MAILAN_42", "Įspėjimas");
define("MAILAN_43", "vartotojo vardas");
define("MAILAN_44", "Vartotojo loginas");
define("MAILAN_45", "Vartotojo el.paštas");
define("MAILAN_46", "Vartotojo atitikimas");
define("MAILAN_47", "yra");
define("MAILAN_48", "lygus");
define("MAILAN_49", "Id");
define("MAILAN_50", "Autorius");
define("MAILAN_51", "Subjektas");
define("MAILAN_52", "Lastmod");
define("MAILAN_53", "Adminai");
define("MAILAN_54", "pats");
define("MAILAN_55", "vartotojo klasės");
define("MAILAN_56", "Išsiųsti laišką");
define("MAILAN_57", "Laikykite SMTP sesijas gyvas");
define("MAILAN_58", "Problema su prisegamais failais");
define("MAILAN_59", "Mailing Progress");
define("MAILAN_60", "Siuntimas...");
define("MAILAN_61", "Nėra jokių laiškų, kurie turi būti siunčiami.");
define("MAILAN_62", "Laiškas išsiųstas:");
define("MAILAN_63", "Laiško išsiuntimo klaida:");
define("MAILAN_64", "Bendras laikas praėjo:");
define("MAILAN_65", "sekundės");
define("MAILAN_66", "Atšaukimas sėkmingas");
define("MAILAN_67", "naudoti 'POP prieš SMTP' autentifikavimą");
define("MAILAN_68", "Testiniai adresai");
define("MAILAN_69", "vartotojo loginas");
define("MAILAN_70", "vartotojo el.paštas");


?>