<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_users_extended.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("EXTLAN_1", "Pavadinimas");
define("EXTLAN_2", "Peržiūra");
define("EXTLAN_3", "Reikšmės");
define("EXTLAN_4", "Būtinas");
define("EXTLAN_5", "Pritaikytas grupei");
define("EXTLAN_6", "Gali skaityti");
define("EXTLAN_7", "Gali rašyti");
define("EXTLAN_8", "Veiksmai");
define("EXTLAN_9", "Papildomi informacijos apie narį laukeliai");
define("EXTLAN_10", "Laukelio pavadinimas");
define("EXTLAN_11", "Unikalus laukelio, sukurto duomenų bazėje pavadinimas.");
define("EXTLAN_12", "Laukelio tekstas");
define("EXTLAN_13", "Laukelio pavadinimas, kuris matomas svetainės puslapiuose");
define("EXTLAN_14", "Laukelio tipas");
define("EXTLAN_15", "Tekstinio lauko html parametrai");
define("EXTLAN_16", "Numatytoji reikšmė");
define("EXTLAN_17", "įrašykite kiekvieną įmanomą reikšmę į atskirą eilutę <br /> Pasirinkus 'Duomenų bazės lentelės laukas' skaitykite info dešinėje.");
define("EXTLAN_18", "Būtinas");
define("EXTLAN_19", "Nariai būtinai turės užpildyti laukelį, kai mėgins atnaujiti savo anketą.");
define("EXTLAN_20", "Nustato, kuriai narių grupei skirta.");
define("EXTLAN_21", "Nustato, kas galės redaguoti šių laukelių reikšmes savo anketoje.");
define("EXTLAN_22", "Nustato, kas galės matyti šių laukelių reikšmes nario anketoje <br />Dėmesio: Pasirinkus 'Tik skaityti' reikšmė bus matoma tik administratoriui ir konkrečiam nariui.");
define("EXTLAN_23", "Sukurti papildomą laukelį");
define("EXTLAN_24", "Atnaujinti papildomą laukelį");
define("EXTLAN_25", "žemyn");
define("EXTLAN_26", "aukštyn");
define("EXTLAN_27", "Patvirtinti ištrynimą");
define("EXTLAN_28", "Nėra sukurtų papildomų laukelių");
define("EXTLAN_29", "Papildomas informacijos laukelis apie narį išsaugotas.");
define("EXTLAN_30", "Papildomas informacijos laukelis apie narį ištrintas");
define("EXTLAN_33", "Atšaukti");
define("EXTLAN_34", "Papildomi laukeliai");
define("EXTLAN_35", "Laukelių grupės");
define("EXTLAN_36", "Nepriskirta grupei");
define("EXTLAN_37", "Nėra įrašytų laukelių grupių");
define("EXTLAN_38", "Grupės pavadinimas");
define("EXTLAN_39", "Įrašyti naują grupę");
define("EXTLAN_40", "Papildomų laukelių grupė įrašyta");
define("EXTLAN_41", "Papildomų laukelių grupė ištrinta");
define("EXTLAN_42", "Atnaujinti grupę");
define("EXTLAN_43", "Papildomų laukelių grupė atnaujinta");
define("EXTLAN_44", "Grupė");
define("EXTLAN_45", "Sukurti naują laukelį");
define("EXTLAN_46", "Info");
define("EXTLAN_47", "Įrašyti naują parametrą");
define("EXTLAN_48", "Įrašyti naują reikšmę");
define("EXTLAN_49", "Leisti paslėpti laukelį");
define("EXTLAN_50", "Pažymėjus, bus leista nariui paslėpti šį laukelį nuo svetainės lankytojų ir kitų narių");
define("EXTLAN_51", "Bet koks validusd w3c parametras gali būti įrašytas<br />pvz., <i><b>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "Laukelio užpildymo taisyklės");
define("EXTLAN_53", "Įveskite taisykles (reguliarusis reiškinys), pagal kurias bus tikrinama į laukelį įvesta reikšmė <br />**reguliarojo reiškinio skyrikliai būtini**");
define("EXTLAN_54", "Pranešimas apie klaidą");
define("EXTLAN_55", "Įrašykite pranešimą apie klaidą, jei į laukelį įvesta reikšmė neatitiks aukščiau įrašytų taisyklių.");
define("EXTLAN_56", "Paruošti papildomi laukeliai");
define("EXTLAN_57", "Aktyvuoti papildomi informacijos laukeliai");
define("EXTLAN_58", "Neaktyvuoti papildomi informacijos laukeliai");
define("EXTLAN_59", "Aktyvuoti");
define("EXTLAN_60", "Panaikinti");
define("EXTLAN_61", "Nėra");
define("EXTLAN_62", "Lentelė");
define("EXTLAN_63", "Lauklelio Id");
define("EXTLAN_64", "Rodoma reikšmė");
define("EXTLAN_65", "Ne - nebus rodomas registracijos puslapyje");
define("EXTLAN_66", "Taip - bus rodomas registracijos puslapyje");
define("EXTLAN_67", "Ne - bus rodomas registracijos puslapyje");
define("EXTLAN_68", "Laukas:");
define("EXTLAN_69", "aktyvuotas");
define("EXTLAN_70", "KLAIDA!! Laukas:");
define("EXTLAN_71", "neaktyvuota!");
define("EXTLAN_72", "buvo deaktyvuota");
define("EXTLAN_73", "nebuvo išjungta");
define("EXTLAN_74", "lauko pavadinimas yra rezervuotas, ir negali būti naudojamas");
define("EXTLAN_75", "Laukų įvedimo klaida į duomenų bazę");
define("EXTLAN_76", "Klaidinga charakteristika ar lauko vardas - only A-Z, a-z, 0-9, '_' allowed.");
define("EXTLAN_77", "Kategorija neištrinta-privalote ištrinti lauką iš kategorijos");
define("EXTLAN_78", "Negalima rasti failo --FILE--reikia sukurti duomenų lentelę");
define("EXTLAN_79", "Tikrinimo klaida-nutraukta.");
define("EXTLAN_HELP_1", "<b><i>Parametrai:</i></b><br />size - laukelio dydis<br />maxlength - maksimalus simbolių skaičius<br /><br />class - laukelio stilių lentelės klasė (class)<br />style - papildomi laukelio stilių lentelės parametrai<br /><br /><b>reguliarusis reiškinys</b> - teksto eilutė, apibrėžianti tam tikrą eilučių aibę.<br />Paprasčiausiu atveju – teksto eilutė, pavyzdžiui, 'abc'. Toks reguliarusis reiškinys apibrėžia tik vieną eilutę – pačią save. Didesnei aibei generuoti vartojami pakaitos simboliai. Formuojant eilučių aibę, jie pakeičiami įvairiais ženklais arba jų sekomis ir taip gaunama daug eilučių. Vietoj klaustuko ? galima įstatyti bet kurį kitą ženklą. Pavyzdžiui, reguliarusis reiškinys 'ab?' apibrėžia eilutes: 'aba', 'abb', 'abc, ... 'ab0' Vietoj žvaigždutės* galima įstatyti bet kurią eilutę (ir tuščią). Pavyzdžiui, reguliarusis reiškinys 'ab*' apibrėžia eilutes: 'ab', 'aba', 'ab ilgesnė eilutė', ...<br />Kai reikia į eilutę įdėti patį pakaitos simbolį kaip ženklą, tai prieš jį prirašomas šiam tikslui skirtas pakaitos simbolis, pavyzdžiui,  paverčiantis jį normaliu eilutės ženklu.<br />Reguliarieji reiškiniai dažniausiai vartojamas kaip paieškos reiškinys užklausai aprašyti.<br /><br />regexfail - validation fail text");
define("EXTLAN_HELP_2", "<b>Žymimoji akutė</b> - Mažas skritulėlis, turintis dvi būsenas: pažymėtas arba nepažymėtas, ir esantis tokių akučių grupėje, iš kurių tik viena gali būti pažymėta.<br /><br />Pažymėtos akutės viduje būna taškas. Pažymima spustelint nepažymėtą akutę pele. Tada toje pat grupėje esančios kitos pažymėtos akutės žymėjimas panaikinamas (pažymėta gali būti tik viena akutė). Kad aiškiau matytųsi tai pačiai grupei priklausančios akutės, jos paprastai būna apvestos rėmeliu – sudėtos į vieną langelį.<br />Daugelyje programų galima perkelti žymėjimą iš vienos akutės į kitą tos pačios grupės akutę spaudant klaviatūroje esančius rodyklių klavišus.");
define("EXTLAN_HELP_3", "<b>Išskleidžiamasis meniu</b> - Sąrašas, kuriame normaliai matomas tik vienas elementas.<br /><br />Norint pamatyti kitus sąrašo elementus, reikia jį išskleisti, dažniausiai spustelint slinkties mygtuką.");
define("EXTLAN_HELP_4", "<b><i>Values:</i></b><br />There should be three values given ALWAYS:<br /><ol><li>dbtable</li><li>field containing id</li><li>field containing value</li></ol><br />");
define("EXTLAN_HELP_5", "Teksto laukas");
define("EXTLAN_HELP_6", "<b>Sveikasis skaičius</b> - Teigiamas arba neigiamas skaičius, neturintis trupmeninės dalies.<br /><br />Operacijos su sveikaisiais skaičiais atliekamos absoliučiai tiksliai. Dėl to sveikieji skaičiai vartojami įvairiems numeravimams, indeksams. Tačiau kompiuteryje yra riboti jų rėžiai. Šiuolaikiniuose kompiuteriuose sveikajam skaičiui dažniausiai skiriami 4 baitai, todėl galimi skaičiai nuo –2147483647 iki 2147483648. Kai gautas skaičius (skaičiavimų rezultatas) nepatenka į šiuos rėžius, įvyksta klaida – perpildymas.");
define("EXTLAN_HELP_7", "Datos laukas");
define("EXTLAN_HELP_8", "Leidžia vartotojui pasirinkti iš įdiegtų kalbų");


?>