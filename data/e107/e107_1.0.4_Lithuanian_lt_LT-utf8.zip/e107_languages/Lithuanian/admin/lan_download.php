<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_download.php $
|     $Revision: 12132 $
|     $Id: lan_download.php 12132 2011-04-12 21:25:31Z e107steved $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("DOWLAN_1", "Atsisiuntimai pridėti į duomenų bazę.");
define("DOWLAN_2", "Atsisiuntimai atnaujinti duomenų bazėje.");
define("DOWLAN_3", "Atsisiuntimai ištrinti.");
define("DOWLAN_4", "Prašome pažymėti langelį, kad patvirtinti ištrintą atsisiuntimą");
define("DOWLAN_5", "Nėra atsisiųstų kategorijų ir jūs negalite patekti.");
define("DOWLAN_6", "Negaliojantys pasrsisiuntimai");
define("DOWLAN_7", "Esami parsisiuntimai");
define("DOWLAN_11", "Kategorijos");
define("DOWLAN_12", "Vardas");
define("DOWLAN_13", "Failas");
define("DOWLAN_14", "Įvesti adresus jei atsisiunčiama kaip išorinis failas");
define("DOWLAN_15", "Autorius");
define("DOWLAN_16", "Autoriaus Email");
define("DOWLAN_17", "Autoriaus Tinklalapis");
define("DOWLAN_18", "Aprašymai");
define("DOWLAN_19", "Pagrindinis atvaizdas");
define("DOWLAN_20", "Minetiūrinis atvaizdas");
define("DOWLAN_21", "Statusas");
define("DOWLAN_24", "Atnaujinti atsisiuntimus");
define("DOWLAN_25", "Patvirtinti atsisiuntimus");
define("DOWLAN_27", "Atsisiųsti");
define("DOWLAN_28", "Nė vienas");
define("DOWLAN_29", "Atsisiųsti pradinį puslapį");
define("DOWLAN_30", "Sukurti atsisiuntimą");
define("DOWLAN_31", "Kategorijos");
define("DOWLAN_32", "Atsisiuntimų opcijos");
define("DOWLAN_33", "Ar norite trinti šį atsisiuntimą?");
define("DOWLAN_34", "Ar norite trinti šią atsisiuntimų kategoriją?");
define("DOWLAN_36", "ištrinta");
define("DOWLAN_37", "Tėvų");
define("DOWLAN_38", "Kategorijos neegzistuoja");
define("DOWLAN_39", "Atsisiųsti kategorijas");
define("DOWLAN_40", "Nėra - pagrindinė patronuojanti");
define("DOWLAN_41", "Piktograma");
define("DOWLAN_42", "Žiūrėti iliustracijas");
define("DOWLAN_43", "matoma");
define("DOWLAN_44", "Pažymint bus matoma tik vartotojo kategorijos klasėje");
define("DOWLAN_45", "Sukurti kategoriją");
define("DOWLAN_46", "Atnaujinti kategoriją");
define("DOWLAN_47", "Kategorija sukurta");
define("DOWLAN_48", "Kategorija atnaujinta");
define("DOWLAN_49", "Atsisiųsti kategoriją");
define("DOWLAN_51", "Ieškoti/Atnaujinti atsisiuntimus");
define("DOWLAN_52", "Failai");
define("DOWLAN_53", "subkategorija");
define("DOWLAN_54", "Atsisiųsti opcijas");
define("DOWLAN_55", "Parsisiuntimų skaičių rodyti viename puslapyje");
define("DOWLAN_56", "Rūšiuoti kaip");
define("DOWLAN_59", "Failo vardas");
define("DOWLAN_62", "Didėjančia tvarka");
define("DOWLAN_63", "Mažėjančia tvarka");
define("DOWLAN_64", "Atnaujinti opcijas");
define("DOWLAN_65", "Opcijos atnaujintos");
define("DOWLAN_66", "Įvesti failo dydį");
define("DOWLAN_67", "ID");
define("DOWLAN_68", "Failo klaida!");
define("DOWLAN_69", "Parsiusintimai tvarkomi naudojant PHP");
define("DOWLAN_70", "Tikrinimas į visus atsisiųstus prašymus per PHP.");
define("DOWLAN_100", "Aktyvuoti parsiuntimo susitarimus");
define("DOWLAN_101", "Susitarimo tekstas");
define("DOWLAN_102", "Leisti komentarus?");
define("DOWLAN_103", "Išmesti iš įkrautų");
define("DOWLAN_104", "buvo ištrinti iš viešų įkrovų");
define("DOWLAN_105", "Grįžti į viešas įkrovas");
define("DOWLAN_106", "Galima atsisiųsti");
define("DOWLAN_107", "Limituotas atsisiuntimų skaičius");
define("DOWLAN_108", "Apriboti atsisiuntimų pralaidumą");
define("DOWLAN_109", "kiekvieną");
define("DOWLAN_110", "dienos");
define("DOWLAN_111", "kb");
define("DOWLAN_112", "Limitai");
define("DOWLAN_113", "Vartotojo grupės");
define("DOWLAN_114", "Įvesti naują limitą");
define("DOWLAN_115", "Atnaujinti limitus");
define("DOWLAN_116", "Vartotojo grupės limitai visada egzistuoja");
define("DOWLAN_117", "Limitas sėkmingai pridėtas");
define("DOWLAN_118", "Limitas nepridėtas - nežinoma klaida");
define("DOWLAN_119", "Limitas sėkmingai pašalintas");
define("DOWLAN_120", "Limitas nepašalintas - nežinoma klaida");
define("DOWLAN_121", "Limitas sėkmingai atnaujintas");
define("DOWLAN_122", "Neaktyvus");
define("DOWLAN_123", "Aktyvus - Failas kaip subjektas atsisiųsti limitus");
define("DOWLAN_124", "Aktyvus - Failas nėra subjektas atsisiųsti limitus");
define("DOWLAN_125", "Parsisiųsti ribotus aktyvus");
define("DOWLAN_126", "Aktyvavimo statusas atnaujintas");
define("DOWLAN_127", "Tik įveskite failo dydį, jei atsisiunčiate išorinį failą");
define("DOWLAN_128", "Atvaizdai");
define("DOWLAN_129", "palikite tuščią jei nenorite naudoti atvaizdų");
define("DOWLAN_130", "Pridėti kitus atvaizdus");
define("DOWLAN_131", "Pažymėti vietinį failą");
define("DOWLAN_132", "Prašome įvesti atvaizdą, adresui atsisiųsti");
define("DOWLAN_133", "Atvaizdas atnaujintas duomenų bazėje");
define("DOWLAN_134", "Atvaizdas išsaugotas duomenų bazėje");
define("DOWLAN_135", "Atvaizdas ištrintas");
define("DOWLAN_136", "iliustracijae");
define("DOWLAN_137", "Ar tikrai norite ištrinti šą atvaizdą?");
define("DOWLAN_138", "Egzistuojantis atvaizdas");
define("DOWLAN_139", "Adresai");
define("DOWLAN_140", "Įkelti lokalią iliustraciją į ".e_FILE." atsiunčiama iliustracija parodyti čia, arba įvesti pilną adresą jei iliustracija nutolusi");
define("DOWLAN_141", "Vieta");
define("DOWLAN_142", "Atnaujinti atvaizdą");
define("DOWLAN_143", "Sukurti atvaizdą");
define("DOWLAN_144", "Atvaizdas nerastas atvaizdų sekcijoje.");
define("DOWLAN_145", "Parsisiųsti matomus į");
define("DOWLAN_146", "Pasirenkamas siuntimas-atsisakymas arba URL");
define("DOWLAN_147", "Piktograma tuščioje kategorijoje");
define("DOWLAN_148", "Pažymėti atnaujintą datąt šio laiku");
define("DOWLAN_149", "arba paspauskite čia išorinio failo naudojimui");
define("DOWLAN_150", "Elektroninio pašto administratorius, pranešė apie brokuotusd parsiuntimus");
define("DOWLAN_151", "Atsisiųsti ataskaitos prieinamos");
define("DOWLAN_152", "Nepavyko perkelti failo");
define("DOWLAN_153", "Perkelti failą į atsisiuntimų aplanką ");
define("DOWLAN_154", "jei naudojant veidrodžius, pasirinkti, kaip jie bus rodomi");
define("DOWLAN_155", "Veidrodžio rodymo tipas:");
define("DOWLAN_156", "veidrodinis sąrašas, leidžia vartotojui pasirinkti veidrodį");
define("DOWLAN_157", "naudoti atsitiktinį veidrodį - joks vartotojo pasirinkimas");
define("DOWLAN_158", "Rodyti sub-sub-kategorijas pagrindiniame atsisiuntimo puslapyje");
define("DOWLAN_159", "Įtraukti sub-sub-kategorijų skaičiavimą į subkategorijos skaičiavimą");
define("DOWLAN_160", "Užkirsti kelią parsisiuntimui vienu metu  atskiriems vartotojams");
define("DOWLAN_161", "Naudoti Įvadinį puslapį atliekant rinkmenų atsisiuntimus");
define("DOWLAN_162", "Prašymai");
define("DOWLAN_163", "Vartotojas");
define("DOWLAN_164", "IP");
define("DOWLAN_165", "Data / laikas");
define("DOWLAN_166", "Grįžti į atsisiuntimų priekinį  puslapį");
define("DOWLAN_199", "Saugokitės: kiekvieno atsisiuntimo statistika gali neatspindėti bendros istorijos!");
define("DOWLAN_200", "Skaičius");
define("DOWLAN_201", "Prisijungti");
define("DOWLAN_202", "Prisijungimo duomenys");


?>