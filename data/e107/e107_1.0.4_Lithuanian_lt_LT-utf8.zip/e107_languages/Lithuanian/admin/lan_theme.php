<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_theme.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("TPVLAN_1", "Jūs galite peržiūrėti visas temas, esančias serveryje. Šiuo metu jūs matote temą, pavadintą <b>'".PREVIEWTHEMENAME."'</b>. Dabar jūs matote pirmąjį šios temos puslapį.<br />Norėdami naudoti šią temą kaip pagrindinę svetainės temą, turite <a href='".e_ADMIN."theme.php'>sugrįžti atgal į temų tvarkyklę</a> ir pasirinkti 'Svetainės tema'.<br /><a href='".e_ADMIN."theme.php'>Temų tvarkyklėje</a> galite peržiūrėti ir kitas temas");
define("TPVLAN_2", "Temų peržiūra");
define("TPVLAN_3", "Main site theme set to");
define("TPVLAN_4", "Autorius");
define("TPVLAN_5", "Internetinis adresas");
define("TPVLAN_6", "Išleidimo data");
define("TPVLAN_7", "Informacija");
define("TPVLAN_8", "Parinktys");
define("TPVLAN_9", "Peržiūrėti temą");
define("TPVLAN_10", "Svetainės tema");
define("TPVLAN_11", "Versija");
define("TPVLAN_12", "Peržiūra negalima");
define("TPVLAN_13", "Nusiųsti temą į serverį (.zip arba .tar.gz formatu)");
define("TPVLAN_14", "Nusiųsti temą");
define("TPVLAN_15", "Byla negali būti nusiųsta, nes sistema negali bylų įrašyti į katalogą ".e_THEME." Pakeiskite katalogo atributus (CHMOD 777).");
define("TPVLAN_16", "Administratoriaus pranešimas");
define("TPVLAN_17", "Byla nėra .zip ar .tar archyvas.");
define("TPVLAN_18", "Klaida: negalima išskleisti archyvo");
define("TPVLAN_19", "Jūsų tema nusiųsta ir išskleista. Peržiūrėkite temų sąrašą ir pamatysite naują temą.");
define("TPVLAN_20", "Automatiškas archyvo su temos bylomis atsiuntimas ir išskleidimas negalimas, nes į temų katalogą sistema negali įrašyti bylų. Pakeiskite temų katalogo atributus (CHMOD 777).");
define("TPVLAN_21", "Tai pasirinkta svetainės tema");
define("TPVLAN_22", "ši tema turi keletą stilių lentelių");
define("TPVLAN_23", "numatyta stilių lentelė");
define("TPVLAN_24", "informacijos nėra");
define("TPVLAN_25", "To choose which stylesheet to use, please go to <a href='".e_ADMIN."prefs.php'>preferences</a> and click on 'Theme'.");
define("TPVLAN_26", "Temų tvarkyklė");
define("TPVLAN_27", "Prašome pasirinkti stilių lentelę");
define("TPVLAN_28", "Taip");
define("TPVLAN_29", "Ne");
define("TPVLAN_30", "Iš anksto lankytojui nusiųsti temos iliustracijas:");
define("TPVLAN_31", "This is the currently selected admin theme");
define("TPVLAN_32", "Administravimo srities tema");
define("TPVLAN_33", "Dabartinė svetainės tema");
define("TPVLAN_34", "Dabartinė administravimo srities tema");
define("TPVLAN_35", "Išsaugoti nuostatas");
define("TPVLAN_36", "Admin Message");
define("TPVLAN_37", "Temos nuostatos išsaugotos");
define("TPVLAN_38", "Įdiegti temą");
define("TPVLAN_39", "Įdiegtos temos");
define("TPVLAN_40", "Admin theme set to");
define("TPVLAN_41", "Prašome pasirinkti administravimo srities vaizdavimo būdą");
define("TPVLAN_42", "Išsaugoti nuostatas");
define("TPVLAN_43", "Administravimo srities temos nuostatos išsaugotos");
define("TPVLAN_46", "PCLZIP išarchyvavimo klaida:");
define("TPVLAN_47", "PCLTAR išarchyvavimo klaida:");
define("TPVLAN_48", "kodas:");


?>