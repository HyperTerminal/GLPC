<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_check_user.php $
|     $Revision: 11678 $
|     $Id: lan_check_user.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "Patikrinkite vartotojo duomenų bazę");
define("LAN_CKUSER_02", "Tai bus patikrinta dėl įvairių galimų problemų  vartotojo duomenų bazėje");
define("LAN_CKUSER_03", "Jei turite daug vartotojų, tai gali užtrukti šiek tiek laiko");
define("LAN_CKUSER_04", "Pradėti");
define("LAN_CKUSER_05", "pažymėkite pasikartojančius prisijungimo vardus");
define("LAN_CKUSER_06", "Pasirinkite funkcijas atlikimui");
define("LAN_CKUSER_07", "Besidubliuojantys vartotojo vardai rasti");
define("LAN_CKUSER_08", "Nerasta pasikartojančių vardų");
define("LAN_CKUSER_09", "vartotojo vardas");
define("LAN_CKUSER_10", "Vartotojo ID");
define("LAN_CKUSER_11", "Atvaizduojamas vardas");
define("LAN_CKUSER_12", "Patikrinkite pasikartojančius elektroninio pašto adresus");
define("LAN_CKUSER_13", "pasikartojančių elektroninio pašto adresų nerasta");
define("LAN_CKUSER_14", "El.pašto adresai");
define("LAN_CKUSER_15", "Pasikartojimų nerasta");
define("LAN_CKUSER_16", "eškoti įrašus, kur vartotojo vardas yra kažkas\ i's prisijungimo vardas");
define("LAN_CKUSER_17", "Konfliktuojantis vartotojo vardas ir prisijungimo vardas");
define("LAN_CKUSER_18", "Vartotojas A");
define("LAN_CKUSER_19", "Vartotojas B");
define("LAN_CKUSER_20", "");


?>