<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Siųsti pranešimą el.paštu");
define("UCSLAN_2", "Atnaujinti privelegijas");
define("UCSLAN_3", "Gerb.");
define("UCSLAN_4", "Jūsų privelegijos atnaujintos");
define("UCSLAN_5", "dabar jūs turite prieigą prie šios srities (-ių)");
define("UCSLAN_6", "Nustatyti vartotojo kalsę");
define("UCSLAN_7", "Nustatyti klases");
define("UCSLAN_8", "Informuoti vartotoją");
define("UCSLAN_9", "Klasės atnaujintos");
define("UCSLAN_10", "Linkėjimai,");
define("UCSLAN_12", "Tik narių privelegijos");


?>