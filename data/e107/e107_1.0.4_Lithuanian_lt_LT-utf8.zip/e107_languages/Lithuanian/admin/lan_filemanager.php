<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_filemanager.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "Įkelta");
define("FMLAN_2", "į");
define("FMLAN_3", "katalogą");
define("FMLAN_4", "Atsiųsta byla viršija dydžio limitą, nustatytą upload_max_filesize nuostatoje php.ini byloje.");
define("FMLAN_10", "Klaida");
define("FMLAN_12", "byla");
define("FMLAN_13", "bylos");
define("FMLAN_14", "katalogas");
define("FMLAN_15", "katalogai");
define("FMLAN_16", "Šakninis katalogas");
define("FMLAN_17", "Pavadinimas");
define("FMLAN_18", "Dydis");
define("FMLAN_19", "Paskutinis redagavimas");
define("FMLAN_21", "Siųsti bylą į šį katalogą");
define("FMLAN_22", "Siųsti");
define("FMLAN_26", "ištrinta");
define("FMLAN_27", "sėkmingai");
define("FMLAN_28", "Nepavyko ištrinti");
define("FMLAN_29", "Kelias");
define("FMLAN_30", "Aukštyn");
define("FMLAN_31", "katalogą");
define("FMLAN_32", "Pasirinkite katalogą");
define("FMLAN_33", "Pasirinkti");
define("FMLAN_34", "Katalogo pasirinkimas");
define("FMLAN_35", "Bylų katalogas");
define("FMLAN_36", "Individualių meniu katalogas");
define("FMLAN_37", "Individualių puslapių katalogas");
define("FMLAN_38", "Byla sėkmingai perkelta į");
define("FMLAN_39", "Nepavyksta perkelti bylos į");
define("FMLAN_40", "Naujienų iliustracijų katalogas");
define("FMLAN_43", "Ištrinti pasirinktas bylas");
define("FMLAN_46", "Prašome patvirtinti norą IŠTRINTI pasirinktas bylas.");
define("FMLAN_47", "Atsiųstos bylos");
define("FMLAN_48", "Perkelti pasirinktas bylas į");
define("FMLAN_49", "Prašome patvirtinti bylų perkėlimą.");
define("FMLAN_50", "Perkelti");
define("FMLAN_51", "Nenustatyta klaida");


?>