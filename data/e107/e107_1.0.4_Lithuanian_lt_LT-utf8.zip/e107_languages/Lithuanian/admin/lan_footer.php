<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_footer.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/01/11 18:51:57 $
|     $Author: vipuro $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Svetainė");
define("FOOTLAN_2", "Svetainės administratorius");
define("FOOTLAN_3", "versija");
define("FOOTLAN_4", "leidimas");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "sukūrė");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Įdiegimo data");
define("FOOTLAN_9", "Serveris");
define("FOOTLAN_10", "host'as");
define("FOOTLAN_11", "PHP versija");
define("FOOTLAN_12", "mySQL versija");
define("FOOTLAN_13", "Informacija");
define("FOOTLAN_14", "Parodyti dokumentus");
define("FOOTLAN_15", "Dokumentacija");
define("FOOTLAN_16", "Duomenų bazė");
define("FOOTLAN_17", "Koduotė");
define("FOOTLAN_18", "Temos saitas");
define("FOOTLAN_19", "Dabartinis serverio laikas");
define("FOOTLAN_20", "Apsaugos lygis");


?>