<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_userclass2.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Iš narių grupės pašalinti visi nariai.");
define("UCSLAN_2", "Narių grupė atnaujinta.");
define("UCSLAN_3", "Narių grupė ištrinta.");
define("UCSLAN_4", "Pažymėkite, grupės ištrynimo patvirtinimui");
define("UCSLAN_5", "Narių grupė atnaujinta.");
define("UCSLAN_6", "Informacija apie narių grupę išsaugota duomenų bazėje.");
define("UCSLAN_7", "Dar nesukurta narių grupių.");
define("UCSLAN_8", "Narių grupių sąrašas");
define("UCSLAN_11", "pažymėti patvirtinimui");
define("UCSLAN_12", "Grupės pavadinimas");
define("UCSLAN_13", "Trumpas grupės aprašymas");
define("UCSLAN_14", "Atnaujinti grupę");
define("UCSLAN_15", "sukurti naują narių grupę");
define("UCSLAN_16", "Įrašyti narius į grupę");
define("UCSLAN_17", "Pašalinti");
define("UCSLAN_18", "Išvalyti narių grupę");
define("UCSLAN_19", "Įrašyti narius į grupę");
define("UCSLAN_20", "grupė");
define("UCSLAN_21", "Narių grupių nuostatos");
define("UCSLAN_22", "Nariai - pasirinkite perkėlimui ...");
define("UCSLAN_23", "Grupės nariai ...");
define("UCSLAN_24", "Kas gali tvarkyti grupę");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Vartotojo vardas");
define("UCSLAN_27", "Grįžti");


?>