﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$caption = "Use Class Help";
$text = "Čia galite kurti, redaguoti ar ištrinti klases.<br />
Tai naudina, kai norite uždrausti lankytojams lankytis tam tikrose tinklapio puslapiuose. Pavyzdžiui, galite sukurti klasę TEST, 
po to sukurti forumą, kurį tik šios klasės nariai galės pasiekti.";
$ns -> tablerender($caption, $text);
?>