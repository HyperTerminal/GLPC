﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/wmessage.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Šis puslapis leidia sukurti žinutes, kurios pasirodo pagrindinio puslapio viršuje tol,kl jos yra aktyvios.
Galite sukurti skirtingas žinutes, svečiams, registruotiems ir prisijungusiems nariamasir administratoriams.";
$ns -> tablerender("WMessage Help", $text);
?>
