﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/users_extended.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/07 22:33:28 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = " Extended user fields allow you to add additional types of data a user is able to specify as part of their profile.";
$ns -> tablerender(" Extended User Fields Help", $text);
?>