﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/ugflag.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Jei atnaujinate savo e107 arba tiesiog jums reikia padaryti savo tinklapį laikinai nepasiekiamą, pažymėkite
 maintainance laukelį ir lankytojai bus nukreipti į puslapį su paaiškinimais, kad puslapis perdaromas. 
 Pabeigą pakeitimus nuimkitę žymą -sugražinsite viską į pradinę būseną.";

$ns -> tablerender("Maintainance", $text);
?>