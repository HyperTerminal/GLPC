﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/emoticon.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Jūs galite sukurti jausmukų rinkinius, kuriuos lengvai įdiegsite į e107. Eikite ir <a href='".e_FILE."emote_create/emotecreate.php'>kurkite</a> sekdami instrukcijas.";

$ns -> tablerender("Emoticon Help", $text);
?>