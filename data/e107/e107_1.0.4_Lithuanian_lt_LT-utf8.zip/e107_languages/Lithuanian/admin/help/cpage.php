﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/cpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Čia jūs galite sukurti savo Specializuotą meniu ar puslapį (custom menus/custom pages) su kokiu tik norite savo turiniu.<br /><br />
Plačiau skaitykite <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a>.";

$ns -> tablerender(CUSLAN_18, $text);
?>