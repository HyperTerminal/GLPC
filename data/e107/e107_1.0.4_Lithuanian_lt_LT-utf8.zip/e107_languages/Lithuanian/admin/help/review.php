﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/review.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Apžvalgos panašios į straipsnus, tik jos pateikiamos savo atskirame meniu.<br />
 Norėdami turėti apžvalgą iš daugelio puslapių, kiekvieną puslapį atskirkite tekstu [newpage], pvz., <br /><code>Testas1 [newpage] 
 Testas2</code><br />. Taip bus sukurti du puslapiai su tekstu 'Testas1' I-me puslapyje bei 'Testas2' II-me puslapyje.";
$ns -> tablerender("Review Help", $text);
?>