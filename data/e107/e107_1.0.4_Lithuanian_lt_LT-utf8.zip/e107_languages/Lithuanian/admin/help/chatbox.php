﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/chatbox.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Čia keičiamos chatbox nuostatos.<br />Jei Pakeisti nuorod1 yra pažymėta, bet kokios įvestos nuorodos bus pakeistos tekstu, kurį įrašėte teksto laukelyje, tai leidžia įšvengti ilgų nuorodų rodymo problemų. Wordwrap will auto wrap text that is longer than the length specified here.";

$ns -> tablerender("Chatbox", $text);
?>