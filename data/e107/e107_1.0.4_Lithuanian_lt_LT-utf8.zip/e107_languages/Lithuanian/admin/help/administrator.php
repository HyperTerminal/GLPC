﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/administrator.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:15:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$caption = "Pagalba tinklapio administratoriui";
$text = "Šiame puslapyje galima įrašyti naują arba ištrinti esamą tinklapio administratorių. Administratorius turės tik tas savybes, kurios bus pažymėtos varnele..";
$ns -> tablerender($caption, $text);
?>