﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/content.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Pasinaudoję šia galimybe, jūs galite įdėti normalų puslapį į savo tinklalapį. Nuoroda į šį puslapį bus įdėta į pagrindinį meniu. Pavyzdžiui, jei sukūrėte naują puslapį su Nuorodos pavadinimu 'Testas', tai nuuoroda šiuo pavadinimu atsiras nuorodų lauke po to, kai išsaugosite naująjį puslapį.<br />
Jei norite, kad puslapis turėtų antraštę, įašykite ją Page Heading laukelyje.";
$ns -> tablerender("Content Help", $text);
?>