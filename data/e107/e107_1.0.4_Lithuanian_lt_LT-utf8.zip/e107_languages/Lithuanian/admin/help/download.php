﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/download.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Prašome savo bylas siųsti į ".e_FILE."downloads direktoriją, vaizdinius - ".e_FILE."downloadimages direktoriją ir thumbnail vaizdinius - į ".e_FILE."downloadthumbs direktoriją.
<br /><br />
Norėdami sukurti siuntinį, pirmiausiai sukurkite parent, tada sukurkite kategoriją šiame parent. Tada Jūs jau galėsite aktyvuoti siuntinius parsisiuntimui.";
$ns -> tablerender("Download Help", $text);
?>