﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/search.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Jei tai palaiko jūsų MySql serverio versija, galite panaudoti šį MySql rūšiavimo metodą, kuris yra greitesnis nei PHP rūšivimas
ir turi boolean paieškos funkcionalumą.<br /><br />

<b>Chars</b> Teksto ženklų kiekis, kuris bus parodytas paieškos rezultatų išklotinėje.<br /><br />
<b>Results</b> Pateikiamų paieškos rezultatu skaičius puslapyje.";
$ns -> tablerender("Search Help", $text);
?>