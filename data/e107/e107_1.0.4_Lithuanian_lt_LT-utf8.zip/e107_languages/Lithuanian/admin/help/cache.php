﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
$caption = "Podėlis";
$text = "Įjungus podėlį, labai pagreitinsite svetainės įkrovimą ir sumažinsite užklausų į sql duomenų bazę skaičių.<br /><br /><b><font style='color: red;'>Dėmesio!</font> Jei jūs kuriate naują temą, išjunkite podėlį, kitaip nematysite temos pasikeitimų.</b>";
$ns -> tablerender($caption, $text);
?>