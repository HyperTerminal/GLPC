﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/mailout.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/07 22:33:28 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Use this page to configure your mail settings for site-wide mailing functions. The mail out form also allows you to send out a mail-shot to all your users.";
$ns -> tablerender("Mail Help", $text);
?>