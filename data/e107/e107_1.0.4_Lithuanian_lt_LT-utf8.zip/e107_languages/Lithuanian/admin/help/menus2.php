﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/menus2.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$caption = "Menu Help";
$text .= "Čia galite nuspręsti, kokia tvarka bus išdėstytos meniu. Panaudokite rodykles, norėdami perkelti meniuaukštyn ar žemyn, kol rasite joms geriausią vietą.<br />
Meniu, kurios yra puslapio viduryje, yra neaktyvios. Būtent jas ir galite perkelti ten, kur manote esant reiklainga.
";

$ns -> tablerender("Menus Help", $text);
?>