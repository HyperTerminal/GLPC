﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/filemanager.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Čia jūs galite valdyti bylas, esančias /direktorijos. Jei gaunate klaidos pranešimą apie neteisingas privilegijas, būtinai pakeiskite jas CHMOD į 777 tai direktorijai, į kurią norite nusiųsti bylas.";
$ns -> tablerender("File Manager Help", $text);
?>