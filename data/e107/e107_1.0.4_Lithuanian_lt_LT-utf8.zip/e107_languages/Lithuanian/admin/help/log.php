﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/log.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Galima aktyvuoti statistiką - bus įrašomi visi prisijungimai prie tinklapio.
Jei neturite serveryje vietos į valias, geriau pažymėkite the domain only box as referer logging,
tai įrašys tik domeinus, bet ne visą url, pvz., 'jalist.com' vietoje 'http://jalist.com/links.php' ";
$ns -> tablerender("Logging Help", $text);
?>