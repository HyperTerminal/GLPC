﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$caption = "Newspost Help";
$text = "<b>General</b><br />
Pagrindinis turinys bus rodomas pagrindiniame psulapyje, papildomas - kai tik paspausite 'Read More' nuorodą.
<br />
<br />
<b>Show title only</b>
<br />
Busrodoma tik naujienos antraštė pagrindiniame puslapyje. Iš jos nuorodą ves į visą pagrindinį tekstą.
<br /><br />
<b>Activation</b>
<br />
Jei įrašysite pradžios ir pabaigos datą, naujiena bus rodoma laikotarpyje tarp šių datų.
";
$ns -> tablerender($caption, $text);
?>