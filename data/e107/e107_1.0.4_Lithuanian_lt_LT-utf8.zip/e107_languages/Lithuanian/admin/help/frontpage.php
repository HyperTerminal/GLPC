﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/frontpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$caption = "Front Page Help";
$text = "Šiame ekrane jūs galite pasirinkti, ką rpdyti tinklaapio pradiniame puslapyje, pagal numatymą tai yra naujienos.";
$ns -> tablerender($caption, $text);
?>