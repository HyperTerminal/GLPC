﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/phpinfo.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/07 22:33:28 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = " This page displays all your servers PHP configuration settings. ";
$ns -> tablerender("PHP Info Help", $text);
?>