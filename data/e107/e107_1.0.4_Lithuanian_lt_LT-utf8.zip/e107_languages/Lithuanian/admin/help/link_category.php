﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/link_category.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Jūs galite suskirstyti nuorodas į atsiras kategorijas, tai leidžia lengviau judėti pagrindiniame Nuorodų puslapyje, o taip pat pagerina išvaizdą.<br /><br />
Nuorodos, įvestos pagrindiniame meniu, ir bus rodomas pagrindiniame maniu.";
$ns -> tablerender("Link Category Help", $text);
?>