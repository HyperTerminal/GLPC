﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/links.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Čia galima suvesti savo tinklapio nuorodas, kurios bus rodomos Pagrindiniame meni.Kitas nuorodas patariame
įašyti į Nuorodų puslapį.
<br />
";
$ns -> tablerender("Links Help", $text);
?>