﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/news_category.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Galite suskirstyti naujienas į  kategorijas, tai leis lankytojams matyti tik tos kategorijos naujienas. <br /><br />
Atsiųskite naujienų piktogramas arba į ".e_THEME."-jusutema-/images/ arba themes/shared/newsicons/.";
$ns -> tablerender("News Category Help", $text);
?>