﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/theme.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/07 22:33:28 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "The theme manager allows you to set your site's public theme and your admin areas theme.";
$ns -> tablerender("Theme Manager Help", $text);
?>