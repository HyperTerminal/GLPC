﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/poll.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Čia galite sukurti apklausas/balsavimu įrašydami antraštę ir parinktis, peržvelgti, ir, jei viskas gerai, 
pažymeti laukelį - taip apklausa bus aktyvuota.<br /><br />
Norėdami matyti Apklausų meniu, reikia šį meniu aktyvuot.";

$ns -> tablerender("Polls", $text);
?>