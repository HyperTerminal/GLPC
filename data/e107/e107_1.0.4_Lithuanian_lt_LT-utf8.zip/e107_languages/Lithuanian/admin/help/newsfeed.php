﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/newsfeed.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Jūs galite surinkti ir pateikti kitų tinklapių RSS naujienas savama tinklapyje.<br />
Įrašykite visą URL adresą (pvz., http://e107.org/news.xml). Taip pat galite įrašyti kelią iki vaizdinio, jei jums nepatina
numatytasisarba jis iš viso nėranumatytas. Taip pat galite aktyvuoti arba deaktyvuoti naujienas jei tinklais neveikia.
<br /><br />Norėdami matyti naujienų antraštes,įsitikinkite, kad headlines_menu jūsų menių pslapyje yra aktyvuota.";

$ns -> tablerender("Headlines", $text);
?>