﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/help/users.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/23 23:21:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
$text = "Šiame puslapyje galite valdyi užsiregistravusius lankytojus. Galite atnujinti jų nuostatas, suteikt administratoriaus teises
 bei nustatyti klasę.";
$ns -> tablerender("Users Help", $text);
unset($text);
?>