<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_db_verify.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Negalima perskaityti sgl duomenų bylos<br /><br />Prašome patikrinti ar <b>core_sql.php</b> byla yra kataloge <b>/admin/sql</b>.");
define("DBLAN_2", "Tikrinti viską");
define("DBLAN_4", "Lentelė");
define("DBLAN_5", "Laukelis");
define("DBLAN_6", "Būsena");
define("DBLAN_7", "Pastabos");
define("DBLAN_8", "Neatitikimas");
define("DBLAN_9", "Yra");
define("DBLAN_10", "turi būti");
define("DBLAN_11", "Trūksta laukelio");
define("DBLAN_12", "Nereikalingas laukelis!");
define("DBLAN_13", "Trūksta lentelės!");
define("DBLAN_14", "Pasirinkite lenteles vientisumo patikrinimui");
define("DBLAN_15", "Pradėti tikrinimą");
define("DBLAN_16", "SQL duomenų bazės vientisumo patikrinimas");
define("DBLAN_17", "Atgal");
define("DBLAN_18", "lentelės");
define("DBLAN_19", "Pabandyti ištaisyti");
define("DBLAN_20", "Bandoma ištaisyti lenteles");
define("DBLAN_21", "Ištaisyti pasirinktas lenteles");
define("DBLAN_22", "neperskaitomas");


?>