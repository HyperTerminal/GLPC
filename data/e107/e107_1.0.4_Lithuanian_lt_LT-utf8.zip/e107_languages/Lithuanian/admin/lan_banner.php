<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_banner.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("BNRLAN_1", "Reklaminis skydelis ištrintas.");
define("BNRLAN_2", "Prašome patvirtinti, ar tikrai norite ištrinti šį reklaminį skydelį? Po patvirtinimo sugrąžinti atgal jo nepavyks");
define("BNRLAN_5", "Reklaminio skydelio ištrynimo patvirtinimas");
define("BNRLAN_6", "Skydelio pašalinimas atšauktas.");
define("BNRLAN_7", "Reklaminių skydelių sąrašas");
define("BNRLAN_8", "ID Nr.");
define("BNRLAN_9", "Klientas");
define("BNRLAN_10", "Paspaudimai");
define("BNRLAN_11", "Paspaudimų %");
define("BNRLAN_12", "Pateikimai");
define("BNRLAN_13", "Pateikimų liko");
define("BNRLAN_15", "Nėra reklaminių skydelių.");
define("BNRLAN_16", "Neribota");
define("BNRLAN_17", "Nėra");
define("BNRLAN_21", "Pabaiga");
define("BNRLAN_22", "Atnaujinti");
define("BNRLAN_23", "Naujo reklaminio skydelio įrašymas");
define("BNRLAN_24", "Kampanija");
define("BNRLAN_25", "pasirinkite esančią reklaminę kampaniją");
define("BNRLAN_26", "įrašykite naują");
define("BNRLAN_27", "Klientas");
define("BNRLAN_28", "pasirinkite esantį klientą");
define("BNRLAN_29", "įrašykite naują");
define("BNRLAN_30", "Kliento prisijungimo vardas");
define("BNRLAN_31", "Kliento slaptažodis");
define("BNRLAN_32", "Skydelio paveiksliukas");
define("BNRLAN_33", "Skydelio nuoroda");
define("BNRLAN_34", "Pateikimų skaičius");
define("BNRLAN_35", "neribota");
define("BNRLAN_36", "Pradžia");
define("BNRLAN_37", "Pabaiga");
define("BNRLAN_38", "tuščia = neribotai");
define("BNRLAN_39", "Matomumas");
define("BNRLAN_40", "Atnaujinti skydelį");
define("BNRLAN_41", "Sukurti naują skydelį");
define("BNRLAN_42", "Reklaminių skydelių sistema");
define("BNRLAN_43", "Pasirinkite skydelio paveiksliuką");
define("BNRLAN_45", "Pradžia");
define("BNRLAN_46", "Kodas");
define("BNRLAN_58", "skydelių sąrašas");
define("BNRLAN_59", "naujas skydelis");
define("BNRLAN_60", "kampanijos");
define("BNRLAN_61", "reklaminis meniu");
define("BNRLAN_62", "Meniu");
define("BNRLAN_63", "Reklaminis skydelis sukurtas");
define("BNRLAN_64", "Reklaminis skydelis atnaujintas");
define("BANNER_MENU_L1", "Reklama");
define("BANNER_MENU_L2", "Reklaminio meniu nuostatos išsaugotos`");
define("BANNER_MENU_L3", "Antraštė");
define("BANNER_MENU_L5", "Reklaminio meniu tvarkymas");
define("BANNER_MENU_L6", "pasirinkti kampanijas, kurios bus rodomos meniu");
define("BANNER_MENU_L7", "galimos kampanijos");
define("BANNER_MENU_L8", "pasirinktos kampanijos");
define("BANNER_MENU_L9", "ištrinti pasirinkimą");
define("BANNER_MENU_L10", "Pateikimo būdas");
define("BANNER_MENU_L18", "Atnaujinti meniu nuostatas");
define("BANNER_MENU_L19", "rodyti numeris baneriųi: <br />tik tada, kai kelios kompanijos pasirinkta:");


?>