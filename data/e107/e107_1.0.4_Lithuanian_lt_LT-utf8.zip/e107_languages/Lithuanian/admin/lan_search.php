<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("SEALAN_1", "Paieškos nuostatos");
define("SEALAN_2", "Simbolių, rodomų paieškos rezultatuose santrauka:");
define("SEALAN_3", "Paieškos rezultatų išdėstymo būdas:");
define("SEALAN_6", "Komentarai");
define("SEALAN_7", "Registruoti nariai");
define("SEALAN_10", "Rodyti susijusius duomenis:");
define("SEALAN_11", "Leisti nariams pasirinkti paieškos sritis:");
define("SEALAN_12", "Laiko tarpo tarp kelių paieškų reguliavimas (iki 5 minučių):");
define("SEALAN_13", "Paiešką galima vykdyti ne dažniau kaip kas");
define("SEALAN_14", "sekundžių");
define("SEALAN_15", "Narių grupės, galinčios vykdyti paiešką");
define("SEALAN_16", "Įjungta");
define("SEALAN_17", "Išjungta");
define("SEALAN_18", "Paieškos komentaruose sritys (kai paieška komentaruose aktyvuota)");
define("SEALAN_19", "Leisti nariams ieškoti keliose srityse vienu metu:");
define("SEALAN_20", "Pagrindinės nuostatos");
define("SEALAN_21", "Paieškos sritys");
define("SEALAN_22", "Numatyta");
define("SEALAN_23", "Alternatyva:");
define("SEALAN_24", "Sritis");
define("SEALAN_25", "Narių grupė");
define("SEALAN_26", "Antraštės tekstas");
define("SEALAN_30", "Paryškinti paieškos raktažodžius rezultatų puslapiuose:");
define("SEALAN_31", "PHP limitas");
define("SEALAN_32", "resultatų (palikite tuščią, jei nelimituota)");
define("SEALAN_33", "Negalima pasirinkti MySql išdėstymo būdo, kadangi jis reikalauja bent 4.0.1 MySql versijos.");
define("SEALAN_34", "Dabar MySql versija yra");
define("SEALAN_35", "Paieškos sričių pasirinkimo būdas:");
define("SEALAN_36", "Išskleidžiamas sąrašas");
define("SEALAN_37", "Žymimieji langeliai");
define("SEALAN_38", "Žymimosios akutės");
define("SEALAN_39", "Individualūs puslapiai");
define("LAN_SEARCH_98", "Naujienos");
define("LAN_197", "Bylos");
define("LAN_418", "Įprasti puslapiai");
define("SEALAN_40", "Paieškos parametrai");
define("SEALAN_41", "Pagrindinis puslapis");
define("SEALAN_42", "Nustatymai");
define("SEALAN_43", "Redaguoti paieškos nustatymus");
define("SEALAN_44", "Vartotojo klasės leidžia ieškoti šioje srityje");
define("SEALAN_45", "Viename puslapyje rodomų rezultatų skaičius");
define("SEALAN_46", "Simbolių skaičius paieškos rezultatų santrauka");
define("SEALAN_47", "Atitiks tik ištisų žodžių:");
define("SEALAN_48", "Šis nustatymas taikomas tik kai paieškos rūšiavimo būdas yra PHP. Jei jūsų svetainėje yra Ideografinių kalbų, pavyzdžiui, kinų ir japonų, turite šį rinkinį į padėtį IŠJUNGTA.");
define("SEALAN_49", "Jei jūsų svetainėje yra Ideografinių kalbų, pavyzdžiui, kinų ir japonų, turite naudoti PHP rūšiavimo būdą.");


?>