<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_admin_log.php $
|     $Revision: 11678 $
|     $Id: lan_admin_log.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Žurnalas");
define("LAN_ADMINLOG_1", "Data");
define("LAN_ADMINLOG_2", "Pavadinimas");
define("LAN_ADMINLOG_3", "Aprašymas");
define("LAN_ADMINLOG_4", "Vartotojo IP");
define("LAN_ADMINLOG_5", "Vartotojo ID");
define("LAN_ADMINLOG_6", "Informatyvi piktograma");
define("LAN_ADMINLOG_7", "Informatyvus pranešimas");
define("LAN_ADMINLOG_8", "Atkreipkite dėmesį į piktogramą");
define("LAN_ADMINLOG_9", "Atkreipkite dėmesį į pranešimą");
define("LAN_ADMINLOG_10", "įspėjamoji piktograma");
define("LAN_ADMINLOG_11", "įspėjamasis pranešimas");
define("LAN_ADMINLOG_12", "Lemtinga piktograma");
define("LAN_ADMINLOG_13", "Lemtinga pranešimo klaida");


?>