<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_administrator.php $
|     $Revision: 11678 $
|     $Id: lan_administrator.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "Naujas vartotojas/adminas įrašas sukurtas");
define("ADMSLAN_1", "neturi admin statuso");
define("ADMSLAN_2", "atnaujinta duomenų bazėje");
define("ADMSLAN_3", "Pagrindinis svetainės administratorius ir negali būti redaguojamas.");
define("ADMSLAN_4", "Tęsti");
define("ADMSLAN_5", "Klaida!");
define("ADMSLAN_6", "yra pagrindinis svetainės administratorius ir negali būti ištrintas");
define("ADMSLAN_13", "Esami Administratoriai");
define("ADMSLAN_16", "Admin Vardas");
define("ADMSLAN_17", "Admin Slaptažodis");
define("ADMSLAN_18", "Leidimai");
define("ADMSLAN_19", "Buvę svetainės nuostatos");
define("ADMSLAN_20", "Buvę Meniu");
define("ADMSLAN_21", "Modifikuoti administratoriaus leidimus");
define("ADMSLAN_22", "Moderate users/bans etc");
define("ADMSLAN_23", "Individualiai pritaikytus puslapius kurti / redaguoti / meniu");
define("ADMSLAN_24", "Tvarkyti atsisiųstas kategorijas");
define("ADMSLAN_25", "Įkelti /tvarkyti failus");
define("ADMSLAN_26", "Peržiūrėti naujienas");
define("ADMSLAN_27", "Peržiūrėti nuorodas");
define("ADMSLAN_28", "Take site down for maintenance");
define("ADMSLAN_29", "Valdyti banerius");
define("ADMSLAN_30", "Konfigūruoti naujienų kanalų antraštes");
define("ADMSLAN_31", "Konfigūruoti šypsenėles");
define("ADMSLAN_32", "Konfigūruoti priekinį puslapio turinį");
define("ADMSLAN_33", "Konfigūruoti žurnalus/statistiką");
define("ADMSLAN_34", "Konfigūruoti meta tags");
define("ADMSLAN_35", "Konfigūruoti viešai įkeltus failus");
define("ADMSLAN_36", "Konfigūruoti paveikslėlių nustatymus");
define("ADMSLAN_37", "Prižiūrėti komentarus");
define("ADMSLAN_39", "Siųsti naujienas");
define("ADMSLAN_40", "Siųsti nuorodas");
define("ADMSLAN_44", "Siųsti atsisiuntimus");
define("ADMSLAN_45", "Siųsti apklausas");
define("ADMSLAN_46", "Pasisveikinimas");
define("ADMSLAN_47", "Prižiūrėti pateiktas naujienas");
define("ADMSLAN_49", "Pažymėti viską");
define("ADMSLAN_51", "Atžymėtii viską");
define("ADMSLAN_52", "Atnaujinti administratorių");
define("ADMSLAN_53", "Pridėti administratorių");
define("ADMSLAN_54", "Tinklapio administratorius");
define("ADMSLAN_55", "lauką(us) palikti tuščius");
define("ADMSLAN_56", "Tinklapio Administratorius");
define("ADMSLAN_58", "Pagrindinis tinklapio Administratorius");
define("ADMSLAN_59", "Pašalinti Admin statusą");
define("ADMSLAN_60", "Ar norite pašalinti admin statusą iš");
define("ADMSLAN_61", "Administratorius ištrintas");
define("ADMSLAN_62", "Įskiepių Valdymas");
define("ADMSLAN_64", "Išvalyti sistemos podėlį");
define("ADMSLAN_65", "Pašto parametrų konfigūravimas ir išsiuntimas");
define("ADMSLAN_66", "Konfigūruoti paiešką");
define("ADMSLAN_67", "Skenuoti su failų inspektoriumi");
define("ADMSLAN_68", "Konfigūruoti el.pašto pranešimus");
define("ADMSLAN_69", "jau yra administratoriaus ir turi būti redaguojamas.");
define("ADMSLAN_70", "Return to Administrator Listing");
define("ADMSLAN_71", "Paspauskite čia, kad pamatyti privelegijas");
define("ADMSLAN_76", "Valdyti kalbų paketus");


?>