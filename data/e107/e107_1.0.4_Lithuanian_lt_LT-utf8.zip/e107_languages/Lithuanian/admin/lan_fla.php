<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_fla.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Nepavykę bandymai prisijungti");
define("FLALAN_2", "Jokių nepavykusių bandymų prisijungti į žurnalą neįrašyta.");
define("FLALAN_3", "Informacija apie bandymus prisijungti ištrinta");
define("FLALAN_4", "Bandymai prisijungti naudojant negaliojančius prisijungimo vardą ir/ar slaptažodį");
define("FLALAN_5", "Uždrausti IP adresai");
define("FLALAN_6", "Data");
define("FLALAN_7", "Duomenys");
define("FLALAN_8", "IP adresas/Hostas");
define("FLALAN_9", "Nuostatos");
define("FLALAN_10", "Ištrinti / Užbaninti pažymėtus įrašus");
define("FLALAN_11", "patikrinti visus Ištrintus pažymės langelius");
define("FLALAN_12", "nuimti pažymėtus ištrinimui langelius");
define("FLALAN_13", "pažymėti visus užbanintus langelius");
define("FLALAN_14", "nuimti žymes nuo visų užbanintų langelių");
define("FLALAN_15", "Šis IP adresas (-ai) Buvo automatiškai uždraustas - vartotojas bandė daugiau nei dešimt nesėkmingų prisijungimų");
define("FLALAN_16", "ištrinti šį auto apribojimų sąrašą");
define("FLALAN_17", "Auto-apribojimų sąrašas ištrintas");


?>