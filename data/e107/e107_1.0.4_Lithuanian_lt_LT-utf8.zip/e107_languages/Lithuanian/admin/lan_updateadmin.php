<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Klaida - prašome pateikti iš naujo");
define("UDALAN_2", "Nuostatos atnaujintos");
define("UDALAN_3", "Nuostatų atnaujinimas");
define("UDALAN_4", "Vardas");
define("UDALAN_5", "Slaptažodis");
define("UDALAN_6", "Pakartoti slaptažodį");
define("UDALAN_7", "Pakeisti slaptažodį");
define("UDALAN_8", "Slaptažodžio pakeitimas");


?>