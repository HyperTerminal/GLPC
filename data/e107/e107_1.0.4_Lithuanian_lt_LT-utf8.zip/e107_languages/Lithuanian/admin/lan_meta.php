<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_meta.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta-žymės atnaujintos duomenų bazėje");
define("METLAN_2", "Įvesti meta-žymes");
define("METLAN_3", "Įveskite naujas meta-žymes");
define("METLAN_4", "Atnaujinta");
define("METLAN_5", "įrašykite aprašymą apie svetainę čia");
define("METLAN_6", "surašykite, svetainės, raktinių, žodžių, sąrąšą, čia");
define("METLAN_7", "surašykite autorystės teises čia");
define("METLAN_8", "Meta-žymės");
define("METLAN_9", "Aprašymas");
define("METLAN_10", "Raktažodžiai");
define("METLAN_11", "Visos teisės saugomos");
define("METLAN_12", "Naudokite Naujienos pavadinimą ir santrauką kaip meta-aprašymą naujienų puslapiuose.");
define("METLAN_13", "Autorius");


?>