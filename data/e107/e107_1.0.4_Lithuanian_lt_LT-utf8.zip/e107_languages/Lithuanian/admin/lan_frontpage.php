<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_frontpage.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Pirmojo puslapio nuostatos atnaujintos.");
define("FRTLAN_2", "Rodomi puslapiai");
define("FRTLAN_6", "Nuorodos");
define("FRTLAN_12", "Atnaujinti pirmojo puslapio nuostatas");
define("FRTLAN_13", "Pirmojo puslapio nuostatos");
define("FRTLAN_15", "Kitas (įveskite puslapio adresą):");
define("FRTLAN_16", "klaida: no content main parent selected");
define("FRTLAN_17", "klaida: no content sub category selected");
define("FRTLAN_18", "klaida: no content item selected");
define("FRTLAN_19", "turinys");
define("FRTLAN_20", "turinio straipsnių rubrika");
define("FRTLAN_21", "turinio straipsnis");
define("FRTLAN_22", "įprastas puslapis");
define("FRTLAN_26", "visiems lankytojams");
define("FRTLAN_27", "svečiams");
define("FRTLAN_28", "nariams");
define("FRTLAN_29", "administratoriams");
define("FRTLAN_31", "Visiems lankytojams");
define("FRTLAN_32", "Narių grupei");
define("FRTLAN_33", "Rodomi puslapiai");
define("FRTLAN_34", "Puslapis");


?>