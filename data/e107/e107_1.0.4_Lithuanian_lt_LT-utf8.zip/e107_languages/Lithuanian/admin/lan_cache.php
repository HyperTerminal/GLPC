<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_cache.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 19:07:47 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Įkelti sistemos būseną į podėlį");
define("CACLAN_2", "Nustatyti podėlio statusą");
define("CACLAN_3", "Podėlio sistema");
define("CACLAN_4", "Podėlio statusas nustatytas");
define("CACLAN_5", "Išvalyti podėlį");
define("CACLAN_6", "Podėlis išvalytas");
define("CACLAN_7", "Podėlis atjungtas");
define("CACLAN_9", "Podėlio duomenys įrašyti į diską");
define("CACLAN_10", "Neįmanoma įrašyti į podėlio aplankalą. Prašome įsitikinti, jog aplankalo atributai yra 0777 (CHMOD 777)");


?>