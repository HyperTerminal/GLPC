<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_links.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LCLAN_1", "Nuostatos išsaugotos");
define("LCLAN_2", "Nuoroda išsaugota duomenų bazėje.");
define("LCLAN_3", "Informacija apie nuorodą atnaujita duomenų bazėje.");
define("LCLAN_6", "Eiliškumas pakeistas.");
define("LCLAN_8", "Nuorodų sąrašas");
define("LCLAN_12", "Pateikimo būdas");
define("LCLAN_15", "Pavadinimas");
define("LCLAN_16", "Nuoroda");
define("LCLAN_17", "Aprašymas");
define("LCLAN_18", "Mygtukas / Piktograma");
define("LCLAN_19", "Nuorodos aktyvavimas");
define("LCLAN_20", "Atveriama tame pačiame lange");
define("LCLAN_23", "Atveriama naujame pačiame lange");
define("LCLAN_24", "Atveriama 600x400 mini dydžio lange");
define("LCLAN_25", "Nuorodos klasės");
define("LCLAN_26", "Pažymint nuoroda matoma tik vartotojams tos klasės");
define("LCLAN_27", "Atnaujinti nuorodą");
define("LCLAN_28", "Sukurti nuorodą");
define("LCLAN_29", "Nuorodos");
define("LCLAN_30", "perkelti aukštyn");
define("LCLAN_31", "perkelti žemyn");
define("LCLAN_39", "Peržiūrėti paveikslėlius");
define("LCLAN_53", "Nuoroda");
define("LCLAN_54", "ištrinta");
define("LCLAN_58", "Ar tikrai norite ištrinti šią nuorodą?");
define("LCLAN_61", "Nuorodų nėra");
define("LCLAN_62", "Nuorodų sąrašas");
define("LCLAN_63", "Įrašyti naują nuorodą");
define("LCLAN_68", "Parinktys");
define("LCLAN_78", "Rodyti aprašymkaip Ekranas-Tip");
define("LCLAN_79", "Aprašymas apie nuorodą bus pateiktas informaciniame langelyje, kai pelės žymeklis bus ties nuoroda");
define("LCLAN_80", "Aktyvuoti išplėstus submeniu");
define("LCLAN_81", "Antriniai meniu bus rodomas tik po to spustelėdami šakninę. (Nuoroda šakninė yra išjungta)");
define("LCLAN_83", "Submeniu generatorius");
define("LCLAN_88", "Nuorodų nuostatos");
define("LCLAN_89", "Ikona");
define("LCLAN_91", "Perkelti");
define("LCLAN_95", "Grupė");
define("LCLAN_96", "Rodyti jūsų temoje kaip");
define("LINKLAN_1", "Atveriama 800x600 dydžio lange");
define("LINKLAN_2", "Šakninė nuoroda");
define("LINKLAN_3", "Nėra šakninių nuorodų (Normali nuoroda)");
define("LINKLAN_4", "Sub-nuorodų generatorius");
define("LINKLAN_5", "Generuoti sub-nuorodas");
define("LINKLAN_6", "Sukurti sub-nuorodas iš:");
define("LINKLAN_7", "Sukurti sub-nuorodas, kuriuose yra nuoroda?");
define("LINKLAN_8", "Naujienų kategorijos");
define("LINKLAN_9", "Atsisiuntimo kategorijos");
define("LINKLAN_10", "Sukurti sub-nuorodas");


?>