<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_e107_update.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Veiksmas");
define("LAN_UPDATE_3", "Nereikia");
define("LAN_UPDATE_5", "Atnaujinimas galimas");
define("LAN_UPDATE_7", "Vykdomas");
define("LAN_UPDATE_8", "Versijos atnaujinimas nuo");
define("LAN_UPDATE_9", "iki");
define("LAN_UPDATE_10", "Galimi atnaujinimai");
define("LAN_UPDATE_11", ".617 to .7 Atnaujinimas tęsis");
define("LAN_UPDATE_12", "Viena iš lentelių yra su pasikartojančiais įrašais");


?>