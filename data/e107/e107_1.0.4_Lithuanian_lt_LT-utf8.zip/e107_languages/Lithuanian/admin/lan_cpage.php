<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_cpage.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/06 14:53:23 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Pavadinimas");
define("CUSLAN_2", "Tipas");
define("CUSLAN_3", "Nuostatos");
define("CUSLAN_4", "Ar ištrinti puslapį?");
define("CUSLAN_5", "Esantys puslapiai");
define("CUSLAN_7", "Meniu pavadinimas");
define("CUSLAN_8", "Antraštė / Pavadinimas");
define("CUSLAN_9", "Tekstas");
define("CUSLAN_10", "Leisti lankytojams vertinti puslapį");
define("CUSLAN_11", "Sąrašas");
define("CUSLAN_12", "Sukurti puslapį");
define("CUSLAN_13", "Leisti komentarus");
define("CUSLAN_14", "Puslapis apsaugotas slaptažodžiu");
define("CUSLAN_15", "apsaugoti puslapį slaptažodžiu");
define("CUSLAN_16", "Sukurti nuorodą pagrindiniame meniu");
define("CUSLAN_17", "įrašykite nuorodos pavadinimą");
define("CUSLAN_18", "Puslapį kartu su nuoroda galės matyti");
define("CUSLAN_19", "Atnaujinti puslapį");
define("CUSLAN_20", "Sukurti puslapį");
define("CUSLAN_21", "Atnaujinti puslapį");
define("CUSLAN_22", "Sukurti meniu");
define("CUSLAN_23", "Redaguoti puslapį");
define("CUSLAN_24", "Sukurti naują individualų puslapį");
define("CUSLAN_25", "Redaguoti meniu");
define("CUSLAN_26", "Sukurti naują individualų meniu");
define("CUSLAN_27", "Puslapis išsaugotas duomenų bazėje.");
define("CUSLAN_28", "Puslapis ištrintas");
define("CUSLAN_29", "Jei nepasirinkta konkretaus puslapio, rodyti visą sąrašą");
define("CUSLAN_30", "Sausainuko gyvavimo laikas (sekundėmis)");
define("CUSLAN_31", "Sukurti meniu");
define("CUSLAN_32", "Pritaikyti senus puslapius / meniu");
define("CUSLAN_33", "Parinktys");
define("CUSLAN_34", "Pradėti konvertavimą");
define("CUSLAN_35", "Baigtas individualaus puslapio atnaujinimas");
define("CUSLAN_36", "Kiekvieno puslapio savybes galite nustatyti pasirinkę atitinkamą puslapį sąraše.");
define("CUSLAN_37", "Individualaus puslapio atnaujinimas");
define("CUSLAN_38", "on");
define("CUSLAN_39", "off");
define("CUSLAN_40", "Išsaugoti nuostatas");
define("CUSLAN_41", "Rodyti autorių ir datą");
define("CUSLAN_42", "Dar nėra sukurta individualių puslapių");
define("CUSLAN_43", "neužvardintas meniu:");
define("CUSLAN_44", "užvardintas puslapis");


?>