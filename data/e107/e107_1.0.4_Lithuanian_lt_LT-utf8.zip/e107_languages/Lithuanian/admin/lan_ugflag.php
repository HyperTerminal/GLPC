<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_ugflag.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/23 19:59:02 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Techninės profilaktikos nuostatos atnaujintos");
define("UGFLAN_2", "Aktyvuoti svetainės techninę profilaktiką");
define("UGFLAN_3", "Išsaugoti techninės profilaktikos nuostatas");
define("UGFLAN_4", "Techninės profilaktikos nuostatos");
define("UGFLAN_5", "Tekstas, kurį matys lankytojai tuo metu, kai svetainėje bus atliekama techninė profilaktika.");
define("UGFLAN_6", "Jei paliksite tuščią laukelį, lankytojai matys standartinę frazę.");
define("UGFLAN_8", "Riboti priėjimai tik prie Administratorių");
define("UGFLAN_9", "Riboti priėjimai tik prie Pagrindinio Administratoriaus");


?>