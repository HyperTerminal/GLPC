<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_header.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/02/22 23:23:53 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin Navigacija");
define("LAN_head_2", "Jūsų serveris neleidžia HTTP įkelti failų, todėl nebus įmanoma jūsų vartotojams įkelti avatarus / failus ir tt Norėdami pašalinti šį nustatymą file_uploads  jūsų php.ini ir iš naujo paleisti savo serverį. Jei jūs neturite prieigos prie jūsų php.ini susisiekti su savo šeimininkus.");
define("LAN_head_3", "Jūsų serveris veikia su basedir apribojimų poveikį. Tai neleidžia failą bet ne jūsų namų katalogą, ir kaip toks naudojimas gali turėti įtakos tam tikras scenarijus, kaip antai filemanager.");
define("LAN_head_4", "Administravimo sritis");
define("LAN_head_5", "rodoma kalba admino lauke:");
define("LAN_head_6", "Įskiepių info");


?>