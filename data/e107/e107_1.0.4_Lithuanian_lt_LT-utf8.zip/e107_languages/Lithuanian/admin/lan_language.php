<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_language.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "negali būti sukurta (jau egzistuoja)");
define("LANG_LAN_01", "buvo ištrinta ir vėl sukurta.");
define("LANG_LAN_02", "negali būti ištrinta");
define("LANG_LAN_03", "Lentelės");
define("LANG_LAN_05", "Nesukurta");
define("LANG_LAN_06", "Sukurti lenteles");
define("LANG_LAN_07", "Panaikinti esančias lenteles?");
define("LANG_LAN_08", "Pakeisti esančias lenteles (duomenys bus prarasti).");
define("LANG_LAN_10", "Patvirtinti ištrynimą");
define("LANG_LAN_11", "Ištrinti nepažymėtas lenteles (jei jos egzistuoja).");
define("LANG_LAN_12", "Aktyvuoti daugiakalbės sistemos lenteles");
define("LANG_LAN_13", "Daugiakalbės sistemos nuostatos");
define("LANG_LAN_14", "Numatyta svetainės kalba");
define("LANG_LAN_15", " Ar kopijuoti duomenis iš numatytosios kalbos? (naudotina nuorodoms, naujienų grupėms ir t.t.) Jei taip, pažymėkite -");
define("LANG_LAN_16", "Multi kalbos duomenų bazėje");
define("LANG_LAN_17", "Numatytoji Kalba - Nebūtinos jokios papildomos lentelės.");
define("LANG_LAN_18", "Nustatykite subdomainą į kalbų nustatymą:");
define("LANG_LAN_19", "pvz.lt.mydomain.com nustatyti kalbą į lietuvių.");
define("LANG_LAN_20", "Įveskite pagrindinis domeno vardą galima.pvz. mydomain.com");
define("LANG_LAN_21", "Kalbos įrankiai");
define("LANG_LAN_23", "Sukurti kalbų paketą (zip)");
define("LANG_LAN_24", "Sukurti paketą");
define("LANG_LAN_AGR", "Pastaba: Naudojant šiuos įrankius, jūs sutinkate pasidalinti savo kalbą Pack (-ų) su e107 bendruomene.");
define("LANG_LAN_EML", "Prašome išsiųsti jūsų kalbos paketą į");
define("LANG_LAN_25", "Prašome patikrinti, kad CORE_LC ir CORE_LC2 turi reikšmes [lcpath] ir bandykite dar kartą.");
define("LANG_LAN_26", "Prašome įsitikinkite, kad jūs naudojate numatytąjį aplanką vardą e107_config.php (eg. 'e107_languages/', 'e107_plugins/' etc.) ir bandykite dar kartą.");
define("LANG_LAN_27", "Prašome patikrinkite jūsų kalbos paketo failus ir bandykite vėl");
define("LANG_LAN_28", "Pažymėkite šį langelį, jei jūs [e107 sertifikuota vertėjas].");
define("LANG_LAN_29", "Jūs turėtumėte ištaisyti klaidas prieš pridedant savo kalbos paketą.");
define("LANG_LAN_30", "Išleidimo data");
define("LANG_LAN_31", "Suderinamumas");
define("LANG_LAN_32", "Instaliuota kalba");
define("LANG_LAN_33", "Rodyti tik klaidas per patikrinimą");
define("LANG_LAN_34", "Prašome patikrinti ir ištaisyti likę [x] klaida (-os) prieš bandant sukurti language-pack.");


?>