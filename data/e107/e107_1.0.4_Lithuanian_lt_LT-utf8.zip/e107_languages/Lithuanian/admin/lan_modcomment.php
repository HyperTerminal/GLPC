<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_modcomment.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Prižiūrimi");
define("MDCLAN_2", "Nėra komentarų apie tai");
define("MDCLAN_3", "Narys");
define("MDCLAN_4", "Svečias");
define("MDCLAN_5", "atblokuota");
define("MDCLAN_6", "blokuota");
define("MDCLAN_7", "patvirtinti");
define("MDCLAN_8", "Komentarų priežiūra");
define("MDCLAN_9", "Dėmesio!Parent komentarų trynimas taip pat ištrina visus atsakymus!");
define("MDCLAN_10", "opcijos");
define("MDCLAN_11", "komentaras");
define("MDCLAN_12", "komentarai");
define("MDCLAN_13", "užblokuota");
define("MDCLAN_14", "uždaryti komentarus");
define("MDCLAN_15", "atidaryti");
define("MDCLAN_16", "uždaryti");
define("MDCLAN_17", "Nėra komentarų, laukiama patvirtinimo šiuo metu");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>