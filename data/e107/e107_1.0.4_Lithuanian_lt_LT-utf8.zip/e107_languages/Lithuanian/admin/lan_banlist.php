<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_banlist.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Draudimas panaikintas.");
define("BANLAN_2", "Draudimų nėra.");
define("BANLAN_3", "Esami draudimai");
define("BANLAN_4", "Panaikinti draudimą");
define("BANLAN_5", "Įveskite IP, e-pašto adresą, ar host'ą");
define("BANLAN_7", "Priežastis");
define("BANLAN_8", "Vartotojo apribojimas");
define("BANLAN_9", "Nepageidaujamų lankytojų patekimo į svetainę apribojimas");
define("BANLAN_10", "IP / El. paštas / Priežastis");
define("BANLAN_11", "Automatinis draudimas: Daugiau negu 10 nepavykusių bandymų prisijungti prie svetainės");
define("BANLAN_12", "Pastaba: Reversas DNS šiuo metu išjungtas, jis turi būti įjungtas, kad būtų galima uždrausti pagal priimančiosios. Uždrausti pagal IP ir elektroniniu paštu vis dar normaliai funkcionuos.");
define("BANLAN_13", "Pastaba: Norėdami uždrausti vartotoją kaip vartotojo vardas, eikite į vartotojų admin puslapį:");
define("BANLAN_78", "Rezultatų skaičius viršytas (- HTS - prašo per paskirtą laiką)");


?>