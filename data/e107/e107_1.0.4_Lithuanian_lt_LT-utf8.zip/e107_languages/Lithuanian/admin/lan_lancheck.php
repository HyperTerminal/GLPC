<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_lancheck.php $
|     $Revision: 11756 $
|     $Id: lan_lancheck.php 11756 2010-09-06 23:31:47Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Patvirtinti/Redaguoti kalbos failus");
define("LAN_CHECK_2", "Tvarkyti");
define("LAN_CHECK_3", "Patikrinti");
define("LAN_CHECK_4", "Klaidingas failas!");
define("LAN_CHECK_5", "Klaidinga frazė!");
define("LAN_CHECK_7", "frazė");
define("LAN_CHECK_8", "Klaidingas failas...");
define("LAN_CHECK_9", " klaidingi failai...");
define("LAN_CHECK_10", "Kritinė klaida:");
define("LAN_CHECK_11", "Neklaidingas failas !");
define("LAN_CHECK_12", "Neteisingas failas...");
define("LAN_CHECK_13", " neteisingi failai...");
define("LAN_CHECK_14", "Visi egzistuojantys failai yra galiojantys !");
define("LAN_CHECK_15", "Nelegalūs charakeriai ar tuščios vietos rastos prieš '<?php' ar po '?>'");
define("LAN_CHECK_16", "Originalus failas");
define("LAN_CHECK_17", "Įrašymo problema bandant įrašyti failą.");
define("LAN_CHECK_18", "Kalbų failai standartiniame formate negalimi šiuose įskiepiai / temos.");
define("LAN_CHECK_19", "Nerastos UTF-8 charakteristikos!");
define("LAN_CHECK_20", "Generuoti kalbos paketą");
define("LAN_CHECK_21", "Patikrinti iš naujo");
define("LAN_CHECK_22", "Tema");
define("LAN_CHECK_23", "Rasta klaidų");
define("LAN_CHECK_24", "sumoje");
define("LAN_CHECK_25", "Temos");
define("LAN_CHECK_26", "Failas");


?>