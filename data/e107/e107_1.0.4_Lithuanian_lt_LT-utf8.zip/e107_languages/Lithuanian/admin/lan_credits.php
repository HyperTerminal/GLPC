<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/admin/lan_credits.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "e107 Kūrėjai");
define("CRELAN_1", "Kūrėjai");
define("CRELAN_2", "Čia yra iš trečiosios šalies programinės įrangos / išteklių, naudojamų e107 sąrašas. E107 plėtros komanda norėčiau asmeniškai padėkoti šiems kūrėjams leidžia mums-Nuke naudojama savo kodą su e107 ir atleidžiantis savo programinę įrangą pagal GPL licenciją.");
define("CRELAN_3", "visos teisės saugomos");
define("CRELAN_4", "Rodyti e107  Komandą");
define("CRELAN_5", "Rodyti trečiųjų šalių scenarijų");
define("CRELAN_6", "e107 v0.7 atnešė į Jūsų ...");
define("CRELAN_7", "versija");
define("CRELAN_8", "išduoti leidimai");
define("CRELAN_9", "Licencija");
define("CRELAN_10", "MagpieRSS provides an XML-based (expat) RSS parser in PHP.");
define("CRELAN_11", "Pclzip biblioteka siūlo suspaudimo ir ištraukimo funkcijas, ZIP formato archyvus (WinZip, PKZIP).");
define("CRELAN_12", "PclTar siūlo galimybę archyvas su arba be kompresijos failų ar katalogų sąrašą. Šie archyvai sukūrė PclTar yra įskaitomas dauguma gzip / deguto paraiškas ir Windows WinZip .");
define("CRELAN_13", "TinyMCE yra nepriklausoma platforma žiniatinklio veikiancio Javascript, HTML WYSIWYG redaktorius kontrolė išleistas kaip atviro kodo LGPL licenciją Moxiecode Systems AB. Ji turi galimybę konvertuoti HTML textarea laukus ar kitus HTML elementus su redaktoriumi atvejais.");
define("CRELAN_14", "Piktogramos naudojamos e107");
define("CRELAN_15", "Visiškai matoma pašto perdavimo klasė PHP");
define("CRELAN_16", "Meniu sistemoje, naudojama Jayya tema");
define("CRELAN_17", "Iššokančio kalendoriaus valdikliai");
define("CRELAN_18", "PDF palaikymas");
define("CRELAN_19", "UTF-8 PDF palaikymas");
define("CRELAN_20", "");
define("CRELAN_21", "Always a pressure..err..pleasure!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Auštyn ir pirmyn!");
define("CRELAN_30", "");


?>