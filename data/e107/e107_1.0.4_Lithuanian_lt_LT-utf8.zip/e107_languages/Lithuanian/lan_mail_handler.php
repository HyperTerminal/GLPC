<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_mail_handler.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Sugeneruota e107 portalo sistemos");
define("LANMAILH_2", "Tai yra kelių dalių žinutė MIME formatu.");
define("LANMAILH_3", " yra neteisingai suformatuota");
define("LANMAILH_4", "Serveris adresą atmetė");
define("LANMAILH_5", "Serveris neatsako");
define("LANMAILH_6", "Neįmanoma rasti elektroninio pašto serverio.");
define("LANMAILH_7", " yra teisingas.");


?>