<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:52:32 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Bylos tipas");
define("LANUPLOAD_2", "nepriimtinas, todėl buvo ištrintas.");
define("LANUPLOAD_3", "Sėkmingai atsiųsta");
define("LANUPLOAD_4", "Paskirties vieta neegzistuoja arba į ją neturima teisės įrašyti.");
define("LANUPLOAD_5", "Atsiųsta byla viršija upload_max_filesize ribas php.ini byloje.");
define("LANUPLOAD_6", "Atsiųsta byla viršija MAX_FILE_SIZE ribas, nurodytas html formoje.");
define("LANUPLOAD_7", "Atsiuntimas nepavyko.");
define("LANUPLOAD_8", "Bylos nebuvo atsiųstos.");
define("LANUPLOAD_9", "Atsiųstos bylos dydis yra 0 baitų");
define("LANUPLOAD_10", "Atsiuntimas nepavyko [tas pats bylos pavadinimas] - byla tokiu pavadinimu jau egzistuoja.");
define("LANUPLOAD_11", "Byla nebuvo atsiųstas. Bylos pavadinimas:");
define("LANUPLOAD_12", "Klaida");
define("LANUPLOAD_13", "Klaidingas laikinas laukas");
define("LANUPLOAD_14", "Failo įrašymas nepavyko");
define("LANUPLOAD_15", "Įkelti neleidžiama");
define("LANUPLOAD_16", "Nežinoma klaida");
define("LANUPLOAD_17", "Įkeliamo failo klaidingas vardas");
define("LANUPLOAD_18", "Įkeltas failas viršija leistinas ribas.");
define("LANUPLOAD_19", "Įkelta per daug rinkmenų- viršijančios ištrintos.");


?>