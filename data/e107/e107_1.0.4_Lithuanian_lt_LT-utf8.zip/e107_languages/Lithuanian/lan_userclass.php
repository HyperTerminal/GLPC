<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Visi (viešas)");
define("UC_LAN_1", "Svečiai");
define("UC_LAN_2", "Niekas (neaktyvus)");
define("UC_LAN_3", "Nariai");
define("UC_LAN_4", "Tik skaityti");
define("UC_LAN_5", "Administratoriai");
define("UC_LAN_6", "Main Admin");
define("UC_LAN_9", "Nauji vartotojai");
define("UC_LAN_10", "Paieškos robotai");


?>