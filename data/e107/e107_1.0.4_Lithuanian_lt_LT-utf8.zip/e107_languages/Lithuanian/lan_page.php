<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_page.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LAN_PAGE_1", "Puslapių sąrašas išjungtas");
define("LAN_PAGE_2", "Puslapių nėra");
define("LAN_PAGE_3", "Prašomas puslapis neegzistuoja");
define("LAN_PAGE_4", "Vertinti šį puslapį");
define("LAN_PAGE_5", "Ačiū už puslapio įvertinimą");
define("LAN_PAGE_6", "Jūs neturite leidimo peržiūrėti šį puslapį");
define("LAN_PAGE_7", "nekorektiškas slaptažodis");
define("LAN_PAGE_8", "Puslapis apsaugotas slaptažodžiu");
define("LAN_PAGE_9", "Slaptažodis");
define("LAN_PAGE_10", "Pateikti");
define("LAN_PAGE_11", "Puslapių sąrašas");
define("LAN_PAGE_12", "Klaidingas puslapis");
define("LAN_PAGE_13", "Puslapis");


?>