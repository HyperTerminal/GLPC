<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_print.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Printer Friendly");}
define("LAN_PRINT_86", "Rubrika:");
define("LAN_PRINT_87", " Nuo");
define("LAN_PRINT_94", "Paskelbė");
define("LAN_PRINT_135", "Naujienų pranešimas: ");
define("LAN_PRINT_303", "Ši naujiena yra iš svetainės ");
define("LAN_PRINT_304", "Straipsnio pavadinimas: ");
define("LAN_PRINT_305", "Paantraštė: ");
define("LAN_PRINT_306", "Šis straipsnis yra iš svetainės ");
define("LAN_PRINT_307", "Spausdinti šį puslapį");
define("LAN_PRINT_1", "Spausdinti");


?>