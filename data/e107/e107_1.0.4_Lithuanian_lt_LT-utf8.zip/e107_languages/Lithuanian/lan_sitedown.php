<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_sitedown.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Svetainė laikinai uždaryta");
define("LAN_SITEDOWN_00", "laikinai uždaryta");
define("LAN_SITEDOWN_01", "Mes turime uždaryti svetainę atnaujinimui. Tai neturėtų užtrukti ilgai. prašome apsilankyti truputį vėliau. Atleiskite už nepatogumus.");


?>