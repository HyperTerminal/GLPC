<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_online.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Svečiai: ");
define("ONLINE_EL2", "Dalyviai: ");
define("ONLINE_EL3", "Šiame puslapyje: ");
define("ONLINE_EL4", "Prisijungę naršo");
define("ONLINE_EL5", "Dalyviai");
define("ONLINE_EL6", "Naujausias dalyvis");
define("ONLINE_EL7", "peržiūri");
define("ONLINE_EL8", "daugiausia naršė: ");
define("ONLINE_EL9", "on");
define("ONLINE_EL10", "Dalyvio vardas");
define("ONLINE_EL11", "Peržiūri puslapį");
define("ONLINE_EL12", "Atsako į");
define("ONLINE_EL13", "Forumas");
define("ONLINE_EL14", "Tema");
define("ONLINE_EL15", "Puslapis");
define("CLASSRESTRICTED", "Ribotai dalyvių grupei prieinamas puslapis");
define("ARTICLEPAGE", "Straipsnis/apžvalga");
define("CHAT", "Pokalbiai");
define("COMMENT", "Komentarai");
define("DOWNLOAD", "Bylos");
define("EMAIL", "email.php");
define("FORUM", "Pagrindinė forumo rodyklė");
define("LINKS", "Nuorodos");
define("NEWS", "Naujienos");
define("OLDPOLLS", "Ankstesnės apklausos");
define("POLLCOMMENT", "Apklausa");
define("PRINTPAGE", "Atspausdinti");
define("LOGIN", "Jungiamasi");
define("SEARCH", "Ieškoma");
define("STATS", "Tinklalapio statistika");
define("SUBMITNEWS", "Paskelbti naujienas");
define("UPLOAD", "Atsiųstos bylos");
define("USERPAGE", "Vartotojo dosjė");
define("USERSETTINGS", "Vartotojo parametrai");
define("ONLINE", "Prisijungę dalyviai");
define("LISTNEW", "Rodyti pasikeitimus");
define("USERPOSTS", "Dalyvio pranešimai");
define("SUBCONTENT", "Paskelbti Straipsnį/Apžvalgą");
define("TOP", "Aktyviausi pranešėjai/Aktyviausiai diskutuojamos temos");
define("ADMINAREA", "Administratoriaus sritis");
define("BUGTRACKER", "Klaidų seklys");
define("EVENT", "Įvykių sąrašas");
define("CALENDAR", "Įvykių kalendorius");
define("FAQ", "DUK");
define("PM", "Privati žinutė");
define("SURVEY", "Apklausa");
define("ARTICLE", "Straipsnis");
define("CONTENT", "Turinys");
define("REVIEW", "Apžvalga");


?>