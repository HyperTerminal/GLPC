<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_userposts.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:26 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Dalyvių pranešimai");
define("UP_LAN_0", "Visi pasisakymai diskusijose ");
define("UP_LAN_1", "Visi komentarai ");
define("UP_LAN_2", "Temos");
define("UP_LAN_3", "Peržiūros");
define("UP_LAN_4", "Atsakymai");
define("UP_LAN_5", "Paskutinis pranešimas");
define("UP_LAN_6", "Temos");
define("UP_LAN_7", "Komentarų nėra");
define("UP_LAN_8", "Pranešimų nėra");
define("UP_LAN_9", " įjungta ");
define("UP_LAN_10", "Ats");
define("UP_LAN_11", "Paskelbta: ");
define("UP_LAN_12", "Ieškoti");
define("UP_LAN_13", "Komentarai");
define("UP_LAN_14", "Pasisakymai diskusijose");
define("UP_LAN_15", "Ats");
define("UP_LAN_16", "IP adresas");


?>