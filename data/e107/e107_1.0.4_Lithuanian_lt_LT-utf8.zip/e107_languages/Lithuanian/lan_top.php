<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_top.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:52:32 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Aktyviausi forumo dalyviai");
define("TOP_LAN_1", "Vardas");
define("TOP_LAN_2", "Pranešimai");
define("TOP_LAN_3", "Aktyviausi komentatoriai");
define("TOP_LAN_4", "Komentarai");
define("TOP_LAN_5", "Aktyviausi pokalbių dalyviai");
define("TOP_LAN_6", "Svetainės reitingas");
define("LAN_1", "Tema");
define("LAN_2", "Autorius");
define("LAN_3", "Peržiūros");
define("LAN_4", "Atsakymai");
define("LAN_5", "Paskutinis pranešimas");
define("LAN_6", "Temos");
define("LAN_7", "Aktyviausiai diskutuojamos temos");
define("LAN_8", "Aktyviausi dalyviai");


?>