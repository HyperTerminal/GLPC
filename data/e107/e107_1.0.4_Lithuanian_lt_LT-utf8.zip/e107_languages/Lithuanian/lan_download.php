<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_download.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Atsisiuntimai");
define("LAN_dl_1", "(Apribota)");
define("LAN_dl_2", "Įkrovimų, apsilankykite vėliau");
define("LAN_dl_3", "Šioje kategorijoje bylų dar nėra");
define("LAN_dl_4", "Prienamos bylos:");
define("LAN_dl_5", "Bendra bylų apimtis:");
define("LAN_dl_6", "Atsisiųsta bylų:");
define("LAN_dl_7", "Aprašymas");
define("LAN_dl_8", "Gauti");
define("LAN_dl_9", "Grįžti prie kategorijų sąrašo");
define("LAN_dl_10", "Dydis");
define("LAN_dl_11", "Nuotrauka");
define("LAN_dl_12", "Reitingas");
define("LAN_dl_13", "Neįvertinta");
define("LAN_dl_14", "Įvertinti šį failą");
define("LAN_dl_15", "Dėkojame už įvertinimą");
define("LAN_dl_16", "siuntimai");
define("LAN_dl_17", "bylos(-ų)");
define("LAN_dl_18", "Siuntėsi");
define("LAN_dl_19", "Kategorija");
define("LAN_dl_20", "Bylos");
define("LAN_dl_21", "Dydis");
define("LAN_dl_22", "Data");
define("LAN_dl_23", "Failo pavadinimas");
define("LAN_dl_24", "Autorius");
define("LAN_dl_25", "Didėjančia tvarka");
define("LAN_dl_26", "Mažėjančia tvarka");
define("LAN_dl_27", "Eiti");
define("LAN_dl_28", "Vardas");
define("LAN_dl_29", "Siuntėsi");
define("LAN_dl_30", "Autoriaus el. paštas");
define("LAN_dl_31", "Autoriaus tinklalapis");
define("LAN_dl_32", "Atsisiųsti");
define("LAN_dl_33", "Atgal");
define("LAN_dl_34", "Sekantis");
define("LAN_dl_35", "Atgal prie sąrašo");
define("LAN_dl_36", "Naujos bylos");
define("LAN_dl_37", "Peržiūrėti");
define("LAN_dl_38", "Rūšiuoti pagal");
define("LAN_dl_39", "Rūšiuoti");
define("LAN_dl_40", "Paspauskite, jei norite pažiūrėti į nuotrauką");
define("LAN_dl_41", "Ieškoti bylų");
define("LAN_dl_42", "Pakategoris");
define("LAN_dl_43", "balsas");
define("LAN_dl_44", "balsai");
define("LAN_dl_45", "Pranešti apie neveikiančią nuorodą");
define("LAN_dl_46", "paspausti čia įkrovimui");
define("LAN_dl_47", "žinutė pranešta");
define("LAN_dl_48", "Apie siuntinį buvo pranešta administratoriui. <br />Ačiū.");
define("LAN_dl_49", "Paspauskite čia grįžti į siuntinių puslapį");
define("LAN_dl_50", "Praneškite apie neveikiančią įkrovą administratoriui");
define("LAN_dl_51", "Ataskaitinis atsiuntimas");
define("LAN_dl_52", "Svečias");
define("LAN_dl_53", "Paspauskite pažiūrėti siuntinį");
define("LAN_dl_54", "Administratorius peržiūrės šį siuntinį. Jei norite, galite palikti jam žinutę.");
define("LAN_dl_55", "<b>Nenaudokite</b> šios formos tik šiaip sau susisiekti su administratoriumi.");
define("LAN_dl_57", "pranešta");
define("LAN_dl_58", "Pranešta, kad atsiųsti siuntiniai iš svetainės neveikia");
define("LAN_dl_59", "Pranešta:");
define("LAN_dl_60", "Pranešimas apie neteisingą atsisiuntimą");
define("LAN_dl_61", "Download Error");
define("LAN_dl_62", "Jums buvo trukdoma atsisiųsti šį failą, jus viršijote parsisiuntimo kvotą");
define("LAN_dl_63", "Jūs neturite reikiamus leidimus atsisiųsti šį failą.");
define("LAN_dl_64", "Atgal");
define("LAN_dl_65", "Failas nerastas");
define("LAN_dl_66", "Pasirinkite parsisiųstą atvaizdą");
define("LAN_dl_67", "Prašome pažymėti atvaizdą");
define("LAN_dl_68", "Veidrodinis Hostas");
define("LAN_dl_70", "Vieta");
define("LAN_dl_71", "Paie");
define("LAN_dl_72", "Prašomas failas:");
define("LAN_dl_73", "Atsisiųsti iš veidrodžio");
define("LAN_dl_74", "Viso atsisiuntimų iš šio veidrodžio");
define("LAN_dl_75", "paveikslėlio nėra");
define("LAN_dl_76", "Eiti į puslapį");
define("LAN_dl_77", "Atsisiuntimai");
define("LAN_dl_78", "Atsisiuntimai buvo išjungtas arba nutraukti. Prašome patikrinti plotas [parsisiųsti] naujesnės versijos.");
define("LAN_dl_79", "Prašome palaukti kelias akimirkas prieš [prieš atsisisiuntimą vėl].");
define("LAN_dl_80", "Prašome įgalinti slapukus ir [bandykite dar kartą].");
define("LAN_dl_81", "Slapukai reikalaujami");
define("LAN_dl_82", "Prašau palaukti");
define("LAN_dl_83", "Jūsų atsisiuntimas prasidės netrukus...");
define("LAN_dl_84", "Jeigu atsisiuntimas neprasidėjo per kelias sekundes, prašome [spauskite čia].");


?>