<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_signup.php $
|     $Revision: 12130 $
|     $Id: lan_signup.php 12130 2011-04-12 21:09:45Z e107steved $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Registras");
define("LAN_7", "Rodomas Vardas:");
define("LAN_8", "pavadinimą, kuris bus rodomas svetainėje");
define("LAN_9", "Vartotojo vardas:");
define("LAN_10", "vardas, kurį matysite prisijungę");
define("LAN_17", "Slaptažodis:");
define("LAN_103", "Vartotojo vardas negali būti priimamas kaip galiojantis, pasirinkite kitą vartotojo vardą");
define("LAN_104", "Toks vartotojo vardas jau egzistuoja duomenų bazėje, prašome pasirinkti kitą vardą");
define("LAN_105", "Šie du slaptažodžiai nesutampa");
define("LAN_106", "Neatrodo, kad būti galiojantis elektroninio pašto adresas");
define("LAN_107", "Ačiū! Dabar jūs esate registruotas narys");
define("LAN_108", "Registracija užbaigta");
define("LAN_109", "Ši svetainė atitinka Vaikų internetinio privatumo apsaugos aktą 1998 (COPPA), ir kaip toks, negali priimti iš vartotojų jaunesnių nei 13 metų be jų tėvų ar globėjų raštiško sutikimo dokumentą iš registracijos. Daugiau informacijos galite skaityti teisės aktu");
define("LAN_110", "Registracija");
define("LAN_111", "pakartotinai įveskite slaptažodį");
define("LAN_112", "El.pašto adresas");
define("LAN_113", "Paslėpti el.pašto adresą?:");
define("LAN_114", "Tai leis išvengti savo elektroninio pašto adreso  rodymą svetainėje");
define("LAN_123", "Registruotas");
define("LAN_185", "Tu palikai privalomą lauką (-us) tuščią");
define("LAN_201", "Taip");
define("LAN_200", "Ne");
define("LAN_202", "Jūs jau turite sąskaitą.Jei pamiršote savo slaptažodį, prašome spausti "Pamiršau slaptažodį" nuorodą.");
define("LAN_309", "Prašome įvesti jūsų duomenis.");
define("LAN_399", "Tęsti");
define("LAN_400", "Vartotojų vardai ir slaptažodžiai yra <b> didžiąsias ir mažąsias raides </ b>.");
define("LAN_401", "Jūsų sąskaita jau aktyvuota");
define("LAN_402", "Registracija aktyvuota");
define("LAN_403", "Sveiki atvykę į");
define("LAN_404", "Registracijos detalės");
define("LAN_405", "Šis registracijos etapas yra baigtas. Jūs gausite patvirtinimo laišką su savo prisijungimo duomenimis. Prašome sekti nuorodą laiške, ir užbaikite registracijos procesą ir aktyvuoti savo sąskaitą.");
define("LAN_406", "Ačiū!");
define("LAN_407", "Prašome išsaugoti šį laišką savo informacijai. Jūsų slaptažodis buvo užšifruoti ir negali būti atgautas jei  jį pamiršote. Tačiau galite prašyti naują slaptažodį, jei tai atsitiks. \n\n Dėkojame už registraciją. \n\niš");
define("LAN_408", "Vartotojas su tokiu elektroniniu adresu jau egzistuoja. Prašome naudoti "Pamiršau slaptažodį" ekraną, kad gautumėte slaptažodį.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "simbolis");
define("LAN_SIGNUP_3", "Klaidingas kodo patvirtinimas");
define("LAN_SIGNUP_4", "Jūsų slaptažodis turi būti bent");
define("LAN_SIGNUP_5", "simbolių ilgis");
define("LAN_SIGNUP_6", "Jūsų");
define("LAN_SIGNUP_7", "Reikia");
define("LAN_SIGNUP_8", "Ačiū!");
define("LAN_SIGNUP_9", "Nepavyko tęsti");
define("LAN_SIGNUP_10", "Taip");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Yra neleistinų simbolių Vartotojo varde");
define("LAN_410", "Įrašykite kodą, matomą iš paveikslėlio");
define("LAN_411", "Parodoma vardas jau egzistuoja duomenų bazėje, prašome pasirinkti kitą rodomą vardą");
define("LAN_SIGNUP_12", "prašome išsaugoti savo vartotojo vardą ir slaptažodį saugioje vietoje užrašyti taip, tarsi prarado jie negali būti atgautas.");
define("LAN_SIGNUP_13", "Dabar galite prisijungti iš Prisijunk laukeio ar iš <a href='".e_BASE."login.php'>here</a>.");
define("LAN_SIGNUP_14", "čia");
define("LAN_SIGNUP_15", "Prašome susisiekti su pagrindiniu saito administratoriumi");
define("LAN_SIGNUP_16", "jei jums reikia pagalbos.");
define("LAN_SIGNUP_17", "Prašome patvirtinate, kad esate 13 arba virš 13 metų amžiaus.");
define("LAN_SIGNUP_18", "Jūsų registracija buvo gauta ir sukurta ši informacija prisijungimui:");
define("LAN_SIGNUP_21", "Jūsų sąskaita šiuo metu pažymėtas kaip neaktyvi.Norėdami aktyvuoti paskyrą, eikite į šią nuorodą:");
define("LAN_SIGNUP_22", "spausti čia");
define("LAN_SIGNUP_23", "prisijungti");
define("LAN_SIGNUP_24", "Ačiū už prisijungimą");
define("LAN_SIGNUP_25", "Įkelti jūsų kaukę");
define("LAN_SIGNUP_26", "Įkelti Jūsų nuotrauką");
define("LAN_SIGNUP_27", "Rodyti");
define("LAN_SIGNUP_28", "pasirinkimas Content / Pašto sąrašai");
define("LAN_SIGNUP_29", "Patvirtinimo laiškas bus siunčiami į elektroninio pašto adresą kurį įvedate čia, todėl jis turi būti galiojantis.");
define("LAN_SIGNUP_30", "Jei jūs nenorite rodyti savo elektroninio pašto adresą šioje svetainėje, pasirinkite "Taip" "Slėpti elektroninio pašto adresą?" variantas.");
define("LAN_SIGNUP_31", "URL į jūsų XUP bylą");
define("LAN_SIGNUP_32", "Kas yra XUPfailas?");
define("LAN_SIGNUP_33", "Įvedimo kelias arba pasirinkta kaukė");
define("LAN_SIGNUP_34", "Atkreipkite dėmesį:  vaizdas įkeltas į šį serverį, laikomas netikslingu administratorių bus ištrinta iškart.");
define("LAN_SIGNUP_35", "Spauskite čia norėdami užsiregistruoti naudojant XUP byla");
define("LAN_SIGNUP_36", "Įvyko klaida kuriant naudotojo informaciją, prašome susisiekti su svetainės administratoriumi");
define("LAN_LOGINNAME", "Vartotojo vardas");
define("LAN_PASSWORD", "Slaptažodis");
define("LAN_USERNAME", "Rodomas vardas");
define("LAN_EMAIL_01", "Gerb");
define("LAN_EMAIL_04", "Prašome išsaugoti šį laišką savo informacijai");
define("LAN_EMAIL_05", "Jūsų slaptažodis buvo užšifruotas ir negali būti atgautas jei pamirote.Tačiau galite prašyti naują slaptažodį, jei tai atsitiks.");
define("LAN_EMAIL_06", "Ačiū už registraciją");
define("LAN_SIGNUP_37", "Šis registracijos etapas yra baigtas.Saito Adminui reikės patvirtinti savo narystę. Kai tai bus padaryta, gausite patvirtinimo laišką apie tai, kad jūsų narystės buvo patvirtintas.");
define("LAN_SIGNUP_38", "Jūs įvedėte du skirtingus adresus. Prašome įvesti galiojantį el.paštą dviejose laukuose");
define("LAN_SIGNUP_39", "Pakartotinai įveskite el.pašto adresą:");
define("LAN_SIGNUP_40", "Aktyvavimas nebūtinas");
define("LAN_SIGNUP_41", "Jūsų sąskaitą jau aktyvuota");
define("LAN_SIGNUP_42", "Iškilo problema, registracijos paštas nebuvo išsiųstas, prašome susisiekti su svetainės administratoriumi.");
define("LAN_SIGNUP_43", "El.paštas išsiųstas");
define("LAN_SIGNUP_44", "Aktyvacijos laiškas išsiųstas į:");
define("LAN_SIGNUP_45", "Prašome patikrink  atėjusias žinutes.");
define("LAN_SIGNUP_47", "Persiųsti aktyvavimo elektroninį laišką");
define("LAN_SIGNUP_48", "Vartotojo vardas ar el.paštas");
define("LAN_SIGNUP_49", "Jei esate registruotas su neteisingu elektroninio pašto adresu, įveskite naują vardą ir slaptažodį:");
define("LAN_SIGNUP_50", "Naujas laiškas");
define("LAN_SIGNUP_51", "Senas slaptažodis");
define("LAN_SIGNUP_52", "Nekorektiškas slaptažodis");
define("LAN_SIGNUP_53", "laukui nepavyko patikros testas");
define("LAN_SIGNUP_54", "Spustelėkite čia ir užpildykite savo duomenis, registracijai");
define("LAN_SIGNUP_55", "Rodomas pavadinimas yra per ilgas. Prašome pasirinkti kitą");
define("LAN_SIGNUP_56", "Rodomas pavadinimas yra per trumpas. Prašome pasirinkti kitą");
define("LAN_SIGNUP_57", "Prisijungimo vardas yra per ilgas. Prašome pasirinkti kitą");
define("LAN_SIGNUP_58", "Registracijos peržiūra");
define("LAN_SIGNUP_59", "**** Jei nuoroda neveikia, prašome patikrinti, ar jos dalis nebuvo perpildyta į kitą eilutę ****");
define("LAN_SIGNUP_60", "Klaida bandant prisijungti išorinę kaukę");
define("LAN_SIGNUP_72", "Ačiū už Užsiregistravę [sitename]! Mes ką tik jums išsiuntėme patvirtinimo laišką į [email]. Baigti savo registracijos patvirtinimo nuorodą el Prašome spausti ir aktyvuoti savo sąskaitą.");
define("LAN_SIGNUP_98", "Patvirtinkite savo el.pašto adresą");
define("LAN_SIGNUP_99", "Iškilusi problema");
define("LAN_SIGNUP_100", "Vyksta admino patvirtinimas");
define("LAN_SIGNUP_102", "Registracija atsakyta");
define("LAN_SIGNUP_103", "Daugelis vartotojų jau naudoja IP adresas:");
define("LAN_SIGNUP_104", "Klaidingas kaukės vardas");
define("LAN_SIGNUP_105", "Negalime imtis veiksmų į savo prašymą, prašome susisiekti su svetainės administratoriumi");
define("LAN_SIGNUP_106", "Negali imtis veiksmų į Jūsų užklausą - jūs jau turite paskyrą?");


?>