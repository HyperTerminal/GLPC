<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_upload.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:52:32 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Įkelti");
define("LAN_UL_001", "Klaidingas email adresas");
define("LAN_UL_002", "Jūs neturite reikiamų leidimų įkelti failus į šį serverį.");
define("LAN_UL_020", "Klaida");
define("LAN_UL_021", "Įkėlimo klaida");
define("LAN_UL_032", "Jūs turite pasirinkti kategoriją");
define("LAN_UL_033", "Jūs turite įvesti galiojantį email adresą");
define("LAN_UL_034", "Jūs turite nurodyti failo vardą");
define("LAN_UL_035", "Jūs turite įvesti aprašymą");
define("LAN_UL_036", "Turite nurodyti failą įkėlimui");
define("LAN_UL_037", "Jūs turite nurodyti kategoriją");
define("LAN_UL_038", "");
define("LAN_61", "Jūsų vardas:");
define("LAN_112", "El. pašto adresas:");
define("LAN_144", "Tinklalapio adresas:");
define("LAN_402", "Privalote užsiregistruoti, jei norite atsiųsti bylas į šį serverį.");
define("LAN_404", "Dėkojame. Jūsų pateikta byla bus peržiūrėta ir, jei tikslinga, patalpinta Bylų puslapyje.");
define("LAN_406", "Dėmesio");
define("LAN_407", "Kitos bylos bus iš karto pašalintos.");
define("LAN_408", "Pabrauktus");
define("LAN_409", "Bylos pavadinimas");
define("LAN_410", "Versija");
define("LAN_411", "Byla");
define("LAN_412", "Paveiksliukas");
define("LAN_413", "Aprašymas");
define("LAN_414", "Veikianti demonstracinė versija");
define("LAN_415", "įveskite veikiančios demonstracinės versijos nuorodą");
define("LAN_416", "Pateikti ir atsiųsti");
define("LAN_417", "Atsiųsti bylą");
define("LAN_418", "Maksimali bylos apimtis:");
define("DOWLAN_11", "Kategorija");
define("LAN_419", "Leidžiami bylų tipai");
define("LAN_420", "laukelius užpildyti būtina");


?>