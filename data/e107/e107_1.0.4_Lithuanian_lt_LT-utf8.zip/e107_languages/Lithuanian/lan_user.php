<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_user.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nariai");
define("LAN_20", "Klaida");
define("LAN_112", "El. pašto adresas");
define("LAN_137", "Informacijos apie šį vartotoją nėra, nes jis neužsiregistravęs");
define("LAN_138", "Registruoti nariai:");
define("LAN_139", "Tvarka:");
define("LAN_140", "Registruoti nariai");
define("LAN_141", "Registruotų narių dar nėra.");
define("LAN_142", "Dalyvis");
define("LAN_143", "[nerodomas]");
define("LAN_145", "Užsiregistravo");
define("LAN_146", "Apsilankė kartų po registracijos");
define("LAN_147", "Pokalbiai");
define("LAN_148", "Komentarai");
define("LAN_149", "Pranešimai forumuose");
define("LAN_308", "Pilnas vardas ir pavardė");
define("LAN_400", "Tokio nario nėra.");
define("LAN_401", "informacijos nėra");
define("LAN_402", "Nario duomenys");
define("LAN_403", "Puslapio statistika");
define("LAN_404", "Paskutinį kartą lankėsi prieš");
define("LAN_405", "dienas(-ų)");
define("LAN_406", "Reitingas");
define("LAN_407", "nėra");
define("LAN_408", "nuotraukos nėra");
define("LAN_409", "taškai");
define("LAN_410", "Įvairūs");
define("LAN_411", "Atnaujinti informaciją");
define("LAN_412", "Redaguoti informaciją apie dalyvį");
define("LAN_413", "ištrinti nuotrauką");
define("LAN_414", "ankstesnis dalyvis");
define("LAN_415", "kitas dalyvis");
define("LAN_416", "Privalote prisijungti, jei norite pasiekti šį puslapį");
define("LAN_417", "Pagrindinis Administratorius");
define("LAN_418", "Tinklalapio administratorius");
define("LAN_419", "Rodyti");
define("LAN_420", "MAŽ");
define("LAN_421", "DID");
define("LAN_422", "Eiti");
define("LAN_423", "Paspauskite čia, jei norite peržiūrėti dalyvio komentarus");
define("LAN_424", "Paspauskite čia, jei norite peržiūrėti pranešimus forumuose");
define("LAN_425", "Išsiųsti privačią žinutę");
define("LAN_426", "prieš");
define("USERLAN_1", "Aukščiausias Reitingas");
define("USERLAN_2", "Jūs neturite leidimo matyti šį puslapį.");


?>