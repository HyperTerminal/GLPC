<?php
/*
+ ----------------------------------------------------------------------------+
|     Russian Language Pack for e107 0.7
|     $Revision: 183 $
|     $Date: 2008-08-30 21:41:13 +0600 (Сб, 30 авг 2008) $
|     $Author: yarodin $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vartotojo nustatymai");
define("LAN_7", "Atvaizduojamas vardas:");
define("LAN_8", "Vardas, atvaizduotas tinklalapyje");
define("LAN_9", "vartotojo vardas:");
define("LAN_10", "Vardas, kurį naudojate prisijungdami prie tinklalapio");
define("LAN_11", "Įėjimo į tinklalapį vardas negali būti pakeistas, susisiekite su administratoriumi.");
define("LAN_20", "Klaida");
define("LAN_105", "Du slaptažodžiai nesutampa");
define("LAN_106", "Įvestas email adresas nesutampa arba neteisingas.");
define("LAN_112", "email adresas:");
define("LAN_113", "Paslėpti email adresą?:");
define("LAN_114", "Šita opcija leidžia išrinkti - parodyti/paslėpti jūsų email adresą tinklalapyje");
define("LAN_120", "Parašas:");
define("LAN_121", "Avataras:");
define("LAN_122", "Laikina zona:");
define("LAN_150", "Nustatymai atnaujinti ir išsaugoti bazėje.");
define("LAN_151", "OK");
define("LAN_152", "Naujas slaptažodis:");
define("LAN_153", "Pakartoti naują slaptažodį:");
define("LAN_154", "Išsaugoti nustatymus");
define("LAN_155", "Atnaujinti vartotojo nustatymus");
define("LAN_185", "Jūs palikote slaptažodžių lauką tuščią");
define("LAN_308", "Tikrasis vardas:");
define("LAN_401", "Palikti tuščią, kad išsaugoti esamą slaptažodį");
define("LAN_402", "Įveskite kelią avatarui");
define("LAN_403", "Pasirinkti avatarą");
define("LAN_404", "Turėkite galvoje, kad betkoks vaizdas, perduotas į šį serverį bus nedelsiant panaikintas.");
define("LAN_410", "Nustatymai dėl");
define("LAN_411", "Atnaujinti jūsų nustatymus");
define("LAN_412", "Pakeisti jūsų slaptažodį");
define("LAN_413", "Pasirinkti avatarą");
define("LAN_414", "Įkrauti į serverį jūsų nuotrauką");
define("LAN_415", "Įkrauti į serverį jūsų avatarą");
define("LAN_416", "Taip");
define("LAN_417", "Ne");
define("LAN_418", "Registracijos informacija");
define("LAN_419", "Asmeninė / kontaktinė informacija");
define("LAN_420", "Avataras");
define("LAN_421", "Pasirinkti iš avatarų galerijos");
define("LAN_422", "Panaudoti avatarą iš kito tinklalapio");
define("LAN_423", "Parašykite pilną adresą iki vaizdo");
define("LAN_424", "Paspauskite knopke avatarų peržiūrai, esančių šiame tinklapyje");
define("LAN_425", "Nuotrauka");
define("LAN_426", "Bus parodyta jūsų profilio puslapyje");
define("LAN_433", "URL jūsų XUP-failo");
define("LAN_434", "kas tai?");
define("LAN_435", "XML Vartotojo protokolo failas");
define("LAN_SIGNUP_1", "Minimum");
define("LAN_SIGNUP_2", "simbolis.");
define("LAN_SIGNUP_4", "Ilgis ne mažiau");
define("LAN_SIGNUP_5", " simboolių.");
define("LAN_SIGNUP_6", "Jūs");
define("LAN_SIGNUP_7", " būtinai");
define("LAN_USET_1", "Jūsų avataras per didelis");
define("LAN_USET_2", "Maksimalus plotis");
define("LAN_USET_3", "Maksimalus aukštis");
define("LAN_USET_4", "Maksimaliai leistinas aukštis");
define("LAN_CUSTOMTITLE", "Personalinis užvadinimas");
define("LAN_408", "Vartotojas su tokiu email-adresu jau egzistuoja.");
define("MAX_AVWIDTH", "Maksimalus avataro dysis (whx)");
define("MAX_AVHEIGHT", " x");
define("RESIZE_NOT_SUPPORTED", "Pakeitimo metodas nepalaikomas serverio. Pakeiskite vaizdo matmenis ar pasirinkite kitą. Failas buvo ištrintas");
define("LAN_USET_5", "Pasirašytas");
define("LAN_USET_6", "Pasirašyti jūsų siuntiniams ir/arba kitoms šios tinklapio dalims.");
define("LAN_USET_7", "Įvairūsе");
define("LAN_USET_8", "Parašas / Lako juosta");
define("LAN_USET_9", "Kai kurie privalomi laukai neužpildyti (pažymėti *).");
define("LAN_USET_10", "Prašome atnaujinti savo nustatymus, kad tęsti toliau.");
define("LAN_USET_11", "Šis vartotojo vardas negali būti priimtinas, kaip teisingas, pasirinkite kitą vartotojo vardą");
define("LAN_USET_12", "Šis atvaizduotas vaizdas per daug trumpas. Pasirinkite kitą.");
define("LAN_USET_13", "Vartotojo pavadinime aptikti neteisingi simboliai. Pasirinkite kitą pavadinimą.");
define("LAN_USET_14", "Vartotojo vardas perilgas. Pasirinkite kitą");
define("LAN_USET_15", "Vartotojo vardas perilgas. Pasirinkite kitą");
define("LAN_USET_16", "Pažymėti varnele, kad pašalinti esamą foto be užkrovimo į serverį");
define("LAN_USET_17", "Parodytas vaizdas jau naudojamas. Pasirinkite kitą");
define("LAN_USET_18", "Natikras avataro failo vardas.");
define("LAN_USET_19", "Nėra priėimo prie avataro failo.");
define("LAN_USET_20", "Informacijos apie vaizdą nėra.");


?>