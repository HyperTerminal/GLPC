<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Tik nariams");
define("LAN_MEMBERS_0", "apribota sritis");
define("LAN_MEMBERS_1", "Tai yra apribota sritis.");
define("LAN_MEMBERS_2", "Patekimui <a href='".e_LOGIN."'>prisijunkite</a>");
define("LAN_MEMBERS_3", "ar <a href='".e_SIGNUP."'>prisiregistruokite</a> kaip narys");
define("LAN_MEMBERS_4", "Norėdami grįžti į pagrindinį puslapį, paspauskite čia");


?>