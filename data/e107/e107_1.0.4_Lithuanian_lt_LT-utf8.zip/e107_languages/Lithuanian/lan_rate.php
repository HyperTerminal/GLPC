<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_rate.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:52:32 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "balsas");
define("RATELAN_1", "balsai");
define("RATELAN_2", "kaip Jūs įvertintumėte tai?");
define("RATELAN_3", "ačiū už Jūsų balsą");
define("RATELAN_4", "nevertintas");
define("RATELAN_5", "Vertinimas");


?>