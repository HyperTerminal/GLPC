<?php
/*
+ ----------------------------------------------------------------------------+
|     Lithuanian Language Pack for e107 0.7
|     $Revision: 237 $
|     $Date: 2009-09-20 16:18:50 +0600 (Вс, 20 сен 2009) $
|     $Author: vincass $
+----------------------------------------------------------------------------+
*/
define("LANINS_TITLE", "e107 instaliavimas");
define("LANINS_000", "Įvyko klaida. Instaliavimas nutrauktas");
define("LANINS_001", "Versija %1$s");
define("LANINS_002", "Instaliavimas");
define("LANINS_002a", "(Žingsnis %1$s iš 7)");
define("LANINS_003", "1");
define("LANINS_004", "Kalbos pasirinkimas");
define("LANINS_004a", "Kalba pasirinkta");
define("LANINS_004b", "Kalba");
define("LANINS_005", "Prašome pasirinkti kalbą instaliavimui");
define("LANINS_006", "Pasirinkti kalbą");
define("LANINS_007", "4");
define("LANINS_008", "Patikrinimas versijų PHP и MySQL; failo plėtinių patikra");
define("LANINS_008a", "Failų tapatumas ir patikra");
define("LANINS_009", "Perpatikrinti failų plėtinius");
define("LANINS_010", "Neperrašomas failas:");
define("LANINS_010a", "Katalogas neperrašomas:");
define("LANINS_011", "Klaida");
define("LANINS_012", "MySQL funkcijų nėra. Tai reiškia, kad PHP-plėtiniai MySQL nenustatyti, arba instaliavimas PHP nesukompiliuota su MySQL.");
define("LANINS_013", "Negalima nustatyti MySQL versijos. Tai ne kritinė klaida, teskite instaliavimą, bet turėkite omenyje, kad e107 reikalauja MySQL >= 3.23, kad korektiškai veiktų.");
define("LANINS_014", "Failų plėtiniai");
define("LANINS_015", "PHP versija");
define("LANINS_016", "MySQL");
define("LANINS_017", "PRAĖJO");
define("LANINS_018", "Įsitikinkite, kad visi išvardinti failai egzistuoja ir rašyti iš serverio.Tai paprastai apima CHMODing jų 777, bet aplinka skirtis - kreipkitės į savo kompiuterį, jei turite kokių nors problemų.");
define("LANINS_019", "Nustatyta PHP versija netinka e107. Būtina versija PHP 4.3.0 ir aukštesnė.");
define("LANINS_020", "Tęsti instaliavimą");
define("LANINS_021", "2");
define("LANINS_022", "Informacija apie MySQL versiją");
define("LANINS_022a", "Duomenų bazė");
define("LANINS_023", "Įveskite duomenų bazės nustatymus.<br /><br />Jeigu turite root teises, galite sukurti naują duomenų bazę arba naudoti jau egzistuojančią <br /> <br /> Jei turite tik vieną duomenų bazę naudoti priešdėlį, kad kiti scenarijai gali tą pačią duomenų bazę. <br /> Jei jūs nežinote savo MySQL duomenų susisiekti su savo tinklo hostu.");
define("LANINS_024", "MySQL serveris:");
define("LANINS_025", "MySQL loginas:");
define("LANINS_026", "MySQL slaptažodis:");
define("LANINS_027", "MySQL Duomenų bazė:");
define("LANINS_028", "Sukurti duomenų bazę?");
define("LANINS_029", "Lentelių vardų prefiksas:");
define("LANINS_030", "Serveris, MySQL, skirtas naudoti sistemą e107. Ji taip pat gali apimti prievado numerį. Pavyzdžiui: "host: portas" arba kelias į vietos kištukinis lizdas, pavyzdžiui: \ ": / kelias / iki / lizdas \" vietos kompiuterio.");
define("LANINS_031", "Naudotojo vardas, kuris bus naudojamas e107 prisijungti prie jūsų MySQL serverio");
define("LANINS_032", "The Password for the user you just entered");
define("LANINS_033", "MySQL duomenų bazės, kuriose norite rasti e107, kartais vadinamas schemą. Jei naudotojas turi leidimą kurti duomenų bazes, galite sukurti naują duomenų bazę, pažymėdamas atitinkamą langelį.");
define("LANINS_034", "Prefiksas, kad galite naudoti norėdami kurti lenteles e107. Naudinga, jei turite tik vieną duomenų bazę ir reikia šiek tiek nustatymų e107 tą pačią duomenų bazę.");
define("LANINS_035", "Tęsti");
define("LANINS_036", "3");
define("LANINS_037", "MySQL sujungimų patikrinimas");
define("LANINS_038", "duomenų bazės sukūrimui");
define("LANINS_038a", "Duomenų bazės patvirtinimas");
define("LANINS_039", "Prašome įsitikinti, kad užpildyti visi laukai, ypač: Server, MySQL, MySQL vartotojo vardą ir duomenų bazės MySQL (Jie visada reikia serverio MySQL)");
define("LANINS_040", "Klaidos");
define("LANINS_041", "e107 nepavyko prisijungti prie MySQL, naudojant informaciją, kurią įvedėte. <br /> Prašome grįžti į ankstesnį puslapį ir įsitikinkite, kad parametrai yra teisingi.");
define("LANINS_042", " MySQL nustatyta ir patikrinta.");
define("LANINS_043", "Nepavyko sukurti duomenų bazę. Prašome įsitikinti, kad turite teisę kurti serverio duomenų bazėje.");
define("LANINS_044", "Duomenų bazė sukurta sėkmingai");
define("LANINS_045", "Prašome paspauskite mygtuką pereiti į kitą nustatymo etapą");
define("LANINS_046", "5");
define("LANINS_047", "Infrmacija apie administratoriuų");
define("LANINS_047a", "Administracija");
define("LANINS_048", "Atgal prie paskutinio žingsnio");
define("LANINS_049", "Slaptažodžiai nesutampa, grįžkite atgal ir suveskite dar kartą.");
define("LANINS_050", "XML plėtiniai");
define("LANINS_051", "Instaliuota");
define("LANINS_052", "Neisntaliuota");
define("LANINS_053", "e107 0.7.x reikalauja įdiegta PHP XML išplėtimo. Susisiekite su kompiuterio, ar perskaityti apie tai <a href='http://php.net/manual/en/ref.xml.php' target='_blank'> php.net </ a> prieš pradedant");
define("LANINS_054", "duomenų bazės egzistavimo patikrinimas praėjo sėkmingai.");
define("LANINS_055", "Instaliavimo patvirtinimas");
define("LANINS_055a", "Patvirtinti");
define("LANINS_056", "6");
define("LANINS_057", "e107 dabar turi visą būtiną informaciją, siekiant užbaigti diegimą <br /> <br /> Prašome spausti ant mygtuko sukurti duomenų bazės lentelę ir saugoti visus savo nustatymus.");
define("LANINS_058", "7");
define("LANINS_060", "Negalima perskaityti sql failo

Įsitikinkite, kad failas <b>core_sql.php</b> egzistuoja kataloge <b>/e107_admin/sql</b>");
define("LANINS_061", "ee107 was unable to create all of the required database tables.<br /><br />Please clear the database and rectify any problems before trying again.");
define("LANINS_062", "");
define("LANINS_063", "	Welcome to e107");
define("LANINS_069", "e107 sėkmingai įdiegta! <br /><br /> Dėl saugumo priežasčių, turėtumėte nustatyti <b>e107_config.php</ b> failo teises į 644. <br /><br /> Negalima pamiršti, ištrinti įdiegti.php iš serverio, kai paspausite mygtuką žemiau.");
define("LANINS_070", "e107 nesugebėjo išsaugoti pagrindinį config failą į savo serverį. <br /><br /> Prašome užtikrinti, <b>e107_config.php</ b> failas turi turėti reikiamus leidimus");
define("LANINS_071", "Instaliavimas baigtas");
define("LANINS_071a", "Paruošta");
define("LANINS_071b", "Klaida, pasibaigus instaliavimui");
define("LANINS_071c", "Užbaigta su klaidom");
define("LANINS_072", "Admino vartotojo vardas");
define("LANINS_073", "Šis vardas bus naudojamas interneto svetainės prisijungimams");
define("LANINS_074", "Atvaizduojamas admino vardas");
define("LANINS_075", "Šis pavadinimas bus rodomas į savo profilį, forumų ir kitų sričių naudotojams. Palikite šį lauką tuščią, jei norite parodyti savo tikrąjį vardą.");
define("LANINS_076", "Admino slaptažodis");
define("LANINS_077", "Prašome įvesti administratoriaus slaptažodį, kurį norite naudoti čia");
define("LANINS_078", "Admin slaptažodis patvirtintas");
define("LANINS_079", "Įveskite Admino slaptažodį patvirtinimui dar kartą");
define("LANINS_080", "Admino e-mailas");
define("LANINS_081", "Įveskite jūsų e-mail");
define("LANINS_082", "vartotojas@jusutinklapis.com");
define("LANINS_083", "Klaidos iš MySQL:");
define("LANINS_084", "Instaliatorius negali nustatyti sujungimo su duomenų bazeх");
define("LANINS_085", "Instaliatorius negali pasirinkti duomenų bazę.");
define("LANINS_086", "Administratorius Vartotojo vardas, administratoriaus slaptažodį ir Admin Email laukai yra <b>privalomas</b>! Prašome įvesti teisingą informaciją.");
define("LANINS_087", "Įvairūs");
define("LANINS_088", "Pradžia");
define("LANINS_089", "Įkrovos");
define("LANINS_090", "Vartotojai");
define("LANINS_091", "Pasiūlyti naujienas");
define("LANINS_092", "Susisiekite su mumis");
define("LANINS_093", "Leidžia priėjimą prie privačių menių punktų");
define("LANINS_094", "Privataus forumo klasės pavyzdys");
define("LANINS_095", "Vientisumo patikrinimas");
define("LANINS_096", "Paskutiniai komentarai");
define("LANINS_097", "[toliau ...]");
define("LANINS_098", "Naujienos");
define("LANINS_099", "e107 CMS");
define("LANINS_100", "Paskutiniai forumo pranešimai");
define("LANINS_101", "Atnaujinti meniu nuostatas");
define("LANINS_102", "Data / Laikas");
define("LANINS_103", "Įskiepiai e107");
define("LANINS_104", "Patikrinta");
define("LANINS_105", "Vardas arba duomenų bazės priešdėlis pradedant skaitmenų po raidės "E" arba "E" - yra neleistina. <br /> Vardas duomenų bazės arba prefik negali būti tuščias ..");
define("LANINS_106", "PASTABA: e107 negali rašyti į šiuos katalogus ir / ar failus. Jei e107 diegimas vis dar neveikia, tai reiškia, kad kai kurios funkcijos bus nepasiekiama. <br /> <br /> Jūs turite pakeisti teises naudotis šiomis funkcijomis");
define("LANINS_107", "e107_config.php ne tuščias");
define("LANINS_108", "Galbūt jau instaliavote");
define("LANINS_DB_UTF8_LABEL", "Priverstinai naudoti UTF-8 duomenų bazėje?");
define("LANINS_DB_UTF8_CAPTION", "Koduotė MySQL:");
define("LANINS_DB_UTF8_TOOLTIP", "Jei pažymėta, programa bandys atlikti duomenų bazės UTF-8 suderinamos. UTF-8 bazėje yra reikalingas suderinamumas su ateities versijų e107.");
define("LANINS_109", "Pradėta");
define("LANINS_110", "Baigta");
define("LANINS_111", "Temos e107");
define("LANINS_112", "Žinynas e107");
define("LANINS_113", "");
define("LANINS_121", "e107_config.php jau egzistuoja!");
define("LANINS_122", "Galbūt jau instaliuota");
define("LANINS_123", "Debug info");
define("LANINS_124", "Klaidų sekimas");
define("LANINS_125", "neteisingas veiksmas");
define("LANINS_125a", "Klaida");
define("LANINS_WELCOME", "[b]Sveiki atvykę į naują tinklapį![/b] e107 instaliuota sėkmingai. administravimo sekcija yra [link=e107_admin/admin.php]located here[/link], spauskite dabar čia. Jums reikės prisijungimo vardo ir slaptažodžio kuriuos suvedėte instaliavimo metu. [b]Support[/b] [link=http://e107.org/]e107 Homepage[/link] [link=http://e107.org/support]e107 Forums[/link] [link=http://wiki.e107.org/]e107 Handbook[/link] TAčiū.");
define("LANINS_NEWS", "[b] Sveiki [/b] e107 turinio valdymo sistemą, parašytą PHP ir populiarus atviro kodo MySQL duomenų bazės sistema, turinio saugojimo. Ji yra visiškai nemokama, visiškai pritaikyti ir nuolat plėtoti. [sąrašas] [link=http://e107.org/content/Learn-all-about-e107] Viskas, ką jums reikia žinoti apie e107 [/ link]*[link = http://e107.org/content/About su mumis:-Team] Dev Team | vertėjai | Support Team "[/link]*[link =http://wiki.e107.org/] Dokumentacija Wiki [/link] [/list]");


?>