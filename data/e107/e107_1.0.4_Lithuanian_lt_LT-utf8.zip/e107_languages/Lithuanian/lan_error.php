<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_error.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Klaida");
define("LAN_ERROR_1", "Klaida 401 - Priėjimas negalimas");
define("LAN_ERROR_2", "URL Užklausėte reikia teisingą vartotojo vardą ir slaptažodį. Arba įvedėte neteisingą vartotojo vardą / slaptažodį, ar jūsų naršyklė nepalaiko šios funkcijos.");
define("LAN_ERROR_3", "Prašome informuoti puslapio administratorius, jei manote, kad šios klaidos puslapis buvo parodyta per klaidą.");
define("LAN_ERROR_4", "Klaida 403 - Prieiga draudžiama");
define("LAN_ERROR_5", "Jums neleidžiama gauti arba URL nuorodos kurios prašėte.");
define("LAN_ERROR_6", "Prašome informuoti puslapio administratorius, jei manote, kad šios klaidos puslapis buvo parodyta per klaidą.");
define("LAN_ERROR_7", "Klaida 404 - Dokumentas nerastas");
define("LAN_ERROR_9", "Prašome informuoti puslapio administratorių, jei manote, kad per klaidą buvo parodytas ši klaida.");
define("LAN_ERROR_10", "Klaida 500 - Kenksmingas antraštė");
define("LAN_ERROR_11", "Serveryje įvyko vidinė klaida arba netinkamos nuostatos ir negalėjo įvykdyti jūsų prašymo");
define("LAN_ERROR_12", "Prašome informuoti puslapį administratoriumi, jei jūs manote, per klaidą buvo parodyta šį klaidingas puslapis.");
define("LAN_ERROR_13", "Klaida - Nežinoma");
define("LAN_ERROR_14", "Serveris aptiko klaidą");
define("LAN_ERROR_15", "Prašome informuoti puslapio administratoriumi, jei jūs manote, per klaidą buvo parodyta šis klaidos puslapis.");
define("LAN_ERROR_16", "Jūsų nesėkmingas bandymas prieiti prie");
define("LAN_ERROR_17", "buvo įrašyta.");
define("LAN_ERROR_18", "Matyt, jūs čia buvo perduoti");
define("LAN_ERROR_19", "Deja, nuoroda šiuo adresu yra pasenusi ");
define("LAN_ERROR_20", "Prašome spausti čia norėdami pereiti į šios svetainės pagrindinį puslapį");
define("LAN_ERROR_21", "Nepavyko rasti  URL šiame serveryje.Nuoroda  tikriausiai pasenusi.");
define("LAN_ERROR_22", "Prašome spausti čia norėdami pereiti į šios svetainės paieškos puslapį");
define("LAN_ERROR_23", "Jūsų bandymas prieiti prie");
define("LAN_ERROR_24", "buvo nesėkmingas");
define("LAN_ERROR_25", "[1]: Nepavyko perskaityti pagrindinių nustatymų iš duomenų bazės Pagrindiniai parametrai egzistuoja, tačiau negali būti sužymėti. Bandykite atkurti pagrindinę atsarginę kopiją.");
define("LAN_ERROR_26", "[2]: Nepavyko perskaityti pagrindinių nustatymus iš duomenų bazės - neegzistuojantys pagrindiniai parametrai.");
define("LAN_ERROR_27", "[3]: Pagrindiniai nustatymai išsaugoti atsarginę kopiją aktyvuoti..");
define("LAN_ERROR_28", "[4]:Pagrindinė atsarginė kopijąarasta. Įsitikinkite, kad jūsų duomenų bazės turi galiojantį turinį. Jei ne, prašome paleisti <ahref='".e_FILE_ABS."resetcore/resetcore.php'>Reset_Core </ a>, įrankis, atkurti savo pagrindinius nustatymus. <br /> Po atkūrimo savo pagrindinės prašome įrašyti atsarginę kopiją admin/SQL ekraną.");
define("LAN_ERROR_29", "[5]: Sritis (-ys) buvo paliktos tuščios. Pateikite formą iš naujo ir užpildykite privalomus laukus.");
define("LAN_ERROR_30", "[6]: Nepavyko suformuoti tinkamą ryšį su MySQL. Prašome patikrinti, kad jūsų e107_config.php turi teisingą informaciją.");
define("LAN_ERROR_31", "[7]: MySQL veikia, tačiau duomenų bazė ({$ mySQLdefaultdb}) negali būti prijungtas prie. <br /> Prašome patikrinti, ar ji egzistuoja ir kad jūsų e107_config.php turi teisingą informaciją.");
define("LAN_ERROR_32", "Kad užbaigtumėte atnaujinimą, nukopijuokite šį tekstą į savo e107_config.php failą:");
define("LAN_ERROR_33", "Apdorojimo klaid! Paprastai nukreipiama į pagrindinį puslapį.");
define("LAN_ERROR_34", "Nežinoma klaida! Prašome informuoti svetainės administratorių apie tai:");
define("LAN_ERROR_35", "Klaida 400 - Bloga užklausa");
define("LAN_ERROR_36", "Yra formatavimo klaida puslapyje kurį jūs bandote pasiekti.");
define("LAN_ERROR_37", "Ikonos klaida");
define("LAN_ERROR_38", "");
define("LAN_ERROR_39", "");


?>