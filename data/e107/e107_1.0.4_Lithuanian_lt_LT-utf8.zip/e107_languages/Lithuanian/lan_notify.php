<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Vartotojas Registruotas");
define("NT_LAN_UV_1", "Vartotojo registracija patvirtinta");
define("NT_LAN_UV_2", "VartotojoID:");
define("NT_LAN_UV_3", "Vartotojo prisijungimo vardas:");
define("NT_LAN_UV_4", "vartotojo IP:");
define("NT_LAN_LI_1", "Vartotojas prisijungęs prie");
define("NT_LAN_LO_1", "Vartotojas atsijungęs");
define("NT_LAN_LO_2", "atsijungta nuo saito");
define("NT_LAN_FL_1", "Flood draudimas");
define("NT_LAN_FL_2", "IP adresas uždraustas dėl flood");
define("NT_LAN_SN_1", "Naujienos pateiktos");
define("NT_LAN_NU_1", "Atnaujinta");
define("NT_LAN_ND_1", "Naujienos pašalintos");
define("NT_LAN_ND_2", "Pašalintų naujienų id");
define("NT_LAN_CM_1", "Vartotojo komentaras laukia patvirtinimo");


?>