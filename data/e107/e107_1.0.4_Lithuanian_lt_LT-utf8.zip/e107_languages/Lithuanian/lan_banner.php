<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_banner.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Reklama");
define("BANNERLAN_16", "Kliento vardas:");
define("BANNERLAN_17", "Slaptažodis:");
define("BANNERLAN_18", "Tęsti");
define("BANNERLAN_19", "Prašome įrašyti jūsų kaip kliento prisijungimo vardą ir slaptažodį");
define("BANNERLAN_20", "Atleiskite, tačiau negalime rasti šios informacijos mūsų duomenų bazėje. Prašome susisiekti su administratoriumi");
define("BANNERLAN_21", "Reklaminių skydelių statistika");
define("BANNERLAN_22", "Klientas");
define("BANNERLAN_23", "Reklaminio skydelio ID");
define("BANNERLAN_24", "Paspaudimų");
define("BANNERLAN_25", "Paspaudimų %");
define("BANNERLAN_26", "Perkėlimų");
define("BANNERLAN_27", "Nupirkta perkėlimų");
define("BANNERLAN_28", "Liko perkėlimų");
define("BANNERLAN_29", "Reklaminių skydelių nėra");
define("BANNERLAN_30", "Neribotas");
define("BANNERLAN_31", "Netaikomas");
define("BANNERLAN_32", "Taip");
define("BANNERLAN_33", "Ne");
define("BANNERLAN_34", "Baigiasi");
define("BANNERLAN_35", "Besikreipiančių IP adresai");
define("BANNERLAN_36", "Aktyvūs:");
define("BANNERLAN_37", "Pradžia:");
define("BANNERLAN_38", "Klaida");


?>