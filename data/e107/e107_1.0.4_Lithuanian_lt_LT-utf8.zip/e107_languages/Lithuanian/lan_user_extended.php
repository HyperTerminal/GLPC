<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_user_extended.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Teksto laukelis");
define("UE_LAN_2", "Žymimosios akutės");
define("UE_LAN_3", "Išskleidžiamas meniu");
define("UE_LAN_4", "Duomenų bazės lentelės laukas");
define("UE_LAN_5", "Tekstinis laukas");
define("UE_LAN_6", "Sveikas skaičius");
define("UE_LAN_7", "Data");
define("UE_LAN_8", "Kalba");
define("UE_LAN_9", "Vardas");
define("UE_LAN_10", "Rūšis");
define("UE_LAN_11", "Vartoti");
define("UE_LAN_HIDE", "paslėpti nuo kitų narių");
define("UE_LAN_LOCATION", "Vieta");
define("UE_LAN_LOCATION_DESC", "Vartotojo vieta");
define("UE_LAN_AIM", "AIM Adresas");
define("UE_LAN_AIM_DESC", "AIM Adresas");
define("UE_LAN_ICQ", "ICQ Nr.");
define("UE_LAN_ICQ_DESC", "ICQ Nr.");
define("UE_LAN_YAHOO", "Yahoo! Adresas");
define("UE_LAN_YAHOO_DESC", "Yahoo! Adresas");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN Adresas");
define("UE_LAN_HOMEPAGE", "Namų puslapis");
define("UE_LAN_HOMEPAGE_DESC", "Vartotojo namų puslapis (url)");
define("UE_LAN_BIRTHDAY", "Gimtadienis");
define("UE_LAN_BIRTHDAY_DESC", "Gimtadienis");
define("UE_LAN_LANGUAGE", "Kalba");
define("UE_LAN_LANGUAGE_DESC", "Vartotojo kalba");
define("UE_LAN_COUNTRY", "Šalis");
define("UE_LAN_COUNTRY_DESC", "Vartotojo šalis (įskaitant  db lenteles)");
define("LAN_UE_FAIL_HOMEPAGE", "Neteisingas įrašas pagrindinio puslapio nustatyme");


?>