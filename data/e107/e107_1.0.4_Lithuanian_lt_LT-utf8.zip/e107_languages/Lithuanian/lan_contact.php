<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_contact.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Susisiekite su mumis");
define("LANCONTACT_01", "Kontaktiniai duomenys");
define("LANCONTACT_02", "Rašykite mums");
define("LANCONTACT_03", "Įveskite savo vardą:");
define("LANCONTACT_04", "Įveskite savo e-mail:");
define("LANCONTACT_05", "Laiško tema:");
define("LANCONTACT_06", "Rašykite žinutę:");
define("LANCONTACT_07", "Nusiųskite šios žinutės kopiją jūsų adresu");
define("LANCONTACT_08", "Išsiųsti");
define("LANCONTACT_09", "Jūsų žinutė buv išsiųsta.");
define("LANCONTACT_10", "Problema išsiunčiant žinutę.");
define("LANCONTACT_11", "Neatrodo, kad jūsų elektroninio pašto adresas galioja.\\NPrašome pažymėkite jį ir bandykite dar kartą.");
define("LANCONTACT_12", "Jūsų žinutė per trumpa.");
define("LANCONTACT_13", "Prašau įvesti pavadinimą.");
define("LANCONTACT_14", "Nusiųsti žinutę :");
define("LANCONTACT_15", "Negerai įvestas kodas");
define("LANCONTACT_16", "Įveskite kodą:");


?>