<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_search.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/03/25 18:06:46 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Paieška:");
define("LAN_140", "Nariai");
define("LAN_180", "Ieškoti");
define("LAN_192", "Visi skyriai");
define("LAN_193", "Įvykių kalendorius");
define("LAN_194", "Visi skyriai");
define("LAN_195", "Ieškoma");
define("LAN_196", "Rasta");
define("LAN_197", "Bylos");
define("LAN_198", "Nerasta");
define("LAN_199", "Ko ieškoti?");
define("LAN_416", "Norėdami pasiekti šį puslapį turite prisijungti");
define("LAN_417", "Paieškos užklausa turi būti ne mažiau 3 simbolių.");
define("LAN_418", "Kiti puslapiai");
define("LAN_SEARCH_1", "Pažymėti visus");
define("LAN_SEARCH_2", "Panaikinti žymėjimus");
define("LAN_SEARCH_3", "pranešimas paskelbtas");
define("LAN_SEARCH_4", "Rasta naujienų antraštėje");
define("LAN_SEARCH_5", "Rasta naujienų tekste");
define("LAN_SEARCH_6", "Rasta išplėstajame naujienų tekste");
define("LAN_SEARCH_7", "Paskelbė");
define("LAN_SEARCH_8", "on");
define("LAN_SEARCH_9", "Be pavadinimo");
define("LAN_SEARCH_10", "Eiti į puslapį:");
define("LAN_SEARCH_11", "Rezultatai:");
define("LAN_SEARCH_12", "of");
define("LAN_SEARCH_13", "in");
define("LAN_SEARCH_14", "Kategorija:");
define("LAN_SEARCH_15", "Autorius:");
define("LAN_SEARCH_17", "Atsiprašome, ieškoti leidžiama kas");
define("LAN_SEARCH_18", " sekundžių (-es).");
define("LAN_SEARCH_19", "Kur ieškoti?");
define("LAN_SEARCH_20", "Reikalinga autorizacija");
define("LAN_SEARCH_21", "Jums neleidžiama peržiūrėti šio puslapio.");
define("LAN_SEARCH_22", "Visos sritys");
define("LAN_SEARCH_23", "Išplėstos užklausos forma");
define("LAN_SEARCH_24", "Privalo turėti žodį(-ius)");
define("LAN_SEARCH_25", "Neturi turėti žodžio(-ių)");
define("LAN_SEARCH_26", "Tiksli frazė");
define("LAN_SEARCH_27", "Žodžiai, prasidedantys");
define("LAN_SEARCH_28", "Visi neturi išplėstos paieškos");
define("LAN_SEARCH_29", "Paprasta");
define("LAN_SEARCH_30", "Išplėsta");
define("LAN_SEARCH_31", "neturi išplėstos paieškos");
define("LAN_SEARCH_32", "Sekantys žodžiai praleisti paieškoje");
define("LAN_SEARCH_33", "Sekantys žodžiai išplėsti paieškoje");
define("LAN_SEARCH_34", "Naujesnis nei");
define("LAN_SEARCH_35", "Senesnis nei");
define("LAN_SEARCH_36", "Bet kurio laiko");
define("LAN_SEARCH_37", "Dienos");
define("LAN_SEARCH_38", "2 dienų");
define("LAN_SEARCH_39", "3 dienų");
define("LAN_SEARCH_40", "Savaitės");
define("LAN_SEARCH_41", "2 savaičių");
define("LAN_SEARCH_42", "3 savaičių");
define("LAN_SEARCH_43", "Mėnesio");
define("LAN_SEARCH_44", "2 mėnesių");
define("LAN_SEARCH_45", "3 mėnesių");
define("LAN_SEARCH_46", "Pūsės metų");
define("LAN_SEARCH_47", "metų");
define("LAN_SEARCH_48", "2 metų");
define("LAN_SEARCH_49", "3 metų");
define("LAN_SEARCH_50", "Paskelbimo data");
define("LAN_SEARCH_51", "Visos kategorijos");
define("LAN_SEARCH_52", "Sutinka");
define("LAN_SEARCH_53", "Visas įrašas");
define("LAN_SEARCH_54", "Tik pavadinimas");
define("LAN_SEARCH_55", "Paieška naujienų kategorijoje");
define("LAN_SEARCH_56", "Visos naujos kategorijos");
define("LAN_SEARCH_57", "Paskelbti komentarai į");
define("LAN_SEARCH_58", "Visos sritys");
define("LAN_SEARCH_59", "Visi komentarai");
define("LAN_SEARCH_60", "Paskelbti komentarai į");
define("LAN_SEARCH_61", "Pagal autorių");
define("LAN_SEARCH_62", "Prisijungimo datą");
define("LAN_SEARCH_63", "Paieška kategorijoje");
define("LAN_SEARCH_64", "Visos siuntinių kategorijos");
define("LAN_SEARCH_65", "Siuntiniai");
define("LAN_SEARCH_66", "Įdėjimo data");
define("LAN_SEARCH_67", "Visos siuntinių detalės");
define("LAN_SEARCH_68", "Data");
define("LAN_SEARCH_69", "Tinkamumas");
define("LAN_SEARCH_70", "Paskelbta siuntinio įraše");
define("LAN_SEARCH_71", "Paskelbta atsakant į naujienų įrašą");
define("LAN_SEARCH_72", "Parašas");
define("LAN_SEARCH_73", "Nėra parašo.");
define("LAN_SEARCH_74", "Prisijunta");
define("LAN_SEARCH_75", "Paieškos tipas");
define("LAN_SEARCH_76", "Paskelbta puslpyje");
define("LAN_SEARCH_77", "Paskelbta profilio puslapyje");
define("LAN_SEARCH_98", "Naujienos");
define("LAN_SEARCH_99", "Komentarai");
define("LAN_SEARCH_201", "Prašome iš naujo apibrėžti savo paieškos užklausa");


?>