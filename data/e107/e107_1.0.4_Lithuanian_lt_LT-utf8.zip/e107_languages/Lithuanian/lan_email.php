<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_email.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Email");}
define("LAN_EMAIL_1", "Nuo:");
define("LAN_EMAIL_2", "Siuntėjo IP adresas:");
define("LAN_EMAIL_3", "Naujiena ");
define("LAN_EMAIL_4", "Išsiųsti Email");
define("LAN_EMAIL_5", "Nusiųsti draug");
define("LAN_EMAIL_6", "Manau, kad jums tai bus įdomu");
define("LAN_EMAIL_7", "Nusiųsti ");
define("LAN_EMAIL_8", "Komentaras");
define("LAN_EMAIL_9", "Atsiprašome, laiško išsiųsti negalime");
define("LAN_EMAIL_10", "Laiškas išsiųstas adresu");
define("LAN_EMAIL_11", "Laiškas išsiųstas");
define("LAN_EMAIL_12", "Klaida");
define("LAN_EMAIL_13", "Email article to a friend");
define("LAN_EMAIL_14", "Email news_item to a friend");
define("LAN_EMAIL_15", "Login Name: ");
define("LAN_EMAIL_106", "Tai nėra taisyklingas el. pašto adresas.");
define("LAN_EMAIL_185", "Siųsti straipsnį");
define("LAN_EMAIL_186", "Siųsti naujieną");
define("LAN_EMAIL_187", "Gavėjo el. pašto adresas:");
define("LAN_EMAIL_188", "Manau, jog tave gali sudominti ši naujiena");
define("LAN_EMAIL_189", "Manau, jog tave gali sudominti šis straipsnis");
define("LAN_EMAIL_190", "Įvesti parodytą kodą");


?>