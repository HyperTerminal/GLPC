<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/Lithuanian.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/28 22:22:24 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL,'lt_LT.UTF-8');
define("CORE_LC", "'lt_LT.UTF-8'");
define("CORE_LC2", "'lt_LT.UTF-8'");
define("CHARSET", "UTF-8");
define("CORE_LAN1", "Klaida : tema nerasta.\\n\\nPakeiskite naudojamą temą nuostatuose (administratoriaus srityje) arba į serverį atsiųskite naudojamos temos bylas.");
define("CORE_LAN4", "Prašome ištrinti install.php failą iš jūsų serverio");
define("CORE_LAN5", "jei nenorite  galima saugumo riziką į savo svetainę");
define("CORE_LAN6", "Apsaugos nuo fludo šioje svetainėje buvo aktyvuota ir jūs būsite įspėti, kad jei vykdote prašyti puslapių, jums gali būti uždrausta.");
define("CORE_LAN7", "Branduolys bando atkurti Prefs iš automatinio atsarginės kopijos.");
define("CORE_LAN8", "Pagrindinių nuostatų klaida");
define("CORE_LAN9", "Branduolys negali atkurti iš automatinio atsarginės kopijos. Vykdymą sustabdė.");
define("CORE_LAN10", "Aptiktas sugadintas slapukas - atsijungti.");
define("CORE_LAN11", "Užkrovimo laikas:");
define("CORE_LAN12", "sek.");
define("CORE_LAN13", "užklausų");
define("CORE_LAN14", "");
define("CORE_LAN15", "DB užklausų");
define("CORE_LAN16", "Atminties panaudojimas");
define("CORE_LAN17", "[ vaizdas negalimas ]");
define("CORE_LAN18", "Vaizdas:");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "KB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "Įspėjimas!");
define("LAN_ERROR", "Klaida");
define("LAN_ANONYMOUS", "Anonimas");
define("LAN_EMAIL_SUBS", "el.paštas");
define("LAN_SANITISED", "SANTISED");


?>