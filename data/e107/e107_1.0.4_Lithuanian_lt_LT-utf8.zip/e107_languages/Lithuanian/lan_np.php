<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_np.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/03/06 18:52:32 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Atgal");
define("NP_2", "Sekantis");
define("NP_3", "Į puslapį");


?>