<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_login.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/03/25 18:06:46 $
|     $Author: g3d45 $
+----------------------------------------------------------------------------+
*/
define("LAN_27", "Jūs palikote privalomus laukus tuščius");
define("LAN_300", "Prisijunti nepavyko, nes įvesti duomenys nesutampa. Pabandykite išjungti CAPS-LOCK.");
define("LAN_302", "Jūs neaktyvavote savo sąskaitos. Turėtumėte gauti e-laišką su tolimesnėmis registracijos instrukcijomis. Jei įvyko klaida, spauskite <a href='".e_BASE."signup.php?resend'>čia</a>.");
define("LAN_303", "vestas neteisingas kodas.");
define("LAN_304", "Ši vardo/slaptažodžio kombinacija jau naudojama.");
define("LAN_LOGIN_1", "Prisijungimo vardas");
define("LAN_LOGIN_2", "Slaptažodis");
define("LAN_LOGIN_3", "Apsaugotas serveris");
define("LAN_LOGIN_4", "Prašome įvesti duomenus, kad galėtumėte prisijunti.");
define("LAN_LOGIN_5", "Paspauskite čia registracijai");
define("LAN_LOGIN_6", "Šiuo metu naujų narių registracija nevykdoma");
define("LAN_LOGIN_7", "Įveskite kodą");
define("LAN_LOGIN_8", "Prisiminti mane");
define("LAN_LOGIN_9", "Prisijungti");
define("LAN_LOGIN_10", "Spauskite prisijungti");
define("LAN_LOGIN_11", "Registruoti naują vartotoją");
define("LAN_LOGIN_12", "Pamiršau slaptažodį");
define("LAN_LOGIN_13", "Prašome įvesti tekstą, matoma paveikslėlyje");
define("LAN_LOGIN_14", "Vartotojas bando prisijunti su neatpažįstamu vartotojo vardu");
define("LAN_LOGIN_15", "Vartotojas bando prisijunti su neteisingu slaptažodžiu");
define("LAN_LOGIN_16", "Vartotojas bando prisijunti su vartotojo vardo/slaptažodžio kombinacija, kuri jau yra naudojama");
define("LAN_LOGIN_17", "Vartotojo slaptažodis User password (supainiotas)");
define("LAN_LOGIN_18", "Autodraudimas: daugiau kaip 10 bandymų prisijunti");
define("LAN_LOGIN_19", "> 10 nepavykusių prisijungimų");


?>