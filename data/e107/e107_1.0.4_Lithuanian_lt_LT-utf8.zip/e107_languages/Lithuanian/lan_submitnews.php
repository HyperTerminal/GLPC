<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_languages/Lithuanian/lan_submitnews.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/02/24 00:11:26 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Paskelbti naujienas");
define("LAN_7", "Vardas:");
define("LAN_62", "Tema:");
define("LAN_112", "El. pašto adresas:");
define("LAN_133", "Dėkojame");
define("LAN_134", "Jūsų naujiena išsiųsta ir bus peržiūrėta vieno iš tinklalapio administratorių.");
define("LAN_135", "Naujienos tekstas:");
define("LAN_136", "Paskelbti naujieną");
define("NWSLAN_6", "Rubrika");
define("NWSLAN_10", "Naujienų rubrikų nėra");
define("NWSLAN_11", "Jūs neturite teisės čia patekti.");
define("NWSLAN_12", "Uždrausta.");
define("SUBNEWSLAN_1", "Turite nurodyti pavadinimą.\\n");
define("SUBNEWSLAN_2", "Naujienų pranešime jūs turite įrašyti bent kiek teksto.\\n");
define("SUBNEWSLAN_3", "Pridėti galima tik bylą, kurios plėtinys turi būti jpg, gif, png");
define("SUBNEWSLAN_4", "Byla per didelė");
define("SUBNEWSLAN_5", "Paveikslo byla");
define("SUBNEWSLAN_6", "(jpg, jpeg, gif arba png)");
define("SUBNEWSLAN_7", "Jūs turite pateikti jūsų vardą ir el.pašto adresą");
define("SUBNEWSLAN_8", "Paveikslėlio išsiuntimo klaida");


?>