<?php
/*
+---------------------------------------------------------------+
|        e107 website system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/interfectus/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 10:51:53 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'interfectus' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Skaityti/Rašyti komentarus");
define("LAN_THEME_3", "Komentarai išjungti");
define("LAN_THEME_4", "Skaityti toliau...");
define("LAN_THEME_5", "Kopijos:");


?>