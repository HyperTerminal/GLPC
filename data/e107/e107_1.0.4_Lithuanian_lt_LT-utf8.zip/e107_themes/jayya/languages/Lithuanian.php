<?php
/*
+---------------------------------------------------------------+
|        e107 website system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/jayya/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 10:53:06 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Komentarai išjungti");
define("LAN_THEME_2", "Skaityti/Rašyti komentarus");
define("LAN_THEME_3", "Skaityti toliau...");
define("LAN_THEME_4", "Kopijos:");
define("LAN_THEME_5", "Paskelbė");
define("LAN_THEME_6", "į");


?>