<?php
/*
+---------------------------------------------------------------+
|        e107 website system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/crahan/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 10:45:09 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "CraHan' by <a href='http://e107.org' rel='external'>jalist</a>, based on the theme by CraHan at his homepage <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Komentarai čia išjungti");
define("LAN_THEME_3", "komentaras(ai)");
define("LAN_THEME_4", "Skaityti toliau...");
define("LAN_THEME_5", "Kopijos:");
define("LAN_THEME_6", "Komentavo");


?>