<?php
/*
+---------------------------------------------------------------+
|        e107 website system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/khatru/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 10:55:11 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'khatru' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Komentarai išjungti");
define("LAN_THEME_3", "komentaras:");
define("LAN_THEME_4", "Skaityti toliau");
define("LAN_THEME_5", "Kopijos:");


?>