<?php
/*
+---------------------------------------------------------------+
|        e107 website system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/human_condition/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 10:50:26 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' by <a href='http://e107.org' rel='external'>jalist</a>, based on the Wordpress theme, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Komentarai čia išjungti");
define("LAN_THEME_3", "komentaras(ai)");
define("LAN_THEME_4", "Skaityti toliau...");
define("LAN_THEME_5", "Kopijos:");
define("LAN_THEME_6", "Komentavo");


?>