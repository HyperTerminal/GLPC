<?php
/*
+---------------------------------------------------------------+
|        e107 website system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/kubrick/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 10:56:38 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' by <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Based on original theme by Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Komentarai išjungti");
define("LAN_THEME_3", "komentaras:");
define("LAN_THEME_4", "Skaityti toliau");
define("LAN_THEME_5", "Kopijos");
define("LAN_THEME_6", "į");
define("LAN_THEME_7", "by");


?>