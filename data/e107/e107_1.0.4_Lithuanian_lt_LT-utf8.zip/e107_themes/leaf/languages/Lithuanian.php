<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|
|     $Source: /cvsroot/e107lithuanian/e107lt_vertimas/e107_themes/leaf/languages/Lithuanian.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/03/06 14:41:25 $
|     $Author: alkas $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Komentarai(s)");
define("LAN_THEME_2", "Comments are turned off for this item");
define("LAN_THEME_3", "komentarai(s)");
define("LAN_THEME_4", "Skaityti likusį ...");
define("LAN_THEME_5", "Kopijos:");
define("LAN_THEME_6", "Komentavao");
define("LAN_THEME_7", "Naujienos");


?>