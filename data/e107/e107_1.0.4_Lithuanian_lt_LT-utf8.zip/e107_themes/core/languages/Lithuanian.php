<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Lithuanian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/core/languages/Lithuanian.php $
|        $Revision: 1.0 $
|        $Id: 2013/03/18 15:57:04 $
|        $Author: Adminas $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "e107 core theme by <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>");
define("LAN_THEME_2", "Komentarai:");
define("LAN_THEME_3", "Komentarai išjungti");
define("LAN_THEME_4", "Skaityti visą istoriją");
define("LAN_THEME_5", "Kopijos:");
define("LAN_THEME_8", "į");
define("LAN_THEME_9", "nuo");
define("LAN_THEME_11", "Paskutinės naujienos");
define("LAN_THEME_12", "E-mail to a friend");
define("LAN_THEME_13", "Sukurti PDF failą");
define("LAN_THEME_14", "Spausdinti");
define("LAN_THEME_15", "Redaguoti");
define("LAN_THEME_17", "Prisijungti");
define("LAN_THEME_18", "Vartotojo vardas");
define("LAN_THEME_19", "Slaptažodis");
define("LAN_THEME_20", "Registruota");
define("LAN_THEME_21", "Prisijungimas");
define("LAN_THEME_22", "Užmiršai slaptažodį?");
define("LAN_THEME_23", "Sveiki");
define("LAN_THEME_24", "Admin");
define("LAN_THEME_26", "Nustatymai");
define("LAN_THEME_27", "Profilis");
define("LAN_THEME_28", "Atsijungti");
define("LAN_THEME_29", "Naujas lapas");
define("LAN_THEME_SING", "Prisijungti");
define("LAN_THEME_REG", "Registruotas");
define("LAN_SEARCH", "Ieškoti");
define("LAN_SEARCH_SUB", "Eiti");
define("LAN_THEME_SHARE", "Share this");
define("LAN_THEME_VER", "e107 v.");
define("CM_L13", "nuo");


?>