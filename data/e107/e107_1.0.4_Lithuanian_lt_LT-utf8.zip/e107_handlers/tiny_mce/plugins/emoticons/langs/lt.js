// LT lang variables
tinyMCE.addI18n('lt.emoticons',{
	desc : 'Įkelti šypsenėlę'
});