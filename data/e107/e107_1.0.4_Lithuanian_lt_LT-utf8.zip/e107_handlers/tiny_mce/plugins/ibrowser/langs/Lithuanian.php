<?php

$lang_ibrowser_title= 'Įkelti / Redaguoti vaizdą';
$lang_ibrowser_desc= 'Įkelti / Redaguoti vaizdą';
$lang_ibrowser_library= 'Biblioteka';
$lang_ibrowser_preview= 'Išankstinis peržiūrėjimas';
$lang_ibrowser_img_sel= 'Vaizdo pasirinkimas';
$lang_ibrowser_img_info= 'Informacija apie vaizdą';
$lang_ibrowser_img_upload= 'Vaizdo Įkrovimas į serverį';
$lang_ibrowser_images= 'Paveikslėlis';
$lang_ibrowser_src= 'Šaltinis';
$lang_ibrowser_alt= 'Aprašymas';
$lang_ibrowser_size= 'Dydis';
$lang_ibrowser_align= 'Teksto išlyginimas';
$lang_ibrowser_height= 'Aukštis';
$lang_ibrowser_width= 'Plotis';
$lang_ibrowser_reset= 'Atšaukti matmenis';
$lang_ibrowser_border= 'Kraštinė';
$lang_ibrowser_hspace= 'Horizontalus atitraukimas';
$lang_ibrowser_vspace= 'Vertikalus atitraukimas';
$lang_ibrowser_select= 'Išsaugoti';
$lang_ibrowser_delete= 'Pašalinti';
$lang_ibrowser_cancel= 'Atšaukti';
$lang_ibrowser_uploadtxt= 'failas';
$lang_ibrowser_uploadbt= 'Įkrauti į serverį';
$lang_ibrowser_marginl = 'Atitraukimas iš kairės';
$lang_ibrowser_marginr = 'Atitraukimas iš dešinės';
$lang_ibrowser_margint = 'Atitraukimas nuo viršaus';
$lang_ibrowser_marginb = 'Atitraukimas nuo apačios';
$lang_insert_image_align_default = "Pagal nutylėjimą";
$lang_insert_image_align_left = "Į kairę";
$lang_insert_image_align_right = "Į dešinę";

// error messages
$lang_ibrowser_error= 'Klaida';
$lang_ibrowser_errornoimg= 'Prašome pasirinkti paveikslėlį';
$lang_ibrowser_errornodir= 'Biblioteka neegzistuoja';
$lang_ibrowser_errorupload= 'failo įkrovimo klaida į serverį.\Pabandykite vėliau';
$lang_ibrowser_errortype= 'Neteisingas paveikslėlio failo tipas';
$lang_ibrowser_errordelete= 'Ištrynimo klaida';
$lang_ibrowser_confirmdelete= 'Paspauskite OK, kad patvirtinti paveikslėlį!';
$lang_ibrowser_error_width_nan= 'Pločio reikšmė nėra skaičius!';
$lang_ibrowser_error_height_nan= 'Aukščio reikšmė nėra skaičius!';
$lang_ibrowser_error_border_nan= 'Kraštinės reikšmė nėra skaičius!';
$lang_ibrowser_error_hspace_nan= 'Horizontalaus tarpo reikšmė nėra skaičius!';
$lang_ibrowser_error_vspace_nan= 'Vertilalaus tarpo reikšmė nėra skaičius!';

?>