// LT lang variables
tinyMCE.addI18n('lt.ibrowser',{
	desc : 'Atvaizdavimo brauzeris'
});