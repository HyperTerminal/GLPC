tinyMCE.addI18n({lt:{
common:{
edit_confirm:"Redagavimui norite naudoti vizualinį režimą?",
apply:"Išsaugoti",
insert:"Įstatyti",
update:"Atnaujinti",
cancel:"Atšaukti",
close:"Uždaryti",
browse:"Apžvalga",
class_name:"Klasė",
not_set:"-- Ne --",
clipboard_msg:"Komandos /Kopijuoti/Iškirpti/Įterpti neveikia Firefoxe. Norite sužinoti apie tai smulkiau?",
clipboard_no_support:"Nepalaiko jūsų naršyklė, naudokite klavetūrinius sutrumpinimus.",
popup_blocked:"Jūsų naršyklė užblokavo iškylantį langą, reikalingą darbui su priedu. Jums reikia atšaukti užblokuotų langų blokavimą šiame tinklalapyje, kad naudotis šiuo instrumentu.",
invalid_data:"Klaida: Reikšmės pažymėtos raudonai, įvestos neteisingai.",
more_colors:"Pasirinkti spalvą"
},
contextmenu:{
align:"Išlyginimas",
left:"Pagal kairį kraštą",
center:"Per centrą",
right:"Pagal dešinį kraštą",
full:"Pagal plotį"
},
insertdatetime:{
date_fmt:"%Y-%m-%d",
time_fmt:"%H:%M:%S",
insertdate_desc:"Įkelti datą",
inserttime_desc:"Įkelti laiką",
months_long:"sausio,vasario,kovo,balandžio,gegužės,birželio,liepos,rugpjūčio,rugsėjo,spalio,lapkričio,gruodžio",
months_short:"sau,vas,kov,bal,geg,bir,lie,rgp,gug,spa,lap,gru",
day_long:"sekmadieni,pirmadienis,antradienis,trečiadienis,ketvirtadienis,penktadienis,šeštadienis,sekmadienis",
day_short:"sk,pr,an,tr,kt,pn,šš,sk"
},
print:{
print_desc:"Spausdinimas"
},
preview:{
preview_desc:"Pirminė peržiūra"
},
directionality:{
ltr_desc:"Nukreipimas iš kairės į dešinę",
rtl_desc:"Nukreipimas iš dešinės į kairę"
},
layer:{
insertlayer_desc:"Įstatyti naują sluoksnį",
forward_desc:"Į priekį",
backward_desc:"Atgal",
absolute_desc:"Įjn./atjng. absoliutų pozicionavimą",
content:"Naujas sluoksnis"
},
save:{
save_desc:"Išsaugoti",
cancel_desc:"Atšaukti"
},
nonbreaking:{
nonbreaking_desc:"Įstatyti iškirptą tarpą"
},
iespell:{
iespell_desc:"Patikrinti orfografiją",
download:"Orfografijos patikrinimo komponentas nerastas. Nustatyti?"
},
advhr:{
advhr_desc:"Horizontali linija"
},
emotions:{
emotions_desc:"Šypsenėlės"
},
searchreplace:{
search_desc:"Rasti",
replace_desc:"Rasti ir pakeisti"
},
advimage:{
image_desc:"Įstatyti/redaguoti vaizdą"
},
advlink:{
link_desc:"ВĮstatyti/redaguoti nuorodą"
},
xhtmlxtras:{
cite_desc:"Citata",
abbr_desc:"Abrevetūra",
acronym_desc:"Akronim",
del_desc:"Panaikintas tekstas",
ins_desc:"Pridėtas tekstas",
attribs_desc:"Įkelti/redaguoti atributus"
},
style:{
desc:"Apipavidalinimo stilius"
},
paste:{
paste_text_desc:"Įkelti tik tekstą",
paste_word_desc:"Įkelti iš WORDo",
selectall_desc:"Pažymėti viską"
},
paste_dlg:{
text_title:"Kombinuotas klavišas Ctrl+V, teksto įkėlimui.",
text_linebreaks:"Išsaugoti linijų tarpus",
word_title:"Kombinuotas klavišas Ctrl+V, teksto įkėlimui."
},
table:{
desc:"Įkelti lentelę",
row_before_desc:"Ikelti eilutę iki",
row_after_desc:"Ikelti eilutę po",
delete_row_desc:"Pašalinti eilutę",
col_before_desc:"Įkelti stulpelį iki",
col_after_desc:"Įkelti stulpelį po",
delete_col_desc:"Pašalinti stulpelį",
split_cells_desc:"Padalinti celę",
merge_cells_desc:"Apjungti celę",
row_desc:"Eilutės įpatybės",
cell_desc:"Celės įpatybės",
props_desc:"Lentelės įpatybės",
paste_row_before_desc:"Įkelti eilutę lentelėje iki",
paste_row_after_desc:"Įkelti eilutę lentelėje po",
cut_row_desc:"Iškirpti eilutę",
copy_row_desc:"Kopijuoti eilutę",
del:"Pašalinti lentelę",
row:"Eilutė",
col:"Stulpelis",
cell:"Celė"
},
autosave:{
unload_msg:"padaryti pakeitimai dings, jeigu jūs išeisite iš šio puslapio."
},
fullscreen:{
desc:"Įjn./išj. pilno ekrano režimą"
},
media:{
desc:"Įkelti/redaguoti media objektą",
edit:"Redaguoti media objektą"
},
fullpage:{
desc:"Dokumento savybės"
},
template:{
desc:"Įkelti paruoštą šabloną"
},
visualchars:{
desc:"Vizualinės kontrolės simboliai įjn./išj."
},
spellchecker:{
desc:"Orfografijos patikrinimas",
menu:"Orfografijos patikrinimo parametrai",
ignore_word:"Ignoruoti žodį",
ignore_words:"Ignoruoti viską",
langs:"Kalbos",
wait:"Prašome palaukti...",
sug:"Variantai",
no_sug:"Nėra variantų",
no_mpell:"Klaidų neaptikta."
},
pagebreak:{
desc:"Įkelti puslapio skyriklį."
}}});