﻿// English lang variables
tinyMCE.addToLang('ibrowser', {
title: 'Resim ekle/Düzenle',
desc:  'Resim Ekleme'
});
