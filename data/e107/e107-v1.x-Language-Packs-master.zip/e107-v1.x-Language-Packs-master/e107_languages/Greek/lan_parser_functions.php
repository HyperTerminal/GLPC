<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_parser_functions.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Επισκέπτης");
define("LAN_WROTE", "έγραψε"); // as in John wrote.."  ";


?>