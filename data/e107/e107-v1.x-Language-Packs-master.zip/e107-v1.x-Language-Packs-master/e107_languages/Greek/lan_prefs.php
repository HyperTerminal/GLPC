<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_prefs.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://e107gr.com by Gatakia $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "Δημιουργός Ιστοσελίδας e107gr.com ");
define("LAN_PREF_2", "Σύστημα Ιστοσελίδας e107 CMS ");
define("LAN_PREF_3", "Αυτή η ιστοσελίδα δημιουργήθηκε από <a href=&quot;http://e107gr.com/&quot; rel=&quot;external&quot;>e107gr</a>, το οποίο κυκλοφορεί από <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, υπό τους όρους <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> Άδειας GPL.");
define("LAN_PREF_4", "λογοκρίθηκε");
define("LAN_PREF_5", "Συζητήσεις");

?>