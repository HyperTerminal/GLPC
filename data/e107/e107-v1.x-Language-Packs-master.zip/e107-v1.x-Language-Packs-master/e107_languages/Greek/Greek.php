<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/Greek.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/01 14:30:25 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
setlocale(LC_ALL,'gr_GR.UTF-8', 'el_GR.utf8');
define("CORE_LC", "el");
define("CORE_LC2", "el");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Σφάλμα : Το θέμα λείπει \\n\\nΤροποποίηση των θεμάτων που χρησιμοποιούνται στις προτιμήσεις σας (admin περιοχή) ή να φορτώσετε τα αρχεία του τρέχοντος θέματος στο διακομιστή..");
define("CORE_LAN4", "Παρακαλώ κάντε απεγκατάσταση του.php από τον διακομιστή σας");
define("CORE_LAN5", "αν δεν υπάρχει ενδεχόμενος κίνδυνος για την ασφάλεια στον ιστοχώρο σας");
define("CORE_LAN6", "Η flood ...πληθώρα εσκεμμένων μηνυμάτων... έχει ενεργοποιηθεί σε αυτή την ιστοσελίδα και θα προειδοποιηθείτε και σε περίπτωση που δεν συμμορφωθείτε θα σας απαγορευτεί η είσοδος .");
define("CORE_LAN7", "Ο πυρήνας σας προσπαθεί να αποκαταστήσει τις επιλογές σας από την αυτόματη δημιουργία αντιγράφων.");
define("CORE_LAN8", "Πυρήνας Επιλογών Λάθος");
define("CORE_LAN9", "Ο πυρήνας δεν μπόρεσε να αποκατασταθεί από την αυτόματη δημιουργία αντιγράφων. Εκτέλεση σταμάτησε.");
define("CORE_LAN10", "Κατεστραμμένο cookie έχει ανιχνευθεί - έξοδος.");
define("CORE_LAN11", "Χρόνος Ανταπόδοσης:");
define("CORE_LAN12", " δευτ,");
define("CORE_LAN13", " για τα ερωτήματα.");
define("CORE_LAN14", "");
define("CORE_LAN15", "DB ερωτήματα:");
define("CORE_LAN16", "Μνήμη χρήσης:");
define("CORE_LAN17", "[ εικόνα απενεργοποιημένη ]");
define("CORE_LAN18", "Εικόνα:");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "kB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "Προειδοποίηση!");
define("LAN_ERROR", "Λάθος");
define("LAN_ANONYMOUS", "Ανώνυμος");
define("LAN_EMAIL_SUBS", "-ηλεκτρονική διεύθυνση-");
define("LAN_SANITISED", "SANITISED");


?>