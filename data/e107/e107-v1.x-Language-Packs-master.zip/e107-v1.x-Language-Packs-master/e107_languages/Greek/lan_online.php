<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_online.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "Επισκέπτες: 1");
define("ONLINE_EL2", "Μέλη: ");
define("ONLINE_EL3", "Σε αυτή τη σελίδα: ");
define("ONLINE_EL4", "Σε σύνδεση");
define("ONLINE_EL5", "Συνολο ");
define("ONLINE_EL6", "Το νεο μας μελισσακι ειναι ο/η ");
define("ONLINE_EL7", "βλέπει");
define("ONLINE_EL8", "περισσότεροι χρήστες σε σύνδεση: 1");
define("ONLINE_EL9", "σε σύνδεση");
define("ONLINE_EL10", "Όνομα Μέλους");
define("ONLINE_EL11", "Είναι στη σελίδα");
define("ONLINE_EL12", "Απάντηση");
define("ONLINE_EL13", "Φόρουμ");
define("ONLINE_EL14", "Θέμα");
define("ONLINE_EL15", "Σελίδα");
define("CLASSRESTRICTED", "Περιορισμένης πρόσβασης σελίδα");
define("ARTICLEPAGE", "Άρθρο/Κριτική");
define("CHAT", "Chat");
define("COMMENT", "Σχόλια");
define("DOWNLOAD", "Λήψεις");
define("EMAIL", "email.php");
define("FORUM", "Κύριο Ευρετήριο Φόρουμ");
define("LINKS", "Σύνδεσμοι");
define("NEWS", "Νέα");
define("OLDPOLLS", "Παλιές Δημοσκοπήσεις");
define("POLLCOMMENT", "Δημοσκόπηση");
define("PRINTPAGE", "Εκτύπωση");
define("LOGIN", "Συνδεθείτε");
define("SEARCH", "Αναζήτηση");
define("STATS", "Στατιστικά της Ιστοσελίδας");
define("SUBMITNEWS", "Υποβολή Νέων");
define("UPLOAD", "Ανέβασμα αρχείων");
define("USERPAGE", "Προφίλ Χρήστη");
define("USERSETTINGS", "Ρυθμίσεις Χρήστη");
define("ONLINE", "Χρήστες σε σύνδεση");
define("LISTNEW", "Λίστα Νέων Θεμάτων");
define("USERPOSTS", "Άρθρα Χρήστη");
define("SUBCONTENT", "Υποβολή Άρθρο/Σχόλιο");
define("TOP", "Δημοφιλής Χρήστες/Δημοφιλή Άρθρα");
define("ADMINAREA", "Περιοχή Διαχειριστή");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Κατάλογος Εκδηλώσεων");
define("CALENDAR", "Ημερολόγιο");
define("FAQ", "Κανονισμοί");
define("PM", "Προσωπικά Μηνύματα");
define("SURVEY", "Έρευνα");
define("ARTICLE", "Άρθρο");
define("CONTENT", "Περιεχόμενα Σελίδας");
define("REVIEW", "Κριτική");

?>