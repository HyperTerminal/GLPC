<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_userposts.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Αναρτήσεις Χρήστη");

define("UP_LAN_0", "Όλες οι Αναρτήσεις για ");
define("UP_LAN_1", "Όλα τα Σχόλια για ");
define("UP_LAN_2", "Θέματα");
define("UP_LAN_3", "Προβολές");
define("UP_LAN_4", "Απαντήσεις");
define("UP_LAN_5", "Τελευταία ανάρτηση");
define("UP_LAN_6", "Θέματα");
define("UP_LAN_7", "Κανένα Σχόλιο");
define("UP_LAN_8", "Καμμία Ανάρτηση");
define("UP_LAN_9", " ανοικτό ");
define("UP_LAN_10", "Απ:");
define("UP_LAN_11", "Καταχωρήθηκε στο");
define("UP_LAN_12", "Αναζήτηση");
define("UP_LAN_13", "Σχόλια");
define("UP_LAN_14", "Θέματα Φόρουμ");
define("UP_LAN_15", "Απ:");
define("UP_LAN_16", "IP Διεύθυνση");
?>