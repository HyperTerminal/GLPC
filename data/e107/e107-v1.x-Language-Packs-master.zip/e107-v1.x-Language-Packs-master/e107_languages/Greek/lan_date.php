<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_date.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "χρόνος");
define("LANDT_02", "μήνας");
define("LANDT_03", "εβδομάδα");
define("LANDT_04", "ημέρα");
define("LANDT_05", "ώρα");
define("LANDT_06", "λ");
define("LANDT_07", "δ");
define("LANDT_01s", "χρόνια");
define("LANDT_02s", "μήνες");
define("LANDT_03s", "εβδομάδες");
define("LANDT_04s", "ημέρες");
define("LANDT_05s", "ώρες");
define("LANDT_06s", "λ");
define("LANDT_07s", "δ");

define("LANDT_08", "λ");
define("LANDT_08s", "λ");
define("LANDT_09", "δ");
define("LANDT_09s", "δ");
define("LANDT_AGO", "πριν");


?>