<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_banner.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");

define("BANNERLAN_16", "Όνομα χρήστη: ");
define("BANNERLAN_17", "Κωδικός: ");
define("BANNERLAN_18", "Συνέχεια");
define("BANNERLAN_19", "Παρακαλώ πληκτρολογείστε το όνομα πελάτη και τον κωδικό εισόδου στο site");
define("BANNERLAN_20", "Συγγνώμη, αδύνατον να βρεθούν αυτά τα στοιχεία στη βάση δεδομένων. Παρακαλώ επικοινωνήστε με τους διαχειριστές του site για περισσότερες λεπτομέρειες.");
define("BANNERLAN_21", "Banners Στατιστικά");
define("BANNERLAN_22", "Πελάτης");
define("BANNERLAN_23", "Banner Ταυτότητα");
define("BANNERLAN_24", "Αναλογία κλικ");
define("BANNERLAN_25", "Κλικ %");
define("BANNERLAN_26", "Εντυπώσεις");
define("BANNERLAN_27", "Πραγματοποίηση Αγοράς");
define("BANNERLAN_28", "Κλείσιμο Σελίδας");
define("BANNERLAN_29", "No banners");
define("BANNERLAN_30", "Απεριόριστο");
define("BANNERLAN_31", "Δεν ισχύει");
define("BANNERLAN_32", "Ναι");
define("BANNERLAN_33", "Όχι");
define("BANNERLAN_34", "Άκρα:");
define("BANNERLAN_35", "Αναλογία κλικ σε IP διευθύνσεις");
define("BANNERLAN_36", "Ενεργό:");
define("BANNERLAN_37", "Αρχή:");
define("BANNERLAN_38", "Λάθος");

?>