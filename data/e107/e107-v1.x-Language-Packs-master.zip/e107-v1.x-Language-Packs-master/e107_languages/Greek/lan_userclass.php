<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Όλοι (κοινό)");
define("UC_LAN_1", "Επισκέπτες");
define("UC_LAN_2", "Κανένας (ανενεργό)");
define("UC_LAN_3", "Μέλη");
define("UC_LAN_4", "Μόνο Ανάγνωση");
define("UC_LAN_5", "Διαχειριστές");
define("UC_LAN_6", "Κύριος Διαχειριστής");
?>