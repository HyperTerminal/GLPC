<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "ψήφος");
define("RATELAN_1", "ψήφοι");
define("RATELAN_2", "πως αξιολογείτε αυτό το στοιχείο;");
define("RATELAN_3", "ευχαριστούμε για την ψήφο σας");
define("RATELAN_4", "δεν αξιολογήθηκε");
define("RATELAN_5", "Αξιολόγηση");

?>