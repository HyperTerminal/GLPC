<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Εκτυπώσιμη"); }

define("LAN_PRINT_86", "Κατηγορία:");
define("LAN_PRINT_87", "από ");
define("LAN_PRINT_94", "Αναρτήθηκε από");
define("LAN_PRINT_135", "Νέα Στοιχεία: ");
define("LAN_PRINT_303", "Αυτό το νέο στοιχείο είναι από ");
define("LAN_PRINT_304", "Τίτλος: ");
define("LAN_PRINT_305", "Υπότιτλος: ");
define("LAN_PRINT_306", "Αυτό είναι από: ");
define("LAN_PRINT_307", "Εκτύπωση σελίδας");

define("LAN_PRINT_1", "εκτυπώσιμη");


?>