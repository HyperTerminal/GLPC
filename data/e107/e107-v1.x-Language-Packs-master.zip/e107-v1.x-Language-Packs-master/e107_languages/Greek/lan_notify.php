<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_notify.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Εγγραφή Χρήστη");

define("NT_LAN_UV_1", "Επιβεβαίωση Εγγραφής Χρήστη");
define("NT_LAN_UV_2", "Ταυτότητα Χρήστη: ");
define("NT_LAN_UV_3", "Όνομα Εισόδου Χρήστη: ");
define("NT_LAN_UV_4", "Χρήστη IP: ");


define("NT_LAN_LI_1", "Είσοδος Χρήστη");

define("NT_LAN_LO_1", "Έξοδος Χρήστη");
define("NT_LAN_LO_2", " Αποσυνδέθηκε από την ιστοσελίδα");

define("NT_LAN_FL_1", "Flood Ban");
define("NT_LAN_FL_2", "Η IP διεύθυνση απαγορεύτηκε για flooding");

define("NT_LAN_SN_1", "Νέο Στοιχείο Προστέθηκε");

define("NT_LAN_NU_1", "Ενημερώθηκε");

define("NT_LAN_ND_1", "Νέα Στοιχεία Διαγράφηκαν");
define("NT_LAN_ND_2", "Ταυτότητα διαγραμμένων νέων στοιχείων");

?>