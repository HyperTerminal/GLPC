<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_membersonly.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Μέλη μόνο");

define("LAN_MEMBERS_0", "Απαγορευμένη περιοχή");
define("LAN_MEMBERS_1", "Αυτή είναι απαγορευμένη περιοχή.");
define("LAN_MEMBERS_2","Για είσοδο πρέπει να  <a href='".e_LOGIN."'>Συνδεθείτε</a>");
define("LAN_MEMBERS_3","ή να κάνετε <a href='".e_SIGNUP."'>Εγγραφή</a> σαν μέλος");
define("LAN_MEMBERS_4","Κάντε κλικ εδώ για να επιστρέψετε στην κεντρική σελίδα");


?>