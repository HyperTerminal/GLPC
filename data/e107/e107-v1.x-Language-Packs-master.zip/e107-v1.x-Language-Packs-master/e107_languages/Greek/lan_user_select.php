<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_user_select.php,v $
|     $Revision: 0.1 $
|     $Date: 2010-06-21 21:34:14 -0500  (((Δευτερα 21 Ιουνιου 2010))) $
|     $Author: Http://gatakia.com by Limontselo $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Επιλέξτε χρήστη");
define("US_LAN_2", "Επιλέξτε κλάση χρήστη");
define("US_LAN_3", "Όλοι οι χρήστες");
define("US_LAN_4", "Βρες όνομα χρήστη");
define("US_LAN_5", "Χρήστης(ες) βρέθηκαν");
define("US_LAN_6", "Αναζήτηση");
?>