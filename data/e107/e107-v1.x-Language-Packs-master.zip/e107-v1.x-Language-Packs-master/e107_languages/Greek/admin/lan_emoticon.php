<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_emoticon.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/01 17:47:36 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("EMOLAN_1", "Ενεργοποίηση εικονιδίων/Emotes");
define("EMOLAN_2", "Όνομα");
define("EMOLAN_3", "Εικονίδια/Emotes");
define("EMOLAN_4", "Ενεργοποίηση εικονιδίων/emoticons;");
define("EMOLAN_5", "Εικόνα");
define("EMOLAN_6", "κώδικας εικονιδίου/Emote");
define("EMOLAN_7", "διαχωρίζετε πολλαπλές καταχωρήσεις με διαστήματα");
define("EMOLAN_8", "Κατάσταση");
define("EMOLAN_9", "Επιλογές");
define("EMOLAN_10", "Ενεργό");
define("EMOLAN_11", "Ενεργοποίηση πακέτου");
define("EMOLAN_12", "Επεξεργασία / διαμορφώσετε αυτό το πακέτο");
define("EMOLAN_13", "Εγκατεστημένα πακέτα εικονιδίων");
define("EMOLAN_14", "Αποθήκειση παραμέτρων");
define("EMOLAN_15", "Επεξεργασία / ρύθμιση εικονιδιων/emotes");
define("EMOLAN_16", "Οι παράμετροι των εικονιδίων/emote αποθηκεύτηκαν");
define("EMOLAN_17", "Έχετε σε χρήση πακέτο εικονιδίων/ emoticon που
περιέχει κενά διαστήματα στην ονομασία, τα οποία δεν επιτρέπονται!");
define("EMOLAN_18", "παρακαλούμε να μετονομάσετε τις περιπτώσεις που αναφέρονται παρακάτω, ώστε να μην περιέχουν κενά διαστήματα:");
define("EMOLAN_19", "Όνομα");
define("EMOLAN_20", "Τοποθεσία");
define("EMOLAN_21", "Σφάλμα");
define("EMOLAN_22", "Νέα πακέτα εικονιδίων/emote που βρέθηκαν:");
define("EMOLAN_23", "Νέα πακετα εικονιδίων/emote  xml που βρέθηκαν :");
define("EMOLAN_24", "Νέα εικονίδια/emote php που βρέθηκαν :");
define("EMOLAN_25", "Εγκατάσταση νέων εικονιδίων/emotes PHP:");
define("EMOLAN_26", "Επανασάρωση για πακέτα");
define("EMOLAN_27", "Παρουσιάστηκε σφάλμα επεξεργασίας συσκευασίας:");
define("EMOLAN_28", "Δημιουργία XML");
define("EMOLAN_29", "Αρχείο XML που δημιουργήθηκε:");
define("EMOLAN_30", "Σφάλμα κατά την εγγραφή αρχείου XML:");


?>