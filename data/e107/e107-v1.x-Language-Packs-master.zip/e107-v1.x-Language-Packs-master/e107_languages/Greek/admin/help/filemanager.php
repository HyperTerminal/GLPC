<?php

/*
+---------------------------------------------------------------+
| e107 website system Greek Language File
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
|
| $URL: ../e107_languages/Greek/admin/help/filemanager.php $
| $Revision: 1.0 $
| $Id: 2011/03/01 18:41:25 $
| $Author: e107gr.com $
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Είστε σε θέση να διαχειρίζεστε τα αρχεία στον κατάλογο η τα αρχεία σας από αυτήν τη σελίδα. Εάν λαμβάνετε ένα μήνυμα σφάλματος σχετικά με τα δικαιώματα κατά τη μεταφόρτωση, παρακαλούμε CHMOD τον κατάλογο που προσπαθείτε να φορτώσετε σε 777.";
$ns -> tablerender("Βοήθεια Αρχείου Διαχείρισής", $text);
?>