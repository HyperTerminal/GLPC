<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_db_verify.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/01 15:19:19 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("DBLAN_1", "Αδύνατο να διαβαστεί το sql αρχείο δεδομένων<br /><br />Παρακαλούμε βεβαιωθείτε ότι το αρχείο <b>core_sql.php</b> υπάρχει στον<b>/admin/sql</b> κατάλογο.");
define("DBLAN_2", "Επαλήθευση όλων");
define("DBLAN_4", "Πίνακας");
define("DBLAN_5", "Τομέας");
define("DBLAN_6", "Κατάσταση");
define("DBLAN_7", "Σημειώσεις");
define("DBLAN_8", "Ασυμφωνία");
define("DBLAN_9", "Σήμερα");
define("DBLAN_10", "Θα πρέπει να");
define("DBLAN_11", "Το πεδίο λείπει");
define("DBLAN_12", "Επιπλέον πεδίο!");
define("DBLAN_13", "Πίνακας λείπει!");
define("DBLAN_14", "Επιλέξτε Πίνακα(-ες) για την επικύρωση");
define("DBLAN_15", "Έναρξη Επαλήθευσης");
define("DBLAN_16", "SQL Επαλήθευση");
define("DBLAN_17", "Επιστροφή");
define("DBLAN_18", "πίνακες");
define("DBLAN_19", "Προσπάθεια να Διόρθωση");
define("DBLAN_20", "Προσπαθώντας να καθορισμό πινάκων");
define("DBLAN_21", "Διόρθωση σε επιλεγμένα αντικείμενα");
define("DBLAN_22", "δεν είναι αναγνώσιμο");


?>