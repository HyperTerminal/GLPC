<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_userinfo.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/21 20:16:59 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/

define("USFLAN_1", "Αδύνατον να βρεθεί η διεύθυνση IP του Συγγραφέα - δεν υπάρχουν διαθέσιμες πληροφορίες.");
define("USFLAN_3", "Τα Μηνύματα ταχυδρομήθηκαν από τη διεύθυνση IP");
define("USFLAN_4", "Πάροχος");
define("USFLAN_5", "Πατήστε εδώ για να μεταφέρετε αυτήν την IP διεύθυνση στη σελίδα διαχείρησης αποκλεισμού");
define("USFLAN_6", "Χρήστης Ταυτότητα/ID");
define("USFLAN_7", "Πληροφορίες χρήστη");


?>