<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_filemanager.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/01 18:41:25 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("FMLAN_1", "Ανέβηκαν");
define("FMLAN_2", "στον");
define("FMLAN_3", "κατάλογο");
define("FMLAN_4", "Το αρχείο υπερβαίνει το μέγιστο μέγεθος/upload_max_filesize οδηγίας στο php.ini.");
define("FMLAN_10", "Σφάλμα");
define("FMLAN_12", "αρχείο");
define("FMLAN_13", "αρχεία");
define("FMLAN_14", "κατάλογος");
define("FMLAN_15", "κατάλογοι");
define("FMLAN_16", "Κατάλογος Ρίζας");
define("FMLAN_17", "Όνομα");
define("FMLAN_18", "Μέγεθος");
define("FMLAN_19", "Τελευταία Τροποποίηση");
define("FMLAN_21", "Φορτώστε το αρχείο σε αυτό τον κατάλογο/ dir");
define("FMLAN_22", "Ανεβάστε");
define("FMLAN_26", "Διαγράφηκε");
define("FMLAN_27", "με επιτυχία");
define("FMLAN_28", "Αδύνατον να διαγραφεί");
define("FMLAN_29", "Μονοπάτι");
define("FMLAN_30", "Επίπεδο πάνω");
define("FMLAN_31", "φάκελος");
define("FMLAN_32", "Επιλέξτε Κατάλογο");
define("FMLAN_33", "Επιλέξτε");
define("FMLAN_34", "Επιλογή Καταλόγου");
define("FMLAN_35", "Αρχεία Καταλόγου");
define("FMLAN_36", "Προσαρμοζόμενα Μενού Καταλόγων");
define("FMLAN_37", "Προσαρμοζόμενες Σελίδες Καταλόγων");
define("FMLAN_38", "Μετακινήθηκε με επιτυχία το αρχείο στο");
define("FMLAN_39", "Αδύνατό να μετακινήσετε το αρχείο σε");
define("FMLAN_40", "Νέο Καταχώρησή Καταλόγου Εικόνων");
define("FMLAN_43", "Διαγραφή επιλεγμένων αρχείων");
define("FMLAN_46", "Επιβεβαιώστε ότι θέλετε να διαγράψετε τα επιλεγμένα αρχεία.");
define("FMLAN_47", "Φορτώσεις/Uploads Χρήστη");
define("FMLAN_48", "Μετακίνηση επιλεγμένων σε");
define("FMLAN_49", "Επιβεβαιώστε οτι επιθυμείτε να μετακινήσετε τα επιλεγμένα αρχεία.");
define("FMLAN_50", "Μετακίνηση");
define("FMLAN_51", "Άγνωστο σφάλμα:");


?>