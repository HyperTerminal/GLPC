<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_footer.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/02 16:31:34 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("FOOTLAN_1", "Ιστοσελίδα");
define("FOOTLAN_2", "Κύριός Διαχειριστής");
define("FOOTLAN_3", "Έκδοση");
define("FOOTLAN_4", "κατασκευή");
define("FOOTLAN_5", "Τρέχων Θέμα");
define("FOOTLAN_6", "από");
define("FOOTLAN_7", "Πληροφορίες");
define("FOOTLAN_8", "Hμερομηνία Εγκατάστασης");
define("FOOTLAN_9", "Διακομιστής (Server)");
define("FOOTLAN_10", "κόμβος (Host)");
define("FOOTLAN_11", "PHP Έκδοση");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Πληροφορίες Ιστοσελίδας");
define("FOOTLAN_14", "Προβολή Εγγράφων");
define("FOOTLAN_15", "Τεκμηρίωση");
define("FOOTLAN_16", "Βάση δεδομένων");
define("FOOTLAN_17", "Κωδικοποίηση χαρακτήρων");
define("FOOTLAN_18", "Θέμα Ιστοσελίδας");
define("FOOTLAN_19", "Τρέχουσα ώρα του διακομιστή");
define("FOOTLAN_20", "Επίπεδο ασφαλείας");


?>