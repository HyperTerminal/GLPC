<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: ../e107_languages/Greek/admin/admin/lan_message.php $
|     $Revision: 1.0 $
|     $Id: lan_message.php 1.0 2011/03/04 00:43:45Z e107gr.com $
|     $Author: e107gr.com $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Ληφθέντα μηνύματα");
define("MESSLAN_2", "Διαγραφή μηνύματος");
define("MESSLAN_3", "Μήνυμα Διαγράφηκε.");
define("MESSLAN_4", "Διαγραφή όλων των μηνυμάτων");
define("MESSLAN_5", "Επιβεβαίωση");
define("MESSLAN_6", "Όλα τα μηνύματα που διαγράφτηκαν.");
define("MESSLAN_7", "Δεν υπάρχουν μηνύματα.");
define("MESSLAN_8", "Τύπος μηνύματος");
define("MESSLAN_9", "Αναφέρθηκε στις");
define("MESSLAN_10", "Υποβλήθηκε από");
define("MESSLAN_11", "ανοίγει σε νέο παράθυρο");
define("MESSLAN_12", "Μήνυμα");
define("MESSLAN_13", "Σύνδεσμος");


?>