<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_e107_update.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/01 17:39:25 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Δράση");
define("LAN_UPDATE_3", "Δεν χρειάζεται");
define("LAN_UPDATE_5", "Διαθέσιμες Ενημερώσεις");
define("LAN_UPDATE_7", "Εκτελέστηκε");
define("LAN_UPDATE_8", "Ενημέρωση από το");
define("LAN_UPDATE_9", "σε");
define("LAN_UPDATE_10", "Διαθέσιμες Ενημερώσεις");
define("LAN_UPDATE_11", ".617 to .7 Συνέχειας Ενημέρωσης");
define("LAN_UPDATE_12", "Ένας από τους πίνακες σας περιέχει διπλές καταχωρήσεις.");


?>