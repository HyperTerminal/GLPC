<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: ../e107_languages/Greek/admin/admin/lan_modcomment.php $
|     $Revision: 1.0 $
|     $Id: lan_modcomment.php 1.0 2011/03/04 00:43:45Z e107gr.com $
|     $Author: e107gr.com $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Συντονίστηκε.");
define("MDCLAN_2", "Δεν υπάρχουν σχόλια για αυτό το αντικείμενο");
define("MDCLAN_3", "Μέλη");
define("MDCLAN_4", "Επισκέπτης");
define("MDCLAN_5", "απεμπλοκή");
define("MDCLAN_6", "εμπλοκή");
define("MDCLAN_8", "Συντονισμός Σχολίων");
define("MDCLAN_9", "Προσοχή! Διαγράφοντας το μητρικό άρθρο,  θα διαγράψετε επίσης και όλες τις απαντήσεις που έχουν αναρτηθεί σε αυτο!");
define("MDCLAN_10", "Επιλογές");
define("MDCLAN_11", "σχόλιο");
define("MDCLAN_12", "σχόλια");
define("MDCLAN_13", "μπλοκαρισμένο");
define("MDCLAN_14", "κλείδωμα σχολίων");
define("MDCLAN_15", "ανοικτό");
define("MDCLAN_16", "κλειδωμένο");
define("MDCLAN_17", "");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>