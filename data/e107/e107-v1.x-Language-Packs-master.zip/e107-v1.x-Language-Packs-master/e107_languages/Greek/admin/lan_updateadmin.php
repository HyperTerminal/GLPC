<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: ../e107_languages/Greek/admin/admin/lan_updateadmin.php $
|     $Revision: 1.0 $
|     $Id: lan_updateadmin.php 1.0 2011/03/04 00:43:45Z e107gr.com $
|     $Author: e107gr.com $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Σφάλμα - παρακαλώ κάντε υποβολή εκ νέου");
define("UDALAN_2", "Ρυθμίσεις ενημερώθηκαν");
define("UDALAN_3", "Οι Ρυθμίσεις ενημερώθηκαν για");
define("UDALAN_4", "Όνομα");
define("UDALAN_5", "Κωδικό Πρόσβασης");
define("UDALAN_6", "Επαναπληκτρολογείστε τον Κωδικό Πρόσβασης");
define("UDALAN_7", "Αλλαγή κωδικού");
define("UDALAN_8", "Ο Κωδικός πρόσβασης ενημερώθηκε για");


?>