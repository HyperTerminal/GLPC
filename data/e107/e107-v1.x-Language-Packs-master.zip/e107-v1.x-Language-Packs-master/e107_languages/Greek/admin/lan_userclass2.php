<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_userclass2.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/21 20:22:08 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("UCSLAN_1", "Αφαιρέθηκαν όλοι οι χρήστες από την κλάση.");
define("UCSLAN_2", "Η Κλάση χρηστών ενημερώθηκε.");
define("UCSLAN_3", "Η Κλάση διαγράφηκε.");
define("UCSLAN_4", "Παρακαλούμε τσεκάρετε το πλαίσιο για επιβεβαίωση της διαγραφής αυτής της κλάσης χρηστών");
define("UCSLAN_5", "Η Κλάση ενημερώθηκε.");
define("UCSLAN_6", "Η Κλάση αποθηκεύτηκε στη βάση δεδομένων.");
define("UCSLAN_7", "Δεν υπάρχουν κλάσεις ακόμα.");
define("UCSLAN_8", "Υπάρχουσες Κλάσεις");
define("UCSLAN_11", "τσεκάρετε για επιβεβαίωση");
define("UCSLAN_12", "Όνομα Κλάσης");
define("UCSLAN_13", "Περιγραφή Κλάσης");
define("UCSLAN_14", "Ενημερώθηκε η Κλάση Χρήστη");
define("UCSLAN_15", "Δημιουργία Νέας Κλάσης");
define("UCSLAN_16", "Αντιστοίχηση των χρηστών στην κλάση");
define("UCSLAN_17", "Κατάργηση");
define("UCSLAN_18", "Καθαρισμός Κλάσης");
define("UCSLAN_19", "Αντιστοίχηση χρηστών σε");
define("UCSLAN_20", "κλάση");
define("UCSLAN_21", "Ρυθμίσεις Κλάσης Χρηστών");
define("UCSLAN_22", "Χρήστης - κάντε κλικ για μετακίνηση ...");
define("UCSLAN_23", "Οι χρήστες αυτής τηςκλάσης ...");
define("UCSLAN_24", "Ποιος μπορεί να διαχειριστεί την κλάση");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Όνομα Χρήστη");
define("UCSLAN_27", "Επιστροφή");


?>