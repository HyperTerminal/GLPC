<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_wmessage.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/21 15:54:33 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/

define("WMLAN_00", "Χαιρετισμοί");
define("WMLAN_01", "Δημιουργία νέου μηνύματος");
define("WMLAN_02", "Μήνυμα");
define("WMLAN_03", "Ορατότητα");
define("WMLAN_04", "Μήνυμα κειμένου");
define("WMLAN_05", "Κλείσε");
define("WMLAN_06", "Εάν σημειώνεται, το μήνυμα θα δοθεί μέσα στο κιβώτιο");
define("WMLAN_07", "Τυποποιημένο σύστημα συμπληρωματικής προμήθειας στη χρήση {WMESSAGE} σύντομου κώδικα:");
define("WMLAN_09", "Κανένα καθορισμένο ευπρόσδεκτο μήνυμα ακόμα");
define("WMLAN_10", "Τίτλος μηνυμάτων");


?>