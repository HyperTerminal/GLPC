<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: ../e107_languages/Greek/admin/admin/lan_admin_log.php $
|     $Revision: 1.0 $
|     $Id: lan_admin_log.php 1.0 2011/03/04 00:43:45Z e107gr.com $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Σύνδεση Διαχειριστή");
define("LAN_ADMINLOG_1", "Ημερομηνία");
define("LAN_ADMINLOG_2", "Τίτλος");
define("LAN_ADMINLOG_3", "Περιγραφή");
define("LAN_ADMINLOG_4", "Χρήστη ΙΡ");
define("LAN_ADMINLOG_5", "Αναγνωριστική Ταυτότητα/ID χρήστη");
define("LAN_ADMINLOG_6", "Ενημερωτική εικονίδιο");
define("LAN_ADMINLOG_7", "Ενημερωτικό Μήνυμα");
define("LAN_ADMINLOG_8", "Εικονίδιο Ανακοίνωσης");
define("LAN_ADMINLOG_9", "Ανακοίνωση Μήνυμα");
define("LAN_ADMINLOG_10", "Εικονίδιο Προειδοποίησης");
define("LAN_ADMINLOG_11", "Προειδοποίηση Μήνυμα");
define("LAN_ADMINLOG_12", "Μοιραίο Εικονίδιο");
define("LAN_ADMINLOG_13", "Μοιραίο Μήνυμα Λάθους");


?>