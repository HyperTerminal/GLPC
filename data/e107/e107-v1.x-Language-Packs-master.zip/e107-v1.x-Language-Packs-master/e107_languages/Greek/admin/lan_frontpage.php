<?php
/*
+---------------------------------------------------------------+
|        e107 website system Greek Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Greek/admin/lan_frontpage.php $
|        $Revision: 1.0 $
|        $Id: 2011/03/02 16:51:18 $
|        $Author: e107gr.com $
+---------------------------------------------------------------+
*/
define("FRTLAN_1", "Ανανεώθηκε η ρύθμιση της Κεντρικής Σελίδας .");
define("FRTLAN_2", "Ορισμός της κεντρικής σελίδας για");
define("FRTLAN_6", "Σύνδεσμοι");
define("FRTLAN_12", "Ενημέρωση ρυθμίσεων της Κεντρικής Σελίδας");
define("FRTLAN_13", "Ρυθμίσεις Κεντρικής Σελίδας");
define("FRTLAN_15", "Άλλα (εισάγετε url):");
define("FRTLAN_16", "σφάλμα: δεν υπάρχει περιεχόμενο σε βασικό επιλεγμένο γονέα");
define("FRTLAN_17", "σφάλμα: δεν υπάρχει περιεχόμενο στην επιλεγμένη υποκατηγορία");
define("FRTLAN_18", "Σφάλμα: δεν υπάρχει περιεχόμενο στοιχείο επιλεγμένο");
define("FRTLAN_19", "περιεκτικότητα σε κύρια μητρική");
define("FRTLAN_20", "κατηγορία περιεχομένου");
define("FRTLAN_21", "στοιχείο περιεχομένου");
define("FRTLAN_22", "Προσαρμοσμένη σελίδα");
define("FRTLAN_26", "όλοι οι χρήστες");
define("FRTLAN_27", "Επισκέπτες");
define("FRTLAN_28", "Μέλη");
define("FRTLAN_29", "Διαχειριστές");
define("FRTLAN_31", "Όλοι οι Χρήστες");
define("FRTLAN_32", "Κατηγοριών Μελών");
define("FRTLAN_33", "Τρέχουσες ρυθμίσεις");
define("FRTLAN_34", "Σελίδα");


?>