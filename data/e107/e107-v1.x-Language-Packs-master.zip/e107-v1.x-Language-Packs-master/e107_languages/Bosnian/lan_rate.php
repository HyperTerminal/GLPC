<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 11:45:50 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "glasaj");
define("RATELAN_1", "glasovi");
define("RATELAN_2", "kako ocijeniti to?");
define("RATELAN_3", "Zahvaljujemo se za Vaš glas");
define("RATELAN_4", "neocijenjeno");
define("RATELAN_5", "Ocijeni");


?>