<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Dostupno svima");
define("UC_LAN_1", "Gosti");
define("UC_LAN_2", "Neaktivno");
define("UC_LAN_3", "Članovi");
define("UC_LAN_4", "Samo za čitanje");
define("UC_LAN_5", "Administratori");
?>