<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
|	Traduzione Italiana a cura di:
|   e107 italian team http://e107it.org
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Semua Orang (umum)");
define("UC_LAN_1", "Tamu");
define("UC_LAN_2", "Tidak ada (non-aktif)");
define("UC_LAN_3", "Anggota");
define("UC_LAN_4", "Baca saja");
define("UC_LAN_5", "Administrator");
define("UC_LAN_6", "Admin Induk");

?>