<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/lan_mail_handler.php $
|     $Revision: 11678 $
|     $Id: lan_mail_handler.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produced by e107 website system");
define("LANMAILH_2", "This is a multi-part message in MIME format.");
define("LANMAILH_3", " is not properly formatted");
define("LANMAILH_4", "Server rejected address");
define("LANMAILH_5", "No response from server");
define("LANMAILH_6", "Cannot find E-Mail server.");
define("LANMAILH_7", " appears to be valid.");


?>