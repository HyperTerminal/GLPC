<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/lan_date.php $
|     $Revision: 11678 $
|     $Id: lan_date.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "年");
define("LANDT_02", "月");
define("LANDT_03", "週");
define("LANDT_04", "日");
define("LANDT_05", "時");
define("LANDT_06", "分");
define("LANDT_07", "秒");
define("LANDT_01s", "年");
define("LANDT_02s", "月");
define("LANDT_03s", "週");
define("LANDT_04s", "日");
define("LANDT_05s", "時");
define("LANDT_06s", "分");
define("LANDT_07s", "秒");
define("LANDT_08", "分");
define("LANDT_08s", "分");
define("LANDT_09", "秒");
define("LANDT_09s", "秒");
define("LANDT_AGO", "前");


?>