<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/lan_banner.php $
|     $Revision: 11678 $
|     $Id: lan_banner.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "バーナー");
define("BANNERLAN_16", "ユーザー名:");
define("BANNERLAN_17", "パスワード:");
define("BANNERLAN_18", "続行");
define("BANNERLAN_19", "あなたのクライアントのログインと継続するためのパスワードを入力してください。");
define("BANNERLAN_20", "申し訳ありませんが、データベース内のこれらの詳細を見つけることができません。  詳細については、サイト管理者に連絡してください。");
define("BANNERLAN_21", "バナー統計");
define("BANNERLAN_22", "クライアント");
define("BANNERLAN_23", "バナーID");
define("BANNERLAN_24", "クリック率");
define("BANNERLAN_25", "クリック %");
define("BANNERLAN_26", "インプレッション");
define("BANNERLAN_27", "購入したインプレッション");
define("BANNERLAN_28", "インプレッションの残り");
define("BANNERLAN_29", "バナーなし");
define("BANNERLAN_30", "無制限");
define("BANNERLAN_31", "適用されない");
define("BANNERLAN_32", "はい");
define("BANNERLAN_33", "いいえ");
define("BANNERLAN_34", "終了:");
define("BANNERLAN_35", "IPアドレスのクリック率");
define("BANNERLAN_36", "アクティブ:");
define("BANNERLAN_37", "開始:");
define("BANNERLAN_38", "エラー");


?>