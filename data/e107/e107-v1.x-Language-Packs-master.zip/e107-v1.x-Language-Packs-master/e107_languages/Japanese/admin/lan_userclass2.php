<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_userclass2.php $
|     $Revision: 12246 $
|     $Id: lan_userclass2.php 12246 2011-06-04 14:14:26Z nlstart $
|     $Author: nlstart $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Cleared all users from class.");
define("UCSLAN_2", "Class users updated.");
define("UCSLAN_3", "クラス削除");
define("UCSLAN_4", "Please tick the confirm box to delete this user class");
define("UCSLAN_5", "クラス更新");
define("UCSLAN_6", "Class saved to database.");
define("UCSLAN_7", "No user classes yet.");
define("UCSLAN_8", "既存のクラス");
define("UCSLAN_11", "tick to confirm");
define("UCSLAN_12", "クラス名");
define("UCSLAN_13", "クラスの説明");
define("UCSLAN_14", "ユーザー·クラスの更新");
define("UCSLAN_15", "新しいクラスを作成");
define("UCSLAN_16", "Assign users to class");
define("UCSLAN_17", "削除");
define("UCSLAN_18", "Clear Class");
define("UCSLAN_19", "Assign users to");
define("UCSLAN_20", "クラス");
define("UCSLAN_21", "ユーザクラスの設定");
define("UCSLAN_22", "Users - click to move ...");
define("UCSLAN_23", "Users in this class ...");
define("UCSLAN_24", "Who can manage class");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "ユーザー名");
define("UCSLAN_27", "Return");


?>