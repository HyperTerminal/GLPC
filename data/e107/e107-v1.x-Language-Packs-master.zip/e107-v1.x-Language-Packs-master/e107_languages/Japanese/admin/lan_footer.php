<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_footer.php $
|     $Revision: 12060 $
|     $Id: lan_footer.php 12060 2011-01-30 19:22:47Z secretr $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "サイト");
define("FOOTLAN_2", "ヘッド管理者");
define("FOOTLAN_3", "バージョン");
define("FOOTLAN_4", "ビルド");
define("FOOTLAN_5", "アドミンのテーマ");
define("FOOTLAN_6", "by");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "インストール日付");
define("FOOTLAN_9", "サーバー");
define("FOOTLAN_10", "ホスト");
define("FOOTLAN_11", "PHP Version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "サイト情報");
define("FOOTLAN_14", "ドキュメント表示");
define("FOOTLAN_15", "ドキュメンテーション");
define("FOOTLAN_16", "データベース");
define("FOOTLAN_17", "文字コード");
define("FOOTLAN_18", "サイトテーマ");
define("FOOTLAN_19", "現在のサーバー時刻");
define("FOOTLAN_20", "セキュリティレベル");


?>