<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_meta.php $
|     $Revision: 11678 $
|     $Id: lan_meta.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "メタタグは、データベース内で更新");
define("METLAN_2", "追加のメタタグを入力してください");
define("METLAN_3", "新しいメタタグ設定を入力");
define("METLAN_4", "更新");
define("METLAN_5", "説明を入力します");
define("METLAN_6", "type, a, list, of, your, keywords, here");
define("METLAN_7", "著作権情報を入力します");
define("METLAN_8", "メタタグ");
define("METLAN_9", "説明");
define("METLAN_10", "キーワード");
define("METLAN_11", "著作権");
define("METLAN_12", "ニュースページ上のメタ記述としてニュースのタイトルと要約を使用します。");
define("METLAN_13", "筆者");


?>