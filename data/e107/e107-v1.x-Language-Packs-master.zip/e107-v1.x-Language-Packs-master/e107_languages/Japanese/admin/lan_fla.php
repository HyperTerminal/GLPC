<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_fla.php $
|     $Revision: 11678 $
|     $Id: lan_fla.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "失敗したログイン試行");
define("FLALAN_2", "失敗したログインの試みがログに記録されていない");
define("FLALAN_3", "試みは、削除された");
define("FLALAN_4", "ユーザーが不正なユーザ名/パスワードを使用してログインしようとしました");
define("FLALAN_5", "禁止されたIP(s)");
define("FLALAN_6", "日付");
define("FLALAN_7", "データ");
define("FLALAN_8", "IP アドレス/ホスト");
define("FLALAN_9", "オプション");
define("FLALAN_10", "禁止チェックエントリを削除します");
define("FLALAN_11", "すべての削除チェックボックスをチェック");
define("FLALAN_12", "すべての削除チェックボックスオフ");
define("FLALAN_13", "全て禁止チェックボックスをチェックする");
define("FLALAN_14", "全ての禁止チェックボックスオフ");
define("FLALAN_15", "次のIPアドレス（複数可）は、自動禁止されている - ユーザーは、10回以上のログイン失敗を試みた");
define("FLALAN_16", "自動禁止リストを削除");
define("FLALAN_17", "自動禁止リストを削除");


?>