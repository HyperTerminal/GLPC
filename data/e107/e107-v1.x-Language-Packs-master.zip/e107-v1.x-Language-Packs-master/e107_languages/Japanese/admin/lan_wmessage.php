<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_wmessage.php $
|     $Revision: 11678 $
|     $Id: lan_wmessage.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "ウェルカムメッセージ");
define("WMLAN_01", "新しいメッセージを作成");
define("WMLAN_02", "メッセージ");
define("WMLAN_03", "可視性");
define("WMLAN_04", "メッセージテキスト");
define("WMLAN_05", "Enclose");
define("WMLAN_06", "If ticked, the message will be rendered inside box");
define("WMLAN_07", "Override standard system to use {WMESSAGE} shortcode:");
define("WMLAN_09", "ウェルカムメッセージはまだ設定されていません");
define("WMLAN_10", "メッセージキャプション");


?>