<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_admin_log.php $
|     $Revision: 11678 $
|     $Id: lan_admin_log.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "管理ログ");
define("LAN_ADMINLOG_1", "日付");
define("LAN_ADMINLOG_2", "タイトル");
define("LAN_ADMINLOG_3", "概要");
define("LAN_ADMINLOG_4", "ユーザーIP");
define("LAN_ADMINLOG_5", "ユーザー ID");
define("LAN_ADMINLOG_6", "情報アイコン");
define("LAN_ADMINLOG_7", "通知メッセージ");
define("LAN_ADMINLOG_8", "通知アイコン");
define("LAN_ADMINLOG_9", "通知メッセージ");
define("LAN_ADMINLOG_10", "警告アイコン");
define("LAN_ADMINLOG_11", "警告メッセージ");
define("LAN_ADMINLOG_12", "Fatal Icon");
define("LAN_ADMINLOG_13", "致命的エラーメッセージ");


?>