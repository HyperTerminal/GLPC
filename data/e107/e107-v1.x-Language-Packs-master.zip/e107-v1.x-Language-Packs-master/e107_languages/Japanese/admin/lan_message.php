<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_message.php $
|     $Revision: 11678 $
|     $Id: lan_message.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "受信したメッセージ");
define("MESSLAN_2", "メッセージの削除");
define("MESSLAN_3", "メッセージは削除済み");
define("MESSLAN_4", "すべてのメッセージを削除する");
define("MESSLAN_5", "確認");
define("MESSLAN_6", "すべてのメッセージが削除された。");
define("MESSLAN_7", "メッセージがありません。");
define("MESSLAN_8", "メッセージの種類");
define("MESSLAN_9", "Reported on");
define("MESSLAN_10", "Submitted by");
define("MESSLAN_11", "新しいウィンドウで開きます");
define("MESSLAN_12", "メッセージ");
define("MESSLAN_13", "リンク");


?>