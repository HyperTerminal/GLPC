<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_userclass.php $
|     $Revision: 11678 $
|     $Id: lan_userclass.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "に通知メールを送信する");
define("UCSLAN_2", "権限を更新");
define("UCSLAN_3", "Dear");
define("UCSLAN_4", "あなたの権限は更新されました");
define("UCSLAN_5", "You now have access to the following area(s)");
define("UCSLAN_6", "Set class for user");
define("UCSLAN_7", "Set Classes");
define("UCSLAN_8", "ユーザに通知する");
define("UCSLAN_9", "ラスが更新されました。");
define("UCSLAN_10", "よろしく,");
define("UCSLAN_12", "メンバー権限のみ");


?>