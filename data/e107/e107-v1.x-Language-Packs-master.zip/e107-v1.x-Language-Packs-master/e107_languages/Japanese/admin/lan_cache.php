<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_cache.php $
|     $Revision: 11678 $
|     $Id: lan_cache.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "キャッシュシステムステータス");
define("CACLAN_2", "キャッシュのステータスを設定");
define("CACLAN_3", "キャッシュシステム");
define("CACLAN_4", "キャッシュステータスセット");
define("CACLAN_5", "キャッシュを空にする");
define("CACLAN_6", "キャッシュは空");
define("CACLAN_7", "キャッシュ無効");
define("CACLAN_9", "キャッシュ・データをディスク上のファイルに保存");
define("CACLAN_10", "キャッシュディレクトリが書き込み可能ではありません。 ディレクトリがCHMOD 0777に設定されていることを確認してください");


?>