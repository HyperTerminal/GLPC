<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Japanese/admin/lan_e107_update.php $
|     $Revision: 11678 $
|     $Id: lan_e107_update.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "アクション");
define("LAN_UPDATE_3", "不要");
define("LAN_UPDATE_5", "アップデート公開");
define("LAN_UPDATE_7", "実行");
define("LAN_UPDATE_8", "更新");
define("LAN_UPDATE_9", "to");
define("LAN_UPDATE_10", "利用可能なアップデート");
define("LAN_UPDATE_11", ".617 to .7 更新継続");
define("LAN_UPDATE_12", "テーブルの1つが重複するエントリが含まれています。");


?>