<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_stats.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Statistika");

define("LAN_124", "Portaali kokku k�lastanud: ");
define("LAN_125", "Kokku vaadanud portaali lehek�lge: ");
define("LAN_126", "Lehek�lge k�lastanud: ");
define("LAN_127", "Vaadanud lehek�lge: ");
define("LAN_128", "Weebilehitseja: ");
define("LAN_129", "Op S�steem: ");
define("LAN_130", "Riik kust k�lastati: ");
define("LAN_131", "Viidatud: ");
define("LAN_132", "Lehek�lje statistika");
define("LAN_371", "Logging is not activated, to activate go to your admin section, click on Logger and tick the Activate Logging/Counter checkbox.");
define("LAN_372", "Tulevikus v�ib see suletud olla.");
define("LAN_373", "Andmeid pole veel.");
define("LAN_374", "Logimisi:");
define("LAN_375", "N�ita k�iki");
define("LAN_376", "Viimased 10");
define("LAN_377", "K�ik");
define("LAN_378", "top 10");
define("LAN_379", "Resulutsioon");
define("LAN_418", " p�eva on m��dunud kodulehe avamise hetkest");
define("LAN_419", "P�eva keskmine");
define("LAN_420", "N�dala keskmine");
define("LAN_421", "Kuu keskmine");
define("LAN_422", "Pole veel midagi");

?>