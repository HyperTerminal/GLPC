<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_forum_viewforum.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Foorum"); 

define("LAN_01", "Foorumid");
define("LAN_02", "tagasi �lesse");
define("LAN_03", "Mine");
define("LAN_53", "Teema");
define("LAN_54", "Alustatud");
define("LAN_55", "Vastatud");
define("LAN_56", "Vaadatud");
define("LAN_57", "viimati");
define("LAN_58", "Veel pole midagi.");
define("LAN_59", "Sa ei saa seda teha registreerimata, registreerimiseks vajuta <a href='".e_BASE."signup.php'>siia</a>!");
define("LAN_79", "Uued");
define("LAN_80", " Uusi pole");
define("LAN_81", "Sule teema");
define("LAN_180", "Otsi");
define("LAN_202", "Sticky");
define("LAN_203", "Suletud");
define("LAN_204", "Sa <b>Saad</b> Alustada uut teemat");
define("LAN_205", "Sa <b>ei saa</b> Alustada uut teemat");
define("LAN_206", "Sa <b>saad</b> vastata");
define("LAN_207", "Sa <b>ei saa</b> vastata");
define("LAN_208", "Sa <b>Saad</b> muuta");
define("LAN_209", "Sa <b>ei saa</b> muuta");
define("LAN_316", "mine lehek�ljele ");
define("LAN_317", "Pole");
define("LAN_321", "Moderators: ");
define("LAN_395", "[populaarsemad]");
define("LAN_396", "Teadeanded");

define("LAN_397", "Ainult lugemiseks");

?>