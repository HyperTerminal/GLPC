<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_links.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Lingid");
define("LAN_61", "Linkide kategooriad");
define("LAN_62", "Kategooriad");
define("LAN_63", "Kategooria");
define("LAN_64", "Selles kategoorias");
define("LAN_65", "Link");
define("LAN_66", "Lingid");
define("LAN_67", "Näita kõiki");
define("LAN_68", "Muuda");
define("LAN_69", "Kustuta");
define("LAN_86", "Kategooria:");
define("LAN_88", "Vaadatud:");
define("LAN_89", "Admin: ");
define("LAN_90", "Lisa uus link");
define("LAN_91", "lisa uus kategooria");
define("LAN_92", "saada link");
define("LAN_93", "enne ilmumist vaatab asja üle admin.");
define("LAN_94", "Lingi nimi:");
define("LAN_95", "Lingi aadress:");
define("LAN_96", "Lingi kirjeldus:");
define("LAN_97", "logo aadress (http://:");
define("LAN_98", "Lisa Link");
define("LAN_99", "Aitäh");
define("LAN_100", "Sinu viide on salvestatud ja ilmub peale seda kui admin on ta kontrollinud.");
define("LAN_101", "Lisamiseks Vajuta siia");
define("LAN_102", "Siin");
define("LAN_103", "on");
define("LAN_104", "on");
define("LAN_105", "kogu");
define("LAN_106", "Täida allajoonitud lahtrid.");
define("LAN_Links_1", "Linke kokku");
define("LAN_Links_2", "Aktiivseid linke kokku");
define("LAN_LINKS_3", "Annonüümne");


?>