<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_forum_viewtopic.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Foorum"); 

define("LAN_01", "Foorumid");
define("LAN_02", "Mine lehek�ljele");
define("LAN_03", "Mine");
define("LAN_04", "Eelmine");
define("LAN_05", "J�rgmine");
define("LAN_06", "liitunud");
define("LAN_07", "Elukoht");
define("LAN_08", "kodukas");
define("LAN_09", "Visits to site since registration");
define("LAN_10", "�lesse");
define("LAN_65", "H�ppa");
define("LAN_66", "Teema on n��d suletud");
define("LAN_67", "postitused");
define("LAN_194", "K�laline");
define("LAN_195", "Registreeritud kasutaja");
define("LAN_321", "Vahendaja: ");
define("LAN_389", "eelmine teema");
define("LAN_390", "J�rgmine teema");
define("LAN_391", "track this thread");
define("LAN_392", "stop tracking this thread");
define("LAN_393", "Kiire vastus");
define("LAN_394", "Vaata");
define("LAN_395", "Vasta");
define("LAN_396", "Kodukas");
define("LAN_397", "Email");
define("LAN_398", "Profiile");
define("LAN_399", "Privaatne Kiri");
define("LAN_400", "Muuda");
define("LAN_401", "Tsitaat");

define("LAN_402", "Autor");
define("LAN_403", "Postitus");
define("LAN_404", "pole");
define("LAN_405", "pole");

?>