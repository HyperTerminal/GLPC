<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_forum.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Foorum"); 

define("LAN_30", "Tere tulemast");
define("LAN_31", "Uusi postitusi pole ");
define("LAN_32", "uus postitus ");
define("LAN_33", "There Are");
define("LAN_34", "Uus postitus");
define("LAN_35", "Sinu 1 k�lastusest alates.");
define("LAN_36", "Viimati olid siin ");
define("LAN_37", "T�na on ");
define("LAN_38", ", all times are ");
define("LAN_41", "Uuelt kasutajalt: ");
define("LAN_42", "Registreeritud kasutajalt: ");
define("LAN_43", "see toiming pole m�eldud registreerimata kasutajale, kui sa soovid postitada, muuta/kustutada postitusi pead sa registreerima. <a href='".e_BASE."signup.php'>Registreeru</a> ja logi sisse.");
define("LAN_44", "See toiming pole m�eldud registreerimata kasutajale.");
define("LAN_45", "See toiming pole m�eldud registreerimata kasutajale. Registreerumiseks vajuta <a href='".e_BASE."signup.php'>siia</a>.");
define("LAN_46", "Foorum");
define("LAN_47", "Teema");
define("LAN_48", "Vastused");
define("LAN_49", "Viimased");
define("LAN_51", "foorum ei toimi veel.");
define("LAN_52", "Foorum ei toimi veel.");
define("LAN_79", "uus Postitus");
define("LAN_80", " Uusi Postitusi pole");
define("LAN_81", "sule");
define("LAN_100", "Artikel");
define("LAN_180", "Otsi");
define("LAN_191", "Informatioon");
define("LAN_192", "Selle foorumi kasutajad on postitanud ");
define("LAN_196", "Tahad lugeda ");
define("LAN_197", " Postita.");
define("LAN_198", " Uued postitused on loetud.");
define("LAN_199", "M�rgi k�ik loetuks");
define("LAN_204", "Sa <b>saad</b> alustada uut teemat");
define("LAN_205", "Sa <b>ei saa</b> alustada uut teemat");
define("LAN_206", "sa <b>saad</b> vastata");
define("LAN_207", "Sa <b>ei saa</b> vastata");
define("LAN_208", "Sa <b>saad</b> muuta seda");
define("LAN_209", "Sa <b>ei saa</b> muuta seda");
define("LAN_392", "stop tracking this thread");
define("LAN_393", "Keelatud teemade nimekiri");
define("LAN_394", "suletud foorum");
define("LAN_397", "piiratud teema");
define("LAN_398", "Suletud");
define("LAN_399", "piiratud");
define("LAN_400", "ainult kasutajatele");
define("LAN_401", "Ainult kasutajatele");

define("LAN_402", "Ainult lugemiseks");

?>