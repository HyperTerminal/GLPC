<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_userclass.php $
|     $Revision: 11678 $
|     $Id: lan_userclass.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Sending notification email to");
define("UCSLAN_2", "Updated Privileges");
define("UCSLAN_3", "Dear");
define("UCSLAN_4", "Your privileges have been updated at");
define("UCSLAN_5", "You now have access to the following area(s)");
define("UCSLAN_6", "Set class for user");
define("UCSLAN_7", "Set Classes");
define("UCSLAN_8", "Notify User");
define("UCSLAN_9", "Classes Updated.");
define("UCSLAN_10", "Regards,");
define('UCSLAN_12', 'Member privileges only');

?>