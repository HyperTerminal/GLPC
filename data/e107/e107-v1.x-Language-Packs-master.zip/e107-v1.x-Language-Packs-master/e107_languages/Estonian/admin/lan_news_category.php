<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/admin/lan_news_category.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("NCLAN_1", "Category added to database.");
define("NCLAN_2", "Categories updated.");
define("NCLAN_3", "Category deleted.");
define("NCLAN_4", "Please confirm you wish to delete the");
define("NCLAN_5", "news category - once deleted it cannot be retrieved");
define("NCLAN_6", "Cancel");
define("NCLAN_7", "Confirm Delete");
define("NCLAN_8", "Confirm Delete Category");
define("NCLAN_9", "Delete cancelled.");
define("NCLAN_10", "Update Existing Categories");
define("NCLAN_11", "Category Name");
define("NCLAN_12", "Category Icon");
define("NCLAN_13", "Create New News Category");
define("NCLAN_14", "News Categories");
define("NCLAN_15", "Update News Categories");
define("NCLAN_16", "Create New Category");
define("NCLAN_17", "Delete");

?>