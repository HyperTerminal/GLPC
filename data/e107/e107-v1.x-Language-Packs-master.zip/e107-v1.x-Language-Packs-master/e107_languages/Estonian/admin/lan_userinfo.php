<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_userinfo.php $
|     $Revision: 11678 $
|     $Id: lan_userinfo.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Unable to find poster's IP address - no information is available.");
// define("USFLAN_2", "Error");
define("USFLAN_3", "Messages posted from IP address");
define("USFLAN_4", "Host");
define("USFLAN_5", "Click here to transfer IP address to admin ban page");
define("USFLAN_6", "User ID");
define("USFLAN_7", "User Information");

?>