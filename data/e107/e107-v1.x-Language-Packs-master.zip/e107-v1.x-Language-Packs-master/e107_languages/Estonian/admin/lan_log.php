<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/admin/lan_log.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/17 01:00:05 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("LOGLAN_1", "Logging settings updated.");
define("LOGLAN_2", "Stats table(s) emptied.");
define("LOGLAN_3", "Activate Logging/Counter?");
define("LOGLAN_4", "Refer log type");
define("LOGLAN_5", "Domain only");
define("LOGLAN_6", "Complete URL");
define("LOGLAN_7", "Count how many last visitors?");
define("LOGLAN_8", "Clear stats tables");
define("LOGLAN_9", "Tick to clear information stats");
define("LOGLAN_10", "Tick to clear counter stats");
define("LOGLAN_11", "Clear!");
define("LOGLAN_12", "Update Logger Settings");
define("LOGLAN_13", "Logger/Counter Settings");

?>