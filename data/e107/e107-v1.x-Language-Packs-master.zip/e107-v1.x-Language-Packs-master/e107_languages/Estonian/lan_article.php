<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/admin/lan_prefs.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Artiklid"); 

define("LAN_5", "Kommentaarid ...");
define("LAN_25", "eelmine lehek�lg");
define("LAN_26", "j�rgmine lehek�lg");
define("LAN_99", "Kommentaar");
define("LAN_100", "artikel");
define("LAN_190", "eelvaade");
define("LAN_313", "Vali nimekiri ...");
define("LAN_398", "Pole kokkuv�ttet.");
define("LAN_399", "reiting");

define("LAN_400", "Mitteaktiivne");
define("LAN_401", "See lehek�lg pole aktiivne.");

define("LAN_2", "Sul pole piisavalt �igusi seda vaadata.");


?>