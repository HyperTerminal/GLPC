<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_newspost.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("NWSLAN_1", "Kustutatud.");
define("NWSLAN_2", "Märgi linnukesega nõustumise jaoks.");
define("NWSLAN_3", "Uudiseid pole.");
define("NWSLAN_4", "Olemasolev uudis");
define("NWSLAN_5", "Ava HTML Editor");
define("NWSLAN_6", "Kategooria");
define("NWSLAN_7", "Muuda");
define("NWSLAN_8", "Kustuta");
define("NWSLAN_9", "Maärgi ära");
define("NWSLAN_10", "Kategooriat pole veel.");
define("NWSLAN_11", "Lisa/Muuda kategooriat");
define("NWSLAN_12", "Pealkiri");
define("NWSLAN_13", "Sisu");
define("NWSLAN_14", "lisa");
define("NWSLAN_15", "Kommentaarid");
define("NWSLAN_16", "Lubatud");
define("NWSLAN_17", "Keelatud");
define("NWSLAN_18", "Luba kommentaarid sellele uudisele");
define("NWSLAN_19", "Aktiveeri");
define("NWSLAN_20", "Jäta tühjaks kui ei soovi automaatset aktiveerimist");
define("NWSLAN_21", "aktiveeri vahemikus");
define("NWSLAN_22", "Kuvatavus");
define("NWSLAN_23", "Uudis on nähtav ainult teatud kasutajatele");
define("NWSLAN_24", "Vaata veel");
define("NWSLAN_25", "Uuenda");
define("NWSLAN_26", "Postita uudis");
define("NWSLAN_27", "Eelvaade");
define("NWSLAN_28", "Uus lugu");
define("NWSLAN_29", "Udiste post");
define("NWSLAN_30", "Näita ainult pealkirja");


?>