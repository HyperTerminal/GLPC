<?php
/*
+---------------------------------------------------------------+
|        e107 website system Estonian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../keeled/Estonian/lan_prefs.php $
|        $Revision: 1.0 $
|        $Date: 2009/10/16 15:38:03 $
|        $Author: vazzar $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Vanad k�sitlused");

define("LAN_92", "Vana k�sitlus");
define("LAN_93", "Pole �htegi veel.");
define("LAN_94", "Postitanud");
define("LAN_95", "Kokku osalenud:");
define("LAN_96", "Polls");
define("LAN_97", "N�ita kommentaare");

define("LAN_98", "Poll");

?>