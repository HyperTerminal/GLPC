<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_print.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/29 14:16:44 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Prentv�nt");

define("LAN_86", "Flokkur:");
define("LAN_87", "af ");
define("LAN_94", "P�sta� af");
define("LAN_135", "Fr�tt: ");
define("LAN_303", "�essi fr�tt er fr� ");
define("LAN_304", "Titill: ");
define("LAN_305", "Undirtitill: ");
define("LAN_306", "�etta er fr�: ");
define("LAN_307", "Prenta �essa s��u");

?>