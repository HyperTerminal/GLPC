<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Póstur frá www.sksiglo.is");
define("LANMAILH_2", "Þetta er margþætt bréf í  MIME formati.");
define("LANMAILH_3", " er ekki rétt formatað");
define("LANMAILH_4", "Póstþjónn neitar netfangi");
define("LANMAILH_5", "Ekkert svar frá server");
define("LANMAILH_6", "Finn ekki póstþjón.");
define("LANMAILH_7", " virðist vera gilt.");

?>