<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Virkustu vef notendur");
define("TOP_LAN_1", "Notendanafn");
define("TOP_LAN_2", "P�star");
define("TOP_LAN_3", "Ofurnotendur");
define("TOP_LAN_4", "Athugasemdir");
define("TOP_LAN_5", "Ofurspjallarar");
define("TOP_LAN_6", "Einkun vefsv��is");

//v.616
define("LAN_1", "�r��ur");
define("LAN_2", "P�stari");
define("LAN_3", "Sko�a�");
define("LAN_4", "Sv�r");
define("LAN_5", "S��asti p�stur");
define("LAN_6", "�r��ir");
define("LAN_7", "Virkustu �r��irnir");
define("LAN_8", "Virkustu notendur");


?>