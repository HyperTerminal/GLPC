<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/24 11:23:45 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "ár");
define("LANDT_02", "mánuður");
define("LANDT_03", "vika");
define("LANDT_04", "dagur");
define("LANDT_05", "klukkustund");
define("LANDT_06", "mínúta");
define("LANDT_07", "sekúnda");
define("LANDT_01s", "ár");
define("LANDT_02s", "mánuðir");
define("LANDT_03s", "vikur");
define("LANDT_04s", "dagar");
define("LANDT_05s", "klukkustundir");
define("LANDT_06s", "mínútur");
define("LANDT_07s", "sekúndur");

define("LANDT_08", "mín");
define("LANDT_08s", "mín");
define("LANDT_09", "sek");
define("LANDT_09s", "sek");
define("LANDT_AGO", "síðan");

?>