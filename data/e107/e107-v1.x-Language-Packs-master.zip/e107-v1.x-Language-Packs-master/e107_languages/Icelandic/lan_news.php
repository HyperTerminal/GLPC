<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_news.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/01/11 18:13:29 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "FRÉTTIR");

define("LAN_82", "Fréttaflokkar");
define("LAN_83", "Engar frétti í augnablikinu - Vinsamlegast lítið við fljótt aftur.");
define("LAN_84", "Fréttir");
define("LAN_99", "Athugasemdir");
define("LAN_100", "um");
define("LAN_307", "Heildarskrár í þessum flokki: ");

define("LAN_NEWS_1", "Fréttir fyrir meðlimi eingöngu");
define("LAN_NEWS_2", "Þér er ekki heimilt að skoða þessa frétt");
define("LAN_NEWS_3", "Vinsamlegast eyddu install.php af servernum");
define("LAN_NEWS_4", "ef þú gerir það ekki er öryggi vefsins þíns í hættur");

define("LAN_NEWS_5", "<b>Error!</b> Ekki tókst að uppfæra frétt í gagnagrunni!</b>");
define("LAN_NEWS_6", "Fréttir skráðar í gagnagrunni.");
define("LAN_NEWS_7", "<b>Error!</b> Ekki var unnt að skrá frétt í gagnagrunn!</b>");
define("LAN_NEWS_8", "Fréttir skráðar í gagnagrunn fyrir öll tungumál. ID: ");
define("LAN_NEWS_9", "Title only is set - <b>only the news title will be shown</b><br />");
define("LAN_NEWS_10", "Þessi fréttapóstur er <b>inactive</b> (It will be not shown on front page). ");
define("LAN_NEWS_11", "Þessi fréttapóstur er<b>active</b> (it will be shown on front page). ");
define("LAN_NEWS_12", "Athugasemdir eru <b>Virkar</b>. ");
define("LAN_NEWS_13", "Athugasemdir eru <b>Óvirkar</b>. ");
define("LAN_NEWS_14", "<br />Tímabil virkni: ");
define("LAN_NEWS_15", "Body length: ");
define("LAN_NEWS_16", "b. Extended length: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Uppl:");
define("LAN_NEWS_19", "Núna");
define("LAN_NEWS_20", "News updated in database for the following language: ");
define("LAN_NEWS_21", "Fréttir uppfærðar í gagnagrunn.");
define("LAN_NEWS_22", "Fara á síðu: ");
define("LAN_NEWS_23", "Fréttaflokkar");
define("LAN_NEWS_24", "búa til  pdf skjal úr þessari frétt");
define("LAN_462", "engar fréttir úr nefndum mánuði");

?>