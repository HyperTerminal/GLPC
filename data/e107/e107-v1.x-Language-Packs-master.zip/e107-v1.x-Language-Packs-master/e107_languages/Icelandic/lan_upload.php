<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_upload.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Upphal");

define("LAN_20", "Villa");
define("LAN_61", "�itt Nafn: ");
define("LAN_112", "Netfang: ");
define("LAN_144", "Sl�� � Vef: ");
define("LAN_402", "�� ver�ur a� vera skr��ur notandi til a� upphala skr�m � �ennan vef.");
define("LAN_403", "�� hefur ekki r�ttindi til a� upphala skr�m � �ennan vef.");
define("LAN_404", "Takk fyrir. Upphal �itt ver�ur sko�a� af vefstj�ra og birt ef �a� uppfyllir allar kr�fur vefsins.");
define("LAN_405", "Skr�in var st�rri en leyft er - Skr�nni hefyr veri� eytt.");
define("LAN_406", "Vinsamlegast athugi�");
define("LAN_407", "�llum ��rum skr�arger�um ver�ur eytt.");
define("LAN_408", "Undirstrika�");
define("LAN_409", "Nafn Skr�ar");
define("LAN_410", "�tg�fa");
define("LAN_411", "Sk�in");
define("LAN_412", "Skj�mynd (snapshot)");
define("LAN_413", "L�sing");
define("LAN_414", "Virkt demo");
define("LAN_415", "Settu inn  URL � vef �ar sem demo er virkt");
define("LAN_416", "Senda og Upphala");
define("LAN_417", "Upphala Skr�");
define("LAN_418", "H�marks St�r� Skr�ar: ");
define("DOWLAN_11", "Flokkur");
define("LAN_419", "Leyf�ar skr�arger�ir");
define("LAN_420", "sv��i eru nau�synleg");



?>