<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_notify.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/23 23:10:14 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Nýskráning notanda");

define("NT_LAN_UV_1", "Nýskráning staðfest");
define("NT_LAN_UV_2", "Þráður innskráðs notanda");

define("NT_LAN_LI_1", "Notandi skráður inn");

define("NT_LAN_LO_1", "Notandi skráður út");
define("NT_LAN_LO_2", " útskráður af vefsvæði");

define("NT_LAN_FL_1", "Bann vegna misnotkunar");
define("NT_LAN_FL_2", "IP tala bönnuð vegna misnotkunar");

define("NT_LAN_SN_1", "Frétt innsend");

define("NT_LAN_NU_1", "Uppfært");

define("NT_LAN_ND_1", "Frétt eytt");
define("NT_LAN_ND_2", "Númer eyddra frétta id");

?>