<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Senda Fr�tt");
define("LAN_7", "Notendanafn: ");
define("LAN_62", "Var�andi: ");
define("LAN_112", "Netfang: ");
define("LAN_133", "Takk Fyrir");
define("LAN_134", "Efni �itt hefur veri� sent og ver�ur yfirfari� af Vefstj�ra flj�tlega.");
define("LAN_135", "Fr�tt: ");
define("LAN_136", "Senda Fr�tt");
define("NWSLAN_6", "Flokkur");
define("NWSLAN_10", "Engir Fr�tta Flokkar");
define("NWSLAN_11", "�� hefur ekki a�gang a� �essu sv��i.");
define("NWSLAN_12", "A�gangi Neita�.");

define("SUBNEWSLAN_1", "�� ver�ur a� setja inn Titil.\\n");
define("SUBNEWSLAN_2", "�� ver�ur a� setja inn einhvern Texta.\\n");
define("SUBNEWSLAN_3", "Vi�hengi� ver�ur a� vera eitthvert �essara - jpg, gif e�a png skr�");
define("SUBNEWSLAN_4", "Skr�in er of st�r");
define("SUBNEWSLAN_5", "Myndskr�");
define("SUBNEWSLAN_6", "(jpg, gif e�a png)");

?>