<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Notenda Póstar");

define("UP_LAN_0", "Allur spjallpóstur til ");
define("UP_LAN_1", "Allar athugasemdir til ");
define("UP_LAN_2", "Þráður");
define("UP_LAN_3", "Skoðað");
define("UP_LAN_4", "Svör");
define("UP_LAN_5", "Síðasti póstur");
define("UP_LAN_6", "Þræðir");
define("UP_LAN_7", "Engar athugasemdir");
define("UP_LAN_8", "Engir póstar");
define("UP_LAN_9", " á ");
define("UP_LAN_10", "Varðandi");
define("UP_LAN_11", "Póstað á");
define("UP_LAN_12", "Leita");
define("UP_LAN_13", "Athugasemdir");
define("UP_LAN_14", "Spjall póstar");
define("UP_LAN_15", "Varðandi");
define("UP_LAN_16", "IP veffang");

?>