<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "Gestir: ");
define("ONLINE_EL2", "Meðlimir: ");
define("ONLINE_EL3", "Á þessari síðu: ");
define("ONLINE_EL4", "Á sveimi");
define("ONLINE_EL5", "Meðlimir");
define("ONLINE_EL6", "Nýjasti meðlimurinn");
define("ONLINE_EL7", "Skoðar");
define("ONLINE_EL8", "mest á sveimi: ");
define("ONLINE_EL9", "on");
define("ONLINE_EL10", "Nafn meðlims");
define("ONLINE_EL11", "Skoðar síðu");
define("ONLINE_EL12", "Svarar");
define("ONLINE_EL13", "Spjall");
define("ONLINE_EL14", "Þráður");
define("ONLINE_EL15", "Síða");
define("CLASSRESTRICTED", "Aðgangsstýrð síða");
define("ARTICLEPAGE", "Grein/gagnrýni");
define("CHAT", "Röfl");
define("COMMENT", "Athugasemdir");
define("DOWNLOAD", "Niðurhöl");
define("EMAIL", "email.php");
define("FORUM", "Listun Aðalspjallvefs");
define("LINKS", "tenglar");
define("NEWS", "Fréttir");
define("OLDPOLLS", "Gamlar kannanir");
define("POLLCOMMENT", "Skoðanakönnun");
define("PRINTPAGE", "Prenta");
define("LOGIN", "Innskráning");
define("SEARCH", "Að leita");
define("STATS", "Staða vefs");
define("SUBMITNEWS", "Senda inn frétt");
define("UPLOAD", "Upphal");
define("USERPAGE", "Notendaprófílar");
define("USERSETTINGS", "Notendastillingar");
define("ONLINE", "Notendur á sveimi");
define("LISTNEW", "Sýna nýtt");
define("USERPOSTS", "frá notendum");
define("SUBCONTENT", "Senda inn grein/gagnrýni");
define("TOP", "Helstu höfundar/Virkustu þræðir");
define("ADMINAREA", "Stjórnsvæði");
define("BUGTRACKER", "Meyndýraleitir");
define("EVENT", "Listi viðburða");
define("CALENDAR", "Dagatal viðburða");
define("FAQ", "Faq");
define("PM", "Einkaskeytin");
define("SURVEY", "Könnun");
define("ARTICLE", "Grein");
define("CONTENT", "Efnis síða");
define("REVIEW", "gagnrýni");

?>