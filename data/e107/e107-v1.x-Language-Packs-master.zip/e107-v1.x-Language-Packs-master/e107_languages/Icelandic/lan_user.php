<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_user.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/04/06 03:53:00 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Notendur");

define("LAN_20", "Villa");
define("LAN_112", "Netfang");
define("LAN_115", "ICQ Númer");
define("LAN_116", "AIM Netfang");
define("LAN_117", "MSN Messenger");
define("LAN_118", "Fæðingardagur");
define("LAN_119", "Staðsetning");
define("LAN_120", "Undirskrift");
define("LAN_137", "Engar upplýsingar fáanlegar um notanda því þeir eru ekki skráðir í");
define("LAN_138", "Skráðir notendur: ");
define("LAN_139", "Röð: ");
define("LAN_140", "Skráðir notendur");
define("LAN_141", "Engir skráðir notendur.");
define("LAN_142", "Notandi");
define("LAN_143", "[falið samkvæmt beiðni]");
define("LAN_144", "Vefsíðu URL");
define("LAN_145", "Skráði sig inn");
define("LAN_146", "Heimsóknir eftir skráningu");
define("LAN_147", "Spjallkassaskeyti");
define("LAN_148", "Athugasemdir sendar");
define("LAN_149", "Spjall sendingar");
define("LAN_308", "Rétt nafn");
define("LAN_400", "Þetta er ekki gildur notandi.");
define("LAN_401", "engar upplýsingar");
define("LAN_402", "Prófíll notanda");
define("LAN_403", "Site Stats");
define("LAN_404", "Síðasta heimsókn");
define("LAN_405", "dögum síðan");
define("LAN_406", "Einkun");
define("LAN_407", "engin");
define("LAN_408", "engin mynd");
define("LAN_409", "punktar");
define("LAN_410", "Ýmislegt");
define("LAN_411", "Smelltu hér til að uppfæra prófílinn þinn");
define("LAN_412", "Smelltu hér til að breyta uppl. um þennann notanda");
define("LAN_413", "eyða mynd");
define("LAN_414", "fyrri notandi");
define("LAN_415", "næsti notandi");
define("LAN_416", "Þú verður að vera skráðiur inn til að skoða þessa síðu");
define("LAN_417", "Vefstjóri");
define("LAN_418", "Aðstoðar vefstjóri");
define("LAN_419", "Sýna");
define("LAN_420", "Lækk");
define("LAN_421", "Hækk");
define("LAN_422", "Áfram");
define("LAN_423", "Smelltu hér til að skoða athugasemdir notanda");
define("LAN_424", "Smelltu hér til að skoða þræði á Spjallvef");
define("LAN_425", "Senda einkaskeyti");
define("LAN_426", "síðan");

define("USERLAN_1", "Jafningja einkun");

?>