<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_upload_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/05 06:58:21 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Skr�arger�");
define("LANUPLOAD_2", "er ekki leyf� og ver�ur eytt.");
define("LANUPLOAD_3", "Upphal t�kst me� afbrig�um vel");
define("LANUPLOAD_4", "Anna�hvort er sv��i sem sent er � ekki til e�a ekki me� skrifr�ttindi. (chmod 777)");
define("LANUPLOAD_5", "Skr�in er st�rri en leyf� er � php.ini.");
define("LANUPLOAD_6", "Skr�in er st�rri en teki� var fram a� leyft v�ri � html formi.");
define("LANUPLOAD_7", "Skr�in komst aa�eins a� hluta til � lei�arenda.");
define("LANUPLOAD_8", "Engin skr� komst � lei�arenda.");
define("LANUPLOAD_9", "Upph�lu� skr� er bara 0 b�ti");
define("LANUPLOAD_10", "Upphal klikka�i [Duplicate filename] - Skr� me� �essu nafni er �egar til.");
define("LANUPLOAD_11", "Skr�in komst ekki � lei�arenda. Skr�arnafn: ");
define("LANUPLOAD_12", "Villa");

?>