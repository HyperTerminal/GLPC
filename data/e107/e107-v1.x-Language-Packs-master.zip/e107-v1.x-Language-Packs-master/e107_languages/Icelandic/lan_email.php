<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_email.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/07 19:06:54 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Netp�stur");

define("LAN_5", "Emaila grein til vinar");
define("LAN_6", "Emaila fr�tt til vinar");
define("LAN_7", "Notendanafn: ");
define("LAN_8", "Athugasemd");
define("LAN_9", "�v� mi�ur, gat ekki sent email");
define("LAN_10", "Mail sent til");
define("LAN_11", "Email sent");
define("LAN_12", "VILLA ");
define("LAN_106", "�etta vir�ist ekki vera gilt netfang");
define("LAN_185", "Senda Grein");
define("LAN_186", "Senda Fr�tt");
define("LAN_187", "Netfang til a� senda �");
define("LAN_188", "�� g�tir haft �huga � �essari fr�tt fr�");
define("LAN_189", "�� g�tir haft �huga � �essari grein fr�");

define("LAN_email_1", "Fr�:");
define("LAN_email_2", "IP fang sendanda:");
define("LAN_email_3", "Emaila� br�f fr� ");
define("LAN_email_4", "Senda Email");
define("LAN_email_5", "Sendu Email til vinar");
define("LAN_email_6", "�� g�tir haft �huga � �essu br�fi fr�");


?>