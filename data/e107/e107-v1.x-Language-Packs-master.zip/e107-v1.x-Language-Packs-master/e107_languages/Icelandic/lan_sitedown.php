<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vefsíðan er lokuð tímabundið");
define("LAN_00", "er lokuð tímabundið");
define("LAN_01", "Við höfum tímabundið lokað vefnum vegna breytinga. Þetta ætti ekki að taka langan tíma - endilega kíktu fljótt við aftur og við biðjumst velvirðingar á óþægindunum.");

?>