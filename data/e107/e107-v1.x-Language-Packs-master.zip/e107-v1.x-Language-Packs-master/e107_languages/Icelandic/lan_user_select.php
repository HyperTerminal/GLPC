<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Velja notanda");
define("US_LAN_2", "Velja svið notanda");
define("US_LAN_3", "Allir notendur");
define("US_LAN_4", "Finna notendanafn");
define("US_LAN_5", "Notendur fundnir");
define("US_LAN_6", "Leita");

?>