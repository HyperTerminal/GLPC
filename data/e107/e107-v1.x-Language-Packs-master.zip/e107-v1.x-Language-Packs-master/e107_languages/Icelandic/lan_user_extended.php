<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_user_extended.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/28 16:22:00 $
|     $Author: siggik $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Texabox");
define("UE_LAN_2", "Valhnúðar");
define("UE_LAN_3", "Fellivalmynd");
define("UE_LAN_4", "DB Table Field");
define("UE_LAN_5", "Textasvæði");
define("UE_LAN_6", "Integer");
define("UE_LAN_7", "Dags");
define("UE_LAN_8", "Tungumál");

define("UE_LAN_9", "Nafn");
define("UE_LAN_10", "Gerð");
define("UE_LAN_11", "Nota");

define("UE_LAN_HIDE", "Fela frá notendum");

define("UE_LAN_LOCATION", "Staðsetning");
define("UE_LAN_LOCATION_DESC", "Staðsetning notanda");
define("UE_LAN_AIM", "AIM netfang");
define("UE_LAN_AIM_DESC", "AIM netfang");
define("UE_LAN_ICQ", "ICQ Number");
define("UE_LAN_ICQ_DESC", "ICQ Númer");
define("UE_LAN_YAHOO", "Yahoo! netfang");
define("UE_LAN_YAHOO_DESC", "Yahoo! netfang");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN netfang");
define("UE_LAN_HOMEPAGE", "Heimasíða");
define("UE_LAN_HOMEPAGE_DESC", "Heimasíða notanda (url)");
define("UE_LAN_BIRTHDAY", "Afmælisdagur");
define("UE_LAN_BIRTHDAY_DESC", "Afmælisdagur");

?>