<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_np.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Fyrri síða");
define("NP_2", "Næsta síða");
define("NP_3", "Fara á síðu");

?>