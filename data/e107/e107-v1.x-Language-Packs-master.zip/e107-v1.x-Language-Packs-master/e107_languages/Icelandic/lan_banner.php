<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/14 12:57:27 $
|     $Author: damaverick_ $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Bor�i");

define("LAN_16", "Notendanafn: ");
define("LAN_17", "A�gangsor�: ");
define("LAN_18", "�fram");
define("LAN_19", "Settu inn notendanafn og lykilor� til a� halda �fram");
define("LAN_20", "�v� mi�ur fannst leit ��n ekki � gagnagrunni. Haf�u samband vi� vefstj�ra.");
define("LAN_21", "Uppl. um Bor�a");
define("LAN_22", "Vi�skiptavinur");
define("LAN_23", "N�mer Bor�a");
define("LAN_24", "Smella-gegnum");
define("LAN_25", "Click %");
define("LAN_26", "�hrif");
define("LAN_27", "Keypt �hrif");
define("LAN_28", "�hrif eftir");
define("LAN_29", "Engir Bor�ar");
define("LAN_30", "�takmarka�");
define("LAN_31", "Ekki noth�ft");
define("LAN_32", "J�");
define("LAN_33", "Nei");
define("LAN_34", "Endar:");
define("LAN_35", "Smella-gegnum IP t�lur");
define("LAN_36", "Virkt:");
define("LAN_37", "Byrjar:");
define("LAN_38", "VILLA !!");

?>