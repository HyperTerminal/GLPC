<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_comment.php,v $
|     $Revision: 1.7 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: damaverick_ $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Athugasemdir");

define("LAN_0", "[blokka� af admin]");
define("LAN_1", "Afblokka");
define("LAN_2", "Blokka");
define("LAN_3", "Ey�a");
define("LAN_4", "Uppl�singar");
define("LAN_5", "Athugasemdir ...");
define("LAN_6", "�� ver�ur a� vera skr��ur inn til a� setja inn athugasemdir � �ennan vef - skr��u �ig inn e�a, ef �� ert ekki Skr��ur Notandi smelltu ��:");
define("LAN_7", "Vefstj�ri");
define("LAN_8", "Athugasemd");
define("LAN_9", "Senda athugasemd");
define("LAN_10", "Vefstj�ri");
define("LAN_11", "var ekki m�gulegt a� setja inn athugasemd - reyndur aftur �n s�r-stafa.");
define("LAN_16", "Notendanafn: ");
define("LAN_99", "Athugasemdir");
define("LAN_100", "Fr�ttir");
define("LAN_101", "Sko�anak�nnun");
define("LAN_102", "Svar til: ");
define("LAN_103", "Grein");
define("LAN_104", "Umfj�llun");
define("LAN_105", "Efni");
define("LAN_145", "Skr��: ");
define("LAN_194", "Gestur");
define("LAN_195", "Skr��ur notandi");
define("LAN_310", "Ekki var h�gt a� sam�ykkja sendingu �ar sem �etta notendanafn er � notkun - ef �etta er �itt notendanafn skr��u �ig �� inn til a� senda.");
define("LAN_312", "Tv�skr�� efni - Ekki h�gt a� taka vi�.");
define("LAN_313", "Sta�setning");
define("LAN_314", "breyta athugasemdum");
define("COMLAN_1", "h�r");
define("COMLAN_2", "til a� skr� sig");
define("COMLAN_3", "VILLA !");
define("COMLAN_4", 'Var�andi');
define("COMLAN_5", 'Vegna:');
define("COMLAN_6", 'Svara �essu');
define("COMLAN_7", 'Einkun');
define("COMLAN_8", 'Athugasemdir eru l�star');

define("LAN_315", "Afturvirk leit");
define("LAN_316", "Engin afturvirk leit fyrir �essa fr�tt.");
define("LAN_317", "Breyta afturvirkri leit");

define("LAN_318", "Breyta athugasemd");
define("LAN_319", "breytt");
define("LAN_320", "Uppf�ra athugasemd");

?>