<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Icelandic/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: damaverick $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Members Only");

define("LAN_MEMBERS_0", "lokað svæði");
define("LAN_MEMBERS_1", "Þetta svæði hefur takmarkaðan aðgang.");
define("LAN_MEMBERS_2","Til að fá aðgang vinsamlegast <a href='".e_LOGIN."'>SKRÁÐU ÞIN INN</a>");
define("LAN_MEMBERS_3","eða <a href='".e_SIGNUP."'>skráðu þig</a> sem meðlim/notanda");
define("LAN_MEMBERS_4","Smelltu hér til að fara aftur á AÐALSÍÐU");

?>