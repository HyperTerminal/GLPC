<?php

/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/05/13 01:03:35 $
|     $Author: mcfly_e107 $
| Traduzione Italiana a cura di:
|   e107 italian team http://e107it.org
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "সবাই (উম্মুক্ত)");
define("UC_LAN_1", "অতিখি");
define("UC_LAN_2", "কেউ না (নি:ক্রিয়)");
define("UC_LAN_3", "সদস্য");
define("UC_LAN_4", "শুধু মাত্র পড়া যাবে");
define("UC_LAN_5", "প্রসাশক");
define("UC_LAN_6", "প্রধান প্রসাশক"); 

?>