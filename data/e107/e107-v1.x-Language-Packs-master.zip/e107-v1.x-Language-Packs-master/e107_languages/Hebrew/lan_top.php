<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:35 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "המשתמשים שכתבו הכי הרבה הודעות בפורומים");
define("TOP_LAN_1", "שם משתמש");
define("TOP_LAN_2", "הודעות");
define("TOP_LAN_3", "המשתמשים שפירסמו הכי הרבה תגובות באתר");
define("TOP_LAN_4", "תגובות");
define("TOP_LAN_5", "המשתמשים שפירסמו הכי הרבה הודעות בתיבת הצ'ט");
define("TOP_LAN_6", "דירוג אתר");

//v.616
define("LAN_1", "נושא");
define("LAN_2", "מפרסם");
define("LAN_3", "צפיות");
define("LAN_4", "תגובות");
define("LAN_5", "הודעה אחרונה");
define("LAN_6", "נושאים");
define("LAN_7", "נושאים הכי פעילים");
define("LAN_8", "הכותבים הכי פעילים");


?>