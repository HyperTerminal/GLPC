<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_membersonly.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "חברים בלבד");
define("LAN_MEMBERS_0", "איזור מוגבל");
define("LAN_MEMBERS_1", "זהו איזור מוגבל");
define("LAN_MEMBERS_2", "כדי להיכנס <a href='login.php'>התחבר</a> או");
define("LAN_MEMBERS_3", "or <a href='".e_SIGNUP."'>register</a> as a member	");
define("LAN_MEMBERS_4", "לחץ כאן לחזרה לדף הראשי של האתר");


?>