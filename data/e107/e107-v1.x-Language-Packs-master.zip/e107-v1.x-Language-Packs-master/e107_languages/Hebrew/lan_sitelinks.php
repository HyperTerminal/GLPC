<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_langpacks/e107_languages/Hebrew/lan_sitelinks.php,v $
|     $Revision: 1.1 $
|     $Date: 2006-04-13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "תפריט ראשי");
define("LAN_SITELINKS_502", "איזור ניהול");

?>