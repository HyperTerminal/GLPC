<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 10:56:14 -0800 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/

define ("LAN_PAGE_1", "רשימת עמוד כבויה");
define ("LAN_PAGE_2", "יש דפים לא");
define ("LAN_PAGE_3", "הדף המבוקש לא קיים");
define ("LAN_PAGE_4", "דרג מקור");
define ("LAN_PAGE_5", "תודה לך על דירוג זה מקור");
define ("LAN_PAGE_6", "אין לך הרשאה להציג דף זה");
define ("LAN_PAGE_7", "סיסמה שגויה");
define ("LAN_PAGE_8", "המוגנים על ידי סיסמה עמוד");
define ("LAN_PAGE_9", "סיסמה");
define ("LAN_PAGE_10", "שלח");
define ("LAN_PAGE_11", "רשימת עמוד");
define ("LAN_PAGE_12", "מקור חוקי");
define ("LAN_PAGE_13", "עמוד");


?>