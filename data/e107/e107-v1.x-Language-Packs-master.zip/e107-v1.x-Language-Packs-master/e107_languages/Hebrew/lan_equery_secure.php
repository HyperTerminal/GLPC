<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_equery_secure.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("EQSEC_LAN1", "אתה מופנה לפונקציית אדמין, שינויים במסד הנתונים יכולים לקרות");
define("EQSEC_LAN2", "אנא אשר פעולה זו:");
define("EQSEC_LAN3", "אין מפנה");
define("EQSEC_LAN4", "פעולה מ:");
define("EQSEC_LAN5", "פעולה ל:");
define("EQSEC_LAN6", "בצע פעולה");
define("EQSEC_LAN7", "או בטל");
?>