<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_userposts.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:35 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "הודעות משתמש");

define("UP_LAN_0", "כל ההודעות בפורומים של ");
define("UP_LAN_1", "כל התגובות של ");
define("UP_LAN_2", "נושא");
define("UP_LAN_3", "צפיות");
define("UP_LAN_4", "תגובות");
define("UP_LAN_5", "תגובה אחרונה");
define("UP_LAN_6", "נושאים");
define("UP_LAN_7", "אין תגובות");
define("UP_LAN_8", "אין הודעות");
define("UP_LAN_9", " על ");
define("UP_LAN_10", "תגובה");
define("UP_LAN_11", "פורסם ב: ");
define("UP_LAN_12", "חיפוש");
define("UP_LAN_13", "תגובות");
define("UP_LAN_14", "הודעות בפורומים");
define("UP_LAN_15", "תגובה");
define("UP_LAN_16", "IP כתובת");
?>