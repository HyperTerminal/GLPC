<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_langpacks/e107_languages/Hebrew/lan_user_extended.php,v $
|     $Revision: 1.1 $
|     $Date: 2006-04-13 15:13:35 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "תיבת טקסט");
define("UE_LAN_2", "כפתורי רדיו");
define("UE_LAN_3", "תפריט נפתח למטה");
define("UE_LAN_4", "שדה בסיס נתונים");
define("UE_LAN_5", "איזור טקסט");
define("UE_LAN_6", "Integer");
define("UE_LAN_7", "תאריך");
define("UE_LAN_8", "שפה");

define("UE_LAN_9", "שם");
define("UE_LAN_10", "סוג");
define("UE_LAN_11", "שימוש");

define("UE_LAN_HIDE", "החבא ממשתמשים רגילים");

define("UE_LAN_LOCATION", "מיקום");
define("UE_LAN_LOCATION_DESC", "מיקום משתמש");
define("UE_LAN_AIM", "AIM ");
define("UE_LAN_AIM_DESC", "AIM ");
define("UE_LAN_ICQ", "ICQ");
define("UE_LAN_ICQ_DESC", "ICQ");
define("UE_LAN_YAHOO", "Yahoo! ");
define("UE_LAN_YAHOO_DESC", "Yahoo! ");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN כתובת");
define("UE_LAN_HOMEPAGE", "דף הבית");
define("UE_LAN_HOMEPAGE_DESC", "דף הבית של המשתמש - כתובת");
define("UE_LAN_BIRTHDAY", "יום הולדת");
define("UE_LAN_BIRTHDAY_DESC", "יום הולדת");
define("UE_LAN_LANGUAGE", "שפה");
define("UE_LAN_LANGUAGE_DESC", "משתמש שפה");
define("UE_LAN_COUNTRY", "מדינה");
define("UE_LAN_COUNTRY_DESC", "פרטי מדינה (כולל שולחן db)");

define("LAN_UE_FAIL_HOMEPAGE", "ערך לא חוקי עבור לדף הבית הגדרת");


?>