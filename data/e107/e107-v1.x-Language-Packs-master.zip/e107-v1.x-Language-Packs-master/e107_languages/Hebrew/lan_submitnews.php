<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_submitnews.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "שליחת חדשות");
define("LAN_7", "שם משתמש:");
define("LAN_62", "נושא:");
define("LAN_112", "כתובת אי-מייל:");
define("LAN_133", "תודה לך");
define("LAN_134", "פריט החדשות ששלחת נשלח וייבדק על ידי אחד מהמנהלים בזמן הקרוב..");
define("LAN_135", "פריט חדשות:");
define("LAN_136", "שלח פריט חדשות");
define("NWSLAN_6", "קטגוריה");
define("NWSLAN_10", "אין קטגוריות לחדשות");
define("NWSLAN_11", "אין לך גישה לאיזור זה.");
define("NWSLAN_12", "גישה נדחתה.");
define("SUBNEWSLAN_1", "אתה חייב לכתוב כותרת.\\n");
define("SUBNEWSLAN_2", "אתה חייב לכתוב תוכן בפריט החדשות.\\n");
define("SUBNEWSLAN_3", "הקובץ שצירפת צריך להיות עם סיומת jpg, gif או png");
define("SUBNEWSLAN_4", "קובץ גדול מדי");
define("SUBNEWSLAN_5", "קובץ תמונה");
define("SUBNEWSLAN_6", "(jpg, gif או png)");
define("SUBNEWSLAN_7", "עליך לתת שם וכתובת מייל");
define("SUBNEWSLAN_8", "שגיאה בהעלאת תמונה");


?>