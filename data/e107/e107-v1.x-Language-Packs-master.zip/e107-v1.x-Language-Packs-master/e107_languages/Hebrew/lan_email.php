<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_email.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_EMAIL_1", "מאת:");
define("LAN_EMAIL_2", "כתובת IP של השולח:");
define("LAN_EMAIL_3", "Emailed item from");
define("LAN_EMAIL_4", "שלח אימייל");
define("LAN_EMAIL_5", "Email item to a friend");
define("LAN_EMAIL_6", "I thought you might be interested in this item from");
define("LAN_EMAIL_7", "email to someone");
define("LAN_EMAIL_8", "תגובה");
define("LAN_EMAIL_9", "מצטערים - לא נית לשלוח אימייל");
define("LAN_EMAIL_10", "אימייל נשלח אל");
define("LAN_EMAIL_11", "אימייל נשלח");
define("LAN_EMAIL_12", "שגיאה");
define("LAN_EMAIL_13", "שלח מאמר לחבר");
define("LAN_EMAIL_14", "שלח כתבה לחבר");
define("LAN_EMAIL_15", "שם משתמש:");
define("LAN_EMAIL_106", "כתובת האימייל לא תקינה");
define("LAN_EMAIL_185", "שלח מאמר");
define("LAN_EMAIL_186", "שלח כתבה");
define("LAN_EMAIL_187", "כתובת מייל לשליחה");
define("LAN_EMAIL_188", "I thought you might be interested in this news story from");
define("LAN_EMAIL_189", "I thought you might be interested in this article from");
define("LAN_EMAIL_190", "הכנס קוד");


?>