<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_langpacks/e107_languages/Hebrew/lan_sitedown.php,v $
|     $Revision: 1.1 $
|     $Date: 2006-04-13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "אתר סגור זמנית");
define("LAN_SITEDOWN_00", "סגור זמנית");
define("LAN_SITEDOWN_01", "סגרנו את האתר זמנית לעבודות תחזוקה חיוניות. נשוב אליכם בקרוב. קבלו סליחתנו על חוסר הנוחיות הזמנית.");
?>