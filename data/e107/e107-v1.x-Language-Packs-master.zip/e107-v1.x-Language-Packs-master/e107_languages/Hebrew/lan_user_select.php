<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_user_select.php,v $
|     $Revision: 11346 $
|     $Date: 2010-02-17 10:56:14 -0800 (Wed, 17 Feb 2010) $
|     $Author: secretr $
+----------------------------------------------------------------------------+
*/
define ("US_LAN_1", "המשתמש בחר");
define ("US_LAN_2", "בכיתה בחירת המשתמש");
define ("US_LAN_3", "כל המשתמשים");
define ("US_LAN_4", "מצא משתמש");
define ("US_LAN_5", "משתמש (ים) נמצאו");
define ("US_LAN_6", "חיפוש");

?>