<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_userclass.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:35 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "כולם (ציבורי)");
define("UC_LAN_1", "אורחים");
define("UC_LAN_2", "אף אחד (פעיל)");
define("UC_LAN_3", "חברים");
define("UC_LAN_4", "קריאה בלבד");
define("UC_LAN_5", "מנהל");
define("UC_LAN_6", "מנהל ראשי");
define("UC_LAN_9", "משתמשים חדשים");
define("UC_LAN_10", "Search Bots	");


?>