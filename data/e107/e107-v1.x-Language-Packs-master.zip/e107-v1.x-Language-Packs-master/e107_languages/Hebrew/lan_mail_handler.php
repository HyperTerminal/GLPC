<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_mail_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "יוצר על ידי מערכת אתרים e107");
define("LANMAILH_2", "זהו חלק מהודעה בפורמט MIME.");
define("LANMAILH_3", " לא פורמט כראוי");
define("LANMAILH_4", "שרת דחה כתובת");
define("LANMAILH_5", "אין תגובה מהשרת");
define("LANMAILH_6", "לא ניתן למצוא שרת אי-מייל.");
define("LANMAILH_7", " פועל.");


?>