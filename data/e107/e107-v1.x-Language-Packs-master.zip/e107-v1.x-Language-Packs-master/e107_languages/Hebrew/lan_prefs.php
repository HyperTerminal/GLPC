<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_prefs.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "אתר מופעל e107");
define("LAN_PREF_2", "מערכת אתרים e107");
define("LAN_PREF_3", "אתר זה מופעל בעזרת <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, שמשוחררת ברישיון ה <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL.");
define("LAN_PREF_4", "מצונזר");
define("LAN_PREF_5", "פורומים");

?>