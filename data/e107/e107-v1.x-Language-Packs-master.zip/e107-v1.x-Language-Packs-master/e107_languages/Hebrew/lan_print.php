<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_print.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_PRINT_86", "קטגוריה:");
define("LAN_PRINT_87", "על ידי");
define("LAN_PRINT_94", "פורסם על ידי");
define("LAN_PRINT_135", "פריט חדשות:");
define("LAN_PRINT_303", "פריט חדשות זה הינו מאת");
define("LAN_PRINT_304", "כותרת:");
define("LAN_PRINT_305", "תת כותרת:");
define("LAN_PRINT_306", "זה מאת:");
define("LAN_PRINT_307", "הדפס דף זה");
define("LAN_PRINT_1", "ידידותי להדפסה");


?>