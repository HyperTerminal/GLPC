<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_langpacks/e107_languages/Hebrew/lan_notify.php,v $
|     $Revision: 1.1 $
|     $Date: 2006-04-13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "רישום משתמש");
define("NT_LAN_UV_1", "רישום משתמש אושר");
define("NT_LAN_UV_2", "טבעת רישום משתמשים");
define("NT_LAN_UV_3", "שם משתמש התחברות:");
define("NT_LAN_UV_4", "פרטי ה-IP:");
define("NT_LAN_LI_1", "משתמש מחובר לאתר");
define("NT_LAN_LO_1", "משתמש מנותק מהאתר");
define("NT_LAN_LO_2", " מנותק מהאתר");
define("NT_LAN_FL_1", "השעיית הצפה");
define("NT_LAN_FL_2", "כתובת IP נחסמה בגלל הצפה");
define("NT_LAN_SN_1", "פריט חדשות שנשלח");
define("NT_LAN_NU_1", "עודכן");
define("NT_LAN_ND_1", "פריט חדשות נמחק");
define("NT_LAN_ND_2", "מספר סידורי של פריט חדשות שנמחק");
define("NT_LAN_CM_1", "User Comment Pending Approval	");


?>