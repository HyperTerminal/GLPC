<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_upload_handler.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:35 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "סוג קובץ");
define("LANUPLOAD_2", "זה לא מאושר ונמחק");
define("LANUPLOAD_3", "הועלה בהצלחה");
define("LANUPLOAD_4", "התיקיה לא נמצאת או לא נגישה למשתמשים.");
define("LANUPLOAD_5", "הקובץ שהועלה גדול מדי");
define("LANUPLOAD_6", "גודל הקובץ יותר מגודל הקובץ המותר באתר.");
define("LANUPLOAD_7", "הקובץ הועלה חלקית בלבד.");
define("LANUPLOAD_8", "הקובץ לא הועלה");
define("LANUPLOAD_9", "גודל הקובץ שהועלה 0 בתים");
define("LANUPLOAD_10", "העלאה נכשלה [Duplicate filename] - קובץ עם שם זה כבר קיים");
define("LANUPLOAD_11", "הקובץ לא הועלה , שם הקובץ:");
define("LANUPLOAD_12", "שגיאה");
define("LANUPLOAD_13", "Missing temporary folder");
define("LANUPLOAD_14", "File write failed");
define("LANUPLOAD_15", "Upload not allowed");
define("LANUPLOAD_16", "Unknown Error");
define("LANUPLOAD_17", "Invalid name for uploaded file");
define("LANUPLOAD_18", "The uploaded file exceeds allowable limits.");
define("LANUPLOAD_19", "Too many files uploaded - excess deleted.");


?>