<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_rate.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "הצבע");
define("RATELAN_1", "הצבעות");
define("RATELAN_2", "מהו דירוגך לפריט זה?");
define("RATELAN_3", "תודה לך על הצבעתך");
define("RATELAN_4", "לא מדורג");
define("RATELAN_5", "דרג");

?>