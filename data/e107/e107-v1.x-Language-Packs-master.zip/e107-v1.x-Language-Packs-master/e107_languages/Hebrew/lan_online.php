<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Hebrew/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/13 15:13:34 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "אורחים: ");
define("ONLINE_EL2", "רשומים: ");
define("ONLINE_EL3", "בדף הזה: ");
define("ONLINE_EL4", "מחובר");
define("ONLINE_EL5", "רשומים");
define("ONLINE_EL6", "המשתמש הכי חדש");
define("ONLINE_EL7", "צופה");
define("ONLINE_EL8", "הכי הרבה מחוברים אי פעם: ");
define("ONLINE_EL9", "פועל");
define("ONLINE_EL10", "שם משתמש");
define("ONLINE_EL11", "צופה בדף");
define("ONLINE_EL12", "מגיב אל ");
define("ONLINE_EL13", "פורום");
define("ONLINE_EL14", "נושא");
define("ONLINE_EL15", "דף");
define("CLASSRESTRICTED", "דף מוגבל לקבוצה זו");
define("ARTICLEPAGE", "כתבה/ נושא");
define("CHAT", "צ'אט");
define("COMMENT", "תגובות");
define("DOWNLOAD", "הורדות");
define("EMAIL", "email.php");
define("FORUM", "דף פורום ראשי");
define("LINKS", "קישורים");
define("NEWS", "חדשות");
define("OLDPOLLS", "סקרים ישנים");
define("POLLCOMMENT", "סקר");
define("PRINTPAGE", "הדפס");
define("LOGIN", "מתחבר");
define("SEARCH", "מחפש");
define("STATS", "סטטיסטיקות אתר");
define("SUBMITNEWS", "שלח חדשות");
define("UPLOAD", "העלאות");
define("USERPAGE", "פרופילים");
define("USERSETTINGS", "הגדרות משתמשים");
define("ONLINE", "משתמשים מחוברים");
define("LISTNEW", "פריטים חדשים");
define("USERPOSTS", "הודעות משתמש");
define("SUBCONTENT", "שלח כתבה/נושא");
define("TOP", "מפרסמים הכי פעילים/נושאים הכי פעילים");
define("ADMINAREA", "אזור מנהלים");
define("BUGTRACKER", "מעקב באגים");
define("EVENT", "רשימת אירועים");
define("CALENDAR", "לוח שנה");
define("FAQ", "שאלות נפוצות");
define("PM", "הודעות פרטיות");
define("SURVEY", "משאל");
define("ARTICLE", "כתבה");
define("CONTENT", "דף קשר");
define("REVIEW", "כתבה");

?>