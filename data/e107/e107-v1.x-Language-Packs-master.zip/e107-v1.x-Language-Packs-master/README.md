e107-v1.x-Language-Packs
========================

e107 v1.x Language Packs under development. 

This repo contains INCOMPLETE language packs of e107 v1.x in various languages. They are NOT compatible with e107 v2.x or the files located here: https://github.com/e107inc/e107

To download completed language packs (for v1.x only) and in other languages not found here - please go to http://www.e107.org/download/

Incomplete language packs (with their latest e107 version base, if known):
Bengali
Bosnian
Estonian	(v1.0.0 based)
Greek		(v1.0.3 based)
Hebrew
Icelandic	(v1.0.2 based)
Indonesian
Japanese	(v1.0.3 based)
Korean
Latvian		(v1.0.3 based)
Mongolian
Nepali
Romanian
Serbian
Thai
Turkish		(v1.0.2 based)
Ukrainian	(v1.0.2 based)
Uzbek
Vietnamese