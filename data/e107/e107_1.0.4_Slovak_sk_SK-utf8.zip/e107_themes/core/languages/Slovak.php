<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/core/languages/Slovak.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/05 22:47:30 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Základná téma e107 od <a href='http://e107.org' title='e107 CMS' rel='external'>e107 tímu</a>");
define("LAN_THEME_2", "Komentáre: ");
define("LAN_THEME_3", "Komentáre sú vypnuté");
define("LAN_THEME_4", "Čítať zvyšok ...");
define("LAN_THEME_5", "Spätné sledovanie:");
define("LAN_THEME_8", "v");
define("LAN_THEME_9", "od");
define("LAN_THEME_11", "Posledné novinky");
define("LAN_THEME_12", "Odoslať emailom priateľovi");
define("LAN_THEME_13", "Vytvoriť pdf súbor");
define("LAN_THEME_14", "Vytlačiť");
define("LAN_THEME_15", "Editovať");
define("LAN_THEME_17", "Prihlásiť sa");
define("LAN_THEME_18", "Užívateľské meno");
define("LAN_THEME_19", "Heslo");
define("LAN_THEME_20", "Registrácia");
define("LAN_THEME_21", "Prihlásenie");
define("LAN_THEME_22", "Zabudnuté heslo?");
define("LAN_THEME_23", "Vitajte");
define("LAN_THEME_24", "Administrátor");
define("LAN_THEME_26", "Nastavenia");
define("LAN_THEME_27", "Profil");
define("LAN_THEME_28", "Odhlásenie");
define("LAN_THEME_29", "Zoznam noviniek");
define("LAN_THEME_SING", "Prihlásenie");
define("LAN_THEME_REG", "Registrácia");
define("LAN_SEARCH", "Hľadaj...");
define("LAN_SEARCH_SUB", "Choď");
define("LAN_THEME_SHARE", "Zdieľať na");
define("LAN_THEME_VER", "e107");
define("CM_L13", "od");


?>