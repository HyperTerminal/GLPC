<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/vekna_blue/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/03/21 12:26:46 $
|     $Author: stevedunstan $
|     $Translation: whitewolfsix $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'vekna blue' by <a href='http://e107.org' rel='external'>jalist</a>, based on, and with permission from Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Čítať/poslať komentár:");
define("LAN_THEME_3", "Komentáre sú vypnuté pre túto položku");
define("LAN_THEME_4", "Čítať zvyšok ...");
define("LAN_THEME_5", "Spätné sledovanie:");


?>