<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/pm/languages/admin/Slovak.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/05 22:49:55 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("ADLAN_PM", "Súkromné správy (SS)");
define("ADLAN_PM_1", "Pre aktiváciu, prosím, choďte do administrátorského menu a zvoľte súkromné správy do jednej z vašich menu oblastí. <br /><br />Ak potrebujete skonvertovať správy z predchádzajúcej verzie, choďte do hlavnej konfiguračnej stránky pre tento plugin a vyberte odkaz 'konvertovať'.");
define("ADLAN_PM_2", "Nastavenie Súkromných správ");
define("ADLAN_PM_3", "Nastavenia SS neboli nájdené, použité prednastavené hodnoty ");
define("ADLAN_PM_4", "Možnosti boli aktualizované");
define("ADLAN_PM_5", "Obmedzenie pre vybranú triedu užívateľa už existuje");
define("ADLAN_PM_6", "Obmedzenie bolo úspešne pridané");
define("ADLAN_PM_7", "Obmedzenie nebolo pridané - neznáma chyba");
define("ADLAN_PM_8", "Status obmedzenia bol aktualizovaný");
define("ADLAN_PM_9", " - Obmedzenie bolo úspešne odstránené");
define("ADLAN_PM_10", " - Obmedzenie nebolo odstránené - neznáma chyba");
define("ADLAN_PM_11", " - Obmedzenie bolo úspešne aktualizované");
define("ADLAN_PM_12", "Možnosti SS");
define("ADLAN_PM_13", "Konverzia SS");
define("ADLAN_PM_14", "Obmedzenia SS");
define("ADLAN_PM_15", "Pridať obmedzenie SS");
define("ADLAN_PM_16", "Názov pluginu");
define("ADLAN_PM_17", "Zobraziť novú SS animáciu");
define("ADLAN_PM_18", "Zobraziť užívateľský rozbaľovací zoznam");
define("ADLAN_PM_19", "Časový limit PREČÍTANEJ správy");
define("ADLAN_PM_20", "Časový limit NEPREČÍTANEJ správy");
define("ADLAN_PM_21", "Popup upozornenie na novú SS");
define("ADLAN_PM_22", "Časový limit pre oneskorenie Popup okna");
define("ADLAN_PM_23", "Pridať obmedzenie SS");
define("ADLAN_PM_24", "Počet SS zobrazených na stránku");
define("ADLAN_PM_25", "Aktivovať emailové upozornenie SS");
define("ADLAN_PM_26", "Umožniť užívateľovi požadovať prečítanie prijatia emailového upozornenia");
define("ADLAN_PM_27", "Umožniť zasielanie príloh");
define("ADLAN_PM_28", "Maximálna veľkosť príloh");
define("ADLAN_PM_29", "Umožniť zasielanie všetkým členom");
define("ADLAN_PM_30", "Umožniť zasielanie viacerým príjemcom");
define("ADLAN_PM_31", "Aktivovať zasielanie užívateľskej triede");
define("ADLAN_PM_32", "Aktualizovať nastavenia");
define("ADLAN_PM_33", "Neaktívne (bez limitov)");
define("ADLAN_PM_34", "Súhrny SS");
define("ADLAN_PM_35", "Rozmery schránky SS");
define("ADLAN_PM_36", "Užívateľská skupina");
define("ADLAN_PM_37", "Výpočet obmedzení");
define("ADLAN_PM_38", "Veľkosť obmedzení (v KB)");
define("ADLAN_PM_39", "Došlá pošta:");
define("ADLAN_PM_40", "Odoslaná pošta:");
define("ADLAN_PM_41", "Momentálne nie sú nastavené žiadne obmedzenia.");
define("ADLAN_PM_42", "Aktualizovať obmedzenia");
define("ADLAN_PM_43", "Pridať nové obmedzenie");
define("ADLAN_PM_44", "sekundy");
define("ADLAN_PM_45", "Obmedzenie SS od:");
define("ADLAN_PM_46", "Konverzia SS");
define("ADLAN_PM_47", "Vyzerá to, že nemáte žiadne staré správy z predchádzajúcich verzií, je bezpečné odinštalovať starý plugin.");
define("ADLAN_PM_48", "Máte {OLDCOUNT} správ zo starej verzie, prosím rozhodnite sa, čo chcete s týmito správami urobiť.<br /><br />Pokiaľ budete správy konvertovať, každá úspešne skonvertovaná správa bude zo starého systému vymazaná.
");
define("ADLAN_PM_49", "Konvertovať do novej SS");
define("ADLAN_PM_50", "Vymazať staré správy");
define("ADLAN_PM_51", "SS #{PMNUM} nie je skonvertovaná");
define("ADLAN_PM_52", "konvertované správy");
define("ADLAN_PM_53", "Neboli nájdené žiadne záznamy na koverziu.");
define("ADLAN_PM_54", "Hlavné nastavenia");
define("ADLAN_PM_55", "Obmedzenia");
define("ADLAN_PM_56", "Konverzia");
define("ADLAN_PM_57", "Tento plugin plne rozširuje systém Súkromných správ.");
define("ADLAN_PM_58", "Súkromné správy (SS)");


?>