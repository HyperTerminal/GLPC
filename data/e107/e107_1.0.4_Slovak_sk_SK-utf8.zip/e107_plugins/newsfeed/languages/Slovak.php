<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsfeed/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro, whitewolfsix $
+----------------------------------------------------------------------------+
*/


define("NFLAN_01", "Import RSS noviniek");
define("NFLAN_02", "Tento plugin vyberie rss dodávky z iných internetových stránok a zobrazí ich podľa vašich nastavení");
define("NFLAN_03", "Konfigurovať RSS novinky");
define("NFLAN_04", "Plugin Import RSS noviniek bol úspešne nainštalovaný. Pre pridanie RSS novinky a konfiguráciu sa vráťte na hlavnú stránku administrácie a kliknite na ikonu RSS novinky v sekcii pluginov.");
define("NFLAN_05", "Upraviť");
define("NFLAN_06", "Zmazať");
define("NFLAN_07", "Existujúce RSS novinky");
define("NFLAN_08", "Hlavná stránka RSS noviniek");
define("NFLAN_09", "Vytvoriť RSS novinky");
define("NFLAN_10", "URL k RSS dodávke");
define("NFLAN_11", "Cesta k obrázku");
define("NFLAN_12", "Aktivácia");
define("NFLAN_13", "Nikde (neaktívne)");
define("NFLAN_14", "Len v menu");
define("NFLAN_15", "Vytvoriť RSS novinku");
define("NFLAN_16", "Aktualizovať RSS novinku");
define("NFLAN_17", "vložiť 'predvolené' do rámika k použitiu obrázka definovanom v RSS, pre použitie vášho vlastného obrázka, vložte celú cestu, ponechajte prázdne pre žiadny obrázok.");
define("NFLAN_18", "Aktualizačný interval v sekundách");
define("NFLAN_19", "napr. 3600: RSS noviniek bude aktualizovaná každú hodinu");
define("NFLAN_20", "Len na hlavnej stránke RSS noviniek");
define("NFLAN_21", "Aj v menu aj na stránke RSS noviniek");
define("NFLAN_22", "vyberte si, kde chcete mať RSS noviniek zobrazenú");
define("NFLAN_23", "Import RSS noviniek je pridaný do databázy.");
define("NFLAN_24", "Požadované pole(ia) ostali prázdne.");
define("NFLAN_25", "Import RSS noviniek je aktualizovaný v databáze.");
define("NFLAN_26", "Aktualizačný interval");
define("NFLAN_27", "Možnosti");
define("NFLAN_28", "URL");
define("NFLAN_29", "Dostupné importy RSS noviniek");
define("NFLAN_30", "Názov importovaného RSS");
define("NFLAN_31", "Naspäť do zoznamu RSS noviniek");
define("NFLAN_32", "Nie je možné nájsť import RSS noviniek s tým identifikačným číslom.");
define("NFLAN_33", "Dátum vydania: ");
define("NFLAN_34", "neznámy");
define("NFLAN_35", "poslané od ");
define("NFLAN_36", "Popis");
define("NFLAN_37", "krátky popis RSS, vložte 'prednastavené' pre použitie popisu, ktorý je definovaný v dodávke");
define("NFLAN_38", "Posledné správy");
define("NFLAN_39", "Podrobnosti");
define("NFLAN_40", "Import RSS noviniek je zmazaný");
define("NFLAN_41", "Zatiaľ nebol definovaný žiaden import RSS noviniek");

define("NFLAN_42", "<b>&raquo;</b> <u>Názov importovaného RSS:</u>
	Identifikačným názvom RSS novinky môže byť čokoľvek, čo chcete.
	<br /><br />
	<b>&raquo;</b> <u>URL k RSS dodávke:</u>
	Adresa RSS dodávky
	<br /><br />
	<b>&raquo;</b> <u>Cesta k obrázku:</u>
	Ak má dodávka definovaný obrázok, pre používanie vložte 'prednastavené'. Pre použitie vlastného obrázka, vložte plnú cestu k nemu. A nakoniec, ponechajte prázdne, ak nechcete použiť obrázok.
	<br /><br />
	<b>&raquo;</b> <u>Popis:</u>
	Vložte krátky popis dodávky alebo 'prednastavené' pre použitie popisu, ktorý je definovaný v dodávke (ak tam nejaký je).
	<br /><br />
	<b>&raquo;</b> <u>Aktualizačný interval v sekundách:</u>
	Množstvo sekúnd, ktoré majú prejsť predtým, než je dodávka aktualizovaná, napr.: 1800 pre 30 minút, 3600 pre 1 hodinu.
	<br /><br />
	<b>&raquo;</b> <u>Aktivácia:</u>
	Kde chcete zobraziť výsledky RSS importu? Aby ste videli menu import RSS, budete potrebovať aktivovať menu RSS dodávky na <a href='".e_ADMIN."menus.php'>stránke menu</a>.
	<br /><br />Pre získanie vhodného zoznamu dostupných RSS, navštívte <a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> alebo <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a>");
define("NFLAN_43", "Pomoc pre import RSS noviniek");
define("NFLAN_44", "kliknúť pre zobrazenie");

define("NFLAN_45", "Počet položiek, ktoré sa zobrazia v menu");
define("NFLAN_46", "Počet položiek, ktoré sa zobrazia na hlavnej stránke");
define("NFLAN_47", "0 alebo prázdne pre zobrazenie všetkých");

define("NFLAN_48", "Nespracované dáta  nie je možné uložiť v databáze.");
define("NFLAN_49", "Nie je možné nesériovať rss dáta - používate neštandardnú syntax");

?>