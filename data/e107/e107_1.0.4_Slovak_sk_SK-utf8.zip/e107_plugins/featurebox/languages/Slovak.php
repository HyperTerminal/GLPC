<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/featurebox/languages/Slovak.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("FBLAN_01", "Feature Box");
define("FBLAN_02", "Tento doplnok vám umožňuje zobraziť blok s textom nad vašimi novinkami. Texty sa môžu buď meniť, buď náhodne alebo podľa daného poradia.");
define("FBLAN_03", "Konfigurácia Feature Box");
define("FBLAN_04", "Doplnok Feature Box bol nainštalovaný. Pre pridanie správy a konfiguráciu sa vráťte na hlavnú stránku administrátora a kliknite na ikonu Nástenky oznamov v sekcií doplnkov.");
define("FBLAN_05", "Zatiaľ nenastavené žiadne správy");
define("FBLAN_06", "Súčasné správy:");
define("FBLAN_07", "Titulok / Nadpis");
define("FBLAN_08", "Text správy");
define("FBLAN_09", "Viditeľnosť správy");
define("FBLAN_10", "Vytvoriť správu s textom");
define("FBLAN_11", "Aktualizovať správu");
define("FBLAN_12", "Mód");
define("FBLAN_13", "Náhodné obmieňanie správ");
define("FBLAN_14", "Ukázať len túto správu");
define("FBLAN_15", "Správa uložená.");
define("FBLAN_16", "Správa aktualizovaná.");
define("FBLAN_17", "Nevyplnené polia");
define("FBLAN_18", "Správa zmazaná z Feature Box");
define("FBLAN_19", "Možnosti");
define("FBLAN_20", "Editovať");
define("FBLAN_21", "Zmazať");
define("FBLAN_22", "Typ zobrazenia");
define("FBLAN_23", "Nastavenie vzhľadu");
define("FBLAN_24", "Jednoduchý text");
define("FBLAN_25", "Šablóna");
define("FBLAN_26", "pre každú správu môžete použiť samostatnú šablónu, pridajte šablónu do adresára e107_plugins/featurebox/templates/");


?>