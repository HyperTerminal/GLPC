<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Czech_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/16 11:43:25 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/
define("EC_LAN_RECUR_00", "žiadny");
define("EC_LAN_RECUR_01", "ročný");
define("EC_LAN_RECUR_02", "polročný");
define("EC_LAN_RECUR_03", "štvrťročný");
define("EC_LAN_RECUR_04", "mesačný");
define("EC_LAN_RECUR_05", "štvortýždňový");
define("EC_LAN_RECUR_06", "štrnásťdenný");
define("EC_LAN_RECUR_07", "týždenný");
define("EC_LAN_RECUR_08", "denný");
define("EC_LAN_RECUR_100", "nedeľa v mesiaci");
define("EC_LAN_RECUR_101", "pondelok v mesiaci");
define("EC_LAN_RECUR_102", "utorok v mesiaci");
define("EC_LAN_RECUR_103", "streda v mesiaci");
define("EC_LAN_RECUR_104", "štvrtok v mesiaci");
define("EC_LAN_RECUR_105", "piatok v mesiaci");
define("EC_LAN_RECUR_106", "sobota v mesiaci");
define("EC_LAN_RECUR_1100", "Prvý/á");
define("EC_LAN_RECUR_1200", "Druhý/á");
define("EC_LAN_RECUR_1300", "Tretí/ia");
define("EC_LAN_RECUR_1400", "Štvrtý/á");
define("NT_LAN_EC_1", "Udalosti kalendára udalostí");
define("NT_LAN_EC_2", "Udalosť aktualizovaná");
define("NT_LAN_EC_3", "Aktualizované v");
define("NT_LAN_EC_4", "IP adresa");
define("NT_LAN_EC_5", "Správa");
define("NT_LAN_EC_6", "Kalendár udalostí - udalosť bola pridaná");
define("NT_LAN_EC_7", "Nová udalosť bola pridaná");
define("NT_LAN_EC_8", "Kalendár udalostí - udalosť upravená");
define("EC_ADM_01", "Kalendár udalostí - udalosť pridaná");
define("EC_ADM_02", "Kalendár udalostí - udalosť upravená");
define("EC_ADM_03", "Kalendár udalostí - udalosť zmazaná");
define("EC_ADM_04", "Kalendár udalostí - Hromadné odstránenie");
define("EC_ADM_05", "Kalendár udalostí - Hromadné pridanie");
define("EC_ADM_06", "Kalendár udalostí - Hlavné nastavenie zmenené");
define("EC_ADM_07", "Kalendár udalostí - FE možnosti zmenené");
define("EC_ADM_08", "Kalendár udalostí - Kategória pridaná");
define("EC_ADM_09", "Kalendár udalostí -  Kategória upravená");
define("EC_ADM_10", "Kalendár udalostí - Kategória vymazaná");
define("EC_ADM_11", "Kalendár udalostí - Staršie udalosti vymazané");


?>