<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/counter_menu/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Návštevy administrátorov sa nezapočítavajú.");
define("COUNTER_L2", "Táto stránka dnes ...");
define("COUNTER_L3", "spolu");
define("COUNTER_L4", "Táto stránka ...");
define("COUNTER_L5", "návštevníci");
define("COUNTER_L6", "Server...");
define("COUNTER_L7", "Počítadlo");
define("COUNTER_L8", "Správa admina: <b>Počítadlo prístupov je vypnuté.</b><br />Pre aktivovanie je nutné nainštalovať plugin Štatistiky z <a href='".e_ADMIN."plugin.php'>manažéra pluginov</a> a aktivujte ich z  <a href='".e_PLUGIN."log/admin_config.php'>konfiguračnej stránky</a>.");


?>