<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/newforumposts_main/languages/Slovak.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/09 20:49:05 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("NFPM_LAN_1", "Vlákno");
define("NFPM_LAN_2", "Odosielateľ");
define("NFPM_LAN_3", "Zobrazenia");
define("NFPM_LAN_4", "Odpovede");
define("NFPM_LAN_5", "Posledná odpoveď");
define("NFPM_LAN_6", "Vlákna");
define("NFPM_LAN_7", "od");
define("NFPM_L1", "Tento plugin zobrazuje zoznam nových príspevkov do fóra na vašej úvodnej strane");
define("NFPM_L2", "Posledné príspevky fóra");
define("NFPM_L3", "Pre konfiguráciu kliknite na link v sekcii pluginov administrátorského panela");
define("NFPM_L4", "Aktivovať v ktorej oblasti?");
define("NFPM_L5", "Neaktívne");
define("NFPM_L6", "Vrch strany");
define("NFPM_L7", "Spodok strany");
define("NFPM_L8", "Nadpis");
define("NFPM_L9", "Počet nových príspevkov k zobrazeniu?");
define("NFPM_L10", "Zobraziť vnútri pohyblivej vrstvy?");
define("NFPM_L11", "Výška vrstvy");
define("NFPM_L12", "Nastavenie nových príspevkov fóra");
define("NFPM_L13", "Aktualizuj nastavenia nových príspevkov fóra");
define("NFPM_L14", "Nastavenia nových príspevkov fóra sú aktualizované.");
define("NFPM_L15", "Skontroluj pre zobrazenie nových príspevkov fóra.<br />Prednastavené sú posledné témy.");
define("NFPM_L16", "[užívateľ zmazaný]");
define("NFPM_L17", "Nové príspevky v populárnych témach");
define("NFPM_L18", "Nové príspevky");
define("NFPM_L19", "Žiadne nové príspevky v populárnych témach");
define("NFPM_L20", "Žiadne nové príspevky");
define("NFPM_L21", "Zvýraznené vlákna");
define("NFPM_L22", "Zamknúť zvýraznené vlákno");
define("NFPM_L23", "Oznámenie");
define("NFPM_L24", "Zamknúť vlákno");


?>