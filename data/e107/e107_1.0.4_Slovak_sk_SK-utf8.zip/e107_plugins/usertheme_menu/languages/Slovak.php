<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/usertheme_menu/languages/Slovak.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/09 20:53:10 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("LAN_UMENU_THEME_1", "Nastaviť vzhľad");
define("LAN_UMENU_THEME_2", "Zvoliť vzhľad");
define("LAN_UMENU_THEME_3", "Používané:");
define("LAN_UMENU_THEME_4", "Vyberte vzhľady, ktoré môžu užívatelia používať");
define("LAN_UMENU_THEME_5", "Uložiť");
define("LAN_UMENU_THEME_6", "Vzhľady, ktoré si môžu užívatelia zvoliť");
define("LAN_UMENU_THEME_7", "Skupina uživateľov, ktorá môže zvoliť vlastný vzhľad webu");


?>