<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/content/languages/Slovak/lan_content_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Články");
define("CONT_SCH_LAN_2", "Všetky kategórie článkov");
define("CONT_SCH_LAN_3", "Poslať v odpovedi na článok");
define("CONT_SCH_LAN_4", "v");


?>