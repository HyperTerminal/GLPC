<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Czech/lan_forum_notify.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/31 10:20:35 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/
define("NT_LAN_FT_1", "Udalosti fóra");
define("NT_LAN_FO_1", "Vlákno vo fóre poslal");
define("NT_LAN_MP_1", "Správu vo fóre poslal");
define("NT_LAN_FD_1", "Vlákno vo fóre zmazané");
define("NT_LAN_FP_1", "Správa vo fóre zmazaná");
define("NT_LAN_FM_1", "Vlákno vo fóre presunuté");
define("NT_LAN_FO_3", "Vlákno vo fóre vytvoril");
define("NT_LAN_FO_4", "Názov fóra");
define("NT_LAN_FO_5", "Predmet");
define("NT_LAN_FO_6", "Správa");
define("NT_LAN_FO_7", "Vytvorené nové vlákno vo fóre");
define("NT_LAN_MP_3", "Správu vo fóre vytvoril");
define("NT_LAN_MP_4", "Názov fóra");
define("NT_LAN_MP_6", "Správa");
define("NT_LAN_MP_7", "Nová správa vo fóre vytvorená");
define("NT_LAN_FD_3", "Vlákno vo fóre vytvorené");
define("NT_LAN_FD_4", "Názov fóra");
define("NT_LAN_FD_5", "Predmet");
define("NT_LAN_FD_6", "Správa");
define("NT_LAN_FD_7", "Vlákno je vymazané");
define("NT_LAN_FD_8", "Vlákno vo fóre vymazané");
define("NT_LAN_FP_3", "Správa vo fóre vytvorená");
define("NT_LAN_FP_4", "Názov fóra");
define("NT_LAN_FP_6", "Zpráva");
define("NT_LAN_FP_7", "Správa vo fóre vymazaná");
define("NT_LAN_FP_8", "Správu vo fóre vymazal: ");
define("NT_LAN_FM_3", "Vlákno vytvoril:");
define("NT_LAN_FM_4", "Starý predmet");
define("NT_LAN_FM_5", "Nový predmet");
define("NT_LAN_FM_6", "Starý (zdroj) názov fóra");
define("NT_LAN_FM_7", "Nový (cieľ) názov fóra");
define("NT_LAN_FM_8", "Vlákno bolo presunuté");
define("NT_LAN_FM_9", "Vlákno presunul: ");


?>