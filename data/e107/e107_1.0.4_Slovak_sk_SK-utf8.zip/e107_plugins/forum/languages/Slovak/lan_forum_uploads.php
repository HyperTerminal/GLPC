<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Slovak/lan_forum_uploads.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:35 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Uploady fóra");
define("FRMUP_1", "Uploadované súbory vo fóre");
define("FRMUP_2", "Súbor zmazaný");
define("FRMUP_3", "Chyba: Nie je možné zmazať súbor");
define("FRMUP_4", "Mazanie súboru");
define("FRMUP_5", "Meno súboru");
define("FRMUP_6", "Výsledok");
define("FRMUP_7", "Nájdené vo vlákne");
define("FRMUP_8", "NENÁJDENÉ");
define("FRMUP_9", "Nenájdené žiadne uploadované súbory");
define("FRMUP_10", "Zmazať");


?>