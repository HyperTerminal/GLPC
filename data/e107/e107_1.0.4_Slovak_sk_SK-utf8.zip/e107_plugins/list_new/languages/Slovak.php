<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/list_new/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: whitewolfsix $
+----------------------------------------------------------------------------+
*/
define("LIST_PLUGIN_1", "Prehľad aktualít");
define("LIST_PLUGIN_2", "Tento doplnok umožňuje zobraziť zoznam posledných príspevkov, položiek vo všetkých kategóriach vašich stránok. Môžete zobraziť buď prehľad od vašej poslednej návštevy alebo zobraziť všeobecne zoznam posledných príspevkov. Je dostupný i vo forme menu. Každá sekcia je nastaviteľná v administrácii.");
define("LIST_PLUGIN_3", "Konfigurácia hlavného menu");
define("LIST_PLUGIN_4", "Doplnok Prehľad aktualít je pripravený k použitiu");
define("LIST_PLUGIN_5", "prehľad");
define("LIST_PLUGIN_6", "Tento doplnok nie je nainštalovaný");
define("LIST_ADMIN_1", "aktuálne");
define("LIST_ADMIN_2", "aktualizovať nastavenia");
define("LIST_ADMIN_3", "nastavenia aktualizované");
define("LIST_ADMIN_4", "sekcia");
define("LIST_ADMIN_5", "menu");
define("LIST_ADMIN_6", "stránka");
define("LIST_ADMIN_7", "povolené");
define("LIST_ADMIN_8", "zakázané");
define("LIST_ADMIN_9", "otvorené");
define("LIST_ADMIN_10", "zatvorené");
define("LIST_ADMIN_11", "Upraviť");
define("LIST_ADMIN_12", "Vybrať");
define("LIST_ADMIN_13", "Vitajte na prehľade najnovších aktualít na webovej stránke ".SITENAME." ! Táto stránka zobrazuje zoznam posledných príspevkov v najbežnejších sekciách webovej stránky.");
define("LIST_ADMIN_14", "Aktuality na webe");
define("LIST_ADMIN_15", "Nové položky od vašej poslednej návštevy");
define("LIST_ADMIN_16", "Vitajte na prehľade najnovších aktualít na webe ".SITENAME." ! Táto stránka zobrazuje zoznam posledných príspevkov v najbežnejších sekciách webu.");
define("LIST_ADMIN_SECT_1", "Zobrazované sekcie:");
define("LIST_ADMIN_SECT_2", "Označte, ktoré sekcie budú v prehľade zobrazené");
define("LIST_ADMIN_SECT_3", "");
define("LIST_ADMIN_SECT_4", "Štýl zobrazenia (zobrazená, skrytá)");
define("LIST_ADMIN_SECT_5", "Označte ktoré sekcie budú štandardne otvorené nebo zatvorené");
define("LIST_ADMIN_SECT_6", "");
define("LIST_ADMIN_SECT_7", "autor");
define("LIST_ADMIN_SECT_8", "Označte, či sa má zobraziť autor");
define("LIST_ADMIN_SECT_9", "");
define("LIST_ADMIN_SECT_10", "kategória");
define("LIST_ADMIN_SECT_11", "Označte, či sa má zobraziť kategória");
define("LIST_ADMIN_SECT_12", "");
define("LIST_ADMIN_SECT_13", "dátum");
define("LIST_ADMIN_SECT_14", "Označte, či sa má zobraziť dátum");
define("LIST_ADMIN_SECT_15", "");
define("LIST_ADMIN_SECT_16", "Počet položiek");
define("LIST_ADMIN_SECT_17", "Označte, koľko položiek sa má v každej sekcii zobraziť");
define("LIST_ADMIN_SECT_18", "");
define("LIST_ADMIN_SECT_19", "Poradie položiek");
define("LIST_ADMIN_SECT_20", "Zvoľte poradie sekcií");
define("LIST_ADMIN_SECT_21", "");
define("LIST_ADMIN_SECT_22", "Ikona sekcie");
define("LIST_ADMIN_SECT_23", "Vyberte pre každú sekciu ikonu");
define("LIST_ADMIN_SECT_24", "");
define("LIST_ADMIN_SECT_25", "Názov sekcie");
define("LIST_ADMIN_SECT_26", "Určte názov každej sekcie");
define("LIST_ADMIN_SECT_27", "");
define("LIST_ADMIN_OPT_1", "hlavné");
define("LIST_ADMIN_OPT_2", "aktuálna stránka");
define("LIST_ADMIN_OPT_3", "aktuálne menu");
define("LIST_ADMIN_OPT_4", "nová stránka");
define("LIST_ADMIN_OPT_5", "nové menu");
define("LIST_ADMIN_OPT_6", "možnosti");
define("LIST_ADMIN_MENU_2", "ikona : prednastavená");
define("LIST_ADMIN_MENU_3", "Použiť defaultné odrážky vzhľadu pokiaľ nie je dostupná žiadna ikona alebo pokiaľ je zakázané používanie ikon");
define("LIST_ADMIN_MENU_4", "");
define("LIST_ADMIN_LAN_2", "Nadpis");
define("LIST_ADMIN_LAN_3", "Zadajte nadpis menu");
define("LIST_ADMIN_LAN_4", "");
define("LIST_ADMIN_LAN_5", "Ikona : použité");
define("LIST_ADMIN_LAN_6", "použiť ikonu z každej sekcie");
define("LIST_ADMIN_LAN_7", "");
define("LIST_ADMIN_LAN_8", "znakov");
define("LIST_ADMIN_LAN_9", "Vyberte, koľko znakov zo záhlavia sa má zobraziť");
define("LIST_ADMIN_LAN_10", "nechajte prázdne, ak sa má zobraziť celé záhlavie");
define("LIST_ADMIN_LAN_11", "prípona");
define("LIST_ADMIN_LAN_12", "vyberte príponu, ak je záhlavie dlhšie než stanovený počet znakov");
define("LIST_ADMIN_LAN_13", "nechajte prázdne, ak sa nemá zobraziť žiadna prípona");
define("LIST_ADMIN_LAN_14", "dátum");
define("LIST_ADMIN_LAN_15", "vyberte štýl dátumu");
define("LIST_ADMIN_LAN_16", "Pre viac informácii si preštudujte manuál  <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funkcie na cz.php.net</a>");
define("LIST_ADMIN_LAN_17", "dnešný dátum");
define("LIST_ADMIN_LAN_18", "vyberte štýl dátum, ak pôjde o dnešok");
define("LIST_ADMIN_LAN_19", "Pre viac informácii si preštudujte manuál  <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funkcie na cz.php.net</a>");
define("LIST_ADMIN_LAN_20", "stĺpce");
define("LIST_ADMIN_LAN_21", "vyberte počet stĺpcov");
define("LIST_ADMIN_LAN_22", "Určte koľko stĺpcov chcete zobraziť. Zadané číslo rozdelí stránku do rovnako rozdelených stĺpcov.");
define("LIST_ADMIN_LAN_23", "Uvítacia správa");
define("LIST_ADMIN_LAN_24", "Určite uvítaciu správu, ktorá bude zobrazená ako nadpis stránky");
define("LIST_ADMIN_LAN_25", "");
define("LIST_ADMIN_LAN_26", "Zobrazit prázdne");
define("LIST_ADMIN_LAN_27", "Určite, či sa má správa zobraziť, ak je sekcia prázdna");
define("LIST_ADMIN_LAN_28", "");
define("LIST_ADMIN_LAN_29", "Ikona: prednastavená");
define("LIST_ADMIN_LAN_30", "Použiť defaultné odrážky vzhľadu pokiaľ nie je dostupná žiadna ikona alebo pokiaľ je zakázané používanie ikon");
define("LIST_ADMIN_LAN_31", "");
define("LIST_ADMIN_LAN_32", "História: počet dní");
define("LIST_ADMIN_LAN_33", "maximum dní, o koľko sa užívatelia môžu vrátiť");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dni");
define("LIST_ADMIN_LAN_36", "Historie : ručne");
define("LIST_ADMIN_LAN_37", "Zobraziť zoznam s výberom koľko dní zobrazovať?");
define("LIST_ADMIN_LAN_38", "");
define("LIST_ADMIN_LAN_39", "otvoriť, ak existujú záznamy");
define("LIST_ADMIN_LAN_40", "mali by byť sekcie, ktoré obsahujú záznamy, byť defaultne otvorené");
define("LIST_ADMIN_LAN_41", "");
define("LIST_MENU_1", "Posledné príspevky");
define("LIST_MENU_2", "od");
define("LIST_MENU_3", "on");
define("LIST_MENU_4", "v kategórii");
define("LIST_MENU_5", "dni");
define("LIST_MENU_6", "Koľko dní dozadu zobraziť obsah?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "Články");
define("LIST_NEWS_2", "Žiadne nové články");
define("LIST_COMMENT_1", "komentáre");
define("LIST_COMMENT_2", "Žiadne komentáre");
define("LIST_COMMENT_3", "články");
define("LIST_COMMENT_4", "FAQ");
define("LIST_COMMENT_5", "Ankety");
define("LIST_COMMENT_6", "Dokumenty");
define("LIST_COMMENT_7", "Sledovanie bugov");
define("LIST_COMMENT_8", "Obsah");
define("LIST_COMMENT_9", "Stiahnutia");
define("LIST_COMMENT_10", "Nápadov");
define("LIST_DOWNLOAD_1", "Stahnutia");
define("LIST_DOWNLOAD_2", "Žiadne stiahnutia");
define("LIST_MEMBER_1", "členovia");
define("LIST_MEMBER_2", "žiadni členovia");
define("LIST_CONTENT_1", "obsah");
define("LIST_CONTENT_2", "Žiadny obsah v");
define("LIST_CONTENT_3", "Žiadna platná kategória obsahu");
define("LIST_CHATBOX_1", "Chatbox");
define("LIST_CHATBOX_2", "Žiadne príspevky v chatboxe");
define("LIST_CALENDAR_1", "Kalendár");
define("LIST_CALENDAR_2", "Žiadne akcie v kalendári");
define("LIST_LINKS_1", "Linky");
define("LIST_LINKS_2", "Žiadne linky");
define("LIST_FORUM_1", "Fórum");
define("LIST_FORUM_2", "Žiadne príspevky vo fóre");
define("LIST_FORUM_3", "Zobrazenia:");
define("LIST_FORUM_4", "Odpovede:");
define("LIST_FORUM_5", "Posledný príspevok:");
define("LIST_FORUM_6", "V:");


?>