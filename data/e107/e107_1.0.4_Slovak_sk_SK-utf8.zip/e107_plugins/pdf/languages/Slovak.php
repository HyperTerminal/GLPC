<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/English.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/22 19:49:58 $
|     $Author: e107coders $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Podpora tvorby PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Tento plugin je teraz pripravený na použitie.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF nastavenia");
define("PDF_LAN_3", "aktivované");
define("PDF_LAN_4", "blokované");
define("PDF_LAN_5", "ľavý okraj stránky");
define("PDF_LAN_6", "pravý okraj stránky");
define("PDF_LAN_7", "horný okraj stránky");
define("PDF_LAN_8", "skupina fontov");
define("PDF_LAN_9", "prednastavená veľkosť fontu");
define("PDF_LAN_10", "veľkosť fontu názvu internetových stránok");
define("PDF_LAN_11", "veľkosť fontu url stránky");
define("PDF_LAN_12", "veľkosť fontu čísla stránky");
define("PDF_LAN_13", "zobraziť logo v pdf?");
define("PDF_LAN_14", "zobraziť názov webstránok v pdf?");
define("PDF_LAN_15", "zobraziť tvorcu url stránky v pdf?");
define("PDF_LAN_16", "zobraziť čísla stránky v pdf?");
define("PDF_LAN_17", "aktualizovať");
define("PDF_LAN_18", "PDF nastavenia boli úspešne aktualizované");
define("PDF_LAN_19", "Stránka");
define("PDF_LAN_20", "Chybová správa");

?>