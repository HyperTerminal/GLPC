<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newsletter/languages/Slovak.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:58:14 $
|     $Author: manro $
+----------------------------------------------------------------------------+
*/
define("NLLAN_MENU_CAPTION", "Novinky");
define("NLLAN_01", "Novinky");
define("NLLAN_02", "Poskytuje ľahký a rýchly spôsob na konfigurovanie a odoslanie správ s novinkami");
define("NLLAN_03", "Konfiguruj novinky");
define("NLLAN_04", "Doplnok Novinky bol úspešne nainštalovaný. Pre nastavenie sa vráťte na hlavné menu administrátora a kliknite na 'Novinky' v sekcii doplnky.");
define("NLLAN_05", "Zatial nie sú zadefinované žiadne novinky");
define("NLLAN_06", "Meno");
define("NLLAN_07", "Odberateľ");
define("NLLAN_08", "Možnosti");
define("NLLAN_09", "Ste si istý, že chcete zmazat túto novinku?");
define("NLLAN_10", "Existujúce novinky");
define("NLLAN_11", "Zatiaľ neexistuje žiadna vydanie noviniek");
define("NLLAN_12", "Vydanie");
define("NLLAN_13", "[ Parent ID ] Predmet/Nadpis");
define("NLLAN_14", "Mailované?");
define("NLLAN_15", "Možnosti");
define("NLLAN_16", "áno");
define("NLLAN_17", "Neodoslané - kliknite k odoslaniu");
define("NLLAN_18", "Ste si istý, že chcete odoslať toto vydanie odberateľom?");
define("NLLAN_19", "Ste si istý, že chcete zmazať toto vydanie novín?");
define("NLLAN_20", "Existujúce vydania");
define("NLLAN_21", "Nadpis");
define("NLLAN_22", "Popis");
define("NLLAN_23", "Hlavička");
define("NLLAN_24", "Pätička");
define("NLLAN_25", "Aktualizuj novinky");
define("NLLAN_26", "Vytvor novinky");
define("NLLAN_27", "Novinky sú aktualizované v databáze.");
define("NLLAN_28", "Novinky sú definované a uložené v databáze.");
define("NLLAN_29", "Zatiaľ nie sú definované žiadne novinky.");
define("NLLAN_30", "Novinky");
define("NLLAN_31", "Predmet / Nadpis");
define("NLLAN_32", "Číslo vydania");
define("NLLAN_33", "Text");
define("NLLAN_34", "Aktualizujte Mailing");
define("NLLAN_35", "Vytvorte Mailing");
define("NLLAN_36", "Aktualizujte vydanie novín");
define("NLLAN_37", "Vytvorte vydanie novín");
define("NLLAN_38", "Noviny sú aktualizované v databáze.");
define("NLLAN_39", "Vydanie novín je aktualizované v databáze - pre odoslanie, kliknite na tlačidlo 'Odošlite vydanie' v menu Možnosti.");
define("NLLAN_40", "Odoslanie ukončené - Vydanie odoslané komu:");
define("NLLAN_41", " odberateľ(lia).");
define("NLLAN_42", "Novinky zmazané.");
define("NLLAN_43", "Vydanie noviniek zmazané.");
define("NLLAN_44", "Úvodná strana noviniek");
define("NLLAN_45", "Vytvorte novinky");
define("NLLAN_46", "Vytvorte mailing");
define("NLLAN_47", "Možnosti noviniek");
define("NLLAN_48", "ste prihlásený odberateľom týchto novín - ak sa chcete odhlásiť, stlačte prosím tlačidlo dole.");
define("NLLAN_49", "Ste si istý, že sa chcete odhlásiť z odberu týchto noviniek?");
define("NLLAN_50", "Klikni tlačidlo k prihláseniu sa ( vaša adresa na odber novín je");
define("NLLAN_51", "Odhláste sa");
define("NLLAN_52", "Prihláste sa");
define("NLLAN_53", "Ste si istý, že sa chcete prihlásiť k odberu týchto novín?");
define("NLLAN_54", "Odosielanie");
define("NLLAN_55", "ID");
define("NLLAN_56", "ID informačného spravodaja nie je dostupné");
define("NLLAN_57", "Späť na predchádzajúcu stranu");
define("NLLAN_58", "Chyba");
define("NLLAN_59", "Meno");
define("NLLAN_60", "Email");
define("NLLAN_61", "Akcia");
define("NLLAN_62", "Užívateľ je zablokovaný! (alebo nie je plne prihlásený)");
define("NLLAN_63", "Celkom odberateľov");
define("NLLAN_64", "Späť na hlavnú stranu informačného spravodaja");
define("NLLAN_65", "Prehľad ID odberateľov");


?>