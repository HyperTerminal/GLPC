<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Slovak/lan_otherdb_auth.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/05 22:51:34 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Druh databázy:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Meno užívateľa:");
define("OTHERDB_LAN_4", "Heslo:");
define("OTHERDB_LAN_5", "Databáza");
define("OTHERDB_LAN_6", "Tabuľka");
define("OTHERDB_LAN_7", "Pole užívateľa:");
define("OTHERDB_LAN_8", "Pole hesla:");
define("OTHERDB_LAN_9", "Metóda hesla:");
define("OTHERDB_LAN_10", "Nastav overenie inej db");
define("OTHERDB_LAN_11", "** Ak používate e107 databázu, nasledujúce polia nie sú požadované");


?>