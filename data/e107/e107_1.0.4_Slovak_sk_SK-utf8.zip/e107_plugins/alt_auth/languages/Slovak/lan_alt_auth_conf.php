<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Slovak/lan_alt_auth_conf.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/09 20:11:06 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("LAN_ALT_2", "Aktualizujte nastavenia");
define("LAN_ALT_3", "Zvoľte alternatívny typ overovania");
define("LAN_ALT_4", "Nastavte parametre pre");
define("LAN_ALT_5", "Nastavte overovacie parametre");
define("LAN_ALT_6", "Spojovacia činnosť zlyhala");
define("LAN_ALT_7", "Ak spojenie na alternatívnu metódu zlyhá, ako s tým bude zaobchádzané?");
define("LAN_ALT_8", "Činnosť nenájdeného užívateľa");
define("LAN_ALT_9", "Pokiaľ nie je meno užívateľa nájdené alternatívnou metódou, ako sa to bude riešiť?");
define("LAN_ALT_10", "Neúspešné prihlásenie");
define("LAN_ALT_11", "Použiť užívateľské tabuľky e107");
define("LAN_ALT_PAGE", "Alternatívna autentizácia");


?>