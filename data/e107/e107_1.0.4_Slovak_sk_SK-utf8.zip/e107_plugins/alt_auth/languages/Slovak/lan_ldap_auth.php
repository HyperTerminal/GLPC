<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Slovak/lan_ldap_auth.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/05 22:50:44 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("LDAPLAN_1", "Adresa servera");
define("LDAPLAN_2", "BaseDN alebo Doména<br />Ak LDAP - vložte BaseDN<br />Ak AD - vložte doménu");
define("LDAPLAN_3", "LDAP užívateľ<br />Plný kontext užívateľa, ktorý môže prehľadávať zložky.");
define("LDAPLAN_4", "LDAP heslo<br />Heslo pre LDAP užívateľa.");
define("LDAPLAN_5", "LDAP verzia");
define("LDAPLAN_6", "Nastav LDAP overenie");
define("LDAPLAN_7", "eDirectory vyhľadávací filter:");
define("LDAPLAN_8", "Toto sa použite pre zaistenie, aby bolo užívateľské meno  v správnom strome, <br />napr. '(objectclass=inetOrgPerson)'
");
define("LDAPLAN_9", "Súčasný vyhľadávací filter bude:");
define("LDAPLAN_10", "UPOZORNENIE: Vyzerá to tak, že ldap modul nie je momentálne dostupný, nastavenia pre vašu overovaciu metódu pre LDAP nebude fungovať!");
define("LDAPLAN_11", "Typ servera");


?>