<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/13 15:03:34 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Užívatelia");
define("LAN_20", "Chyba");
define("LAN_112", "Emailová adresa");
define("LAN_137", "Informácie sú dostupné iba pre registrovaných užívateľov");
define("LAN_138", "Registrovaní užívatelia: ");
define("LAN_139", "Poradie:");
define("LAN_140", "Registrovaní užívatelia");
define("LAN_141", "Žiadni registrovaní užívatelia");
define("LAN_142", "Užívateľ");
define("LAN_143", "[Skrytý stav]");
define("LAN_145", "Registrovaný");
define("LAN_146", "Počet návštev od registrácie");
define("LAN_147", "Príspevkov v Chatboxe");
define("LAN_148", "Komentárov");
define("LAN_149", "Príspevkov na fóre");
define("LAN_308", "Skutočné meno");
define("LAN_400", "Neplatný užívateľ");
define("LAN_401", "neuvedené");
define("LAN_402", "Profil užívateľa");
define("LAN_403", "Štatistiky");
define("LAN_404", "Posledná návšteva");
define("LAN_405", "dňami");
define("LAN_406", "Hodnotenie");
define("LAN_407", "žiadne");
define("LAN_408", "bez fotky");
define("LAN_409", "bodov");
define("LAN_410", "Rôzne");
define("LAN_411", "Kliknite sem pre úpravu svojich údajov");
define("LAN_412", "Kliknite sem pre úpravu údajov tohto užívateľa");
define("LAN_413", "vymazať foto");
define("LAN_414", "predchádzajúci člen");
define("LAN_415", "nasledujúci člen");
define("LAN_416", "Pre prístup na túto stránku musíte byť prihlásený");
define("LAN_417", "Hlavný administrátor");
define("LAN_418", "Administrátor");
define("LAN_419", "Ukázať");
define("LAN_420", "Zostupne");
define("LAN_421", "Vzostupne");
define("LAN_422", "Choď");
define("LAN_423", "Zobraziť komentáre");
define("LAN_424", "Zobraziť príspevky vo fóre");
define("LAN_425", "Poslať súkromnú správu");
define("LAN_426", "predchádzajúcej");
define("USERLAN_1", "Vzájomné hodnotie");
define("USERLAN_2", "K zobrazeniu stránky nemáte potrebné práva.");


?>