<?php
/*
+---------------------------------------------------------------+
|        e107 website system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Slovak/lan_contact.php $
|        $Revision: 0.1 $
|        $Id: 2013/06/05 08:53:46 $
|        $Author: Jimako $
|        Encoding: UTF-8
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Aktualizácia hesla");
define("LAN_02", "Prepáčte, mail nebolo možné odoslať - prosím, kontaktujte hlavného administrátora.");
define("LAN_03", "Aktualizovanie hesla");
define("LAN_05", "Pre zmenu hesla zadajte prosím, nasledujúce informácie");
define("LAN_06", "Pokus o aktualizáciu hesla");
define("LAN_07", "Niekto s nasledujúcou IP adresou ");
define("LAN_08", "sa pokúšal o zmenu heslo hlavného administrátora.");
define("LAN_09", "Heslo aktualizované od ");
define("LAN_112", "Emailová adresa použitá pri registrácií ");
define("LAN_156", "Odoslať");
define("LAN_213", "Toto užívateľské meno/heslo nebolo nájdené v databáze.");
define("LAN_214", "Nie je možné aktualizovať heslo");
define("LAN_216", "Pre potvrdenie nového hesla kliknite prosím na tento odkaz ...");
define("LAN_217", "Vaše nové heslo je potvrdené, prihláste sa prosím s novým heslom.");
define("LAN_218", "Vaše užívateľské meno je:");
define("LAN_219", "Heslo priradené tejto emailovej adrese už bolo raz zmenené a nemôže byť resetované znovu. Kontaktujte prosím hlavného administrátora pre viac informácií.");
define("LAN_FPW1", "Užívateľské meno");
define("LAN_FPW2", "Zadajte kód");
define("LAN_FPW3", "Zadaný nesprávny kód");
define("LAN_FPW4", "Požiadavka na zmenu hesla už bola poslaná, ak neobdržíte kontaktný email, oboznámte o tom prosím, hlavného administrátora.");
define("LAN_FPW5", "Požiadavka pre aktualizáciu hesla pre");
define("LAN_FPW6", "Bol vám zaslaný email s odkazom, ktorým potvrdíte vašu požiadavku na zmenu hesla.");
define("LAN_FPW7", "Toto nie je správny odkaz pre zmenu hesla.<br />Prosím, kontaktujte hlavného administrátora pre viac detailov.");
define("LAN_FPW8", "Vaše heslo bolo úspešne zmenené.");
define("LAN_FPW9", "Nové heslo je:");
define("LAN_FPW10", "Prosím");
define("LAN_FPW11", "teraz sa prihláste");
define("LAN_FPW12", "a ihneď si zmeňte heslo pre Vašu väčšiu bezpečnosť.");
define("LAN_FPW13", "prosím, postupujte podľa inštrukcií v emaile pre potvrdenie Vášho hesla.");
define("LAN_FPW14", "bola zaslané od niekoho s IP adresou");
define("LAN_FPW15", "Toto už nie je vaše heslo. Musíte dokončiť zmenu hesla vo vašom emaile.");
define("LAN_FPW16", "Ak ste nežiadali o reset hesla a ak nechcete resetovať vaše heslo, prosím, jednoducho tento email ignorujte");
define("LAN_FPW17", "Odkaz (URL) je platný len nasledujúcich 48 hodín.");
?>