<?php
/*
+---------------------------------------------------------------+
|        e107 website system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Slovak/lan_contact.php $
|        $Revision: 0.1 $
|        $Id: 2013/06/05 08:53:46 $
|        $Author: Jimako $
|        Encoding: UTF-8
+---------------------------------------------------------------+
*/
define("LANINS_TITLE", "Inštalácia e107");
define("LANINS_000", "Neplatné údaje! Inštalácia zastavená.");
define("LANINS_001", "Verzia %1$s");
define("LANINS_002", "Inštalácia");
define("LANINS_002a", "(Krok %1$s z 7)");
define("LANINS_003", "1");
define("LANINS_004", "Výber jazyka");
define("LANINS_004a", "Zvolený jazyk");
define("LANINS_004b", "Jazyk");
define("LANINS_005", "Vyberte si prosím jazyk, ktorý bude použitý počas inštalácie");
define("LANINS_006", "Nastaviť jazyk");
define("LANINS_007", "4");
define("LANINS_008", "Kontrola verzie PHP & MySQL  / Kontrola nastavenia oprávnení");
define("LANINS_008a", "Oprávnenie a kompatibilita súborov");
define("LANINS_009", "Prekontrolovať oprávnenia prístupov k súborom");
define("LANINS_010", "Súbor nie je prístupný pre zápis:");
define("LANINS_010a", "Adresár nie je prístupná pre zápis:");
define("LANINS_011", "Chyba");
define("LANINS_012", "Funkcie MySQL pravdepodobne neexistujú. Toto pravdepodobne znamená, že buď PHP rozšírenie pre MYSQL nie je nainštalovaná alebo inštalácia PHP nebola skompilovaná s podporou MySQL.");
define("LANINS_013", "Nie je možné rozpoznať číslo vašej verzie MySQL. Toto nie je kritická chyba, takže môžete pokračovať v inštalácii, no buďte si vedomí, že e107 vyžaduje MySQL >= 3.23 pre správne fungovanie.");
define("LANINS_014", "Oprávnenia prístupu k súborom");
define("LANINS_015", "PHP verzia");
define("LANINS_016", "MySQL");
define("LANINS_017", "PASS");
define("LANINS_018", "Uistite sa, že všetky súbore na zozname existujú a majú nastavené právo zápisu pre server. Bežne to znamená nastavenie pomocou CHMOD na  Toto normálne vyžaduje nastaviť ich CHMOD na 777, ale záleží na prostredí. Pokiaľ máte problémy, kontaktujte administrátora svojho hostingu.");
define("LANINS_019", "Verzia PHP nainštalovaného na vašom serveri neumožňuje beh e107. e107 vyžaduje PHP verzie od 4.3.0 vyššie, pre správny beh. Bud aktualizujte svoju PHP verziu, alebo kontaktujte vášho poskytovateľa s požiadavkou na aktualizáciu.");
define("LANINS_020", "Pokračovať v inštalácii");
define("LANINS_021", "2");
define("LANINS_022", "Detaily MySQL Servera");
define("LANINS_022a", "Databáza");
define("LANINS_023", "Vložte prosím údaje nastavenia MYSQL.<br /><br /> Ak máte root oprávnenia, môžete vytvoriť novú databázu zaškrtnutím okienka, ak ich nemáte musíte najskôr vytvoriť alebo použiť už existujúcu databázu. Ak mátek dispozícii len jednu databázu, použite prefix, aby mohli s databázou pracovať aj iné skripty. Ak nepoznáte svoje MySQL údaje, kontaktujte svojho poskytovateľa webhostingu.");
define("LANINS_024", "MySQL server:");
define("LANINS_025", "MySQL meno užívateľa:");
define("LANINS_026", "MySQL heslo:");
define("LANINS_027", "MySQL databáza:");
define("LANINS_028", "Vytvoriť databázu?");
define("LANINS_029", "Prefix tabuliek:");
define("LANINS_030", "MySQL server, ktorý chcete, aby e107 používal. Môže obsahovať aj číslo portu, napr. \"hostname:port\" alebo cestu k miestnemu soketu, napr. \":/path/to/socket\" pre localhost.");
define("LANINS_031", "Meno užívateľa, ktoré má e107 používať pri spájaní s MySQL serverom");
define("LANINS_032", "Heslo pre užívateľa, ktorého ste práve vložili");
define("LANINS_033", "MySQL databáza, ktorú chcete, aby e107 používal. Ak má užívateľ oprávnenia pre vytvorenie databázy, môžete zvoliť automatické vytvorenie databázy, ak táto ešte neexistuje.");
define("LANINS_034", "Predpona, ktorú e107 použije pri vytváraní e107 tabuliek. Vhodné pri viacnásobných inštaláciách e107 v jednej databáze.");
define("LANINS_035", "Pokračovať");
define("LANINS_036", "3");
define("LANINS_037", "Overenie spojenia s MySQL");
define("LANINS_038", " a vytvorenie databázy");
define("LANINS_038a", "Validácia databázy");
define("LANINS_039", "Uistite sa prosím, že vyplníte všetky polia, hlavne MySQL server, MySQL meno užívateľa a MySQL databáza (Tieto sú vždy požadované MySQL serverom)");
define("LANINS_040", "Chyby");
define("LANINS_041", "Systém e107 nebol schopný vytvoriť spojenie s MySQL serverom s údajmi, ktoré ste použili. <br /> Vráťte sa, prosím, na poslednú stránku a uistite sa, že informácia je správna.");
define("LANINS_042", "Spojenie s MySQL serverom je vytvorené a overené.");
define("LANINS_043", "Databázu nie je možné vytvoriť, uistite sa prosím, že máte oprávnenie vytvárať databázu na vašom serveri.");
define("LANINS_044", "Databáza bola úspešne vytvorená.");
define("LANINS_045", "Stlačte tlačidlo, prosím, pre postup do ďalšej fázy.");
define("LANINS_046", "5");
define("LANINS_047", "Detaily administrátora");
define("LANINS_047a", "Administrácia");
define("LANINS_048", "Vráťte sa k poslednému kroku");
define("LANINS_049", "Heslá, ktoré ste vložili, nie sú totožné. Vráťte sa späť a skúste to znovu, prosím.");
define("LANINS_050", "XML rozšírenie");
define("LANINS_051", "nainštalované");
define("LANINS_052", "nenainštalované");
define("LANINS_053", "e107 .700 vyžaduje nainštalované XML rozšírenie PHP. Kontaktujte svojho poskytovateľa webhostingu alebo si prečítajte informácie na <a href='http://php.net/manual/en/ref.xml.php' target='_blank'>php.net</a>");
define("LANINS_054", "Existencia zvolenej databázy úspešne overená");
define("LANINS_055", "Potvrdenie inštalácie");
define("LANINS_055a", "Potvrdiť");
define("LANINS_056", "6");
define("LANINS_057", " e107 má teraz všetky potrebné informácie pre dokončenie inštalácie. <br /><br /> Stlačte tlačidlo pre vytvorenie databázových tabuliek a pre uloženie vašich nastavení, prosím.");
define("LANINS_058", "7");
define("LANINS_060", "Nie je možné čítať sql datový súborUistite sa, prosím, že aúbor <b>core_sql.php</b> existuje v zložke <b>/e107_admin/sql</b>.");
define("LANINS_061", "e107 nebol schopný vytvoriť všetky potrebné databázové tabuľky. <br /><br /> Vyčistite databázu a odstráň možné problémy pred tým ako pokus zopakujete.");
define("LANINS_062", "[b]Vitajte na vašej novej internetovej stránke![/b]e107 bol úspešne nainštalovaný a teraz je pripravený prijímať obsah.<br />Váš administračný panel sa [link=e107_admin/admin.php]nachádza tu[/link], kliknite na link, aby ste sa tam dostali. Budete sa musieť prihlásiť s použitím vášho užívateľského mena a hesla, ktoré ste použili počas inštalácie.[b]Podpora[/b]e107 stránka: [link=http://e107.org]http://e107.org[/link], najdete tu FAQ a dokumentáciu k e107.Fóra: [link=http://e107.org/e107_plugins/forum/forum.php]http://e107.org/e107_plugins/forum/forum.php[/link][b]Downloady[/b]Pluginy: [link=http://e107coders.org]http://e107coders.org[/link]Témy: [link=http://e107themes.org]http://e107themes.org[/link]Ďakujeme, že ste sa rozhodli vyskúšať e107 a dúfame, že naplní vaše potreby na internetové stránky.(Túto správu môžete zmazať z administračného panela.)");
define("LANINS_063", "Vitajte v e107");
define("LANINS_069", "e107 bol úspešne nainštalovaný!Z bezpečnostných dôvodov, musíte nastaviť oprávnenia súboru <b>e107_config.php</b> späť na CHMOD 644.Taktiež zmažte install.php z vášho servera potom, čo kliknete na tlačidlo nižšie.");
define("LANINS_070", "e107 nebol schopný uložiť hlavný konfiguračný súbor na váš server.Uistite sa, prosím, že súbor <b>e107_config.php</b> má CHMOD nastavený na 666");
define("LANINS_071", "Dokončenie inštalácie");
define("LANINS_071a", "Hotovo");
define("LANINS_071b", "Vyskytla sa chyba pred dokončením inštalácie");
define("LANINS_071c", "Hotovo s chybami");
define("LANINS_072", "Užívateľské meno administrátora");
define("LANINS_073", "Toto je užívateľské meno, ktoré budete používať pre prihlásenie sa na stránku. Pokiaľ ho chcete používať tiež ako svoje meno pre zobrazenie (display name)");
define("LANINS_074", "Zobrazované meno administrátora");
define("LANINS_075", "Toto je meno, ktoré chcete, aby užívatelia videli vo vašom profile, fóre a iných oblastiach. Nechajte toto pole prázdne, ak chcete, aby bolo zobrazované to isté ako prihlasovacie meno.");
define("LANINS_076", "Heslo administrátora");
define("LANINS_077", "Sem zadajte heslo administrátora");
define("LANINS_078", "Potvrdenie hesla administrátora");
define("LANINS_079", "Pre potvrdenie, prosím, znovu vložte heslo administrátora");
define("LANINS_080", "Email administrátora");
define("LANINS_081", "Vložte svoju emailovú adresu");
define("LANINS_082", "uzivatel@vasestranky.sk");
define("LANINS_083", "Chybná odpoveď MySQL:");
define("LANINS_084", "Inštalačná aplikácia nemôže nadviazať spojenie s databázou");
define("LANINS_085", "Inštalačná aplikácia nemôže vybrať databázu:");
define("LANINS_086", "Meno admina, heslo admina a adminov email sú <b>požadované</b> polia. Vráťte sa na predchádzajúcu stránku, prosím a uistite sa, že ste použili správne informácie.");
define("LANINS_087", "Ostatné");
define("LANINS_088", "Obsah");
define("LANINS_089", "Na stiahnutie");
define("LANINS_090", "Členovia");
define("LANINS_091", "Odoslať novinku");
define("LANINS_092", "Napíšte nám");
define("LANINS_093", "Umožňuje prístup k súkromným položkám menu");
define("LANINS_094", "Príklad súkromnej triedy fóra");
define("LANINS_095", "Kontrola integrity");
define("LANINS_096", "Posledné komentáre");
define("LANINS_097", "[viac ...]");
define("LANINS_098", "Novinky");
define("LANINS_099", "e107 CMS");
define("LANINS_100", "Posledné príspevky fóra");
define("LANINS_101", "Aktualizácia nastavenia menu");
define("LANINS_102", "Dátum / Čas");
define("LANINS_103", "Doplnky pre e107");
define("LANINS_104", "Kontrola");
define("LANINS_105", "Názov databázy alebo jej predpona začínajúca s nejakými číslicami a nasledujúcim \'e\' alebo \'E\' nie je akceptovateľné. <br /> Názov databázy či prefix nemôže byť prázdny.");
define("LANINS_106", "VAROVANIE - E107 nemôže zapisovať do zobrazených adresárov a/alebo súborov. Inštalácia nebude prerušená, znamená to, že isté funkcie nebudú dostupné. <br /><br /> Pre používanie týchto funkcií potrebujete zmeniť práva súboru(ov).");
define("LANINS_107", "e107_config.php už obsahuje údaje");
define("LANINS_108", "Pravdepodobne máte existujúcu inštaláciu");
define("LANINS_DB_UTF8_LABEL", "Previesť databázu na UTF-8?");
define("LANINS_DB_UTF8_CAPTION", "Kódování MySQL:");
define("LANINS_DB_UTF8_TOOLTIP", "Ak je zaškrtnuté, bude sa inštalačný skript snažiť, aby databáza bola UTF-8 kompatibilná. UTF-8 databáza je nutná pre dalšie verzie E107.");
define("LANINS_109", "Inicializácia");
define("LANINS_110", "Komplet");
define("LANINS_111", "Vzhľady pre e107");
define("LANINS_112", "Príručka pre e107");
define("LANINS_113", "");
define("LANINS_121", "e107_config.php už existuje!");
define("LANINS_122", "Pravdepodobne máte existujúcu inštaláciu");
define("LANINS_123", "Ladiace informácie");
define("LANINS_124", "Backtrace");
define("LANINS_125", "Neplatný krok");
define("LANINS_125a", "Chyba");
define("LANINS_WELCOME", "[b]Vitajte na vašich nových webových stránkach![/b] CMS e107 bol úspešne nainštalovaný a je pripravený k okamžitému použitiu. Vaša administratívna sekcia [link=e107_admin/admin.php]se nachádza tu[/link], kliknite na odkaz, budete presmerovaný na prihlasovaciu stránku. Pre vstup do administratívnej sekcie budete vyzvaný k zadaniu prihlasovacieho mena a hesla hlavného administrátora, zadajte meno a heslo, ktoré ste vložili behom inštalácie.
[b]Podpora:[/b] 
[link=http://e107.org/]e107 Stránka projektu e107[/link]
[link=http://e107.org/support]Fórum o e107[/link]
[link=http://wiki.e107.org/]e107 Príručka[/link]
Ďakujeme za inštaláciu e107, zároveň dúfame, že splní vaše očakávania.
[link=http://e107sk.eu/]Portál pre slovenských užívateľov e107[/link]
[link=http://e107.funsite.cz/]Portál pre českých užívateľov e107[/link]");
define("LANINS_NEWS", "[b]Vitajte![/b] e107 je redakčný systém napísaný v jazyku PHP používajúci MYSQL databázu k uchovávaniu obsahu webu (článkov apod.). Je úplne zdarma, plne prispôsobiteľný a v stálom vývoji. Vzhľad webu postaveného na e107 môžete ovlyvňovať pomocou  mnohých šablón. [list][link=http://e107.org/content/Learn-all-about-e107]Všetko, čo potrebujete vedieť o e107[/link]*[link=http://e107.org/content/About-Us:The-Team]Realizačný tím | Prekladatelia | Tím podpory[/link]*[link=http://wiki.e107.org/]Dokumentácia Wiki[/link][/list]");


?>