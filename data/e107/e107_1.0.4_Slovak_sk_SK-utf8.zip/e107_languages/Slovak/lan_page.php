<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Revision: 1.4 $
|     $Date: 2006/11/07 00:15:58 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Výpis stránok je vypnutý");
define("LAN_PAGE_2", "Nie sú tu žiadne stránky");
define("LAN_PAGE_3", "Požadovaná stránka neexistuje");
define("LAN_PAGE_4", "Ohodnoť túto stránku");
define("LAN_PAGE_5", "Ďakujeme, že si ohodnotil túto stránku");
define("LAN_PAGE_6", "Nie si oprávnený zobraziť túto stránku");
define("LAN_PAGE_7", "Nesprávne heslo");
define("LAN_PAGE_8", "Stránka je chránená heslom");
define("LAN_PAGE_9", "Heslo");
define("LAN_PAGE_10", "Odošli");
define("LAN_PAGE_11", "Zoznam stránok");
define("LAN_PAGE_12", "Nesprávna stránka");
define("LAN_PAGE_13", "Stránka");

?>