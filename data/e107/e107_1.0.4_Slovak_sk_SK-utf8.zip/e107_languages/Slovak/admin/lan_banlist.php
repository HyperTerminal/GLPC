<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_banlist.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Zákaz odstránený.");
define("BANLAN_2", "Žiadne zákazy.");
define("BANLAN_3", "Existujúce zákazy");
define("BANLAN_4", "Odstrániť zákaz");
define("BANLAN_5", "Zadajte IP, emailovú adresu, alebo hosta");
define("BANLAN_7", "Dôvod");
define("BANLAN_8", "Zakázať užívateľa");
define("BANLAN_9", "Zakázať užívateľov zo stránky");
define("BANLAN_10", "IP / Email / Dôvod");
define("BANLAN_11", "Auto-vyhostenie: Viac než 10 neúspešných pokusov o prihlásenie");
define("BANLAN_12", "Poznámka: Opačná DNS je momentálne zablokovaná, musí byť povolená, aby bolo možné vyhostiť podľa internetového hostiteľa. Vyhostenie podľa IP a email bude stále normálne fungovať.");
define("BANLAN_13", "Upozornenie: Pre vylúčenie užívateľa podľa užívateľského mena, choďte do užívateľovej administračnej stránky: ");
define("BANLAN_14", "Zoznam zákazov");
define("BANLAN_15", "Správy/Periódy zákazov");
define("BANLAN_16", "Zakazovannie");
define("BANLAN_17", "Dátum zákazu");
define("BANLAN_18", "Zákaz vyprší");
define("BANLAN_19", "Pozamky");
define("BANLAN_20", "Typ");
define("BANLAN_21", "Nikdy");
define("BANLAN_22", "Neznáme");
define("BANLAN_23", "deň/dní");
define("BANLAN_24", "hodiny");
define("BANLAN_25", "Pridať do zoznamu zákazov");
define("BANLAN_26", "Aktuálne");
define("BANLAN_27", "Neplatné znaky v IP adrese odstránené - teraz:");
define("BANLAN_28", "Typ zákazu");
define("BANLAN_29", "Správa na zobrazenie");
define("BANLAN_30", "Trvanie zákazu");
define("BANLAN_31", "(Použite prázdnu strávu, ak si prajete, aby užívateľ uvidel prázdnu obrazovku)");
define("BANLAN_32", "časovo neobmedzený");
define("BANLAN_33", "Nastaveia aktualizované");
define("BANLAN_34", "Vypršalo");
define("BANLAN_35", "Import/Export");
define("BANLAN_36", "Exportuj typy");
define("BANLAN_37", "Oddeľovač polí");
define("BANLAN_38", "Citovať (zaokrúhli každú hodnotu)");
define("BANLAN_39", "Export");
define("BANLAN_40", "Export zoznamu zákazov");
define("BANLAN_41", "Import zoznamu zákazov");
define("BANLAN_42", "Importuj možnosti");
define("BANLAN_43", "Nahradiť všetky existujúce importované zákazy");
define("BANLAN_44", "Použiť dátum/čas expirácie z importu");
define("BANLAN_45", "Import");
define("BANLAN_46", "Súbor k importu");
define("BANLAN_47", "Chyba uploadu súboru");
define("BANLAN_49", "CSV import: Nesúmerné úvodzovky v riadku");
define("BANLAN_50", "CSV import: Chybne zapísaný záznam v riadku");
define("BANLAN_51", "CSV import: Úspešne --NUM-- riadkov importovaných zo súboru");
define("BANLAN_52", "Zoznam povolení");
define("BANLAN_53", "Pridať do zoznamu povolení");
define("BANLAN_54", "Žiadne záznamy v zozname povolení");
define("BANLAN_55", "Dátum položky");
define("BANLAN_56", "IP/Email, Užívateľ");
define("BANLAN_57", "Užívateľ");
define("BANLAN_58", "Pridaj užívateľov do zoznamu povolení");
define("BANLAN_59", "Uprav existujúcu položku zoznamu povolení");
define("BANLAN_60", "Uprav existujúcu položku zoznamu zákazov");
define("BANLAN_61", "Existujúce položky zoznamu povolení");
define("BANLAN_62", "Možnosti");
define("BANLAN_63", "Použiť obrátené DNS pre umožnenie zákazov hostiteľa");
define("BANLAN_64", "Obrátené DNS sprístupnenné počas pridávania zákazu");
define("BANLAN_65", "Zapnutie tejto možnosti Vám dovolí zakázať užívateľov podľa mena internetového hostiteľa, skôr ako iba podľa IP, alebo emailovej adresy. <br /> POZNÁMKA: Môže zasiahnúť do času načítavania stránky na niektorých hostiteľoch, alebo ak server neodpovedá");
define("BANLAN_66", "Keď nastane zákaz , táto možnosť pridá k príčíne doménu zablokovanej adresy");
define("BANLAN_67", "Nastaviť maximálnu prístupovú intenzitu");
define("BANLAN_68", "Toto určí maximálne číslo prístupov na stránku v 5-minútových periódach");
define("BANLAN_69", "pre užívateľov");
define("BANLAN_70", "pre návštevníkov");
define("BANLAN_71", "");
define("BANLAN_72", "Možnosti zákazu");
define("BANLAN_73", "Toto reštartuje časový úsek zákazov a ak zablokovaný užívateľ navštívi stránku");
define("BANLAN_74", "Údržba listiny zákazov");
define("BANLAN_75", "Odstrániť vypršané zákazy zo zoznamu");
define("BANLAN_76", "Vykonať");
define("BANLAN_77", "Správy/Časové úseky zákazov");
define("BANLAN_78", "Počet aktívnych záznamov prekročený (--HITS-- žiadostí v rámci prideleného času)");
define("BANLAN_79", "");
define("BANLAN_80", "");
define("BANLAN_100", "Neznáme");
define("BANLAN_101", "Manuálne");
define("BANLAN_102", "Pretečenie");
define("BANLAN_103", "Počet aktívnych záznamov");
define("BANLAN_104", "Zlyhalo prihlásenie");
define("BANLAN_105", "Importované");
define("BANLAN_106", "Užívateľ");
define("BANLAN_107", "Neznáme");
define("BANLAN_108", "Neznáme");
define("BANLAN_109", "Staré");
define("BANLAN_110", "");
define("BANLAN_111", "Zadané adminom");
define("BANLAN_112", "Pokusy aktualizovať stranku príliš rýchlo");
define("BANLAN_113", "Pokusy načítať stránku príliž často z tej istej adresy");
define("BANLAN_114", "Viacnásobné zlyhanie prihlásenia od toho istého užívateľa");
define("BANLAN_115", "Pridané z externého zoznamu");
define("BANLAN_116", "IP adresa zablokovaná z účtu z užívateľského zákazu");
define("BANLAN_117", "Náhradný dôvod");
define("BANLAN_118", "Náhradný dôvod");
define("BANLAN_119", "Indikuje chybu importu - predošle importovaných zákazov");
define("BANLAN_120", "Neznáme");


?>