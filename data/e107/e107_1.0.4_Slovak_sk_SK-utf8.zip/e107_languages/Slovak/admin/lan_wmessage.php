<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_wmessage.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Uvítacie správy");
define("WMLAN_01", "Vytvoriť novú správu");
define("WMLAN_02", "Správa");
define("WMLAN_03", "Viditeľnosť");
define("WMLAN_04", "Text správy");
define("WMLAN_05", "Uzavretá");
define("WMLAN_06", "Označte, ak chcete aby bola správa renderovaná v samostatnom boxe");
define("WMLAN_07", "Povoliť štandardný systém použitia kódu {WMESSAGE}:");
define("WMLAN_09", "Žiadne uvítacie správy");
define("WMLAN_10", "Popis správy");


?>