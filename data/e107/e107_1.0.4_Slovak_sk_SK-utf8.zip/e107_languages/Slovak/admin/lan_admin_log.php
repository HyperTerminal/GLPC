<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Slovak/admin/lan_admin_log.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Záznamy admina (log)");
define("LAN_ADMINLOG_1", "Dátum");
define("LAN_ADMINLOG_2", "Nadpis");
define("LAN_ADMINLOG_3", "Popis");
define("LAN_ADMINLOG_4", "IP užívateľa");
define("LAN_ADMINLOG_5", "ID užívateľa");
define("LAN_ADMINLOG_6", "Informačná ikona");
define("LAN_ADMINLOG_7", "Informačná správa");
define("LAN_ADMINLOG_8", "Upozorňovacia ikona");
define("LAN_ADMINLOG_9", "Upozorňovacia správa");
define("LAN_ADMINLOG_10", "Varujúca ikona");
define("LAN_ADMINLOG_11", "Varujúca zpráva");
define("LAN_ADMINLOG_12", "Ikona závažnej chyby");
define("LAN_ADMINLOG_13", "Zpráva o závažnej chybe");


?>