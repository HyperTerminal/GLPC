<?php
$text = "From this screen you can create custom menus or custom pages with your own content in them.<br /><br />
Please see <a href='http://docs.e107.org?Custom Pages'>http://docs.e107.org?Custom Pages</a>";

$ns -> tablerender(CUSLAN_18, $text);
?>