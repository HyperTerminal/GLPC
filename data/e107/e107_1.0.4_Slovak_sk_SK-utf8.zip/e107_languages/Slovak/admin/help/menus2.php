<?php
$caption = "Menu Help";
$text .= "You can arrange where and in which order your menu items are displayed from here. Use the arrows to move the menus up and down until you are satisfied with their positioning.<br />
The menu items in the middle of the screen are de-activated, you can activate these by choosing a location to put them in.
";

$ns -> tablerender("Menus Help", $text);
?>