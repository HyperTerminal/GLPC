<?php
$text = "You set polls/surveys from this page, just type in the poll title and options, preview it and if all looks ok tick the box to make it active.<br /><br />
To see the poll, go to your menus page and make sure poll_menu is activated.";

$ns -> tablerender("Polls", $text);
?>