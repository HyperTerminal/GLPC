<?php
$text = "Use this page to configure your mail settings for site-wide mailing functions. The mail out form also allows you to send out a mail-shot to all your users.";
$ns -> tablerender("Mail Help", $text);
?>