<?php
$text = "If your MySql server version supports it you can switch to the MySql sort method which is faster than the PHP sort method.<br /><br />

<b>Chars</b> This is the number of text characters that will be displayed in the search result summary.<br /><br />
<b>Results</b> This is the number of results that will show per page.";
$ns -> tablerender("Search Help", $text);
?>