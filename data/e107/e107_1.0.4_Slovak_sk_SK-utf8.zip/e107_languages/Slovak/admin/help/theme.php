<?php
$text = "The theme manager allows you to set your site's public theme and your admin areas theme.";
$ns -> tablerender("Theme Manager Help", $text);
?>