<?php
$text = " Extended user fields allow you to add additional types of data a user is able to specify as part of their profile.";
$ns -> tablerender(" Extended User Fields Help", $text);
?>