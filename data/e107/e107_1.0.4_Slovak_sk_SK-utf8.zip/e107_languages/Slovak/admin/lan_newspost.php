<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_newspost.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("NWSLAN_1", "Novinka zmazaná");
define("NWSLAN_2", "Prosím, potvrďte zmazanie tejto novinky.");
define("NWSLAN_3", "Žiadne novinky.");
define("NWSLAN_4", "Existujúce novinky");
define("NWSLAN_5", "Otvoriť HTML editor");
define("NWSLAN_6", "Kategória");
define("NWSLAN_9", "potvrďte");
define("NWSLAN_10", "Žiadne kategórie noviniek");
define("NWSLAN_11", "+/e/- Kategórií noviniek");
define("NWSLAN_12", "Nadpis");
define("NWSLAN_13", "Text novinky");
define("NWSLAN_14", "Rozšírený text");
define("NWSLAN_15", "Komentáre");
define("NWSLAN_18", "Povolí zasielanie komentárov k novinkám");
define("NWSLAN_19", "Aktivita");
define("NWSLAN_21", "Aktivovať medzi");
define("NWSLAN_22", "Viditeľnosť");
define("NWSLAN_24", "Ukázať znovu");
define("NWSLAN_25", "Aktualizovať");
define("NWSLAN_26", "Uložiť");
define("NWSLAN_27", "Ukázať");
define("NWSLAN_29", "Novinky");
define("NWSLAN_31", "Novinka");
define("NWSLAN_32", "zmazať");
define("NWSLAN_33", "Kategórie noviniek");
define("NWSLAN_34", "Zaslané novinky");
define("NWSLAN_35", "Kategória noviniek uložená");
define("NWSLAN_36", "Kategória noviniek aktualizovaná");
define("NWSLAN_37", "Ste si istý, že chcete zmazať túto kategóriu?");
define("NWSLAN_38", "Ste si istý, že chcete zmazať túto zaslanú novinku?");
define("NWSLAN_39", "Ste si istý, že chcete zmazať túto novniku?");
define("NWSLAN_40", "Nadpis");
define("NWSLAN_42", "Bez nadpisu");
define("NWSLAN_43", "Žiadne novinky");
define("NWSLAN_44", "Úvodná stránka noviniek");
define("NWSLAN_45", "Vytvoriť novú novinku");
define("NWSLAN_46", "Kategórie");
define("NWSLAN_47", "Zaslané novinky");
define("NWSLAN_48", "Nastavenia noviniek");
define("NWSLAN_49", "Zaslal");
define("NWSLAN_51", "Existujúce kategórie noviniek");
define("NWSLAN_52", "Meno kategórie");
define("NWSLAN_53", "Ikona kategórie");
define("NWSLAN_54", "Zobraziť ikony");
define("NWSLAN_55", "Aktualizovať kategóriu noviniek");
define("NWSLAN_56", "Vytvoriť kategóriu noviniek");
define("NWSLAN_57", "Novinka");
define("NWSLAN_58", "Poslať");
define("NWSLAN_59", "Žiadne zaslané novinky");
define("NWSLAN_62", "Choď na stránku:");
define("NWSLAN_63", "Hľadať novinky");
define("NWSLAN_66", "Upload");
define("NWSLAN_67", "Obrázok");
define("NWSLAN_68", "Súbor");
define("NWSLAN_69", "Uploaduje obrázok alebo súbor pre použitie v novinke");
define("NWSLAN_72", "Ukázať novinku iba medzi nasledujúcimi dátumami");
define("NWSLAN_73", "Typ zobrazenia");
define("NWSLAN_74", "Zvoľte ako a kde budú novinky zobrazené");
define("NWSLAN_75", "Prednastavené - zobraziť na úvodnej stránke");
define("NWSLAN_76", "Len nadpis - zobraziť na údvodnej stránke");
define("NWSLAN_77", "Zobraziť v inom menu noviniek");
define("NWSLAN_79", "Vyčistit formulár");
define("NWSLAN_83", "Rozšírený text novinky");
define("NWSLAN_84", "Zvoľte, ktorí návštevníci môžu vidieť novinku");
define("NWSLAN_86", "Zobrazovať zoznam kategórii ako pätičku správ");
define("NWSLAN_87", "Zobrazovať kategórie správ v stĺpcoch?");
define("NWSLAN_88", "Počet noviniek zobrazených na stránku?");
define("NWSLAN_89", "Uložiť nastavenia noviniek");
define("NWSLAN_90", "Nastavenia noviniek");
define("NWSLAN_100", "Povoliť nahrávanie obrázkov pri zasielaných novinkách");
define("NWSLAN_101", "Automaticky orezávať uploadované obrázky");
define("NWSLAN_102", "šírka v pixeloch<br /> alebo nechajte prázdne pre vypnutie.");
define("NWSLAN_103", "Poslať znovu");
define("NWSLAN_104", "napísal");
define("NWSLAN_105", "Označte pre nastavenie dátumu novinky na aktuálny dátum");
define("NWSLAN_106", "Zasielanie noviniek prístupné:");
define("NWSLAN_107", "Zapnúť WYSIWYG editor na stránke zaslaných noviniek.");
define("NWSLAN_108", "Zap");
define("NWSLAN_111", "Ukázať novú dátumovú hlavičku");
define("NWSLAN_112", "Ak je táto voľba povolená, pole obsahujúce dátum bude zobrazené nad novinkami poslanými nasledujúci deň. Použiteľné pre odlíšenie noviniek zaslaných v rôzne dni");
define("NWSLAN_113", "Použiť neštandardné šablóny pre rozloženie noviniek");
define("NWSLAN_114", "Použiť vlastné rozloženie pre novinky, ak ho vaša téma podporuje");
define("NWSLAN_115", "Počet noviniek zobrazených v archíve?");
define("NWSLAN_116", "Pokiaľ meníte počet noviniek na stranu, tak nastavenie najprv uložte a až potom meňte túto voľbu (0 znamená neaktivované)");
define("NWSLAN_117", "Nastaviť nadpis pre archív noviniek");
define("NWSLAN_119", "Nastavenia uložené");
define("NWSLAN_120", "Text, ktorý sa zobrazí nad formulárom zasielanej novinky");
define("LAN_NEWS_5", "Chyba! - nie je možné aktualizovať novinku!");
define("LAN_NEWS_6", "Novinka uložená.");
define("LAN_NEWS_7", "Chyba! - nie je možné uložiť novinku!");
define("LAN_NEWS_9", "Je nastavený len nadpis - <b>budú zobrazené len nadpisy noviniek</b>");
define("LAN_NEWS_10", "Táto novinka je <b>neaktívna</b> (Nebude zobrazená na úvodnej stránke).");
define("LAN_NEWS_11", "Táto novinka je <b>aktívna</b> (Bude zobrazená na úvodnej stránke).");
define("LAN_NEWS_12", "Komentáre sú <b>zapnuté</b>.");
define("LAN_NEWS_13", "Komentáre sú <b>vypnuté</b>.");
define("LAN_NEWS_14", "<br />Doba aktivity:");
define("LAN_NEWS_15", "Dĺžka textu novinky:");
define("LAN_NEWS_16", "b. Dĺžka rozšíreného textu novinky:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info");
define("LAN_NEWS_19", "Teraz");
define("LAN_NEWS_21", "Novinka aktualizovaná.");
define("LAN_NEWS_22", "Náhľad obrázkov");
define("LAN_NEWS_23", "Zvoľte náhlad pre obrázok / ikonu pre túto novinku");
define("LAN_NEWS_24", "Obrázok + autom.miniatúra");
define("LAN_NEWS_25", "Veľkosť autom.miniatúry");
define("LAN_NEWS_26", "pridať nový upload");
define("LAN_NEWS_27", "Sumár");
define("LAN_NEWS_28", "Zvýraznené");
define("LAN_NEWS_29", "Zvoľte, či bude novinka zvýraznená");
define("LAN_NEWS_30", "Ak je táto voľba povolená, novinky sa budú objavovať nad všetkými ostatnými");
define("LAN_NEWS_31", "Táto novinka je <b>zvýraznená</b> (je zobrazovaná nad ostatnými novinkami).");
define("LAN_NEWS_32", "Dátum vytvorenia");
define("LAN_NEWS_33", "Nastavte dátum vytvorenia pre túto novinku.");
define("LAN_NEWS_34", "Spätné sledovanie novinky");
define("LAN_NEWS_35", "Pridať URL spätného sledovania");
define("LAN_NEWS_36", "<b>Pingback</b> (pošle pingback na všetky URL v tejto novinke)");
define("LAN_NEWS_37", "<b>URL sledovania:</b> (jedno URL na riadok)");
define("LAN_NEWS_38", "Vložiť obrázky");
define("LAN_NEWS_39", "kliknite na súbor pre jeho vloženie na pozíciu kurzora");
define("LAN_NEWS_40", "Vložiť odkaz na download");
define("LAN_NEWS_42", "Súbory");
define("LAN_NEWS_44", "Sledovanie je vypnuté.");
define("LAN_NEWS_45", "ID");
define("LAN_NEWS_46", "Položka novinky nebola aktualizovaná, pretože neboli vykonané žiadne zmeny.");
define("LAN_NEWS_48", "Bez obrázku");
define("LAN_NEWS_49", "Typ zobrazenia");
define("LAN_NEWS_50", "Údržba");
define("LAN_NEWS_51", "Prepočítať počet komentárov");
define("LAN_NEWS_52", "Pokračovať");
define("LAN_NEWS_53", "Aktualizácia dokončená. ");
define("LAN_NEWS_54", "Údržba noviniek");
define("LAN_NEWS_55", "Autor (Publikované):");
define("LAN_NEWS_56", "Publikované");
define("LAN_NEWS_61", "Odstrániť tiež nepovolené komentáre");
define("LAN_NEWS_62", "Chyba v prístupe k databáze alebo sa nenašli nové položky");


?>