<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_search.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("SEALAN_1", "Konfigurácia hľadania");
define("SEALAN_2", "Počet znakov zobrazených vo výsledkoch hľadania:");
define("SEALAN_3", "Metóda triedenia hľadaní:");
define("SEALAN_6", "Komentáre");
define("SEALAN_7", "Registrovaní užívatelia");
define("SEALAN_10", "Zobraziť dôležitosť výsledkov:");
define("SEALAN_11", "Povoliť užívateľom výber lokácií hľadania:");
define("SEALAN_12", "Obmedziť čas medzi hľadaniami (max 5 minút):");
define("SEALAN_13", "Obmedziť na jedno hľadanie každých");
define("SEALAN_14", "sekúnd");
define("SEALAN_15", "Hľadanie prístupné pre triedu užívateľov");
define("SEALAN_16", "Áno");
define("SEALAN_17", "Nie");
define("SEALAN_18", "Hľadať v komentároch (ak sú komentáre aktivované)");
define("SEALAN_19", "Povoliľ užívateľom hľadanie vo viac ako jednej lokácií na raz:");
define("SEALAN_20", "Hlavné nastavenia");
define("SEALAN_21", "Lokácie hľadania");
define("SEALAN_22", "Prednastavené");
define("SEALAN_23", "Alternatíva:");
define("SEALAN_24", "Typ");
define("SEALAN_25", "Trieda užívateľov");
define("SEALAN_26", "Predtitulok textu");
define("SEALAN_30", "Zvýraznenie hľadaných výrazov na stránkach:");
define("SEALAN_31", "PHP limitované na");
define("SEALAN_32", "výsledkov (prázdne pre žiadne limity)");
define("SEALAN_33", "Nieje možné prepnúť na MySQL metódu hľadania, pretože táto funkcia potrebuje minimálne verziu MySQL 4.0.1.");
define("SEALAN_34", "Vaša verzia je");
define("SEALAN_35", "Metóda výberu lokácií hľadania:");
define("SEALAN_36", "Roletový výber");
define("SEALAN_37", "Zaškrtávacie polia");
define("SEALAN_38", "Označovacie polia");
define("SEALAN_39", "Vlastné stránky");
define("LAN_SEARCH_98", "Novinky");
define("LAN_197", "Downloady");
define("LAN_418", "Vlastné stránky");
define("SEALAN_40", "Možnosti hľadania");
define("SEALAN_41", "Hlavná stránka");
define("SEALAN_42", "Predvoľby");
define("SEALAN_43", "Úprava vyhľadávacích nastavení pre");
define("SEALAN_44", "Užívateľská trieda umožňuje vyhľadávanie v tejto oblasti");
define("SEALAN_45", "Počet výsledkov zobrazovaných na stránku");
define("SEALAN_46", "Počet znakov v súhrne výsledku vyhľadávania");
define("SEALAN_47", "Porovnať len celé slová:");
define("SEALAN_48", "Toto nastavenie je možné použiť len v prípade, že metóda triedenia vyhľadávania je PHP. Ak vaša stránka využíva znakové jazyky (Čínštinu alebo Japonštinu) je nutné túto voľbu vypnúť.");
define("SEALAN_49", "Ak vaša stránka obsahuje znakové jazyky (Čínštinu alebo Japonštinu), musíte použiť PHP metódu triedenia.");


?>