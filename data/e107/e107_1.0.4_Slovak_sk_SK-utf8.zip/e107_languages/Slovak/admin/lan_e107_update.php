<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_e107_update.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Akcia");
define("LAN_UPDATE_3", "Nie je potrebné");
define("LAN_UPDATE_5", "Dostupná aktualizácia");
define("LAN_UPDATE_7", "Vykonané");
define("LAN_UPDATE_8", "Aktualizácia z");
define("LAN_UPDATE_9", "na");
define("LAN_UPDATE_10", "Jsou k dispozici aktualizace");
define("LAN_UPDATE_11", "úprava z .617 na .7 pokračuje");
define("LAN_UPDATE_12", "Jedna z vašich tabuliek obsahuje zdvojené položky.");


?>