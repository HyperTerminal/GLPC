<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_cache.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Status systémovej vyrovnávacej pamäte");
define("CACLAN_2", "Nastaviť vyrovnávaciu pamäť");
define("CACLAN_3", "Vyrovnávacia pamäť systému");
define("CACLAN_4", "Stav Vyrovnávacej pamäte nastavený");
define("CACLAN_5", "Vyprázdniť Vyrovnávaciu pamäť");
define("CACLAN_6", "Vyrovnávacia pamäť vyprázdnená");
define("CACLAN_7", "Vyrovnávacia pamäť vypnutá");
define("CACLAN_9", "Údaje pamäte ukladať do súborov na disk");
define("CACLAN_10", "Cache adresár nieje zapisovateľný. Prosím, nastavte práva tohto adresára na CHMOD 777");


?>