<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Vymazať všetkých užívateľov z tejto triedy.");
define("UCSLAN_2", "Užívatelia triedy aktualizovaný.");
define("UCSLAN_3", "Trieda zmazaná.");
define("UCSLAN_4", "Prosím, potvrďte zmazanie tejto témy.");
define("UCSLAN_5", "Trieda aktualizovaná.");
define("UCSLAN_6", "Trieda uložená.");
define("UCSLAN_7", "Žiadne triedy užívateľov.");
define("UCSLAN_8", "Existujúce triedy užívateľov");
define("UCSLAN_9", "Žiadna ikona");
define("UCSLAN_10", "Trieda neodstránená - je to trieda jadra, alebo je použitá ako definícia inej triedy, tiež ako hlavná, alebo ako upravovaná trieda");
define("UCSLAN_11", "potvrďte");
define("UCSLAN_12", "Názov triedy");
define("UCSLAN_13", "Popis triedy");
define("UCSLAN_14", "Aktualizovať triedu užívateľov");
define("UCSLAN_15", "Vytvoriť novú triedu");
define("UCSLAN_16", "Pridať užívateľa do triedy");
define("UCSLAN_17", "Odstrániť");
define("UCSLAN_18", "Vyprázdniť triedu");
define("UCSLAN_19", "Pridať užívateľa do triedy");
define("UCSLAN_20", ".");
define("UCSLAN_21", "Nastavenia užívateľských tried");
define("UCSLAN_22", "Užívatelia - kliknite pre presun ...");
define("UCSLAN_23", "Užívatelia v triede ...");
define("UCSLAN_24", "Kto môže spravovať triedu -");
define("UCSLAN_25", "Definovať/Upraviť triedy");
define("UCSLAN_26", "Trieda užívateľov");
define("UCSLAN_27", "Pomoc pri ladení");
define("UCSLAN_28", "Uprav triedu užívateľov");
define("UCSLAN_29", "Táto trieda nemôže byť odstránená");
define("UCSLAN_30", "Krátky názov zobrazený vo vyberači");
define("UCSLAN_31", "Informácie o použiteľnosti triedy");
define("UCSLAN_32", "");
define("UCSLAN_33", "Určí, ktorí užívatelia uvidia túto triedu v rolovacom výpise");
define("UCSLAN_34", "Viditeľnosť triedy");
define("UCSLAN_35", "Rodič triedy");
define("UCSLAN_36", "");
define("UCSLAN_37", "Musíte vložiť názov triedy");
define("UCSLAN_38", "Začiatočná trieda užívateľa");
define("UCSLAN_39", "Žiadne triedy, ktoré môžu byť nastavené");
define("UCSLAN_40", "Nastav začiatočné triedy");
define("UCSLAN_41", "Nastavenia aktualizované");
define("UCSLAN_42", "Žiadna zmena - žiadna aktualizácia");
define("UCSLAN_43", "Existujúce triedy:");
define("UCSLAN_44", "Žiadne");
define("UCSLAN_45", "");
define("UCSLAN_46", "");
define("UCSLAN_47", "");
define("UCSLAN_48", "Overenie emailom, alebo administrátorom");
define("UCSLAN_49", "");
define("UCSLAN_50", "Možnosti/Nastavenia");
define("UCSLAN_51", "Funkcie užívateľovej triedy");
define("UCSLAN_52", "Možnosti nastavenia");
define("UCSLAN_53", "Výstraha! Používajte tieto nastavenia, iba ak viete, čo robia");
define("UCSLAN_54", "");
define("UCSLAN_55", "");
define("UCSLAN_56", "");
define("UCSLAN_57", "");
define("UCSLAN_58", "");
define("UCSLAN_59", "");
define("UCSLAN_60", "");
define("UCSLAN_61", "");
define("UCSLAN_62", "");
define("UCSLAN_63", "");
define("UCSLAN_64", "dokončené");
define("UCSLAN_65", "");
define("UCSLAN_66", "");
define("UCSLAN_67", "");
define("UCSLAN_68", "");
define("UCSLAN_69", "");
define("UCSLAN_70", "");
define("UCSLAN_71", "");
define("UCSLAN_72", "");
define("UCSLAN_73", "");
define("UCSLAN_74", "");
define("UCSLAN_75", "");
define("UCSLAN_76", "");
define("UCSLAN_77", "");
define("UCSLAN_78", "");
define("UCSLAN_79", "");
define("UCSLAN_80", "");
define("UCSLAN_81", "");
define("UCSLAN_82", "");
define("UCSLAN_83", "");
define("UCSLAN_84", "");
define("UCSLAN_85", "");
define("UCSLAN_86", "");
define("UCSLAN_87", "");
define("UCSLAN_88", "");
define("UCSLAN_89", "");
define("UCSLAN_90", "");
define("UCSLAN_91", "");
define("UCSLAN_UPDATE", "Aktualizuj");


?>