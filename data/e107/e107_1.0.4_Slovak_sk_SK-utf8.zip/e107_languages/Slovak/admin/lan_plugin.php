<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_plugin.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("EPL_ADLAN_0", "Inštalovať");
define("EPL_ADLAN_1", "Odinštalovať");
define("EPL_ADLAN_2", "Ste si istý, že chcete odinštalovať tento plugin?");
define("EPL_ADLAN_3", "Potvrdiť odinštalaáciu");
define("EPL_ADLAN_4", "Odinštalácia zrušená.");
define("EPL_ADLAN_5", "Inštalácia vytvorí nové položky v hlavnom nastavení");
define("EPL_ADLAN_6", "... kliknite sem pre pokračovanie v inštalácií");
define("EPL_ADLAN_7", "Tabuľky databázy úspešne upgradované.");
define("EPL_ADLAN_8", "Nastavenia konfigurácie úspešne uložené.");
define("EPL_ADLAN_9", "Chybný SQL príkaz. Presvedčte sa, že sú všetky zmeny v poriadku.");
define("EPL_ADLAN_10", "Meno");
define("EPL_ADLAN_11", "Verzia");
define("EPL_ADLAN_12", "Autor");
define("EPL_ADLAN_13", "Kompatibilita");
define("EPL_ADLAN_14", "Popis");
define("EPL_ADLAN_15", "Pre viac informácií čítajte README súbor");
define("EPL_ADLAN_16", "Informácie o pluginoch");
define("EPL_ADLAN_17", "Ďalšie info...");
define("EPL_ADLAN_18", "Nie je možné vytvoriť tabuľky pre tento plugin.");
define("EPL_ADLAN_19", "Tabuľky databázy úspešne vytvorené.");
define("EPL_ADLAN_21", "Plugin je v poriadku nainštalovaný.");
define("EPL_ADLAN_22", "Inštalované");
define("EPL_ADLAN_23", "Nenainštalované");
define("EPL_ADLAN_24", "Dostupný upgrade");
define("EPL_ADLAN_25", "Nie je potrebná inštalácia");
define("EPL_ADLAN_26", "... kliknite sem pre pokračovanie v inštalácií");
define("EPL_ADLAN_27", "Nie je možné zmazanie");
define("EPL_ADLAN_28", "Tabuľky databázy úspešne zmazané");
define("EPL_ADLAN_29", "Nastavenia konfigurácie úspešne zmazané.");
define("EPL_ADLAN_30", "prosím, zmažte to manuálne.");
define("EPL_ADLAN_31", "Prosím, zmažte teraz adresár");
define("EPL_ADLAN_32", "a všetky súbory, ktoré obsahuje, pre dokončenie odinštalácie.");
define("EPL_ADLAN_33", "Plugin inštalovaný.");
define("EPL_ADLAN_34", "Plugin aktualizovaný.");
define("EPL_ADLAN_35", "Nastavenia syntaktického analyzátora pridané.");
define("EPL_ADLAN_36", "Chyba kódu analyzátora, nepovolené formátovanie.");
define("EPL_ADLAN_37", "Uploadovať plugin (.zip alebo .tar.gz formát)");
define("EPL_ADLAN_38", "Uploadovať plugin");
define("EPL_ADLAN_39", "Súbor nemôže byť uploadovaný do adresára ".e_PLUGIN." , pretože nemá dostatočné práva - prosím, zmeňte prístupové práva adresára na CHMOD 777 a uploadujte súbor znovu.");
define("EPL_ADLAN_40", "Správa administrátora");
define("EPL_ADLAN_41", "Tento súbor nie je korektný .zip alebo .tar archív");
define("EPL_ADLAN_42", "Chyba, nie je možné dekomprimovať archív");
define("EPL_ADLAN_43", "Váš plugin bol uploadovaný dekomprimovaný, prosím, pozrite sa nižšie do zoznamu na váš plugin.");
define("EPL_ADLAN_44", "Auto upload a dekompresia pluginov je vypnutá, pretože váš adresár pluginov nemá dostatočné prístupové práva - prosím, zmente prístupové práva adresára na CHMOD 777.");
define("EPL_ADLAN_45", "Vaše menu bolo uploadované dekomprimované, pre jeho aktiváciu choďte na <a href='".e_ADMIN."menus.php'>stránku správy menu</a>.");
define("EPL_ADLAN_46", "chyba rozbaľovania PCLZIP:");
define("EPL_ADLAN_47", "chyba rozbaľovania PCLTAR:");
define("EPL_ADLAN_48", "kód:");
define("EPL_ADLAN_49", "Tabuľky neboli zmazané počas požadovanej odinštalácie");
define("EPL_WEBSITE", "Webstránka");
define("EPL_NOINSTALL", "Nie je potrebná inštalácia, stačí aktivácia v zozname pluginov. Pre odinštaláciu zmažte adresár");
define("EPL_DIRECTORY", "adresár.");
define("EPL_NOINSTALL_1", "Inštalácia nie je potrebná, pre odstránenie zmažte");
define("EPL_UPGRADE", "Upgrade");
define("EPL_ADLAN_50", "Komentáre sú úspešne zmazané");
define("EPL_ADLAN_53", "Zložka nie je zapisovateľná");
define("EPL_ADLAN_54", "Vyberte, prosím, možnosť odinštalovať plugin:");
define("EPL_ADLAN_55", "Odinštalovať plugin");
define("EPL_ADLAN_57", "Zmazať tabuľky pluginu");
define("EPL_ADLAN_58", "Ak tabuľky nebudú odstránené, plugin bude možné reinštalovať bez straty dát. Tvorba tabuliek počas reinštalácie zlyhá. Tabuľky bude nutné zmazať ručné, aby sa odstránili.");
define("EPL_ADLAN_59", "Zmaže plugin súbory");
define("EPL_ADLAN_60", "e107 sa pokúsi odstrániť všetky súbory daného pluginu.");
define("EPL_ADLAN_62", "Zrušiť odinštalovanie");
define("EPL_ADLAN_63", "Odinštalovanie:");
define("EPL_ADLAN_64", "Všetky súbory odstránené z:");
define("EPL_ADLAN_65", "Nepodarilo sa odstrániť súbory");
define("LAN_UPGRADE_SUCCESSFUL", "Aktualizácia úspešná");
define("LAN_INSTALL_SUCCESSFUL", "Inštalácia úspešná");


?>