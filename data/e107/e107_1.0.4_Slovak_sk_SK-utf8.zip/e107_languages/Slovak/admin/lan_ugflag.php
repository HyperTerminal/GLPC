<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_ugflag.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "nastavenie údržby aktualizované");
define("UGFLAN_2", "Aktivovať stav údržby");
define("UGFLAN_3", "Aktualizovať nastavenie údržby");
define("UGFLAN_4", "Nastavenie údržby");
define("UGFLAN_5", "Text, ktorý sa má zobraziť pri aktivovanej údržbe");
define("UGFLAN_6", "Nechajte prázdne pre zobrazenie prednastaveného textu.");
define("UGFLAN_8", "Obmedziť prístup len na administrátorov");
define("UGFLAN_9", "Obmedziť prístup len na hlavných administrátorov");


?>