<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_fla.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Neúspešné pokusy o prihlásenie");
define("FLALAN_2", "Nezaznamenané žiadne neúspešné pokusy prihlásenia");
define("FLALAN_3", "Pokus(y) zmazaný(é)");
define("FLALAN_4", "Užívateľ pokúšajúci sa prihlásiť použil nesprávne užívateľské meno/heslo");
define("FLALAN_5", "IP zakázaná(é)");
define("FLALAN_6", "Dátum");
define("FLALAN_7", "Dáta");
define("FLALAN_8", "IP adresa / host");
define("FLALAN_9", "Nastavenia");
define("FLALAN_10", "Zmazať / Zakázať zaznamenené prístupy");
define("FLALAN_11", "označiť všetky zmazané pokusy");
define("FLALAN_12", "odznačiť všetky zmazané pokusy");
define("FLALAN_13", "označiť všetky zakázané pokusy");
define("FLALAN_14", "odznačiť všetky zakázané pokusy");
define("FLALAN_15", "Nasledujúca IP adresa(y) sú automaticky zakázané - užívateľ sa pokúsil o viac ako 10 neúspešných prihlásení");
define("FLALAN_16", "Zmažte tento zoznam auto-vyhostení");
define("FLALAN_17", "Zoznam auto-vyhostení zmazaný");
define("FLALAN_18", "Nemožno zakázať IP adresu --IP-- - v zozname povolení");
define("FLALAN_19", "Označ všetky zmazané");


?>