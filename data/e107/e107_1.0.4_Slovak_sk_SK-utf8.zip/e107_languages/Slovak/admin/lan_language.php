<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_language.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "nemohla byť vytvorená (už existuje).");
define("LANG_LAN_01", "%s bol zmazaný (ak existoval) a vytvorený.");
define("LANG_LAN_02", "nemohla být zmazaná");
define("LANG_LAN_03", "Tabuľky");
define("LANG_LAN_05", "Nenainštalované");
define("LANG_LAN_06", "Vytvoriť tabuľky");
define("LANG_LAN_07", "Zmazať existujúce tebuľky?");
define("LANG_LAN_08", "Nahradiť existujúce tabuľky (dáta budú stratené).");
define("LANG_LAN_10", "Potvrdiť zmazanie");
define("LANG_LAN_11", "Zmazať neskontrolované tabuľky (ak existujú).");
define("LANG_LAN_12", "Zapnúť multijazykovú podporu");
define("LANG_LAN_13", "Nastavenie jazyka");
define("LANG_LAN_14", "Základný jazyk webu");
define("LANG_LAN_15", "Označte pre kópiu dát z prednastaveného jazyka portálu (použiteľné pre odkazy, kategórie noviniek atď)");
define("LANG_LAN_16", "Použitie viacjazyčnej databázy");
define("LANG_LAN_17", "Predvolený jazyk - nie sú potrebné ďalšie tabuľky.");
define("LANG_LAN_18", "Použite parkované subdomény k týmto doménam pre nastavenie jazyka:");
define("LANG_LAN_19", "napr.: fr.mydomain.com pre nastavenie francúzskeho jazyka.");
define("LANG_LAN_20", "Pre povolenie vložte názov hlavnej domény, napr.: mydomain.com");
define("LANG_LAN_21", "Jazykové nástroje");
define("LANG_LAN_23", "Vytvor jazykový balíček (zip)");
define("LANG_LAN_24", "Generuj");
define("LANG_LAN_AGR", "Poznámka: Pomocou týchto nástrojov súhlasíte so zdieľaním jazykových balíčkov s E107 komunitou.");
define("LANG_LAN_EML", "Prosím zašlete mailom jazykový balíček na:");
define("LANG_LAN_25", "Skontrolujte prosím, či CORE_LC a CORE_LC2 majú v [lcpath] hodnoty a skúste to znova.");
define("LANG_LAN_26", "Presvečte sa, že používate východzie názvy zložiek v e107_config.php (napr. 'e107_languages/', 'e107_plugins /' atd.), a  skúste to znovu.");
define("LANG_LAN_27", "Prosím, skontrolujte si jazykové súbory (Overiť) a skúste to znova.");
define("LANG_LAN_28", "Zaškrtnite toto políčko, pokiaľ ste[E107 certifikovaný prekladateľ].");
define("LANG_LAN_29", "Mali by ste opraviť zostávajúce chyby, než prispejete so svojím jazykovým balíčkom");
define("LANG_LAN_30", "Dátum vydania");
define("LANG_LAN_31", "Kompatibilita");
define("LANG_LAN_32", "Inštalované jazyky");
define("LANG_LAN_33", "Zobraziť iba chyby nájdené počas overovania");
define("LANG_LAN_34", "Prosím overte súbory prekladu a opravte zostávajúce [x] chyby pred vytvorením jazykového balíčku.");


?>