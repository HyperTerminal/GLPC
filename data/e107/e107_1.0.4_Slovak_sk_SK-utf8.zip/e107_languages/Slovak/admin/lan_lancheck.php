<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_lancheck.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Zvoľte jazyk, ktorý sa má skontrolovať");
define("LAN_CHECK_2", "Začať kontrolu");
define("LAN_CHECK_3", "Kontrola");
define("LAN_CHECK_4", "Súbor chýba!");
define("LAN_CHECK_5", "Chýba reťazec!");
define("LAN_CHECK_7", "reťazec");
define("LAN_CHECK_8", "Chýba súbor...");
define("LAN_CHECK_9", " súbor chýba...");
define("LAN_CHECK_10", "Kritická chyba: ");
define("LAN_CHECK_11", "Nechýba žiadny súbor !");
define("LAN_CHECK_12", "Súbor je poškodený...");
define("LAN_CHECK_13", " súbor je poškodený...");
define("LAN_CHECK_14", "Všetky existujúce súbory sú vporiadku!");
define("LAN_CHECK_15", "Boli nájdené neplatné znaky pred '<?php'");
define("LAN_CHECK_16", "Originálny súbor");
define("LAN_CHECK_17", "Počas pokusu o uloženie súboru došlo k problémom so zápisom.");
define("LAN_CHECK_18", "Pre tento plugin/theme NIE SÚ dostupné jazykové súbory v štandardnom formáte.");
define("LAN_CHECK_19", "Boli nájdené znaky, ktoré nie sú v UTF-8 kódovaní!");
define("LAN_CHECK_20", "Súbor");
define("LAN_CHECK_21", "Téma");
define("LAN_CHECK_22", "Témy");
define("LAN_CHECK_23", "%s uložený");
define("LAN_CHECK_PAGE_TITLE", "Jazyky");
define("LAN_CHECK_24", "Uprav/Vytvor súbor");
define("LAN_CHECK_25", "Kontrola Jazyka");
define("LAN_CHECK_26", "Žiadne údaje");


?>