<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_db.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Záloha nastavení jadra uložená do databázy.");
define("DBLAN_2", "Kliknite na tlačítko pre zálohu vašej databázy");
define("DBLAN_3", "Zálohovať SQL databázu");
define("DBLAN_4", "Kliknite na tlačítko pre overenie vašej databázy");
define("DBLAN_5", "Skontrolovať správnosť databázy");
define("DBLAN_6", "Kliknite na tlačítko pre optimalizáciu vašej databázy");
define("DBLAN_7", "Optimalizovať SQL databázu");
define("DBLAN_8", "Kliknite na tlačítko pre zálohovanie nastavení jadra portálu");
define("DBLAN_9", "Zálohovať jadro");
define("DBLAN_10", "Nástroje databázy");
define("DBLAN_11", "mySQL databáza");
define("DBLAN_12", "optimalizovaná");
define("DBLAN_13", "Späť");
define("DBLAN_14", "OK");
define("DBLAN_15", "Kliknite na tlačítko pre skontrolovanie prístupných aktualizácií databázy");
define("DBLAN_16", "Skontrolovať aktualizácie");
define("DBLAN_17", "Meno volieb");
define("DBLAN_18", "Hodnota volieb");
define("DBLAN_19", "Kliknite na tlačidlo pre otvorenie editora volieb (len pre skúsených užívateľov!)");
define("DBLAN_20", "Editor volieb");
define("DBLAN_21", "Zmažte skontrolované");
define("DBLAN_22", "Plugin: Zobraz a skenuj");
define("DBLAN_23", "Skenovanie ukončené");
define("DBLAN_24", "Meno");
define("DBLAN_25", "Zložka");
define("DBLAN_26", "Zahrnuté doplnky");
define("DBLAN_27", "Inštalované");
define("DBLAN_28", "Kliknite na tlačidlo pre skenovanie plugin zložiek kvôli zmenám");
define("DBLAN_29", "Skenujte plugin zložky");
define("DBLAN_30", " (Ak doplnok vykazuje chybu, skontrolujte znaky mimo PHP otváracie/zatváracie tagy)");
define("DBLAN_31", "Prejsť");
define("DBLAN_32", "Chyba");
define("DBLAN_33", "Nedostupné");
define("DBLAN_34", "Neskontrolované");
define("DBLAN_35", "Zvoľte pre skontrolovanie správnosti e107 databázových záznamov");
define("DBLAN_36", "Skontroluj oprávnenie zápisu do databázy");
define("DBLAN_37", "Zvoľ tabuľku(y) pre kontrolu");
define("DBLAN_38", "Začni overovať");
define("DBLAN_39", "Oprávnenie zápisu do databázy");
define("DBLAN_40", "Oprávnenie zápisu :");
define("DBLAN_41", "tabuľka");
define("DBLAN_42", "id");
define("DBLAN_43", "zaznamenať");
define("DBLAN_44", "možnosti");
define("DBLAN_45", "Id nenájdené!");
define("DBLAN_46", "Tabuľka nenájdená!");
define("DBLAN_47", "zmazať");
define("DBLAN_48", "Zmaž označené");
define("DBLAN_49", "žiadne záznamy v tabuľke, nič na overenie");
define("DBLAN_50", "Oprávnenie zápisu Sql");
define("DBLAN_51", "Spusti označené");
define("DBLAN_52", "Zmaž duplikáty");
define("DBLAN_53", "Prosím zvoľte akciu.");
define("DBLAN_54", "Nenájdené žiadne chyby.");
define("DBLAN_55", "");
define("DBLAN_56", "");
define("DBLAN_57", "");


?>