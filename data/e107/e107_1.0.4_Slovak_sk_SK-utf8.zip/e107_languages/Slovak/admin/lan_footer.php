<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_footer.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Stránka");
define("FOOTLAN_2", "Hlavný administrátor");
define("FOOTLAN_3", "Verzia");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Téma");
define("FOOTLAN_6", "od");
define("FOOTLAN_7", "Informácie");
define("FOOTLAN_8", "Dátum inštalácie");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP verzia");
define("FOOTLAN_12", "mySQL verzia");
define("FOOTLAN_13", "Informácie o portály");
define("FOOTLAN_14", "Ukázať dokumenty");
define("FOOTLAN_15", "Dokumentácia");
define("FOOTLAN_16", "Databáza");
define("FOOTLAN_17", "Kódovanie");
define("FOOTLAN_18", "Štýl stránok");
define("FOOTLAN_19", "Aktuální čas serveru");
define("FOOTLAN_20", "Stupeň zabezpečení");


?>