<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/admin/lan_credits.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "e107 Credits");
define("CRELAN_1", "Poďakovanie");
define("CRELAN_2", "Tu je zoznam použitého software tretích strán / zdrojov použitých v e107. Vývojový tím e107 osobne ďakuje vývojárom nasledovných produktov a kódov použitých v e107, a za vydanie tohto kódu pod licenciou GPL.");
define("CRELAN_3", "všetky práva vyhradené");
define("CRELAN_4", "Zobraz e107 vývojársky tím");
define("CRELAN_5", "Zobraz skripty tretích strán");
define("CRELAN_6", "e107 v0.7 bol k vám prinesený ...");
define("CRELAN_7", "verzia");
define("CRELAN_8", "práva zaručené");
define("CRELAN_9", "Licencia");
define("CRELAN_10", "MagpieRSS provides an XML-based (expat) RSS parser in PHP.");
define("CRELAN_11", "PclZip library offers compression and extraction functions for Zip formatted archives (WinZip, PKZIP).");
define("CRELAN_12", "PclTar ponúka schopnosť archivovať zoznam súborov alebo zložiek s/bez kompresiou. Archívy vytvorené spoločnosťou PclTar sú čitateľné pre väčšinu gzip/tar aplikácií ako aj Windows WinZip aplikáciou.");
define("CRELAN_13", "TinyMCE je nezávislá platforma HTML WYSIWYG editora založeného na Javascripte, vydaného ako Open Source pod LGPL firmou Moxiecode Systems AB. Umožňuje konvertovať HTML textové polia alebo iné HTML značky podľa požiadaviek editora.");
define("CRELAN_14", "Ikony použité v e107");
define("CRELAN_15", "Plne podporovaný emailový prenos triedy pre PHP");
define("CRELAN_16", "Menu systém použitý v Jayya téme");
define("CRELAN_17", "Vyskakovací nástroj kalendára");
define("CRELAN_18", "podpora PDF");
define("CRELAN_19", "podpora UTF-8 PDF");
define("CRELAN_20", "");
define("CRELAN_21", "Vždy pod tlakom ..ehm..s radosťou!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Dohora a smer vpred!");
define("CRELAN_30", "");


?>