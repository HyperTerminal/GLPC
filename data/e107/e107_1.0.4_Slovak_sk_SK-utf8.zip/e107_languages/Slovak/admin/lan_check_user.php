<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Slovak/admin/lan_check_user.php $
|        $Revision: 1.0 $
|        $Id: 2013/06/06 20:55:35 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "Skontrolovať databázu užívateľov");
define("LAN_CKUSER_02", "Toto skontroluje rôzne možné problémy s databázou užívateľov");
define("LAN_CKUSER_03", "Pokiaľ máte veľa užívateľov, môže nejakú to chvíľu trvať alebo dôjde k prekročeniu časového limitu");
define("LAN_CKUSER_04", "Pokračovať");
define("LAN_CKUSER_05", "Skontrolovať duplicitné uživateľská mená");
define("LAN_CKUSER_06", "Zvoľte funkcie, ktoré sa majú vykonať");
define("LAN_CKUSER_07", "Nájdené duplicitné užívateľské mená");
define("LAN_CKUSER_08", "Žiadne duplicity nenájdené");
define("LAN_CKUSER_09", "Užívateľské meno");
define("LAN_CKUSER_10", "ID užívateľa");
define("LAN_CKUSER_11", "Zobrazované meno");
define("LAN_CKUSER_12", "Skontrolovať duplicitu emailových adries");
define("LAN_CKUSER_13", "Nájdené duplicitné emailové adresy");
define("LAN_CKUSER_14", "Emailové adresy");
define("LAN_CKUSER_15", "Žiadne duplicity nenájdené");
define("LAN_CKUSER_16", "Hľadať záznamy, kde je meno užívateľa prihlasovacím menom niekoho iného");
define("LAN_CKUSER_17", "Konfliktné meno užívateľa s prihlasovacím menom");
define("LAN_CKUSER_18", "Užívateľ 1");
define("LAN_CKUSER_19", "Užívateľ 2");
define("LAN_CKUSER_20", "");


?>