<?php
/*
 * e107 website system
 *
 * Copyright (C) 2001-2008 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Language File
 *
 * $Source: /duvalo/languages/Slovak/admin/lan_docs.php $
 * $Revision: 1.0 $
 * $Date: 2009/05/18 01:16:12 $
 *  $Author: Dj HaCk $
 *
*/

define("LAN_DOCS", "Systémové Dokumenty");
define("LAN_DOCS_SECTIONS", "Sekcie");
define("LAN_DOCS_GOTOP", "Choď na vrch");
define("LAN_DOCS_ANSWER", "Odpoveď");
define("LAN_DOCS_QUESTION", "Otázka");


?>