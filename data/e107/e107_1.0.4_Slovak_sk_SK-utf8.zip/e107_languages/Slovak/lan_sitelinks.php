<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Hlavné menu");
define("LAN_SITELINKS_502", "Administračná časť");

?>