<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Hostí:");
define("ONLINE_EL2", "Členov:");
define("ONLINE_EL3", "Na túto stránku:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Členov");
define("ONLINE_EL6", "Najnovší člen");
define("ONLINE_EL7", "ukázať");
define("ONLINE_EL8", "najviac ľudí online:");
define("ONLINE_EL9", "zapnuté");
define("ONLINE_EL10", "Meno člena");
define("ONLINE_EL11", "Prezerať stránku");
define("ONLINE_EL12", "Odpoveď na");
define("ONLINE_EL13", "Fórum");
define("ONLINE_EL14", "Vlákno");
define("ONLINE_EL15", "Stránka");
define("CLASSRESTRICTED", "Stránka vyhradená pre triedu užívateľov");
define("ARTICLEPAGE", "Článok");
define("CHAT", "Chat");
define("COMMENT", "Komentáre");
define("DOWNLOAD", "Downloady");
define("EMAIL", "email.php");
define("FORUM", "Index hlavného fóra");
define("LINKS", "Odkazy");
define("NEWS", "Novinky");
define("OLDPOLLS", "Staršie ankety");
define("POLLCOMMENT", "Anketa");
define("PRINTPAGE", "Tlačiť");
define("LOGIN", "Prihlásenie");
define("SEARCH", "Hľadanie");
define("STATS", "Štatistiky");
define("SUBMITNEWS", "Zaslanie novinky");
define("UPLOAD", "Uploady");
define("USERPAGE", "Užívateľské profily");
define("USERSETTINGS", "Užívateľské nastavenia");
define("ONLINE", "Online užívatelia");
define("LISTNEW", "Zoznam nových udalostí");
define("USERPOSTS", "Príspevky užívateľov");
define("SUBCONTENT", "Zaslanie Článku/Recenzie");
define("TOP", "Top prispievatelia/Najviac aktívne vlákna");
define("ADMINAREA", "Administrátor");
define("BUGTRACKER", "Ohlasovateľ chýb");
define("EVENT", "Zoznam udalostí");
define("CALENDAR", "Kalendár udalostí");
define("FAQ", "FAQ");
define("PM", "Osobné správy");
define("SURVEY", "Prezerá");
define("ARTICLE", "Článok");
define("CONTENT", "Stránka obsahu");
define("REVIEW", "Recenzia");


?>