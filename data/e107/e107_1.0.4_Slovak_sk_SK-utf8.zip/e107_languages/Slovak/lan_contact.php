<?php
/*
+---------------------------------------------------------------+
|        e107 website system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Slovak/lan_contact.php $
|        $Revision: 0.1 $
|        $Id: 2013/06/05 08:53:46 $
|        $Author: Jimako $
|        Encoding: UTF-8
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Kontaktujte nás");
define("LANCONTACT_01", "Detaily kontaktu");
define("LANCONTACT_02", "Kontaktný formulár");
define("LANCONTACT_03", "Vložte svoje meno:");
define("LANCONTACT_04", "E-mail:");
define("LANCONTACT_05", "Predmet správy:");
define("LANCONTACT_06", "Zadajte správu:");
define("LANCONTACT_07", "Odoslať kópiu na email:");
define("LANCONTACT_08", "Odoslať");
define("LANCONTACT_09", "Vaša správa bola odoslaná");
define("LANCONTACT_10", "Pri odosielaní došlo k chybe");
define("LANCONTACT_11", "Zadaná emailová adresa nie je správna\\n Skontrolujte ju prosím.");
define("LANCONTACT_12", "Vaša správa je príliš krátka");
define("LANCONTACT_13", "Zadajte predmet");
define("LANCONTACT_14", "Odoslať správu:");
define("LANCONTACT_15", "Vložený nesprávny kód");
define("LANCONTACT_16", "Vložte kód");


?>