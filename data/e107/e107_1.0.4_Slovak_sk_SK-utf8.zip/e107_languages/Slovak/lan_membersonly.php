<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Len pre členov");
define("LAN_MEMBERS_0", "vyhradená lokácia");
define("LAN_MEMBERS_1", "Toto je vyhradená lokácia");
define("LAN_MEMBERS_2", "pre prístup sa musíte najskôr <a href='login.php'>prihlásiť</a> alebo");
define("LAN_MEMBERS_3", "alebo sa <a href='".e_SIGNUP."'>zaregistrujte</a>ako nový uživatel");
define("LAN_MEMBERS_4", "Kliknite sem pre návrat na úvodnú stránku");


?>