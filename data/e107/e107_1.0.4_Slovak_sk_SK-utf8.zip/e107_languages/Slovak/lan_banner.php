<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_banner.php,v $
|     $Revision: 1.2 $
|     $Date: 2007/15/12 16:43:40 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");
define("BANNERLAN_16", "Užívateľské meno:");
define("BANNERLAN_17", "Heslo:");
define("BANNERLAN_18", "Pokračovať");
define("BANNERLAN_19", "Pre pokračovanie zadajte vaše klientské užívateľské meno a heslo, prosím.");
define("BANNERLAN_20", "Prepáčte, ale vaše údaje neboli nájdené v databáze. Kontaktujte, prosím, hlavného administrátora.");
define("BANNERLAN_21", "Štatistiky bannerov");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "ID bannera");
define("BANNERLAN_24", "Počet kliknutí");
define("BANNERLAN_25", "Kliknutia v %");
define("BANNERLAN_26", "Zobrazenia");
define("BANNERLAN_27", "Zakúpené zobrazenia");
define("BANNERLAN_28", "Zostáva zobrazení");
define("BANNERLAN_29", "Žiadne bannery");
define("BANNERLAN_30", "Bez limitu");
define("BANNERLAN_31", "Nie je možné aplikovať");
define("BANNERLAN_32", "Áno");
define("BANNERLAN_33", "Nie");
define("BANNERLAN_34", "Ukončenie:");
define("BANNERLAN_35", "IP adresy preklikov:");
define("BANNERLAN_36", "Aktivita:");
define("BANNERLAN_37", "Začiatok:");
define("BANNERLAN_38", "Chyba");


?>