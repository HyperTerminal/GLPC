<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Upload");
define("LAN_UL_001", "Neplatná e-mailová adresa");
define("LAN_UL_002", "Nemáte oprávnenia pre uploadnutie súborov na server.");
define("LAN_UL_020", "Chyba");
define("LAN_UL_021", "Zlyhanie uploadu");
define("LAN_UL_022", "M§že sa meniť podľa typu súboru");
define("LAN_UL_023", "Typ");
define("LAN_UL_024", "Max Veľkosť");
define("LAN_UL_025", "Uploady nie sú povolené");
define("LAN_UL_026", "");
define("LAN_UL_027", "");
define("LAN_UL_032", "Musíte zvoliť kategóriu");
define("LAN_UL_033", "Musíte vložiť platnú emailovú adresu");
define("LAN_UL_034", "Musíte špecifikovať názov súboru");
define("LAN_UL_035", "Musíte vložiť popis");
define("LAN_UL_036", "Musíte špecifikovať súbor pre upload");
define("LAN_UL_037", "Musíte špecifikovať kategóriu");
define("LAN_UL_038", "");
define("LAN_61", "Vaše meno: ");
define("LAN_112", "Emailová adresa: ");
define("LAN_144", "URL webstránok: ");
define("LAN_402", "Pre upload súborov na tento server musíte byť jeho registrovaným členom.");
define("LAN_404", "Ďakujeme vám. Váš upload bol zaznamenaný a posunutý administrátorovi na schválenie.");
define("LAN_406", "Poznámka");
define("LAN_407", "Všetky ostatné typy súborov budú okamžite zmazané.");
define("LAN_408", "Podtrhnuté");
define("LAN_409", "Meno súboru");
define("LAN_410", "Verzia");
define("LAN_411", "Súbor");
define("LAN_412", "Náhľad");
define("LAN_413", "Popis");
define("LAN_414", "Fungujúce demo");
define("LAN_415", "vložte URL, kde je možné vidieť uploadovaný súbor v reále");
define("LAN_416", "Uložiť a Uploadovať");
define("LAN_417", "Upload súboru");
define("LAN_418", "Maximálna veľkosť súboru: ");
define("DOWLAN_11", "Kategória");
define("LAN_419", "Povolené typy súborov");
define("LAN_420", "polia sú povinné");


?>