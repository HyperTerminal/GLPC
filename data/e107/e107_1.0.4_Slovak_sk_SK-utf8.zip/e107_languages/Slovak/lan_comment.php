<?php
/*
+---------------------------------------------------------------+
|        e107 website system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Slovak/lan_contact.php $
|        $Revision: 0.1 $
|        $Id: 2013/06/05 08:53:46 $
|        $Author: Jimako $
|        Encoding: UTF-8
+---------------------------------------------------------------+
*/
define("COMLAN_0", "[blokované adminom]");
define("COMLAN_1", "Odblokovať");
define("COMLAN_2", "Zablokovať");
define("COMLAN_3", "Zmazať");
define("COMLAN_4", "Informácie");
define("COMLAN_5", "Komentáre ...");
define("COMLAN_6", "Musíte byť prihlásení, aby ste mohli zasielať komentáre - prosím prihláste alebo zaregistrujte sa");
define("COMLAN_7", "Hlavný administrátor");
define("COMLAN_8", "Komentár");
define("COMLAN_9", "Pridať komentár");
define("COMLAN_10", "Administrátor");
define("COMLAN_11", "Nepodarilo sa zapísať komentár do databázy - prosím, prepíšte komentár a vynechajte všetky neštandardné znaky.");
define("COMLAN_12", "Užívateľ");
define("COMLAN_16", "Užívateľské meno:");
define("COMLAN_99", "Komentáre");
define("COMLAN_100", "Novinky");
define("COMLAN_101", "Hlasovanie");
define("COMLAN_102", "Odpoveď na:");
define("COMLAN_103", "Článok");
define("COMLAN_104", "Recenzia");
define("COMLAN_105", "Obsah");
define("COMLAN_106", "Na stiahnutie");
define("COMLAN_145", "Registrovaný:");
define("COMLAN_194", "Hosť");
define("COMLAN_195", "Registrovaný člen");
define("COMLAN_310", "Nie je možné zaslať komentár s týmto užívateľským menom - ak je to vaše užívateľské meno, prosím prihláste sa.");
define("COMLAN_312", "Dvojitý komentár, nie je možné uložiť.");
define("COMLAN_313", "Umiestnenie");
define("COMLAN_314", "Moderovať komentáre");
define("COMLAN_315", "Spätné odkazy");
define("COMLAN_316", "Žiadne spätné odkazy pre tento príspevok.");
define("COMLAN_317", "Moderovať spätné odkazy");
define("COMLAN_318", "Editovať komentáre");
define("COMLAN_319", "editované");
define("COMLAN_320", "Upraviť komentár");
define("COMLAN_321", "tu");
define("COMLAN_322", "pre prihlásenie");
define("COMLAN_323", "Chyba!");
define("COMLAN_324", "Predmet");
define("COMLAN_325", "Re:");
define("COMLAN_326", "Reagovať na príspevok:");
define("COMLAN_327", "Hodnotenie");
define("COMLAN_328", "Komentáre sú zamknuté");
define("COMLAN_329", "Neautorizované");
define("COMLAN_330", "IP:");
define("COMLAN_331", "Komentár ešte nebol schválený");
define("COMLAN_TYPE_1", "novinky");
define("COMLAN_TYPE_2", "download");
define("COMLAN_TYPE_3", "FAQ");
define("COMLAN_TYPE_4", "hlasovanie");
define("COMLAN_TYPE_5", "dokumenty");
define("COMLAN_TYPE_6", "oznámenie chýb");
define("COMLAN_TYPE_7", "námety");
define("COMLAN_TYPE_8", "užívateľský profil");
define("COMLAN_TYPE_PAGE", "Obsah");


?>