<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Revision: 1.3 $
|     $Date: 2006/04/04 23:13:42 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "Stránka bežiaca na e107");
define("LAN_PREF_2", "e107 systém internetových stránok");
define("LAN_PREF_3", "Tieto stránky bežia na systéme <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, ktorý je voľne prístupný podľa podmienok <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL licencie.");
define("LAN_PREF_4", "cenzúrované");
define("LAN_PREF_5", "Fóra");

?>