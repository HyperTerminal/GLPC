<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Slovak/lan_date.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "rok");
define("LANDT_02", "mesiac");
define("LANDT_03", "týždeň");
define("LANDT_04", "deň");
define("LANDT_05", "hodina");
define("LANDT_06", "minúta");
define("LANDT_07", "sekunda");
define("LANDT_01s", "rokov");
define("LANDT_02s", "mesiacov");
define("LANDT_03s", "týždňov");
define("LANDT_04s", "dní");
define("LANDT_05s", "hodín");
define("LANDT_06s", "minút");
define("LANDT_07s", "sekúnd");
define("LANDT_08", "min");
define("LANDT_08s", "min");
define("LANDT_09", "sek");
define("LANDT_09s", "sek");
define("LANDT_AGO", "pred");


?>