<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Slovak Language File.
|
|     $Revision: 1.1 $
|     $Date: 2005/07/15 20:53:50 $
|     $Author: Dj HaCk $
|     Encoding: UTF-8
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "hlas");
define("RATELAN_1", "hlasov");
define("RATELAN_2", "ako ohodnotíte tento článok?");
define("RATELAN_3", "ďakujeme za váš hlas");
define("RATELAN_4", "nehodnotené");
define("RATELAN_5", "hodnoť");

?>