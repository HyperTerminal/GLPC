<?php
/*
+---------------------------------------------------------------+
|        e107 website system Slovak Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Slovak/lan_signup.php $
|        $Revision: 0.1 $
|        $Id: 2013/06/05 08:53:46 $
|        $Author: Mira, Jimako $
|        Encoding: UTF-8
+---------------------------------------------------------------+
*/
define("PAGE_NAME", " Registrácia");
define("LAN_7", "Meno užívateľa:");
define("LAN_8", " Meno, ktoré sa bude zobrazovať na webe");
define("LAN_9", "Prihlasovacie meno:");
define("LAN_10", " Meno, ktoré budete používať k prihlasovaniu(login)");
define("LAN_17", "Heslo:");
define("LAN_103", " Neplatné užívateľské meno, zvoľte si prosím iné");
define("LAN_104", " Prihlasovacie meno je už obsadené, zvolte si prosím iné");
define("LAN_105", "Heslá sa nezhodujú");
define("LAN_106", "Chybná E-mailová adresa");
define("LAN_107", " Ďakujeme. Teraz ste registrovaným členom webu");
define("LAN_108", "Registrácia je dokončená");
define("LAN_109", "Tento web rešpektuje pravidlá COPPA (ochrana dieťaťa : The Children's Online Privacy Protection Act), a preto neprijíma registrácie detí mladších 13 rokov bez písomného súhlasu rodičov alebo ich zákonných zástupcov. Pre viacej informácií si prečítajte platnú legislatívu COPPA a zistite platnú legislatívu štátu, kde chcete web prevádzkovať.");
define("LAN_110", "Registrácia");
define("LAN_111", "Znovu zadajte heslo:");
define("LAN_112", "E-mailová adresa:");
define("LAN_113", "Skryť e-mail?:");
define("LAN_114", "Zabráni zobrazenie Vašej e-mailovej adresy na tomto webe");
define("LAN_123", "Registruj");
define("LAN_185", " Niektoré povinné políčka nie sú vyplnené");
define("LAN_201", "Áno");
define("LAN_200", "Nie");
define("LAN_202", "Už tu máte vytvorený účet. Pokiaľ ste zabudli heslo, kliknite na odkaz 'zabudol som heslo'.");
define("LAN_309", "Nižšie prosím vyplňte požadované údaje.");
define("LAN_399", "Pokračujme");
define("LAN_400", "Užívateľské mená a heslá sú <b>citlivé na veľkosť znakov</b>. Internet nie je to isté ako iNteRNet");
define("LAN_401", "Váš účet bol práve aktivovaný");
define("LAN_402", "Registrácia je aktívna");
define("LAN_403", "Vitajte na webe");
define("LAN_404", "Registračné údaje pre");
define("LAN_405", "Túto časť registrácie už máte za sebou. Mal by Vám prísť e-mail s potvrdením Vašich údajov pre prihlásenie. V e-maily je aktívny odkaz, na ktorý je potrebné kliknúť, aby ste mohli dokončiť registráciu a Váš účet bol aktivovaný.");
define("LAN_406", "Ďakujeme.");
define("LAN_407", "Tento e-mail je určený len Vám. Vaše heslo bolo zakódované a nedá sa nijako znovu získať, ani v prípade, že ho zabudnete. V prípade, že sa tak stane, môžete požiadať o nastavenie nového hesla.\n\nĎakujeme za Vašu registráciu.\n\nZ");
define("LAN_408", "Táto adresa je už priradená k inému účtu. Pokiaľ sa jedná o Váš účet, použite prosím odkaz 'zabudol som heslo', kde môžete požiadať o vystavenie nového hesla.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "znakov");
define("LAN_SIGNUP_3", "Nepodarilo sa overiť kód.");
define("LAN_SIGNUP_4", "Heslo musí mať minimálne");
define("LAN_SIGNUP_5", " znakov.");
define("LAN_SIGNUP_6", "Vaše");
define("LAN_SIGNUP_7", " Je potrebným údajom.");
define("LAN_SIGNUP_8", "Ďakujeme.");
define("LAN_SIGNUP_9", "Nedá sa spracovať.");
define("LAN_SIGNUP_10", "Áno");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Užívateľské meno obsahuje zakázané znaky");
define("LAN_410", "Zadajte kód, ktorý vidíte na obrázku");
define("LAN_411", "Vami zvolené užívateľské meno je už používané. Zvoľte prosím iné.");
define("LAN_SIGNUP_12", "Uchovajte prosím Vaše užívateľské meno a heslo na bezpečnom mieste. Pokiaľ ho zabudnete, heslo sa nedá znovu zistiť.");
define("LAN_SIGNUP_13", "Prihlásiť sa môžete v poli pre prihlásenie, alebo  <a href='".e_BASE."login.php'>týmto odkazom</a>.");
define("LAN_SIGNUP_14", "Tu");
define("LAN_SIGNUP_15", "Kontaktujte prosím hlavného administrátora webu");
define("LAN_SIGNUP_16", "pokiaľ potrebujete pomôcť.");
define("LAN_SIGNUP_17", "Potvrďte prosím (na vlastnú zodpovednosť), že Máte 13 alebo viac rokov.");
define("LAN_SIGNUP_18", "Prijali sme Vašu žiadosť o registráciu s týmito údajmi ...");
define("LAN_SIGNUP_21", "Váš účet zatiaľ nie je aktívny. Účet sa dá aktivovať kliknutím na nasledujúci odkaz ...");
define("LAN_SIGNUP_22", "kliknite tu");
define("LAN_SIGNUP_23", "pre prihlásenie.");
define("LAN_SIGNUP_24", "Ďakujeme za registráciu na tomto webe");
define("LAN_SIGNUP_25", "Nahrajte si svoj avatar (obrázok)");
define("LAN_SIGNUP_26", "Nahrajte svoju fotku");
define("LAN_SIGNUP_27", "Ukázať");
define("LAN_SIGNUP_28", "výber obsahu/zoznamu e-mailov");
define("LAN_SIGNUP_29", "Na vloženú adresu Vám zašleme potvrdzovací e-mail, preto musí byť vložená adresa platná.");
define("LAN_SIGNUP_30", "Pokiaľ si neprajete zobrazovať na tomto webe Vašu e-mailovú adresu, zaškrtnite políčko 'skryť e-mailovú adresu'.");
define("LAN_SIGNUP_31", "URL Vášho XUP súboru");
define("LAN_SIGNUP_32", "Čo to je XUP súbor?");
define("LAN_SIGNUP_33", "Zadajte cestu alebo vyberte avatar (obrázok)");
define("LAN_SIGNUP_34", "Upozornenie! Akékoľvek obrázky považované administrátorom za nevhodné budú bez upozornenia vymazané!");
define("LAN_SIGNUP_35", "Registrovať sa pomocou XUP súboru môžete kliknutím na tento odkaz");
define("LAN_SIGNUP_36", "Došlo k chybe pri vytváraní informácií pre Váš užívateľský účet. Kontaktujte prosím administrátora webu.");
define("LAN_LOGINNAME", "Prihlasovacie meno");
define("LAN_PASSWORD", "Heslo");
define("LAN_USERNAME", "Užívateľské meno");
define("LAN_EMAIL_01", "Vážený");
define("LAN_EMAIL_04", "Informácie obsiahnuté v tomto e-maile uchovajte len pre vlastnú potrebu.");
define("LAN_EMAIL_05", "Heslo bolo zakódované a nedá sa spätne nijako zistiť. Môžete však kedykoľvek požiadať administrátora webu o nastavenie nového hesla administrátora webu.");
define("LAN_EMAIL_06", "Ďakujeme za Vašu registráciu.");
define("LAN_SIGNUP_37", "Túto fázu registrácie máte za sebou. Hlavný administrátor webu musí potvrdiť Vašu registráciu. Len čo to urobí, príde Vám e-mail s oznámením, že Váš účet bol aktivovaný.");
define("LAN_SIGNUP_38", "Zadal(a) ste dve odlišné e-mailové adresy. Zadajte prosím platnú e-mailovou adresu do oboch polí.");
define("LAN_SIGNUP_39", "Znovu zadať e-mail:");
define("LAN_SIGNUP_40", "Aktivácia nie je nutná.");
define("LAN_SIGNUP_41", "Váš účet už bol aktivovaný.");
define("LAN_SIGNUP_42", "Nastal technický problém, nepodarilo sa odoslať potvrdzovací e-mail. Kontaktujte prosím hlavného administrátora webu.");
define("LAN_SIGNUP_43", "E-mail bol odoslaný.");
define("LAN_SIGNUP_44", "Aktivačný e-mail odoslaný:");
define("LAN_SIGNUP_45", "Pozrite sa do svojej prichádzajúcej pošty.");
define("LAN_SIGNUP_47", "Poslať aktivačný e-mail ešte raz.");
define("LAN_SIGNUP_48", "Užívateľské meno alebo e-mail");
define("LAN_SIGNUP_49", "Pokiaľ ste sa registroval(a) s neplatnou e-mailovou adresou, zadajte sem funkčnú e-mailovú adresu a uveďte aj heslo:");
define("LAN_SIGNUP_50", "Nový e-mail");
define("LAN_SIGNUP_51", "Staré heslo");
define("LAN_SIGNUP_52", "Nesprávne heslo");
define("LAN_SIGNUP_53", "pole neprešlo testom pravosti");
define("LAN_SIGNUP_54", "Kliknite sem, aby ste sa mohol(a) registrovať");
define("LAN_SIGNUP_55", "Zobrazované meno je veľmi dlhé. Zadajte prosím iné, kratšie.");
define("LAN_SIGNUP_56", "Zobrazované meno je veľmi krátke. Zadajte prosím iné, dlhšie.");
define("LAN_SIGNUP_57", "Toto prihlasovacie meno je veľmi dlhé. Prosím vyberte si iné");
define("LAN_SIGNUP_58", "Náhľad prihlásenia");
define("LAN_SIGNUP_59", "**** Pokiaľ odkaz nefunguje, skontrolujte, či časť odkazu nie je na ďalšom riadku ****");
define("LAN_SIGNUP_60", "Chyba pri prístupe k vzdialenému avataru");
define("LAN_SIGNUP_72", "Vďaka za registráciu na [sitename]! Práve sme vám zaslali potvrdzujúci e-mail na [email]. Kliknite prosím na odkaz v e-maile k dokončeniu registrácie a aktivácií účtu.");
define("LAN_SIGNUP_98", "Potvrďte svoju e-mailovú adresu");
define("LAN_SIGNUP_99", "Vyskytol sa problém");
define("LAN_SIGNUP_100", "Až do schválenia administrátorom");
define("LAN_SIGNUP_102", "Registrácia zamietnutá");
define("LAN_SIGNUP_103", "Tieto IP adresy už používa priveľa užívateľov:");
define("LAN_SIGNUP_104", "Neplatný názov avataru");
define("LAN_SIGNUP_105", "Vaša žiadosť o registráciu sa nedá dokončiť - prosím kontaktujte administrátora");
define("LAN_SIGNUP_106", "Vaša žiadosť o registráciu sa nedá dokončiť - už tu vlastníte účet?");


?>