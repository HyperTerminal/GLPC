<?php
/*
+---------------------------------------------------------------+
|        e107 website system Italiano Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/newforumposts_main/languages/Italiano.php $
|        $Revision: 1.0 $
|        $Date: 2008/12/23 18:56:08 $
|        $Author: Maurizio $
+---------------------------------------------------------------+
*/

define("NFPM_LAN_1", "Discussioni");
define("NFPM_LAN_2", "Autore");
define("NFPM_LAN_3", "Visite");
define("NFPM_LAN_4", "Repliche");
define("NFPM_LAN_5", "Ultimo messaggio di");
define("NFPM_LAN_6", "Discussioni");
define("NFPM_LAN_7", "di");
define("NFPM_L1", "Questo plugin visualizza la lista dei nuovi messaggi del forum sulla tua Homepage");
define("NFPM_L2", "Ultimi Messaggi Forum");
define("NFPM_L3", "Per configurare vai nella sezione Gestione Plugin dell'amministrazione");
define("NFPM_L4", "In quale area della pagina vuoi attivare il plugin?");
define("NFPM_L5", "Inattivo");
define("NFPM_L6", "In alto");
define("NFPM_L7", "In basso");
define("NFPM_L8", "Titolo");
define("NFPM_L9", "Numero di nuovi messaggi da visualizzare");
define("NFPM_L10", "Spunta per visualizzare i messaggi all'interno di un'area con scrolling");
define("NFPM_L11", "Altezza Layer");
define("NFPM_L12", "Configurazione Plugin Ultimi Messaggi Forum");
define("NFPM_L13", "Aggiornamento configurazione");
define("NFPM_L14", "Impostazioni aggiornate.");
define("NFPM_L15", "Spunta per visualizzare gli ultimi messaggi.<br />Per default gli ultimi messaggi.");
define("NFPM_L16", "[Utente Eliminato]");

//7.23
define('NFPM_L17', 'Nuovi Post nelle Discussioni Popolari');
define('NFPM_L18', 'Nuovi Post');
define('NFPM_L19', 'Nessun Nuovo Post nelle Discussioni Popolari');
define('NFPM_L20', 'Nessun Nuovo Post');
define('NFPM_L21', 'Discussione Fissata');
define('NFPM_L22', 'Discussione Fissata chiusa');
define('NFPM_L23', 'Comunicazione');
define('NFPM_L24', 'Discussione chiusa');


?>