<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_viewtopic.php,v $
|     $Revision: 1.10 $
|     $Date: 2005/07/22 02:12:58 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum");
define("LAN_01", "Forum");
define("LAN_02", "Vai a pagina");
define("LAN_03", "Vai");
define("LAN_04", "Precedente");
define("LAN_05", "Successiva");
define("LAN_06", "Registrato il");
define("LAN_07", "Localit&agrave;");
define("LAN_08", "Sito web");
define("LAN_09", "Visite al sito dalla registrazione");
define("LAN_10", "Torna ad inizio pagina");
define("LAN_65", "Salta");
define("LAN_66", "Questa discussione &egrave; chiusa");
define("LAN_67", "messaggi");
define("LAN_194", "Ospite");
define("LAN_195", "Utenti Registrati");
define("LAN_321", "Moderatori: ");
define("LAN_389", "Discussione precedente");
define("LAN_390", "Discussione successiva");
define("LAN_391", "Tieni Traccia della Discussione");
define("LAN_392", "Cancella la traccia alla discussione");
define("LAN_393", "Risposta veloce");
define("LAN_394", "Anteprima");
define("LAN_395", "Rispondi alla discussione");
define("LAN_396", "Sito Web");
define("LAN_397", "Email");
define("LAN_398", "Profilo");
define("LAN_399", "Messaggi Privati");
define("LAN_400", "Modifica");
define("LAN_401", "Riporta");
define("LAN_402", "Autore");
define("LAN_403", "Messaggio");
define("LAN_404", "Nessuna discussione precedente");
define("LAN_405", "Nessuna discussione successiva");
define("LAN_406", "Moderatori: Modifica");
define("LAN_435", "Moderatori: Elimina");
define("LAN_408", "Moderatore: Muovi");
define("LAN_409", "Sei sicuro di voler eliminare questa discussione con le sue risposte?");
define("LAN_410", "Sei sicuro di vole cancellare questa risposta?");
define("LAN_411", "scritto da ");
define("LAN_412", "Titolo");
define("LAN_413", "Segnala");
define("LAN_414", "Segnala questo messaggio ad un moderatore");
define("LAN_415", "Titolo discussione");
define("LAN_416", "Inserisci la tua segnalazione");
define("LAN_417", "L'amministratore sar&agrave; avvisato di questa discussione. Puoi scrivere un messaggio spiegando le ragioni delle tue obiezioni.");
define("LAN_418", "<b>ATTENZIONE: NON</b> usare questo modulo per contattare l'amministrazione con altre motivazioni.");
define("LAN_419", "Invia segnalazione");
define("LAN_420", "Premi per vedere il messaggio");
define("LAN_421", "Messaggio segnalato da");
define("LAN_422", "Questo messaggio &egrave; stato segnalato dal sito ");
define("LAN_423", "Il messaggio non pu&ograve; essere inviato. ");
define("LAN_424", "Il messaggio &egrave; stato segnalato al moderatore e all'amministratore.<br />Grazie.");
define("LAN_425", "Messaggio da: ");
define("LAN_426", "Segnalazione messaggio nella discussione: ");
define("LAN_427", "Errore inviando la mail");
define("LAN_428", "Il messaggio &egrave; stato segnalato");
define("LAN_429", "Premi qui per ritornare al forum");
define("LAN_430", "sondaggio");
define("FORLAN_26", "Risposta eliminata");
define("FORLAN_10", "Inizia una nuova discussione");
define("LAN_29", "Modificato");
define("LAN_431", "RSS discussione: rss 0.92");
define("LAN_432", "RSS discussione: rss 2.0");
define("LAN_433", "RSS discussione: RDF");
define("FORLAN_101", "Email Discussione");
define("FORLAN_102", "Anteprima di stampa");
define("FORLAN_103", "[utente eliminato]");
define("FORLAN_104", "Discussione non trovata");
define("FORLAN_HIDDEN", "NASCOSTA - Fai il LOGIN e REPLICA Per Rivelarla");


?>