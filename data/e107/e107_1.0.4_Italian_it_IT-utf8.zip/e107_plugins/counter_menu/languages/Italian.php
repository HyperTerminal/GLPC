<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/22 18:07:49 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/

define("COUNTER_L1", "Gli accessi dell'Amministratore non sono conteggiati.");
define("COUNTER_L2", "Questa pagina oggi ...");
define("COUNTER_L3", "totale");
define("COUNTER_L4", "Questa pagina totale ...");
define("COUNTER_L5", "visite uniche");
define("COUNTER_L6", "Sito ...");
define("COUNTER_L7", "Statistiche");
define("COUNTER_L8", "Messaggio dell'Amministratore: <b>Le Statistiche del sito sono disabilitate.</b><br />Per attivarle, devi installare il Plugin Statistiche Sito dal tuo <a href='".e_ADMIN."plugin.php'>Plugin Manager</a>, successivamente le attivi dal <a href='".e_PLUGIN."log/admin_config.php'>Pannello di Configurazione</a>.");

?>