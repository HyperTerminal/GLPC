<?php

define('LAN_UMENU_THEME_1', 'Imposta Tema');
define('LAN_UMENU_THEME_2', 'Seleziona Tema');
define('LAN_UMENU_THEME_3', 'Utenti:');
define('LAN_UMENU_THEME_4', 'Abilita i Temi che gli Utenti possono selezionare');
define('LAN_UMENU_THEME_5', 'Aggiorna');
define('LAN_UMENU_THEME_6', 'Temi disponibili agli Utenti');
define('LAN_UMENU_THEME_7', 'Gruppo Utenti abilitato a selezionare il Tema');
	
?>