<?php
/*
+---------------------------------------------------------------+
|        e107 website system Italiano Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/alt_auth/languages/Italiano/lan_alt_auth_conf.php $
|        $Revision: 1.0 $
|        $Date: 2008/12/19 13:49:56 $
|        $Author: Maurizio $
+---------------------------------------------------------------+
*/
define('LAN_ALT_1', 'Tipo di autorizzazione corrente');
define('LAN_ALT_2', 'Aggiorna Impostazioni');
define('LAN_ALT_3', 'Scegli un tipo di Autorizzazione Alternativa');
define('LAN_ALT_4', 'Configura i parametri per');
define('LAN_ALT_5', 'Configura i parametri di autorizzazione');
define('LAN_ALT_6', 'Connessione fallita');
define('LAN_ALT_7', 'Se la connessione con il metodo alternativo fallisce, cosa intendi fare?');
define('LAN_ALT_8', 'User not found action');
define('LAN_ALT_9', 'Se lo username non viene trovato con la connessione alternativa, cosa intendi fare?');
define('LAN_ALT_10', 'Login Fallito');
define('LAN_ALT_11', 'Usa tabelle utenti e107');

//1.0.1
define('LAN_ALT_PAGE', 'Alternative authentication');
