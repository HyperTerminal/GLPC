<?php

define('LDAPLAN_1', 'Indirizzo Server');
define('LDAPLAN_2', 'Base DN o Dominio<br />Se LDAP - Inserisci BaseDN<br />Se AD - Inserisci dominio');
define('LDAPLAN_3', 'LDAP Browsing user<br />Full context dell\'utente abilitato alla ricerca delle cartelle.');
define('LDAPLAN_4', 'LDAP Browsing password<br />Password per LDAP Browsing user.');
define('LDAPLAN_5', 'Versione LDAP');
define('LDAPLAN_6', 'Configura LDAP auth');
define('LDAPLAN_7', 'Filtro ricerca eDirectory:');
define('LDAPLAN_8', 'Questo dovrebbe essere usato per assicurarsi che lo username sia nel tree corretto, <br />esempio \'(objectclass=inetOrgPerson)\'');
define('LDAPLAN_9', 'Il filtro di ricerca corrente sarà:');
//define('LDAPLAN_10', 'Impostazioni Aggiornate');
define('LDAPLAN_10', 'WARNING: Se il modulo LDAP non &egrave; al momento disponibile, impostando il tuo metodo di autorizzazione in LDAP probabilmente non funzioner&agrave;!');
define('LDAPLAN_11', 'Server Type');
//define('LDAPLAN_13', 'Aggiorna impostazioni');