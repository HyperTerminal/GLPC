<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the Calendario Eventi (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/usersettings.php $
 * $Id: usersettings.php 11645 2010-08-01 12:57:11Z e107coders $
 */

/**
 *	e107 Calendario Eventi plugin
 *
 *	Language file - anything called up in ecal_class.php and similar
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: English_class.php 11315 2010-02-10 18:18:01Z secretr $;
 */

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'no');
define('EC_LAN_RECUR_01', 'annuale');
define('EC_LAN_RECUR_02', 'biennale');
define('EC_LAN_RECUR_03', 'trimestrale');
define('EC_LAN_RECUR_04', 'mensile');
define('EC_LAN_RECUR_05', 'ogni quattro settimane');
define('EC_LAN_RECUR_06', 'quindicinale');
define('EC_LAN_RECUR_07', 'settimanale');
define('EC_LAN_RECUR_08', 'giornaliero');
define('EC_LAN_RECUR_100', 'Domenica nel mese');
define('EC_LAN_RECUR_101', 'Lunedi nel mese');
define('EC_LAN_RECUR_102', 'Martedi nel mese');
define('EC_LAN_RECUR_103', 'Mercoledi nel mese');
define('EC_LAN_RECUR_104', 'Giovedi nel mese');
define('EC_LAN_RECUR_105', 'Venerdi nel mese');
define('EC_LAN_RECUR_106', 'Sabato nel mese');

define('EC_LAN_RECUR_1100', 'Primo');
define('EC_LAN_RECUR_1200', 'Secondo');
define('EC_LAN_RECUR_1300', 'Terzo');
define('EC_LAN_RECUR_1400', 'Quarto');


// Notify
define('NT_LAN_EC_1', 'Calendario Eventi');
define('NT_LAN_EC_2', 'Evento Aggiornato');
define('NT_LAN_EC_3', 'Aggiornato da');
define('NT_LAN_EC_4', 'Indirizzo IP');
define('NT_LAN_EC_5', 'Messaggio');
define('NT_LAN_EC_6', 'Calendario Eventi - Inserito nuovo Evento');
define('NT_LAN_EC_7', 'Nuovo Evento postato');
define('NT_LAN_EC_8', 'Calendario Eventi - Evento modificato');


// Log messages
define('EC_ADM_01', 'Calendario Eventi - inserito nuovo evento');
define('EC_ADM_02', 'Calendario Eventi - evento editato');
define('EC_ADM_03', 'Calendario Eventi - evento eliminato');
define('EC_ADM_04', 'Calendario Eventi - Eliminazione Bulk');
define('EC_ADM_05', 'Calendario Eventi - Inserimento Multiplo');
define('EC_ADM_06', 'Calendario Eventi - Opzioni Principali modificate');
define('EC_ADM_07', 'Calendario Eventi - FE optioni modificate');
define('EC_ADM_08', 'Calendario Eventi - Inserita Nuova Categoria');
define('EC_ADM_09', 'Calendario Eventi - Editata Categoria');
define('EC_ADM_10', 'Calendario Eventi - Eliminata Categoria');
define('EC_ADM_11', 'Calendario Eventi - Vecchi eventi eliminati');


?>