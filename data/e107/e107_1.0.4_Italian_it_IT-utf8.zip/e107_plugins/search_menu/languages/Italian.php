<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/search_menu/languages/English.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/01/27 19:53:17 $
|     $Author: streaky $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/

define("LAN_180", "Cerca");

?>