<?php
/*
+---------------------------------------------------------------+
|        e107 website system Italiano Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/linkwords/languages/Italiano.php $
|        $Revision: 1.0 $
|        $Date: 2008/12/23 18:46:31 $
|        $Author: Maurizio $
+---------------------------------------------------------------+
*/

define("LWLAN_1", "Campo/i richiesti non compilati");
define("LWLAN_2", "Link word salvata.");
define("LWLAN_3", "Link word aggiornata.");
define("LWLAN_4", "Ancora nessuna link words definita.");
define("LWLAN_5", "Parola");
define("LWLAN_6", "Link");
define("LWLAN_7", "Attivi?");
define("LWLAN_8", "Opzioni");
define("LWLAN_9", "Sì");
define("LWLAN_10", "No");
define("LWLAN_11", "Linkwords esistente");
define("LWLAN_12", "Sì");
define("LWLAN_13", "No");
define("LWLAN_14", "Invia LinkWord");
define("LWLAN_15", "Aggiorna LinkWord");
define("LWLAN_16", "Edita");
define("LWLAN_17", "Elimina");
define("LWLAN_18", "Sei sicuro di volere eliminare questa linkword?");
define("LWLAN_19", "Linkword eliminata.");
define("LWLAN_20", "Impossibile trovare la linkword inserita.");
define("LWLAN_21", "Word da auto-linkare");
define("LWLAN_22", "Attivi?");
define("LWLAN_23", "Amministrazione Linkwords");
define("LWLAN_24", "Gestisci Words");
define("LWLAN_25", "Opzioni");
define("LWLAN_26", "Area in cui abilitare le linkwords");
define("LWLAN_27", "Questo è il 'contesto' del testo visualizzato");
define("LWLAN_28", "Pagine in cui disabilitare le linkwords");
define("LWLAN_29", "Same format as menu visibility control. One match per line. Specify a partial or complete URL. End with '!' for exact match of the end part of the link");
define("LWLAN_30", "Salva opzioni");
define("LWLAN_31", "Aggiungi/edita linkword");
define("LWLAN_32", "Opzioni Linkword");
define("LWLAN_33", "Aree Titolo");
define("LWLAN_34", "Riassunto");
define("LWLAN_35", "testo Body");
define("LWLAN_36", "Descrizione (links etc)");
define("LWLAN_37", "Area Legacy");
define("LWLAN_38", "Link cliccabile");
define("LWLAN_39", "Testo non processato");
define("LWLAN_40", "Titolo definito dall\'utente(e.g. forum)");
define("LWLAN_41", "Testo definito dall\'utente (e.g. forum)");
define("LWLANINS_1", "Linkwords");
define("LWLANINS_2", "Questo plugin ti permette di associare determinate parole ad un link");
define("LWLANINS_3", "Configura LinkWords");
define("LWLANINS_4", "Per configurare click sul link Gestione Plugins");


?>