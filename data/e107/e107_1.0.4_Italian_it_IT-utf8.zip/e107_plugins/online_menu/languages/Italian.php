<?php
/*+---------------------------------------------------------------+
|	e107 website system|
|	
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvs_backup/e107_0.7/e107_plugins/online_menu/languages/English.php,v $
|     $Revision: 11634 $
|     $Date: 2010-07-30 04:30:59 -0500 (Fri, 30 Jul 2010) $
|     $Author: e107coders $
|  
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+---------------------------------------------------------------+
*/

define("ONLINE_L1", "Ospiti: ");
define("ONLINE_L2", "Utenti: ");
define("ONLINE_L3", "In questa pagina: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Totale");
define("ONLINE_L6", "Ultimo");
define("TRACKING_MESSAGE", "La tracciatura degli utenti Online è disabilitata, abilitala [link=".e_ADMIN."users.php?options]qui[/link][br]");
?>