<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsfeed/languages/English_frontpage.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/07 20:56:04 $
|     $Author: sweetas $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "News Feeds");
define("NWSF_FP_2", "Pagina Principale");

?>