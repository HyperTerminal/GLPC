<?php
/*
+---------------------------------------------------------------+
|        e107 website system Italiano Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_themes/jayya/languages/Italiano.php $
|        $Revision: 1.0 $
|        $Date: 2007/10/09 23:58:29 $
|        $Author: e107 Italian Team $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Commenti disabilitati");
define("LAN_THEME_2", "Leggi/Invia Commenti");
define("LAN_THEME_3", "Leggi tutto ...");
define("LAN_THEME_4", "Trackbacks:");
define("LAN_THEME_5", "Inviato da");
define("LAN_THEME_6", "il");


?>