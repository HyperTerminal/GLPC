<?php
/*
+---------------------------------------------------------------+
|        e107 website system Italiano Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_themes/vekna_blue/languages/Italiano.php $
|        $Revision: 1.0 $
|        $Date: 2007/10/10 00:07:04 $
|        $Author: e107 Italian Team $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'vekna blue' by <a href='http://e107.org' rel='external'>jalist</a>, based on, and with permission from Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Leggi/Invia Commenti");
define("LAN_THEME_3", "Commenti disabilitati");
define("LAN_THEME_4", "Leggi tutto ...");
define("LAN_THEME_5", "Trackbacks:");


?>