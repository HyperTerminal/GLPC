<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Seleziona Utenti");
define("US_LAN_2", "Seleziona Gruppo Utenti");
define("US_LAN_3", "Tutti gli Utenti");
define("US_LAN_4", "Trova username");
define("US_LAN_5", "Utente(i) trovato");
define("US_LAN_6", "Cerca");

?>