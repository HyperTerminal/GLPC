<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 11:45:50 $
|     $Author: lisa_ $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "Valutazione");
define("RATELAN_1", "valutazioni");
define("RATELAN_2", "Come valuti questa risorsa?");
define("RATELAN_3", "Grazie per aver valutato questa risorsa");
define("RATELAN_4", "non valutato");
define("RATELAN_5", "Valutazione");

?>