<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/24 11:23:45 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "anno");
define("LANDT_02", "mese");
define("LANDT_03", "settimana");
define("LANDT_04", "giorno");
define("LANDT_05", "ora");
define("LANDT_06", "minuto");
define("LANDT_07", "secondo");
define("LANDT_01s", "anni");
define("LANDT_02s", "mesi");
define("LANDT_03s", "settimane");
define("LANDT_04s", "giorni");
define("LANDT_05s", "ore");
define("LANDT_06s", "minuti");
define("LANDT_07s", "secondi");

define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "sec");
define("LANDT_09s", "secs");
define("LANDT_AGO", "fa");


?>