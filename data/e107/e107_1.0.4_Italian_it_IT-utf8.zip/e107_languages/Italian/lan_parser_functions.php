<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_parser_functions.php,v $
|     $Revision: 11634 $
|     $Date: 2010-07-30 04:30:59 -0500 (Fri, 30 Jul 2010) $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Ospite");
define("LAN_WROTE", "ha scritto"); // as in John wrote.."  ";


?>