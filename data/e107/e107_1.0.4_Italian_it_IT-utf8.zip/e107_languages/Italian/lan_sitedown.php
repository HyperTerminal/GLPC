<?php
/*+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
| 
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_sitedown.php,v $
|     $Revision: 11634 $
|     $Date: 2010-07-30 04:30:59 -0500 (Fri, 30 Jul 2010) $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Sito temporaneamente chiuso");
define("LAN_SITEDOWN_00", "è temporaneamente chiuso");
define("LAN_SITEDOWN_01", "Il sito è temporaneamente chiuso per Manutenzione. Il sito sarà riaperto nel più breve tempo possibile - Arrivederci a presto, ci scusiamo per l'inconveniente.");
?>