<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.|
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: mcfly_e107 $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Solo Utenti registrati");
define("LAN_MEMBERS_0", "Area riservata");
define("LAN_MEMBERS_1", "Questa è un'area riservata");
define("LAN_MEMBERS_2","per accedere fai <a href='".e_LOGIN."'>log in</a>");
define("LAN_MEMBERS_3","oppure <a href='".e_SIGNUP."'>registrati</a>");
define("LAN_MEMBERS_4","Clicca qui per tornare alla Pagina Principale");
?>