<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_news.php,v $
|     $Revision: 11560 $
|     $Date: 2010-05-31 16:04:50 -0500 (Mon, 31 May 2010) $
|     $Author: e107steved $
|
|     Italian Translation: e107 Italian Team - http://www.e107italia.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "News");
define("LAN_NEWS_1", "News solo per utenti specifici");
define("LAN_NEWS_2", "Spiacente, non sei autorizzato a leggere questa news");
define("LAN_NEWS_9", "Impostato solo Titolo - <b>sarà mostrato solo il titolo della news</b><br />");
define("LAN_NEWS_10", "Questa news è <b>inattiva</b> (Non sarà visualizzata in Homepage). ");
define("LAN_NEWS_11", "Questa news è <b>attiva</b> (Sarà visualizzata in Homepage). ");
define("LAN_NEWS_12", "Commenti <b>abilitati</b>. ");
define("LAN_NEWS_13", "Commenti <b>non abilitati</b>. ");
define("LAN_NEWS_14", "<br />Periodo di attivazione: ");
define("LAN_NEWS_15", "Lunghezza testo: ");
define("LAN_NEWS_16", "b. Testo completo: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Adesso");
define("LAN_NEWS_23", "Categorie News");
define("LAN_NEWS_24", "crea pdf di questa news");
define("LAN_NEWS_25", "Edita");
define("LAN_NEWS_31", "Sticky news");
define("LAN_NEWS_82", "News - Categoria");
define("LAN_NEWS_83", "Nessuna news al momento - prova più tardi.");
define("LAN_NEWS_84", "Torna alle News");
define("LAN_NEWS_85", "Torna alle Categorie");
define("LAN_NEWS_86", "News successiva");
define("LAN_NEWS_87", "News precedente");
define("LAN_NEWS_462", "Nessuna news per il mese specificato");
define("LAN_NEWS_99", "Commenti");
define("LAN_NEWS_100", "in");
define("LAN_NEWS_307", "News totali in questa categoria:");


?>