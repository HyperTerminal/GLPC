<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_upload.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Upload");
define("LAN_UL_001", "Indirizzo mail non valido");
define("LAN_UL_002", "Non hai i permessi necessari per caricare i files su questo server.");
define("LAN_UL_020", "Errore");
define("LAN_UL_021", "Upload Non Riuscito");
define("LAN_UL_032", "Devi selezionare una categoria");
define("LAN_UL_033", "Devi inserire un indirizzo email valido");
define("LAN_UL_034", "Devi specificare il nome del file");
define("LAN_UL_035", "Devi inserire la descrizione");
define("LAN_UL_036", "Devi specificare il file da caricare");
define("LAN_UL_037", "Devi specificare una categoria");
define("LAN_UL_038", "");
define("LAN_61", "Il tuo nome: ");
define("LAN_112", "Indirizzo Email: ");
define("LAN_144", "URL Sito web: ");
define("LAN_402", "Devi essere un utente registrato per caricare i file sul server.");
define("LAN_404", "Grazie. Il tuo allegato sarà esaminato da un amministratore e quindi approvato se ritenuto idoneo al sito.");
define("LAN_406", "Attento");
define("LAN_407", "ogni altra estensione caricata sarà automaticamente eliminata.");
define("LAN_408", "Sottolineato");
define("LAN_409", "Nome del file");
define("LAN_410", "Versione");
define("LAN_411", "File");
define("LAN_412", "Miniatura");
define("LAN_413", "Descrizione");
define("LAN_414", "Demo funzionante");
define("LAN_415", "inserisci l'indirizzo web del sito dove è possibile vedere in funzione la demo");
define("LAN_416", "Invia e carica");
define("LAN_417", "Caricamento File");
define("LAN_418", "Massime dimensioni File: ");
define("DOWLAN_11", "Categoria");
define("LAN_419", "Estensioni ammesse");
define("LAN_420", "i campi sono richiesti.");


?>