<?php
/*
+---------------------------------------------------------------+
|        e107 website system Italiano Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_languages/Italiano/lan_installer.php $
|        $Revision: 1.0 $
|        $Date: 2008/12/17 14:37:41 $
|        $Author: Maurizio $
+---------------------------------------------------------------+
*/

define('LANINS_TITLE',	'Installazione e107');  // v. 1.0.0
//define("LANINS_002", "Stage ");
define('LANINS_000',	'Rilevate informazioni non valide! Installazione arrestata.');  // v. 1.0.0
define('LANINS_001',	'Version %1$s');  // v. 1.0.0
define('LANINS_002',	'Installazione');
define('LANINS_002a',	'(Step %1$s of 7)');  // v. 1.0.0
define("LANINS_003", "1");
define("LANINS_004", "Selezione Lingua");
define('LANINS_004a',	'Lingua selezionata');  // v. 1.0.0
define('LANINS_004b',	'Lingua'); // v. 1.0.0
define("LANINS_005", "Prego scegli la Lingua da utilizzare per il processo di installazione");
define("LANINS_006", "Imposta Lingua");
define("LANINS_007", "4");
define("LANINS_008", "Controllo Versioni PHP & MySQL / Controllo Permessi File");
define('LANINS_008a',	'Compatibilit&agrave; &amp; Permessi File'); 
define("LANINS_009", "Testa nuovamente i Permessi File");
define("LANINS_010", "File non scrivibile: ");
define("LANINS_010a", "Cartella non scrivibile: ");
define("LANINS_011", "Errore");
define("LANINS_012", "Le Funzioni MySQL sembrano non esistere. Questo probabilmente significa che o l'estensione MySQL PHP non &egrave; installata oppure che la tua installazione PHP non supporta MySQL.");
define("LANINS_013", "Impossibile determinare la tua versione MySQL. Questo non costituisce un errore fatale, pertanto continua pure il processo si installazione, ma sii consapevole che e107 richiede MySQL >= 3.23 per funzionare correttamente.");
define("LANINS_014", "Permessi File");
define("LANINS_015", "Versione PHP");
define("LANINS_016", "MySQL");
define("LANINS_017", "OK");
define("LANINS_018", "Assicurati che i seguenti file esistano e siano scrivibili lato server. Questo normalmente richiede che siano settati CHMOD 777, ma in caso contrario - contatta il tuo hosting se hai qualunque problema.");
define("LANINS_019", "La versione PHP installata sul tuo server non &egrave; in grado di funzionare con e107. e107 richiede una versione min. PHP 4.3.0 per funzionare correttamente. Aggiorna la tua versione PHP, oppure contatta il tuo host per un aggiornamento.");
define("LANINS_020", "Continua Installazione");
define("LANINS_021", "2");
define("LANINS_022", "Dettagli Server MySQL");
define('LANINS_022a',	'Database');
define('LANINS_023',	'Prego inserisci le tue impostazioni MySQL.<br />Se hai i permessi root puoi creare un nuovo database selezionando la casella crea database. In caso contrario devi creare un database oppure utilizzarne uno pre-esistente.<br /><br />Se hai soltanto un database usa un prefisso in modo che altri scripts possano condividere lo stesso database.<br />Se non conosci i dettagli del tuo MySQL contatta il tuo web host.');
define("LANINS_024", "Server MySQL:");
define("LANINS_025", "Username MySQL:");
define("LANINS_026", "Password MySQL:");
define("LANINS_027", "Database MySQL:");
define("LANINS_028", "Crea Database?");
define("LANINS_029", "Prefisso Tabelle:");
define("LANINS_030", "Il server MySQL che vorresti che e107 utilizzasse. Pu&ograve; includere un port number. es. \"hostname:port\" oppure una path ad un socket locale es. \":/path/to/socket\" per il localhost.");
define("LANINS_031", "Lo username che vuoi che e107 usi per connettersi al tuo server MySQL");
define("LANINS_032", "La Password scelta per lo username sopra inserito");
define("LANINS_033", "Il database MySQL nel quale vuoi che e107 risieda, a volte riferito ad uno schema. Se l'utente ha un database, crea i permessi con i quali puoi operare per creare automaticamente il database se non esiste gia'.");
define("LANINS_034", "Il prefisso che vuoi che e107 usi nel creare le tabelle. Utile per installazioni multiple di e107 in unico schema database.");
define("LANINS_035", "Continua");
define("LANINS_036", "3");
define("LANINS_037", "Verifica Connessione MySQL");
define("LANINS_038", " e Creazione Database");
define('LANINS_038a',	'Validazione Database');  // v. 1.0.0
define("LANINS_039", "Prego assicurati che tutti i campi richiesti siano compilati, in particolare, Server MySQL, Username MySQL e Database MySQL (Questi sono sempre richiesti dal Server MySQL)");
define("LANINS_040", "Errore");
define('LANINS_041',	'Impossibile connettersi al server MySQL utilizzando le informazioni inserite.<br /> Prego torna alla pagina precedente e assicurati che tutte le informazioni siano corrette.');
define("LANINS_042", "Connessione al server MySQL stabilita e verificata.");
define("LANINS_043", "Impossibile creare database, prego assicurati di avere i permessi corretti per creare database sul tuo server.");
define("LANINS_044", "Database creato con successo.");
define("LANINS_045", "Prego clicca il pulsante per procedere allo Step successivo.");
define("LANINS_046", "5");
define("LANINS_047", "Dettagli Admministratore");
define('LANINS_047a',	'Amministrazione'); // v. 1.0.0
define("LANINS_048", "Torna indietro all&rsquo;ultimo Step");
define("LANINS_049", "Le due password inserite non coincidono. Prego torna indietro e riprova.");
define("LANINS_050", "Estensione XML");
define("LANINS_051", "Installata");
define("LANINS_052", "Non Installata");
define("LANINS_053", "e107 0.7.x richiede che sia installata l&rsquo;Estensione PHP XML. Prego contatta il tuo host oppure leggi le informazioni qui: <a href='http://php.net/manual/en/ref.xml.php' target='_blank'>php.net</a> prima di continuare");
define('LANINS_054',	'Controllata con successo l&rsquo;esistenza del database scelto.'); // 
define("LANINS_055", "Conferma Installazione");
define('LANINS_055a',	'Conferma'); // v. 1.0.0

define("LANINS_056", "6");
define('LANINS_057',	'e107 ha ora tutte le informazioni per completare l&rsquo;installazione.<br /><br />Prego clicca il pulsante per creare le tabelle database e salvare tutte le impostazioni.');
define("LANINS_058", "7");
define("LANINS_060", "Impossibile leggere il datafile sql.<br /><br /><br />Prego assicurati che il file <b>core_sql.php</b> esista nella directory <b>/e107_admin/sql</b>.");
define("LANINS_061", "e107 non &egrave; stato in grado di creare tutte le tabelle richieste nel database.<br /><br />Prego pulisci il database e rettifica qualunque inconveniente prima di riprovare nuovamente.");
define("LANINS_062", "");
define("LANINS_063", "Benvenuto in e107");
define("LANINS_069", "e107 &egrave; stato installato con successo! Per motivi di sicurezza dovresti impostare i permessi sul file <b>e107_config.php</b> a 644.Prego cancella anche il file <b>install.php</b> dal tuo server dopo aver cliccato il pulsante sottostante");
define("LANINS_070", "e107: impossibile salvare il file principale di configurazione sul tuo server. Assicurati che il file <b>e107_config.php</b> abbia i permessi corretti");
define("LANINS_071", "Completamento Installazione");
define('LANINS_071a',	'Completato'); // v. 1.0.0
define('LANINS_071b',	'Errore nal Completamento Installazione'); // v. 1.0.0
define('LANINS_071c',	'Completato con errori'); // v. 1.0.0

define("LANINS_072", "Username Amministratore");
define("LANINS_073", "Questo &egrave; il nome che userai per accedere al sito.");
define("LANINS_074", "Nome Reale Amministratore");
define("LANINS_075", "Questo &egrave; il nome che vuoi che sia mostrato agli utenti nel tuo Profilo, Forum e altre aree del sito. Se desideri utilizzare solo lo Username, lascia vuoto questo campo.");
define("LANINS_076", "Password Amministratore");
define("LANINS_077", "Prego inserisci la password amministratore che vuoi usare");
define("LANINS_078", "Conferma Password Amministratore");
define("LANINS_079", "Prego digita nuovamente la password amministratore per la conferma");
define("LANINS_080", "Email Amministratore");
define("LANINS_081", "Inserisci il tuo indirizzo email");
define("LANINS_082", "user@yoursite.com");
define("LANINS_083", "Errori riscontati MySQL:");
define("LANINS_084", "Lo script di installazione non pu&ograve; stabilire una connessione al database");
define("LANINS_085", "Lo script di installazione non pu&ograve; selezionare il database:");
define("LANINS_086", "Username Admin, Password  Admin and Email Admin  sono  campi <b>necessari</b>. Ritorna all&rsquo;ultimo form e verifica che i dati siano correttamente inseriti.");
define("LANINS_087", "Miscellanea");
define("LANINS_088", "Home");
define("LANINS_089", "Download");
define("LANINS_090", "Utenti");
define("LANINS_091", "Invia News");
define("LANINS_092", "Contatti");
define("LANINS_093", "Abilita accesso a elementi riservati dei menu");
define("LANINS_094", "Esempio Gruppo riservato forum");
define("LANINS_095", "Verifica Integrit&agrave;");
define("LANINS_096", "Ultimi commenti");
define("LANINS_097", "[ancora ...]");
define('LANINS_098',	'News');
define('LANINS_099',	'e107 CMS');
define("LANINS_100", "Ultimi Post Forum");
define("LANINS_101", "Aggiorna menu impostazioni");
define("LANINS_102", "Data / Ora");
define('LANINS_103',	'e107 Plugins');
define('LANINS_104',	'Checked');
define("LANINS_105", "Non sono ammessi Nome di Database o Prefisso che inizino con \'e\' or \'E\' .<br />Il Nome del Database o il prefisso non devono essere lasciati vuoti.");  // STRINGA CORRETTA [7.24]
define("LANINS_106", "WARNING - E107 non pu&ograve; scrivere nelle directory e/o file elencati. Questo non interromper&agrave; l&rsquo;installazione di E107 ma alcune impostazioni non saranno disponibili.<br /><br />Ti sar&agrave; richiesto di cambiare i permessi dei file per poter utilizzare queste impostazioni.");
define('LANINS_107',	'e107_config.php non &egrave; un file vuoto'); // v. 1.0.0
define('LANINS_108',	'Probabilmente hai un&rsquo;installazione esistente'); 



define("LANINS_DB_UTF8_CAPTION", "MySQL Charset:");
define("LANINS_DB_UTF8_LABEL",   "Forzare il database UTF-8?");
define("LANINS_DB_UTF8_TOOLTIP", "Se impostato, lo script di installazione cercher&agrave; di rendere il database UTF-8 compatibile se possibile. Il database UTF-8 sar&agrave; necessario per la nuova versione di e107.");


// v1.0 - Be sure to re-check ALL translations above for modifications and additions. 

define("LANINS_109",	"Avviato");
define("LANINS_110",	"Completo");
define("LANINS_111",	"e107 Temi");
define("LANINS_112",	"e107 Handbook");
define("LANINS_113",	"");

define("LANINS_121",	"e107_config.php currently exists!");
define("LANINS_122",	"E' possibile che tu abbia una installazione gi&agrave; attiva");
define("LANINS_123",	"Debug info");
define("LANINS_124",	"Backtrace");
define("LANINS_125",	"Step non valido");
define("LANINS_125a",	"Errore");

define("LANINS_WELCOME", "[b]Benvenuto al tuo nuovo sito e107![/b]
e107 &egrave; stato installato con successo ed &egrave; ora pronto all&rsquo;inserimento di contenuti.<br />L&rsquo;Area Amministrazione &egrave; [link=e107_admin/admin.php]qui[/link], clicca per accedere. Dovrai fare il Login utilizzando Username e Password memorizzate nel processo di installazione.

[b]Supporto[/b]
e107 Italian Team: [link=http://www.e107italia.org]e107 Italia[/link], Team di Supporto Italiano.
e107 Homepage: [link=http://e107.org]http://e107.org[/link], qui troverai FAQ e documentazione (in Inglese).
Forums: [link=http://e107.org/e107_plugins/forum/forum.php]http://e107.org/e107_plugins/forum/forum.php[/link]

Grazie per aver scelto e107, ci auguriamo soddisfi le tue esigenze di un sito web.(Puoi cancellare questo messaggio dall&rsquo;Area Amministrazione.)");

define("LANINS_NEWS", "[b]Benvenuto![/b]
e107 &egrave; un content management system scritto in PHP che usa il popolare database open source MySQL. E' completamente gratuito, personalizzabile e in sviluppo costante.

[list][link=http://e107.org/content/Learn-all-about-e107]Everything you need to know about e107[/link]*[link=http://e107.org/content/About-Us:The-Team]Dev Team | Translators | Support Team[/link]*[link=http://wiki.e107.org/]Documentation Wiki[/link][/list]");



?>