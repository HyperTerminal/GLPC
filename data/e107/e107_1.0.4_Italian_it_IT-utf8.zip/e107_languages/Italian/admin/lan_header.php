<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_header.php,v $
|     $Revision: 1.3 $
|     $Date: 2004/10/25 16:11:40 $
|     $Author: loloirie $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Menù navigazione Admin");
define("LAN_head_2", "Il tuo server non permette il caricamento files via HTTP; sarà impossibile per i tuoi utenti caricare avatars/files etc. Per risolvere questa situazione devi impostare file_uploads a On nel file php.ini e riavviare il tuo server. Se non hai accesso al file php.ini, contatta il tuo hosts.");
define("LAN_head_3", "Your server is running with a basedir restriction in effect. This disallows usage of any file outside of your home directory and as such could affect certain scripts such as the filemanager.");
define("LAN_head_4", "Amministrazione");
define("LAN_head_5", "linguaggio visualizzato in amministrazione: ");
define("LAN_head_6", "Info Plugins");


?>