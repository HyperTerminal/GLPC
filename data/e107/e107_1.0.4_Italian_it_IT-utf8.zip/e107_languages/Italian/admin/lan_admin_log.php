<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Log");
define("LAN_ADMINLOG_1", "Data");
define("LAN_ADMINLOG_2", "Titolo");
define("LAN_ADMINLOG_3", "Descrizione");
define("LAN_ADMINLOG_4", "User IP");
define("LAN_ADMINLOG_5", "User ID");
define("LAN_ADMINLOG_6", "Icona Informativa");
define("LAN_ADMINLOG_7", "Messaggio Informativo");
define("LAN_ADMINLOG_8", "Icona Notizia");
define("LAN_ADMINLOG_9", "Messaggio");
define("LAN_ADMINLOG_10", "Icona di Warning");
define("LAN_ADMINLOG_11", "Messaggio di Warning");
define("LAN_ADMINLOG_12", "Icona errore fatale");
define("LAN_ADMINLOG_13", "Messaggio errore fatale");


?>