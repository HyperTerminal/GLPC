<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/01/06 20:58:08 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define("LAN_CKUSER_01","Check user database");
define("LAN_CKUSER_02","Check per vari potenziali problemi con il database utenti");
define("LAN_CKUSER_03","Se hai molti utenti può impiegare molto tempo oppure andare in time out");
define("LAN_CKUSER_04","Procedi");
define("LAN_CKUSER_05","Cerca per nomi di login duplicati");
define("LAN_CKUSER_06","Seleziona le funzioni da attivare");
define("LAN_CKUSER_07","Nomi utenti duplicati, trovati");
define("LAN_CKUSER_08","Nessun nome duplicato");
define("LAN_CKUSER_09","User Name");
define("LAN_CKUSER_10","User ID");
define("LAN_CKUSER_11","Display Name");
define("LAN_CKUSER_12","Cerca per email duplicate");
define("LAN_CKUSER_13","email duplicate trovate");
define("LAN_CKUSER_14","Email address");
define("LAN_CKUSER_15","Nessun duplicato");
define("LAN_CKUSER_16","Find entries where user name is someone else\"s login name");
define("LAN_CKUSER_17","Conflicting user name and login name");
define("LAN_CKUSER_18","User A");
define("LAN_CKUSER_19","User B");
define("LAN_CKUSER_20","");

?>