<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_db_verify.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 18:29:48 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/

define("DBLAN_1", "Impossibile leggere il file di dati sql<br /><br />Assicurati che il file <b>core_sql.php</b> esista nella cartella <b>/admin/sql</b>.");
define("DBLAN_2", "Verifica in atto");
 //define("DBLAN_3", "per la versione");
define("DBLAN_4", "Tabella");
define("DBLAN_5", "Campo");
define("DBLAN_6", "Status");
define("DBLAN_7", "Note");
define("DBLAN_8", "Abbinamento errato");
define("DBLAN_9", "Attualmente");
define("DBLAN_10", "dovrebbe essere");
define("DBLAN_11", "Campo mancante");
define("DBLAN_12", "Campo Extra!");
define("DBLAN_13", "Tabella mancante!");
define("DBLAN_14", "Scegli tabella/e da verificare");
define("DBLAN_15", "Inizia Verifica");
define("DBLAN_16", "Verifica SQL");
define("DBLAN_17", "Indietro");
define("DBLAN_18", "Tabelle");
define("DBLAN_19", "Tentativo di Riparazione");
define("DBLAN_20", "Tentativo di Riparazione delle tabelle");
define("DBLAN_21", "Ripara gli articoli selezionati ");
define("DBLAN_22", " non è leggibile");

?>