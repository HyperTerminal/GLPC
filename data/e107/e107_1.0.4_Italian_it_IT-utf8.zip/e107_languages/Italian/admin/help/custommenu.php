<?php
//     Italian Translation:
//           e107 Italian Team http://www.e107it.org
//           con la collaborazione di Stefano Vecchi
$text = "Da questo Pannello puoi creare Menù e/o Pagine personalizzati con il contenuto che preferisci.<br /><br />
Per spiegazioni più dettagliate vedi <a href='http://docs.e107.org/Custom Pages'>Using Custom Pages and Custom Menus</a>.";

$ns -> tablerender(CUSLAN_18, $text);
?>
