<?php

//     Italian Translation:
//           e107 Italian Team http://www.e107it.org
//           con la collaborazione di Stefano Vecchi


$text = "Qualsiasi meta tags che inserirai sarà posizionato correttamente nella costruzione della pagina web.";

$ns -> tablerender("Meta Tags", $text);
?>
