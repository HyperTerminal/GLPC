<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Inserisci qui tutti i collegamenti del tuo sito.
I collegamenti aggiunti verranno inseriti nel Menu Principale di navigazione.
Per ulteriori links esterni utilizza il Plugin Link.";
$ns -> tablerender("Help Links del Sito", $text);
?>
