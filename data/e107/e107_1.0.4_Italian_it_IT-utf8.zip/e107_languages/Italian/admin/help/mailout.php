<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Usa questa pagina per configurare tutte le funzioni di invio email nelle varie parti del sito.
Il Modulo consente anche l'invio di email preimpostate per tutti i Gruppi di Utenti del sito.";
$ns -> tablerender("Help Sistema invio email", $text);
?>
