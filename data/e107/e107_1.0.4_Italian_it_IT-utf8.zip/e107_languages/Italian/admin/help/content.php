<?php
//|     Italian Translation:
//|           e107 Italian Team http://www.e107it.org
//|           con la collaborazione di Stefano Vecchi


$text = "Puoi aggiungere una pagina normale al tuo sito usando questa opzione. Un link alla nuova pagina sarà creato nel tuo Mainmenù. Per esempio se crei una pagina con il nome del link 'Test', un link 'Test dovrà appparire nel tuo Mainmenù dopo aver inviato la nuova pagina.<br />
Se vuoi assegnare un Titolo alla tua pagina, inseriscilo in Titolo Pagina.";
$ns -> tablerender("Content Help", $text);
?>
