<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$caption = "Help News";
$text = "<b>Generale</b><br />
Il testo sarà visualizzato sulla Pagina Principale, il testo esteso sarà leggibile cliccando il link 'Leggi tutto'.
<br />
<br />
<b>Mostra solo il Titolo</b>
<br />
Abilitando questa opzione verrà visualizzato nella Pagina Principale soltanto il titolo della news,
con un link per leggere l'intero contenuto.
<br /><br />
<b>Attivazione</b>
<br />
Se imposti una data di inizio e/o scadenza la tua news verrà visualizzata solo entro tali date.";

$ns -> tablerender($caption, $text);
?>
