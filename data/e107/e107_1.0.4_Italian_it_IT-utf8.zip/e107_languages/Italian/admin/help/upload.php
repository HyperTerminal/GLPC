<?php
//     Italian Translation: e107 Italian Team http://www.e107it.org
$text = "Da qui puoi abilitare/disabilitare la possibilità per gli Utenti di caricare files e di
gestirli una volta caricati.";

$ns -> tablerender("Help Uploads Pubblici", $text);
?>
