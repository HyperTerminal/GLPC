<?php
//     Italian Translation:
//           e107 Italian Team http://www.e107it.org
//           con la collaborazione di Stefano Vecchi

$text = "Le Recensioni sono simili agli articoli ma vengono elencate in un diverso elemento di menù.<br />
Per una recensione multipagina separa ogni pagina con il testo [newpage], es. <br /><code>Test1 [newpage] Test2</code><br /> creerà  una recensione di due pagine contenente 'Test1' sulla pagina 1 e 'Test2' sulla pagina 2.";
$ns -> tablerender("Review Help", $text);
?>
