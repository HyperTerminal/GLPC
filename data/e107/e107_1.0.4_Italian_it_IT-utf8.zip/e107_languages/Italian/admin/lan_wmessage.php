<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_wmessage.php,v $
|     $Revision: 1.9 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org	
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Messaggio di Benvenuto");
define("WMLAN_01", "Crea Nuovo Messaggio");
define("WMLAN_02", "Messaggio");
define("WMLAN_03", "Visibilit&agrave;");
define("WMLAN_04", "Testo del Messaggio");
define("WMLAN_05", "Incornicia");
define("WMLAN_06", "Se selezionato, il messaggio verr&agrave; visualizzato all'interno di una cornice");
define("WMLAN_07", "Sostituisci il sistema standard usando la shortcode {WMESSAGE}:");
define("WMLAN_09", "Nessun Messaggio impostato");
define("WMLAN_10", "Titolo Messaggio");


?>