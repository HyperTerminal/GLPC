<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_ugflag.php,v $
|     $Revision: 1.3 $
|     $Date: 2009/10/28 16:53:52 $
|     $Author: e107italia $
|     Italian Translation: e107 Italian Team http://www.e107italia.org
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Impostazioni di Manutenzione aggiornate");
define("UGFLAN_2", "Attiva flag di Manutenzione");
define("UGFLAN_3", "Aggiorna impostazioni Manutenzione");
define("UGFLAN_4", "Impostazioni di Manutenzione");
define("UGFLAN_5", "Testo da visualizzare quando il sito è in Manutenzione");
define("UGFLAN_6", "Lascia vuoto per visualizzare Messaggio di default");

define('UGFLAN_8', 'Limita accesso ai soli Amministratori');			//	Nuovo
define('UGFLAN_9', 'Limita accesso al solo Amministratore Principale');		//		Nuovo
?>