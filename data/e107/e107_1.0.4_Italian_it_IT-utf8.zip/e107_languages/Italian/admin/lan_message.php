<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Messaggi ricevuti");
define("MESSLAN_2", "Cancella Messaggio");
define("MESSLAN_3", "Messaggio cancellato.");
define("MESSLAN_4", "Cancella tutti i Messaggi");
define("MESSLAN_5", "Conferma");
define("MESSLAN_6", "Tutti i messaggi cancellati.");
define("MESSLAN_7", "Nessun Messaggio.");
define("MESSLAN_8", "Tipo Messaggio");
define("MESSLAN_9", "Riportato il");
define("MESSLAN_10", "Inviato da");
define("MESSLAN_11", "apri in una nuova finestra");
define("MESSLAN_12", "Messaggio");
define("MESSLAN_13", "Link");


?>