<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_updateadmin.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
|     Italian Translation: e107 Italian Team http://www.e107it.org
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Errore - prego re-invia");
define("UDALAN_2", "Impostazioni aggiornate");
define("UDALAN_3", "Impostazioni aggiornate per");
define("UDALAN_4", "Nome");
define("UDALAN_5", "Password");
define("UDALAN_6", "Inserisci nuovamente Password");
define("UDALAN_7", "Cambia Password");
define("UDALAN_8", "Password aggiornata per");
?>