tinyMCE.addI18n({it:{
common:{
edit_confirm:"Vuoi usare l'editor WYSIWYG per l'area di testo?",
apply:"Applica",
insert:"Inserisci",
update:"Aggiorna",
cancel:"Annulla",
close:"Chiudi",
browse:"Sfoglia",
class_name:"Classe",
not_set:"-- Non impostato --",
clipboard_msg:"Taglia/Copia/Incolla non � disponibile in Mozilla and Firefox.\nVuoi maggiori informazioni a riguardo?",
clipboard_no_support:"Opzione non supportata dal tuo browser, usa le scorciatorie da tastiera.",
popup_blocked:"Spiacente, abbiamo riscontrato che il blocco dei popup ha disabilitato la finestra che precluce la funzionalita dell'applicazione. Dovrai disabilitare il blocco popup sul sito per utilizzare a pieno questo tool.",
invalid_data:"Errore: � stato inserito un valore non valito, che sono stati marcati di rosso.",
more_colors:"Pi� colori"
},
contextmenu:{
align:"Allineamento",
left:"Sinistra",
center:"Centro",
right:"Destra",
full:"Giustificato"
},
insertdatetime:{
date_fmt:"%A-%m-%g",
time_fmt:"%H:%M:%S",
insertdate_desc:"Inserisci data",
inserttime_desc:"Inserisci ora",
months_long:"Gennaio,Febbraio,Marzo,Aprile,Maggio,Giugno,Luglio,Agosto,Settembre,Ottobre,Novembre,Dicembre",
months_short:"Gen,Feb,Mar,Apr,Mag,Giu,Lug,Ago,Set,Ott,Nov,Dic",
day_long:"Domenica,Luned�,Marted�,Mercoled�,Gioved�,Venerd�,Sabato,Domenica",
day_short:"Dom,Lun,Mar,Mer,Gio,Ven,Sab,Dom"
},
print:{
print_desc:"Stampa"
},
preview:{
preview_desc:"Anteprima"
},
directionality:{
ltr_desc:"Direzione da sinistra a destra",
rtl_desc:"Direzione da destra a sinistra"
},
layer:{
insertlayer_desc:"Inserisci nuovo livello",
forward_desc:"Muovi avanti",
backward_desc:"Muovi indietro",
absolute_desc:"Commuta al posizionamento assoluto",
content:"Nuovo livello..."
},
save:{
save_desc:"Salva",
cancel_desc:"Annulla tutti i cambiamenti"
},
nonbreaking:{
nonbreaking_desc:"Inserisci carattere di interruzione di pagina"
},
iespell:{
iespell_desc:"Lancia controllo ortografia",
download:"Controllo ortografico non trovato. Vuoi installarlo ora?"
},
advhr:{
advhr_desc:"Riga orizzontale"
},
emotions:{
emotions_desc:"Faccine"
},
searchreplace:{
search_desc:"Trova",
replace_desc:"Trova/Sostituisci"
},
advimage:{
image_desc:"Inserisci/modifica immagine"
},
advlink:{
link_desc:"Inserisci/midifica collegamento"
},
xhtmlxtras:{
cite_desc:"Citazione",
abbr_desc:"Abbreviazione",
acronym_desc:"Acronimo",
del_desc:"Barrato",
ins_desc:"Inserzione",
attribs_desc:"Inserisci/modifica attributi"
},
style:{
desc:"Modifica Stile CSS"
},
paste:{
paste_text_desc:"Incolla come testo semplcie",
paste_word_desc:"Incolla da Word",
selectall_desc:"Seleziona tutto"
},
paste_dlg:{
text_title:"Usa CTRL+V sulla tua tastiera per incollare il testo nella finestra.",
text_linebreaks:"Lascia interruzione di pagina",
word_title:"Usa CTRL+V sulla tua tastiera per incollare il testo nella finestra."
},
table:{
desc:"Inserisci una nuova tabella",
row_before_desc:"Inserisci una riga prima",
row_after_desc:"Inserisci una riga dopo",
delete_row_desc:"Cancella riga",
col_before_desc:"Inserisci una colonna prima",
col_after_desc:"Inserisci una colonna dopo",
delete_col_desc:"Rimuovi colonna",
split_cells_desc:"Separa le celle unite nella tabella",
merge_cells_desc:"Unisci celle tabella",
row_desc:"Proprieta riga tabella",
cell_desc:"Proprieta cella tabella",
props_desc:"Proprieta tabella",
paste_row_before_desc:"Incolla riga tabella prima",
paste_row_after_desc:"Incolla riga tabella dopo",
cut_row_desc:"Taglia riga tabella",
copy_row_desc:"Copia riga tabella",
del:"Cancella tabella",
row:"Riga",
col:"Colonna",
cell:"Cella"
},
autosave:{
unload_msg:"Le modifiche apportate verranno perse se si esce da questa pagina."
},
fullscreen:{
desc:"Cambia la modalita a schermo intero"
},
media:{
desc:"Inserisci/modifica oggetto multimediale",
edit:"Modifica oggetto multimediale"
},
fullpage:{
desc:"Proprieta documento"
},
template:{
desc:"Inserisci contenuto da template predefinito"
},
visualchars:{
desc:"Caratteri di controllo visuale on / off."
},
spellchecker:{
desc:"Attiva correttore ortografico",
menu:"Impostazionei correttore ortografico",
ignore_word:"Ignora parola",
ignore_words:"Ignora tutto",
langs:"Lingue",
wait:"Per favore aspetta...",
sug:"Suggerimenti",
no_sug:"Nessun suggerimento",
no_mpell:"Nessun errore rilevato."
},
pagebreak:{
desc:"Inserisci interruzione di pagina."
}}});