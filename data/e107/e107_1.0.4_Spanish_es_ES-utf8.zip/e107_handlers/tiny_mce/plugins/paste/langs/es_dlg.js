﻿tinyMCE.addI18n('es.paste_dlg',{
"word_title":"Usar CTRL+V de su teclado para pegar el texto dentro de la ventana.",
"text_linebreaks":"Mantener salto de linea",
"text_title":"Usar CTRL+V de su teclado para pegar el texto dentro de la ventana."
});