﻿// ES lang variables

tinyMCE.addI18n('es.emoticons',{
	desc : 'Insertar emoticones'
});