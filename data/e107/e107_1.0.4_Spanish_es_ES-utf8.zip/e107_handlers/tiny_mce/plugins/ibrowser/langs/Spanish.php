﻿<?php

$lang_ibrowser_title= 'Insertar/Editar Imagen';
$lang_ibrowser_desc= 'Insertar/Editar Imagen';
$lang_ibrowser_library= 'Librería';
$lang_ibrowser_preview= 'Previsualizar';
$lang_ibrowser_img_sel= 'Seleccionar Imagen';
$lang_ibrowser_img_info= 'Info Imagen';
$lang_ibrowser_img_upload= 'Transferir imagen';
$lang_ibrowser_images= 'Imágenes';
$lang_ibrowser_src= 'Origen';
$lang_ibrowser_alt= 'Descripción';
$lang_ibrowser_size= 'Tamaño';
$lang_ibrowser_align= 'Texto';
$lang_ibrowser_height= 'Altura';
$lang_ibrowser_width= 'Ancho';
$lang_ibrowser_reset= 'Resetear Dimensiones';
$lang_ibrowser_border= 'Borde';
$lang_ibrowser_hspace= 'EspacioH';
$lang_ibrowser_vspace= 'EspacioV';
$lang_ibrowser_select= 'Guardar';
$lang_ibrowser_delete= 'Eliminar';
$lang_ibrowser_cancel= 'Cancelar';
$lang_ibrowser_uploadtxt= 'Archivo';
$lang_ibrowser_uploadbt= 'Transferir';
$lang_ibrowser_marginl = 'Margen Izquierdo';
$lang_ibrowser_marginr = 'Margen Derecho';
$lang_ibrowser_margint = 'Margen Superior';
$lang_ibrowser_marginb = 'Margen Inferior';
$lang_insert_image_align_default = "Por defecto";
$lang_insert_image_align_left = "Izquierdo";
$lang_insert_image_align_right = "Derecho";

// error messages
$lang_ibrowser_error= 'Error';
$lang_ibrowser_errornoimg= 'Seleccione una imagen';
$lang_ibrowser_errornodir= 'La librería no existe físicamente';
$lang_ibrowser_errorupload= 'Ocurrió un error al transferir el archivo. Por favor, pruebe más tarde';
$lang_ibrowser_errortype= 'Tipo de imagen erróneo';
$lang_ibrowser_errordelete= 'Falló al eliminar';
$lang_ibrowser_confirmdelete= '¡Haga click Ok para eliminar la imagen!';
$lang_ibrowser_error_width_nan= '¡El ancho no es un número!';
$lang_ibrowser_error_height_nan= '¡El alto no es un número!';
$lang_ibrowser_error_border_nan= '¡El borde no es un número!';
$lang_ibrowser_error_hspace_nan= '¡El espacio horizontal no es un número!';
$lang_ibrowser_error_vspace_nan= '¡El espacio vertical no es un número!';

?>