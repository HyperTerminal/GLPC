﻿// ES lang variables
tinyMCE.addI18n('es.ibrowser',{
	desc : 'Imagen Browser'
});	