<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Noticias");
define("LAN_NEWS_1", "Noticias, sólo para algunos de sus miembros");
define("LAN_NEWS_2", "No tiene los permisos necesarios para ver estas noticias");
define("LAN_NEWS_9", "Solo título activo - <b>solo se mostrará el título de la noticia</b><br />");
define("LAN_NEWS_10", "Este envío de noticias está <b>inactivo</b> (no se verá en la página). ");
define("LAN_NEWS_11", "Este envío de noticias está <b>activo</b> (se verá en la página). ");
define("LAN_NEWS_12", "Comentarios <b>activados</b>. ");
define("LAN_NEWS_13", "Comentarios <b>desactivados</b>. ");
define("LAN_NEWS_14", "<br />Período de activación: ");
define("LAN_NEWS_15", "Longitud cuerpo: ");
define("LAN_NEWS_16", "b. Longitud extendida: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Ahora");
define("LAN_NEWS_23", "Categoría de Noticias");
define("LAN_NEWS_24", "Crear PDF para esta noticia");
define("LAN_NEWS_25", "Editar");
define("LAN_NEWS_31", "Noticia en destaque");
define("LAN_NEWS_82", "Noticias - Categoría");
define("LAN_NEWS_83", "No hay noticias en este momento - por favor vuelva más tarde.");
define("LAN_NEWS_84", "Volver a Noticias");
define("LAN_NEWS_85", "Volver a Categorías");
define("LAN_NEWS_86", "Noticias Pasadas");
define("LAN_NEWS_87", "Noticias Recientes");
define("LAN_NEWS_462", "No hay noticias para el mes especificado");
define("LAN_NEWS_99", "Comentarios");
define("LAN_NEWS_100", "En");
define("LAN_NEWS_307", "Total de publicaciones en esta categoría: ");


?>