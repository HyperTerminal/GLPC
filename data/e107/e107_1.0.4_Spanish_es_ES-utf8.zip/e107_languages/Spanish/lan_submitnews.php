<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Enviar Noticia");

define("LAN_7", "Nombre: ");
define("LAN_62", "Título de noticia: ");
define("LAN_112", "Email: ");
define("LAN_133", "Gracias");
define("LAN_134", "Su noticia ha sido enviada y será sometida a una revisión por uno de los administradores del sitio.");
define("LAN_135", "Noticia: ");
define("LAN_136", "Enviar Noticia");
define("NWSLAN_6", "Categoría");
define("NWSLAN_10", "No hay categorias");
define("NWSLAN_11", "No tiene acceso a este área.");
define("NWSLAN_12", "Acceso denegado.");

define("SUBNEWSLAN_1", "Debe incluir un título.\\n");
define("SUBNEWSLAN_2", "Debe incluir algún texto en la noticia.\\n");
define("SUBNEWSLAN_3", "El archivo adjunto debe ser jpg, gif o png");
define("SUBNEWSLAN_4", "Archivo demasiado grande");
define("SUBNEWSLAN_5", "Imagen");
define("SUBNEWSLAN_6", "(jpg, gif o png)");

define("SUBNEWSLAN_7", "Usted debe dar su nombre y dirección de correo electrónico");
define("SUBNEWSLAN_8", "Error al subir la imagen");
?>