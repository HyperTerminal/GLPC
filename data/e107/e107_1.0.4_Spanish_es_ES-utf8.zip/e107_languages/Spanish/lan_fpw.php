<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Cambiar Contraseña");

define("LAN_01", "La nueva contraseña ha sido enviada a ".$_POST['email'].", por favor siga las instrucciones en el email para validar su contraseña.");
define("LAN_02", "Lo sentimos, no se puede enviar el email - por favor póngase en contacto con el administrador del sitio.");
define("LAN_03", "Cambiar Contraseña");
define("LAN_04", "Por favor escriba su dirección email");
define("LAN_05", "Por favor escriba su dirección email ...");
define("LAN_06", "Intento de Cambio de contraseña");
define("LAN_07", "Alguien con la dirección IP ");
define("LAN_08", "intentó cambiar la contraseña del administrador principal.");
define("LAN_09", "Contraseña cambiada desde ");
define("LAN_112", "Email: ");
define("LAN_156", "Enviar");
define("LAN_213", "La dirección email no se encuentra en la base de datos.");
define("LAN_214", "No se puede cambiar la contraseña");
define("LAN_215", "Su contraseña para ".SITENAME." ha sido cambiada. Su nueva contraseña es\n\n");
define("LAN_216", "Para validar su nueva contraseña por favor vaya a la siguiente dirección web ...");
define("LAN_217", "Su nueva contraseña ha sido validada, ahora solo tiene que iniciar sesión en el portal con su nueva contraseña.");
define("LAN_218", "Su nombre de usuario es:");
define("LAN_219", "La contraseña asociada a esta cuenta de email fué cambiada y no se puede volver a cambiar. Por favor póngase en contacto con el administrador del sitio.");
define("LAN_FPW1","Usuario");
define("LAN_FPW2","Código");
define("LAN_FPW3","Código Incorrecto");
define("LAN_FPW4","Se envió una solicitud para cambiar esta contraseña, si no ha recibido el email, por favor póngase en contacto con el administrador del sitio.");
define("LAN_FPW5","Se ha solicitado el cambio de su contraseña en");
define("LAN_FPW6","Se ha enviado un email a su cuenta de correo con un enlace que le permitirá cambiar su contraseña.");
define("LAN_FPW7","Este no es un enlace válido para cambiar su contraseña.<br />Por favor póngase en contacto con el administrador del sitio.");
define("LAN_FPW8","La contraseña se cambió correctamente");
define("LAN_FPW9","La nueva contraseña es:");
define("LAN_FPW10","Por favor"); 
define("LAN_FPW11","inicie su sesión ahora"); 
define("LAN_FPW12","e inmediatamente cambie su contraseña, por motivos de seguridad.");

define("LAN_FPW13", "por favor siga las instrucciones del email para validar su contraseña.");
define("LAN_FPW14", "Fué enviado por alguien con la IP");
define("LAN_FPW15", "Esto no quiere decir que su contraseña haya sido cambiada.  Debe acceder al enlace proporcionado al final de este mensaje para completar el cambio de contraseña.");
define("LAN_FPW16", "Si no solicitó resetear su contraseña y NO quiere resetearla, simplemente ignore este correo");
define("LAN_FPW17", "El siguiente enlace será válido durante 48 horas.");
?>