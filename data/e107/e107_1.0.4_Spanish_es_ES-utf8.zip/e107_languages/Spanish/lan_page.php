<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Listado de página desactivado");
define("LAN_PAGE_2", "No hay páginas");
define("LAN_PAGE_3", "La página solicitada no existe");
define("LAN_PAGE_4", "Valorar esta página");
define("LAN_PAGE_5", "Gracias por valorar esta página");
define("LAN_PAGE_6", "No tiene permisos para ver esta página");
define("LAN_PAGE_7", "Contraseña incorrecta");
define("LAN_PAGE_8", "Página con contraseña protegida");
define("LAN_PAGE_9", "Contraseña");
define("LAN_PAGE_10", "Enviar");
define("LAN_PAGE_11", "Lista de página");
define("LAN_PAGE_12", "Página inválida");
define("LAN_PAGE_13", "Página");
?>