<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Vista de impresión"); }

define("LAN_PRINT_86", "Categoría:");
define("LAN_PRINT_87", "por ");
define("LAN_PRINT_94", "Enviada por");
define("LAN_PRINT_135", "Noticias: ");
define("LAN_PRINT_303", "Esta noticia proviene de ");
define("LAN_PRINT_304", "Título del artículo: ");
define("LAN_PRINT_305", "Encabezado: ");
define("LAN_PRINT_306", "Este artículo es de: ");
define("LAN_PRINT_307", "Imprimir esta página");

define("LAN_PRINT_1", "modo impresión");
?>