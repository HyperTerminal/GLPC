<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("RATELAN_0", "Voto");
define("RATELAN_1", "Votos");
define("RATELAN_2", "¿Como valora este elemento?");
define("RATELAN_3", "Gracias por su voto");
define("RATELAN_4", "Sin valorar");
define("RATELAN_5", "Valorar");
?>