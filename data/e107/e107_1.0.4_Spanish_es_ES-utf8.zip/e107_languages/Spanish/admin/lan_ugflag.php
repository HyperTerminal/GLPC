<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('UGFLAN_1', 'Configuración de mantenimiento actualizada');
define('UGFLAN_2', 'Activar aviso de mantenimiento');
define('UGFLAN_3', 'Actualizar Configuración Mantenimiento');
define('UGFLAN_4', 'Configuración de Mantenimiento:');

define('UGFLAN_5', 'Texto a mostrar cuando el sitio esté en mantenimiento');
define('UGFLAN_6', 'Deje en blanco para mostrar el mensaje por defecto');

define('UGFLAN_8', 'Acceso solo para administradores');
define('UGFLAN_9', 'Acceso solo para administradores principales');
?>