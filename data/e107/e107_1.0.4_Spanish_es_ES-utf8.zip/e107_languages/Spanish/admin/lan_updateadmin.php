<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("UDALAN_1", "Error - por favor enviar nuevamente");
define("UDALAN_2", "Configuración actualizada");
define("UDALAN_3", "Configuración actualizada para");
define("UDALAN_4", "Nombre");
define("UDALAN_5", "Contraseña");
define("UDALAN_6", "Re-escribir contraseña");
define("UDALAN_7", "Cambiar Contraseña");
define("UDALAN_8", "Actualizar contraseña de");

?>