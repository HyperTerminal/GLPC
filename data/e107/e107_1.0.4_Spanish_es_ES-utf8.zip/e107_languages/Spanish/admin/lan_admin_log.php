<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_ADMINLOG_0", "Registro del Admin");
define("LAN_ADMINLOG_1", "Fecha");
define("LAN_ADMINLOG_2", "Título");
define("LAN_ADMINLOG_3", "Descripción");
define("LAN_ADMINLOG_4", "Usuario IP");
define("LAN_ADMINLOG_5", "Usuario ID");
define("LAN_ADMINLOG_6", "Icono informativo");
define("LAN_ADMINLOG_7", "Mensaje informativo");
define("LAN_ADMINLOG_8", "Icono aviso");
define("LAN_ADMINLOG_9", "Mensaje aviso");
define("LAN_ADMINLOG_10", "Icono de alarma");
define("LAN_ADMINLOG_11", "Mensaje de alarma");
define("LAN_ADMINLOG_12", "Icono Fatal");
define("LAN_ADMINLOG_13", "Mensaje de error");

?>