<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("DOWLAN_1", "Descarga añadida en la base de datos.");
define("DOWLAN_2", "Descarga actualizada en la base de datos.");
define("DOWLAN_3", "Descarga borrada.");
define("DOWLAN_4", "Por favor, marque la casilla para confirmar el borrado de la descarga");
define("DOWLAN_5", "No hay categorías definidas de descargas.<br />Por favor <a href='download.php?cat'>pulse aquí</a> para crear categorías.");
define("DOWLAN_6", "No hay descargas.");
define("DOWLAN_7", "Descargas:");
define("DOWLAN_11", "Categoría");
define("DOWLAN_12", "Nombre");
define("DOWLAN_13", "Fichero");
define("DOWLAN_14", "Escriba la URL si es un fichero externo");
define("DOWLAN_15", "Autor");
define("DOWLAN_16", "Email del autor");
define("DOWLAN_17", "Sitio Web");
define("DOWLAN_18", "Descripción");
define("DOWLAN_19", "Imagen principal");
define("DOWLAN_20", "Imagen miniatura");
define("DOWLAN_21", "Estado");
define("DOWLAN_24", "Actualizar descarga");
define("DOWLAN_25", "Enviar descarga");
define("DOWLAN_27", "Descarga");
define("DOWLAN_28", "Nada");
define("DOWLAN_29", "Página de Descargas");
define("DOWLAN_30", "Crear Descarga");
define("DOWLAN_31", "Categorías");
define("DOWLAN_32", "Opciones de Descargas");
define("DOWLAN_33", "¿Está seguro de querer borrar esta descarga?");
define("DOWLAN_34", "¿Está seguro de querer borrar esta categoría de descargas?");
define("DOWLAN_36", "eliminada");
define("DOWLAN_37", "Categoría principal");
define("DOWLAN_38", "No existen categorías");
define("DOWLAN_39", "Categorías de descargas");
define("DOWLAN_40", "Categoría principal- Ninguna");
define("DOWLAN_41", "Icono");
define("DOWLAN_42", "Ver imágenes");
define("DOWLAN_43", "Visible para");
define("DOWLAN_44", "La categoría solo sera visible a los usuarios de la clase seleccionada");
define("DOWLAN_45", "Crear");
define("DOWLAN_46", "Actualizar");
define("DOWLAN_47", "¡Categoría creada!");
define("DOWLAN_48", "¡Categoría actualizada!");
define("DOWLAN_49", "Categoría de descargas");
define("DOWLAN_51", "Buscar descargas");
define("DOWLAN_52", "Archivos");
define("DOWLAN_53", "Subcategoría");
define("DOWLAN_54", "Opciones de Descarga");
define("DOWLAN_55", "Nº de descargas por página");
define("DOWLAN_56", "Orden predefinido");
define("DOWLAN_59", "Archivo");
define("DOWLAN_62", "Ascendente");
define("DOWLAN_63", "Descendente");
define("DOWLAN_64", "Actualizar");
define("DOWLAN_65", "¡Opciones Actualizadas!");
define("DOWLAN_66", "Colocar tamaño de archivo");
define("DOWLAN_67", "ID");
define("DOWLAN_68", "¡Archivo Perdido!");
define("DOWLAN_69", "Descargas creadas por PHP");
define("DOWLAN_70", "Seleccionar para descargas a través de PHP.");
define("DOWLAN_100", "Activar aceptación de licencia");
define("DOWLAN_101", "Texto de licencia");
define("DOWLAN_102", "Permitir comentarios");
define("DOWLAN_103", "Eliminar de las transferencias");
define("DOWLAN_104", "¡Fue eliminado de las transferencias públicas!");
define("DOWLAN_105", "Volver a las transferencias públicas");
define("DOWLAN_106", "Descarga disponible para");
define("DOWLAN_107", "Numero de descargas");
define("DOWLAN_108", "Valor de transferencia de descargas");
define("DOWLAN_109", "cada");
define("DOWLAN_110", "día/s");
define("DOWLAN_111", "kb");
define("DOWLAN_112", "Límites");
define("DOWLAN_113", "Clase de usuario");
define("DOWLAN_114", "Añadir");
define("DOWLAN_115", "Actualizar");
define("DOWLAN_116", "El límite para la clase de usuario ya existe");
define("DOWLAN_117", "¡Límite añadido con éxito!");
define("DOWLAN_118", "Límite no añadido - error desconocido");
define("DOWLAN_119", "¡Límite eliminado con éxito!");
define("DOWLAN_120", "Límite no eliminado - error desconocido");
define("DOWLAN_121", "¡Límite actualizado con éxito!");
define("DOWLAN_122", "Inactivo");
define("DOWLAN_123", "Archivo CON límites de descarga - Activar");
define("DOWLAN_124", "Archivo SIN límites de descarga -Activar");
define("DOWLAN_125", "Activar límites de descarga");
define("DOWLAN_126", "¡Estado de activación actualizado!");
define("DOWLAN_127", "Sólo introduzca el tamaño del archivo si la descarga es un archivo externo");
define("DOWLAN_128", "Servidores (Mirrors)");
define("DOWLAN_129", "Dejar en blanco si no usa servidor");
define("DOWLAN_130", "Añadir otro servidor");
define("DOWLAN_131", "Seleccionar archivo local");
define("DOWLAN_132", "Escriba la zona a usar, luego la dirección de la descarga");
define("DOWLAN_133", "¡Servidor actualizado en la base de datos!");
define("DOWLAN_134", "¡Servidor guardado en la base de datos!");
define("DOWLAN_135", "¡Servidor eliminado!");
define("DOWLAN_136", "Imagen");
define("DOWLAN_137", "¿Está seguro que quiere eliminar el servidor de descarga?");
define("DOWLAN_138", "Servidores existentes");
define("DOWLAN_139", "Dirección");
define("DOWLAN_140", "Transferir imágenes para ".e_files."downloadimages para mostrarlas aquí, o escriba la URL si es una imagen externa");
define("DOWLAN_141", "Localización");
define("DOWLAN_142", "Actualizar");
define("DOWLAN_143", "Crear");
define("DOWLAN_144", "No hay servidores definidos en la sección de zonas de descarga");
define("DOWLAN_145", "Visible para");
define("DOWLAN_146", "Mensaje o URL personalizada de negación de descarga");
define("DOWLAN_147", "Icono para categoría vacía");
define("DOWLAN_148", "Seleccionar para actualizar la fecha y la hora actual");
define("DOWLAN_149", "O clic aquí para usar un archivo externo");
define("DOWLAN_150", "Enviar email de informe de una descarga corrupta al administrador");
define("DOWLAN_151", "Envío de informe para descargas corruptas para");
define("DOWLAN_152", "No se puede mover el archivo");
define("DOWLAN_153", "Mover el archivo a la carpeta de descargas");
define("DOWLAN_154", "Si usa servidores, seleccione el modo como se mostraran");
define("DOWLAN_155", "Tipo de presentar la zona:");
define("DOWLAN_156", "Mostrar lista de zonas, permite al usuario elegir la zona de descarga");
define("DOWLAN_157", "Usar zona aleatoria - el usuario no puede seleccionar la zona");
define("DOWLAN_158", "Mostrar sub subcategorías en la página principal de descargas");
define("DOWLAN_159", "Incluir el número de sub subcategororías con las subcategorías");
define("DOWLAN_160", "Impedir descargas simultáneas por usuarios");
define("DOWLAN_161", "Utilizar página de descarga para retrasar la descarga de archivos");
define("DOWLAN_162", "Solicitado por");
define("DOWLAN_163", "Usuario");
define("DOWLAN_164", "IP");
define("DOWLAN_165", "Fecha/Hora");
define("DOWLAN_166", "Volver a la Página Principal de Descargas");
define("DOWLAN_199", "Atención: después de limpiar las estadísticas de cada descarga no podrá reflejar el historial completo de cada una de ellas.");
define("DOWLAN_200", "Numero");
define("DOWLAN_201", "Registro de Limpieza");
define("DOWLAN_202", "Detalle del Registro de Limpieza");


?>