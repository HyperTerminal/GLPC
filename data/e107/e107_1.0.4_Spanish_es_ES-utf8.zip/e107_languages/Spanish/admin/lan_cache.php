<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CACLAN_1", "Estado de Sistema de Caché");
define("CACLAN_2", "Cambiar Estado");
define("CACLAN_3", "Sistema de Caché");
define("CACLAN_4", "Estado de caché alterado!");
define("CACLAN_5", "Vaciar Caché");
define("CACLAN_6", "Caché vaciada!");
define("CACLAN_7", "Caché desactivada");
define("CACLAN_9", "Guardar información de caché en archivo");
define("CACLAN_10", "La carpeta caché [e107_files\cache] no tiene permisos de escritura. Asegúrese de cambiar el directorio con permiso de escritura CHMOD 777");


?>