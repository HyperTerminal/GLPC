<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("UCSLAN_1", "Enviando notificación por e-mail a");
define("UCSLAN_2", "Actualizar privilegios");
define("UCSLAN_3", "Estimado");
define("UCSLAN_4", "Tus privilegios han sido actualizados a");
define("UCSLAN_5", "Ahora tiene acceso en la(s) siguiente(s) área(s)");
define("UCSLAN_6", "Cambiar Clase para usuario");
define("UCSLAN_7", "Cambiar clase");
define("UCSLAN_8", "Notificar usuario");
define("UCSLAN_9", "Clases actualizadas");
define("UCSLAN_10", "Atentamente");
define('UCSLAN_12', 'Solo miembros con privilégios');

?>