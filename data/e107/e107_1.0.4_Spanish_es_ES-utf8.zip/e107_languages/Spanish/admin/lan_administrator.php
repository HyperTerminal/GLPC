<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ADMSLAN_0", "Nuevo usuario/administrador creado para");
define("ADMSLAN_1", "Ahora como administrador.");
define("ADMSLAN_2", "Actualizado en la base de datos.");
define("ADMSLAN_3", "Es el administrador del sitio y no puede ser editado.");
define("ADMSLAN_4", "Continuar");
define("ADMSLAN_5", "¡Error!");
define("ADMSLAN_6", "Es el administrador del sitio y no puede ser borrado.");
define("ADMSLAN_13", "Administradores existentes:");
define("ADMSLAN_16", "Nombre del Admin");
define("ADMSLAN_17", "Contraseña Admin");
define("ADMSLAN_18", "Clase de Permisos");
define("ADMSLAN_19", "Cambiar preferencias del sitio");
define("ADMSLAN_20", "Cambiar menús y páginas personales");
define("ADMSLAN_21", "Modificar permisos de administrador");
define("ADMSLAN_22", "Moderar usuarios/expulsiones etc");
define("ADMSLAN_23", "Crear/editar foros");
define("ADMSLAN_24", "Gestionar categorías de descargas");
define("ADMSLAN_25", "Transferir/gestionar archivos");
define("ADMSLAN_26", "Supervisar categorías de noticias");
define("ADMSLAN_27", "Supervisar categorías de enlaces");
define("ADMSLAN_28", "Apagar sitio por mantenimiento");
define("ADMSLAN_29", "Gestionar anuncios/publicidad");
define("ADMSLAN_30", "Configurar noticias");
define("ADMSLAN_31", "Configurar emoticonos");
define("ADMSLAN_32", "Configurar página de inicio");
define("ADMSLAN_33", "Configurar estadísticas");
define("ADMSLAN_34", "Configurar meta tags");
define("ADMSLAN_35", "Configurar transferencia de archivos");
define("ADMSLAN_36", "Configurar ajustes de imagen");
define("ADMSLAN_37", "Moderar comentarios");
define("ADMSLAN_39", "Añadir Noticias");
define("ADMSLAN_40", "Añadir Enlaces");
define("ADMSLAN_44", "Añadir Descargas");
define("ADMSLAN_45", "Añadir Encuestas");
define("ADMSLAN_46", "Mensaje de Bienvenida");
define("ADMSLAN_47", "Moderar noticias enviadas");
define("ADMSLAN_49", "Seleccionar todo");
define("ADMSLAN_51", "Quitar selección a todo");
define("ADMSLAN_52", "Actualizar Administrador");
define("ADMSLAN_53", "Añadir administradores");
define("ADMSLAN_54", "Administradores");
define("ADMSLAN_55", "Ha dejado campos en blanco");
define("ADMSLAN_56", "Administrador");
define("ADMSLAN_58", "Administrador principal");
define("ADMSLAN_59", "Quitar estado de administrador");
define("ADMSLAN_60", "¿Está seguro de querer quitar el estado de administrador?");
define("ADMSLAN_61", "Administrador eliminado");
define("ADMSLAN_62", "Gestor de Plugins");
define("ADMSLAN_64", "Limpiar el caché del sistema");
define("ADMSLAN_65", "Configurar las opciones de envío");
define("ADMSLAN_66", "Configurar búsquedas");
define("ADMSLAN_67", "Escanear con el inspector de archivos");
define("ADMSLAN_68", "Configurar notificación de email");
define("ADMSLAN_69", "Es ya un Administrador y debe ser editado.");
define("ADMSLAN_70", "Volver a la lista de Administradores");
define("ADMSLAN_71", "Clic aquí para ver los privilegios");
define("ADMSLAN_76", "Administrar paquetes de idioma");


?>