<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("USRLAN_1", "Opciones Guardadas!");
define("USRLAN_3", "es ahora un administrador - para configurar los permisos vaya a la");
define("USRLAN_4", "Página de administrador");
define("USRLAN_5", "No puedes eliminar el estado del administrador");
define("USRLAN_6", "El estado del Administrador ya ha sido eliminado.");
define("USRLAN_7", "No puedes expulsar al administrador del sitio principal");
define("USRLAN_8", "Usuario excluído.");
define("USRLAN_9", "Usuario no excluído.");
define("USRLAN_10", "Usuario eliminado.");
define("USRLAN_11", "Eliminación cancelada.");
define("USRLAN_12", "No puedes eliminar el administrador del sitio.");
define("USRLAN_13", "Por favor, confirme que desea borrar este miembro");
define("USRLAN_16", "Confirmar la eliminación");
define("USRLAN_17", "Confirmar la eliminación del usuario");
define("USRLAN_30", "Expulsar");
define("USRLAN_32", "Activar");
define("USRLAN_33", "No expulsar");
define("USRLAN_34", "Eliminar Estado Admin");
define("USRLAN_35", "Asignar Administrador");
define("USRLAN_36", "Definir Clase");
define("USRLAN_44", "Permitir a los miembros cargar su avatar");
define("USRLAN_47", "Ancho máximo del avatar (píxels)");
define("USRLAN_48", "Tamaño predeterminado 120px");
define("USRLAN_49", "Método de conversión (píxeles)");
define("USRLAN_50", "Tamaño predeterminado 100px");
define("USRLAN_51", "Actualizar");
define("USRLAN_52", "Opciones de miembro");
define("USRLAN_53", "Permitir a los miembros cargar su fotografía");
define("USRLAN_54", "Pulsa aquí para eliminar todos los miembros desactivados");
define("USRLAN_55", "Limpiar");
define("USRLAN_56", "Eliminado");
define("USRLAN_57", "Eliminando miembros desactivados ...");
define("USRLAN_58", "Transferencia de ficheros deshabilitada en php.ini");
define("USRLAN_59", "Añadir usuario rápido");
define("USRLAN_60", "Añadir Usuario");
define("USRLAN_61", "Usuario");
define("USRLAN_62", "Contraseña");
define("USRLAN_63", "Confirmar Contraseña");
define("USRLAN_64", "Email");
define("USRLAN_65", "Este nombre a mostrar no puede ser aceptado, por favor elija otro nombre diferente");
define("USRLAN_66", "Este nombre a mostrar existe en la base de datos, por favor elija otro nombre diferente");
define("USRLAN_67", "Las dos contraseñas no coinciden");
define("USRLAN_68", "Ha dejado en blanco algún/s campos obligatorios");
define("USRLAN_69", "Ésta no parece ser una dirección de e-mail válida");
define("USRLAN_70", "Usuario creado con éxito!");
define("USRLAN_71", "Página Principal");
define("USRLAN_72", "Añadir Usuario");
define("USRLAN_73", "Limpiar Usuarios");
define("USRLAN_75", "Ese nombre de usuario ya existe en la base de datos, elija un nombre de usuario diferente");
define("USRLAN_76", "Opciones de usuario");
define("USRLAN_77", "Usuarios");
define("USRLAN_78", "Nombre de usuario");
define("USRLAN_79", "Estado");
define("USRLAN_80", "Info.");
define("USRLAN_84", "Hay");
define("USRLAN_85", "usuarios que no han activado su cuenta - pulse a continuación para borrarlos.");
define("USRLAN_86", "Usuario verificado");
define("USRLAN_87", "Configuración de usuario actualizada");
define("USRLAN_88", "Clases de usuario actualizadas");
define("USRLAN_90", "Buscar/refrescar");
define("USRLAN_91", "Clase");
define("USRLAN_92", "Caracteres no válidos en el nombre de usuario");
define("USRLAN_93", "Eliminar usuarios sin verificar");
define("USRLAN_94", "Eliminar los usuarios sin confirmación de registro después de (tiempo especificado en minutos) - dejar en blanco para no usar esta opción<br />Esta opción será ignorada si los registros los modera el administrador");
define("USRLAN_95", "minutos");
define("USRLAN_112", "Reenviar Email");
define("USRLAN_113", "Detalles del registro para");
define("USRLAN_114", "Estimado");
define("USRLAN_115", "Gracias por su registro.");
define("USRLAN_116", "Confirme que desea reenviar un email de confirmación a:");
define("USRLAN_117", "Pulse el botón para probar el siguiente email:");
define("USRLAN_118", "Probar email");
define("USRLAN_120", "Elegir Clases");
define("USRLAN_121", "Mailing");
define("USRLAN_122", "Bienvenido a");
define("USRLAN_123", "Su registro ha sido recibido y creado.");
define("USRLAN_124", "Su cuenta está actualmente marcada como inactiva, para activarla pulse sobre el siguiente enlace");
define("USRLAN_125", "Desde");
define("USRLAN_126", "Permitir a usuarios valorar usuarios");
define("USRLAN_127", "Permitir comentarios en perfil de usuario");
define("USRLAN_128", "Nombre de usuario");
define("USRLAN_130", "Activar seguimiento de usuario");
define("USRLAN_131", "Debe activar esta opción para dar seguimiento a las actividades del usuario online, online.php, foro online info y menús online");
define("USRLAN_132", "Activar");
define("USRLAN_133", "Forzar al usuario para que actualice su configuración");
define("USRLAN_134", "Activando esta opción se enviará automáticamente al usuario un aviso para ajustar su configuración, si algún campo requerido no se ha rellenado.");
define("USRLAN_135", "No se encontró la IP en la info de usuario, IP no expulsada");
define("USRLAN_136", "Varios usuarios tienen la ip {IP}, IP no expulsada.");
define("USRLAN_137", "Usuarios con la IP {IP} expulsados.");
define("USRLAN_138", "Usuarios sin verificar");
define("USRLAN_139", "Su cuenta ha sido activada.\n\nPuede visitar {SITEURL} y conectarse en el sitio usando la información de conexión que dispone.");
define("USRLAN_140", "Email reenviado a");
define("USRLAN_141", "Error al reenviar el email a");
define("USRLAN_142", "con el siguiente enlace de activación");
define("USRLAN_143", "Comprobar saltos");
define("USRLAN_144", "Reenviar confirmación de email a todos");
define("USRLAN_145", "Usuarios saltados");
define("USRLAN_146", "Información de miembro disponible para");
define("USRLAN_147", "La dirección de correo la utiliza un usuario expulsado");
define("USRLAN_148", "La dirección de correo está expulsada");
define("USRLAN_149", "Eliminar correos marcados");
define("USRLAN_150", "Eliminar todos los correos");
define("USRLAN_151", "Limpiar saltos requieren activación");
define("USRLAN_152", "Limpiar saltos y activar");
define("USRLAN_153", "Eliminar correos sin saltos");
define("USRLAN_154", "Limiar marca de correo");
define("USRLAN_155", "Total: {TOTAL} Correos encontrados. {DELCOUNT} eliminados a través de opciones.<br />{DELUSER} usuarios marcados como 'saltados' (fuera de {FOUND} correos)");
define("USRLAN_156", "La dirección de e-mail ya está en uso");
define("USRLAN_157", "Caracteres no válidos en el nombre de inicio de sesión");
define("LAN_MAINADMIN", "Admin principal");
define("LAN_NOTVERIFIED", "Sin verificar");
define("LAN_BANNED", "Expuldado");
define("LAN_BOUNCED", "Integrado");
define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "Nombre a Mostrar");
define("DUSRLAN_3", "Usuario");
define("DUSRLAN_4", "Título Personal");
define("DUSRLAN_5", "Contraseña");
define("DUSRLAN_6", "Sesión");
define("DUSRLAN_7", "Email");
define("DUSRLAN_8", "Sitio Web");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "Zona");
define("DUSRLAN_13", "Cunmpleaños");
define("DUSRLAN_14", "Firma");
define("DUSRLAN_15", "Imagen");
define("DUSRLAN_16", "Zona horaria");
define("DUSRLAN_17", "Ocultar email");
define("DUSRLAN_18", "Fecha de ingreso");
define("DUSRLAN_19", "Última visita");
define("DUSRLAN_20", "Visita actual");
define("DUSRLAN_21", "Último envío");
define("DUSRLAN_22", "Envíos de Chat");
define("DUSRLAN_23", "Comentarios");
define("DUSRLAN_24", "Envíos al foros");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "Expulsado");
define("DUSRLAN_27", "Prefs");
define("DUSRLAN_28", "Nuevo");
define("DUSRLAN_29", "Visto");
define("DUSRLAN_30", "Visitas");
define("DUSRLAN_31", "Admin");
define("DUSRLAN_32", "Nombre real");
define("DUSRLAN_33", "Clase de usuario");
define("DUSRLAN_34", "Permisos");
define("DUSRLAN_35", "Foto");
define("DUSRLAN_36", "Cambiar contraseña");
define("DUSRLAN_37", "XUP");
define("USRLAN_190", "Período de prueba para nuevo usuario (días)");
define("USRLAN_191", "(el administrador puede imponer restricciones  en algunas áreas, durante este período de prueba)");
define("USRLAN_194", "La firma puede ser modificada por");
define("USRLAN_219", "Sin cambios a más de 30 días");


?>