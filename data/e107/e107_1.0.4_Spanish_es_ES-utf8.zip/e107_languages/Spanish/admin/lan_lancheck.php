<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_CHECK_1", "Editar/Verificar archivos de idioma");
define("LAN_CHECK_2", "Verificar");
define("LAN_CHECK_3", "Verificación de");
define("LAN_CHECK_4", "¡Archivo perdido!");
define("LAN_CHECK_5", "¡Frase perdida!");
define("LAN_CHECK_7", "Frase");
define("LAN_CHECK_8", "Falta un archivo...");
define("LAN_CHECK_9", "faltan archivos...");
define("LAN_CHECK_10", "Error crítico: ");
define("LAN_CHECK_11", "¡No falta/n archivo/s !");
define("LAN_CHECK_12", "Un archivo está mal...");
define("LAN_CHECK_13", " los archivos están mal...");
define("LAN_CHECK_14", "¡Todos los archivos son válidos!");
define("LAN_CHECK_15", "Caracteres o espacios inapropiados antes de '&lt;?php' o después de '?&gt;'");
define("LAN_CHECK_16", "Archivo Original");
define("LAN_CHECK_17", "Hubo un problema de escritura al intentar guardar el archivo.");
define("LAN_CHECK_18", "No están disponibles los archivos de idiomas estándar para este plugin/tema.");
define("LAN_CHECK_19", "Caracteres UTF-8 no fueron encontrados");
define("LAN_CHECK_20", "Generar Paquete de Idiomas");
define("LAN_CHECK_21", "Nueva Comprobación");
define("LAN_CHECK_22", "Tema");
define("LAN_CHECK_23", "Errores encontrados");
define("LAN_CHECK_24", "Resumen");
define("LAN_CHECK_25", "Temas");
define("LAN_CHECK_26", "Archivo");


?>