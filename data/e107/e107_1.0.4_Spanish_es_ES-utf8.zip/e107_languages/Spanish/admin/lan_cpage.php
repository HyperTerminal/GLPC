<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CUSLAN_1", "Título");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opciones");
define("CUSLAN_4", "¿Borrar esta página?");
define("CUSLAN_5", "Páginas existentes:");
define("CUSLAN_7", "Nombre del menú");
define("CUSLAN_8", "Título página/menú");
define("CUSLAN_9", "Texto del cuerpo");
define("CUSLAN_10", "Permitir valorar página");
define("CUSLAN_11", "Principal");
define("CUSLAN_12", "Crear página");
define("CUSLAN_13", "Permitir comentarios");
define("CUSLAN_14", "Contraseña de página");
define("CUSLAN_15", "<i>Escriba una contraseña para proteger el contenido de la página</i>");
define("CUSLAN_16", "Crear enlace");
define("CUSLAN_17", "<i>Escriba el nombre del enlace a crear en el menú principal</i>");
define("CUSLAN_18", "Página visible a");
define("CUSLAN_19", "Actualizar página");
define("CUSLAN_20", "Crear Página");
define("CUSLAN_21", "Actualizar menú");
define("CUSLAN_22", "Crear Menú");
define("CUSLAN_23", "Editar página");
define("CUSLAN_24", "Crear nueva página");
define("CUSLAN_25", "Editar menú");
define("CUSLAN_26", "Crear nuevo menú");
define("CUSLAN_27", "Página guardada en la Base de Datos.");
define("CUSLAN_28", "Página eliminada");
define("CUSLAN_28a", "Opciones:");
define("CUSLAN_29", "Lista de páginas si no seleccionó una página");
define("CUSLAN_30", "Tiempo de la expiración de la cookie (en segundos)");
define("CUSLAN_31", "Crear menú");
define("CUSLAN_32", "Convertir viejas páginas/menús");
define("CUSLAN_33", "Opciones de página");
define("CUSLAN_34", "Comenzando conversión");
define("CUSLAN_35", "Actualización finalizada en la página personalizada");
define("CUSLAN_36", "Para fijar sus preferencias por cada página, vuelva a la página de trabajo y edite las páginas.");
define("CUSLAN_37", "Página personalizada actualizada");
define("CUSLAN_38", "On");
define("CUSLAN_39", "Off");
define("CUSLAN_40", "Guardar Opciones");

define("CUSLAN_41", "Información de autor y fecha");
define("CUSLAN_42", "No hay páginas definidas todavía");
define('CUSLAN_43', 'Menú sin título: ');
define('CUSLAN_44', 'Página sin título');

?>