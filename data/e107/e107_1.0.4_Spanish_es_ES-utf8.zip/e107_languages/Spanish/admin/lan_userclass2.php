<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("UCSLAN_1", "Eliminar todos los usuarios de esta clase.");
define("UCSLAN_2", "Usuarios de esta clase actualizados.");
define("UCSLAN_3", "Clase borrada.");
define("UCSLAN_4", "Por favor marca la casilla de confirmación para borrar el usuario de esta clase");
define("UCSLAN_5", "Clase actualizada.");
define("UCSLAN_6", "Clase guardada en base de datos.");
define("UCSLAN_7", "No hay clases de usuarios aún.");
define("UCSLAN_8", "Clases existentes");
define("UCSLAN_11", "Marcar para confirmar");
define("UCSLAN_12", "Nombre de Clase");
define("UCSLAN_13", "Descripción de clase");
define("UCSLAN_14", "Actualizar clase de usuario");
define("UCSLAN_15", "Crear Nueva Clase");
define("UCSLAN_16", "Asignar usuarios a esta clase");
define("UCSLAN_17", "Eliminar");
define("UCSLAN_18", "Limpiar Clase");
define("UCSLAN_19", "Asignar usuarios a");
define("UCSLAN_20", "Clases");
define("UCSLAN_21", "Configuraciones para clase de usuario:");
define("UCSLAN_22", "Usuarios - pulse para mover ...");
define("UCSLAN_23", "Usuarios en esta clase ...");
define("UCSLAN_24", "¿Quién puede gestionar las clases?");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Contraseña");
define("UCSLAN_27", "Volver");


?>