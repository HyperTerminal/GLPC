<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FRTLAN_1", "La nueva configuración de la pagina principal fue actualizada!");
define("FRTLAN_2", "Definir como página principal para...");
define("FRTLAN_6", "Enlaces");
define("FRTLAN_12", "Actualizar");
define("FRTLAN_13", "Configuración de página");
define("FRTLAN_15", "Otra (añadir url):");
define("FRTLAN_16", "Error: no hay contenido principal seleccionado");
define("FRTLAN_17", "Error: no hay subcategoría de contenido seleccionado");
define("FRTLAN_18", "Error: no hay ningún contenido seleccionado");
define("FRTLAN_19", "Contenido principal");
define("FRTLAN_20", "Categoría de contenido");
define("FRTLAN_21", "Contenido");
define("FRTLAN_22", "Página personalizada");
define("FRTLAN_26", "Todos los usuarios");
define("FRTLAN_27", "Invitados");
define("FRTLAN_28", "Miembros");
define("FRTLAN_29", "Administradores");
define("FRTLAN_31", "Todos los usuarios");
define("FRTLAN_32", "Clase de usuario");
define("FRTLAN_33", "Configuración actual");
define("FRTLAN_34", "Página");


?>