<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANG_LAN_00", "No se puede crear (ya existe)");
define("LANG_LAN_01", "Fue borrado (si existía) y creado.");
define("LANG_LAN_02", "No puede eliminarse");
define("LANG_LAN_03", "Tablas de Idioma");
define("LANG_LAN_05", "No instalado");
define("LANG_LAN_06", "Crear tablas");
define("LANG_LAN_07", "¿Eliminar tablas existentes?");
define("LANG_LAN_08", "Reemplazar tablas existentes (los datos se perderán).");
define("LANG_LAN_10", "Confirmar eliminación");
define("LANG_LAN_11", "Eliminar tablas de arriba no marcadas (si existen).");
define("LANG_LAN_12", "Seleccionar para activar tablas multi-idioma");
define("LANG_LAN_13", "Preferencias de idioma:");
define("LANG_LAN_14", "Idioma predefinido");
define("LANG_LAN_15", "Para copiar los datos del idioma predeterminado.(útil para enlaces, nuevas categorías, etc.)");
define("LANG_LAN_16", "Uso de base de datos multi-idioma:");
define("LANG_LAN_17", "Idioma predefinido - No se necesitan tablas adicionales.");
define("LANG_LAN_18", "Usar subdominios aparcados con este dominio para fijar el idioma:");
define("LANG_LAN_19", "Ej. El dominio es.midomino.com se fijaría para estar en Español.");
define("LANG_LAN_20", "Escriba un dominio por línea. ej. midominio.com etc. o dejar en blanco para deshabilitar.");
define("LANG_LAN_21", "Herramientas del idioma");
define("LANG_LAN_23", "Crear (zip)");
define("LANG_LAN_24", "Generar");
define("LANG_LAN_AGR", "Nota: mediante el uso de estas herramientas usted se compromete a compartir su paquete de idioma (s) con la comunidad e107.");
define("LANG_LAN_EML", "Por favor envíe su paquete de idioma a:");
define("LANG_LAN_25", "Compruebe que CORE_LC y CORE_LC2 tienen valores en [lcpath] y vuelva a intentarlo.");
define("LANG_LAN_26", "Por favor, asegúrese de que está usando los nombres de carpeta predeterminada en e107_config.php (por ejemplo, 'e107_languages /', 'e107_plugins /', etc) y vuelva a intentarlo.");
define("LANG_LAN_27", "Por favor, compruebe los archivos de idioma ('Verificar') y vuelva a intentarlo.");
define("LANG_LAN_28", "Marque esta casilla si es un [Traductor Certificado e107].");
define("LANG_LAN_29", "Usted debe corregir los errores, antes de contribuir con un nuevo paquete de idioma.");
define("LANG_LAN_30", "Fecha de lanzamiento");
define("LANG_LAN_31", "Compatibilidad");
define("LANG_LAN_32", "Idiomas Instalados");
define("LANG_LAN_33", "Mostrar solo archivos con errores");
define("LANG_LAN_34", "Por favor, verifique y corrija los [X] archivos que contengan errores, antes de intentar crear un paquete de idioma.");


?>