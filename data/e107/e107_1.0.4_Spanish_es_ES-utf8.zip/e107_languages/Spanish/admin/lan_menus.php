<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("MENLAN_1", "Visible para todos");
define("MENLAN_2", "Visible solo para miembros");
define("MENLAN_3", "Visible solo para administradores");
define("MENLAN_4", "Solo visible para:");
define("MENLAN_6", "Guardar las opciones de visibilidad");
define("MENLAN_7", "Configuración de clase para");
define("MENLAN_8", "Clases actualizadas");
define("MENLAN_9", "Nuevo menú personalizado instalado");
define("MENLAN_10", "Nuevo menú instalado");
define("MENLAN_11", "Menú retirado");
define("MENLAN_12", "Activar este menú");
define("MENLAN_13", "Activar en área");
define("MENLAN_14", "Área");
define("MENLAN_15", "Desactivar");
define("MENLAN_16", "Configurar");
define("MENLAN_17", "Mover arriba");
define("MENLAN_18", "Mover abajo");
define("MENLAN_19", "Mover al área");
define("MENLAN_20", "Visible");
define("MENLAN_22", "Menús inactivos");
define("MENLAN_23", "Mover al último");
define("MENLAN_24", "Mover al primero");
define("MENLAN_25", "Función ...");
define("MENLAN_26", "Este menú solo se<strong> MOSTRARÁ </strong>en las siguientes páginas");
define("MENLAN_27", "Este menú solo se<strong> OCULTARÁ </strong>en las siguientes páginas");
define("MENLAN_28", "Introduzca una página por línea, introduzca la URL. Si usted necesita una url que coincida exactamente, al final de la linea utilice una! <br />por ejemplo: <strong>page.php?1!</strong>");
define("MENLAN_29", "Seleccionar Plantilla");
define("MENLAN_30", "Para ver áreas de menú y sus posiciones en las plantillas personalizadas, seleccione su plantilla personalizada aquí:");
define("MENLAN_31", "Plantilla Predeterminada");
define("MENLAN_32", "Plantilla Cabecera de Noticias");
define("MENLAN_33", "Plantilla Personalizada");
define("MENLAN_34", "Integrado");
define("MENLAN_35", "Configurar Menús");
define("MENLAN_36", "Escoja el/los menú/s a activar");
define("MENLAN_37", "y donde activarlos.");
define("MENLAN_38", "Mantenga la tecla CRTL para seleccionar múltiples menús.");
?>