<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Créditos e107");
define("CRELAN_1", "Créditos");
define("CRELAN_2", "Debajo está una lista de recursos y software de terceras personas para e107. Agradecemos su colaboración así como el permitir usar su software bajo licencia GPL");
define("CRELAN_3", "Todos los derechos reservados");
define("CRELAN_4", "Mostrar equipo e107");
define("CRELAN_5", "Mostrar script de terceros");
define("CRELAN_6", "e107 ha sido realizado por...");
define("CRELAN_7", "Versión");
define("CRELAN_8", "permiso concedido");
define("CRELAN_9", "Licenciaa");
define("CRELAN_10", "MagpieRSS proporciona XML-based (expat) RSS parser en PHP.");
define("CRELAN_11", "PclZip ofrece compresión y extracción en archivos Zip");
define("CRELAN_12", "PclTar ofrece archivar una lista de archivos o directorios con o sin compresión. Los archivos creados por PclTar son leíbles por cualquier aplicación gzip/tar.");
define("CRELAN_13", "TinyMCE es una plataforma web independiente basado en Javascript proporcionando un editor WYSIWYG por Moxiecode Systems AB. Tiene la propiedad de convertir codigo html en texto perfectamente leíble.");
define("CRELAN_14", "Iconos usados en e107");
define("CRELAN_15", "Clase de transferencia de mail de PHP");
define("CRELAN_16", "Sistema de menús en el tema Jayya");
define("CRELAN_17", "Calendario Popup");
define("CRELAN_18", "Soporte PDF");
define("CRELAN_19", "Soporte UTF-8 PDF");
define("CRELAN_20", "");
define("CRELAN_21", "Always a pressure..err..pleasure!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Sigamos en frente!");
define("CRELAN_30", "");


?>