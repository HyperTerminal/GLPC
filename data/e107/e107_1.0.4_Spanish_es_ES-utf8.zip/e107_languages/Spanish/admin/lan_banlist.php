<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("BANLAN_1", "Expulsión eliminada.");
define("BANLAN_2", "No hay expulsados.");
define("BANLAN_3", "Expulsados existentes:");
define("BANLAN_4", "Eliminar expulsión");
define("BANLAN_5", "Expulsar por IP, e-mail o host");
define("BANLAN_7", "Razón");
define("BANLAN_8", "Expulsar Usuario");
define("BANLAN_9", "Expulsar usuarios del sitio:");
define("BANLAN_10", "IP/Email/Razón");
define("BANLAN_11", "Auto-expulsión: Más de 10 intentos de conexión fallidos");
define("BANLAN_12", "Nota: DNS reversa está actualmente desactivada, debe activarse para permitir expulsar un dominio. La expulsión por IP y correo seguirá funcionando correctamente.");
define("BANLAN_13","Nota: Para expulsar a un usuario por su nombre, vaya a la página de administración de usuarios");
define("BANLAN_78", "Nº de visitas superado (fue exedido el tiempo asignado)");
?>