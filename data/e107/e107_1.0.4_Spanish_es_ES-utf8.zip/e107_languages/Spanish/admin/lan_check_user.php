<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('LAN_CKUSER_01','Verificar base de datos de usuario');
define('LAN_CKUSER_02','Este buscará varios problemas potenciales con su base de datos de usuario');
define('LAN_CKUSER_03','Si usted tiene muchos usuarios, puede demorar algún tiempo.');
define('LAN_CKUSER_04','Continuar');
define('LAN_CKUSER_05','Verificar los nombres duplicados de inicio de sesión');
define('LAN_CKUSER_06','Seleccione las funciones que desea realizar');
define('LAN_CKUSER_07','Nombres de usuario (Duplicados) encontrados');
define('LAN_CKUSER_08','No hay duplicados');
define('LAN_CKUSER_09','Nombre de usuario');
define('LAN_CKUSER_10','ID de usuario');
define('LAN_CKUSER_11','Nombre para mostrar');
define('LAN_CKUSER_12','Verificar direcciones de correo electrónico duplicadas');
define('LAN_CKUSER_13','Duplicar las direcciones de correo electrónico encontrado');
define('LAN_CKUSER_14','Dirección de correo');
define('LAN_CKUSER_15','No se han encontrado duplicados.');
define('LAN_CKUSER_16','Encuentra registros donde el nombre de usuario es de otra persona.');
define('LAN_CKUSER_17','Conflicto entre nombre de usuario y nombre de la cuenta de usuario.');
define('LAN_CKUSER_18','Usuario A');
define('LAN_CKUSER_19','Usuario B');
define('LAN_CKUSER_20','');

?>