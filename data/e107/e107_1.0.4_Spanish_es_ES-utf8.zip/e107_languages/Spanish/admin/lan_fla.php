<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FLALAN_1", "Fallo en los intentos de conexión");
define("FLALAN_2", "No se han registrado fallos de conexión");
define("FLALAN_3", "Intento(s) eliminado(s)");
define("FLALAN_4", "Un usuario intentó conectar con un nombre o contraseña incorrectas");
define("FLALAN_5", "IP(s) expulsado(s)");
define("FLALAN_6", "Fecha");
define("FLALAN_7", "Datos");
define("FLALAN_8", "IP dirección / Servidor");
define("FLALAN_9", "Opciones");
define("FLALAN_10", "Eliminar / expulsar entradas marcadas");
define("FLALAN_11", "Marca todas la cajas de eliminación");
define("FLALAN_12", "Desmarca todas las cajas de eliminación");
define("FLALAN_13", "Marca todas las cajas de expulsión");
define("FLALAN_14", "Desmarca todas las cajas de expulsión");
define("FLALAN_15", "La(s) siguiente(s) IP(s) han sido autoexpulsadas - El usuario intentó la conexión más de 10 veces");
define("FLALAN_16", "Eliminar esta lista de auto-expulsados");
define("FLALAN_17", "Lista de auto-expulsados eliminada");

?>