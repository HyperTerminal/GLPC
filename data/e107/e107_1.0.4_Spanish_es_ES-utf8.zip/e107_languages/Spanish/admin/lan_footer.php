<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FOOTLAN_1", "Sitio");
define("FOOTLAN_2", "Admin. Principal");
define("FOOTLAN_3", "Versión");
define("FOOTLAN_4", "Revisión");
define("FOOTLAN_5", "Tema de Admin");
define("FOOTLAN_6", "Por");
define("FOOTLAN_7", "Info.");
define("FOOTLAN_8", "Fecha Instalación");
define("FOOTLAN_9", "Servidor");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "Versión PHP");
define("FOOTLAN_12", "mySQL");
define("FOOTLAN_13", "Info. Sitio");
define("FOOTLAN_14", "Ver Documentos");
define("FOOTLAN_15", "Documentación");
define("FOOTLAN_16", "Base de Datos");
define("FOOTLAN_17", "Juego de Caracteres");
define("FOOTLAN_18", "Tema del Sitio");
define("FOOTLAN_19", "Tiempo actual del servidor");
define("FOOTLAN_20", "Nivel de seguridad");


?>