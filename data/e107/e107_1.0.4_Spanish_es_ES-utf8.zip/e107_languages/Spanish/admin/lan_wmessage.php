<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

//define("WMGLAN_1", "Mensaje para invitados");
//define("WMGLAN_2", "Mensaje para miembros");
//define("WMGLAN_3", "Mensaje para Administradores");
//define("WMGLAN_4", "Enviar");
//define("WMGLAN_5", "Poner mensaje de bienvenida");
//define("WMGLAN_6", "¿Activar?");
//define("WMGLAN_7", "Ajustes de mensajes de bienvenida actualizado.");

define("WMLAN_00","Mensajes de Bienvenida");
define("WMLAN_01","Nuevo Mensaje");
define("WMLAN_02","Mensaje");
define("WMLAN_03","Ver");
define("WMLAN_04","Texto de mensaje");

define("WMLAN_05","Encerrado");
define("WMLAN_06","<b>On:</b> El mensaje se renderizará en la caja");
define("WMLAN_07","Invalidar el método abreviado {WMESSAGE}:");
//define("WMLAN_08","Preferencias");

define("WMLAN_09","No hay mensajes de bienvenida");
define("WMLAN_10","Texto del mensaje");

?>