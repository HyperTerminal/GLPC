<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Acción");
define("LAN_UPDATE_3", "No necesaria");

define("LAN_UPDATE_5", "Actualización disponible");
define("LAN_UPDATE_7", "Ejecutado");
define("LAN_UPDATE_8", "Actualizar de");
define("LAN_UPDATE_9", "para");
define("LAN_UPDATE_10", "Actualizaciones disponibles");
define("LAN_UPDATE_11", "Actualización de .617 a .7xx");
define("LAN_UPDATE_12", "Una de sus tablas contiene entradas duplicadas.");
?>