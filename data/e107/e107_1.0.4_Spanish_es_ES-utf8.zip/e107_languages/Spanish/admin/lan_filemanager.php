<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FMLAN_1", "Actualizado");
define("FMLAN_2", "A");
define("FMLAN_3", "Directorio");
define("FMLAN_4", "El fichero transferido excede el máximo tamaño permitido en php.ini.");
define("FMLAN_10", "Error");
define("FMLAN_12", "Fichero");
define("FMLAN_13", "Ficheros");
define("FMLAN_14", "Directorio");
define("FMLAN_15", "Directorios");
define("FMLAN_16", "Directorio raíz");
define("FMLAN_17", "Nombre");
define("FMLAN_18", "Tamaño");
define("FMLAN_19", "Última modificación");
define("FMLAN_21", "Transferir fichero a este directorio");
define("FMLAN_22", "Transferir");
define("FMLAN_26", "Borrado");
define("FMLAN_27", "Completado");
define("FMLAN_28", "No se pudo borrar");
define("FMLAN_29", "Ruta");
define("FMLAN_30", "Transferir");
define("FMLAN_31", "Carpeta");
define("FMLAN_32", "Seleccione Directorio");
define("FMLAN_33", "Seleccionar");
define("FMLAN_34", "Seleccionar directorio:");
define("FMLAN_35", "Directorio e107_files");
define("FMLAN_36", "Directorio Menús Personalizados ");
define("FMLAN_37", "Directorio Páginas Personalizadas");
define("FMLAN_38", "Archivo/s movido/s con éxito a");
define("FMLAN_39", "Imposible mover el/los archivo/s a");
define("FMLAN_40", "Directorio Newspost-Images");
define("FMLAN_43", "Eliminar archivos seleccionados");
define("FMLAN_46", "Confirme que desea ELIMINAR los archivos seleccionados.");
define("FMLAN_47", "Transferencias de usuario");
define("FMLAN_48", "Mover los seleccionados a");
define("FMLAN_49", "Por favor, confirme que desea mover los archivos seleccionados.");
define("FMLAN_50", "Mover");
define("FMLAN_51", "Error no identificado:");


?>