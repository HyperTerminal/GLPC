<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ayuda:<br />
			# Expulsar usuarios";
$text = "Usted puede expulsar usuarios de su sitio desde este área.<br />
Escriba una dirección IP completa o use comodines para expulsar un rango completo de direcciones IP.
También puede escribir una dirección email para impedir el registro como miembro en su sitio.<br /><br />
<b>Expulsar por dirección IP:</b><br />
Escribiendo la dirección IP 123.123.123.123 expulsará a los visitantes de su sitio que accedan desde esa dirección IP.<br />
Escribiendo la dirección IP 123.123.123.* expulsará a todos los visitantes que accedan desde una dirección IP dentro de ese rango.<br /><br />
<b>Expulsar por dirección email</b><br />
Escribiendo la dirección email foo@bar.com expulsará o no permitirá el registro al miembro registrado con esa dirección de email.<br />
Escribiendo la dirección email *@bar.com expulsará o no permitirá el registro a los miembros que usen ese dominio en su dirección de email.";
$ns -> tablerender($caption, $text);
?>