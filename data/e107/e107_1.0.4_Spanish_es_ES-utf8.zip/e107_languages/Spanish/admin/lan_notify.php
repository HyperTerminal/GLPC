<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NT_LAN_1", "Notificaciones:");
define("NT_LAN_2", "Recibir notificación via email para");
define("NT_LAN_3", "OFF");
define("NT_LAN_4", "Administrador Principal");
define("NT_LAN_5", "Clase");
define("NT_LAN_6", "Email");
define("NU_LAN_1", "Eventos de usuario");
define("NU_LAN_2", "Registro de usuario");
define("NU_LAN_3", "Verificación de cuenta de usuario");
define("NU_LAN_4", "Usuario conectado");
define("NU_LAN_5", "Usuario desconectado");
define("NS_LAN_1", "Eventos de seguridad");
define("NS_LAN_2", "IP expulsada por excesos");
define("NN_LAN_1", "Eventos de noticias");
define("NN_LAN_2", "Noticias enviadas por");
define("NN_LAN_3", "Noticias enviadas por Admin");
define("NN_LAN_4", "Noticias editadas por Admin");
define("NN_LAN_5", "Noticias eliminadas por Admin");
define("NF_LAN_1", "Eventos de archivo");
define("NF_LAN_2", "Archivo transferido por el usuario");
define("CM_LAN_1", "Comentarios de Eventos");
define("CM_LAN_2", "Comentario publicado por el usuario, está pendiente de aprobación");


?>