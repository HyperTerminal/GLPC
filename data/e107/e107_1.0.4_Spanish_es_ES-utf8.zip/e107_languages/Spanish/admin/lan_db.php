<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("DBLAN_1", "La configuración principal del núcleo fue guardada como cópia de seguridad dentro de la carpeta:<br />“e107_admin/sql” con el nombre de “core_sql.php”. (backup de la base de datos).");
define("DBLAN_2", "Backup BD");
define("DBLAN_3", "Hacer Backup de base de datos SQL");
define("DBLAN_4", "Chequear validación de la base de datos");
define("DBLAN_5", "Verificar");
define("DBLAN_6", "Optimizar base de datos SQL");
define("DBLAN_7", "Optimizar");
define("DBLAN_8", "Cópia de seguridad del Núcleo");
define("DBLAN_9", "Backup de Núcleo");
define("DBLAN_10", "Utilidades de la base de datos:");
define("DBLAN_11", "Base de datos MySQL");
define("DBLAN_12", "Optimizada");
define("DBLAN_13", "Volver");
define("DBLAN_14", "Hecho");
define("DBLAN_15", "Ver y buscar actualizaciones disponibles");
define("DBLAN_16", "Actualizaciones");
define("DBLAN_17", "Pref. Nombre"); 
define("DBLAN_18", "Pref. Valor"); 
define("DBLAN_19", "Editor de preferencias (solo ususarios avanzados)"); 
define("DBLAN_20", "Preferencias"); 
define("DBLAN_21", "Eliminar marcados");
define("DBLAN_22", "Plugin: Ver y escanear"); 
define("DBLAN_23", "Escaneado completado"); 
define("DBLAN_24", "Nombre"); 
define("DBLAN_25", "Directorio"); 
define("DBLAN_26", "Complementos incluídos"); 
define("DBLAN_27", "Instalado"); 
define("DBLAN_28", "Escanear los cambios en los directorios de plugins"); 
define("DBLAN_29", "Escanear Directorios");
define("DBLAN_30","(Si un plugin muestra algún error, compruebe los carácteres fuera de los tags de apertura y cierre de PHP)");
define("DBLAN_31","Acceso");
define("DBLAN_32","Error");
define("DBLAN_33","Inaccesible");
define("DBLAN_34","Sin comprobar");
define('DBLAN_35', 'Comprobar la validez de la tabla usuarios');
define('DBLAN_36', 'Tabla Usuarios');
?>