<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderado.");
define("MDCLAN_2", "No hay comentarios");
define("MDCLAN_3", "Miembro");
define("MDCLAN_4", "Invitado");
define("MDCLAN_5", "Desbloquear");
define("MDCLAN_6", "Bloquear");
define("MDCLAN_7", "Aprobado");
define("MDCLAN_8", "Moderar comentarios");
define("MDCLAN_9", "¡Cuidado! Borrando el comentario raíz borrará todas sus respuestas!");
define("MDCLAN_10", "Opciones");
define("MDCLAN_11", "Comentario");
define("MDCLAN_12", "Comentarios");
define("MDCLAN_13", "Bloqueado");
define("MDCLAN_14", "Bloquear comentarios");
define("MDCLAN_15", "Abierto");
define("MDCLAN_16", "Cerrado");
define("MDCLAN_17", "No hay comentarios pendientes para aprobación en este momento");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>