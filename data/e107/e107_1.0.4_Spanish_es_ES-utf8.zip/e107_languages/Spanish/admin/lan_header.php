<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_head_1", "Menú Admin.");
define("LAN_head_2", "Su servidor no admite la transferencia de archivos via HTTP, los usuarios no podrán transferir sus avatares/archivos etc. Para corregir esto cambie file_uploads a On en su php.ini y reinicie el servidor. Si usted no tiene acceso al servidor póngase en contacto con su proovedor de hosting.");
define("LAN_head_3", "Su servidor está ejecutando una restricción en el directorio principal. Esto no permitirá el uso de algunos archivos fuera de su carpeta principal y afectará a determinados Scripts como el gestor de ficheros.");

define("LAN_head_4", "Area Admin.");

define("LAN_head_5", "Idioma mostrado en el área del Admin: ");
define("LAN_head_6", "Info de plugins");
?>