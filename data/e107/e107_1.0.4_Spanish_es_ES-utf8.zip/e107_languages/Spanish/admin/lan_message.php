<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducci�n Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("MESSLAN_1", "Mensajes recibidos");
define("MESSLAN_2", "Eliminar mensaje");
define("MESSLAN_3", "Mensaje borrado.");
define("MESSLAN_4", "Eliminar todos los mensajes");
define("MESSLAN_5", "Confirmar");
define("MESSLAN_6", "Todos los mensajes borrados.");
define("MESSLAN_7", "Sin mensajes.");
define("MESSLAN_8", "Tipo de mensaje");
define("MESSLAN_9", "Informe");

define("MESSLAN_10", "Enviado por");
define("MESSLAN_11", "Abrir en nueva ventana");
define("MESSLAN_12", "Mensaje");
define("MESSLAN_13", "Enlace");
?>