<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "De:");
define("LAN_EMAIL_2", "Dirección IP del remitente:");
define("LAN_EMAIL_3", "Noticia desde ");
define("LAN_EMAIL_4", "Enviar e-mail");
define("LAN_EMAIL_5", "Envíar por e-mail");
define("LAN_EMAIL_6", "Creo que estarías muy interesad@ en este email de, ");
define("LAN_EMAIL_7", "Enviar por e-mail");
define("LAN_EMAIL_8", "Comentário"); 
define("LAN_EMAIL_9", "Lo sentimos - imposible enviar el correo"); 
define("LAN_EMAIL_10", "Correo enviado a"); 
define("LAN_EMAIL_11", "Correo enviado"); 
define("LAN_EMAIL_12", "Error"); 
define("LAN_EMAIL_13", "Enviar artículo por correo a un amigo"); 
define("LAN_EMAIL_14", "Enviar noticia por correo a un amigo"); 
define("LAN_EMAIL_15", "Nombre de usuario: "); 
define("LAN_EMAIL_106", "Esta no parece una dirección de email válida");
define("LAN_EMAIL_185", "Enviar artículo");
define("LAN_EMAIL_186", "Enviar noticia");
define("LAN_EMAIL_187", "Email del destinatario");
define("LAN_EMAIL_188", "Espero que le guste esta noticia de");
define("LAN_EMAIL_189", "Espero que le guste este artículo de");
define("LAN_EMAIL_190", "Entre código visible");
?>