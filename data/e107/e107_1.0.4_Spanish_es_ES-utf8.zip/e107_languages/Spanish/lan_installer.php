<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('LANINS_TITLE',	'Instalación e107');
define('LANINS_000', 	'Información incorrecta! Instalación interrumpuda.');
define('LANINS_001', 	'Versión %1$s');
define('LANINS_002', 	'Instalación');
define('LANINS_002a', 	'(Etapa %1$s de 7)');
define('LANINS_003', 	'1');
define('LANINS_004', 	'Seleccionar idioma');
define('LANINS_004a', 	'Idioma seleccionado');
define('LANINS_004b', 	'Idioma');
define('LANINS_005', 	'Por favor, escoja el idioma a utilizar durante el proceso de instalación');
define('LANINS_006', 	'Definir Idioma');
define('LANINS_007', 	'4');
define('LANINS_008', 	'Verificación de las versiones de PHP &amp; MySQL e de los permisos de archivos');
define('LANINS_008a', 	'Compatibilidad y permisos de archivos');
define('LANINS_009', 	'Reinicie los permisos del archivo');
define('LANINS_010', 	'Archivo no editable: ');
define('LANINS_010a', 	'Carpeta no editable: ');
define('LANINS_011', 	'Error');
define('LANINS_012', 	'Las funciones de MySQL parecen no existir. Esto puede significar que la extensión MySQL de PHP no está instalada o su versión de PHO no fué compilada para funcionar con MySQL.'); // help for 012
define('LANINS_013', 	'No se pudo determinar la versión de su MySQL. Esto podría significar que su servidor MySQL está caído o rechazando las conexiones.');
define('LANINS_014', 	'Permisos de archivo');
define('LANINS_015', 	'Versión PHP');
define('LANINS_016', 	'MySQL');
define('LANINS_017', 	'OK');
define('LANINS_018', 	'Asegúrese de que estos archivos listados tienen permisos de escritura. Si tiene algún problema a la hora de configurarlos, contacte con su servidor.');
define('LANINS_019', 	'La versión de PHP instalada en su servidor no es operativa para funcionar con e107. e107 requiere una versión mayor de 4.3.0 para funcionar correctamente. Actualice su versión PHP o contacte con su servidor para actualizar.');
define('LANINS_020', 	'Continar Instalación');
define('LANINS_021', 	'2');
define('LANINS_022', 	'Detalles del servidor MySQL');
define('LANINS_022a',	'Base de Datos');
define('LANINS_023', 	'Por favor, introduzca aquí la configuración de MySQL.<br /><br />Si tiene permisos de administrador, podrá crear una nueva base de datos seleccionando la caja, si no, deberá crear una base de datos via MyAdmin o usar una ya existente.<br /><br />Si solo tiene una base de datos para utilizar, utilice el prefijo para que otros scripts puedan utilizar la misma base de datos.<br /><br />Si no tiene conocimento de los datos de su MySQL, contacte su servidor web.');
define('LANINS_024', 	'Servidor MySQL:');
define('LANINS_025', 	'Nombre de usuario MySQL:');
define('LANINS_026', 	'Contraseña MySQL:');
define('LANINS_027', 	'Base de datos MySQL:');
define('LANINS_028', 	'¿Crear base de datos?');
define('LANINS_029', 	'Prefijo de la tabla:');
define('LANINS_030', 	'El servidor MySQL que quiere utilizar para e107. Puede incluir el puerto utilizado. ej. \'servidor:puerto\' o una ruta local ej. \':/ruta/a/socket\' para localhost.');
define('LANINS_031', 	'El nombre de usuario que desea para conectar a su servidor MySQL (Modo Local: root).');
define('LANINS_032', 	'La contraseña del administrador (Modo Local: vacio).');
define('LANINS_033', 	'La base de datos MySQL que desea utilizar para e107. Si el usuario tiene permiso para crear bases de datos, tiene la opción de hacerlo si actualmente no existe.');
define('LANINS_034', 	'El prefijo que desea utilizar en e107 para encabezar las tablas. Útil para instalaciones múltiples de e107 en una misma base de datos.');
define('LANINS_035', 	'Continuar');
define('LANINS_036', 	'3');
define('LANINS_037', 	'Verificación de conexión MySQL');
define('LANINS_038', 	' y creación de la base de datos');
define('LANINS_038a', 	'Verificación de la base de datos');
define('LANINS_039', 	'Asegúrese que ha rellenado todos los campos más importantes, Servidor MySQL, Nombre de usuario MySQL y Base de datos MySQL.(Son necesarios para el servidor MySQL)');
define('LANINS_040', 	'Errores');
define('LANINS_041', 	'e107 no pudo establecer una conexión con el servidor MySQL usando la información que ha introducido.<br />Por favor, vuelva a ingresar los datos necesarios para una correcta instalación.');
define('LANINS_042', 	'Conexión con el servidor MySQL establecida y verificada.');
define('LANINS_043', 	'Imposible crear la base de datos, por favor, asegúrese que tiene permisos suficientes para crear bases de datos en su servidor.');
define('LANINS_044', 	'Base de datos creada con éxito.');
define('LANINS_045', 	'Por favor, pulse el botón <b>Continuar</b> para pasar a la siguiente etapa.');
define('LANINS_046', 	'5');
define('LANINS_047', 	'Detalles del Administrador');
define('LANINS_047a', 	'Administración');
define('LANINS_048', 	'Vuelva al útlimo paso');
define('LANINS_049', 	'Las dos contraseñas no coinciden. Por favor, vuelva e inténtelo de nuevo.');
define('LANINS_050', 	'Extensión XML');
define('LANINS_051', 	'Instalada');
define('LANINS_052', 	'No instalada');
define('LANINS_053', 	'e107 0.7.x requiere de las extensiones PHP XML para ser instalado. Por favor, contacte con su servidor o lea la información en <a href="http://php.net/manual/en/ref.xml.php" target="_blank">php.net</a> antes de continuar.');
define('LANINS_054', 	'La base de datos escojida fue verificada con éxito.');
define('LANINS_055', 	'Confirmación de instalación');
define('LANINS_055a', 	'Confirmar');
define('LANINS_056', 	'6');
define('LANINS_057', 	'e107 tiene toda la información para completar la instalación.<br /><br />Por favor, pulse en el botón <b>Continuar</b> para crear la base de datos y guardar sus configuraciones.');
define('LANINS_058', 	'7');
define('LANINS_060', 	'Imposible leer el archivo de datos sql.<br /><br /><br />Por favor, asegúrese que <b>core_sql.php</b> existe en el directorio <b>/e107_admin/sql</b>.');
define('LANINS_061', 	'e107 no pudo crear las tablas necesarias.<br /><br />Por favor, limpie la base de datos y rectifique cualquier problema antes de probar de nuevo.');
define('LANINS_062', 	'');

define('LANINS_063', 	'Bienvenido a e107.');
define('LANINS_069', 	'¡e107 fue instalado con éxito!<br /><br />Por razones de seguridad deberá cambiar los permisos en el archivo <b>e107_config.php</b> para 644.<br /><br />También deberá borrar el directorio <i>e107_install</i> de su servidor <i>e107</i><br /><br /> Ahora pulse el botón <b>Continuar</b>.');
define('LANINS_070', 	'e107 no pudo guardar la configuración principal en su servidor. Asegúrese que el archivo <b>e107_config.php</b> existe en el directório y que tiene los permisos de escritura correctos.');
define('LANINS_071', 	'Finalizando la instalación');
define('LANINS_071a', 	'Concluido');
define('LANINS_071b', 	'Error al finalizar la instalación');
define('LANINS_071c', 	'Concluida con errores');
define('LANINS_072', 	'Nombre Administrador');
define('LANINS_073', 	'Este es el nombre que usará para conectarse en si sitio web.');
define('LANINS_074', 	'Nombre Admin a mostrar');
define('LANINS_075', 	'Este es el nombre que se mostrará en su perfil y en todo el sitio. Si desea mostrar el mismo nombre que el nombre de usuario, déjelo en blanco.');
define('LANINS_076', 	'Contraseña Administrador');
define('LANINS_077', 	'Por favor, indique la contraseña que le asignará al administrador');
define('LANINS_078', 	'Confirmar contraseña');
define('LANINS_079', 	'Vuelva a escribir la contraseña para confirmarla');
define('LANINS_080', 	'Email Admin');
define('LANINS_081', 	'Escriba su dirección de email');
define('LANINS_082', 	'usuario@susitio.com');
define('LANINS_083', 	'Informe de error de MySQL');
define('LANINS_084', 	'El instalador no puede conectarse con la base de datos');
define('LANINS_085', 	'El instalador no puede seleccionar la base de datos:');
define('LANINS_086', 	'El nombre, Contraseña y Correo electrónico de Administrador son <b>campos obligatorios</b>. Por favor, vuelva a la página y asegúrese de escribir la información correctamente.');
define('LANINS_087', 	'Varios');
define('LANINS_088', 	'Inicio');
define('LANINS_089', 	'Descargas');
define('LANINS_090', 	'Miembros');
define('LANINS_091', 	'Enviar Noticias');
define('LANINS_092', 	'Contactar');
define('LANINS_093', 	'Dar permisos a menus privados');
define('LANINS_094', 	'Ejemplo de clase de foro privada');
define('LANINS_095', 	'Comprobación de integridad');
define('LANINS_096', 	'Últimos Comentarios'); 
define('LANINS_097', 	'[más...]'); 
define('LANINS_098', 	'Noticias'); 
define('LANINS_099', 	'e107 CMS'); 
define('LANINS_100', 	'Últimas Publicaciones Foro'); 
define('LANINS_101', 	'Actualizar opciones de menú'); 
define('LANINS_102', 	'Fecha/Hora'); 
define('LANINS_103', 	'e107 Plugins'); 
define('LANINS_104', 	'Comprobado'); 
define('LANINS_105', 	'El nombre o prefijo de base de datos con algunos caracteres “e” or “E” no es aceptable.<br />El nombre de base de datos o prefijo no puede estar vacío.'); 
define('LANINS_106', 	'ATENCION - e107 no puede escribir en los directorios y/o en los archivos que aparecen en la lista. Si bien esto no detendrá la instalación de e107, algunas funciones determinadas no estarán disponibles.<br /><br />Acceda al directorio principal via ftp y cambie los permisos de escritura en los archivo correspondientes.'); 
define('LANINS_107',	'El archivo e107_config.php no está vacío'); 
define('LANINS_108',	'Posiblemente, usted tiene una instalación ya existente');

define('LANINS_DB_UTF8_LABEL',	'Forzar UTF-8 en la base de datos');
define('LANINS_DB_UTF8_CAPTION','MySQL Charset:');
define('LANINS_DB_UTF8_TOOLTIP','Al seleccionar, el script de instalación hará que la base de datos sea compatible con cotejamiento UTF-8. Las próximas versiones de e107 requieren de UTF-8 en la base de datos.');

// v1.0 - . 

define('LANINS_109', 	'Comienzo');
define('LANINS_110', 	'Completada');
define('LANINS_111', 	'e107 Themes');
define('LANINS_112', 	'e107 Handbook');
define('LANINS_113', 	'');

define('LANINS_121', 	'e107_config.php ya existe!');
define('LANINS_122', 	'Posiblemente, usted tiene una instalación existente');
define('LANINS_123', 	'Información de depuración');
define('LANINS_124', 	'backtrace');
define('LANINS_125', 	'Paso no válido');
define('LANINS_125a', 	'Error');

define('LANINS_WELCOME','[b]¡Bienvenido a su nuevo sitio web![/b]

e107 se instaló correctamente, ya está preparado para aceptar contenidos. Su sección de administración está [link=e107_admin/admin.php]AQUÍ[/link], haga click para ir ahora. Necesitará conectarse con el nombre de usuario y contraseña utilizada en la instalación.

[b]Soporte[/b]
[link=http://e107.org/]e107 Homepage[/link] 
[link=http://e107.org/support]e107 Forums[/link] 
[link=http://wiki.e107.org/]e107 Handbook[/link] 

Muchas Gracias por instalar e107, esperamos que cubra las necesidades de su nuevo sitio web');

define('LANINS_NEWS', 	'[b]Bem-vindo![/b]
e107 es un sistema de gestión de contenidos escrito en PHP y que utiliza para su base de datos el software de código abierto MySQL para el almacenamiento de contenido.<br />e107CMS es totalmente gratuito, personalizable y en constante desarrollo.	 

[list][link=http://e107.org/content/Learn-all-about-e107]Todo lo que necesitas saber sobre el e107[/link]*[link=http://e107.org/content/About-Us:The-Team]Desarrolladores | Traductores | Equipo de Soporte[/link]*[link=http://wiki.e107.org/]Documentación Wiki[/link][/list]');
?>