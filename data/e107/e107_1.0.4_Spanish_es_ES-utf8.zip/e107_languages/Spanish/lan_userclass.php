<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UC_LAN_0", "Todos (público)");
define("UC_LAN_1", "Invitados");
define("UC_LAN_2", "Nadie (inactivo)");
define("UC_LAN_3", "Miembros");
define("UC_LAN_4", "Solo Lectura");
define("UC_LAN_5", "Administrador");
define("UC_LAN_6", "Admin Principal");
define("UC_LAN_9", "Nuevos Usuarios");
define("UC_LAN_10", "Motores de búsqueda");


?>