<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "El Sitio está cerrado temporalmente");
define("LAN_SITEDOWN_00", "<b>- Temporalmente cerrado -</b><br /><br />Hemos cerrado temporalmente nuestro portal para realizar un mantenimiento del mismo e implementar nuevas utilidades. Este proceso durará pocas horas - Le rogamos nos disculpe por los inconvenientes que este proceso le pueda causar..");
define("LAN_SITEDOWN_01", "Este sitio está cerrado temporalmente por mantenimiento. El sitio estará disponible lo antes posible, por favor disculpe las molestias.");
?>