<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Conexión de usuario");
define("NT_LAN_UV_1", "Verificación de la conexión de usuario");
define("NT_LAN_UV_2", "Usuario ID:");
define("NT_LAN_UV_3", "suario nombre conexión:");
define("NT_LAN_UV_4", "Usuario IP:");
define("NT_LAN_LI_1", "Usuario conectado");
define("NT_LAN_LO_1", "Usuario desconectado");
define("NT_LAN_LO_2", " desconectado del sitio");
define("NT_LAN_FL_1", "Expulsión flood");
define("NT_LAN_FL_2", "Expulsiones IP por flooding");
define("NT_LAN_SN_1", "Noticias enviadas");
define("NT_LAN_NU_1", "Actualizado");
define("NT_LAN_ND_1", "Eventos de archivo");
define("NT_LAN_ND_2", "Archivo transferido por el usuario");
define("NT_LAN_CM_1", "Aprobación Pendiente para Comentario de Usuario");


?>