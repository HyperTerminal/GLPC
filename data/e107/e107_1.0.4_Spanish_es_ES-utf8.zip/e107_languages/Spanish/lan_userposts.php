<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Envios de usuario");

define("UP_LAN_0", "Todos los mensajes en foros para ");
define("UP_LAN_1", "Todos los comentarios para ");
define("UP_LAN_2", "Tema");
define("UP_LAN_3", "Vistas");
define("UP_LAN_4", "Respuestas");
define("UP_LAN_5", "Último");
define("UP_LAN_6", "Temas");
define("UP_LAN_7", "Sin comentarios");
define("UP_LAN_8", "Sin mensajes");
define("UP_LAN_9", " el ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Enviado el: ");
define("UP_LAN_12", "Buscar");
define("UP_LAN_13", "Comentarios");
define("UP_LAN_14", "Envíos de foros");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "Dirección IP");
?>