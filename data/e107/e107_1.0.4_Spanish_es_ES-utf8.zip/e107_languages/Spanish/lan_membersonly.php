<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Solo miembros");

define("LAN_MEMBERS_0", "Área restringida");
define("LAN_MEMBERS_1", "Esta es un área restringida");
define("LAN_MEMBERS_2","Para acceder, por favor <a href='".e_LOGIN."'>conéctese</a>");
define("LAN_MEMBERS_3","o <a href='".e_SIGNUP."'>regístrese</a> como miembro");
define("LAN_MEMBERS_4","Volver a la página de inicio");

?>