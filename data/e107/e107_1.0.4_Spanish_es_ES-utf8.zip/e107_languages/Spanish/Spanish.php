<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
setlocale(LC_ALL, 'es.UTF-8', 'es.utf8', 'es');
define("CORE_LC", "es");
define("CORE_LC2", "es");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Error: el tema no ha sido encontrado.\\n\\nCambie el tema utilizado en preferencias (área de administración) o copie los archivos del tema en falta en el servidor.");
define("CORE_LAN4", "Por favor, acceda al directorio principal de su sitio y elimine el archivo install.php de su servidor.");
define("CORE_LAN5", "Si no lo hace, pone en peligro su sitio web");
define("CORE_LAN6", "La protección por excesos (flood) ha sido activada en este sitio. Se le advierte que podrá ser expulsado si continúa a solicitar la página.");
define("CORE_LAN7", "El núcleo está intentando recuperar los ajustes del backup automático.");
define("CORE_LAN8", "Ajustes del núcleo en error");
define("CORE_LAN9", "El núcleo no puede recuperar del backup automático. Ejecución fallida.");
define("CORE_LAN10", "Detectada cookie corrupta - desconectando.");
define("CORE_LAN11", "Tiempo de renderizado:");
define("CORE_LAN12", "seg,");
define("CORE_LAN13", "de éstos para llamadas sql.");
define("CORE_LAN14", "");
define("CORE_LAN15", "Consultas BD:");
define("CORE_LAN16", "Uso de memoria:");
define("CORE_LAN17", "[imagen desactivada]");
define("CORE_LAN18", "Imagen:");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "KB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "¡Atención!");
define("LAN_ERROR", "Error");
define("LAN_ANONYMOUS", "Anónimo");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_SANITISED", "SANITISED");


?>