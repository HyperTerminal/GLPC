<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Contacto");

define("LANCONTACT_01", "Detalles del contacto");
define("LANCONTACT_02", "Formulario del contacto");
define("LANCONTACT_03", "Escriba su nombre:");
define("LANCONTACT_04", "Direccion correo:");
define("LANCONTACT_05", "Asunto del mensaje:");
define("LANCONTACT_06", "Escriba el mensaje:");
define("LANCONTACT_07", "Enviar una copia del correo a su dirección ");
define("LANCONTACT_08", "Enviar");
define("LANCONTACT_09", "Su mensaje fué enviado.");
define("LANCONTACT_10", "Hubo un problema al enviar su mensaje.");
define("LANCONTACT_11", "Su dirección de correo no parece válida.\\nPor favor, compruébela de nuevo.");
define("LANCONTACT_12", "Su mensaje es demasiado corto.");
define("LANCONTACT_13", "Por favor, incluya un asunto.");

define("LANCONTACT_14", "Enviar mensaje a:");
define("LANCONTACT_15", "Código incorrecto"); 
define("LANCONTACT_16", "Escriba código");
?>