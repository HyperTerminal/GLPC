<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Registro de nuevo miembro");
define("LAN_7", "Nombre a exhibir:");
define("LAN_8", "Este es el nombre que se mostrará en el sitio");
define("LAN_9", "Nombre usuario:");
define("LAN_10", "Nombre para iniciar sesión");
define("LAN_17", "Contraseña:");
define("LAN_103", "Este nombre de usuario no puede ser aceptado como válido, por favor elija otro nombre de usuario");
define("LAN_104", "Este nombre de conexión ya existe en nuestra base de datos, por favor elija otro nombre de usuario");
define("LAN_105", "Las dos contraseñas no coinciden");
define("LAN_106", "Esta dirección de email no parece ser válida");
define("LAN_107", "¡Muchas Gracias! Ahora usted ya es un miembro registrado de ".SITENAME.", por favor guarde su nombre de usuario y contraseña en un lugar seguro.<br /><br />Ahora ya puede iniciar sesión en el portal.");
define("LAN_108", "Su registro está completado");
define("LAN_109", "# Información...<br /># Este sitio contiene material no apto para menores de edad.<br /># Para más información sobre la ley de protección del menor <a href=\"http://e107.org/portal/content.php?article.31\">pulse aquí</a>.<br /># Por favor contactese con el administrador del sitio <a href=\"mailto:".SITEADMINEMAIL."\">pulsando aquí</a> si necesita asistencia.<br /><br /><div style=\"text-align:center\"><b>Por favor regístrese solo si es mayor de edad.");
define("LAN_110", "Registrarse");
define("LAN_111", "Reescribir Contraseña:");
define("LAN_112", "Dirección Email:");
define("LAN_113", "¿Ocultar Email?:");
define("LAN_114", "Esto previene que su dirección de email sea exhibida en el portal");
define("LAN_123", "Registro");
define("LAN_185", "Ha dejado campos obligatorios en blanco");
define("LAN_201", "Si");
define("LAN_200", "No");
define("LAN_202", "Ya dispone de una cuenta. Si se olvidó de la contraseña, haga click en el enlace '¿Contraseña olvidada?'.");
define("LAN_309", "#Por favor rellene los campos que se solicitan a continuación.<br /># <b>Recibirá un email de verificación, asegúrese de escribir una dirección de email válida.</b>");
define("LAN_399", "Continuar");
define("LAN_400", "Los nombres de usuario y contraseñas son <b>sensibles entre mayúsculas y minúsculas</b>.");
define("LAN_401", "Su cuenta ha sido activada, por favor, inicie su 1ª sesión en el portal.");
define("LAN_402", "Su registro fue activado");
define("LAN_403", "Bienvenid@ a");
define("LAN_404", "Detalles del registro para");
define("LAN_405", "Esta etapa de registro se ha completado. Usted recibirá un email con sus datos de acceso. Por favor siga el enlace del mensaje para completar el proceso de registro y activar su cuenta.");
define("LAN_406", "¡Muchas Gracias!");
define("LAN_407", "Por favor guarde este email y coloque nuestra dirección de email en su agenda de contactos seguros, sus datos están encriptados y en caso de perdida de la contraseña no podría ser recuperada. Si esto sucediera, usted debería solicitar una nueva contraseña.\n\nGracias por su registro.\n\nDe");
define("LAN_408", "Ya existe un usuario con esta dirección email. por favor utilice la opción '¿Contraseña Olvidada?' en el menú, para recuperar su contraseña.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "carac.");
define("LAN_SIGNUP_3", "Código de verificación incorrecto.");
define("LAN_SIGNUP_4", "Su contraseña debe tener más de");
define("LAN_SIGNUP_5", " Capacidad de caracteres.");
define("LAN_SIGNUP_6", "Su");
define("LAN_SIGNUP_7", " es requerido");
define("LAN_SIGNUP_8", "¡Gracias!");
define("LAN_SIGNUP_9", "No se pudo realizar el proceso.");
define("LAN_SIGNUP_10", "Si");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Caracteres no válidos en el nombre de usuario");
define("LAN_410", "Digitar el código");
define("LAN_411", "Ese nombre a mostrar ya existe en la base de datos, por favor, elija otro nombre a mostrar");
define("LAN_SIGNUP_12", "Guarde su nombre de usuario en un lugar seguro, si lo pierde no se podrá volver a recuperar.");
define("LAN_SIGNUP_13", "Ahora ya puede conectarse desde el menú de iniciar sesión en nuestro portal, o desde <a href='".e_BASE."login.php'>aquí</a>.");
define("LAN_SIGNUP_14", "aquí");
define("LAN_SIGNUP_15", "Por favor, contactarse con el administrador del sitio");
define("LAN_SIGNUP_16", "si necesita de asistencia.");
define("LAN_SIGNUP_17", "Por favor certifique que es usted es mayor de 13 años.");
define("LAN_SIGNUP_18", "Su registro ha sido recibido y creado con los siguientes datos:");
define("LAN_SIGNUP_21", "Su cuenta de usuario está inactiva, para activarla pulse sobre el siguiente enlace:");
define("LAN_SIGNUP_22", "pulse aquí");
define("LAN_SIGNUP_23", "para iniciar sesión.");
define("LAN_SIGNUP_24", "Gracias por registrarse en");
define("LAN_SIGNUP_25", "Envíe su avatar");
define("LAN_SIGNUP_26", "Envíe su fotografía");
define("LAN_SIGNUP_27", "Exhibir");
define("LAN_SIGNUP_28", "Seleccione el contenidos de las listas de correo");
define("LAN_SIGNUP_29", "Se le enviará un correo de verificación a la dirección de email facilitada, por lo que deberá ser una dirección de e-mail válida.");
define("LAN_SIGNUP_30", "Si no desea mostrar su dirección email en este sitio, seleccione 'ocultar dirección de email'.");
define("LAN_SIGNUP_31", "URL de su archivo XUP");
define("LAN_SIGNUP_32", "¿Qué es un archivo XUP?");
define("LAN_SIGNUP_33", "Seleccione un avatar o escriba la ruta de acceso");
define("LAN_SIGNUP_34", "Tenga en cuenta: Cualquier imagen transferida a este servidor y que sea considerada inapropiada por los administradores será eliminada inmediatamente.");
define("LAN_SIGNUP_35", "Click aquí para registrarse usando un archivo XUP");
define("LAN_SIGNUP_36", "Ocurrió un error al crear la información de usuario, Por favor, contacte con el Administrador");
define("LAN_LOGINNAME", "Nombre de conexión");
define("LAN_PASSWORD", "Contraseña");
define("LAN_USERNAME", "Nombre a ver");
define("LAN_EMAIL_01", "Sr(a).");
define("LAN_EMAIL_04", "Por favor, guarde y/o imprima este email para su propia información.");
define("LAN_EMAIL_05", "Su contraseña ha sido encriptada y no podrá ser recuperada si la pierde u olvida. Sin embargo, puede solicitar una nueva contraseña si esto ocurriese.<br />Ingrese nuestra dirección de e-mail en su lista de contactos para futuras informaciones.");
define("LAN_EMAIL_06", "Gracias por su registro.");
define("LAN_SIGNUP_37", "Esta parte del registro está completa. El administrador necesitará aprobar su registro.  Una vez completado, recibirá un correo informándole que su registro ha sido aprobado.");
define("LAN_SIGNUP_38", "Ha escrito dos correos diferentes. Por favor, escriba la misma dirección de correo electrónico en ambos campos");
define("LAN_SIGNUP_39", "Reescriba el email:");
define("LAN_SIGNUP_40", "Activación no necesaria");
define("LAN_SIGNUP_41", "Su cuenta acaba de activarse.");
define("LAN_SIGNUP_42", "Hubo un problema, el email de registro no fue enviado, por favor, contacte con el administrador.");
define("LAN_SIGNUP_43", "Email enviado");
define("LAN_SIGNUP_44", "Activación de email enviado a:");
define("LAN_SIGNUP_45", "Por favor, comprueba su carpeta de entrada.");
define("LAN_SIGNUP_47", "Re-enviar activación de email");
define("LAN_SIGNUP_48", "Nombre de usuario o email");
define("LAN_SIGNUP_49", "Si se registró con un email equivocado, escriba uno nuevo y su contraseña aquí:");
define("LAN_SIGNUP_50", "Nuevo email");
define("LAN_SIGNUP_51", "Contraseña antigua");
define("LAN_SIGNUP_52", "Contraseña incorrecta");
define("LAN_SIGNUP_53", "falló la prueba de validación");
define("LAN_SIGNUP_54", "Haga click aquí para rellenar los detalles de su registro");
define("LAN_SIGNUP_55", "El nombre a mostrar es demasiado largo. Por favor, escoja otro");
define("LAN_SIGNUP_56", "El nombre a mostrar es demasiado corto. Por favor, escoja otro");
define("LAN_SIGNUP_57", "Ese nombre de conexión es demasiado largo. Por favor, escoja otro");
define("LAN_SIGNUP_58", "Pre-visualizar registro");
define("LAN_SIGNUP_59", "**** Si el enlace no funciona, por favor, compruebe cual es la parte que ha sido enviada a la siguiente línea. ****");
define("LAN_SIGNUP_60", "Error en el acceso externo del avatar");
define("LAN_SIGNUP_72", "¡Gracias por registrarse en [sitename]! Sólo le hemos envió un mensaje de confirmación de [email].<br />Por favor, haga clic en el enlace para confirmación su cuenta de correo electrónico, completar su registro y activar su cuenta en [sitename].");
define("LAN_SIGNUP_98", "Confirme su email");
define("LAN_SIGNUP_99", "Problema detectado");
define("LAN_SIGNUP_100", "A la espera de la aprobación del administrador");
define("LAN_SIGNUP_102", "Registro Denegado");
define("LAN_SIGNUP_103", "Demasiados usuarios que están utilizando esta dirección IP:");
define("LAN_SIGNUP_104", "Nombre del avatar no válido");
define("LAN_SIGNUP_105", "No fue posible ejecutar su solicitud - por favor póngase en contacto con el administrador del sitio");
define("LAN_SIGNUP_106", "No fue posible ejecutar su solicitud - ¿Ya tiene una cuenta aquí?");


?>