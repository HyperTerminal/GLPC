<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("TOP_LAN_0", "Top foros");
define("TOP_LAN_1", "Usuario");
define("TOP_LAN_2", "Mensajes");
define("TOP_LAN_3", "Top comentarios");
define("TOP_LAN_4", "Comentarios");
define("TOP_LAN_5", "Top chatbox");
define("TOP_LAN_6", "Puntuación del sitio");

//v.616
define("LAN_1", "Tema");
define("LAN_2", "Autor");
define("LAN_3", "Vistas");
define("LAN_4", "Respuestas");
define("LAN_5", "Último");
define("LAN_6", "Temas");
define("LAN_7", "Temas más activos");
define("LAN_8", "Top Autores");
?>