<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Perfil de Usuario");
define("LAN_7", "Nombre a ver:");
define("LAN_8", "El nombre que se mostrará en el sitio");
define("LAN_9", "Nombre de usuario:");
define("LAN_10", "El nombre para conectarse al sitio");
define("LAN_11", "El nombre que usará para conectarse a este sitio - no podrá cambiarse. Por favor, contacte con el administrador si necesita cambiarlo por razones de seguridad");
define("LAN_20", "Error");
define("LAN_105", "Las dos contraseñas ingresadas no coinciden");
define("LAN_106", "Esta no parece ser una dirección de email válida");
define("LAN_112", "Dirección de email:");
define("LAN_113", "¿Ocultar dirección email?:");
define("LAN_114", "Esto previene que su dirección de email sea exibida en el portal");
define("LAN_120", "Firma:");
define("LAN_121", "Avatar:");
define("LAN_122", "Zona Horaria:");
define("LAN_150", "Perfil actualizado y guardado en la base de datos.");
define("LAN_151", "OK");
define("LAN_152", "Nueva contraseña:");
define("LAN_153", "Reescriba Nueva contraseña:");
define("LAN_154", "Actualizar perfil");
define("LAN_155", "Actualizar datos de usuario");
define("LAN_185", "Ha dejado el campo de contraseña en blanco");
define("LAN_308", "Nombre real:");
define("LAN_401", "Deje en blanco para continuar con la misma contraseña");
define("LAN_402", "Escriba la ruta o elija un avatar");
define("LAN_403", "Elegir avatar");
define("LAN_404", "Tenga en cuenta que: Las imágenes subidas a nuestro servidor y que sean consideradas por los administradores no apropiadas serán borradas inmediatamente.");
define("LAN_410", "Configuración para");
define("LAN_411", "Actualize su configuración");
define("LAN_412", "Cambie su contraseña");
define("LAN_413", "Elija un Avatar");
define("LAN_414", "Suba su fotografía");
define("LAN_415", "Suba su avatar");
define("LAN_416", "Si");
define("LAN_417", "No");
define("LAN_418", "Información de registro");
define("LAN_419", "Información Personal/Contacto");
define("LAN_420", "Avatar");
define("LAN_421", "Elegir avatar");
define("LAN_422", "Usar avatar remoto");
define("LAN_423", "Por favor escriba la dirección completa a la imagen");
define("LAN_424", "Pulse el botón para ver los avatarares disponibles en este sitio");
define("LAN_425", "Fotografía");
define("LAN_426", "Será mostrada en su página de perfil");
define("LAN_433", "URL de su archivo XUP");
define("LAN_434", "¿Qué es esto?");
define("LAN_435", "Archivo de Protocolo de usuario XML");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "carac.");
define("LAN_SIGNUP_4", "Su contraseña debe tener");
define("LAN_SIGNUP_5", " caracteres de largo.");
define("LAN_SIGNUP_6", "Su");
define("LAN_SIGNUP_7", " es requerido");
define("LAN_USET_1", "Su avatar es demasiado ancho");
define("LAN_USET_2", "El ancho máximo permitido es");
define("LAN_USET_3", "Su avatar es demasiado alto");
define("LAN_USET_4", "El alto máximo permitido es");
define("LAN_CUSTOMTITLE", "Título");
define("LAN_408", "Existe un usuario con esta dirección de email.");
define("MAX_AVWIDTH", "El tamaño máximo del avatar es (ancho x alto)");
define("MAX_AVHEIGHT", " x");
define("RESIZE_NOT_SUPPORTED", "Este servidor no soporta el cambio de tamaño automático de imágenes. Fichero borrado.");
define("LAN_USET_5", "Suscrito a");
define("LAN_USET_6", "Suscrito a la lista de correo o a las secciones de la página.");
define("LAN_USET_7", "Adicionales");
define("LAN_USET_8", "Firma /Zona horaria");
define("LAN_USET_9", "Algunos de los campos requeridos (marcados con un  *) están en blanco en sus ajustes.");
define("LAN_USET_10", "Por favor, actualice sus ajustes ahora para poder proceder.");
define("LAN_USET_11", "No se puede aceptar este usuario como válido, por favor escoja otro usuario");
define("LAN_USET_12", "El nombre a mostrar es demasiado corto. Por favor, escoja otro");
define("LAN_USET_13", "Carácteres inválidos en el nombre de usuario. Por favor, escoja otro");
define("LAN_USET_14", "Nombre de conexion demasiado largo. Por favor, escoja otro");
define("LAN_USET_15", "Nombre a mostrar demasiado largo. Por favor, escoja otro");
define("LAN_USET_16", "Marcar para borrar la foto existente sin transferir ninguna otra");
define("LAN_USET_17", "El nombre a mostrar ya se está utilizando. Por favor, escoja otro");
define("LAN_USET_18", "Nombre no válido para el avatar");
define("LAN_USET_19", "Avatar no se puede subir");
define("LAN_USET_20", "No se puede obtener información de la imagen");


?>