<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LANDT_01", "Año");
define("LANDT_02", "Mes");
define("LANDT_03", "Semana");
define("LANDT_04", "Día");
define("LANDT_05", "Hora");
define("LANDT_06", "Minuto");
define("LANDT_07", "Segundo");
define("LANDT_01s", "Años");
define("LANDT_02s", "Meses");
define("LANDT_03s", "Semanas");
define("LANDT_04s", "Días");
define("LANDT_05s", "Horas");
define("LANDT_06s", "Minutos");
define("LANDT_07s", "Segundos");

define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "seg");
define("LANDT_09s", "segs");
define("LANDT_AGO", "hace");
?>