<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_PREF_1", "Sitio e107");
define("LAN_PREF_2", "Portal de Gestión e107");
define("LAN_PREF_3", "Este portal está soportado por el sistema <a href=\"http://e107.org/\" rel=\"external\">e107CMS</a> y ha sido distribuido bajo <a href=\"http://www.gnu.org/\" rel=\"external\">Licencia GNU GPL</a>.");
define("LAN_PREF_4", "censurado");
define("LAN_PREF_5", "Foros");


?>