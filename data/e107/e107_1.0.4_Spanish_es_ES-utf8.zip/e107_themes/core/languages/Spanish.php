<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('LAN_THEME_1', 		'Tema e107 core de<a href="http://e107.org" title="e107 CMS" rel="external"> e107 Inc.</a>');
define('LAN_THEME_2', 		'Comentarios:');
define('LAN_THEME_3', 		'Comentarios desactivados');
define('LAN_THEME_4', 		'Leer todo...');
define('LAN_THEME_5', 		'Trackbacks:');
define('LAN_THEME_8', 		'en');
define('LAN_THEME_9', 		'por');
define("LAN_THEME_11", 		"Últimas noticias");
define("LAN_THEME_12", 		"E-mail para un amigo");
define("LAN_THEME_13", 		"Crear un archivo PDF");
define("LAN_THEME_14", 		"Imprimir");
define("LAN_THEME_15", 		"Editar");
define('LAN_THEME_17', 		'Entrar');
define('LAN_THEME_18', 		'Usuario');
define('LAN_THEME_19', 		'Contraseña');
define('LAN_THEME_20', 		'Registro');
define('LAN_THEME_21', 		'Entrar');
define('LAN_THEME_22', 		'¿Olvidaste tu contraseña?');
define('LAN_THEME_23', 		'Bienvenido');
define('LAN_THEME_24', 		'Administrador');
define('LAN_THEME_26', 		'Configuración');
define('LAN_THEME_27', 		'Perfil');
define('LAN_THEME_28', 		'Salir');
define('LAN_THEME_29', 		'Lista nueva');
define('LAN_THEME_SING', 	'Entrar');
define('LAN_THEME_REG', 	'Registro');
define("LAN_SEARCH", 		"Buscar");
define("LAN_SEARCH_SUB", 	"Ir");
define('LAN_THEME_SHARE', 	'Compartir esta');
define('LAN_THEME_VER', 	'e107 v.');
define("CM_L13", 			"por");
?>