<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' por <a href='http://e107.org' rel='external'>jalist</a>, Basado en el original theme de Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>).");
define("LAN_THEME_2", "Comentarios desactivados ");
define("LAN_THEME_3", "Comentario(s):");
define("LAN_THEME_4", "Leer todo...");
define("LAN_THEME_5", "Trackbacks: ");
define("LAN_THEME_6", "en: ");
define("LAN_THEME_7", "por: ");

?>