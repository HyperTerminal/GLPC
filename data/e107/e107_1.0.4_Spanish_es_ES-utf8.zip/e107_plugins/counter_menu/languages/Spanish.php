<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("COUNTER_L1", "Las visitas del Admin no se contabilizan.");
define("COUNTER_L2", "Esta página hoy ...");
define("COUNTER_L3", "Total");
define("COUNTER_L4", "Esta página siempre ...");
define("COUNTER_L5", "única");
define("COUNTER_L6", "Sitio ...");
define("COUNTER_L7", "Contador");
define("COUNTER_L8", "Mensaje del Admin: <b>El registro de estadísticas está desactivado.</b><br />Para activarlo, necesita instalar el plugin de registro de estadísticas desde el <a href='".e_ADMIN."plugin.php'>gestor de plugins</a>, y luego activarlo desde la <a href='".e_PLUGIN."log/admin_config.php'>pantalla de configuración</a>.");
?>