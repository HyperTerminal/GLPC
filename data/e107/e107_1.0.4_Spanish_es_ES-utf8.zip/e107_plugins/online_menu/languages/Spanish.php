<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ONLINE_L1", "Invitados: ");
define("ONLINE_L2", "Miembros: ");
define("ONLINE_L3", "En esta página: ");
define("ONLINE_L4", "En linea");
define("ONLINE_L5", "Miembros");
define("ONLINE_L6", "Último");

define("TRACKING_MESSAGE", "El tracking de usuario online está actualmente desactivado, por favor actívelo [link=".e_ADMIN."users.php?options]aquí[/link][br]");
?>