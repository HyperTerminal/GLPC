<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'no');
define('EC_LAN_RECUR_01', 'anual');
define('EC_LAN_RECUR_02', 'bianual');
define('EC_LAN_RECUR_03', 'trimestral');
define('EC_LAN_RECUR_04', 'mensual');
define('EC_LAN_RECUR_05', 'cuatro semanas');
define('EC_LAN_RECUR_06', 'quincenal');
define('EC_LAN_RECUR_07', 'semanal');
define('EC_LAN_RECUR_08', 'todos los días');
define('EC_LAN_RECUR_100', 'Domingo del mes');
define('EC_LAN_RECUR_101', 'Lunes del mes');
define('EC_LAN_RECUR_102', 'Martes del mes');
define('EC_LAN_RECUR_103', 'Miércoles del mes');
define('EC_LAN_RECUR_104', 'Jueves del mes');
define('EC_LAN_RECUR_105', 'Viernes del mes');
define('EC_LAN_RECUR_106', 'Sábado del mes');

define('EC_LAN_RECUR_1100', 'Primero');
define('EC_LAN_RECUR_1200', 'Segundo');
define('EC_LAN_RECUR_1300', 'Tercero');
define('EC_LAN_RECUR_1400', 'Cuarto');


// Notify
define('NT_LAN_EC_1', 'Evento del calendario de eventos');
define('NT_LAN_EC_2', 'Evento actualizado');
define('NT_LAN_EC_3', 'Actualizado por');
define('NT_LAN_EC_4', 'Dirección IP');
define('NT_LAN_EC_5', 'Mensaje');
define('NT_LAN_EC_6', 'Calendario de eventos - Evento añadido');
define('NT_LAN_EC_7', 'Nuevo evento publicado');
define('NT_LAN_EC_8', 'Calendario de eventos - Evento modificado');


// Log messages
define('EC_ADM_01', 'Calendario de Eventos - añadir evento');
define('EC_ADM_02', 'Calendario de Eventos - editar evento');
define('EC_ADM_03', 'Calendario de Eventos - apagar evento');
define('EC_ADM_04', 'Calendario de Eventos - apagar vários');
define('EC_ADM_05', 'Calendario de Eventos - Añadir varios');
define('EC_ADM_06', 'Calendario de Eventos - Opciones principales actualizadas');
define('EC_ADM_07', 'Calendario de Eventos - FE opciones alteradas');
define('EC_ADM_08', 'Calendario de Eventos - Categoría añadida');
define('EC_ADM_09', 'Calendario de Eventos - Categoría editada');
define('EC_ADM_10', 'Calendario de Eventos - Categoría eliminada');
define('EC_ADM_11', 'Calendario de Eventos - Eventos antiguos eliminados');


?>