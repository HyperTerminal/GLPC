<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("TREE_L1", "Configurar árbol de menú");
define("TREE_L2", "Actualizar opciones del árbol de menú");
define("TREE_L3", "Configuración guardada.");
define("TREE_L4", "On");
define("TREE_L5", "Off");
define("TREE_L6", "Clase CSS para usar en enlaces sin poder abrir");
define("TREE_L7", "Clase CSS para usar en enlaces normales");
define("TREE_L8", "Clase CSS para usar en enlaces abiertos");
define("TREE_L9", "Use la clase spacer entre los enlaces principales");

?>