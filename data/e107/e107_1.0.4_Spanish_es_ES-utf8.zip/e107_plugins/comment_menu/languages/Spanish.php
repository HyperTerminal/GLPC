<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CM_L1", "Aún no hay comentarios.");
define("CM_L3", "Título");
define("CM_L4", "¿Número de comentarios a mostrar?");
define("CM_L5", "¿Número de caracteres a mostrar?");
define("CM_L6", "¿Cortar comentarios demasiado largos?");
define("CM_L7", "¿Mostrar título original?");
define("CM_L8", "Configuración");
define("CM_L9", "Actualizar configuración");
define("CM_L10", "La configuración ha sido guardada");
define("CM_L11", "el");
define("CM_L12", "Re:");
define("CM_L13", "Enviado por");


?>