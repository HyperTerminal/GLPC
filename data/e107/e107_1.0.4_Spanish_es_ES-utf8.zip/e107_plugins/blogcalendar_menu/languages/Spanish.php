<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("BLOGCAL_L1", "Noticias para ");
define("BLOGCAL_L2", "Archivo");

define("BLOGCAL_D1", "Lu");
define("BLOGCAL_D2", "Ma");
define("BLOGCAL_D3", "Mi");
define("BLOGCAL_D4", "Ju");
define("BLOGCAL_D5", "Vi");
define("BLOGCAL_D6", "Sa");
define("BLOGCAL_D7", "Do");

define("BLOGCAL_M1", "Enero");
define("BLOGCAL_M2", "Febrero");
define("BLOGCAL_M3", "Marzo");
define("BLOGCAL_M4", "Abril");
define("BLOGCAL_M5", "Mayo");
define("BLOGCAL_M6", "Junio");
define("BLOGCAL_M7", "Julio");
define("BLOGCAL_M8", "Agosto");
define("BLOGCAL_M9", "Septiembre");
define("BLOGCAL_M10", "Octubre");
define("BLOGCAL_M11", "Noviembre");
define("BLOGCAL_M12", "Diciembre");

define("BLOGCAL_1", "Noticias");

define("BLOGCAL_CONF1", "Meses/fila");
define("BLOGCAL_CONF2", "Espacio entre borde y texto");
define("BLOGCAL_CONF3", "Actualizar parámetros de menú");
define("BLOGCAL_CONF4", "BlogCal Configuración del menú");
define("BLOGCAL_CONF5", "BlogCal configuración del menú guardada");

define("BLOGCAL_ARCHIV1", "Seleccione archivo");

?>