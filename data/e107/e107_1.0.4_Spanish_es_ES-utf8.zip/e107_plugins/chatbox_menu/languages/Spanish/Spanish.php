<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CHATBOX_L1", "No se pudo aceptar el mensaje con ese nombre de usuario porque ya está registrado - Si es su nombre de usuario, por favor inicie sesión antes de continuar.");
define("CHATBOX_L2", "Chatbox");
define("CHATBOX_L3", "Usted debe de iniciar sesión como miembro, antes de enviar mensajes en nuestro sitio web.<BR />Si usted no es un usuario registrado,<BR />Por favor pulse <a href='".e_BASE."signup.php'>AQUÍ</a> para registrarse");
define("CHATBOX_L4", "Enviar");
define("CHATBOX_L5", "Resetear");
define("CHATBOX_L6", "[Bloqueado por admin]");
define("CHATBOX_L7", "Desbloquear");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Bloquear");
define("CHATBOX_L10", "Borrar");
define("CHATBOX_L11", "No hay mensajes aún.");
define("CHATBOX_L12", "Ver todos los mensajes");
define("CHATBOX_L13", "Moderar Chatbox");
define("CHATBOX_L14", "Emoticones");
define("CHATBOX_L15", "Mensaje demasiado largo, o enviaste un mensaje vacío");
define("CHATBOX_L16", "Anónimo");
define("CHATBOX_L17", "Mensaje duplicado");
define("CHATBOX_L18", "Mensajes de ChatBox moderados");
define("CHATBOX_L19", "Solo puedes enviar un mensaje cada ".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." segundos");

define("CHATBOX_L20", "Chatbox (todos los envíos)");
define("CHATBOX_L21", "Envíos Chat");
define("CHATBOX_L22", "el");
define("CHATBOX_L23", "¡Error!");
define("CHATBOX_L24", "No tiene autorización para ver esta página.");
define("CHATBOX_L25", "[ este envío ha sido bloqueado por el Admin ]");
define("CHATBOX_L26", "Editar");

// Notify
define("NT_LAN_CB_1", "Eventos Chatbox");
define("NT_LAN_CB_2", "Mensaje Publicado");
define("NT_LAN_CB_3", "Enviado por");
define("NT_LAN_CB_4", "Dirección IP");
define("NT_LAN_CB_5", "Mensaje");
define("NT_LAN_CB_6", "Mensaje Chatbox Publicado");

?>