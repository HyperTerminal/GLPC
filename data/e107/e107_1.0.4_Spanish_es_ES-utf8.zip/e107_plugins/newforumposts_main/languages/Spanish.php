<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NFPM_LAN_1", "Tema");
define("NFPM_LAN_2", "Usuario");
define("NFPM_LAN_3", "Vistas");
define("NFPM_LAN_4", "Respuestas");
define("NFPM_LAN_5", "Último");
define("NFPM_LAN_6", "Temas");
define("NFPM_LAN_7", "por");

define("NFPM_L1", "Este plugin muestra una lista de nuevos mensajes en los foros en la página principal");
define("NFPM_L2", "Últimos mensajes en los foros");
define("NFPM_L3", "Para configurar, haga click en el enlace de la sección de plugins en la administración");
define("NFPM_L4", "¿Activar en el área?");
define("NFPM_L5", "Inactivo");
define("NFPM_L6", "Superior");
define("NFPM_L7", "Inferior");
define("NFPM_L8", "Título");
define("NFPM_L9", "Número de mensajes nuevos a mostrar");
define("NFPM_L10", "¿Mostrar en una caja con scroll?");
define("NFPM_L11", "Alto");
define("NFPM_L12", "Configuración");
define("NFPM_L13", "Actualizar configuración");
define("NFPM_L14", "Configuración actualizada.");
define("NFPM_L15", "Marque para ver los últimos mensajes en los foros.<br />Por defecto son los últimos temas.");
define('NFPM_L16', '[Usuario eliminado]');
define('NFPM_L17', 'Nuevas publicaciones en tema popular');
define('NFPM_L18', 'Nuevas publicaciones');
define('NFPM_L19', 'No hay Nuevas publicaciones en tema popular');
define('NFPM_L20', 'No hay Nuevas publicaciones');
define('NFPM_L21', 'Tema en destaque');
define('NFPM_L22', 'Tema en destaque cerrado');
define('NFPM_L23', 'Anuncio');
define('NFPM_L24', 'Tema Cerrado');

?>