<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('OTHERDB_LAN_1', 'Tipo de base de datos:');
define('OTHERDB_LAN_2', 'Servidor:');
define('OTHERDB_LAN_3', 'Usuario:');
define('OTHERDB_LAN_4', 'Contraseña:');
define('OTHERDB_LAN_5', 'Base de datos');
define('OTHERDB_LAN_6', 'Tabla');
define('OTHERDB_LAN_7', 'Campo de usuario');
define('OTHERDB_LAN_8', 'Campo de contraseña:');
define('OTHERDB_LAN_9', 'Método de contraseña:');
define('OTHERDB_LAN_10', 'Configurar otra bd autentica');
define('OTHERDB_LAN_11', '** Los siguientes campos no son obligatorios si usa la base de datos de e107');