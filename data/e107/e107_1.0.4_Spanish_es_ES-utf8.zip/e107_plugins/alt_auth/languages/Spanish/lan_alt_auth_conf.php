<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define('LAN_ALT_2', 'Actualizar configuración');
define('LAN_ALT_3', 'Elija otro tipo de autorización');
define('LAN_ALT_4', 'Configurar parámetros para');
define('LAN_ALT_5', 'Configurar parámetros de autorización');
define('LAN_ALT_6', 'Error en la acción de conexión');
define('LAN_ALT_7', 'Si falla el método de conexión alternativo, ¿Como será dirigido?');
define('LAN_ALT_8', 'El usuario no encontró la acción');
define('LAN_ALT_9', 'Si el nombre de usuario no se encuentra usando el método alternativo, ¿Como será dirigido?');
define('LAN_ALT_10', 'Error de inicio de sesión');
define('LAN_ALT_11', 'Utilice la tabla de usuario de e107');

define('LAN_ALT_PAGE', 'Inicio de sesión alternativa');