<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('LDAPLAN_1', 'Dirección del servidor');
define('LDAPLAN_2', 'Base DN o Dominio<br />If LDAP - Escriba BaseDN<br />If AD - Escriba Dominio');
define('LDAPLAN_3', 'LDAP mostrar usuarios<br />Contenido de texto del usuario que será capaz de buscar en el directorio.');
define('LDAPLAN_4', 'LDAP mostrar contraseña<br />Contraseña para el usuario LDAP.');
define('LDAPLAN_5', 'Versión LDAP');
define('LDAPLAN_6', 'Configurar LDAP aut.');
define('LDAPLAN_7', 'Filtro de búsqueda de sDirectory:'); 
define('LDAPLAN_8', 'Se utilizará para asegurar que el usuario esta en el árbol correcto, <br />ie '(objectclass=inetOrgPerson)''); 
define('LDAPLAN_9', 'El actual filtro de búsqueda será:');
define('LDAPLAN_10', 'ATENCION:  ¡Parece que el modulo LDAP no está disponible actualmente, si configura el método de autentificación para LDAP podría no funcionar!'); 
define('LDAPLAN_11', 'Tipo de servidor'); 