<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_ADMIN_HELP_0", "Ayuda:<br /># Página de Enlaces");
  	 
define("LAN_ADMIN_HELP_1", "<i>La página de gestión de categorías de enlaces muestra las categorías existentes.</i><br /><br /><b>Lista detallada</b><br />Verá una lista de todas las categorías con su icono, nombre descripción, opciones y métodos de ordenación.<br /><br /><b>Explicación de iconos</b><br />
  	 ".LINK_ICON_LINK." : Enlace de la categoría<br /><br />
  	 ".LINK_ICON_EDIT." : Editar la categoría<br /><br />
  	 ".LINK_ICON_DELETE." : Eliminar la categoría<br /><br />
  	 ".LINK_ICON_ORDER_UP." : Sube una posición respecto al orden.<br /><br />
  	 ".LINK_ICON_ORDER_DOWN." : Baja una posición respecto al orden.<br />
  	 <br />
  	 <b>orden</b><br />Aquí puede fijar manualmente el orden de todas las categorías. Necesita cambiar los valores en las cajas para poder el orden deseado y luego pulsar el botón de reordenar para actualizarlo.<br />");
  	 
  	 
define("LAN_ADMIN_HELP_2", "<i>La página de creación de categoría de enlace le permitirá añadir nuevas categorías</i><br /><br />Puede transferir un icono y depués asignarlo a la categoría.");
define("LAN_ADMIN_HELP_3", "<i>La página de gestor de enlaces muestra primeramente las categorías.</i><br /><br />".LINK_ICON_LINK." : enlace a la categoría<br /><br />".LINK_ICON_EDIT." : Click en el icono para editar todos los enlaces de esta categoría<br />");
define("LAN_ADMIN_HELP_4", "<i>La página de creación de enlaces le permitirá añadir un nuevo enlace</i><br /><br />Puede transferir un icono y depués asignarlo aal enlace.<br /><br />El tipo de apertura definirá como se abrirá el enlace al pulsar sobre él.");
define("LAN_ADMIN_HELP_5", "<i>La página de envíos de enlaces muestra todos los enlaces enviados por los uauarios</i><br /><br /><b>Lista detallada</b><br />Verá la URL, el nombre del usuario que envió el enlace y opciones.<br /><br /><b>Explicación de iconos</b><br />
  	 ".LINK_ICON_EDIT." : Envía el enlace al formulario de creación<br /><br />
  	 ".LINK_ICON_DELETE." : Elimina el enlace enviado<br />
  	 ");
  	 define("LAN_ADMIN_HELP_6", "<i>La página de opciones permite cambiar el comportamiento del plugin links_page</i><br /><br />
  	 Opciones generales<br />
  	 Estas opciones son generalmente usadas a través de la página de enlaces.<br /><br />
  	 Gestores personales de enlaces<br />
  	 Los gestores personales de enlaces son usuarios privilegiados que pueden gestionar sus enlaces añadidos personalmente.<br /><br />
  	 Página de categoría<br />
  	 Aquí puede cambiar las opciones de la página de categoría.<br /><br />
  	 Página de enlaces<br />
  	 Estas opciones se usan en la página de enlaces.<br /><br />
  	 Página de referidos<br />
  	 Estas opciones se usan en la página top de enlaces de referidos.<br /><br />
  	 Página de Clasificación<br />
  	 Estas opciones se usan en la página top de valoraciones.<br />
  	 ");

define("LAN_ADMIN_HELP_7", "<i>La página de edición de categorías le permite editar la categoría del enlace</i><br /><br />Puede transferir un icono y depués asignarlo a la categoría.<br />Puede actualizar el sello de fecha del enlace activando la caja de selección.");
  	 
define("LAN_ADMIN_HELP_8", "<i>Esta página muestra todos los enlaces en la categoría seleccionada.</i><br /><br /><b>Lista detallada</b><br />Puede ver una lista de enlaces con su imagen, nombre, opciones y métodos de ordenación.<br /><br /><b>Explicación de iconos</b><br />
  	 ".LINK_ICON_LINK." : enlace a la página web<br /><br />
  	 ".LINK_ICON_EDIT." : editar enlace<br /><br />
  	 ".LINK_ICON_DELETE." : eliminar el enlace<br /><br />
  	 ".LINK_ICON_ORDER_UP." : sube 1 posición de orden.<br /><br />
  	 ".LINK_ICON_ORDER_DOWN." : baja una posición de orden.<br />
  	 <br />
  	 <b>order</b><br />Aquí puede manualmente fijar el orden de los enlaces. Necesita cambiar los valores de las cajas de selección al orden que desee, y luego pulsar el botón de reordenar para actualizar.<br />");
  	 
define("LAN_ADMIN_HELP_9", "<i>La página de edición de enlaces le permite editar los enlaces</i><br /><br />Puede transferir un nuevo icono, y después asignarlo al enlace.<br /><br />El tipo de apertura le permite como se abrirá el enlace cuando se pulse sobre él.");
define("LAN_ADMIN_HELP_10", "<i>La página de envío de enlaces le permite añadir un enlace a los enlaces existentes</i><br /><br />Se añadira un pequeño texto en el campo de descripción del envío.<br /><br />Puede transferir un nuevo icono, y después asignarlo al enlace.<br /><br />El tipo de apertura le permite como se abrirá el enlace cuando se pulse sobre él.");

?>