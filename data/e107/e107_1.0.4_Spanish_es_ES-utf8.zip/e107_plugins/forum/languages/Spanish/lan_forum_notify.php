<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NT_LAN_FT_1", "Eventos de Foro");
define("NT_LAN_FO_1", "Foro - Nuevo hilo");
define("NT_LAN_MP_1", "Foro - Nueva publicación ");
define("NT_LAN_FD_1", "Foro - Hilo eliminado ");
define("NT_LAN_FP_1", "Foro - publicación eliminada");
define("NT_LAN_FM_1", "Foro - Hilo movido ");
define("NT_LAN_FO_3", "Foro - Hilo creado por");
define("NT_LAN_FO_4", "Nombre del foro");
define("NT_LAN_FO_5", "Asunto");
define("NT_LAN_FO_6", "Mensaje");
define("NT_LAN_FO_7", "Foro - Nuevo hilo creado ");
define("NT_LAN_MP_3", "Foro - publicación creada por");
define("NT_LAN_MP_4", "Nombre del foro");
define("NT_LAN_MP_6", "Mensaje");
define("NT_LAN_MP_7", "Nuevo foro - publicación creada");
define("NT_LAN_FD_3", "Foro - Hilo creado por");
define("NT_LAN_FD_4", "Nombre del foro");
define("NT_LAN_FD_5", "Asunto");
define("NT_LAN_FD_6", "Mensaje");
define("NT_LAN_FD_7", "Foro - Hilo eliminado");
define("NT_LAN_FD_8", "Foro - Hilo eliminado por");
define("NT_LAN_FP_3", "Foro - publicación creada por");
define("NT_LAN_FP_4", "Nombre del foro");
define("NT_LAN_FP_6", "Mensaje");
define("NT_LAN_FP_7", "Foro - publicación eliminada");
define("NT_LAN_FP_8", "Foro -  publicación eliminada por");
define("NT_LAN_FM_3", "Foro - Hilo creado por");
define("NT_LAN_FM_4", "Anterior");
define("NT_LAN_FM_5", "Siguiente");
define("NT_LAN_FM_6", "Anterior (fuente) nombre de foro ");
define("NT_LAN_FM_7", "Siguiente (próximo) nombre de foro");
define("NT_LAN_FM_8", "Foro - Hilo movido");
define("NT_LAN_FM_9", "Foro - Hilo movido por");


?>