<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("e_PAGETITLE", "Foros");

define("LAN_30", "Bienvenid@");
define("LAN_31", "No hay nuevos mensajes ");
define("LAN_32", "Hay 1 nuevo mensaje ");
define("LAN_33", "Hay");
define("LAN_34", "Nuevos mensajes");
define("LAN_35", "desde su última visita.");
define("LAN_36", "Su última visita fué el ");
define("LAN_37", "Estamos a ");
define("LAN_38", ", todas las horas son GMT");
define("LAN_41", "Nuevo miembro: ");
define("LAN_42", "Miembros registrados: ");
define("LAN_44", "Todos los foros pueden ser visitados por los usuarios no registrados, pero tenga en cuenta que su dirección IP será registrada al hacer una publicación.<br />Para acceder a todas las funcionalidades de este foro tendrá que registrarse");
define("LAN_45", "Este foro solo puede ser usado por usuarios registrados, por favor pulse <a href='".e_BASE."signup.php'>aquí</a> para ir a la página de registro.");
define("LAN_46", "Foros");
define("LAN_47", "Temas");
define("LAN_48", "Respuestas");
define("LAN_49", "Última publicación");
define("LAN_51", "No hay foros en este momento, por favor vuelva más tarde.");
define("LAN_52", "No hay foros en esta sección ahora, por favor vuelva más tarde.");
define("LAN_79", "Nuevos envios");
define("LAN_80", " Sin nuevas publicaciones");
define("LAN_81", "Tema cerrado");
define("LAN_100", "artículos");
define("LAN_180", "Buscar");
define("LAN_191", "Información");
define("LAN_192", "Mensajes enviados por los usuarios de este foro ");
define("LAN_196", "Has leido ");
define("LAN_197", " de estos mensajes.");
define("LAN_198", " Todos los mensajes nuevos han sido leidos.");
define("LAN_199", "Marcar todos los mensajes como leidos");
define("LAN_204", "Usted <b>Puede</b> iniciar nuevos temas");
define("LAN_205", "Usted <b>No puede</b> iniciar nuevos temas");
define("LAN_206", "Usted <b>Puede</b> responder");
define("LAN_207", "Usted <b>No puede</b> responder");
define("LAN_208", "Usted <b>Puede</b> editar sus mensajes");
define("LAN_209", "Usted <b>No puede</b> editar sus mensajes");
define("LAN_392", "Parar rastreo de este tema");
define("LAN_393", "Listar temas rastreados");
define("LAN_394", "Foro cerrado");
define("LAN_397", "Rastrear temas");
define("LAN_398", "Cerrado");
define("LAN_399", "Limitado");
define("LAN_400", "Este foro solo puede ser visitado por usuarios registrados");
define("LAN_401", "Solo Miembros");
define("LAN_402", "Este foro es solo de lectura");
define("LAN_403", "No hay mensajes");
define("LAN_404", "mensajes");
define("LAN_405", "Acceso restringido");
define("LAN_406", "Este foro está restringido solo para administradores");
define("LAN_407", "Este foro está restringido solo para miembros");
define("LAN_408", "Este foro es de solo lectura");
define("LAN_409", "Este es un foro de acceso restringido.");
define("LAN_410", "Bienvenido");
define("LAN_411", "Tema");
define("LAN_412", "respuesta");
define("LAN_413", "Temas");
define("LAN_414", "respuestas");
define("LAN_415", "usuario en este momento");
define("LAN_416", "usuarios en este momento");
define("LAN_417", "miembros");
define("LAN_418", "visita");
define("LAN_419", "miembros");
define("LAN_420", "visitas");
define("LAN_421", "Mostrar nuevos mensajes");
define("LAN_422", "Nuevos mensajes desde su última visita");
define("LAN_423", "Enviado por");
define("LAN_424", "Nuevos temas");
define("LAN_425", "Re:");
//v.616
define("LAN_426", "En linea: ");
define("LAN_427", "Ver lista detallada.");
define("LAN_428", "Re:");
define("LAN_429", "Top Autores");
define("LAN_430", "Temas más activos");
define("LAN_431", "Mis mensajes");
define("LAN_432", "Mi configuración");
define("LAN_433", "Normas del foro");
define("LAN_434", "Volver a foros");
define("LAN_435", "Mi perfil");
define("LAN_436", " (se abrirá en una nueva ventana.)");
define("LAN_437", "registrar");
define("LAN_438", "e iniciar sesión.");
define("LAN_439", "aquí");
define("LAN_440", "para ir a la página de registro.");
define("LAN_441", "Ver estadísticas del foro.");

define('FORLAN_441', 'No hay reglas definidas.');
define('FORLAN_442', 'Mis subidas');
define('FORLAN_443', '[Usuario eliminado]');
define('FORLAN_444', 'sub-foros');
?>