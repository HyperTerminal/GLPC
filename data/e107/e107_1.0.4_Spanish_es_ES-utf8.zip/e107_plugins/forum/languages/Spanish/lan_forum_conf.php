<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

# Install LANs
define('LAN_FORUM_INSTALL_01', 'Foro');
define('LAN_FORUM_INSTALL_02', 'Este plugin es un sistema de foro completo.');
define('LAN_FORUM_INSTALL_03', 'Configurar el Foro');
define('LAN_FORUM_INSTALL_04', 'El Foro ya está instalado!');
define('LAN_FORUM_INSTALL_05', 'El foro fue actualizado correctamente, versión actual: %1$s');
define('LAN_FORUM_INSTALL_06', '[foro]');
define('LAN_FORUM_INSTALL_07', '[más...]');

# Config LANs
define('FORLAN_5', 'Encuesta borrada.');
define('FORLAN_6', 'Tema borrado');
define('FORLAN_7', 'Respuestas borradas');
define('FORLAN_8', 'Borrar cancelado.');
define('FORLAN_9', 'Tema movido.');
define('FORLAN_10', 'Movimiento cancelado.');
define('FORLAN_11', 'Volver a foros');
define('FORLAN_12', 'Configuración del foro');
define('FORLAN_13', '¿Está seguro que quiere borrar esta encuesta?<br />Una vez borrada, <b><u>no podrá</u></b> recupararla.');
define('FORLAN_14', 'Cancelar');
define('FORLAN_15', 'Confirmar que quiere borrar mensajes del foro');
define('FORLAN_16', 'Confirmar que quiere borrar la encuesta');
define('FORLAN_17', 'Publicado por');
define('FORLAN_18', '¿Está seguro que quiere borrar este foro');
define('FORLAN_19', 'tema y sus correspondientes mensajes?');
define('FORLAN_20', 'La encuesta también será borrada');
define('FORLAN_21', 'Quiere borrados estas');
define('FORLAN_22', 'publicaciones?<br />Una vez borrado');
define('FORLAN_23', 'no puede</u></b> ser recuperado');
define('FORLAN_24', 'Mover tema a foro');
define('FORLAN_25', 'Mover Tema');
define('FORLAN_26', 'Respuesta borrada');
define('FORLAN_27', 'Movido');
define('FORLAN_28', 'No cambie el nombre de título del tema');
define('FORLAN_29', 'Añadir');
define('FORLAN_30', 'al título');
define('FORLAN_31', 'Renombrar para:');
define('FORLAN_32', 'Opciones al renombrar tema:');