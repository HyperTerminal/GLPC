<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Transferencias del foro");

define("FRMUP_1","Archivos transferidos al foro");
define("FRMUP_2","Archivo eliminado");
define("FRMUP_3","Error: Imposible eliminar archivo");
define("FRMUP_4","Eliminación del archivo");
define("FRMUP_5","Nombre del archivo");
define("FRMUP_6","Resultado");
define("FRMUP_7","Encontrado en el tema");
define("FRMUP_8","NO ENCONTRADO");
define("FRMUP_9","No se han encontrado archivos transferidos");
define("FRMUP_10","Eliminar");
?>