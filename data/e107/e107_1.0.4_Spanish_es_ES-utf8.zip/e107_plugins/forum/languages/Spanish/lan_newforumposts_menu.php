<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       Spanish language file)
|
|       Traducción Spanish(ES) -> KANONimpresor
|       (http://www.kanonimpresor.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|    	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NFP_1", "Todos los últimos envíos estan fuera de su clase de usuario. Imposible mostrar.");
define("NFP_2", "Sin envíos todavía");
define("NFP_3", "Configuración de nuevos envíos del foro guardada");
define("NFP_4", "Título");
define("NFP_5", "¿Número de mensajes a mostrar?");
define("NFP_6", "¿Número de carácteres a mostrar?");
define("NFP_7", "¿Fijar envíos muy largos?");
define("NFP_8", "¿Mostrar temas originales en el menú?");
define("NFP_9", "Actualizar parámetros del menú");
define("NFP_10", "Configuración del menú de nuevos envíos del foro");
define("NFP_11", "Enviado por");
define("NFP_12", "Antiguedad de los envíos mostrados"); 
define("NFP_13", "Use cero para un sitio tranquilo; fijando un valor en días reducirá el tiempo de la dase de datos en un sitio ocupado"); 
?>