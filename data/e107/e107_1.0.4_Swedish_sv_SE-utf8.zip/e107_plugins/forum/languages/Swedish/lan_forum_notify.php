<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Swedish/lan_forum_notify.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/23 14:02:45 $
|        $Author: Hanssons.de $
+---------------------------------------------------------------+
*/

// Forum Notify Types 
define("NT_LAN_FT_1", "Forumhändelser");
define("NT_LAN_FO_1", "Forumtråd skapad");
define("NT_LAN_MP_1", "Forummeddelande postad");
define("NT_LAN_FD_1", "Forumtråd raderad");
define("NT_LAN_FP_1", "Forummeddelande raderad");
define("NT_LAN_FM_1", "Forumtråd flyttad");

// Forum thread posted
define("NT_LAN_FO_3", "Forumtråd skapad av");
define("NT_LAN_FO_4", "Forumnamn");
define("NT_LAN_FO_5", "Ämne");
define("NT_LAN_FO_6", "Meddelande");
define("NT_LAN_FO_7", "Ny forumtråd skapad");

// Forum message posted
define("NT_LAN_MP_3", "Forummeddelandet skapades av");
define("NT_LAN_MP_4", "Forumnamn");
define("NT_LAN_MP_6", "Meddelande");
define("NT_LAN_MP_7", "Nytt forummeddelande postat");

// Forum thread deleted
define("NT_LAN_FD_3", "Forumtråden skapades av");
define("NT_LAN_FD_4", "Forumnamn");
define("NT_LAN_FD_5", "Ämne");
define("NT_LAN_FD_6", "Meddelande");
define("NT_LAN_FD_7", "Forumtråden är raderad");
define("NT_LAN_FD_8", "Forumtråden raderades av");

// Forum message deleted
define("NT_LAN_FP_3", "Forummeddelandet skapades av");
define("NT_LAN_FP_4", "Forumnamn");
define("NT_LAN_FP_6", "Meddelande");
define("NT_LAN_FP_7", "Forummeddelande är raderad");
define("NT_LAN_FP_8", "Forummeddelande raderades av");

// Forum thread moved
define("NT_LAN_FM_3", "Forumtrådenen skapades av");
define("NT_LAN_FM_4", "Gammalt ämne");
define("NT_LAN_FM_5", "Nytt ämne");
define("NT_LAN_FM_6", "Gammalt ( källa ) forumnamn");
define("NT_LAN_FM_7", "Ny ( destination ) forumnamn");
define("NT_LAN_FM_8", "Forumtråden är flyttad");
define("NT_LAN_FM_9", "Forumtråden flyttades av");


?>