<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_FORUM_INSTALL_01", "Forum");
define("LAN_FORUM_INSTALL_02", "Detta program är ett komplett forumsystem.");
define("LAN_FORUM_INSTALL_03", "Konfigurera forum");
define("LAN_FORUM_INSTALL_04", "Ditt forum är nu installerat");
define("LAN_FORUM_INSTALL_05", "Forum uppgraderades. Du använder nu version %1$s");
define("LAN_FORUM_INSTALL_06", "[forum]");
define("LAN_FORUM_INSTALL_07", "[mer...]");
define("FORLAN_5", "Omöstning raderad.");
define("FORLAN_6", "Tråd raderad");
define("FORLAN_7", "svar raderade");
define("FORLAN_8", "Radering avbruten.");
define("FORLAN_9", "Tråd flyttad.");
define("FORLAN_10", "Flyttning avbruten.");
define("FORLAN_11", "Tillbaka till forum");
define("FORLAN_12", "Forumkonfiguration");
define("FORLAN_13", "Är du absolut säker på att du vill radera denna omröstningen?<br />Väl raderad kan den <b><u>inte</u></b> återfås.");
define("FORLAN_14", "Avbryt");
define("FORLAN_15", "Bekräfta radering av inlägg");
define("FORLAN_16", "Bekräfta radering av omröstning");
define("FORLAN_17", "inlagd av");
define("FORLAN_18", "Är du absolut säker på att du vill radera detta forum");
define("FORLAN_19", "tråd och dess relaterade inlägg?");
define("FORLAN_20", "röstningen kommer också att raderas");
define("FORLAN_21", "Väl raderade kan");
define("FORLAN_22", "inlägg?<br />Väl raderat kan det");
define("FORLAN_23", "inte</u></b> återfås");
define("FORLAN_24", "Flytta tråd till forum");
define("FORLAN_25", "Flytta tråd");
define("FORLAN_26", "Svar raderat");
define("FORLAN_27", "flyttad");
define("FORLAN_28", "Byt inte namn på trådrubriken");
define("FORLAN_29", "Lägg till");
define("FORLAN_30", "till rubrik");
define("FORLAN_31", "Byt namn till:");
define("FORLAN_32", "Val för namnbyte på tråd:");


?>