<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/forum/languages/Swedish/lan_newforumposts_menu.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("NFP_1", "Alla senaste inlägg är utanför din användarklass, kan ej visa dem.");
define("NFP_2", "Inga inlägg ännu");
define("NFP_3", "Menykonfiguration för nya foruminlägg sparad");
define("NFP_4", "Rubrik");
define("NFP_5", "Antal inlägg att visa?");
define("NFP_6", "Antal tecken att visa?");
define("NFP_7", "Postfix för för långa inlägg?");
define("NFP_8", "Visa ursprungliga ämnen i meny?");
define("NFP_9", "Uppdatera menyinställningar");
define("NFP_10", "Menykonfiguration för nya foruminlägg");
define("NFP_11", "Postad av");
define("NFP_12", "Maxålder på visade poster");
define("NFP_13", "Använd 0 på en tyst webbplats; inställning av värde i dagar kommer att reducera databastiden på webbplats med mycket besökare");
	
?>