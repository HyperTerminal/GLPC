<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Välj forum");
define("FOR_SCH_LAN_3", "Alla forum");
define("FOR_SCH_LAN_4", "Hela inlägg/poster");
define("FOR_SCH_LAN_5", "Som del av en tråd");

?>