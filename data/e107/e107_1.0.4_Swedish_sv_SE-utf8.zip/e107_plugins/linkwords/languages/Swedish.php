<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/linkwords/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:52 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssonsde $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "Fält har lämnat tomt.");
define("LWLAN_2", "Länkordet sparades");
define("LWLAN_3", "Länkordet uppdaterades");
define("LWLAN_4", "Inga länkord definierade ännu.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "Länk");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Alternativ");
define("LWLAN_9", "Ja");
define("LWLAN_10", "Nej");
define("LWLAN_11", "Befintliga länkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nej");
define("LWLAN_14", "Spara länkord");
define("LWLAN_15", "Uppdatera länkord");
define("LWLAN_16", "Redigera");
define("LWLAN_17", "Radera");
define("LWLAN_18", "Är du säker på att du vill radera detta länkord?");
define("LWLAN_19", "Länkordet raderat");
define("LWLAN_20", "Kan inte hitta den länkordsposten");
define("LWLAN_21", "Ord att autolänka (eller kommaseparerad lista av ord)");
define("LWLAN_22", "Aktivera?");
define("LWLAN_23", "Adminstrera länkord");
define("LWLAN_24", "Hantera ord");
define("LWLAN_25", "Val");
define("LWLAN_26", "Områden där länkord ska aktiveras");
define("LWLAN_27", "Det här är 'innehållet' av den visade texten.");
define("LWLAN_28", "Sidor där länkord ska avaktiveras");
define("LWLAN_29", "Ange en sida per rad, ange tillräckligt mycket av webbadressen för att utmärka den ordentligt. Om du behöver slutet av webbadressen för att matcha exakt, använd ett ! i slutet av sidnamnet, till exempel: page.php?1! ");
define("LWLAN_30", "Spara inställningar");
define("LWLAN_31", "Lägg till / ändra länkord");
define("LWLAN_32", "Alternativ för länkord");
define("LWLAN_33", "Rubriker");
define("LWLAN_34", "Innehållssammanfattningar");
define("LWLAN_35", "Brödtext");
define("LWLAN_36", "Beskrivningar (länkar osv)");
define("LWLAN_37", "Arvsområden");
define("LWLAN_38", "Klickbara länkar");
define("LWLAN_39", "Oprocessad text");
define("LWLAN_40", "Rubriker skrivna av användare (exempelvis i forum, bloggar osv)");
define("LWLAN_41", "Brödtext skriven av användare (exempelvis i forum, bloggar osv)");

define("LWLANINS_1", "Länkord");
define("LWLANINS_2", "Denna plugin kommer att länka specificerade ord till en definierad länk");
define("LWLANINS_3", "Konfigurera länkord");
define("LWLANINS_4", "För att konfigurera, klicka på länken i pluginsektionen på admins förstasida");


?>