<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/links_page/languages/Swedish_help.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/23 14:36:32 $
|        $Author: Hanssons.de $
+---------------------------------------------------------------+
*/
define("LAN_ADMIN_HELP_0", "Hjälparea för Länksida");
define("LAN_ADMIN_HELP_1", "<i>På sidan Hantera kategorier visas alla befintliga kategorier.</i><br /><br /><b>Detaljerad lista</b><br />Visar en lista med alla kategorier med ikoner, namn, beskrivning, alternativ och sorteringsalternativ.<br /><br /><b> Förklaring till knapparna </b><br /><br /> ".LINK_ICON_LINK." : Länk till kategorin<br /><br /> ".LINK_ICON_EDIT." : Redigera kategorin <br /><br /> ".LINK_ICON_DELETE." : Radera kategorin <br /><br /> ".LINK_ICON_ORDER_UP." : Uppåtpilen låter dig flytta upp kategorin en nivå <br /><br /> ".LINK_ICON_ORDER_DOWN." : Nedpilen låter dig flytta ner kategorin en nivå <br /> <br /> <b>Ordning</b><br /> Här kan du manuellt sortera kategorierna. När du ställt in önskad ordning klickar du på knappen Ordna för att spara inställningarna. <br />");
define("LAN_ADMIN_HELP_2", "<i> Skapa länkkategori sidan tillåter dig att lägga till nya kategorier</i><br /><br /> Du kan ladda upp en ny ikon, och efter uppladdning tilldela ikonen till kategorin.");
define("LAN_ADMIN_HELP_3", "<i>Hantera länkar sidan visar alla kategorier.</i><br /><br />".LINK_ICON_LINK." : länk till kategorin<br /><br />".LINK_ICON_EDIT." : klicka på ikonen för att se alla länkar i denna kategorin<br />");
define("LAN_ADMIN_HELP_4", "<i>Sidan Skapa länk tillåter dig att skapa en ny länk</i><br /><br />Du kan ladda upp en ny ikon, och efter uppladdning tilldela ikonen till länken.<br /><br />På öppningstyp kan du definiera hur länken ska öppnas när en användare klickar på den.");
define("LAN_ADMIN_HELP_5", "<i>Sidan Inskickade länkar visar de länkar som skickats in av användare </i><br /><br /><b> Du ser länkens URL, användarens namn samt alternativ. <br /><br /><b> Förklaring till ikonerna </b><br /><br /> ".LINK_ICON_EDIT." : Öppna den inskickade länken i sidan Skapa länk br /><br /> ".LINK_ICON_DELETE." : Radera den inskickade länken <br />");
define("LAN_ADMIN_HELP_6", "<i>Sidan Alternativ låter dig ändra hur länksidan beter sig </i><br /><br /> Allmänna inställningar <br /> Dessa inställningar påverkar i huvudsak länksidorna. <br /><br /> Personlig länkhanterare <br /> Den användarklass som tillåts hantera egna länkar. .<br /><br /> Kategorisida <br /> Ändra inställningar för kategorisidan här. <br /><br /> Länksida <br /> Alternativ för länksidan ställs in här. <br /><br /> Flest klick <br /> Alternativ för sidan Flest klickade länkar .<br /><br /> Betygssida <br /> Inställningar för sidan Länkar med högst betyg. <br />");
define("LAN_ADMIN_HELP_7", "<i>Redigera länkkategorin tillåter dig att redigera en befintlig kategori</i><br /><br />Du kan ladda upp en ny ikon, och efter uppladdning tilldela ikonen till kategorin..<br />Du kan uppdatera tidstämpeln på länken genom att bocka i rutan.");
define("LAN_ADMIN_HELP_8", "<i> Denna sida visar samtliga länkar i  vald kategori. .</i> <br /> <br /> <b> Detaljerad lista </b> <br /> En lista med länkarnas ikon, namn, alternativ och sorteringsalternativ. <br /> <br /> <b> Förklaring till knapparna </b> <br /> ".LINK_ICON_LINK." : Webblänk <br /> <br /> ".LINK_ICON_EDIT." : Ändra länken <br /> <br /> ".LINK_ICON_DELETE." : Radera länken <br /> <br /> ".LINK_ICON_ORDER_UP." : Flytta upp länken en nivå. <br /> <br /> ".LINK_ICON_ORDER_DOWN." : Flytta ned länken en nivå. <br /> <br /> <b> Ordna </b> <br /> Ordna om länkarna manuellt genom att ange ordning med rutorna. Klicka sedan på knappen Ordna för att spara den inställda ordningen. <br />");
define("LAN_ADMIN_HELP_9", "<i>Sidan Redigera länkar låter dig redigera en befintlig länk</i><br /><br />Du kan ladda upp en ny ikon, och efter uppladdning tilldela ikonen till länken.<br /><br />På öppningstyp kan du definiera hur länken ska öppnas när en användare klickar på den.");
define("LAN_ADMIN_HELP_10", "<i>Inkskickad postlänk sidan tillåter dig att lägga till en inskickad länk till befintliga länkar</i><br /><br />En liten inskickad text läggs in i fältet beskrivning.<br /><br />Du kan ladda upp en ny ikon, och efter uppladdning tilldela ikonen till länken.<br /><br />På öppningstyp kan du definiera hur länken ska öppnas när en användare klickar på den.");


?>