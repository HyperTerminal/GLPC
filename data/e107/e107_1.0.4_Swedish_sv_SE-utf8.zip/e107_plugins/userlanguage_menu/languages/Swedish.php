<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/userlanguage_menu/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/07/12 16:18:11 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "Ställ in språk");
define("UTHEME_MENU_L2", "Välj språk");
define("UTHEME_MENU_L3", "Tabeller");
?>