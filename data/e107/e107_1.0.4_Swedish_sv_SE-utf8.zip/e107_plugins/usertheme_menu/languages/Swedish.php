<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/usertheme_menu/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_UMENU_THEME_1", "Ställ in tema");
define("LAN_UMENU_THEME_2", "Välj tema");
define("LAN_UMENU_THEME_3", "användare");
define("LAN_UMENU_THEME_4", "Aktivera de teman som användarna kan välja");
define("LAN_UMENU_THEME_5", "Uppdatera");
define("LAN_UMENU_THEME_6", "Teman som är tillgängliga för användare");
define("LAN_UMENU_THEME_7", "Klass som kan välja teman");
?>