<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Admininistratörsbesök räknas inte.<br />");
define("COUNTER_L2", "Denna sida idag");
define("COUNTER_L3", "Totalt");
define("COUNTER_L4", "Denna sidan någonsin...");
define("COUNTER_L5", "unika");
define("COUNTER_L6", "Webbplats...");
define("COUNTER_L7", "Räknare");
define("COUNTER_L8", "Adminmeddelande: <b>Statistikloggningen är inte aktiverad.</b><br />För att aktivera måste du installera statistikloggningsprogrammet från din <a href='".e_ADMIN."plugin.php'>programhanterare</a>, och sedan aktivera den från <a href='".e_PLUGIN."log/admin_config.php'>konfigurationssidan</a>.");


?>