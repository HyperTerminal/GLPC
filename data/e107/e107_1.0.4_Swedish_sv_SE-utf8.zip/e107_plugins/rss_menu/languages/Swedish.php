<?php
/*
+ ----------------------------------------------------------------------------+
|      e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/rss_menu/languages/English.php,v $
|     $Revision: 1.15 $
|     $Date: 2006/11/09 19:04:19 $
|     $Author: e107coders $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("RSS_LAN05", "Antal artiklar (0=inaktiverad)");
define("RSS_MENU_L1", " syndikeras genom dessa RSS-flöden.");
define("RSS_MENU_L2", "RSS-flöden");
define("RSS_MENU_L3", "Nyhetsartiklar");
define("RSS_MENU_L4", "Kommentarer");
define("RSS_MENU_L5", "Forumtrådar");
define("RSS_MENU_L6", "Forumposter");
define("RSS_MENU_L7", "Chattinlägg");
define("RSS_MENU_L8", "Buggrapporter");
define("RSS_MENU_L9", "Nedladdningar");
define("RSS_NEWS", "Nyheter");
define("RSS_COM", "Kommentarer");
define("RSS_ART", "Nyhetsartiklar");
define("RSS_REV", "Recensioner");
define("RSS_FT", "Forumtrådar");
define("RSS_FP", "Foruminlägg");
define("RSS_FSP", "Forumspecifikt inlägg");
define("RSS_BUG", "Buggspårare");
define("RSS_FOR", "Forum");
define("RSS_DL", "Nedladdningar");
define("RSS_PLUGIN_LAN_1", "RSS");
define("RSS_PLUGIN_LAN_6", "Flödeslänkar");
define("RSS_PLUGIN_LAN_7", "RSS-flöde för nyheter");
define("RSS_PLUGIN_LAN_8", "RSS-flöde för nedladdningar");
define("RSS_PLUGIN_LAN_9", "RSS-flöde för kommentarer");
define("RSS_PLUGIN_LAN_10", "RSS-flöde för nyhetskategori:");
define("RSS_PLUGIN_LAN_11", "RSS-flöde för nedladdningskategori:");
define("RSS_PLUGIN_LAN_14", "Kommentarer");
define("RSS_LAN_ADMINMENU_1", "RSS-inställningar");
define("RSS_LAN_ADMINMENU_2", "Listningar");
define("RSS_LAN_ADMINMENU_4", "Importera");
define("RSS_LAN_ERROR_1", "Det här är inget korrekt RSS-flöde<br /><br /><a href='".e_SELF."'>◄ Tillbaka till RSS-flödeslistan</a>");
define("RSS_LAN_ERROR_2", "Din e107_config.php fil eller din språkfil innehåller tomrum eller tecken före <?. Du måste ta bort det med en icke-UTF-8 textredigerare om du vill ha ett korrekt RSS-flöde.");
define("RSS_LAN_ERROR_3", "Inga RSS-flöden finns ännu.<br />Använd importeringsverktyget för att importera tillgängliga RSS-flöden eller för att skapa ett RSS-flöde manuellt.");
define("RSS_LAN_ERROR_4", "Inga RSS-flöden är tillgängliga ännu");
define("RSS_LAN_ERROR_5", "Det här RSS-inlägget existerar inte");
define("RSS_LAN_ERROR_6", "Det finns inga RSS-flöden att importera");
define("RSS_LAN_ERROR_7", "Några nödvändiga fält saknas.");
define("RSS_LAN_ADMIN_1", "Befintliga RSS-flöden");
define("RSS_LAN_ADMIN_2", "ID");
define("RSS_LAN_ADMIN_3", "Program / funktion");
define("RSS_LAN_ADMIN_4", "Namn");
define("RSS_LAN_ADMIN_5", "URL");
define("RSS_LAN_ADMIN_6", "Text");
define("RSS_LAN_ADMIN_7", "Gräns");
define("RSS_LAN_ADMIN_8", "Synlighet");
define("RSS_LAN_ADMIN_9", "Typ");
define("RSS_LAN_ADMIN_10", "RSS-flöde skapa inlägg");
define("RSS_LAN_ADMIN_11", "RSS-flöde importera flöden");
define("RSS_LAN_ADMIN_12", "Ämnes-ID");
define("RSS_LAN_ADMIN_13", "Inkludera artiklar postade under annan nyhetsmeny i nyhetsflödet?");
define("RSS_LAN_ADMIN_14", "Aktivera");
define("RSS_LAN_ADMIN_15", "Markera det du vill importera...");
define("RSS_LAN_ADMIN_16", "Importera?");
define("RSS_LAN_ADMIN_17", "Importera markerade länkar");
define("RSS_LAN_ADMIN_18", "RSS-flöden importerades.");
define("RSS_LAN_ADMIN_21", "Aktiv och synlig i RSS-flödeslistan");
define("RSS_LAN_ADMIN_22", "Aktiv men EJ synlig i RSS-flödeslistan");
define("RSS_LAN_ADMIN_23", "Inaktiv");
define("RSS_LAN_ADMIN_26", "Markera alla");
define("RSS_LAN_ADMIN_27", "Avmarkera alla");
define("RSS_LAN_ADMIN_31", "Gränsen för RSS-inlägg uppdaterad");
define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@nospam.com");
define("RSS_LAN_3", "noauthor@nospam.com");


?>