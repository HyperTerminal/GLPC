<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "Nyhetsflöden");
define("NWSF_FP_2", "Huvudsida");

?>