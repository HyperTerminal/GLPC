<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/sitebutton_menu/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
|     $Swedish translation checked by: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("SITEBUTTON_MENU_L1", "Länka hit");

?>