<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("FBLAN_01", "Funktionsruta");
define("FBLAN_02", "Detta program låter dig visa en ruta ovanför dina nyheter med funktioner / vad du vill i den. Meddelandena kan antingen bytas ut slumpmässigt eller dynamiskt tonas till en ny ruta.");
define("FBLAN_03", "Konfigurera Funktionsrutan");
define("FBLAN_04", "Funktionsrutan har installerats. För att lägga till meddelande och konfigurera, gå tillbaka till administratörshuvudsidan och klicka på ikonen för Funktionsruta i programsektionen.");
define("FBLAN_05", "Inga meddelanden definierade för rutan ännu");
define("FBLAN_06", "Befintliga meddelanden i Funktionsrutan");
define("FBLAN_07", "Rubrik");
define("FBLAN_08", "Meddelandetext");
define("FBLAN_09", "Vilka får se meddelandet?");
define("FBLAN_10", "Skapa meddelande");
define("FBLAN_11", "Uppdatera meddelande");
define("FBLAN_12", "Statisk eller slumpvis visning");
define("FBLAN_13", "Slumpvis visning av meddelande");
define("FBLAN_14", "Visa enbart detta meddelande");
define("FBLAN_15", "Meddelande sparat i databasen.");
define("FBLAN_16", "Meddelande uppdaterat i databasen.");
define("FBLAN_17", "Fält lämnat tomt");
define("FBLAN_18", "Meddelandet raderat");
define("FBLAN_19", "Alternativ");
define("FBLAN_20", "Redigera");
define("FBLAN_21", "Radera");
define("FBLAN_22", "Använd ram eller ej (slätt)");
define("FBLAN_23", "Använd ram (temaruta)");
define("FBLAN_24", "Slätt");
define("FBLAN_25", "Välj mall");
define("FBLAN_26", "Du kan använda olika mallar för varje meddelande.<br />Lägg till mallar i mappen e107_plugins/featurebox/templates/ ");

?>