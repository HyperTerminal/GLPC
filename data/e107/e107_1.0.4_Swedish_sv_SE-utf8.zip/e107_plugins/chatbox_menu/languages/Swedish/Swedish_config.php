<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/Swedish/Swedish_config.php $
|        $Revision: 1.0 $
|        $Id: 2010/10/28 01:43:50 $
|        $Author: Admin $
+---------------------------------------------------------------+
*/

define("CHBLAN_1", "Inställningar för chattruta uppdaterade");
define("CHBLAN_2", "Modererad");
define("CHBLAN_3", "Inga chattinlägg ännu");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "Gäst");
define("CHBLAN_6", "Avblockera");
define("CHBLAN_7", "Blockera");
define("CHBLAN_8", "Ta bort");
define("CHBLAN_9", "Moderera chattruta");
define("CHBLAN_10", "Moderera chattinlägg");
define("CHBLAN_11", "Visa antal chattinlägg");
define("CHBLAN_12", "Antalet inlägg som ska visas i chattrutan");
define("CHBLAN_13", "Ersätt länkar");
define("CHBLAN_14", "Om du markerar denna ruta kommer länkar ersättas med den text du anger nedan");
define("CHBLAN_15", "Ersättningssträng (om aktiverad)");
define("CHBLAN_16", "Länkar kommer ersättas med denna sträng");
define("CHBLAN_17", "Ordbrytning efter antal tecken");
define("CHBLAN_18", "Ord med fler tecken än detta kommer avstavas");
define("CHBLAN_19", "Uppdatera inställningar för chattrutan");
define("CHBLAN_20", "Inställningar för chattrutan");
define("CHBLAN_21", "Rensa");
define("CHBLAN_22", "Radera gamla inlägg");
define("CHBLAN_23", "Radera inlägg äldre än");
define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En vecka");
define("CHBLAN_26", "En månad");
define("CHBLAN_27", "- Ta bort ALLA inlägg -");
define("CHBLAN_28", "Chattrutan rensad");
define("CHBLAN_29", "Visa chattrutan i ruta med scrollfunktion");
define("CHBLAN_30", "Rutans höjd");
define("CHBLAN_31", "Visa uttryckssymboler");
define("CHBLAN_32", "Moderator användarklass");
define("CHBLAN_33", "Antalet inlägg omräknade");
define("CHBLAN_34", "Räkna om antalet inlägg");
define("CHBLAN_35", "Räkna om");
define("CHBLAN_36", "Alternativ för chattruta");
define("CHBLAN_37", "Normal chattruta");
define("CHBLAN_38", "Använd JavaScript-kod för att uppdatera inlägg dynamiskt (AJAX)");


?>