<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "Kunde inte acceptera inlägget eftersom det användarnamnet är registrerat - om det är ditt användarnamn - var vänlig och logga in för att posta.");
define("CHATBOX_L2", "Chattruta");
define("CHATBOX_L3", "Du måste vara inloggad för att posta kommentarer på den här webbplatsen - var vänlig och logga in eller om du inte är registrerad - klicka <a href='".e_SIGNUP."'>här</a> för att registrera dig");
define("CHATBOX_L4", "Skicka");
define("CHATBOX_L5", "Töm");
define("CHATBOX_L6", "[blockerad av administratör]");
define("CHATBOX_L7", "Ta bort blockering");
define("CHATBOX_L8", "Information");
define("CHATBOX_L9", "Blockera");
define("CHATBOX_L10", "Radera");
define("CHATBOX_L11", "Inga meddelanden ännu.");
define("CHATBOX_L12", "Visa alla inlägg");
define("CHATBOX_L13", "Moderera chattrutan");
define("CHATBOX_L14", ":-)");
define("CHATBOX_L15", "Inlägget är för långt, eller tomt");
define("CHATBOX_L16", "Anonym");
define("CHATBOX_L17", "Dubbelt inlägg");
define("CHATBOX_L18", "Chattrutemeddelanden modererade");
define("CHATBOX_L19", "Du kan bara posta var ".(FLOODPROTECT ? FLOODTIMEOUT : 'e')." sekund(er)");
define("CHATBOX_L20", "Chattruta ( alla inlägg )");
define("CHATBOX_L21", "Chattinlägg");
define("CHATBOX_L22", "den");
define("CHATBOX_L23", "Fel!");
define("CHATBOX_L24", "Du har inte korrekt behörighet för att se den här sidan.");
define("CHATBOX_L25", "[ det här inlägget har blivit blockerat av administratör ]");
define("NT_LAN_CB_1", "Chattrutehändelser");
define("NT_LAN_CB_2", "Meddelande postat");
define("NT_LAN_CB_3", "Postat av");
define("NT_LAN_CB_4", "IP Adress");
define("NT_LAN_CB_5", "Meddelande");
define("NT_LAN_CB_6", "Chattmeddelande postat");


?>