<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/pdf/languages/Swedish.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/01/24 13:23:50 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Stöd för skapande av PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Detta plugin är nu redo att användas.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF preferenser");
define("PDF_LAN_3", "aktiverad");
define("PDF_LAN_4", "inaktiverad");
define("PDF_LAN_5", "Sidomarginal vänster");
define("PDF_LAN_6", "Sidomarginal höger");
define("PDF_LAN_7", "Sidomarginal topp");
define("PDF_LAN_8", "Fontfamilj");
define("PDF_LAN_9", "Standard fontstorlek");
define("PDF_LAN_10", "Fontstorlek webbplatsnamn");
define("PDF_LAN_11", "Fontstorlek webbadress");
define("PDF_LAN_12", "Fontstorlek sidnummer");
define("PDF_LAN_13", "Visa logo på pdf?");
define("PDF_LAN_14", "Visa webbplatsnamn på pdf?");
define("PDF_LAN_15", "Visa skaparens webbadress på pdf?");
define("PDF_LAN_16", "Visa sidonummer på pdf?");
define("PDF_LAN_17", "Uppdatera");
define("PDF_LAN_18", "Egenskaper för PDF sparades");
define("PDF_LAN_19", "Sida");
define("PDF_LAN_20", "Felrapportering");

?>