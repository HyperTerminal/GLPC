<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/list_new/languages/Swedish.php,v $
|     $Revision: 1.9 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Lista nya objekt");

define("LIST_PLUGIN_1", "Lista");
define("LIST_PLUGIN_2", "Detta program låter dig se en lista på nya tillägg i flera sektioner (nyhetsartiklar, forum, medlemmar, kalender, innehållsobjekt, chattruta, nedladdningar, kommentarer och externa länkar). Du kan antingen visa listan med data sedan ditt senaste besök, eller visa en allmän lista på senaste tillägg. Förutom sidan finns även motsvarande menyer. Alla sektioner är konfigurerbara i adminsektionen. Om du installerar nya program kan även dessa i förekommande fall listas på dessa sidor och menyer.");
define("LIST_PLUGIN_3", "Konfigurera huvudmeny");
define("LIST_PLUGIN_4", "Program för nya tillägg är nu klart att användas");
define("LIST_PLUGIN_5", "Lista");
define("LIST_PLUGIN_6", "Detta program är inte installerat");

define("LIST_ADMIN_1", "Senaste");
define("LIST_ADMIN_2", "Uppdatera inställningar");
define("LIST_ADMIN_3", "Inställningarna uppdaterade");
define("LIST_ADMIN_4", "Sektion");
define("LIST_ADMIN_5", "Meny");
define("LIST_ADMIN_6", "Sida");
define("LIST_ADMIN_7", "Aktiverad");
define("LIST_ADMIN_8", "Avaktiverad");
define("LIST_ADMIN_9", "Öppen");
define("LIST_ADMIN_10", "Stängd");
define("LIST_ADMIN_11", "Uppdatera");
define("LIST_ADMIN_12", "Välj");
define("LIST_ADMIN_13", "Välkommen till de senaste händelserna på ".SITENAME.". Här visas de senaste tilläggen på olika delar av webbplatsen.");
define("LIST_ADMIN_14", "Senaste tilläggen");
define("LIST_ADMIN_15", "Nya sedan ditt senaste besök");
define("LIST_ADMIN_16", "Välkommen till nya händelser på ".SITENAME."! Sedan ditt senaste besök har följande tillkommit på webbplatsen.");

define("LIST_ADMIN_SECT_1", "Sektioner");
define("LIST_ADMIN_SECT_2", "Välj vilka sektioner som skall visas");
define("LIST_ADMIN_SECT_3", "");

define("LIST_ADMIN_SECT_4", "Visningsstil");
define("LIST_ADMIN_SECT_5", "Välj vilka sektioner som är öppna som standard");
define("LIST_ADMIN_SECT_6", "");

define("LIST_ADMIN_SECT_7", "Författare");
define("LIST_ADMIN_SECT_8", "Välj om författaren skall visas");
define("LIST_ADMIN_SECT_9", "");

define("LIST_ADMIN_SECT_10", "Kategori");
define("LIST_ADMIN_SECT_11", "Välj om kategorin skall visas");
define("LIST_ADMIN_SECT_12", "");

define("LIST_ADMIN_SECT_13", "Datum");
define("LIST_ADMIN_SECT_14", "Välj om datum skall visas");
define("LIST_ADMIN_SECT_15", "");

define("LIST_ADMIN_SECT_16", "Antal objekt");
define("LIST_ADMIN_SECT_17", "Välj hur många objekt som skall visas för varje sektion");
define("LIST_ADMIN_SECT_18", "");

define("LIST_ADMIN_SECT_19", "Sortera objekt");
define("LIST_ADMIN_SECT_20", "Välj i vilken ordning sektionerna skall visas");
define("LIST_ADMIN_SECT_21", "");

define("LIST_ADMIN_SECT_22", "Kula");
define("LIST_ADMIN_SECT_23", "Välj en kula för varje sektion");
define("LIST_ADMIN_SECT_24", "");

define("LIST_ADMIN_SECT_25", "Rubrik");
define("LIST_ADMIN_SECT_26", "Välj en rubrik för varje sektion");
define("LIST_ADMIN_SECT_27", "");

define("LIST_ADMIN_OPT_1", "Allmänt");
define("LIST_ADMIN_OPT_2", "Senaste sida");
define("LIST_ADMIN_OPT_3", "Senaste meny");
define("LIST_ADMIN_OPT_4", "Ny sida");
define("LIST_ADMIN_OPT_5", "Ny meny");
define("LIST_ADMIN_OPT_6", "Alternativ");

define("LIST_ADMIN_MENU_2", "Standardkula");
define("LIST_ADMIN_MENU_3", "Använd temats standardkula ( bullet2.gif ) om ingen annan kula finns.");
define("LIST_ADMIN_MENU_4", "");

define("LIST_ADMIN_LAN_2", "Rubrik");
define("LIST_ADMIN_LAN_3", "Ange en rubrik");
define("LIST_ADMIN_LAN_4", "");

define("LIST_ADMIN_LAN_5", "Använd kula");
define("LIST_ADMIN_LAN_6", "Använd en kula framför varje objekt enligt inställningarna vid 'Kula'");
define("LIST_ADMIN_LAN_7", "");

define("LIST_ADMIN_LAN_8", "Tecken");
define("LIST_ADMIN_LAN_9", "Välj hur många tecken av rubriken som skall visas");
define("LIST_ADMIN_LAN_10", "Lämna tomt för att visa hela rubriken");

define("LIST_ADMIN_LAN_11", "Postfix");
define("LIST_ADMIN_LAN_12", "Välj ett postfix att använda om rubriken överskrider angivet antal tecken");
define("LIST_ADMIN_LAN_13", "Lämna tomt för att inte använda postfix");

define("LIST_ADMIN_LAN_14", "Datum");
define("LIST_ADMIN_LAN_15", "Välj en datumstil");
define("LIST_ADMIN_LAN_16", "För mer information om datumformat, se <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funktionens</a> sida på php.net");

define("LIST_ADMIN_LAN_17", "Dagens datum");
define("LIST_ADMIN_LAN_18", "Välj datumstil om datumet är dagens datum");
define("LIST_ADMIN_LAN_19", "För mer information om datumformat, se <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funktionens</a> sida på php.net");

define("LIST_ADMIN_LAN_20", "Kolumner");
define("LIST_ADMIN_LAN_21", "Ange antal kolumner");
define("LIST_ADMIN_LAN_22", "Ange hur många kolumner du vill visa. Antalet du anger här kommer att dela sidan i så många kolumner");

define("LIST_ADMIN_LAN_23", "Hälsningstext");
define("LIST_ADMIN_LAN_24", "Ange en hälsningstext som kommer att visas högst upp på sidan");
define("LIST_ADMIN_LAN_25", "");

define("LIST_ADMIN_LAN_26", "Visa tomma");
define("LIST_ADMIN_LAN_27", "Ange om du vill att ett meddelande skall visas om en sektion inte har några resultat ");
define("LIST_ADMIN_LAN_28", "");

define("LIST_ADMIN_LAN_29", "Standardkula");
define("LIST_ADMIN_LAN_30", "Använd temats standardkula (bullet2.gif) om ingen kula angetts eller om 'Använd kula' är avaktiverad");
define("LIST_ADMIN_LAN_31", "");

define("LIST_ADMIN_LAN_32", "Tidspännvidd: Dagar");
define("LIST_ADMIN_LAN_33", "Maximum antal dagar en användare kan se bakåt");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dagar");

define("LIST_ADMIN_LAN_36", "Tidspännvidd");
define("LIST_ADMIN_LAN_37", "Visa en valruta med antale dagar att se tillbaka?");
define("LIST_ADMIN_LAN_38", "");

define("LIST_ADMIN_LAN_39", "öppna om det finns något listat");
define("LIST_ADMIN_LAN_40", "Ska sektioner som innehåller dokumentationer vara öppna som standard?");
define("LIST_ADMIN_LAN_41", "");

define("LIST_MENU_1", "Senaste tilläggen");
define("LIST_MENU_2", "av");
define("LIST_MENU_3", "den");
define("LIST_MENU_4", "under");
define("LIST_MENU_5", "dagar");
define("LIST_MENU_6", "visa innehåll under hur många dagar?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");

define("LIST_NEWS_1", "Nyheter");
define("LIST_NEWS_2", "Inga nyhetsobjekt");

define("LIST_COMMENT_1", "Kommentarer");
define("LIST_COMMENT_2", "Inga kommentarer");
define("LIST_COMMENT_3", "Nyheter");
define("LIST_COMMENT_4", "FAQ");
define("LIST_COMMENT_5", "Omröstning");
define("LIST_COMMENT_6", "Dokumentation");
define("LIST_COMMENT_7", "Buggspårning");
define("LIST_COMMENT_8", "Innehåll");
define("LIST_COMMENT_9", "Nedladdningar");
define("LIST_COMMENT_10", "Idéer");

define("LIST_DOWNLOAD_1", "Nedladdningar");
define("LIST_DOWNLOAD_2", "Inga nedladdningar");

define("LIST_MEMBER_1", "Medlemmar");
define("LIST_MEMBER_2", "Inga medlemmar");

define("LIST_CONTENT_1", "Innehåll");
define("LIST_CONTENT_2", "Inget innehåll i");
define("LIST_CONTENT_3", "ingen giltig innehållskategori");

define("LIST_CHATBOX_1", "Chattruta");
define("LIST_CHATBOX_2", "Inga inlägg i chattrutan");

define("LIST_CALENDAR_1", "Kalender");
define("LIST_CALENDAR_2", "Inga kalenderposter");

define("LIST_LINKS_1", "Länkar");
define("LIST_LINKS_2", "Inga länkar");

define("LIST_FORUM_1", "Forum");
define("LIST_FORUM_2", "Inga foruminlägg");
define("LIST_FORUM_3", "Visningar:");
define("LIST_FORUM_4", "Svar:");
define("LIST_FORUM_5", "Senaste inlägg:");
define("LIST_FORUM_6", "Den:");

?>