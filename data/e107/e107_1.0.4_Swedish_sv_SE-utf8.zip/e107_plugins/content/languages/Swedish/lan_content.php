<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("CONTENT_EMAILPRINT_LAN_1", "Detta innehåll kommer från");
define("POPUP_LAN_1", "Klicka för att förstora bilden");
define("CONTENT_NOTIFY_LAN_1", "Innehåll för händelser");
define("CONTENT_NOTIFY_LAN_2", "Innehållssidor inskickat av användare");
define("CONTENT_NOTIFY_LAN_3", "Innehåll inskickat");
define("CONTENT_TYPE_LAN_0", "Kategorier");
define("CONTENT_TYPE_LAN_1", "Författare");
define("CONTENT_TYPE_LAN_2", "Arkiv");
define("CONTENT_TYPE_LAN_3", "Högsta betyg från läsare");
define("CONTENT_TYPE_LAN_4", "Högsta betyg av författare");
define("CONTENT_TYPE_LAN_5", "Senaste innehållet");
define("CONTENT_ICON_LAN_0", "Redigera");
define("CONTENT_ICON_LAN_1", "Radera");
define("CONTENT_ICON_LAN_2", "Alternativ");
define("CONTENT_ICON_LAN_3", "Användardetaljer");
define("CONTENT_ICON_LAN_4", "Klicka för att hämta");
define("CONTENT_ICON_LAN_5", "Ny");
define("CONTENT_ICON_LAN_6", "Skicka innehåll");
define("CONTENT_ICON_LAN_7", "Författarlista");
define("CONTENT_ICON_LAN_8", "Varning");
define("CONTENT_ICON_LAN_9", "OK");
define("CONTENT_ICON_LAN_10", "FEL");
define("CONTENT_ICON_LAN_11", "Sortera sidor i kategori");
define("CONTENT_ICON_LAN_12", "Sortera sidor i typ");
define("CONTENT_ICON_LAN_13", "Personlig administratör");
define("CONTENT_ICON_LAN_14", "Personlig innehållshanterare");
define("CONTENT_ICON_LAN_15", "Visa");
define("CONTENT_ADMIN_DATE_LAN_0", "Januari");
define("CONTENT_ADMIN_DATE_LAN_1", "Februari");
define("CONTENT_ADMIN_DATE_LAN_2", "Mars");
define("CONTENT_ADMIN_DATE_LAN_3", "April");
define("CONTENT_ADMIN_DATE_LAN_4", "Maj");
define("CONTENT_ADMIN_DATE_LAN_5", "Juni");
define("CONTENT_ADMIN_DATE_LAN_6", "Juli");
define("CONTENT_ADMIN_DATE_LAN_7", "Augusti");
define("CONTENT_ADMIN_DATE_LAN_8", "September");
define("CONTENT_ADMIN_DATE_LAN_9", "Oktober");
define("CONTENT_ADMIN_DATE_LAN_10", "November");
define("CONTENT_ADMIN_DATE_LAN_11", "December");
define("CONTENT_ADMIN_DATE_LAN_12", "Dag");
define("CONTENT_ADMIN_DATE_LAN_13", "Månad");
define("CONTENT_ADMIN_DATE_LAN_14", "År");
define("CONTENT_ADMIN_DATE_LAN_15", "Startdatum");
define("CONTENT_ADMIN_DATE_LAN_16", "Slutdatum");
define("CONTENT_ADMIN_DATE_LAN_17", "Du kan ange ett startdatum för denna innehållssida. Om du anger ett framtida datum kommer innehållet att synas från det datumet och framåt. Om du inte behöver något specifikt startdatum, kan du lämna dessa fält som de är.");
define("CONTENT_ADMIN_DATE_LAN_18", "Du kan ange ett slutdatum för denna innehållssida. Med slutdatum definierar du fram till vilket datum posten skall visas. Om du inte behöver något specifikt slutdatum, kan du lämna dessa fält som de är.");
define("CONTENT_PAGETITLE_LAN_0", "Innehåll"); // sidrubrik
define("CONTENT_PAGETITLE_LAN_1", "Huvud");
define("CONTENT_PAGETITLE_LAN_2", "De senaste");
define("CONTENT_PAGETITLE_LAN_3", "Kategori");
define("CONTENT_PAGETITLE_LAN_4", "Högsta betyg av författare");
define("CONTENT_PAGETITLE_LAN_5", "Författare");
define("CONTENT_PAGETITLE_LAN_6", "Arkiv");
define("CONTENT_PAGETITLE_LAN_7", "Skicka");
define("CONTENT_PAGETITLE_LAN_8", "Skicka in innehållssida");
define("CONTENT_PAGETITLE_LAN_9", "Personlig innehållshanterare");
define("CONTENT_PAGETITLE_LAN_10", "Visa sidor");
define("CONTENT_PAGETITLE_LAN_11", "Redigera sidor");
define("CONTENT_PAGETITLE_LAN_12", "Skapa innehållssida"); 
define("CONTENT_PAGETITLE_LAN_13", "Kategorier");
define("CONTENT_PAGETITLE_LAN_14", "Författarlista");
define("CONTENT_PAGETITLE_LAN_15", "Högsta betyg från läsare");
define("CONTENT_SEARCH_LAN_0", "Inget innehåll hittades i vald avdelning med dessa nyckelord. Prova att göra en <a href=".e_BASE."search.php>fullständig webbplatssökning</a>.");
define("CONTENT_ORDER_LAN_0", "Sortera på ...");
define("CONTENT_ORDER_LAN_1", "Rubrik ▲");
define("CONTENT_ORDER_LAN_2", "Rubrik ▼");
define("CONTENT_ORDER_LAN_3", "Datum ▲");
define("CONTENT_ORDER_LAN_4", "Datum ▼");
define("CONTENT_ORDER_LAN_5", "Visningar ▲");
define("CONTENT_ORDER_LAN_6", "Visningar ▼");
define("CONTENT_ORDER_LAN_7", "Typ ▲");
define("CONTENT_ORDER_LAN_8", "Typ ▼");
define("CONTENT_ORDER_LAN_9", "Ordning ▲");
define("CONTENT_ORDER_LAN_10", "Ordning ▼");
define("CONTENT_ORDER_LAN_11", "Författare ▲");
define("CONTENT_ORDER_LAN_12", "Författare ▼");
define("CONTENT_LAN_0", "Innehåll"); // not used?
define("CONTENT_LAN_1", "Lista senaste");
define("CONTENT_LAN_2", "Kategorilista");
define("CONTENT_LAN_3", "Kategori");
define("CONTENT_LAN_4", "Författarlista");
define("CONTENT_LAN_5", "Författare");
define("CONTENT_LAN_6", "Alla kategorier");
define("CONTENT_LAN_7", "Alla författare");
define("CONTENT_LAN_8", "Högsta betyg från läsare");
define("CONTENT_LAN_9", "i");
define("CONTENT_LAN_10", "den");
define("CONTENT_LAN_11", "Författare");
define("CONTENT_LAN_12", "Högsta betyg av författare");
define("CONTENT_LAN_13", "Arkiv"); // content.php?list.
define("CONTENT_LAN_14", " 	-- Kategorier --");
define("CONTENT_LAN_15", "Inga författare ännu");
define("CONTENT_LAN_16", "[ Läs mer ]");
define("CONTENT_LAN_17", "");
define("CONTENT_LAN_18", "Sök på nyckelord");
define("CONTENT_LAN_19", "Sök");
define("CONTENT_LAN_20", "Sökresultat");
define("CONTENT_LAN_21", "Inga innehållstyper ännu.");
define("CONTENT_LAN_22", "Innehållstyper");
define("CONTENT_LAN_23", "Lista senaste innehåll");
define("CONTENT_LAN_24", "Brödsmulor");
define("CONTENT_LAN_25", "Typer");
define("CONTENT_LAN_26", "Typ");
define("CONTENT_LAN_27", "Kategorier");
define("CONTENT_LAN_28", "Kategori");
define("CONTENT_LAN_29", "Okänt");
define("CONTENT_LAN_30", "Innehållssida"); // singularis
define("CONTENT_LAN_31", "Innehållssidor"); // pluralis
define("CONTENT_LAN_32", "Författarlista");
define("CONTENT_LAN_33", "Gå till sidan");
define("CONTENT_LAN_34", "Innehåll 3");
define("CONTENT_LAN_35", "Kommentarer");
define("CONTENT_LAN_36", "Moderera kommentarer");
define("CONTENT_LAN_37", "Inga läsare har satt betyg ännu");
define("CONTENT_LAN_38", "Högsta betyg av författare");
define("CONTENT_LAN_39", "Författarlista");
define("CONTENT_LAN_40", "Författardetaljer");
define("CONTENT_LAN_41", "Ladda ned");
define("CONTENT_LAN_42", "bifogad fil");
define("CONTENT_LAN_43", "bifogade filer");
define("CONTENT_LAN_44", "Träffar:");
define("CONTENT_LAN_45", "Författarens poäng:");
define("CONTENT_LAN_46", "Innehåll 4");
define("CONTENT_LAN_47", "Författare");
define("CONTENT_LAN_48", "Innehållssidor"); // pluralis
define("CONTENT_LAN_49", "Senaste sida"); // singularis ?
define("CONTENT_LAN_50", "Datum");
define("CONTENT_LAN_51", "Typlista");
define("CONTENT_LAN_52", "Inga giltiga författare funna");
define("CONTENT_LAN_53", "sida"); // singularis lower case
define("CONTENT_LAN_54", "sidor"); // pluralis lower case
define("CONTENT_LAN_55", "Senaste ämne den");
define("CONTENT_LAN_56", "Navigator");
define("CONTENT_LAN_57", "Kommentarer:");
define("CONTENT_LAN_58", "Hem");
define("CONTENT_LAN_59", "Innehåll 5");
define("CONTENT_LAN_60", "Det senaste innehållet");
define("CONTENT_LAN_61", "Visa senaste sidor"); // pluralis
define("CONTENT_LAN_62", "Visa alla kategorier");
define("CONTENT_LAN_63", "Visa alla författare");
define("CONTENT_LAN_64", "Visa sidor med högsta författarbetyg"); // pluralis
define("CONTENT_LAN_65", "Skapa innehåll");
define("CONTENT_LAN_66", "Klicka här för att skapa innehåll, du kan välja kategori på insändarsidan.");
define("CONTENT_LAN_67", "Personlig innehållshanterare");
define("CONTENT_LAN_68", "Klicka här för att hantera ditt personliga innehåll.");
define("CONTENT_LAN_69", "E-posta");
define("CONTENT_LAN_70", "Skriv ut");
define("CONTENT_LAN_71", "innehållssidan"); // singularis lower case
define("CONTENT_LAN_72", "kategoribeskrivningen"); // singularis lower case
define("CONTENT_LAN_73", "Stigande ▲");
define("CONTENT_LAN_74", "Fallande ▼");
define("CONTENT_LAN_75", "Skicka in innehållssida");
define("CONTENT_LAN_76", "Skapa PDF-fil från");
define("CONTENT_LAN_77", "Sökning innehåll");
define("CONTENT_LAN_78", "Ingen rubrik");
define("CONTENT_LAN_79", "Del");
define("CONTENT_LAN_80", "De senaste sidorna:"); // pluralis
define("CONTENT_LAN_81", "Kategorier");
define("CONTENT_LAN_82", "Inga sidor ännu i"); // pluralis
define("CONTENT_LAN_83", "Sidarkiv"); // navigator
define("CONTENT_LAN_84", "sidor i arkiv"); // pluralis lower case
define("CONTENT_LAN_85", "Författarlista");
define("CONTENT_LAN_86", "Visa sidor med högsta författarbetyg");
define("CONTENT_LAN_87", "Innehåll med högsta författarbetyg");
define("CONTENT_LAN_88", "Inga innehållssidor har fått betyg ännu");
define("CONTENT_LAN_89", "Välj del");
define("CONTENT_LAN_90", "Föregående del");
define("CONTENT_LAN_91", "Nästa del");
define("CONTENT_LAN_92", " - Nuvarande del");
define("CONTENT_LAN_ALL", "Alla");
define("CONTENT_MENU_LAN_0", "Innehållsmeny :");
define("CONTENT_MENU_LAN_1", "Inga innehållssidor ännu");
define("CONTENT_MENU_LAN_2", "De senaste sidorna"); // pluralis
define("CONTENT_MENU_LAN_3", "Kategorier");
define("CONTENT_MENU_LAN_4", "Innehållslänkar");
define("CONTENT_MENU_LAN_5", "Inga sidor i");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");


?>