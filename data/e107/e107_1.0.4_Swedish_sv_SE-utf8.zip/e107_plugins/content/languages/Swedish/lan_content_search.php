<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Innehåll");
define("CONT_SCH_LAN_2", "Alla innehållskategorier");
define("CONT_SCH_LAN_3", "Postat som svar till objektet");
define("CONT_SCH_LAN_4", "i");

?>