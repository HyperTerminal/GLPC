<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("CONT_FP_1", "Innehållskategori");
define("CONT_FP_2", "Huvudsida");


?>