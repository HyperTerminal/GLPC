<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/newforumposts_main/languages/Swedish.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/01/24 12:42:35 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("NFPM_LAN_0", "Forum");
define("NFPM_LAN_1", "Tråd");
define("NFPM_LAN_2", "Författare");
define("NFPM_LAN_3", "Visningar");
define("NFPM_LAN_4", "Svar");
define("NFPM_LAN_5", "Senaste inlägg");
define("NFPM_LAN_6", "Trådar");
define("NFPM_LAN_7", "Av");
define("NFPM_LAN_8", "Forumstatistik");

define("NFPM_L1", "Detta program visar en lista med nya forumtrådar eller -inlägg inlägg på news.php");
define("NFPM_L2", "Senaste foruminlägg");
define("NFPM_L3", "För att konfigurera, klicka på länken på admins förstasida");
define("NFPM_L4", "Var ska rutan synas?");
define("NFPM_L5", "Inaktivera");
define("NFPM_L6", "På sidans början över nyhetsartiklarna");
define("NFPM_L7", "På sidans slut under nyhetsartiklarna");
define("NFPM_L8", "Ange rutans rubrik");
define("NFPM_L9", "Antal nya trådar eller inlägg att visa");
define("NFPM_L10", "Visa rutan i ett rullande lager");
define("NFPM_L11", "Lagrets höjd i pixlar ");
define("NFPM_L12", "Lista nya forumtrådar eller -inlägg på news.php");
define("NFPM_L13", "Uppdatera inställningarna");
define("NFPM_L14", "Inställningara uppdaterade");
define("NFPM_L15", "Markera för att visa senaste foruminlägg.<br />Lämna tomt för att visa senaste trådar (ämnen).");
define("NFPM_L16", "[användare raderad]");
define("NFPM_L17", "Nya poster på populära trådar");
define("NFPM_L18", "Nya poster");
define("NFPM_L19", "Inga nya poster på populära trådar");
define("NFPM_L20", "Inga nya poster");
define("NFPM_L21", "Låst tråd");
define("NFPM_L22", "Stängd låst tråd");
define("NFPM_L23", "Meddelande");
define("NFPM_L24", "Stängd tråd");


?>