<?php
/*
+ ----------------------------------------------------------------------------+
|    e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsletter/languages/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/04 18:28:51 $
|     $Author: e107coders $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("NLLAN_MENU_CAPTION", "Nyhetsbrev");
define("NLLAN_01", "Nyhetsbrev");
define("NLLAN_02", "Tillhandahåller ett snabbt och enkelt sätt att konfigurera och skicka nyhetsbrev.");
define("NLLAN_03", "Konfigurera nyhetsbrev");
define("NLLAN_04", "Programmet Nyhetsbrev har installerats. För att konfigurera, gå till admins huvudsida och klicka på 'Nyhetsbrev' i programhanteraren.");
define("NLLAN_05", "Inga nyhetsbrev definierade ännu");
define("NLLAN_06", "Namn");
define("NLLAN_07", "Prenumeranter");
define("NLLAN_08", "Alternativ");
define("NLLAN_09", "Är du säker på att du vill radera detta nyhetsbrev?");
define("NLLAN_10", "Befintliga nyhetsbrev");
define("NLLAN_11", "Inga utgåvor av nyhetsbrev ännu");
define("NLLAN_12", "Utgåva");
define("NLLAN_13", "[ Värd ID ] Utskicksrubrik");
define("NLLAN_14", "Skickade?");
define("NLLAN_15", "Alternativ");
define("NLLAN_16", "ja");
define("NLLAN_17", "Ej utskickat - klicka för att skicka");
define("NLLAN_18", "Är du säker på att du vill skicka denna utgåva till prenumeranterna?");
define("NLLAN_19", "Är du säker på att du vill radera denna utgåva av nyhetsbrevet?");
define("NLLAN_20", "Befintliga utgåvor");
define("NLLAN_21", "Rubrik ( utskickets rubrik läggs till bakom denna )");
define("NLLAN_22", "Beskrivning ( visas i menyn )");
define("NLLAN_23", "Sidhuvud");
define("NLLAN_24", "Sidfot");
define("NLLAN_25", "Uppdatera nyhetsbrev");
define("NLLAN_26", "Skapa nyhetsbrev");
define("NLLAN_27", "Nyhetsbrev uppdaterat i databasen.");
define("NLLAN_28", "Nyhetsbrev definierat och sparat i databasen.");
define("NLLAN_29", "Inga nyhetsbrev definierade ännu.");
define("NLLAN_30", "Nyhetsbrev");
define("NLLAN_31", "Utskicksrubrik ( hamnar bakom det du väljer ovan )");
define("NLLAN_32", "Utgåva nummer");
define("NLLAN_33", "Text ( hamnar mellan nyhetsbrevets sidhuvud och sidfot )");
define("NLLAN_34", "Uppdatera utskick");
define("NLLAN_35", "Skapa utskick");
define("NLLAN_36", "Uppdatera utgåva av nyhetsbrev");
define("NLLAN_37", "Skapa utgåva av nyhetsbrev");
define("NLLAN_38", "Nyhetsbrev uppdaterat i databasen.");
define("NLLAN_39", "Nyhetsbrevsutgåva sparad i databasen - för att skicka ut, klicka på knappen ".NLLAN_17);
define("NLLAN_40", "Utskick avslutat - utgåvan sänd till ");
define("NLLAN_40", "Nyhetsbrevet färdigställt - utskicket sänt till ");
define("NLLAN_41", " prenumerant(er).");
define("NLLAN_42", "Nyhetsbrev raderat.");
define("NLLAN_43", "Nyhetsbrevsutgåva raderad.");
define("NLLAN_44", "Nyhetsbrev förstasida");
define("NLLAN_45", "Skapa nyhetsbrev");
define("NLLAN_46", "Skapa utskick");
define("NLLAN_47", "Nyhetsbrev alternativ");
define("NLLAN_48", "Du prenumererar på detta nyhetsbrev - om du vill avbryta prenumerationen, klicka på knappen nedan.");
define("NLLAN_49", "Är du säker på att du vill avbryta prenumerationen på detta nyhetsbrev?");
define("NLLAN_50", "Klicka på knappen för att prenumerera (din prenumerationsadress är");
define("NLLAN_51", "Avbryt prenumeration");
define("NLLAN_52", "Prenumerera");
define("NLLAN_53", "Är du säker på att du vill prenumerera på detta nyhetsbrev?");
define("NLLAN_54", "Skickar");
define("NLLAN_55", "ID");
define("NLLAN_56", "Nyhetsbrev-ID ej tillgänglig");
define("NLLAN_57", "Tillbaka till förra sidan");
define("NLLAN_58", "Fel");
define("NLLAN_59", "Namn");
define("NLLAN_60", "E-post");
define("NLLAN_61", "Åtgärder");
define("NLLAN_62", "Användaren är blockerad eller inte fullt registrerad.");
define("NLLAN_63", "Totalt antal prenumeranter");
define("NLLAN_64", "Tillbaka till förstasidan för nyhetsbrev");
define("NLLAN_65", "Översikt över prenumeranter");


?>