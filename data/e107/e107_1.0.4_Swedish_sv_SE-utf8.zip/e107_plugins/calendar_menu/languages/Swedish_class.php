<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/usersettings.php $
 * $Id: usersettings.php 11645 2010-08-01 12:57:11Z e107coders $
 */

/**
 *	e107 Event calendar plugin
 *
 *	Language file - anything called up in ecal_class.php and similar
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: Swedish_class.php 11315 2010-02-10 18:18:01Z secretr $;
 */

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'nummer');
define('EC_LAN_RECUR_01', 'årligen');
define('EC_LAN_RECUR_02', 'vartannat år');
define('EC_LAN_RECUR_03', 'kvartalsvis');
define('EC_LAN_RECUR_04', 'månatligen');
define('EC_LAN_RECUR_05', 'var fjärde vecka');
define('EC_LAN_RECUR_06', 'tvåveckorsintervall');
define('EC_LAN_RECUR_07', 'veckovis');
define('EC_LAN_RECUR_08', 'dagligen');
define('EC_LAN_RECUR_100', 'Söndagen i månaden');
define('EC_LAN_RECUR_101', 'Måndagen i månaden');
define('EC_LAN_RECUR_102', 'Tisdagen i månaden');
define('EC_LAN_RECUR_103', 'Onsdagen i månaden');
define('EC_LAN_RECUR_104', 'Torsdagen i månaden');
define('EC_LAN_RECUR_105', 'Fredagen i månaden');
define('EC_LAN_RECUR_106', 'Lördagen i maånaden');

define('EC_LAN_RECUR_1100', 'Första');
define('EC_LAN_RECUR_1200', 'Andra');
define('EC_LAN_RECUR_1300', 'Tredje');
define('EC_LAN_RECUR_1400', 'Fjärde');


// Notify
define('NT_LAN_EC_1', 'Evenemangskalender händelser');
define('NT_LAN_EC_2', 'Händelse uppdaterad');
define('NT_LAN_EC_3', 'Uppdaterad av');
define('NT_LAN_EC_4', 'IP Adress');
define('NT_LAN_EC_5', 'Meddelande');
define('NT_LAN_EC_6', 'Evenemangskalender - Händelse tillagd');
define('NT_LAN_EC_7', 'Ny händelse postad');
define('NT_LAN_EC_8', 'Evenemangskalender - Händelse modifierad');


// Log messages
define('EC_ADM_01', 'Evenemangskalender - Lägg till händelse');
define('EC_ADM_02', 'Evenemangskalender - Redigera händelse');
define('EC_ADM_03', 'Evenemangskalender - Radera händelse');
define('EC_ADM_04', 'Evenemangskalender - Massradera');
define('EC_ADM_05', 'Evenemangskalender - Lägg till flera');
define('EC_ADM_06', 'Evenemangskalender - Huvudinställningar ändrade');
define('EC_ADM_07', 'Evenemangskalender - FE inställningar ändrade');
define('EC_ADM_08', 'Evenemangskalender - Kategori tillagd');
define('EC_ADM_09', 'Evenemangskalender - Kategori redigerad');
define('EC_ADM_10', 'Evenemangskalender - Kategori raderad');
define('EC_ADM_11', 'Evenemangskalender - Gamla händelser raderade');


?>