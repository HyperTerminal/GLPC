<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("CM_L1", "Inga kommentarer ännu.");
define("CM_L2", "");
define("CM_L3", "Rubrik");
define("CM_L4", "Antal kommentarer att visa?");
define("CM_L5", "Antal tecken att visa?");
define("CM_L6", "Tillägg för för långa kommentarer?");
define("CM_L7", "Visa originalrubrik i meny?");
define("CM_L8", "Menykonfiguration för nya kommentarer");
define("CM_L9", "Uppdatera menyinställningar");
define("CM_L10", "Kommentarsmenyns konfiguration sparad");
define("CM_L11", "den");
define("CM_L12", "Svar:");
define("CM_L13", "Postat av");
?>