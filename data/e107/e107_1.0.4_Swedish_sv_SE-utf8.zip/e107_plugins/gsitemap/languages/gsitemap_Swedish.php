<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/gsitemap/languages/gsitemap_English.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/04/15 17:43:12 $
|     $Author: e107coders $
|     $Swedish translation edited by: hanssonsde $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Webbplatskarta");
define("GSLAN_1", "Webbplatslänk");
define("GSLAN_2", "Importera?");
define("GSLAN_3", "Typ");
define("GSLAN_4", "Namn");
define("GSLAN_5", "URL");
define("GSLAN_6", "Markera de länkar som skall importeras...");
define("GSLAN_7", "Importera länkar");
define("GSLAN_8", "Importera med:");
define("GSLAN_9", "Prioritet");
define("GSLAN_10", "Frekvens");
define("GSLAN_11", "alltid");
define("GSLAN_12", "varje timme");
define("GSLAN_13", "dagligen");
define("GSLAN_14", "varje vecka");
define("GSLAN_15", "varje månad");
define("GSLAN_16", "varje år");
define("GSLAN_17", "aldrig");
define("GSLAN_18", "Importera markerade länkar");
define("GSLAN_19", "Google Webbplatskarta");
define("GSLAN_20", "Listning");
define("GSLAN_21", "Instruktioner");
define("GSLAN_22", "Skapa nytt inlägg");
define("GSLAN_23", "Importera");
define("GSLAN_24", "Inlägg för Google Webbplatskarta");
define("GSLAN_25", "Namn");
define("GSLAN_26", "URL");
define("GSLAN_27", "Senast modererad");
define("GSLAN_28", "Frekvens.");
define("GSLAN_29", "Konfiguration för Google Webbplatskarta");
define("GSLAN_30", "Visa ordning");
define("GSLAN_31", "Synlig för");
define("GSLAN_32", "Hur man avänder Google Webbplatskartor");
define("GSLAN_33", "Instruktioner för GSiteMap");
define("GSLAN_34", "Först skapar du länkar som du vill ha i din webbplatskarta. Du kan importera de flesta av dina länkar genom att klicka på knappen 'Importera' på sidan");
define("GSLAN_35", "Om du har valt att importera dina länkar, klicka på 'Importera' och sedan markerar du vilka länkar du vill importera");
define("GSLAN_36", "Du kan också välja att importera länkar manuellt genom att klicka på 'Skapa nytt inlägg'");
define("GSLAN_37", "När du har några inlägg, gå till [URL] och skriv in följande webbadress [URL2]  om den ovanstående webbadressen inte ser rätt ut för dig, var vänlig och kontrollera att din webbplats webbadress är korrekt i admin -> [preferences]");
define("GSLAN_38", "För mer information om Google Sitemap protocol, gå till [URL]");
define("GSLAN_39", "Inga länkar i webbplatskartan - vill du importera webbplatslänkar?");
define("GSLAN_40", "inlägg för Google webbplatskarta ");


?>