<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/poll/languages/Swedish.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/23 15:11:19 $
|        $Author: Hanssons.de $
+---------------------------------------------------------------+
*/

define("POLL_ADLAN01", "Omröstning");
define("POLL_ADLAN02", "Omröstningsfunktionen tillåter dig att definiera en omröstning i antingen en meny eller i en forumpost.");
define("POLL_ADLAN03", "Konfigurera omröstningar");
define("POLL_ADLAN04", "Omröstningsfunktionen har installerats. För att lägga till omröstningar, klicka på ikonen 'Omröstningar' i pluginsektionen på din administratörssida; kom ihåg att aktivera menyobjektet på menysidan.");
define("POLL_ADLAN05", "Huvudomröstning");
define("POLL_ADLAN06", "Forumtråd");
define("POLL_ADLAN07", "Typ");
define("POLLAN_MENU_CAPTION", "Omröstning");
define("POLLAN_1", "Befintliga omröstningar");
define("POLLAN_2", "Skapa/redigera omröstning");
define("POLLAN_3", "Omröstningsfråga");
define("POLLAN_4", "Alternativ");
define("POLLAN_5", "Redigera");
define("POLLAN_6", "Radera");
define("POLLAN_7", "Inga omröstningar ännu");
define("POLLAN_8", "Lägg till ett alternativ");
define("POLLAN_9", "Tillåt flervalsalternativ?");
define("POLLAN_10", "Ja");
define("POLLAN_11", "Nej");
define("POLLAN_12", "Visa resultat");
define("POLLAN_13", "efter omröstning");
define("POLLAN_14", "genom att klicka på länken 'se resultat'; kommentarer måste vara aktiverade för att använda det här alternativet.");
define("POLLAN_15", "Vilken användarklass tillåts delta i denna omröstning?");
define("POLLAN_16", "Lagringmetod för omröstning");
define("POLLAN_17", "Kaka (cookie)");
define("POLLAN_18", "IP-adress");
define("POLLAN_19", "Användar-ID (endast medlemmar kan rösta)");
define("POLLAN_20", "Tillåt kommentarer på denna omröstning?");
define("POLLAN_21", "Förhandsgranska igen");
define("POLLAN_22", "Uppdatera omröstning");
define("POLLAN_23", "Skapa omröstning");
define("POLLAN_24", "Förhandsgranska");
define("POLLAN_25", "Rensa formulär");
define("POLLAN_26", "Antal röster");
define("POLLAN_27", "Kommentarer");
define("POLLAN_28", "Föregående omröstningar");
define("POLLAN_29", "Postat av");
define("POLLAN_30", "Skicka");
define("POLLAN_31", "Röster");
define("POLLAN_32", "Klicka här för att se resultat");
define("POLLAN_33", "Inga föregående omröstningar ännu");
define("POLLAN_34", "Rubrik");
define("POLLAN_35", "Postad av");
define("POLLAN_36", "Aktiv");
define("POLLAN_37", "Aktiv från");
define("POLLAN_38", "tills");
define("POLLAN_39", "Tack för din röst");
define("POLLAN_40", "Klicka här för att se resultat");
define("POLLAN_41", "Denna omröstning är begränsad till enbart medlemmar");
define("POLLAN_42", "Denna omröstning är begränsad till enbart administratörer");
define("POLLAN_43", "Du har inte behörighet att rösta i denna omröstning");
define("POLLAN_44", "Radera denna omröstning?");
define("POLLAN_45", "Omröstning uppdaterad");
define("POLLAN_46", "Obligatoriska fält har lämnats tomma");


?>