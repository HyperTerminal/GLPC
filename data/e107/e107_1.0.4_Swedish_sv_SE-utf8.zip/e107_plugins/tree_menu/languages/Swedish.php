<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/tree_menu/languages/Swedish.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "Konfigurera trädmeny");
define("TREE_L2", "Uppdatera inställningar för trädmeny");
define("TREE_L3", "Trädemenykonfiguration sparad.");
define("TREE_L4", "På");
define("TREE_L5", "Av");
define("TREE_L6", "CSS klass att använda på icke-öppningsbara länkar");
define("TREE_L7", "CSS klass att använda på öppningsbara länkar");
define("TREE_L8", "CSS klass att använda på öppna länkar");
define("TREE_L9", "Använd utrymme mellan huvudlänkar");


?>