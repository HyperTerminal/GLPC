<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/alt_auth/languages/Swedish/lan_ldap_auth.php $
|        $Revision: 1.0 $
|        $Date: 2010/05/26 21:16:54 $
|        $Author: administrator $
+---------------------------------------------------------------+
*/

define("LDAPLAN_1", "Serveradress");
define("LDAPLAN_2", "Base DN eller Domän<br />If LDAP - Skriv in BaseDN<br />If AD - Skriv in domän");
define("LDAPLAN_3", "LDAP Browsing user<br />Fult innehåll av användaren som kan söka i katalogen.");
define("LDAPLAN_4", "LDAP Browsing password<br />Lösenord för LDAP Browsing Användaren.");
define("LDAPLAN_5", "LDAP Version");
define("LDAPLAN_6", "Konfigurera LDAP auth");
define("LDAPLAN_7", "eDirectory sökfilter:");
define("LDAPLAN_8", "Detta kommer att användas för att säkerställa användarnamnet är i rätt träd, <br />ie '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Nuvarande sökfilter kommer vara:");
define("LDAPLAN_10", "Inställningar uppdaterade");
define("LDAPLAN_11", "VARNING: Det verkar som om LDAP-modulen inte finns tillgänglig för närvarande, att ställa in auth metod för att LDAP kommer antagligen inte att fungera!");
define("LDAPLAN_12", "Servertyp");
define("LDAPLAN_13", "Uppdatera inställningar");


?>