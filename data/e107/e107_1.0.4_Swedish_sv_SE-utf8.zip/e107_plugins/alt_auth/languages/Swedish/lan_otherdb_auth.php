<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/alt_auth/languages/Swedish/lan_otherdb_auth.php $
|        $Revision: 1.0 $
|        $Date: 2010/05/26 21:18:59 $
|        $Author: knutars $
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Databastyp:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Användarnamn:");
define("OTHERDB_LAN_4", "Lösenord:");
define("OTHERDB_LAN_5", "Databas:");
define("OTHERDB_LAN_6", "Tabell:");
define("OTHERDB_LAN_7", "Fält för användarnamn:");
define("OTHERDB_LAN_8", "Fält för lösenord:");
define("OTHERDB_LAN_9", "Metod för lösenord:");
define("OTHERDB_LAN_10", "Konfigurera autentisering via annan databas ( otherdb )");
define("OTHERDB_LAN_11", "** Fälten nedan är inte obligatoriska om en e107 databas används");


?>