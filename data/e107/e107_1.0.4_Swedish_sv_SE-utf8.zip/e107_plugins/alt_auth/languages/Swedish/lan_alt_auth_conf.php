<?php
/*
+---------------------------------------------------------------+
|        e107 website system Swedish Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../e107_plugins/alt_auth/languages/Swedish/lan_alt_auth_conf.php $
|        $Revision: 1.0 $
|        $Date: 2010/09/09 07:35:15 $
|        $Author: knutars $
+---------------------------------------------------------------+
*/
define("LAN_ALT_2", "Uppdatera inställningar");
define("LAN_ALT_3", "Välj alternativ authentiseringstyp");
define("LAN_ALT_4", "Konfigurera parametrar för");
define("LAN_ALT_5", "Konfigurera authentiseringstyps parametrar");
define("LAN_ALT_6", "Åtgärder vid misslyckad anslutning");
define("LAN_ALT_7", "Om anslutning till den alternativa metoden inte fungerar, hur ska detta hanteras?");
define("LAN_ALT_8", "Ågärder om användaren inte hittas");
define("LAN_ALT_9", "Om användarnamnet inte finns med när alternativ metod används, hur ska detta hanteras?");
define("LAN_ALT_10", "Misslyckad nloggning");
define("LAN_ALT_11", "Använd e107 användartabell");
define("LAN_ALT_PAGE", "Alternativ autentisering");


?>