<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("BLOGCAL_L1", "Nyhetsartiklar för ");
define("BLOGCAL_L2", "Artikelarkiv");

define("BLOGCAL_D1", "Mån");
define("BLOGCAL_D2", "Tis");
define("BLOGCAL_D3", "Ons");
define("BLOGCAL_D4", "Tor");
define("BLOGCAL_D5", "Fre");
define("BLOGCAL_D6", "Lör");
define("BLOGCAL_D7", "Sön");

define("BLOGCAL_M1", "Januari");
define("BLOGCAL_M2", "Februari");
define("BLOGCAL_M3", "Mars");
define("BLOGCAL_M4", "April");
define("BLOGCAL_M5", "Maj");
define("BLOGCAL_M6", "Juni");
define("BLOGCAL_M7", "Juli");
define("BLOGCAL_M8", "Augusti");
define("BLOGCAL_M9", "September");
define("BLOGCAL_M10", "Oktober");
define("BLOGCAL_M11", "November");
define("BLOGCAL_M12", "December");

define("BLOGCAL_1", "Nyhetsartiklar");

define("BLOGCAL_CONF1", "Månader / rad");
define("BLOGCAL_CONF2", "Cellutfyllnad");
define("BLOGCAL_CONF3", "Uppdatera menyinställningarna");
define("BLOGCAL_CONF4", "Nyhetsartikelarkiv menykonfiguration");
define("BLOGCAL_CONF5", "Menykonfiguration för nyhetsartikelarkiv sparad");

define("BLOGCAL_ARCHIV1", "Välj år");

?>