<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Annonsering");
define("BANNER_MENU_L2", "Konfiguration för Bannermeny sparad");

//v.617
define("BANNER_MENU_L3", "Rubrik");
define("BANNER_MENU_L4", "Kampanj");
define("BANNER_MENU_L5", "Bannermeny konfiguration");
define("BANNER_MENU_L6", "välj kampanjer att visa i meny");
define("BANNER_MENU_L7", "tillgängliga kampanjer");
define("BANNER_MENU_L8", "valda kampanjer");
define("BANNER_MENU_L9", "ta bort urval");
define("BANNER_MENU_L10", "hur skall valda kampanjer visas?");
define("BANNER_MENU_L11", "välj visningstyp...");
define("BANNER_MENU_L12", "en kampanj i en meny");
define("BANNER_MENU_L13", "alla valda kampanj i en meny");
define("BANNER_MENU_L14", "alla valda kamanjer i separata menyer");
define("BANNER_MENU_L15", "hur många banners skall visas?");
define("BANNER_MENU_L16", "denna inställning används bara med valen 2 and 3.<br />om det finns färre banners än detta maxvärde kommer alla tillgängliga banners att användas.");
define("BANNER_MENU_L17", "ställ in antal...");
define("BANNER_MENU_L18", "Uppdatera menyinställningarna");

?>