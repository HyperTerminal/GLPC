<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_plugins/log/languages/admin/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/26 11:12:24 $
|     $Author: mrpiercer $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("ADSTAT_ON", "Till");
define("ADSTAT_OFF", "Från");
define("ADSTAT_L1", "Detta program loggar alla besök till din webbplats och bygger detaljerade statistikbilder baserade på den insamlade informationen.");
define("ADSTAT_L2", "Statistikloggaren har installerats. För att aktivera, gå till konfigurationssidan och välj Aktivera statistikloggning.<br /><b>Du måste sätta filrättigheterns för katalogen e107_plugins/log/logs till 777 (chmod 777)</b>");
define("ADSTAT_L3", "Statistikloggning");
define("ADSTAT_L4", "Aktivera statistikloggning");
define("ADSTAT_L5", "Statistiktyper");
define("ADSTAT_L6", "Webbläsare");
define("ADSTAT_L7", "Operativsystem");
define("ADSTAT_L8", "Skärmupplösningar / färgdjup");
define("ADSTAT_L9", "Besök från länder / domäner");
define("ADSTAT_L10", "Hänvisare");
define("ADSTAT_L11", "Sökfrågor");
define("ADSTAT_L12", "Nollställ stats");
define("ADSTAT_L13", "detta raderar stats - var försiktig!");
define("ADSTAT_L14", "Sidräknare");
define("ADSTAT_L15", "Uppdatera statistikinställningar");
define("ADSTAT_L16", "Inställningar för webbplatsstatistik");
define("ADSTAT_L17", "Statistikinställningar uppdaterade");
define("ADSTAT_L18", "Tillåt åtkomst till huvudstatistiksidan för...");
define("ADSTAT_L19", "Senaste besökare");
define("ADSTAT_L20", "Räkna administratörsbesök");
define("ADSTAT_L21", "Maximalt antal poster att visa på statistiksidan");
define("ADSTAT_L22", "Kör uppdateringsrutin");
define("ADSTAT_L23", "Loggar från en tidigare version av e107 har hittats, uppdatera dem här.");
define("ADSTAT_L24", "Gå till uppdateringsskriptet");
define("ADSTAT_L25", "Vald statistik nollställd");
define("ADSTAT_L26", "Radera sidposter");
define("ADSTAT_L27", "Om din statistik har felaktiga sidor kan du ta bort dem här");
define("ADSTAT_L28", "Öppna sida");
define("ADSTAT_L29", "Sidonamn");
define("ADSTAT_L30", "Markera för att ta bort");
define("ADSTAT_L31", "Ta bort valda sidor");
define("ADSTAT_L32", "Städa sidor");
define("ADSTAT_L33", "Konfigurera Statistikloggning");
define("ADSTAT_L34", "Webbplatsstatistik");
define("ADSTAT_L35", "Visa komprimerad webbläsarinformation i statistiken");
define("ADSTAT_L38", "Du måste ändra katalogen e107_plugins/log/logs så den blir skrivbar");


?>