<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Klockmenykonfiguration sparad");
define("CLOCK_AD_L2", "Rubrik");
define("CLOCK_AD_L3", "Uppdatera menyinställninar");
define("CLOCK_AD_L4", "Klockmenykonfiguration");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Om markerad kommer tid att visas i amerikanskt format (0-12 AM/PM format). Avmarkerad så visas 'militärt/Europeiskt' format 0-24.");
define("CLOCK_AD_L7", "Datumprefix");
define("CLOCK_AD_L8", "Om ditt språk kräver ett kort ord framför datumet (T.ex 'le' på franska eller 'den' för Tyska...), så använd detta fältet. Om inte det behövs, lämna fältet tomt.");
define("CLOCK_AD_L9", "Suffix 1");
define("CLOCK_AD_L10", "Suffix 2");
define("CLOCK_AD_L11", "Suffix 3");
define("CLOCK_AD_L12", "Suffix 4 och mer");
define("CLOCK_AD_L13", "Om ditt språk behöver ett suffix direkt efter datumets siffror, fyll då i dessa fält med bara suffixen. (T.ex: 'st' på 1, 'nd' på 2, 'rd' på 3 och 'th' på 4 och så vidare - för Engelska användare ). Om inte det behövs, lämna fältet tomt.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");
?>