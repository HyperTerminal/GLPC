<?php
/**
 * $Swedish translation: hanssons.de $
 */

$lang_ibrowser_title= 'Infoga / redigera bild';
$lang_ibrowser_desc= 'Infoga / redigera bild';
$lang_ibrowser_library= 'Bibliotek';
$lang_ibrowser_preview= 'Förhandsgranska';
$lang_ibrowser_img_sel= 'Bildval';
$lang_ibrowser_img_info= 'Bildinformation';
$lang_ibrowser_img_upload= 'Bilduppladdning';
$lang_ibrowser_images= 'Bilder';
$lang_ibrowser_src= 'Källa';
$lang_ibrowser_alt= 'Beskrivning';
$lang_ibrowser_size= 'Storlek';
$lang_ibrowser_align= 'Textflöde';
$lang_ibrowser_height= 'Höjd';
$lang_ibrowser_width= 'Bredd';
$lang_ibrowser_reset= 'Återställ Mått';
$lang_ibrowser_border= 'Kant';
$lang_ibrowser_hspace= 'Mellanrum horisontellt';
$lang_ibrowser_vspace= 'Mellanrum vertikalt';
$lang_ibrowser_select= 'Spara';
$lang_ibrowser_delete= 'Radera';
$lang_ibrowser_cancel= 'Avbryt';
$lang_ibrowser_uploadtxt= 'Fil';
$lang_ibrowser_uploadbt= 'Uppladdning';
$lang_ibrowser_marginl = 'Marginal-Vänster';
$lang_ibrowser_marginr = 'Marginal-Höger';
$lang_ibrowser_margint = 'Marginal-Topp';
$lang_ibrowser_marginb = 'Marginal-Botten';
$lang_insert_image_align_default = "Standard";
$lang_insert_image_align_left = "Vänster";
$lang_insert_image_align_right = "Höger";

// Felmeddelanden
$lang_ibrowser_error= 'Fel';
$lang_ibrowser_errornoimg= 'Var vänlig välj en bild';
$lang_ibrowser_errornodir= 'Biblioteket existerar inte fysiskt';
$lang_ibrowser_errorupload= 'Ett fel uppstod vid hantering av filöverföring. \n Vänligen försök igen senare';
$lang_ibrowser_errortype= 'Fel filtyp på bildfilen';
$lang_ibrowser_errordelete= 'Radering misslyckades';
$lang_ibrowser_confirmdelete= 'Klicka på OK för att radera bilden!';
$lang_ibrowser_error_width_nan= 'Bredden är inte ett nummer!';
$lang_ibrowser_error_height_nan= 'Höjden är inte ett nummer!';
$lang_ibrowser_error_border_nan= 'Kant är inte ett nummer!';
$lang_ibrowser_error_hspace_nan= 'Horisontellt mellanrum är inte ett nummer!';
$lang_ibrowser_error_vspace_nan= 'Vertikalt mellanrum är inte ett nummer!';

?>