// SV spr�kvariabler
tinyMCE.addI18n('sv.ibrowser',{
	desc : 'Bildl�sare'
});