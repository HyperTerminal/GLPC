tinyMCE.addI18n('sv.paste_dlg',{
text_title:"Anv�nd ctrl-v p� ditt tangentbord f�r att klistra in i detta f�nster.",
text_linebreaks:"Spara radbrytningar",
word_title:"Anv�nd ctrl-v p� ditt tangentbord f�r att klistra in i detta f�nster."
});