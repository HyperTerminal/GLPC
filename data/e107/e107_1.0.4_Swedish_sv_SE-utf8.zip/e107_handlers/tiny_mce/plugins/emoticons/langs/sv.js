tinyMCE.addI18n('sv.emoticons',{
desc:"Infoga smileys",
});