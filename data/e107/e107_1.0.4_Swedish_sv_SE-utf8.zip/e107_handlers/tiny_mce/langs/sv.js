﻿tinyMCE.addI18n({sv:{
common:{
edit_confirm:"Vill du använda WYSIWYG för denna textarea?",
apply:"Applicera",
insert:"Infoga",
update:"Uppdatera",
cancel:"Avbryt",
close:"Stäng",
browse:"Bläddra",
class_name:"Klass",
not_set:"-- Inte satt --",
clipboard_msg:"Kopiera/klipp ut/klistra in är inte tillgängligt i din webbläsare.\nVill du veta mer?",
clipboard_no_support:"Funktionen är inte tillgänglig i din webbläsare, använd tangentbordsgenvägarna i stället.",
popup_blocked:"Popup blockerare detekterad. Stäng av den så att dialogerna kan öppnas.",
invalid_data:"Fel: Inkorrekta värden har matats in, dessa är markerade i rött.",
more_colors:"Fler färger"
},
contextmenu:{
align:"Justering",
left:"Vänster",
center:"Centrerad",
right:"Höger",
full:"Utfyllnad"
},
insertdatetime:{
date_fmt:"%Y-%m-%d ",
time_fmt:"%H:%M:%S",
insertdate_desc:"Infoga datum",
inserttime_desc:"Infoga tid",
months_long:"Januari,Februari,Mars,April,Maj,Juni,Juli,Augusti,September,Oktober,November,December",
months_short:"Jan,Feb,Mar,Apr,Maj,Jun,Jul,Aug,Sep,Okt,Nov,Dec",
day_long:"Söndag,Måndag,Tisdag,Onsdag,Torsdag,Fredag,Lördag,Söndag",
day_short:"Sön,Mån,Tis,Ons,Tors,Fre,Lör,Sön"
},
print:{
print_desc:"Skriv ut"
},
preview:{
preview_desc:"Förhandsgranska"
},
directionality:{
ltr_desc:"Skriftläge - vänster till höger",
rtl_desc:"Skriftläge - höger till vänster"
},
layer:{
insertlayer_desc:"Infoga nytt lager",
forward_desc:"Flytta framåt",
backward_desc:"Flytta bakåt",
absolute_desc:"Slå av/på absolut positionering",
content:"Nytt lager..."
},
save:{
save_desc:"Spara",
cancel_desc:"Hoppa över alla förändringar"
},
nonbreaking:{
nonbreaking_desc:"Infoga icke radbrytande mellanslag"
},
iespell:{
iespell_desc:"Rättstava",
download:"ieSpell kunde inte hittas, vill du installera denna nu?"
},
advhr:{
advhr_desc:"Horisontell skiljelinje"
},
emotions:{
emotions_desc:"Smileys"
},
searchreplace:{
search_desc:"Sök",
replace_desc:"Sök/ersätt"
},
advimage:{
image_desc:"Infoga/redigera bild"
},
advlink:{
link_desc:"Infoga/redigera länk"
},
xhtmlxtras:{
cite_desc:"citat",
abbr_desc:"Förkortning",
acronym_desc:"Akronym",
del_desc:"Markera som struket",
ins_desc:"Markera som tillagt",
attribs_desc:"Redigera attribut"
},
style:{
desc:"Redigera inline CSS"
},
paste:{
paste_text_desc:"Klistra in som text",
paste_word_desc:"Klistra in från Word",
selectall_desc:"Markera allt"
},
paste_dlg:{
text_title:"Använd ctrl-v på ditt tangentbord för att klistra in i detta fönster.",
text_linebreaks:"Spara radbrytningar",
word_title:"Använd ctrl-v på ditt tangentbord för att klistra in i detta fönster."
},
table:{
desc:"Infoga/redigera ny tabell",
row_before_desc:"Infoga ny rad före",
row_after_desc:"Infoga ny rad efter",
delete_row_desc:"Radera rad",
col_before_desc:"Infoga kolumn före",
col_after_desc:"Infoga kolumn efter",
delete_col_desc:"Radera kolumn",
split_cells_desc:"Separera sammansatta celler",
merge_cells_desc:"Sammanfoga celler",
row_desc:"Tabellradsinställningar",
cell_desc:"Tabellcellsinställningar",
props_desc:"Tabellinställningar",
paste_row_before_desc:"Klistra in rad ovanför",
paste_row_after_desc:"Klistra in rad efter",
cut_row_desc:"Klipp ut rad",
copy_row_desc:"Klistra in rad",
del:"Radera tabell",
row:"Rad",
col:"Kolumn",
cell:"Cell"
},
autosave:{
unload_msg:"De förändringar som du gjort kommer att gå förlorade om du lämnar sidan."
},
fullscreen:{
desc:"Slå av/på fullskärmsläge"
},
media:{
desc:"Infoga/redigera inbäddad media",
edit:"Redigera inbäddad media"
},
fullpage:{
desc:"Dokumentinställningar"
},
template:{
desc:"Infoga en färdig mall"
},
visualchars:{
desc:"Visa osynliga tecken"
},
spellchecker:{
desc:"Slå av/på rättstavningskontroll",
menu:"Rättstavningsinställningar",
ignore_word:"Ignorera ord",
ignore_words:"Ignorera alla",
langs:"Språk",
wait:"Var god vänta...",
sug:"Förslag",
no_sug:"Inga förslag",
no_mpell:"Inga felstavningar funna."
},
pagebreak:{
desc:"Infoga sidbrytning"
}}});