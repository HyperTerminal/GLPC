<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/human_condition/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'Human Condition' av <a href='http://e107.org' rel='external'>jalist</a>, baserat på wordpresstemat, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Kommentarer är avaktiverade för detta objekt");
define("LAN_THEME_3", "kommentar(er): ");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");
define("LAN_THEME_6", "Kommentar av");


?>