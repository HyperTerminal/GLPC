<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/interfectus/languages/Swedish.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/25 11:07:53 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'interfectus' av <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Läs/Posta kommentar: ");
define("LAN_THEME_3", "Kommentarer är avaktiverade för detta objekt");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");


?>