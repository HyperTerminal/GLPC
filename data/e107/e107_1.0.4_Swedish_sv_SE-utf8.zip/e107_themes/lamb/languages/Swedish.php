<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/lamb/languages/English.php,v $
|     $Revision: 1.4 $
|     $Date: 2007/03/03 19:59:49 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'lamb' av <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Kommentarer är avaktiverade för detta objekt");
define("LAN_THEME_3", "kommentar: ");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");
define("LAN_THEME_6", 'den');

?>