<?php
/*
+ ----------------------------------------------------------------------------+
|
|     Swedish language file.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_themes/leaf/languages/Swedish.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/09/17 13:04:48 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Kommentar(er) ");
define("LAN_THEME_2", "Kommentarer är inaktiverade för detta objekt");
define("LAN_THEME_3", "kommentar(er) ");
define("LAN_THEME_4", "Läs resten ...");
define("LAN_THEME_5", "Bakåtlänkar: ");
define("LAN_THEME_6", "Kommentar av");
define("LAN_THEME_7", "Nyheter");


?>