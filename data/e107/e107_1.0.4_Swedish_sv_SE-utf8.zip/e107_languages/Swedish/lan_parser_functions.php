<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "Gäst");
define("LAN_WROTE", "skrev"); // som i John skrev.."  ");


?>