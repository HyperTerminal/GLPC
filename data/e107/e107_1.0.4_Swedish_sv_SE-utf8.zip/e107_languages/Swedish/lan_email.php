<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_email.php,v $
|     $Revision: 1.6 $
|     $Date: 2006/10/21 11:20:27 $
|     $Author: mrpete $
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "E-post");}
define("LAN_EMAIL_1", "Från:");
define("LAN_EMAIL_2", "Avsändarens IP-adress:");
define("LAN_EMAIL_3", "E-postad artikel från ");
define("LAN_EMAIL_4", "Skicka E-post");
define("LAN_EMAIL_5", "E-posta artikeln till en vän");
define("LAN_EMAIL_6", "Jag tänkte du kunde vara intresserad av den här artikeln från");
define("LAN_EMAIL_7", "E-posta till någon");
define("LAN_EMAIL_8", "Kommentar");
define("LAN_EMAIL_9", "Tyvärr - kan inte skicka e-post");
define("LAN_EMAIL_10", "E-posten skickades till");
define("LAN_EMAIL_11", "E-post skickat");
define("LAN_EMAIL_12", "Fel");
define("LAN_EMAIL_13", "E-posta artikeln till en vän");
define("LAN_EMAIL_14", "E-posta nyhetsartikeln till en vän");
define("LAN_EMAIL_15", "Användarnamn: ");
define("LAN_EMAIL_106", "Det verkar inte vara en giltig e-postadress");
define("LAN_EMAIL_185", "Skicka artikeln");
define("LAN_EMAIL_186", "Skicka nyhetsartikeln");
define("LAN_EMAIL_187", "E-postadress att skicka till");
define("LAN_EMAIL_188", "Jag tänkte du kunde vara intresserad av den här nyhetsartikeln från");
define("LAN_EMAIL_189", "Jag tänkte du kunde vara intresserad av den här artikeln från");
define("LAN_EMAIL_190", "Ange synlig kod");


?>