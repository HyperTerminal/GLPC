<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Annonser");
define("BANNERLAN_16", "Klientnamn:");
define("BANNERLAN_17", "Lösenord:");
define("BANNERLAN_18", "Fortsätt");
define("BANNERLAN_19", "Var vänlig och skriv in ditt klientnamn och lösenord för att fortsätta");
define("BANNERLAN_20", "Tyvärr, kunde inte finna dessa uppgifter i databasen. Vänligen kontakta webbplatsadministratören för mer information.");
define("BANNERLAN_21", "Annonsstatistik");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "Annons-ID");
define("BANNERLAN_24", "Antal klick");
define("BANNERLAN_25", "% klick");
define("BANNERLAN_26", "Visade annonser");
define("BANNERLAN_27", "Köpta annonser");
define("BANNERLAN_28", "Annonser kvar");
define("BANNERLAN_29", "Inga annonser");
define("BANNERLAN_30", "Obegränsat");
define("BANNERLAN_31", "Ej satt");
define("BANNERLAN_32", "Ja");
define("BANNERLAN_33", "Nej");
define("BANNERLAN_34", "Slutar");
define("BANNERLAN_35", "Genomklickningar IP-adresser");
define("BANNERLAN_36", "Aktiv ");
define("BANNERLAN_37", "Startar");
define("BANNERLAN_38", "FEL");


?>