<?php
/*
+ ----------------------------------------------------------------------------+
|      e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_submitnews.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/04/12 22:58:23 $
|     $Author: e107coders $
|     $Swedish translation edited by: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Skriv en nyhetsartikel");
define("LAN_7", "Namn: ");
define("LAN_62", "Rubrik: ");
define("LAN_112", "E-postadress: ");
define("LAN_133", "Tack");
define("LAN_134", "Nyhetsartikeln har skickats in och kommer att granskas av en webbplatsadministratör.");
define("LAN_135", "Nyhetsartikel: ");
define("LAN_136", "Skicka in nyhetsartikel");
define("NWSLAN_6", "Kategori");
define("NWSLAN_10", "Inga nyhetskategorier");
define("NWSLAN_11", "Du har inte tillgång till denna area.");
define("NWSLAN_12", "Tillgång nekad.");
define("SUBNEWSLAN_1", "Du måste ange en rubrik.\n");
define("SUBNEWSLAN_2", "Du måste inkludera en text i nyhetsartikeln.\n");
define("SUBNEWSLAN_3", "Din bild måste vara i något av formaten jpg, gif eller png.");
define("SUBNEWSLAN_4", "Bildfilen är för stor");
define("SUBNEWSLAN_5", "Bildfil");
define("SUBNEWSLAN_6", "jpg / gif / png");
define("SUBNEWSLAN_7", "Du måste ange ditt namn och din e-postadress");
define("SUBNEWSLAN_8", "Ett fel uppstod när bilden skulle laddas upp");


?>