<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Användarinställningar");
define("LAN_7", "Visningsnamn:");
define("LAN_8", "namnet som visas på webbplatsen");
define("LAN_9", "Användarnamn:");
define("LAN_10", "namnet du använder för att logga in på webbplatsen");
define("LAN_11", "namnet du använder för att logga in på webbplatsen. Detta kan du inte ändra själv; kontakta en administratör om det behöver ändras av säkerhetsskäl.");
define("LAN_20", "FEL");
define("LAN_105", "De två lösenorden matchar inte varandra");
define("LAN_106", "Det ser inte ut att vara en giltig e-postadress");
define("LAN_112", "E-postadress:");
define("LAN_113", "Dölj e-postadress:");
define("LAN_114", "Detta hindrar att din e-postadress visas på webbplatsen.");
define("LAN_120", "Signatur:");
define("LAN_121", "Figur ( avatar ):");
define("LAN_122", "Tidszon");
define("LAN_150", "Inställningarna uppdaterade och sparade i databasen.");
define("LAN_151", "OK");
define("LAN_152", "Nytt lösenord:");
define("LAN_153", "Nytt lösenord igen:");
define("LAN_154", "Spara inställningar");
define("LAN_155", "Uppdatera användarinställningar");
define("LAN_185", "Du lämnade lösenordsfältet tomt");
define("LAN_308", "Riktigt namn:");
define("LAN_401", "Lämna tomt för att behålla nuvarande lösenord");
define("LAN_402", "Ange sökväg eller välj figur ( avatar )");
define("LAN_403", "Välj figur (avatar)");
define("LAN_404", "Vänligen observera: Alla bilder som laddas upp till servern som anses olämplig av administratörerna kommer att raderas omedelbart.");
define("LAN_410", "Inställningar för");
define("LAN_411", "Uppdatera dina inställningar");
define("LAN_412", "Ändra ditt lösenord");
define("LAN_413", "Välj en figur ( avatar )");
define("LAN_414", "Ladda upp ditt foto");
define("LAN_415", "Ladda upp din figur ( avatar )");
define("LAN_416", "Ja");
define("LAN_417", "Nej");
define("LAN_418", "Registreringsinformation");
define("LAN_419", "Personlig- / kontaktinformation");
define("LAN_420", "Figur ( avatar )");
define("LAN_421", "Välj en figur ( avatar ) från webbplatsen");
define("LAN_422", "Använd figur ( avatar ) från annan webbplats");
define("LAN_423", "Ange den fullständiga adressen till bilden, inklusive http");
define("LAN_424", "Klicka på knappen för att se figurer lagrade på webbplatsen");
define("LAN_425", "Fotografi");
define("LAN_426", "Detta kommer att visas på din profilsida");
define("LAN_433", "URL till din XUP fil");
define("LAN_434", "Vad är detta?");
define("LAN_435", "XML användarprotokoll fil");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "tecken");
define("LAN_SIGNUP_4", "Ditt lösenord måste vara minst");
define("LAN_SIGNUP_5", " tecken långt.");
define("LAN_SIGNUP_6", "Din");
define("LAN_SIGNUP_7", " är obligatorisk");
define("LAN_USET_1", "Din figur ( avatar ) är för bred");
define("LAN_USET_2", "Maximal tillåten bredd är ");
define("LAN_USET_3", "Din figur ( avatar ) är för hög");
define("LAN_USET_4", "Maximal tillåten höjd är ");
define("LAN_CUSTOMTITLE", "Egen titel");
define("LAN_408", "En användare med den e-postadressen finns redan.");
define("MAX_AVWIDTH", "Maximal bredd x höjd för figur ( avatar ) är ");
define("MAX_AVHEIGHT", " x ");
define("RESIZE_NOT_SUPPORTED", "Skalningsmetod stöds inte av servern. Vänligen ändra själv storlek, eller välj en annan bild. Filen raderades.");
define("LAN_USET_5", "Användarklass");
define("LAN_USET_6", "Olika användarklasser har tillgång till olika funktioner, sektioner, e-postutskick mm.");
define("LAN_USET_7", "Diverse");
define("LAN_USET_8", "Signatur / Tidszon");
define("LAN_USET_9", "Något eller några av de obligatoriska fälten (markerade med *) saknas i dina inställningar.");
define("LAN_USET_10", "Vänligen uppdatera dina inställningar nu för att kunna fortsätta.");
define("LAN_USET_11", "Det användarnamnet kan inte accepteras som giltigt; vänligen välj något annat namn.");
define("LAN_USET_12", "Visningsnamnet är för kort; välj ett annat.");
define("LAN_USET_13", "Ogiltiga tecken i användarnamnet; vänligen välj ett annat.");
define("LAN_USET_14", "Inloggningsnamnet är för långt; vänligen välj ett kortare.");
define("LAN_USET_15", "Visningsnamnet är för långt; vänligen välj ett kortare.");
define("LAN_USET_16", "Markera rutan för att radera befintligt foto utan att ladda upp ett nytt.");
define("LAN_USET_17", "Visningsnamnet används redan; var vänlig och välj ett annat.");
define("LAN_USET_18", "Ogiltigt namn på avataren");
define("LAN_USET_19", "Kunde inte nå avataren");
define("LAN_USET_20", "Kan ej läsa bildinformation");


?>