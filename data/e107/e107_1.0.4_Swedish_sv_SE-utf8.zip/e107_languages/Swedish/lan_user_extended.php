<?php
/*
+ ----------------------------------------------------------------------------+
|      e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Textruta");
define("UE_LAN_2", "Radioknappar");
define("UE_LAN_3", "Rullgardinsmeny");
define("UE_LAN_4", "DB-tabellfält");
define("UE_LAN_5", "Textarea");
define("UE_LAN_6", "Heltal");
define("UE_LAN_7", "Datum");
define("UE_LAN_8", "Språk");

define("UE_LAN_9", "Namn");
define("UE_LAN_10", "Typ");
define("UE_LAN_11", "Använd");

define("UE_LAN_HIDE", "Dölj från användare");

define("UE_LAN_LOCATION", "Plats");
define("UE_LAN_LOCATION_DESC", "Användarens ort");
define("UE_LAN_AIM", "AIM adress");
define("UE_LAN_AIM_DESC", "AIM adress");
define("UE_LAN_ICQ", "ICQ nummer");
define("UE_LAN_ICQ_DESC", "ICQ nummer");
define("UE_LAN_YAHOO", "Yahoo! adress");
define("UE_LAN_YAHOO_DESC", "Yahoo! adress");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN adress");
define("UE_LAN_HOMEPAGE", "Hemsida");
define("UE_LAN_HOMEPAGE_DESC", "Webbadress till användarens hemsida");
define("UE_LAN_BIRTHDAY", "Födelsedag");
define("UE_LAN_BIRTHDAY_DESC", "Födelsedag");
define("UE_LAN_LANGUAGE", "Språk");
define("UE_LAN_LANGUAGE_DESC", "Användarspråk");
define("UE_LAN_COUNTRY", "Land");
define("UE_LAN_COUNTRY_DESC", "Användares land (inkluderar databastabell)");

define("LAN_UE_FAIL_HOMEPAGE", "Felaktigt inlägg för heminställningar");

?>