<?php
/*+---------------------------------------------------------------+
| e107 website system Swedish Language File
| Released under the terms and conditions of the| GNU General Public License (http://gnu.org).
|
| $URL: ../e107_languages/Swedish/lan_signup.php $
| $Revision: 1.0 $| $Id: 2010/10/21 21:38:37 $
| $Author: Hanssons.de $
+---------------------------------------------------------------+*/
define("PAGE_NAME", "Registrera");
define("LAN_7", "Visat namn");
define("LAN_8", "Detta namn kommer visas på webbplatsen");
define("LAN_9", "Användarnamn");
define("LAN_10", "Det namn du använder för att logga in");
define("LAN_17", "Lösenord");
define("LAN_103", "Det användarnamnet kan inte användas; vänligen välj ett annat.");
define("LAN_104", "Det användarnamnet är upptaget; vänligen välj ett annat.");
define("LAN_105", "Du angav två olika lösenord");
define("LAN_106", "E-postadressen verkar inte vara korrekt");
define("LAN_107", "Tack! Du är nu registrerad som medlem på");
define("LAN_108", "Registreringsprocessen fullbordad");
define("LAN_109", "Denna webbplats efterföljer The Children's Online Privacy Protection Act från 1998 (COPPA) och kan därför inte acceptera medlemsregistreringar från användare som är yngre än 13 år utan ett skriftligt godkännande från förälder eller målsman. För mer information kan du läsa lagstiftningen");
define("LAN_110", "Registrering");
define("LAN_111", "Skriv in lösenordet igen");
define("LAN_112", "E-postadress");
define("LAN_113", "Ska e-postadressen döljas?");
define("LAN_114", "Detta kommer hindra din e-postadress från att visas på webbplatsen");
define("LAN_123", "Registrera");
define("LAN_185", "Du lämnade obligatoriskt fält tomt");
define("LAN_201", "Ja");
define("LAN_200", "Nej");
define("LAN_202", "Du har redan ett webbplatskonto. Har du glömt ditt lösenord? Klicka i så fall på länken 'Glömt lösenord'.");
define("LAN_203", "Din IP-adress är uppförd på en DNS-blockeringslista. ");
define("LAN_309", "Vänligen ange dina uppgifter här");
define("LAN_399", "Fortsätt");
define("LAN_400", "Användarnamn och lösenord är <b>skiftlägeskänsliga</b>");
define("LAN_401", "Ditt användarkonto har nu aktiverats; vänligen");
define("LAN_402", "Registreringen har aktiverats");
define("LAN_403", "Välkommen till");
define("LAN_404", "Detaljer för");
define("LAN_405", "Detta steg i registreringsprocessen är nu avklarat. Du kommer få ett e-postmeddelande med dina inloggningsuppgifter och en webblänk. Klicka på webblänken för att slutföra registreringsprocessen och aktivera ditt webbplatskonto.");
define("LAN_406", "Tack");
define("LAN_407", "Vänligen spara detta meddelande. Ditt lösenord har krypterats och om du förlorar det kan det inte tas fram igen. Du kan dock begära ett nytt lösenord om detta inträffar. \n\n Tack för att du registrerat dig. \n\n Från");
define("LAN_408", "En användare med den e-postadressen finns redan. Vänligen använd 'Glömt lösenord' funktionen för att begära ditt lösenord.");
define("LAN_SIGNUP_1", "Minst");
define("LAN_SIGNUP_2", "tecken");
define("LAN_SIGNUP_3", "Bildkodsverifieringen misslyckades");
define("LAN_SIGNUP_4", "Lösenordet måste vara minst");
define("LAN_SIGNUP_5", "tecken långt.");
define("LAN_SIGNUP_6", "Ditt");
define("LAN_SIGNUP_7", "krävs");
define("LAN_SIGNUP_8", "Tack");
define("LAN_SIGNUP_9", "Kan inte fortsätta");
define("LAN_SIGNUP_10", "Ja");
define("LAN_SIGNUP_11", "-");
define("LAN_409", "Ogiltiga tecken i användarnamnet");
define("LAN_410", "Skriv koden som syns i bilden");
define("LAN_411", "Det namn du vill visa används redan; välj ett annat namn att visa.");
define("LAN_SIGNUP_12", "Vänligen anteckna ditt användarnamn och lösenord och spara dessa på säker plats eftersom de inte kan tas fram om du förlorar dem.");
define("LAN_SIGNUP_13", "Nu kan du logga in i inloggningmenyn eller <a href=='".e_BASE."login.php'>på inloggningssidan</a>.");
define("LAN_SIGNUP_14", "här");
define("LAN_SIGNUP_15", "Vänligen kontakta huvudadministratören");
define("LAN_SIGNUP_16", "om du behöver assistans.");
define("LAN_SIGNUP_17", "Godtar du dessa regler och villkor?");
define("LAN_SIGNUP_18", "Din webbplatsregistrering har tagits emot och skapats med följande information:");
define("LAN_SIGNUP_21", "Ditt webbplatskonto är för närvarande inaktivt. För att aktivera kontot, vänligen klicka på den här länken:");
define("LAN_SIGNUP_22", "klicka här");
define("LAN_SIGNUP_23", "för att logga in.");
define("LAN_SIGNUP_24", "Tack för att du registrerade dig på");
define("LAN_SIGNUP_25", "Ladda upp din avatar");
define("LAN_SIGNUP_26", "Ladda upp ditt foto");
define("LAN_SIGNUP_27", "Visa");
define("LAN_SIGNUP_28", "e-postutskick / nyhetsmeddelanden");
define("LAN_SIGNUP_29", "Ett verifieringsmeddelande skickas till den e-postadress du anger här, så denna adress måste vara giltig.");
define("LAN_SIGNUP_30", "Om du inte vill visa din e-postadress på webbplatsen ska du markera 'Ja' vid alternativet för att dölja e-postadress.");
define("LAN_SIGNUP_31", "URL till XUP-fil");
define("LAN_SIGNUP_32", "Vad är en XUP-fil?");
define("LAN_SIGNUP_33", "Ange webbadress eller klicka på en avatar");
define("LAN_SIGNUP_34", "OBS! Bilder som laddas upp till denna server kan komma att raderas om en webbplatsansvarig finner dem olämpliga.");
define("LAN_SIGNUP_35", "Klicka här för att använda en XUP-fil");
define("LAN_SIGNUP_36", "Ett fel inträffade vid registreringen; kontakta webbplatsansvarig.");
define("LAN_LOGINNAME", "Användarnamn");
define("LAN_PASSWORD", "Lösenord");
define("LAN_USERNAME", "Visat namn");
define("LAN_EMAIL_01", "Bästa");
define("LAN_EMAIL_04", "Vänligen spara detta meddelande.");
define("LAN_EMAIL_05", "Ditt lösenord har krypterats och kan inte återskapas ifall du förlorar det. Om detta inträffar kan du dock begära ett nytt lösenord.");
define("LAN_EMAIL_06", "Tack för att du registrerade dig.");
define("LAN_SIGNUP_37", "Detta steg i registreringen är nu klart. En webbplatsadministratör måste nu godkänna ditt medlemskap. När det är gjort kommer du att få ett bekräftelsebrev med e-post som upplyser dig om att medlemskapet har godkänts.");
define("LAN_SIGNUP_38", "Du angav två olika e-postadresser. Ange en korrekt e-postadress i de två fälten för detta.");
define("LAN_SIGNUP_39", "Ange e-postadressen igen:");
define("LAN_SIGNUP_40", "Aktivering inte nödvändig");
define("LAN_SIGNUP_41", "Ditt webbplatskonto har redan aktiverats.");
define("LAN_SIGNUP_42", "Ett problem uppstod; registreringsmeddelandet skickades inte. Vänligen kontakta webbplatsansvarig.");
define("LAN_SIGNUP_43", "E-post har skickats");
define("LAN_SIGNUP_44", "Aktiveringsmeddelande har skickats till:");
define("LAN_SIGNUP_45", "Vänligen kontrollera din inkorg.");
define("LAN_SIGNUP_47", "Skicka aktiveringsmeddelande igen");
define("LAN_SIGNUP_48", "Användarnamn eller e-postadress");
define("LAN_SIGNUP_49", "Om du registrerade dig med felaktig e-postadress ska du skriva in en korrekt e-postadress och ditt lösenord här:");
define("LAN_SIGNUP_50", "Ny e-postadress");
define("LAN_SIGNUP_51", "Tidigare lösenord");
define("LAN_SIGNUP_52", "Fel lösenord");
define("LAN_SIGNUP_53", "fältet validerades inte korrekt");
define("LAN_SIGNUP_54", "Klicka här för att ange dina uppgifter och registrera ett webbplatskonto");
define("LAN_SIGNUP_55", "Det visade namnet är för långt; välj ett kortare namn.");
define("LAN_SIGNUP_56", "Det visade namnet är för kort; välj ett längre namn.");
define("LAN_SIGNUP_57", "Inloggningsnamnet är för långt; välj ett kortare.");
define("LAN_SIGNUP_58", "Förhandsgranska webbplatsregistreringen");
define("LAN_SIGNUP_59", "**** Om webblänken inte fungerar kan den ha blivit radbruten ****");
define("LAN_SIGNUP_60", "Kunde inte nå avatar på extern webbplats");
define("LAN_SIGNUP_72", "Tack för att du registrerat webbplatskonto på [sitename]. En bekräftelse har skickats till [email] med en webblänk. Klicka på den webblänken för att slutföra din registrering och aktivera ditt konto.");
define("LAN_SIGNUP_98", "Bekräfta din e-postadress");
define("LAN_SIGNUP_99", "Ett problem uppstod");
define("LAN_SIGNUP_100", "Inväntar godkännande av administratör");
define("LAN_SIGNUP_102", "Registreringen godkändes inte");
define("LAN_SIGNUP_103", "Det är för många användare som redan använder IP-adress");
define("LAN_SIGNUP_104", "Ogiltigt namn på avatar");
define("LAN_SIGNUP_105", "Kunde inte utföra din begäran - kontakta webbplatsansvarig.");
define("LAN_SIGNUP_106", "Kunde inte utföra din begäran - har du redan ett webbplatskonto här?");
define("LAN_SIGNUP_107", "En eller flera DNS-blocklistor har registrerat IP-adressen: ");


?>