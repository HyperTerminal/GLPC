<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Gäster: ");
define("ONLINE_EL2", "Medlemmar: ");
define("ONLINE_EL3", "På denna sida: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Medlemmar");
define("ONLINE_EL6", "Senaste medlem");
define("ONLINE_EL7", "tittar på");
define("ONLINE_EL8", "flest online samtidigt: ");
define("ONLINE_EL9", "den");
define("ONLINE_EL10", "Medlemsnamn");
define("ONLINE_EL11", "Tittar på sidan");
define("ONLINE_EL12", "Svarar till");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Tråd");
define("ONLINE_EL15", "Sida");
define("CLASSRESTRICTED", "Klassbegränsad sida");
define("ARTICLEPAGE", "Artikel/Recension");
define("CHAT", "Chat");
define("COMMENT", "Kommentarer");
define("DOWNLOAD", "Nedladdningar");
define("EMAIL", "email.php");
define("FORUM", "Forum huvudindex");
define("LINKS", "Länkar");
define("NEWS", "Nyheter");
define("OLDPOLLS", "Gamla omröstningar");
define("POLLCOMMENT", "Omröstning");
define("PRINTPAGE", "Skriv ut");
define("LOGIN", "Loggar in");
define("SEARCH", "Söker");
define("STATS", "Webbplatsstatistik");
define("SUBMITNEWS", "Skicka in nyhet");
define("UPLOAD", "Uppladdningar");
define("USERPAGE", "Användarprofiler");
define("USERSETTINGS", "Användarinställningar");
define("ONLINE", "Användare online");
define("LISTNEW", "Lista nya objekt");
define("USERPOSTS", "Användarpostningar");
define("SUBCONTENT", "Skicka in Artikel/Recension");
define("TOP", "Toppostare/Mest aktiva trådar");
define("ADMINAREA", "Administratörs Area");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Evenemang/händelse Lista");
define("CALENDAR", "Kalender");
define("FAQ", "Faq");
define("PM", "Privata meddelanden");
define("SURVEY", "Undersökning");
define("ARTICLE", "Artikel");
define("CONTENT", "Innehållssida");
define("REVIEW", "Recension");


?>