<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/04/25 18:01:18 $
|     $Author: e107coders $
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Kontakt");
define("LANCONTACT_01", "Kontaktuppgifter");
define("LANCONTACT_02", "Kontaktformulär");
define("LANCONTACT_03", "Ditt namn");
define("LANCONTACT_04", "Din e-postadress");
define("LANCONTACT_05", "Ämne");
define("LANCONTACT_06", "Meddelande");
define("LANCONTACT_07", "Skicka en kopia av detta meddelande till dig själv");
define("LANCONTACT_08", "Skicka");
define("LANCONTACT_09", "Ditt meddelande har skickats");
define("LANCONTACT_10", "Det uppstod problem med att skicka ditt meddelande");
define("LANCONTACT_11", "Din e-postdress verkar inte vara riktig.\\n Vänligen kontrollera och försök igen.");
define("LANCONTACT_12", "Ditt meddelande är för kort");
define("LANCONTACT_13", "Vanligen ange ett ämne");
define("LANCONTACT_14", "Mottagare");
define("LANCONTACT_15", "Felaktig kod angiven");
define("LANCONTACT_16", "Skriv in koden på bilden");


?>