<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/lan_error.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/28 16:28:12 $
|     $Author: mrpiercer $
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Fel");
define("LAN_ERROR_1", "FEL 401 - Tillstånd nekad");
define("LAN_ERROR_2", "Du har inte tillåtelse att hämta den webbadress eller länk du har begärt");
define("LAN_ERROR_3", "Vänligen meddela administratören om hänvisningssidan om du anser att detta felmeddelande visas av misstag.");
define("LAN_ERROR_4", "FEL 403 - Verifiering misslyckades");
define("LAN_ERROR_5", "Webbadressen som du har begärt kräver ett korrekt användarnamn och lösenord. Antingen du har angett ett felaktigt användarnamn / lösenord. , eller så har din webbläsare inte stöd för funktionen.");
define("LAN_ERROR_6", "Vänligen meddela administratören om hänvisningssidan om du anser att detta felmeddelande visas av misstag.");
define("LAN_ERROR_7", "Fel 404 - Dokumentet hittades inte");
define("LAN_ERROR_9", "Vänligen meddela administratören om hänvisningssidan om du anser att detta felmeddelande visas av misstag.");
define("LAN_ERROR_10", "Fel 500 - Felaktig header");
define("LAN_ERROR_11", "Servern stötte på ett internt fel eller felaktig konfiguration och kunde inte slutföra din begäran");
define("LAN_ERROR_12", "Vänligen meddela administratören om hänvisningssidan om du anser att detta felmeddelande visas av misstag.");
define("LAN_ERROR_13", "FEL - Okänt");
define("LAN_ERROR_14", "Det uppstod ett serverfel");
define("LAN_ERROR_15", "Vänligen meddela administratören om hänvisningssidan om du anser att detta felmeddelande visas av misstag.");
define("LAN_ERROR_16", "Ditt misslyckade försök att komma åt");
define("LAN_ERROR_17", "har registrerats.");
define("LAN_ERROR_18", "Tydligen verkar som om du sänts hit av");
define("LAN_ERROR_19", "Tyvärr finns det en föråldrad länk på den adressen.");
define("LAN_ERROR_20", "Vänligen klicka här för att komma till denna webbplatsens förstasida.");
define("LAN_ERROR_21", "Den begärda webbadressen kunde inte hittas på servern. Länken du följde är antagligen föråldrad.");
define("LAN_ERROR_22", "Klicka här för att gå denna denna webbplatsens söksida");
define("LAN_ERROR_23", "Ditt försök att komma åt ");
define("LAN_ERROR_24", " misslyckades.");
define("LAN_ERROR_25", "[1]: Kan inte läsa kärninställningar från databasen - Kärninställningarna existerar men kan inte bli unserialized. Försöker att återställa kärnbackupen ...");
define("LAN_ERROR_26", "[2]: Kan inte läsa kärninställningarna från databasen - kärninställningar är obefintliga.");
define("LAN_ERROR_27", "[3]: Kärninställningar sparade - backupen är nu aktiv");
define("LAN_ERROR_28", "[4]: Ingen backup av kärnan hittades. Kontrollera att din databas har giltigt innehåll. Om inte, kör <a href='".e_FILE."resetcore/resetcore.php'> Reset_Core </ a> verktyget för att återbygga dina kärninställningar. <br /> Efter ombyggnaden av din kärna vänligen spara en säkerhetskopia från admin / SQL skärmen.");
define("LAN_ERROR_29", "[5]: Fält har lämnats blanka. Vänligen skicka in formuläret på nytt och fyll i de obligatoriska fälten.");
define("LAN_ERROR_30", "[6]: Det går inte att bilda/skapa en giltig anslutning till MySQL. Vänligen kontrollera att din e107_config.php innehåller rätt information.");
define("LAN_ERROR_31", "[7]: mySQL körs men databasen ({$mySQLdefaultdb}) kunde inte kopplas till.<br />Vänligen och kontrollera att den finns och att din e107_config.php innehåller korrekt information.");
define("LAN_ERROR_32", "För att slutföra uppgraderingen, kopiera följande text in i din e107_config.php fil:");
define("LAN_ERROR_33", "Processfel! Normalt, skulle du bli skickad till startsidan.");
define("LAN_ERROR_34", "Okänt fel! Var vänlig och kontakta webbplatsens administratör att du såg det här:");
define("LAN_ERROR_35", "Fel 400 - Felaktig begäran");
define("LAN_ERROR_36", "Det finns ett formateringsfel på den webbsida du försöker komma åt.");
define("LAN_ERROR_37", "Ikon för fel");
define("LAN_ERROR_38", " ");
define("LAN_ERROR_39", " ");


?>