<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'sv_SE.UTF-8', 'sv_SE.utf8', 'sve_swe.utf8', 'sv');
define("CORE_LC", "sv");
define("CORE_LC2", "se");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Fel: Tema saknas.\\n\\nByt det använda temat i dina preferenser ( administrationsarea ) eller ladda upp filerna för det aktuella temat till servern.");
define("CORE_LAN4", "Vänligen radera install.php från din server");
define("CORE_LAN5", "Om du inte gör det är filen en potentiell säkerhetsrisk på din webbplats");
define("CORE_LAN6", "Översvämningsskydd på denna webbplats har aktiverats och du är nu varnad att om du fortsätter begära sidor så kan du bli blockerad.");
define("CORE_LAN7", "Kärnan försöker återställa preferenserna från automatisk säkerhetskopia.");
define("CORE_LAN8", "Kärnpreferensfel");
define("CORE_LAN9", "Kärnan kunde inte återställa preferenserna från automatisk säkerhetskopia. Åtgärden stoppades.");
define("CORE_LAN10", "Skadad cookie upptäcktes - utloggad.");
define("CORE_LAN11", "Renderingstid: ");
define("CORE_LAN12", " sek, ");
define("CORE_LAN13", " av det till frågor. ");
define("CORE_LAN15", "DB-frågor: ");
define("CORE_LAN16", "Minnesanvändning: ");
define("CORE_LAN17", "[ Bild avaktiverad ]");
define("CORE_LAN18", "Bild: ");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "kB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "Varning!");
define("LAN_ERROR", "Fel");
define("LAN_ANONYMOUS", "Anonym");
define("LAN_EMAIL_SUBS", "-E-post-");
define("LAN_SANITISED", "SANERAD");


?>