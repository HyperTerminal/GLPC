<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_PAGE_1", "Sidolistning är inaktiverat");
define("LAN_PAGE_2", "Det finns inga sidor");
define("LAN_PAGE_3", "Önskad sida existerar inte");
define("LAN_PAGE_4", "Betygsätt denna sida");
define("LAN_PAGE_5", "Tack för att du satte betyg på den här sidan");
define("LAN_PAGE_6", "Du har inte behörighet att se denna sida");
define("LAN_PAGE_7", "Felaktigt lösenord");
define("LAN_PAGE_8", "Lösenordsskyddad sida");
define("LAN_PAGE_9", "Lösenord");
define("LAN_PAGE_10", "Skicka");
define("LAN_PAGE_11", "Sidolista");
define("LAN_PAGE_12", "Ogiltig sida");
define("LAN_PAGE_13", "Del");


?>