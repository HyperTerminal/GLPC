<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Välj användare");
define("US_LAN_2", "Välj användarklass");
define("US_LAN_3", "Alla användare");
define("US_LAN_4", "Sök användarnamn");
define("US_LAN_5", "Användare hittades");
define("US_LAN_6", "Sök");
?>