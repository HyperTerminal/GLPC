<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Utskriftsvänlig sida");}

define("LAN_PRINT_86", "Kategori");
define("LAN_PRINT_87", "av");
define("LAN_PRINT_94", "Postat av ");
define("LAN_PRINT_135", "Nyhetsartikel: ");
define("LAN_PRINT_303", "Den här nyhetsartikeln är från ");
define("LAN_PRINT_304", "Titel: ");
define("LAN_PRINT_305", "Underrubrik: ");
define("LAN_PRINT_306", "Det här är från: ");
define("LAN_PRINT_307", "Skriv ut den här sidan");

define("LAN_PRINT_1", "utskriftsvänlig");


?>