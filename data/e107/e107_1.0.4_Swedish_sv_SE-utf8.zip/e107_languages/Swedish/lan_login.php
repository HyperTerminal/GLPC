<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_27", "Du lämnade obligatoriskt(obligatoriska) fält tomt");
define("LAN_300", "Felaktig inloggning. Angivna data matchar inte någon registrerad användare. Kontrollera om du har CAPS-LOCK aktiverad eftersom inloggningen är skiftlägeskänsligt.");
define("LAN_302", "Du har inte aktiverat ditt konto. Du bör ha fått ett e-postmeddelande med instruktioner om hur du bekräftar/aktiverar ditt konto. Om du inte fått det, klicka <a href='".e_BASE."signup.php?resend'>här</a>.");
define("LAN_303", "Felaktig kod angiven.");
define("LAN_304", "Det användarnamnet/lösenordskombinationen används redan.");
define("LAN_LOGIN_1", "Användarnamn");
define("LAN_LOGIN_2", "Användarlösenord");
define("LAN_LOGIN_3", "Skyddad server");
define("LAN_LOGIN_4", "Vänligen ange dina uppgifter för att få tillgång.");
define("LAN_LOGIN_5", "Klicka här för registrering");
define("LAN_LOGIN_6", "Accepterar inte nya medlemmar just nu");
define("LAN_LOGIN_7", "Skriv/ange synlig kod");
define("LAN_LOGIN_8", "Kom ihåg mig");
define("LAN_LOGIN_9", "Logga in");
define("LAN_LOGIN_10", "Klicka för inloggning");
define("LAN_LOGIN_11", "Registrera som ny användare");
define("LAN_LOGIN_12", "Glömt lösenord");
define("LAN_LOGIN_13", "Ange texten i bilden");
define("LAN_LOGIN_14", "Användare försökte logga in med okänt användarnamn");
define("LAN_LOGIN_15", "Användare försökte logga in med felaktigt lösenord");
define("LAN_LOGIN_16", "Användare försökte logga in med användarnamn/lösenordskombination som redan finns");
define("LAN_LOGIN_17", "Användarlösenord (hashed)");
define("LAN_LOGIN_18", "Auto-avstängd: Mer än 10 misslyckades inloggningsförsök");
define("LAN_LOGIN_19", "> 10 misslyckade inloggningsförsök");


?>