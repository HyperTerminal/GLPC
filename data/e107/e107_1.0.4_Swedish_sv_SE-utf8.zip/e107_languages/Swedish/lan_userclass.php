<?php
/*
+ ----------------------------------------------------------------------------+
|      e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Alla ( publik )");
define("UC_LAN_1", "Gäster");
define("UC_LAN_2", "Ingen ( inaktiv )");
define("UC_LAN_3", "Medlemmar");
define("UC_LAN_4", "Skrivskyddad");
define("UC_LAN_5", "Administratör");
define("UC_LAN_6", "Huvudadministratör");
define("UC_LAN_9", "Nya användare");
define("UC_LAN_10", "Sökbotar");


?>