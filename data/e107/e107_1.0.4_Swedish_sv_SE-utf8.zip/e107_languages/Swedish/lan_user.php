<?php
/*
+ ----------------------------------------------------------------------------+
|      e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Medlemmar");
define("LAN_20", "Fel");
define("LAN_112", "E-postadress");
define("LAN_137", "Det finns ingen information på den användaren eftersom den inte är registrerad på");
define("LAN_138", "Registrerade medlemmar: ");
define("LAN_139", "Ordning: ");
define("LAN_140", "Registrerade medlemmar");
define("LAN_141", "Inga registrerade medlemmar ännu.");
define("LAN_142", "Medlem");
define("LAN_143", "[dold på begäran]");
define("LAN_145", "Medlem på webbplatsen sedan");
define("LAN_146", "Besök här sedan registrering");
define("LAN_147", "Chattruta poster");
define("LAN_148", "Antal kommentarer");
define("LAN_149", "Foruminlägg");
define("LAN_308", "Riktigt namn");
define("LAN_400", "Det är ingen giltig användare.");
define("LAN_401", "ingen information");
define("LAN_402", "Medlemsprofil");
define("LAN_403", "Webbplatsstatistik");
define("LAN_404", "Senaste besök");
define("LAN_405", "dagar sedan");
define("LAN_406", "Gradering/Betyg");
define("LAN_407", "ingen");
define("LAN_408", "inget foto");
define("LAN_409", "poäng");
define("LAN_410", "Diverse");
define("LAN_411", "Klicka här för att uppdatera din information");
define("LAN_412", "Klicka här för att redigera denna användares information");
define("LAN_413", "radera foto");
define("LAN_414", "föregående medlem");
define("LAN_415", "nästa medlem");
define("LAN_416", "Du måste vara inloggad för att komma åt denna sida");
define("LAN_417", "Webbplatsens huvudadministratör");
define("LAN_418", "Webbplatsadministratör");
define("LAN_419", "Visa");
define("LAN_420", "▼ Fallande");
define("LAN_421", "▲ Stigande");
define("LAN_422", "Kör");
define("LAN_423", "Klicka här för att se användarkommentarer");
define("LAN_424", "Klicka här för att se foruminlägg");
define("LAN_425", "Sänd privat meddelande");
define("LAN_426", "sedan");
define("USERLAN_1", "Peer Gradering/Betyg");
define("USERLAN_2", "Du har inte behörighet att se denna sida.");


?>