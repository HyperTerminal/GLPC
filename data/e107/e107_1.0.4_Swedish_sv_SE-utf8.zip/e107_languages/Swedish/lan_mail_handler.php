<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Producerad av e107 webbportalsystem");
define("LANMAILH_2", "Detta är ett fler-delat meddelande i MIME format.");
define("LANMAILH_3", " är inte korrekt formaterat");
define("LANMAILH_4", "Servern avvisade adressen");
define("LANMAILH_5", "Ingen respons(svar) från servern");
define("LANMAILH_6", "Kan inte hitta e-postservern.");
define("LANMAILH_7", " verkar vara giltig.");


?>