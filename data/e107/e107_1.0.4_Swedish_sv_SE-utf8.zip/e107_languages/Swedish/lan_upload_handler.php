<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Filtypen");
define("LANUPLOAD_2", "är inte tillåten och har raderats.");
define("LANUPLOAD_3", "Uppladdningen lyckades");
define("LANUPLOAD_4", "Antingen finns inte målmappen eller så är mappen inte skrivbar. (Chmod 777)");
define("LANUPLOAD_5", "Den uppladdade filen överskrider upload_max_filesize direktivet i php.ini.");
define("LANUPLOAD_6", "Den uppladdade filen överskrider MAX_FILE_SIZE direktivet som specifierad i html-formuläret.");
define("LANUPLOAD_7", "Filen blev bara delvis uppladdad.");
define("LANUPLOAD_8", "Ingen fil laddades upp.");
define("LANUPLOAD_9", "Uppladdad filstorlek 0 bytes");
define("LANUPLOAD_10", "Uppladdning misslyckades [Dubblerat filnamn] - En fil med samma namn finns redan.");
define("LANUPLOAD_11", "Filen laddades inte upp. Filnamn: ");
define("LANUPLOAD_12", "Fel");
define("LANUPLOAD_13", "Temporär mapp saknas");
define("LANUPLOAD_14", "Det gick inte att skriva till filen");
define("LANUPLOAD_15", "Uppladdning är inte tillåten");
define("LANUPLOAD_16", "Okänt fel");
define("LANUPLOAD_17", "Ogiltigt filnamn för uppladdning");
define("LANUPLOAD_18", "Den uppladdade filen överskrider de tillåtna gränser.");
define("LANUPLOAD_19", "För många filer uppladdade - den överskridna mängden är raderad.");


?>