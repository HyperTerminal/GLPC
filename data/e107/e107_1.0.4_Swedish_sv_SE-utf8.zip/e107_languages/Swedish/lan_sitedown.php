<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Webbplatsen tillfälligt stängd");
define("LAN_SITEDOWN_00", "är tillfälligt stängd");
define("LAN_SITEDOWN_01", "Vi har tillfälligt stängt ner webbplatsen för underhåll. Det bör inte ta alltför lång tid  - vänligen kom tillbaka senare.");


?>