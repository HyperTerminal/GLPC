<?php
/*
+ ----------------------------------------------------------------------------+
|    e107 website system - Language File.
|    $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Användarregistrering");
define("NT_LAN_UV_1", "Användarregistrering verifierad");
define("NT_LAN_UV_2", "Användar-ID");
define("NT_LAN_UV_3", "Inloggningsnamn för användare:");
define("NT_LAN_UV_4", "Användar IP:");
define("NT_LAN_LI_1", "Användare loggade in");
define("NT_LAN_LO_1", "Användare loggade ut");
define("NT_LAN_LO_2", " utloggad från webbplatsen");
define("NT_LAN_FL_1", "Flödningsblockerad");
define("NT_LAN_FL_2", "IP-adress blockerad p.g.a. flödning(flooding)");
define("NT_LAN_SN_1", "Nyhetsartikel postat");
define("NT_LAN_NU_1", "Uppdaterad");
define("NT_LAN_ND_1", "Nyhetsartikel raderat");
define("NT_LAN_ND_2", "Raderat nyhetsartikel ID");
define("NT_LAN_CM_1", "Användarkommentar avvaktar godkännande");


?>