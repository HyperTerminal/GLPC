<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Toppostare i forum");
define("TOP_LAN_1", "Användarnamn");
define("TOP_LAN_2", "Inlägg");
define("TOP_LAN_3", "Toppostare, kommentarer");
define("TOP_LAN_4", "Kommentarer");
define("TOP_LAN_5", "Toppostare, chattruta");
define("TOP_LAN_6", "Webbplatsbetyg");
define("LAN_1", "Tråd");
define("LAN_2", "Postare");
define("LAN_3", "Visningar");
define("LAN_4", "Svar");
define("LAN_5", "Senaste post");
define("LAN_6", "Trådar");
define("LAN_7", "Mest aktiva trådar");
define("LAN_8", "Toppostare");


?>