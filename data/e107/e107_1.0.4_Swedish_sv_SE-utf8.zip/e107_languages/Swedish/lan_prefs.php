<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 driven Webbplats");
define("LAN_PREF_2", "e107 Webbplatssystem");
define("LAN_PREF_3", "Denna webbplats drivs av <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>,  som distribueras under villkoren i <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL License.");
define("LAN_PREF_4", "censurerad");
define("LAN_PREF_5", "Forum");


?>