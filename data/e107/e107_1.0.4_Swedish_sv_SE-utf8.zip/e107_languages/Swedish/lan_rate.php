<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "röst");
define("RATELAN_1", "röster");
define("RATELAN_2", "Hur vill du betygssätta detta objekt?");
define("RATELAN_3", "Tack för din röst");
define("RATELAN_4", "Ej betygssatt");
define("RATELAN_5", "Betyg");

?>