<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Endast medlemmar");
define("LAN_MEMBERS_0", "begränsad area");
define("LAN_MEMBERS_1", "Detta är en begränsad area");
define("LAN_MEMBERS_2", "För tillgång till den, vänligen <a href='login.php'>logga in</a>");
define("LAN_MEMBERS_3", "eller <a href='".e_SIGNUP."'>registrera</a> dig som medlem");
define("LAN_MEMBERS_4", "Klicka här för att återgå till förstasidan");


?>