<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("NP_1", "Föregående sida");
define("NP_2", "Nästa sida");
define("NP_3", "Gå till sidan");


?>