<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "Huvudmeny");
define("LAN_SITELINKS_502", "Administrations Area");


?>