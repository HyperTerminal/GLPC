<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Skickar e-postrapporter till");
define("UCSLAN_2", "Uppdaterade privilegier");
define("UCSLAN_3", "Kära");
define("UCSLAN_4", "Dina privilegier har uppdaterats på");
define("UCSLAN_5", "Du har nu tillgång till följande area(or)");
define("UCSLAN_6", "Ställ in klass för användare");
define("UCSLAN_7", "Ställ in klasser");
define("UCSLAN_8", "Skicka rapport till anvädare");
define("UCSLAN_9", "Klasser uppdaterade.");
define("UCSLAN_10", "Hälsningar,");
define('UCSLAN_12', 'Endast för medlemmar');
?>