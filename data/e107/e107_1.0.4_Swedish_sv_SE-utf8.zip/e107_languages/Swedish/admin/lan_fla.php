<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Misslyckade inloggningsförsök");
define("FLALAN_2", "Inga misslyckade inloggningar har loggats");
define("FLALAN_3", "Försök raderade");
define("FLALAN_4", "Användare försökte logga in med felaktigt användarnamn / lösenord");
define("FLALAN_5", "Blockerad(e) IP-adress(er)");
define("FLALAN_6", "Datum");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP-adress / värd");
define("FLALAN_9", "Alternativ");
define("FLALAN_10", "Radera / blockera markerade poster");
define("FLALAN_11", "Markera <b>alla</b> poster för radering");
define("FLALAN_12", "Markera <b>ingen</b> för radering");
define("FLALAN_13", "Markera <b>alla</b> poster för blockering");
define("FLALAN_14", "Markera <b>ingen</b> för blockering");
define("FLALAN_15", "Följande IP-adress(er) har blivit automatiskt blockerade eftersom användare har gjort fler än tio felaktiga inloggningsförsök");
define("FLALAN_16", "Radera den automatiska blockeringslistan");
define("FLALAN_17", "Den automatiska blockeringslistan är raderad");

?>