<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Fel - vänligen skicka igen");
define("UDALAN_2", "Inställningar uppdaterade");
define("UDALAN_3", "Inställningar uppdaterade för");
define("UDALAN_4", "Namn");
define("UDALAN_5", "Lösenord");
define("UDALAN_6", "Ange lösenord igen");
define("UDALAN_7", "Ändra lösenord");
define("UDALAN_8", "Lösenord uppdaterat för");


?>