<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Blockering borttagen.");
define("BANLAN_2", "Inga Blockeringar.");
define("BANLAN_3", "Befintliga blockeringar");
define("BANLAN_4", "Ta bort blockering");
define("BANLAN_5", "Ange IP, e-postadress, eller värd");
define("BANLAN_7", "Orsak");
define("BANLAN_8", "Blockera adress");
define("BANLAN_9", "Blockera användare från webbplatsen genom e-post, IP eller värdadress");
define("BANLAN_10", "IP / E-post / Orsak");
define("BANLAN_11", "Automatisk blockering: Fler än 10 misslyckade inloggningsförsök");
define("BANLAN_12", "Notera: Backning av DNS är för närvarande avaktiverat, det måste vara aktiverat för att tillåta blockering av värd. Blocking av IP och e-post kommer fortfarande att fungera.");
define("BANLAN_13", "Notera: För att blockera en användare via användarnamnet, gå till användare i administrationen: ");
define("BANLAN_78", "Träffräkning överskriden (--HITS-- förfrågningar (på filer) inom utsatt tid)");


?>