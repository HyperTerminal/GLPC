<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Message for Guests");
// define("WMGLAN_2", "Message for Members");
// define("WMGLAN_3", "Message for Administrators");
// define("WMGLAN_4", "Submit");
// define("WMGLAN_5", "Set Welcome Message");
// define("WMGLAN_6", "Activate?");
// define("WMGLAN_7", "Welcome message settings updated.");

define("WMLAN_00", "Välkomstmeddelande");
define("WMLAN_01", "Skapa nytt välkomstmeddelande");
define("WMLAN_02", "Meddelande");
define("WMLAN_03", "Synlighet");
define("WMLAN_04", "Meddelandetext");

define("WMLAN_05", "Rama in");
define("WMLAN_06", "Markera för att rendera meddelandet inuti en rubricerad ram");
define("WMLAN_07", "Åsidosätt standardsystem för att använda {WMESSAGE} kortkod");
define("WMLAN_09", "Inga välkomstmeddelanden inställda ännu");
define("WMLAN_10", "Meddelanderubrik");


?>