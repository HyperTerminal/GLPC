<?php
/*
+---------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+---------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Administratörslogg");
define("LAN_ADMINLOG_1", "Datum");
define("LAN_ADMINLOG_2", "Titel");
define("LAN_ADMINLOG_3", "Beskrivning");
define("LAN_ADMINLOG_4", "Användar IP");
define("LAN_ADMINLOG_5", "Användar ID");
define("LAN_ADMINLOG_6", "Informativ ikon");
define("LAN_ADMINLOG_7", "Informativt meddelande");
define("LAN_ADMINLOG_8", "Ikon för underrättelse");
define("LAN_ADMINLOG_9", "Underrättelsemeddelande");
define("LAN_ADMINLOG_10", "Ikon för varning");
define("LAN_ADMINLOG_11", "Varningsmeddelande");
define("LAN_ADMINLOG_12", "Ikon för kritiskt fel");
define("LAN_ADMINLOG_13", "Meddelande för kritiskt fel");


?>