<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("EPL_ADLAN_0", "Installera");
define("EPL_ADLAN_1", "Avinstallera");
define("EPL_ADLAN_2", "Är du skäker på att du vill avinstallera detta program?");
define("EPL_ADLAN_3", "Bekräfta avinstallation");
define("EPL_ADLAN_4", "Avinstallation avbruten.");
define("EPL_ADLAN_5", "Installationsprocessen kommer att skapa nya preferensinställningar.");
define("EPL_ADLAN_6", "... klicka sedan här för att börja installationen");
define("EPL_ADLAN_7", "Databastabeller uppgraderade.");
define("EPL_ADLAN_8", "Preferensinställningar skapade.");
define("EPL_ADLAN_9", "SQL-kommandon missslyckades. Kontrollera så att alla uppgraderingsändringar är okej.");
define("EPL_ADLAN_10", "Namn");
define("EPL_ADLAN_11", "Version");
define("EPL_ADLAN_12", "Författare");
define("EPL_ADLAN_13", "Kompatibilitet");
define("EPL_ADLAN_14", "Beskrivning");
define("EPL_ADLAN_15", "Läs README-filen för mer information");
define("EPL_ADLAN_16", "Programinformation");
define("EPL_ADLAN_17", "Mer information...");
define("EPL_ADLAN_18", "Kunde inte skapa tabell(er) för detta program.");
define("EPL_ADLAN_19", "Databastabeller skapades.");
define("EPL_ADLAN_21", "Programmet är redan installerat.");
define("EPL_ADLAN_22", "Installerad");
define("EPL_ADLAN_23", "Ej installerad");
define("EPL_ADLAN_24", "Uppgradering tillgänglig");
define("EPL_ADLAN_25", "Ingen installation krävs");
define("EPL_ADLAN_26", "... klicka sedan här för att påbörja avinstallationen");
define("EPL_ADLAN_27", "Kunde inte radera");
define("EPL_ADLAN_28", "Databastabeller raderade.");
define("EPL_ADLAN_29", "Preferensinställningar raderade.");
define("EPL_ADLAN_30", "vänligen ta bort dem manuellt.");
define("EPL_ADLAN_31", "Vänligen ta nu bort katalogen");
define("EPL_ADLAN_32", "och alla filer inuti den för att avsluta avinstallationen.");
define("EPL_ADLAN_33", "Programmet installerades.");
define("EPL_ADLAN_34", "Programmet uppdaterades.");
define("EPL_ADLAN_35", "Parserinställningar tillagda.");
define("EPL_ADLAN_36", "Infogning av Parserkod misslyckades, felaktigt formatterad.");
define("EPL_ADLAN_37", "Ladda upp program (.zip eller .tar.gz format)");
define("EPL_ADLAN_38", "Ladda upp program");
define("EPL_ADLAN_39", "Filen kunde inte laddas eftersom katalogen ".e_PLUGIN." inte har korrekta rättigheter - vänligen ändra skrivrättigheterna och ladda upp filen på nytt.");
define("EPL_ADLAN_40", "Administratörsmeddelande");
define("EPL_ADLAN_41", "Den filen verkar inte vara ett giltigt .zip eller .tar arkiv.");
define("EPL_ADLAN_42", "Ett fel har uppstått, kan inte packa upp arkivfilen");
define("EPL_ADLAN_43", "Ditt program har laddats upp och packats upp, vänligen bläddra ner för att se ditt program i listan.");
define("EPL_ADLAN_44", "Automatisk programuppladdning och -extrahering är avaktiverat eftersom din programmapp (katalog) för närvarande inte har rättigheter - Om du vill kunna göra detta, vänligen ändra rättigheterna på din ". e_PLUGIN." mapp att kunna tillåta uppladdningar.");
define("EPL_ADLAN_45", "Ditt menyobjekt har laddats upp och extraherats, gå till <a href='".e_ADMIN."menus.php'>din menysida</a> för att aktivera det.");
define("EPL_ADLAN_46", "PCLZIP extraheringsfel:");
define("EPL_ADLAN_47", "PCLTAR extraheringsfel:");
define("EPL_ADLAN_48", "kod:");
define("EPL_ADLAN_49", "Tabeller inte raderade på begäran under avinstallationen");
define("EPL_WEBSITE", "Webbplats");
define("EPL_NOINSTALL", "Ingen installation krävs, aktivera bara från din menysida. För att avinstallera, radera");
define("EPL_DIRECTORY", "katalogen/mappen).");
define("EPL_NOINSTALL_1", "Ingen installation krävs. För att ta bort, radera");
define("EPL_UPGRADE", "Uppgradera");
define("EPL_ADLAN_50", "Kommentarer raderades.");
define("EPL_ADLAN_53", "Katalogen är inte skrivbar");
define("EPL_ADLAN_54", "Vänligen välj altenativ för att avinstallera programet");
define("EPL_ADLAN_55", "Avinstallera program");
define("EPL_ADLAN_57", "Radera programtabeller");
define("EPL_ADLAN_58", "Om tabellerna inte är borttagna, kan programet ominstalleras utan att data förloras. Skapandet av tabeller under ominstallationen misslyckas. Tabellerna måste raderas manuellt för att tas bort.");
define("EPL_ADLAN_59", "Radera programfiler");
define("EPL_ADLAN_60", "e107 kommer att försöka ta bort alla programrelaterade filer");
define("EPL_ADLAN_62", "Avbryt avinstallationen");
define("EPL_ADLAN_63", "Avinstallera:");
define("EPL_ADLAN_64", "Samtliga filer raderades från");
define("EPL_ADLAN_65", "Radering av filer misslyckades");
define("LAN_UPGRADE_SUCCESSFUL", "Upggraderingen lyckades");
define("LAN_INSTALL_SUCCESSFUL", "Installationen lyckades");


?>