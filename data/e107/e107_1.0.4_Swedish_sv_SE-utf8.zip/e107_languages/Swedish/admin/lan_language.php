<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "kunde inte skapas. (Finns redan)");
define("LANG_LAN_01", "raderades (om befintlig) och skapades.");
define("LANG_LAN_02", "kunde inte raderas");
define("LANG_LAN_03", "Tabeller");
define("LANG_LAN_05", "Ej installerad");
define("LANG_LAN_06", "Skapa tabeller");
define("LANG_LAN_07", "Släpp/ta bort befintliga tabeller?");
define("LANG_LAN_08", "Ersätt existerande tabeller (data kommer att förloras).");
define("LANG_LAN_10", "Bekräfta radering");
define("LANG_LAN_11", "Radera omarkerade tabeller ovan (om de existerar).");
define("LANG_LAN_12", "Aktivera separata språktabeller");
define("LANG_LAN_13", "Flerspråkspreferenser");
define("LANG_LAN_14", "Webblatsens standardspråk");
define("LANG_LAN_15", "Markera för att kopiera data från standardspråket (användbart för länkar, nyhetskategorier etc).");
define("LANG_LAN_16", "Flerspråkig databasanvändning");
define("LANG_LAN_17", "Standardspråk - inga tilläggstabeller behövs");
define("LANG_LAN_18", "Använd parkerade underdomäner med dessa områden för att ställa webbplatsens språk:");
define("LANG_LAN_19", "Exempelvis fr.domän.com väljer franska medan it.domän.com väljer italienska.");
define("LANG_LAN_20", "Skriv in ett domännamn per rad, t ex. se.domän.com etc. eller lämna tomt för att avaktivera.");
define("LANG_LAN_21", "Språkverktyg");
define("LANG_LAN_23", "Skapa språkpaket (zip)");
define("LANG_LAN_24", "Generera");
define("LANG_LAN_AGR", "Observera: Genom att använda dessa verktyg är du överens om att dela med ditt språkpaket med e107-gemenskapen.");
define("LANG_LAN_EML", "Var vänlig e-posta ditt språkpaket till:");
define("LANG_LAN_25", "Vänligen kontrollera att CORE_LC och CORE_LC2 har värden i [lcpath] och försök igen");
define("LANG_LAN_26", "Var vänlig kontrollera  att du använder standardnamn i mapparna i e107_config.php (eg. 'e107_languages/', 'e107_plugins/' etc.) och försök igen,");
define("LANG_LAN_27", "Vänligen kontrollera dina språkfiler ('Kontrollera') och försök sedan igen.");
define("LANG_LAN_28", "Markera denna ruta om du är en [certifierad e107-översättare].");
define("LANG_LAN_29", "Du borde korrigera återstående felaktigheter innan du skickar in ditt språkpaket.");
define("LANG_LAN_30", "Publiceringsdatum");
define("LANG_LAN_31", "Kompabilitet");
define("LANG_LAN_32", "Installerade språk");
define("LANG_LAN_33", "Visa endast fel under verifiering");
define("LANG_LAN_34", "Vänligen verifiera och korrigera återstående [x] fel innan du försöker skapa ett språkpaket. ");


?>