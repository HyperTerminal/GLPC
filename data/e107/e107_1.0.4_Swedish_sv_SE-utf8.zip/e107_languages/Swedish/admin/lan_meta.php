<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Metataggar uppdaterade i databasen");
define("METLAN_2", "Lägg till ytterligare meta-taggar");
define("METLAN_3", "Lägg till nya metatagg inställningar");
define("METLAN_4", "Uppdaterat");
define("METLAN_5", "skriv in din beskrivning här");
define("METLAN_6", "skriv, en, lista, på, dina, nyckelord, här");
define("METLAN_7", "skriv in din copyright info här");
define("METLAN_8", "Metataggar");

define("METLAN_9", "Beskrivning");
define("METLAN_10", "Nyckelord");
define("METLAN_11", "Copyright");
define("METLAN_12", "Använd nyhetstiteln och sammanfattningen av meta-beskrivningen på nyhetssidor");
define("METLAN_13", "Författare");

?>