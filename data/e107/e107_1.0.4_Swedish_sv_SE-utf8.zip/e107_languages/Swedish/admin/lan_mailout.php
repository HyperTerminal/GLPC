<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "Spara ändringar");
define("PRFLAN_63", "Skicka ett test e-postmeddelande");
//define("PRFLAN_64", "När du klickar på knappen kommer ett testmeddelande att skickas till huvudadmins e-postadress");
define("PRFLAN_65", "Klicka för att skicka till");
define("PRFLAN_66", "Testbrev från");
define("PRFLAN_67", "Detta är ett testmeddelande, det verkar som om dina e-postinställningar fungerar!\n\nHälsningar\nfrån e107 CMS");
define("PRFLAN_68", "E-postmeddelandet kunde inte skickas. Det verkar som om din e-postserver inte är rätt konfigurerad för att skicka e-post, vänligen prova igen med SMTP, eller kontakta ditt webbhotell och be dem kontrollera sina sendmail / e-postserverinställningar.");
define("PRFLAN_69", "E-postmeddelandet skickades korrekt, vänlingen kontrollera din inkorg.");
define("PRFLAN_70", "E-post sändmetod");
define("PRFLAN_71", "Om du är osäker, lämna som PHP");
define("PRFLAN_72", "SMTP server");
define("PRFLAN_73", "SMTP användarnamn");
define("PRFLAN_74", "SMTP lösenord");
define("PRFLAN_75", "E-postmeddelandet kunde inte skickas. Vänligen kontrollera dina SMTP inställningar, eller avaktivera SMTP och försök igen.");

define("MAILAN_01", "Från namn");
define("MAILAN_02", "Från e-postadress");
define("MAILAN_03", "Till");
define("MAILAN_04", "Cc");
define("MAILAN_05", "Bcc");
define("MAILAN_06", "Ämne");
define("MAILAN_07", "Bilaga");
define("MAILAN_08", "Skicka e-postmeddelande");
define("MAILAN_09", "Använd standardtemats stilmall");
define("MAILAN_10", "Användarprenumeration");
define("MAILAN_11", "Infoga variabler");
define("MAILAN_12", "Alla medlemmar");
define("MAILAN_13", "Alla overifierade medlemmar ");
define("MAILAN_14", "Det rekommenderas att du använder SMTP för att skicka stora mängder e-post - sätt in preferenser nedan.");
define("MAILAN_15", "Ugående e-post");

define("MAILAN_16", "Användarnamn");
define("MAILAN_17", "Registreringslänk");
define("MAILAN_18", "Användar-id");
define("MAILAN_19", "Det finns ingen e-postadress angiven för webbplatsadministratören. Vänligen kontrollera dina preferenser och försök igen.");
define("MAILAN_20", "Sökväg till sendmail");
define("MAILAN_21", "Massutskick e-post");
define("MAILAN_22", "Det finns för närvarande inga sparade poster");
define("MAILAN_23", "användarklass: ");
define("MAILAN_24", "E-postmeddelande klar(a) för sändning");

define("MAILAN_25", "Paus");
define("MAILAN_26", "Pausa massutskick efter varje ");
define("MAILAN_27", "meddelanden");
define("MAILAN_28", "Pauslängd");
define("MAILAN_29", "sekunder");
define("MAILAN_30", "Mer än 30 sekunder kan orsaka time-out för webbläsaren");
define("MAILAN_31", "Behandling av e-post som studsar tillbaka");
define("MAILAN_32", "E-postadress");
define("MAILAN_33", "Inkommande e-post");
define("MAILAN_34", "Kontonamn");
define("MAILAN_35", "Lösenord");
define("MAILAN_36", "Radera studsande e-postmeddelande efter kontroll");

define("MAILAN_37", "Fortsätt");
define("MAILAN_38", "Avbryt");
define("MAILAN_39", "Skickar e-post");
define("MAILAN_40", "Du måste byta namn på <b>e107.htaccess</b> till <b>.htaccess</b> i");
define("MAILAN_41", "Innan du sänder e-post från den här sidan");
define("MAILAN_42", "Varning");
define("MAILAN_43", "Användarnamn");
define("MAILAN_44", "Användarinloggning");
define("MAILAN_45", "Användares e-postadress");
define("MAILAN_46", "Användarmatchning ");
define("MAILAN_47", " innehåller");
define("MAILAN_48", " är lika med");
define("MAILAN_49", "ID");
define("MAILAN_50", "Författare");
define("MAILAN_51", "Ämne");
define("MAILAN_52", "Lastmod ( senast ändrad )");
define("MAILAN_53", "Administratörer");
define("MAILAN_54", "Self ( mig själv )");
define("MAILAN_55", "Användargrupp");
define("MAILAN_56", "Skicka e-post");
define("MAILAN_57", "Behåll SMTP-sessionstiden aktiv");
define("MAILAN_58", "Det finns ett problem med den bifogningen");
define("MAILAN_59", "E-postgång");
define("MAILAN_60", "Skickar...");
define("MAILAN_61", "Det finns inga e-postmeddelande kvar att skicka");
define("MAILAN_62", "Skickade e-postmeddelande");
define("MAILAN_63", "Misslyckade e-postmeddelande");
define("MAILAN_64", "Total tid som förflutit:");
define("MAILAN_65", "sekunder");
define("MAILAN_66", "Lyckades avbryta");
define("MAILAN_67", "Använd 'POP före SMTP'-autentisering");
define('MAILAN_68', 'Testadress');
define("MAILAN_69", "Användarinloggning");
define("MAILAN_70", "Användares e-postadress");

?>