<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kärninställningar kopierade till databasen.");
define("DBLAN_2", "Klicka på knappen för att spara en kopia av din e107 databas");
define("DBLAN_3", "Kopiera SQL-databasen");
define("DBLAN_4", "Klicka på knappen för att validera giltigheten av e107 databasen");
define("DBLAN_5", "Kontrollera databasens validitet ");
define("DBLAN_6", "Klicka på knappen för att optimera din e107 databas");
define("DBLAN_7", "Optimera SQL-databasen");
define("DBLAN_8", "Klicka på knappen för att säkerhetskopiera dina kärninställningar");
define("DBLAN_9", "Gör backup på kärnan");
define("DBLAN_10", "Databasverktyg");
define("DBLAN_11", "MySQL databas");
define("DBLAN_12", "optimerad");
define("DBLAN_13", "Tillbaka");
define("DBLAN_14", "Klart");
define("DBLAN_15", "Klicka på knappen för att se om det finns någon tillgängliga uppdateringar");
define("DBLAN_16", "Kontrollera om det finns uppdateringar");
define("DBLAN_17", "Pref. Namn");
define("DBLAN_18", "Pref. Värde");
define("DBLAN_19", "Klicka på knappen för att öppna preferensredigeraren (endast för avancerade användare)");
define("DBLAN_20", "Preferensredigerare");
define("DBLAN_21", "Radering markerad");
define("DBLAN_22", "Program: Visa och scanna");
define("DBLAN_23", "Scanning slutförd");
define("DBLAN_24", "Namn");
define("DBLAN_25", "Katalog");
define("DBLAN_26", "Inkluderade tilläggsprogram");
define("DBLAN_27", "Installerad");
define("DBLAN_28", "Klicka på knappen för att scanna programkatalogerna för ändringar");
define("DBLAN_29", "Scanna programkataloger");
define("DBLAN_30", " (om ett tillägg(addon) visar ett fel, kontrollera efter tecken utanför PHP öppnings/stängnings taggar)");
define("DBLAN_31", "Godtas");
define("DBLAN_32", "Fel");
define("DBLAN_33", "Otillgänglig");
define("DBLAN_34", "Inte kontrollerad");
define("DBLAN_35", "Klicka på knappen för att kontrollera validiteten på användartabellen");
define("DBLAN_36", "Kontrollera användartabellen");


?>