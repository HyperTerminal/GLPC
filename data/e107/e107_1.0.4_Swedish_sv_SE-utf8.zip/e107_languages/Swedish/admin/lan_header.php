<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin navigering");
define("LAN_head_2", "Din server tillåter inte HTTP filuppladdningar, så dina användare kommer inte att kunna ladda upp figurer(avatarer)/filer etc. För att rätta till detta, sätt file_uploads till On i din php.ini och starta om din server. Om du inte har tillgång till php.ini kontakta din webbvärd(webbhotel).");
define("LAN_head_3", "Din server körs med en 'baskatalog' restriktion aktiverad. Detta förbjuder användandet av filer utanför din hemkatalog och kan med det påverka vissa skript som t.ex. filhanteraren.");
define("LAN_head_4", "Administratörsarea");
define("LAN_head_5", "språk visat i administratörsarean: ");
define("LAN_head_6", "Programinformation");


?>