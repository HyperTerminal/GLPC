<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("TPVLAN_1", "Du tittar på en förhandsgranskning av <b>'".PREVIEWTHEMENAME."'</b> temat. Det har inte satts som huvudtema för webbplatsen ännu, det är bara aktiverat för förhandsgranskning av hur temat ser ut.<br />För att sätta detta som webbplatstema, <a href='".e_ADMIN."theme.php'>gå tillbaka till din temahanterare</a> och välj 'Sätt som Webblatstema'.<br />För att förhandsgranska fler teman vänligen <a href='".e_ADMIN."theme.php'>klicka här</a>");
define("TPVLAN_2", "Förhandsgranskning av Tema");
define("TPVLAN_3", "Webbplatstema satt till");
define("TPVLAN_4", "Författare");
define("TPVLAN_5", "Webbplats");
define("TPVLAN_6", "Publiceringsdatum");
define("TPVLAN_7", "Information");
define("TPVLAN_8", "Alternativ");
define("TPVLAN_9", "Förhandsgranska tema");
define("TPVLAN_10", "Sätt som webbplatstema");
define("TPVLAN_11", "Version");
define("TPVLAN_12", "Ingen förhandsgranskning tillgänglig");

define("TPVLAN_13", "Ladda upp tema (.zip eller .tar.gz format)");
define("TPVLAN_14", "Ladda upp tema");
define("TPVLAN_15", "Filen kunde inte laddas upp eftersom ".e_THEME." katalogen inte har korrekta rättigheter - sätt den till CHMOD 777 och försök igen.");
define("TPVLAN_16", "Administratörsmeddelande");
define("TPVLAN_17", "Filen verkar inte vara ett giltigt .zip eller .tar arkiv.");
define("TPVLAN_18", "Ett fel uppstod, kan inte packa upp arkivfilen");
define("TPVLAN_19", "Ditt tema har laddats upp och blivit uppackat, bläddra ner för att se temat i listan.");
define("TPVLAN_20", "Autouppladdning av tema och extrahering är inaktiverat efterom din temakatalog(mapp) inte har korrekta rättigheter - vänligen sätt din e107_themes katalog(mapp) till CHMOD 777.");

define("TPVLAN_21", "Detta är det nuvarande valda webbplatstemat");

define("TPVLAN_22", "Detta tema har flera stilmallar");
define("TPVLAN_23", "standard stilmall");
define("TPVLAN_24", "ingen information");
//define("TPVLAN_25", "För att välja stilmall, gå till <a href='".e_ADMIN."prefs.php'>preferenser</a> och klicka på 'Tema'.");

define("TPVLAN_26", "Temahanterare");
define("TPVLAN_27", "Välj stilmall att använda");
define("TPVLAN_28", "på");
define("TPVLAN_29", "av");
define("TPVLAN_30", "Förhandsladda temabilder:");

define("TPVLAN_31", "Detta är det nuvarande administratörstemat");
define("TPVLAN_32", "Sätt som adminstratörstema");

define("TPVLAN_33", "Nuvarande webbplatstema");
define("TPVLAN_34", "Nuvarande administratörstema");
define("TPVLAN_35", "Spara alternativ");
define("TPVLAN_36", "Administratörsmeddelande");
define("TPVLAN_37", "Alternativ för tema sparade");
define("TPVLAN_38", "Ladda upp tema");
define("TPVLAN_39", "Tillgängliga teman");
define("TPVLAN_40", "Administratörstema satt till");

define("TPVLAN_41", "Välj administratörs layoutstil att använda");
define("TPVLAN_42", "Spara adminalternativ");
define("TPVLAN_43", "Adminalternativ sparade");

define("TPVLAN_46", "PCLZIP extracteringsfel:");
define("TPVLAN_47", "PCLTAR extracteringsfel: ");
define("TPVLAN_48", "kod:");
?>