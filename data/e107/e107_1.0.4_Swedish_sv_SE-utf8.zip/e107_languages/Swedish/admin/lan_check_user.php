<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "Kontrollera användardatabas");
define("LAN_CKUSER_02", "Det här kommer att söka efter flertal potentiella problem med din användardatabas");
define("LAN_CKUSER_03", "Om du har många användare, kan det ta lite tid, eller t.o.m ge time out");
define("LAN_CKUSER_04", "Fortsätt");
define("LAN_CKUSER_05", "Kontrollera om det finns dubbla inloggningsnamn");
define("LAN_CKUSER_06", "Välj funktion att genomföra");
define("LAN_CKUSER_07", "Dubbla användarnamn hittades");
define("LAN_CKUSER_08", "Inga dubbla användarnamn hittades");
define("LAN_CKUSER_09", "Användarnamn");
define("LAN_CKUSER_10", "Användar ID");
define("LAN_CKUSER_11", "Visningsnamn");
define("LAN_CKUSER_12", "Kontrollera om det finns dubbla email adresser");
define("LAN_CKUSER_13", "Dubbla e-mail adresser hittades");
define("LAN_CKUSER_14", "Email adress");
define("LAN_CKUSER_15", "Inga dubbletter hittades");
define("LAN_CKUSER_16", "Sök inlägg/poster där användarnamnet är någon annans inloggningsnamn");
define("LAN_CKUSER_17", "Konflikt mellan användarnamn och inloggningsnamn");
define("LAN_CKUSER_18", "Användare A");
define("LAN_CKUSER_19", "Användare B");
define("LAN_CKUSER_20", " ");


?>