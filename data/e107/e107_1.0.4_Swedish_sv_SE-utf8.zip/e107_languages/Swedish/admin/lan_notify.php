<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Rapporter");
define("NT_LAN_2", "Ta emot e-postrapporter om");
define("NT_LAN_3", "Av");
define("NT_LAN_4", "Huvudadministratör");
define("NT_LAN_5", "Klass");
define("NT_LAN_6", "E-post");
define("NU_LAN_1", "Användarhändelse");
define("NU_LAN_2", "Användarregistrering");
define("NU_LAN_3", "Användarkonto verifierat");
define("NU_LAN_4", "Användarinloggning");
define("NU_LAN_5", "Användarutloggning");
define("NS_LAN_1", "Säkerhetshändelse");
define("NS_LAN_2", "IP blockerat på grund av flödning(flooding) av webbplatsen");
define("NN_LAN_1", "Nyhetshändelse");
define("NN_LAN_2", "Nyhetspost insänd av användare");
define("NN_LAN_3", "Nyhet postad av administratör");
define("NN_LAN_4", "Nyhet redigerad av administratör");
define("NN_LAN_5", "Nyhet raderad av administratör");
define("NF_LAN_1", "Filhändelser");
define("NF_LAN_2", "Fil uppladdad av användare");
define("CM_LAN_1", "Kommentera händelser");
define("CM_LAN_2", "Kommentarer postade av användare som inväntar godkännande");


?>