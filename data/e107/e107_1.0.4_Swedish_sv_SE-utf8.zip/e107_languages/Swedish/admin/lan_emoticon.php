<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Uttryckssymboler");
define("EMOLAN_2", "Filnamn");
define("EMOLAN_3", "Uttryckssymbol");
define("EMOLAN_4", "Aktivera uttryckssymboler");

define("EMOLAN_5", "Bild");
define("EMOLAN_6", "Uttryckssymbolens kod");
define("EMOLAN_7", "seperera multipla koder med mellanslag");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Alternativ");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Aktivera paket");

define("EMOLAN_12", "Konfigurera detta paket");
define("EMOLAN_13", "Installerade paket");

define("EMOLAN_14", "Spara konfiguration");
define("EMOLAN_15", "Konfigurera uttryckssymboler");
define("EMOLAN_16", "Uttryckssymbolskonfiguration sparad");
define("EMOLAN_17", "Du har ett uttryckssymbolpaket som innehåller mellanslag i namnet, vilket inte är tillåtet!");
define("EMOLAN_18", "Vänligen byt namn på dessa som är listade nedanför så att de inte längre innehåller mellanslag:");
define("EMOLAN_19", "Namn");
define("EMOLAN_20", "Plats");
define("EMOLAN_21", "FEL");
//define("EMOLAN_2", "Namn");
define("EMOLAN_22", "Nytt uttryckssymbolspaket hittat:");
define("EMOLAN_23", "Nytt uttryckssymbolspaket xml hittat:");
define("EMOLAN_24", "Nytt uttryckssymbolspaket php hittat:");
define("EMOLAN_25", "Installerar nytt php uttryckssymbolspaket: ");
define("EMOLAN_26", "Skanna paketet igen");
define("EMOLAN_27", "Fel uppstod vid bearbetning av paketet: ");
define("EMOLAN_28", "Generera XML");
define("EMOLAN_29", "XML fil  genererad: ");
define("EMOLAN_30", "Fel uppstod vid skrivning av XML fil: ");

?>