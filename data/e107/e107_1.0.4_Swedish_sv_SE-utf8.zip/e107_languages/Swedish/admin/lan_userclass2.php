<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Rensade alla användare från användarklass");
define("UCSLAN_2", "Klassanvändare uppdaterade");
define("UCSLAN_3", "Användarklass raderad");
define("UCSLAN_4", "Vänligen markera rutan för att bekräfta radering av denna användarklass");
define("UCSLAN_5", "Användarklass uppdaterad");
define("UCSLAN_6", "Användarklass sparad till databasen");
define("UCSLAN_7", "Inga användarklasser ännu");
define("UCSLAN_8", "Befintliga klasser");
define("UCSLAN_11", "Bekräfta radering");
define("UCSLAN_12", "Namn på användarklass");
define("UCSLAN_13", "beskrivning av användarklass");
define("UCSLAN_14", "Uppdatera användarklass");
define("UCSLAN_15", "Skapa ny användarklass");
define("UCSLAN_16", "Tilldela ( lägg till ) användare till användarklass");
define("UCSLAN_17", "Ta bort");
define("UCSLAN_18", "Rensa användarklass");
define("UCSLAN_19", "Tilldela ( lägg till ) användare till");
define("UCSLAN_20", "användarklass");
define("UCSLAN_21", "Användarklassinställningar");
define("UCSLAN_22", "Användare - klicka för att flytta...");
define("UCSLAN_23", "Användare i denna användarklass...");
define("UCSLAN_24", "Vem kan hantera användarklass");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Användarnamn");
define("UCSLAN_27", "Återgå");


?>