<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Åtgärd");
define("LAN_UPDATE_3", "Ej nödvändig");

define("LAN_UPDATE_5", "Uppdatering tillgänglig");
define("LAN_UPDATE_7", "Genomförd");
define("LAN_UPDATE_8", "Uppdatera från");
define("LAN_UPDATE_9", "till");
define("LAN_UPDATE_10", "Tillgängliga uppdateringar");
define("LAN_UPDATE_11", ".617 to .7 Uppdatering fortsatt");
define("LAN_UPDATE_12", "En av dina tabeller innehåller dublettposter");


?>