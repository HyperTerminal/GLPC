<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("IMALAN_1", "Aktivera bildvisning");
define("IMALAN_2", "Visa bilder, kommer detta att gälla hela webbplatsen (kommentarer, Chatbox etc) för bilderna postade användandes [img] BBCode");
define("IMALAN_3", "Metod för storleksändring");
define("IMALAN_4", "Metod som används för att storleksändra bilder, antingen GD1/2 biblioteken, eller ImageMagick");
define("IMALAN_5", "Sökväg till ImageMagick (om vald)");
define("IMALAN_6", "Full sökväg till ImageMagick konverteringsmodul");
define("IMALAN_7", "Bildinställningar");
define("IMALAN_8", "Uppdatera bildinställningar");
define("IMALAN_9", "Bildinställningar uppdaterade");
define("IMALAN_10", "Klass för bildvisning");
define("IMALAN_11", "Begränsa vilka användare som kan se(posta) bilder (om aktiverat ovan)");
define("IMALAN_12", "Metod vid inaktiva bilder");
define("IMALAN_13", "Vad som skall göras med postade bilder om visning(postning) är avaktiverat");
define("IMALAN_14", "Visa bildens webbadress");
define("IMALAN_15", "Visa ingenting");
define("IMALAN_16", "Visa uppladdade figurer(avatarer)");
define("IMALAN_17", "Klicka här");
define("IMALAN_18", "Uppladdede bilder");
define("IMALAN_19", "Visa 'avaktiverad' meddelande");
define("IMALAN_21", "Används av");
define("IMALAN_22", "Bilden används ej");
define("IMALAN_23", "Figur(avatar)");
define("IMALAN_24", "Fotografi");
define("IMALAN_25", "Klicka här för att radera alla oanvända bilder");
define("IMALAN_26", "bild(er) raderad(e)");
define("IMALAN_28", "raderad");
define("IMALAN_29", "Inga bilder");
define("IMALAN_30", "Alla (publik)");
define("IMALAN_31", "Endast gäster");
define("IMALAN_32", "Endast medlemmar");
define("IMALAN_33", "Endast administratörer");
define("IMALAN_34", "Använd sleight");
define("IMALAN_35", "Fixar transparenta PNG-24 bilder med alpha transparens i IE 5/6 (Gäller hela webbplatsen)");
define("IMALAN_36", "Godkänn avatar storlek och tillgänglighet");
define("IMALAN_37", "Godkänn avatar");
define("IMALAN_38", "Max tillåtna bredd");
define("IMALAN_39", "Max tillåtna höjd");
define("IMALAN_40", "För bred");
define("IMALAN_41", "För hög");
define("IMALAN_42", "Hittades inte");
define("IMALAN_43", "Radera uppladdad avatar");
define("IMALAN_44", "Radera extern referens");
define("IMALAN_45", "Hittades inte");
define("IMALAN_46", "För stor");
define("IMALAN_47", "Totalt uppladdade avatarer");
define("IMALAN_48", "Totalt externa avatarer");
define("IMALAN_49", "Användare med avatarer");
define("IMALAN_50", "Totalt");
define("IMALAN_51", "Avatar för");
define("IMALAN_52", "Sökväg till ImageMagick verkar vara felaktig");
define("IMALAN_53", "Sökväg till ImageMagick verkar vara korrekt, men konverterteringsfilen verkar inte vara giltig");
define("IMALAN_54", "GD version installerad:");
define("IMALAN_55", "Inte installerad");


?>