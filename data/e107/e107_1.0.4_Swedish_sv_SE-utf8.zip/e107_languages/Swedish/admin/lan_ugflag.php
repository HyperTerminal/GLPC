<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Underhållsinställningar sparade");
define("UGFLAN_2", "Aktivera underhållsflaggan");
define("UGFLAN_3", "Uppdatera underhållsinställningar");
define("UGFLAN_4", "Underhållsinställning");

define("UGFLAN_5", "Text att visa när webbplatsen är i underhållsläge");
define("UGFLAN_6", "Lämna tomt för att visa standardmeddelande");

define('UGFLAN_8', 'Begränsad tillgång - endast administratörer');
define('UGFLAN_9', 'Begränsad tillgång - endast huvudadministratörer');
?>