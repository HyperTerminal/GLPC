<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Utökade användarfält låter dig lägga till ytterligare datafält av olika typer som användarna kan fylla i i sin profil.";
$ns -> tablerender("Hjälp för utökade användarfält", $text);
?>
