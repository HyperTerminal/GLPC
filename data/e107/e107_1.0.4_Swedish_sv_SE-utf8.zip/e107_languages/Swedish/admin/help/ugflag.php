<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Om du uppgraderar e107 eller bara behöver ta din webbplats offline för en tid, markera bara i underhållsrutan så kommer dina besökare att omdirigeras till en sida som förklarar att webbplatsen är nere för underhåll. När du är klar, avmarkera rutan och webbplatsen återgår till det vanliga.";

$ns -> tablerender("Underhåll", $text);
?>
