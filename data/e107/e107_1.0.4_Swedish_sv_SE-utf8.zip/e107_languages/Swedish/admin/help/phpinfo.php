<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = " Denna sidan visar din servers alla PHP konfigurationsinställningar. ";
$ns -> tablerender("Hjälp för PHP info", $text);
?>
