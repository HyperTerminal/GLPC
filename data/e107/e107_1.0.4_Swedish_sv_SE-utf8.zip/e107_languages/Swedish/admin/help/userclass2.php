<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Hjälp användande av klasser";
$text = "Du kan skapa och redigera/radera befintliga klasser från denna sidan.<br />Det är användbart för att begränsa användare från/till valda delar av din webbplats. Till exempel kan du skapa en klass kallad TEST, sedan skapa ett forum som endast användare i klassen TEST har tillgång till.";
$ns -> tablerender($caption, $text);
?>
