<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Här kan du komponera meddelanden som visas överst upp på användarens förstasida (Inställningar > Förstasida); detta kan vara användbart för exempelvis en presentation av din webbplats för nytillkomna besökare, riktad information till medlemmar i en viss användarklass osv. <br/ ><br/ >Du kan ange vilken användarklass som skall se respektive välkomstmeddelande, alltså olika meddelanden för gäster, inloggade medlemmar och administratörer mm, eller avaktivera ett meddelande utan att behöva radera det.<br/ ><br/ >Om du skapat fler än ett välkomstmeddelanden som är synliga för en viss användarklass kommer dessa meddelanden visas samtidigt, ovan och under varandra, men endast rubriken från det första visade meddelandet kommer renderas. <br /><br />Används koden för en uttryckssymbol i rubriken för välkomstmeddelanden så försvinner allt innehåll i rubriken från och med symbolens kod i listan över välkomstmeddelanden här i adminarean. Dessutom renderas ingen symbol på förstasidan utan koden skrivs ut i klartext.";
$ns -> tablerender("Hjälp för välkomstmeddelande", $text);
?>
