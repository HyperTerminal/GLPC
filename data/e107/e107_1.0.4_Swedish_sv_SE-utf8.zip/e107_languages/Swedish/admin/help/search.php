<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Om din version av MySQL servern stöder det så kan du ändra till MySQL sorteringsmetod vilken är snabbare än PHPs sorteringsmetod. Se preferenserna.<br /><br />
Om din webbplats innehåller Ideografiska språk som Kinesiska eller Japanska måste du använda PHP's sorteringsmetod och stänga av hel-ords matchningen.";
$ns -> tablerender("Hjälp för Sök", $text);
?>