<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan separera dina nyhetsobjekt i olika kategorier och låta besökarna att visa nyheterobjekten i enbart dessa kategorier. <br /><br />Ladda upp dina ikonbilder antingen till ".e_THEME."-yourtheme-/images/ eller themes/shared/newsicons/.";
$ns -> tablerender("Hjälp för nyhetskategorier", $text);
?>
