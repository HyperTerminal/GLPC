<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Härifrån kan du tillåta/förbjuda att användare laddar upp filer, och du kan hantera de filer som har laddats upp.";
$ns -> tablerender("Hjälp för publika uppladdningar", $text);
?>
