<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Cachning";
$text = "Om du har cachning påkopplad kommer hasigheten på din webbplats att öka markant och antalet förfrågningar till SQL-databasen minskas.<br /><br /><b>VIKTIGT! Om du håller på att göra ett eget tema, koppla från cachning under tiden, annars kommer dina ändringar inte att ha någon effekt.</b>";
$ns -> tablerender($caption, $text);

?>
