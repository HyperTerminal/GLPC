<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Att sätta ett nytt språk ger dig möjligheten att ha en version av detta språket på ditt innehåll på webbplatsen.";
$ns -> tablerender("Språkhjälp", $text);

?>
