<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "De metataggar du anger här kommer att skickas till rätt ställe.";

$ns -> tablerender("Metataggar", $text);
?>
