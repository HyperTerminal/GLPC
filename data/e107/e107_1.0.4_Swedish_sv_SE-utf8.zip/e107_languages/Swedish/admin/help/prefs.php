<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Dina preferenser låter dig specificera alla de viktiga inställningarna på din webbplats, allt från webbplatsnamn och beskrivning till flödesskydd och svordomsfilter.";
$ns -> tablerender("Hjälp för preferenser", $text);
?>
