<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Hjälp för förstasidan";
$text = "Från denna sida väljer du vad som skall visas som förstasida på webbplatsen. Standard är nyheter.";
$ns -> tablerender($caption, $text);

?>
