<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Härifrån kan du tillåta/förbjuda användarnas möjligheter att posta bilder på webbplatsen, samt sätta skalningsmetod och titta på uppladdade figurer(avatarer).";
$ns -> tablerender("Hjälp för bilder", $text);
?>
