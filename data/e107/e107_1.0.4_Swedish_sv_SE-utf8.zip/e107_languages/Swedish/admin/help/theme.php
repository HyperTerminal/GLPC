<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Temahanteraren låter dig sätta teman för din webbplats publika avdelning och för administratörssektionen.";
$ns -> tablerender("Hjälp för Temahanteraren", $text);
?>