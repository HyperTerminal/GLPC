<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Denna sida låter dig moderera dina registrerade användare. Du kan uppdatera deras inställningar, ge dem administatörstatus, sätta deras klass med mera.";
$ns -> tablerender("Hjälp för användare", $text);
unset($text);
?>
