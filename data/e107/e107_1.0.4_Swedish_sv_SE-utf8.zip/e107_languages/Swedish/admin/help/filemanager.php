<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons-de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Du kan hantera filerna i din /files katalog från denna sidan. Om du får felmeddelande om filrättigheter när du laddar upp, sätt då katalogen du försöker ladda upp till till CHMOD 777.";
$ns -> tablerender("Hjälp för Filhanteraren", $text);

?>
