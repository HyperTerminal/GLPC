<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Använd denna sida för att konfigurera dina e-postinställningar för webbplatsens utskicksfunktioner. Utskicksformuläret ger dig också möjlighet att skicka ut ett meddelande till alla dina användare.";
$ns -> tablerender("Hjälp för e-post", $text);
?>
