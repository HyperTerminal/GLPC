<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ange alla dina webbplatslänkar här. Länkar inlagda här kommer att visas i din huvudnavigeringsmeny. För externa länkar, vänligen använd programmet Länksida.
<br />
";
$ns -> tablerender("Hjälp för webbplatslänkar", $text);
?>
