﻿<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Rapporter skickar e-postrapporter när e107-händelser uppstår.<br /><br />
Till exempel, om du sätter 'IP blockering för flödning av webbplatsen' till klassen 'Admin' så kommer alla adminsistratörer att få ett meddelande via e-post när webbplatsen blir flödad.<br /><br />Du kan också, som ett annat exempel, sätta 'Nyhetsartikel postad av admin' till användarklass 'Medlemmar' och alla dina medlemmar kommer att få ett meddelande skickat till sig när du postar en nyhet på webbplatsen.<br /><br />Om du vill att rapporterna skall skickas till en alternativ e-postadress - välj då alternativet 'E-post' och ange e-postadressen i fältet avsett för detta.";

$ns -> tablerender("Hjälp för rapporter", $text);
?>
