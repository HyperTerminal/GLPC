<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Hjälp för nyhetsartiklar";
$text = "<b>Generellt</b><br />
Ingressen kommer att visas på huvudsidan, resten av nyhetsartikeln kan läsas genom att klicka på 'Läs mer'.
<br />
<br />
<b>Visa endast rubrik</b>
<br />
Aktivera detta för att endast visa rubriken på förstasidan, med en klickbar länk till hela nyhetsartikeln.
<br /><br />
<b>Aktivering</b>
<br />
Om du anger start och/eller slutdatum kommer nyhetsartikeln endast att visas mellan dessa datum.
";
$ns -> tablerender($caption, $text);
?>
