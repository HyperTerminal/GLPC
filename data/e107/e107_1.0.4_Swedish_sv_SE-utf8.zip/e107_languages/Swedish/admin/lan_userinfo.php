<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Kunde inte hitta postarens IP-adress - ingen information tillgänglig.");
// define("USFLAN_2", "Fel");
define("USFLAN_3", "Meddelanden postade från IP-adress");
define("USFLAN_4", "Värd");
define("USFLAN_5", "Klicka här för att överföra IP-adressen till adminstratörens blockeringssida");
define("USFLAN_6", "AnvändarID");
define("USFLAN_7", "Användarinformation");

?>