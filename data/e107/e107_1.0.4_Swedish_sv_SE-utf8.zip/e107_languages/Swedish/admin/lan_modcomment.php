<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Modererad");
define("MDCLAN_2", "Inga kommentarer för detta objekt");
define("MDCLAN_3", "Medlem");
define("MDCLAN_4", "Gäst");
define("MDCLAN_5", "Avblockera");
define("MDCLAN_6", "Blockera");
define("MDCLAN_7", "Godkänn");
define("MDCLAN_8", "Moderera kommentarer");
define("MDCLAN_9", "Varning! Radering av värdkommentar raderar också alla svar!");
define("MDCLAN_10", "Alternativ");
define("MDCLAN_11", "kommentar");
define("MDCLAN_12", "kommentarer");
define("MDCLAN_13", "blockerad");
define("MDCLAN_14", "lås kommentarer");
define("MDCLAN_15", "öppen");
define("MDCLAN_16", "låst");
define("MDCLAN_17", "För närvarande finns inga kommentarer som avvaktar godkännande");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>