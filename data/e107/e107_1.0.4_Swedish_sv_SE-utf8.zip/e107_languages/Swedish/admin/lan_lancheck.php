<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Kontrolleraa/ editera språkfiler");
define("LAN_CHECK_2", "Kontrollera");
define("LAN_CHECK_3", "Kontroll av");
define("LAN_CHECK_4", "Fil saknas!");
define("LAN_CHECK_5", "Fras saknas!");
define("LAN_CHECK_7", "fras");
define("LAN_CHECK_8", "En fil saknas...");
define("LAN_CHECK_9", " filer saknas...");
define("LAN_CHECK_10", "Kritiskt fel: ");
define("LAN_CHECK_11", "Inga saknade filer!");
define("LAN_CHECK_12", "En fil är felaktig...");
define("LAN_CHECK_13", " filer är felaktiga...");
define("LAN_CHECK_14", "Alla existerande filer är giltiga!");
define("LAN_CHECK_15", "Otillåtna tecken eller mellanrum hittade innan '&lt;?php' och efter '?&gt;'");
define("LAN_CHECK_16", "Original Fil");
define("LAN_CHECK_17", "Ett skrivproblem uppstod när försök att spara filen gjordes.");
define("LAN_CHECK_18", "Språkfiler i standardformat är INTE tillgängligt för det här programmet / temat");
define("LAN_CHECK_19", "Icke-UTF-8 tecken hittades!");
define("LAN_CHECK_20", "Generera (skapa) språkpaket");
define("LAN_CHECK_21", "Kontrollera igen");
define("LAN_CHECK_22", "Tema");
define("LAN_CHECK_23", "Fel som upptäckts");
define("LAN_CHECK_24", "Summering");
define("LAN_CHECK_25", "Teman");
define("LAN_CHECK_26", "Fil");


?>