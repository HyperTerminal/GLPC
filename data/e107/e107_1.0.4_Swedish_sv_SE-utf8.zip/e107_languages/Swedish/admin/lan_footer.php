<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Webbplats");
define("FOOTLAN_2", "Huvudadministratör");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "build");
define("FOOTLAN_5", "Administratörstema");
define("FOOTLAN_6", "av");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installationsdatum");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "värd");
define("FOOTLAN_11", "PHP version");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Webbplatsinfo");
define("FOOTLAN_14", "Visa dokument");
define("FOOTLAN_15", "Dokumentation");
define("FOOTLAN_16", "Databas");
define("FOOTLAN_17", "Teckenuppsättning");
define("FOOTLAN_18", "Webbplatstema");
define("FOOTLAN_19", "Nuvarande servertid");
define("FOOTLAN_20", "Säkerhetsnivå");


?>