<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/Swedish/admin/lan_upload.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/24 12:44:19 $
|     $Author: mrpiercer $
+----------------------------------------------------------------------------+
*/
define("UPLLAN_1", "Uppladdning borttagen från lista.");
define("UPLLAN_2", "Inställningar sparade i databasen");
define("UPLLAN_3", "UppladdningsID");
define("UPLLAN_5", "Insänd av");
define("UPLLAN_6", "E-post");
define("UPLLAN_7", "Webbplats");
define("UPLLAN_8", "Rubrik");
define("UPLLAN_9", "Version");
define("UPLLAN_10", "Fil");
define("UPLLAN_11", "Filstorlek");
define("UPLLAN_12", "Skärmdump");
define("UPLLAN_13", "Beskrivning");
define("UPLLAN_14", "Demo");
define("UPLLAN_16", "Skapa nyhetsartikel");
define("UPLLAN_17", "Ta bort uppladdning från lista");
define("UPLLAN_18", "Visa detaljer");
define("UPLLAN_19", "Det finns inga oövervakade publika uppladdade filer");
define("UPLLAN_20", "Det");
define("UPLLAN_21", "oövervakade publika uppladdningar");
define("UPLLAN_22", "ID");
define("UPLLAN_23", "Rubrik");
define("UPLLAN_24", "Fil");
define("UPLLAN_25", "Aktivera uppladdningar ( upload.php )?");
define("UPLLAN_26", "Inga publika uppladdningar tillåts om inaktiverad");
define("UPLLAN_27", "oövervakade publika uppladdningar");
define("UPLLAN_29", "Lagringstyp");
define("UPLLAN_30", "Välj hur uppladdade filer skall sparas; antingen som normala filer på servern eller som binär info i databasen.<br /><b>OBS</b> binärt är bara lämpligt för mindre filer under cirka 500 kB.");
define("UPLLAN_31", "Fil");
define("UPLLAN_32", "Binärt");
define("UPLLAN_33", "Maximal filstorlek");
define("UPLLAN_34", "Maximal filstorlek i bytes. Lämna tomt för att använda inställningen i php.ini");
define("UPLLAN_35", "Tillåtna filtyper");
define("UPLLAN_36", "Ange en typ per rad");
define("UPLLAN_37", "Behörighet");
define("UPLLAN_38", "Välj vilka användare som tillåts att ladda upp");
define("UPLLAN_39", "Spara");
define("UPLLAN_41", "Observera - filuppladdningar är inaktiverade i din php.ini, filer kommer inte att kunna laddas upp förrän du satt det till On i php.ini.");
define("UPLLAN_42", "Åtgärder");
define("UPLLAN_43", "Uppladdningar");
define("UPLLAN_44", "Uppladdning");
define("UPLLAN_45", "Är du säker på att du vill radera följande fil...");
define("UPLAN_COPYTODLM", "Kopiera till nedladdningshanteraren");
define("UPLAN_IS", "finns ");
define("UPLAN_ARE", "är ");
define("UPLAN_COPYTODLS", "Skapa nedladdning");
define("UPLLAN_48", "Av säkerhetsskäl har tillåtna filtyper flyttats ut från databasen till en textfil som finns i din adminkatalog. För att använda den, döp om filen e107_admin / filetypes_.php till e107_admin / filetypes.php och lägg till en kommaseparerad lista av filtypsändelser i filen. Du skall inte tillåta uppladdning av .html, .txt, etc eftersom om någon som attackerar din webbplats kan ladda en fil av denna typ som innehåller farliga javascript. Du skall självklart heller inte tillåta uppladdning av .php filer eller någon annan typ av exekverbart skript.");


?>