<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Förstasidans inställningar uppdaterade.");
define("FRTLAN_2", "Sätt förstasida för");
define("FRTLAN_6", "Länkar");
define("FRTLAN_12", "Uppdatera förstasidans inställningar");
define("FRTLAN_13", "Förstasidans inställningar");
define("FRTLAN_15", "Annat ( ange webbadress ):");
define("FRTLAN_16", "Fel: ingen huvudkategori ( typ ) vald");
define("FRTLAN_17", "Fel: ingen innehållskategori vald");
define("FRTLAN_18", "Fel: ingen innehållssida vald");
define("FRTLAN_19", "Huvudkategori ( Typ )");
define("FRTLAN_20", "Innehållskategori");
define("FRTLAN_21", "Innehållssida");
define("FRTLAN_22", "Egen sida");
define("FRTLAN_26", "alla användare");
define("FRTLAN_27", "gäster");
define("FRTLAN_28", "medlemmar");
define("FRTLAN_29", "administratörer");
define("FRTLAN_31", "alla användare");
define("FRTLAN_32", "användarklass");
define("FRTLAN_33", "Nuvarande inställningar");
define("FRTLAN_34", "Sida");


?>