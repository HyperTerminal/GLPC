<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|     $Swedish translation: hanssons.de $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Status för Cachesystem");
define("CACLAN_2", "Ställ in cachestatus");
define("CACLAN_3", "Cachesystem");
define("CACLAN_4", "Cachestatus är nu inställt");
define("CACLAN_5", "Töm cache");
define("CACLAN_6", "Cache tömd");

define("CACLAN_7", "Cache inaktiverad");
// define("CACLAN_8", "Cachedata sparad till MySQL");
define("CACLAN_9", "Cachedata sparad till fil på disk");
define("CACLAN_10", "Cachebiblioteket är skrivskyddat. Vänligen verifiera att katalogen är satt till CHMOD 0777");

?>