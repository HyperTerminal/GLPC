<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_email.php,v $
|     $Revision: 1.7 $
|     $Date: 2007/04/12 22:51:34 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_EMAIL_1", "المرسل:");
define("LAN_EMAIL_2", "عنوان IP المرسل:");
define("LAN_EMAIL_3", "الخبر من طرف");
define("LAN_EMAIL_4", "أرسل البريد");
define("LAN_EMAIL_5", "أرسل المقال لصديق");
define("LAN_EMAIL_6", "أعتقد بأنك قد تكون مهتما بهذا الموضوع من");
define("LAN_EMAIL_7", "أرسل لأحد ما");
define("LAN_EMAIL_8", "التعليق");
define("LAN_EMAIL_9", "عفواً - تعذر إرسال البريد");
define("LAN_EMAIL_10", "تم إرسال البريد بنجاح");
define("LAN_EMAIL_11", "إرسال البريد");
define("LAN_EMAIL_12", "خطأ");
define("LAN_EMAIL_13", "أرسل المقال لصديق");
define("LAN_EMAIL_14", "أرسل الخبر لصديق");
define("LAN_EMAIL_15", "اسم المستخدم:");
define("LAN_EMAIL_106", "بريد إلكتروني غير صحيح، تأكد من فضلك من المعلومات المدخلة.");
define("LAN_EMAIL_185", "أرسل المقال");
define("LAN_EMAIL_186", "أرسل الخبر");
define("LAN_EMAIL_187", "بريد المرسل إليه");
define("LAN_EMAIL_188", "أعتقد أنك ستكون مهتم بهذا الخبر من");
define("LAN_EMAIL_189", "أعتقد أنك ستكون مهتم بهذا المقال من");
define("LAN_EMAIL_190", "أدخل الكود الظاهر");


?>