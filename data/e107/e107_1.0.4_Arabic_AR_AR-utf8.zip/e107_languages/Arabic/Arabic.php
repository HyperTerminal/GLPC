<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/English.php,v $
|     $Revision: 1.11 $
|     $Date: 2007/08/13 19:56:30 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'ar');
setLocale(LC_TIME, "ar_SA.UTF-8");
define("CORE_LC", "AR");
define("CORE_LC2", "ar");
define("CHARSET", "utf-8");
define("TEXTDIRECTION","rtl");
define("CORE_LAN1", "خطأ : ستايل غير موجود.\\n\\nغير الستايل  المستعمل في الخصائص  ( المشرف العام  ) أو انسخ  الملفات الستايل الحالي إلى السيرفر.");
define("CORE_LAN4", "من فضلك أحذف ملف install.php من موقعك .");
define("CORE_LAN5", "إذا لم تقم بذلك ، فإن موقعك معرض لمخاطر الاختراق .");
define("CORE_LAN6", "نظام  الحماية من الفلود مفعل في هذا الموقع ، و بالتالي أي تكرار المحاولات قد يتم حجبك .");
define("CORE_LAN7", "المجلة ستحاول استرجاع الإعدادات من النسخ التلقائي .");
define("CORE_LAN8", "خطأ في خيارات نواة المجلة");
define("CORE_LAN9", "لم تتمكن  المجلة من الاسترجاع التلقائي للخصائص ، تنفيذ فاشل .");
define("CORE_LAN10", "تم ضبط كوكيز خاطئ - تم إخراجك من النظام .");
define("CORE_LAN11", "وقت تحميل الصفحة :");
define("CORE_LAN12", " ثانية,");
define("CORE_LAN13", " من الاستعلامات.");
define("CORE_LAN14", "");
define("CORE_LAN15", "استعلامات القاعدة :");
define("CORE_LAN16", "حجم الذاكرة المستخدمة :");
define("CORE_LAN17", "[ الصور معطلة ]");
define("CORE_LAN18", "صورة:");
define("CORE_LAN_B", "بايت");
define("CORE_LAN_KB", "كيلوبايت");
define("CORE_LAN_MB", "ميجابايت");
define("CORE_LAN_GB", "جيجابايت");
define("CORE_LAN_TB", "طيرابايت");
define("LAN_WARNING", "تنبيه !");
define("LAN_ERROR", "خطأ");
define("LAN_ANONYMOUS", "مجهول");
define("LAN_EMAIL_SUBS", "-بريد إلكتروني-");
define("LAN_SANITISED", "SANITISED");


?>