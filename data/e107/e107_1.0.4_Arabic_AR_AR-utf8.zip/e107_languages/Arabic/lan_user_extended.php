<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_user_extended.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/04/29 06:45:38 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Text Box");
define("UE_LAN_2", "Radio Buttons");
define("UE_LAN_3", "Drop-Down Menu");
define("UE_LAN_4", "DB Table Field");
define("UE_LAN_5", "Textarea");
define("UE_LAN_6", "متغير");
define("UE_LAN_7", "التاريخ");
define("UE_LAN_8", "اللغة");
define("UE_LAN_9", "الاسم");
define("UE_LAN_10", "النوع");
define("UE_LAN_11", "اسم الحقل");
define("UE_LAN_HIDE", "إخفاء على الأعضاء");
define("UE_LAN_LOCATION", "الاقامة");
define("UE_LAN_LOCATION_DESC", "مكان اقامة العضو");
define("UE_LAN_AIM", "عنوان AIM");
define("UE_LAN_AIM_DESC", "عنوان AIM");
define("UE_LAN_ICQ", "رقم ICQ");
define("UE_LAN_ICQ_DESC", "رقم ICQ");
define("UE_LAN_YAHOO", "بريد ياهوو");
define("UE_LAN_YAHOO_DESC", "بريد ياهوو");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "بريد MSN");
define("UE_LAN_HOMEPAGE", "الصفحة الشخصية");
define("UE_LAN_HOMEPAGE_DESC", "الموقع المفضل للعضو (url)");
define("UE_LAN_BIRTHDAY", "تاريخ الميلاد");
define("UE_LAN_BIRTHDAY_DESC", "تاريخ الميلاد");
define("UE_LAN_LANGUAGE", "اللغة");
define("UE_LAN_LANGUAGE_DESC", "لغة العضو");
define("UE_LAN_COUNTRY", "الدولة");
define("UE_LAN_COUNTRY_DESC", "دولة العضو (includes db table)");
define("LAN_UE_FAIL_HOMEPAGE", "مدخلة غير صحيحة للصفحة الشخصية");


?>