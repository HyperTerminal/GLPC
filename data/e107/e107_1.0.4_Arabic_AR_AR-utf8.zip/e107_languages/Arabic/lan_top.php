<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_top.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "أفضل الأعضاء مشاركة.");
define("TOP_LAN_1", "إسم المستخدم");
define("TOP_LAN_2", "المشاركات");
define("TOP_LAN_3", "أفضل الأعضاء تعليقا");
define("TOP_LAN_4", "التعليقات");
define("TOP_LAN_5", "أفضل الأعضاء لصندوق المحادثة");
define("TOP_LAN_6", "تقييم الموقع");
define("LAN_1", "موضوع");
define("LAN_2", "الكاتب");
define("LAN_3", "المشاهدات");
define("LAN_4", "الردود");
define("LAN_5", "آخر مشاركة");
define("LAN_6", "مواضيع");
define("LAN_7", "الموضوع الأكثر شعبية");
define("LAN_8", "أفضل الأعضاء");


?>