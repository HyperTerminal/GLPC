<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_contact.php,v $
|     $Revision: 1.5 $
|     $Date: 2009/07/18 17:00:49 $
|     $Author: marj_nl_fr $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define('PAGE_NAME',     'اتصل بنا');

define("LANCONTACT_01", "بيانات الاتصال بنا"); 
define("LANCONTACT_02", "نموذج الاتصال بنا"); 
define("LANCONTACT_03", "أدخل إسمك:"); 
define("LANCONTACT_04", "البريد الإلكتروني:"); 
define("LANCONTACT_05", "عنوان الرسالة:"); 
define("LANCONTACT_06", "أدخل نص الرسالة:"); 
define("LANCONTACT_07", "أرسل نسخة من هذه الرسالة إلى بريدك الالكتروني ."); 
define("LANCONTACT_08", "أرسل"); 
define("LANCONTACT_09", "تم إرسال رسالتك بنجاح."); 
define("LANCONTACT_10", "حدث مشكل أثناء محاولة إرسال رسالتك."); 
define("LANCONTACT_11", "بريدك الالكتروني غير صحيح .\\nمن فضلك تأكد منه ثم أعد المحاولة ."); 
define("LANCONTACT_12", "رسالتك قصيرة جدا."); 
define("LANCONTACT_13", "من فضلك أضف عنوان للرسالة."); 

define("LANCONTACT_14", "أرسل البريد ل :"); 
define("LANCONTACT_15", "كود التحقق الذي أدخلته خاطيء"); 
define("LANCONTACT_16", "أدخل الكود");

?>