<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_userclass2.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "تم إفراغ المجموعة من جميع الأعضاء.");
define("UCSLAN_2", "تم تحديث مجموعة الأعضاء.");
define("UCSLAN_3", "تم حذف المجموعة بنجاح.");
define("UCSLAN_4", "من فضلك ضع علامة في خانة تأكيد الحذف أمام زر الحذف.");
define("UCSLAN_5", "تم تحديث المجموعة بنجاح.");
define("UCSLAN_6", "تم حفظ المجموعة بنجاح.");
define("UCSLAN_7", "لا توجد مجموعات.");
define("UCSLAN_8", "المجموعات");
define("UCSLAN_11", "ضع علامة للتأكيد");
define("UCSLAN_12", "إسم المجموعة");
define("UCSLAN_13", "وصف المجموعة");
define("UCSLAN_14", "تحديث مجموعة العضو");
define("UCSLAN_15", "إضافة مجموعة جديدة");
define("UCSLAN_16", "دمج الأعضاء للمجموعة");
define("UCSLAN_17", "حذف العضو");
define("UCSLAN_18", "إفراغ المجموعة");
define("UCSLAN_19", "دمج الأعضاء في مجموعة");
define("UCSLAN_20", ".");
define("UCSLAN_21", "إعدادات المجموعات");
define("UCSLAN_22", "الأعضاء - إضغط لنقل العضو للمجموعة ...");
define("UCSLAN_23", "الأعضاء المنتسبون للمجموعة ...");
define("UCSLAN_24", "من سيدير المجموعة");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "اسم المستخدم");
define("UCSLAN_27", "الرجوع");


?>