<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2008/04/04 21:03:58 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "إرسال بريد إعلامي لكل من");
define("UCSLAN_2", "تم تحديث الصلاحيات");
define("UCSLAN_3", "عزيزي");
define("UCSLAN_4", "تم ترقية الصلاحيات الخاصة بك  في ");
define("UCSLAN_5", "الان انتتملك صلاحيات على الأقسام التالية : ");
define("UCSLAN_6", "اختر المجموعة التي سيدمج فيها العضو");
define("UCSLAN_7", "نقل العضو");
define("UCSLAN_8", "إعلام العضو");
define("UCSLAN_9", "تم تحديث الرتبة.");
define("UCSLAN_10", "مع تحياتنا الحارة ،");
define('UCSLAN_12', 'صلاحيات عضو فقط');
?>