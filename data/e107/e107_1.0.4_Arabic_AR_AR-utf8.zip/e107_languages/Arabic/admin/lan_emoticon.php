<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_emoticon.php,v $
|     $Revision: 1.11 $
|     $Date: 2007/05/29 19:45:31 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "تفعيل الابتسامات");
define("EMOLAN_2", "الاسم");
define("EMOLAN_3", "الابتسامات");
define("EMOLAN_4", "تفعيل الابتسامات ؟");
define("EMOLAN_5", "صورة");
define("EMOLAN_6", "كود اختصار الابتسامة");
define("EMOLAN_7", "فرق بين كل كود بواسطة فراغ");
define("EMOLAN_8", "الحالة");
define("EMOLAN_9", "الخيارات");
define("EMOLAN_10", "مفعل");
define("EMOLAN_11", "تفعيل الابتسامات");
define("EMOLAN_12", "تعديل / إدارة هذه المجموعة");
define("EMOLAN_13", "الابتسامات الموجودة");
define("EMOLAN_14", "حفظ الخيارات");
define("EMOLAN_15", "تعديل خيارات الابتسامات");
define("EMOLAN_16", "تم حفظ الاعدادات بنجاح");
define("EMOLAN_17", "ديك مجموعة ابتسامات تتضمن فراغات ، و هذا غير مسموح ! !");
define("EMOLAN_18", "من فضلك غير الأسماء التالية بحيث تصبح لا تتضمن فراغات في الاسم :");
define("EMOLAN_19", "الإسم");
define("EMOLAN_20", "المكان");
define("EMOLAN_21", "خطأ");
define("EMOLAN_22", "تم العثور على مجموعة ابتسامات جديدة :");
define("EMOLAN_23", "تم العثور على مجموعة ابتسامات   XML جديدة :");
define("EMOLAN_24", "تم العثور على ابتسامات PHP جديدة :");
define("EMOLAN_25", "Installing new PHP emotes:");
define("EMOLAN_26", "أعد فحص مجموعة الابتسامات");
define("EMOLAN_27", "Error occurred processing pack:");
define("EMOLAN_28", "توليد ملف XML");
define("EMOLAN_29", "تم إضافة الملف بنجاح :");
define("EMOLAN_30", "خطأ في كتابة الملف :");


?>