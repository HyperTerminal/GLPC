<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_e107_update.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/07/09 03:43:42 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "العملية");
define("LAN_UPDATE_3", "لا يحتاج لتحديث");
define("LAN_UPDATE_5", "يوجد تحديث");
define("LAN_UPDATE_7", "تنفيذ تحديث");
define("LAN_UPDATE_8", "تحديث من");
define("LAN_UPDATE_9", "إلى");
define("LAN_UPDATE_10", "التحديثات المتوفرة");
define("LAN_UPDATE_11", ".617 ألى .7 استمرار التحديث");
define("LAN_UPDATE_12", "إحدى الجداول تحتوي على مدخلات مكررة .");


?>