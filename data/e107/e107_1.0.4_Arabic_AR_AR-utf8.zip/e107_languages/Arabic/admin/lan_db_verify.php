<?php

define("DBLAN_1", "غير قادر على قراءة ملف بيانات القاعدة (sql datafile)<br /><br />من فضلك تأكد من أن الملف <b>core_sql.php</b> موجود في مجلد <b>/admin/sql</b> .");
define("DBLAN_2", "فحص الكل");
define("DBLAN_4", "الجدول");
define("DBLAN_5", "الحقل");
define("DBLAN_6", "الحالة");
define("DBLAN_7", "ملاحظة");
define("DBLAN_8", "غير صحيح");
define("DBLAN_9", "حاليا");
define("DBLAN_10", "ينبغي أن يكون");
define("DBLAN_11", "حقل ناقص");
define("DBLAN_12", "حقل زائد!");
define("DBLAN_13", "جدول ناقص!");
define("DBLAN_14", "إختر الجدول/الجداول للفحص : ");
define("DBLAN_15", "إبدأ الفحص");
define("DBLAN_16", "مراجعة SQL");
define("DBLAN_17", "العودة");
define("DBLAN_18", "(الجدول)");
define("DBLAN_19", "محاولة تصحيح");
define("DBLAN_20", "محاولة تصحيح الجداول");
define("DBLAN_21", "تصحيح المواد المختارة");
define("DBLAN_22", " غير مقروءة");
?>