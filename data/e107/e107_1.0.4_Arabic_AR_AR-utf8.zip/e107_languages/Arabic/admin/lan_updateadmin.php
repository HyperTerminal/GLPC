<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "خطأ - أعد  المحاولة من جديد");
define("UDALAN_2", "تم تحديث الإعدادات بنجاح");
define("UDALAN_3", "تم تحديث إعدادات");
define("UDALAN_4", "الإسم");
define("UDALAN_5", "كلمة المرور");
define("UDALAN_6", "إعد إدخال كلمة المرور");
define("UDALAN_7", "غير كلمة المرور");
define("UDALAN_8", "تحديث كلمة مرور");


?>