<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_banlist.php,v $
|     $Revision: 1.9 $
|     $Date: 2009/02/03 21:16:29 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "تم إلغاء الإيقاف.");
define("BANLAN_2", "لا يوجد موقوفين.");
define("BANLAN_3", "الأعضاء الموقوفين");
define("BANLAN_4", "إلغاء الإيقاف");
define("BANLAN_5", "أدخل عنوان IP، البريد الإلكتروني، أو المضيف (host)");
define("BANLAN_7", "السبب");
define("BANLAN_8", "إيقاف عضو");
define("BANLAN_9", "إيقاف أعضاء من الموقع");
define("BANLAN_10", "IP / بريد إلكتروني / السبب");
define("BANLAN_11", "عضو حاول الدخول بإسم عضو/كلمة مرور خاطئة.");
define("BANLAN_12", "ملاحظة : خاصية عكس DNS حاليا معطلة ،يجب تفعيلها ليتم حجب الهوست (host) ، حجب الإيبي و البريد ما زالا يعملان .");
define("BANLAN_13", "ملاحظة : لتوقيف العضو باسم المستخدم ، اذهب للوحة تحكم الأعضاء :");
define("BANLAN_78", "Hit count exceeded (--HITS-- requests within allotted time)");


?>