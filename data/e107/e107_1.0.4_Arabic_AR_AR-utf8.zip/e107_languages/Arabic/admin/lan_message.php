<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "الرسائل المستقبلة");
define("MESSLAN_2", "حذف الرسالة");
define("MESSLAN_3", "تم حذف الرسالة بنجاح.");
define("MESSLAN_4", "حذف جميع الرسائل");
define("MESSLAN_5", "تأكيد");
define("MESSLAN_6", "تم حذف جميع الرسائل.");
define("MESSLAN_7", "لا توجد رسائل.");
define("MESSLAN_8", "نوع الرسالة");
define("MESSLAN_9", "أبلغ عنها في");
define("MESSLAN_10", "أرسلت بواسطة");
define("MESSLAN_11", "فتح في نافذة مستقلة");
define("MESSLAN_12", "الرسالة");
define("MESSLAN_13", "الرابط");


?>