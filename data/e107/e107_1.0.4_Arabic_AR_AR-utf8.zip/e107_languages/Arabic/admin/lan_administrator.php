<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_administrator.php,v $
|     $Revision: 1.17 $
|     $Date: 2009/07/18 15:53:42 $
|     $Author: marj_nl_fr $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "مدخلة عضو/مشرف جديدة تم إنشائها من اجل");
define("ADMSLAN_1", "الآن في رتبة مشرف بالموقع.");
define("ADMSLAN_2", "تم تحديث خصائصه.");
define("ADMSLAN_3", "هو المدير العام للموقع و لا يمكن تعديل صلاحياته.");
define("ADMSLAN_4", "متابعة");
define("ADMSLAN_5", "خطأ !");
define("ADMSLAN_6", "هو المدير العام للموقع و لا يمكن حذفه.");
define("ADMSLAN_13", "قائمة المشرفين");
define("ADMSLAN_16", "إسم المشرف");
define("ADMSLAN_17", "كلمة المرور");
define("ADMSLAN_18", "الصلاحيات");
define("ADMSLAN_19", "تغيير - الخيارات");
define("ADMSLAN_20", "تغيير - القوائم");
define("ADMSLAN_21", "إضافة مشرفين");
define("ADMSLAN_22", "تعديل الأعضاء/الموقوفين إلخ...");
define("ADMSLAN_23", "إضافة/تعديل منتديات");
define("ADMSLAN_24", "إدارة أقسام التحميلات");
define("ADMSLAN_25", "رفع /إدارة الملفات");
define("ADMSLAN_26", "الإشراف على أقسام الأخبار");
define("ADMSLAN_27", "الإشراف على أقسام الروابط");
define("ADMSLAN_28", "إغلاق الموقع للصيانة");
define("ADMSLAN_29", "إدارة الإعلانات");
define("ADMSLAN_30", "تعديل الأخبار و عناوين الاخبار");
define("ADMSLAN_31", "تعديل الإبتسامات");
define("ADMSLAN_32", "تعديل محتوى الصفحة الرئيسية");
define("ADMSLAN_33", "تعديل سجل التتبع/الإحصائيات");
define("ADMSLAN_34", "تعديل meta tags");
define("ADMSLAN_35", "تعديل الملفات المرفوعة");
define("ADMSLAN_36", "تعديل المنتديات");
define("ADMSLAN_37", "تعديل التعليقات");
define("ADMSLAN_39", "إضافة اخبار");
define("ADMSLAN_40", "لإضافة روابط");
define("ADMSLAN_44", "إضافة تحميلات");
define("ADMSLAN_45", "إضافة استطلاع للرأي");
define("ADMSLAN_46", "رسالة ترحيبية");
define("ADMSLAN_47", "تعديل الأخبار المنشورة");
define("ADMSLAN_49", "تحدبد الكل");
define("ADMSLAN_51", "إلغاء الكل");
define("ADMSLAN_52", "تحديث الخصائص");
define("ADMSLAN_53", "أضف المشرف");
define("ADMSLAN_54", "المشرف");
define("ADMSLAN_55", "تركت بعض الحول فارغة");
define("ADMSLAN_56", "المشرف");
define("ADMSLAN_58", "المدير العام للموقع");
define("ADMSLAN_59", "حذف المشرف");
define("ADMSLAN_60", "هل أنت متاكد من أنك تريد تجريد صلاحيات المشرف من");
define("ADMSLAN_61", "تم حذف المشرف بنجاح");
define("ADMSLAN_62", "إدارة القوائم الإضافية");
define("ADMSLAN_64", "إفراغ cache");
define("ADMSLAN_65", "تعديل إعدادات البريد الإلكتروني و البريد الصادر");
define("ADMSLAN_66", "تعديل البحث");
define("ADMSLAN_67", "فحص بواسطة فاحص الملفات");
define("ADMSLAN_68", "تعديل");
define("ADMSLAN_69", "هذا أصلا مشرف و عليك تعديله.");
define("ADMSLAN_70", "العودة لصفحة المشرفين");
define("ADMSLAN_71", "إضغط هنا لمعرفة صلاحيات هذا المشرف");
define("ADMSLAN_76", "إدارة ملفات اللغة");


?>