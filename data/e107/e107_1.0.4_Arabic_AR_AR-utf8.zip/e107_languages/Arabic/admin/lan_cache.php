<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_cache.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/04/02 21:08:06 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "حالة نظام Cache");
define("CACLAN_2", "تعديل حالة cache");
define("CACLAN_3", "نظام Cache");
define("CACLAN_4", "تم تعديل إعدادات Cache");
define("CACLAN_5", "إفراغ Cache");
define("CACLAN_6", "تم إفراغ Cache بنجاح");
define("CACLAN_7", "Cache معطل");
define("CACLAN_9", "حفظ بيانات Cache في نظام الملفات");
define("CACLAN_10", "مجلد cache غير قابل للكتابة. تأكد من أن تصريح المجلد CHMOD 0777");


?>