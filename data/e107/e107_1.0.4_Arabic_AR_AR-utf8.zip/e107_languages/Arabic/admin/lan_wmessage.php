<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_wmessage.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/04/22 19:30:47 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "الرسالة الترحيبية");
define("WMLAN_01", "أضف رسالة ترحيبية");
define("WMLAN_02", "الرسالة");
define("WMLAN_03", "الرؤية");
define("WMLAN_04", "نص الرسالة الترحيبية");
define("WMLAN_05", "الإطار");
define("WMLAN_06", "في حالة التفعيل، سيتم عرض الرسالة داخل إطار مستقل بها");
define("WMLAN_07", "تجاهل النّظام العاديّ لاستخدام {WMESSAGE} shortcode:");
define("WMLAN_09", "لا توجد رسالة ترحيبية");
define("WMLAN_10", "عنوان رسالة الترحيب");


?>