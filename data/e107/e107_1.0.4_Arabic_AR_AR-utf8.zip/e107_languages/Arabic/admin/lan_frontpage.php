<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_frontpage.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/06/02 06:14:20 $
|     $Author: sweetas $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "تم تحديث خيارات الصفحة الرئيسية.");
define("FRTLAN_2", "ضبط صفحة البداية ل");
define("FRTLAN_6", "الروابط");
define("FRTLAN_12", "تحديث الإعدادت");
define("FRTLAN_13", "إعدادات الصفحة الرئيسية");
define("FRTLAN_15", "اخر (أدخل مسارurl):");
define("FRTLAN_16", "خطأ : لم  يتم تحديد اي قسم رئيسي");
define("FRTLAN_17", "خطأ : لم  يتم تحديد اس قسم فرعي");
define("FRTLAN_18", "خطأ : لم  يتم تحديد اي مقال");
define("FRTLAN_19", "القسم الرئيسي للمحتوى");
define("FRTLAN_20", "قسم المحتوى");
define("FRTLAN_21", "مقال المحتوى");
define("FRTLAN_22", "صفحة خاصة");
define("FRTLAN_26", "جميع المستخدمين");
define("FRTLAN_27", "الزوار");
define("FRTLAN_28", "الأعضاء");
define("FRTLAN_29", "المشرفين");
define("FRTLAN_31", "جميع المستخدمين");
define("FRTLAN_32", "المجموعات");
define("FRTLAN_33", "الإعدادت الحالية");
define("FRTLAN_34", "صفحة");


?>