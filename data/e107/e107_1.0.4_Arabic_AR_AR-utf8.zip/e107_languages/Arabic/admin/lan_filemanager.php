<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_filemanager.php,v $
|     $Revision: 1.6 $
|     $Date: 2005/06/14 23:35:15 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "تم رفعه");
define("FMLAN_2", "في");
define("FMLAN_3", "المجلد");
define("FMLAN_4", "الملف المرفع فاق الحجم الأقصى المسموح به (upload_max_filesize) في ملف إعدادات خادم الإستضافة (php.ini).");
define("FMLAN_10", "خطأ");
define("FMLAN_12", "ملف");
define("FMLAN_13", "ملفات");
define("FMLAN_14", "مجلد");
define("FMLAN_15", "مجلدات");
define("FMLAN_16", "المجلّد الرئيسي");
define("FMLAN_17", "الإسم");
define("FMLAN_18", "الحجم");
define("FMLAN_19", "آخر تحديث");
define("FMLAN_21", "ارفع ملف لهذا المجلد");
define("FMLAN_22", "رفع");
define("FMLAN_26", "تمت عملية الحذف");
define("FMLAN_27", "بنجاح");
define("FMLAN_28", "غير قادر على الحذف");
define("FMLAN_29", "المسار");
define("FMLAN_30", "Up level");
define("FMLAN_31", "مجلد");
define("FMLAN_32", "إختر المجلد");
define("FMLAN_33", "اختر");
define("FMLAN_34", "اختيار المجلد");
define("FMLAN_35", "مجلد الملفات");
define("FMLAN_36", "مجلد قوائم حسب الطلب");
define("FMLAN_37", "مجلد صفحات حسب الطلب");
define("FMLAN_38", "تمت بنجاح عملية النقل للملف ");
define("FMLAN_39", "غير قادر على نقل الملف");
define("FMLAN_40", "مجلد صور الأخبار");
define("FMLAN_43", "حذف الملفات المختارة");
define("FMLAN_46", "من فضلك هل أنت متأكد من أنك تريد حذف الملفات المختارة.");
define("FMLAN_47", "ملفات الأعضاء");
define("FMLAN_48", "نقل المختار إلى ");
define("FMLAN_49", "من فضلك هل انت متأكد من أنك تريد نقل الملفات النختارة ؟");
define("FMLAN_50", "نقل");
define("FMLAN_51", "خطأ غير معروف");


?>