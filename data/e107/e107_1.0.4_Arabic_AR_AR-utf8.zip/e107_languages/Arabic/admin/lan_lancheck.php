<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_lancheck.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/11/05 03:50:19 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "اختر اللغة التي تلريد فحص ملفاتها");
define("LAN_CHECK_2", "إبدأالفحص");
define("LAN_CHECK_3", "فحص ملف لغة : ");
define("LAN_CHECK_4", "ملف ناقص!");
define("LAN_CHECK_5", "جملة ناقصة!");
define("LAN_CHECK_7", "الجملة");
define("LAN_CHECK_8", "ملف ناقص...");
define("LAN_CHECK_9", " ملفات ناقصة ...");
define("LAN_CHECK_10", "خطأ فادح : ");
define("LAN_CHECK_11", "لا يوجد ملف ناقص !");
define("LAN_CHECK_12", "ملف خاطيء...");
define("LAN_CHECK_13", " ملفات خاطئة...");
define("LAN_CHECK_14", "جميع الملفات صحيحة !");
define("LAN_CHECK_15", "رموز غير مقبولة تم  العثور عليها قبل '<?php'");
define("LAN_CHECK_16", "الملف الأصلي");
define("LAN_CHECK_17", "حدث مشكل الكتابة أثناء محاولة الحفظ للملف .");
define("LAN_CHECK_18", "Language files in the standard format are NOT available for this plugin/theme.");
define("LAN_CHECK_19", "Non-UTF-8 characters found!");
define("LAN_CHECK_20", "توليد ملف اللغة");
define("LAN_CHECK_21", "إعادة الفحص");
define("LAN_CHECK_22", "القالب");
define("LAN_CHECK_23", "الأخطاء الموجودة ");
define("LAN_CHECK_24", "الملخص");
define("LAN_CHECK_25", "القوالب");
define("LAN_CHECK_26", "الملف");


?>