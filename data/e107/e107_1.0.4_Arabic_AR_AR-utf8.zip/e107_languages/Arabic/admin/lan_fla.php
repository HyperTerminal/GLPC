<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_fla.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/17 07:51:40 $
|     $Author: stevedunstan $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("FLALAN_1", "محاولات دخول فاشلة");
define("FLALAN_2", "لم يتم تسجيل أي عملية دخول فاشلة");
define("FLALAN_3", "تم الحذف.");
define("FLALAN_4", "عضو حاول الدخول باسم مستخدم و كلمة مرور خاطئة.");
define("FLALAN_5", "IP(s) موقوف");
define("FLALAN_6", "التاريخ");
define("FLALAN_7", "البيانات");
define("FLALAN_8", "عنوان/مضيف IP");
define("FLALAN_9", "الخيارات");
define("FLALAN_10", "حذف / إيقاف الخانات المعلمة");
define("FLALAN_11", "اخيار جميع الخانات حذف");
define("FLALAN_12", "إلغاء اختيار جميع الخانات حذف");
define("FLALAN_13", "اختيار جميع الخانات ايقاف");
define("FLALAN_14", "الغاء اختيار جميع خانات ايقاف");
define("FLALAN_15", "عناوين ال IP التالية تم ؟إيقافها تلقائيا - محاولات تسجيل دخول اكثر من عشر مرات فاشلة.");
define("FLALAN_16", "حذف لائحة الموقوفين تلقائيا");
define("FLALAN_17", "تم حذف لائحة الموقوفين تلقائيا بنجاح.");


?>