<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_userinfo.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "لم يتمكن من إيجاد معلومات العنوان IP - لا توجد معلومات.");
define("USFLAN_3", "تم إضافة مشاركات من العنوان IP التالي");
define("USFLAN_4", "المضيف");
define("USFLAN_5", "إضغط هنا لنقل عنوان IP إلى صفحة قائمة الموقوفين");
define("USFLAN_6", "رقم العضو");
define("USFLAN_7", "معلومات عن العضو");


?>