<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_modcomment.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/30 14:18:21 $
|     $Author: lisa_ $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "تم التعديل.");
define("MDCLAN_2", "لا توجد تعليقات.");
define("MDCLAN_3", "عضو");
define("MDCLAN_4", "ضيف");
define("MDCLAN_5", "إلغاء الحجب");
define("MDCLAN_6", "حجب");
define("MDCLAN_7", "موافقة");
define("MDCLAN_8", "تعديل التعليقات");
define("MDCLAN_9", "انتباه! حذف التعليقات الرئيسية سيتم حذف جميع التعليقات المتفرعة عنها!");
define("MDCLAN_10", "الخيارات");
define("MDCLAN_11", "تعليق");
define("MDCLAN_12", "التعليقات");
define("MDCLAN_13", "محجوبة");
define("MDCLAN_14", "حجب التعليقات");
define("MDCLAN_15", "فتح");
define("MDCLAN_16", "محجوبة");
define("MDCLAN_17", "لا يوجد تعليقات بانتظار التفعيل");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>