<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "سجل تتبع المشرفين");
define("LAN_ADMINLOG_1", "التاريخ");
define("LAN_ADMINLOG_2", "العنوان");
define("LAN_ADMINLOG_3", "الوصف");
define("LAN_ADMINLOG_4", "إيبي العضو");
define("LAN_ADMINLOG_5", "رقم العضو");
define("LAN_ADMINLOG_6", "أيقونة إعلامية");
define("LAN_ADMINLOG_7", "رسالة إعلامية");
define("LAN_ADMINLOG_8", " أيقونة الإعلام");
define("LAN_ADMINLOG_9", "رسالة الإعلام");
define("LAN_ADMINLOG_10", "أيقونة التنبيه");
define("LAN_ADMINLOG_11", "رسالة التنبيه");
define("LAN_ADMINLOG_12", "أيقونة خطأ");
define("LAN_ADMINLOG_13", "رسالة خطأ");


?>