<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/admin/lan_check_user.php,v $
|     $Revision: 1.2 $
|     $Date: 2009/01/06 20:58:08 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "فحص قاعدة بيانات المستخدم");
define("LAN_CKUSER_02", "سيتم فحص مجموعة من الأخطاء في قاعدة بيانات المستخدمين");
define("LAN_CKUSER_03", "إذا كنت تتوفر على عدد كبير من المستخدمين ، سيأخذ بعض الوقت ، أو ربما حتى استنفاذ الوقت");
define("LAN_CKUSER_04", "استمرار");
define("LAN_CKUSER_05", "البحث عن أسماء مستخدمين مكررة");
define("LAN_CKUSER_06", "اختر المهمة التي تريد تنفيذها");
define("LAN_CKUSER_07", "تم  العثور على أسماء مكررة ");
define("LAN_CKUSER_08", "لم يتم العثور على مكررات");
define("LAN_CKUSER_09", "اسم المستخدم ");
define("LAN_CKUSER_10", "ID المستخدم ");
define("LAN_CKUSER_11", "اسم الظهور");
define("LAN_CKUSER_12", "فحص بريد مستخدم مكرر");
define("LAN_CKUSER_13", "تم العثور على بريد إلكتروني مكرر");
define("LAN_CKUSER_14", "البريد  الإلكتروني");
define("LAN_CKUSER_15", "لم يتم العثور على متطايقان");
define("LAN_CKUSER_16", "Find entries where user name is someone else\'s login name");
define("LAN_CKUSER_17", "Conflicting user name and login name");
define("LAN_CKUSER_18", "المستخدم A");
define("LAN_CKUSER_19", "المستخدم B");
define("LAN_CKUSER_20", "");


?>