<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/09/16 18:18:04 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "إعلام");
define("NT_LAN_2", "توصل ببريد إعلامي عند");
define("NT_LAN_3", "معطل");
define("NT_LAN_4", "المدير العام");
define("NT_LAN_5", "على مستوى");
define("NT_LAN_6", "البريد");
define("NU_LAN_1", "أحداث العضو");
define("NU_LAN_2", "تسجيل عضو جديد");
define("NU_LAN_3", "تنشيط عضوية");
define("NU_LAN_4", "تسجيل دخول عضو");
define("NU_LAN_5", "تسجيل خروج عضو");
define("NS_LAN_1", "أحداث الامان و الحماية");
define("NS_LAN_2", "ايقاف IP للقيام بعملية فلوود");
define("NN_LAN_1", "أحداث الأخبار");
define("NN_LAN_2", "إرسال خبر من طرف عضو");
define("NN_LAN_3", "إضافة خبر من طرف مشرف");
define("NN_LAN_4", "التعديل على خبر من طرف مشرف");
define("NN_LAN_5", "حذف خبر من طرف مشرف");
define("NF_LAN_1", "أحداث الرفع");
define("NF_LAN_2", "ملف مرفوع من طرف العضو");
define("CM_LAN_1", "أحداث التعليق");
define("CM_LAN_2", "تم إضافة تعليق و هو بانتظار الموافقة .");


?>