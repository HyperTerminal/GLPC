<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_meta.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/06/07 05:04:58 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "تم تحديث Meta tags بنجاح.");
define("METLAN_2", "أدخل meta-tags");
define("METLAN_3", "تحديث إعدادات meta tag");
define("METLAN_4", "تم التحديث بنجاح");
define("METLAN_5", "اكتب وصفك هنا");
define("METLAN_6", "أكتب، مجموعة، من، الكلمات، المفتاحية، هنا،");
define("METLAN_7", "أكتب معلومات الحقوق هنا");
define("METLAN_8", "علامات التّعريف");
define("METLAN_9", "وصف الموقع");
define("METLAN_10", "الكلمات المفتاحية");
define("METLAN_11", "الحقوق");
define("METLAN_12", "استخدم عنوان الخبر و ملخصه كعلامة تعريف في صفحات الخبر (meta-description).");
define("METLAN_13", "الكاتب");


?>