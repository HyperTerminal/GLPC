<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/admin/lan_footer.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/12/29 17:45:38 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "إسم الموقع");
define("FOOTLAN_2", "المدير العام");
define("FOOTLAN_3", "الإصدار");
define("FOOTLAN_4", "بتاريخ");
define("FOOTLAN_5", "الستايل");
define("FOOTLAN_6", "بواسطة");
define("FOOTLAN_7", "معلومات");
define("FOOTLAN_8", "تاريخ التثبيث");
define("FOOTLAN_9", "الخادم");
define("FOOTLAN_10", "المضيف");
define("FOOTLAN_11", "إصدار PHP");
define("FOOTLAN_12", "خادم MySQL");
define("FOOTLAN_13", "معلومات عامة");
define("FOOTLAN_14", "عرض الوثائق");
define("FOOTLAN_15", "الوثائق");
define("FOOTLAN_16", "قاعدة البيانات");
define("FOOTLAN_17", "ترميز اللغة");
define("FOOTLAN_18", "استايل الموقع");
define("FOOTLAN_19", "توقيت السيرفر الحالي");
define("FOOTLAN_20", "مستوى الحماية");


?>