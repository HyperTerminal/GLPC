<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_userposts.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/11/30 19:36:50 $
|     $Author: sweetas $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "مشاركات العضو");
define("UP_LAN_0", "جميع مشاركات المنتدى ل");
define("UP_LAN_1", "كل تعليقات العضو");
define("UP_LAN_2", "موضوع");
define("UP_LAN_3", "المشاهدات");
define("UP_LAN_4", "الردود");
define("UP_LAN_5", "آخر مشاركة");
define("UP_LAN_6", "مواضيع");
define("UP_LAN_7", "لم يشارك بأي تعليق");
define("UP_LAN_8", "لم يقم بأي مشاركة");
define("UP_LAN_9", " في");
define("UP_LAN_10", "رد");
define("UP_LAN_11", "بتاريخ:");
define("UP_LAN_12", "بحث");
define("UP_LAN_13", "تعليقات");
define("UP_LAN_14", "مشاركات المنتدى");
define("UP_LAN_15", "رد");
define("UP_LAN_16", "عنوان IP");


?>