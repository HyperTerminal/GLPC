<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_userclass.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/29 06:53:06 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "الجميع (عام)");
define("UC_LAN_1", "الضيوف فقط");
define("UC_LAN_2", "لا أحد (معطل)");
define("UC_LAN_3", "الأعضاء فقط");
define("UC_LAN_4", "قراءة فقط");
define("UC_LAN_5", "المشرفين");
define("UC_LAN_6", "المدير العام");
define("UC_LAN_9", "أعضاء جدد");
define("UC_LAN_10", "بوتات البحث");


?>