<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_notify.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/04/11 01:43:42 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "تسجيل عضو جديد");
define("NT_LAN_UV_1", "تأكيد عضوية");
define("NT_LAN_UV_2", "رقم العضو");
define("NT_LAN_UV_3", "اسم  المستخدم للعضو :");
define("NT_LAN_UV_4", "إيبي العضو (IP):");
define("NT_LAN_LI_1", "تشجيل دخول العضو");
define("NT_LAN_LO_1", "تسجيل خروج العضو");
define("NT_LAN_LO_2", " سجل خروجه خارج الموقع");
define("NT_LAN_FL_1", "إيقافات الفلوود");
define("NT_LAN_FL_2", "إيقاف IP لقيامه بعملية فلوود على الموقع");
define("NT_LAN_SN_1", "تم إرسال خبر");
define("NT_LAN_NU_1", "تم التحديث");
define("NT_LAN_ND_1", "تم حذف خبر");
define("NT_LAN_ND_2", "تم حذف الخبر رقم");
define("NT_LAN_CM_1", "تعليق مستخدم بانتظار الموافقة");


?>