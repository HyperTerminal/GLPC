<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_membersonly.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/01/06 18:11:26 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "للأعضاء فقط");
define("LAN_MEMBERS_0", "منطقة محمية");
define("LAN_MEMBERS_1", "هذه منطقة خاصة بالأعضاء المسجلين فقط");
define("LAN_MEMBERS_2", "لمشاهدة محتويات هذه الصفحة عليك إما <a href='".e_LOGIN."'> تسجيل الدخول</a>");
define("LAN_MEMBERS_3", "أو <a href='".e_SIGNUP."'>التسجيل</a> كعظو جديد");
define("LAN_MEMBERS_4", "أظغط هنا للرجوع للصفحة الرئيسية");


?>