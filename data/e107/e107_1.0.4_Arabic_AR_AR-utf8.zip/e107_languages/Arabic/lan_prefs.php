<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../languages/Arabic/lan_prefs.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 00:06:19 $
|        $Author: الادارة $
+---------------------------------------------------------------+
*/

define("LAN_PREF_1", "الموقع بدعم من مجلة e107");
define("LAN_PREF_2", "نظام إدارة الموقع");
define("LAN_PREF_3", "هذا الموقع يعمل بنظام مجلة <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>,  التي تم إصدارها تحت نظام <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> الرخصة العمومية للجميع.");
define("LAN_PREF_4", "ممنوعة");
define("LAN_PREF_5", "المنتديات");


?>