<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_parser_functions.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/10/25 16:39:41 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_GUEST", "ضيف");
define("LAN_WROTE", "كتب");


?>