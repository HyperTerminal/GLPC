<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_mail_handler.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "ناتج عن مجلة e107 العربية");
define("LANMAILH_2", "هذه عدة أجزاء من رسالة ذات الصيغة MIME.");
define("LANMAILH_3", " غير متجانسة");
define("LANMAILH_4", "الخادم رفض العنوان");
define("LANMAILH_5", "لا يوجد رد فعل أو تجاوب من الخادم");
define("LANMAILH_6", "لم يتمكن من العثور على سيرفر البريد الإلكتروني.");
define("LANMAILH_7", " يبدوا أنه صحيح.");


?>