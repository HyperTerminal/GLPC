<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_news.php,v $
|     $Revision: 11465 $
|     $Date: 2010-04-07 16:36:23 -0400 (Wed, 07 Apr 2010) $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "آخر الأخبار");
define("LAN_NEWS_1", "الأخبار للأعضاء المعيّنين فقط");
define("LAN_NEWS_2", "لا تملك الصلاحيات لمشاهدة الخبر");
define("LAN_NEWS_9", "تم اختيارعرض العنوان فقط - <b>سيتم عرض العنوان فقط دون المحتوى </b><br />");
define("LAN_NEWS_10", "هذا الخبر <b>غير مفعل/غير نشط</b> (لن يظهر في الصفحة الرئيسية). ");
define("LAN_NEWS_11", "هذا الخبر <b>مفعل/نشط</b> (سيظهر في الصفحة الرئيسية). ");
define("LAN_NEWS_12", "إضافة التعليقات <b>مفعلة</b>. ");
define("LAN_NEWS_13", "إضافة التعليقات <b>معطلة</b>. ");
define("LAN_NEWS_14", "<br />فترة التفعيل: ");
define("LAN_NEWS_15", "طول النص : ");
define("LAN_NEWS_16", " حرف. طول النص الممتد : ");
define("LAN_NEWS_17", "حرف.");
define("LAN_NEWS_18", "معلومات:");
define("LAN_NEWS_19", "الآن");
define("LAN_NEWS_23", "أقسام الأخبار");
define("LAN_NEWS_24", "أنشاء ملف pdf لهذا الخبر ");
define("LAN_NEWS_25", "تعديل");
define("LAN_NEWS_31", "خبر مثبت");
define("LAN_NEWS_82", "الأخبار - قسم");
define("LAN_NEWS_83", "لم يتم نشر أي خبر لحد الساعة - عد لاحقا لزيارتنا و الإطلاع على اخر الأخبار.");
define("LAN_NEWS_84", "الرجوع لعرض كل الأخبار");
define("LAN_NEWS_85", "الرجوع للتصنيف");
define("LAN_NEWS_86", "خبر أقدم");
define("LAN_NEWS_87", "خبر أحدث");
define("LAN_NEWS_462", "لا توجد أخبار منشورة للشهر الذي اخترته.");
define("LAN_NEWS_99", "تعليقات");
define("LAN_NEWS_100", "في");
define("LAN_NEWS_307", "عدد  المشاركات في هذا التصنيف :");


?>