<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_date.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/24 11:23:45 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LANDT_01", "سنة");
define("LANDT_02", "شهر");
define("LANDT_03", "أسبوع");
define("LANDT_04", "يوم");
define("LANDT_05", "ساعة");
define("LANDT_06", "دقيقة");
define("LANDT_07", "ثانية");
define("LANDT_01s", "سنوات");
define("LANDT_02s", "شهور");
define("LANDT_03s", "أسابيع");
define("LANDT_04s", "أيام");
define("LANDT_05s", "ساعات");
define("LANDT_06s", "دقائق");
define("LANDT_07s", "ثوان");
define("LANDT_08", "دقيقة");
define("LANDT_08s", "دقائق");
define("LANDT_09", "ثانية");
define("LANDT_09s", "ثوان");
define("LANDT_AGO", "مضت");


?>