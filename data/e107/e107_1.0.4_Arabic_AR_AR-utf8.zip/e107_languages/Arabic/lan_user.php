<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvs_backup/e107_0.7/e107_languages/English/lan_user.php,v $
|     $Revision: 11520 $
|     $Date: 2010-05-04 15:04:37 -0400 (Tue, 04 May 2010) $
|     $Author: e107steved $
|     $Translation : AnouaroS $ 
+----------------------------------------------------------------------------+ 
*/ 
define("PAGE_NAME","الأعضاء");
define("LAN_20","خطأ");
define("LAN_112","البريد الإلكتروني");
//define("LAN_115", "ICQ Number");
//define("LAN_116", "AIM Address");
//define("LAN_117", "MSN Messenger");
//define("LAN_118", "Birthday");
//define("LAN_119", "Location");
//define("LAN_120", "Signature");
define("LAN_137","لا توجد معلومات عن هذا المستخدم لأنه غير مسجل في");
define("LAN_138","الأعضاء المسجلين: ");
define("LAN_139","رتب: ");
define("LAN_140","الأعضاء المسجلين");
define("LAN_141","لا يوجد أعضاء مسجلين لحد الساعة.");
define("LAN_142","العضو");
define("LAN_143","[تم طلب إخفائه]");
//define("LAN_144", "Website URL");
define("LAN_145","تاريخ التسجيل");
define("LAN_146","عدد الزيارات منذ التسجيل");
define("LAN_147","مشاراكات صندوق المحادثة");
define("LAN_148","عدد التعليقات");
define("LAN_149","عدد مشاراكات المنتدى");
define("LAN_308","الاسم الحقيقي");
define("LAN_400","عضو خاطيء . إذا كنت قد اتبعت رابط خاطيء , الرجاء إعلام المشرف العام.");
define("LAN_401","غير متوفر");
define("LAN_402","لوحة تحكم العضو");
define("LAN_403","إحصائيات العضو في الموقع");
define("LAN_404","آخر تواجد");
define("LAN_405","مرت منذ تاريخ التسجيل");
define("LAN_406","الرتبة");
define("LAN_407","لا شيء");
define("LAN_408","صورة شخصية غير متوفرة");
define("LAN_409","النقاط");
define("LAN_410","معلومات إضافية");
define("LAN_411","تعديل الملف الشخصي");
define("LAN_412","إضغط هنا لتعديل معلومات العضو");
define("LAN_413","حذف الصورة");
define("LAN_414","العضو السابق");
define("LAN_415","العضو التالي");
define("LAN_416","عليك تسجيل الدخول لمشاهدة الصفحة.");
define("LAN_417","المدير العام للموقع");
define("LAN_418","مشرف بالموقع");
define("LAN_419","عرض");
define("LAN_420","تنازلي");
define("LAN_421","تصاعدي");
define("LAN_422","رتب");
define("LAN_423","عرض جميع تعليقات العضو");
define("LAN_424","عرض جميع مشاركات العضو بالمنتدى");
define("LAN_425","أرسل رسالة خاصة للعضو");
define("LAN_426","مضت");
define("USERLAN_1","Peer Rating");
define("USERLAN_2","لا تملك الصلاحيات لرؤية هذه الصفحة .");

?>