<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_print.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/21 11:20:27 $
|     $Author: mrpete $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_PRINT_86", "الأقسام:");
define("LAN_PRINT_87", "بواسطة");
define("LAN_PRINT_94", "أرسلت بواسطة");
define("LAN_PRINT_135", "الخبر:");
define("LAN_PRINT_303", "قام بإرسال الخبر");
define("LAN_PRINT_304", "عنوان المقال:");
define("LAN_PRINT_305", "العنوان الفرعي:");
define("LAN_PRINT_306", "قام بإرسال المقال");
define("LAN_PRINT_307", "إطبع هذه الصفحة");
define("LAN_PRINT_1", "طباعة الصفحة");


?>