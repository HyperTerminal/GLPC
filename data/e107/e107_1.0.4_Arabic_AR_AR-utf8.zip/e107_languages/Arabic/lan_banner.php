<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/BANNERLAN_banner.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/02 13:59:40 $
|     $Author: lisa_ $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "الإعلانات");
define("BANNERLAN_16", "إسم العميل:");
define("BANNERLAN_17", "كلمة المرور:");
define("BANNERLAN_18", "تسجيل الدخول");
define("BANNERLAN_19", "من فضلك أدخل اسم العميل وكلمة المرور لتسجيل الدخول");
define("BANNERLAN_20", "لم يتم العثور على البيانات المدخلة في قاعدة البيانات ، عليك الاتصال بمدير الموقع .");
define("BANNERLAN_21", "إحصائيات الإعلانات");
define("BANNERLAN_22", "العميل");
define("BANNERLAN_23", "رقم الإعلان");
define("BANNERLAN_24", "النقرات");
define("BANNERLAN_25", "النسبة %");
define("BANNERLAN_26", "الظهور");
define("BANNERLAN_27", "النقرات المتفق عليها");
define("BANNERLAN_28", "النقرات المتبقية");
define("BANNERLAN_29", "بدون إعلانات");
define("BANNERLAN_30", "غير محدود");
define("BANNERLAN_31", "غير مطبقة");
define("BANNERLAN_32", "نعم");
define("BANNERLAN_33", "لا");
define("BANNERLAN_34", "<> ينتهي :");
define("BANNERLAN_35", "تم النقر من عنوان IP التالي </br>");
define("BANNERLAN_36", " نشط :");
define("BANNERLAN_37", " بدأ :");
define("BANNERLAN_38", "خطأ");


?>