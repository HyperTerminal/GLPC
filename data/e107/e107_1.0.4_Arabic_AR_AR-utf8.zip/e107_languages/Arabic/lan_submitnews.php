<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_submitnews.php,v $
|     $Revision: 1.5 $
|     $Date: 2009/08/17 19:22:16 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "أرسل خبر");
define("LAN_7", "إسم المستخدم:");
define("LAN_62", "الموضوع:");
define("LAN_112", "البريد الإلكتروني:");
define("LAN_133", "شكرا لك");
define("LAN_134", "تم إرسال الخبر بنجاح، و سيقوم أحد المشرفين بمراجعة الخبر و نشره في أقرب وقت ممكن.");
define("LAN_135", "محتوى الخبر:");
define("LAN_136", "أضف خبر");
define("NWSLAN_6", "القسم");
define("NWSLAN_10", "أقسام غير متوفرة");
define("NWSLAN_11", "لا تملك الصلاحيات للولوج إلى هذه المنطقة.");
define("NWSLAN_12", "دخول ممنوع.");
define("SUBNEWSLAN_1", "عليك إدخال عنوان للخبر.\\n");
define("SUBNEWSLAN_2", "عليك إدخال محتوى الخبر.\\n");
define("SUBNEWSLAN_3", "الملف المرفق يجب أن يكون صورة من نوع jpg, gif أو png");
define("SUBNEWSLAN_4", "ملف كبير");
define("SUBNEWSLAN_5", "الصورة");
define("SUBNEWSLAN_6", "(jpg, gif أو png)");
define("SUBNEWSLAN_7", "يرجى إدخال بريدك الالكتروني و اسمك الخاص");
define("SUBNEWSLAN_8", "يرجى إدخال بريدك الالكتروني و اسمك الاخاص");


?>