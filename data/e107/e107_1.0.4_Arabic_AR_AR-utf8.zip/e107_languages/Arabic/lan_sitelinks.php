<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_sitelinks.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/06/02 13:59:40 $
|     $Author: lisa_ $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_SITELINKS_183", "القائمة الرئيسية");
define("LAN_SITELINKS_502", "لوحة التحكم");


?>