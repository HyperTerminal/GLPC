<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_online.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:56 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "الزوار:");
define("ONLINE_EL2", "الأعضاء:");
define("ONLINE_EL3", "المتصفحون الآن:");
define("ONLINE_EL4", "المتواجدون الآن");
define("ONLINE_EL5", "عدد الأعضاء");
define("ONLINE_EL6", "نرحب بعضونا الجديد");
define("ONLINE_EL7", "يشاهد");
define("ONLINE_EL8", "أكبر عدد أعضاء تواجدوا كان");
define("ONLINE_EL9", "في");
define("ONLINE_EL10", "إسم المستخدم");
define("ONLINE_EL11", "يتصفح");
define("ONLINE_EL12", "يقوم بالرد على");
define("ONLINE_EL13", "منتدى");
define("ONLINE_EL14", "موضوع");
define("ONLINE_EL15", "صفحة");
define("CLASSRESTRICTED", "مجموعة غير مخول لها دخول الصفحة.");
define("ARTICLEPAGE", "المقالات/المراجعات");
define("CHAT", "صندوق المحادثة");
define("COMMENT", "التعليقات");
define("DOWNLOAD", "التحميلات");
define("EMAIL", "email.php");
define("FORUM", "الصفحة الرئيسية للمنتدى");
define("LINKS", "الروابط");
define("NEWS", "الأخبار");
define("OLDPOLLS", "استطلاعات قديمة");
define("POLLCOMMENT", "استطلاع للرأي");
define("PRINTPAGE", "طباعة الصفحة");
define("LOGIN", "تسجيل الدخول");
define("SEARCH", "البحث");
define("STATS", "إحصائيات الموقع");
define("SUBMITNEWS", "إرسال خبر");
define("UPLOAD", "رفع الملفات");
define("USERPAGE", "الملف الشخصي");
define("USERSETTINGS", "إعدادات العضو");
define("ONLINE", "المتواجدون الآن");
define("LISTNEW", "لائحة المستجدات");
define("USERPOSTS", "مشاركات العضو");
define("SUBCONTENT", "أرسل مقال/تقرير");
define("TOP", "أفضل الأعضاء/ أنشط المواضيع");
define("ADMINAREA", "لوحة التحكم");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "أحداث التقويم");
define("CALENDAR", "التقويم");
define("FAQ", "الأسئلة الشائعة");
define("PM", "الرسائل الخاصة");
define("SURVEY", "Survey");
define("ARTICLE", "المقالات");
define("CONTENT", "المقالات/المراجعات");
define("REVIEW", "التقارير");


?>