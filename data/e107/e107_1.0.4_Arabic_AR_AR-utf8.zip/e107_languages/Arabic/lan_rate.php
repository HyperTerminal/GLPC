<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_rate.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/27 11:45:50 $
|     $Author: lisa_ $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("RATELAN_0", "صوت");
define("RATELAN_1", "التصويتات");
define("RATELAN_2", "كيف تقيم هذه الموضوع ؟");
define("RATELAN_3", "شكرا لتصويتك");
define("RATELAN_4", "لم تقيم بعد");
define("RATELAN_5", "قيم");


?>