<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/English/lan_page.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/11/07 00:15:58 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LAN_PAGE_1", "تم إلغاء لائحة الصفحات");
define("LAN_PAGE_2", "لا توجد صفحات بعد .");
define("LAN_PAGE_3", "الصفحة المطلوية غير موجودة .");
define("LAN_PAGE_4", "قيم هذه الصفحة");
define("LAN_PAGE_5", "شكرا لتقييمك لهذه الصفحة .");
define("LAN_PAGE_6", "لا تملك الصلاحيات لمشاهدة هذه الصفحة");
define("LAN_PAGE_7", "كلمة مرور خاطئة");
define("LAN_PAGE_8", "صفحة محمية بكلمة مرور");
define("LAN_PAGE_9", "كلمة المرور");
define("LAN_PAGE_10", "أرسل");
define("LAN_PAGE_11", "قائمة الصفحات");
define("LAN_PAGE_12", "صفحة خاطئة");
define("LAN_PAGE_13", "صفحة");


?>