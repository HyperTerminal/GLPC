<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Arabic/lan_user_select.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/12/09 20:59:02 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "اختيار عضو");
define("US_LAN_2", "اختيار المجموعة");
define("US_LAN_3", "جميع الأعضاء");
define("US_LAN_4", "إيجاد عضو");
define("US_LAN_5", "تم العثور على");
define("US_LAN_6", "بحث");


?>