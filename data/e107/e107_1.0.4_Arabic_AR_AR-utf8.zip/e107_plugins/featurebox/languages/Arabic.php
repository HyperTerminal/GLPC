<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/featurebox/languages/English.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/04/01 11:03:59 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("FBLAN_01", "علبة النصوص");
define("FBLAN_02", "هذا البلوجين سيسمح لك بعرض نص بجانب الاخبار / ضع ما تشاء بالنص حتى بلغة html . النص سيتم عرضه باختيار عشوائي أو تلقائي الظهور .");
define("FBLAN_03", "إعدادات علبة النصوص");
define("FBLAN_04", "تم تثبيث علبة النصوص بنجاح . لأضافة نص و تعديله ، توجه للوحة التحكم و اظغط على ايقونة إعدادات علبة النصوص.");
define("FBLAN_05", "لا توجد نصوص بعد .");
define("FBLAN_06", "النصوص الموجودة للعرض");
define("FBLAN_07", "العنوان");
define("FBLAN_08", "نص الموضوع");
define("FBLAN_09", "حق الرؤية");
define("FBLAN_10", "أضف النص للرئيسية");
define("FBLAN_11", "تحديث نص الرسالة");
define("FBLAN_12", "نمط النصوص");
define("FBLAN_13", "اختيار النص عشوائيا من بين النصوص الموجودة");
define("FBLAN_14", "عرض هذا النص فقط");
define("FBLAN_15", "تم إضافة النص بنجاح.");
define("FBLAN_16", "تم تحديث الراسلة.");
define("FBLAN_17", "تركت بعض الحقول فارغة");
define("FBLAN_18", "تم حذف النص");
define("FBLAN_19", "الخيارات");
define("FBLAN_20", "تعديل");
define("FBLAN_21", "حذف");
define("FBLAN_22", "طريقة العرض");
define("FBLAN_23", "في جدول الستايل");
define("FBLAN_24", "بدون جدول");
define("FBLAN_25", "القوالب");
define("FBLAN_26", "يمكنك اختيار قالب لكل رسالة ، أضف القوالب في مجلد plugins/featurebox/templates/");


?>