<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/Arabic.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/22 19:49:56 $
|     $Author: e107coders $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "الإعلانات");
define("BANNER_MENU_L2", "تم حفظ إعدادات القائمة بنجاح");
define("BANNER_MENU_L3", "العنوان");
define("BANNER_MENU_L4", "الحملة");
define("BANNER_MENU_L5", "إعدادات قائمة الإعلانات");
define("BANNER_MENU_L6", "اختر الحملات لإظهارها في القائمة");
define("BANNER_MENU_L7", "الحملات المتوفرة");
define("BANNER_MENU_L8", "الحملات المختارة");
define("BANNER_MENU_L9", "حذف المختار");
define("BANNER_MENU_L10", "كيف تريد ان يتم طهور الإعلانات المختارة ?");
define("BANNER_MENU_L11", "اختر طريقة عرض الإعلان ...");
define("BANNER_MENU_L12", "كل حملة في قائمة فردية");
define("BANNER_MENU_L13", "كل الحملات المعلمة في قائمة فردية");
define("BANNER_MENU_L14", "كل الحملات المعلمة في قائمة منفصلة");
define("BANNER_MENU_L15", "عدد البانرات المراد ظهورها ؟");
define("BANNER_MENU_L16", "هذا الإعداد سيعمل فقط مع الخيار 2 و 3.<br />if less banners are present the maximum available amount will be used.");
define("BANNER_MENU_L17", "ظبط العدد ...");
define("BANNER_MENU_L18", "تحديث الإعدادات");


?>