<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/English/English.php,v $
|     $Revision: 1.8 $
|     $Date: 2009/05/26 20:05:36 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "لا يمكن قبول رسالة بواسطة من هذا الاسم مادام مسجل لدينا ، إذا كان هذا اسم المستخدم الخاص بك سجل دخولك للموقع لإضافة المشاركة .");
define("CHATBOX_L2", "صندوق المحادثة");
define("CHATBOX_L3", "عليك تسجيل الدخول لإضافة المشاركة ، من فضلك سجل دخولك و إذا كنت غير مسجل يمكنك التسجيل <a href='".e_BASE."signup.php'>من هنا</a>");
define("CHATBOX_L4", "أرسل");
define("CHATBOX_L5", "إفراغ");
define("CHATBOX_L6", "[تم حجب الرسالة من طرف المشرف]");
define("CHATBOX_L7", "رفع الحجب");
define("CHATBOX_L8", "معلومات");
define("CHATBOX_L9", "حجب");
define("CHATBOX_L10", "حذف");
define("CHATBOX_L11", "لا توجد رسائل بعد.");
define("CHATBOX_L12", "مشاهدة كل المشاركات");
define("CHATBOX_L13", "تعديل المشاركات");
define("CHATBOX_L14", "الابتسامات");
define("CHATBOX_L15", "مشاركة طويلة جدا ، أو مشاركة فارغة");
define("CHATBOX_L16", "زائر");
define("CHATBOX_L17", "مشاركة مكررة");
define("CHATBOX_L18", "تم تعديل المشاركات بنجاح");
define("CHATBOX_L19", "You may only post once every ".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." seconds");
define("CHATBOX_L20", "صندوق المحادثة (كل المشاركات)");
define("CHATBOX_L21", "مشاركات الصندوق");
define("CHATBOX_L22", "في");
define("CHATBOX_L23", "خطأ!");
define("CHATBOX_L24", "لا تملك الصلاحيات لرؤية هذه الصفحة .");
define("CHATBOX_L25", "[ هذه الرسالة تم حجبها من طرف المشرف ]");
define("NT_LAN_CB_1", "أحداث صندوق المراسلة");
define("NT_LAN_CB_2", "تم إرسال المشاركة");
define("NT_LAN_CB_3", "بواسطة");
define("NT_LAN_CB_4", "عنوان IP");
define("NT_LAN_CB_5", "الرسالة");
define("NT_LAN_CB_6", "Chatbox Message Posted");


?>