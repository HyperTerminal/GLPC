<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/Arabic/Arabic_config.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/06 01:06:09 $
|     $Author: mcfly_e107 $
|     Encoding:
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "تم تحديث الإدادات بنجاح.");
define("CHBLAN_2", "تم التعديل.");
define("CHBLAN_3", "لا توجد رسائل بعد.");
define("CHBLAN_4", "عضو");
define("CHBLAN_5", "زائر");
define("CHBLAN_6", "رفع الحجب");
define("CHBLAN_7", "حجب");
define("CHBLAN_8", "حذف");
define("CHBLAN_9", "تعديل الرسائل");
define("CHBLAN_10", "تعديل المشاركات");
define("CHBLAN_11", "عدد المشاركات المراد ظهورها");
define("CHBLAN_12", "عدد المشاركات التي تريد ظهورها في صندوق المحادثة");
define("CHBLAN_13", "تعويض الروابط");
define("CHBLAN_14", "عند تفعيلها سيتم تعويض الروابط بالنص المدخل في الخانة");
define("CHBLAN_15", "نص التعويض  في حالة التفعيل");
define("CHBLAN_16", "الروابط سيتم تعويضها بهذه الكلمة");
define("CHBLAN_17", "Wordwrap count");
define("CHBLAN_18", "words longer than the number you set here will be wrapped");
define("CHBLAN_19", "تحديث الإعدادات");
define("CHBLAN_20", "إعدادات صندوق المحادثة");
define("CHBLAN_21", "حذف");
define("CHBLAN_22", "حذف مشاركات أقدم من مدة معينة");
define("CHBLAN_23", "حذف مشاركات أفدم من");
define("CHBLAN_24", "يوم واحد");
define("CHBLAN_25", "أسبوع واحد");
define("CHBLAN_26", "شهر واحد");
define("CHBLAN_27", "- حذف جميع المشاركات -");
define("CHBLAN_28", "تم الحذف بنجاح.");
define("CHBLAN_29", "عرض الصندوق داخل إطار");
define("CHBLAN_30", "طول الإطار");
define("CHBLAN_31", "عرض الابتسامات");
define("CHBLAN_32", "مجموعة المشرفين على الصندوق");
define("CHBLAN_33", "تم تحديث العدادات بنجاح");
define("CHBLAN_34", "تحديث عداد مشاركات العضو");
define("CHBLAN_35", "تحديث العداد");
define("CHBLAN_36", "خصائص عرض صندوق المحادثة");
define("CHBLAN_37", "العرض الافتراضي");
define("CHBLAN_38", "استخدام تقنية (AJAX)");


?>