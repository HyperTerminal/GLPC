<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/linkwords/languages/English.php,v $
|     $Revision: 1.5 $
|     $Date: 2007/07/23 21:02:23 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("LWLAN_1", "تركت بعض الحقول فارغة .");
define("LWLAN_2", "تم الحفظ بنجاح .");
define("LWLAN_3", "تم التحديث بنجاح .");
define("LWLAN_4", "لا توجد كلمات مدخلة بعد .");
define("LWLAN_5", "الكلمة");
define("LWLAN_6", "مسار الرابط");
define("LWLAN_7", "تفعيل ؟");
define("LWLAN_8", "الخيارات");
define("LWLAN_9", "نعم");
define("LWLAN_10", "لا");
define("LWLAN_11", "الكلمات الموجودة");
define("LWLAN_12", "نعم");
define("LWLAN_13", "لا");
define("LWLAN_14", "أضف الكلمة");
define("LWLAN_15", "تحديث");
define("LWLAN_16", "تعديل");
define("LWLAN_17", "حذف");
define("LWLAN_18", "هل أنت متأكد من أنك تريد حذف هذه الكلمة ورابطها ؟");
define("LWLAN_19", "تم الحذف بنجاح .");
define("LWLAN_20", "غير قادر على إيجاد هذه المدخلة .");
define("LWLAN_21", "الكلمة التي سيتم تعويضها برابط");
define("LWLAN_22", "تفعيل ؟");
define("LWLAN_23", "إدارة ربط الكلمات");
define("LWLAN_24", "إدارة الكلمات");
define("LWLAN_25", "الخيارات");
define("LWLAN_26", "المناطق التي سيتم تفعيل ربط الكلمات فيها");
define("LWLAN_27", "This is the 'context' of the displayed text");
define("LWLAN_28", "الصفحات التي سيتم تعطيل ربط الكلمات فيها");
define("LWLAN_29", "Same format as menu visibility control. One match per line. Specify a partial or complete URL. End with '!' for exact match of the end part of the link");
define("LWLAN_30", "حفظ التغييرات");
define("LWLAN_31", "إضافة/تعديل كلمة");
define("LWLAN_32", "خيارات ربط الكلمة");
define("LWLAN_33", "عناوين القوائم");
define("LWLAN_34", "ملخصات الأخبار و المواضيع");
define("LWLAN_35", "نص الموضوع");
define("LWLAN_36", "الوصف ( الدليل ، المحتوى ... إلخ ...)");
define("LWLAN_37", "Legacy areas");
define("LWLAN_38", "الروابط النشيطة");
define("LWLAN_39", "Unprocessed text");
define("LWLAN_40", "User-entered titles (e.g. forum)");
define("LWLAN_41", "User-entered body text (e.g. forum)");
define("LWLANINS_1", "ربط الكلمات");
define("LWLANINS_2", "هذا البلوجين سيقوم بتعويض كلمات معينة برابط");
define("LWLANINS_3", "إعدادات ربط الكلمات");
define("LWLANINS_4", "لتغيير الإعدادات قم بالدخول الى رابط القائمة بلوحة التحكم .");


?>