<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../plugins/usertheme_menu/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:20:15 $
|        $Author: الادارة $
+---------------------------------------------------------------+
*/

define("LAN_UMENU_THEME_1", "اعتمد الستايل");
define("LAN_UMENU_THEME_2", "شكل الواجهة");
define("LAN_UMENU_THEME_3", "الاستخدام :");
define("LAN_UMENU_THEME_4", "قم بتحدي الستايلات التي يمكن للأعضاء استخدامها");
define("LAN_UMENU_THEME_5", "تحديث");
define("LAN_UMENU_THEME_6", "الستايلات المتاحة للأعضاء");
define("LAN_UMENU_THEME_7", "الموجوعة المخول لها باستخدام الستايلات");


?>