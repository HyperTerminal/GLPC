<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../plugins/newforumposts_main/languages/Arabic.php Arabic language file
|        Translated using translator plugin by Izydor (www.izydor.net)
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NFPM_LAN_1", "المواضيع في القسم");
define("NFPM_LAN_2", "كاتب الموضوع ");
define("NFPM_LAN_3", "المشاهدات");
define("NFPM_LAN_4", "ردود");
define("NFPM_LAN_5", "آخر مشاركة");
define("NFPM_LAN_6", "المواضيع في القسم");
define("NFPM_LAN_7", "بواسطة");
define("NFPM_L1", "هذا البلوجين يقوم بعرض اخر المشاركات في المنتدى في الصفحة الرئسية");
define("NFPM_L2", "اخر المشاركات في المنتدى");
define("NFPM_L3", "لتعديل الخيارات قم بالضعط على الرابط في قسم البلوجينات الموجود في الصفحة الرئسية للمدير");
define("NFPM_L4", "في اي منطقة تريد عرضها ؟");
define("NFPM_L5", "تعطيل");
define("NFPM_L6", "اعلى الصفحة الرئسية");
define("NFPM_L7", "اسفل الصفحة الرئسية");
define("NFPM_L8", "اسم القائمة");
define("NFPM_L9", "عدد المواضيع الجديدة للعرض ؟");
define("NFPM_L10", "عرض داخل scrolling layer ؟");
define("NFPM_L11", "عرض الطبقة");
define("NFPM_L12", "الخيارات");
define("NFPM_L13", "تحديث");
define("NFPM_L14", "تم التحديث بنجاح");
define("NFPM_L15", "ضع علامة  لعرض  آخر مشركات  المنتدى.<br />الافتراضي ، آخر المواضيع.");
define("NFPM_L16", "[عضو محذوف]");
define("NFPM_L17", "ردود جديدة قي مواضيع نشطة");
define("NFPM_L18", "ردود جديدة");
define("NFPM_L19", "لا توجد ردود جديدة في مواضيع نشطة");
define("NFPM_L20", "لا توجد ردود جديدة");
define("NFPM_L21", "مواضيع مثبتة");
define("NFPM_L22", "مواضيع مثبتة مغلقة");
define("NFPM_L23", "الإعلانات");
define("NFPM_L24", "مواضيع مغلقة");


?>