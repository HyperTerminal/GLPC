<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/Arabic.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/22 18:07:49 $
|     $Author: stevedunstan $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "زيارات المشرف العام لن يتم احتسابها.");
define("COUNTER_L2", "زيارات الصفحة اليوم ...");
define("COUNTER_L3", "المجموع");
define("COUNTER_L4", "إجمالي الزيارات للصفحة  ...");
define("COUNTER_L5", "انفرادي");
define("COUNTER_L6", "الموقع ...");
define("COUNTER_L7", "الإحصائيات الشاملة");
define("COUNTER_L8", "رسالة إدارية: <b>نظام الإحصائيات غير مفعل.</b><br /> لتفعيله, عليك تثبيث قائمة الإحصائيات من لوحة التحكم في منطقة  <a href='".e_ADMIN."plugin.php'> القوائم الإضافية</a> ، و بعدها عليك تفعيلها من  <a href='".e_PLUGIN."log/admin_config.php'>إعدادات الإحصائيات</a>.");


?>