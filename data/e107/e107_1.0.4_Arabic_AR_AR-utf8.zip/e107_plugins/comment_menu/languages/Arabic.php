<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| �Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
| Translation : AnouaroS $
+---------------------------------------------------------------+
*/
define("CM_L1", "لا توجد تعليقات بعد .");
define("CM_L2", "");
define("CM_L3", "عنوان القائمة");
define("CM_L4", "عدد التعليقات المراد ظهورها ؟");
define("CM_L5", "عدد الحروف المراد ظهورها ؟");
define("CM_L6", "كلمة التتمة للتعليقات الطويلة ؟");
define("CM_L7", "إظهار عنوان الخبر الأصلي في القائمة ؟");
define("CM_L8", "إعدادات  قائمة آخر التعليقات");
define("CM_L9", "تحديث العدادات");
define("CM_L10", "تم حفظ الإعدادات بنجاح");
define("CM_L11", "في");
define("CM_L12", "رد :");
define("CM_L13", "أرسلت بواسطة");


?>