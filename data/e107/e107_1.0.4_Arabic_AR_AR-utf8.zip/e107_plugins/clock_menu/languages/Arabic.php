<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/Arabic.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/	
define("CLOCK_MENU_L1", "تم حفظ إعدادات الساعة بنجاح");
define("CLOCK_MENU_L2", "العنوان");
define("CLOCK_MENU_L3", "تحديث الاعدادات");
define("CLOCK_MENU_L4", "إعدادات الساعة");
define("CLOCK_MENU_L5", "الإثنين،");
define("CLOCK_MENU_L6", "الثلاثاء،");
define("CLOCK_MENU_L7", "الأربعاء،");
define("CLOCK_MENU_L8", "الخميس،");
define("CLOCK_MENU_L9", "الجمعة،");
define("CLOCK_MENU_L10", "السبت،");
define("CLOCK_MENU_L11", "الأحد،");
define("CLOCK_MENU_L12", "يناير");
define("CLOCK_MENU_L13", "فبراير");
define("CLOCK_MENU_L14", "مارس");
define("CLOCK_MENU_L15", "أبريل");
define("CLOCK_MENU_L16", "ماي");
define("CLOCK_MENU_L17", "يونيو");
define("CLOCK_MENU_L18", "يوليوز");
define("CLOCK_MENU_L19", "غشت");
define("CLOCK_MENU_L20", "شتمبر");
define("CLOCK_MENU_L21", "أكتوبر");
define("CLOCK_MENU_L22", "نونبر");
define("CLOCK_MENU_L23", "دجنبر");
define("CLOCK_MENU_L24", "");


?>