<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../plugins/pdf/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:06:24 $
|        $Author: الادارة $
+---------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "توليد ملف PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "القائمة الان قابلة للإستخدام");
define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "إعدادات PDF");
define("PDF_LAN_3", "تفعيل");
define("PDF_LAN_4", "تعطيل");
define("PDF_LAN_5", "هامس الصفحة في اليسار");
define("PDF_LAN_6", "هامش الصفحة في اليمين");
define("PDF_LAN_7", "هامش الصفحة في الأعلى");
define("PDF_LAN_8", "نوع الخط");
define("PDF_LAN_9", "حجم الخط الافتراضي");
define("PDF_LAN_10", "حجم خط اسم الموقع");
define("PDF_LAN_11", "حجم خط رابط الصفحة");
define("PDF_LAN_12", "حجم خط رقم الصفحة");
define("PDF_LAN_13", "عرض اللوجو في ملف PDF ؟");
define("PDF_LAN_14", "عرض اسم الموقع في ملف PDF ؟");
define("PDF_LAN_15", "عرض رابط الصفحة في ملف PDF ؟");
define("PDF_LAN_16", "عرض عدد الصفحات في ملف PDF ؟");
define("PDF_LAN_17", "تحديث");
define("PDF_LAN_18", "تم تحديث إعدادات PDF بنجاح");
define("PDF_LAN_19", "الصفحة");
define("PDF_LAN_20", "تقرير الخطأ");


?>