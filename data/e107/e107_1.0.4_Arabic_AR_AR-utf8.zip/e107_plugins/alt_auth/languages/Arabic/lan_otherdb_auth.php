<?php
/*
+---------------------------------------------------------------+
|        e107 website system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../mods/alt_auth/languages/Arabic/lan_otherdb_auth.php $
|        $Revision: 1.0 $
|        $Date: 2010/08/21 20:42:51 $
|        $Author: النجاح هوست $
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "نوع قاعدة البيانات:");
define("OTHERDB_LAN_2", "الخادم Server:");
define("OTHERDB_LAN_3", "Username:");
define("OTHERDB_LAN_4", "Password:");
define("OTHERDB_LAN_5", "القاعدة");
define("OTHERDB_LAN_6", "الجدول");
define("OTHERDB_LAN_7", "حقل Username :");
define("OTHERDB_LAN_8", "حقل Password Field:");
define("OTHERDB_LAN_9", "Password Method:");
define("OTHERDB_LAN_10", "Configure otherdb auth");
define("OTHERDB_LAN_11", "** الحقول التالية ليست ضرورية إذا كنت ستستخدم قاعدة المجلة");


?>