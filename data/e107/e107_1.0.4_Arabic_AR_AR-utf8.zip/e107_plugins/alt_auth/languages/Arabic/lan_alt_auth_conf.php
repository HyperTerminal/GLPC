<?php
/*
+---------------------------------------------------------------+
|        e107 website system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $Source: ../mods/alt_auth/languages/Arabic/lan_alt_auth_conf.php $
|        $Revision: 1.0 $
|        $Date: 2010/08/21 20:41:11 $
|        $Author: النجاح هوست $
+---------------------------------------------------------------+
*/
define("LAN_ALT_2", "تحديث الخيارات");
define("LAN_ALT_3", "اختر طريقة مراقبة تسجيل الدخول ");
define("LAN_ALT_4", "Configure parameters for");
define("LAN_ALT_5", "Configure authorization parameters");
define("LAN_ALT_6", "استعلام دخول فاشل");
define("LAN_ALT_7", "If connection to the alternate method fails, how should that be handled?");
define("LAN_ALT_8", "استعلام عدم العثور على المستخدم");
define("LAN_ALT_9", "If username is not found using alternate method, how should that be handled?");
define("LAN_ALT_10", "دخول خاطيء");
define("LAN_ALT_11", "استخدم جدول الأعضاء الخاص بالمجلة");
define("LAN_ALT_PAGE", "مراقبة تسجيل الدخول البديلة");


?>