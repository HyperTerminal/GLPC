<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_extended_menu/languages/Arabic.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/12/23 18:37:52 $
|     $Author: e107steved $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "الزوار: ");
define("ONLINE_EL2", "الأعضاء: ");
define("ONLINE_EL3", "على هذه الصفحة: ");
define("ONLINE_EL4", "المتواجدون");
define("ONLINE_EL5", "الأعضاء");
define("ONLINE_EL6", "مرحباً بالعضو الجديد");
define("ONLINE_EL7", "يشاهد");
define("ONLINE_EL8", "أكثر عدد تواجد : ");
define("ONLINE_EL9", "في");
define("ONLINE_TRACKING_MESSAGE", "خاصية متابعة الأعضاء غير مفعلة ، من فضلك فعلها من [link=".e_ADMIN."users.php?options]من هنا[/link][br]");


?>