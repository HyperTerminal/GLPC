<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/other_news_menu/languages/Arabic.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/11/23 14:53:38 $
|     $Author: mcfly_e107 $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("TD_MENU_L1", "أخبار أخرى");
define("TD_MENU_L2", "أخبار أخرى 2");


?>