<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/lastseen/languages/Arabic.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/06/28 20:13:14 $
|     $Author: stevedunstan $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("LSP_LAN_1", "اخر تواجد");


?>