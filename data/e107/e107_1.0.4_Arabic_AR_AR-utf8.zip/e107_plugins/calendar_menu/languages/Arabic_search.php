<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../plugins/calendar_menu/languages/Arabic_search.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 01:10:39 $
|        $Author: الادارة $
+---------------------------------------------------------------+
*/

define("CM_SCH_LAN_1", "التقويم");


?>