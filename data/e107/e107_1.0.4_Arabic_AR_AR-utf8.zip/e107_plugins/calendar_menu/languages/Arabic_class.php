<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Arabic_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/15 01:58:13 $
|        $Author: Administrator $
+---------------------------------------------------------------+
*/
define("EC_LAN_RECUR_00", "لا");
define("EC_LAN_RECUR_01", "سنوي");
define("EC_LAN_RECUR_02", "سنتان");
define("EC_LAN_RECUR_03", "كل ثلاثة شهور");
define("EC_LAN_RECUR_04", "شهري");
define("EC_LAN_RECUR_05", "4 أسابيع");
define("EC_LAN_RECUR_06", "نصف شهري");
define("EC_LAN_RECUR_07", "أسبوعي");
define("EC_LAN_RECUR_08", "يومي");
define("EC_LAN_RECUR_100", "الأحد في شهر");
define("EC_LAN_RECUR_101", "الإثنين في شهر");
define("EC_LAN_RECUR_102", "ثلاثاء في شهر");
define("EC_LAN_RECUR_103", "أربعاء في شهر");
define("EC_LAN_RECUR_104", "خميس في شهر");
define("EC_LAN_RECUR_105", "جمعة في شهر");
define("EC_LAN_RECUR_106", "سبت في شهر");
define("EC_LAN_RECUR_1100", "أول");
define("EC_LAN_RECUR_1200", "ثان");
define("EC_LAN_RECUR_1300", "ثالث");
define("EC_LAN_RECUR_1400", "رابع");
define("NT_LAN_EC_1", "Event Calendar Events");
define("NT_LAN_EC_2", "تم تحديث الحدث");
define("NT_LAN_EC_3", "تحديث بواسطة");
define("NT_LAN_EC_4", "عنوان الايبي");
define("NT_LAN_EC_5", "الرسالة");
define("NT_LAN_EC_6", "Event Calendar - Event added");
define("NT_LAN_EC_7", "تم إضافة حدث جديد");
define("NT_LAN_EC_8", "Event Calendar - Event modified");
define("EC_ADM_01", "Event Calendar - أضف حدث");
define("EC_ADM_02", "Event Calendar - نعديل حدث");
define("EC_ADM_03", "Event Calendar - حذف حدث");
define("EC_ADM_04", "Event Calendar - Bulk Delete");
define("EC_ADM_05", "Event Calendar - Multiple Add");
define("EC_ADM_06", "Event Calendar - Main options changed");
define("EC_ADM_07", "Event Calendar - FE options changed");
define("EC_ADM_08", "Event Calendar - Category added");
define("EC_ADM_09", "Event Calendar - Category edited");
define("EC_ADM_10", "Event Calendar - Category deleted");
define("EC_ADM_11", "Event Calendar - Old events deleted");


?>