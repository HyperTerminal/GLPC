<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| �Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
| Translation : AnouaroS $
+---------------------------------------------------------------+
*/
define("BLOGCAL_L1", "الأرشيف لسنة");
define("BLOGCAL_L2", "الأرشيف");
define("BLOGCAL_D1", "إ");
define("BLOGCAL_D2", "ث");
define("BLOGCAL_D3", "أ");
define("BLOGCAL_D4", "خ");
define("BLOGCAL_D5", "ج");
define("BLOGCAL_D6", "س");
define("BLOGCAL_D7", "أ");
define("BLOGCAL_M1", "يناير");
define("BLOGCAL_M2", "فبراير");
define("BLOGCAL_M3", "مارس");
define("BLOGCAL_M4", "أبريل");
define("BLOGCAL_M5", "ماي");
define("BLOGCAL_M6", "يونيو");
define("BLOGCAL_M7", "يوليوز");
define("BLOGCAL_M8", "غشت");
define("BLOGCAL_M9", "شتنبر");
define("BLOGCAL_M10", "أكتوبر");
define("BLOGCAL_M11", "نونبر");
define("BLOGCAL_M12", "دجنبر");
define("BLOGCAL_1", "الأخبار");
define("BLOGCAL_CONF1", "عدد أعمدة الشهور في الصف");
define("BLOGCAL_CONF2", "مساحة الخانات");
define("BLOGCAL_CONF3", "حفظ الإعدادات");
define("BLOGCAL_CONF4", "إعدادات قائمة الأرشيف");
define("BLOGCAL_CONF5", "تم حفظ الإعدادات بنجاح");
define("BLOGCAL_ARCHIV1", "اختر من الأرشيف");


?>