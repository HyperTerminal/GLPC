<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/Arabic.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/02/22 18:20:52 $
|     $Author: stevedunstan $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("TRACKBACK_L1", "إعدادات قائمة المتابعات");
define("TRACKBACK_L2", "هذا اليلوجين سيقوم بإضافة المتابعات لمشاركات الأخبار </p><p>مسار المتابعات لهذه المشاركة .");
define("TRACKBACK_L3", "تم تثبيث و تفعيل المتابعات الان .");
define("TRACKBACK_L4", "تم حفظ الإعدادات بنجاح.");
define("TRACKBACK_L5", "مفعل");
define("TRACKBACK_L6", "معطل");
define("TRACKBACK_L7", "تفعيل المتابعات");
define("TRACKBACK_L8", "نص مسار المتابعات");
define("TRACKBACK_L9", "حفظ الإعدادات");
define("TRACKBACK_L10", "إعدادات قائمة  المتابعات");
define("TRACKBACK_L11", "مسار المتابعات لهذه المشاركة :");
define("TRACKBACK_L12", "لا توجد متابعة لهذا الخبر");
define("TRACKBACK_L13", "تعديل المتابعات");
define("TRACKBACK_L14", "حذف");
define("TRACKBACK_L15", "تم الحذف بنجاح .");


?>