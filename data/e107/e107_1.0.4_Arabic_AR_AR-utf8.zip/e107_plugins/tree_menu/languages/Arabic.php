<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/Arabic.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/10/07 02:54:20 $
|     $Author: sweetas $
|     $Translation : AnouaroS $
+----------------------------------------------------------------------------+
*/
define("TREE_L1", "إعدادات قائمة Tree Menu");
define("TREE_L2", "تحديث الإعدادات");
define("TREE_L3", "تم حفظ الإعدادات بنجاح.");
define("TREE_L4", "مفعل");
define("TREE_L5", "معطل");
define("TREE_L6", "CSS class to use for non-openable links");
define("TREE_L7", "CSS class to use for openable links");
define("TREE_L8", "CSS class to use for opened links");
define("TREE_L9", "Use spacer class between main links");


?>