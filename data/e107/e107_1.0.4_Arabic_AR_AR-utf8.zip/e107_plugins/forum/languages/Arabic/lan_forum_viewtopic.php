<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_viewtopic.php,v $
|     $Revision: 1.12 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "المنتدى");
define("LAN_01", "المنتديات");
define("LAN_02", "انتقل للصفحة");
define("LAN_03", "اذهب");
define("LAN_04", "السابق");
define("LAN_05", "القادم");
define("LAN_06", "تاريخ الانضمام");
define("LAN_07", "المكان");
define("LAN_08", "الموقع");
define("LAN_09", "زيارات للموقع منذ تسجيلك :");
define("LAN_10", "للأعلى");
define("LAN_65", "الانتقال إلى");
define("LAN_66", "هذا الموضوع غير مغلق");
define("LAN_67", "المشاركات");
define("LAN_194", "زائر");
define("LAN_195", "عضو مسجل");
define("LAN_321", "المشرفين:");
define("LAN_389", " الموضوع السابق");
define("LAN_390", "الموضوع التالي");
define("LAN_391", "متابعة الموضوع");
define("LAN_392", "إلغاء متابعة الموضوع");
define("LAN_393", " الرد السريع");
define("LAN_394", "معاينة");
define("LAN_395", "أضف الرد السريع");
define("LAN_396", "الموقع");
define("LAN_397", "البريد");
define("LAN_398", "الملف الشخصي");
define("LAN_399", "رسالة خاصة");
define("LAN_400", "تعديل");
define("LAN_401", "اقتباس");
define("LAN_402", "الكاتب");
define("LAN_403", "الموضوع");
define("LAN_404", "لا توجد مواضيع سابقة");
define("LAN_405", "لا توجد مواضيع قادمة");
define("LAN_406", "المشرف: تعديل");
define("LAN_435", "المشرف: حذف");
define("LAN_408", "المشرف: نقل");
define("LAN_409", "هل انت متأكد من أنك تريد حذف هذه المشاركة مع كل الردود ؟");
define("LAN_410", "هل أنت متأكد من أنك تريد حذف هذا الرد ؟");
define("LAN_411", "بواسطة");
define("LAN_412", "العنوان");
define("LAN_413", "تقرير");
define("LAN_414", "تقرير بمشاركة سيئة");
define("LAN_415", "عنوان الموضوع");
define("LAN_416", "الرسالة:");
define("LAN_417", "ملاحظة: هذا يستخدم فقط للإبلاغ عن مشاركات تحوي رسائل الدعاية, الرسائل الإعلانية, والمشاكل (مضايقة, قتال, أو وقاحة) .");
define("LAN_418", "<b>لا تستخدم</b> هذا النموذج للاتصال بالمشرف لأسبا اخرى.");
define("LAN_419", "إرسال التقرير");
define("LAN_420", "إضغط لمشاهدة المشاركة");
define("LAN_421", "تقرير من منتدى");
define("LAN_422", "هذا التقرير عن المشاركة تم إرسالهم من موقع");
define("LAN_423", "لم يتمكن من إرسال البريد.");
define("LAN_424", "تم إرسال التقرير للمشرف على القسم.<br />شكرا لك.");
define("LAN_425", "رسالة من طرف:");
define("LAN_426", "تقرير عن مشاركة بعنوان :");
define("LAN_427", "خطأ اثناء إرسال البريد");
define("LAN_428", "تم إرسال التقرير بنجاح");
define("LAN_429", "إضغط هنا للعودة للقسم.");
define("LAN_430", "استطلاع الرأي");
define("FORLAN_26", "تم حذف الرد");
define("FORLAN_10", "موضوع جديد");
define("LAN_29", "معدل");
define("LAN_431", "Syndicate this thread: rss 0.92");
define("LAN_432", "Syndicate this thread: rss 2.0");
define("LAN_433", "Syndicate this thread: RDF");
define("FORLAN_101", "أرسل الموضوع");
define("FORLAN_102", "نسخة للطباعة");
define("FORLAN_103", "[عضو محذوف]");
define("FORLAN_104", "لم يتم العثور على الموضوع");
define("FORLAN_HIDDEN", "HIDDEN - LOGIN AND REPLY TO REVEAL");


?>