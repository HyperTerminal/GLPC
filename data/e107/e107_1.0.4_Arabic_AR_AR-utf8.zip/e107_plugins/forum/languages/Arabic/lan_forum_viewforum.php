<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_viewforum.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/09/06 01:12:01 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "المنتدى");
define("LAN_01", "المنتديات");
define("LAN_02", "للأعلى");
define("LAN_03", "اذهب");
define("LAN_53", "المواضيع في القسم");
define("LAN_54", " كاتب الموضوع");
define("LAN_55", "ردود");
define("LAN_56", "المشاهدات");
define("LAN_57", "آخر مشاركة");
define("LAN_58", "لا توجد مواضيع في هذا القسم .");
define("LAN_59", "عليك ان تكون مسجلا لتتمكن من المشاركة في هذا القسم .");
define("LAN_79", "مشاركات جديدة");
define("LAN_80", " لا يوجد مشاركات جديدة");
define("LAN_81", "الموضوع مغلق");
define("LAN_180", "بحث");
define("LAN_199", "توجد مشاركات غير مقروءة");
define("LAN_202", "مثبث");
define("LAN_203", "مثبث/مغلق");
define("LAN_204", "<b>تستطيع</b> كتابة مواضيع جديدة <br />");
define("LAN_205", "<b>لا تستطيع</b> كتابة مواضيع جديدة <br />");
define("LAN_206", "<b>تستطيع</b> كتابة ردود جديدة <br />");
define("LAN_207", "<b>لا تستطيع</b> كتابة ردود جديدة <br />");
define("LAN_208", "<b>تستطيع</b> تحرير مشاركاتك");
define("LAN_209", "<b>لا تستطيع</b> تحرير مشاركاتك");
define("LAN_316", "اذهب للصفحة:");
define("LAN_317", "لا شيء");
define("LAN_321", "المشرفين:");
define("LAN_395", "[شعبي]");
define("LAN_396", "إعلان");
define("LAN_397", "هذا القسم في وضع القراءة فقط.");
define("LAN_398", "إلغاء تثبيث الموضوع");
define("LAN_399", "إغلاق الموضوع");
define("LAN_400", "فتح الموضوع");
define("LAN_401", "تثبيث الموضوع");
define("LAN_402", "نقل الموضوع");
define("LAN_403", "الانتقال إلى");
define("LAN_404", "المشرفين");
define("LAN_405", " مستخدم يتصفخ هذا القسم حاليا");
define("LAN_406", "مستخدمين يتصفحون هذا القسم حاليا");
define("LAN_407", "عضو");
define("LAN_408", "زائر");
define("LAN_409", "أعضاء");
define("LAN_410", "زوار");
define("LAN_411", "المواضيع المثبثة للفائدة");
define("LAN_412", "المواضيع");
define("LAN_431", "Syndicate this forum: rss 0.92");
define("LAN_432", "Syndicate this forum: rss 2.0");
define("LAN_433", "Syndicate this forum: RDF");
define("LAN_434", "هل انت متاكد من أنك تريد حذف الموضوع مع جميع الردود ؟");
define("LAN_435", "حذف الموضوع");
define("FORLAN_CLOSE", "تم إغلاق الموضوع بنجاح.");
define("FORLAN_OPEN", "تم فتح الموضوع بنجاح.");
define("FORLAN_STICK", "تم تثبيث الموضوع بنجاح.");
define("FORLAN_UNSTICK", "تم إلغاء تثبيث الموضوع بنجاح.");
define("FORLAN_6", "تم حذف الموضوع بنجاح");
define("FORLAN_7", "تم حذف الردود بنجاح");
define("FORLAN_8", "هنا");
define("FORLAN_9", "للتسجيل أو تسجيل الدخول من قائمة الدخول.");
define("FORLAN_10", "إضافة موضوع جديد");
define("FORLAN_11", "مشاركات جديدة");
define("FORLAN_12", "لا يوجد مشاركات جديدة");
define("FORLAN_13", "New Posts on Popular Thread");
define("FORLAN_14", "No New Posts on Popular Thread");
define("FORLAN_15", "موضوع مثبث");
define("FORLAN_16", "موضوع مثبث مغلق");
define("FORLAN_17", "موضوع الإعلان");
define("FORLAN_18", "الموضوع مغلق");
define("FORLAN_19", "[عضو محذوف]");
define("FORLAN_20", "المنتديات الفرعية");
define("FORLAN_21", "المواضيع");
define("FORLAN_22", "آخر مشاركة");


?>