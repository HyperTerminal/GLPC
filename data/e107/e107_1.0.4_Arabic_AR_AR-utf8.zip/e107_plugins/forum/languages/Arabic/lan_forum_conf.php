<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_conf.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/22 19:49:58 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_FORUM_INSTALL_01", "المنتدى");
define("LAN_FORUM_INSTALL_02", "هاته القائمة تحتوى على نظام منتدى  متكامل ");
define("LAN_FORUM_INSTALL_03", "إعدادات المنتدى");
define("LAN_FORUM_INSTALL_04", "تم  الان تثبيت المنتدى");
define("LAN_FORUM_INSTALL_05", "تمت ترقية المنتدى بنجاح ، الان تستخدم الإصدار %1$s");
define("LAN_FORUM_INSTALL_06", "[منتدى]");
define("LAN_FORUM_INSTALL_07", "[المزيد...]");
define("FORLAN_5", "تم حذف استطلاع الرأي.");
define("FORLAN_6", "تم حذف الموضوع");
define("FORLAN_7", "تم حذف الردود.");
define("FORLAN_8", "تم إلغاء حذف البموضوع.");
define("FORLAN_9", "تم نقل الموضوع بنجاح.");
define("FORLAN_10", "تم إلغاء نقل الموضوع.");
define("FORLAN_11", "العودة للمنتدى");
define("FORLAN_12", "أدوات المنتدى");
define("FORLAN_13", "هل أنت متاكد من انك تريد حذف الاستطلاع ؟ <br />بمجرد حذفك له  <b><u>لا يمكن</u></b> استرجاعه.");
define("FORLAN_14", "إلغاء");
define("FORLAN_15", "تاكيد حذف مشاركة القسم");
define("FORLAN_16", "تاكيد حذف استطلاع الرأي");
define("FORLAN_17", "بواسطة");
define("FORLAN_18", "هل انت متأكد من انك تريد حذف القسم");
define("FORLAN_19", "الموضوع مع جميع الردود ؟");
define("FORLAN_20", "سيتم حذف الاستطلاع أيضا");
define("FORLAN_21", "بمجرد حذفك لهم");
define("FORLAN_22", "المشاركة ؟<br />بمجرد حذفك لها");
define("FORLAN_23", "لا يمكنك</u></b> التراجع فيما بعد .");
define("FORLAN_24", "انقل الموضوع للقسم الجديد");
define("FORLAN_25", "نقل الموضوع");
define("FORLAN_26", "تم حذف الرد .");
define("FORLAN_27", "منقول");
define("FORLAN_28", "عدم نغيير عنوان الموضوع");
define("FORLAN_29", "أضف");
define("FORLAN_30", "للعنوان");
define("FORLAN_31", "عنوان الموضوع الجديد :");
define("FORLAN_32", "خيارات تغيير عنوان الموضوع :");


?>