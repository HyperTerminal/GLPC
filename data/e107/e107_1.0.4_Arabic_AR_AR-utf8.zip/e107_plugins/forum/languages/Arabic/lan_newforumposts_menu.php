<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     �Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/05/27 19:25:00 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "جميع المشاركات الاخيرة خارج مجموعة الاعضاء ، غير ممكن عرضهم..");
define("NFP_2", "لا توجد مواضيع بعد.");
define("NFP_3", "تم حفظ إعدادات القائمة بنجاح.");
define("NFP_4", "عنوان القائمة");
define("NFP_5", "عدد المشاركات التي سيتم عرضها ؟");
define("NFP_6", "عدد الحروف التي سيتم عرضها ؟");
define("NFP_7", "كلمة المتابعة للمشاركات الطويلة ؟");
define("NFP_8", "عرض الموضوع الأصلي في القائمة ؟.");
define("NFP_9", "تحديث الإعدادات");
define("NFP_10", "إعدادات قائمة اخر المشاركات بالمنتدى");
define("NFP_11", "بواسطة");
define("NFP_12", "العمر الزمني الأقصى للمشاركات المعروضة");
define("NFP_13", "Use zero on a quiet site; setting a value in days will reduce database time on a busy site");


?>