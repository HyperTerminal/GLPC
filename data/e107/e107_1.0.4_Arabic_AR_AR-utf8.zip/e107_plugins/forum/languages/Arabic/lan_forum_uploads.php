<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/24 20:43:34 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "المرفقات بالمنتدى");
define("FRMUP_1", "ملفاتك المرفقة في المنتديات");
define("FRMUP_2", "تم حذف الملف بنجاح");
define("FRMUP_3", "خطأ: غير قادر على حذف الملف");
define("FRMUP_4", "عملية حذف الملف");
define("FRMUP_5", "اسم الملف");
define("FRMUP_6", "النتائج");
define("FRMUP_7", "تم العثور عليه في الموضوع");
define("FRMUP_8", "غير موجودة");
define("FRMUP_9", "لا توجد ملفات مرفقة خاصة بك");
define("FRMUP_10", "حذف");


?>