<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/English/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "إحصائيات المنتدى");
define("FSLAN_1", "معلومات عامة");
define("FSLAN_2", "تم افتتاح المنتدى يوم");
define("FSLAN_3", "مدة عمل المنتدى");
define("FSLAN_4", "عدد المشاركات");
define("FSLAN_5", "عدد المواضيع");
define("FSLAN_6", "عدد الردود");
define("FSLAN_7", "تمت مشاهدة مواضيع المنتدى");
define("FSLAN_8", "حجم قاعدة البيانات (جداول المنتدى فقط)");
define("FSLAN_9", "كتوسط حجم المدخلات في كل سطر من جدول المنتدى");
define("FSLAN_10", "المواضيع الاكثر نشاطا");
define("FSLAN_11", "الرتبة");
define("FSLAN_12", "الموضوع");
define("FSLAN_13", "الردود");
define("FSLAN_14", "الكاتب");
define("FSLAN_15", "التاريخ");
define("FSLAN_16", "المواضيع الاكثر مشاهدة");
define("FSLAN_17", "المشاهدات");
define("FSLAN_18", "الاعضاء الاكثر نشاطا");
define("FSLAN_19", "الاسم");
define("FSLAN_20", "المشاركات");
define("FSLAN_21", "الاكثر كتابة للمواضيع");
define("FSLAN_22", "الأكثر ردودا");
define("FSLAN_23", "إحصائيات المنتدى");
define("FSLAN_24", "متوسط المشاركات في اليوم الواحد");


?>