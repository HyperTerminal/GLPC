<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/kubrick/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:35:09 $
|        $Author: Naja7host.com $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'kubrick' by <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Based on original theme by Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "تم إلغاء التعليقات لهذا الخبر");
define("LAN_THEME_3", "التعليق:");
define("LAN_THEME_4", "التفاصيل...");
define("LAN_THEME_5", "المتابعات:");
define("LAN_THEME_6", "بتاريخ");
define("LAN_THEME_7", "بواسطة");


?>