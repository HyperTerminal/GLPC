<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/human_condition/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:24:46 $
|        $Author: الادارة $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' by <a href='http://e107.org' rel='external'>jalist</a>, based on the Wordpress theme, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "تم إلغاء التعليقات");
define("LAN_THEME_3", "التعليقات:");
define("LAN_THEME_4", "إقرأ المزيد...");
define("LAN_THEME_5", "المتابعات:");
define("LAN_THEME_6", "تعليق من طرف");


?>