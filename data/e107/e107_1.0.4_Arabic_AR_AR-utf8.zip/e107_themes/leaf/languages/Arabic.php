<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/leaf/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:36:33 $
|        $Author: Naja7host.com $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "التعليقات");
define("LAN_THEME_2", "تم إلغاء التعليقات لهذا الخبر");
define("LAN_THEME_3", "التعليقات");
define("LAN_THEME_4", "المزيد...");
define("LAN_THEME_5", "المتابعات:");
define("LAN_THEME_6", "تعليق من طرف");
define("LAN_THEME_7", "الأخبار");


?>