<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/vekna_blue/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:25:34 $
|        $Author: الادارة $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'vekna blue' by <a href='http://e107.org' rel='external'>jalist</a>, based on, and with permission from Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "اقرأ / أضف تعليق : ");
define("LAN_THEME_3", "تم إلغاء التعليقات لهذا الخبر");
define("LAN_THEME_4", "التفاصيل...");
define("LAN_THEME_5", "المتابعات:");


?>