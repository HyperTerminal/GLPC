<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/khatru/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:34:24 $
|        $Author: Naja7host.com $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'khatru' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "تم إلغاء التعليقات لهذا الخبر");
define("LAN_THEME_3", "التعليق");
define("LAN_THEME_4", "التفاصيل...");
define("LAN_THEME_5", "المتابعات:");


?>