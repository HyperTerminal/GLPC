<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Arabic Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../themes/core/languages/Arabic.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/12 02:31:54 $
|        $Author: Naja7host.com $
+---------------------------------------------------------------+
*/

define('LAN_THEME_1', 'e107 core theme by <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>');
define("LAN_THEME_2", "التعليقات:");
define("LAN_THEME_3", "تم إلغاء التعليقات لهذا الخبر");
define("LAN_THEME_4", "إقرأ المزيد");
define("LAN_THEME_5", "المتابعات: ");
define("LAN_THEME_8", "في");
define("LAN_THEME_9", "بواسطة");
define("LAN_THEME_11", "آخر الأخبار");
define("LAN_THEME_12", "أرسل لصديق");
define("LAN_THEME_13", "توليد ملف PDF");
define("LAN_THEME_14", "طباعة");
define("LAN_THEME_15", "تعديل");
define("LAN_THEME_17", "تسجيل الدخول");
define("LAN_THEME_18", "اسم المستخدم");
define("LAN_THEME_19", "كلمة المرور");
define("LAN_THEME_20", "التسجيل");
define("LAN_THEME_21", "دخول");
define("LAN_THEME_22", "نسيت كلمة المرور ؟");
define("LAN_THEME_23", "مرحبا");
define("LAN_THEME_24", "المدير العام");
define("LAN_THEME_26", "الإعدادات");
define("LAN_THEME_27", "الملف الخاص");
define("LAN_THEME_28", "تسجيل الخروج");
define("LAN_THEME_29", "لائحة المستجدات");
define("LAN_THEME_SING", "دخول");
define("LAN_THEME_REG", "تسجيل");
define("LAN_SEARCH", "بحث");
define("LAN_SEARCH_SUB", "إنطلق");
define("LAN_THEME_SHARE", "نشر في");
define("LAN_THEME_VER", "e107 إصدار.");
define("CM_L13", "بواسطة");


?>