<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.5 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/clock_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/clock_menu/languages/English.php rev. 11678
+-----------------------------------------------------------------------------+
*/

define('CLOCK_MENU_L1', 'Konfiguracja menu Data i czas została zapisana');
define('CLOCK_MENU_L2', 'Nagłówek');
define('CLOCK_MENU_L3', 'Aktualizuj ustawienia');
define('CLOCK_MENU_L4', 'Konfiguracja menu Data i czas');
define('CLOCK_MENU_L5', 'Poniedziałek,');
define('CLOCK_MENU_L6', 'Wtorek,');
define('CLOCK_MENU_L7', 'Środa,');
define('CLOCK_MENU_L8', 'Czwartek,');
define('CLOCK_MENU_L9', 'Piątek,');
define('CLOCK_MENU_L10', 'Sobota,');
define('CLOCK_MENU_L11', 'Niedziela,');
define('CLOCK_MENU_L12', 'Stycznia');
define('CLOCK_MENU_L13', 'Lutego');
define('CLOCK_MENU_L14', 'Marca');
define('CLOCK_MENU_L15', 'Kwietnia');
define('CLOCK_MENU_L16', 'Maja');
define('CLOCK_MENU_L17', 'Czerwca');
define('CLOCK_MENU_L18', 'Lipca');
define('CLOCK_MENU_L19', 'Sierpnia');
define('CLOCK_MENU_L20', 'Września');
define('CLOCK_MENU_L21', 'Października');
define('CLOCK_MENU_L22', 'Listopada');
define('CLOCK_MENU_L23', 'Grudnia');
define('CLOCK_MENU_L24', '');

?>