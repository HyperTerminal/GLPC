<?php

/*
  +-----------------------------------------------------------------------------+
  |     e107 website system - Language File
  +-----------------------------------------------------------------------------+
  |     Spolszczenie systemu e107
  |     e107 Polish Team
  |     Polskie wsparcie: http://e107pl.org
  |
  |     $Revision: 1.4 $
  |     $Date: 2012/05/19 12:54:29 $
  |     $Author: marcelis_pl $
  |     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/alt_auth/languages/Polish/lan_otherdb_auth.php,v $
  +-----------------------------------------------------------------------------+
  |     Zgodne z: /e107_plugins/alt_auth/languages/English/lan_otherdb_auth.php rev. 12527
  +-----------------------------------------------------------------------------+
 */

define('OTHERDB_LAN_1', 'Typ bazy danych:');
define('OTHERDB_LAN_2', 'Serwer:');
define('OTHERDB_LAN_3', 'Użytkownik:');
define('OTHERDB_LAN_4', 'Hasło:');
define('OTHERDB_LAN_5', 'Baza danych');
define('OTHERDB_LAN_6', 'Tabela');
define('OTHERDB_LAN_7', 'Pole użytkownika:');
define('OTHERDB_LAN_8', 'Pole hasła:');
define('OTHERDB_LAN_9', 'Rodzaj hasła:');
define('OTHERDB_LAN_10', 'Konfiguracja otherdb auth');
define('OTHERDB_LAN_11', '** Te pola nie są wymagane jeśli używasz bazy danych e107');