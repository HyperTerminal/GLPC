<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.8 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/comment_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/comment_menu/languages/English.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("CM_L1", "Nie ma jeszcze żadnych komentarzy.");
define("CM_L2", "");
define("CM_L3", "Nagłówek");
define("CM_L4", "Ilość wyświetlanych komentarzy?");
define("CM_L5", "Ilość wyświetlanych znaków?");
define("CM_L6", "Przyrostek dla zbyt długich komentarzy?");
define("CM_L7", "Pokazywać oryginalny nagłówek wiadomości w menu?");
define("CM_L8", "Konfiguracja menu Ostatnie komentarze");
define("CM_L9", "Aktualizuj ustawienia");
define("CM_L10", "Konfiguracja została zapisana");
define("CM_L11", "dnia");
define("CM_L12", "Odp:");
define("CM_L13", "Autor:");

?>