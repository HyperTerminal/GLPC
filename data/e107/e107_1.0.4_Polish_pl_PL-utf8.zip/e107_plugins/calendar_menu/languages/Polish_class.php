<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/usersettings.php $
 * $Id: usersettings.php 11645 2010-08-01 12:57:11Z e107coders $
 */

/**
 *	e107 Event calendar plugin
 *
 *	Language file - anything called up in ecal_class.php and similar
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: English_class.php 11315 2010-02-10 18:18:01Z secretr $;
 */

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'brak');
define('EC_LAN_RECUR_01', 'raz w roku');
define('EC_LAN_RECUR_02', 'dwa razy w roku');
define('EC_LAN_RECUR_03', 'kwartalnie');
define('EC_LAN_RECUR_04', 'miesięcznie');
define('EC_LAN_RECUR_05', 'cztery raz w tygodniu');
define('EC_LAN_RECUR_06', 'dwutygodniowo');
define('EC_LAN_RECUR_07', 'tygodniowo');
define('EC_LAN_RECUR_08', 'dziennie');
define('EC_LAN_RECUR_100', 'Niedziele w miesiącu');
define('EC_LAN_RECUR_101', 'Poniedziałki w miesiącu');
define('EC_LAN_RECUR_102', 'Wtorki w miesiącu');
define('EC_LAN_RECUR_103', 'Środy w miesiącu');
define('EC_LAN_RECUR_104', 'Czwartki w miesiącu');
define('EC_LAN_RECUR_105', 'Piątki w miesiącu');
define('EC_LAN_RECUR_106', 'Soboty w miesiącu');

define('EC_LAN_RECUR_1100', 'Pierwszy');
define('EC_LAN_RECUR_1200', 'Drugi');
define('EC_LAN_RECUR_1300', 'Trzeci');
define('EC_LAN_RECUR_1400', 'Czwarty');


// Notify
define("NT_LAN_EC_1", "Wydarzenie - Kalendarz Wydarzeń");
define("NT_LAN_EC_2", "Wydarzenie zaktualizowane");
define("NT_LAN_EC_3", "Zaktualizowane przez");
define("NT_LAN_EC_4", "Adres IP");
define("NT_LAN_EC_5", "Wiadomość");
define("NT_LAN_EC_6", "Kalendarz wydarzeń - Wydarzenie dodane");
define("NT_LAN_EC_7", "Nowe wydarzenie dodane");
define("NT_LAN_EC_8", "Kalendarz Wydarzeń - Wydarzenie zmodyfikowane");


// Log messages
define('EC_ADM_01', 'Kalendarz wydarzeń - dodaj wydarzenie');
define('EC_ADM_02', 'Kalendarz wydarzeń - edytuj wydarzenie');
define('EC_ADM_03', 'Kalendarz wydarzeń - usuń wydarzenie');
define('EC_ADM_04', 'Kalendarz wydarzeń - Usuwanie grupowe');
define('EC_ADM_05', 'Kalendarz wydarzeń - Dodawanie grupowe');
define('EC_ADM_06', 'Kalendarz wydarzeń - Zmiany opcji głównych');
define('EC_ADM_07', 'Kalendarz wydarzeń - Zmiany opcji FE');
define('EC_ADM_08', 'Kalendarz wydarzeń - Dodana kategoria');
define('EC_ADM_09', 'Kalendarz wydarzeń - Edytowana kategoria');
define('EC_ADM_10', 'Kalendarz wydarzeń - Usunięta kategoria');
define('EC_ADM_11', 'Kalendarz wydarzeń - Usunięte stare wydarzenia');


?>