<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.6 $
|     $Date: 2011/11/20 10:03:47 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/online_extended_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/online_extended_menu/languages/English.php rev. 11678
+-----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Gości: ");
define("ONLINE_EL2", "Użytkowników: ");
define("ONLINE_EL3", "Na tej stronie: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Użytkowników");
define("ONLINE_EL6", "Najnowszy");
define("ONLINE_EL7", "przegląda");

define("ONLINE_EL8", "Najwięcej online: ");
define("ONLINE_EL9", "dnia");

define("ONLINE_TRACKING_MESSAGE", "Śledzenie użytkowników online jest obecnie wyłączone. Proszę odblokować [link=".e_ADMIN."users.php?options]tutaj[/link] odpowiednią opcję.[br]");

?>