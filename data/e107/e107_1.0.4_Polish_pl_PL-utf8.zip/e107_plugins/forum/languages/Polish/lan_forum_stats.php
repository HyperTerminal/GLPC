<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_stats.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_newforumposts_menu.php rev rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("e_PAGETITLE", "Statystyki forum");

define("FSLAN_1", "Ogólne");
define("FSLAN_2", "Forum otwarto");
define("FSLAN_3", "Działa od");
define("FSLAN_4", "Wszystkich wypowiedzi");
define("FSLAN_5", "Tematów na forum");
define("FSLAN_6", "Postów na forum");
define("FSLAN_7", "Wyświetleń tematów");
define("FSLAN_8", "Rozmiar bazy danych (tylko tabela forum)");
define("FSLAN_9", "Średnia rozmiar wiersza w tabeli forum");
define("FSLAN_10", "Lista Top : Najbardziej aktywne tematy");
define("FSLAN_11", "Pozycja");
define("FSLAN_12", "Temat");
define("FSLAN_13", "Posty");
define("FSLAN_14", "Autor");
define("FSLAN_15", "Data");
define("FSLAN_16", "Lista Top : Najchętniej czytane tematy");
define("FSLAN_17", "Odsłon");
define("FSLAN_18", "Lista Top : Najbardziej aktywni użytkownicy");
define("FSLAN_19", "Imię");
define("FSLAN_20", "Posty");
define("FSLAN_21", "Lista Top : Najwięcej założyli tematów");
define("FSLAN_22", "Lista Top : Najwięcej zamieścili odpowiedzi");
define("FSLAN_23", "Statystyki forum");
define("FSLAN_24", "Średnia ilość postów na dzień");

?>