<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/forum/languages/Polish/lan_forum_uploads.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/forum/languages/English/lan_forum_uploads.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Forum - dział plików");

define('FRMUP_1', 'Załadowane pliki na forum');
define('FRMUP_2', 'Plik został usunięty');
define('FRMUP_3', 'Błąd: Nie można usunąć pliku');
define('FRMUP_4', 'Usuwanie pliku');
define('FRMUP_5', 'Nazwa pliku');
define('FRMUP_6', 'Rezultat');
define('FRMUP_7', 'Znaleziono w temacie');
define('FRMUP_8', 'NIE ZNALEZIONO');
define('FRMUP_9', 'Nie znaleziono załadowanych plików');
define('FRMUP_10', 'Usuń');
	
?>