<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/chatbox_menu/languages/Polish/lan_chatbox_search.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/chatbox_menu/languages/English/lan_chatbox_search.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("CB_SCH_LAN_1", "Czat");

?>