<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.9 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/counter_menu/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/counter_menu/languages/English.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("COUNTER_L1", "Wizyty administratorów nie są zliczane.<br />");
define("COUNTER_L2", "Dzisiejsze odwiedziny tej strony...");
define("COUNTER_L3", "ogółem");
define("COUNTER_L4", "Dotychczasowe odwiedziny tej strony...");
define("COUNTER_L5", "unikalnych");
define("COUNTER_L6", "Wszystkich odwiedzin serwisu...");
define("COUNTER_L7", "Licznik");
define("COUNTER_L8", "Wiadomość administracyjna: <b>Rejestracja statystyk jest wyłączona.</b><br />Aby ją aktywować, zainstaluj plugin <i>Statystyki</i> używając <a href='".e_ADMIN."plugin.php'>menedżera pluginów</a>, a następnie aktywuj odpowiednią opcję na stronie <a href='".e_PLUGIN."log/admin_config.php'>ustawień plugina</a>.");

?>