<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_plugins/content/languages/Polish/lan_content_frontpage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_plugins/content/languages/English/lan_content_frontpage.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("CONT_FP_1", "Kategoria publikacji");
define("CONT_FP_2", "Strona główna");

?>