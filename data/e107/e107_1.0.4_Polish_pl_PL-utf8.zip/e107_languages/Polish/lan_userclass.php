<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.5 $
|     $Date: 2012/08/18 10:52:01 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_userclass.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_userclass.php rev. 12892
+-----------------------------------------------------------------------------+
*/
 
define("UC_LAN_0", "Wszyscy (publiczne)");
define("UC_LAN_1", "Goście");
define("UC_LAN_2", "Nikt (nieaktywne)");
define("UC_LAN_3", "Zarejestrowani");
define("UC_LAN_4", "Tylko do odczytu");
define("UC_LAN_5", "Administratorzy");
define("UC_LAN_6", "Główni administratorzy");

define('UC_LAN_9','Nowi użytkownicy');
define('UC_LAN_10', 'Roboty wyszukiwarek');

?>