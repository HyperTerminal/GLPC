<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_mail_handler.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_mail_handler.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("LANMAILH_1", "Stworzony przez e107 website system");
define("LANMAILH_2", "To jest wieloczęściowa wiadomość w formacie MIME.");
define("LANMAILH_3", " jest niewłaściwie sformatowana");
define("LANMAILH_4", "Serwer odrzucił adres");
define("LANMAILH_5", "Brak odpowiedzi z serwera");
define("LANMAILH_6", "Nie można odnaleźć serwera poczty.");
define("LANMAILH_7", " wydaje się być prawidłowy.");

?>