<?php

/*
  +-----------------------------------------------------------------------------+
  |     e107 website system - Language File
  +-----------------------------------------------------------------------------+
  |     Spolszczenie systemu e107
  |     e107 Polish Team
  |     Polskie wsparcie: http://e107pl.org
  |
  |     $Revision: 1.12 $
  |     $Date: 2012/05/19 10:51:43 $
  |     $Author: marcelis_pl $
  |     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_language.php,v $
  +-----------------------------------------------------------------------------+
  |     Zgodne z: /e107_languages/English/admin/lan_language.php rev. 12553
  +-----------------------------------------------------------------------------+
 */

define("LANG_LAN_00", "nie może zostać utworzona (już istnieje).");
define("LANG_LAN_01", "została usunięta (jeśli istniała) i ponownie utworzona.");
define("LANG_LAN_02", "nie została usunięta");
define("LANG_LAN_03", "Tabele");

define("LANG_LAN_05", "Nie zainstalowane");
define("LANG_LAN_06", "Utwórz tabele");
define("LANG_LAN_07", "Usunąć istniejące tabele?");
define("LANG_LAN_08", "Zastąpi istniejące tabele (dane zostaną utracone).");
define("LANG_LAN_10", "Potwierdź usunięcie");
define("LANG_LAN_11", "Usuń niesprawdzone tabele znajdujące się powyżej (jeśli takie istnieją).");
define("LANG_LAN_12", "Uaktywnij tryb tabel wielojęzykowych");
define("LANG_LAN_13", "Preferencje języka");
define("LANG_LAN_14", "Domyślny język strony");
define("LANG_LAN_15", "Zaznacz, aby skopiować dane z domyślnego języka (przydatne dla menu nawigacyjnego, kategorii aktualności itp.).");
define("LANG_LAN_16", "Używanie wielojęzycznej bazy danych");
define("LANG_LAN_17", "Domyślny język - nie wymaga dodatkowych tabel.");
define("LANG_LAN_18", "Używaj zaparkowanych poddomen następujących domen, aby ustawić język strony:");
define("LANG_LAN_19", "np. domena fr.mojadomena.com ustawi język francuski.");
define("LANG_LAN_20", "Wprowadzaj po jednej domenie w linii, np. mojadomena.com, lub pozostaw puste w celu dezaktywacji.");

define("LANG_LAN_21", "Pakiety językowe");

define("LANG_LAN_23", "Tworzenie pakietu językowego (zip)");
define("LANG_LAN_24", "Twórz pakiet");

define("LANG_LAN_AGR", "Uwaga: Poprzez użycie tego narzędzia zgadzasz się na udostępnienie pakietu językowego społeczności e107.");
define("LANG_LAN_EML", "Proszę wysłać pakiet językowy na adres:");

define("LANG_LAN_25", "Sprawdź, czy CORE_LC oraz CORE_LC2 mają przypisane wartości w pliku [lcpath] i spróbuj ponownie.");
define("LANG_LAN_26", "Upewnij się, że korzystasz z domyślnych nazw katalogów w pliku e107_config.php (np. 'e107_languages/', 'e107_plugins/' etc.) i spróbuj ponownie.");
define("LANG_LAN_27", "Sprawdź poprawność plików językowych ('Weryfikuj') i spróbuj ponownie.");
define("LANG_LAN_28", "Zaznacz to pole, jeśli jeteś [certyfikowanym tłumaczem e107].");

define("LANG_LAN_29", "Należy poprawić błędy przed opublikowaniem swojego pakietu językowego.");
define("LANG_LAN_30", "Data wydania");
define("LANG_LAN_31", "Zgodność");
define("LANG_LAN_32", "Zainstalowane języki");
define("LANG_LAN_33", "Wyświetlaj tylko błędy podczas weryfikacji");
define("LANG_LAN_34", "Przed przystąpieniem do tworzenia paczki językowej, proszę zweryfikować i poprawić pozostałe błędy: [x].");
?>