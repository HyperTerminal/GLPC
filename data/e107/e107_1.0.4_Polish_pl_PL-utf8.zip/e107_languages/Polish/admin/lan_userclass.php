<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_userclass.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_userclass.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("UCSLAN_1", "Wysyłanie powiadomienia e-mail do");
define("UCSLAN_2", "Zaktualizowano uprawnienia");
define("UCSLAN_3", "Witaj");
define("UCSLAN_4", "Zaktualizowano Twoje uprawnienia w serwisie");
define("UCSLAN_5", "Masz teraz dostęp do następujących stref");
define("UCSLAN_6", "Ustaw klasę dla użytkownika");
define("UCSLAN_7", "Ustaw klasę");
define("UCSLAN_8", "Powiadom użytkownika");
define("UCSLAN_9", "Klasy użytkowników zaktualizowano.");
define("UCSLAN_10", "Pozdrawiam,");
define('UCSLAN_12', 'Tylko uprzywilejowani użytkownicy');

?>