<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_updateadmin.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_updateadmin.php rev. 11678
+-----------------------------------------------------------------------------+
*/

define("UDALAN_1", "Błąd - wyślij ponownie");
define("UDALAN_2", "Ustawienia zaktualizowano");
define("UDALAN_3", "Ustawienia zaktualizowano dla");
define("UDALAN_4", "Login");
define("UDALAN_5", "Hasło");
define("UDALAN_6", "Powtórz hasło");
define("UDALAN_7", "Zmień hasło");
define("UDALAN_8", "Zaktualizowano hasło dla");

?>