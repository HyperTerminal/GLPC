<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.2 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/prefs.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/prefs.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Dział preferencji pozwoli Ci na sprecyzowanie wszystkich najważniejszych ustawień dotyczących Twojej strony internetowej, począwszy od nazwy strony oraz jej opisu do zabezpieczeń przeciwko atakom typu flood i filtrowaniu wulgaryzmów.";
$ns -> tablerender("Preferencje", $text);

?>
