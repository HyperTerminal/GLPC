<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.4 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/filemanager.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/filemanager.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Z poziomu tej strony możesz zarządzać plikami w swoich katalogach plików. Jeśli otrzymasz komunikat błędu o uprawnieniach podczas usiłowania przesyłania plików do określonego katalogu, ustaw CHMOD wskazanego folderu na wartość 777.";
$ns -> tablerender("Menedżer plików", $text);

?>
