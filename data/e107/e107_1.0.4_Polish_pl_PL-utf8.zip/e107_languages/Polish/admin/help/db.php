<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.5 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/db.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/db.php rev. 11678
+-----------------------------------------------------------------------------+
*/
if (!defined('e107_INIT')) { exit; }

$text = "Ten zestaw narzędzi pozwala na zarządzanie bazą danych.";
$ns -> tablerender("Narzędzia bazy danych", $text);
?>
