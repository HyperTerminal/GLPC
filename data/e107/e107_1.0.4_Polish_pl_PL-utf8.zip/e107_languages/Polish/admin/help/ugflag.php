<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File.
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107 v0.7
|     Polskie wsparcie: http://e107.org.pl - http://e107poland.org
|
|     $Revision: 1.3 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/ugflag.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/ugflag.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Jeśli aktualizujesz e107 do nowszej wersji lub po prostu potrzebujesz przełączyć swoją stronę na chwilę w tryb offline zaznacz pole <i>Aktywuj tryb konserwacji</i>. Od tej chwili odwiedzający Twoja stronę będą przekierowani do strony wyjaśniającej przyczyny przerwy technicznej. Gdy zakończysz odznacz pole, aby przywrócić normalne funkcjonowanie serwisu.";

$ns -> tablerender("Konserwacja", $text);

?>
