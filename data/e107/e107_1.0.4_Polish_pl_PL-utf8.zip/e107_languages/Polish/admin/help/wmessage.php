<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.3 $
|     $Date: 2011/11/20 10:03:46 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/help/wmessage.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/help/wmessage.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
if (!defined('e107_INIT')) { exit; }

$text = "Na tej stronie możesz ustawić wiadomość, która będzie wyświetlana w górnej części Twojej strony głównej przez cały czas jej aktywacji. Możesz ustawić różne wiadomości dla gości, zalogowanych użytkowników oraz administratorów.";
$ns -> tablerender("Wiadomość powitalna", $text);

?>
