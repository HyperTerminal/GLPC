<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.3 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_meta.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_meta.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("METLAN_1", "Znaczniki meta zaktualizowano w bazie danych");
define("METLAN_2", "Dodatkowe znaczniki meta");
define("METLAN_3", "Dodaj znaczniki meta");
define("METLAN_4", "Zaktualizowano znaczniki");
define("METLAN_5", "tutaj zamieść opis strony");
define("METLAN_6", "tutaj możesz wpisać słowa kluczowe, oddziel je przecinkami");
define("METLAN_7", "tutaj możesz wpisać informacje o prawach autorskich");
define("METLAN_8", "Znaczniki meta");

define("METLAN_9", "Opis");
define("METLAN_10", "Słowa kluczowe");
define("METLAN_11", "Prawa autorskie");
define("METLAN_12", "Używaj tytułu oraz streszczenia aktualności jako znacznika 'Opis' na stronie aktualności.");
define("METLAN_13", "Autor");

?>