<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_e107_update.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_e107_update.ph rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("LAN_UPDATE_2", "Działanie");
define("LAN_UPDATE_3", "Nie wymagane");

define("LAN_UPDATE_5", "Aktualizuj dostępne");
define("LAN_UPDATE_7", "Wykonano");
define("LAN_UPDATE_8", "Aktualizuj z wersji");
define("LAN_UPDATE_9", "do");
define("LAN_UPDATE_10", "Dostępne aktualizacje");
define("LAN_UPDATE_11", "Pozostałe aktualizacje z wersji .617 do .7");
define("LAN_UPDATE_12", "Jedna z tabel zawiera zduplikowane wpisy.");

?>