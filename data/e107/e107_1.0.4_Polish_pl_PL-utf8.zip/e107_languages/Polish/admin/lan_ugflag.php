<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.5 $
|     $Date: 2011/04/10 14:48:31 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/admin/lan_ugflag.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/admin/lan_ugflag.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("UGFLAN_1", "Ustawienia konserwacji zaktualizowano");
define("UGFLAN_2", "Aktywuj tryb konserwacji");
define("UGFLAN_3", "Aktualizuj ustawienia konserwacji");
define("UGFLAN_4", "Ustawienia konserwacji");

define("UGFLAN_5", "Tekst do wyświetlenia podczas zamknięcia strony");
define("UGFLAN_6", "Pozostaw puste, aby wyświetlić domyślny komunikat");

define('UGFLAN_8', 'Ograniczenie dostępu pomijane dla administratorów');
define('UGFLAN_9', 'Ograniczenie dostępu pomijane dla głównych administratorów');

?>