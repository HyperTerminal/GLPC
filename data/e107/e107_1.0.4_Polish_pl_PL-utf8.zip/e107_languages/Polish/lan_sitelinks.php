<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.3 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_sitelinks.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_sitelinks.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("LAN_SITELINKS_183", "Menu główne");
define("LAN_SITELINKS_502", "Panel administracyjny");

?>