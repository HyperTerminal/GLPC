<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.3 $
|     $Date: 2010/09/23 20:23:07 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_languages/Polish/lan_userposts.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_languages/English/lan_userposts.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("PAGE_NAME", "Posty użytkownika");

define("UP_LAN_0", "Wszystkie posty na forum dla ");
define("UP_LAN_1", "Wszystkie komentarze dla ");
define("UP_LAN_2", "Wątek");
define("UP_LAN_3", "Wyświetleń");
define("UP_LAN_4", "Posty");
define("UP_LAN_5", "Ostatni post");
define("UP_LAN_6", "Wątki");
define("UP_LAN_7", "Brak komentarzy");
define("UP_LAN_8", "Brak postów");
define("UP_LAN_9", " dnia ");
define("UP_LAN_10", "Odp");
define("UP_LAN_11", "Dodane dnia");
define("UP_LAN_12", "Szukaj");
define("UP_LAN_13", "Komentarze");
define("UP_LAN_14", "Posty na forum");
define("UP_LAN_15", "Odp");
define("UP_LAN_16", "Adres IP");

?>