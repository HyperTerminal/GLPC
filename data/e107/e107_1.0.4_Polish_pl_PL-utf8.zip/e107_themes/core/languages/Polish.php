<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.2 $
|     $Date: 2012/01/04 18:07:51 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_themes/core/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_themes/core/languages/English.php rev. 12477
+-----------------------------------------------------------------------------+
*/


define('LAN_THEME_1', 'Główny motyw e107 - <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>');
define('LAN_THEME_2', 'Komentarze: ');
define('LAN_THEME_3', 'Komentarze zablokowane');
define('LAN_THEME_4', 'Czytaj więcej...');
define('LAN_THEME_5', 'Trackback: '); 
define('LAN_THEME_8', 'w dniu');
define('LAN_THEME_9', '-');
define("LAN_THEME_11", "Ostatnie nowości");
define("LAN_THEME_12", "Powiadom znajomego poprzez e-mail");
define("LAN_THEME_13", "Pobierz w pliku PDF");
define("LAN_THEME_14", "Drukuj");
define("LAN_THEME_15", "Edytuj");
define('LAN_THEME_17', 'Login');
define('LAN_THEME_18', 'Login');
define('LAN_THEME_19', 'Hasło');
define('LAN_THEME_20', 'Rejestracja');
define('LAN_THEME_21', 'Login');
define('LAN_THEME_22', 'Nie pamiętasz hasła?');
define('LAN_THEME_23', 'Witaj');
define('LAN_THEME_24', 'Panel admina');
define('LAN_THEME_26', 'Ustawienia');
define('LAN_THEME_27', 'Profil');
define('LAN_THEME_28', 'Wyloguj');
define('LAN_THEME_29', 'Lista nowości');
define('LAN_THEME_SING', 'Logowanie');
define('LAN_THEME_REG', 'Rejestracja');
define("LAN_SEARCH", "Szukaj");
define("LAN_SEARCH_SUB", "Idź");
define('LAN_THEME_SHARE', 'Podziel się');
define('LAN_THEME_VER', 'e107 v.');
define("CM_L13", " - ");
?>