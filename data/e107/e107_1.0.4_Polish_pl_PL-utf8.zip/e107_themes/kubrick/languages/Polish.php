<?php
/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2010/09/23 20:23:25 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_themes/kubrick/languages/Polish.php,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_themes/kubrick/languages/English.php rev. 11678
+-----------------------------------------------------------------------------+
*/
 
define("LAN_THEME_1", "Motyw 'kubrick' został wykonany przez <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> &amp; <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Bazuje na oryginalnym motywie wykonanym przez Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Komentarze zablokowane");
define("LAN_THEME_3", "Komentarze: ");
define("LAN_THEME_4", "Czytaj resztę...");
define("LAN_THEME_5", "Powiązania: ");
define('LAN_THEME_6', 'dnia');
define('LAN_THEME_7', 'przez');

?>