/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.7 $
|     $Date: 2012/05/19 10:51:42 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/ibrowser/langs/pl.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/ibrowser/langs/en.php rev. 11346
+-----------------------------------------------------------------------------+
*/
tinyMCE.addI18n('pl.ibrowser',{
    desc : 'Przeglądarka grafiki'
});