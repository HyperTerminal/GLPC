/*
+-----------------------------------------------------------------------------+
|     e107 website system - Language File
+-----------------------------------------------------------------------------+
|     Spolszczenie systemu e107
|     e107 Polish Team
|     Polskie wsparcie: http://e107pl.org
|
|     $Revision: 1.4 $
|     $Date: 2012/05/19 10:51:43 $
|     $Author: marcelis_pl $
|     $Source: /cvsroot/e107pl/e107_main/0.7_PL_strict_utf8/e107_handlers/tiny_mce/plugins/table/langs/pl_dlg.js,v $
+-----------------------------------------------------------------------------+
|     Zgodne z: /e107_handlers/tiny_mce/plugins/table/langs/en_dlg.js rev. 12535
|     Tlumaczenie TinyMCE Community z dnia: 2012-05-19
+-----------------------------------------------------------------------------+
*/

tinyMCE.addI18n('pl.table_dlg',{
    "rules_border":"granica",
    "rules_box":"ramka",
    "rules_vsides":"vsides",
    "rules_rhs":"rhs",
    "rules_lhs":"lhs",
    "rules_hsides":"hsides",
    "rules_below":"pod",
    "rules_above":"nad",
    "rules_void":"void",
    rules:"Prowadnice",
    "frame_all":"wszystkie",
    "frame_cols":"kolumny",
    "frame_rows":"wiersze",
    "frame_groups":"grupy",
    "frame_none":"brak",
    frame:"Ramka",
    caption:"Nag\u0142\u00f3wek tabeli",
    "missing_scope":"Jeste\u015b pewny \u017ce chcesz kontynuowa\u0107 bez definiowania zasi\u0119gu dla kom\u00f3rki tabeli. Bez niej, mo\u017ce by\u0107 trudne dla niekt\u00f3rych u\u017cytkownik\u00f3w zrozuminie zawarto\u015bci albo danych wy\u015bwietlanych poza tabel\u0105.",
    "cell_limit":"Przekroczy\u0142e\u015b maksymaln\u0105 liczb\u0119 kom\u00f3rek kt\u00f3ra wynosi {$cells}.",
    "row_limit":"Przekroczy\u0142e\u015b maksymaln\u0105 liczb\u0119 wierszy kt\u00f3ra wynosi {$rows}.",
    "col_limit":"Przekroczy\u0142e\u015b maksymaln\u0105 liczb\u0119 kolumn kt\u00f3ra wynosi {$cols}.",
    colgroup:"Grupa kolumn",
    rowgroup:"Grupa wierszy",
    scope:"Zakres",
    tfoot:"Stopka tabeli",
    tbody:"Cia\u0142o tabeli",
    thead:"Nag\u0142\u00f3wek tabeli",
    "row_all":"Zmie\u0144 wszystkie wiersze",
    "row_even":"Zmie\u0144 parzyste wiersze",
    "row_odd":"Zmie\u0144 nieparzyste wiersze",
    "row_row":"Zmie\u0144 aktualny wiersz",
    "cell_all":"Zmie\u0144 wszytkie kom\u00f3rki w tabeli",
    "cell_row":"Zmie\u0144 wszytkie kom\u00f3rki w wierszu",
    "cell_cell":"Zmie\u0144 aktualn\u0105 kom\u00f3rk\u0119",
    th:"Nag\u0142owek",
    td:"Dane",
    summary:"Podsumowanie",
    bgimage:"Obrazek t\u0142a",
    rtl:"Kierunek z prawej do lewej",
    ltr:"Kierunek z lewej do prawej",
    mime:"Docelowy typ MIME",
    langcode:"Kod j\u0119zyka",
    langdir:"Kierunek czytania tekstu",
    style:"Styl",
    id:"Id",
    "merge_cells_title":"Po\u0142\u0105cz kom\u00f3rki",
    bgcolor:"Kolor t\u0142a",
    bordercolor:"Kolor ramki",
    "align_bottom":"D\u00f3\u0142",
    "align_top":"G\u00f3ra",
    valign:"Pionowe wyr\u00f3wnanie",
    "cell_type":"Typ kom\u00f3rki",
    "cell_title":"W\u0142a\u015bciwo\u015bci kom\u00f3rki",
    "row_title":"W\u0142a\u015bciwo\u015bci wiersza",
    "align_middle":"\u015arodek",
    "align_right":"Prawy",
    "align_left":"Lewy",
    "align_default":"Domy\u015blnie",
    align:"Wyr\u00f3wnanie",
    border:"Ramka",
    cellpadding:"Margines wewn\u0105trz kom\u00F3rek",
    cellspacing:"Odst\u0119py mi\u0119dzy kom\u00F3rkami",
    rows:"Wiersze",
    cols:"Kolumny",
    height:"Wysoko\u015b\u0107",
    width:"Szeroko\u015b\u0107",
    title:"Wklej/Zmie\u0144 tabel\u0119",
    rowtype:"Wiersz w cz\u0119\u015bci tabeli",
    "advanced_props":"Zaawansowane w\u0142a\u015bciwo\u015bci",
    "general_props":"G\u0142\u00f3wne w\u0142a\u015bciwo\u015bci",
    "advanced_tab":"Zaawansowane",
    "general_tab":"G\u0142\u00f3wne",
    "cell_col":"Zaktualizuj wszystkie kom\u00f3rki w kolumnie"
});
