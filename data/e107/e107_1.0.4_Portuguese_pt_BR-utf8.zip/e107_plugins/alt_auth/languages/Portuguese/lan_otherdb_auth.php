<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/alt_auth/languages/Portuguese_Brazilian/lan_otherdb_auth.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("OTHERDB_LAN_1", "Tipo de banco de dados:");
define("OTHERDB_LAN_2", "Servidor:");
define("OTHERDB_LAN_3", "Usuário:");
define("OTHERDB_LAN_4", "Senha:");
define("OTHERDB_LAN_5", "Banco de dados");
define("OTHERDB_LAN_6", "Tabela");
define("OTHERDB_LAN_7", "Campo de Usuário:");
define("OTHERDB_LAN_8", "Campo da senha:");
define("OTHERDB_LAN_9", "Método da senha:");
define("OTHERDB_LAN_10", "Configurar plugin 'otherdb auth' (outro tipo de autenticação ao banco de dados)");
define("OTHERDB_LAN_11", "** Os seguintes campos não são requeridos se você estiver usando um banco de dados do e107");


?>