<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/content/languages/Portuguese_Brazilian/lan_content.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CONTENT_EMAILPRINT_LAN_1", "este conteúdo é de");
define("POPUP_LAN_1", "clique para ver imagem ampliada");
define("CONTENT_NOTIFY_LAN_1", "Eventos de Conteúdo");
define("CONTENT_NOTIFY_LAN_2", "Item de conteúdo submetido pelo usuário");
define("CONTENT_NOTIFY_LAN_3", "Conteúdo Enviado");
define("CONTENT_TYPE_LAN_0", "categorias");
define("CONTENT_TYPE_LAN_1", "autores");
define("CONTENT_TYPE_LAN_2", "arquivo");
define("CONTENT_TYPE_LAN_3", "mais votado");
define("CONTENT_TYPE_LAN_4", "mais avaliado");
define("CONTENT_TYPE_LAN_5", "recente");
define("CONTENT_ICON_LAN_0", "editar");
define("CONTENT_ICON_LAN_1", "apagar");
define("CONTENT_ICON_LAN_2", "opções");
define("CONTENT_ICON_LAN_3", "detalhes do usuário");
define("CONTENT_ICON_LAN_4", "arquivo anexado");
define("CONTENT_ICON_LAN_5", "novo");
define("CONTENT_ICON_LAN_6", "enviar conteúdo");
define("CONTENT_ICON_LAN_7", "lista de autores");
define("CONTENT_ICON_LAN_8", "perigo");
define("CONTENT_ICON_LAN_9", "ok");
define("CONTENT_ICON_LAN_10", "erro");
define("CONTENT_ICON_LAN_11", "ordenar os itens na categoria");
define("CONTENT_ICON_LAN_12", "ordenar os itens na página principal/pai");
define("CONTENT_ICON_LAN_13", "administração personalizada");
define("CONTENT_ICON_LAN_14", "gerenciador de conteúdo personalizado");
define("CONTENT_ICON_LAN_15", "visualizar");
define("CONTENT_ADMIN_DATE_LAN_0", "Janeiro");
define("CONTENT_ADMIN_DATE_LAN_1", "Fevereiro");
define("CONTENT_ADMIN_DATE_LAN_2", "Março");
define("CONTENT_ADMIN_DATE_LAN_3", "Abril");
define("CONTENT_ADMIN_DATE_LAN_4", "Maio");
define("CONTENT_ADMIN_DATE_LAN_5", "Junho");
define("CONTENT_ADMIN_DATE_LAN_6", "Julho");
define("CONTENT_ADMIN_DATE_LAN_7", "Agosto");
define("CONTENT_ADMIN_DATE_LAN_8", "Setembro");
define("CONTENT_ADMIN_DATE_LAN_9", "Outubro");
define("CONTENT_ADMIN_DATE_LAN_10", "Novembro");
define("CONTENT_ADMIN_DATE_LAN_11", "Dezembro");
define("CONTENT_ADMIN_DATE_LAN_12", "dia");
define("CONTENT_ADMIN_DATE_LAN_13", "mês");
define("CONTENT_ADMIN_DATE_LAN_14", "ano");
define("CONTENT_ADMIN_DATE_LAN_15", "data inicial");
define("CONTENT_ADMIN_DATE_LAN_16", "data final");
define("CONTENT_ADMIN_DATE_LAN_17", "Você pode especificar uma data inicial para este conteúdo. Se você usar uma data no futuro, o conteúdo será visível desta data em diante. Se você não precisa especificar uma data de início, pode deixar estes campos como estão.");
define("CONTENT_ADMIN_DATE_LAN_18", "Você pode especificar uma data final para este conteúdo. Com uma data final, você pode especificar até quando o item será visível. Se você não precisa de uma data final, deixe esses campos como estão.");
define("CONTENT_PAGETITLE_LAN_0", "Conteúdo");
define("CONTENT_PAGETITLE_LAN_1", "Principal");
define("CONTENT_PAGETITLE_LAN_2", "Recentes");
define("CONTENT_PAGETITLE_LAN_3", "Categoria");
define("CONTENT_PAGETITLE_LAN_4", "Mais Votados");
define("CONTENT_PAGETITLE_LAN_5", "Autor");
define("CONTENT_PAGETITLE_LAN_6", "Arquivo");
define("CONTENT_PAGETITLE_LAN_7", "Enviar");
define("CONTENT_PAGETITLE_LAN_8", "Enviar Item de Conteúdo");
define("CONTENT_PAGETITLE_LAN_9", "Gerenciador de Conteúdo Personalizado");
define("CONTENT_PAGETITLE_LAN_10", "Visualizar Itens");
define("CONTENT_PAGETITLE_LAN_11", "Editar Item");
define("CONTENT_PAGETITLE_LAN_12", "Criar Item");
define("CONTENT_PAGETITLE_LAN_13", "Categorias");
define("CONTENT_PAGETITLE_LAN_14", "Lista de Autores");
define("CONTENT_PAGETITLE_LAN_15", "Mais Pontuados");
define("CONTENT_SEARCH_LAN_0", "nenhum conteúdo encontrado com essa palavra-chave.");
define("CONTENT_ORDER_LAN_0", "organizar por...");
define("CONTENT_ORDER_LAN_1", "título (ASC)");
define("CONTENT_ORDER_LAN_2", "título (DESC)");
define("CONTENT_ORDER_LAN_3", "data (ASC)");
define("CONTENT_ORDER_LAN_4", "data (DESC)");
define("CONTENT_ORDER_LAN_5", "referência (ASC)");
define("CONTENT_ORDER_LAN_6", "referência (DESC)");
define("CONTENT_ORDER_LAN_7", "categoria pai/principal (ASC)");
define("CONTENT_ORDER_LAN_8", "categoria pai/principal (DESC)");
define("CONTENT_ORDER_LAN_9", "ordenar (ASC)");
define("CONTENT_ORDER_LAN_10", "ordenar (DESC)");
define("CONTENT_ORDER_LAN_11", "autor (ASC)");
define("CONTENT_ORDER_LAN_12", "autor (DESC)");
define("CONTENT_LAN_0", "Conteúdo");
define("CONTENT_LAN_1", "Lista dos mais Recentes");
define("CONTENT_LAN_2", "Lista de Categorias");
define("CONTENT_LAN_3", "Categoria");
define("CONTENT_LAN_4", "Lista de Autores");
define("CONTENT_LAN_5", "Autor");
define("CONTENT_LAN_6", "todas as categorias");
define("CONTENT_LAN_7", "todos os autores");
define("CONTENT_LAN_8", "itens mais votados");
define("CONTENT_LAN_9", "em");
define("CONTENT_LAN_10", "em");
define("CONTENT_LAN_11", "por");
define("CONTENT_LAN_12", "itens mais pontuados");
define("CONTENT_LAN_13", "lista");
define("CONTENT_LAN_14", "-- categorias --");
define("CONTENT_LAN_15", "não há autores ainda");
define("CONTENT_LAN_16", "[leia mais]");
define("CONTENT_LAN_18", "buscar por palavra-chave");
define("CONTENT_LAN_19", "buscar");
define("CONTENT_LAN_20", "resultados da busca de conteúdos");
define("CONTENT_LAN_21", "nenhum tipo de conteúdo ainda.");
define("CONTENT_LAN_22", "tipos de conteúdo");
define("CONTENT_LAN_23", "Lista de Conteúdos Recentes");
define("CONTENT_LAN_24", "trecho");
define("CONTENT_LAN_25", "Categorias de Conteúdo");
define("CONTENT_LAN_26", "Categoria de Conteúdo");
define("CONTENT_LAN_27", "subcategorias");
define("CONTENT_LAN_28", "subcategorias principais/pai");
define("CONTENT_LAN_29", "desconhecido");
define("CONTENT_LAN_30", "item de conteúdo");
define("CONTENT_LAN_31", "itens de conteúdo");
define("CONTENT_LAN_32", "Lista de Autores de Conteúdo");
define("CONTENT_LAN_33", "Ir para a Página");
define("CONTENT_LAN_34", "conteúdo");
define("CONTENT_LAN_35", "comentários");
define("CONTENT_LAN_36", "moderar comentários");
define("CONTENT_LAN_37", "não há itens de conteúdo votados ainda");
define("CONTENT_LAN_38", "Conteúdos mais votados");
define("CONTENT_LAN_39", "lista de autores");
define("CONTENT_LAN_40", "detalhes do autor");
define("CONTENT_LAN_41", "anexado");
define("CONTENT_LAN_42", "arquivo");
define("CONTENT_LAN_43", "arquivos");
define("CONTENT_LAN_44", "cliques:");
define("CONTENT_LAN_45", "pontuação dada ao autor:");
define("CONTENT_LAN_46", "índice de artigos");
define("CONTENT_LAN_47", "autor");
define("CONTENT_LAN_48", "itens de conteúdo");
define("CONTENT_LAN_49", "último item de conteúdo");
define("CONTENT_LAN_50", "data");
define("CONTENT_LAN_51", "Lista de Tipos");
define("CONTENT_LAN_52", "nenhum autor válido encontrado");
define("CONTENT_LAN_53", "item");
define("CONTENT_LAN_54", "itens");
define("CONTENT_LAN_55", "último item em");
define("CONTENT_LAN_56", "mostrar resumo de");
define("CONTENT_LAN_57", "comentários:");
define("CONTENT_LAN_58", "principal");
define("CONTENT_LAN_59", "conteúdo");
define("CONTENT_LAN_60", "recentes");
define("CONTENT_LAN_61", "visualizar itens recentes");
define("CONTENT_LAN_62", "visualizar todas as categorias");
define("CONTENT_LAN_63", "visualizar todos os autores");
define("CONTENT_LAN_64", "visualizar os itens mais votados");
define("CONTENT_LAN_65", "enviar conteúdo");
define("CONTENT_LAN_66", "clique aqui para enviar o conteúdo, você pode escolher a categoria na página de envio.");
define("CONTENT_LAN_67", "gerenciador de conteúdo personalizado");
define("CONTENT_LAN_68", "clique aqui para gerenciar seu conteúdo pessoal.");
define("CONTENT_LAN_69", "enviar e-mail");
define("CONTENT_LAN_70", "imprimir o");
define("CONTENT_LAN_71", "item de conteúdo");
define("CONTENT_LAN_72", "item de categoria");
define("CONTENT_LAN_73", "não há itens de conteúdo ainda");
define("CONTENT_LAN_75", "enviar item de conteúdo");
define("CONTENT_LAN_76", "criar um arquivo pdf de");
define("CONTENT_LAN_77", "buscar conteúdo");
define("CONTENT_LAN_78", "página sem título");
define("CONTENT_LAN_79", "página");
define("CONTENT_LAN_80", "itens recentes:");
define("CONTENT_LAN_81", "categorias");
define("CONTENT_LAN_82", "não há itens ainda em");
define("CONTENT_LAN_83", "arquivo de item");
define("CONTENT_LAN_84", "Arquivo de Conteúdo");
define("CONTENT_LAN_85", "lista de autores");
define("CONTENT_LAN_86", "ver itens mais votados");
define("CONTENT_LAN_87", "Conteúdos Mais Votados");
define("CONTENT_LAN_88", "não há itens de conteúdo votados ainda");
define("CONTENT_LAN_89", "selecionar página");
define("CONTENT_LAN_90", "página anterior");
define("CONTENT_LAN_91", "próxima página");
define("CONTENT_LAN_92", "- atual -");
define("CONTENT_LAN_ALL", "tudo");
define("CONTENT_MENU_LAN_0", "Menu de conteúdo:");
define("CONTENT_MENU_LAN_1", "não há itens de conteúdo ainda");
define("CONTENT_MENU_LAN_2", "itens recentes");
define("CONTENT_MENU_LAN_3", "categorias");
define("CONTENT_MENU_LAN_4", "links de conteúdo");
define("CONTENT_MENU_LAN_5", "não há itens em");


?>