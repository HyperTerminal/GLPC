<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/content/languages/Portuguese_Brazilian/lan_content_search.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CONT_SCH_LAN_1", "Conteúdo");
define("CONT_SCH_LAN_2", "Todas as Categorias de Conteúdo");
define("CONT_SCH_LAN_3", "Postado em resposta ao item");
define("CONT_SCH_LAN_4", "em");


?>