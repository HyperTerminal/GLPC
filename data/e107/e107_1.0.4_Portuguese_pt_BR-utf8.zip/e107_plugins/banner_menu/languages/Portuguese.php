<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/banner_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "Publicidade");
define("BANNER_MENU_L2", "Configurações do menu banner salvas");
define("BANNER_MENU_L3", "Subtítulo");
define("BANNER_MENU_L4", "Campanha");
define("BANNER_MENU_L5", "Configuração do Menu Banner");
define("BANNER_MENU_L6", "escolha campanhas a mostrar no menu");
define("BANNER_MENU_L7", "campanhas disponíveis");
define("BANNER_MENU_L8", "selecionar campanhas");
define("BANNER_MENU_L9", "remover seleção");
define("BANNER_MENU_L10", "como as campanhas selecionadas devem ser mostradas?");
define("BANNER_MENU_L11", "escolha o tipo...");
define("BANNER_MENU_L12", "uma campanha em um único menu");
define("BANNER_MENU_L13", "todas as campanhas selecionadas em um único menu");
define("BANNER_MENU_L14", "todas as campanhas selecionadas em menus separados");
define("BANNER_MENU_L15", "quantas campanhas devem ser mostradas?");
define("BANNER_MENU_L16", "este ajuste será usado somente com opções 2 e 3.<br />se menos banners estiverem presentes, o máximo disponível será mostrado. ");
define("BANNER_MENU_L17", "ajuste uma quantidade...");
define("BANNER_MENU_L18", "Atualização das Preferências do Menu");


?>