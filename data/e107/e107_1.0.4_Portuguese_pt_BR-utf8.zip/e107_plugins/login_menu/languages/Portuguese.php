<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/login_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LOGIN_MENU_L1", "Usuário:");
define("LOGIN_MENU_L2", "Senha:");
define("LOGIN_MENU_L3", "Registrar");
define("LOGIN_MENU_L4", "Esqueceu a senha?");
define("LOGIN_MENU_L5", "Bem-Vindo");
define("LOGIN_MENU_L6", "Relembrar senha");
define("LOGIN_MENU_L7", "Erro de conexão por identificação de usuário (possível cookie corrompido).<br />Por favor <a href=\"".e_BASE."index.php?logout\">clique aqui</a> para destruí-lo.");
define("LOGIN_MENU_L8", "Desconectar");
define("LOGIN_MENU_L9", "Erro de Login");
define("LOGIN_MENU_L10", "O site está em manutenção - isso significa que os membros do sites serão redirecionados para sitedown.php. Para alterar esse estado, vá em admin/manutenção.");
define("LOGIN_MENU_L11", "Área de Admin");
define("LOGIN_MENU_L12", "Preferências");
define("LOGIN_MENU_L13", "Perfil");
define("LOGIN_MENU_L14", "novo item");
define("LOGIN_MENU_L15", "novos itens");
define("LOGIN_MENU_L16", "postagem no chat");
define("LOGIN_MENU_L17", "postagens no chat");
define("LOGIN_MENU_L18", "comentário");
define("LOGIN_MENU_L19", "comentários");
define("LOGIN_MENU_L20", "postagem no fórum");
define("LOGIN_MENU_L21", "postagens no fórum");
define("LOGIN_MENU_L22", "novo membro do site");
define("LOGIN_MENU_L23", "novos membros do site");
define("LOGIN_MENU_L24", "Clique aqui para ver a lista de novos itens");
define("LOGIN_MENU_L25", "Desde a sua útima visita");
define("LOGIN_MENU_L26", "não");
define("LOGIN_MENU_L27", "e");
define("LOGIN_MENU_L28", "Login");
define("LOGIN_MENU_L29", "novo artigo");
define("LOGIN_MENU_L30", "novos artigos");
define("LOGIN_MENU_L31", "Mostrar novas notícias");
define("LOGIN_MENU_L32", "Mostrar novos artigos");
define("LOGIN_MENU_L33", "Mostrar novas mensagens de chat");
define("LOGIN_MENU_L34", "Mostrar novos comentários");
define("LOGIN_MENU_L35", "Mostrar novas mensagens no fórum");
define("LOGIN_MENU_L36", "Mostrar novos membros cadastrados");
define("LOGIN_MENU_L39", "Sair da Administração");
define("LOGIN_MENU_L40", "Reenviar e-mail de ativação");
define("LOGIN_MENU_L41", "Configurações do Menu de Login");


?>