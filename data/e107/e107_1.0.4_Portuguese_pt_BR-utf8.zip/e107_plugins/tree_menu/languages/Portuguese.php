<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/tree_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("TREE_L1", "Configurar Menu");
define("TREE_L2", "Atualizar Preferências do Menu");
define("TREE_L3", "Configuração do Menu gravada.");
define("TREE_L4", "Sim");
define("TREE_L5", "Não");
define("TREE_L6", "Classe CSS que deseja usar para links padrão");
define("TREE_L7", "Classe CSS que deseja usar para links que foram clicados");
define("TREE_L8", "Classe CSS a usar para links já abertos");
define("TREE_L9", "Usar classe de espaçamento entre links principais");


?>