<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/forum/languages/Portuguese_Brazilian/lan_forum_conf.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_FORUM_INSTALL_01", "Fórum");
define("LAN_FORUM_INSTALL_02", "Este plugin é um sistema completo de Fórum");
define("LAN_FORUM_INSTALL_03", "Configurar Fórum");
define("LAN_FORUM_INSTALL_04", "Seu fórum está instalado agora");
define("LAN_FORUM_INSTALL_05", "Fórum atualizado com sucesso, agora usando a versão: %1$s");
define("LAN_FORUM_INSTALL_06", "[fórum]");
define("LAN_FORUM_INSTALL_07", "[mais...]");
define("FORLAN_5", "Pesquisa apagada.");
define("FORLAN_6", "Tópico apagado");
define("FORLAN_7", "respostas apagadas");
define("FORLAN_8", "Deleção cancelada.");
define("FORLAN_9", "Tópico movido.");
define("FORLAN_10", "Remoção cancelada.");
define("FORLAN_11", "Voltar para os Fóruns");
define("FORLAN_12", "Configuração do Fórum");
define("FORLAN_13", "Tem certeza absoluta que quer apagar esta pesquisa?<br />Uma vez apagada ela <b><u>não poderá</u></b> ser ativada novamente.");
define("FORLAN_14", "Cancelar");
define("FORLAN_15", "Confirmar Apagar Postagem do Fórum");
define("FORLAN_16", "Confirmar Apagar Pesquisa");
define("FORLAN_17", "postado por");
define("FORLAN_18", "Você tem certeza absoluta que quer apagar este fórum?");
define("FORLAN_19", "Tópicos e postagens relacionados?");
define("FORLAN_20", "a pesquisa também será apagada");
define("FORLAN_21", "Também apagar");
define("FORLAN_22", "postagem?<br />Uma vez apagado");
define("FORLAN_23", "não poderá</u></b> ser revisto");
define("FORLAN_24", "Mover tópico para o fórum");
define("FORLAN_25", "Mover Tópico");
define("FORLAN_26", "Apagar resposta");
define("FORLAN_27", "movido");
define("FORLAN_28", "Não é possível renomear o título do tópico");
define("FORLAN_29", "Adicionar");
define("FORLAN_30", "para o título");
define("FORLAN_31", "Renomear para:");
define("FORLAN_32", "Opções de renomear tópicos:");


?>