<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/list_new/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Listar Novos Itens");}
define("LIST_PLUGIN_1", "Listar");
define("LIST_PLUGIN_2", "Este plugin permite ver uma lista de adições recentes em todas as categorias do e107. Poderá ver uma lista com dados desde a sua última visita, ou ver uma lista geral das últimas adições. Também está presente um menu. Todas as seções são configuráveis na área de administração.");
define("LIST_PLUGIN_3", "Configurar Menu Principal");
define("LIST_PLUGIN_4", "O plugin List_new está pronto para ser usado.");
define("LIST_PLUGIN_5", "Novos Itens");
define("LIST_PLUGIN_6", "Este plugin não está instalado.");
define("LIST_ADMIN_1", "recentes");
define("LIST_ADMIN_2", "atualizar preferências");
define("LIST_ADMIN_3", "preferências atualizadas");
define("LIST_ADMIN_4", "seção");
define("LIST_ADMIN_5", "menu");
define("LIST_ADMIN_6", "página");
define("LIST_ADMIN_7", "ativar");
define("LIST_ADMIN_8", "desativar");
define("LIST_ADMIN_9", "abrir");
define("LIST_ADMIN_10", "fechar");
define("LIST_ADMIN_11", "atualizar");
define("LIST_ADMIN_12", "escolha");
define("LIST_ADMIN_13", "Bem Vindo à página a lista ".SITENAME." ! Esta página mostra as seções mais comuns do site, uma lista com as mais recentes adições.");
define("LIST_ADMIN_14", "últimas adições");
define("LIST_ADMIN_15", "inseridas desde a sua última visita");
define("LIST_ADMIN_16", "Bem Vindo à página de ".SITENAME." ! Esta página mostra as seções mais comuns do site, uma lista com as novas adições desde a sua última visita.");
define("LIST_ADMIN_SECT_1", "seções");
define("LIST_ADMIN_SECT_2", "escolha que seção mostrar");
define("LIST_ADMIN_SECT_3", "");
define("LIST_ADMIN_SECT_4", "estilo de visualização");
define("LIST_ADMIN_SECT_5", "escolha quais seções estarão abertas por padrão");
define("LIST_ADMIN_SECT_6", "");
define("LIST_ADMIN_SECT_7", "autor");
define("LIST_ADMIN_SECT_8", "escolha se o autor deve ser mostrado");
define("LIST_ADMIN_SECT_9", "");
define("LIST_ADMIN_SECT_10", "categoria");
define("LIST_ADMIN_SECT_11", "escolha se a categoria deve ser mostrada");
define("LIST_ADMIN_SECT_12", "");
define("LIST_ADMIN_SECT_13", "data");
define("LIST_ADMIN_SECT_14", "escolha se a data deve ser mostrada");
define("LIST_ADMIN_SECT_15", "");
define("LIST_ADMIN_SECT_16", "quantidade de itens");
define("LIST_ADMIN_SECT_17", "escolha quantos itens devem ser mostrados por seção");
define("LIST_ADMIN_SECT_18", "");
define("LIST_ADMIN_SECT_19", "ordenar itens");
define("LIST_ADMIN_SECT_20", "escolha a ordem pela qual as seções devem ser mostradas");
define("LIST_ADMIN_SECT_21", "");
define("LIST_ADMIN_SECT_22", "ícone");
define("LIST_ADMIN_SECT_23", "escolha um ícone para cada seção");
define("LIST_ADMIN_SECT_24", "");
define("LIST_ADMIN_SECT_25", "título");
define("LIST_ADMIN_SECT_26", "defina um título para cada seção");
define("LIST_ADMIN_SECT_27", "");
define("LIST_ADMIN_OPT_1", "geral");
define("LIST_ADMIN_OPT_2", "página recente");
define("LIST_ADMIN_OPT_3", "menu recente");
define("LIST_ADMIN_OPT_4", "nova página");
define("LIST_ADMIN_OPT_5", "novo menu");
define("LIST_ADMIN_OPT_6", "opções");
define("LIST_ADMIN_MENU_2", "ícone : padrão");
define("LIST_ADMIN_MENU_3", "usar marca do theme por padrão se nenhum ícone estiver presente ou se usar ícone estiver desativado");
define("LIST_ADMIN_MENU_4", "");
define("LIST_ADMIN_LAN_2", "título");
define("LIST_ADMIN_LAN_3", "defina um título");
define("LIST_ADMIN_LAN_4", "");
define("LIST_ADMIN_LAN_5", "ícone : usar");
define("LIST_ADMIN_LAN_6", "usar ícone de cada seção");
define("LIST_ADMIN_LAN_7", "");
define("LIST_ADMIN_LAN_8", "caracteres");
define("LIST_ADMIN_LAN_9", "escolha quantos cabeçalhos serão mostrados");
define("LIST_ADMIN_LAN_10", "deixe em branco para mostrar todos os cabeçalhos");
define("LIST_ADMIN_LAN_11", "postfix");
define("LIST_ADMIN_LAN_12", "escolha um postfix se o cabeçalho for maior do que a quantidade de caracteres informado");
define("LIST_ADMIN_LAN_13", "deixe em branco para nenhum postfix");
define("LIST_ADMIN_LAN_14", "data");
define("LIST_ADMIN_LAN_15", "escolha um estilo para a data");
define("LIST_ADMIN_LAN_16", "Para mais informações sobre formatos de data, veja a <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>página do php.net sobre a função strftime</a>");
define("LIST_ADMIN_LAN_17", "data de hoje");
define("LIST_ADMIN_LAN_18", "escolha um estilo para a data se a data for hoje");
define("LIST_ADMIN_LAN_19", "Para mais informações sobre formatos de data, veja a <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>página do php.net sobre a função strftime</a>");
define("LIST_ADMIN_LAN_20", "colunas");
define("LIST_ADMIN_LAN_21", "escolha uma quantidade de colunas");
define("LIST_ADMIN_LAN_22", "defina quantas colunas quer usar. O número que especificar irá separar a página em numa quantidade igual de colunas");
define("LIST_ADMIN_LAN_23", "texto de boas vindas");
define("LIST_ADMIN_LAN_24", "defina um texto de boas vindas que será mostrado no topo da página");
define("LIST_ADMIN_LAN_25", "");
define("LIST_ADMIN_LAN_26", "mostrar vazio");
define("LIST_ADMIN_LAN_27", "defina se a mensagem tem que ser mostrada quando a seção não tem resultados ");
define("LIST_ADMIN_LAN_28", "");
define("LIST_ADMIN_LAN_29", "ícone : padrão");
define("LIST_ADMIN_LAN_30", "usar marca do theme padrão se nenhum ícone estiver presente ou se o ícone a usar estiver desativado");
define("LIST_ADMIN_LAN_31", "");
define("LIST_ADMIN_LAN_32", "falha de tempo:dias");
define("LIST_ADMIN_LAN_33", "máximo de dias que os utilizadores podem ver. (dias passados)");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dias");
define("LIST_ADMIN_LAN_36", "falha de tempo");
define("LIST_ADMIN_LAN_37", "mostra uma caixa de seleção com o número de dias para ver. (dias passados)?");
define("LIST_ADMIN_LAN_38", "");
define("LIST_ADMIN_LAN_39", "abrir se os dados existirem");
define("LIST_ADMIN_LAN_40", "seções que contêm dados devem ser abertas por padrão?");
define("LIST_ADMIN_LAN_41", "");
define("LIST_MENU_1", "recentes adições");
define("LIST_MENU_2", "por");
define("LIST_MENU_3", "no");
define("LIST_MENU_4", "em");
define("LIST_MENU_5", "dias");
define("LIST_MENU_6", "ver conteúdo para quantos dias?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");
define("LIST_NEWS_1", "notícias");
define("LIST_NEWS_2", "não há itens de notícia");
define("LIST_COMMENT_1", "comentários");
define("LIST_COMMENT_2", "sem comentários");
define("LIST_COMMENT_3", "notícias");
define("LIST_COMMENT_4", "faq");
define("LIST_COMMENT_5", "pesquisa");
define("LIST_COMMENT_6", "documentos");
define("LIST_COMMENT_7", "bugtrack");
define("LIST_COMMENT_8", "conteúdo");
define("LIST_COMMENT_9", "download");
define("LIST_COMMENT_10", "ideias");
define("LIST_DOWNLOAD_1", "downloads");
define("LIST_DOWNLOAD_2", "sem downloads");
define("LIST_MEMBER_1", "membros");
define("LIST_MEMBER_2", "sem membros");
define("LIST_CONTENT_1", "conteúdo");
define("LIST_CONTENT_2", "nenhum conteúdo em");
define("LIST_CONTENT_3", "nenhuma categoria de conteúdo válida");
define("LIST_CHATBOX_1", "chatbox");
define("LIST_CHATBOX_2", "sem postagens no chatbox");
define("LIST_CALENDAR_1", "calendário");
define("LIST_CALENDAR_2", "sem eventos no calendário");
define("LIST_LINKS_1", "links");
define("LIST_LINKS_2", "sem links");
define("LIST_FORUM_1", "fórum");
define("LIST_FORUM_2", "sem postagens no fórum");
define("LIST_FORUM_3", "visualizações:");
define("LIST_FORUM_4", "respostas:");
define("LIST_FORUM_5", "última mensagem:");
define("LIST_FORUM_6", "em:");


?>