<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/usertheme_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_UMENU_THEME_1", "Escolher Tema");
define("LAN_UMENU_THEME_2", "Selecionar Tema");
define("LAN_UMENU_THEME_3", "usuários:");
define("LAN_UMENU_THEME_4", "Ativar os temas que os usuários poderão selecionar");
define("LAN_UMENU_THEME_5", "Atualizar");
define("LAN_UMENU_THEME_6", "Temas disponíveis para usuários");
define("LAN_UMENU_THEME_7", "Classe que pode selecionar temas");


?>