<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/newsletter/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NLLAN_MENU_CAPTION", "Newsletter - Boletim");
define("NLLAN_01", "Newsletter - Boletim");
define("NLLAN_02", "Fornece uma forma simples e rápida de configurar e enviar boletim de notícias");
define("NLLAN_03", "Configurar Boletim de Notícias");
define("NLLAN_04", "O plugin newsletter foi instalado com sucesso. Para configurar, volte à página principal da administração e clique em 'Boletim de Notícias' na seção de plugins.");
define("NLLAN_05", "Nenhum boletim de notícia definido ainda");
define("NLLAN_06", "Nome");
define("NLLAN_07", "Assinantes");
define("NLLAN_08", "Opções");
define("NLLAN_09", "Tem certeza que quer apagar este boletim de notícias?");
define("NLLAN_10", "Boletins de Notícia Existentes");
define("NLLAN_11", "Ainda não há edições de boletim de notícias");
define("NLLAN_12", "Edição");
define("NLLAN_13", "[ ID do Parente ] Assunto/Título");
define("NLLAN_14", "Enviado?");
define("NLLAN_15", "Opções");
define("NLLAN_16", "sim");
define("NLLAN_17", "Não enviado - clique para enviar");
define("NLLAN_18", "Tem certeza que quer enviar esta edição para os assinantes?");
define("NLLAN_19", "Tem certeza que quer apagar esta edição do boletim de notícias?");
define("NLLAN_20", "Edições Existentes");
define("NLLAN_21", "Título");
define("NLLAN_22", "Descrição");
define("NLLAN_23", "Cabeçalho");
define("NLLAN_24", "Rodapé");
define("NLLAN_25", "Atualizar Boletim de Notícias");
define("NLLAN_26", "Criar Boletim de Notícias");
define("NLLAN_27", "Boletim de notícias atualizado na base de dados.");
define("NLLAN_28", "Boletim de notícias definido e gravado na base de dados.");
define("NLLAN_29", "Ainda não hà boletins de notícias definidos.");
define("NLLAN_30", "Boletim de Notícias");
define("NLLAN_31", "Assunto / Título");
define("NLLAN_32", "Edição Número");
define("NLLAN_33", "Texto");
define("NLLAN_34", "Atualizar Envios");
define("NLLAN_35", "Criar Envios");
define("NLLAN_36", "Atualizar Edição do Boletim de Notícias");
define("NLLAN_37", "Criar Edição do Boletim de Notícias");
define("NLLAN_38", "Boletim de notícias atualizada na base de dados.");
define("NLLAN_39", "Edição do boletim de notícias gravado na base de dados - para enviar,clique em 'Lançar Edição' no menu Opções.");
define("NLLAN_40", "Envio completo - edição enviada a");
define("NLLAN_41", " assinante(s).");
define("NLLAN_42", "Boletim de notícias apagado.");
define("NLLAN_43", "Edição do boletim de notícias apagado.");
define("NLLAN_44", "Página Inicial do Boletim de Notícias");
define("NLLAN_45", "Criar Boletim de Notícias");
define("NLLAN_46", "Criar Envios");
define("NLLAN_47", "Opções do Boletim de Notícias");
define("NLLAN_48", "você é assinante deste boletim de notícias - se deseja encerrar a assinatura, por favor clique no botão abaixo.");
define("NLLAN_49", "Tem certeza de que deseja cancelar a assinatura deste boletim de notícias?");
define("NLLAN_50", "Clique no botão para assinar ( o endereço da assinatura é");
define("NLLAN_51", "Cancelar Assinatura");
define("NLLAN_52", "Assinar");
define("NLLAN_53", "Tem a certeza de que deseja assinar esta newsletter?");
define("NLLAN_54", "Enviando");
define("NLLAN_55", "ID");
define("NLLAN_56", "ID de Newsletter não disponível");
define("NLLAN_57", "Retornar à página anterior");
define("NLLAN_58", "Erro");
define("NLLAN_59", "Nome");
define("NLLAN_60", "E-mail");
define("NLLAN_61", "Ações");
define("NLLAN_62", "Usuário está banido! (ou não está logado direito)");
define("NLLAN_63", "Total de inscritos");
define("NLLAN_64", "Retornar à primeira página da Newsletter");
define("NLLAN_65", "Visão geral dos inscritos na newsletter ID");


?>