<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/online_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ONLINE_L1", "Visitantes:");
define("ONLINE_L2", "Membros:");
define("ONLINE_L3", "Nesta página:");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Membros");
define("ONLINE_L6", "mais novo");
define("TRACKING_MESSAGE", "O rastreador de usuários online está desativado, favor ativá-lo [link=".e_ADMIN."users.php?options]AQUI[/link][br]");


?>