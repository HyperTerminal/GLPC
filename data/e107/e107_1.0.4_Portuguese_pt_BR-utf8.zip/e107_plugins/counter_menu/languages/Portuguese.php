<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/counter_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("COUNTER_L1", "Visitas do admin não estão sendo contadas.");
define("COUNTER_L2", "Esta página hoje ...");
define("COUNTER_L3", "total");
define("COUNTER_L4", "Esta página sempre ...");
define("COUNTER_L5", "únicos");
define("COUNTER_L6", "Site ...");
define("COUNTER_L7", "Contador");
define("COUNTER_L8", "Mensagem de admin: <b>Registro de estatísticas desligado.</b><br />Para  ativá-lo é necessário instalar o Plugin de Registro de Estatísticas a partir do <a href='".e_ADMIN."plugin.php'>gerenciador de plugins</a>, e depois ativá-lo no <a href='".e_PLUGIN."log/admin_config.php'>no painel de configuração</a>.");


?>