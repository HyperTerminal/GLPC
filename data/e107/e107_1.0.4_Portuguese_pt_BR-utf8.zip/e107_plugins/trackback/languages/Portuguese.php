<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/trackback/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("TRACKBACK_L1", "Configurar Trackback");
define("TRACKBACK_L2", "Este plugin permite usar trackback nas suas notícias.");
define("TRACKBACK_L3", "O Trackback está instalado e ativado.");
define("TRACKBACK_L4", "Preferências de trackback salvas.");
define("TRACKBACK_L5", "Sim");
define("TRACKBACK_L6", "Não");
define("TRACKBACK_L7", "Ativar trackbacks");
define("TRACKBACK_L8", "Texto da URL do trackback");
define("TRACKBACK_L9", "Salvar Preferências");
define("TRACKBACK_L10", "Preferências de Trackback");
define("TRACKBACK_L11", "Endereço trackback para esta mensagem:");
define("TRACKBACK_L12", "Não existe trackbacks para este item");
define("TRACKBACK_L13", "Moderar trackbacks");
define("TRACKBACK_L14", "Apagar");
define("TRACKBACK_L15", "Trackbacks apagados.");


?>