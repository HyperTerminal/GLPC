<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/clock_menu/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CLOCK_MENU_L1", "Configuração do Clock Menu salva");
define("CLOCK_MENU_L2", "Subtítulo");
define("CLOCK_MENU_L3", "Atualizar Preferências");
define("CLOCK_MENU_L4", "Configurações do Clock Menu");
define("CLOCK_MENU_L5", "Segunda,");
define("CLOCK_MENU_L6", "Terça,");
define("CLOCK_MENU_L7", "Quarta,");
define("CLOCK_MENU_L8", "Quinta,");
define("CLOCK_MENU_L9", "Sexta,");
define("CLOCK_MENU_L10", "Sábado,");
define("CLOCK_MENU_L11", "Domingo,");
define("CLOCK_MENU_L12", "de Janeiro de");
define("CLOCK_MENU_L13", "de Fevereiro de");
define("CLOCK_MENU_L14", "de Março de");
define("CLOCK_MENU_L15", "de Abril de");
define("CLOCK_MENU_L16", "de Maio de");
define("CLOCK_MENU_L17", "de Junho de");
define("CLOCK_MENU_L18", "de Julho de");
define("CLOCK_MENU_L19", "de Agosto de");
define("CLOCK_MENU_L20", "de Setembro de");
define("CLOCK_MENU_L21", "de Outubro de");
define("CLOCK_MENU_L22", "de Novembro de");
define("CLOCK_MENU_L23", "de Dezembro de");
define("CLOCK_MENU_L24", "");


?>