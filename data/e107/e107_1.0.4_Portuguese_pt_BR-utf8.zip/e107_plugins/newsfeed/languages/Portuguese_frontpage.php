<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/newsfeed/languages/Portuguese_Brazilian_frontpage.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NWSF_FP_1", "Notícias Externas");
define("NWSF_FP_2", "página principal");


?>