<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_plugins/integrity_check/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("Integ_01", "Gravação com sucesso");
define("Integ_02", "Falha na gravação");
define("Integ_03", "Arquivos Faltantes:");
define("Integ_04", "Erros CRC:");
define("Integ_05", "Incapaz de abrir arquivo...");
define("Integ_06", "Verificar integridade dos arquivos");
define("Integ_07", "Nenhum arquivo disponível");
define("Integ_08", "Verificar integridade");
define("Integ_09", "Criar arquivo sfv");
define("Integ_10", "A pasta selecionada <u>não</u> será gravada no arquivo crc.");
define("Integ_11", "Nome do arquivo:");
define("Integ_12", "Criar arquivo sfv");
define("Integ_13", "Verificando a integridade");
define("Integ_14", "Criação do arquivo SFV impossível, porque a pasta ".e_PLUGIN."integrity_check/<b>{output}</b> não permite escrita. Por favor altere o CHMOD desta pasta para 777!");
define("Integ_15", "Todos os arquivos foram verificados e estão o.k.!");
define("Integ_16", "Nenhum arquivo crc do núcleo do sistema disponível");
define("Integ_17", "Nenhum arquivo crc dos plugins disponível");
define("Integ_18", "Criar arquivo CRC dos plugins");
define("Integ_19", "Arquivo Checksum do Núcleo do Sistema");
define("Integ_20", "Arquivo Checksum dos Plugins");
define("Integ_21", "Selecione o plugin para o qual quer criar um arquivo crc.");
define("Integ_22", "Usar gzip");
define("Integ_23", "Verificar somente themes instalados");
define("Integ_24", "Página Inicial do Admin");
define("Integ_25", "Sair da Área do Admin");
define("Integ_26", "Carregar site com o cabeçalho normal");
define("Integ_27", "USE O ARQUIVO FILEINSPECTOR PARA CHECAR OS ARQUIVOS DO NÚCLEO DO SISTEMA");
define("Integ_30", "Para forçar menos a CPU, pode fazer a verificação em 1 - 10 passos.");
define("Integ_31", "Passos:");
define("Integ_32", "Existe um arquivo chamado <b>log_crc.txt</b> na pasta crc. Por favor apague-o! (Ou tente atualizar a página)");
define("Integ_33", "Existe um arquivo chamado <b>log_miss.txt</b> na pasta crc. Por favor apague-o! (Ou tente atualizar a página)");
define("Integ_34", "A sua pasta CRC não permite escrita!");
define("Integ_35", "Devido aos seguintes motivos, só é permitido escolher <b>um</b> passo:");
define("Integ_36", "Clique aqui, se não quer esperar 5 segundos até o próximo passo:");
define("Integ_37", "Clique aqui");
define("Integ_38", "Ainda faltam <u><i>{counts}</i></u> linhas...");
define("Integ_39", "Por favor apague o arquivo:<br />".e_PLUGIN."integrity_check/<u><i>do_core_file.php</i></u>!<br />Esta desatualizado e nunca foi destinado ao público...");


?>