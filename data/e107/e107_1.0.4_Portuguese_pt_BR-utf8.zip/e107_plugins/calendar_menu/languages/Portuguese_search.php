<?php
/*
+---------------------------------------------------------------+
|        e107 website system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Portuguese_search.php $
|        $Revision: 1.0 $
|        $Id: 2010/09/20 14:22:35 $
|        $Author: barbaratostes $
+---------------------------------------------------------------+
*/

define("CM_SCH_LAN_1", "Calendário");


?>