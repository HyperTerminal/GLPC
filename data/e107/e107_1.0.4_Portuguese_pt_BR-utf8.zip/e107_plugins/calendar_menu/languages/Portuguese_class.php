<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Portuguese_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/17 10:59:42 $
|        $Author: barbaratostes $
+---------------------------------------------------------------+
*/

define("EC_LAN_RECUR_00", "não");
define("EC_LAN_RECUR_01", "anual");
define("EC_LAN_RECUR_02", "semestral");
define("EC_LAN_RECUR_03", "trimestral");
define("EC_LAN_RECUR_04", "mensal");
define("EC_LAN_RECUR_05", "de quatro em quatro semanas");
define("EC_LAN_RECUR_06", "quinzenal");
define("EC_LAN_RECUR_07", "semanal");
define("EC_LAN_RECUR_08", "diariamente");
define("EC_LAN_RECUR_100", "Todo Domingo do mês");
define("EC_LAN_RECUR_101", "Toda Segunda-feira do mês");
define("EC_LAN_RECUR_102", "Toda Terça-feira do mês");
define("EC_LAN_RECUR_103", "Toda Quarta-feira do mês");
define("EC_LAN_RECUR_104", "Toda Quinta-feira do mês");
define("EC_LAN_RECUR_105", "Toda Sexta-feira do mês");
define("EC_LAN_RECUR_106", "Todo Sábado do mês");
define("EC_LAN_RECUR_1100", "Primeiro");
define("EC_LAN_RECUR_1200", "Segundo");
define("EC_LAN_RECUR_1300", "Terceiro");
define("EC_LAN_RECUR_1400", "Quarto");
define("NT_LAN_EC_1", "Eventos do Calendário de Eventos");
define("NT_LAN_EC_2", "Evento Atualizado");
define("NT_LAN_EC_3", "Atualizado por");
define("NT_LAN_EC_4", "Endereço IP");
define("NT_LAN_EC_5", "Mensagem");
define("NT_LAN_EC_6", "Calendário de Eventos - Evento adicionado");
define("NT_LAN_EC_7", "Novo evento postado");
define("NT_LAN_EC_8", "Calendário de Eventos - Evento modificado");
define("EC_ADM_01", "Calendário de Eventos - Evento adicionado");
define("EC_ADM_02", "Calendário de Eventos - Evento editado");
define("EC_ADM_03", "Calendário de Eventos - Evento deletado");
define("EC_ADM_04", "Calendário de Eventos - Exclusão em massa");
define("EC_ADM_05", "Calendário de Eventos - Adição em massa");
define("EC_ADM_06", "Calendário de Eventos - Opções Principais modificadas");
define("EC_ADM_07", "Calendário de Eventos - opções modificadas");
define("EC_ADM_08", "Calendário de Eventos - Categoria adicionada");
define("EC_ADM_09", "Calendário de Eventos - Categoria editada");
define("EC_ADM_10", "Calendário de Eventos - Categoria deletada");
define("EC_ADM_11", "Calendário de Eventos - Eventos Antigos deletados");


?>