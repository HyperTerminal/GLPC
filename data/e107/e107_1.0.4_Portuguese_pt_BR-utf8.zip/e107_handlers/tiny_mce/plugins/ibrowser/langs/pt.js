// UK lang variables
tinyMCE.addI18n('pt_br.ibrowser',{
	desc : 'Navegador de Imagens'
});