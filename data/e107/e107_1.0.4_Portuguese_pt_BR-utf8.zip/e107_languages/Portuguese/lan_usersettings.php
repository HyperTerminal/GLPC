<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_usersettings.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Preferências dos Usuários");
define("LAN_7", "Nome de Exibição:");
define("LAN_8", "<u>Nome para exibição no site</u>");
define("LAN_9", "Nome de Login:");
define("LAN_10", "<u>Nome para ser usado no LOGIN e no site</u>");
define("LAN_11", "O nome que você usa para se logar no site - este não pode ser modificado, Por favor contate o administrador se houver necessidade de mudança por finalidades de segurança");
define("LAN_20", "Erro");
define("LAN_105", "As duas senhas não conferem");
define("LAN_106", "Aparentemente não foi indicado um e-mail válido");
define("LAN_112", "Endereço de E-Mail:");
define("LAN_113", "Esconder o E-Mail?");
define("LAN_114", "<u>Isto impede que o seu e-mail seja mostrado no site</u>");
define("LAN_120", "Assinatura:");
define("LAN_121", "Avatar:");
define("LAN_122", "Fuso horário:");
define("LAN_150", "Preferências atualizadas e gravadas na base de dados.");
define("LAN_151", "OK");
define("LAN_152", "Nova Senha:");
define("LAN_153", "Confirme a Nova Senha:");
define("LAN_154", "Atualizar Preferências");
define("LAN_155", "Atualizar Preferências do Usuário");
define("LAN_185", "Campo de senha deixado em branco");
define("LAN_308", "Nome Real:");
define("LAN_401", "<u>Deixe em branco para manter a senha atual</u>");
define("LAN_402", "Digite o caminho ou escolha um avatar");
define("LAN_403", "Escolher avatar");
define("LAN_404", "<b>Aviso:</b> Qualquer imagem enviada para este servidor que seja considerada inapropriada pelos administradores será apagada de imediato.");
define("LAN_410", "Preferências para");
define("LAN_411", "Atualizar Suas Preferências");
define("LAN_412", "Mudar Sua Senha");
define("LAN_413", "Escolha Um Avatar");
define("LAN_414", "Upload de Fotografia");
define("LAN_415", "Upload de Avatar");
define("LAN_416", "Sim");
define("LAN_417", "Não");
define("LAN_418", "Informações de Registro");
define("LAN_419", "Pessoal / Informação de Contato");
define("LAN_420", "Avatar");
define("LAN_421", "Escolher um avatar existente");
define("LAN_422", "Usar um avatar remoto");
define("LAN_423", "<u>Indique a URL de endereço completo da imagem</u>");
define("LAN_424", "<u>Clique no botão para ver avatares existentes no site</u>");
define("LAN_425", "Foto");
define("LAN_426", "<u>Isto vai ser mostrado na sua página de perfil</u>");
define("LAN_433", "URL do arquivo XUP");
define("LAN_434", "O que é isso?");
define("LAN_435", "Arquivo XML do Usuário");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "carac.");
define("LAN_SIGNUP_4", "Sua senha deve ter, pelo menos,");
define("LAN_SIGNUP_5", " caracteres de comprimento.");
define("LAN_SIGNUP_6", "Sua(seu)");
define("LAN_SIGNUP_7", " é necessária(o)");
define("LAN_USET_1", "O comprimento de seu avatar é muito grande");
define("LAN_USET_2", "O comprimento máximo permitido é");
define("LAN_USET_3", "A altura de seu avatar é muito grande");
define("LAN_USET_4", "A altura máxima permitida é");
define("LAN_CUSTOMTITLE", "Título Personalizado");
define("LAN_408", "Um usuário com esse endereço de e-mail já existe.");
define("MAX_AVWIDTH", "A largura e altura máxima do avatar é");
define("MAX_AVHEIGHT", "x");
define("RESIZE_NOT_SUPPORTED", "Ajuste por favor a imagem ou escolha outra. O arquivo foi deletado.");
define("LAN_USET_5", "Subscrever em");
define("LAN_USET_6", "<u>Subscreva-se em nossas listas de mailing e/ou seções deste site.</u>");
define("LAN_USET_7", "Miscelâneas");
define("LAN_USET_8", "Assinatura / Fuso horário");
define("LAN_USET_9", "Alguns dos campos requeridos (marcados com  *) faltam  em suas preferências.");
define("LAN_USET_10", "Por favor atualize agora suas preferências a fim de proseguir.");
define("LAN_USET_11", "Este nome de usuário não foi aceito como válido, por favor escolha um nome diferente de usuário");
define("LAN_USET_12", "Este nome de usuário é muito curto. Por favor escolha outro");
define("LAN_USET_13", "Há caracteres inválidos no login. Por favor escolha outros");
define("LAN_USET_14", "Nome de login muito longo. Favor escolher outro");
define("LAN_USET_15", "Nome de Exibição muito longo. Favor escolher outro");
define("LAN_USET_16", "Marque a caixa para apagar a foto existente sem enviar outra");
define("LAN_USET_17", "Nome de Exibição já está em uso. Favor escolher outro");
define("LAN_USET_18", "Nome inválido para o avatar");
define("LAN_USET_19", "Avatar não pode ser acessado");
define("LAN_USET_20", "Não foi possível ter informação da imagem");


?>