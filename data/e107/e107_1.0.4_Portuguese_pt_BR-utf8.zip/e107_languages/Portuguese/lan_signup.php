<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_signup.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Registro");
define("LAN_7", "Nome de Exibição:");
define("LAN_8", "este nome é exibido no site");
define("LAN_9", "Nome de Login:");
define("LAN_10", "este nome será usado como LOGIN!");
define("LAN_17", "Senha:");
define("LAN_103", "Esse nome de usuário não pode ser aceito como válido. Escolha um nome diferente");
define("LAN_104", "Esse nome de usuário já existe na base de dados. Escolha um nome diferente");
define("LAN_105", "As duas senhas não conferem");
define("LAN_106", "Não parece ser um endereço de e-mail válido");
define("LAN_107", "Muito Obrigado! Agora você é um membro registrado de");
define("LAN_108", "Registro concluído");
define("LAN_109", "Este site cumpre as normas da <b>The Children's Online Privacy Protection Act of 1998 (COPPA)</b> e, como tal, não pode aceitar registros de usuários com menos de 18 anos sem a autorização escrita dos pais ou tutores. Para mais informações, leia a legislação");
define("LAN_110", "Registro");
define("LAN_111", "Re-escreva a Senha:");
define("LAN_112", "Endereço de E-Mail:");
define("LAN_113", "Esconder o endereço de E-Mail?:");
define("LAN_114", "isto impede que o seu e-mail seja mostrado no site");
define("LAN_123", "Registrar");
define("LAN_185", "Deixou campo(s) obrigatório(s) em branco");
define("LAN_201", "Sim");
define("LAN_200", "Não");
define("LAN_202", "Você já possui uma conta. Se por acaso esqueceu sua senha, por favor clique no link 'esqueceu sua senha?'.");
define("LAN_309", "Por favor indique os detalhes abaixo.");
define("LAN_399", "Continuar");
define("LAN_400", "O nome de usuário e a senhas são sensíveis a <b>maiúsculas-minúsculas</b>");
define("LAN_401", "Sua conta foi ativada, por favor");
define("LAN_402", "Registro ativado");
define("LAN_403", "Bem-vindo(a)");
define("LAN_404", "Detalhes de registro para");
define("LAN_405", "Esta etapa do registro está completa. Você receberá um e-mail de confirmação contendo a sua informação de login. Siga o link indicado no e-mail para completar o processo de registro e ativar a sua conta.");
define("LAN_406", "Muito Obrigado!");
define("LAN_407", "Guarde este e-mail com a informação de Nome de Usuário e Senha. Os seus dados foram criptografados e não podem ser recuperados se você os esquecer. É possível, no entanto, pedir um nova senha se isso acontecer.nnObrigado por seu registro.nnDe");
define("LAN_408", "Um usuário com esse e-mail já existe. Favor usar o sistema de recuperação de senhas para recuperar a sua.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "caracteres.");
define("LAN_SIGNUP_3", "Código de verificação falhou");
define("LAN_SIGNUP_4", "As senhas devem ter, pelo menos,");
define("LAN_SIGNUP_5", " caracteres de comprimento.");
define("LAN_SIGNUP_6", "Sua");
define("LAN_SIGNUP_7", " é requerida");
define("LAN_SIGNUP_8", "Muito Obrigado!");
define("LAN_SIGNUP_9", "Impossível prosseguir.");
define("LAN_SIGNUP_10", "Sim");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Caracteres inválidos no nome de usuário");
define("LAN_410", "Digite código visível na imagem");
define("LAN_411", "Este nome de exibição já existe na base de dados, por favor escolha um nome de exibição diferente");
define("LAN_SIGNUP_12", "mantenha por favor seu username e senha em um lugar seguro.");
define("LAN_SIGNUP_13", "Você pode agora logar-se utilizando o menu de login, ou clicando <a href='".e_BASE."login.php'>AQUI</a>.");
define("LAN_SIGNUP_14", " aqui");
define("LAN_SIGNUP_15", "Por favor entre em contato com o adminstrador do site");
define("LAN_SIGNUP_16", "se você precisar de ajuda.");
define("LAN_SIGNUP_17", "Estou de acordo com as normas do site/portal e desejo me cadastrar agora!.");
define("LAN_SIGNUP_18", "Seu registo foi recebido e criado com a seguinte informação do início de uma sessão..");
define("LAN_SIGNUP_21", "Sua conta está definida como inativa, e para ativá-la, você deverá clicar no seguinte link...");
define("LAN_SIGNUP_22", "clique aqui");
define("LAN_SIGNUP_23", "para login.");
define("LAN_SIGNUP_24", "Obrigado por se registrar conosco!");
define("LAN_SIGNUP_25", "Upload do seu avatar");
define("LAN_SIGNUP_26", "Upload da sua foto");
define("LAN_SIGNUP_27", "Mostrar");
define("LAN_SIGNUP_28", "escolha do Conteúdo / Listas de e-mails");
define("LAN_SIGNUP_29", "Um e-mail de verificação será enviado ao endereço que você inserir aqui, portanto o mesmo deve ser válido.");
define("LAN_SIGNUP_30", "Se você não quiser mostrar o endereço de e-mail no site, por favor clique na caixa 'esconder o endereço de e-mail'.");
define("LAN_SIGNUP_31", "URL para o arquivo XUP");
define("LAN_SIGNUP_32", "O que é o arquivo XUP?");
define("LAN_SIGNUP_33", "Digite o endereço ou escolha o avatar");
define("LAN_SIGNUP_34", "Por favor, Atenção: Se a imagem enviada para o servidor for classificada como inapropriada pelo(s) administrador(es) a mesma será deletada imediatamente.");
define("LAN_SIGNUP_35", "Clique aqui para registrar usando o arquivo XUP");
define("LAN_SIGNUP_36", "Um erro ocorreu durante a criação da informação do usuário, por favor entre em contato com o administrador do site");
define("LAN_LOGINNAME", "Nome de Login");
define("LAN_PASSWORD", "Senha");
define("LAN_USERNAME", "Nome de Exibição");
define("LAN_EMAIL_01", "Prezado(a)");
define("LAN_EMAIL_04", "Mantenha por favor este e-mail para sua informação.");
define("LAN_EMAIL_05", "Sua senha é encriptada e não pode ser recuperada caso perca ou esqueça dela. No entanto pode-se pedir uma nova senha caso isto ocorra.");
define("LAN_EMAIL_06", "Obrigado por se registrar.");
define("LAN_SIGNUP_37", "Este estágio de registro está concluído. Sua solicitação de registro necessitará de aprovação do administrador. Assim que a solicitação for liberada você receberá um e-mail confirmando o registro no site.");
define("LAN_SIGNUP_38", "Você inseriu 2 endereços de e-mail diferentes. Por favor insira um endereço de e-mail válido nos dois campos fornecidos");
define("LAN_SIGNUP_39", "Re-escreva o endereço de e-mail:");
define("LAN_SIGNUP_40", "Ativação não necessária");
define("LAN_SIGNUP_41", "Sua conta já foi ativada.");
define("LAN_SIGNUP_42", "Há um problema, o e-mail com o registro não foi enviado, favor entrar em contato com o administrador do site.");
define("LAN_SIGNUP_43", "E-mail enviado");
define("LAN_SIGNUP_44", "E-mail de ativação enviado para:");
define("LAN_SIGNUP_45", "Favor checar seu e-mail.");
define("LAN_SIGNUP_47", "Re-enviar e-mail de ativação");
define("LAN_SIGNUP_48", "Nome de usuário ou E-mail");
define("LAN_SIGNUP_49", "Se você registrou-se com um endereço de e-mail errado, digite um novo e-mail e sua senha aqui:");
define("LAN_SIGNUP_50", "Novo E-Mail");
define("LAN_SIGNUP_51", "Senha antiga");
define("LAN_SIGNUP_52", "Senha incorreta");
define("LAN_SIGNUP_53", "teste de campo de validação falhou");
define("LAN_SIGNUP_54", "Clique aqui para preencher seus detalhes no registro");
define("LAN_SIGNUP_55", "Esse nome de exibição é muito longo. Por favor escolher outro");
define("LAN_SIGNUP_56", "Este nome de exibição é muito curto. Por favor escolher outro");
define("LAN_SIGNUP_57", "Este nome de login é muito grande. Favor escolher outro");
define("LAN_SIGNUP_58", "Visualização da tela de Login");
define("LAN_SIGNUP_59", "**** Se o link não funcionar, verifique em que parte não há o funcionamento e vá para a próxima linha. ****");
define("LAN_SIGNUP_60", "Erro ao acessar avatar externo");
define("LAN_SIGNUP_72", "Obrigado por se cadastrar no [sitename]! Nós acabamos de enviar a você um email de confirmação para [email]. Favor clicar no link que aparece  no email para completar seu cadastro e ativar sua conta.");
define("LAN_SIGNUP_98", "Confirme seu endereço de email");
define("LAN_SIGNUP_99", "Problema Encontrado");
define("LAN_SIGNUP_100", "Aprovação do Admin está pendente");
define("LAN_SIGNUP_102", "Login recusado");
define("LAN_SIGNUP_103", "Muitos usuários já estão utilizando este endereço IP:");
define("LAN_SIGNUP_104", "Nome inválido de avatar");
define("LAN_SIGNUP_105", "Não foi possível processar sua solicitação - favor entrar em contato com o administrador do site");
define("LAN_SIGNUP_106", "Não foi possível processar sua solicitação - você já possui uma conta criada aqui?");


?>