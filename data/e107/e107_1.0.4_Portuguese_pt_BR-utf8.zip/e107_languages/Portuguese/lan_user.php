<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_user.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Membros");
define("LAN_20", "Erro");
define("LAN_112", "Endereço de E-Mail:");
define("LAN_115", "Número de ICQ:");
define("LAN_116", "Endereço AIM:");
define("LAN_117", "MSN Messenger:");
define("LAN_118", "Data de Nascimento:");
define("LAN_119", "Localização:");
define("LAN_120", "Assinatura:");
define("LAN_137", "Não existe informação para o usuário, pois não está registrado em");
define("LAN_138", "Membros registrados:");
define("LAN_139", "Ordem:");
define("LAN_140", "Membros registrados");
define("LAN_141", "Não há membros registrados no momento.");
define("LAN_142", "Membro");
define("LAN_143", "[sigilo requisitado]");
define("LAN_144", "URL do Website:");
define("LAN_145", "Registrado em");
define("LAN_146", "Visitas ao site desde o registro:");
define("LAN_147", "Postagens na área de Chat");
define("LAN_148", "Comentários postados:");
define("LAN_149", "Postagens no fórum:");
define("LAN_308", "Nome Real:");
define("LAN_400", "Esse não é um usuário válido.");
define("LAN_401", "sem informação");
define("LAN_402", "Perfil do Membro");
define("LAN_403", "Estatísticas do Site");
define("LAN_404", "Última visita");
define("LAN_405", "dias atrás");
define("LAN_406", "Avaliação");
define("LAN_407", "nada");
define("LAN_408", "sem foto");
define("LAN_409", "pontos");
define("LAN_410", "Vários");
define("LAN_411", "Clique aqui para atualizar as suas informações");
define("LAN_412", "Clique aqui para editar a informação deste usuário");
define("LAN_413", "apagar a foto");
define("LAN_414", "Membro anterior");
define("LAN_415", "Membro seguinte");
define("LAN_416", "Você precisa estar logado para acessar esta página");
define("LAN_417", "Administrador Geral");
define("LAN_418", "Administrador do Site");
define("LAN_419", "Mostrar");
define("LAN_420", "P/ Baixo");
define("LAN_421", "P/ Cima");
define("LAN_422", "Ir");
define("LAN_423", "Clique aqui para ver comentários de usuários");
define("LAN_424", "Clique aqui para ver postagens no Fórum");
define("LAN_425", "Enviar Mensagem Privada");
define("LAN_426", "atrás");
define("USERLAN_1", "Minha Avaliação");
define("USERLAN_2", "Você não tem permissão para acessar esta página.");


?>