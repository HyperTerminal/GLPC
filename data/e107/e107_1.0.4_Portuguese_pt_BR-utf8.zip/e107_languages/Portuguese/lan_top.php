<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_top.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("TOP_LAN_0", "Maiores criadores em Fóruns");
define("TOP_LAN_1", "Nome do Usuário");
define("TOP_LAN_2", "Postagens");
define("TOP_LAN_3", "Maiores Comentadores");
define("TOP_LAN_4", "Comentários");
define("TOP_LAN_5", "Maiores usuários do ChatBox");
define("TOP_LAN_6", "Avaliação do Site");
define("LAN_1", "Debate");
define("LAN_2", "Mensagens");
define("LAN_3", "Visualizações");
define("LAN_4", "Respostas");
define("LAN_5", "Última Postagem");
define("LAN_6", "Debates");
define("LAN_7", "Debates Mais Populares");
define("LAN_8", "Top Membros");


?>