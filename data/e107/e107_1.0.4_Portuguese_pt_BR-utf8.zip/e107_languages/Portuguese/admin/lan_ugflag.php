<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_ugflag.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UGFLAN_1", "Preferências de manutenção atualizadas");
define("UGFLAN_2", "Ativar estado de manutenção");
define("UGFLAN_3", "Atualizar as Preferências de Manutenção");
define("UGFLAN_4", "Preferências de Manutenção");
define("UGFLAN_5", "Texto mostrado quando estiver em manutenção");
define("UGFLAN_6", "<u>Deixe em branco para mostrar a mensagem padrão</u>");
define("UGFLAN_8", "Acesso Restrito a Administradores");
define("UGFLAN_9", "Acesso Restrito apenas a Main-Admins");


?>