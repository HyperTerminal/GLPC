<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_mailout.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PRFLAN_52", "Salvar Alterações");
define("PRFLAN_63", "Enviar um e-mail de teste");
define("PRFLAN_65", "Clique para enviar um e-mail para");
define("PRFLAN_66", "E-Mail de teste para");
define("PRFLAN_67", "Este é um e-mail de teste, ele confirma que os ajustes do e-mail estão funcionando perfeitamente!nnAgradecimentos para os desenvolvedores do sistema de websites e107.");
define("PRFLAN_68", "O e-mail não podia ser enviado. Parece que seu servidor não está configurado corretamente para enviar e-mails, por favor tente novamente usando o SMTP, ou contate seu host(servidor) e peça a verificação do sistema de envios de e-mail(do host) / ajustes de e-mail do servidor.");
define("PRFLAN_69", "O e-mail foi enviado com sucesso, verifique por favor sua caixa de entrada de e-mail.");
define("PRFLAN_70", "Método de mailing");
define("PRFLAN_71", "<u>Se não deu certo, tentar com o php</u>");
define("PRFLAN_72", "Servidor SMTP");
define("PRFLAN_73", "Nome de Usuário SMTP");
define("PRFLAN_74", "Senha SMTP");
define("PRFLAN_75", "O e-mail não pôde ser enviado. Reveja por favor os ajustes do SMTP, ou desabilite o SMTP e tente outra vez.");
define("MAILAN_01", "Nome");
define("MAILAN_02", "Para o E-Mail");
define("MAILAN_03", "Para");
define("MAILAN_04", "Cópia Carbono");
define("MAILAN_05", "Bcc");
define("MAILAN_06", "Assunto");
define("MAILAN_07", "Arquivo Atachado");
define("MAILAN_08", "Enviar E-Mail");
define("MAILAN_09", "Usar o Estilo do Thema");
define("MAILAN_10", "Usuário Subscrito");
define("MAILAN_11", "Inserir Variáveis");
define("MAILAN_12", "Todos os Membros");
define("MAILAN_13", "Todos os membros não verificados");
define("MAILAN_14", "Recomenda-se o uso do SMTP para enviar grandes quantidades de mensagens, ajuste-o nas preferências abaixo.");
define("MAILAN_15", "Serviço de Mailing");
define("MAILAN_16", "username");
define("MAILAN_17", "link de registro");
define("MAILAN_18", "ID do usuário");
define("MAILAN_19", "Não há nenhum e-mail para o administrador. Por favor verifique suas preferências e tente novamente.");
define("MAILAN_20", "Endereço de envio de e-mail");
define("MAILAN_21", "Entradas para envio de e-mails em massa");
define("MAILAN_22", "Não há atualmente nenhuma entrada salva");
define("MAILAN_23", "classe de usuário:");
define("MAILAN_24", "o e-mail(s) está pronto para ser enviado");
define("MAILAN_25", "Pausa");
define("MAILAN_26", "Parar envio de e-mail em massa a cada");
define("MAILAN_27", "e-mails");
define("MAILAN_28", "Tamanho da Pausa");
define("MAILAN_29", "segundos");
define("MAILAN_30", "Mais de 30 segundos pode causar 'time-out' do navegador");
define("MAILAN_31", "Processo de Retorno de E-Mail");
define("MAILAN_32", "Endereço de E-Mail");
define("MAILAN_33", "Entrada de E-Mail");
define("MAILAN_34", "Nome da Conta");
define("MAILAN_35", "Senha");
define("MAILAN_36", "Apagar e-mails que retornam antes de checar");
define("MAILAN_37", "Continuar");
define("MAILAN_38", "Cancelar");
define("MAILAN_39", "Enviando e-mails");
define("MAILAN_40", "Você precisa renomear o <b>e107.htaccess</b> para <b>.htaccess</b> em");
define("MAILAN_41", "antes de enviar e-mail por esta página.");
define("MAILAN_42", "Atenção");
define("MAILAN_43", "Usuário");
define("MAILAN_44", "Login de Usuário");
define("MAILAN_45", "E-mail do Usuário");
define("MAILAN_46", "Usuários que sejam iguais a");
define("MAILAN_47", "contém");
define("MAILAN_48", "igual");
define("MAILAN_49", "ID");
define("MAILAN_50", "Autor");
define("MAILAN_51", "Assunto");
define("MAILAN_52", "Última modificação");
define("MAILAN_53", "Admins");
define("MAILAN_54", "Para você mesmo");
define("MAILAN_55", "Classe de Usuários");
define("MAILAN_56", "Enviar E-Mail");
define("MAILAN_57", "Manter a sessão SMTP ativa");
define("MAILAN_58", "Há um problema com o arquivo anexado:");
define("MAILAN_59", "Progresso do envio de e-mail");
define("MAILAN_60", "Enviando...");
define("MAILAN_61", "Não há e-mails remanescentes a enviar.");
define("MAILAN_62", "E-mails enviados:");
define("MAILAN_63", "E-mails que falharam:");
define("MAILAN_64", "Tempo total gasto no envio:");
define("MAILAN_65", "segundos");
define("MAILAN_66", "Cancelado com sucesso");
define("MAILAN_67", "Usar autenticação 'POP antes de SMTP'");
define("MAILAN_68", "Endereço de teste");
define("MAILAN_69", "login do usuário");
define("MAILAN_70", "email do usuário");


?>