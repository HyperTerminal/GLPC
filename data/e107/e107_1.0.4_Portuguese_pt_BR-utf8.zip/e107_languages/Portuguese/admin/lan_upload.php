<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_upload.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UPLLAN_1", "Upload removido da lista.");
define("UPLLAN_2", "Definições gravadas na base de dados");
define("UPLLAN_3", "Identificação do Upload");
define("UPLLAN_5", "Autor");
define("UPLLAN_6", "E-Mail");
define("UPLLAN_7", "Website");
define("UPLLAN_8", "Nome do Arquivo");
define("UPLLAN_9", "Versão");
define("UPLLAN_10", "Arquivo");
define("UPLLAN_11", "Tamanho do Arquivo");
define("UPLLAN_12", "Imagem");
define("UPLLAN_13", "Descrição");
define("UPLLAN_14", "Demo");
define("UPLLAN_16", "Copiar para Notícias");
define("UPLLAN_17", "marcar como indesejado");
define("UPLLAN_18", "Ver os detalhes");
define("UPLLAN_19", "Não há uploads públicos sem moderador");
define("UPLLAN_20", "Há");
define("UPLLAN_21", "uploads públicos sem moderação");
define("UPLLAN_22", "Identificação");
define("UPLLAN_23", "Nome");
define("UPLLAN_24", "Tipo de arquivo");
define("UPLLAN_25", "Permitir Uploads?");
define("UPLLAN_26", "<u>Não serão permitidos uploads públicos se estiver desativado</u>");
define("UPLLAN_27", "uploads públicos sem moderação");
define("UPLLAN_29", "Tipo de armazenamento");
define("UPLLAN_30", "<u>Escolha a forma de guardar os arquivos de upload: se como arquivos normais no servidor ou se como informação binária na base de dados. <br /><b>OBS.:</b> binários são adequados apenas para arquivos menores que, aproximadamente, 500kB</u>");
define("UPLLAN_31", "Como arquivo");
define("UPLLAN_32", "Binário");
define("UPLLAN_33", "Tamanho máximo do arquivo");
define("UPLLAN_34", "<u>Tamanho máximo do upload em bytes - deixe em branco para seguir a definição do php.ini (a definição de php.ini é</u>");
define("UPLLAN_35", "Tipos de arquivos permitidos");
define("UPLLAN_36", "Indique um tipo por linha");
define("UPLLAN_37", "Permissões");
define("UPLLAN_38", "<u>Selecione para permitir que alguns usuários possam fazer upload</u>");
define("UPLLAN_39", "Enviar");
define("UPLLAN_41", "Aviso - o upload está desativado no seu php.ini; não será possível fazer upload até que seja alterado.");
define("UPLLAN_42", "Ações");
define("UPLLAN_43", "Uploads");
define("UPLLAN_44", "Upload");
define("UPLLAN_45", "Você está certo que quer deletar o seguinte arquivo...");
define("UPLAN_COPYTODLM", "cópia para gerenciador de download");
define("UPLAN_IS", "é");
define("UPLAN_ARE", "são");
define("UPLAN_COPYTODLS", "Copiar para Downloads");
define("UPLLAN_48", "<u>Por razões de segurança, os tipos de arquivos permitidos foram removidos do banco de dados para um arquivo localizado na sua pasta admin do servidor. Para usar, renomeie o arquivo e107_admin/filetypes_.php para e107_admin/filetypes.php e adicione uma vírgula entre um tipo de arquivo e outro. Você não deve permitir upload de arquivos do tipo .html, .txt, etc pois um cracker/attacker poderá enviar um arquivo deste tipo que pode incluir javascript malicioso. Você também não deve, é claro, permitir upload de arquivos .php ou qualquer outro tipo de script executável.</u>");


?>