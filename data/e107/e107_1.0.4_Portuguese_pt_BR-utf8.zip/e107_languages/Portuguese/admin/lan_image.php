<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_image.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("IMALAN_1", "Permitir postar imagens");
define("IMALAN_2", "Mostrar imagens, isto se aplicará a todo o site (comentários, área de Chat etc.) para imagens postadas com o bbcode [img]");
define("IMALAN_3", "Método de redimensionamento");
define("IMALAN_4", "Método usado para redimensionar imagens, ou biblioteca GD1/2 ou ImageMagick");
define("IMALAN_5", "Caminho para o ImageMagick (se selecionado)");
define("IMALAN_6", "Caminho completo para o utilitário de conversão ImageMagick");
define("IMALAN_7", "Definições de Imagens");
define("IMALAN_8", "Atualizar as Definições de Imagens");
define("IMALAN_9", "Definições de imagens atualizadas");
define("IMALAN_10", "Classe para postar imagens");
define("IMALAN_11", "Restringir usuários que podem postar imagens (se selecionado acima)");
define("IMALAN_12", "Desativar o método das imagens");
define("IMALAN_13", "<u>O que fazer com as imagens postadas se a postagem for desativada</u>");
define("IMALAN_14", "Mostrar a URL de origem da imagem");
define("IMALAN_15", "Não mostrar nada");
define("IMALAN_16", "Mostrar avatares atualizados");
define("IMALAN_17", "Clique Aqui");
define("IMALAN_18", "Imagens enviadas");
define("IMALAN_19", "Mostrar mensagem de 'desativado' ");
define("IMALAN_21", "Usada por");
define("IMALAN_22", "Imagem não usada");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Foto");
define("IMALAN_25", "Clique aqui para apagar as imagens não usadas");
define("IMALAN_26", "imagem(s) apagada(s)");
define("IMALAN_28", "apagada");
define("IMALAN_29", "Sem imagens");
define("IMALAN_30", "Todos (público)");
define("IMALAN_31", "Convidados apenas");
define("IMALAN_32", "Membros apenas");
define("IMALAN_33", "Administradores apenas");
define("IMALAN_34", "Permitir Sleight");
define("IMALAN_35", "Reparo transparente PNG-24's com alpha transparência in IE 5 / 6 (Aplica-se Sitewide)");
define("IMALAN_36", "Validar o tamanho do avatar e o acesso");
define("IMALAN_37", "Validação de avatar");
define("IMALAN_38", "Largura máxima permitida");
define("IMALAN_39", "Altura máxima permitida");
define("IMALAN_40", "Muito largo");
define("IMALAN_41", "Muito alto");
define("IMALAN_42", "Não encontrado");
define("IMALAN_43", "Apagar avatar enviado");
define("IMALAN_44", "Apagar referência externa");
define("IMALAN_45", "Não encontrado");
define("IMALAN_46", "Muito largo");
define("IMALAN_47", "Total de avatares enviados");
define("IMALAN_48", "Total de avatares externos");
define("IMALAN_49", "Usuários com avatares");
define("IMALAN_50", "Total");
define("IMALAN_51", "Avatar para");
define("IMALAN_52", "Caminho para a ImageMagick parece estar incorreto");
define("IMALAN_53", "Caminho para ImageMagick parece estar correto, mas o arquivo convertido pode não ser válido");
define("IMALAN_54", "Versão da GD instalada:");
define("IMALAN_55", "Não instalada(o)");


?>