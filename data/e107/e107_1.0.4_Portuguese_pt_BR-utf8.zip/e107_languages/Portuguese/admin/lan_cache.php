<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_cache.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CACLAN_1", "Status do sistema de Cache");
define("CACLAN_2", "Definir o status do Cache");
define("CACLAN_3", "Sistema de Cache");
define("CACLAN_4", "Status do Cache definido");
define("CACLAN_5", "Esvaziar Cache");
define("CACLAN_6", "Cache Esvaziado");
define("CACLAN_7", "Cache Desativado");
define("CACLAN_9", "Dados do Cache salvos em arquivos no disco (servidor)");
define("CACLAN_10", "O diretório do Cache não é gravável. Por favor, assegure-se de dar o CHMOD 777.");


?>