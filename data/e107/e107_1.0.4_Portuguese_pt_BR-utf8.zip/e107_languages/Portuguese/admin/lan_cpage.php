<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_cpage.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CUSLAN_1", "Título");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opções");
define("CUSLAN_4", "Deletar esta página?");
define("CUSLAN_5", "Páginas Existentes");
define("CUSLAN_7", "Nome do Menu");
define("CUSLAN_8", "Título / Subtítulo");
define("CUSLAN_9", "Texto");
define("CUSLAN_10", "Votação para esta página");
define("CUSLAN_11", "Página Inicial");
define("CUSLAN_12", "Criar Página");
define("CUSLAN_13", "Permitir comentários");
define("CUSLAN_14", "Proteger página com senha");
define("CUSLAN_15", "<u>Entre com a senha de proteção</u>");
define("CUSLAN_16", "Criar link no menu principal");
define("CUSLAN_17", "<u>Digite um nome para o link</u>");
define("CUSLAN_18", "Página / link visível para");
define("CUSLAN_19", "Atualizar Página");
define("CUSLAN_20", "Criar Página");
define("CUSLAN_21", "Atualizar Menu");
define("CUSLAN_22", "Criar Menu");
define("CUSLAN_23", "Editar página");
define("CUSLAN_24", "Criar nova página");
define("CUSLAN_25", "Editar menu");
define("CUSLAN_26", "Criar novo menu");
define("CUSLAN_27", "Página salva no banco de dados.");
define("CUSLAN_28", "Página deletada");
define("CUSLAN_29", "Lista páginas se não houver páginas selecionadas");
define("CUSLAN_30", "Tempo para expirar o cookie <b>(em segundos)</b>");
define("CUSLAN_31", "Criar Menu");
define("CUSLAN_32", "Converter antigas páginas/menus");
define("CUSLAN_33", "Opções de Página");
define("CUSLAN_34", "Começando a conversão");
define("CUSLAN_35", "Atualização terminada feita pelo usuário - atualizada ");
define("CUSLAN_36", "Para ajustar suas preferências para cada página, retorne por favor à página principal e edite as páginas.");
define("CUSLAN_37", "Atualização da Página Customizada");
define("CUSLAN_38", "sim");
define("CUSLAN_39", "não");
define("CUSLAN_40", "Opções Salvas");
define("CUSLAN_41", "Exibir informações do autor e data");
define("CUSLAN_42", "Não há páginas definidas");
define("CUSLAN_43", "menu sem título: ");
define("CUSLAN_44", "página sem título ");


?>