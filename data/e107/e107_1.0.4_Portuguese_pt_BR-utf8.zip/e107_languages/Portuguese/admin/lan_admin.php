<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_admin.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ADLAN_0", "Notícias");
define("ADLAN_1", "Adicionar/editar/apagar ítens de notícias");
define("ADLAN_4", "Preferências");
define("ADLAN_5", "Editar as preferências do site");
define("ADLAN_6", "Menus");
define("ADLAN_7", "Alterar a ordem dos menus");
define("ADLAN_8", "Administradores");
define("ADLAN_9", "Adicionar/apagar administradores do site");
define("ADLAN_10", "Senha do Admin");
define("ADLAN_11", "Altere sua senha");
define("ADLAN_24", "Downloads");
define("ADLAN_25", "Gerenciar downloads");
define("ADLAN_28", "Mensagem de Boas-Vindas");
define("ADLAN_29", "Definir mensagens estáticas de boas-vindas");
define("ADLAN_30", "Gerenciador de Arquivos");
define("ADLAN_31", "Gerenciar arquivos de upload");
define("ADLAN_34", "Lista de Banidos");
define("ADLAN_35", "Banir visitantes");
define("ADLAN_36", "Usuários");
define("ADLAN_37", "Moderar membros do site");
define("ADLAN_38", "Classe de Usuários");
define("ADLAN_39", "Criar/editar classe de usuários");
define("ADLAN_40", "Manutenção");
define("ADLAN_41", "Colocar o site em manutenção");
define("ADLAN_42", "Páginas Customizadas");
define("ADLAN_43", "Criar ítens de menu de usuários");
define("ADLAN_44", "Base de Dados");
define("ADLAN_45", "Utilitários da base de dados");
define("ADLAN_46", "Logout");
define("ADLAN_47", "Bem Vindo");
define("ADLAN_48", "Logado como");
define("ADLAN_49", "Administrador Geral");
define("ADLAN_51", "Faça login para obter acesso às áreas de administração");
define("ADLAN_52", "Página Inicial de Admin");
define("ADLAN_53", "Sair do Admin");
define("ADLAN_54", "Anúncios (Banners)");
define("ADLAN_55", "Configurar os anúncios");
define("ADLAN_58", "Emoticons");
define("ADLAN_59", "Configurar emoticons");
define("ADLAN_60", "Página Inicial");
define("ADLAN_61", "Configurar o conteúdo da página inicial");
define("ADLAN_66", "Meta Tags");
define("ADLAN_67", "Adicionar/editar as meta tags do site");
define("ADLAN_68", "Informação PHP");
define("ADLAN_69", "Página de informação PHP");
define("ADLAN_72", "Uploads Públicos");
define("ADLAN_73", "Configurar arquivos públicos de uploads");
define("ADLAN_74", "Cache");
define("ADLAN_75", "Definir o estado do cache");
define("ADLAN_78", "Campos Extendidos");
define("ADLAN_79", "Editar campos extendidos");
define("ADLAN_89", "Nome do Admin");
define("ADLAN_90", "Senha do Admin");
define("ADLAN_91", "LogIn");
define("ADLAN_92", "Faça login para prosseguir para a área de administração...");
define("ADLAN_93", "Mostrar Funções Administrativas");
define("ADLAN_95", "Gerenciar os Plugins");
define("ADLAN_98", "Gerenciador de Plugin");
define("ADLAN_99", "Instalar/atualizar plugins");
define("ADLAN_102", "A senha de administração não é mudada há mais de 30 dias -");
define("ADLAN_103", "Clique aqui para mudá-la agora!");
define("ADLAN_104", "Segurança");
define("ADLAN_105", "Imagens");
define("ADLAN_106", "Definições de imagem");
define("ADLAN_110", "Membros registrados");
define("ADLAN_111", "Membros não confirmados");
define("ADLAN_112", "Usuários banidos");
define("ADLAN_113", "Postagens no fórum");
define("ADLAN_114", "Comentários");
define("ADLAN_115", "Postagens na área de chat");
define("ADLAN_116", "Log de Admin");
define("ADLAN_117", "Ver tudo");
define("ADLAN_118", "Limpar o log");
define("ADLAN_119", "Links enviados não verificados");
define("ADLAN_120", "Há uma atualização na base de dados disponível; clique para instalar...");
define("ADLAN_121", "Instalar");
define("ADLAN_132", "Linguagem");
define("ADLAN_133", "Linguagem padrão do site");
define("ADLAN_134", "Status");
define("ADLAN_135", "Login de Admin");
define("ADLAN_136", "E-Mail");
define("ADLAN_137", "Preferências de e-mail e mailout");
define("ADLAN_138", "Links do Site");
define("ADLAN_139", "Adicionar/editar/deletar links");
define("ADLAN_140", "Gerenciador de Temas");
define("ADLAN_141", "Instalar/definir temas");
define("ADLAN_142", "Buscas");
define("ADLAN_143", "Configuração da busca");
define("ADLAN_144", "Você está no modo de visualização simples, para mudar para visualização avançada");
define("ADLAN_145", "Clique Aqui");
define("ADLAN_146", "Tentativas de login falhas");
define("ADLAN_147", "Inspetor de Arquivos");
define("ADLAN_148", "Scanear os arquivos do site");
define("ADLAN_149", "Notificações");
define("ADLAN_150", "E-Mail para notificação do admin");
define("ADLAN_151", "Iniciar");
define("ADLAN_152", "Insira o Código");
define("ADLAN_153", "Área de Admin");
define("ADLAN_154", "Erro ao tentar entrar em contato com o e107.org para chegar a existência de nova versão");
define("ADLAN_CL_1", "Configurações");
define("ADLAN_CL_2", "Usuários");
define("ADLAN_CL_3", "Conteúdo");
define("ADLAN_CL_4", "Comentários");
define("ADLAN_CL_5", "Arquivos");
define("ADLAN_CL_6", "Ferramentas");
define("ADLAN_CL_7", "Plugins");
define("ADLAN_CL_8", "Documentos");
define("ADLAN_LAT_1", "Mais tarde");
define("ADLAN_LAT_2", "Notícias enviadas");
define("ADLAN_LAT_5", "Links enviados");
define("ADLAN_LAT_6", "Postagens do fórum reportadas");
define("ADLAN_LAT_7", "Arquivos enviados");
define("ADLAN_LAT_8", "Há mensagens não moderadas pelo administrador");
define("ADLAN_LAT_9", "Comentários pendentes");
define("ADLAN_ERR_2", "Há arquivos no seu servidor que podem ser potencialmente perigosos e portanto devem ser removidos <b>IMEDIATAMENTE</b>. Estes arquivos estão relacionados com as versões antigas 0.6.xx do e107. Por favor delete todos os diretórios a seguir e seus conteúdos:");
define("ADLAN_ERR_3", "Existe um ou mais arquivos no seu diretório de upload público que não estão na lista de arquivos permitidos. Isto pode ter sido colocado aqui por um cracker/attacker e precisa ser removido <b>imediatamente</b>. Você <b>NÃO deve</b> abrir esses arquivos porque eles podem conter códigos maliciosos. Por exemplo, não abra-o em seu navegador.<br /><br />Se você reconhece esses arquivos como legítimos, pode ser que alguma mudança recente nos tipos de arquivos permitidos tenha sido feita, o tipo de arquivo permitido pode não estar mais na lista e você precisa adicionar novamente (veja admin => uploads). Você não deve permitir uploads de arquivos html, .txt, etc porque um attacker poderá enviar um arquivo deste tipo que inclua javascript malicioso. Você também não deve, é claro, permitir upload de arquivos .php ou outro tipo de script executável.<br /><br />Abaixo, uma lista de tipos de arquivos que podem ser potencialmente maliciosos:");
define("ADLAN_ERR_4", "Arquivo(s) de plugin depreciado(s) encontrado(s)");
define("ADLAN_ERR_5", "Os seguintes arquivos precisam ser renomeados para");
define("ADLAN_ERR_6", "Então, clique para re-scanear sua pasta de plugins.");
define("ADLAN_ERR_7", "Arquivos maliciosos foram detectados no seu servidor. Eles deverão ser deletados [b]IMEDIATAMENTE[/b].");
define("ADLAN_ERR_8", "Favor rodar o [File inspector] para verificar os arquivos do core que talvez possam ter sido modificados.");
define("LAN_EDIT", "Editar");
define("LAN_DELETE", "Deletar");
define("LAN_CREATE", "Criar");
define("LAN_UPDATE", "Atualizar");
define("LAN_SAVE", "Salvar");
define("LAN_SAVED", "Salvo");
define("LAN_SETSAVED", "Suas preferências foram salvas");
define("LAN_CONFIRMDEL", "Por favor, confirme seu pedido para deletar");
define("LAN_OPTIONS", "Opções");
define("LAN_PREFS", "Preferências");
define("LAN_DELETED", "Deletado com sucesso");
define("LAN_UPDATED", "Atualizado com sucesso");
define("LAN_CREATED", "Criado com sucesso");
define("LAN_CREATED_FAILED", "Criação sem sucesso");
define("LAN_DELETED_FAILED", "Deleção sem sucesso");
define("LAN_UPDATED_FAILED", "Atualização sem sucesso");
define("LAN_NO_CHANGE", "O update mal sucedido sem nenhuma mudança foi feito.");
define("LAN_TRY_AGAIN", "Por favor tente novamente.");
define("LAN_RESET", "Resetar");
define("LAN_CLEAR", "Limpar");
define("LAN_OK", "OK");
define("LAN_PRESET", "Pré-ajuste");
define("LAN_PRESET_SAVED", "Pré-ajuste salvo com sucesso");
define("LAN_PRESET_DELETED", "Pré-ajuste detelado com sucesso");
define("LAN_PRESET_CONFIRMDEL", "Você está certo se quer suprimir este pré-ajuste?");
define("LAN_NOTWRITABLE", "não pode ser escrito, você necessita primeiro de CHMOD 777 na pasta.");
define("LAN_DATE", "Data");
define("LAN_TIME", "Hora");
define("LAN_YES", "Sim");
define("LAN_NO", "Não");
define("LAN_EMPTY", "Não há nenhuma entrada na base de dados ainda");
define("LAN_EXISTING", "Entradas Existentes");
define("LAN_CANCEL", "Cancelar");
define("LAN_CONFDELETE", "Confirmar o Delete");
define("LAN_PLUGIN", "Plugin");
define("LAN_ORDER", "Ordem");
define("LAN_SELECT", "Selecione..");
define("LAN_ADMIN", "Administrador");
define("LAN_DISPLAYOPT", "Editar as Opções de Exibição");
define("LAN_GOPAGE", "Ir para página:");
define("LAN_DATESTAMP", "Gravar data");
define("LAN_OPTIONAL", "opcional");
define("LAN_INACTIVE", "Inativo");
define("LAN_BAN", "Banido");
define("LAN_RATING", "Votação");
define("LAN_UPLOAD", "Upload");
define("LAN_UPLOAD_IMAGES", "Enviar Imagens");
define("LAN_UPLOAD_FILES", "Enviar Arquivos");
define("LAN_UPLOAD_ADDFILE", "Adicionar outro arquivo");
define("LAN_UPLOAD_CONFIRM", "Qualquer mudança não salva nesta página será perdida. Continuar?");
define("LAN_UPLOAD_777", "Pasta faltando ou não tem permissão de escrita. Você precisa fazer CHMOD 777 nas seguintes pastas antes de enviar/fazer upload:");
define("LAN_UPLOAD_SERVEROFF", "Esta opção está desativada como arquivo não permitido no seu servidor");
define("LAN_DISABLED", "Desativado");
define("LAN_ENABLED", "Ativado");
define("LAN_PRESET_CONFIRMSAVE", "Salvar valores do formulário como o padrão para esta página?");
define("LAN_CONFIGURE", "Configurar");
define("LAN_BACK", "Voltar");
define("LAN_CREDITS", "Créditos");
define("LAN_NEWVERSION", "Nova Versão Disponível");
define("LAN_NEWVERSION_MORE", "saiba mais");
define("LAN_NEWVERSION_DLD", "Download %s de SF.net");
define("LAN_NEWVERSION_CHECK_ERROR", "Erro na verificação da versão");
define("LAN_SECURITYL_0", "Procurando problemas (nenhum)");
define("LAN_SECURITYL_5", "Balanceado");
define("LAN_SECURITYL_8", "Alto");
define("LAN_SECURITYL_10", "Insano");
define("LAN_PLEASEWAIT", "Favor Aguardar");


?>