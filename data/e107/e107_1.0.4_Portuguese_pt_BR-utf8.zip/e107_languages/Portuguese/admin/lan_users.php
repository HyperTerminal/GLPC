<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_users.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("USRLAN_1", "Alterações Salvas.");
define("USRLAN_3", "listado agora um administrador - Para definir permissões, vá para");
define("USRLAN_4", "Página do administrador");
define("USRLAN_5", "Não se pode remover permissão de administração do administrador principal do site");
define("USRLAN_6", "status de administração foi removido.");
define("USRLAN_7", "Não se pode banir o administrador do site");
define("USRLAN_8", "Usuário banido.");
define("USRLAN_9", "Usuário reintegrado.");
define("USRLAN_10", "Usuário apagado.");
define("USRLAN_11", "Apagamento cancelado.");
define("USRLAN_12", "Não se pode apagar o administrador principal do site.");
define("USRLAN_13", "Confirme eliminação deste membro");
define("USRLAN_16", "Confirme Eliminação");
define("USRLAN_17", "Confirme Eliminação do Usuário");
define("USRLAN_30", "Banir");
define("USRLAN_32", "Ativar");
define("USRLAN_33", "Reintegrar");
define("USRLAN_34", "Remover status de administrador");
define("USRLAN_35", "Tornar administrador");
define("USRLAN_36", "Definir Classe");
define("USRLAN_44", "Permitir que os membros façam upload de avatares?");
define("USRLAN_47", "Comprimento máximo do avatar (em pixels)");
define("USRLAN_48", "valor padrão é 120");
define("USRLAN_49", "Altura máxima do avatar (em pixels)");
define("USRLAN_50", "valor padrão é 100");
define("USRLAN_51", "Atualizar Opções");
define("USRLAN_52", "Opções de Membros");
define("USRLAN_53", "Permitir aos usuários fazer upload de foto?");
define("USRLAN_54", "Clique aqui para apagar os usuários não ativados");
define("USRLAN_55", "Eliminar");
define("USRLAN_56", "Apagado(s)");
define("USRLAN_57", "Apagando os usuários não ativados...");
define("USRLAN_58", "O upload de arquivos está desativado no php.ini");
define("USRLAN_59", "Adicionar usuário rapidamente");
define("USRLAN_60", "Adicionar Usuário");
define("USRLAN_61", "Nome de Usuário");
define("USRLAN_62", "Senha");
define("USRLAN_63", "Confirmar Senha");
define("USRLAN_64", "E-Mail");
define("USRLAN_65", "Esse nome de usuário não pode ser aceito. Por favor, escolha outro nome de usuário diferente");
define("USRLAN_66", "Esse nome de usuário já existe na base de dados. Por favor, escolha um diferente");
define("USRLAN_67", "As duas senhas não conferem");
define("USRLAN_68", "Campo(s) obrigatório(s) deixado(s) em branco");
define("USRLAN_69", "O e-mail não parece ser válido!");
define("USRLAN_70", "Usuário criado");
define("USRLAN_71", "Página Inicial de Usuários");
define("USRLAN_72", "Adição Rápida de Usuário");
define("USRLAN_73", "Remover Usuários");
define("USRLAN_75", "Este nome de login já existe no banco de dados, favor escolher um nome de login diferente");
define("USRLAN_76", "Opções de Usuários");
define("USRLAN_77", "Usuários Existentes");
define("USRLAN_78", "Nome de Usuário");
define("USRLAN_79", "Situação");
define("USRLAN_80", "Info");
define("USRLAN_84", "Existem");
define("USRLAN_85", "usuários que não ativaram suas contas - clique abaixo para apagar.");
define("USRLAN_86", "Usuário verificado");
define("USRLAN_87", "Configuração de usuário atualizada");
define("USRLAN_88", "Classes de usuário atualizadas");
define("USRLAN_90", "Procurar Usuários");
define("USRLAN_91", "Classe");
define("USRLAN_92", "Caracteres inválidos no nome de usuário");
define("USRLAN_93", "Apagar usuários não verificados");
define("USRLAN_94", "<u>Apaga registros se não verificados depois desse tempo decorrido - deixar em branco para não usar a opção</u>");
define("USRLAN_95", "minutos");
define("USRLAN_112", "Reenviar E-Mail");
define("USRLAN_113", "Detalhes de registro para");
define("USRLAN_114", "Prezado(a)");
define("USRLAN_115", "Obrigado por ser registrar.");
define("USRLAN_116", "Favor confirmar seu desejo de reenviar um e-mail de confirmação para:");
define("USRLAN_117", "Clique no botão abaixo para testar o seguinte e-mail:");
define("USRLAN_118", "Testar E-Mail");
define("USRLAN_120", "Definir Classes");
define("USRLAN_121", "Enviar Newsletter");
define("USRLAN_122", "Bem Vindo a");
define("USRLAN_123", "Seu registo foi recebido e criado.");
define("USRLAN_124", "Sua conta está setada como inativa, para ativá-la, basta acessar o seguinte link");
define("USRLAN_125", "Para");
define("USRLAN_126", "Permitir que os usuários avaliem outros usuários");
define("USRLAN_127", "Permitir comentários no perfil de usuário");
define("USRLAN_128", "Nome de Login");
define("USRLAN_130", "Permitir rastrear (tracking) usuários online");
define("USRLAN_131", "<u>Você deve habilitar essa opção para usar as opções de rastreamento de usuários online, como online.php, informação online do fórum e menus</u>");
define("USRLAN_132", "Habilitar");
define("USRLAN_133", "Forçar usuários a atualizar as preferências");
define("USRLAN_134", "<u>Ativando essa opcão irá levar o usuário automaticamente à sua página de preferências se o campo requerido não estiver marcado (ou selecionado).</u>");
define("USRLAN_135", "Nenhum endereço IP encontrado nas informações do usuário, não foi possível banir este IP");
define("USRLAN_136", "Múltiplos usuários encontrados com o IP {IP}, não foi possível banir este IP.");
define("USRLAN_137", "Usuários banidos do IP {IP}.");
define("USRLAN_138", "Usuários não verificados");
define("USRLAN_139", "Sua conta foi ativada!.nnVocê deve acessar o {SITEURL} para fazer login usando as informações fornecidas anteriormente.");
define("USRLAN_140", "Re-enviar e-mail para");
define("USRLAN_141", "Falha no reenvio de e-mail para");
define("USRLAN_142", "com o seguinte link de ativação");
define("USRLAN_143", "Checar por Retornos");
define("USRLAN_144", "Re-enviar Confirmação de E-mail para Todos");
define("USRLAN_145", "Usuários que retornaram e-mail");
define("USRLAN_146", "Informação do membro disponível para");
define("USRLAN_147", "Endereço de email já foi usado por um usuário banido");
define("USRLAN_148", "Endereço de email está banido");
define("USRLAN_149", "Deletar emails marcados");
define("USRLAN_150", "Deletar todos os emails");
define("USRLAN_151", "Limpar emails que voltam (bounce), requer Ativação");
define("USRLAN_152", "Limpar emails que voltam (bounce) e Ativar");
define("USRLAN_153", "Deletar emails não entregues");
define("USRLAN_154", "Limpar emails marcados");
define("USRLAN_155", "Um total de {TOTAL} emails foram encontrados. {DELCOUNT} foram apagados nas opções. <br />{DELUSER} usuários marcados como 'devolvedores' (bounced) (em {FOUND} emails).");
define("USRLAN_156", "Endereço de email já está em uso");
define("USRLAN_157", "Caracteres inválidos no nome de login");
define("LAN_MAINADMIN", "Admin Principal");
define("LAN_NOTVERIFIED", "Não Verificado");
define("LAN_BANNED", "Banido");
define("LAN_BOUNCED", "Retornado");
define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "Nome de Exibição");
define("DUSRLAN_3", "Nome de Usuário");
define("DUSRLAN_4", "Título Customizado");
define("DUSRLAN_5", "Senha");
define("DUSRLAN_6", "Sessão");
define("DUSRLAN_7", "E-Mail");
define("DUSRLAN_8", "Website");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "Localização");
define("DUSRLAN_13", "Aniversário");
define("DUSRLAN_14", "Assinatura");
define("DUSRLAN_15", "Imagem");
define("DUSRLAN_16", "Fuso horário");
define("DUSRLAN_17", "Esconder e-mail");
define("DUSRLAN_18", "Data de Cadastro");
define("DUSRLAN_19", "Última Visita");
define("DUSRLAN_20", "Visita Atual");
define("DUSRLAN_21", "Última Postagem");
define("DUSRLAN_22", "Postagem de Chatbox");
define("DUSRLAN_23", "Comentários");
define("DUSRLAN_24", "Postagem do Fórum");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "Banido");
define("DUSRLAN_27", "Preferências");
define("DUSRLAN_28", "Novo");
define("DUSRLAN_29", "Visualizado");
define("DUSRLAN_30", "Visitas");
define("DUSRLAN_31", "Administrador");
define("DUSRLAN_32", "Nome Real");
define("DUSRLAN_33", "Classes de Usuários");
define("DUSRLAN_34", "Permissão");
define("DUSRLAN_35", "Imagem");
define("DUSRLAN_36", "Mudar Senha");
define("DUSRLAN_37", "XUP");
define("USRLAN_190", "Período experimental de novo usuário (dias)");
define("USRLAN_191", "(admin pode impor restrições durante este período, em algumas áreas)");
define("USRLAN_194", "Assinatura pode ser modificada por");
define("USRLAN_219", "Mais antigo que 30 dias");


?>