<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_db_verify.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("DBLAN_1", "Impossível ler o arquivo de dados de sql<br /><br />Assegure-se que o arquivo <b>core_sql.php</b> existe no diretório <b>/admin/sql</b>.");
define("DBLAN_2", "Verificando tudo");
define("DBLAN_4", "Tabela");
define("DBLAN_5", "Campo");
define("DBLAN_6", "Status");
define("DBLAN_7", "Notas");
define("DBLAN_8", "difere");
define("DBLAN_9", "Atualmente");
define("DBLAN_10", "deveria ser");
define("DBLAN_11", "Campo em falta");
define("DBLAN_12", "Campo Extra!");
define("DBLAN_13", "Falta tabela!");
define("DBLAN_14", "Escolha tabela(s) para validar");
define("DBLAN_15", "Iniciar Verificação");
define("DBLAN_16", "Verificação SQL");
define("DBLAN_17", "Voltar");
define("DBLAN_18", "Tabelas");
define("DBLAN_19", "Tentativa de reparar");
define("DBLAN_20", "Tentar reparar tabelas");
define("DBLAN_21", "Reparar os seguintes ítens");
define("DBLAN_22", "não pode ser lido");


?>