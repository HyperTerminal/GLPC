<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_db.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("DBLAN_1", "Definições dos arquivos de sistema salvos na base de dados.");
define("DBLAN_2", "Clique no botão para gravar uma cópia da base de dados do e107");
define("DBLAN_3", "Backup da base de dados SQL");
define("DBLAN_4", "Clique no botão para verificar a validade da base de dados do e107");
define("DBLAN_5", "Verificar a validade da base de dados");
define("DBLAN_6", "Clique no botão para otimizar a base de dados do e107");
define("DBLAN_7", "Otimizar a base de dados SQL");
define("DBLAN_8", "Clique no botão para fazer uma cópia de segurança das definições dos arquivos de sistema");
define("DBLAN_9", "Cópia de segurança dos arquivos de sistema");
define("DBLAN_10", "Utilitários da base de dados");
define("DBLAN_11", "Base de dados MySQL");
define("DBLAN_12", "otimizada");
define("DBLAN_13", "Voltar");
define("DBLAN_14", "Completo");
define("DBLAN_15", "Clique no botão para verificar disponibilidade de atualização do BD");
define("DBLAN_16", "Verificar Atualizações");
define("DBLAN_17", "Nome da Preferência");
define("DBLAN_18", "Valor da Preferência");
define("DBLAN_19", "Clique no botão para abrir o editor de preferências (para usuários avançados apenas)");
define("DBLAN_20", "Editor de Preferências");
define("DBLAN_21", "Deletar os selecionados");
define("DBLAN_22", "Plugin: Ver e escanear");
define("DBLAN_23", "Escaneamento Completado");
define("DBLAN_24", "Nome");
define("DBLAN_25", "Diretório");
define("DBLAN_26", "Adicionais Incluídos");
define("DBLAN_27", "Instalado");
define("DBLAN_28", "Clique no botão para escanear o diretório de plugins para procurar modificações");
define("DBLAN_29", "Escanear o diretório de plugins");
define("DBLAN_30", "(Se um addon mostrar um erro, fazer verificação para caracteres fora da abertura de PHP/Tag de fechamento)");
define("DBLAN_31", "Passou");
define("DBLAN_32", "Erro");
define("DBLAN_33", "Inacessível");
define("DBLAN_34", "Não checado");
define("DBLAN_35", "Clique no botão para verificar a validade da tabela de usuários");
define("DBLAN_36", "Verificar a tabela de usuários");


?>