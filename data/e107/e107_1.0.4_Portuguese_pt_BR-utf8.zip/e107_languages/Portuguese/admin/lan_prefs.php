<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_prefs.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PRFLAN_1", "Informação do Site");
define("PRFLAN_2", "Nome do Site");
define("PRFLAN_3", "URL do Site");
define("PRFLAN_4", "Botão de Link do Site");
define("PRFLAN_5", "Tagline do Site");
define("PRFLAN_6", "Descrição do Site");
define("PRFLAN_7", "Administrador principal do site");
define("PRFLAN_8", "E-Mail do administrador");
define("PRFLAN_9", "Observações do Site");
define("PRFLAN_10", "Tema");
define("PRFLAN_11", "Tema do Site");
define("PRFLAN_12", "Clique aqui para visualizar themas");
define("PRFLAN_13", "Mostrar Informação");
define("PRFLAN_14", "Mostrar informação do thema?");
define("PRFLAN_15", "Mostrar tempo de execução?");
define("PRFLAN_16", "Mostrar as queries de SQL?");
define("PRFLAN_17", "Compactar os dados do site usando gzip");
define("PRFLAN_19", "Opções de Registro de Página");
define("PRFLAN_21", "Opções de Exibição de Data");
define("PRFLAN_22", "Formato de data curto");
define("PRFLAN_23", "Formato de data longo");
define("PRFLAN_24", "Formato da data no fórum");
define("PRFLAN_25", "<u>Para mais informações sobre formato de data, veja a</u>");
define("PRFLAN_26", "Compensação de hora");
define("PRFLAN_27", "<u>Exemplo: se preencher com +2, todas as horas no site serão somadas de 2 horas</u>");
define("PRFLAN_28", "Registro/Postagem de Usuário");
define("PRFLAN_29", "Ativar o sistema de registro de usuários?");
define("PRFLAN_30", "<u>Permitir aos usuários registrarem-se como membros do site?</u>");
define("PRFLAN_32", "Permitir postagens anônimas?");
define("PRFLAN_33", "<u>Se desmarcado, só os membros do site poderão postar ou comentar.</u>");
define("PRFLAN_35", "Ativar a proteção contra excesso de requisições?");
define("PRFLAN_36", "Tempo de Requisição (Flood)");
define("PRFLAN_37", "Auto Banimento");
define("PRFLAN_38", "<b>Exemplo:</b> <u>Considerando o número de requisições igual a 100 e o tempo 50, quando alguma página receber um número de requisições igual a 100 em 50 segundos, ela ficará inacessível por 50 segundos</u>");
define("PRFLAN_40", "Filtro de vocabulário indecoroso ou ofensivo?");
define("PRFLAN_41", "<u>Se ativado as palavras não permitidas serão substituídas pela(s) indicada(s) abaixo</u>");
define("PRFLAN_42", "Palavra(s) de substituição");
define("PRFLAN_43", "Filtrar palavras");
define("PRFLAN_44", "<b>palavras a censurar, separadas por vírgulas</b>");
define("PRFLAN_45", "Usar a página do COPPA no registro?");
define("PRFLAN_46", "<u>Para mais informações sobre o COPPA veja</u>");
define("PRFLAN_47", "Segurança e Proteção");
define("PRFLAN_48", "Método de rastreamento de usuário");
define("PRFLAN_49", "Cookies");
define("PRFLAN_50", "Sessões");
define("PRFLAN_52", "Gravar Alterações");
define("PRFLAN_53", "Preferências do Site");
define("PRFLAN_55", "Nome do Cookie (se opção de cookies selecionada)");
define("PRFLAN_56", "Fuso Horário");
define("PRFLAN_58", "Restringir o site só para membros");
define("PRFLAN_59", "<u>Se selecionar vai tornar todas as áreas, além da página inicial e de registro, só para membros</u>");
define("PRFLAN_60", "Ativar SSL");
define("PRFLAN_61", "<u>Só ative esse recurso se <b>tiver certeza do que está fazendo!</b></u>");
define("PRFLAN_76", "Habilita verificação por código de imagem no cadastro.");
define("PRFLAN_77", "Mostra Opções de Administração");
define("PRFLAN_78", "<u>Deixar em branco para desabilitar</u>");
define("PRFLAN_80", "Clique aqui para visualizar");
define("PRFLAN_81", "Habilita verificação por código de imagem no LOGIN.");
define("PRFLAN_83", "exemplo");
define("PRFLAN_87", "Comentários");
define("PRFLAN_88", "Permitir comentários aninhados");
define("PRFLAN_89", "Mostrar ícone após novo comentário");
define("PRFLAN_90", "Permita que os postadores editem seus comentários");
define("CUSTSIG_1", "Configurações Salvas!");
define("CUSTSIG_2", "Nome Real:");
define("CUSTSIG_3", "Website:");
define("CUSTSIG_4", "Aniversário:");
define("CUSTSIG_5", "Localidade:");
define("CUSTSIG_6", "Assinatura:");
define("CUSTSIG_7", "Avatar");
define("CUSTSIG_8", "Fuso Horário:");
define("CUSTSIG_12", "Ocultar");
define("CUSTSIG_13", "Campos");
define("CUSTSIG_14", "Mostrar");
define("CUSTSIG_15", "Requerido");
define("CUSTSIG_16", "Comprimento mínimo para senhas");
define("CUSTSIG_17", "Subscrever o conteúdo/saída de mensagens");
define("CUSTSIG_18", "Desativar usernames");
define("CUSTSIG_19", "<u>Os usuários que contêm o seguinte texto serão rejeitados, palavras separadas por vírgulas</u>");
define("PRFLAN_91", "<u>Se alguém estiver atacando seu servidor por pedidos múltiplos a seu usuário, o IP será proibido automaticamente!  Não substitua uma config correta do servidor!!!</u>");
define("PRFLAN_92", "Verificação segura do cadastro -- esconder a senha enviada no e-mail?");
define("PRFLAN_93", "página da função do strftime em php.net");
define("PRFLAN_94", "AQUI!!");
define("PRFLAN_95", "Exibição de informações de plugin:");
define("PRFLAN_96", "<u>Indicará as informações em todas as páginas do admin para cada plugin suportando este tipo de característica</u>");
define("PRFLAN_97", "Menu original de 'Plugins info':");
define("PRFLAN_98", "<u>Se não selecionado, cada plugin indicará sua própria informação em um menu individual. Se selecionado, toda a informação será indicada em um menu.</u>");
define("PRFLAN_101", "Texto Traduzido");
define("PRFLAN_102", "Substituir os links");
define("PRFLAN_103", "<u>Ativando esta opção, os links postados serão substituídos por texto inserido na caixa de texto abaixo, os links muito longos serão divididos para evitar problemas no layout do site</u>");
define("PRFLAN_104", "Links substituídos por texto");
define("PRFLAN_105", "<u>O texto para substituir os links com imagem pode ser usado usando <b>< tag da img</b>, com a url da imagem a ser exibida</u>");
define("PRFLAN_106", "Preferências do sistema salvas no banco de dados.");
define("PRFLAN_107", "Links de e-mail substituídos por texto");
define("PRFLAN_108", "<u>O texto para substituir os links de e-mail com imagem pode ser usado usando <b>< tag da img</b>, com a url da imagem a ser exibida</u>");
define("PRFLAN_109", "Texto principal com palavras muito longas");
define("PRFLAN_110", "<u>As palavras maiores do que o comprimento incorporado, serão envolvidas por muito mais tempo em uma linha nova</u>");
define("PRFLAN_111", "Menu de texto com palavras muito longas");
define("PRFLAN_112", "Sim");
define("PRFLAN_113", "Não");
define("PRFLAN_116", "Permitir postagem HTML");
define("PRFLAN_117", "<u>Isto permitirá que os usuários postem em código HTML em qualquer lugar do site, selecione depois qual classe de usuário terá esta permissão.</u>");
define("PRFLAN_118", "Use Geshi para o destaque de sintaxe");
define("PRFLAN_119", "Geshi é um destacador aberto de sintaxe multi-língua, veja http://qbnz.com/highlighter/ para mais informações");
define("PRFLAN_120", "Padrão Geshi de língua de sintaxe");
define("PRFLAN_121", "se nenhuma língua for especificada no bbtag do código, esta língua será usada destacando");
define("PRFLAN_122", "Habilitar o editor WYSIWYG nas áreas de texto");
define("PRFLAN_123", "<u>O editor indicará o que-você-vê-é-o-que-você-começa nas áreas de texto quando disponível. Aplica-se somente a Admins e a usuários que são permitidos postar em HTML.</u>");
define("PRFLAN_124", "Usar o estilo clássico de paginação");
define("PRFLAN_125", "<u>Ativando esta opção, as páginas de notícia seguinte serão visualizadas com numeração 1, 2 3... 21 22 23, em vez de economizar espaço com um menu dropdown.</u>");
define("PRFLAN_126", "Indicar texto na página de registro");
define("PRFLAN_127", "Faça postagem de links clicáveis");
define("PRFLAN_128", "<u>Ativando esta opção, links postados serão convertidos em hyperlinks</u>");
define("PRFLAN_129", "Desativar múltiplos logins");
define("PRFLAN_130", "<u>Ativando esta opção, será impedido que mais de uma pessoa entre com o mesmo usuário/senha (detalhe do login que compartilha)</u>");
define("PRFLAN_131", "Ativar o uso do bbcode [php]");
define("PRFLAN_132", "<u>Ativando esta opção, será permitido que os usuários autorizados postem o código em tag [php] em determinadas áreas</u>");
define("PRFLAN_133", "A extensão GD é requerida e não foi encontrada");
define("PRFLAN_134", "Redirecione todos os pedidos da URL do site");
define("PRFLAN_135", "<u>Por exemplo, se sua URL do site acima for http://foo.com ajustado, qualquer acesso ao endereço http://www.foo.com será redirecionado novamente a http://foo.com</u>");
define("PRFLAN_136", "Máximo de registros acima permitido no mesmo endereço de IP.");
define("PRFLAN_137", "Mostrar Uso da Memória");
define("PRFLAN_138", "Habilitar a imagem de verificação de segurança(Securit Code) durante a recuperação de senha esquecida.");
define("PRFLAN_139", "Mostrar aviso quando a senha principal do administrador não foi alterada pelo menos em 30 dias");
define("PRFLAN_140", "Mostrar texto depois que o formulário de registro acima foi enviado.");
define("PRFLAN_141", "Usar no registro as preferências dos usuários com XML");
define("PRFLAN_142", "Somente Flood");
define("PRFLAN_143", "Somente Logins Falhos");
define("PRFLAN_144", "Flood & Logins Falhos");
define("PRFLAN_145", "Links em nova janela");
define("PRFLAN_146", "<u>Selecione aqui para fazer com que todos os links abram em nova janela (<i>isto aplicará o sitewide</i>).</u>");
define("PRFLAN_147", "Modo Desenvolvedor");
define("PRFLAN_148", "<u>Ativar as funções de colaborador. isto é para colaboradores somente. Não use para produção de sites por motivos de segurança.</u>");
define("PRFLAN_149", "Funções Avançadas");
define("PRFLAN_150", "Selecione o método de autenticação do e107");
define("PRFLAN_151", "e107 - Não há métodos alternativos de autenticação instalados");
define("PRFLAN_31", "Usar e-mail de verificação para registro?");
define("PRFLAN_152", "Sem Verificação");
define("PRFLAN_153", "Aprovação do Admin");
define("PRFLAN_154", "Novo método de verificação de usuário <br /><u>Se o ítem 'Aprovação do Administrador' estiver selecionado, é recomendado que você ative a notificação por e-mail no registro de usuário <a href='".e_ADMIN."notify.php'>AQUI</a>.</u>");
define("PRFLAN_155", "Nome de exibição disponível para");
define("PRFLAN_156", "Restaurar todos os nomes de exibição");
define("PRFLAN_157", "Todos os nomes mostrados como 'Visualização de Nome' foram trocados pelo Nome de Login");
define("PRFLAN_158", "Tamanho máximo para o nome de exibição");
define("PRFLAN_159", "vendo esta página com");
define("PRFLAN_160", "Marcar servidores remotos quando validar um endereço de e-mail.");
define("PRFLAN_161", "Desabilitar todos os comentários neste site");
define("PRFLAN_162", "Informações de Contato do Site");
define("PRFLAN_163", "<u>ex. Nome da Empresa, Endereço, Telefone, etc.</u>");
define("PRFLAN_164", "Permitir usuários enviarem uma cópia do e-mail de contato para eles mesmos");
define("PRFLAN_165", "<u>Possibilidade de permitir spam, use com precaução</u>");
define("PRFLAN_166", "Mostrar imagens de emoticon no formulário de comentários?");
define("PRFLAN_167", "Fazer a digitação de endereço de e-mail ser opcional");
define("PRFLAN_168", "Contato(s) Pessoal(is) do Site");
define("PRFLAN_169", "<u>Se o grupo escolhido contém mais de uma pessoa, o usuário será questionado para selecionar uma pessoa do grupo.</u>");
define("PRFLAN_170", "Usar DNS reverso para permitir banimento de host");
define("PRFLAN_171", "<u>Ligando esta opção irá permitir banir usuários pelo nome do host, não apenas pelo IP ou pelo endereço de e-mail. <br />NOTA: Isto poderá afetar a leitura das páginas em alguns hosts.</u>");
define("PRFLAN_172", "Tamanho máximo para o Nome de Login (10...100)");
define("PRFLAN_173", "Verifique no SourceForge por atualizações do E107 a cada... (dias)");
define("PRFLAN_174", "Nome para respostas de emails do site");
define("PRFLAN_175", "Isto irá aparecer no campo 'De' do registro e em outros emails enviados pelo site");
define("PRFLAN_176", "Endereço de email para os emails que partirem do site");
define("PRFLAN_177", "Endereço especificado para respostas de emails a partir deste site.");
define("PRFLAN_208", "Classe de usuário que poderá enviar links por email de itens do site");
define("PRFLAN_209", "Outras Funções");
define("PRFLAN_210", "Comentários/Postagens");
define("PRFLAN_215", "Classes que podem postar < script > e tags similares");
define("PRFLAN_216", "(Requer permissões de postagem HTML também)");
define("PRFLAN_217", "Filtrar conteúdo HTML");
define("PRFLAN_218", "Se [desligado], coloca os usuários sob risco de exploits XSS postados por membros de classes acima (v0.7.24)");
define("PRFLAN_220", "Filtro de Abuso HTML (experimental)");
define("PRFLAN_221", "Bloqueia algumas tags que não combinam para aqueles que têm permissão para postar código HTML");
define("PRFLAN_222", "Moderação de Comentários feita por");
define("PRFLAN_223", "Comentários devem ser aprovados manualmente por um administrador antes de se tornarem visíveis a outros usuários");


?>