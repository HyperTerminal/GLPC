<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_e107_update.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Ação");
define("LAN_UPDATE_3", "Não Necessária");
define("LAN_UPDATE_5", "Atualização disponível");
define("LAN_UPDATE_7", "Executado");
define("LAN_UPDATE_8", "Atualizar de");
define("LAN_UPDATE_9", "para");
define("LAN_UPDATE_10", "Atualizações Disponíveis");
define("LAN_UPDATE_11", "0.617 Atualizando para 0.7x...");
define("LAN_UPDATE_12", "Uma de suas tabelas contém informações duplicadas.");


?>