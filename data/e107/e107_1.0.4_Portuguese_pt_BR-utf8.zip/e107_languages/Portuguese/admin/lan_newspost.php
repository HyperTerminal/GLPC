<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_newspost.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NWSLAN_1", "Notícia apagada.");
define("NWSLAN_2", "Clique na caixa para confirmar que quer apagar este item.");
define("NWSLAN_3", "Não há notícias por enquanto.");
define("NWSLAN_4", "Notícias Existentes");
define("NWSLAN_5", "Abrir o Editor HTML");
define("NWSLAN_6", "Categoria");
define("NWSLAN_9", "clique para confirmar");
define("NWSLAN_10", "Não há categorias definidas ainda.");
define("NWSLAN_11", "Adicionar/Editar Categorias");
define("NWSLAN_12", "Título");
define("NWSLAN_13", "Corpo");
define("NWSLAN_14", "Estendido");
define("NWSLAN_15", "Comentários");
define("NWSLAN_18", "Permitir comentários para esta notícia");
define("NWSLAN_19", "Ativação");
define("NWSLAN_21", "Ativar entre");
define("NWSLAN_22", "Visibilidade");
define("NWSLAN_24", "Visualizar novamente");
define("NWSLAN_25", "Atualizar a notícia na base de dados");
define("NWSLAN_26", "Gravar a notícia na base de dados");
define("NWSLAN_27", "Visualizar");
define("NWSLAN_29", "Notícias Enviadas");
define("NWSLAN_31", "Item de notícia");
define("NWSLAN_32", "apagada");
define("NWSLAN_33", "Categoria de Notícias");
define("NWSLAN_34", "Item de notícias submetido");
define("NWSLAN_35", "Categoria de Notícia Salva");
define("NWSLAN_36", "Categoria de Notícia Atualizada");
define("NWSLAN_37", "Tem certeza de apagar esta categoria?");
define("NWSLAN_38", "Tem certeza de apagar este item de notícia submetido?");
define("NWSLAN_39", "Tem certeza de apagar este item de notícia?");
define("NWSLAN_40", "Título");
define("NWSLAN_42", "Sem título");
define("NWSLAN_43", "Sem itens de notícias");
define("NWSLAN_44", "Página Inicial de Notícias");
define("NWSLAN_45", "Criar Item de Notícias");
define("NWSLAN_46", "Categorias");
define("NWSLAN_47", "Notícia Submetida");
define("NWSLAN_48", "Opções de Notícias");
define("NWSLAN_49", "Submetido por");
define("NWSLAN_51", "Categorias de Notícias Existentes");
define("NWSLAN_52", "Nome da Categoria");
define("NWSLAN_53", "Ícone da Categoria");
define("NWSLAN_54", "Ver Imagens");
define("NWSLAN_55", "Atualizar Categoria de Notícias");
define("NWSLAN_56", "Criar Categoria de Notícias");
define("NWSLAN_57", "Item");
define("NWSLAN_58", "Postar");
define("NWSLAN_59", "Sem notícias submetidas");
define("NWSLAN_62", "Ir para página:");
define("NWSLAN_63", "Procurar notícia");
define("NWSLAN_66", "Upload");
define("NWSLAN_67", "Imagem");
define("NWSLAN_68", "Arquivo");
define("NWSLAN_69", "Upload de imagem ou arquivo para uso no item de notícia");
define("NWSLAN_72", "Apenas itens de notícias entre certas datas");
define("NWSLAN_73", "Tipo de execução");
define("NWSLAN_74", "Selecione como e onde o item de notícia é postado");
define("NWSLAN_75", "Padrão - postar na página principal");
define("NWSLAN_76", "Apenas título - postar na página principal");
define("NWSLAN_77", "Postar em outro menu de notícias");
define("NWSLAN_79", "Limpa formulário");
define("NWSLAN_83", "Notícia estendida");
define("NWSLAN_84", "Escolher quais visitantes visualizarão o item de notícias");
define("NWSLAN_86", "Mostrar Menu de Categorias de Rodapé");
define("NWSLAN_87", "Colunas de Categoria de Notícias?");
define("NWSLAN_88", "Postagens mostradas por página?");
define("NWSLAN_89", "Salvar Preferências de Notícias");
define("NWSLAN_90", "Preferências de Notícias");
define("NWSLAN_100", "Habilita upload de imagem na página de envio de notícias");
define("NWSLAN_101", "Redimensionamento automático de imagem enviada");
define("NWSLAN_102", "comprimento em pixels<br> ou deixe em branco para desabilitar.");
define("NWSLAN_103", "Postar Novamente");
define("NWSLAN_104", "por");
define("NWSLAN_105", "Clique nesta caixa para atualizar a data de gravação da notícia a data presente");
define("NWSLAN_106", "Notícias Submetidas talvez acessadas por:");
define("NWSLAN_107", "Habilitar o editor WYSIWYG HtmlArea em Submit-News.");
define("NWSLAN_108", "em");
define("NWSLAN_111", "Mostre o novo encabeçamento da data");
define("NWSLAN_112", "<u>Clicando nesta opção, uma caixa que conta a data será indicada acima dos artigos de notícia postados em novos dias, sendo útil para distinguir postagens feitas em dias diferentes</u>");
define("NWSLAN_113", "Use o molde não padronizado para a disposição da notícia");
define("NWSLAN_114", "<u>Se o tema que você se está usando contiver um molde do layout da notícia, use isto em vez do layout genérico</u>");
define("NWSLAN_115", "Postar notícia para indicar um arquivo?");
define("NWSLAN_116", "<u>Atualize primeiramente as preferências com a exibição mudada para a exibição da página, depois atualize então outra vez a preferência arquivo-notícia. <b>(0 (zero) são desativados)</b></u>");
define("NWSLAN_117", "Ajuste o título para o arquivo-notícia");
define("NWSLAN_119", "Configurações Salvas");
define("NWSLAN_120", "Texto para ser mostrado no topo de notícias submetidas");
define("LAN_NEWS_5", "Erro! - Impossível atualizar a notícia na base de dados!");
define("LAN_NEWS_6", "Notícia inserida na base de dados.");
define("LAN_NEWS_7", "Erro! - Impossível inserir a notícia na base de dados!");
define("LAN_NEWS_9", "Somente o título é ajustado - <b>somente o título da notícia será mostrado</b>");
define("LAN_NEWS_10", "Esta postagem da notícia está <b>inativa</b> (Não se mostrará na página inicial).");
define("LAN_NEWS_11", "Esta postagem da notícia está <b>ativa</b> (será mostrada na página inicial).");
define("LAN_NEWS_12", "Comentários para esta notícia <b>on</b>.");
define("LAN_NEWS_13", "Comentários para esta notícia <b>off</b>.");
define("LAN_NEWS_14", "<br />Período de ativação:");
define("LAN_NEWS_15", "Comprimento do corpo:");
define("LAN_NEWS_16", "b. Comprimento prolongado:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Informação");
define("LAN_NEWS_19", "Agora");
define("LAN_NEWS_21", "Notícia atualizada no banco de dados.");
define("LAN_NEWS_22", "Thumbnail");
define("LAN_NEWS_23", "Escolha a imagem de thumbnail / ícone para o item de notícia");
define("LAN_NEWS_24", "Imagem + Auto-Thumbnail");
define("LAN_NEWS_25", "Tamanho do Auto-Thumbnail");
define("LAN_NEWS_26", "adicionar novo upload");
define("LAN_NEWS_27", "Sumário");
define("LAN_NEWS_28", "Fixar");
define("LAN_NEWS_29", "Selecione se o artigo de notícia será fixado");
define("LAN_NEWS_30", "Se selecionado, o artigo de notícia aparecerá sobre todo os outros");
define("LAN_NEWS_31", "Esta postagem da notícia está <b>fixada</b> (será mostrada sobre todos os outros itens)");
define("LAN_NEWS_32", "Gravar data");
define("LAN_NEWS_33", "Ajuste a gravação de data para o artigo da notícia atual.");
define("LAN_NEWS_34", "TrackBack");
define("LAN_NEWS_35", "Adicionar url's de trackback");
define("LAN_NEWS_36", "<b>Pingback</b> (emita um pingback a todos as URL's nesta postagem)");
define("LAN_NEWS_37", "<b>Url do Trackback:</b> (Uma url por linha)");
define("LAN_NEWS_38", "Inserir imagens");
define("LAN_NEWS_39", "clique no arquivo para inserir a posição do cursor");
define("LAN_NEWS_40", "Inserir links de downloads");
define("LAN_NEWS_42", "Arquivos");
define("LAN_NEWS_44", "Trackback não habilitado");
define("LAN_NEWS_45", "ID");
define("LAN_NEWS_46", "A notícia não foi atualizada e nenhuma mudança foi feita.");
define("LAN_NEWS_48", "Sem imagem");
define("LAN_NEWS_49", "Tipo de renderização");
define("LAN_NEWS_50", "Manutenção");
define("LAN_NEWS_51", "Recalcular contador de comentários");
define("LAN_NEWS_52", "Prosseguir");
define("LAN_NEWS_53", "Atualização completa");
define("LAN_NEWS_54", "Manutenção de Notícias");
define("LAN_NEWS_55", "Autor (Postado por)");
define("LAN_NEWS_56", "Postado");
define("LAN_NEWS_61", "Apagar também os comentários não permitidos");
define("LAN_NEWS_62", "Erro ao acessar o Banco de Dados, ou os itens de notícias não foram encontrados");


?>