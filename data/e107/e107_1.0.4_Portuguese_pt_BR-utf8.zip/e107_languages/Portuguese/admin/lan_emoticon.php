<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_emoticon.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("EMOLAN_1", "Ativação dos Emoticons");
define("EMOLAN_2", "Nome");
define("EMOLAN_3", "Emoticons");
define("EMOLAN_4", "Ativar emoticons?");
define("EMOLAN_5", "Imagem");
define("EMOLAN_6", "Código do Emoticon");
define("EMOLAN_7", "Entradas múltiplas seperadas com espaços");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Opções");
define("EMOLAN_10", "Ativado");
define("EMOLAN_11", "Ativar o pacote");
define("EMOLAN_12", "Editar / Configurar este pacote");
define("EMOLAN_13", "Pacotes instalados");
define("EMOLAN_14", "Salvar configurações");
define("EMOLAN_15", "Editar / Configurar emotes");
define("EMOLAN_16", "Configurações de emote salvas");
define("EMOLAN_17", "Você tem um pacote de emoticon que contém espaços, o que não é permitido!");
define("EMOLAN_18", "favor renomear as instâncias abaixo para que não contenham mais espaços nos nomes:");
define("EMOLAN_19", "Nome");
define("EMOLAN_20", "Localização");
define("EMOLAN_21", "Erro");
define("EMOLAN_22", "Novo pacote de emoticons encontrado:");
define("EMOLAN_23", "Novo pacote de emoticons xml encontrado:");
define("EMOLAN_24", "Novo emoticon php encontrado:");
define("EMOLAN_25", "Instalando novos emoticons:");
define("EMOLAN_26", "Escanear o pacote novamente");
define("EMOLAN_27", "Ocorreu um erro ao processar o pacote:");
define("EMOLAN_28", "Gerar XML");
define("EMOLAN_29", "Arquivo XML gerado:");
define("EMOLAN_30", "Erro ao escrever arquivo XML:");


?>