<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_lancheck.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Selecione linguagem para verificar");
define("LAN_CHECK_2", "Iniciar Verificação");
define("LAN_CHECK_3", "Verificação de");
define("LAN_CHECK_4", "Faltando arquivo!");
define("LAN_CHECK_5", "Faltando linha!");
define("LAN_CHECK_7", "linha");
define("LAN_CHECK_8", "Falta um arquivo...");
define("LAN_CHECK_9", "arquivos estão faltando...");
define("LAN_CHECK_10", "Erro crítico:");
define("LAN_CHECK_11", "Não falta nenhum arquivo!");
define("LAN_CHECK_12", "O arquivo está errado...");
define("LAN_CHECK_13", "arquivos estão errados..");
define("LAN_CHECK_14", "Todos os arquivos existentes são válidos!");
define("LAN_CHECK_15", "Caracteres não permitidos encontrados antes de '<?php'");
define("LAN_CHECK_16", "Arquivo original");
define("LAN_CHECK_17", "Um problema de escrita ocorreu enquanto tentava salvar o arquivo.");
define("LAN_CHECK_18", "Arquivos de idioma no formato padrão NÃO estão disponíveis para este plugin/tema.");
define("LAN_CHECK_19", "Caracteres não-UTF-8 encontrados!");
define("LAN_CHECK_20", "Gerar Pacote de Idioma (Language Pack)");
define("LAN_CHECK_21", "Verificar Novamente");
define("LAN_CHECK_22", "Tema");
define("LAN_CHECK_23", "Erros Encontrados");
define("LAN_CHECK_24", "Resumo");
define("LAN_CHECK_25", "Temas");
define("LAN_CHECK_26", "Arquivo");


?>