<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_credits.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Créditos do e107");
define("CRELAN_1", "Créditos");
define("CRELAN_2", "Aqui está uma lista dos softwares e recursos usados no e107. A equipe de desenvolvimento do e107 gostaria de agradecer pessoalmente os colaboradores dos seguintes recursos que permitiram a utilização e a possibilidade de nós redistribuí­mos seu código com o e107, possibilitando o uso do software sob a licença GPL.");
define("CRELAN_3", "todos os direitos reservados");
define("CRELAN_4", "Mostrar a equipe de desenvolvimento do e107");
define("CRELAN_5", "Mostrar os scripts de terceiros");
define("CRELAN_6", "e107 v0.7x é trazido a você por...");
define("CRELAN_7", "Versão");
define("CRELAN_8", "permissão garantida");
define("CRELAN_9", "Licença");
define("CRELAN_10", "MagpieRSS fornece um interpretador RSS em php baseado em XML.");
define("CRELAN_11", "Biblioteca PclZip oferece funções de compressão e extração para o formato de arquivos Zip (WinZip, PKZip).");
define("CRELAN_12", "PclTar oferece a habilidade de arquivar uma lista de arquivos ou diretórios com ou sem compressão. Os arquivos criados pelo PclTar são lidos pela maioria dos aplicativos gzip/tar e pelos aplicativos Windows do tipo WinZip.");
define("CRELAN_13", "TinyMCE é uma plataforma web independente baseada em Javascript. É um editor HTML do tipo WYSIWYG distribuído como Código Aberto sob licença LGPL por Moxiecode Systems AB. Ele tem a função de converter áreas de texto HTML, campos ou outros elementos em códigos HTML.");
define("CRELAN_14", "Ícones usados no e107");
define("CRELAN_15", "Funções completas de envio de e-mail por PHP");
define("CRELAN_16", "Sistema de menus usado no tema Jayya");
define("CRELAN_17", "Engenharia do calendário popup");
define("CRELAN_18", "Suporte PDF");
define("CRELAN_19", "Suporte PDF UTF-8");
define("CRELAN_20", "");
define("CRELAN_21", "Sempre uma pressão... quer dizer... um prazer!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />ahhh! não batem!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Quê? Sem café? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Para o alto e avante!");
define("CRELAN_30", "");


?>