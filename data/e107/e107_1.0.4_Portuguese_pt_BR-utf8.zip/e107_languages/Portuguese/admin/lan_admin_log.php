<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_admin_log.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Log de Administrador");
define("LAN_ADMINLOG_1", "Data");
define("LAN_ADMINLOG_2", "Título");
define("LAN_ADMINLOG_3", "Descrição");
define("LAN_ADMINLOG_4", "IP do Usuário");
define("LAN_ADMINLOG_5", "ID do Usuário");
define("LAN_ADMINLOG_6", "Ícone Informativo");
define("LAN_ADMINLOG_7", "Mensagem Informativa");
define("LAN_ADMINLOG_8", "Ícone de Notificação");
define("LAN_ADMINLOG_9", "Mensagem de Notificação");
define("LAN_ADMINLOG_10", "Ícone de Aviso");
define("LAN_ADMINLOG_11", "Mensagem de Aviso");
define("LAN_ADMINLOG_12", "Ícone de erro fatal");
define("LAN_ADMINLOG_13", "Mensagem de erro fatal");


?>