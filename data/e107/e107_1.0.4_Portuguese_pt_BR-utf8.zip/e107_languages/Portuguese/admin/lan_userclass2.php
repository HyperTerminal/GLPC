<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_userclass2.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UCSLAN_1", "Limpar todos os usuários desta classe.");
define("UCSLAN_2", "Classe de usuários atualizada.");
define("UCSLAN_3", "Classe apagada.");
define("UCSLAN_4", "Clique na caixa para confirmar apagar esta classe de usuários");
define("UCSLAN_5", "Classe atualizada.");
define("UCSLAN_6", "Classe gravada na base de dados.");
define("UCSLAN_7", "Não há classes de usuários no momento.");
define("UCSLAN_8", "Classes Existentes");
define("UCSLAN_11", "clique para confirmar");
define("UCSLAN_12", "Nome da Classe");
define("UCSLAN_13", "Descrição da Classe");
define("UCSLAN_14", "Atualizar Classe de Usuário");
define("UCSLAN_15", "Criar Nova Classe");
define("UCSLAN_16", "Atribuir usuários à classe");
define("UCSLAN_17", "Remover");
define("UCSLAN_18", "Limpar Classe");
define("UCSLAN_19", "Atribuir usuários a");
define("UCSLAN_20", "classe");
define("UCSLAN_21", "Configuração da Classe de Usuário");
define("UCSLAN_22", "Usuários - clique para mover...");
define("UCSLAN_23", "Usuários nesta classe...");
define("UCSLAN_24", "Quem pode controlar a classe");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Nome de Usuário");
define("UCSLAN_27", "Retornar");


?>