<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_banlist.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("BANLAN_1", "Banido removido.");
define("BANLAN_2", "Sem banidos.");
define("BANLAN_3", "Banidos Existentes");
define("BANLAN_4", "Remover o banido");
define("BANLAN_5", "Banir pelo IP, endereço de e-mail ou host");
define("BANLAN_7", "Motivo");
define("BANLAN_8", "Banir Usuário");
define("BANLAN_9", "Banir usuários do site");
define("BANLAN_10", "IP / E-Mail / Motivo");
define("BANLAN_11", "Auto-Ban: Para 10 ou mais tentativas de login falhas");
define("BANLAN_12", "Nota: DNS reverso está desativado atualmente, precisa estar ativado para permitir banimento por host/servidor. A função de banir por IP e e-mail irá continuar funcionando normalmente.");
define("BANLAN_13", "Nota: Para proibir um usuário pelo nome do usuário, ir à página de administração dos usuários:");
define("BANLAN_78", "Excedeu o número de hits permitidos (--HITS-- solicitados acima do permitido)");


?>