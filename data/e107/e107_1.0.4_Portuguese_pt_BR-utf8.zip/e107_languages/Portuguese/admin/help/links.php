<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Digite todos os links de seu site aqui. Para links do menu principal (os que são mostrados na barra de navegação) configure para a categoria 'Main' (principal), qualquer outro link será mostrado na página de Links. Você pode separar estes links em categorias diferentes.
<br />
<br />
O gerador de submenus é APENAS útil para os menus do e107 em DHTML (TreeMenu, UltraTreeMenu, eDynamicMenu, ypSlideMenu...)";
$ns -> tablerender("Links", $text);
?>
