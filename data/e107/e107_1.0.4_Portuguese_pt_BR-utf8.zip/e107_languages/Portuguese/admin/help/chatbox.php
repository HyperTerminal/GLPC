<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Configure as preferências da janela de Chat aqui.<br />Se a opção de substituir links estiver marcada, qualquer link digitado será trocado pelo texto que você digitou nesta área, isto evitará longos links que causam problemas de visualização nas tabelas.  O número de letras para corte irá automaticamente quebrar palavras mais compridas que o especificado aqui.";

$ns -> tablerender("Área de Chat", $text);
?>
