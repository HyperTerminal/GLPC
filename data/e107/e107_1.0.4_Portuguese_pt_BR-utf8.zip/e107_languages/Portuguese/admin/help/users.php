<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Esta página permite a você moderar seus membros registrados.  Você pode atualizar as configurações deles, dar a eles status de administrador e configurar as classes para um monte de outras coisas.";
$ns -> tablerender("Usuários", $text);
unset($text);
?>
