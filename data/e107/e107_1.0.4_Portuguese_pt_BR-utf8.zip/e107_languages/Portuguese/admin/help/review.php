<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Revisões são similares a artigos mas eles podem ser listados em seu próprio item de menu.<br />
 Para uma revisão em múltiplas páginas, separe cada página por [newpage], ex. <br /><code>Teste1 [newpage] Teste2</code><br /> irá criar duas páginas de revisão com o texto 'Teste1' na página 1 e 'Teste2' na página 2.";
$ns -> tablerender("Revisões", $text);
?>
