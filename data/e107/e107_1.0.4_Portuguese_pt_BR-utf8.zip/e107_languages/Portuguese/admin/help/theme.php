<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "O gerenciador de temas permite a você configurar o tema público do seu site e o tema da área de admin.";
$ns -> tablerender("Gerenciador de Tema - Ajuda", $text);
?>

