<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$caption = "Fazendo Cache";
$text = "Se você ligou a opção de fazer cache, isto irá aumentar a velocidade do seu site e minimizar a quantidade de chamadas ao banco de dados mysql.<br /><br /><b>IMPORTANTE! Se você estiver fazendo seu próprio tema, desligue o cache para fazer as mudanças que você necessitar, senão elas não funcionarão.</b>";
$ns -> tablerender($caption, $text);
?>
