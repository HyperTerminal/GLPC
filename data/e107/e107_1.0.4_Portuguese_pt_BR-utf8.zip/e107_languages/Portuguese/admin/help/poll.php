<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Você configura pesquisas nesta página, apenas digite um título e as opções, dê uma visualização prévia e se tudo estiver correto, marque a caixa para ativar a pesquisa.<br /><br />
Para ver a pesquisa, vá na página de menus e veja se o poll_menu está ativado.";

$ns -> tablerender("Pesquisas", $text);
?>
