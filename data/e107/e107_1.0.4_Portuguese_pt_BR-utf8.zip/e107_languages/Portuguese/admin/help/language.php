<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Configurando um novo idioma irá permitir a você ter uma versão do seu conteúdo naquele idioma no seu site..";
$ns -> tablerender("Idioma - Ajuda", $text);
?>

