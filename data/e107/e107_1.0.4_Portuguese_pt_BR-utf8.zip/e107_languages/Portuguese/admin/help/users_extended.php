<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = " Os campos estendidos de usuários permitem a você adicionar tipos de dados que os usuários irão digitar em seu perfil.";
$ns -> tablerender("Campos Estendidos de Usuário - Ajuda", $text);
?>

