<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$caption = "Classe de Usuários";
$text = "Você pode criar ou editar/deletar classes de usuários nesta página.<br />Isto é útil para restringir o acesso de usuários a certas partes do seu site. Por exemplo, você poderá criar uma classe chamada TESTE, então criar um fórum onde apenas usuários que estiverem na classe TESTE poderão acessá-lo.";
$ns -> tablerender($caption, $text);
?>
