<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Se a versão do MySql do seu server suporta isto, você deve alterar para o método de busca no MySql, que é mais rápido que a busca pelo método PHP e inclui a função de busca por operações booleanas (e, ou).<br /><br />
<b>Caracteres</b> Este é o número de caracteres por texto que será mostrado no resultado da busca.<br /><br />
<b>Resultados</b> Este é o número de resultados que será mostrado por página.";
$ns -> tablerender("Ajuda da Busca", $text);
?>

