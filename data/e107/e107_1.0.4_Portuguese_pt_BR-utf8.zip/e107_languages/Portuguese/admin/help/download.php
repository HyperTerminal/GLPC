<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Favor enviar (upload) seus arquivos para a pasta ".e_FILE."downloads, imagens na pasta ".e_FILE."downloadimages e as imagens de thumbnail (amostras de imagens) na pasta ".e_FILE."downloadthumbs.
<br /><br />
Para enviar um download, primeiro crie uma categoria pai, depois crie uma categoria abaixo da primeira criada, depois disso, você poderá disponibilizar o download.";
$ns -> tablerender("Ajuda em Downloads", $text);
?>
