<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Use esta página para configurar as opções de e-mail do site - funções de envio de e-mail.  O formulário de e-mail de saída permite enviar mensagens a todos os usuários.";
$ns -> tablerender("E-mail - Ajuda", $text);
?>

