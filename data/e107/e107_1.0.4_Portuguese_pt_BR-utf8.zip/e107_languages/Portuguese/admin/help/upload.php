<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Aqui você pode permitir ou não os usuários a fazerem upload de arquivos e gerenciarem esses arquivos que eles tiverem enviado por upload.";
$ns -> tablerender("Uploads Públicos - Ajuda", $text);
?>

