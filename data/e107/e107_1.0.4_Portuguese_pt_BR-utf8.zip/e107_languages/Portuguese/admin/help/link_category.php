<?php
////////////////////////////////////////////////////////////////////
// ARQUIVOS DE TRADUÇÃO DA AJUDA DO E107                          //
// Tradução Português(Brasil) -> Comunidade e107Brasil.NET        //
//             (http://www.e107brasil.net), 2007-2009             //
////////////////////////////////////////////////////////////////////

if (!defined('e107_INIT')) { exit; }

$text = "Você pode separar seus links em diferentes categorias, isto fará com que a navegação na página de Links fique mais fácil e com layout melhorado.<br /><br />Qualquer link digitado na categoria principal (Main) será mostrado no seu menu de navegação.";
$ns -> tablerender("Categoria de links", $text);
?>
