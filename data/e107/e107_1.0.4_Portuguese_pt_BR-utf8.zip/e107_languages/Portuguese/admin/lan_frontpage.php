<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_frontpage.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FRTLAN_1", "Preferências da página inicial atualizadas.");
define("FRTLAN_2", "Página principal ajustada para");
define("FRTLAN_6", "Links");
define("FRTLAN_12", "Atualizar preferências da página inicial");
define("FRTLAN_13", "Preferências da Página Inicial");
define("FRTLAN_15", "Outra (insira a url):");
define("FRTLAN_16", "erro: nenhum índice de pai principal selecionado");
define("FRTLAN_17", "erro: nenhum índice de categoria secundária selecionada");
define("FRTLAN_18", "erro: nenhum índice de conteúdo selecionado");
define("FRTLAN_19", "conteúdo pai principal");
define("FRTLAN_20", "categoria do conteúdo");
define("FRTLAN_21", "ítem do conteúdo");
define("FRTLAN_22", "Página Customizada");
define("FRTLAN_26", "todos usuários");
define("FRTLAN_27", "Anônimos");
define("FRTLAN_28", "Membros");
define("FRTLAN_29", "Administradores");
define("FRTLAN_31", "Todos Usuários");
define("FRTLAN_32", "Classe de Usuário");
define("FRTLAN_33", "Preferências Atuais");
define("FRTLAN_34", "Página");


?>