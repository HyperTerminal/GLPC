<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_meta.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags atualizadas na base de dados");
define("METLAN_2", "Entrar com meta-tags adicionais");
define("METLAN_3", "Entrar nova definição de meta tag");
define("METLAN_4", "Atualizado");
define("METLAN_5", "digite sua descrição aqui");
define("METLAN_6", "digite, uma, lista, de, suas, palavras-chave, aqui");
define("METLAN_7", "digite sua informação de copyright aqui");
define("METLAN_8", "Meta Tags");
define("METLAN_9", "Descrição");
define("METLAN_10", "Palavras-chave");
define("METLAN_11", "Copyright");
define("METLAN_12", "Usar título da notícia e sumário como meta-descrições nas páginas de notícias.");
define("METLAN_13", "Autor");


?>