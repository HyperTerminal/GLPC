<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/admin/lan_language.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANG_LAN_00", "não podia ser criado.(já existe)");
define("LANG_LAN_01", "era deletado(se existisse) e criado.");
define("LANG_LAN_02", "não pode ser deletado");
define("LANG_LAN_03", "Tabelas");
define("LANG_LAN_05", "Não Instalado");
define("LANG_LAN_06", "Criar tabelas");
define("LANG_LAN_07", "Apagar as tabelas existentes?");
define("LANG_LAN_08", "Substitua tabelas existentes (os dados serão perdidos).");
define("LANG_LAN_10", "Confirmar deleção");
define("LANG_LAN_11", "Deletar sem verificar nas tabelas acima (se elas existem).");
define("LANG_LAN_12", "Habilitar Tabelas de Multi-Linguagens");
define("LANG_LAN_13", "Preferências de Multi-Linguagem");
define("LANG_LAN_14", "Linguagem Padrão do Site");
define("LANG_LAN_15", "Selecione para copiar dados da linguagem padrão.(útil para os links, notícia-categorias etc...)");
define("LANG_LAN_16", "Uso de Banco de Dados Multi-idioma/Multilíngüe");
define("LANG_LAN_17", "Idioma Padrão - Nenhuma tabela adicional requerida.");
define("LANG_LAN_18", "Usar subdomínios para configurar novos Idiomas:");
define("LANG_LAN_19", "exemplo: fr.seudominio.com.br para configurar o idioma para o Francês.");
define("LANG_LAN_20", "Digite o nome do domínio principal para ativar. Ex.: seudominio.com.br");
define("LANG_LAN_21", "Ferramentas de Idioma");
define("LANG_LAN_23", "Criar um Pacote de Idioma/Language-Pack (zip)");
define("LANG_LAN_24", "Gerar");
define("LANG_LAN_AGR", "Nota: Usando essas ferramentas, você aceita compartilhar seu pacote de idioma(s) com a comunidade e107.");
define("LANG_LAN_EML", "Favor enviar seu pacote de idiomas para:");
define("LANG_LAN_25", "Favor verificar se CORE_LC e CORE_LC2 têm valores em [lcpath] e tente novamente.");
define("LANG_LAN_26", "Favor ter certeza de que está usando o nome padrão nas pastas no arquivo e107_config.php (ex. 'e107_languages/', 'e107_plugins/' etc.) e tente novamente.");
define("LANG_LAN_27", "Favor verificar seus arquivos de idioma ('Verificar') e tente novamente.");
define("LANG_LAN_28", "Marque esta caixa se você é um [e107 certified translator].");
define("LANG_LAN_29", "Você deverá corrigir os erros remanescentes antes de contribuir com seu pacote de idioma.");
define("LANG_LAN_30", "Data de lançamento");
define("LANG_LAN_31", "Compatibilidade");
define("LANG_LAN_32", "Idiomas Instalados");
define("LANG_LAN_33", "Mostrar apenas erros durante a verificação");
define("LANG_LAN_34", "Favor verificar e corrigir os erros remanescentes [X] antes de tentar criar um pacote de idiomas.");


?>