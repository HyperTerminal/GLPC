<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
setlocale(LC_ALL,'portuguese');
define("CORE_LC", "pt");
define("CORE_LC2", "br");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Erro: Faltando arquivos do tema. <b>Mude o tema usado em suas preferências (Área de administração) ou faça upload dos arquivos do tema atual.</b>");
define("CORE_LAN4", "Por favor, apague o arquivo install.php do seu servidor");
define("CORE_LAN5", "pois ele pode ser potencialmente perigoso para seu website");
define("CORE_LAN6", "A proteção de flood foi ativada neste site e você está sendo avisado que poderá ser banido caso continue a solicitar páginas com muita frequência.");
define("CORE_LAN7", "O sistema está tentando restaurar as preferências de um backup automático.");
define("CORE_LAN8", "Erro nas Preferências do Sistema");
define("CORE_LAN9", "Execução falhou. O sistema não pode se restaurar de um backup automático.");
define("CORE_LAN10", "Cookie corrompido detectado - faça login novamente.");
define("CORE_LAN11", "Tempo de renderização: ");
define("CORE_LAN12", " segundos, ");
define("CORE_LAN13", " para conteúdos. ");
define("CORE_LAN14", "");
define("CORE_LAN15", "Conteúdos no BD: ");
define("CORE_LAN16", "Uso de Memória: ");
define("CORE_LAN17", "[ imagem desativada ]");
define("CORE_LAN18", "Imagem: ");
define("CORE_LAN_B", "b");
define("CORE_LAN_KB", "kb");
define("CORE_LAN_MB", "Mb");
define("CORE_LAN_GB", "Gb");
define("CORE_LAN_TB", "Tb");
define("LAN_WARNING", "Atenção!");
define("LAN_ERROR", "Erro");
define("LAN_ANONYMOUS", "Anônimo");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_SANITISED", "SANITIZADO");


?>