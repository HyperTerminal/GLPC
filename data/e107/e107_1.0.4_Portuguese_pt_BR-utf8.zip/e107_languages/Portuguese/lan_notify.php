<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_notify.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Registro de usuários");
define("NT_LAN_UV_1", "Registro de usuários verificados");
define("NT_LAN_UV_2", "ID de Usuário:");
define("NT_LAN_UV_3", "Nome de login do usuário:");
define("NT_LAN_UV_4", "IP do usuário:");
define("NT_LAN_LI_1", "Usuários logados no site");
define("NT_LAN_LO_1", "Usuários deslogados do site");
define("NT_LAN_LO_2", "deslogado do site");
define("NT_LAN_FL_1", "Banimento por Flood");
define("NT_LAN_FL_2", "Endereço de IP banido por Flood");
define("NT_LAN_SN_1", "Item de notícia submetido");
define("NT_LAN_NU_1", "Atualizado");
define("NT_LAN_ND_1", "Item de notícia apagado");
define("NT_LAN_ND_2", "ID da notícia apagada");
define("NT_LAN_CM_1", "Aprovação pendente de comentário de Usuário");


?>