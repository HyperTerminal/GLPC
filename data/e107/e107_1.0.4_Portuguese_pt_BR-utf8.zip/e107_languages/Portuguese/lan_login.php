<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_login.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_27", "Campo(s) obrigatório(s) deixado(s) em branco");
define("LAN_300", "Esse nome de usuário não foi encontrado na base de dados. Verifique se o botão CAPS LOCK não está ativado pois os logins são sensíveis a letras maiúsculas/minúsculas");
define("LAN_302", "Você não ativou sua conta. Um e-mail deve ter sido enviado com instruções de como confirmá-la. Se isso não ocorreu, contate o administrador do site ou clique <a href='".e_BASE."signup.php?resend'>AQUI</a>.");
define("LAN_303", "Código informado incorreto.");
define("LAN_304", "Esta combinação de username/senha já está sendo usada.");
define("LAN_LOGIN_1", "Nome do Usuário");
define("LAN_LOGIN_2", "Senha do Usuário");
define("LAN_LOGIN_3", "Servidor protegido");
define("LAN_LOGIN_4", "Favor informar seus detalhes a fim de liberar seu acesso.");
define("LAN_LOGIN_5", "Clique aqui para registrar-se");
define("LAN_LOGIN_6", "Não aceitando novos membros no momento");
define("LAN_LOGIN_7", "Insira o código visível");
define("LAN_LOGIN_8", "Lembrar de Mim");
define("LAN_LOGIN_9", "Login");
define("LAN_LOGIN_10", "Clique para login");
define("LAN_LOGIN_11", "Registrar um Novo Usuário");
define("LAN_LOGIN_12", "Recuperar Senha");
define("LAN_LOGIN_13", "Por favor entre com o texto da imagem");
define("LAN_LOGIN_14", "O usuário tentou logar com login incorreto, ou login não reconhecido");
define("LAN_LOGIN_15", "Usuário tentando logar com senha incorreta");
define("LAN_LOGIN_16", "Esta combinação de username/password já está sendo utilizada");
define("LAN_LOGIN_17", "Senha de usuário (Criptografada)");
define("LAN_LOGIN_18", "Auto-Banimento: Mais de 10 tentativas falhas de login");
define("LAN_LOGIN_19", "Mais de 10 tentativas falhas de login");


?>