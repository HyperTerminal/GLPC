<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_ren_help.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANHELP_1", "Preto");
define("LANHELP_2", "Azul");
define("LANHELP_3", "Marrom");
define("LANHELP_4", "Ciano");
define("LANHELP_5", "Azul Escuro");
define("LANHELP_6", "Vermelho Escuro");
define("LANHELP_7", "Verde");
define("LANHELP_8", "Índigo");
define("LANHELP_9", "Verde Oliva");
define("LANHELP_10", "Alaranjado");
define("LANHELP_11", "Vermelho");
define("LANHELP_12", "Violeta");
define("LANHELP_13", "Branco");
define("LANHELP_14", "Amarelo");
define("LANHELP_15", "Muito pequeno");
define("LANHELP_16", "Pequeno");
define("LANHELP_17", "Normal");
define("LANHELP_18", "Grande");
define("LANHELP_19", "Maior");
define("LANHELP_20", "Gigante");
define("LANHELP_21", "Cor...");
define("LANHELP_22", "Tamanho...");
define("LANHELP_23", "Insere link: [link]http://meusite.com.br[/link] ou  [link=http://seusite.com.br]Visite meu Site[/link]");
define("LANHELP_24", "Texto negrito: [b]Este texto ficará em negrito[/b]", "font-weight:bold; width: 20px");
define("LANHELP_25", "Texto itálico: [i]Este texto ficará em itálico[/i]", "font-style:italic; width: 20px");
define("LANHELP_26", "Texto sublinhado: [u]Este texto ficará sublinhado[/u]", "text-decoration: underline; width: 20px");
define("LANHELP_27", "Insere imagem: [img]minhafigura.jpg[/img]");
define("LANHELP_28", "Centraliza: [center]Esse texto ficará centralizado[/center]");
define("LANHELP_29", "Alinhamento esquerdo: [left]Esse texto ficará alinhado pela esquerda[/left]");
define("LANHELP_30", "Alinhamento direito: [right]Esse texto ficará alinhado pela direita[/right]");
define("LANHELP_31", "Texto indentado: [blockquote]Esse texto ficará alinhado indentado[/blockquote]");
define("LANHELP_32", "Código - texto preformatado: [code]$foo = bah;[/code]");
define("LANHELP_33", "HTML - remove quebras de linha do texto: [html]<table><tr><td> etc.[/html]");
define("LANHELP_34", "[newpage] ou [newpage=título]Insere código de nova página, separando o artigo em páginas distintas");
define("LANHELP_35", "URL de hyperlink");
define("LANHELP_36", "Sem ordem de numeração: [list]linha1*linha2*linha3[/list] Ordenado por numeração: [list=type]linha1*linha2*linha3[/list]");
define("LANHELP_37", "Insira a imagem no diretório e107_images/newspost_images/");
define("LANHELP_38", "link para imagem em tamanho cheio será gerada");
define("LANHELP_39", "Insira o link de download a partir dos downloads existentes no site");
define("LANHELP_40", "Não há nenhum download existente atualmente");
define("LANHELP_41", "Tamanho da fonte...");
define("LANHELP_42", "Selecione a imagem...");
define("LANHELP_43", "Selecione o arquivo para download...");
define("LANHELP_44", "Clique para abrir/fechar o diálogo dos emoticons...");
define("LANHELP_45", "Inserir imagem do diretório:");
define("LANHELP_46", "* Arquivos não encontrados em:");
define("LANHELP_47", "Inserir flash: [flash=width,height]http://www.exemplo.com.br/arquivo.swf[/flash]");
define("LANHELP_48", "Vídeo do YouTube: [youtube=tiny|small|medium|big|huge|width,height]6kYjxJmk0wc[/youtube]	");
define("LANHELP_49", "Alinhamento Justificado: [justify]Este texto será justificado[/justify]");


?>