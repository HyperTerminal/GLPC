<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_languages/Portuguese_Brazilian/lan_userposts.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Mensagens de Usuários");
define("UP_LAN_0", "Todas Postagens de Fórum por ");
define("UP_LAN_1", "Todos Comentários por ");
define("UP_LAN_2", "Assunto");
define("UP_LAN_3", "Visualizações");
define("UP_LAN_4", "Respostas");
define("UP_LAN_5", "Última Postagem");
define("UP_LAN_6", "Assuntos");
define("UP_LAN_7", "Sem Comentários");
define("UP_LAN_8", "Sem Postagens");
define("UP_LAN_9", " enviado em ");
define("UP_LAN_10", "De");
define("UP_LAN_11", "Postado em:");
define("UP_LAN_12", "Procura");
define("UP_LAN_13", "Comentários");
define("UP_LAN_14", "Postagens do Fórum");
define("UP_LAN_15", "De");
define("UP_LAN_16", "Endereço IP");


?>