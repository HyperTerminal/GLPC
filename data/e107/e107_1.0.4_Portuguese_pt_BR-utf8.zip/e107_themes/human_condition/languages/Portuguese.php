<?php
/*
+---------------------------------------------------------------+
|        e107 website system
|        ../../e107_themes/human_condition/languages/Portuguese_Brazilian.php
|        (Portuguese_Brazilian language file)
|
|        Tradução Português(Brasil) -> Comunidade e107Brasil.NET
|        (http://www.e107brasil.net), 2007-2009
|
|        ©Steve Dunstan 2001-2002
|        http://e107.org
|        jalist@e107.org
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "Human Condition desenvolvido por <a href='http://e107.org' rel='external'>jalist</a>, baseado no thema do Wordpress, <a href='http://wordpress.org'>http://wordpress.org</a>. ");
define("LAN_THEME_2", "Os comentários estão desativados para este item");
define("LAN_THEME_3", "Comentário(s):");
define("LAN_THEME_4", ">>Leia Mais!<<");
define("LAN_THEME_5", "TrackBacks:");
define("LAN_THEME_6", "Comentado por");


?>