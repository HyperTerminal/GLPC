<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Portuguese Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/core/languages/Portuguese.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/21 09:48:48 $
|        $Author: barbaratostes $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "e107 core tema feito por <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>");
define("LAN_THEME_2", "Comentários:");
define("LAN_THEME_3", "Comentários desligados para este item");
define("LAN_THEME_4", "Leia a matéria completa");
define("LAN_THEME_5", "Trackbacks:");
define("LAN_THEME_8", "em");
define("LAN_THEME_9", "por");
define("LAN_THEME_11", "Últimas Notícias");
define("LAN_THEME_12", "E-mail para um amigo");
define("LAN_THEME_13", "Criar arquivo PDF");
define("LAN_THEME_14", "Imprimir");
define("LAN_THEME_15", "Editar");
define("LAN_THEME_17", "Login");
define("LAN_THEME_18", "Usuário");
define("LAN_THEME_19", "Senha");
define("LAN_THEME_20", "Registrar");
define("LAN_THEME_21", "Login");
define("LAN_THEME_22", "Esqueceu a Senha?");
define("LAN_THEME_23", "Bem-vindo");
define("LAN_THEME_24", "Admin");
define("LAN_THEME_26", "Configurações");
define("LAN_THEME_27", "Perfil");
define("LAN_THEME_28", "Logout");
define("LAN_THEME_29", "Listar novo");
define("LAN_THEME_SING", "Login");
define("LAN_THEME_REG", "Registrar");
define("LAN_SEARCH", "Procurar");
define("LAN_SEARCH_SUB", "Ir");
define("LAN_THEME_SHARE", "Compartilhar isto");
define("LAN_THEME_VER", "e107 v.");
define("CM_L13", "por");


?>