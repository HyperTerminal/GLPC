<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Norwegian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/core/languages/Norwegian.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/09 13:32:23 $
|        $Author: John-Arild Foss $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "e107 kjerne tema av <a href='http://e107.org' title='e107 CMS' rel='external'>e107 Inc.</a>");
define("LAN_THEME_2", "Kommentarer:");
define("LAN_THEME_3", "Kommentarer er slått av for dette elementet");
define("LAN_THEME_4", "LES MER");
define("LAN_THEME_5", "Tilbakesporinger:");
define("LAN_THEME_8", "i");
define("LAN_THEME_9", "av");
define("LAN_THEME_11", "Siste nyheter");
define("LAN_THEME_12", "E-post til en venn");
define("LAN_THEME_13", "Lag PDF fil");
define("LAN_THEME_14", "Skriv ut");
define("LAN_THEME_15", "Rediger");
define("LAN_THEME_17", "Logg inn");
define("LAN_THEME_18", "Brukernavn");
define("LAN_THEME_19", "Passord");
define("LAN_THEME_20", "Registrer");
define("LAN_THEME_21", "Logg inn");
define("LAN_THEME_22", "Glemt passord?");
define("LAN_THEME_23", "Velkommen");
define("LAN_THEME_24", "Admin");
define("LAN_THEME_26", "Innstillinger");
define("LAN_THEME_27", "Profil");
define("LAN_THEME_28", "Logg ut");
define("LAN_THEME_29", "List nye");
define("LAN_THEME_SING", "Logg inn");
define("LAN_THEME_REG", "Registrer");
define("LAN_SEARCH", "Søk");
define("LAN_SEARCH_SUB", "Kjør");
define("LAN_THEME_SHARE", "Del dette");
define("LAN_THEME_VER", "e107 v.");
define("CM_L13", "av");


?>