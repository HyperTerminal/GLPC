<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_themes/khatru/languages/Norwegian.php,v $
|     $Revision: 23 $
|     $Date: 2010-05-03 22:20:01 +0200 (ma, 03 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "'khatru' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Kommentarer er deaktivert for denne nyheten");
define("LAN_THEME_3", "kommentar: ");
define("LAN_THEME_4", "Les resten ...");
define("LAN_THEME_5", "Trackbacks: ");


?>