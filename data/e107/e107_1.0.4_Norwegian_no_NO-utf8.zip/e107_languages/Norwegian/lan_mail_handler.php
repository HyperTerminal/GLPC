<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_mail_handler.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Produsert av e107 website system");
define("LANMAILH_2", "Dette er en multi-del melding i MIME format.");
define("LANMAILH_3", " er ikke riktig formatert");
define("LANMAILH_4", "Server avslo adressen");
define("LANMAILH_5", "Intet svar fra server");
define("LANMAILH_6", "Kunne ikke finne e-post server.");
define("LANMAILH_7", " ser ut til å være gyldig.");


?>