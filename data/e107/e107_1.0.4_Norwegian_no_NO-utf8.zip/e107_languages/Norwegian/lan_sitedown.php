<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_sitedown.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nettsiden er midlertidig stengt");
define("LAN_SITEDOWN_00", "er midlertidig stengt.");
define("LAN_SITEDOWN_01", "Vi har midlertidig stengt denne nettsiden for vedlikehold. Dette burde ikke ta lang tid, og vi beklager eventuelle ulemper dette måtte medføre.");
?>