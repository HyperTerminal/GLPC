<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_notify.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Brukerregistrering");
define("NT_LAN_UV_1", "Medlem er aktivert");
define("NT_LAN_UV_2", "Medlem ID:");
define("NT_LAN_UV_3", "Brukernavn:");
define("NT_LAN_UV_4", "Brukers IP:");
define("NT_LAN_LI_1", "Medlem har logget inn");
define("NT_LAN_LO_1", "Medlem har logget ut");
define("NT_LAN_LO_2", " logget ut av siden");
define("NT_LAN_FL_1", "Flood Ban");
define("NT_LAN_FL_2", "IP addresser bannet for flooding");
define("NT_LAN_SN_1", "Nyhet er sendt inn");
define("NT_LAN_NU_1", "Oppdatert");
define("NT_LAN_ND_1", "Nyhet er slettet");
define("NT_LAN_ND_2", "Slettet nyhet med ID");
define("NT_LAN_CM_1", "Bruker kommentar venter på godkjenning");


?>