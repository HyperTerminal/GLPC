<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_upload_handler.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Filtypen");
define("LANUPLOAD_2", "er ikke tillatt og slettes derfor.");
define("LANUPLOAD_3", "Opplastningen var vellykket");
define("LANUPLOAD_4", "Enten finnes ikke mottagende mappe, eller så er den ikke skrivbar.");
define("LANUPLOAD_5", "Den opplastede filen overskrider upload_max_filesize direktivet i php.ini.");
define("LANUPLOAD_6", "Den opplastede filen overskrider MAX_FILE_SIZE direktivet som spesfiseres i html-formularet.");
define("LANUPLOAD_7", "Filen ble bare delvis lastet opp.");
define("LANUPLOAD_8", "Ingen fil ble lastet opp.");
define("LANUPLOAD_9", "Opplastet filstørrelse 0 bytes");
define("LANUPLOAD_10", "Opplastningen mislyktes [Duplisert filnavn] - En fil med samme navn finnes allerede.");
define("LANUPLOAD_11", "Filen ble ikke lastet opp. Filnavn: ");
define("LANUPLOAD_12", "Feil");
define("LANUPLOAD_13", "Mangler midlertidig mappe");
define("LANUPLOAD_14", "Det skjedde en feil ved å skrive inn filen");
define("LANUPLOAD_15", "Opplastinger er ikke tillatt");
define("LANUPLOAD_16", "Ukjent feil");
define("LANUPLOAD_17", "Ugyldig navn for opplastet fil");
define("LANUPLOAD_18", "Opplastingen går over grensene som er satt.");
define("LANUPLOAD_19", "For mange filer ble lastet opp - det som ble for mye er slettet.");


?>