<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_print.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Printer Vennlig"); }

define("LAN_PRINT_86", "Kategori:");
define("LAN_PRINT_87", "av ");
define("LAN_PRINT_94", "Lagt inn av");
define("LAN_PRINT_135", "Nyhet: ");
define("LAN_PRINT_303", "Denne nyheten kommer fra ");
define("LAN_PRINT_304", "Tittel: ");
define("LAN_PRINT_305", "Undertittel: ");
define("LAN_PRINT_306", "Dette er fra: ");
define("LAN_PRINT_307", "Print denne siden");

define("LAN_PRINT_1", "printer vennlig");


?>