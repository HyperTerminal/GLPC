<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_fpw.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Resetting av passord");

define("LAN_02", "Beklager, kunne ikke sende e-posten - vennligst kontakt en av sidens ansvarlige.");
define("LAN_03", "Resetting av passord");
define("LAN_05", "For å resette passordet, vennligst fyll inn følgende informasjon");
define("LAN_06", "Forsøkt passord resetting");
define("LAN_07", "Noen med IP adressen ");
define("LAN_08", "har prøvd å resette passordet til hovedadministratoren.");
define("LAN_09", "Resetting av passord fra ");
define("LAN_112", "Registrert e-post adresse");
define("LAN_156", "Send");
define("LAN_213", "Det brukernavnet eller e-posten ble ikke funnet i databasen");
define("LAN_214", "Kunne ikke resette passordet ditt");
define("LAN_216", "For å validere det nye passordet, vennligst klikk deg inn på følgende URL ...");
define("LAN_217", "Ditt nye passord er nå validert, du kan nå logge inn med det nye passordet.");
define("LAN_218", "Ditt brukernavn er:");
define("LAN_219", "Passordet som er koblet til denne e-posten er allerede resatt og kan ikke ble resatt igjen. Vennligst kontakt en av sidens ansvarlige for mer informasjon.");
define("LAN_FPW1","Brukernavn");
define("LAN_FPW2","Skriv inn koden");
define("LAN_FPW3","Feil kode er skrevet inn");
define("LAN_FPW4","En forespørsel om å endre dette passordet er allerede sendt. Dersom du ikke har fått dette, vennligst kontakt en av sidens ansvarlige for mer hjelp.");
define("LAN_FPW5","En forespørsel om å endre ditt passord fra");
define("LAN_FPW6","En e-post er nå sendt til deg med en link du må følge for å endre ditt passord.");
define("LAN_FPW7","Dette er ikke en gyldig link for å endre passordet ditt.<br />Vennligst kontakt en av sidens ansvarlige for mer informasjon");
define("LAN_FPW8","Ditt passord er nå endret.");
define("LAN_FPW9","Det nye passordet er:");
define("LAN_FPW10","Vennligst");
define("LAN_FPW11","logg inn nå");
define("LAN_FPW12","og øyeblikkelig endre ditt passord, for sikkerhetsmessige årsaker");

define("LAN_FPW13", "vennligst følg instruksjonene i e-posten for å validere passordet ditt.");
define("LAN_FPW14", "har blitt lagt inn av noen med IP adressen");
define("LAN_FPW15", "Dette betyr ikke at passordet ditt har blitt endret.  Du må navigere til linken under, for å fullføre prosessen.");
define("LAN_FPW16", "Dersom du ikke har prøvd å resette ditt passord og du heller ikke ønsker det, så kan du enkelt og greit ignorere denne e-posten");
define("LAN_FPW17", "Linken under vil være gyldig i 48 timer");

?>