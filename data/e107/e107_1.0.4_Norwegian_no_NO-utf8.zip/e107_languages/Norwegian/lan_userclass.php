<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_userclass.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Alle (offentlig)");
define("UC_LAN_1", "Gjester");
define("UC_LAN_2", "Ingen (inaktiv)");
define("UC_LAN_3", "Medlemmer");
define("UC_LAN_4", "Les-bare");
define("UC_LAN_5", "Admin");
define("UC_LAN_6", "Hoved Admin");
define("UC_LAN_9", "Nye brukere");
define("UC_LAN_10", "Søk roboter");


?>