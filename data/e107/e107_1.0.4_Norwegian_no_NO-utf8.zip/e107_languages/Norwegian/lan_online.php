<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_online.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "Gjester: ");
define("ONLINE_EL2", "Medlemmer: ");
define("ONLINE_EL3", "På denne siden: ");
define("ONLINE_EL4", "Pålogget");
define("ONLINE_EL5", "Medlemmer");
define("ONLINE_EL6", "Nyeste medlem");
define("ONLINE_EL7", "ser på");
define("ONLINE_EL8", "flest personer samtidig pålogget: ");
define("ONLINE_EL9", "den");
define("ONLINE_EL10", "Medlem");
define("ONLINE_EL11", "Ser på siden");
define("ONLINE_EL12", "Svarer på");
define("ONLINE_EL13", "Forum");
define("ONLINE_EL14", "Emne");
define("ONLINE_EL15", "Side");
define("CLASSRESTRICTED", "Sperret side");
define("ARTICLEPAGE", "Artikkel/Annmeldelse");
define("CHAT", "Chat");
define("COMMENT", "Kommentarer");
define("DOWNLOAD", "Nedlastinger");
define("EMAIL", "email.php");
define("FORUM", "Hovedsiden for forumet");
define("LINKS", "Linker");
define("NEWS", "Nyheter");
define("OLDPOLLS", "Gamle avstemninger");
define("POLLCOMMENT", "Avstemning");
define("PRINTPAGE", "Print");
define("LOGIN", "Logger inn");
define("SEARCH", "Søker");
define("STATS", "Statistikk for nettsiden");
define("SUBMITNEWS", "Send inn nyhet");
define("UPLOAD", "Opplastinger");
define("USERPAGE", "Medlemsprofiler");
define("USERSETTINGS", "Brukerinnstillinger");
define("ONLINE", "Påloggede brukere");
define("LISTNEW", "Liste over nyheter");
define("USERPOSTS", "Medlems Poster");
define("SUBCONTENT", "Send inn artikkel/annmeldelse");
define("TOP", "Topp postere / Mest aktive forumemner");
define("ADMINAREA", "Admin området");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Liste over hendelser");
define("CALENDAR", "Hendelseskalender");
define("FAQ", "Faq");
define("PM", "Private Meldinger");
define("SURVEY", "Undersøkelse");
define("ARTICLE", "Artikkel");
define("CONTENT", "Side");
define("REVIEW", "Annmeldelse");

?>