<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_user.php,v $
|     $Revision: 24 $
|     $Date: 2010-05-23 19:55:25 +0200 (sø, 23 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Medlemmer");

define("LAN_20", "Feil");
define("LAN_112", "E-post Addresse");
//define("LAN_115", "ICQ Nummer");
//define("LAN_116", "AIM Addresse");
//define("LAN_117", "Windows Live Messenger");
//define("LAN_118", "Bursdag");
//define("LAN_119", "Sted");
//define("LAN_120", "Signatur");
define("LAN_137", "Det finnes ingen informasjon om denne brukeren, da det ikke er registrert noen bruker som dette på ");
define("LAN_138", "Registrerte medlemmer: ");
define("LAN_139", "Rekkefølge: ");
define("LAN_140", "Registrerte medlemmer");
define("LAN_141", "Det er enda ingen registrerte medlemmer.");
define("LAN_142", "Medlem");
define("LAN_143", "[skjult]");
//define("LAN_144", "Hjemmeside URL");
define("LAN_145", "Registrert");
define("LAN_146", "Besøk siden registrering");
define("LAN_147", "Chatboks poster");
define("LAN_148", "Kommentarer postet");
define("LAN_149", "Forum poster");
define("LAN_308", "Ekte navn");
define("LAN_400", "Dette er ikke en gyldig bruker.");
define("LAN_401", "Ingen informasjon");
define("LAN_402", "Profil");
define("LAN_403", "Statistikk");
define("LAN_404", "Siste besøk");
define("LAN_405", "dager siden");
define("LAN_406", "Rating");
define("LAN_407", "ingen");
define("LAN_408", "har ikke bilde");
define("LAN_409", "poeng");
define("LAN_410", "Diverse");
define("LAN_411", "Klikk her for å endre din informasjon");
define("LAN_412", "Klikk her for å endre denne brukeren sin informasjon");
define("LAN_413", "slett bilde");
define("LAN_414", "forrige medlem");
define("LAN_415", "neste medlem");
define("LAN_416", "Du må være logget inn for å se denne siden");
define("LAN_417", "Hovedadministrator");
define("LAN_418", "Administrator");
define("LAN_419", "Vis");
define("LAN_420", "Synkende");
define("LAN_421", "Stigende");
define("LAN_422", "Gå");
define("LAN_423", "Klikk her for å se kommentarer fra denne brukeren.");
define("LAN_424", "Klikk her for å se forumpostene til denne brukeren");
define("LAN_425", "Send Privat melding");
define("LAN_426", "siden");

define("USERLAN_1", "Peer Rating");
define("USERLAN_2", "Du har ikke tilgang til denne siden");

?>