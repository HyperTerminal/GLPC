<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_userposts.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Medlemsposter");

define("UP_LAN_0", "Alle forumposter for ");
define("UP_LAN_1", "Alle kommentarer for ");
define("UP_LAN_2", "Emne");
define("UP_LAN_3", "Visninger");
define("UP_LAN_4", "Svar");
define("UP_LAN_5", "Siste post");
define("UP_LAN_6", "Emner");
define("UP_LAN_7", "Ingen kommentarer");
define("UP_LAN_8", "Ingen poster");
define("UP_LAN_9", " den ");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Postet den");
define("UP_LAN_12", "Søk");
define("UP_LAN_13", "Kommentarer");
define("UP_LAN_14", "Forum Poster");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP Addresse");
?>