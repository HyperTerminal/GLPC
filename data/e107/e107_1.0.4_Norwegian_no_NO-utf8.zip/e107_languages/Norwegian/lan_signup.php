<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_signup.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Registrer");
define("LAN_7", "Nick:");
define("LAN_8", "navnet som blir vist til andre på nettsiden");
define("LAN_9", "Brukernavn:");
define("LAN_10", "navnet du bruker for å logge inn");
define("LAN_17", "Passord:");
define("LAN_103", "Det brukernavnet er ikke gyldig, vennligst velg et annet navn");
define("LAN_104", "Brukernavnet eksisterer fra før av, vennligst velg et annet navn");
define("LAN_105", "Passordene som ble skrevet inn matcher ikke, vennligst prøv igjen");
define("LAN_106", "Mailadressen som ble skrevet inn ser ikke ut til å være gyldig");
define("LAN_107", "Ferdig! Du er nå registrert på Hvam Golfsimulatorsenter");
define("LAN_108", "Registreringen er nå ferdig");
define("LAN_109", "This site complies with The Children's Online Privacy Protection Act of 1998 (COPPA) and as such cannot accept registrations from users under the age of 13 without a written permission document from their parent or guardian. For more information you can read the legislation");
define("LAN_110", "Registrering");
define("LAN_111", "Skriv passordet igjen:");
define("LAN_112", "Email Addresse:");
define("LAN_113", "Skjule emailadressen?:");
define("LAN_114", "Dette gjør så ingen andre brukere kan se din mailadresse");
define("LAN_123", "Registrer");
define("LAN_185", "Noen nødvendige felt ble ikke fylt inn.");
define("LAN_201", "Ja");
define("LAN_200", "Nei");
define("LAN_202", "Du har allerede en konto. Dersom du har glemt passordet ditt, trykk på 'Glemt passord?' linken på forsiden.");
define("LAN_309", "Skriv inn alle detaljene under");
define("LAN_399", "Fortsett");
define("LAN_400", "Brukernavn og passord er <b>'case-sensitive'</b>. Dette betyr at det er forskjell på store og små bokstaver.");
define("LAN_401", "Din konto er nå aktivert, vennligst");
define("LAN_402", "Registrering er aktivert");
define("LAN_403", "Velkommen til");
define("LAN_404", "Registreringsdetaljer for");
define("LAN_405", "Dette steget er nå fullført. Du vil snart motta en konfirmasjonsmail som inneholder dine login detaljer. Vennligst følg linken i den emailen for å fullføre registreringen");
define("LAN_406", "Takk!");
define("LAN_407", "Vennligst behold denne mailen for din egen del. Ditt passord er kryptert og kan ikke hentes tilbake dersom du glemmer det. Men du kan be om et nytt passord dersom dette skulle skje.\n\ntakk for din registrering.\n\nHilsen,");
define("LAN_408", "En bruker med den eposten eksisterer fra før av. Vennligst bruk 'glemt passord' siden for å lage et nytt.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "tegn.");
define("LAN_SIGNUP_3", "Kodeverifikasjonen feilet.");
define("LAN_SIGNUP_4", "Ditt passord må være minst");
define("LAN_SIGNUP_5", " tegn langt.");
define("LAN_SIGNUP_6", "Ditt");
define("LAN_SIGNUP_7", " Er nødvendig");
define("LAN_SIGNUP_8", "Takk!");
define("LAN_SIGNUP_9", "Kan ikke fortsette.");
define("LAN_SIGNUP_10", "ja");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Ugyldige tegn i brukernavnet");
define("LAN_410", "Skriv inn koden som blir vist:");
define("LAN_411", "Det nicket eksisterer fra før av, vennligst velg et annet");
define("LAN_SIGNUP_12", "vennligst husk ditt brukernavn og passord. Dersom du glemmer det kan vi ikke hente det tilbake.");
define("LAN_SIGNUP_13", "Du kan nå logge inn fra forsiden, eller <a href='".e_BASE."login.php'>herfra</a>.");
define("LAN_SIGNUP_14", "her");
define("LAN_SIGNUP_15", "Vennligst kontakt administratoren for denne siden");
define("LAN_SIGNUP_16", "dersom du trenger hjelp.");
define("LAN_SIGNUP_17", "Please certify you are 13 or over the age of 13.");
define("LAN_SIGNUP_18", "Din registrering er mottatt med følgende informasjon ...");
define("LAN_SIGNUP_21", "Din konto er merket som inaktiv, For å aktivere, vennligst følg følgende link ...");
define("LAN_SIGNUP_22", "klikk her");
define("LAN_SIGNUP_23", "for å logge inn.");
define("LAN_SIGNUP_24", "Du er nå registrert hos");
define("LAN_SIGNUP_25", "Last opp et avatar");
define("LAN_SIGNUP_26", "Last opp et bilde");
define("LAN_SIGNUP_27", "Vis");
define("LAN_SIGNUP_28", "choice of Content/Mail-lists");
define("LAN_SIGNUP_29", "En verifikasjonsmail blir sendt til denne andressen, så det er viktig at den er gyldig.");
define("LAN_SIGNUP_30", "Dersom du ønsker å skjule din mailadresse på denne nettsiden, vennligst velg 'Ja' for valget 'Skjule email adressen?'.");
define("LAN_SIGNUP_31", "URL to your XUP file");
define("LAN_SIGNUP_32", "What's an XUP file?");
define("LAN_SIGNUP_33", "Type path or choose avatar");
define("LAN_SIGNUP_34", "Please note: Any image uploaded to this server that is deemed inappropriate by the administrators will be deleted immediately.");
define("LAN_SIGNUP_35", "Click here to register using an XUP file");
define("LAN_SIGNUP_36", "An error has occurred creating your user information, please contact the site admin");
define("LAN_LOGINNAME", "Brukernavn");
define("LAN_PASSWORD", "Passord");
define("LAN_USERNAME", "Nick");
define("LAN_EMAIL_01", "Kjære");
define("LAN_EMAIL_04", "Vennligst behold denne mailen for din egen informasjon");
define("LAN_EMAIL_05", "Ditt passord er kryptert og kan ikke hentes tilbake dersom du glemmer det. Men du kan be om et nytt passord dersom dette skulle skje.");
define("LAN_EMAIL_06", "Takk for din registrering");
define("LAN_SIGNUP_37", "Dette steget er nå ferdig. En administrator må nå godkjenne din bruker.  Når dette er gjort vil du motta en mail hvor det står at din konto er aktivert.");
define("LAN_SIGNUP_38", "Du har skrevet inn to forskjellige emailadresser. Vennligst skriv inn en gyldig mailadresse i begge feltene");
define("LAN_SIGNUP_39", "Skriv inn mailadressen på nytt:");
define("LAN_SIGNUP_40", "Aktivering er ikke nødvendig");
define("LAN_SIGNUP_41", "Din konto er allerede aktivert.");
define("LAN_SIGNUP_42", "Det oppsto et problem og registreringsmailen ble ikke sendt. Vennligst kontakt en administrator");
define("LAN_SIGNUP_43", "Email Sendt");
define("LAN_SIGNUP_44", "Aktiveringsmailen ble sendt til:");
define("LAN_SIGNUP_45", "Vennligst se i innboksen din");
define("LAN_SIGNUP_47", "Send aktiveringsmailen på nytt");
define("LAN_SIGNUP_48", "Brukernavn eller epost adresse");
define("LAN_SIGNUP_49", "Dersom du registrerte deg med feil mailadresse, skriv inn en ny adresse og passordet ditt her:");
define("LAN_SIGNUP_50", "Ny email");
define("LAN_SIGNUP_51", "Gamle passord");
define("LAN_SIGNUP_52", "Feil passord");
define("LAN_SIGNUP_53", "velideringen feilet");
define("LAN_SIGNUP_54", "Klikk her for å fylle inn dine detaljer for registreringen");
define("LAN_SIGNUP_55", "Nicket du har valgt er for langt. Vennligst velg et annet");
define("LAN_SIGNUP_56", "TNicket du har valgt er for kort. Vennligst velg et annet");
define("LAN_SIGNUP_57", "Det brukernavnet var for kort. Vennligst velg et annet");
define("LAN_SIGNUP_58", "Registrering forhåndsvisning");
define("LAN_SIGNUP_59", "**** Dersom linken ikke fungerer, vennligst sjekk at den ikke har delt seg på to linjer. ****");
define("LAN_SIGNUP_60", "Kunne ikke finne eksternt avatar");
define("LAN_SIGNUP_72", "Takk for at du registrerte deg hos [sitename]! Vi har nå sendt en verifikasjons e-post til [email]. Vennligst klikk på linken i denne e-posten for å fullføre din registrering");
define("LAN_SIGNUP_98", "Verifiser din e-post");
define("LAN_SIGNUP_99", "Et problem oppsto");
define("LAN_SIGNUP_100", "Venter på godkjenning av en administrator");
define("LAN_SIGNUP_102", "Registrering ble avbrutt");
define("LAN_SIGNUP_103", "Det har skjedd for mange registreringer fra denne IP adressen:");
define("LAN_SIGNUP_104", "Ugyldig navn på avatar");
define("LAN_SIGNUP_105", "Kan ikke behandle din forespørsel - Vennligst kontakt administratoren av hjemmesiden.");
define("LAN_SIGNUP_106", "Kan ikke behandle din forespørsel - Har du allerede en konto her?");


?>