<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_banner.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Banner");

define("BANNERLAN_16", "Brukernavntest: ");
define("BANNERLAN_17", "Passord: ");
define("BANNERLAN_18", "Fortsett");
define("BANNERLAN_19", "Vennligst skriv inn ditt klient brukernavn og passord for å fortsette");
define("BANNERLAN_20", "Beklager, kunne ikke finne disse detaljene i databasen. Vennligst kontakt en administrator for hjelp.");
define("BANNERLAN_21", "Banner statistikker");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "Banner ID");
define("BANNERLAN_24", "Klikk");
define("BANNERLAN_25", "Klikk %");
define("BANNERLAN_26", "Visninger");
define("BANNERLAN_27", "Visninger kjøpt");
define("BANNERLAN_28", "Visninger igjen");
define("BANNERLAN_29", "Ingen bannere");
define("BANNERLAN_30", "Ingen grense");
define("BANNERLAN_31", "Gjelder ikke");
define("BANNERLAN_32", "Ja");
define("BANNERLAN_33", "Nei");
define("BANNERLAN_34", "Slutter:");
define("BANNERLAN_35", "Klikk IP adresser");
define("BANNERLAN_36", "Aktiv:");
define("BANNERLAN_37", "Starter:");
define("BANNERLAN_38", "Feil");

?>