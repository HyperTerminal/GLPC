<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_email.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "Email"); }

define("LAN_EMAIL_1", "Fra:");
define("LAN_EMAIL_2", "IP addressen til avsender:");
define("LAN_EMAIL_3", "Innholdet i e-posten er sendt fra ");
define("LAN_EMAIL_4", "Send Epost");
define("LAN_EMAIL_5", "Send dette på mail til en venn");
define("LAN_EMAIL_6", "Jeg tenkte at du kanskje vil være interessert i dette fra");
define("LAN_EMAIL_7", "send til noen");
define("LAN_EMAIL_8", "Kommentar");
define("LAN_EMAIL_9", "Beklager - kunne ikke sende eposten");
define("LAN_EMAIL_10", "Mailen er sendt til");
define("LAN_EMAIL_11", "E-posten er nå sendt");
define("LAN_EMAIL_12", "Feil");
define("LAN_EMAIL_13", "Send denne artikkelen til en venn");
define("LAN_EMAIL_14", "Send denne nyheten til en venn");
define("LAN_EMAIL_15", "Brukernavn: ");
define("LAN_EMAIL_106", "Det ser ut til å være en ugyldig adresse");
define("LAN_EMAIL_185", "Send Artikkel");
define("LAN_EMAIL_186", "Send Nyhet");
define("LAN_EMAIL_187", "E-post adresser som dette skal sendes til");
define("LAN_EMAIL_188", "Jeg tenkte at du kanskje vil være interessert i denne nyheten fra");
define("LAN_EMAIL_189", "Jeg tenkte at du kanskje vil være interessert i denne artikkelen fra");
define("LAN_EMAIL_190", "Skriv inn den synlige koden");

?>