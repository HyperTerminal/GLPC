<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_error.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Feil");

define("LAN_ERROR_1", "Feil 401 - Autorisasjon kreves");
define("LAN_ERROR_2", "Du har ikke tilgang til siden du prøver å nå.");
define("LAN_ERROR_3", "Dersom du mener at dette er en feil, vennligst kontakt en administrator.");
define("LAN_ERROR_4", "Feil 403 - Tilgang nektes");
define("LAN_ERROR_5", "Du har bedt om en ressurs du ikke har tilgang til.");
define("LAN_ERROR_6", "Dersom du mener at dette er en feil, vennligst kontakt en administrator.");
define("LAN_ERROR_7", "Feil 404 - Filen ble ikke funnet.");
define("LAN_ERROR_8", "Siden eller ressursen du prøver å nå ble ikke funnet.");
define("LAN_ERROR_9", "Dersom du mener at dette er en feil, vennligst kontakt en administrator.");
define("LAN_ERROR_10", "Feil 500 - Intern serverfeil");
define("LAN_ERROR_11", "Webserveren du prøver å nå har fått en uventet tilstand som forhindret den i å levere det du ber om.");
define("LAN_ERROR_12", "Dersom du mener at dette er en feil, vennligst kontakt en administrator.");
define("LAN_ERROR_13", "Feil - Ukjent");
define("LAN_ERROR_14", "Serveren støtte på en feil");
define("LAN_ERROR_15", "Dersom du mener at dette er en feil, vennligst kontakt en administrator.");
define("LAN_ERROR_16", "Ditt misslykkede forsøk på å nå");
define("LAN_ERROR_17", "har blitt registrert");
define("LAN_ERROR_18", "Tilsynelatende ble du henvist hit av");
define("LAN_ERROR_19", "Beklagelivis er dette en foreldet linkadresse.");
define("LAN_ERROR_20", "Venligst trykk her for å gå til sidens startside.");
define("LAN_ERROR_21", "Den ønskede URL kunne ikke bli funnet på serveren. Linken du fulgte er sannsynlegvis utdatert.");
define("LAN_ERROR_22", "Venligst trykk her for å gå til sidens søkefunksjon");
define("LAN_ERROR_23", "Ditt forsøk på å få adgang til");
define("LAN_ERROR_24", "mislykktes.");

// 0.7.6
define("LAN_ERROR_25", "[1]: Ikke i stand til å lese kjerneinnstillinger fra databasen - Kjerneinstillinger finnes men kan ikke bli brukt. Prøver å gjenopprette kjerneinstillinger ...");
define("LAN_ERROR_26", "[2]: Ikke i stand til å lese kjerneinstillinger fra databasen - Kjerneinstillinger finnes ikke.");
define("LAN_ERROR_27", "[3]: Kjerneinstillinger er lagret - backup er nå tilgjenngelig.");
define("LAN_ERROR_28", "[4]: Ingen kjernebackupfil finnes. Vennligst kjør <a href='".e_FILE."resetcore/resetcore.php'>Resett_Kjerne</a> programmet for å gjenoppbygge kjerneinstillingene. <br /> Etter gjenoppbygging av kjernen kan du lagre en backupfil fra admin/sql skjermen.  ");
define("LAN_ERROR_29", "[5]: Felt har blitt latt være blanke. Venligst send skjemaet på nytt med de manglene feltene utfylt.");
define("LAN_ERROR_30", "[6]: Var ikke i stand til å forme en gyldig tilkobling til mySQL. Venligst sjekk at e107_config.php inneholder rett informasjon.");
define("LAN_ERROR_31", "[7]: mySQL kjører men databasen ({$mySQLdefaultdb}) kunne ikke kobles til.<br />Sjekk at den eksisterer, og rett informasjon er registrert i e107_config.php.");
define("LAN_ERROR_32", "For å fullføre oppdateringen må du kopiere følgende tekst inn i e107_config.php filen:");

define("LAN_ERROR_33", "Feil med lasting! Vanligvis, så ville jeg sendt deg videre til forsiden.");
define("LAN_ERROR_34", "Ukjent feil! Vennligst informer oss om at du fikk dette og legg ved informasjon som link, tid og hvordan du kom deg hit.:");

define('LAN_ERROR_35', 'Feil 400 - Bad Request');
define('LAN_ERROR_36', 'Det er en feil i formate til websiden du prøver å nå.');
define('LAN_ERROR_37', 'Feil i ikon');
define('LAN_ERROR_38', '');
define('LAN_ERROR_39', '');


?>