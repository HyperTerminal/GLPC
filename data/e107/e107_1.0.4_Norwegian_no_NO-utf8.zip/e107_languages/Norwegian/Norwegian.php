<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/Norwegian.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'no_NO.UTF-8', 'no_NO.utf8', 'nor_nor.utf8', 'no');
define("CORE_LC", 'no');
define("CORE_LC2", 'no');
// define("TEXTDIRECTION","rtl");
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","Feil : design mangler.\\n\\nEndre designet som er valgt ( i admin området) eller last opp filene til designet som er valgt nå til serveren.");

//v.616
//obsolete define("CORE_LAN2"," \\1 Skrev:");// "\\1" representerer brukernavnet.
//obsolete define("CORE_LAN3","vedlegg er deaktivert");

//v0.7+
define("CORE_LAN4", "Vennligst slett install.php fra serveren");
define("CORE_LAN5", "dersom du ikke gjør dette, så er det en potensiell sikkerhetsrisiko for websiden din");

// v0.7.6
define("CORE_LAN6", "Flood beskyttelsen er aktivert, og dersom du fortsetter å be om sider, så vil du bli utestengt fra denne siden.");
define("CORE_LAN7", "Kjernen prøver å gjenopprette innstillinger fra den automatiske backupen.");
define("CORE_LAN8", "Feil i kjerneinnstillinger");
define("CORE_LAN9", "Kjernen kunne ikke gjenopprettes fra den automatiske backupen. Handlingen ble stoppet.");
define("CORE_LAN10", "Korrupt cookie oppdaget. Logget ut.");

// Footer
define("CORE_LAN11", "Sidegenerering tokk: ");
define("CORE_LAN12", " sekunder, ");
define("CORE_LAN13", " av det for spørringer. ");
define("CORE_LAN14", "");			// Used in 0.8
define("CORE_LAN15", "DB spørringer: ");
define("CORE_LAN16", "Minnebruk: ");

// img.bb
define('CORE_LAN17', '[ bilder er deaktivert ]');
define('CORE_LAN18', 'Bilde: ');

define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "kB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");


define("LAN_WARNING", "Advarsel!");
define("LAN_ERROR", "Feil");
define("LAN_ANONYMOUS", "Anonym");
define("LAN_EMAIL_SUBS", "-epost-");

// 0.7.23
define("LAN_SANITISED", "SANITISED");
?>