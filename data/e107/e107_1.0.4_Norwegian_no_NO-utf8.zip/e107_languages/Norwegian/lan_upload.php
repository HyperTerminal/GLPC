<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_upload.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Last opp");

define('LAN_UL_001','Ugyldig epost adresse');
define('LAN_UL_002', 'Du har ikke riktig rettigheter til å laste opp filer til denne serveren.');	// LAN_403

define('LAN_UL_020', 'Feil');
define('LAN_UL_021', 'Feil med opplasting');

define('LAN_UL_032', 'Du må velge en kategori');
define('LAN_UL_033', 'Du må skrive inn en gyldig epost adresse');
define('LAN_UL_034', 'Du må spesifisere et filnavn');
define('LAN_UL_035', 'Du må skrive inn en beskrivelse');
define('LAN_UL_036', 'Du må spesifisere hvilken fil du vil laste opp');
define('LAN_UL_037', 'Du må spesifisere en kategori');
define('LAN_UL_038', '');

define("LAN_61", "Ditt Navn: ");
define("LAN_112", "Epostadresse: ");
define("LAN_144", "Nettsted URL: ");
define("LAN_402", "Du må være registrert medlem for å få laste opp filer til denne serveren.");
define("LAN_404", "Takk. Opplastningen din vil bli sjekket av en nettstedsadministrator så snart som mulig lagt ut på nettstedet om den anses som passende.");
//define("LAN_405", "Filen overskrider maximal tillatt størrelse - slettet.");
define("LAN_406", "NB");
define("LAN_407", "Alle andre filtyper som lastes opp vil umiddelbart bli slettet.");
define("LAN_408", "Understreket");
define("LAN_409", "Filnavn");
define("LAN_410", "Versjon");
define("LAN_411", "Fil");
define("LAN_412", "Skjermbilde");
define("LAN_413", "Beskrivelse");
define("LAN_414", "Fungerende demo");
define("LAN_415", "oppgi URL til et nettsted der en demo vises");
define("LAN_416", "Bekreft og last opp");
define("LAN_417", "Last opp fil");
define("LAN_418", "Maksimal filstørrelse: ");
define("DOWLAN_11", "Kategori");
define("LAN_419", "Tillatte filtyper");
define("LAN_420", "felt er obligatoriske");



?>