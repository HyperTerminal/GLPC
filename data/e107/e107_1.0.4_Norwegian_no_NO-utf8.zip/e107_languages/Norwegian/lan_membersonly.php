<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_membersonly.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Bare for registrerte brukere");

define("LAN_MEMBERS_0", "sperret område");
define("LAN_MEMBERS_1", "Dette er et sperret område.");
define("LAN_MEMBERS_2","For tilgang, vennligst <a href='".e_LOGIN."'>logg inn</a>");
define("LAN_MEMBERS_3","eller <a href='".e_SIGNUP."'>registrer deg som en medlem</a>.");
define("LAN_MEMBERS_4","Klikk her for å gå tilbake til forsiden");


?>