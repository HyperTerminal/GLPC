<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_rate.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "stem");
define("RATELAN_1", "stemmer");
define("RATELAN_2", "hvilken karakter vil du gi dette?");
define("RATELAN_3", "takk for din stemme");
define("RATELAN_4", "ingen stemmer");
define("RATELAN_5", "Karakter");

?>