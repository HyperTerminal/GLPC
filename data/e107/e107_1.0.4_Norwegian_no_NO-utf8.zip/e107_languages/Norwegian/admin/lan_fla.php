<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_fla.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("FLALAN_1", "Mislykkede innloggingsforsøk");
define("FLALAN_2", "Ingen mislykkede innlogginger er registrert");
define("FLALAN_3", "Forsøk slettet");
define("FLALAN_4", "Bruker forsøkte logge inn med feil brukernavn/passord");
define("FLALAN_5", "Blokkert(e) IP(er)");
define("FLALAN_6", "Dato");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP adresse/Server");
define("FLALAN_9", "Alternativer");
define("FLALAN_10", "Slett/Blokker merkede poster");
define("FLALAN_11", "marker alle slettingsrutene");
define("FLALAN_12", "fjern merking fra alle slettingsrutene");
define("FLALAN_13", "marker alle blokkeringsrutene");
define("FLALAN_14", "fjern merking fra alle blokkeringsrutene");
define("FLALAN_15", "Følgende IP adress(er) har blitt auto-blokkert - brukerne har gjort flere enn ti mislykkede innloggingsforsøk");
define("FLALAN_16", "Slett denne autoblokklisten");
define("FLALAN_17", "Autoblokkliste slettet");

?>