<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_fileinspector.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("FC_LAN_1", "Filinspektør");
define("FC_LAN_2", "Skanningsalternativ");
define("FC_LAN_3", "Vis");
define("FC_LAN_4", "Alle filer");
define("FC_LAN_5", "Kjernefiler");
define("FC_LAN_6", "Kjernefiler (Integritetsfeil)");
define("FC_LAN_7", "Ikke kjernefiler");
define("FC_LAN_8", "Sjekk integriteten til kjernefiler");
define("FC_LAN_9", "På");
define("FC_LAN_10", "Av");
define("FC_LAN_11", "Skann nå");
define("FC_LAN_12", "Ingen");
define("FC_LAN_13", "Manglende kjernefiler");
define("FC_LAN_14", "Vis resultat som");
define("FC_LAN_15", "Katalogtråd");
define("FC_LAN_16", "Liste");
define("FC_LAN_17", "Strengsammeligning");
define("FC_LAN_18", "Vanlig uttrykk");
define("FC_LAN_19", "Vis radnummer");
define("FC_LAN_20", "Vis passende rader");
define("FC_LAN_21", "Gamle kjernefiler");

define("FR_LAN_1", "Skanner");
define("FR_LAN_2", "Skaningsresultat");
define("FR_LAN_3", "Oversikt");
define("FR_LAN_4", "Kjernefiler skannet");
define("FR_LAN_5", "Kjernefiler ikke skannet");
define("FR_LAN_6", "Totalt skannade filer");
define("FR_LAN_7", "Integritetskontroll");
define("FR_LAN_8", "Kjernefiler ok");
define("FR_LAN_9", "Feil i kjernefiler");
define("FR_LAN_10", "Mulige årsaker til feil i filer");
define("FR_LAN_11", "Filen er korrupt");
define("FR_LAN_12", "Dette kan ha ulike grunner, for eksempel at filen var skadd i zip/tar.gz-arkivet, ble skadet under
utpakkingen eller under opplastingen via FTP. Du bør prøve å laste opp filen på nytt til serveren
og kjøre skanningen igjen for å se se om det løser problemet.");
define("FR_LAN_13", "Filen er for gammel");
define("FR_LAN_14", "Om denne filen er fra en eldre versjon av e107 enn den versjonen du kjører nå så kommer kontrollen til å feile. Forsikre deg om at du har lastet opp den nyeste versjonen av filen.");
define("FR_LAN_15", "Filen har blitt endret");
define("FR_LAN_16", "Om du har endret denne filen på noen måte så vil den ikke bestå en integritetskontroll. Om du
har endret den med vilje trenger du ikke bekymre deg og kan overse at kontrollen feilet. Om filen derimot er blitt endret av noen andre uten tillatelsebør du laste opp en ny versjon av filen fra e107 arkivet.");
define("FR_LAN_17", "Om du er en CVS bruker");
define("FR_LAN_18", "Om du kjører med e107 CVS chackouts på nettstedet ditt i stedet for den offisielle og stabile e107
utgaven så kommer du til å opplevet integritetskontrollen feiler pga at filene er endret av en utvikler etter at den siste sjekksummen av kjernen ble opprettet.");
define("FR_LAN_19", "filer feilet");
define("FR_LAN_20", "Alle filer ok");
define("FR_LAN_21", "ingen");
define("FR_LAN_22", "Manglende kjernefiler");
define("FR_LAN_23", "Ingen treff funnet.");
define("FR_LAN_24", "Gamle kjernefiler");
define("FR_LAN_25", "Integritet kan ikke beregnes");

define("FR_LAN_26", "Advarsel! Kjent sikkerhetsproblem oppdaget!");
define("FR_LAN_27", "Det finnes filer på serveren din som er kejnte for å kunne utnyttes og de må slettes umiddelbart.");
define("FR_LAN_28", "Kjente usikre filer");

?>