<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_plugin.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("EPL_ADLAN_0", "Installer");
define("EPL_ADLAN_1", "Avinstaller");
define("EPL_ADLAN_2", "Er du sikker på at du vil avinstallere denne utvidelsen?");
define("EPL_ADLAN_3", "Bekreft avinstallasjon");
define("EPL_ADLAN_4", "Avinstallasjon avbrutt.");
define("EPL_ADLAN_5", "Installasjonsprosessen kommer til å skape nye preferanseinstillinger.");
define("EPL_ADLAN_6", "... klikk deretter her for å begynne installasjonen");
define("EPL_ADLAN_7", "Databaestabeller oppgradert.");
define("EPL_ADLAN_8", "Preferanseinstillinger opprettet.");
define("EPL_ADLAN_9", "SQL-kommandoen mislyktes. Kontroller at alle oppgraderingsendringer er ok.");
define("EPL_ADLAN_10", "Navn");
define("EPL_ADLAN_11", "Versjon");
define("EPL_ADLAN_12", "Forfattere");
define("EPL_ADLAN_13", "Kompatibilitet");
define("EPL_ADLAN_14", "Beskrivelse");
define("EPL_ADLAN_15", "Les README-filen for mer informasjon");
define("EPL_ADLAN_16", "Utvidelsesinformasjon");
define("EPL_ADLAN_17", "Mer info...");
define("EPL_ADLAN_18", "Kunne ikke opprette tabell(er) for denne utvidelsen.");
define("EPL_ADLAN_19", "Databasetabeller opprettet.");
define("EPL_ADLAN_21", "Utvidelsen er allerede installert.");
define("EPL_ADLAN_22", "Innstallert");
define("EPL_ADLAN_23", "Ikke installert");
define("EPL_ADLAN_24", "Oppgradering tilgjengelig");
define("EPL_ADLAN_25", "Ingen installasjon kreves");
define("EPL_ADLAN_26", "... klikk deretter her for å begynne avinstallasjonen");
define("EPL_ADLAN_27", "Kunne ikke slette");
define("EPL_ADLAN_28", "Databasetabeller slettet.");
define("EPL_ADLAN_29", "Preferanseinstillinger slettet.");
define("EPL_ADLAN_30", "Vennligst ta dem bortmanuelt.");
define("EPL_ADLAN_31", "Ta bort katalogen nå");
define("EPL_ADLAN_32", "og alle filer i den for å avslutte avinstallasjonen.");
define("EPL_ADLAN_33", "Utvidelse installert.");
define("EPL_ADLAN_34", "Utvidelse oppdatert.");
define("EPL_ADLAN_35", "Tolkinnstillinger opprettet.");
define("EPL_ADLAN_36", "Innlegging av tolkekode mislyktes, feil formattert.");
define("EPL_ADLAN_37", "Last opp utvidelse (.zip eller .tar.gz format)");
define("EPL_ADLAN_38", "Last opp utvidelse");
define("EPL_ADLAN_39", "Filen kunne ikke lastes opp ettersom ".e_PLUGIN." katalogen ikke har korrekte rettigheter - endre til CHMOD 777 og forsøk igjen.");
define("EPL_ADLAN_40", "Adminmelding");
define("EPL_ADLAN_41", "Denne filen ser ikke ut til å være et gyldig.zip eller .tar arkiv.");
define("EPL_ADLAN_42", "En feil har oppstått, kan ikke pakke opp arkivfilen");
define("EPL_ADLAN_43", "Utvidelsen er lastet opp og pakket ut, bla nedover for å se utvidelsen i listen.");
define("EPL_ADLAN_44", "Auto utvidelses opplastning og utpakking er deaktivert ettersom utvidelsesmappen ikke har korrekte rettighetet - endre din e107_plugins katalog til CHMOD 777.");
define("EPL_ADLAN_45", "Ditt menyobjekt har blitt lastet opp og pakket ut, gå til <a href='".e_ADMIN."menus.php'>din menyside</a> for å aktivere det.");
define("EPL_ADLAN_46", "feil ved utpakking av PCLZIP:");
define("EPL_ADLAN_47", "feil ved utpakking av PCLTAR:");
define("EPL_ADLAN_48", "kode:");
define("EPL_ADLAN_49", "Tabellene ble ikke slettet i avinstalleringen etter ditt ønske");
define("EPL_WEBSITE", "Hjemmeside");
define("EPL_NOINSTALL", "Ingen installasjon kreves, aktiver bare fra din menyside. For å avinstallere, slette");
define("EPL_DIRECTORY", "katalogen.");
define("EPL_NOINSTALL_1", "Ingen installasjon kreves. For å ta bort, slett");
define("EPL_UPGRADE", "Oppgrader");
define("EPL_ADLAN_50", "Kommentarer slettet.");
define("EPL_ADLAN_53", "Mappen er ikke srivbar");
define("EPL_ADLAN_54", "Venligst velg alternativet for sletting av utvidelse:");
define("EPL_ADLAN_55", "Avinstaller utvidelsen");
define("EPL_ADLAN_57", "Slett tabeller for utvidelsen");
define("EPL_ADLAN_58", "Om tabellene ikke blir fjernet kan utvidelsen bli reinstallert uten noe datatap.  Opprattningen av tabeller vil feile under reinstalasjonen. Tabellene må slettes manuelt for å fjernes.");
define("EPL_ADLAN_59", "Slett utvidelsesfiler");
define("EPL_ADLAN_60", "e107 vil prøve å slette alle relaterte filer til utvidelsen.");
define("EPL_ADLAN_62", "Avbryt avinstallering");
define("EPL_ADLAN_63", "Avinstaller:");
define("EPL_ADLAN_64", "Alle filer fjernet fra");
define("EPL_ADLAN_65", "Sletting av fil feilet");
define("LAN_UPGRADE_SUCCESSFUL", "Oppgraderingen var vellykket");
define("LAN_INSTALL_SUCCESSFUL", "Installasjonen var vellykket");


?>