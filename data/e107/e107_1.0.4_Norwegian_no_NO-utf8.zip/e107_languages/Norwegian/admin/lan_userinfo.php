<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_userinfo.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Kunne ikke finne posters IP adresse - ingen informasjon er tilgjengelig.");
// define("USFLAN_2", "Feil");
define("USFLAN_3", "Meldinger postet fra IP addresse");
define("USFLAN_4", "Host");
define("USFLAN_5", "Klikk her for å overføre IP addressen til ban-siden");
define("USFLAN_6", "Medlems ID");
define("USFLAN_7", "Brukerinformasjon");

?>