<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_menus.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("MENLAN_1", "Synlig for alle");
define("MENLAN_2", "Synlig kun for medlemmer");
define("MENLAN_3", "Synlig kun for administratorer");
define("MENLAN_4", "Kun synlig for:");
// define("MENLAN_5", "gruppe");
define("MENLAN_6", "Lagre synlighetsalternativ");
define("MENLAN_7", "Konfigurer synlighetsalternativ for");
define("MENLAN_8", "Synlighetsalternativ oppdatert");
define("MENLAN_9", "Ny egen meny installert");
define("MENLAN_10", "Ny meny installert");
define("MENLAN_11", "Meny fjernet");
define("MENLAN_12", "Aktiver: velg område");
define("MENLAN_13", "Aktiver i område");
define("MENLAN_14", "Område");
define("MENLAN_15", "Deaktiver");
define("MENLAN_16", "Konfigurer");
define("MENLAN_17", "Flytt opp");
define("MENLAN_18", "Flytt ned");
define("MENLAN_19", "Flytt til område");
define("MENLAN_20", "Synlighet");

// define("MENLAN_21", "Bare synlig for gjester");
define("MENLAN_22", "Inaktive menyer");

define("MENLAN_23", "Flytt til bunn");
define("MENLAN_24", "Flytt til topp");
define("MENLAN_25", "Funksjon ...");

define("MENLAN_26", "Denne menyen kommer bare til å <strong>VISES</strong> på følgende sider");
define("MENLAN_27", "Denne menyen kommer bare til å vara <strong>GJEMT</strong>  på følgende sider");
define("MENLAN_28", "Angi en side pr rad, angi tilstrekkelig mye av URL'en til å gjenkjenne den ordnetlig. Dersom du trenger at URLen matcher nøyaktig, bruk en ! på slutten av sidenavnet <br /> For eksempel: <strong>page.php?1!</strong>");

define("MENLAN_29", "Velg layout");
define("MENLAN_30", "For å se menyområdene og deres posisjon for egne layouter, velg egen layout her:");
define("MENLAN_31", "Standardlayout");
define("MENLAN_32", "Nyhetsrubrikklayout");
define("MENLAN_33", "Egen layout");
define("MENLAN_34", "Innebygd");
define("MENLAN_35", "Konfigurer menyer");
define("MENLAN_36", "Velg meny(er) å aktivere");
define("MENLAN_37", "og hvor de skal aktiveres.");
define("MENLAN_38", "Hold nede CTRL for å velge flere menyer.");


?>