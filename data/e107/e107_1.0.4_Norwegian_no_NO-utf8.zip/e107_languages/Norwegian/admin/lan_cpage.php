<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_cpage.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Tittel");
define("CUSLAN_2", "Type");
define("CUSLAN_3", "Valg");
define("CUSLAN_4", "Slett denne siden?");
define("CUSLAN_5", "Eksisterende sider");
define("CUSLAN_7", "Meny navn");
define("CUSLAN_8", "Tittel / Overskrift");
define("CUSLAN_9", "Tekst");
define("CUSLAN_10", "Tillat vurdering på siden");
define("CUSLAN_11", "Forside");
define("CUSLAN_12", "Lag side");
define("CUSLAN_13", "Tillat kommentarer");
define("CUSLAN_14", "Passordbeskytt siden");
define("CUSLAN_15", "skriv inn passord for å beskytte siden");
define("CUSLAN_16", "Lag en link under hovedlinkene");
define("CUSLAN_17", "skriv inn navnet på linken for å legge til");
define("CUSLAN_18", "Siden / linken er synlig for");
define("CUSLAN_19", "Oppdater side");
define("CUSLAN_20", "Lag side");
define("CUSLAN_21", "Oppdater meny");
define("CUSLAN_22", "Lag meny");
define("CUSLAN_23", "Rediger side");
define("CUSLAN_24", "Lag en ny side");
define("CUSLAN_25", "Rediger meny");
define("CUSLAN_26", "Lag en ny meny");
define("CUSLAN_27", "Siden ble lagret i databasen.");
define("CUSLAN_28", "Siden er nå slettet");
define("CUSLAN_29", "List opp sider dersom ingen side er valgt");
define("CUSLAN_30", "Hvor lenge skal cookien vare (i sekunder)");
define("CUSLAN_31", "Lag meny");
define("CUSLAN_32", "Konverter gamle sider/menyer");
define("CUSLAN_33", "Valg for side");
define("CUSLAN_34", "Begynnelse");
define("CUSLAN_35", "Ferdig med oppdatering av siden - oppdatert");
define("CUSLAN_36", "For å sette innstillinger for hver siden, vennligst returner til forsiden og rediger sidene.");
define("CUSLAN_37", "Oppdater spesialside");
define("CUSLAN_38", "på");
define("CUSLAN_39", "av");
define("CUSLAN_40", "Lagre innstillinger");

define("CUSLAN_41", "Vis skaper og dato informasjon");
define("CUSLAN_42", "Ingen sider er definert enda");
define('CUSLAN_43', 'meny uten tittel: ');
define('CUSLAN_44', 'side uten tittel');

?>