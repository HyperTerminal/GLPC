<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_check_user.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','Sjekk brukerdatabase');
define('LAN_CKUSER_02','Dette vil sjekke etter potensielle problemer i din brukerdatabase');
define('LAN_CKUSER_03','Dersom du har mange brukere, så kan det ta lang tid og du kan få en timeout');
define('LAN_CKUSER_04','Fortsett');
define('LAN_CKUSER_05','Sjekk etter duplikate login navn');
define('LAN_CKUSER_06','Velg funksjoner som skal utføres');
define('LAN_CKUSER_07','Duplikate brukernavn ble funnet');
define('LAN_CKUSER_08','Ingen duplikater ble funnet');
define('LAN_CKUSER_09','Brukernavn');
define('LAN_CKUSER_10','BrukerID');
define('LAN_CKUSER_11','Visningsnavn');
define('LAN_CKUSER_12','Sjekk etter duplikate e-post adresser');
define('LAN_CKUSER_13','Duplikate epost adresser ble funnet');
define('LAN_CKUSER_14','Epost addresse');
define('LAN_CKUSER_15','Ingen duplikater ble funnet');
define('LAN_CKUSER_16','Se etter oppføringer hvor noens brukernavn er det samme som login navnet');
define('LAN_CKUSER_17','Feil i brukernavn og login navn');
define('LAN_CKUSER_18','Bruker A');
define('LAN_CKUSER_19','Bruker B');
define('LAN_CKUSER_20','');

?>