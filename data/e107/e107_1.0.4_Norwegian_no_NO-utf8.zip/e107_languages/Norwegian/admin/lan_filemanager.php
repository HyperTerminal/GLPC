<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_filemanager.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "Opplastet");
define("FMLAN_2", "til");
define("FMLAN_3", "katalog");
define("FMLAN_4", "Den opplastede filen overskrider upload_max_filesize direktivet i php.ini.");
// define("FMLAN_5", "Den opplastede filen overstiger MAX_FILE_SIZE direktivet som ble spesifisert i html skjemaet.");
// define("FMLAN_6", "Den opplastede filen ble bare delvis lastet opp");
// define("FMLAN_7", "Ingen fil ble lastet opp");
// define("FMLAN_8", "Størrelse på den opplastede filen er 0 bytes");
// define("FMLAN_9", "Filen ble ikke lastet opp. Filnavn");
define("FMLAN_10", "Feil");
// define("FMLAN_11", "Sannsynligvis feil rettigheter på opplastingsmappen.");
define("FMLAN_12", "fil");
define("FMLAN_13", "filer");
define("FMLAN_14", "katalog");
define("FMLAN_15", "kataloger");
define("FMLAN_16", "Root katalog");
define("FMLAN_17", "Navn");
define("FMLAN_18", "Størrelse");
define("FMLAN_19", "Sist endret");

define("FMLAN_21", "Last opp fil til denne katalogen");
define("FMLAN_22", "Last opp");

define("FMLAN_26", "Slettet");
define("FMLAN_27", "korrekt");
define("FMLAN_28", "Kan ikke slette");
define("FMLAN_29", "Sti");
define("FMLAN_30", "Opp nivå");
define("FMLAN_31", "katalog");

define("FMLAN_32", "Velg katalog");
define("FMLAN_33", "Velg");
define("FMLAN_34", "Katalogvalg");
define("FMLAN_35", "Filer katalog");

define("FMLAN_36", "Katalog egne menyer");
define("FMLAN_37", "Katalog egne sider");

define("FMLAN_38", "Flyttet filen til");
define("FMLAN_39", "Kunne ikke flytte filen til");
define("FMLAN_40", "Katalog, nyhetsbilder");


define("FMLAN_43", "Slett valgte filer");


define("FMLAN_46", "Bekreft at du vil SLETTE de valgte filene.");
define("FMLAN_47", "Brukerens opplastninger");

define("FMLAN_48", "Flytt valgte til");
define("FMLAN_49", "Bekreft at du vil flytte de valgte filene.");
define("FMLAN_50", "Flytt");
define('FMLAN_51', 'Uidentifisert feil: ');




?>