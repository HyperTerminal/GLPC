<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_meta.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags oppdatert i databasen");
define("METLAN_2", "Skriv inn ekstra meta-tags");
define("METLAN_3", "Skriv inn ny meta tag innstilling");
define("METLAN_4", "Oppdatert");
define("METLAN_5", "skriv inn beskrivelsen her");
define("METLAN_6", "skriv, en, liste, over, dine, nøkkelord, her");
define("METLAN_7", "skriv inn copyright informasjonen her");
define("METLAN_8", "Meta Tags");

define("METLAN_9", "Beskrivelse");
define("METLAN_10", "Nøkkelord");
define("METLAN_11", "Copyright");
define("METLAN_12", "Bruk nyhetstittelen og sammendraget som meta-beskrivelse på nyhetssider.");
define("METLAN_13", "Forfatter");

?>