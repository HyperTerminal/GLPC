<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_emoticon.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("EMOLAN_1", "Uttrykksikon aktivering");
define("EMOLAN_2", "Navn");
define("EMOLAN_3", "Ikon");
define("EMOLAN_4", "Aktiver uttrykksikon?");

define("EMOLAN_5", "Bilde");
define("EMOLAN_6", "Kode");
define("EMOLAN_7", "separer flere koder med mellomrom");

define("EMOLAN_8", "Status");
define("EMOLAN_9", "Alternativ");
define("EMOLAN_10", "Aktiv");
define("EMOLAN_11", "Aktiver pakke");

define("EMOLAN_12", "Rediger/konfigurer denne pakken");
define("EMOLAN_13", "Installerte pakker");

define("EMOLAN_14", "Lagre konfigurasjon");
define("EMOLAN_15", "Rediger/konfigurer ikoner");
define("EMOLAN_16", "Konfigurasjonen er lagret");
define("EMOLAN_17", "Du har en ikonpakke som inneholder mellomrom, som ikke er tillatt!");
define("EMOLAN_18", "Venligst skift navn på tilfellene nedenfor slik at de ikke lenger inneholder mellomrom:");
define("EMOLAN_19", "Navn");
define("EMOLAN_20", "Plassering");
define("EMOLAN_21", "Feil");
//define("EMOLAN_2", "Navn");
define("EMOLAN_22", "Ny ikonpakke er funnet:");
define("EMOLAN_23", "Ny xml ikonpakke er funnet:");
define("EMOLAN_24", "Ny php ikonpakke er funnet:");
define("EMOLAN_25", "Installerer nye PHP ikoner: ");
define("EMOLAN_26", "Scan pakken på nytt");
define("EMOLAN_27", "En feil skjedde med å prosessere pakken: ");
define("EMOLAN_28", "Generer XML");
define("EMOLAN_29", "XML fil er nå generert: ");
define("EMOLAN_30", "Feil ved skriving av XML fil: ");
?>