<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_links.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LCLAN_1", "Alternativene er lagret");
define("LCLAN_2", "Link lagret til databasen.");
define("LCLAN_3", "Link oppdatert i databasen.");
// define("LCLAN_4", "Link slettet.");
define("LCLAN_6", "Rekkefølge oppdatert.");
define("LCLAN_8", "Eksisterende linker");
define("LCLAN_12", "Links rendertype");
define("LCLAN_15", "Navn");
define("LCLAN_16", "Link-URL");
define("LCLAN_17", "Beskrivelse av link");
define("LCLAN_18", "Knapp/Ikon på link");
define("LCLAN_19", "Åpning av link");
define("LCLAN_20", "Åpnes i samme vindu");
define("LCLAN_23", "Åpnes i nytt vindu");
define("LCLAN_24", "Åpnes i 600x400 minivindu");
define("LCLAN_25", "Gruppe linken skal gjelde for");
define("LCLAN_26", "Markering gjør linken synlig kun for brukere i denne klassen");
define("LCLAN_27", "Oppdater link");
define("LCLAN_28", "Opprett link");
define("LCLAN_29", "Linker");
define("LCLAN_30", "flytt opp");
define("LCLAN_31", "flytt ned");
define("LCLAN_39", "Vis bilder");
define("LCLAN_53", "Link");
define("LCLAN_54", "slettet");
define("LCLAN_58", "Er du sikker å at du vil slette denne linken?");
define("LCLAN_61", "Ingen linker");
define("LCLAN_62", "Linker hovedside");
define("LCLAN_63", "Opprett ny link");
define("LCLAN_68", "Linkalternativer");
define("LCLAN_78", "Vis beskrivelsen som tooltip");
define("LCLAN_79", "Beskrivelsen kommer til å vises når muspekeren holdes over linken");
define("LCLAN_80", "Aktiver utvidbare undermenyer");
define("LCLAN_81", "Undermenyer vises kun ved klikk på tittelen. (Tittelen er deaktivert)");
define("LCLAN_83", "Undermenygenerator");
define("LCLAN_88", "Alternativ for nettstedslinker");
define("LCLAN_89", "Bilde");

define("LCLAN_91", "Flytt");
define("LCLAN_95", "Klasse");

define("LCLAN_96", "Vises i ditt tema som");


define("LINKLAN_1", "Æpnes i 800x600 vindu");
define("LINKLAN_2", "Tittel");
define("LINKLAN_3", "Ingen tittel(Normal link)");
define("LINKLAN_4", "Underlinkgenerator");
define("LINKLAN_5", "Generer underlinker");
define("LINKLAN_6", "Opprett underlinker fra:");
define("LINKLAN_7", "Opprett underlinker under hvilken link?");
define("LINKLAN_8", "Nyhetskategorier");
define("LINKLAN_9", "Nedlastningskategorier");
define("LINKLAN_10", "Opprett underlink");

?>