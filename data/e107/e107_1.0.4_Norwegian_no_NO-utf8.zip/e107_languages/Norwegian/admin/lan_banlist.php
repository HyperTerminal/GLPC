<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_banlist.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Blokkering fjernet.");
define("BANLAN_2", "Ingen blokkeringer.");
define("BANLAN_3", "Eksisterende blokkeringer");
define("BANLAN_4", "Ta bort blokkering");
define("BANLAN_5", "Angi IP, epostadresse, eller server");
define("BANLAN_7", "Begrunnelse");
define("BANLAN_8", "Blokker bruker");
define("BANLAN_9", "Blokker bruker fra nettstedet");
define("BANLAN_10", "IP / Epost / Begrunnelse");
define("BANLAN_11", "Auto-blokkering: Flere enn 10 mislykkede innloggingsforsøk");
define("BANLAN_12", "Noter: Reverser DNS er for tiden slått av. Det må slåes på for å tillate banning av vert. Banning ved IP eller e-post fungerer fortsatt som vanlig.");
define("BANLAN_13", "Noter: For å banne en bruker med brukernavn, vennligst gå til administrasjonsdelen for medlemmer: ");
define('BANLAN_78','Hit count ble oversteget (--HITS-- spørringer innen tillatte tid)');

?>