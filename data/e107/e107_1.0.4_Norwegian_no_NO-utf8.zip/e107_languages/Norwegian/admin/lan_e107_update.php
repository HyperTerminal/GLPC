<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_e107_update.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Handling");
define("LAN_UPDATE_3", "Ikke nødvendig");

define("LAN_UPDATE_5", "Oppdatering er tilgjengelig");
define("LAN_UPDATE_7", "Utført");
define("LAN_UPDATE_8", "Oppdater fra");
define("LAN_UPDATE_9", "til");
define("LAN_UPDATE_10", "Tilgjengelig oppdateringer");
define("LAN_UPDATE_11", ".617 til .7 oppdatering ble fortsatt");
define("LAN_UPDATE_12", "En av dine tabeller inneholder duplikater.");


?>