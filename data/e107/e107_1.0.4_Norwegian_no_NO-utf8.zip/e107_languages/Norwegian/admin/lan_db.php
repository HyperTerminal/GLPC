<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_db.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kjerneinnstillinger kopiert til databasen.");
define("DBLAN_2", "Klikk på knappen for å lagre en kopi av e107 databasen din");
define("DBLAN_3", "Kopier SQL-databasen");
define("DBLAN_4", "Klikk på knappen for å kontrollera gyldigheten av e107 databasen din");
define("DBLAN_5", "Kontrollera databasens gyldighet ");
define("DBLAN_6", "Klikk på knappen for å optimere e107 databasen din");
define("DBLAN_7", "Optimer SQL-databasen");
define("DBLAN_8", "Klikk på knappen for å sikkerhetskopiere kjerneinnstillingene");
define("DBLAN_9", "Kopier kjerneinnstillingene");
define("DBLAN_10", "Databasverktøy");
define("DBLAN_11", "MySQL database");
define("DBLAN_12", "optimert");
define("DBLAN_13", "Tillbake");
define("DBLAN_14", "Klart");
define("DBLAN_15", "Klikk på knappen for å se om det finnes en DB oppdatering");
define("DBLAN_16", "Kontroller oppdateringer");
define("DBLAN_17", "Pref. Navn");
define("DBLAN_18", "Pref. Verdi");
define("DBLAN_19", "Trykk på kanppen for å åpne preferanseredaktøren (bare for avanserte brukere)");
define("DBLAN_20", "Preferanseredaktør");
define("DBLAN_21", "Sletting er valgt");
define("DBLAN_22", "Plugin: Se og Skann");
define("DBLAN_23", "Skann er fullført");
define("DBLAN_24", "Navn");
define("DBLAN_25", "Mappe");
define("DBLAN_26", "Inkludert add-ons");
define("DBLAN_27", "Installert");
define("DBLAN_28", "Trykk på kanppen for å skanne pluginmapper for forandringer");
define("DBLAN_29", "Skann pluginmapper");
define("DBLAN_30", " (hvis den viser en feil, se etter tegn på utsiden av PHP åpning og lukking taggene)");
define("DBLAN_31", "Pass");
define("DBLAN_32", "Feil");
define("DBLAN_33", "Kunne ikke åpne");
define("DBLAN_34", "Ikke sjekket");
define('DBLAN_35', 'Klikk på knappen for å validere brukertabell');
define('DBLAN_36', 'Sjekk brukertabell');


?>