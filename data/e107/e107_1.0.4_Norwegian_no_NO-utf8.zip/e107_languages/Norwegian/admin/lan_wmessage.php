<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_wmessage.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
// define("WMGLAN_1", "Melding for gjester");
// define("WMGLAN_2", "Melding for medlemmer");
// define("WMGLAN_3", "Melding for administratorer");
// define("WMGLAN_4", "Legg til");
// define("WMGLAN_5", "Sett velkomstmelding");
// define("WMGLAN_6", "Aktiver?");
// define("WMGLAN_7", "Innstillinger for velkomstmeldinger er aktivert");

define("WMLAN_00","Velkomstmeldinger");
define("WMLAN_01","Lag en ny melding");
define("WMLAN_02","Melding");
define("WMLAN_03","Synlighet");
define("WMLAN_04","Meldingstekst");

define("WMLAN_05","Ramm inn");
define("WMLAN_06","Hvis merket, så vil meldingen bli rammet inn i en boks");
define("WMLAN_07","For å kjøre over standard system, så kan du bruke {WMESSAGE} hurtigkoden:");
// define("WMLAN_08","Innstillinger");

define("WMLAN_09","Det er ikke satt noen velkomstmelding");
define("WMLAN_10","Tittel på melding");    

?>