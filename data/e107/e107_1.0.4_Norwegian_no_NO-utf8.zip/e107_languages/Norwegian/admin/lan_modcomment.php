<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_modcomment.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderert.");
define("MDCLAN_2", "Ingen kommentarer til dette");
define("MDCLAN_3", "Medlem");
define("MDCLAN_4", "Gjest");
define("MDCLAN_5", "fjern blokkering");
define("MDCLAN_6", "blokker");
define("MDCLAN_7", "godkjenn");
define("MDCLAN_8", "Moderer kommentarer");
define("MDCLAN_9", "Advarsel! Sletting av toppkommentarer sletter også alle svar!");
define("MDCLAN_10", "alternativer");
define("MDCLAN_11", "kommentar");
define("MDCLAN_12", "kommentarer");
define("MDCLAN_13", "blokkert");
define("MDCLAN_14", "les kommentarer");
define("MDCLAN_15", "Åpen");
define("MDCLAN_16", "låst");
define("MDCLAN_17", "Det er ingen kommentarer som venter på godkjenning for øyeblikket");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>