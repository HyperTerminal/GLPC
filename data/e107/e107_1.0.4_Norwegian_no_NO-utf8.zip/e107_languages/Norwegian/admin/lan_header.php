<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_header.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin Navigering");
define("LAN_head_2", "Din server tillater ikke HTTP fil opplastinger, så det vil ikke være mulig for dine brukere å laste opp avatarer/filer. For å fikse dette, sett file_uploads til On i fin php.ini og restart serveren. Om du ikke har tilgang til php.ini, kontakt hosten din.");
define("LAN_head_3", "Din server kjører med en basedir restriksjon med effekt. Dette gjør så det ikke er mulig å bruke filer utenom hjemmeområdet, og vil gjøre så ting som Filtyper ikke fungerer");

define("LAN_head_4", "Admin Området");

define("LAN_head_5", "språk som blir vist i admin området: ");
define("LAN_head_6", "Utvidelses info");

?>