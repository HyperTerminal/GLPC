<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/help/newspost.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Hjelp for posting av nyhet";
$text = "<b>Generell</b><br />
Tekst vil bli vist på hovedsiden; Utvidet vil komme frem ved å trykke på 'Les resten' linken.
<br />
<br />
<b>Vis bare tittelen</b>
<br />
Aktiver dette dersom du ønsker at det bare er tittelen som skal bli vist på forsiden, med en klikkbar link for å lese hele nyheten.
<br /><br />
<b>Aktiv mellom</b>
<br />
Dersom du setter en start og slutt dato, så vil nyheten bare bli vist under denne tidsperioden.
";
$ns -> tablerender($caption, $text);
?>