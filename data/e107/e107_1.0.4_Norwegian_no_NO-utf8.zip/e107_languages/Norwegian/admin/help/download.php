<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/help/download.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Vennligst last opp filene til ".e_FILE."downloads mappen, dine bilder til ".e_FILE."downloadimages mappen og miniatyrbilder til ".e_FILE."downloadthumbs mappen.
<br /><br />
For å legge til en nedlasting, lag først en hovedkategori, så lag en kategori under denne. Du kan så gjøre nedlastingen tilgjengelig.";
$ns -> tablerender("Nedlasting hjelp", $text);
?>