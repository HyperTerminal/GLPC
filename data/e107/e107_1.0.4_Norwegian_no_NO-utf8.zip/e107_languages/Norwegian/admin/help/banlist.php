<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/help/banlist.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Blokkere brukere fra siden din";
$text = "Fra denne siden kan du blokkere brukere fra å ha tilgang til siden din.<br />
Enten skriver du inne en fullstendig IP-adresse eller så bruker du et wildcard for angi et område av IP-adresser. Du kan også angi e-postadresser for å hildre at disse brukes til å registere seg på siden.<br /><br />
<b>Blokkere via IP-adresse:</b><br />
Skriver du inn IP-adressen 123.123.123.123 kommer det til å hindre personen med denne IP-adressen i å besøke siden din.<br />
Skriver du inn adressen 123.123.123.* istedet, kommer det til å hindre alle med IP-adresse fra 123.123.123.0 til 123.123.123.255 å besøke siden din.<br /><br />
<b>Blokkere via e-postadresse</b><br />
Om du Skriver inn e-postadressen foo@bar.com kan brukeren ikke regestrere seg på siden her med denne e-postadressen.<br />
Om du Skriver inn e-postadressen *@bar.com istedet, kan ingen brukere med epost fra domenet bar.com registrere seg på siden din.<br /><br />
<b>Blokkere via brukernavn</b><br />
Dette blir gjort fra administrasjonsdelen for brukere.";
$ns -> tablerender($caption, $text);
?>