<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_cache.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Cache System Status");
define("CACLAN_2", "Sett cache status");
define("CACLAN_3", "Cache System");
define("CACLAN_4", "Cache status er satt");
define("CACLAN_5", "Tøm Cache");
define("CACLAN_6", "Cache er tømt");

define("CACLAN_7", "Cache Deaktivert");
// define("CACLAN_8", "Cache data er lagret til MySQL");
define("CACLAN_9", "Cache data lagret til disk-fil");
define("CACLAN_10", "Cache mappen er ikke skrivbar. Vennligst se etter om mappen er satt til CHMOD 0777");
?>