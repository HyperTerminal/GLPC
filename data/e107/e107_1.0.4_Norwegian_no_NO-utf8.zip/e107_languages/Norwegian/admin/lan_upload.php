<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_upload.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("UPLLAN_1", "Opplastning fjernet fra listen.");
define("UPLLAN_2", "Innstillinger lagret i databasen");
define("UPLLAN_3", "Opplasting ID");

define("UPLLAN_5", "Poster");
define("UPLLAN_6", "Epost");
define("UPLLAN_7", "Nettsted");
define("UPLLAN_8", "Filnavn");

define("UPLLAN_9", "Versjon");
define("UPLLAN_10", "Fil");
define("UPLLAN_11", "Filstørrelse");
define("UPLLAN_12", "Skjermbilde");
define("UPLLAN_13", "Beskrivelse");
define("UPLLAN_14", "Demo");

define("UPLLAN_16", "kopier til nyhet");
define("UPLLAN_17", "fjern opplastning fra liste");
define("UPLLAN_18", "Vis detaljer");
define("UPLLAN_19", "Det finnes ingen umodererte offentlige opplastede filer");
define("UPLLAN_20", "Det");
define("UPLLAN_21", "umodererte offentlige opplastninger");
define("UPLLAN_22", "ID");
define("UPLLAN_23", "Navn");
define("UPLLAN_24", "Filtype");
define("UPLLAN_25", "Opplastninger aktivert?");
define("UPLLAN_26", "Ingen offentlige opplastninger tillates dersom deaktivert");
define("UPLLAN_27", "opplastinger som ikke er moderert");

define("UPLLAN_29", "Lagringstype");
define("UPLLAN_30", "Velg hvordan opplastede filer skal lagres, enten som normale filer på serveren eller som binær info i databasen<br /><b>OBS</b> binært passer bare for mindre filer under ca 500 kB");
define("UPLLAN_31", "Fil");
define("UPLLAN_32", "Binært");
define("UPLLAN_33", "Maksimal filstørrelse");
define("UPLLAN_34", "Maksimal filstørrelse i bytes - la stå tomt for å bruke innstillingen i php.ini ( php.ini er satt til");
define("UPLLAN_35", "Tillatte filtyper");
define("UPLLAN_36", "Angi en type pr rad");
define("UPLLAN_37", "Tillatelse");
define("UPLLAN_38", "Velg for å tillate kun visse brukere å laste opp");
define("UPLLAN_39", "Send");

define("UPLLAN_41", "NB - filopplastninger er deaktivert i php.ini, filer kommer vil ikke kunne lastes opp før du har satt det til On i php.ini.");

define("UPLLAN_42", "Handlinger");
define("UPLLAN_43", "Opplastninger");
define("UPLLAN_44", "Opplastning");

define("UPLLAN_45", "Er du sikker på at du vil slette følgende fil...");

define("UPLAN_COPYTODLM", "kopier til nedlastningshåndtereren");
define("UPLAN_IS", "er ");
define("UPLAN_ARE", "er ");
define("UPLAN_COPYTODLS", "Kopier til nedlastning");

define("UPLLAN_48", "Av sikkerhetshensyn har tillatte filtyper blitt flyttet ut fra databasen til en
tekstfil som finnes i adminkatalogen. For å bruke den, døp om filen e107_admin/filetypes_.php 
til e107_admin/filetypes.php og legg til en kommaseparert liste av filtype-endinger i filen. Du burde ikke tillate opplastning av .html, .txt, etc ettersom noen som angriper nettstedet ditt kan laste opp en fil av denne typen som inneholder farlige javascript. Du skal, selvfølgelig heller ikke
tillate opplastning av .php filer eller noen annen type kjørbare skript.");


?>