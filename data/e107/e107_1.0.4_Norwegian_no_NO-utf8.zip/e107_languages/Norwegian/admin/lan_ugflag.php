<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_ugflag.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define('UGFLAN_1', 'Innstillinger for vedlikehold er oppdatert');
define('UGFLAN_2', 'Aktivert vedlikeholdsflagget');
define('UGFLAN_3', 'Oppdater vedlikeholdtinnstillinger');
define('UGFLAN_4', 'Vedlikeholds innstillinger');

define('UGFLAN_5', 'Tekst som skal vises når nettsiden er stengt');
define('UGFLAN_6', 'La stå blank for å vise standard melding');

define('UGFLAN_8', 'Begrens tilgangen til bare administratorer');
define('UGFLAN_9', 'Begrens tilgangen til bare hoved administratorer');

?>