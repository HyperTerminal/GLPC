<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_updateadmin.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Feil - vennligst prøv igjen");
define("UDALAN_2", "Innstillinger er lagret");
define("UDALAN_3", "Innstillinger er oppdatert for");
define("UDALAN_4", "Navn");
define("UDALAN_5", "Passord");
define("UDALAN_6", "Gjenta passord");
define("UDALAN_7", "Endre passord");
define("UDALAN_8", "Passord er oppdatert for");

?>