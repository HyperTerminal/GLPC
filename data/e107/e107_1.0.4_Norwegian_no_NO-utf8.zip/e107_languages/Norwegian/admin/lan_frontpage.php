<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_frontpage.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Innstillinger for forsiden er nå oppdatert.");
define("FRTLAN_2", "Sett forside fir");
define("FRTLAN_6", "Linker");
define("FRTLAN_12", "Oppdater forside innstillinger");
define("FRTLAN_13", "Innstillinger for forsiden");
define("FRTLAN_15", "Annet (oppgi URL):");
define("FRTLAN_16", "Feil: ingen hovedinnholdstittel valgt");
define("FRTLAN_17", "Feil: ingen innholdsunderkategori valgt");
define("FRTLAN_18", "Feil: ingen innholdspost valgt");
define("FRTLAN_19", "hovedinnholdstittel");
define("FRTLAN_20", "innholdskategori");
define("FRTLAN_21", "innholdspost");
define("FRTLAN_22", "Custom Page");
define("FRTLAN_26", "Alle brukere");
define("FRTLAN_27", "Gjester");
define("FRTLAN_28", "Medlemmer");
define("FRTLAN_29", "Administratorer");
define("FRTLAN_31", "Alle brukere");
define("FRTLAN_32", "Brukerklasse");
define("FRTLAN_33", "Eksisterende instillinger");
define("FRTLAN_34", "Side");


?>