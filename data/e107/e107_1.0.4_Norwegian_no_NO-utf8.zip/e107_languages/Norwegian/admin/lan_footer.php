<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_footer.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Side");
define("FOOTLAN_2", "Hovedadministrator");
define("FOOTLAN_3", "Versjon");
define("FOOTLAN_4", "versjon");
define("FOOTLAN_5", "Admin tema");
define("FOOTLAN_6", "av");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Installasjonsdato");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP Versjon");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Side informasjon");
define("FOOTLAN_14", "Vis hjelp");
define("FOOTLAN_15", "Dokumentasjon");
define("FOOTLAN_16", "Database");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Hoveddesign");
define("FOOTLAN_19", "Gjeldene servertid");
define("FOOTLAN_20", "Sikkerhetsnivå");
?>