<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_db_verify.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kan ikke lese SQL-datafilen<br /><br />Forsikre deg om at filen <b>core_sql.php</b> finnes i <b>/admin/sql</b> katalogen.");
define("DBLAN_2", "Bekrefter alt");

define("DBLAN_4", "Tabell");
define("DBLAN_5", "Felt");
define("DBLAN_6", "Status");
define("DBLAN_7", "Notater");
define("DBLAN_8", "Stemmer ikke");
define("DBLAN_9", "Eksisterende");
define("DBLAN_10", "skal være");
define("DBLAN_11", "Felt mangler");
define("DBLAN_12", "Ekstra felt!");
define("DBLAN_13", "Tabell mangler!");
define("DBLAN_14", "Velg tabell(er) å validere");
define("DBLAN_15", "Start verifisering");
define("DBLAN_16", "SQL verifisering");
define("DBLAN_17", "Tilbake");
define("DBLAN_18", "tabeller");
define("DBLAN_19", "Prøver å fikse");
define("DBLAN_20", "Prøver å fikse tabellene");
define("DBLAN_21", "Fiks følgende objekter");
define("DBLAN_22", " er ikke lesbar");
?>