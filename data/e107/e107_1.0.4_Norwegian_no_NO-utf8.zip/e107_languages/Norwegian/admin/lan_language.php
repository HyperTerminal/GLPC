<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_language.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "kunne ikke opprettes. (Finnes allerede)");
define("LANG_LAN_01", "ble slettet(hvis eksisterende) og opprettet.");
define("LANG_LAN_02", "kunne ikke slettes");
define("LANG_LAN_03", "Tabeller");
define("LANG_LAN_05", "Ikke installert");
define("LANG_LAN_06", "Opprett tabeller");
define("LANG_LAN_07", "Slette eksisterende tabeller?");
define("LANG_LAN_08", "Erstatt eksisterende tabeller (alt datainnhold vil gå tapt).");
define("LANG_LAN_10", "Bekreft sletting");
define("LANG_LAN_11", "Slett ikke-markerte tabeller ovenfor (om de eksisterer).");
define("LANG_LAN_12", "Aktiver fler-språkstabeller");
define("LANG_LAN_13", "Flerspråkspreferanser");
define("LANG_LAN_14", "Nettstedets standardspråk");
define("LANG_LAN_15", "Marker for å kopiere data fra standardspråket.(nyttig for linker, nyhetskategorier etc)");
define("LANG_LAN_16", "Multi-språklig databasebruk");
define("LANG_LAN_17", "Gjeldende språk - Ingen ekstra tabeller trengs.");
define("LANG_LAN_18", "Bruk parkerte Underdomener for å sette språk.");
define("LANG_LAN_19", "eks. se.mittdomene.com for å sette språket til Svensk.");
define("LANG_LAN_20", "Skriv inne hoveddomenet for å muliggjøre eks mittdomene.com");
define("LANG_LAN_21", "Språkverktøy");
define("LANG_LAN_23", "Lag en språkpakke (zip)");
define("LANG_LAN_24", "Generer");
define("LANG_LAN_AGR", "Merk: Ved å bruke disse verktøyene, så godtar du å dele din(e) språkpakke(r) med e107 samfunnet.");
define("LANG_LAN_EML", "Vennligst send din språkpakke til:");
define("LANG_LAN_25", "Vennligst verifiser at CORE_LC og CORE_LC2 har verdier i [lcpath] og prøv igjen.");
define("LANG_LAN_26", "Vennligst se til at du bruker standard mappestruktur i e107_config.php (f.eks. 'e107_languages/', 'e107_plugins/' etc.) og prøv igjen.");
define("LANG_LAN_27", "Vennligst verifiser din språkpakke ('Verify') og prøv igjen.");
define("LANG_LAN_28", "Merk av i denne boksen om du er en [e107 certified translator].");
define("LANG_LAN_29", "Du burde rette opp i de resterende feilene før du sender inn din språkpakke.");
define("LANG_LAN_30", "Lanseringsdato");
define("LANG_LAN_31", "Kompitabilitet");
define("LANG_LAN_32", "Installerte språk");
define("LANG_LAN_33", "Vis kun feilmeldinger under verifiseringen");
define("LANG_LAN_34", "Vennligst verifiser og rett opp de gjennstående [x] feil(ene) før du forsøker å lage en ny språkpakke.");


?>