<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_notify.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Varsle");
define("NT_LAN_2", "Motta epostvarsling ved");
define("NT_LAN_3", "Deaktivert");
define("NT_LAN_4", "Hoved administrator");
define("NT_LAN_5", "Gruppe");
define("NT_LAN_6", "Epost");
define("NU_LAN_1", "Medlemshendelser");
define("NU_LAN_2", "Medlemsregistrering");
define("NU_LAN_3", "Medlemsverifisering");
define("NU_LAN_4", "Medlem logger inn");
define("NU_LAN_5", "Medlem logger ut");
define("NS_LAN_1", "Sikkerhetshendelser");
define("NS_LAN_2", "IP bannet for å floode siden");
define("NN_LAN_1", "Nyhetshendelser");
define("NN_LAN_2", "Nyhet sendt inn av medlem");
define("NN_LAN_3", "Nyhet postet av en admin");
define("NN_LAN_4", "Nyhet redigert av en admin");
define("NN_LAN_5", "Nyhet slettet av en admin");
define("NF_LAN_1", "Filhendelser");
define("NF_LAN_2", "Fil er lastet opp av et medlem");
define("CM_LAN_1", "Kommentar hendelser");
define("CM_LAN_2", "Kommentar postet av bruker som venter på godkjenning");


?>