<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_message.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Mottatte meldinger");
define("MESSLAN_2", "Slett melding");
define("MESSLAN_3", "Meldingen ble slettet.");
define("MESSLAN_4", "Slett ALLE meldinger");
define("MESSLAN_5", "Godkjenn");
define("MESSLAN_6", "ALLE meldingene ble nå slettet.");
define("MESSLAN_7", "Ingen meldinger.");
define("MESSLAN_8", "Meldingstype");
define("MESSLAN_9", "Rapportert den");

define("MESSLAN_10", "Sendt inn av");
define("MESSLAN_11", "åpner i et nytt vindu");
define("MESSLAN_12", "Melding");
define("MESSLAN_13", "Link");


?>