<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_admin_log.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Logg");
define("LAN_ADMINLOG_1", "Dato");
define("LAN_ADMINLOG_2", "Tittel");
define("LAN_ADMINLOG_3", "Beskrivelse");
define("LAN_ADMINLOG_4", "Bruker IP");
define("LAN_ADMINLOG_5", "Bruker ID");
define("LAN_ADMINLOG_6", "Informativ Ikon");
define("LAN_ADMINLOG_7", "Informativ melding");
define("LAN_ADMINLOG_8", "Varsel Ikon");
define("LAN_ADMINLOG_9", "Varsel Melding");
define("LAN_ADMINLOG_10", "Advarselsikon");
define("LAN_ADMINLOG_11", "Advarselsmelding");
define("LAN_ADMINLOG_12", "Kritisk ikon");
define("LAN_ADMINLOG_13", "Kritisk feilmelding");

?>