<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_userclass2.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Ta bort alle brukere fra gruppen.");
define("UCSLAN_2", "Gruppebrukere har blitt oppdatert.");
define("UCSLAN_3", "Gruppen er slettet.");
define("UCSLAN_4", "Merk av i boksen for å godkjenne at gruppen skal bli slettet");
define("UCSLAN_5", "Gruppe oppdatert.");
define("UCSLAN_6", "Gruppen er nå lagret i databasen.");
define("UCSLAN_7", "Enda ingen brukergrupper.");
define("UCSLAN_8", "Eksisterende grupper");
define("UCSLAN_11", "merk av for å godkjenne");
define("UCSLAN_12", "Gruppenavn");
define("UCSLAN_13", "Beskrivelse");
define("UCSLAN_14", "Oppdater gruppen");
define("UCSLAN_15", "Lag en ny gruppe");
define("UCSLAN_16", "Legg til brukere i gruppen");
define("UCSLAN_17", "Ta bort");
define("UCSLAN_18", "Rens gruppen");
define("UCSLAN_19", "Legg til brukere til");
define("UCSLAN_20", "gruppe");
define("UCSLAN_21", "Gruppe innstillinger");
define("UCSLAN_22", "Brukere - klikk for å fjerne ...");
define("UCSLAN_23", "Brukere i denne klassen ...");
define("UCSLAN_24", "Hvem kan endre på klassen");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Brukernavn");
define("UCSLAN_27", "Returner");


?>