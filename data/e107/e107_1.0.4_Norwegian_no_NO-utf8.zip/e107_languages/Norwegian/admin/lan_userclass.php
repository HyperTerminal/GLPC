<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/admin/lan_userclass.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Send en varsel e-post til");
define("UCSLAN_2", "Oppdatert privelegier");
define("UCSLAN_3", "Kjære");
define("UCSLAN_4", "Dine privelegier har blitt oppdatert hos");
define("UCSLAN_5", "Du har nå tilgang til følgende område(r)");
define("UCSLAN_6", "Sett gruppe for bruker");
define("UCSLAN_7", "Sett grupper");
define("UCSLAN_8", "Si ifra til bruker");
define("UCSLAN_9", "Brukergrupper er oppdatert.");
define("UCSLAN_10", "Hilsen,");
define('UCSLAN_12', 'Bare medlemsprivelegier');

?>