<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_top.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "Flest poster i forumet");
define("TOP_LAN_1", "Brukernavn");
define("TOP_LAN_2", "Poster");
define("TOP_LAN_3", "Flest kommentarer postet");
define("TOP_LAN_4", "Kommentarer");
define("TOP_LAN_5", "Flest poster i chatboksen");
define("TOP_LAN_6", "Rangering");

//v.616
define("LAN_1", "Tråd");
define("LAN_2", "Forfatter");
define("LAN_3", "Visninger");
define("LAN_4", "Svar");
define("LAN_5", "Siste innlegg");
define("LAN_6", "Tråder");
define("LAN_7", "Mest aktive tråder");
define("LAN_8", "Topp Postere");


?>