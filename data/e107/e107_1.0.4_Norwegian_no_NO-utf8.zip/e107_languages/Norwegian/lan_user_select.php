<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_user_select.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "Velg bruker");
define("US_LAN_2", "Velg brukergruppe");
define("US_LAN_3", "Alle brukere");
define("US_LAN_4", "Finn brukernavn");
define("US_LAN_5", "Bruker(e) funnet");
define("US_LAN_6", "Søk");
?>