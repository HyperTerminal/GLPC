<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_date.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "år");
define("LANDT_02", "måned");
define("LANDT_03", "uke");
define("LANDT_04", "dag");
define("LANDT_05", "time");
define("LANDT_06", "minutt");
define("LANDT_07", "sekund");
define("LANDT_01s", "år");
define("LANDT_02s", "måneder");
define("LANDT_03s", "uker");
define("LANDT_04s", "dager");
define("LANDT_05s", "timer");
define("LANDT_06s", "minutter");
define("LANDT_07s", "sekunder");

define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "sek");
define("LANDT_09s", "seks");
define("LANDT_AGO", "siden");


?>