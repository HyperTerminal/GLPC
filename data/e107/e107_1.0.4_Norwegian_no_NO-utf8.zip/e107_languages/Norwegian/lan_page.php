<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Norwegian/lan_page.php,v $
|     $Revision: 20 $
|     $Date: 2010-05-02 20:10:28 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Listing av sider er deaktivert");
define("LAN_PAGE_2", "Det er ingen sider");
define("LAN_PAGE_3", "Siden du prøvde å nå eksisterer ikke");
define("LAN_PAGE_4", "Gi denne siden er karakter");
define("LAN_PAGE_5", "Takk for at du ga denne siden en karakter");
define("LAN_PAGE_6", "Du har ikke tilgang til å se denne siden");
define("LAN_PAGE_7", "Feil passord");
define("LAN_PAGE_8", "Passordbeskyttet side");
define("LAN_PAGE_9", "Passord");
define("LAN_PAGE_10", "Send");
define("LAN_PAGE_11", "Side liste");
define("LAN_PAGE_12", "Ugyldig side");
define("LAN_PAGE_13", "Side");

?>