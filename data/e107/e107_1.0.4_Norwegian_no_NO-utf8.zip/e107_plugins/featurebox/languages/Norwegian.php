<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Norwegian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/featurebox/languages/Norwegian.php $
|        $Revision: 1.0 $
|        $Id: 2012/08/06 10:23:43 $
|        $Author: John-Arild Foss $
+---------------------------------------------------------------+
*/
define("FBLAN_01", "Funksjonsboks");
define("FBLAN_02", "Med dette programtillegget kan du vise en boks over dine nyheter med funksjoner / hva du ønsker i den. Meldingene kan enten komme tilfeldig eller dynamisk falmet.");
define("FBLAN_03", "Konfigurer funksjonsboks");
define("FBLAN_04", "Funksjonsboksen har blitt innstallert. For å legge til og konfigurere, gå tilbake til hoved administrasjons siden og klikk på funksjonsboks ikonet i utvidelses seksjonen.");
define("FBLAN_05", "Det finnes ikke noen beskjed i funsjonsboksen enda.");
define("FBLAN_06", "Eksisterende Funksjonsboks beskjed");
define("FBLAN_07", "Tittel / Bildetekst");
define("FBLAN_08", "Beskjed tekst");
define("FBLAN_09", "Beskjedens synlighet");
define("FBLAN_10", "Opprett Funksjonsboks beskjed");
define("FBLAN_11", "Oppdater Funksjonsboks beskjed");
define("FBLAN_12", "Modus");
define("FBLAN_13", "Tilfeldige meldinger");
define("FBLAN_14", "Vis kun denne beskjeden");
define("FBLAN_15", "Beskjeden er lagt til databasen.");
define("FBLAN_16", "Beskjeden er oppdatert i databasen.");
define("FBLAN_17", "Felt(er) som er tomme");
define("FBLAN_18", "Funksjonsboks beskjed ble slettet");
define("FBLAN_19", "Valg");
define("FBLAN_20", "Rediger");
define("FBLAN_21", "Slett");
define("FBLAN_22", "Gjengivelsestype");
define("FBLAN_23", "I tema boks");
define("FBLAN_24", "Enkel");
define("FBLAN_25", "Mal");
define("FBLAN_26", "du kan bruke en annen mal for hver melding, legg til maler i e107_plugins/featurebox/templates / mappe");


?>