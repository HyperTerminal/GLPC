<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Reklame");
define("BANNER_MENU_L2", "Konfugurasjon av banner meny er lagret");

//v.617
define("BANNER_MENU_L3", "Tittel");
define("BANNER_MENU_L4", "Kampanje");
define("BANNER_MENU_L5", "Bannermeny konfigurasjon");
define("BANNER_MENU_L6", "hvilket kampanjer skal vises i menyen");
define("BANNER_MENU_L7", "tilgjengelige kampanjer");
define("BANNER_MENU_L8", "valgte kampanjer");
define("BANNER_MENU_L9", "fjern valg");
define("BANNER_MENU_L10", "hvordan skal de valgte kampanjene bli vist ?");
define("BANNER_MENU_L11", "velg render type ...");
define("BANNER_MENU_L12", "en kampanje i en meny");
define("BANNER_MENU_L13", "alle valgte kampanjer i en meny");
define("BANNER_MENU_L14", "alle valgte kampanjer i separate menyer");
define("BANNER_MENU_L15", "hvor mange bannere skal bli vist ?");
define("BANNER_MENU_L16", "denne innstillingen vil bare bli brukt sammen med valg 2 og 3.<br />dersom det er mindre ant. bannere tilgjengelig, så vil maks antallet bli brukt.");
define("BANNER_MENU_L17", "sett antall ...");
define("BANNER_MENU_L18", "Oppdater innstillinger");

?>