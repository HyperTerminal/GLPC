<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Opprettelse av PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Denne utvidelsen er nå klar til bruk.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF-innstillinger");
define("PDF_LAN_3", "aktivert");
define("PDF_LAN_4", "deaktivert");
define("PDF_LAN_5", "Venstremarg ");
define("PDF_LAN_6", "Høyremarg ");
define("PDF_LAN_7", "Toppmarg ");
define("PDF_LAN_8", "Font");
define("PDF_LAN_9", "Standard fontstørrelse");
define("PDF_LAN_10", "Fontstørrelse nettstedsnavn");
define("PDF_LAN_11", "Fontstørrelse sideurl");
define("PDF_LAN_12", "Fontstørrelse sidenummer");
define("PDF_LAN_13", "Vis logo på pdf?");
define("PDF_LAN_14", "Vis nettstedsnavn på pdf?");
define("PDF_LAN_15", "Vis oppretters sideurl på pdf?");
define("PDF_LAN_16", "Vis sidenummer på pdf?");
define("PDF_LAN_17", "Oppdater");
define("PDF_LAN_18", "PDF innstillinger lagret");
define("PDF_LAN_19", "Side");
define("PDF_LAN_20", "Feilrapportering");

?>