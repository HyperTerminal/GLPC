<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_menu/languages/Norwegian.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "Gjester: ");
define("ONLINE_L2", "Medlemmer: ");
define("ONLINE_L3", "På denne siden: ");
define("ONLINE_L4", "Pålogget");
define("ONLINE_L5", "Medlemmer");
define("ONLINE_L6", "Nyeste");
define("TRACKING_MESSAGE", "Sporing av påloggede brukere er for tiden deaktivert, vennligst aktiver det [link=".e_ADMIN."users.php?options]herfra[/link][br]");   
?>