<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Nyheter for");
define("BLOGCAL_L2", "Arkiv");
define("BLOGCAL_D1", "Man");
define("BLOGCAL_D2", "Tirs");
define("BLOGCAL_D3", "Ons");
define("BLOGCAL_D4", "Tor");
define("BLOGCAL_D5", "Fre");
define("BLOGCAL_D6", "Lør");
define("BLOGCAL_D7", "Søn");
define("BLOGCAL_M1", "Januar");
define("BLOGCAL_M2", "Februar");
define("BLOGCAL_M3", "Mars");
define("BLOGCAL_M4", "April");
define("BLOGCAL_M5", "Mai");
define("BLOGCAL_M6", "Juni");
define("BLOGCAL_M7", "Juli");
define("BLOGCAL_M8", "August");
define("BLOGCAL_M9", "September");
define("BLOGCAL_M10", "Oktober");
define("BLOGCAL_M11", "November");
define("BLOGCAL_M12", "Desember");
define("BLOGCAL_1", "Nyhetsemner");
define("BLOGCAL_CONF1", "Måneder/rad");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "Oppdater menyinnetillingene");
define("BLOGCAL_CONF4", "BlogCal menykonfigurasjon");
define("BLOGCAL_CONF5", "BlogCal menykonfigurasjon lagret");
define("BLOGCAL_ARCHIV1", "Velg arkiv");


?>