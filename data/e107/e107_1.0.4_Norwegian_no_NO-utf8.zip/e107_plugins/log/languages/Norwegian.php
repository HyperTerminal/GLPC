<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/log/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Statistikk");

define("ADSTAT_L1", "Denne plugin'en kommer til å logge alle besøk på nettstedet og bygge detaljerte statistikkbilder basert på den innsamlede informasjonen.");
define("ADSTAT_L2", "Statistikkloggingen er innstallert. For å konvertere eksisterende statistikk til det nye systemet, <a href='".e_PLUGIN."log/update_routine.php'>klikk her</a> for å kjøre oppdateringsrutinen.");
define("ADSTAT_L3", "Statistikklogging");
define("ADSTAT_L4", "Du har ikke tillatelse til å se siden.");
define("ADSTAT_L5", "Funksjonene på denne siden er blitt deaktivert.");
define("ADSTAT_L6", "Nettsidestatistikk");
define("ADSTAT_L7", "Statistikk for denne typen samles ikke inn.");
define("ADSTAT_L8", "Dagens statistikk");
define("ADSTAT_L9", "All tids statistikk");
define("ADSTAT_L10", "Daglig statistikk");
define("ADSTAT_L11", "Månedlig statistikk");
define("ADSTAT_L12", "Webleserstatistikk");
define("ADSTAT_L13", "Operativsystemstatistikk");
define("ADSTAT_L14", "Domenestatistikk");
define("ADSTAT_L15", "Skjermoppløsning/Fargedybdestatistikk");
define("ADSTAT_L16", "Henvisningsstatistikk");
define("ADSTAT_L17", "Søkestrengstatistikk");
define("ADSTAT_L18", "Nyeste besøkere");
define("ADSTAT_L19", "Side");
define("ADSTAT_L20", "Besøk i dag");
define("ADSTAT_L21", "Totalt");
define("ADSTAT_L22", "Unike");
define("ADSTAT_L23", "Besøk totalt");
define("ADSTAT_L24", "Totalt unike besøk");
define("ADSTAT_L25", "Ingen statistikk enda.");
define("ADSTAT_L26", "Webblesere");
define("ADSTAT_L27", "Operativsystem");
define("ADSTAT_L28", "Land / Domener");
define("ADSTAT_L29", "Skjermoppløsning");
define("ADSTAT_L30", "Nettstedshenvisninger");
define("ADSTAT_L31", "Søkemotor søkestrenger");
define("ADSTAT_L32", "Henvist fra");
define("ADSTAT_L33", "Besøk siste");
define("ADSTAT_L34", "Besøk");
define("ADSTAT_L35", "Unike besøk siste");
define("ADSTAT_L36", "dager pr side");
define("ADSTAT_L37", "Besøk pr måned");
define("ADSTAT_L38", "Unike besøk pr måned");
define("ADSTAT_L39", "fjern denne posten");
define("ADSTAT_L40", "dager");
define("ADSTAT_L41", "Feil");
define("ADSTAT_L42", "Ingen månendlig statistikk enda.");

define("ADSTAT_L43", "Sidefeil i dag");
define("ADSTAT_L44", "All-tid Sidefeil");
define("ADSTAT_L45", "Statistikk er slettet for: ");
define("ADSTAT_L46", "Noter: stastistikk for i dag vil ikke bli slettet");
define("ADSTAT_L47", "Ingen statistikk ble funnet for: ");
define("ADSTAT_L48", "");
define("ADSTAT_L49", "");
define("ADSTAT_L50", "");

?>