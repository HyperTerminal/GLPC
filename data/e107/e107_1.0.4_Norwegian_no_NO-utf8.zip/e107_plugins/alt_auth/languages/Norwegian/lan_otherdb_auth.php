<?php/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/alt_auth/lan_otherdb_auth,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("OTHERDB_LAN_1", "Databasetype:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Brukernavn:");
define("OTHERDB_LAN_4", "Passord:");
define("OTHERDB_LAN_5", "Database");
define("OTHERDB_LAN_6", "Tabell");
define("OTHERDB_LAN_7", "Brukernavnfelt:");
define("OTHERDB_LAN_8", "Passordfelt:");
define("OTHERDB_LAN_9", "Passordmetode:");
define("OTHERDB_LAN_10", "Konfigurer otherdb autorisasjon");
define("OTHERDB_LAN_11", "** Følgende felt er ikke nødvendige ved bruk av en e107database");

?>