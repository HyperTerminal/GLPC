<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/alt_auth/lan_alt_auth_conf.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LAN_ALT_2", "Oppdater innstillinger");
define("LAN_ALT_3", "velg alternativ autoriseringsrtype");
define("LAN_ALT_4", "Konfigurer parametre for");
define("LAN_ALT_5", "Konfigurer autorisasjonsparametre");
define("LAN_ALT_6", "Tilkobling feilet");
define("LAN_ALT_7", "Om tilkoblig til alternativ autorisasjon feilet, hvordan skal dette hånteres?");
define("LAN_ALT_8", "Bruker ble ikke funnet");
define("LAN_ALT_9", "Om brukernavn ikke blir funnet ved bruk av alternativ autorisasjon, hvordan skal dette hånteres?");
define("LAN_ALT_10", "Logg inn feilet");
define("LAN_ALT_11", "Bruk e107 bruker tabell");
define("LAN_ALT_PAGE", "Alternativ godkjenning");


?>