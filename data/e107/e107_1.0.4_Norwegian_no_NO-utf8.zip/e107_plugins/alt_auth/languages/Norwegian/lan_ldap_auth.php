<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/alt_auth/lan_ldap_auth.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("LDAPLAN_1", "Serveradresse");
define("LDAPLAN_2", "BaseDN eller domene<br />Om LDAP - Skriv baseDN<br />Om AD - Skriv domene");
define("LDAPLAN_3", "LDAP Browser bruker<br />Full context oav bruker som er i stand til å søke i mappen.");
define("LDAPLAN_4", "LDAP Browsepassord<br />Passord for LDAP browserbruker.");
define("LDAPLAN_5", "LDAP Version");
define("LDAPLAN_6", "Konfigurer LDAP auth");
define("LDAPLAN_7", "eDirectory søkefilter:");
define("LDAPLAN_8", "dette vil bli brukt for å forsikre at brukernavnet er i rett tre, <br />eks: '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Gjeldende søkefilter vil bli:");
define("LDAPLAN_10", "Innstillinger er oppdatert");
define("LDAPLAN_11", "ADVARSEL: Det ser ut til at Idapmodulen ikke er tilgjengelig for øyeblikket.Å sette autentikasjonsmetode til LDAP vil sansynligvis ikke virke.");
define("LDAPLAN_12", "Servertype");
define("LDAPLAN_13", "Oppdater innstillinger");
?>