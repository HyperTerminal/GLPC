<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CM_L1", "Ingen kommentarer enda.");
define("CM_L2", "");
define("CM_L3", "Overskrift");
define("CM_L4", "Antall kommentarer å vise?");
define("CM_L5", "Antall tegn å vise?");
define("CM_L6", "Postfiks for for lange kommentarer?");
define("CM_L7", "Vis originaltittel i meny?");
define("CM_L8", "Konfigurasjon for nye kommentarer");
define("CM_L9", "Oppdater menyinnstillinger");
define("CM_L10", "Kommentarmenykonfigurasjon lagret");
define("CM_L11", "på");
define("CM_L12", "Sv:");
define("CM_L13", "Postet av");

?>