<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/tree_menu/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "Konfigurer meny for nettsted tre");
define("TREE_L2", "Oppdater innstillinger");
define("TREE_L3", "Konfigureringen er lagret.");
define("TREE_L4", "Den");
define("TREE_L5", "Av");
define("TREE_L6", "CSSklasse som brukes for linker som ikke kan åpnes.");
define("TREE_L7", "CSSklasse som brukes for linker som kan åpnes");
define("TREE_L8", "CSSklasse for åpnede linker");
define("TREE_L9", "Bruk mellomromklasse mellom hovedlinker");

?>