<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/login_menu/languages/Norwegian.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("LOGIN_MENU_L1", "Brukernavn: ");
define("LOGIN_MENU_L2", "Passord: ");
define("LOGIN_MENU_L3", "Registrer");
define("LOGIN_MENU_L4", "Glemt passord?");
define("LOGIN_MENU_L5", "Velkommen");
define("LOGIN_MENU_L6", "Husk meg");
define("LOGIN_MENU_L7", "Brukeridentiteten ble ikke gjenkjent(mulig ødelagt cockie).<br />Vennligst <a href=\"".e_BASE."index.php?logout\">klikk her</a> for å slette den.");
define("LOGIN_MENU_L8", "Logg ut");
define("LOGIN_MENU_L9", "Feil");
define("LOGIN_MENU_L10", "Vedlikeholdsflagget er satt til aktivt - dette betyr at besøkene vil bli sendt videre til sitedown.php. For å skru av dette, vennligst gå til admin/vedlikehold.");
define("LOGIN_MENU_L11", "Admin området");
define("LOGIN_MENU_L12", "Innstillinger");
define("LOGIN_MENU_L13", "Profil");
define("LOGIN_MENU_L14", "nyhet");
define("LOGIN_MENU_L15", "nyheter");
define("LOGIN_MENU_L16", "post i chatboksen");
define("LOGIN_MENU_L17", "poster i chatboksen");
define("LOGIN_MENU_L18", "kommentar");
define("LOGIN_MENU_L19", "kommentarer");
define("LOGIN_MENU_L20", "forum post");
define("LOGIN_MENU_L21", "forum poster");
define("LOGIN_MENU_L22", "nytt medlem");
define("LOGIN_MENU_L23", "nye medlemmer");
define("LOGIN_MENU_L24", "Klikk her for å se listen over nye ting");
define("LOGIN_MENU_L25", "Siden ditt siste besøk, så har det blitt");
define("LOGIN_MENU_L26", "nå");
define("LOGIN_MENU_L27", "og");
define("LOGIN_MENU_L28", "Logg inn");

define("LOGIN_MENU_L29", "ny artikkel");
define("LOGIN_MENU_L30", "nye artikler");

// New config options
define('LOGIN_MENU_L31', 'Vis nye nyheter');
define('LOGIN_MENU_L32', 'Vis nye artikler');
define('LOGIN_MENU_L33', 'Vis nye poster i chatboksen');
define('LOGIN_MENU_L34', 'Vis nye kommentarer');
define('LOGIN_MENU_L35', 'Vis nye forumposter');
define('LOGIN_MENU_L36', 'Vis nye medlemmer');


define('LOGIN_MENU_L39', 'Forlat admin området');
define("LOGIN_MENU_L40", "Send aktiverings e-post på nytt");
define("LOGIN_MENU_L41", "Innstillinger for innloggingsmenyen");

?>