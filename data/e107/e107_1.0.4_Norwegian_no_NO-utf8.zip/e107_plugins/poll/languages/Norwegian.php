<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/poll/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("POLL_ADLAN01", "Avstemning");
define("POLL_ADLAN02", "Denne utvidelsen lar deg lage en avstemning enten i forumet eller i menyen");
define("POLL_ADLAN03", "Konfigurer avstemning");
define("POLL_ADLAN04", "Utvidelsen er nå installert. For å legge til avstemninger, klikk på stemmegivningsikonet i utvidelsesseksjonen på admins førsteside, og husk å aktivere menyobjektet fra menysiden din.");

define("POLL_ADLAN05", "Hovedavstemning: ");
define("POLL_ADLAN06", "Forum Tråd: ");
define("POLL_ADLAN07", "Type");

define("POLLAN_MENU_CAPTION", "Avstemning");

define("POLLAN_1", "Åpne avstemninger");
define("POLLAN_2", "Opprett/endre avstemninger");
define("POLLAN_3", "Avstemningsspørsmål");
define("POLLAN_4", "Alternativ");
define("POLLAN_5", "Endre");
define("POLLAN_6", "Slett");
define("POLLAN_7", "Foreløpig ingen avstemninger.");
define("POLLAN_8", "Legg til alternativ");
define("POLLAN_9", "Tillat flere alternativ?");
define("POLLAN_10", "Ja");
define("POLLAN_11", "Nei");
define("POLLAN_12", "Vis resultat");
define("POLLAN_13", "etter stemmegivning");
define("POLLAN_14", "ved å klikke på vis-resultat-linken - kommentarer må være aktivert for å benytte dette alternativet");
define("POLLAN_15", "Tillat stemmegivning i denne avstemningen");
define("POLLAN_16", "Stemmegivningsmetode");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP-adresse");
define("POLLAN_19", "BrukerID(kun medlemmer kan stemme)");
define("POLLAN_20", "Tillat kommentarer til denne avstemningen?");
define("POLLAN_21", "Forhåndsvis igjen");
define("POLLAN_22", "Oppdater avstemning");
define("POLLAN_23", "Opprett avstemning");
define("POLLAN_24", "Forhåndsvisning");
define("POLLAN_25", "Tøm skjema");
define("POLLAN_26", "stemmer");
define("POLLAN_27", "kommentarer");
define("POLLAN_28", "Tidligere avstemninger");
define("POLLAN_29", "postet av");
define("POLLAN_30", "Send");
define("POLLAN_31", "stemmer");
define("POLLAN_32", "Klikk her for å se resultatet");
define("POLLAN_33", "Ingen tidligere avstemninger.");
define("POLLAN_34", "Tittel");
define("POLLAN_35", "Postet av");
define("POLLAN_36", "Aktiv");
define("POLLAN_37", "aktivere fra");
define("POLLAN_38", "til");
define("POLLAN_39", "Takk for din stemme!");
define("POLLAN_40", "Klikk her for å se resultatene");
define("POLLAN_41", "Denne avstemningen er kun for medlemmer");
define("POLLAN_42", "Denne avstemningen er kun for administratorer");
define("POLLAN_43", "Du har ikke tillatelse til å stemme i denne avstemningen");
define("POLLAN_44", "Slett denne avstemningen?");
define("POLLAN_45", "Avstemningen er oppdatert");
define("POLLAN_46", "Felt(er) er blanke");

?>