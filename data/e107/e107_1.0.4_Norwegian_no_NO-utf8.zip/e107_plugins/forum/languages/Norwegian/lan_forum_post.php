<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Norwegian/lan_forum_post.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum");

define("LAN_01", "Forum");
define("LAN_02", "Svarer til: ");
define("LAN_03", "Ny tråd");
define("LAN_1", "Normal");
define("LAN_2", "Klistret");
define("LAN_3", "Kunngjøring");
define("LAN_4", "Post avstemning");
define("LAN_5", "Avstemningsspørsmål");
define("LAN_6", "Legg til ett alternativ til");
define("LAN_7", "Avstemningsvalg:");
define("LAN_8", "Tillat alle å stemme");
define("LAN_9", "Tillat kun medlemmer å stemme");
define("LAN_10", "Logg inn");
define("LAN_11", "Husk meg");
define("LAN_16", "Brukernavn: ");
define("LAN_17", "Passord: ");
define("LAN_20", "Feil");
define("LAN_27", "Du lot et obligatorisk felt stå tomt");
define("LAN_28", "Du postet ingenting...");
define("LAN_29", "Endret");
define("LAN_45", "Kun registrerte og innloggede medlemmer kan poste i dette forumet, klikk");
define("LAN_60", "Start ny tråd");
define("LAN_61", "Ditt navn: ");
define("LAN_62", "Emne: ");
define("LAN_63", "Innlegg: ");
define("LAN_64", "Start ny tråd");
define("LAN_73", "Svar: ");
define("LAN_74", "Svar til tråd");
define("LAN_77", "Oppdater tråd");
define("LAN_78", "Oppdater svar");
define("LAN_94", "Postet av");
define("LAN_95", "Ikke autorisert");
define("LAN_96", "Du har ikke tillatelse til å endre dette innlegget.");
define("LAN_100", "Trådemne");
define("LAN_101", "Siste ");
define("LAN_102", " svar");
define("LAN_103", "Overblikk over hele tråden. (Åpner et nytt vindu.)");
define("LAN_133", "Takk");
define("LAN_174", "Registrer");
define("LAN_175", "Logg inn");
define("LAN_212", "Glemt passord?");
define("LAN_310", "Innlegget kan ikke aksepteres siden dette er et registrert brukernavn - om det er ditt brukernavn, vennligst logg inn for å poste.");
define("LAN_311", "Anonym");
define("LAN_322", "Lagt inn: ");
define("LAN_323", "Forhåndsvis");
define("LAN_324", "Meldingen ble korrekt postet.");
define("LAN_325", "Klikk her for å se innlegget ditt");
define("LAN_326", "Klikk her for å gå tilbake til forum");
define("LAN_327", "Se over");
define("LAN_380", "Dersom du ønsker å få en epost når noen svarer i tråden, merk av i denne boksen ");
define("LAN_381", "Forumsvar fra ");
define("LAN_382", "Innlegg lagt inn: ");
define("LAN_383", "Klikk på følgende link for å se hele tråden...");
define("LAN_384", "Forumsvar på ");
define("LAN_385", "Innlegg: ");
define("LAN_386", "Om du ikke vil legge til en avstemning til tråden, la feltene stå tomme");
define("LAN_387", "Kjør");
define("LAN_388", "Tilbake til toppen");
define("LAN_389", "Duplikat innlegg, omdirigerer...");
define("LAN_390", "Legg ved fil/bilde");
define("LAN_391", "Alternativ");
define("LAN_392", "Fil som skal legges ved");
define("LAN_393", "<b>NB</b><br />Tillatte filtyper:");
define("LAN_394", "Alle andre filtyper som lastes opp slettes umiddelbart.");
define("LAN_395", "Maksimal filstørrelse");
define("LAN_396", "bytes");
define("LAN_397", "Denne tråden er lest.");
define("LAN_398", "Dette forumet er skrivebeskyttet");
define("LAN_399", "Du har ikke tillatelse å poste i dette forumet.");
define("LAN_400", "post tråd som");
define("LAN_401", "Gå til");

define("LAN_402", "avstemning");
define("LAN_403", "kunngjøring");
define("LAN_404", "klistret");
define("LAN_405", "Forum");
define("LAN_406", "Sv:");

//v.616
define("LAN_407", "Omdiriger");
define("LAN_408", "Om din webleser ikke støtter omdirigering via meta-kommandoen, klikk");
define("LAN_409", "HER");
define("LAN_410", "for å omdirigeres");
define("LAN_411", "her");
define("LAN_412", "for å gå til registreringssiden.");

define("LAN_413", "Avstemningen din er nå lagt inn.");
define("LAN_414", "Klikk her for å se avstemningen din");
define("LAN_415", "Ditt svar er nå lagt inn.");

define("LAN_416", "Legg ved fil");
define("LAN_417", "Legg ved flere vedlegg");

define("POLL_506", "Tillat flere valg?");
define("POLL_507", "ja");
define("POLL_508", "nei");

define("LAN_FORUM_1", "Opplastning deaktivert: ".e_FILE."public katalogen er ikke skrivbar");
define("LAN_FORUM_2", "Duplikat innlegg");


?>