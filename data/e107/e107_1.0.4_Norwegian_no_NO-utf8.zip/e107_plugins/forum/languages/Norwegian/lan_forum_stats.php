<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Norwegian/lan_forum_stats.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Forumstatistikk");

define("FSLAN_1", "Generelt");
define("FSLAN_2", "Forumet åpnet");
define("FSLAN_3", "Åpnet for");
define("FSLAN_4", "Innlegg totalt");
define("FSLAN_5", "Forumemner");
define("FSLAN_6", "Forumsvar");
define("FSLAN_7", "Forumtrådvisninger");
define("FSLAN_8", "Database størrelse (Kun forumtabeller)");
define("FSLAN_9", "Gjennomsnittlig radlengde i forumtabell");
define("FSLAN_10", "Mest aktive emne");
define("FSLAN_11", "Rang");
define("FSLAN_12", "Emne");
define("FSLAN_13", "Svar");
define("FSLAN_14", "Startet av");
define("FSLAN_15", "Dato");
define("FSLAN_16", "Mest viste emne");
define("FSLAN_17", "Visninger");
define("FSLAN_18", "Mest aktive brukere");
define("FSLAN_19", "Navn");
define("FSLAN_20", "Innlegg");
define("FSLAN_21", "Flest startede emner");
define("FSLAN_22", "Flest svar skrevet");
define("FSLAN_23", "Forumstatistikk");
define("FSLAN_24", "Gjennomsnittlig antall innlegg pr dag");

?>