<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Norwegian/lan_forum_viewforum.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum");
	
define("LAN_01", "Forum");
define("LAN_02", "Tilbake til toppen");
define("LAN_03", "Gå");
define("LAN_53", "Tråd");
define("LAN_54", "Startet av");
define("LAN_55", "Svar");
define("LAN_56", "Visninger");
define("LAN_57", "Siste innlegg");
define("LAN_58", "Det finnes ingen emner i dette forumet enda.");
define("LAN_59", "Du må være registret medlem og innlogget for å kunne poste innleggi forumet. Klikk på registrer eller logg inn for å få innloggingsmenyen.");
define("LAN_79", "Nye innlegg");
define("LAN_80", " Ingen nye innlegg");
define("LAN_81", "Stengt tråd");
define("LAN_180", "Søk");
define("LAN_199", "Ulest post finnes");
define("LAN_202", "Klistret");
define("LAN_203", "Klistret/Stengt");
define("LAN_204", "Du <b>kan</b> starte nye tråder");
define("LAN_205", "Du <b>kan ikke</b> starte nye tråder");
define("LAN_206", "Du <b>kan</b> poste svar");
define("LAN_207", "Du <b>kan ikke</b> poste svar");
define("LAN_208", "Du <b>kan</b> endre innleggene dine");
define("LAN_209", "Du <b>kan ikke</b> endre innleggene dine");
define("LAN_316", "Gå til side: ");
define("LAN_317", "Ingen");
define("LAN_321", "Moderatorer: ");
define("LAN_395", "[populær]");
define("LAN_396", "Kunngjøring");

define("LAN_397", "Dette forumet er skrivebeskyttet");
	
define("LAN_398", "Ta bort klistring");
define("LAN_399", "Lås tråd");
define("LAN_400", "Lås opp tråd");
define("LAN_401", "Klistre tråd");
define("LAN_402", "Flytt tråd");
define("LAN_403", "Gå til forum");
define("LAN_404", "Dette forumet modereres av");

define("LAN_405", "bruker leser dette forumet akkurat nå");
define("LAN_406", "brukere leser dette forumet akkurat nå");
define("LAN_407", "medlem");
define("LAN_408", "gjest");
define("LAN_409", "medlemmer");
define("LAN_410", "gjester");


define("LAN_411", "Viktige tråder");
define("LAN_412", "Forumtråder");
define("LAN_431", "Distribuer dette forumet: rss 0.92");
define("LAN_432", "Distribuer dette forumet: rss 2.0");
define("LAN_433", "Distribuer dette forumet: RDF");

define("LAN_434", "Er du sikker på at du vil slette denne tråden med alle svar?");
define("LAN_435", "Slett tråd");
	
//v.617
define("FORLAN_CLOSE", "Tråd stengt.");
define("FORLAN_OPEN", "Tråd åpnet igjen.");
define("FORLAN_STICK", "Tråd fastklistret.");
define("FORLAN_UNSTICK", "Tråd løsnet.");
define("FORLAN_6", "Tråd slettet");
define("FORLAN_7", "svar slettet");
define("FORLAN_8", "her");
define("FORLAN_9", "for å registrere eller logge inn fra innloggingsmenyen.");

define("FORLAN_10", "Start ny tråd");
define("FORLAN_11", "Nye innlegg");
define("FORLAN_12", "Ingen nye innlegg");
define("FORLAN_13", "Nye innlegg i populær tråd");
define("FORLAN_14", "Ingen nye innlegg i populær tråd");
define("FORLAN_15", "Klistret tråd");
define("FORLAN_16", "Stengt og klistret tråd");
define("FORLAN_17", "Kunngjøringer");
define("FORLAN_18", "Stengt tråd");
define("FORLAN_19", "[bruker slettet]");
define("FORLAN_20", "Underforum");
define("FORLAN_21", "Tråder");
define("FORLAN_22", "Siste innlegg");
	
?>