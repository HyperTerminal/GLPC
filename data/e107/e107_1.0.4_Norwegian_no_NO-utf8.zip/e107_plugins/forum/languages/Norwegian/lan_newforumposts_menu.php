<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Norwegian/lan_newforumposts_menu.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
	
define("NFP_1", "Alle nyeste innlegg er utenfor din brukerklasse, kan ikke vise dem.");
define("NFP_2", "Ingen innlegg enda");
define("NFP_3", "Menykonfigurasjon for nye foruminnleg lagret");
define("NFP_4", "Overskrift");
define("NFP_5", "Antall innlegg å vise?");
define("NFP_6", "Antall tegn å vise?");
define("NFP_7", "Postfiks for for lange innlegg?");
define("NFP_8", "Vise opprinnelige emner i meny?");
define("NFP_9", "Oppdater menyinnstillinger");
define("NFP_10", "Menykonfigurasjon for nye foruminnlegg");
define("NFP_11", "Postet av");
define("NFP_12", "Maks alder på viste poster");
define("NFP_13", "Bruk 0 på en stille side; om du setter en verdi her, så vil det redusere ressursene systemet bruker på en populær side");
	
?>