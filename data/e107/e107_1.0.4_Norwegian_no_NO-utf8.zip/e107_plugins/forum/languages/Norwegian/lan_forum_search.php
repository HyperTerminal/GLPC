<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Norwegian/lan_forum_search.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Velg forum");
define("FOR_SCH_LAN_3", "Alle forumet");
define("FOR_SCH_LAN_4", "Hele poster");
define("FOR_SCH_LAN_5", "Som del av en tråd");

?>