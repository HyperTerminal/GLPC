<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/online_extended_menu/languages/Norwegian.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "Gjester: ");
define("ONLINE_EL2", "Medlemmer: ");
define("ONLINE_EL3", "På denne siden: ");
define("ONLINE_EL4", "Pålogget");
define("ONLINE_EL5", "Medlemmer");
define("ONLINE_EL6", "Nyeste medlem");
define("ONLINE_EL7", "ser på");

define("ONLINE_EL8", "flest online samtidig: ");
define("ONLINE_EL9", "den");

define("ONLINE_TRACKING_MESSAGE", "Sporing av påloggede brukere er for tiden deaktivert, vennligst aktiver det [link=".e_ADMIN."users.php?options]herfra[/link][br]");

?>