<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/chatbox_menu/languages/English/English_config.php $
|     $Revision: 11678 $
|     $Id: English_config.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
|     Encoding:
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Chatboks innstillinger er oppdatert.");
define("CHBLAN_2", "Moderert.");
define("CHBLAN_3", "Ingen poster i chatboksen enda.");
define("CHBLAN_4", "Medlem");
define("CHBLAN_5", "Gjest");
define("CHBLAN_6", "ta bort blokkering");
define("CHBLAN_7", "blokker");
define("CHBLAN_8", "slett");
define("CHBLAN_9", "Moderer chatboks");
define("CHBLAN_10", "Moderer poster");
define("CHBLAN_11", "Poster å vise i chatboksen");
define("CHBLAN_12", "hvor mange poster som blir vist nedover");
define("CHBLAN_13", "Erstatt linker");
define("CHBLAN_14", "dersom markert, så vil linker bli erstattet med teksten i boksen under");
define("CHBLAN_15", "String som skal erstatte");
define("CHBLAN_16", "linker vil bli vist med denne teksten");
define("CHBLAN_17", "Ant. bokstaver får linjeskift");
define("CHBLAN_18", "ord som er lenger enn antallet du setter her vil få et linjeskift");
define("CHBLAN_19", "Oppdater chatboks innstillinger");
define("CHBLAN_20", "Chatboks innstillinger");
define("CHBLAN_21", "Rens");
define("CHBLAN_22", "Slett poster som er lengere enn en viss tidsperiode");
define("CHBLAN_23", "Slett poster eldre enn");
define("CHBLAN_24", "En dag");
define("CHBLAN_25", "En uke");
define("CHBLAN_26", "En måned");
define("CHBLAN_27", "- Slett alle poster -");
define("CHBLAN_28", "Chatboksen er nå renset.");
define("CHBLAN_29", "Vis poster på innsiden av en scrollbar");
define("CHBLAN_30", "Høyde");
define("CHBLAN_31", "Vis uttrykksikoner");
define("CHBLAN_32", "Moderator brukergruppe");
define("CHBLAN_33", "Brukertall er nå rekalkulert");
define("CHBLAN_34", "Kalkuler antall poster til brukere");
define("CHBLAN_35", "Kalkuler");
define("CHBLAN_36", "Visningsinnstillinger for chatboksen");
define("CHBLAN_37", "Normal chatboks");
define("CHBLAN_38", "Bruk Javascript for å oppdatere poster dynamisk (AJAX)");


?>