<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/Norwegian/Norwegian.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("CHATBOX_L1", "Kunne ikke akseptere denne posten ettersom dette brukernavnet allerede er registrert - dersom det er ditt brukernavn, vennligst logg inn for å poste.");
define("CHATBOX_L2", "Chatboks");
define("CHATBOX_L3", "Du må være logget inn for å poste kommentarer på denne siden - vennligst logg inn eller om du er en registrert bruker, klikk for <a href='".e_SIGNUP."'>her</a> å registrere deg.");
define("CHATBOX_L4", "Send");
define("CHATBOX_L5", "Tøm");
define("CHATBOX_L6", "[blokkert av admin]");
define("CHATBOX_L7", "Fjern blokkering");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Blokker");
define("CHATBOX_L10", "Slett");
define("CHATBOX_L11", "Det finnes ingen meldinger enda.");
define("CHATBOX_L12", "Se alle poster");
define("CHATBOX_L13", "Moderer chatboksen");
define("CHATBOX_L14", "Smiley");
define("CHATBOX_L15", "Posten er for lang, eller du har prøvd å poste en tom post.");
define("CHATBOX_L16", "Annonym");
define("CHATBOX_L17", "Duplikat post");
define("CHATBOX_L18", "Chatbox messages moderated");
define("CHATBOX_L19", "You may only post once every ".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." seconds");

define("CHATBOX_L20", "Chatboks (alle poster)");
define("CHATBOX_L21", "Chat Poster");
define("CHATBOX_L22", "den");
define("CHATBOX_L23", "Feil!");
define("CHATBOX_L24", "Du har ikke rettigheter til å se denne siden");
define("CHATBOX_L25", "[ denne posten har blitt blokkert av en admin ]");

// Notify
define("NT_LAN_CB_1", "Chatboks hendelser");
define("NT_LAN_CB_2", "Meldingen er postet!");
define("NT_LAN_CB_3", "Lagt inn av");
define("NT_LAN_CB_4", "IP Addresse");
define("NT_LAN_CB_5", "Melding");
define("NT_LAN_CB_6", "Chatboksmelding er postet");

?>