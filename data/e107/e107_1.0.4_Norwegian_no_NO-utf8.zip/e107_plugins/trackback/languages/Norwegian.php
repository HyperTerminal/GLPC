<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/trackback/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "Konfigurer tilbakesporing");
define("TRACKBACK_L2", "Denne plugin lar deg benytte tilbakesporing i dine nyheter.");
define("TRACKBACK_L3", "Tilbakesporing er nå installert og aktivert.");
define("TRACKBACK_L4", "Tilbakesporingsinnstillinger lagret.");
define("TRACKBACK_L5", "På");
define("TRACKBACK_L6", "Av");
define("TRACKBACK_L7", "Aktiver tilbakesporing");
define("TRACKBACK_L8", "Tilbakesporing URL tekst");
define("TRACKBACK_L9", "Lagre instillinger");
define("TRACKBACK_L10", "Tilbakesporingsinnstillinger");
define("TRACKBACK_L11", "Tilbakesporingsadresse for denne posten:");

define("TRACKBACK_L12", "Ingen tilbakesporing for denne posten");
define("TRACKBACK_L13", "Moderer tilbakesporing");
define("TRACKBACK_L14", "Slett");
define("TRACKBACK_L15", "Tilbakesporinger slettet.");

?>