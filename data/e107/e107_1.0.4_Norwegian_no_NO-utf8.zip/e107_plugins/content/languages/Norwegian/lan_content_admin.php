<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/Norwegian/lan_content_admin.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/


define("CONTENT_PLUGIN_LAN_1", "Innholdshåndtering");
define("CONTENT_PLUGIN_LAN_2", "En komplett seksjon for innholdsholdshåndtering");
define("CONTENT_PLUGIN_LAN_3", "Konfigurera innholdshåndtereren");
define("CONTENT_PLUGIN_LAN_4", "Denne plugin'en er nå klar til bruk.");
define("CONTENT_PLUGIN_LAN_5", "Innhold");
define("CONTENT_PLUGIN_LAN_6", "Innholdsadministrasjon plugin tabellstrukur er oppdatert");

define("CONTENT_LATEST_LAN_1", "Innsente innholdssaker:");
define("CONTENT_STATUS_LAN_1", "Content Items:");

define("CONTENT_ADMIN_CAT_LAN_0", "Opprett innholdskategori");
define("CONTENT_ADMIN_CAT_LAN_1", "Endre innholdsskategori");
define("CONTENT_ADMIN_CAT_LAN_2", "Tittel");
define("CONTENT_ADMIN_CAT_LAN_3", "Undertittel");
define("CONTENT_ADMIN_CAT_LAN_4", "Tekst");
define("CONTENT_ADMIN_CAT_LAN_5", "Ikon");
define("CONTENT_ADMIN_CAT_LAN_6", "Send");
define("CONTENT_ADMIN_CAT_LAN_7", "Oppdater");
define("CONTENT_ADMIN_CAT_LAN_8", "Vis ikoner");
define("CONTENT_ADMIN_CAT_LAN_9", "Ingen innholdskategorier enda");
define("CONTENT_ADMIN_CAT_LAN_10", "Innholdskategorier");
define("CONTENT_ADMIN_CAT_LAN_11", "Innholdskategori opprettet");
define("CONTENT_ADMIN_CAT_LAN_12", "Innholdskategori oppdatert");
define("CONTENT_ADMIN_CAT_LAN_13", "Nødvendig felt latt stå tomt");
define("CONTENT_ADMIN_CAT_LAN_14", "Kommentarer");
define("CONTENT_ADMIN_CAT_LAN_15", "Karakter");
define("CONTENT_ADMIN_CAT_LAN_16", "Skriv ut epost/ikoner");
define("CONTENT_ADMIN_CAT_LAN_17", "Synlighet");
define("CONTENT_ADMIN_CAT_LAN_18", "Forfatter");
define("CONTENT_ADMIN_CAT_LAN_19", "Innholdskategori");
define("CONTENT_ADMIN_CAT_LAN_20", "Alternativ");
define("CONTENT_ADMIN_CAT_LAN_21", "Tøm skjemaet");
define("CONTENT_ADMIN_CAT_LAN_22", "Alternativ uppdaterade");
define("CONTENT_ADMIN_CAT_LAN_23", "Innholdskategori slettet");
define("CONTENT_ADMIN_CAT_LAN_24", "Id");
define("CONTENT_ADMIN_CAT_LAN_25", "Ikon");
define("CONTENT_ADMIN_CAT_LAN_26", "Ny hovedkategori");
define("CONTENT_ADMIN_CAT_LAN_27", "Kategori");
define("CONTENT_ADMIN_CAT_LAN_28", "Tildel brukere fra det venstre vinduet til den personlige innholdshåndtereren for denne kategorien");
define("CONTENT_ADMIN_CAT_LAN_29", "Admins - klikk for å flytte... ");
define("CONTENT_ADMIN_CAT_LAN_30", "Personlige admins av denne kategori ...");
define("CONTENT_ADMIN_CAT_LAN_31", "Fjern");
define("CONTENT_ADMIN_CAT_LAN_32", "Rydd opp i klasse");
define("CONTENT_ADMIN_CAT_LAN_33", "Tildel admins til kategori");
define("CONTENT_ADMIN_CAT_LAN_34", "Admins tildelt til kategori");
define("CONTENT_ADMIN_CAT_LAN_35", "Innholdsunderkategori slettet");
define("CONTENT_ADMIN_CAT_LAN_36", "Kategorikontroll: det finnes fortsatt underkategorier, kategorien vil IKKE bli slettet. Fjern først alle underkategorier og forsøk igjen.");
define("CONTENT_ADMIN_CAT_LAN_37", "Innholdskontroll: Det finnes fortsatt innhold, kategorien vil IKKE bli slettet. Fjern først alt innhold og forsøk igjen.");
define("CONTENT_ADMIN_CAT_LAN_38", "Innholdskontroll: Ingen objekter funnet");
define("CONTENT_ADMIN_CAT_LAN_39", "Kategorikontroll: Ingen underkategorier funnet");
define("CONTENT_ADMIN_CAT_LAN_40", "Nedenfor ser du en liste over hovedkategorien og alle underkategorier, om noen finnes.<br />");

define("CONTENT_ADMIN_CAT_LAN_41", "De personlige instillingene for innholdsskategorier lar deg tildele visse admins til en kategori. Med dette privilegiumet kan admins håndtere sin, og bare sine personlige innholdsposter i denne spesifiserte kategorien uten å behøve å ha kontroll over hele innholdshåndteringen. Fra den normale innholdssiden utenfor adminområdet kommer de til å se et ikon som omdirigerer dem til sin personlige innstillingsside.");
define("CONTENT_ADMIN_CAT_LAN_42", "For å redigere en kategori fra den tidigere valgte hovedkategorien");

define("CONTENT_ADMIN_CAT_LAN_43", "Klikk her");
define("CONTENT_ADMIN_CAT_LAN_44", "For å legge til en ny kategori i den tidligere valgte hovedkategorien");
define("CONTENT_ADMIN_CAT_LAN_45", "Angi om kommentarer skal tillates");
define("CONTENT_ADMIN_CAT_LAN_46", "Angi om karakterer skal tillates");
define("CONTENT_ADMIN_CAT_LAN_47", "Skal skriv ut/epostikoner vises?");
define("CONTENT_ADMIN_CAT_LAN_48", "Velg hvilka brukere som skal se dette objektet");
define("CONTENT_ADMIN_CAT_LAN_49", "Velg et ikon for denne kategorien");
//define("CONTENT_ADMIN_CAT_LAN_50", "innholdsmeny er nå laget<br /><br />Fordi at du har laget en hovedkategori, så har en meny blitt innvilget<br />Menyfilen har blitt laget i /menus mappen din.<br /><br />For å se menyen, så må du fortsatt aktivere denne menyen i <a href='".e_ADMIN."menus.php'>admin meny området</a>.");
define("CONTENT_ADMIN_CAT_LAN_50", "Bare om du opprettet en ny hovedgruppekategori er en meny blitt opprettet.<br />Menyfilen har blitt lagret i din /menus folder.<br />For å se menyen i aksjon må du aktivere menyen i <a href='".e_ADMIN."menus.php'>adminmenyområdet</a>.");




define("CONTENT_ADMIN_CAT_LAN_51", "Feil; Menyfil ble ikke opprettet");
define("CONTENT_ADMIN_CAT_LAN_52", "Velg ALLTID en kategori først før du fyller ut de andre feltene!");
define("CONTENT_ADMIN_CAT_LAN_53", "Hovedgruppekategori");
define("CONTENT_ADMIN_CAT_LAN_54", "bruker");
define("CONTENT_ADMIN_CAT_LAN_55", "brukere");
define("CONTENT_ADMIN_CAT_LAN_56", "objekt");
define("CONTENT_ADMIN_CAT_LAN_57", "objekter");
define("CONTENT_ADMIN_CAT_LAN_58", "opplasting av kategoriikon var vellykket<br />Notera: Du må også tildele ikonet til denne kategorien i Ikon>Velg eksisterende ikonområde!<br />og etter det må du også lagre skjemaet for å opprette/oppdatere denne kategorien");
define("CONTENT_ADMIN_CAT_LAN_59", "kategoriikon ikke opplastet");
define("CONTENT_ADMIN_CAT_LAN_60", "Velg et eksisterende ikon");
define("CONTENT_ADMIN_CAT_LAN_61", "eller eller last opp et nytt ikon");
define("CONTENT_ADMIN_CAT_LAN_62", "Når du har lastet opp et nytt kategoriikon kan du tildele ikonet med 'Velg eksisterende ikon' området ovenfor<br />Om du laste opp et nytt ikon vil det bli skalert til 48 pixlar, et mindre 16 pixlers ikon kommer også til å opprettes<br /><br />");
define("CONTENT_ADMIN_CAT_LAN_63", "Last opp ikon");

define("CONTENT_ADMIN_MANAGER_LAN_0", "godkjenn innsente");
define("CONTENT_ADMIN_MANAGER_LAN_1", "brukere i denne klassen kan godkjenne innholdssaker");
define("CONTENT_ADMIN_MANAGER_LAN_2", "personlig administrasjon");
define("CONTENT_ADMIN_MANAGER_LAN_3", "brukere i denne klassen kan bare administrere deres personlige innholdssaker");
define("CONTENT_ADMIN_MANAGER_LAN_4", "kategoriadministrator");
define("CONTENT_ADMIN_MANAGER_LAN_5", "brukere i denne klassen kan administere alt innhold i denne kategorien");

define("CONTENT_ADMIN_ITEM_LAN_0", "Nødvendige felt latt stå tomme");
define("CONTENT_ADMIN_ITEM_LAN_1", "Innholdsobjekt opprettet");
define("CONTENT_ADMIN_ITEM_LAN_2", "Innholdsobjekt oppdatert");
define("CONTENT_ADMIN_ITEM_LAN_3", "Innholdsobjekt slettet");
define("CONTENT_ADMIN_ITEM_LAN_4", "Ingen innholdssobjekter enda");
define("CONTENT_ADMIN_ITEM_LAN_5", "Eksisterende innholdsobjekt");
define("CONTENT_ADMIN_ITEM_LAN_6", "Første bpkstaver");
define("CONTENT_ADMIN_ITEM_LAN_7", "Velg bokstav ovenfor.");
define("CONTENT_ADMIN_ITEM_LAN_8", "ID");
define("CONTENT_ADMIN_ITEM_LAN_9", "ikon");
define("CONTENT_ADMIN_ITEM_LAN_10", "Forfatter");
define("CONTENT_ADMIN_ITEM_LAN_11", "Tittel");
define("CONTENT_ADMIN_ITEM_LAN_12", "Alternativ");
define("CONTENT_ADMIN_ITEM_LAN_13", "Velg gruppekategori");
define("CONTENT_ADMIN_ITEM_LAN_14", "Navn");
define("CONTENT_ADMIN_ITEM_LAN_15", "Epost");
define("CONTENT_ADMIN_ITEM_LAN_16", "Underoverskrift");
define("CONTENT_ADMIN_ITEM_LAN_17", "Sammendrag");
define("CONTENT_ADMIN_ITEM_LAN_18", "Tekst");
define("CONTENT_ADMIN_ITEM_LAN_19", "Last opp ikon");
define("CONTENT_ADMIN_ITEM_LAN_20", "Ikon");
define("CONTENT_ADMIN_ITEM_LAN_21", "Dette alternativet er deaktivert siden filopplastning ikke er aktivert på serveren din");
define("CONTENT_ADMIN_ITEM_LAN_22", "Katalogen");
define("CONTENT_ADMIN_ITEM_LAN_23", "er skrivebeskyttet, du må sette CHMOD 777 på den før du kan laste opp");
define("CONTENT_ADMIN_ITEM_LAN_24", "vedleg");
define("CONTENT_ADMIN_ITEM_LAN_25", "Last opp nytt ikon");
define("CONTENT_ADMIN_ITEM_LAN_26", "Fjern");
define("CONTENT_ADMIN_ITEM_LAN_27", "eksisterende innholdsfil");
define("CONTENT_ADMIN_ITEM_LAN_28", "Last opp ny fil");
define("CONTENT_ADMIN_ITEM_LAN_29", "Ingen fil enda");
define("CONTENT_ADMIN_ITEM_LAN_30", "Innholdsfil");
define("CONTENT_ADMIN_ITEM_LAN_31", "bilde");
define("CONTENT_ADMIN_ITEM_LAN_32", "Eksisterende innholdsbilde");
define("CONTENT_ADMIN_ITEM_LAN_33", "Last opp nytt bilde");
define("CONTENT_ADMIN_ITEM_LAN_34", "Innholdsbilde");
define("CONTENT_ADMIN_ITEM_LAN_35", "Sett alternativ for denne innholdsposten");
define("CONTENT_ADMIN_ITEM_LAN_36", "Kommentarer");
define("CONTENT_ADMIN_ITEM_LAN_37", "Karakter");
define("CONTENT_ADMIN_ITEM_LAN_38", "Skriv ut/epost ikoner");
define("CONTENT_ADMIN_ITEM_LAN_39", "Synlighet");
define("CONTENT_ADMIN_ITEM_LAN_40", "Poeng");
define("CONTENT_ADMIN_ITEM_LAN_41", "Velg et poeng...");
define("CONTENT_ADMIN_ITEM_LAN_42", "Marker for å oppdatere tidssttempelet til nåværende tid");
define("CONTENT_ADMIN_ITEM_LAN_43", "Post brukerinnsendt innholdspost");
define("CONTENT_ADMIN_ITEM_LAN_44", "Opprett innholdspost");
define("CONTENT_ADMIN_ITEM_LAN_45", "Oppdater innholdsemne");
define("CONTENT_ADMIN_ITEM_LAN_46", "Forhåndsvis");
define("CONTENT_ADMIN_ITEM_LAN_47", "Forhåndsvis igjen");
define("CONTENT_ADMIN_ITEM_LAN_48", "Hovedgruppe");
define("CONTENT_ADMIN_ITEM_LAN_49", "Innsendte innholdsposter");
define("CONTENT_ADMIN_ITEM_LAN_50", "Ingen innsendte innholdsposter");
define("CONTENT_ADMIN_ITEM_LAN_51", "Forfatterdetaljer");
define("CONTENT_ADMIN_ITEM_LAN_52", "Send inn innhold");
define("CONTENT_ADMIN_ITEM_LAN_53", "Metanøkkelord");
define("CONTENT_ADMIN_ITEM_LAN_54", "Ekstra data");
define("CONTENT_ADMIN_ITEM_LAN_55", "Gå tilbake til <a href='".e_SELF."'>hovedsiden for eget innhold</a> for å håndtere mer av ditt personlige innhold<br />eller<br />Gå til <a href='".e_PLUGIN."content/content.php'>hovedsiden for innhold</a> for å se innholdet.");
define("CONTENT_ADMIN_ITEM_LAN_56", "personlig innholdshåndterer");
define("CONTENT_ADMIN_ITEM_LAN_57", "kategori");
define("CONTENT_ADMIN_ITEM_LAN_58", "poster");
define("CONTENT_ADMIN_ITEM_LAN_59", "flytte");
define("CONTENT_ADMIN_ITEM_LAN_60", "sortere");
define("CONTENT_ADMIN_ITEM_LAN_61", "oppdatere rekkefølge");
define("CONTENT_ADMIN_ITEM_LAN_62", "sorter kategorier");
define("CONTENT_ADMIN_ITEM_LAN_63", "stig.");
define("CONTENT_ADMIN_ITEM_LAN_64", "fall.");
define("CONTENT_ADMIN_ITEM_LAN_65", "sorter innholdsposter");
define("CONTENT_ADMIN_ITEM_LAN_66", "Nedenfor ser du de ulike bokstavene i rubrikkene for alle objekt i denne kastegorien.<br />Ved å klikke på noen av bokstavene kommer du til å se alle objekt som begynner på den valgte bokstaven. Du kan også velge knappen ALLE for å vise alle objekt i denna kategorien.");
define("CONTENT_ADMIN_ITEM_LAN_67", "Nedenfor ser du innholdet listet for den valgte kategorien, begrenset av den valgte bokstaven.<br />Du kan endre eller slette et objekt ved å klikke på knappene til høyre.");
define("CONTENT_ADMIN_ITEM_LAN_68", "Nedenfor kan du legge til egne data for dette objektet. Hvert eget datapar må ha både nøkkel og verdi. Du kan spesifisere nøkkelen i det venstre feltet og tilhørende verdi i det høyre feltet.<br />(f.eks. nøkkel'fotografi' og verdi='alle foto tatt av meg'.");
define("CONTENT_ADMIN_ITEM_LAN_69", "Her kan du laste upp ikoner, vedlegg og/eller bilder til ditt innhold. De tillatte filtypene er: ");
define("CONTENT_ADMIN_ITEM_LAN_70", "I neste rute kan du spesifisere metanøkkelord til innholdet ditt. Disse metanøkkelordene vises i sidens hode. Separer ordene med kommategn, og ingen mellomrom er tillatt!");
define("CONTENT_ADMIN_ITEM_LAN_71", "La stå åpent om du har skrevet det");
define("CONTENT_ADMIN_ITEM_LAN_72", "Angi forfatterdetaljer");
define("CONTENT_ADMIN_ITEM_LAN_73", "Angi en startdato for dette objektet (La stå tomt om det ikke behøves)");
define("CONTENT_ADMIN_ITEM_LAN_74", "Angi en sluttdato for dette objektet (La stå tomt om det ikke behøves)");
define("CONTENT_ADMIN_ITEM_LAN_75", "Tildel et ikon til dette objektet");
define("CONTENT_ADMIN_ITEM_LAN_76", "Tildel vedlegg til dette objektet");
define("CONTENT_ADMIN_ITEM_LAN_77", "Tildel bilder til dette objektet");
define("CONTENT_ADMIN_ITEM_LAN_78", "Angi om kommentarer skal tillates");
define("CONTENT_ADMIN_ITEM_LAN_79", "Angi om karaktersetting skal tillates");
define("CONTENT_ADMIN_ITEM_LAN_80", "Angi om skriv ut/e-post ikoner skal vises");
define("CONTENT_ADMIN_ITEM_LAN_81", "Velg hvilke brukere som skal få se dette objektet");
define("CONTENT_ADMIN_ITEM_LAN_82", "Angi et poeng");
define("CONTENT_ADMIN_ITEM_LAN_83", "Angi metanøkkelord");
define("CONTENT_ADMIN_ITEM_LAN_84", "Angi egne datapar (nøkkel + verdi)");
define("CONTENT_ADMIN_ITEM_LAN_85", "Aktivert");
define("CONTENT_ADMIN_ITEM_LAN_86", "Deaktivert");
define("CONTENT_ADMIN_ITEM_LAN_87", "Velg et ikon for dette objektet");
define("CONTENT_ADMIN_ITEM_LAN_88", "For å opprette ett objekt i den tidligere valgte hovedkategorien");
define("CONTENT_ADMIN_ITEM_LAN_89", "For å endre ett objekt i den tidligere valgte hovedkategorien");
define("CONTENT_ADMIN_ITEM_LAN_90", "klikk her");
define("CONTENT_ADMIN_ITEM_LAN_91", "for å endre samme objekt igjen");
define("CONTENT_ADMIN_ITEM_LAN_92", "Mal");
define("CONTENT_ADMIN_ITEM_LAN_93", "Velg en layoutmal");
define("CONTENT_ADMIN_ITEM_LAN_94", "Velg en layoutmal");

define("CONTENT_ADMIN_ITEM_LAN_95", "Last opp et nytt ikon");
define("CONTENT_ADMIN_ITEM_LAN_96", "Velg et eksisterende ikon");
define("CONTENT_ADMIN_ITEM_LAN_97", "Etter at du har lastet opp et nytt ikon kan du tildele det nedenfor med 'Velg et eksisterende ikon'");

define("CONTENT_ADMIN_ITEM_LAN_98", "Last opp et nytt vedlegg");
define("CONTENT_ADMIN_ITEM_LAN_99", "Velg et eksisterende vedlegg");
define("CONTENT_ADMIN_ITEM_LAN_100", "Etter at du har lastet opp et nytt vedlegg kan du tildele det nedenfor med 'Velg et eksisterende vedlegg'");

define("CONTENT_ADMIN_ITEM_LAN_101", "Last opp et nytt bilde");
define("CONTENT_ADMIN_ITEM_LAN_102", "Velg en eksisterende bilde");
define("CONTENT_ADMIN_ITEM_LAN_103", "Etter at du har lastet opp et nytt bilde kan du tildele det nedenfor med 'Velg et eksisterende bilde'");

define("CONTENT_ADMIN_ITEM_LAN_104", "Last opp");
define("CONTENT_ADMIN_ITEM_LAN_105", "Vis");

define("CONTENT_ADMIN_ITEM_LAN_106", "Ikon opplastet<br />OBS: Du må fortsatt tildele dette ikonet til innholdsobjektet med 'Velg et eksisterende ikon'!<br />Selvfølgelig må du etter det også lagre innstillingene ved å sende skjemaet for å opprette/oppdatere innholdsobjektet.");
define("CONTENT_ADMIN_ITEM_LAN_107", "Ikon ble ikke lastet opp");

define("CONTENT_ADMIN_ITEM_LAN_108", "Vedlegg opplastet<br />OBS: Du må fortsatt tildele dette vedlegget til innholdsobjektet med 'Velg et eksisterende vedlegg'!<br />Selvfølgelig må du etter det også lagre innstillingene ved å sende skjemaet for å opprette/oppdatere innholdsobjektet.");
define("CONTENT_ADMIN_ITEM_LAN_109", "Vedlegg ble ikke lastet opp");

define("CONTENT_ADMIN_ITEM_LAN_110", "Bilde opplastet<br />OBS: Du må fortsatt tildele dette bildet til innholdsobjektet med 'Velg et eksisterende bilde'!<br />Selvfølgelig må du etter det også lagre innstillingene ved å sende skjemaet for å opprette/oppdatere innholdsobjektet.");
define("CONTENT_ADMIN_ITEM_LAN_111", "Bilde ble ikke lastet opp");

define("CONTENT_ADMIN_ITEM_LAN_112", "Last opp et ikon, vedlegg eller bilde");
define("CONTENT_ADMIN_ITEM_LAN_113", "Velg type opplastning i valgruten før du laster opp filen");
define("CONTENT_ADMIN_ITEM_LAN_114", "ikon");
define("CONTENT_ADMIN_ITEM_LAN_115", "vedlegg");
define("CONTENT_ADMIN_ITEM_LAN_116", "bilde");
define("CONTENT_ADMIN_ITEM_LAN_117", "Innsendt innholdsobjekt postet");
define("CONTENT_ADMIN_ITEM_LAN_118", "Ingen");
define("CONTENT_ADMIN_ITEM_LAN_119", "tildelt");
define("CONTENT_ADMIN_ITEM_LAN_120", "standardlayout");

define("CONTENT_ADMIN_ITEM_LAN_121", "Ingen ny ikon opplastet enda");
define("CONTENT_ADMIN_ITEM_LAN_122", "Ingen ny vedlegg opplastet enda");
define("CONTENT_ADMIN_ITEM_LAN_123", "Ingen ny bilde opplastet enda");

define("CONTENT_ADMIN_ITEM_LAN_124", "for å se objektet");


define("CONTENT_ADMIN_ORDER_LAN_0", "Rekkefølgen er stigende");
define("CONTENT_ADMIN_ORDER_LAN_1", "Rekkefølgen er fallende");
define("CONTENT_ADMIN_ORDER_LAN_2", "Ny rekkefølge for innholdet er lagret");



define("CONTENT_ADMIN_MAIN_LAN_0", "Eksisterende innholdskategorier");
define("CONTENT_ADMIN_MAIN_LAN_1", "Ingen innholdskategorier enda");
define("CONTENT_ADMIN_MAIN_LAN_2", "Hovedkategorier, innhold");
define("CONTENT_ADMIN_MAIN_LAN_3", "Innholdsobjekt slettet");
define("CONTENT_ADMIN_MAIN_LAN_4", "Gruppetekst");
define("CONTENT_ADMIN_MAIN_LAN_5", "Gruppeikon");
define("CONTENT_ADMIN_MAIN_LAN_6", "");
define("CONTENT_ADMIN_MAIN_LAN_7", "Velkommen til systemet for håndtering av innhold!");
define("CONTENT_ADMIN_MAIN_LAN_8", "Denne informasjonen vises på grunn av at tabellen for innholdshåndtererens plugin ikke innholder noen poster.");
define("CONTENT_ADMIN_MAIN_LAN_9", "Vennligst les følgende informasjon nøye og velg hva du vil gjøre.");
define("CONTENT_ADMIN_MAIN_LAN_10", "Du kan håndtere innholdsobjekt på denne siden. Først velger du den kategorien du vil håndtere innholdet for. Velg en kategori i ruten for å begynne å håndtere innholdet i den kategorien.");
define("CONTENT_ADMIN_MAIN_LAN_11", "Siden den gamle innholdstabellen innholder data kan du velge et av følgende tre alternativ:");
define("CONTENT_ADMIN_MAIN_LAN_12", "");
define("CONTENT_ADMIN_MAIN_LAN_13", "Du kan opprette nytt innhold på denne siden. Velg først den kategorien du vil håndtere. Klikk på knappen på noen av gruppene listet nedenfor for å opprette nytt innhold i den gruppekategorien.");
define("CONTENT_ADMIN_MAIN_LAN_14", "Du kan angi rekkefølgen for innholdet på denna side. Klikk på knappen på en av gruppene listet nedenfor for å begynne å sortere innholdet eller kategoriene for den valgt hovedkategorien.");
define("CONTENT_ADMIN_MAIN_LAN_15", "Du håndterer kategorier på denne siden. Velg hovedkategorien med knappene nedenfor for å vise et overblikk over alle kategorier og underkategorier i denne huvudkategorien.");
define("CONTENT_ADMIN_MAIN_LAN_16", "Du kan opprette nye kategorier på denne siden. Som standard vises skjemaet for ny hovedkategori. Om du vil skape en underkategori til en eksisterende hovedkategori, klikk da på en av knappene vist nednfor for å vise skjemaet for underkategori til den valgte hovedkategorien.");
define("CONTENT_ADMIN_MAIN_LAN_17", "Opprett en ny kategori via <a href='".e_SELF."?type.0.cat.create'>Opprett ny kategori</a> siden");

define("CONTENT_ADMIN_MAIN_LAN_18", "Konverter poster");
define("CONTENT_ADMIN_MAIN_LAN_19", "Det første du må gjøre er å sikkerhetskopiere innholdstabellen såvel som kommentarene og karaktertabellen.<br />Bruk et databaseprogram for detta, f.eks. phpMyAdmin.<br />Etter at du har kopiert innholdet kan du begynne å konvertere postene til den nye innholdshåndtereren.<br />Etter at du har konvertert det gamle innholdet, skal du ikke lenger se denna informasjonen, og du skal ha mulighet til å håndtere eksisterende innhold.<br />");
define("CONTENT_ADMIN_MAIN_LAN_20", "Start med en tom tabell");
define("CONTENT_ADMIN_MAIN_LAN_21", "Om du ikke lenger trenger postene fra din gamle innholdstabell,<br />og du bare vil starte med en ny, fersk innholdshåndteringstabell,<br />og du ikke vil opprette standardoppsett av kategorier,<br />så kan du begynne med å pprette en ny kategori.<br />");
define("CONTENT_ADMIN_MAIN_LAN_22", "Create a default set of categories");
define("CONTENT_ADMIN_MAIN_LAN_23", "Om du vil begynne med en fersk installasjon kan du først opprette et standardoppsett kategorier.<br />Dette standardoppsettet oppretter tre hovedkategorier, kalt Innhold, Anmeldelser og Artikler.<br />");
define("CONTENT_ADMIN_MAIN_LAN_24", "Dette er en fersk installasjon / Den gamle tabellen innholder ingen poster");
define("CONTENT_ADMIN_MAIN_LAN_25", "Ettersom den eksisterende tabellen ikke innholder noen poster kan du nå begynne å håndtere ditt nye innhold.<br />Ved å klikke på nesta-knappen vil standardoppsettet automatisk opprettes, nemlig Innhold, Anmeldelser og Artikler.<br />");
define("CONTENT_ADMIN_MAIN_LAN_26", "Forhåndsvis");
define("CONTENT_ADMIN_MAIN_LAN_27", "Forhåndsvis igjen");
define("CONTENT_ADMIN_MAIN_LAN_28", "Velg kategori...");
define("CONTENT_ADMIN_MAIN_LAN_29", "NY HOVEDKATEGORI");



















define("CONTENT_ADMIN_MENU_LAN_0", "Håndter innhold");
define("CONTENT_ADMIN_MENU_LAN_1", "Opprett nytt innhold");
define("CONTENT_ADMIN_MENU_LAN_2", "Håndter kategorier");
define("CONTENT_ADMIN_MENU_LAN_3", "Opprett ny kategori");
define("CONTENT_ADMIN_MENU_LAN_4", "Innsendt nytt innhold");
define("CONTENT_ADMIN_MENU_LAN_5", "Kategori");
define("CONTENT_ADMIN_MENU_LAN_6", "Alternativ");
define("CONTENT_ADMIN_MENU_LAN_7", "Admin: Opprett innhold");
define("CONTENT_ADMIN_MENU_LAN_8", "Send inn");
define("CONTENT_ADMIN_MENU_LAN_9", "Sti og tema");
define("CONTENT_ADMIN_MENU_LAN_10", "Generelt");
define("CONTENT_ADMIN_MENU_LAN_11", "Forhåndsvis innholdsobjekt");
define("CONTENT_ADMIN_MENU_LAN_12", "Kategorisider");
define("CONTENT_ADMIN_MENU_LAN_13", "Innholdssider");
define("CONTENT_ADMIN_MENU_LAN_14", "Meny");
define("CONTENT_ADMIN_MENU_LAN_15", "Håndter rekkefølge");
define("CONTENT_ADMIN_MENU_LAN_16", "Arkivside");
define("CONTENT_ADMIN_MENU_LAN_17", "Personlig innholdshåndterer");
define("CONTENT_ADMIN_MENU_LAN_18", "Forfatterside");
define("CONTENT_ADMIN_MENU_LAN_19", "Innholdshåndterer");
define("CONTENT_ADMIN_MENU_LAN_20", "Topprangert side");
define("CONTENT_ADMIN_MENU_LAN_21", "Sider");
define("CONTENT_ADMIN_MENU_LAN_22", "Toppoengside");
define("CONTENT_ADMIN_MENU_LAN_23", "Admin : Opprett kategori");

define("CONTENT_ADMIN_JS_LAN_0", "Er du sikker på at du vil fjerne denne kategorien?");
define("CONTENT_ADMIN_JS_LAN_1", "Er du sikker på at du vil fjerne dette innholdet?");
define("CONTENT_ADMIN_JS_LAN_2", "Er du sikker på at du vil fjerne eksisterende bilde?");
define("CONTENT_ADMIN_JS_LAN_3", "Er du sikker på at du vil fjerne denne filen?");
define("CONTENT_ADMIN_JS_LAN_4", "Bilde");
define("CONTENT_ADMIN_JS_LAN_5", "Fil");
define("CONTENT_ADMIN_JS_LAN_6", "ID");
define("CONTENT_ADMIN_JS_LAN_7", "Er du sikker på at du vil fjerne eksisterende ikon?");
define("CONTENT_ADMIN_JS_LAN_8", "Ikon");
define("CONTENT_ADMIN_JS_LAN_9", "OBS:<br />kun tomme kategorier kan slettes.<br />En kategori er tom om den IKKE innholder noen underkategorier og<br />om den IKKE innholder noen innholdsobjekter!");
define("CONTENT_ADMIN_JS_LAN_10", "Er du sikker på at du vil fjerne innsendt innhold før du har postet det?");



define("CONTENT_ADMIN_SUBMIT_LAN_0", "Ingen innholdskategori tillater brukere å sende inn materiell for øyeblikket");
define("CONTENT_ADMIN_SUBMIT_LAN_1", "Materielltype å sende inn");
define("CONTENT_ADMIN_SUBMIT_LAN_2", "Takk, innholdet er sendt inn.");
define("CONTENT_ADMIN_SUBMIT_LAN_3", "Takk, innholdet er sendt inn og kommer til å granskes av en administrator så fort som mulig.");
define("CONTENT_ADMIN_SUBMIT_LAN_4", "Nødvendig felt latt stå tomt.");
define("CONTENT_ADMIN_SUBMIT_LAN_5", "Gå tilbake til <a href='".e_SELF."'>hovedsiden for innsending</a> for tå sende inn mer materiell<br />eller<br />gå til <a href='".e_PLUGIN."content/content.php'>hovedside for innhold</a> for å se innholdet.");
define("CONTENT_ADMIN_SUBMIT_LAN_6", "");
define("CONTENT_ADMIN_SUBMIT_LAN_7", "");
define("CONTENT_ADMIN_SUBMIT_LAN_8", "Innsendt materiell slettet");
define("CONTENT_ADMIN_SUBMIT_LAN_9", "");
define("CONTENT_ADMIN_SUBMIT_LAN_10", "");
define("CONTENT_ADMIN_SUBMIT_LAN_11", "");
define("CONTENT_ADMIN_SUBMIT_LAN_12", "");
define("CONTENT_ADMIN_SUBMIT_LAN_13", "");
define("CONTENT_ADMIN_SUBMIT_LAN_14", "");
define("CONTENT_ADMIN_SUBMIT_LAN_15", "");
define("CONTENT_ADMIN_SUBMIT_LAN_16", "");
define("CONTENT_ADMIN_SUBMIT_LAN_17", "");
define("CONTENT_ADMIN_SUBMIT_LAN_18", "");
define("CONTENT_ADMIN_SUBMIT_LAN_19", "");



define("CONTENT_ADMIN_CONVERSION_LAN_0", "Innhold");
define("CONTENT_ADMIN_CONVERSION_LAN_1", "Anmeldelse");
define("CONTENT_ADMIN_CONVERSION_LAN_2", "Artikkel");
define("CONTENT_ADMIN_CONVERSION_LAN_3", "Kategori");
define("CONTENT_ADMIN_CONVERSION_LAN_4", "Kategorier");
define("CONTENT_ADMIN_CONVERSION_LAN_5", "Side");
define("CONTENT_ADMIN_CONVERSION_LAN_6", "Sider");
define("CONTENT_ADMIN_CONVERSION_LAN_7", "Hovedgruppe innlagt");
define("CONTENT_ADMIN_CONVERSION_LAN_8", "Hovedgruppeinnstillinger innlagt");
define("CONTENT_ADMIN_CONVERSION_LAN_9", "Nei");
define("CONTENT_ADMIN_CONVERSION_LAN_10", "Hovedgruppe nødvendig");
define("CONTENT_ADMIN_CONVERSION_LAN_11", "KONVERTERINGSANALYSE");
define("CONTENT_ADMIN_CONVERSION_LAN_12", "Totalt antall rader å konvertere");
define("CONTENT_ADMIN_CONVERSION_LAN_13", "Totalt antall konverterte rader");
define("CONTENT_ADMIN_CONVERSION_LAN_14", "Totalt antall advarsler");
define("CONTENT_ADMIN_CONVERSION_LAN_15", "Totalt antall misslykkede");
define("CONTENT_ADMIN_CONVERSION_LAN_16", "GAMMEL INNHOLDSTABELL: ANALYSE");
define("CONTENT_ADMIN_CONVERSION_LAN_17", "Totalt antall rader");
define("CONTENT_ADMIN_CONVERSION_LAN_18", "Antall ukjente rader");
define("CONTENT_ADMIN_CONVERSION_LAN_19", "Alle rader kjente");
define("CONTENT_ADMIN_CONVERSION_LAN_20", "HOVEDGRUPPE INNHOLD");
define("CONTENT_ADMIN_CONVERSION_LAN_21", "HOVEDGRUPPE ANMELDELSER");
define("CONTENT_ADMIN_CONVERSION_LAN_22", "HOVEDGRUPPE ARTIKLER");
define("CONTENT_ADMIN_CONVERSION_LAN_23", "Tilføyning mislyktes");
define("CONTENT_ADMIN_CONVERSION_LAN_24", "INGEN INNHOLDSSIDER FUNNET");
define("CONTENT_ADMIN_CONVERSION_LAN_25", "EKSISTERENDE INNHOLDSSIDER");
define("CONTENT_ADMIN_CONVERSION_LAN_26", "Tilføyd");
define("CONTENT_ADMIN_CONVERSION_LAN_27", "Konverteringsanalyse");
define("CONTENT_ADMIN_CONVERSION_LAN_28", "Totalt antall gamle rader");
define("CONTENT_ADMIN_CONVERSION_LAN_29", "Totalt antall nye rader");
define("CONTENT_ADMIN_CONVERSION_LAN_30", "Mislyktes");
define("CONTENT_ADMIN_CONVERSION_LAN_31", "Advarsler");
define("CONTENT_ADMIN_CONVERSION_LAN_32", "Gammel kategori finnes ikke: Objekt lagt til i en høyere kategori");
define("CONTENT_ADMIN_CONVERSION_LAN_33", "Ny kategori finnes ikke: Objekt lagt til i en høyere kategori");
define("CONTENT_ADMIN_CONVERSION_LAN_34", "Nei");
define("CONTENT_ADMIN_CONVERSION_LAN_35", "Eksisterende kategorisider");
define("CONTENT_ADMIN_CONVERSION_LAN_36", "Eksisterende sider og/eller innsendte sider");
define("CONTENT_ADMIN_CONVERSION_LAN_37", "Konvertering av kategorier");
define("CONTENT_ADMIN_CONVERSION_LAN_38", "Gyldige tilføyelser");
define("CONTENT_ADMIN_CONVERSION_LAN_39", "Mislykkede tilføyelser");
define("CONTENT_ADMIN_CONVERSION_LAN_40", "Advarsel");
define("CONTENT_ADMIN_CONVERSION_LAN_41", "Advarsel");
define("CONTENT_ADMIN_CONVERSION_LAN_42", "Konverteringsresultat for den gamle innholdstabellen til den nye innholdsplugin-tabellen");
define("CONTENT_ADMIN_CONVERSION_LAN_43", "Klikk på knappen for å konvertere den gamle tabellen");
define("CONTENT_ADMIN_CONVERSION_LAN_44", "Den nye tabellen innholder allerede data!<br />er du sikker på at du vil konvertere den gamle innholdstabellen til den nye innholdstabellen?<br /><br />Om du fortsatt vil konvertere den gamle tabellen kommer det gamle innholdet til å legges til til den allerede eksisterende nye tabellen, men ingen garantier kan gies på at alle objekter kommer til å legges til på ett korrekt vis!");
define("CONTENT_ADMIN_CONVERSION_LAN_45", "Tilføyelse mislyktes: Hovedgruppe ikke tilføyd");
define("CONTENT_ADMIN_CONVERSION_LAN_46", "Begynn å håndtere innholdet ved å gå til <a href='".e_PLUGIN."content/admin_content_config.php'>Innholdshåndtererens førsteside</a>!");
define("CONTENT_ADMIN_CONVERSION_LAN_47", "Konvertering fullført");
define("CONTENT_ADMIN_CONVERSION_LAN_48", "Klikk her for detaljene");
define("CONTENT_ADMIN_CONVERSION_LAN_49", "Konvertering av sider");
define("CONTENT_ADMIN_CONVERSION_LAN_50", "Konvertering av hovedgrupper");
define("CONTENT_ADMIN_CONVERSION_LAN_51", "Ukjente rader");
define("CONTENT_ADMIN_CONVERSION_LAN_52", "Standardoppsett av hovedgruppekategorier opprettet");
define("CONTENT_ADMIN_CONVERSION_LAN_53", "En hovedgruppe med detta navnet finnes allerede");
define("CONTENT_ADMIN_CONVERSION_LAN_54", "Opprett et standardoppsett av hovedgruppekategorier (innhold, anmeldelse og artikler)");
define("CONTENT_ADMIN_CONVERSION_LAN_55", "Innholdshåndtereren: Konverteringsalternativ");
define("CONTENT_ADMIN_CONVERSION_LAN_56", "Klikk på knappen for å gå til siden for å opprette ny innholdskategori.");
define("CONTENT_ADMIN_CONVERSION_LAN_57", "Velg verdi");
define("CONTENT_ADMIN_CONVERSION_LAN_58", "Oppgradering lyktes<br /><br /><b>OBS:<br />Du må rekonfigurer alternativene for hver hovedgruppe<br />og du må slette menyene du opprettet i innhold/meny folderen, og gjenopprette dem ved å oppdatere alternativene for de spesifike hovedgruppene du vil ha menyer til.</b>");

define("CONTENT_ADMIN_CONVERSION_LAN_59", "Konverter tabell");
define("CONTENT_ADMIN_CONVERSION_LAN_60", "Opprett standard");
define("CONTENT_ADMIN_CONVERSION_LAN_61", "Opprett ny kategori");
define("CONTENT_ADMIN_CONVERSION_LAN_62", "Innholdshhåndteringsplugin oppgradert til versjon:");
define("CONTENT_ADMIN_CONVERSION_LAN_63", "Oppgrader");
define("CONTENT_ADMIN_CONVERSION_LAN_64", "Innholdsadministrasjon utvidelse: tabellstruktur er oppdatert");
define("CONTENT_ADMIN_CONVERSION_LAN_65", "Innholdsadministrasjon utvidelse: content_author er oppdatert");
define("CONTENT_ADMIN_CONVERSION_LAN_66", "Innholdsadministrasjon utvidelse: content_preferences og menyer er oppdatert");
define("CONTENT_ADMIN_CONVERSION_LAN_67", "Innholdsadministrasjon utvidelse: content_preferences er oppdatert");
define("CONTENT_ADMIN_CONVERSION_LAN_68", "Innholdsadministrasjon utvidelse: content_theme er oppdatert");
define("CONTENT_ADMIN_CONVERSION_LAN_69", "");
define("CONTENT_ADMIN_CONVERSION_LAN_70", "");

define("CONTENT_ADMIN_OPT_LAN_MENU_1", "Alternativ:");
define("CONTENT_ADMIN_OPT_LAN_MENU_2", "Sider:");
define("CONTENT_ADMIN_OPT_LAN_MENU_3", "Admin: Opprett objekt");
define("CONTENT_ADMIN_OPT_LAN_MENU_4", "Send in objekt");
define("CONTENT_ADMIN_OPT_LAN_MENU_5", "Stier og temainnstillinger");
define("CONTENT_ADMIN_OPT_LAN_MENU_6", "Generelt");
define("CONTENT_ADMIN_OPT_LAN_MENU_7", "Innholdshåndtereren");
define("CONTENT_ADMIN_OPT_LAN_MENU_8", "Menyattributt");
define("CONTENT_ADMIN_OPT_LAN_MENU_9", "Forhåndsvis innholdsobjekt");
define("CONTENT_ADMIN_OPT_LAN_MENU_10", "Kategorisider");
define("CONTENT_ADMIN_OPT_LAN_MENU_11", "Innholdssider");
define("CONTENT_ADMIN_OPT_LAN_MENU_12", "Forfatterside");
define("CONTENT_ADMIN_OPT_LAN_MENU_13", "Arkivside");
define("CONTENT_ADMIN_OPT_LAN_MENU_14", "Toppkarakterside");
define("CONTENT_ADMIN_OPT_LAN_MENU_15", "Topprangert side");
define("CONTENT_ADMIN_OPT_LAN_MENU_16", "Side med alle kategorier (alle kategorier i hovedgruppen)");
define("CONTENT_ADMIN_OPT_LAN_MENU_17", "Vis kategoriside (hovedgruppeobjekt, underkategorier og innholdsobjekt i den kategorien");
define("CONTENT_ADMIN_OPT_LAN_MENU_18", "Kategorier");
define("CONTENT_ADMIN_OPT_LAN_MENU_19", "List nyeste objekter");
define("CONTENT_ADMIN_OPT_LAN_MENU_20", "Linker til sider");
define("CONTENT_ADMIN_OPT_LAN_MENU_21", "Admin : Opprett kategori");


define("CONTENT_ADMIN_OPT_LAN_SECTION_0", "Seksjoner");
define("CONTENT_ADMIN_OPT_LAN_SECTION_1", "Velg hva som kommer til å vises");
define("CONTENT_ADMIN_OPT_LAN_SECTION_2", "Vedlegg");
define("CONTENT_ADMIN_OPT_LAN_SECTION_3", "Bilder");
define("CONTENT_ADMIN_OPT_LAN_SECTION_4", "Kommentar");
define("CONTENT_ADMIN_OPT_LAN_SECTION_5", "Karakter");
define("CONTENT_ADMIN_OPT_LAN_SECTION_6", "Rangering");
define("CONTENT_ADMIN_OPT_LAN_SECTION_7", "Synlighet");
define("CONTENT_ADMIN_OPT_LAN_SECTION_8", "Metadefinisjon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_9", "Layoutscheman");
define("CONTENT_ADMIN_OPT_LAN_SECTION_10", "Egne datatag'er");
define("CONTENT_ADMIN_OPT_LAN_SECTION_11", "Ferdiglagde datatag'er");
define("CONTENT_ADMIN_OPT_LAN_SECTION_12", "Underoverskrift");
define("CONTENT_ADMIN_OPT_LAN_SECTION_13", "Summering");
define("CONTENT_ADMIN_OPT_LAN_SECTION_14", "Tekst (definer antall ord)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_15", "Dato");
define("CONTENT_ADMIN_OPT_LAN_SECTION_16", "Forfatter: Namn");
define("CONTENT_ADMIN_OPT_LAN_SECTION_17", "Forfatter: E-post");
define("CONTENT_ADMIN_OPT_LAN_SECTION_18", "Forfatter: Link til forfatterens profil");
define("CONTENT_ADMIN_OPT_LAN_SECTION_19", "Forfatter: Link til forfatterliste");
define("CONTENT_ADMIN_OPT_LAN_SECTION_20", "Epost/Skriv ut/PDF ikon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_21", "Foregående gruppe");
define("CONTENT_ADMIN_OPT_LAN_SECTION_22", "Henvist (kun om logging er aktivert)");
define("CONTENT_ADMIN_OPT_LAN_SECTION_23", "Antall objekt");
define("CONTENT_ADMIN_OPT_LAN_SECTION_24", "Nyeste objekt fra hver forfatter");
define("CONTENT_ADMIN_OPT_LAN_SECTION_25", "Antall objekter fra hver forfatter");
define("CONTENT_ADMIN_OPT_LAN_SECTION_26", "Ikon for hurtigredigering");
define("CONTENT_ADMIN_OPT_LAN_SECTION_27", "Ikon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_28", "av kategoriobjektet");
define("CONTENT_ADMIN_OPT_LAN_SECTION_29", "av listen over underkategorier");
define("CONTENT_ADMIN_OPT_LAN_SECTION_30", "Aktivert");
define("CONTENT_ADMIN_OPT_LAN_SECTION_31", "Deaktivert");
define("CONTENT_ADMIN_OPT_LAN_SECTION_32", "underskrift");
define("CONTENT_ADMIN_OPT_LAN_SECTION_33", "startdato");
define("CONTENT_ADMIN_OPT_LAN_SECTION_34", "sluttdato");
define("CONTENT_ADMIN_OPT_LAN_SECTION_35", "opplastningsikol");
define("CONTENT_ADMIN_OPT_LAN_SECTION_36", "tildel ikon");
define("CONTENT_ADMIN_OPT_LAN_SECTION_37", "Admin : Opprett kategori");
define("CONTENT_ADMIN_OPT_LAN_SECTION_38", "sammendrag");
define("CONTENT_ADMIN_OPT_LAN_SECTION_39", "");


define("CONTENT_PRESET_LAN_0", "Feil: Feltnavn ikke utfylt");
define("CONTENT_PRESET_LAN_1", "Feil: Alle felt er ikke korrekt utfylt<br />Alle felt må fylles ut");
define("CONTENT_PRESET_LAN_2", "");
define("CONTENT_PRESET_LAN_3", "Både størrelse og maksstørrelse må være numeriske verdier");
define("CONTENT_PRESET_LAN_4", "Både kolonner og rader må være numeriske verdier");
define("CONTENT_PRESET_LAN_5", "Du må angi alternativer");
define("CONTENT_PRESET_LAN_6", "Både Fra år og Til år må være numeriske verdier");
define("CONTENT_PRESET_LAN_7", "Generator for ferdiginnstilte felt til innhold");
define("CONTENT_PRESET_LAN_8", "Opprett nya ferdiginnstilte datatag'er av type");
define("CONTENT_PRESET_LAN_9", "Feltnavn");
define("CONTENT_PRESET_LAN_10", "Størrelse");
define("CONTENT_PRESET_LAN_11", "Makslengde");
define("CONTENT_PRESET_LAN_12", "Kolonner");
define("CONTENT_PRESET_LAN_13", "Rader");
define("CONTENT_PRESET_LAN_14", "Fra år");
define("CONTENT_PRESET_LAN_15", "Til år");
define("CONTENT_PRESET_LAN_16", "Alternativ");
define("CONTENT_PRESET_LAN_17", "Legg til mer");
define("CONTENT_PRESET_LAN_18", "Legg til fordefinert");
define("CONTENT_PRESET_LAN_19", "Du må angi samma antall tekst og verdifelt");
define("CONTENT_PRESET_LAN_20", "Du må ang en verdi for kryssruten");
define("CONTENT_PRESET_LAN_21", "Tekst");
define("CONTENT_PRESET_LAN_22", "Verdi");
define("CONTENT_PRESET_LAN_23", "Velg tekst");
define("CONTENT_PRESET_LAN_24", "Det første alternativet uten verdi");
define("CONTENT_PRESET_LAN_25", "Legg til felt...");
define("CONTENT_PRESET_LAN_26", "Tekst");
define("CONTENT_PRESET_LAN_27", "Tekstområde");
define("CONTENT_PRESET_LAN_28", "Velg");
define("CONTENT_PRESET_LAN_29", "Dato");
define("CONTENT_PRESET_LAN_30", "Kryssrute");
define("CONTENT_PRESET_LAN_31", "Radioknapp");
define("CONTENT_PRESET_LAN_32", "Eksempel:");



define("CONTENT_ADMIN_OPT_LAN_0", "Alternativ");
define("CONTENT_ADMIN_OPT_LAN_1", "Standardinnstillinger");
define("CONTENT_ADMIN_OPT_LAN_2", "Oppdater alternativ");
define("CONTENT_ADMIN_OPT_LAN_3", "Antall bilder som kan lastes opp");
define("CONTENT_ADMIN_OPT_LAN_4", "Antall vedlegg som kan lastes opp");
define("CONTENT_ADMIN_OPT_LAN_5", "Antall egne datatag'er tilgjengelig");
define("CONTENT_ADMIN_OPT_LAN_6", "Forinnstilte datatag'er");
define("CONTENT_ADMIN_OPT_LAN_7", "Definer forinnstilte standard datatag'er");
//define("CONTENT_ADMIN_OPT_LAN_8", "Her kan du legge til fler data tagger. Feltene du skriver inn her er verdien til nøkkel=>verdi data tagger. Dem kommer til å ha en input element for verdien som blir satt i admin opprettelse skjema. Du kan velge fra nedtrekksmenyen hvordan type element du ønsker at data taggen skal være. Noter:  dette er ekke en del av mengden av tilpasset data tagger som du har spesifisert over, og vil bli brukt i tillegg.");
define("CONTENT_ADMIN_OPT_LAN_9", "Tillat innsending av objekt?");
define("CONTENT_ADMIN_OPT_LAN_10", "Hvem kan sende inn objekt?");
define("CONTENT_ADMIN_OPT_LAN_11", "Direkteposting");
define("CONTENT_ADMIN_OPT_LAN_12", "Hvis aktivert kommer et innsendt objekt til å legges til i databasen og bli synlig omgående, ellers må en nettstedsadmin godkjenne objektet.");
define("CONTENT_ADMIN_OPT_LAN_13", "Her kan du angi hvor bildene dine finnes, eller kommer til å lagres. Bruk parantesene ( { } ) for de generelle e107 relaterte stivariablene (som f.eks. ( {e_PLUGIN} eller {e_IMAGE} ). Det trengs to versjoner for kategoriikoner, en liten og en stor versjon av ikonene. TMP-variablene kreves for opplasting, du må opprette dem!");
define("CONTENT_ADMIN_OPT_LAN_15", "Sti til kategoriikoner (store)");
define("CONTENT_ADMIN_OPT_LAN_16", "Sti til kategoriikoner (små)");
define("CONTENT_ADMIN_OPT_LAN_17", "Sti til objektikoner");
define("CONTENT_ADMIN_OPT_LAN_18", "Sti til objektbilder");
define("CONTENT_ADMIN_OPT_LAN_19", "Sti til objektvedlegg");
define("CONTENT_ADMIN_OPT_LAN_20", "Ang tema for denne kategorien");

define("CONTENT_ADMIN_OPT_LAN_21", "Definier standard layoutschema");
define("CONTENT_ADMIN_OPT_LAN_22", "Aktiver logging av henvisningsteller");
define("CONTENT_ADMIN_OPT_LAN_23", "Vis tomt objektikon om ingen ikoner er definert");
define("CONTENT_ADMIN_OPT_LAN_24", "Vis tomt kategoriikon om ingen ikoner er definert");
define("CONTENT_ADMIN_OPT_LAN_25", "Velg ett layoutschema");
define("CONTENT_ADMIN_OPT_LAN_26", "Vis bakoversporing på disse sidene:");
define("CONTENT_ADMIN_OPT_LAN_27", "Alle kategorier");
define("CONTENT_ADMIN_OPT_LAN_28", "Enkelt kategori");
define("CONTENT_ADMIN_OPT_LAN_29", "Alle forfattere");
define("CONTENT_ADMIN_OPT_LAN_30", "Enkeltforfatter");
define("CONTENT_ADMIN_OPT_LAN_31", "Nyeste");
define("CONTENT_ADMIN_OPT_LAN_32", "innholdsobjekt");
define("CONTENT_ADMIN_OPT_LAN_33", "Toppkarakter");
define("CONTENT_ADMIN_OPT_LAN_34", "Arkiv");
define("CONTENT_ADMIN_OPT_LAN_35", "Rangering");
define("CONTENT_ADMIN_OPT_LAN_36", "Delningstegn for bakoversporingen");
define("CONTENT_ADMIN_OPT_LAN_37", "Angi hvordan bakoversporingsinformasjonen skal vises");
define("CONTENT_ADMIN_OPT_LAN_38", "TMP");
define("CONTENT_ADMIN_OPT_LAN_39", "ekko");
define("CONTENT_ADMIN_OPT_LAN_40", "Bruk separat meny");
define("CONTENT_ADMIN_OPT_LAN_41", "Kombiner i en meny");
define("CONTENT_ADMIN_OPT_LAN_42", "");
define("CONTENT_ADMIN_OPT_LAN_43", "Vis navigator på disse sidene:");
define("CONTENT_ADMIN_OPT_LAN_44", "Vis søk på disse sidene:");
define("CONTENT_ADMIN_OPT_LAN_45", "");
define("CONTENT_ADMIN_OPT_LAN_46", "Vis sorteringsvalg på disse sidene:");
define("CONTENT_ADMIN_OPT_LAN_47", "");
define("CONTENT_ADMIN_OPT_LAN_48", "Visningstype navigator/søk/ordne");
define("CONTENT_ADMIN_OPT_LAN_49", "Vis begrenset antall objekter pr side");
define("CONTENT_ADMIN_OPT_LAN_50", "Hvor mange objekter skal vises");
define("CONTENT_ADMIN_OPT_LAN_51", "Velg standardsortering");
define("CONTENT_ADMIN_OPT_LAN_52", "Maks billedstørrelse");
define("CONTENT_ADMIN_OPT_LAN_53", "Angi til hvilken størrelse opplastede bilder skal forminskes");
define("CONTENT_ADMIN_OPT_LAN_54", "Om høyden eller bredden på det opplastede bildet er større enn angitt verdi kommer bildet til å forminskes til denne verdien.<br />Popupbilder kommer også til å vises med denne størrelsen.");
define("CONTENT_ADMIN_OPT_LAN_55", "Minibildestørrelse");
define("CONTENT_ADMIN_OPT_LAN_56", "Angi hvilken størrelse minibildene til de opplastede bildene skal opprettes med");
define("CONTENT_ADMIN_OPT_LAN_57", "Om høyden eller bredden på det opplastede bildet er større enn angitt verdi kommer bildet til å forminskes til denne verdien.<br />Bildene kommer også til å vises med denne størrelsen på innholdssidene.");
define("CONTENT_ADMIN_OPT_LAN_58", "Maks ikonbredde");
define("CONTENT_ADMIN_OPT_LAN_59", "Angi maksimal bredde på ikon ved opplastning");
define("CONTENT_ADMIN_OPT_LAN_60", "Om det opplastede ikonet er større enn angitt verdi kommer det til å forminskes til denne verdien.<br />Ikonet kommer også til å vises med denne størrelsen .");
define("CONTENT_ADMIN_OPT_LAN_61", "pxl");
define("CONTENT_ADMIN_OPT_LAN_62", "Velg håndterer fra denne brukerklassen");
define("CONTENT_ADMIN_OPT_LAN_63", "rukerlisten i admins innholdshåndterer kommer kun til å inneholde brukerne i den angitte klassen. Du må fortsatt tildele brukere til hver kategori! Denne klassen kommer bara til å begrense antallet brukere å velge fra.");
define("CONTENT_ADMIN_OPT_LAN_64", "Vis epostadressen til forfattere som ikke er medlem");
define("CONTENT_ADMIN_OPT_LAN_65", "Vis en bokstavindeks");
define("CONTENT_ADMIN_OPT_LAN_66", "Bokstavindeks er en liste med knapper med de første bokstavene fra innholdets overskriftfelt. Du kan begrense arkivlisten ved å klikke på en bokstav, da kommer bara innhold som begynner på den bokstaven til å vises på skjermen.");
define("CONTENT_ADMIN_OPT_LAN_67", "Angi datostil for visning av dato");
define("CONTENT_ADMIN_OPT_LAN_68", "For mer informasjon om datoformat, se <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funksjonens side på php.net</a>");
define("CONTENT_ADMIN_OPT_LAN_69", "Vis ikoner for alle objekter<br />(Skriv ut/Epost/PDF ikoner)");
define("CONTENT_ADMIN_OPT_LAN_70", "Tillat karakterssetting av alle objekt");
define("CONTENT_ADMIN_OPT_LAN_71", "Tillat kommentarer til alle objekt");
define("CONTENT_ADMIN_OPT_LAN_72", "");
define("CONTENT_ADMIN_OPT_LAN_73", "Visningstype for flersidesindeks");
define("CONTENT_ADMIN_OPT_LAN_74", "Om du har en flersidig artikell kan du enten vise en artikellindeks over disse sidene som en lista med normal hyperlenker, eller vise dem i en valgrute");
define("CONTENT_ADMIN_OPT_LAN_75", "Hyperlenkar");
define("CONTENT_ADMIN_OPT_LAN_76", "Valgrute");
define("CONTENT_ADMIN_OPT_LAN_77", "Angi antall tegn");
define("CONTENT_ADMIN_OPT_LAN_78", "Definer et postfiks");
define("CONTENT_ADMIN_OPT_LAN_79", "La stå tomt for å vise hele");
define("CONTENT_ADMIN_OPT_LAN_80", "La tomt stå for å ikke vise noe");
define("CONTENT_ADMIN_OPT_LAN_81", "Angi antall ord");
define("CONTENT_ADMIN_OPT_LAN_82", "Tekst");
define("CONTENT_ADMIN_OPT_LAN_83", "Legg til en link til postfiks");
define("CONTENT_ADMIN_OPT_LAN_84", "Vis gruppeobjektet");
define("CONTENT_ADMIN_OPT_LAN_85", "Vis gruppens underkategorier");
define("CONTENT_ADMIN_OPT_LAN_86", "Vis objektene i gruppens underkategorier");
define("CONTENT_ADMIN_OPT_LAN_87", "Hvis aktivert kommer alle objekter fra den valgte kategorien og alle dens underliggende kategorier til å vises.");
define("CONTENT_ADMIN_OPT_LAN_88", "Angi visningsrekkefølgen for gruppe og underliggende objekt");
define("CONTENT_ADMIN_OPT_LAN_89", "Grupper først, deretter objekt");
define("CONTENT_ADMIN_OPT_LAN_90", "Objekt først, deretter grupper");
define("CONTENT_ADMIN_OPT_LAN_91", "Visningstype for gruppe, underkat. og objekt");
define("CONTENT_ADMIN_OPT_LAN_92", "Hver i en separat meny");
define("CONTENT_ADMIN_OPT_LAN_93", "Overskrift");
define("CONTENT_ADMIN_OPT_LAN_94", "Legg til søkerute");
define("CONTENT_ADMIN_OPT_LAN_95", "Legg til sorter og ordne rute");
define("CONTENT_ADMIN_OPT_LAN_96", "Vis navigatorlinker");
define("CONTENT_ADMIN_OPT_LAN_97", "Hvis deaktivert kommer alle linkalternativer til å overses");
define("CONTENT_ADMIN_OPT_LAN_98", "Link: alle kategorier");
define("CONTENT_ADMIN_OPT_LAN_99", "Link: Alle forfattere");
define("CONTENT_ADMIN_OPT_LAN_100", "Link: Alle innholdsobjekt");
define("CONTENT_ADMIN_OPT_LAN_101", "Link: Toppkarakter");
define("CONTENT_ADMIN_OPT_LAN_102", "Link: Topprangert");
define("CONTENT_ADMIN_OPT_LAN_103", "Link: Nyeste objekt");
define("CONTENT_ADMIN_OPT_LAN_104", "Link: Send inn objekt");
define("CONTENT_ADMIN_OPT_LAN_105", "Ikon: Linker");
define("CONTENT_ADMIN_OPT_LAN_106", "Ingen (), Punkt (), Mellompunkt (·), Hvitt punkt (º), Pil (»), Innholdsikon()");
define("CONTENT_ADMIN_OPT_LAN_107", "Ingen");
define("CONTENT_ADMIN_OPT_LAN_108", "Punkt");
define("CONTENT_ADMIN_OPT_LAN_109", "Mellompunkt");
define("CONTENT_ADMIN_OPT_LAN_110", "Hvitt punkt");
define("CONTENT_ADMIN_OPT_LAN_111", "Pil");
define("CONTENT_ADMIN_OPT_LAN_112", "Kategoriikon");
define("CONTENT_ADMIN_OPT_LAN_113", "Innholdsikon");
define("CONTENT_ADMIN_OPT_LAN_114", "Visningstype for linker");
define("CONTENT_ADMIN_OPT_LAN_115", "Overskrift for linkliste");
define("CONTENT_ADMIN_OPT_LAN_116", "Denne overskriften kommer bare til å brukes om linkene vises som 'normale linker'.");
define("CONTENT_ADMIN_OPT_LAN_117", "Vis kategorier");
define("CONTENT_ADMIN_OPT_LAN_118", "Inkluder hovedkategori");
define("CONTENT_ADMIN_OPT_LAN_119", "Hvis deaktivert kommer kun underkategoriene fra gruppen til å vises");
define("CONTENT_ADMIN_OPT_LAN_120", "Antall objekter å vise i hver kategori");
define("CONTENT_ADMIN_OPT_LAN_121", "Ikon: Kategori");
define("CONTENT_ADMIN_OPT_LAN_122", "Ikon: Kategori (standard)");
define("CONTENT_ADMIN_OPT_LAN_123", "Visningstype for kategorilistan");
define("CONTENT_ADMIN_OPT_LAN_124", "Overskrift på kategorilisten");
define("CONTENT_ADMIN_OPT_LAN_125", "Vis liste over nyeste objekter");
define("CONTENT_ADMIN_OPT_LAN_126", "Vis dato");
define("CONTENT_ADMIN_OPT_LAN_127", "Vis forfattere");
define("CONTENT_ADMIN_OPT_LAN_128", "Vis underoverskrift");
define("CONTENT_ADMIN_OPT_LAN_129", "Underoverskrift: Angi antall ord");
define("CONTENT_ADMIN_OPT_LAN_130", "Underoverskrift: Ang postfiks");
define("CONTENT_ADMIN_OPT_LAN_131", "Hvor mange objekter skal vises");
define("CONTENT_ADMIN_OPT_LAN_132", "Ikon for nyeste objekt");
define("CONTENT_ADMIN_OPT_LAN_133", "Ikon: Bredde");
define("CONTENT_ADMIN_OPT_LAN_134", "Om 'innholdsikon' er valgt, angi bredden på ikonet som skal brukes");
define("CONTENT_ADMIN_OPT_LAN_135", "Overskrift for nyeste objekt listen");
define("CONTENT_ADMIN_OPT_LAN_136", "Bakdel");
define("CONTENT_ADMIN_OPT_LAN_137", "Fordel");
define("CONTENT_ADMIN_OPT_LAN_138", "Administrer innhold");
define("CONTENT_ADMIN_OPT_LAN_139", "Opprett innhold");
define("CONTENT_ADMIN_OPT_LAN_140", "Administrer kategori");
define("CONTENT_ADMIN_OPT_LAN_141", "Opprett kategori");
define("CONTENT_ADMIN_OPT_LAN_142", "rekkefølge");
define("CONTENT_ADMIN_OPT_LAN_143", "Alternativer");
define("CONTENT_ADMIN_OPT_LAN_144", "Personlig innholdsadministrasjon");
define("CONTENT_ADMIN_OPT_LAN_145", "Nylig");
define("CONTENT_ADMIN_OPT_LAN_146", "Alle kategorier");
define("CONTENT_ADMIN_OPT_LAN_147", "En kategori");
define("CONTENT_ADMIN_OPT_LAN_148", "Innholdssak");
define("CONTENT_ADMIN_OPT_LAN_149", "Forfatterside");
define("CONTENT_ADMIN_OPT_LAN_150", "Arkivside");
define("CONTENT_ADMIN_OPT_LAN_151", "Topp rangertside");
define("CONTENT_ADMIN_OPT_LAN_152", "Toppskårside");
define("CONTENT_ADMIN_OPT_LAN_153", "Innsendingsside");
define("CONTENT_ADMIN_OPT_LAN_154", "Administratorside");
define("CONTENT_ADMIN_OPT_LAN_155", "overskrivf");
define("CONTENT_ADMIN_OPT_LAN_156", "Overskrift indexside");
define("CONTENT_ADMIN_OPT_LAN_157", "Overskrift forfatterside");
define("CONTENT_ADMIN_OPT_LAN_158", "Tilføye forfatters navn i overskrift");
define("CONTENT_ADMIN_OPT_LAN_159", "Overskrift kategoriside");
define("CONTENT_ADMIN_OPT_LAN_160", "Tilføye kategoritittel i overskrift");
define("CONTENT_ADMIN_OPT_LAN_161", "Overskrift topunderkategori (brukes bare om innstillingene er satt til sepatate menyer)");
define("CONTENT_ADMIN_OPT_LAN_162", "Overskrift innholdssaker (brukes bare om innstillingene er satt til sepatate menyer)");
define("CONTENT_ADMIN_OPT_LAN_163", "Vis neste og forige sidelinker");
define("CONTENT_ADMIN_OPT_LAN_164", "Overskrift for forige sidelink<br />(bruk {PAGETITLE} for å legge til tittelen for forige side)");
define("CONTENT_ADMIN_OPT_LAN_165", "Overskrift for neste sidelink<br />(bruk {PAGETITLE} for å legge til tittelen for forige side)");
define("CONTENT_ADMIN_OPT_LAN_166", "bruk 'alle' for å vise full tekst");
define("CONTENT_ADMIN_OPT_LAN_167", "arve");
define("CONTENT_ADMIN_OPT_LAN_168", "første side");
define("CONTENT_ADMIN_OPT_LAN_169", "siste side");
define("CONTENT_ADMIN_OPT_LAN_170", "hvor skal alternativ- og fastsatt-merkelapp være plassert i en flersiders innholdssak ?");
define("CONTENT_ADMIN_OPT_LAN_171", "antall nivå");
define("CONTENT_ADMIN_OPT_LAN_172", "numerisk verdi for å vise antall nivåer av underkategorier i kategoritreet. La den være blank for å vise alle nivåer.");
define("CONTENT_ADMIN_OPT_LAN_173", "inkluder 'hjem' i smådeler");
define("CONTENT_ADMIN_OPT_LAN_174", "inkluder innholdsstartsiden i smådeler");

// Gap for compatibility with 0.8

define('CONTENT_ADMIN_OPT_LAN_178', 'Starttid for innhold');

?>