<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/Norwegian/lan_content.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/


define("CONTENT_EMAILPRINT_LAN_1", "Dette innholdet kommer fra");

define("POPUP_LAN_1", "Klikk for å forstørre bildet");

define("CONTENT_NOTIFY_LAN_1", "Innholdshendelse");
define("CONTENT_NOTIFY_LAN_2", "Innholdssak sent inn av bruker");
define("CONTENT_NOTIFY_LAN_3", "Innhold sent inn");

define("CONTENT_TYPE_LAN_0", "kategorier");
define("CONTENT_TYPE_LAN_1", "forfattere");
define("CONTENT_TYPE_LAN_2", "arkiv");
define("CONTENT_TYPE_LAN_3", "best rangert");
define("CONTENT_TYPE_LAN_4", "toppscore");
define("CONTENT_TYPE_LAN_5", "nylig");

define("CONTENT_ICON_LAN_0", "endre");
define("CONTENT_ICON_LAN_1", "slett");
define("CONTENT_ICON_LAN_2", "alternativ");
define("CONTENT_ICON_LAN_3", "brukerdetaljer");
define("CONTENT_ICON_LAN_4", "last ned vedlegg");
define("CONTENT_ICON_LAN_5", "ny");
define("CONTENT_ICON_LAN_6", "send innhold");
define("CONTENT_ICON_LAN_7", "forfatterliste");
define("CONTENT_ICON_LAN_8", "advarsel");
define("CONTENT_ICON_LAN_9", "ok");
define("CONTENT_ICON_LAN_10", "feil");
define("CONTENT_ICON_LAN_11", "sorter objekt i kategori");
define("CONTENT_ICON_LAN_12", "sorter objekt i hovedgruppe");
define("CONTENT_ICON_LAN_13", "personlig admin");
define("CONTENT_ICON_LAN_14", "personlig innholdshåndterer");
define("CONTENT_ICON_LAN_15", "vis");

define("CONTENT_ADMIN_DATE_LAN_0", "Januar");
define("CONTENT_ADMIN_DATE_LAN_1", "Februar");
define("CONTENT_ADMIN_DATE_LAN_2", "Mars");
define("CONTENT_ADMIN_DATE_LAN_3", "April");
define("CONTENT_ADMIN_DATE_LAN_4", "Mai");
define("CONTENT_ADMIN_DATE_LAN_5", "Juni");
define("CONTENT_ADMIN_DATE_LAN_6", "Juli");
define("CONTENT_ADMIN_DATE_LAN_7", "August");
define("CONTENT_ADMIN_DATE_LAN_8", "September");
define("CONTENT_ADMIN_DATE_LAN_9", "Oktober");
define("CONTENT_ADMIN_DATE_LAN_10", "November");
define("CONTENT_ADMIN_DATE_LAN_11", "Desember");
define("CONTENT_ADMIN_DATE_LAN_12", "dag");
define("CONTENT_ADMIN_DATE_LAN_13", "måned");
define("CONTENT_ADMIN_DATE_LAN_14", "år");
define("CONTENT_ADMIN_DATE_LAN_15", "Startdato");
define("CONTENT_ADMIN_DATE_LAN_16", "Sluttdato");
define("CONTENT_ADMIN_DATE_LAN_17", "Du kan angi en startdato for denne innholdsposten. Om du angir en framtidig dato kommer innholdet til å synes fra den datoen og framover. Om du ikke behøver en spesiell startdato, la feltene være som de er.");
define("CONTENT_ADMIN_DATE_LAN_18", "Du kan angi en sluttdato for denne innholdsposten. Med sluttdato definerer du fram til hvilken dato posten skal vises. Om du ikke behøver en spesiell sluttdato, la feltene være som de er.");

define("CONTENT_PAGETITLE_LAN_0", "Innhold");
define("CONTENT_PAGETITLE_LAN_1", "Hoved");
define("CONTENT_PAGETITLE_LAN_2", "Nyeste");
define("CONTENT_PAGETITLE_LAN_3", "Kategori");
define("CONTENT_PAGETITLE_LAN_4", "Topprangert");
define("CONTENT_PAGETITLE_LAN_5", "Forfatter");
define("CONTENT_PAGETITLE_LAN_6", "Arkiv");
define("CONTENT_PAGETITLE_LAN_7", "Send");
define("CONTENT_PAGETITLE_LAN_8", "Send inn innholdsobjekt");
define("CONTENT_PAGETITLE_LAN_9", "Personlig innholdshåndterer");
define("CONTENT_PAGETITLE_LAN_10", "Vis objekt");
define("CONTENT_PAGETITLE_LAN_11", "Endre objekt");
define("CONTENT_PAGETITLE_LAN_12", "Opprett objekt");
define("CONTENT_PAGETITLE_LAN_13", "Kategorier");
define("CONTENT_PAGETITLE_LAN_14", "Forfatterliste");
define("CONTENT_PAGETITLE_LAN_15", "Toppoeng");

define("CONTENT_SEARCH_LAN_0", "Intet innhold funnet med disse nøkkelordene.");

define("CONTENT_ORDER_LAN_0", "sorter etter ...");
define("CONTENT_ORDER_LAN_1", "Overskrift (Stig.)");
define("CONTENT_ORDER_LAN_2", "Overskrift (Synk.)");
define("CONTENT_ORDER_LAN_3", "Dato (Stig.)");
define("CONTENT_ORDER_LAN_4", "Dato (Synk.)");
define("CONTENT_ORDER_LAN_5", "Hensvisn. (Stig.)");
define("CONTENT_ORDER_LAN_6", "Hensvisn. (Synk.)");
define("CONTENT_ORDER_LAN_7", "Gruppe (Stig.)");
define("CONTENT_ORDER_LAN_8", "Gruppe (Synk.)");
define("CONTENT_ORDER_LAN_9", "Rekkefølge (Stig.)");
define("CONTENT_ORDER_LAN_10", "Rekkefølge (Synk.)");
define("CONTENT_ORDER_LAN_11", "Forfatter (Stig.)");
define("CONTENT_ORDER_LAN_12", "Forfatter (Synk.)");

define("CONTENT_LAN_0", "Innhold");
define("CONTENT_LAN_1", "List nyeste");
define("CONTENT_LAN_2", "Kategoriliste");
define("CONTENT_LAN_3", "Kategori");
define("CONTENT_LAN_4", "Forfatterliste");
define("CONTENT_LAN_5", "Forfatter");
define("CONTENT_LAN_6", "Alle kategorier");
define("CONTENT_LAN_7", "Alle forfattere");
define("CONTENT_LAN_8", "topprangerte objekter");
define("CONTENT_LAN_9", "i");
define("CONTENT_LAN_10", "den");
define("CONTENT_LAN_11", "av");
define("CONTENT_LAN_12", "topprangerte objekter");
define("CONTENT_LAN_13", "liste");
define("CONTENT_LAN_14", "-- kategorier --");
define("CONTENT_LAN_15", "ingen forfattere enda");
define("CONTENT_LAN_16", "[les mer]");
define("CONTENT_LAN_17", "");
define("CONTENT_LAN_18", "søk på nøkkelord");
define("CONTENT_LAN_19", "Søk");
define("CONTENT_LAN_20", "Søkeresultat innhold");
define("CONTENT_LAN_21", "Ingen innholdstyper enda.");
define("CONTENT_LAN_22", "Innholdstyper");
define("CONTENT_LAN_23", "List nyeste innhold");
define("CONTENT_LAN_24", "Bakoversporing");
define("CONTENT_LAN_25", "Innholdskategorier");
define("CONTENT_LAN_26", "Innholdskategori");
define("CONTENT_LAN_27", "Underkategorier");
define("CONTENT_LAN_28", "Tittelunderkategorier");
define("CONTENT_LAN_29", "Ukjent");
define("CONTENT_LAN_30", "Innholdsobjekt");
define("CONTENT_LAN_31", "Innholdsobjekter");
define("CONTENT_LAN_32", "Forfatterliste");
define("CONTENT_LAN_33", "Gå til siden");
define("CONTENT_LAN_34", "Innhold");
define("CONTENT_LAN_35", "Kommentarer");
define("CONTENT_LAN_36", "Moderer kommentarer");
define("CONTENT_LAN_37", "Ingen innholdsobjekter karaktersatt");
define("CONTENT_LAN_38", "Topprangerte innholdsobjekt");
define("CONTENT_LAN_39", "Forfatterlista");
define("CONTENT_LAN_40", "Forfatterdetaljer");
define("CONTENT_LAN_41", "Last ned vedlegg");
define("CONTENT_LAN_42", "Fil");
define("CONTENT_LAN_43", "Filer");
define("CONTENT_LAN_44", "Treff:");
define("CONTENT_LAN_45", "Forfatterens poeng:");
define("CONTENT_LAN_46", "Artikellindeks");
define("CONTENT_LAN_47", "Forfatter");
define("CONTENT_LAN_48", "Innholdsobjekt");
define("CONTENT_LAN_49", "Nyeste objekt");
define("CONTENT_LAN_50", "Dato");
define("CONTENT_LAN_51", "Typeliste");
define("CONTENT_LAN_52", "Ingen gyldige forfattere funnet");
define("CONTENT_LAN_53", "objekt");
define("CONTENT_LAN_54", "objekter");
define("CONTENT_LAN_55", "Nyeste emner den");
define("CONTENT_LAN_56", "Vis oversikt over");
define("CONTENT_LAN_57", "Kommentarer:");
define("CONTENT_LAN_58", "Hjem");
define("CONTENT_LAN_59", "Innhold");
define("CONTENT_LAN_60", "Nyeste");
define("CONTENT_LAN_61", "Vis nyeste objekt");
define("CONTENT_LAN_62", "Vis alle kategorier");
define("CONTENT_LAN_63", "Vis alle forfattere");
define("CONTENT_LAN_64", "Vis topprangerte objekt");
define("CONTENT_LAN_65", "Send inn innhold");
define("CONTENT_LAN_66", "Klikk her for å sende inn innhold, du kan velge kategori på innsendersiden.");
define("CONTENT_LAN_67", "Personlig innholdshåndterer");
define("CONTENT_LAN_68", "Klikk her for ¨håndtere ditt personlige innhold.");
define("CONTENT_LAN_69", "Send på epost");
define("CONTENT_LAN_70", "Skriv ut");
define("CONTENT_LAN_71", "Innholdsobjektet");
define("CONTENT_LAN_72", "Kategoriobjektet");
define("CONTENT_LAN_73", "Rekkefølge (Stig)");
define("CONTENT_LAN_74", "Rekkefølge (Fall)");
define("CONTENT_LAN_75", "Send inn innhold");
define("CONTENT_LAN_76", "Opprett PDF-fil fra");
define("CONTENT_LAN_77", "Søking innhold");
define("CONTENT_LAN_78", "Tittelløs side");
define("CONTENT_LAN_79", "Side");
define("CONTENT_LAN_80", "Nyeste objekt: ");
define("CONTENT_LAN_81", "Kategorier");
define("CONTENT_LAN_82", "Ingen objekter enda i");
define("CONTENT_LAN_83", "Objektarkiv");
define("CONTENT_LAN_84", "Innholdsarkiv");
define("CONTENT_LAN_85", "Forfatterliste");
define("CONTENT_LAN_86", "Vis topprangerte objekt");
define("CONTENT_LAN_87", "Topprangert innhold");
define("CONTENT_LAN_88", "Intet innhold er rangert enda");
define("CONTENT_LAN_89", "Velg side");
define("CONTENT_LAN_90", "forige side");
define("CONTENT_LAN_91", "neste side");
define("CONTENT_LAN_92", " - gjeldende");

define('CONTENT_LAN_ALL', 'alt');

define("CONTENT_MENU_LAN_0", "Innholdsmeny :");
define("CONTENT_MENU_LAN_1", "Ingen innholdsobjekt enda");
define("CONTENT_MENU_LAN_2", "Nyeste objekt");
define("CONTENT_MENU_LAN_3", "Kategorier");
define("CONTENT_MENU_LAN_4", "Innholdslinker");
define("CONTENT_MENU_LAN_5", "det er ikke noe innhold i");
define("CONTENT_MENU_LAN_6", "");
define("CONTENT_MENU_LAN_7", "");
define("CONTENT_MENU_LAN_8", "");
define("CONTENT_MENU_LAN_9", "");
define("CONTENT_MENU_LAN_10", "");
define("CONTENT_MENU_LAN_11", "");
define("CONTENT_MENU_LAN_12", "");
define("CONTENT_MENU_LAN_13", "");
define("CONTENT_MENU_LAN_14", "");
define("CONTENT_MENU_LAN_15", "");
define("CONTENT_MENU_LAN_16", "");
define("CONTENT_MENU_LAN_17", "");
define("CONTENT_MENU_LAN_18", "");
define("CONTENT_MENU_LAN_19", "");
define("CONTENT_MENU_LAN_20", "");

?>