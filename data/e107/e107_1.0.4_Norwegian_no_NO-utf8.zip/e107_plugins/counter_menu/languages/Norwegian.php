<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
	
define("COUNTER_L1", "Admin besøk blir ikke tellet..");
define("COUNTER_L2", "Denne siden i dag ...");
define("COUNTER_L3", "total");
define("COUNTER_L4", "Denne siden for alltid ...");
define("COUNTER_L5", "unike");
define("COUNTER_L6", "Side ...");
define("COUNTER_L7", "Teller");
define("COUNTER_L8", "Admin melding: <b>Stat logging er deaktivert.</b><br />For å aktivere, så må du installere Statistikk Logging utvidelsen fra<a href='".e_ADMIN."plugin.php'>utvidelser seksjonen</a>, så aktivere det fra <a href='".e_PLUGIN."log/admin_config.php'>statistikk konfigurasjonen</a>.");
	
?>