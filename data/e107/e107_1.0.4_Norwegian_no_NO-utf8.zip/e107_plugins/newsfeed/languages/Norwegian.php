<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsfeed/languages/Norwegian.php,v $
|     $Revision: 25 $
|     $Date: 2010-09-18 22:18:57 +0200 (lø, 18 sep 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
define("NFLAN_01", "Nyhetsstrømmer");
define("NFLAN_02", "Denne plugin henter rss strømmen fra andre websider og viser dem i henhold til dine innstillinger");
define("NFLAN_03", "Konfigurer nyhetsstrømmen");
define("NFLAN_04", "Nyhetsstrømmens  plugin er innstallert. For å legge til strømmen og konfigurere, gå tilbake til adminhovedsiden og klikk på ikonet for nyhetsstrømmen i plugin seksjonen.");
define("NFLAN_05", "Rediger");
define("NFLAN_06", "Slett");
define("NFLAN_07", "Eksisterende nyhetsstrømmer");
define("NFLAN_08", "Nyhetsstrømmens førsteside");
define("NFLAN_09", "Opprett nyhetsstrøm");
define("NFLAN_10", "URL til rss kilde");
define("NFLAN_11", "Sti til bilde");
define("NFLAN_12", "Aktivering");
define("NFLAN_13", "Ingen steder(inaktiv)");
define("NFLAN_14", "Kun i meny");
define("NFLAN_15", "Opprett nyhetsstrøm");
define("NFLAN_16", "Oppdater nyhetsstrøm");
define("NFLAN_17", "angi 'default' i ruten for å bruke bilder definert i strømmen. For å bruke eget bilde, angi hele stien til bildet, la stå tomt for ikke å bruke bilde.");
define("NFLAN_18", "Oppdateringsintervall i sekunder");
define("NFLAN_19", "f.eks. 3600: strømmen oppdateres hver time");
define("NFLAN_20", "Kun på nyhetsstrømmens hovedside");
define("NFLAN_21", "I både meny og på nyhetsstrømmens side");
define("NFLAN_22", "velg hvor du vil vise nyhetsstrømmen");
define("NFLAN_23", "Strøm lagt til i databasen.");
define("NFLAN_24", "Obligatorisk felt latt stå tomt.");
define("NFLAN_25", "Strøm oppdatert i databasen.");
define("NFLAN_26", "Oppdateringsintervall");
define("NFLAN_27", "Alternativ");
define("NFLAN_28", "URL");
define("NFLAN_29", "Tilgjengelige nyhetsstrømmer");
define("NFLAN_30", "Strømmens navn");
define("NFLAN_31", "Tilbake til nyhetsstrømlisten");
define("NFLAN_32", "Ingen strøm med det identifikasjonsnummeret kan finnes.");
define("NFLAN_33", "Dato publisert:");
define("NFLAN_34", "ukjent");
define("NFLAN_35", "postet av");
define("NFLAN_36", "Beskrivelse");
define("NFLAN_37", "kort beskrivelse av strømmen, angi 'default' for å bruke beskrivelsen i strømmen");
define("NFLAN_38", "Titler");
define("NFLAN_39", "Detaljer");
define("NFLAN_40", "Nyhetsstrøm slettet");
define("NFLAN_41", "Ingen nyhetsstrømmer definert enda");
define("NFLAN_42", "<b>?</b> <u>Nyhetsstrøvn:</u> Navn for å dentifisere strømmen, kan være hva du vil. <br /><br /> <b>&raquo;</b> <u>URL til rss-strømmen:</u> Adressen til rss-strømmen <br /><br /> <b>&raquo;</b> <u>Sti til bilde:</u> Om strømmen har et bilde definert i seg, ang 'default' for å bruke det. For å bruke eget bilde, angi hele stien til bildet. La stå tomt for ikke å bruke bilde.
 <br /><br />	<b>&raquo;</b> <u>Beskrivelse:</u> Angi en kort beskrivelse av strømmen, eller 'default' for å bruke beskrivelsen definert i strømmen (om det finnes). <br /><br /> <b>&raquo;</b> <u>Oppdateringsintervall i sekunder:</u> Antall sekunder mellom oppdateringene i strømmen, f.eks. 1800: 30 minutter, 3600: en time. <br /><br /> <b>&raquo;</b> <u>Aktivering:</u> Hvor vil du at strømmen skal vises, for å se strømsmenyen må du aktivere nyhetsstrømsmenyen på <a href='".e_ADMIN."menus.php'>menysiden</a>. <br /><br />For en bra eksempelliste over ulike strømmer, se <a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> eller <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a>");
define("NFLAN_43", "Nyhetsstrømshjelp");
define("NFLAN_44", "klikk for å se");
define("NFLAN_45", "Antall saker som skal vises i meny");
define("NFLAN_46", "Antall saker som skal vises på hovedsiden");
define("NFLAN_47", "0 eller blank for å vise alle");
define("NFLAN_48", "Kunne ikke lagre rådata i databasen.");
define("NFLAN_49", "Ikke i stand til å gjøre rrsdata brukervennlig - bruker en ikkestandard syntax");


?>