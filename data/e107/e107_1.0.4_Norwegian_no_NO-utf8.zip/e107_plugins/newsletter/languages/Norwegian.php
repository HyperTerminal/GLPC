<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/newsletter/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

define("NLLAN_MENU_CAPTION", "Nyhetsbrev");

define("NLLAN_01", "Nyhetsbrev");
define("NLLAN_02", "Tilbyr en rask og enkel metode for å konfigurere og sende nyhetsbrev.");
define("NLLAN_03", "Konfigurer nyhetsbrev");
define("NLLAN_04", "Plugin for nyhetsbrev er innstallert. For å konfigurere, gå til adminhpvedsiden og klikk på 'Nyhetsbrev' i plugin seksen onen.");
define("NLLAN_05", "Ingen nyhetsbrev definert enda");

define("NLLAN_06", "Navn");
define("NLLAN_07", "Abonnenter");
define("NLLAN_08", "Alternativ");
define("NLLAN_09", "Er du sikker på at du vil slette dette nyhetsbrevet?");
define("NLLAN_10", "Eksisterende nyhetsbrev");

define("NLLAN_11", "Ingen utgaver av nyhetsbrevet enda");
define("NLLAN_12", "Utgave");
define("NLLAN_13", "[ Tittel ID ] Emne/Tittel");
define("NLLAN_14", "Sendt?");
define("NLLAN_15", "Alternativ");
define("NLLAN_16", "ja");
define("NLLAN_17", "Ikke utsendt - klikk for å sende");
define("NLLAN_18", "Er du sikker på at du vil sende denne utgaven til abonnentene?");
define("NLLAN_19", "Er du sikker på at du vil slette denne utgaven av nyhetsbrevet?");
define("NLLAN_20", "Eksisterende utgaver");
define("NLLAN_21", "Tittel");
define("NLLAN_22", "Beskrivelse");
define("NLLAN_23", "Topptekst");
define("NLLAN_24", "Bunntekst");
define("NLLAN_25", "Oppdater nyhetsbrev");
define("NLLAN_26", "Opprett nyhetsbrev");
define("NLLAN_27", "Nyhetsbrev oppdatert i databasen.");
define("NLLAN_28", "Nyhetsbrev definert og lagret i databasen.");
define("NLLAN_29", "Ingen nyhetsbrev definert enda.");
define("NLLAN_30", "Nyhetsbrev");
define("NLLAN_31", "Emne / Tittel");
define("NLLAN_32", "Utgave nummer");
define("NLLAN_33", "Tekst");
define("NLLAN_34", "Oppdater utsendelse");
define("NLLAN_35", "Opprett utsendelse");
define("NLLAN_36", "Oppdater utgave av nyhetsbrev");
define("NLLAN_37", "Opprett utgave av nyhetsbrev");
define("NLLAN_38", "Nyhetsbrev oppdatert i databasen.");
define("NLLAN_39", "Nyhetsbrevsutgave lagret i databasen - for å sende ut, klikk på 'Gi ut utgave' knappen i alternativmenyen.");
define("NLLAN_40", "Utsendelse fullført - utgaven sendt til");

define("NLLAN_41", " abonnent(er).");
define("NLLAN_42", "Nyhetsbrev slettet.");
define("NLLAN_43", "Nyhetsbrevsutgave slettet.");

define("NLLAN_44", "Nyhetsbrev førsteside");
define("NLLAN_45", "Opprett nyhetsbrev");
define("NLLAN_46", "Opprett utsendelse");
define("NLLAN_47", "Nyhetsbrev alternativ");

define("NLLAN_48", "du abonnerer på dette nyhetsbrevet - om du vil avbryte abonnementet, klikk på knappen nedenfor.");
define("NLLAN_49", "Er du sikker på at du vil avbryte abonnementet på dette nyhetsbrevet?");
define("NLLAN_50", "Klikk på knappen for å abonnere( abonnementsadressen er");
define("NLLAN_51", "Avbryt abonnement");
define("NLLAN_52", "Abonner");
define("NLLAN_53", "Er du sikker på at du vil abonnere på dette nyhetsbrevet?");

define("NLLAN_54", "Sender");

define("NLLAN_55", "ID");
define("NLLAN_56", "Nyhetsbrev ID er ikke tilgjengelig");
define("NLLAN_57", "Returner til forrige side");
define("NLLAN_58", "Feil");
define("NLLAN_59", "Navn");
define("NLLAN_60", "Epost");
define("NLLAN_61", "Handlinger");
define("NLLAN_62", "Brukeren er blokkert! (eller ikke ferdig registrert)");
define("NLLAN_63", "Totalt abonnenter");
define("NLLAN_64", "Returner til forsiden for nyhetsbrev");
define("NLLAN_65", "Abonnenter overblikk over nyhetsbrev ID");

?>