<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/linkwords/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/
	
define("LWLAN_1", "Felt er tomme.");
define("LWLAN_2", "Linkord lagret.");
define("LWLAN_3", "Linkord oppdatert.");
define("LWLAN_4", "Ingen linkord definert enda.");
define("LWLAN_5", "Ord");
define("LWLAN_6", "Link");
define("LWLAN_7", "Aktiv?");
define("LWLAN_8", "Alternativ");
define("LWLAN_9", "ja");
define("LWLAN_10", "nei");
define("LWLAN_11", "Eksisterende linkord");
define("LWLAN_12", "Ja");
define("LWLAN_13", "Nei");
define("LWLAN_14", "Send inn linkord");
define("LWLAN_15", "Oppdater linkord");
define("LWLAN_16", "Endre");
define("LWLAN_17", "Slett");
define("LWLAN_18", "Er du sikker på at du vil slette dette linkordet?");
define("LWLAN_19", "Linkord slettet.");
define("LWLAN_20", "Kan ikke finne denne linkordsposten.");
define("LWLAN_21", "Ord å autolinke");
define("LWLAN_22", "Aktiver?");

define("LWLAN_23", "Linkord administrasjon");
define("LWLAN_24", "Administrer ord");
define("LWLAN_25", "Alternativer");
define("LWLAN_26", "Områder som linkord skal være aktivert");
define("LWLAN_27", "Dette er 'innholdet' til den viste teksten");
define("LWLAN_28", "Sider som linkord skal deaktiveres");
define("LWLAN_29", "Samme format som meny synlighets kontroll. Ett treff per linje. Spesifiser deler eller en hel URL. Avslutt med '!' for et eksakt treff på slutten av linken");
define("LWLAN_30", "Lagre");
define("LWLAN_31", "Legg til/Rediger linkord");
define("LWLAN_32", "Linkord alternativer");
define("LWLAN_33", 'Tittel området');
define("LWLAN_34", 'Sammendrag');
define("LWLAN_35", 'Innhold');
define("LWLAN_36", 'Beskrivelse (linker etc)');
define("LWLAN_37", 'Arv områder');
define("LWLAN_38", 'klikkbare linker');
define("LWLAN_39", 'Uprossesert tekst');
define("LWLAN_40", 'Bruker-skrevet titler (f.eks forum)');
define("LWLAN_41", 'Bruker-skrevet innhold (f.eks forum)');

define("LWLANINS_1", "Linkord");
define("LWLANINS_2", "Denne plugin'en kommer til å linke spesifiserte ord til en definert link");
define("LWLANINS_3", "Konfigurer linkord");
define("LWLANINS_4", "For å konfigurere, klikk på linken i pluginseksjonen på adminførstesiden");

?>