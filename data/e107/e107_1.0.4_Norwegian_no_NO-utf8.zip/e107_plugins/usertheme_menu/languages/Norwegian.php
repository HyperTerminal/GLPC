<?php

define('LAN_UMENU_THEME_1', 'Sett utseenet på nettsiden');
define('LAN_UMENU_THEME_2', 'Velg et utseenet');
define('LAN_UMENU_THEME_3', 'brukere:');
define('LAN_UMENU_THEME_4', 'Aktiver de utseenene som brukere kan velge');
define('LAN_UMENU_THEME_5', 'Oppdater');
define('LAN_UMENU_THEME_6', 'Design som er tilgjengelige for brukere');
define('LAN_UMENU_THEME_7', 'Brukergruppe som kan velge design');
	
?>