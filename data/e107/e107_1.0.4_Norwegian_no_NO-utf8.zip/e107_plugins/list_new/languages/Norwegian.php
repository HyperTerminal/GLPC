<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/list_new/languages/Norwegian.php,v $
|     $Revision: 22 $
|     $Date: 2010-05-02 20:25:17 +0200 (sø, 02 mai 2010) $
|     $Author: Ruben.Vaadahl $
+----------------------------------------------------------------------------+
*/

if (!defined("PAGE_NAME")) {define("PAGE_NAME", "List opp nye emner");}

define("LIST_PLUGIN_1", "Liste");
define("LIST_PLUGIN_2", "Denne utvidelsen lar deg se en liste over nye tillegg i alle e107 kategorier. Du kan enten vise listen med data siden ditt forrige besøk eller vise en generell liste over nyeste tillegg. Foruten siden finnes det også en meny. Alle seksjoner er konfigurerbare i adminseksjonen.");
define("LIST_PLUGIN_3", "Konfigurer hovedmeny");
define("LIST_PLUGIN_4", "Utvidelse for nye tillegg er nå klar til bruk.");
define("LIST_PLUGIN_5", "list");
define("LIST_PLUGIN_6", "Denne utvidelsen er ikke installert.");

define("LIST_ADMIN_1", "Nyeste");
define("LIST_ADMIN_2", "Oppdater innstillinger");
define("LIST_ADMIN_3", "Innstillingene er oppdatert");
define("LIST_ADMIN_4", "Seksjon");
define("LIST_ADMIN_5", "Meny");
define("LIST_ADMIN_6", "Side");
define("LIST_ADMIN_7", "Aktivert");
define("LIST_ADMIN_8", "Deaktivert");
define("LIST_ADMIN_9", "Æpen");
define("LIST_ADMIN_10", "Lukket");
define("LIST_ADMIN_11", "Oppdater");
define("LIST_ADMIN_12", "Velg");
define("LIST_ADMIN_13", "Velkommen til de nyeste hendelsene på ".SITENAME.". Denne siden viser de nyeste tilleggene på de vanligste delen av nettstedet.");
define("LIST_ADMIN_14", "Nyeste tillegg");
define("LIST_ADMIN_15", "Nye siden ditt forrige besøk");
define("LIST_ADMIN_16", "Velkommen til nye hendelsene på ".SITENAME."! Denne siden viser de nye tilleggene på de vanligste delen av nettstedet.");

define("LIST_ADMIN_SECT_1", "Seksjoner");
define("LIST_ADMIN_SECT_2", "Velg hvilke seksjoner som skal vises");
define("LIST_ADMIN_SECT_3", "");

define("LIST_ADMIN_SECT_4", "Visningsstil");
define("LIST_ADMIN_SECT_5", "Velg hvilke seksjoner som er åpne som standard");
define("LIST_ADMIN_SECT_6", "");

define("LIST_ADMIN_SECT_7", "Forfatter");
define("LIST_ADMIN_SECT_8", "Velg om forfatteren skal vises");
define("LIST_ADMIN_SECT_9", "");

define("LIST_ADMIN_SECT_10", "Kategori");
define("LIST_ADMIN_SECT_11", "Velg om kategorien skal vises");
define("LIST_ADMIN_SECT_12", "");

define("LIST_ADMIN_SECT_13", "Dato");
define("LIST_ADMIN_SECT_14", "Velg om dato skal vises");
define("LIST_ADMIN_SECT_15", "");

define("LIST_ADMIN_SECT_16", "Antall objekter");
define("LIST_ADMIN_SECT_17", "Velg hvor mange objekter som skal vises for hver seksjon");
define("LIST_ADMIN_SECT_18", "");

define("LIST_ADMIN_SECT_19", "Sorter objekter");
define("LIST_ADMIN_SECT_20", "Velg i hvilken rekkefølge seksjonene skal vises");
define("LIST_ADMIN_SECT_21", "");

define("LIST_ADMIN_SECT_22", "Ikon");
define("LIST_ADMIN_SECT_23", "Velg et ikon for hver seksjon");
define("LIST_ADMIN_SECT_24", "");

define("LIST_ADMIN_SECT_25", "Overskrift");
define("LIST_ADMIN_SECT_26", "Velg en overskrift for hver seksjon");
define("LIST_ADMIN_SECT_27", "");

define("LIST_ADMIN_OPT_1", "Generelt");
define("LIST_ADMIN_OPT_2", "Nyeste side");
define("LIST_ADMIN_OPT_3", "Nyeste meny");
define("LIST_ADMIN_OPT_4", "Ny side");
define("LIST_ADMIN_OPT_5", "Ny meny");
define("LIST_ADMIN_OPT_6", "Alternativer");

define("LIST_ADMIN_MENU_2", "Ikon: Standard");
define("LIST_ADMIN_MENU_3", "Bruk standard temabulletinikon om ingen andre ikoner finnes eller om Bruk ikon er deaktiver");
define("LIST_ADMIN_MENU_4", "");

define("LIST_ADMIN_LAN_2", "Overskrift");
define("LIST_ADMIN_LAN_3", "Angi en overskrift");
define("LIST_ADMIN_LAN_4", "");

define("LIST_ADMIN_LAN_5", "Bruk ikon");
define("LIST_ADMIN_LAN_6", "Bruk ikon fra hver seksjon");
define("LIST_ADMIN_LAN_7", "");

define("LIST_ADMIN_LAN_8", "Tegn");
define("LIST_ADMIN_LAN_9", "Velg hvor mange teng av overskriften som skal vises");
define("LIST_ADMIN_LAN_10", "La stå tomt for å vise hele overskriften");

define("LIST_ADMIN_LAN_11", "Postfiks");
define("LIST_ADMIN_LAN_12", "Velg et postfiks å bruke om overskriften overskrider angitt antall tegn");
define("LIST_ADMIN_LAN_13", "La stå tomt for ikke å bruke postfiks");

define("LIST_ADMIN_LAN_14", "Dato");
define("LIST_ADMIN_LAN_15", "Velg en datostil");
define("LIST_ADMIN_LAN_16", "For mer informasjon om datoformat, se <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funksjonens</a> side på php.net");

define("LIST_ADMIN_LAN_17", "Dagens dato");
define("LIST_ADMIN_LAN_18", "Velg datostil om datoen er dagens dato");
define("LIST_ADMIN_LAN_19", "For mer informasjon om datoformat, se <a href='http://www.php.net/manual/en/function.strftime.php' rel='external'>strftime funksjonens</a> side på php.net");

define("LIST_ADMIN_LAN_20", "Kolonner");
define("LIST_ADMIN_LAN_21", "Angi antall kolonner");
define("LIST_ADMIN_LAN_22", "Angi hvor mange kolonner du vil vise. Antallet du angir her kommer til å dele siden i så mange kolonner");

define("LIST_ADMIN_LAN_23", "Velkomsttekst");
define("LIST_ADMIN_LAN_24", "Angi en velkomsttekst som kommer til å vises lengst oppe på siden");
define("LIST_ADMIN_LAN_25", "");

define("LIST_ADMIN_LAN_26", "Vis tomme");
define("LIST_ADMIN_LAN_27", "Angi om du vil at en melding skal vises om en seksjon ikke har noe resultat ");
define("LIST_ADMIN_LAN_28", "");

define("LIST_ADMIN_LAN_29", "Ikon: Standard");
define("LIST_ADMIN_LAN_30", "Bruk standardikonet fra satt tema om ingen ikon finnes eller om Bruk ikon er deaktivert");
define("LIST_ADMIN_LAN_31", "");

define("LIST_ADMIN_LAN_32", "Tidsrom: Dager");
define("LIST_ADMIN_LAN_33", "Maksimum antall dager en bruker kan se bakover");
define("LIST_ADMIN_LAN_34", "");
define("LIST_ADMIN_LAN_35", "dager");

define("LIST_ADMIN_LAN_36", "Tidsrom");
define("LIST_ADMIN_LAN_37", "Vis en valgrute med antall dager å se bakover?");
define("LIST_ADMIN_LAN_38", "");

define("LIST_ADMIN_LAN_39", "åpne om registreringer finnes");
define("LIST_ADMIN_LAN_40", "skal seksjoner som inneholder registreringer bli åpnet som standard?");
define("LIST_ADMIN_LAN_41", "");

define("LIST_MENU_1", "Nyeste tillegg");
define("LIST_MENU_2", "av");
define("LIST_MENU_3", "den");
define("LIST_MENU_4", "under");
define("LIST_MENU_5", "dager");
define("LIST_MENU_6", "vis innhold fra hvor mange dager?");
define("LIST_MENU_7", "");
define("LIST_MENU_8", "");
define("LIST_MENU_9", "");
define("LIST_MENU_10", "");
define("LIST_MENU_11", "");
define("LIST_MENU_12", "");
define("LIST_MENU_13", "");
define("LIST_MENU_14", "");
define("LIST_MENU_15", "");
define("LIST_MENU_16", "");
define("LIST_MENU_17", "");
define("LIST_MENU_18", "");
define("LIST_MENU_19", "");

define("LIST_NEWS_1", "Nyheter");
define("LIST_NEWS_2", "Ingen nyheter");

define("LIST_COMMENT_1", "Kommentarer");
define("LIST_COMMENT_2", "Ingen kommentarer");
define("LIST_COMMENT_3", "Nyheter");
define("LIST_COMMENT_4", "FAQ");
define("LIST_COMMENT_5", "Avstemning");
define("LIST_COMMENT_6", "Dokumentasjon");
define("LIST_COMMENT_7", "Feilsporing");
define("LIST_COMMENT_8", "Innhold");
define("LIST_COMMENT_9", "Nedlastninger");
define("LIST_COMMENT_10", "Ideer");

define("LIST_DOWNLOAD_1", "Nedlastninger");
define("LIST_DOWNLOAD_2", "Ingen nedlastninger");

define("LIST_MEMBER_1", "Medlemmer");
define("LIST_MEMBER_2", "Ingen medlemmer");

define("LIST_CONTENT_1", "Innhold");
define("LIST_CONTENT_2", "Intet innhold i");
define("LIST_CONTENT_3", "ingen gyldig innholdskategori");

define("LIST_CHATBOX_1", "Chatboks");
define("LIST_CHATBOX_2", "Ingen innlegg i chatboks");

define("LIST_CALENDAR_1", "Kalender");
define("LIST_CALENDAR_2", "Ingen kalenderposter");

define("LIST_LINKS_1", "Linker");
define("LIST_LINKS_2", "Ingen linker");

define("LIST_FORUM_1", "Forum");
define("LIST_FORUM_2", "Ingen foruminnlegg");
define("LIST_FORUM_3", "Visninger:");
define("LIST_FORUM_4", "Svar:");
define("LIST_FORUM_5", "Nyeste innlegg:");
define("LIST_FORUM_6", "Den:");

?>