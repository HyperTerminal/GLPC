<?php

$lang_ibrowser_title= '插入 / 修改图像';
$lang_ibrowser_desc= '插入 / 修改图像';
$lang_ibrowser_library= 'Library';
$lang_ibrowser_preview= '预览';
$lang_ibrowser_img_sel= 'Image selection';
$lang_ibrowser_img_info= 'Image information';
$lang_ibrowser_img_upload= 'Image upload';
$lang_ibrowser_images= '图像';
$lang_ibrowser_src= '来源';
$lang_ibrowser_alt= '描述';
$lang_ibrowser_size= '大小';
$lang_ibrowser_align= 'Text flow';
$lang_ibrowser_height= '高度';
$lang_ibrowser_width= '宽度';
$lang_ibrowser_reset= 'Reset Dimensions';
$lang_ibrowser_border= 'Border';
$lang_ibrowser_hspace= 'HSpace';
$lang_ibrowser_vspace= 'VSpace';
$lang_ibrowser_select= '保存';
$lang_ibrowser_delete= '删除';
$lang_ibrowser_cancel= '取消';
$lang_ibrowser_uploadtxt= '文件';
$lang_ibrowser_uploadbt= '上传';
$lang_ibrowser_marginl = 'Margin-Left';
$lang_ibrowser_marginr = 'Margin-Right';
$lang_ibrowser_margint = 'Margin-Top';
$lang_ibrowser_marginb = 'Margin-Bottom';
$lang_insert_image_align_default = "默认";
$lang_insert_image_align_left = "靠左";
$lang_insert_image_align_right = "靠右";

// error messages
$lang_ibrowser_error= '错误';
$lang_ibrowser_errornoimg= '请选择图像';
$lang_ibrowser_errornodir= 'Library doesn\'t physically exist';
$lang_ibrowser_errorupload= 'An error occured while handling the file upload.\nPlease try again later';
$lang_ibrowser_errortype= 'Wrong image file type';
$lang_ibrowser_errordelete= '删除失败';
$lang_ibrowser_confirmdelete= '点击 OK 删除图像!';
$lang_ibrowser_error_width_nan= '宽度必须为数字!';
$lang_ibrowser_error_height_nan= '高度必须为数字!';
$lang_ibrowser_error_border_nan= '边框必须为数字!';
$lang_ibrowser_error_hspace_nan= '水平间隔必须为数字!';
$lang_ibrowser_error_vspace_nan= '垂直间隔必须为数字!';

?>