// Chinese lang variables
tinyMCE.addI18n('cn.ibrowser',{
	desc : '图像浏览器'
});