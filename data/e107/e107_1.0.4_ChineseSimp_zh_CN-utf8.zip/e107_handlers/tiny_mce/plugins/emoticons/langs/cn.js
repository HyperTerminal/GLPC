// Chinese lang variables

tinyMCE.addI18n('cn.emoticons',{
	desc : '插入表情'
});