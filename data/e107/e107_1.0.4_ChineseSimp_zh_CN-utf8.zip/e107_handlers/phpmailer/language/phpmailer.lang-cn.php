<?php
/**
 * PHPMailer language file.
 * English Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG['provide_address']      = '请输入至少一个收件人地址.';
$PHPMAILER_LANG['mailer_not_supported'] = '邮件功能不支持.';
$PHPMAILER_LANG['execute']              = '无法执行: ';
$PHPMAILER_LANG['instantiate']          = '无法执行邮件功能.';
$PHPMAILER_LANG['authenticate']         = 'SMTP 错误: 无法认证.';
$PHPMAILER_LANG['from_failed']          = '以下的发件人地址出错: ';
$PHPMAILER_LANG['recipients_failed']    = 'SMTP 错误: 以下收件人错误: ';
$PHPMAILER_LANG['data_not_accepted']    = 'SMTP 错误: 邮件内容不正确.';
$PHPMAILER_LANG['connect_host']         = 'SMTP 错误: 无法连接SMTP主机.';
$PHPMAILER_LANG['file_access']          = '无法读取文件: ';
$PHPMAILER_LANG['file_open']            = '文件错误: 无法打开文件: ';
$PHPMAILER_LANG['encoding']             = '未知编码: ';
$PHPMAILER_LANG['signing']              = '签名错误: ';
$PHPMAILER_LANG['smtp_error']           = 'SMTP 服务器错误: ';
?>