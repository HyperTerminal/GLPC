<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/online_extended_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("ONLINE_EL1", "访客: ");
define("ONLINE_EL2", "会员: ");
define("ONLINE_EL3", "本页: ");
define("ONLINE_EL4", "在线");
define("ONLINE_EL5", "会员");
define("ONLINE_EL6", "最新会员");
define("ONLINE_EL7", "正在查看");

define("ONLINE_EL8", "最多在线: ");
define("ONLINE_EL9", "于");

define("ONLINE_TRACKING_MESSAGE", "在线用户统计关闭，请在[link=".e_ADMIN."users.php?options]here[/link]打开[br]");

?>