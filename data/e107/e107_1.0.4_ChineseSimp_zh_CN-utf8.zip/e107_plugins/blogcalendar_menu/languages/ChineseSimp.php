<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/blogcalendar_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("BLOGCAL_L1", "新闻日期");
define("BLOGCAL_L2", "存档");

define("BLOGCAL_D1", "星期一");
define("BLOGCAL_D2", "星期二");
define("BLOGCAL_D3", "星期三");
define("BLOGCAL_D4", "星期四");
define("BLOGCAL_D5", "星期五");
define("BLOGCAL_D6", "星期六");
define("BLOGCAL_D7", "星期日");

define("BLOGCAL_M1", "一月");
define("BLOGCAL_M2", "二月");
define("BLOGCAL_M3", "三月");
define("BLOGCAL_M4", "四月");
define("BLOGCAL_M5", "五月");
define("BLOGCAL_M6", "六月");
define("BLOGCAL_M7", "七月");
define("BLOGCAL_M8", "八月");
define("BLOGCAL_M9", "九月");
define("BLOGCAL_M10", "十月");
define("BLOGCAL_M11", "十一月");
define("BLOGCAL_M12", "十二月");

define("BLOGCAL_1", "增加");

define("BLOGCAL_CONF1", "月份/每行");
define("BLOGCAL_CONF2", "间距");
define("BLOGCAL_CONF3", "更新菜单设置");
define("BLOGCAL_CONF4", "BlogCal 菜单配置");
define("BLOGCAL_CONF5", "BlogCal 菜单配置已保存");

define("BLOGCAL_ARCHIV1", "选择存档");

?>