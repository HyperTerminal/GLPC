<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/usersettings.php $
 * $Id: usersettings.php 11645 2010-08-01 12:57:11Z e107coders $
 */

/**
 *	e107 Event calendar plugin
 *
 *	Language file - anything called up in ecal_class.php and similar
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: ChineseSimp_class.php 11315 2010-02-10 18:18:01Z Jack $;
 */

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'no');
define('EC_LAN_RECUR_01', '每年');
define('EC_LAN_RECUR_02', '每半年');
define('EC_LAN_RECUR_03', '每季度');
define('EC_LAN_RECUR_04', '每个月');
define('EC_LAN_RECUR_05', '每四周');
define('EC_LAN_RECUR_06', '每两周');
define('EC_LAN_RECUR_07', '每周');
define('EC_LAN_RECUR_08', '每天');
define('EC_LAN_RECUR_100', '星期天');
define('EC_LAN_RECUR_101', '星期一');
define('EC_LAN_RECUR_102', '星期二');
define('EC_LAN_RECUR_103', '星期三');
define('EC_LAN_RECUR_104', '星期四');
define('EC_LAN_RECUR_105', '星期五');
define('EC_LAN_RECUR_106', '星期六');

define('EC_LAN_RECUR_1100', '第一');
define('EC_LAN_RECUR_1200', '第二');
define('EC_LAN_RECUR_1300', '第三');
define('EC_LAN_RECUR_1400', '第四');


// Notify
define('NT_LAN_EC_1', '活动日历');
define('NT_LAN_EC_2', '活动更新');
define('NT_LAN_EC_3', '更新');
define('NT_LAN_EC_4', 'IP 地址');
define('NT_LAN_EC_5', '内容');
define('NT_LAN_EC_6', '活动日历 - Event added');
define('NT_LAN_EC_7', 'New event posted');
define('NT_LAN_EC_8', '活动日历 - Event modified');


// Log messages
define('EC_ADM_01', '活动日历 - 添加活动');
define('EC_ADM_02', '活动日历 - 修改活动');
define('EC_ADM_03', '活动日历 - 删除活动');
define('EC_ADM_04', '活动日历 - 批量删除');
define('EC_ADM_05', '活动日历 - 添加多个');
define('EC_ADM_06', '活动日历 - 主选项已修改');
define('EC_ADM_07', '活动日历 - FE 选项已修改');
define('EC_ADM_08', '活动日历 - 分类已添加');
define('EC_ADM_09', '活动日历 - 分类已修改');
define('EC_ADM_10', '活动日历 - 分类已删除');
define('EC_ADM_11', '活动日历 - 旧的活动已删除');


?>