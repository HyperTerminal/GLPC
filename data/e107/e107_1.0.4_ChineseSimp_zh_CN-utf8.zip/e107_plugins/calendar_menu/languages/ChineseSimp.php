<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2013 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/calendar_menu/languages/ChineseSimp.php $
 * $Id: ChineseSimp.php 13076 2013-02-22 22:26:23Z Jack $
 */

/**
 *	e107 Event calendar plugin
 *
 *	Language file - general strings
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: English.php 13076 2013-02-22 22:26:23Z e107steved $;
 */
	
	
define('EC_ADLAN_1', "日历");
define('EC_ADLAN_2', "设置日历");
define('EC_INSTALL', "安装日历");
define('EC_UNINSTALL', "卸载日历");
define('EC_LAN_TODAY', "今天");

define('EC_LAN_DAY_1', "1");
define('EC_LAN_DAY_2', "2");
define('EC_LAN_DAY_3', "3");
define('EC_LAN_DAY_4', "4");
define('EC_LAN_DAY_5', "5");
define('EC_LAN_DAY_6', "6");
define('EC_LAN_DAY_7', "7");
define('EC_LAN_DAY_8', "8");
define('EC_LAN_DAY_9', "9");
define('EC_LAN_DAY_10', "10");
define('EC_LAN_DAY_11', "11");
define('EC_LAN_DAY_12', "12");
define('EC_LAN_DAY_13', "13");
define('EC_LAN_DAY_14', "14");
define('EC_LAN_DAY_15', "15");
define('EC_LAN_DAY_16', "16");
define('EC_LAN_DAY_17', "17");
define('EC_LAN_DAY_18', "18");
define('EC_LAN_DAY_19', "19");
define('EC_LAN_DAY_20', "20");
define('EC_LAN_DAY_21', "21");
define('EC_LAN_DAY_22', "22");
define('EC_LAN_DAY_23', "23");
define('EC_LAN_DAY_24', "24");
define('EC_LAN_DAY_25', "25");
define('EC_LAN_DAY_26', "26");
define('EC_LAN_DAY_27', "27");
define('EC_LAN_DAY_28', "28");
define('EC_LAN_DAY_29', "29");
define('EC_LAN_DAY_30', "30");
define('EC_LAN_DAY_31', "31");

define('EC_LAN_0', "一月");
define('EC_LAN_1', "二月");
define('EC_LAN_2', "三月");
define('EC_LAN_3', "四月");
define('EC_LAN_4', "五月");
define('EC_LAN_5', "六月");
define('EC_LAN_6', "七月");
define('EC_LAN_7', "八月");
define('EC_LAN_8', "九月");
define('EC_LAN_9', "十月");
define('EC_LAN_10', "十一月");
define('EC_LAN_11', "十二月");
define('EC_LAN_JAN', "一月");
define('EC_LAN_FEB', "二月");
define('EC_LAN_MAR', "三月");
define('EC_LAN_APR', "四月");
define('EC_LAN_MAY', "五月");
define('EC_LAN_JUN', "六月");
define('EC_LAN_JUL', "七月");
define('EC_LAN_AUG', "八月");
define('EC_LAN_SEP', "九月");
define('EC_LAN_OCT', "十月");
define('EC_LAN_NOV', "十一月");
define('EC_LAN_DEC', "十二月");
define('EC_LAN_12', "星期一");
define('EC_LAN_13', "星期二");
define('EC_LAN_14', "星期三");
define('EC_LAN_15', "星期四");
define('EC_LAN_16', "星期五");
define('EC_LAN_17', "星期六");
define('EC_LAN_18', "星期日");
define('EC_LAN_19', "星期一");
define('EC_LAN_20', "星期二");
define('EC_LAN_21', "星期三");
define('EC_LAN_22', "星期四");
define('EC_LAN_23', "星期五");
define('EC_LAN_24', "星期六");
define('EC_LAN_25', "星期日");
define('EC_LAN_26', "本月活动");
define('EC_LAN_27', "本月没有活动。");
define('EC_LAN_28', "输入新的活动");
define('EC_LAN_29', "时间:");
define('EC_LAN_30', "分类:");
define('EC_LAN_31', "用户:");
define('EC_LAN_32', "地点:");
define('EC_LAN_33', "邮件:");
define('EC_LAN_34', "转到");
define('EC_LAN_35', "修改");
define('EC_LAN_36', "删除");
define('EC_LAN_37', "没有活动");
define('EC_LAN_38', "没有指定");
define('EC_LAN_39', "详情点击这里");
define('EC_LAN_40', "当前月份");
define('EC_LAN_41', "新分类已创建。");
define('EC_LAN_42', "活动结束时间必须大于开始时间。");
define('EC_LAN_43', "必填字段为空");
define('EC_LAN_44', "新的活动已创建并保存到数据库。");
define('EC_LAN_45', "活动已更新到数据库中。");
define('EC_LAN_46', "确认删除活动");
define('EC_LAN_47', "删除已取消。");
define('EC_LAN_48', "请确认您要删除该活动 - 一旦删除将无法恢复");
define('EC_LAN_49', "取消");
define('EC_LAN_50', "确认删除");
define('EC_LAN_51', "活动已删除。");
define('EC_LAN_52', "活动分类:");
define('EC_LAN_53', "创建新的分类?:");
define('EC_LAN_54', "名称:");
define('EC_LAN_55', "图标:");
define('EC_LAN_56', "创建");
define('EC_LAN_57', "活动:");
define('EC_LAN_58', "来源网址:");
define('EC_LAN_59', "联系邮件:");
define('EC_LAN_60', "更新活动");
define('EC_LAN_61', "转到");
define('EC_LAN_62', "后...个活动");
define('EC_LAN_63', "如果是每年同一天重复的活动，请选中本选项。例如生日");
define('EC_LAN_64', "全天");
define('EC_LAN_65', "重复活动:");
define('EC_LAN_66', "修改活动");
define('EC_LAN_67', "开始:");
define('EC_LAN_68', "全天");
define('EC_LAN_69', "结束:");
define('EC_LAN_70', "活动标题:");
define('EC_LAN_71', "活动时间:");
define('EC_LAN_72', "活动日期:");
define('EC_LAN_73', "结束:");
define('EC_LAN_74', "查看分类");
define('EC_LAN_75', "日历设置已更新。");
define('EC_LAN_76', "可以添加活动:");
define('EC_LAN_77', "更新设置");
define('EC_LAN_78', "日历设置");
define('EC_LAN_79', "查看日历");
define('EC_LAN_80', "活动列表");
define('EC_LAN_81', "设置活动日历");
define('EC_LAN_82', "要打开请进入菜单页面选择calendar_menu到菜单区域。");
define('EC_LAN_83', "日历");
define('EC_LAN_84', "从");
define('EC_LAN_85', "到");
define('EC_LAN_86', "单个的活动");
define('EC_LAN_87', "选中这个多选框，会生成大量单个的活动。如果不对，您只能一个个去修改和删除。");
define('EC_LAN_88', "您选择生成 -NUM- 个单个的活动。");
define('EC_LAN_89', "如果项目不对，您只能一个个去修改和删除");
define('EC_LAN_90', "选择");	
define('EC_LAN_91', "没有分类");	
define('EC_LAN_92', "查看分类");		
define('EC_LAN_93', "查看活动列表");		
define('EC_LAN_94', "输入新的活动");			
define('EC_LAN_95', "今天");	
define('EC_LAN_96', "查看活动");	
define('EC_LAN_97', "所有");		
define('EC_LAN_98', "必填字段为空");		
define('EC_LAN_99', "活动必须为全天或结束时间晚于开始时间");			
define('EC_LAN_100', "所有分类不正确");			
//define('EC_LAN_101', "Set to inactive to disable on the new event form.");	
define('EC_LAN_102', "显示到'更多信息'的链接");
//define('EC_LAN_103', "On new event entry form.");	
define('EC_LAN_104', "日历管理员组群");		
define('EC_LAN_105', "* 必填字段");		
define('EC_LAN_106', "活动");		
define('EC_LAN_107', "该插件含有活动日历的全部功能和日历菜单。");		
define('EC_LAN_108', "活动日历已升级，请检查新的选项。");	
define('EC_LAN_109', "无法删除该活动。");	
define('EC_LAN_110', "活动编号");	
define('EC_LAN_111', "所有活动 ");	
define('EC_LAN_112', "所有活动 ");	
define('EC_LAN_113', "活动表单已提交。");
define('EC_LAN_114', "周开始于:");
define('EC_LAN_115', "星期日");
define('EC_LAN_116', "星期一");
define('EC_LAN_117', "日期长度(建议设置为3)");
define('EC_LAN_118', "日历页面的日期格式。");
define('EC_LAN_119', "月/年");
define('EC_LAN_120', "年/月");
define('EC_LAN_121', "显示日历");	
//define('EC_LAN_122', "Css element to show events on this day (menu)");	
define('EC_LAN_123', "订阅");
define('EC_LAN_124', "订阅日历");
define('EC_LAN_125', "可订阅分类");
define('EC_LAN_126', "已订阅");
define('EC_LAN_127', "分类");
define('EC_LAN_128', "没有可订阅的分类");
define('EC_LAN_129', "更新");
define('EC_LAN_130', "订阅已更新");
define('EC_LAN_131', "返回");
define('EC_LAN_132', "展开详细信息");
define('EC_LAN_133', "[查看详情]");
define('EC_LAN_134', "请输入分类名称");
define('EC_LAN_135', "活动");
define('EC_LAN_136', "分类简介");
define('EC_LAN_137', "未来的活动");
define('EC_LAN_138', '---End of List---');

// Added 12.07.06 for next_event_menu.php
define('EC_LAN_140', "近期的活动");
define('EC_LAN_141', "近期没有活动");
define('EC_LAN_142', "Only registered and logged in users can subscribe to events");
define('EC_LAN_143', "Facility not available");
define('EC_LAN_144', " - ");

define('EC_LAN_145', "You must specify a category for the event");
define('EC_LAN_146', "Advance notice of calendar event");
define('EC_LAN_147', "Calendar event today or tomorrow");
define('EC_LAN_148', "No events in specified date range");
define('EC_LAN_149', "Invalid date format");
define('EC_LAN_150', "Enter start and end date for list");
define('EC_LAN_151', "End date after start date");
define('EC_LAN_152', "Maximum one year's events");
define('EC_LAN_153', "开始日期 (first day of): ");
define('EC_LAN_154', "结束日期 (last day of): ");
define('EC_LAN_155', "分类: ");
define('EC_LAN_156', "创建列表");
define('EC_LAN_157', "外观选项:");
define('EC_LAN_158', "输出: ");
define('EC_LAN_159', "显示 ");
define('EC_LAN_160', "打印 ");
define('EC_LAN_161', "PDF ");
define('EC_LAN_162', "Print this page");
define('EC_LAN_163', "Event Listing");
define('EC_LAN_164', "Printable Lists");
define('EC_LAN_165', "Default Listing");
define('EC_LAN_166', "Tabular List no lines");
define('EC_LAN_167', "Tabular List with lines");
define('EC_LAN_168', "从: ");
define('EC_LAN_169', "到: ");
define('EC_LAN_170', "打印于: ");
define('EC_LAN_171', "分类列表");
define('EC_LAN_172', "活动分类: ");
define('EC_LAN_173', "第一个活动开始: ");
define('EC_LAN_174', "最后活动结束: ");
define('EC_LAN_175', "所有日子");
define('EC_LAN_176', "Recurring pattern: ");
define('EC_LAN_177', "取消活动");
define('EC_LAN_178', "接受活动");
define('EC_LAN_179', "Confirmation of multiple event entry");
define('EC_LAN_180', " RECORDS NOT SAVED - DB UPDATE ERROR");

define('EC_LAN_VIEWCALENDAR', "查看日历");
define('EC_LAN_VIEWALLEVENTS', "查看所有活动");
define('EC_LAN_ALLEVENTS', "所有活动");

define('EC_ADLAN_A10', "设置");
define('EC_ADLAN_A11', "分类");
define('EC_ADLAN_A12', "日历");
define('EC_ADLAN_A13', "修改");
define('EC_ADLAN_A14', "新增");
define('EC_ADLAN_A15', "删除");
define('EC_ADLAN_A16', "确认");
define('EC_ADLAN_A17', "执行");
define('EC_ADLAN_A18', "操作");
define('EC_ADLAN_A19', "管理分类");
define('EC_ADLAN_A20', "日历分类");
define('EC_ADLAN_A21', "分类名称");

define('EC_ADLAN_A23', "创建分类");
define('EC_ADLAN_A24', "修改分类");
define('EC_ADLAN_A25', "保存");
define('EC_ADLAN_A26', "分类已创建");
define('EC_ADLAN_A27', "无法创建分类");
define('EC_ADLAN_A28', "修改已保存");
define('EC_ADLAN_A29', "访问保存修改");

define('EC_ADLAN_A30', "分类已删除");
define('EC_ADLAN_A31', "选择确认删除");
define('EC_ADLAN_A32', "无法删除该分类");
define('EC_ADLAN_A33', "没有定义");
define('EC_ADLAN_A34', "日历管理员组群");
//define('EC_ADLAN_A35', "");
define('EC_ADLAN_A59', "分类正在使用中，不能删除。");

define('EC_ADLAN_A80', "可见用户");
define('EC_ADLAN_A81', "允许订阅");
define('EC_ADLAN_A82', "强制该组群接收通知");
define('EC_ADLAN_A83', "通知活动提前的天数");
define('EC_ADLAN_A84', "提前消息");
define('EC_ADLAN_A85', "当日消息");
define('EC_ADLAN_A86', "发送邮件");
define('EC_ADLAN_A87', "无");
define('EC_ADLAN_A88', "仅提前");
define('EC_ADLAN_A89', "仅当日");
define('EC_ADLAN_A90', "提前和当日");
define('EC_ADLAN_A91', "电子邮件标题");
define('EC_ADLAN_A92', "发件人(姓名)");
define('EC_ADLAN_A93', "发件人邮件地址");
define('EC_ADLAN_A94', "提交新的活动类别");
define('EC_ADLAN_A95', "打开订阅");
define('EC_ADLAN_A96', "关闭该选项将删除订阅按钮并覆盖分类订阅中的设置。");
//define('EC_ADLAN_A97', "If set to force subscriptions this category will not be displayed in the available subscription list for the user.");

define('EC_ADLAN_A100', "近期活动");
define('EC_ADLAN_A101', "Days to look forward:");
define('EC_ADLAN_A102', "显示的活动数量:");
define('EC_ADLAN_A103', "Include recurring events:");
define('EC_ADLAN_A104', "Title is link to events list:");
define('EC_ADLAN_A105', "Configure Forthcoming Events Menu");
define('EC_ADLAN_A106', "Menu has to be enabled on the 'Menu' page");
define('EC_ADLAN_A107', "Will not work reliably if looking forward more than 59 days");
define('EC_ADLAN_A108', "菜单标题");
define('EC_ADLAN_A109', "Forthcoming Events preferences updated");

define('EC_ADLAN_A110', "Only on previous day");
define('EC_ADLAN_A111', "Advanced and previous day");
define('EC_ADLAN_A112', "Previous day and on the day");
define('EC_ADLAN_A113', "Advanced, previous day and on the day");

define('EC_ADLAN_A114', "邮件日志");
define('EC_ADLAN_A115', "简单");
define('EC_ADLAN_A116', "详细");
define('EC_ADLAN_A117', "当天或前一天的消息");
define('EC_ADLAN_A118', "显示的分类");
define('EC_ADLAN_A119', "没有定义分类，或读取数据库出错");
define('EC_ADLAN_A120', "菜单中显示分类图标");
define('EC_ADLAN_A121', "分类描述");
define('EC_ADLAN_A122', "活动时间参照");
define('EC_ADLAN_A123', "日历时间的格式");
define('EC_ADLAN_A124', "当前服务器时间 Server: ");
define('EC_ADLAN_A125', "当前网站时间 Site: ");
define('EC_ADLAN_A126', "当前用户时间 User: ");
define('EC_ADLAN_A127', "设定日历中时间的格式。");
define('EC_ADLAN_A128', "使用右边的栏目自定义时间格式");
define('EC_ADLAN_A129', '"网站时间" 来自参数中的设置');
define('EC_ADLAN_A130', "活动名称链接到:");
define('EC_ADLAN_A131', "日历");
define('EC_ADLAN_A132', "来源网址");
define('EC_ADLAN_A133', "日历活动的日期格式: ");
define('EC_ADLAN_A134', "日志的级别:");
define('EC_ADLAN_A135', "修改/删除");
define('EC_ADLAN_A136', "所有修改");
define('EC_ADLAN_A137', "Can cover additions, updates to and deletions from the event list");
define('EC_ADLAN_A138', "活动开始/结束时间以5分钟为单位");
define('EC_ADLAN_A139', "(减少下拉列表的数量)");
define('EC_ADLAN_A140', "在日历菜单中显示本月的活动数量");
define('EC_ADLAN_A141', "维护");
define('EC_ADLAN_A142', "Remove past events ending more than x months ago");
define('EC_ADLAN_A143', "timed from beginning of current month");
define('EC_ADLAN_A144', "日历维护");
define('EC_ADLAN_A145', "删除旧的活动");
define('EC_ADLAN_A146', "以往的活动 ");
define('EC_ADLAN_A147', "已删除");
define('EC_ADLAN_A148', "参数错误 - 没有删除任何内容");
define('EC_ADLAN_A149', "No old events to delete, or delete of past events failed");
define('EC_ADLAN_A150', "确认删除这之前的活动 ");

define('EC_ADLAN_A151', "e107 中文站");
define('EC_ADLAN_A152', "calendar@yoursite.com");
define('EC_ADLAN_A153', "Log directory must be created manually - create a subdirectory 'log' off your event calendar plugin directory, with '666' access rights");
define('EC_ADLAN_A154', "Could not change log directory permissions");
define('EC_ADLAN_A155', "Log directory permissions may require manual update to 0666 or 0766, although depending on your server setup they may work");
define('EC_ADLAN_A156', "数据库已升级");
define('EC_ADLAN_A157', "this is the rss feed for the calendar entries");
define('EC_ADLAN_A158', "无法创建日志目录");

define('EC_ADLAN_A159', "缓存管理");
define('EC_ADLAN_A160', "(仅在使用缓存时有效)");
define('EC_ADLAN_A161', "清空日历缓存");
define('EC_ADLAN_A162', "确认清空缓存");
define('EC_ADLAN_A163', "缓存已清空");

define('EC_ADLAN_A164', "更新完成");
define('EC_ADLAN_A165', "日历菜单标题链接到:");
define('EC_ADLAN_A166', "活动列表中显示的日期:");
define('EC_ADLAN_A167', "近期活动中显示的日期:");
define('EC_ADLAN_A168', "Custom date uses the format in the box on the right");
define('EC_ADLAN_A169', "设定活动列表的日期格式");
define('EC_ADLAN_A170', "设定近期活动列表的日期格式");
define('EC_ADLAN_A171', "标记最近添加/更新的活动");
define('EC_ADLAN_A172', "Value is time from update in hours; zero to disable, 'LV' to show from user's last visit");

define('EC_ADLAN_A173', "订阅");
define('EC_ADLAN_A174', "没有订阅内容");
define('EC_ADLAN_A175', "UID");
define('EC_ADLAN_A176', "用户名字");
define('EC_ADLAN_A177', "分类");
define('EC_ADLAN_A178', "问题");
define('EC_ADLAN_A179', "操作");
define('EC_ADLAN_A180', "Deleted subscription record no ");
define('EC_ADLAN_A181', "Delete failed for record no ");
define('EC_ADLAN_A182', "Total --NUM-- entries in database");
define('EC_ADLAN_A183', "Calendar Menu mouseover shows event title");
define('EC_ADLAN_A184', "may not work with all browsers");
define('EC_ADLAN_A185', "空");
define('EC_ADLAN_A186', "Update settings\nand send test\nemail to self");
define('EC_ADLAN_A187', "Test email sent - ");
define('EC_ADLAN_A188', "Error sending test email - ");
define('EC_ADLAN_A189', "If the message is left blank, the message from the 'Default' category will be used");
define('EC_ADLAN_A190', "默认分类 - mailout messages are used if none defined for any other category");
define('EC_ADLAN_A191', "Details of event for test email");
define('EC_ADLAN_A192', "Test event location");
define('EC_ADLAN_A193', "Allow users to display/print/PDF lists");
define('EC_ADLAN_A194', "无");
define('EC_ADLAN_A195', "显示/打印");
define('EC_ADLAN_A196', "显示/打印/PDF");
define('EC_ADLAN_A197', "No class membership");
define('EC_ADLAN_A198', "Invalid User");
define('EC_ADLAN_A199', "显示 '最近' 图标");
define('EC_ADLAN_A200', "Editor for events");
define('EC_ADLAN_A201', "BBCode (标准)");
define('EC_ADLAN_A202', "BBCode 带帮助");
define('EC_ADLAN_A203', "所见即所得");
define('EC_ADLAN_A204', "");
define('EC_ADLAN_A205', "");


// Prefs - language defines can be used in various places where text is set through the admin screens
define('EC_MAILOUT_SUBJECT', "Advice of calendar event");	// Use shortcode EC_MAIL_SUBJECT


?>