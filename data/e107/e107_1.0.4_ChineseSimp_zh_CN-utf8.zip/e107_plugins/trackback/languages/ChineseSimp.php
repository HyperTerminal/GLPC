<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/trackback/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
	
define("TRACKBACK_L1", "设置引用");
define("TRACKBACK_L2", "该插件允许您在新闻中使用引用。");
define("TRACKBACK_L3", "引用已安装并打开。");
define("TRACKBACK_L4", "引用设置已保存。");
define("TRACKBACK_L5", "打开");
define("TRACKBACK_L6", "关闭");
define("TRACKBACK_L7", "打开引用");
define("TRACKBACK_L8", "引用地址文字");
define("TRACKBACK_L9", "保存设置");
define("TRACKBACK_L10", "引用设置");
define("TRACKBACK_L11", "该项目的引用地址:");

define("TRACKBACK_L12", "该项目没有引用地址");
define("TRACKBACK_L13", "修改引用");
define("TRACKBACK_L14", "删除");
define("TRACKBACK_L15", "引用已删除。");

?>