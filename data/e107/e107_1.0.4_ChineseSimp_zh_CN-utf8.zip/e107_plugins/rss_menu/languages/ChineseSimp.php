<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/rss_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("RSS_LAN05","数量 (0=不启用)");

define("RSS_MENU_L1", " can be syndicated by using these rss feeds.");
define("RSS_MENU_L2", "RSS Feeds");
define("RSS_MENU_L3", "新闻");
define("RSS_MENU_L4", "评论");
define("RSS_MENU_L5", "论坛主题");
define("RSS_MENU_L6", "论坛帖子");
define("RSS_MENU_L7", "聊天室发言");
define("RSS_MENU_L8", "错误跟踪报告");
define("RSS_MENU_L9", "下载");

define("RSS_NEWS", "新闻");
define("RSS_COM", "评论");
define("RSS_ART", "文章");
define("RSS_REV", "评论");
define("RSS_FT", "论坛主题");
define("RSS_FP", "论坛帖子");
define("RSS_FSP", "论坛特定帖子");
define("RSS_BUG", "错误跟踪");
define("RSS_FOR", "论坛");
define("RSS_DL", "下载");

define("RSS_PLUGIN_LAN_1", "RSS");

define("RSS_PLUGIN_LAN_6", "Feed Links");
define("RSS_PLUGIN_LAN_7", "新闻的 rss feed");
define("RSS_PLUGIN_LAN_8", "下载的 rss feed");
define("RSS_PLUGIN_LAN_9", "评论的 rss feed");
define("RSS_PLUGIN_LAN_10", "新闻分类的 rss feed:");
define("RSS_PLUGIN_LAN_11", "下载分类的 rss feed:");

define("RSS_PLUGIN_LAN_14", "评论");

define("RSS_LAN_ADMINMENU_1", "RSS 选项");
define("RSS_LAN_ADMINMENU_2", "Listing");
define("RSS_LAN_ADMINMENU_4", "导入");

define("RSS_LAN_ERROR_1", "This is not a valid rss feed<br /><br /><a href='".e_SELF."'><< return to rss feed list</a>");
define("RSS_LAN_ERROR_2", "Your e107_config.php file or your language files contain spaces or ï»¿﻿ characters before the &lt;? characters. You should remove this with a non-utf8 text-editor if you wish to have a valid RSS feed.");
define("RSS_LAN_ERROR_3", "No rss feeds are present yet<br />please use the import feature to import available rss feeds or create a rss feed manually.");
define("RSS_LAN_ERROR_4", "No rss feeds are available yet");
define("RSS_LAN_ERROR_5", "This rss entry does not exist");
define("RSS_LAN_ERROR_6", "There are no rss feeds to import");
define("RSS_LAN_ERROR_7", "Some required fields are missing.");

define("RSS_LAN_ADMIN_1", "Existing RSS feeds");
define("RSS_LAN_ADMIN_2", "Id");
define("RSS_LAN_ADMIN_3", "路径");
define("RSS_LAN_ADMIN_4", "名称");
define("RSS_LAN_ADMIN_5", "网址");
define("RSS_LAN_ADMIN_6", "文字");
define("RSS_LAN_ADMIN_7", "限制");
define("RSS_LAN_ADMIN_8", "可见");
define("RSS_LAN_ADMIN_9", "联系");
define("RSS_LAN_ADMIN_10", "rss feed 创建条目");
define("RSS_LAN_ADMIN_11", "rss feed 导入内容");
define("RSS_LAN_ADMIN_12", "话题 id");

define("RSS_LAN_ADMIN_13", "Include Other-news items in News Feed?");
define("RSS_LAN_ADMIN_14", "启用");
define("RSS_LAN_ADMIN_15", "Tick links to mark them for import ...");
define("RSS_LAN_ADMIN_16", "导入?");
define("RSS_LAN_ADMIN_17", "导入选择的链接");
define("RSS_LAN_ADMIN_18", "rss feed(s) imported.");

define("RSS_LAN_ADMIN_21", "active and visible in rss feed list");
define("RSS_LAN_ADMIN_22", "active and not visible in rss feed list");
define("RSS_LAN_ADMIN_23", "不启用");

define("RSS_LAN_ADMIN_26", "全选");
define("RSS_LAN_ADMIN_27", "全部取消");

define("RSS_LAN_ADMIN_31", "rss entries limit updated");

define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@nospam.com");
define("RSS_LAN_3", "noauthor@nospam.com");

?>