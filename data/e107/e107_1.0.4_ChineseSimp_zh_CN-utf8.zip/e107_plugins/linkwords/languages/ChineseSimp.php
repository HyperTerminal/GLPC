<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/linkwords/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("LWLAN_1", "栏目留空。");
define("LWLAN_2", "关键字已保存。");
define("LWLAN_3", "关键字已更新。");
define("LWLAN_4", "没有定义关键字");
define("LWLAN_5", "关键字");
define("LWLAN_6", "链接");
define("LWLAN_7", "启用?");
define("LWLAN_8", "选项");
define("LWLAN_9", "是");
define("LWLAN_10", "否");
define("LWLAN_11", "已有关键字");
define("LWLAN_12", "是");
define("LWLAN_13", "否");
define("LWLAN_14", "提交关键字");
define("LWLAN_15", "更新关键字");
define("LWLAN_16", "修改");
define("LWLAN_17", "删除");
define("LWLAN_18", "您确认要删除这个关键字吗?");
define("LWLAN_19", "关键字已删除。");
define("LWLAN_20", "没有找到关键字。");
define("LWLAN_21", "自动链接的关键字 (或者用逗号分开的关键字列表)");
define("LWLAN_22", "启用?");
define("LWLAN_23", "关键字链接管理");
define("LWLAN_24", "管理关键字");
define("LWLAN_25", "选项");
define("LWLAN_26", "启用关键字链接的区域");
define("LWLAN_27", "这是显示文字的'上下文'");
define("LWLAN_28", "关闭关键字链接的页面");
define("LWLAN_29", "Same format as menu visibility control. One match per line. Specify a partial or complete URL. End with '!' for exact match of the end part of the link");
define("LWLAN_30", "保存选项");
define("LWLAN_31", "添加/修改关键字");
define("LWLAN_32", "关键字选项");
define("LWLAN_33", '标题区域');
define("LWLAN_34", '栏目简介');
define("LWLAN_35", '主要内容');
define("LWLAN_36", '描述 (链接等)');
define("LWLAN_37", '普通区域');
define("LWLAN_38", '可点击链接');
define("LWLAN_39", '未处理文字');
define("LWLAN_40", '用户输入的标题 (例如: 论坛)');
define("LWLAN_41", '用户输入的文字 (例如: 论坛)');


define("LWLANINS_1", "关键字链接");
define("LWLANINS_2", "本插件用于给设定的关键字添加链接。");
define("LWLANINS_3", "设置关键字链接");
define("LWLANINS_4", "点击管理页面的插件菜单的链接开始设置");

?>