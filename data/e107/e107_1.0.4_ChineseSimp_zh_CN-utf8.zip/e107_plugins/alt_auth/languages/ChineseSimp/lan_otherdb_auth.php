<?php

define('OTHERDB_LAN_1', '数据库类型:');
define('OTHERDB_LAN_2', '服务器:');
define('OTHERDB_LAN_3', '用户名:');
define('OTHERDB_LAN_4', '密码:');
define('OTHERDB_LAN_5', '数据库');
define('OTHERDB_LAN_6', '数据表');
define('OTHERDB_LAN_7', '用户名字段:');
define('OTHERDB_LAN_8', '密码字段:');
define('OTHERDB_LAN_9', '密码方式:');
define('OTHERDB_LAN_10', '设置其他数据库认证');
define('OTHERDB_LAN_11', '** 如果使用e107数据库，不需要以下字段');