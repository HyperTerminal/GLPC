<?php

define('LDAPLAN_1', '服务器地址');
define('LDAPLAN_2', 'BaseDN或域名<br />如果用LDAP - 输入BaseDN<br />如果用AD - 输入域名');
define('LDAPLAN_3', 'LDAP用户<br />有检索AD目录权限的用户');
define('LDAPLAN_4', 'LDAP密码<br />LDAP检索用户密码。');
define('LDAPLAN_5', 'LDAP版本');
define('LDAPLAN_6', '设置LDAP授权');
define('LDAPLAN_7', 'eDirectory 搜索条件:');
define('LDAPLAN_8', '用于保证用户名位于正确的树下， <br />例如 \'(objectclass=inetOrgPerson)\'');
define('LDAPLAN_9', '当前搜索条件为:');
define('LDAPLAN_10', '警告: 如果 LDAP 模块不可用，设置授权模式为 LDAP 可能无法正常工作!');
define('LDAPLAN_11', '服务器类型');