<?php


define('LAN_ALT_2', '当前授权方式');
define('LAN_ALT_3', '选择其它的授权方式');
define('LAN_ALT_4', '设置参数');
define('LAN_ALT_5', '设置授权参数');
define('LAN_ALT_6', '连接失败的操作');
define('LAN_ALT_7', '如果连接到其它授权方式失败，该如何处理?');
define('LAN_ALT_8', '没有找到用户的操作');
define('LAN_ALT_9', '如果在其它授权方式中没有找到用户名，该如何处理?');
define('LAN_ALT_10', '登录失败');
define('LAN_ALT_11', '使用 e107 用户表');

define('LAN_ALT_PAGE', '其他授权方式');