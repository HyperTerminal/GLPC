<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/tree_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("TREE_L1", "配置主菜单");
define("TREE_L2", "更新主菜单设置");
define("TREE_L3", "主菜单设置已保存。");
define("TREE_L4", "打开");
define("TREE_L5", "关闭");
define("TREE_L6", "用于不能打开的链接的CSS类");
define("TREE_L7", "用于可以打开的链接CSS类");
define("TREE_L8", "用于已打开链接的CSS类");
define("TREE_L9", "主要链接之间使用空类");

?>