<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/pdf/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF 转换");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "本插件已启用.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF 参数");
define("PDF_LAN_3", "启用");
define("PDF_LAN_4", "禁用");
define("PDF_LAN_5", "page margin left");
define("PDF_LAN_6", "page margin right");
define("PDF_LAN_7", "page margin top");
define("PDF_LAN_8", "字体");
define("PDF_LAN_9", "默认字体大小");
define("PDF_LAN_10", "网站名称字体大小");
define("PDF_LAN_11", "页面网址字体大小");
define("PDF_LAN_12", "页面数字字体大小");
define("PDF_LAN_13", "PDF上显示图吧吗?");
define("PDF_LAN_14", "PDF上显示网站名称吗?");
define("PDF_LAN_15", "PDF上显示页面网址吗?");
define("PDF_LAN_16", "PDF上显示页面数值吗?");
define("PDF_LAN_17", "更新");
define("PDF_LAN_18", "PDF 参数已更新");
define("PDF_LAN_19", "页面");
define("PDF_LAN_20", "错误报告");

?>