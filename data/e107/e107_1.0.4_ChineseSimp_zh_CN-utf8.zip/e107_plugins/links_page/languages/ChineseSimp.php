<?php
/*
 * e107 website system - ChineseSimp Language file
 * 
 * Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
 * Copyright (C) 2008-2010 e107 Inc (e107.org)
 * 
 * Released under the terms and conditions of the GNU General Public License
 * (http://gnu.org).
 * 
 * $URL$
 * $Revision$
 * $Id$
 * $Author: Jack $
 */


define("LCLAN_PLUGIN_LAN_1", "链接管理");
define("LCLAN_PLUGIN_LAN_2", "链接管理用于显示外部网站链接");
define("LCLAN_PLUGIN_LAN_3", "设置链接管理");
define("LCLAN_PLUGIN_LAN_4", "链接");
define("LCLAN_PLUGIN_LAN_5", "链接管理模块安装成功, 请在管理首页的链接管理下设置.");
define("LCLAN_PLUGIN_LAN_6", "链接管理升级成功，现有版本");

define("LCLAN_OPT_MENU_1", "常用选项");
define("LCLAN_OPT_MENU_2", "个人链接管理");
define("LCLAN_OPT_MENU_3", "分类页面");
define("LCLAN_OPT_MENU_4", "显示链接");
define("LCLAN_OPT_MENU_5", "来源页面");
define("LCLAN_OPT_MENU_6", "评价页面");
define("LCLAN_OPT_MENU_7", "菜单");

define("LCLAN_PAGETITLE_1", "链接");
define("LCLAN_PAGETITLE_2", "所有分类");
define("LCLAN_PAGETITLE_3", "所有链接");
define("LCLAN_PAGETITLE_4", "分类");
define("LCLAN_PAGETITLE_5", "最佳评价");
define("LCLAN_PAGETITLE_6", "最佳来源");
define("LCLAN_PAGETITLE_7", "个人链接管理");
define("LCLAN_PAGETITLE_8", "链接评论");
define("LCLAN_PAGETITLE_9", "提交链接");
define("LCLAN_PAGETITLE_10", "");


define("LCLAN_OPT_1", "常用选项");
define("LCLAN_OPT_2", "链接管理选项");
define("LCLAN_OPT_3", "打开");
define("LCLAN_OPT_4", "关闭");
define("LCLAN_OPT_5", "px");
define("LCLAN_OPT_6", "");
define("LCLAN_OPT_7", "divide categories into individual pages");
define("LCLAN_OPT_8", "allow links to be submitted");
define("LCLAN_OPT_9", "谁能提交链接");
define("LCLAN_OPT_10", "use multiple pages to show the links");
define("LCLAN_OPT_11", "number of links per page");
define("LCLAN_OPT_12", "分类页面");
define("LCLAN_OPT_13", "显示哪个部分");
define("LCLAN_OPT_14", "图标");
define("LCLAN_OPT_15", "说明");
define("LCLAN_OPT_16", "数量");
define("LCLAN_OPT_17", "来源");
define("LCLAN_OPT_18", "网址");
define("LCLAN_OPT_19", "total category info line");
define("LCLAN_OPT_20", "链接到最佳来源");
define("LCLAN_OPT_21", "链接到最佳评价");
define("LCLAN_OPT_22", "show default icon if none is present");
define("LCLAN_OPT_23", "默认排序方法");
define("LCLAN_OPT_24", "默认排序方法");
define("LCLAN_OPT_25", "默认调整大小值");
define("LCLAN_OPT_26", "链接页面");
define("LCLAN_OPT_27", "allow users to rate links");
define("LCLAN_OPT_28", "show default icon if none present");
define("LCLAN_OPT_29", "display sort and order menu");
define("LCLAN_OPT_30", "升序");
define("LCLAN_OPT_31", "降序");
define("LCLAN_OPT_32", "use override of link open method");
define("LCLAN_OPT_33", "default resize value");
define("LCLAN_OPT_34", "名称");
define("LCLAN_OPT_35", "网址");
define("LCLAN_OPT_36", "排序");
define("LCLAN_OPT_37", "来源");
define("LCLAN_OPT_38", "");
define("LCLAN_OPT_39", "");
define("LCLAN_OPT_40", "名称");
define("LCLAN_OPT_41", "id");
define("LCLAN_OPT_42", "use individual link setting");
define("LCLAN_OPT_43", "Opens in same window");
define("LCLAN_OPT_44", "Opens in new window");
define("LCLAN_OPT_45", "Opens in 600x400 mini-window");
define("LCLAN_OPT_46", "who can manage links");
define("LCLAN_OPT_47", "these users can add/edit their own personal links");
define("LCLAN_OPT_48", "allow direct posting");
define("LCLAN_OPT_49", "if enabled links are submitted directly, else a site admin needs to approve them");
define("LCLAN_OPT_50", "allow direct deleting");
define("LCLAN_OPT_51", "if enabled the link managers can delete their own links");
define("LCLAN_OPT_52", "personal link managers");
define("LCLAN_OPT_53", "日期");
define("LCLAN_OPT_54", "allow personal management on links");
define("LCLAN_OPT_55", "allow comments on all links");
define("LCLAN_OPT_56", "minimum refer value");
define("LCLAN_OPT_57", "only links with a refer count larger then the given value are displayed (0 or empty = all)");
define("LCLAN_OPT_58", "link to submit link");
define("LCLAN_OPT_59", "link to personal manager (only if allowed)");
define("LCLAN_OPT_60", "link to link frontpage");
define("LCLAN_OPT_61", "link to all categories");
define("LCLAN_OPT_62", "show these navigator links");
define("LCLAN_OPT_63", "minimum rating value");
define("LCLAN_OPT_64", "only links with a rating larger then the given value are displayed (0 or empty = all)");
define("LCLAN_OPT_65", "show empty categories");
define("LCLAN_OPT_66", "link to each category");
define("LCLAN_OPT_67", "link to all links");
define("LCLAN_OPT_68", "查看所有链接");

define("LCLAN_OPT_69", "rendertype navigator links");
define("LCLAN_OPT_70", "show category links");
define("LCLAN_OPT_71", "rendertype category links");
define("LCLAN_OPT_72", "show recent links");
define("LCLAN_OPT_73", "display which data");
define("LCLAN_OPT_74", "how many recent links are displayed");
define("LCLAN_OPT_75", "hyperlinks");
define("LCLAN_OPT_76", "selectbox");
define("LCLAN_OPT_77", "分类");
define("LCLAN_OPT_78", "说明");
define("LCLAN_OPT_79", "标题导航");
define("LCLAN_OPT_80", "标题分类");
define("LCLAN_OPT_81", "标题最近列表");
define("LCLAN_OPT_82", "导航");
define("LCLAN_OPT_83", "分类");
define("LCLAN_OPT_84", "最近列表");
define("LCLAN_OPT_85", "标题菜单");
define("LCLAN_OPT_86", "链接菜单");
define("LCLAN_OPT_87", "show amount of links");

define("LCLAN_ADMIN_1", "更新");  // deprecated
define("LCLAN_ADMIN_2", "Link saved to database.");
define("LCLAN_ADMIN_3", "Link updated in database.");
define("LCLAN_ADMIN_4", "Link Category Saved");
define("LCLAN_ADMIN_5", "Link Category Updated");
define("LCLAN_ADMIN_6", "Options Saved");
define("LCLAN_ADMIN_7", "link icon was uploaded successfully !");
define("LCLAN_ADMIN_8", "link icon was not uploaded !");
define("LCLAN_ADMIN_9", "Order updated");
define("LCLAN_ADMIN_10", "链接");
define("LCLAN_ADMIN_11", "删除"); // deprecated
define("LCLAN_ADMIN_12", "Link Category");
define("LCLAN_ADMIN_13", "Submitted link deleted");
define("LCLAN_ADMIN_14", "链接");
define("LCLAN_ADMIN_15", "This category still contains links, please (re)move them first");

define("LCLAN_SL_1", "提交链接");
define("LCLAN_SL_2", "No submitted links");
define("LCLAN_SL_3", "链接");
define("LCLAN_SL_4", "提交者");
define("LCLAN_SL_5", "选项");
define("LCLAN_SL_6", "Post");
define("LCLAN_SL_7", "删除");
define("LCLAN_SL_8", "Are you sure you want to delete this submitted link?");
define("LCLAN_SL_9", "After submitting your link it will be reviewed by a site admin and if appropriate it will be added to the main links page.");
define("LCLAN_SL_10", "分类:");
define("LCLAN_SL_11", "名称");
define("LCLAN_SL_12", "网址");
define("LCLAN_SL_13", "说明");
define("LCLAN_SL_14", "URL to link button:");
define("LCLAN_SL_15", "Underlined fields are required.");
define("LCLAN_SL_16", "提交链接");
define("LCLAN_SL_17", "");
define("LCLAN_SL_18", "");

define("LCLAN_CAT_1", "图像");
define("LCLAN_CAT_2", "分类");
define("LCLAN_CAT_3", "选项");
define("LCLAN_CAT_4", "移动");
define("LCLAN_CAT_5", "排序");
define("LCLAN_CAT_6", "修改");
define("LCLAN_CAT_7", "是");
define("LCLAN_CAT_8", "Are you sure you want to delete this category?");
define("LCLAN_CAT_9", "查看链接");
define("LCLAN_CAT_10", "重排序");
define("LCLAN_CAT_11", "No link categories");
define("LCLAN_CAT_12", "Existing Link Categories");
define("LCLAN_CAT_13", "名称:");
define("LCLAN_CAT_14", "说明:");
define("LCLAN_CAT_15", "Upload a new icon:");
define("LCLAN_CAT_16", "Auto-Thumbnail size:");
define("LCLAN_CAT_17", "This option is disabled as file uploading is not enabled on your server");
define("LCLAN_CAT_18", "该");
define("LCLAN_CAT_19", "folder is not writable, you need to CHMOD 777 the folder before uploading");
define("LCLAN_CAT_20", "px");
define("LCLAN_CAT_21", "上传");
define("LCLAN_CAT_22", "Choose an icon:");
define("LCLAN_CAT_23", "View Images");
define("LCLAN_CAT_24", "Visible for:");
define("LCLAN_CAT_25", "tick to update timestamp to current time");
define("LCLAN_CAT_26", "Update Link Category");
define("LCLAN_CAT_27", "Clear Form");
define("LCLAN_CAT_28", "Create Link Category");
define("LCLAN_CAT_29", "Link Category");

define("LCLAN_ITEM_1", "提交者");
define("LCLAN_ITEM_2", "分类:");
define("LCLAN_ITEM_3", "没有分类");
define("LCLAN_ITEM_4", "名称:");
define("LCLAN_ITEM_5", "网址:");
define("LCLAN_ITEM_6", "说明:");
define("LCLAN_ITEM_7", "上传图标:");
define("LCLAN_ITEM_8", "Auto-Thumbnail size:");
define("LCLAN_ITEM_9", "This option is disabled as file uploading is not enabled on your server");
define("LCLAN_ITEM_10", "The");
define("LCLAN_ITEM_11", "folder is not writable, you need to CHMOD 777 the folder before uploading");
define("LCLAN_ITEM_12", "px");
define("LCLAN_ITEM_13", "上传");
define("LCLAN_ITEM_14", "选择图标:");
define("LCLAN_ITEM_15", "查看图像");
define("LCLAN_ITEM_16", "打开类型:");
define("LCLAN_ITEM_17", "Opens in same window");
define("LCLAN_ITEM_18", "Opens in new window");
define("LCLAN_ITEM_19", "Opens in 600x400 mini-window");
define("LCLAN_ITEM_20", "Visible for:");
define("LCLAN_ITEM_21", "tick to update timestamp to current time");
define("LCLAN_ITEM_22", "更新链接");
define("LCLAN_ITEM_23", "创建链接");
define("LCLAN_ITEM_24", "链接");
define("LCLAN_ITEM_25", "图像");
define("LCLAN_ITEM_26", "链接名称");
define("LCLAN_ITEM_27", "选项");
define("LCLAN_ITEM_28", "移动");
define("LCLAN_ITEM_29", "排序");
define("LCLAN_ITEM_30", "重排序");
define("LCLAN_ITEM_31", "修改");
define("LCLAN_ITEM_32", "删除");
define("LCLAN_ITEM_33", "您确认要删除该链接吗?");
define("LCLAN_ITEM_34", "没有图标");
define("LCLAN_ITEM_35", "管理个人链接");
define("LCLAN_ITEM_36", "执行");
define("LCLAN_ITEM_37", "查看所有链接");
define("LCLAN_ITEM_38", "所有链接");
define("LCLAN_ITEM_39", "评价");

define("LCLAN_ADMINMENU_1", "链接选项");
define("LCLAN_ADMINMENU_2", "管理链接分类");
define("LCLAN_ADMINMENU_3", "新建链接分类");
define("LCLAN_ADMINMENU_4", "管理链接");
define("LCLAN_ADMINMENU_5", "新建链接");
define("LCLAN_ADMINMENU_6", "选项");
define("LCLAN_ADMINMENU_7", "提交链接");
define("LCLAN_ADMINMENU_8", "分类");

define("NT_LAN_LP_1", "链接页面事件");
define("NT_LAN_LP_2", "用户提交的链接");
define("NT_LAN_LP_3", "链接已提交");

define("LNK_SCH_LAN_2", "所有链接分类");
define("LNK_SCH_LAN_3", "所有链接内容");

define("LAN_LINKS_MANAGER_0", "图标");
define("LAN_LINKS_MANAGER_1", "链接");
define("LAN_LINKS_MANAGER_2", "选项");
define("LAN_LINKS_MANAGER_3", "新建链接");
define("LAN_LINKS_MANAGER_4", "您还没有任何链接");
define("LAN_LINKS_MANAGER_5", "分类");
define("LAN_LINKS_MANAGER_6", "");
define("LAN_LINKS_MANAGER_7", "");
define("LAN_LINKS_MANAGER_8", "");
define("LAN_LINKS_MANAGER_9", "");

define("LAN_LINKS_1", "所有链接");
define("LAN_LINKS_2", "所有激活的链接");
define("LAN_LINKS_3", "匿名");
define("LAN_LINKS_4", "页眉");
define("LAN_LINKS_5", "网址");
define("LAN_LINKS_6", "排序");
define("LAN_LINKS_7", "来源");
define("LAN_LINKS_8", "升序");
define("LAN_LINKS_9", "降序");
define("LAN_LINKS_10", "最佳链接 : 来源");
define("LAN_LINKS_11", "最佳链接 : 评价");
define("LAN_LINKS_12", "根据来源查看链接");
define("LAN_LINKS_13", "根据评价查看链接");
define("LAN_LINKS_14", "查看链接首页");
define("LAN_LINKS_15", "排序");
define("LAN_LINKS_16", "在本分类");
define("LAN_LINKS_17", "链接");
define("LAN_LINKS_18", "链接");
define("LAN_LINKS_19", "分类");
define("LAN_LINKS_20", "分类");
define("LAN_LINKS_21", "共");
define("LAN_LINKS_22", "有");
define("LAN_LINKS_23", "有");
define("LAN_LINKS_24", "个在");
define("LAN_LINKS_25", "显示所有链接");
define("LAN_LINKS_26", "来源");
define("LAN_LINKS_27", "提交链接");
define("LAN_LINKS_28", "谢谢");
define("LAN_LINKS_29", "您的链接已提交给网站管理员审核。");
define("LAN_LINKS_30", "链接分类");
define("LAN_LINKS_31", "提交链接");
define("LAN_LINKS_32", "分类:");
define("LAN_LINKS_33", "还没有链接评价.");
define("LAN_LINKS_34", "目前还没有链接");
define("LAN_LINKS_35", "个人链接管理");
define("LAN_LINKS_36", "链接评论");
define("LAN_LINKS_37", "评论");
define("LAN_LINKS_38", "日期");
define("LAN_LINKS_39", "链接");
define("LAN_LINKS_40", "分类");
define("LAN_LINKS_41", "没有分类");
define("LAN_LINKS_42", "没有链接来源");
define("LAN_LINKS_43", "查看所有分类");
define("LAN_LINKS_44", "id");
define("LAN_LINKS_45", "链接分类");
define("LAN_LINKS_46", "链接分类");
define("LAN_LINKS_47", "链接导航...");
define("LAN_LINKS_48", "-- view category --");
define("LAN_LINKS_49", "");
define("LAN_LINKS_50", "您没有提交链接的权限");

define('LAN_LINKS_SCH_1','在链接回复中发表');


?>