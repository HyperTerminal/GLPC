<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/banner_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "广告管理");
define("BANNER_MENU_L2", "广告菜单设置已保存");

//v.617
define("BANNER_MENU_L3", "标题");
define("BANNER_MENU_L4", "系列");
define("BANNER_MENU_L5", "广告菜单设置");
define("BANNER_MENU_L6", "选择菜单中显示的系列");
define("BANNER_MENU_L7", "可用系列");
define("BANNER_MENU_L8", "已选系列");
define("BANNER_MENU_L9", "删除选择");
define("BANNER_MENU_L10", "如何显示所选系列?");
define("BANNER_MENU_L11", "选择加载类型 ...");
define("BANNER_MENU_L12", "一个菜单一个系列");
define("BANNER_MENU_L13", "一个菜单多个系列");
define("BANNER_MENU_L14", "多个菜单多个系列");
define("BANNER_MENU_L15", "显示多少个广告?");
define("BANNER_MENU_L16", "该设置仅用于选项2和3。<br />如果广告少，将使用最大的数量。");
define("BANNER_MENU_L17", "设定数量 ...");
define("BANNER_MENU_L18", "更新菜单设置");

?>