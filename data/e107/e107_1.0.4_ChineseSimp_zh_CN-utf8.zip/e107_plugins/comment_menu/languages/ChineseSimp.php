<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/comment_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("CM_L1", "还没有评论。");
define("CM_L2", "");
define("CM_L3", "标题");
define("CM_L4", "显示的评论?");
define("CM_L5", "显示的字数?");
define("CM_L6", "太长评论的后缀?");
define("CM_L7", "在菜单中显示原来的新闻标题?");
define("CM_L8", "新的评论菜单设置");
define("CM_L9", "更新菜单设置");
define("CM_L10", "评论菜单设置已保存");
define("CM_L11", "于");
define("CM_L12", "回复:");
define("CM_L13", "发表人");

?>