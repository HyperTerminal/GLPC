<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/content/languages/English/lan_content_search.php $
|     $Revision: 11678 $
|     $Id: lan_content_search.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Content");
define("CONT_SCH_LAN_2", "All Content Categories");
define("CONT_SCH_LAN_3", "Posted in reply to item");
define("CONT_SCH_LAN_4", "in");

?>