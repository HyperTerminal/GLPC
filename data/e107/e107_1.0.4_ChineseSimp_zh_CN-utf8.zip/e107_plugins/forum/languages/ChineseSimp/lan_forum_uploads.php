<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php $
|     $Revision: 11678 $
|     $Id: lan_forum_uploads.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "论坛上传");

define('FRMUP_1','在论坛中上传的文件');
define('FRMUP_2','文件已删除');
define('FRMUP_3','错误: 无法删除文件');
define('FRMUP_4','删除文件');
define('FRMUP_5','文件名');
define('FRMUP_6','结果');
define('FRMUP_7','在主题中找到');
define('FRMUP_8','没有找到');
define('FRMUP_9','没有找到上传的文件');
define('FRMUP_10','删除');
	
?>