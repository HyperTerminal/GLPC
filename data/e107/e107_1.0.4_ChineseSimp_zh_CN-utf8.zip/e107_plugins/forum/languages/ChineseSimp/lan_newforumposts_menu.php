<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/forum/languages/English/lan_newforumposts_menu.php $
|     $Revision: 11678 $
|     $Id: lan_newforumposts_menu.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
	
define("NFP_1", "所有最新帖子都不属于您的用户组，无法显示。");
define("NFP_2", "还没有帖子");
define("NFP_3", "新的论坛帖子菜单的设置已保存");
define("NFP_4", "标题");
define("NFP_5", "显示的帖子数?");
define("NFP_6", "显示的字数?");
define("NFP_7", "太长帖子的后缀?");
define("NFP_8", "在菜单中显示原来的主题?");
define("NFP_9", "更新菜单设置");
define("NFP_10", "新的论坛帖子菜单设置");
define("NFP_11", "发贴");
define("NFP_12", "显示的贴子的最长时间");
define("NFP_13", "贴子数很少是设置为0; 贴子数很多的网站，设置一个天数能减低数据库的负载。");
	
?>