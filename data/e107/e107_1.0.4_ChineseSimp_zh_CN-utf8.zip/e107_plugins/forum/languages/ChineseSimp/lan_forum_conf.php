<?php
/**
 * e107 website system - ChineseSimp Language file
 * 
 * Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
 * Copyright (C) 2008-2010 e107 Inc (e107.org)
 * 
 * Released under the terms and conditions of the GNU General Public License
 * (http://gnu.org).
 * 
 * $URL$
 * $Revision$
 * $Id$
 * $Author: Jack$
 */

# Install LANs
define('LAN_FORUM_INSTALL_01', '论坛');
define('LAN_FORUM_INSTALL_02', '本插件是一个功能完善的论坛系统。');
define('LAN_FORUM_INSTALL_03', '配置论坛');
define('LAN_FORUM_INSTALL_04', '论坛已安装');
define('LAN_FORUM_INSTALL_05', '论坛升级成功，目前版本: %1$s');
define('LAN_FORUM_INSTALL_06', '[论坛]');
define('LAN_FORUM_INSTALL_07', '[更多...]');

# Config LANs
define('FORLAN_5', '投票已删除。');
define('FORLAN_6', '主题已删除');
define('FORLAN_7', '回复已删除');
define('FORLAN_8', '删除取消。');
define('FORLAN_9', '主题已移动。');
define('FORLAN_10', '移动取消。');
define('FORLAN_11', '返回论坛');
define('FORLAN_12', '论坛设置');
define('FORLAN_13', '您确认要删除该投票吗?<br />一旦删除，将<b><u>无法</u></b>恢复。');
define('FORLAN_14', '取消');
define('FORLAN_15', '确认删除论坛帖子');
define('FORLAN_16', '确认删除投票');
define('FORLAN_17', '发贴');
define('FORLAN_18', '您确认要删除该论坛吗');
define('FORLAN_19', '主题和相关帖子?');
define('FORLAN_20', '投票也将被删除');
define('FORLAN_21', '一旦删除将');
define('FORLAN_22', '发表?<br />一旦删除');
define('FORLAN_23', '无法</u></b>恢复');
define('FORLAN_24', '移动主题到论坛');
define('FORLAN_25', '移动主题');
define('FORLAN_26', '回复已删除');

define('FORLAN_27', '已移动');

define('FORLAN_28', '不要修改主题标题');
define('FORLAN_29', '添加');
define('FORLAN_30', '到标题');
define('FORLAN_31', '改名为:');
define('FORLAN_32', '改名主题选项:');


?>