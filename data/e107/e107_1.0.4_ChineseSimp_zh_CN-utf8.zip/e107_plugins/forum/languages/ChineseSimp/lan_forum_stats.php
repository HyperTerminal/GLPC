<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/forum/languages/English/lan_forum_stats.php $
|     $Revision: 11678 $
|     $Id: lan_forum_stats.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "论坛统计");

define("FSLAN_1", "基本资料");
define("FSLAN_2", "开坛时间");
define("FSLAN_3", "运行时间");
define("FSLAN_4", "全部帖子");
define("FSLAN_5", "论坛主题");
define("FSLAN_6", "论坛回复");
define("FSLAN_7", "主题查看次数");
define("FSLAN_8", "论坛数据量");
define("FSLAN_9", "记录平均长度");
define("FSLAN_10", "最活跃主题");
define("FSLAN_11", "排名");
define("FSLAN_12", "主题");
define("FSLAN_13", "回复");
define("FSLAN_14", "发贴");
define("FSLAN_15", "日期");
define("FSLAN_16", "最热门帖子");
define("FSLAN_17", "查看");
define("FSLAN_18", "最活跃会员");
define("FSLAN_19", "姓名");
define("FSLAN_20", "帖子");
define("FSLAN_21", "发贴最多会员");
define("FSLAN_22", "回帖最多会员");
define("FSLAN_23", "论坛统计");
define("FSLAN_24", "每天平均帖子");

?>