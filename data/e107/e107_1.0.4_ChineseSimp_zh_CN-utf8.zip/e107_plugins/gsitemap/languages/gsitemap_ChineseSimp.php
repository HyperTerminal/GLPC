<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/gsitemap/languages/gsitemap_ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: gsitemap_ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "网站地图");
define("GSLAN_1", "网站链接");
define("GSLAN_2", "导入");
define("GSLAN_3", "链接类型");
define("GSLAN_4", "链接名称");
define("GSLAN_5", "网址");
define("GSLAN_6", "选择需要导入的链接 ...");
define("GSLAN_7", "导入链接");
define("GSLAN_8", "导入选项:");
define("GSLAN_9", "优先级");
define("GSLAN_10", "频率");
define("GSLAN_11", "always");
define("GSLAN_12", "hourly");
define("GSLAN_13", "daily");
define("GSLAN_14", "weekly");
define("GSLAN_15", "monthly");
define("GSLAN_16", "yearly");
define("GSLAN_17", "never");
define("GSLAN_18", "导入选中的链接");
define("GSLAN_19", "Google网站地图");
define("GSLAN_20", "列表");
define("GSLAN_21", "说明");
define("GSLAN_22", "创建新的链接");
define("GSLAN_23", "导入");
define("GSLAN_24", "Google网站地图链接");
define("GSLAN_25", "名称");
define("GSLAN_26", "网址");
define("GSLAN_27", "最后修改");
define("GSLAN_28", "频率");
define("GSLAN_29", "Google网站地图设置");
define("GSLAN_30", "显示顺序");
define("GSLAN_31", "可见组群");
define("GSLAN_32", "如何使用Google网站地图");
define("GSLAN_33", "GSiteMap说明");
define("GSLAN_34", "首先，创建您要在网站地图中列出的链接。您可以点击右边的'导入'按钮导入大部分链接。");
define("GSLAN_35", "如果您要导入链接，点击'导入'按钮然后选择需要导入的链接");
define("GSLAN_36", "您也可以点击'创建新的链接'，单独输入个别链接");
define("GSLAN_37", "一旦有了链接，访问[URL] 并输入下面的网址: [URL2] 如果您觉得这个网址不对，请在管理页面 -> [参数设置]中检查您的网站地址。");
define("GSLAN_38", "需要了解更多Google网站地图协议，请访问[URL]。");
define("GSLAN_39", "网站地图中没有链接 - 导入网站链接?");
define("GSLAN_40", "Google网站地图链接");


?>