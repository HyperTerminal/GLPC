<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/counter_menu/languages/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
	
define("COUNTER_L1", "不统计管理员访问.");
define("COUNTER_L2", "本页今日 ...");
define("COUNTER_L3", "总计");
define("COUNTER_L4", "本页累计 ...");
define("COUNTER_L5", "唯一");
define("COUNTER_L6", "网站 ...");
define("COUNTER_L7", "计数器");
define("COUNTER_L8", "管理信息: <b>统计日志已关闭.</b><br />需要到<a href='".e_ADMIN."plugin.php'>插件管理</a>下安装统计插件, 然后从<a href='".e_PLUGIN."log/admin_config.php'>配置页面</a>激活.");
	
?>