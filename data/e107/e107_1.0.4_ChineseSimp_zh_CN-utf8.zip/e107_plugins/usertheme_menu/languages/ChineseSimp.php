<?php

define('LAN_UMENU_THEME_1', '设置布景');
define('LAN_UMENU_THEME_2', '选择布景');
define('LAN_UMENU_THEME_3', '用户:');
define('LAN_UMENU_THEME_4', '设置用户可以选择的布景');
define('LAN_UMENU_THEME_5', '更新');
define('LAN_UMENU_THEME_6', '用户可用布景');
define('LAN_UMENU_THEME_7', '可以选择布景的用户组群');
	
?>