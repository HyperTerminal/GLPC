<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_sitedown.php $
|     $Revision: 11678 $
|     $Id: lan_sitedown.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "网站暂时关闭");
define("LAN_SITEDOWN_00", "暂时关闭");
define("LAN_SITEDOWN_01", "本站正在维护中，暂时关闭。不会太久 - 请稍后再访问，谢谢支持。");
?>