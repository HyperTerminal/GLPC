<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_user.php $
|     $Revision: 11678 $
|     $Id: lan_user.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "会员");

define("LAN_20", "错误");
define("LAN_112", "电子邮件");
//define("LAN_115", "ICQ Number");
//define("LAN_116", "AIM Address");
//define("LAN_117", "MSN Messenger");
//define("LAN_118", "Birthday");
//define("LAN_119", "Location");
//define("LAN_120", "Signature");
define("LAN_137", "没有该用户资料，未注册");
define("LAN_138", "注册会员: ");
define("LAN_139", "排序: ");
define("LAN_140", "注册会员");
define("LAN_141", "没有注册会员。");
define("LAN_142", "会员");
define("LAN_143", "[要求隐藏]");
//define("LAN_144", "Website URL");
define("LAN_145", "注册日期");
define("LAN_146", "访问次数");
define("LAN_147", "聊天发言次数");
define("LAN_148", "评论次数");
define("LAN_149", "论坛帖子");
define("LAN_308", "真实姓名");
define("LAN_400", "不是合法用户。");
define("LAN_401", "没有填写");
define("LAN_402", "个人档案");
define("LAN_403", "网站统计");
define("LAN_404", "最后访问");
define("LAN_405", "天之前");
define("LAN_406", "用户等级");
define("LAN_407", "无");
define("LAN_408", "没有照片");
define("LAN_409", "点数");
define("LAN_410", "其它");
define("LAN_411", "点击这里更新您的资料");
define("LAN_412", "点击这里修改用户资料");
define("LAN_413", "删除照片");
define("LAN_414", "上一页");
define("LAN_415", "下一页");
define("LAN_416", "登录后查看该页面");
define("LAN_417", "网站主管理员");
define("LAN_418", "网站管理员");
define("LAN_419", "显示");
define("LAN_420", "降序");
define("LAN_421", "升序");
define("LAN_422", "转到");
define("LAN_423", "点击这里查看用户评论");
define("LAN_424", "点击这里查看论坛帖子");
define("LAN_425", "发短消息");
define("LAN_426", "之前");

define("USERLAN_1", "单一评价");
define("USERLAN_2", "您不能查看该页。");

?>