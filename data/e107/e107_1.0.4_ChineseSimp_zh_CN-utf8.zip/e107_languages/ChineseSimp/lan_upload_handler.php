<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_upload_handler.php $
|     $Revision: 11678 $
|     $Id: lan_upload_handler.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "文件类型");
define("LANUPLOAD_2", "不允许，已经删除");
define("LANUPLOAD_3", "成功上传");
define("LANUPLOAD_4", "目标目录不存在或不可写。(chmod 777)");
define("LANUPLOAD_5", "上传的文件大小超过php.ini中upload_max_filesize的设置");
define("LANUPLOAD_6", "上传文件大小超过html表单中设置的MAX_FILE_SIZE。");
define("LANUPLOAD_7", "仅上传文件的一部分。");
define("LANUPLOAD_8", "没有上传文件。");
define("LANUPLOAD_9", "上传文件大小为0字节");
define("LANUPLOAD_10", "上传失败 [文件名重复] - 已存在同名文件。");
define("LANUPLOAD_11", "文件没有上传。文件名: ");
define("LANUPLOAD_12", "错误");
define("LANUPLOAD_13", "Missing temporary folder");
define("LANUPLOAD_14", "File write failed");
define("LANUPLOAD_15", "Upload not allowed");
define("LANUPLOAD_16", "Unknown Error");
define("LANUPLOAD_17", "Invalid name for uploaded file");
define("LANUPLOAD_18", "The uploaded file exceeds allowable limits.");
define("LANUPLOAD_19", "Too many files uploaded - excess deleted.");


?>