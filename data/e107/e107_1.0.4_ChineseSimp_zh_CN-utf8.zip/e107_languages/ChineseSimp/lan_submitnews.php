<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_submitnews.php $
|     $Revision: 11678 $
|     $Id: lan_submitnews.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "发表新闻");
define("LAN_7", "登录名: ");
define("LAN_62", "新闻标题: ");
define("LAN_112", "电子邮件: ");
define("LAN_133", "谢谢");
define("LAN_134", "您的新闻已提交给管理员审核。");
define("LAN_135", "新闻内容: ");
define("LAN_136", "提交新闻");
define("NWSLAN_6", "分类");
define("NWSLAN_10", "没有新闻分类");
define("NWSLAN_11", "您没有权限访问该页面");
define("NWSLAN_12", "禁止访问。");

define("SUBNEWSLAN_1", "请输入标题。\\n");
define("SUBNEWSLAN_2", "请输入新闻内容\\n");
define("SUBNEWSLAN_3", "附件必须为jpg、gif或png文件");
define("SUBNEWSLAN_4", "文件太大");
define("SUBNEWSLAN_5", "图片文件");
define("SUBNEWSLAN_6", "(jpg, gif 或 png)");
define('SUBNEWSLAN_7', '请输入姓名和电子邮件地址');
define('SUBNEWSLAN_8', '上传图片出错');

?>