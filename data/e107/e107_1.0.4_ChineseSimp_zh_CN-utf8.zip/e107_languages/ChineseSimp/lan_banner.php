<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_banner.php $
|     $Revision: 11678 $
|     $Id: lan_banner.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "广告");

define("BANNERLAN_16", "用户名: ");
define("BANNERLAN_17", "密码: ");
define("BANNERLAN_18", "继续");
define("BANNERLAN_19", "请输入您的客户帐号和密码");
define("BANNERLAN_20", "抱歉，没有找到相应资料。请联系网站管理员。");
define("BANNERLAN_21", "广告统计");
define("BANNERLAN_22", "客户");
define("BANNERLAN_23", "广告ID");
define("BANNERLAN_24", "点击次数");
define("BANNERLAN_25", "点击 %");
define("BANNERLAN_26", "显示次数");
define("BANNERLAN_27", "购买的显示次数");
define("BANNERLAN_28", "剩余显示次数");
define("BANNERLAN_29", "没有广告");
define("BANNERLAN_30", "没有限制");
define("BANNERLAN_31", "没有");
define("BANNERLAN_32", "是");
define("BANNERLAN_33", "否");
define("BANNERLAN_34", "结束日期:");
define("BANNERLAN_35", "点击IP地址");
define("BANNERLAN_36", "激活:");
define("BANNERLAN_37", "开始日期:");
define("BANNERLAN_38", "错误");

?>