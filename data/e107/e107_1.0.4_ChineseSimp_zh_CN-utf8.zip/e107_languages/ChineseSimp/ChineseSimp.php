<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/ChineseSimp.php $
|     $Revision: 11678 $
|     $Id: ChineseSimp.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'zh_CN.UTF-8', 'zh_CN.utf8', 'zhcn');
define("CORE_LC", 'zh');
define("CORE_LC2", 'cn');
// define("TEXTDIRECTION","rtl");
define("CHARSET", "utf-8");  // for a true multi-language site. :)
define("CORE_LAN1","错误：缺少布景。\\n\\n在管理页面下的参数选项中修改布景或者上传当前布景文件到服务器。");

//v.616
//obsolete define("CORE_LAN2"," \\1 wrote:");// "\\1" represents the username.
//obsolete define("CORE_LAN3","file attachment disabled");

//v0.7+
define("CORE_LAN4", "请从服务器上删除install.php");
define("CORE_LAN5", "如果不删除对网站有潜在的安全风险");

// v0.7.6
define("CORE_LAN6", "过载保护已启用，如果您持续不断的访问页面，将会被屏蔽。");
define("CORE_LAN7", "正在从自动备份中恢复参数。");
define("CORE_LAN8", "核心参数错误");
define("CORE_LAN9", "无法从自动备份中恢复核心文件，停止运行。");
define("CORE_LAN10", "cookie 出错 - 退出。");

// Footer
define("CORE_LAN11", "执行时间: ");
define("CORE_LAN12", "秒, ");
define("CORE_LAN13", "用于查询");
define("CORE_LAN14", "");			// Used in 0.8
define("CORE_LAN15", "数据库查询: ");
define("CORE_LAN16", "内存使用: ");

// img.bb
define('CORE_LAN17', '[ 禁用图像 ]');
define('CORE_LAN18', '图像: ');

define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "kB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");


define("LAN_WARNING", "警告!");
define("LAN_ERROR", "错误");
define("LAN_ANONYMOUS", "匿名");
define("LAN_EMAIL_SUBS", "-邮件-");

// 0.7.23
define("LAN_SANITISED", "过滤");
?>