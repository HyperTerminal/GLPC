<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_user_select.php $
|     $Revision: 11678 $
|     $Id: lan_user_select.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("US_LAN_1", "选择用户");
define("US_LAN_2", "选择用户组群");
define("US_LAN_3", "所有用户");
define("US_LAN_4", "查找用户名");
define("US_LAN_5", "找到用户");
define("US_LAN_6", "搜索");
?>