<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_rate.php $
|     $Revision: 11678 $
|     $Id: lan_rate.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "投票");
define("RATELAN_1", "投票");
define("RATELAN_2", "您对该项目的评价为?");
define("RATELAN_3", "谢谢您的投票");
define("RATELAN_4", "尚未评价");
define("RATELAN_5", "评价");

?>