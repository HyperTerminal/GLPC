<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_prefs.php $
|     $Revision: 11678 $
|     $Id: lan_prefs.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107建站系统");
define("LAN_PREF_2", "e107建站系统");
define("LAN_PREF_3", "本建站系统<a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>，采用的是<a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a>GPL开源许可。");
define("LAN_PREF_4", "已审核");
define("LAN_PREF_5", "论坛");

?>