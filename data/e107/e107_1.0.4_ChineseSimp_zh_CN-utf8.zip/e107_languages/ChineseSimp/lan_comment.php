<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2010 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * Comment handling - language files
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_comment.php $
 * $Id: lan_comment.php 11687 2010-08-23 07:25:47Z Jack $
 */

define("COMLAN_0", "[被管理员屏蔽]");
define("COMLAN_1", "解锁");
define("COMLAN_2", "锁定");
define("COMLAN_3", "删除");
define("COMLAN_4", "内容");
define("COMLAN_5", "评论 ...");
define("COMLAN_6", "登录后才能发表评论 - 请先登录，如果还未注册请点击");
define("COMLAN_7", "主站管理员");
define("COMLAN_8", "评论");
define("COMLAN_9", "发表评论");
define("COMLAN_10", "管理员");
define("COMLAN_11", "无法保存评论 - 请重新输入，不能输入任何特殊字符。");
define('COMLAN_12', '用户');
define("COMLAN_16", "用户名: ");
define("COMLAN_99", "评论");
define("COMLAN_100", "新闻");
define("COMLAN_101", "投票");
define("COMLAN_102", "回复: ");
define("COMLAN_103", "文章");
define("COMLAN_104", "评价");
define("COMLAN_105", "内容");
define("COMLAN_106", "下载");
define("COMLAN_145", "已注册: ");
define("COMLAN_194", "客户");
define("COMLAN_195", "注册客户");
define("COMLAN_310", "该用户名已注册，无法保存。 - 如果这是您的用户名，请登录后再发帖。");
define("COMLAN_312", "重复发帖 - 不能保存。");
define("COMLAN_313", "位置");
define("COMLAN_314", "审核评论");
define("COMLAN_315", "Trackbacks");
define("COMLAN_316", "该内容没有 trackbacks。");
define("COMLAN_317", "审核 trackbacks");
define("COMLAN_318", "修改评论");
define("COMLAN_319", "已修改");
define("COMLAN_320", "更新评论");
define("COMLAN_321", "这里");
define("COMLAN_322", "注册");
define("COMLAN_323", "错误!");
define("COMLAN_324", '标题');
define("COMLAN_325", '回复:');
define("COMLAN_326", '回复');
define("COMLAN_327", '评价');
define("COMLAN_328", '评论已关闭');
define("COMLAN_329", '未授权');
define("COMLAN_330", 'IP:');
define("COMLAN_331", "等待审核");

define("COMLAN_TYPE_1", "新闻");
define("COMLAN_TYPE_2", "下载");
define("COMLAN_TYPE_3", "FAQ");
define("COMLAN_TYPE_4", "投票");
define("COMLAN_TYPE_5", "文档");
define("COMLAN_TYPE_6", "bugtrack");
define("COMLAN_TYPE_7", "想法");
define("COMLAN_TYPE_8", "用户资料");
define("COMLAN_TYPE_PAGE", "内容");		// Really custom page, but use a 'non-technical' description

?>