<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_error.php $
|     $Revision: 11875 $
|     $Id: lan_error.php 11875 2010-10-10 19:45:11Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "错误");

define("LAN_ERROR_1", "错误 401 - 权限拒绝");
define("LAN_ERROR_2", "您没有权限访问本网址或链接。");
define("LAN_ERROR_3", "如果您觉得本页面有问题，请通知管理员。");
define("LAN_ERROR_4", "错误 403 - 授权失败");
define("LAN_ERROR_5", "访问该URL需要用户名和密码，输入的用户名或密码不正确，或者是您的浏览器不支持本功能。");
define("LAN_ERROR_6", "如果您觉得本页面有问题，请通知管理员。");
define("LAN_ERROR_7", "错误 404 - 文档不存在");
define("LAN_ERROR_9", "如果您觉得本页面有问题，请通知管理员。");
define("LAN_ERROR_10", "错误 500 - Malformed Header");
define("LAN_ERROR_11", "服务器内部错误，或配置错误，无法完成操作");
define("LAN_ERROR_12", "如果您觉得本页面有问题，请通知管理员。");
define("LAN_ERROR_13", "错误 - 未知");
define("LAN_ERROR_14", "服务器出错");
define("LAN_ERROR_15", "如果您觉得本页面有问题，请通知管理员。");
define("LAN_ERROR_16", "您不能访问");
define("LAN_ERROR_17", "已记录。");
define("LAN_ERROR_18", "您的来源地址");
define("LAN_ERROR_19", "对不起，本链接不存在。");
define("LAN_ERROR_20", "请点击这里转向该网站的首页");
define("LAN_ERROR_21", "服务器上没有相应的网址。您的链接可能过时了。");
define("LAN_ERROR_22", "请点击这里转向该网站的搜索页面");
define("LAN_ERROR_23", "您要访问");
define("LAN_ERROR_24", " 不成功。");

// 0.7.6
define("LAN_ERROR_25", "[1]: Unable to read core settings from database - Core settings exist but cannot be unserialized. Attempting to restore core backup ...");
define("LAN_ERROR_26", "[2]: Unable to read core settings from database - non-existent core settings.");
define("LAN_ERROR_27", "[3]: Core settings saved - backup made active.");
define("LAN_ERROR_28", "[4]: No core backup found. Check that your database has valid content. If not, please run the <a href='".e_FILE_ABS."resetcore/resetcore.php'>Reset_Core</a> utility to rebuild your core settings. <br />After rebuilding your core please save a backup from the admin/sql screen.");
define("LAN_ERROR_29", "[5]: Field(s) have been left blank. Please resubmit the form and fill in the required fields.");
define("LAN_ERROR_30", "[6]: Unable to form a valid connection to mySQL. Please check that your e107_config.php contains the correct information.");
define("LAN_ERROR_31", "[7]: mySQL is running but database ({$mySQLdefaultdb}) couldn't be connected to.<br />Please check it exists and that your e107_config.php contains the correct information.");
define("LAN_ERROR_32", "To complete the upgrade, copy the following text into your e107_config.php file:");

define("LAN_ERROR_33", "处理出错! 通常跳转到首页.");
define("LAN_ERROR_34", "未知错误! 请通知网站管理员以下内容:");

define('LAN_ERROR_35', '错误 400 - Bad Request');
define('LAN_ERROR_36', '访问页面出现格式错误.');
define('LAN_ERROR_37', '错误图标');
define('LAN_ERROR_38', '');
define('LAN_ERROR_39', '');


?>