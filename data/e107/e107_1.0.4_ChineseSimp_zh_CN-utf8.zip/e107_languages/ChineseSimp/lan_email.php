<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_email.php $
|     $Revision: 11678 $
|     $Id: lan_email.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "电子邮件"); }

define("LAN_EMAIL_1", "发件人:");
define("LAN_EMAIL_2", "发件人IP地址:");
define("LAN_EMAIL_3", "发送邮件，来自");
define("LAN_EMAIL_4", "发送邮件");
define("LAN_EMAIL_5", "来自朋友的邮件");
define("LAN_EMAIL_6", "您也许对这个有兴趣，来自");
define("LAN_EMAIL_7", "发送邮件");
define("LAN_EMAIL_8", "备注");
define("LAN_EMAIL_9", "抱歉 - 无法发送邮件");
define("LAN_EMAIL_10", "邮件发送给");
define("LAN_EMAIL_11", "邮件已发送");
define("LAN_EMAIL_12", "错误");
define("LAN_EMAIL_13", "发送文章给朋友");
define("LAN_EMAIL_14", "发送新内容给朋友");
define("LAN_EMAIL_15", "用户名: ");
define("LAN_EMAIL_106", "邮件地址不正确");
define("LAN_EMAIL_185", "发送文章");
define("LAN_EMAIL_186", "发送新邮件");
define("LAN_EMAIL_187", "收件人邮件地址");
define("LAN_EMAIL_188", "您也许对这个新闻感兴趣，来自");
define("LAN_EMAIL_189", "您也许对这篇文章感兴趣，来自");
define("LAN_EMAIL_190", "输入可视化代码");

?>