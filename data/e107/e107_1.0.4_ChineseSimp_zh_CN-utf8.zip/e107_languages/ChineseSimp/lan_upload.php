<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_upload.php $
|     $Revision: 11678 $
|     $Id: lan_upload.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "上传文件");

define('LAN_UL_001','电子邮件地址不正确');
define('LAN_UL_002', 'You do not have the correct permissions to upload files to this server.');	// LAN_403

define('LAN_UL_020', '错误');
define('LAN_UL_021', '上传失败');

define('LAN_UL_032', '请选择分类');
define('LAN_UL_033', '请输入电子邮件地址');
define('LAN_UL_034', '请输入文件名');
define('LAN_UL_035', '请填写简介');
define('LAN_UL_036', '请指定上传文件');
define('LAN_UL_037', '请选择分类');
define('LAN_UL_038', '');

define("LAN_61", "您的姓名: ");
define("LAN_112", "电子邮件: ");
define("LAN_144", "网址: ");
define("LAN_402", "注册为会员后才能上传文件。");
define("LAN_404", "感谢您上传文件！文件通过管理员的审核后，将发布在网站上。");
//define("LAN_405", "File exceeds specified maximum size limit - deleted.");
define("LAN_406", "请注意");
define("LAN_407", "上传其它文件类型将立刻删除。");
define("LAN_408", "下划线");
define("LAN_409", "文件名");
define("LAN_410", "版本");
define("LAN_411", "文件");
define("LAN_412", "缩略图");
define("LAN_413", "描述");
define("LAN_414", "演示版本");
define("LAN_415", "输入网址");
define("LAN_416", "上传");
define("LAN_417", "上传文件");
define("LAN_418", "允许文件大小: ");
define("DOWLAN_11", "分类");
define("LAN_419", "允许的文件类型");
define("LAN_420", "为必填字段");



?>