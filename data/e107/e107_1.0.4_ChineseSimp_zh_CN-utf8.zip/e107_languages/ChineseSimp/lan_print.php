<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_print.php $
|     $Revision: 11678 $
|     $Id: lan_print.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) { define("PAGE_NAME", "打印页面"); }

define("LAN_PRINT_86", "分类:");
define("LAN_PRINT_87", "由");
define("LAN_PRINT_94", "作者");
define("LAN_PRINT_135", "新闻: ");
define("LAN_PRINT_303", "本新闻来自");
define("LAN_PRINT_304", "标题: ");
define("LAN_PRINT_305", "副标题: ");
define("LAN_PRINT_306", "来自: ");
define("LAN_PRINT_307", "打印本页");

define("LAN_PRINT_1", "打印页面");


?>