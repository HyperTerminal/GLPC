<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_signup.php $
|     $Revision: 12130 $
|     $Id: lan_signup.php 12130 2011-04-12 21:09:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "用户注册");
define("LAN_7", "显示名: ");
define("LAN_8", "该名字将显示在网站上");
define("LAN_9", "登录名: ");
define("LAN_10", "您用来登录的名字");
define("LAN_17", "密码: ");
define("LAN_103", "该用户名不合法，请另外选择一个用户名");
define("LAN_104", "该登录名已在数据库中存在，请选择另一个用户名");
define("LAN_105", "两次输入的密码不一样");
define("LAN_106", "电子邮件地址不正确");
define("LAN_107", "非常感谢! 您已注册为会员，在");
define("LAN_108", "注册完成");
define("LAN_109", "本站遵守1998年儿童在线政策保护条例(COPPA)，不接受13岁以下儿童未经父母或监护人书面认可的注册。要阅读更多相关法规请点");
define("LAN_110", "注册");
define("LAN_111", "重复密码: ");
define("LAN_112", "电子邮件: ");
define("LAN_113", "隐藏邮箱吗?: ");
define("LAN_114", "这可以防止在网站上显示您的邮箱");
define("LAN_123", "注册");
define("LAN_185", "有必填项为空");
define("LAN_201", "是");
define("LAN_200", "否");
define("LAN_202", "您已经有了一个账户。如果您忘记了密码，请点击\'忘记密码\'链接。");
define("LAN_309", "请在下面输入您的详细情况。");
define("LAN_399", "继续");
define("LAN_400", "用户名和密码是<b>大小写敏感</b>");
define("LAN_401", "您的帐号已激活，请");
define("LAN_402", "帐号已激活");
define("LAN_403", "欢迎您加入");
define("LAN_404", "注册");
define("LAN_405", "注册完成。您会收到一封包含您的注册信息的确认信。请点击那个链接完成注册并激活账户。");
define("LAN_406", "非常感谢!");
define("LAN_407", "请保留这封信作为记录。您的密码已被加密，遗失不能找回。如果忘记密码，您可以申请一个新密码。\n\n多谢您的注册。\n\n于");
define("LAN_408", "该邮箱已经存在。请使用“取回密码”功能找回密码。");
define("LAN_SIGNUP_1", "最少");
define("LAN_SIGNUP_2", "个字符");
define("LAN_SIGNUP_3", "代码验证失败");
define("LAN_SIGNUP_4", "密码不能少于");
define("LAN_SIGNUP_5", "个字符");
define("LAN_SIGNUP_6", "您的");
define("LAN_SIGNUP_7", "至少");
define("LAN_SIGNUP_8", "非常感谢!");
define("LAN_SIGNUP_9", "无法继续。");
define("LAN_SIGNUP_10", "是");
define("LAN_SIGNUP_11", "。");

define("LAN_409", "用户名中有非法字符");
define("LAN_410", "在图片中输入可见代码");
define("LAN_411", "数据库中已有该名存在，请选择另一个名字");


define("LAN_SIGNUP_12", "请妥善保存您的用户名和密码。");
define("LAN_SIGNUP_13", "您现在可以登录网站，或者点<a href='".e_BASE."login.php'>这里</a>。");
define("LAN_SIGNUP_14", "这里");
define("LAN_SIGNUP_15", "请联系网站管理员");
define("LAN_SIGNUP_16", "如果您需要协助。");
define("LAN_SIGNUP_17", "请保证您已满13岁");
define("LAN_SIGNUP_18", "您的注册资料已收到，生成了以下登录信息:");
//define("LAN_SIGNUP_19", "Username:"); // now LAN_LOGINNAME
//define("LAN_SIGNUP_20", "Password:"); // now LAN_PASSWORD
define("LAN_SIGNUP_21", "您的帐户还未激活，要激活请点击下面的链接 ");
define("LAN_SIGNUP_22", "点击这里");
define("LAN_SIGNUP_23", "登录。");
define("LAN_SIGNUP_24", "多谢您注册");
define("LAN_SIGNUP_25", "上传您的头像");
define("LAN_SIGNUP_26", "上传您的照片");
define("LAN_SIGNUP_27", "显示");
define("LAN_SIGNUP_28", "内容选择/邮件列表");
define("LAN_SIGNUP_29", "确认信会发到您登记的邮箱，请确认您输入的邮箱地址正确。");
define("LAN_SIGNUP_30", "如果您不希望在网页上显示您的邮箱，请选中“隐藏邮箱”选项。");

define("LAN_SIGNUP_31", "您的 XUP 文件地址");
define("LAN_SIGNUP_32", "什么是XUP 文件?");
define("LAN_SIGNUP_33", "输入链接或选择头像");
define("LAN_SIGNUP_34", "请注意:任何上传到服务器的照片一旦管理员认为不合适的将被立即删除。");
define("LAN_SIGNUP_35", "点击这里使用XUP文件注册");
define("LAN_SIGNUP_36", "在产生您的用户信息时出现错误，请联系网络管理员。");

define("LAN_LOGINNAME", "登录名");
define("LAN_PASSWORD", "密码");
define("LAN_USERNAME", "显示名");
define("LAN_EMAIL_01", "尊敬的");
define("LAN_EMAIL_04", "请妥善保存本邮件。");
define("LAN_EMAIL_05", "您的密码已加密，如果遗失将无法恢复，但您可以申请一个新密码。");
define("LAN_EMAIL_06", "多谢您的注册！");

define("LAN_SIGNUP_37", "注册完成。网站管理员通过您的会员资格后，您将会收到一封确认信，通知您的会员资格已被批准。");
define("LAN_SIGNUP_38", "您输入了两个不同的邮箱地址。请在提供的两栏中输入正确的邮箱地址。");
define("LAN_SIGNUP_39", "重复电子邮件:");

// 0.7.6
define("LAN_SIGNUP_40", "不需要激活");
define("LAN_SIGNUP_41", "您的账号已经激活.");
define("LAN_SIGNUP_42", "系统出错，注册邮件未发出。请联系网站管理员.");
define("LAN_SIGNUP_43", "邮件已发出");
define("LAN_SIGNUP_44", "激活邮件发到:");
define("LAN_SIGNUP_45", "请检查邮件.");
define("LAN_SIGNUP_47", "重发激活邮件");
define("LAN_SIGNUP_48", "用户名或邮件地址");
define("LAN_SIGNUP_49", "如果您注册时填写的邮件地址不正确，请输入正确的邮件地址和密码:");
define("LAN_SIGNUP_50", "新的邮件地址");
define("LAN_SIGNUP_51", "旧的密码");
define("LAN_SIGNUP_52", "密码不正确");
define("LAN_SIGNUP_53", "字段检测出错");
define("LAN_SIGNUP_54", "点这里填写注册资料");
define("LAN_SIGNUP_55", "显示名称太长，请重新输入");
define("LAN_SIGNUP_56", "显示名称太短，请重新输入");
define("LAN_SIGNUP_57", "登录名太长，请重新输入");
define("LAN_SIGNUP_58", "注册预览");
define("LAN_SIGNUP_59","**** 如果链接无法打开, 请检查链接没有被分割到下一行。 ****");
define('LAN_SIGNUP_60', '读取外部头像错误');

// 0.7.16

define("LAN_SIGNUP_72", "感谢您在[sitename]注册！确认邮件已发到[email]，请点击邮件中的链接完成注册并激活帐号。");  	// LAN_405

define("LAN_SIGNUP_98", "确认电子邮件地址");
define("LAN_SIGNUP_99", "遇到问题");
define("LAN_SIGNUP_100", "管理待批");


define('LAN_SIGNUP_102', '拒绝注册');
define('LAN_SIGNUP_103', '太多用户使用IP地址: ');
define('LAN_SIGNUP_104', '别名无效');
define('LAN_SIGNUP_105', '无法执行该操作 - 请联系网站管理员');		// Two people with same password.
define('LAN_SIGNUP_106', '无法执行该操作 - 您已经有账号了吗?');		// Trying to set email same as existing

?>