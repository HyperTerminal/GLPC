<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_news.php $
|     $Revision: 11678 $
|     $Id: lan_news.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "新闻");


define("LAN_NEWS_1", "特定会员的新闻");
define("LAN_NEWS_2", "您没有阅读本新闻权限");
define("LAN_NEWS_9", "设定为仅显示标题 - <b>仅显示新闻标题</b><br />");
define("LAN_NEWS_10", "该新闻<b>未激活</b> (不显示在首页)。");
define("LAN_NEWS_11", "该新闻<b>已激活</b> (将显示在首页)。");
define("LAN_NEWS_12", "评论已<b>打开</b>。");
define("LAN_NEWS_13", "评论已<b>关闭</b>。");
define("LAN_NEWS_14", "<br />激活时间: ");
define("LAN_NEWS_15", "内容字数: ");
define("LAN_NEWS_16", "b. 详细内容字数: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "信息:");
define("LAN_NEWS_19", "现在");
define("LAN_NEWS_23", "新闻分类");
define("LAN_NEWS_24", "生成该新闻的pdf文件");
define("LAN_NEWS_25", "修改");
define('LAN_NEWS_31', '固定新闻');					// Added
define('LAN_NEWS_82', '新闻 - 分类');
define('LAN_NEWS_83', '当前没有新闻 - 请稍后查看。');
define('LAN_NEWS_84', '返回新闻首页');
define('LAN_NEWS_85', '返回分类首页');
define('LAN_NEWS_86', '旧的新闻');
define('LAN_NEWS_87', '新的新闻');
define("LAN_NEWS_462", "指定月份没有新闻");

// Following used by alt_news
define('LAN_NEWS_99', '评论');
define('LAN_NEWS_100', '打开');
define('LAN_NEWS_307', '该分类中文章总数: ');

?>