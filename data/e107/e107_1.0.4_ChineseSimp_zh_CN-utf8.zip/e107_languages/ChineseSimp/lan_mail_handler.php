<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_mail_handler.php $
|     $Revision: 11678 $
|     $Id: lan_mail_handler.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "e107 整站系统");
define("LANMAILH_2", "这是MIME格式的multi-part信息。");
define("LANMAILH_3", "格式不对");
define("LANMAILH_4", "服务器拒绝地址");
define("LANMAILH_5", "服务器没有响应");
define("LANMAILH_6", "没有找到邮件服务器。");
define("LANMAILH_7", "正确。");


?>