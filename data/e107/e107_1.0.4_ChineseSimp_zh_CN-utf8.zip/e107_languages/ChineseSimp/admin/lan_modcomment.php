<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_modcomment.php $
|     $Revision: 11678 $
|     $Id: lan_modcomment.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "已修改。");
define("MDCLAN_2", "该项目没有评论");
define("MDCLAN_3", "会员");
define("MDCLAN_4", "访客");
define("MDCLAN_5", "解锁");
define("MDCLAN_6", "锁定");

define("MDCLAN_7", "批准");
define("MDCLAN_8", "修改评论");
define("MDCLAN_9", "警告! 删除上级评论 将删除所有回复!");

define("MDCLAN_10", "选项");
define("MDCLAN_11", "评论");
define("MDCLAN_12", "评论");
define("MDCLAN_13", "锁定");
define("MDCLAN_14", "锁定评论");
define("MDCLAN_15", "打开");
define("MDCLAN_16", "锁定");
define("MDCLAN_17", "目前没有需要审核的评论");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>