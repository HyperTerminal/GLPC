<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_userinfo.php $
|     $Revision: 11678 $
|     $Id: lan_userinfo.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "无法找到服务器IP地址 - 没有可用信息。");
// define("USFLAN_2", "Error");
define("USFLAN_3", "信息来自IP地址");
define("USFLAN_4", "主机");
define("USFLAN_5", "点击这里添加IP地址到黑名单");
define("USFLAN_6", "用户ID");
define("USFLAN_7", "用户信息");

?>