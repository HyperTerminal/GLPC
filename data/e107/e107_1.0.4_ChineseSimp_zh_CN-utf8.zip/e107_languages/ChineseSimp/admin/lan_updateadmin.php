<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_updateadmin.php $
|     $Revision: 11678 $
|     $Id: lan_updateadmin.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "错误 - 请重新提交");
define("UDALAN_2", "设置更新");
define("UDALAN_3", "设置更新");
define("UDALAN_4", "用户名");
define("UDALAN_5", "密码");
define("UDALAN_6", "重复密码");
define("UDALAN_7", "修改密码");
define("UDALAN_8", "密码更新");

?>