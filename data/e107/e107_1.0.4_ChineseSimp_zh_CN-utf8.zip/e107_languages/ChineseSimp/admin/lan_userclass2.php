<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_userclass2.php $
|     $Revision: 12246 $
|     $Id: lan_userclass2.php 12246 2011-06-04 14:14:26Z nlstart $
|     $Author: nlstart $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "从组群中删除所有用户。");
define("UCSLAN_2", "组群用户已更新。");
define("UCSLAN_3", "组群已删除。");
define("UCSLAN_4", "请选择确认框删除该用户组群");
define("UCSLAN_5", "组群已更新。");
define("UCSLAN_6", "组群已保存到数据库。");
define("UCSLAN_7", "还没有用户组群");
define("UCSLAN_8", "现有组群");

// define("UCSLAN_9", "Edit");
// define("UCSLAN_10", "Delete");
define("UCSLAN_11", "选中确认");
define("UCSLAN_12", "组群名称");
define("UCSLAN_13", "组群描述");
define("UCSLAN_14", "更新用户组群");
define("UCSLAN_15", "新建组群");
define("UCSLAN_16", "指定用户到组群");
define("UCSLAN_17", "删除");
define("UCSLAN_18", "清除组群");
define("UCSLAN_19", "指定用户到");
define("UCSLAN_20", "组群");
define("UCSLAN_21", "用户组群设置");

define("UCSLAN_22", "用户 - 点击移动 ...");
define("UCSLAN_23", "该组群中的用户 ...");

define("UCSLAN_24", "管理组群的用户");

define("UCSLAN_25", "ID");
define("UCSLAN_26", "用户名");
define("UCSLAN_27", "返回");

?>