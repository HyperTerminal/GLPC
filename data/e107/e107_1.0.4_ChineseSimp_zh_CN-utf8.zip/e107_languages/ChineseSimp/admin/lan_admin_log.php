<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_admin_log.php $
|     $Revision: 11678 $
|     $Id: lan_admin_log.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "管理日志");
define("LAN_ADMINLOG_1", "日期");
define("LAN_ADMINLOG_2", "标题");
define("LAN_ADMINLOG_3", "简介");
define("LAN_ADMINLOG_4", "用户 IP");
define("LAN_ADMINLOG_5", "用户 ID");
define("LAN_ADMINLOG_6", "消息图标");
define("LAN_ADMINLOG_7", "消息内容");
define("LAN_ADMINLOG_8", "提示图标");
define("LAN_ADMINLOG_9", "提示内容");
define("LAN_ADMINLOG_10", "警告图标");
define("LAN_ADMINLOG_11", "警告内容");
define("LAN_ADMINLOG_12", "错误图标");
define("LAN_ADMINLOG_13", "错误内容");

?>