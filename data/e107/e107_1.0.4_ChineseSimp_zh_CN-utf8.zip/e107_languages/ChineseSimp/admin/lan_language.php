<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_language.php $
|     $Revision: 11842 $
|     $Id: lan_language.php 11842 2010-10-04 07:43:15Z e107coders $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00", "无法创建。(已存在)");
define("LANG_LAN_01", "已删除(如已存在) 并重建。");
define("LANG_LAN_02", "无法删除");
define("LANG_LAN_03", "数据表");

define("LANG_LAN_05", "没有安装");
define("LANG_LAN_06", "创建数据表");
define("LANG_LAN_07", "删除现有数据表?");
define("LANG_LAN_08", "更新已有数据表(数据将丢失)。");
define("LANG_LAN_10", "确认删除");
define("LANG_LAN_11", "删除上面没有选中的数据表(如已存在)。");
define("LANG_LAN_12", "打开多语言数据表");
define("LANG_LAN_13", "语言选择");
define("LANG_LAN_14", "网站默认语言");
define("LANG_LAN_15", "选择从默认语言中复制数据。(对链接、新闻分类等有用) ");
define("LANG_LAN_16", "多语言数据库使用");
define("LANG_LAN_17", "默认语言 - 不需要增加数据表。");
define("LANG_LAN_18", "使用二级域名设置网站语言：");
define("LANG_LAN_19", "例如，域名 fr.mydomain.com 设置语言为法语。");
define("LANG_LAN_20", "每行输入一个域名，例如 mydomain.com 等，或者留空不使用。");

define("LANG_LAN_21", "语言工具");

define("LANG_LAN_23", "创建语言包 (zip)");
define("LANG_LAN_24", "生成");

define("LANG_LAN_AGR", "说明: 使用这些工具表示您同意共享语言包给 e107 社区。");
define("LANG_LAN_EML", "请通过邮件发语言包到:");

define("LANG_LAN_25", "请检查 CORE_LC 和 CORE_LC2 中 [lcpath] 有内容后重试。");
define("LANG_LAN_26", "请确认您使用 e107_config.php 中默认的目录名 (例如 'e107_languages/', 'e107_plugins/' 等) 后重试。");
define("LANG_LAN_27", "请检查语言文件 ('检查') 后重试。");
define("LANG_LAN_28", "如果您是 [e107 认证翻译人员]，请在本框打勾。");

define("LANG_LAN_29", "请修复错误后再发布语言包。");
define("LANG_LAN_30", "发布日期");
define("LANG_LAN_31", "兼容性");
define("LANG_LAN_32", "已安装语言");
define("LANG_LAN_33", "检查时仅显示错误");
define("LANG_LAN_34", "创建语言包前请检查并修复出现的 [x] 错误。");

?>