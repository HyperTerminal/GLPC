<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_ugflag.php $
|     $Revision: 11678 $
|     $Id: lan_ugflag.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define('UGFLAN_1', '维护设置更新');
define('UGFLAN_2', '进入维护状态');
define('UGFLAN_3', '更新维护设置');
define('UGFLAN_4', '维护设置');

define('UGFLAN_5', '网站关闭时显示的文字');
define('UGFLAN_6', '留空显示默认信息');

define('UGFLAN_8', '仅限管理员使用');
define('UGFLAN_9', '仅限主管理员使用');

?>