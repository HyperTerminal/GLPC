<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_notify.php $
|     $Revision: 11678 $
|     $Id: lan_notify.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("NT_LAN_1", "邮件通知");
define("NT_LAN_2", "邮件通知选项");
define("NT_LAN_3", "关闭");
define("NT_LAN_4", "主管理员");
define("NT_LAN_5", "组群");
define("NT_LAN_6", "电子邮件");

define("NU_LAN_1", "用户事件");
define("NU_LAN_2", "用户注册");
define("NU_LAN_3", "用户帐户验证");
define("NU_LAN_4", "用户登录");
define("NU_LAN_5", "用户退出");

define("NS_LAN_1", "安全事件");
define("NS_LAN_2", "屏蔽IP地址");

define("NN_LAN_1", "新闻事件");
define("NN_LAN_2", "用户提交的新闻");
define("NN_LAN_3", "管理员提交的新闻");
define("NN_LAN_4", "管理员修改的新闻");
define("NN_LAN_5", "管理员删除的新闻");

define("NF_LAN_1", "文件记录");
define("NF_LAN_2", "用户上传文件");

define("CM_LAN_1", "评论事件");
define("CM_LAN_2", "用户提交的等待审核的评论");

?>