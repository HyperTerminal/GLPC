<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_mailout.php $
|     $Revision: 12180 $
|     $Id: lan_mailout.php 12180 2011-05-02 21:09:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("PRFLAN_52", "保存修改");
define("PRFLAN_63", "发送测试邮件");
//define("PRFLAN_64", "Clicking button will send test email to main admin email address");
define("PRFLAN_65", "点击发送邮件到");
define("PRFLAN_66", "测试邮件来自");
define("PRFLAN_67", "这是一封测试邮件，您的邮件设置正确!\n\n谢谢\n来自e107整站系统。");
define("PRFLAN_68", "无法发送该邮件。您的服务器发送邮件的设置不正确，请用SMTP重试，或询问主机商有关sendmail和邮件服务器的设置。");
define("PRFLAN_69", "该邮件成功发送，请检查您的邮箱。");
define("PRFLAN_70", "发送邮件方式");
define("PRFLAN_71", "如果不知道，设置为php");
define("PRFLAN_72", "SMTP服务器");
define("PRFLAN_73", "SMTP用户名");
define("PRFLAN_74", "SMTP密码");
define("PRFLAN_75", "无法发送邮件。请检查SMTP设置，或关闭后SMTP重试。");

define("MAILAN_01","发件人姓名");
define("MAILAN_02","发件人邮件");
define("MAILAN_03","收件人");
define("MAILAN_04","抄送");
define("MAILAN_05","秘密抄送");
define("MAILAN_06","标题");
define("MAILAN_07","附件");
define("MAILAN_08","发送邮件");
define("MAILAN_09","布景样式");
define("MAILAN_10","用户已订阅");
define("MAILAN_11","插入变量");
define("MAILAN_12","所有会员");
define("MAILAN_13","所有未验证用户");
define("MAILAN_14","建议打开SMTP以发送大量邮件 - 在下面的参数中设置。");
define("MAILAN_15","发送邮件");

define("MAILAN_16","用户名");
define("MAILAN_17","注册链接");
define("MAILAN_18","用户id");
define("MAILAN_19","网站管理员没有设置电子邮件。请检查设置后再试。");
define("MAILAN_20","Sendmail路径");
define("MAILAN_21","群发项目");
define("MAILAN_22","目前没有保存的项目");
define("MAILAN_23","用户组群: ");
define("MAILAN_24", "已准备好发送邮件");

define("MAILAN_25", "发送间隔");
define("MAILAN_26", "每发送");
define("MAILAN_27", "封邮件，暂停发送");
define("MAILAN_28", "暂停时间");
define("MAILAN_29", "秒");
define("MAILAN_30", "超过30秒可能导致浏览器超时");
define("MAILAN_31", "处理退回的邮件");
define("MAILAN_32", "电子邮件地址");
define("MAILAN_33", "收件箱");
define("MAILAN_34", "帐户名称");
define("MAILAN_35", "密码");
define("MAILAN_36", "检查后删除退回的邮件");  

define("MAILAN_37", "处理");
define("MAILAN_38", "取消");
define("MAILAN_39", "Emailing");
define("MAILAN_40", "You need to rename <b>e107.htaccess</b> to <b>.htaccess</b> in");
define("MAILAN_41", "before sending mail from this page.");
define("MAILAN_42", "警告");
define("MAILAN_43", "用户名");
define("MAILAN_44", "用户名");
define("MAILAN_45", "用户邮件");
define("MAILAN_46", "User-Match");
define("MAILAN_47", "包含");
define("MAILAN_48", "相当于");
define("MAILAN_49", "Id");
define("MAILAN_50", "作者");
define("MAILAN_51", "主题");
define("MAILAN_52", "最后修改");
define("MAILAN_53", "管理员");
define("MAILAN_54", "自己");
define("MAILAN_55", "用户组群");
define("MAILAN_56", "发送邮件");
define("MAILAN_57", "Keep SMTP session alive");
define("MAILAN_58", "There is a problem with the attachment:");
define("MAILAN_59", "Mailing Progress");
define("MAILAN_60", "发送中...");
define("MAILAN_61", "There are no remaining emails to be sent.");
define("MAILAN_62", "发出邮件:");
define("MAILAN_63", "失败邮件:");
define("MAILAN_64", "总耗时:");
define("MAILAN_65", "秒");
define("MAILAN_66", "Cancelled Successfully");
define("MAILAN_67", "Use 'POP before SMTP' authentication"); 
define('MAILAN_68', '测试地址');
define("MAILAN_69","用户登录");
define("MAILAN_70","用户邮件");



?>