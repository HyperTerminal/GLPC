<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_banlist.php $
|     $Revision: 11678 $
|     $Id: lan_banlist.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "黑名单已删除。");
define("BANLAN_2", "没有黑名单。");
define("BANLAN_3", "现有黑名单");
define("BANLAN_4", "删除黑名单");
define("BANLAN_5", "输入IP、电子邮件、或主机");
define("BANLAN_7", "原因");
define("BANLAN_8", "屏蔽用户");
define("BANLAN_9", "屏蔽用户访问本站");
define("BANLAN_10", "IP/电子邮件/原因");
define("BANLAN_11", "自动屏蔽: 登录失败超过10次");
define("BANLAN_12", "说明: Reverse DNS is currently disabled, it must be enabled to allow banning by host.  Banning by IP and email will still function normally.");
define("BANLAN_13", "说明: To ban a user by user name, go to the users admin page: ");
define('BANLAN_78','Hit count exceeded (--HITS-- requests within allotted time)');

?>