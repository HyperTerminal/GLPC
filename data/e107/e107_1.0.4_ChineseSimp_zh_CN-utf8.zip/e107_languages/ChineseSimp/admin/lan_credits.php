<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_credits.php $
|     $Revision: 11975 $
|     $Id: lan_credits.php 11975 2010-11-23 11:26:26Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "e107 鸣谢");

define("CRELAN_1", "鸣谢");
define("CRELAN_2", "这里是e107中使用的第三方软件列表/资源。e107开发小组衷心感谢以下为e107提供接口的开发人员，以及感谢他们采用GPL软件许可。");
define("CRELAN_3", "all rights reserved");
define("CRELAN_4", "显示 e107 开发团队");
define("CRELAN_5", "显示第三方脚本");
define("CRELAN_6", "e107 v0.7 开发者是 ...");
define("CRELAN_7", "版本");
define("CRELAN_8", "已授权");
define("CRELAN_9", "许可");

// third party scripts

define("CRELAN_10", "MagpieRSS 提供PHP的基于XML的RSS解析。");
define("CRELAN_11", "PclZip library offers compression and extraction functions for Zip formatted archives (WinZip, PKZIP).");
define("CRELAN_12", "PclTar offer the ability to archive a list of files or directories with or without compression. The archives created by PclTar are readable by most of gzip/tar applications and by the Windows WinZip application.");
define("CRELAN_13", "TinyMCE is a platform independent web based Javascript HTML WYSIWYG editor control released as Open Source under LGPL by Moxiecode Systems AB. It has the ability to convert HTML TEXTAREA fields or other HTML elements to editor instances.");
define("CRELAN_14", "e107 中使用的图标");
define("CRELAN_15", "Full featured email transfer class for PHP");
define("CRELAN_16", "Jayya 布景中的菜单系统");
define("CRELAN_17", "弹出日历控件");
define("CRELAN_18", "PDF 支持");
define("CRELAN_19", "UTF-8 PDF 支持");

// end third party scripts

// dev team

define("CRELAN_20", ""); // asperon
define("CRELAN_21", "Always a pressure..err..pleasure!"); // CaMer0n
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\""); // jalist
define("CRELAN_23", ""); // lisa
define("CRELAN_24", ""); // McFly
define("CRELAN_25", ""); // que
define("CRELAN_26", ""); // streaky
define("CRELAN_27", "\"Wot? No tea?? 0_0\""); // SweetAs
define("CRELAN_28", ""); // MrPete
define("CRELAN_29", "Up and forward!"); // SecretR
define("CRELAN_30", ""); // steved
//define("CRELAN_31", "");
//define("CRELAN_32", "");

// end dev team

?>