<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_meta.php $
|     $Revision: 11678 $
|     $Id: lan_meta.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta标签在数据库中已更新");
define("METLAN_2", "更新附加的meta标签");
define("METLAN_3", "更新meta标签设置");
define("METLAN_4", "已更新");
define("METLAN_5", "在这里输入描述");
define("METLAN_6", "在, 这里, 输入, 关键字, 列表");
define("METLAN_7", "在这里输入您的版权信息");
define("METLAN_8", "Meta标签");

define("METLAN_9", "描述");
define("METLAN_10", "关键字");
define("METLAN_11", "版权");
define("METLAN_12", "Use News title and summary as the meta-description on news pages.");
define("METLAN_13", "作者");

?>