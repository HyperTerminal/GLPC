<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_admin.php $
|     $Revision: 12315 $
|     $Id: lan_admin.php 12315 2011-07-08 03:02:34Z e107coders $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("ADLAN_0", "新闻");
define("ADLAN_1", "添加/修改/删除新闻");
//define("ADLAN_2", "News Categories");
//define("ADLAN_3", "Add/edit/delete news categories");
define("ADLAN_4", "参数");
define("ADLAN_5", "修改网站参数");
define("ADLAN_6", "页面布局");
define("ADLAN_7", "修改页面布局");
define("ADLAN_8", "管理员");
define("ADLAN_9", "添加/删除网站管理员");
define("ADLAN_10", "管理员密码");
define("ADLAN_11", "修改密码");
//define("ADLAN_12", "Forums");
//define("ADLAN_13", "Add/Edit Forums");
//define("ADLAN_14", "Articles");
//define("ADLAN_15", "Add new/edit/delete articles");
//define("ADLAN_16", "Content");
//define("ADLAN_17", "Add new/edit/delete content pages");
//define("ADLAN_18", "Reviews");
//define("ADLAN_19", "Add new/edit/delete reviews");
//define("ADLAN_22", "Link Categories");
//define("ADLAN_23", "Add new/edit/delete link categories");
define("ADLAN_24", "下载");
define("ADLAN_25", "管理下载");
//define("ADLAN_26", "Download Categories");
//define("ADLAN_27", "Add new/edit/delete download categories");
define("ADLAN_28", "欢迎信息");
define("ADLAN_29", "设置静态欢迎信息");
define("ADLAN_30", "文件管理");
define("ADLAN_31", "管理/上传文件");
//define("ADLAN_32", "Submitted News");
//define("ADLAN_33", "Review user submitted news items");
define("ADLAN_34", "黑名单");
define("ADLAN_35", "被屏蔽的访客");
define("ADLAN_36", "用户");
define("ADLAN_37", "修改网站成员");
define("ADLAN_38", "组群");
define("ADLAN_39", "新增/修改用户组群");
define("ADLAN_40", "网站维护");
define("ADLAN_41", "维护网站");
define("ADLAN_42", "菜单/页面");
define("ADLAN_43", "新增菜单/页面");
define("ADLAN_44", "数据库");
define("ADLAN_45", "数据库工具");
define("ADLAN_46", "退出");
define("ADLAN_47", "欢迎");
define("ADLAN_48", "登录");
define("ADLAN_49", "主管理员");
//define("ADLAN_50", "permissions");
define("ADLAN_51", "请登录后访问管理页面");
define("ADLAN_52", "管理首页");
define("ADLAN_53", "返回网站首页");
define("ADLAN_54", "广告");
define("ADLAN_55", "设置广告");
//define("ADLAN_56", "Chatbox");
//define("ADLAN_57", "Configure chatbox");
define("ADLAN_58", "表情");
define("ADLAN_59", "设置表情");
define("ADLAN_60", "首页");
define("ADLAN_61", "设置首页内容");
//define("ADLAN_62", "News Feeds");
//define("ADLAN_63", "Configure news feeds");
//define("ADLAN_64", "Log Stats");
//define("ADLAN_65", "Log stats/counter etc");
define("ADLAN_66", "Meta");
define("ADLAN_67", "添加/修改网站meta标签");
define("ADLAN_68", "PHP信息");
define("ADLAN_69", "PHP信息页面");
//define("ADLAN_70", "Polls");
//define("ADLAN_71", "Add/Edit Polls");
define("ADLAN_72", "上传");
define("ADLAN_73", "设置文件上传");
define("ADLAN_74", "缓存");
define("ADLAN_75", "设置缓存状态");
//define("ADLAN_77", "You have had a news item submitted - please click here to check.");
define("ADLAN_78", "自定义字段");
define("ADLAN_79", "修改自定义字段");


//define("ADLAN_86", "Incorrect password ");
//define("ADLAN_87", "Administrator name not found in database ");
//define("ADLAN_88", "Unable to login ");
define("ADLAN_89", "管理员姓名");
define("ADLAN_90", "管理员密码");
define("ADLAN_91", "登录");
define("ADLAN_92", "请登录后访问管理页面 ...");
define("ADLAN_93", "显示管理功能");
//define("ADLAN_94", "Show Installed Plugins");
define("ADLAN_95", "插件管理");
//define("ADLAN_96", "None");
//define("ADLAN_97", "Click here for FAQ");
define("ADLAN_98", "插件管理");
define("ADLAN_99", "安装/升级插件");
//define("ADLAN_100", "Theme Layout");
//define("ADLAN_101", "Template Creator");
define("ADLAN_102", "您已超过30天没有修改主管理员密码 - ");
define("ADLAN_103", "点击这里马上修改");
define("ADLAN_104", "安全");

define("ADLAN_105", "图片");
define("ADLAN_106", "图片设置");

//define("ADLAN_107", "Unchecked submitted news items");
//define("ADLAN_108", "Unchecked file uploads");
//define("ADLAN_109", "Information");
define("ADLAN_110", "注册会员");
define("ADLAN_111", "未验证会员");
define("ADLAN_112", "屏蔽用户");
define("ADLAN_113", "帖子数量");
define("ADLAN_114", "评论数量");
define("ADLAN_115", "聊天发言次数");
define("ADLAN_116", "管理日志 ...");
define("ADLAN_117", "显示所有日志");
define("ADLAN_118", "清空日志");

define("ADLAN_119", "不选择提交的链接");

define("ADLAN_120", "有新的数据库更新，请点击按钮安装 ...");
define("ADLAN_121", "安装");


//define("ADLAN_123", "Unchecked submitted articles");
//define("ADLAN_124", "Unchecked submitted reviews");

//define("ADLAN_125", "Unchecked reported forum posts");

//define("ADLAN_126", "Main Options");
//define("ADLAN_127", "Users");
//define("ADLAN_128", "Content");
//define("ADLAN_129", "Communication");
//define("ADLAN_130", "Files Management");
//define("ADLAN_131", "Other tools");

define("ADLAN_132", "语言");
define("ADLAN_133", "默认");

define("ADLAN_134", "状态");
define("ADLAN_135", "管理日志");

define("ADLAN_136", "邮件");
define("ADLAN_137", "电子邮件设置及发送");

define("ADLAN_138", "链接");
define("ADLAN_139", "添加/修改/删除链接");

define("ADLAN_140", "布景管理");
define("ADLAN_141", "安装/设置布景");

define("ADLAN_142", "搜索");
define("ADLAN_143", "搜索设置");
define("ADLAN_144", "您处于简单模式，要转到高级模式");
define("ADLAN_145", "点击这里");

define("ADLAN_146", "登录失败");
define("ADLAN_147", "文件检查");
define("ADLAN_148", "扫描网站文件");

define("ADLAN_149", "邮件通知");
define("ADLAN_150", "管理员邮件通知");

define("ADLAN_151", "首页");
define("ADLAN_152", "输入代码");

define("ADLAN_153", "管理区");
define('ADLAN_154', "无法连接 e107.org 检查新版本");

define('ADLAN_CL_1', '设置');
define('ADLAN_CL_2', '用户');
define('ADLAN_CL_3', '内容');
define('ADLAN_CL_4', '评论');
define('ADLAN_CL_5', '文件');
define('ADLAN_CL_6', '工具');
define('ADLAN_CL_7', '插件');
define('ADLAN_CL_8', '文档');

define("ADLAN_LAT_1", "最新");

define("ADLAN_LAT_2", "提交的新闻");
//define("ADLAN_LAT_3", "Submitted articles");
//define("ADLAN_LAT_4", "Submitted reviews");
define("ADLAN_LAT_5", "提交的链接");
define("ADLAN_LAT_6", "报告的帖子");
define("ADLAN_LAT_7", "上传的文件");
define("ADLAN_LAT_8", "有管理员消息");
define("ADLAN_LAT_9", "待审评论");

//LAN_WARNING define("ADLAN_ERR_1", "Warning!");
define("ADLAN_ERR_2", "您的服务器上有不安全的文件。请<b>立刻</b>删除。这些文件用于旧的e107版本。请删除以下目录及其中的内容:");
define("ADLAN_ERR_3", "您的公共上传目录中有些文件类型不在允许列表，出于安全考虑请<b>立刻</b>删除。<b>不要</b>打开这些文件，这些文件有可能有恶意代码或病毒，不要在浏览器中打开。<br /><br />如果您知道这些文件，那有可能是您最近修改过允许上传的文件类型列表。可以重新添加允许的文件类型(见 管理 => 上传)。不要允许上传.html，.txt, 等，因为黑客可能利用这个功能上传恶意代码。当然也不要允许上传.php文件或其它可执行脚本文件。<br /><br />下面是有潜在风险的文件类型列表。:");
define("ADLAN_ERR_4", "Deprecated plugin file(s) found");
define("ADLAN_ERR_5", "The following files need to be renamed to");
define("ADLAN_ERR_6", "Then, click here to re-scan your plugin folders.");
define("ADLAN_ERR_7", "Malicious files have been detected on your server. They should be deleted [b]immediately[/b].");
define("ADLAN_ERR_8", "Please run [File inspector] to check for core files that may have been modified.");

// Common Terms
define("LAN_EDIT","修改");
define("LAN_DELETE","删除");
define("LAN_CREATE","新增");
define("LAN_UPDATE","更新");
define("LAN_SAVE","保存");
define("LAN_SAVED","已保存");
define("LAN_SETSAVED","您的设置已保存");
define("LAN_CONFIRMDEL","请确认要删除");
define("LAN_OPTIONS","选项");
define("LAN_PREFS","参数");
define("LAN_DELETED","删除成功");
define("LAN_UPDATED","更新成功");
define("LAN_CREATED","创建成功");
define("LAN_CREATED_FAILED","创建不成功");
define("LAN_DELETED_FAILED","删除不成功");
define("LAN_UPDATED_FAILED","更新不成功");
define("LAN_NO_CHANGE","没有修改，更新不成功。");
define("LAN_TRY_AGAIN","请重试。");

define("LAN_RESET","重置");
define("LAN_CLEAR","清除");
define("LAN_OK","OK");

define("LAN_PRESET","预置");
define("LAN_PRESET_SAVED","成功保存预置值");

define("LAN_PRESET_DELETED","成功删除预置值。");
define("LAN_PRESET_CONFIRMDEL","您确认要删除这个预置值吗?");
define("LAN_NOTWRITABLE","不可写，目录要CHMOD 777。");
define("LAN_DATE","日期");
define("LAN_TIME","时间");
define("LAN_YES","是");
define("LAN_NO","否");
define("LAN_EMPTY","数据库中还没有内容");
define("LAN_EXISTING","现有内容");

define("LAN_CANCEL","取消");
define("LAN_CONFDELETE","确认删除");
define("LAN_PLUGIN","插件");
define("LAN_ORDER","排序");

define("LAN_SELECT","选择 ...");
define("LAN_ADMIN","管理");
define("LAN_DISPLAYOPT", "修改显示选项");
define("LAN_GOPAGE", "转到页面:");
define("LAN_DATESTAMP","日期");
define("LAN_OPTIONAL", "选项");
define("LAN_INACTIVE","未使用");

define("LAN_BAN","屏蔽");
define("LAN_RATING", "评价");

define("LAN_UPLOAD", "上传");
define("LAN_UPLOAD_IMAGES","上传图像");
define("LAN_UPLOAD_FILES","上传文件");
define("LAN_UPLOAD_ADDFILE","添加另一个文件");
define("LAN_UPLOAD_CONFIRM","Any unsaved changes to this page will be lost. Continue?");
define("LAN_UPLOAD_777","Folder is missing or not writable, you need to CHMOD 777 the following folder before uploading:");
define("LAN_UPLOAD_SERVEROFF", "This option is disabled as file uploading is not enabled on your server");

define("LAN_DISABLED","关闭");
define("LAN_ENABLED", "打开");

define("LAN_PRESET_CONFIRMSAVE","Save current form values as the default for this page?");
define("LAN_CONFIGURE", "设置");

define("LAN_BACK","返回");

define("LAN_CREDITS","鸣谢");
define("LAN_NEWVERSION","有新版本");
define("LAN_NEWVERSION_MORE","更多");
define("LAN_NEWVERSION_DLD","从SF.net下载%s");
define('LAN_NEWVERSION_CHECK_ERROR', '版本检测错误');

define("LAN_SECURITYL_0", "检查问题 (无)");
define("LAN_SECURITYL_5", "适中");
define("LAN_SECURITYL_8", "高");
define("LAN_SECURITYL_10", "极高");

define("LAN_PLEASEWAIT","请等待");
?>