<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_emoticon.php $
|     $Revision: 11678 $
|     $Id: lan_emoticon.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "允许使用表情");
define("EMOLAN_2", "名称");
define("EMOLAN_3", "表情");
define("EMOLAN_4", "激活表情?");

define("EMOLAN_5", "图像");
define("EMOLAN_6", "代码");
define("EMOLAN_7", "用空格分开");

define("EMOLAN_8", "状态");
define("EMOLAN_9", "选项");
define("EMOLAN_10", "激活");
define("EMOLAN_11", "激活压缩包'");

define("EMOLAN_12", "修改/设置压缩包");
define("EMOLAN_13", "安装压缩包");

define("EMOLAN_14", "保存设置");
define("EMOLAN_15", "修改/设置表情");
define("EMOLAN_16", "表情设置已保存");
define("EMOLAN_17", "You have an emoticon pack present that contains spaces in the name, which are not allowed !");
define("EMOLAN_18", "please rename the instances listed below so they no longer contain spaces:");
define("EMOLAN_19", "名称");
define("EMOLAN_20", "位置");
define("EMOLAN_21", "错误");
//define("EMOLAN_2", "Name");
define("EMOLAN_22", "New emote pak found:");
define("EMOLAN_23", "New emote xml pak found:");
define("EMOLAN_24", "New emote php found:");
define("EMOLAN_25", "Installing new PHP emotes: ");
define("EMOLAN_26", "Re-scan pack");
define("EMOLAN_27", "Error occurred processing pack: ");
define("EMOLAN_28", "Generate XML");
define("EMOLAN_29", "XML file generated: ");
define("EMOLAN_30", "Error writing XML file: ");
?>