<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_lancheck.php $
|     $Revision: 11756 $
|     $Id: lan_lancheck.php 11756 2010-09-06 23:31:47Z e107coders $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "检查/修改语言文件"); // modified in 0.7.6
define("LAN_CHECK_2", "开始检查");
define("LAN_CHECK_3", "检查");
define("LAN_CHECK_4", "缺少文件!");
define("LAN_CHECK_5", "缺少语句!");

define("LAN_CHECK_7", "语句");

define("LAN_CHECK_8", "缺少一个文件...");
define("LAN_CHECK_9", "个文件缺少...");
define("LAN_CHECK_10", "严重错误: ");
define("LAN_CHECK_11", "没有缺少文件!");
define("LAN_CHECK_12", "一个文件错误...");
define("LAN_CHECK_13", "个文件错误...");
define("LAN_CHECK_14", "所有文件都正确!");

define("LAN_CHECK_15", "'&lt;?php' 之前或者 '?&gt;' 之后有无效的字符或空格");
define("LAN_CHECK_16", "原始文件");
define("LAN_CHECK_17", "保存文件时出错。");
define("LAN_CHECK_18", "Language files in the standard format are NOT available for this plugin/theme.");
define("LAN_CHECK_19", "非 UTF-8 字符集!");
define("LAN_CHECK_20", "生成语言包");
define("LAN_CHECK_21", "重新检查");
define("LAN_CHECK_22", "布景");
define("LAN_CHECK_23", "发现错误");
define("LAN_CHECK_24", "总结");
define("LAN_CHECK_25", "布景");
define("LAN_CHECK_26", "文件");

?>