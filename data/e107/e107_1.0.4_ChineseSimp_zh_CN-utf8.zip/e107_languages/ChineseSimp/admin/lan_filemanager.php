<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_filemanager.php $
|     $Revision: 11790 $
|     $Id: lan_filemanager.php 11790 2010-09-16 20:02:09Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "上传");
define("FMLAN_2", "到");
define("FMLAN_3", "目录");
define("FMLAN_4", "上传的文件超过php.ini中upload_max_filesize的设置");
// define("FMLAN_5", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
// define("FMLAN_6", "The uploaded file was only partially uploaded.");
// define("FMLAN_7", "No file was uploaded.");
// define("FMLAN_8", "Uploaded file size 0 bytes");
// define("FMLAN_9", "The file did not upload. Filename");
define('FMLAN_10', '错误');
// define("FMLAN_11", "Probably incorrect permissions on upload directory.");
define("FMLAN_12", "个文件");
define("FMLAN_13", "个文件");
define("FMLAN_14", "个目录");
define("FMLAN_15", "个目录");
define("FMLAN_16", "根目录");
define("FMLAN_17", "名称");
define("FMLAN_18", "大小");
define("FMLAN_19", "最后修改");

define("FMLAN_21", "上传文件到该目录");
define("FMLAN_22", "上传");

define("FMLAN_26", "删除");
define("FMLAN_27", "成功");
define("FMLAN_28", "无法删除");
define("FMLAN_29", "路径");
define("FMLAN_30", "上一级");
define("FMLAN_31", "目录");

define("FMLAN_32", "选择目录");
define("FMLAN_33", "选择");
define("FMLAN_34", "目录选择");
define("FMLAN_35", "系统文件目录");

define("FMLAN_36", "自定义菜单目录");
define("FMLAN_37", "自定义页面目录");

define("FMLAN_38", "成功移动文件到");
define("FMLAN_39", "无法移动文件到");
define("FMLAN_40", "新闻图像目录");


define("FMLAN_43", "删除选择的文件");


define("FMLAN_46", "请确认您要删除选择的文件。");
define("FMLAN_47", "用户上传目录");

define("FMLAN_48", "移动选择的文件到");
define("FMLAN_49", "请确认您要移动选择的文件。");
define("FMLAN_50", "移动");
define('FMLAN_51', '未知错误: ');




?>