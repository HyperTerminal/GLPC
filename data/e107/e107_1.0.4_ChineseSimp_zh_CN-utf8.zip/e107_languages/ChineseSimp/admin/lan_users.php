<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_users.php $
|     $Revision: 11897 $
|     $Id: lan_users.php 11897 2010-10-16 20:13:13Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("USRLAN_1", "选项已保存。");
define("USRLAN_3", "现为管理员 - 要设置权限请转到");
define("USRLAN_4", "管理员页面");
define("USRLAN_5", "您不能删除主管理员");
define("USRLAN_6", "已经不是管理员了。");
define("USRLAN_7", "您不能屏蔽主管理员");
define("USRLAN_8", "用户被屏蔽。");
define("USRLAN_9", "用户解除屏蔽。");
define("USRLAN_10", "用户已删除。");
define("USRLAN_11", "删除取消。");
define("USRLAN_12", "您不能删除主管理员。");
define("USRLAN_13", "请确认您要删除该会员");
// define("USRLAN_14", "once deleted the record cannot be retrieved");
// define("USRLAN_15", "Cancel");
define("USRLAN_16", "确认删除");
define("USRLAN_17", "确认删除用户");
// define("USRLAN_18", "User activated.");
// define("USRLAN_19", "Search");
// define("USRLAN_20", "Order by");
// define("USRLAN_21", "User ID");
// define("USRLAN_22", "User name");
// define("USRLAN_23", "Visits to site");
// define("USRLAN_24", "Admin status");
// define("USRLAN_25", "Status");
// define("USRLAN_26", "Descending");
// define("USRLAN_27", "Ascending");
// define("USRLAN_28", "Sort");

define("USRLAN_30", "屏蔽");
// define("USRLAN_31", "Ban -inactivated-");
define("USRLAN_32", "激活");
define("USRLAN_33", "解除屏蔽");
define("USRLAN_34", "解除管理员状态");
define("USRLAN_35", "设为管理员");
define("USRLAN_36", "设置组群");

// define("USRLAN_37", "Members");
// define("USRLAN_38", "Search returned");
// define("USRLAN_39", "result(s)");
// define("USRLAN_40", "None defined");

define("USRLAN_44", "允许会员上传头像?");

define("USRLAN_47", "Maximum avatar width (in pixels)");
define("USRLAN_48", "default is 120");
define("USRLAN_49", "Maximum avatar height (in pixels)");
define("USRLAN_50", "default is 100");
define("USRLAN_51", "Update Options");
define("USRLAN_52", "Member Options");
define("USRLAN_53", "Allow members to upload a photograph?");
define("USRLAN_54", "Click here to delete all inactivated users");
define("USRLAN_55", "Prune");
define("USRLAN_56", "Deleted");
define("USRLAN_57", "Deleting un-activated members ...");
define("USRLAN_58", "file uploads are disabled in php.ini");
define("USRLAN_59", "Quick add user");
define("USRLAN_60", "Add user");
define("USRLAN_61", "Display name");
define("USRLAN_62", "Password");
define("USRLAN_63", "Re-type Password");
define("USRLAN_64", "Email Address");
define("USRLAN_65", "That display name cannot be accepted as valid, please choose a different display name");
define("USRLAN_66", "That display name already exists in the database, please choose a different display name");
define("USRLAN_67", "The two passwords do not match");
define("USRLAN_68", "You left required field(s) blank");
define("USRLAN_69", "That doesn't appear to be a valid email address");
define("USRLAN_70", "User created");
define("USRLAN_71", "Users Front Page");
define("USRLAN_72", "Quick Add User");
define("USRLAN_73", "删除用户");
define("USRLAN_75", "数据库中已有该登录名，请重新选择一个名字");
define("USRLAN_76", "用户选项");
define("USRLAN_77", "现有用户");
define("USRLAN_78", "用户名");
define("USRLAN_79", "状态");
define("USRLAN_80", "信息");

// define("USRLAN_82", "Are you sure you want to delete this user?");
define("USRLAN_84", "共有");
define("USRLAN_85", "用户未激活 - 点击下面删除。");
define("USRLAN_86", "用户已验证");
define("USRLAN_87", "用户设置已更新");
define("USRLAN_88", "用户组群已更新");

define("USRLAN_90", "搜索/刷新");
define("USRLAN_91", "组群");
define("USRLAN_92", "用户名中有无效字符");

define("USRLAN_93", "删除未验证的用户");
define("USRLAN_94", "删除注册后在该时间段内未验证的用户 - 留空不使用该选项<br />如果是管理员添加的用户，该选项无效");
define("USRLAN_95", "分钟");


define("USRLAN_112", "重发电子邮件");
define("USRLAN_113", "注册信息关于");
define("USRLAN_114", "尊敬的");
define("USRLAN_115", "谢谢您注册成为会员。");
define("USRLAN_116", "请确认您要重发确认邮件到:");
define("USRLAN_117", "点击下面的按钮测试以下邮件:");
define("USRLAN_118", "测试邮件");

define("USRLAN_120", "设置组群");
define("USRLAN_121", "邮件列表");
define("USRLAN_122", "欢迎");
define("USRLAN_123", "您的注册信息已收到并已创建。");
define("USRLAN_124", "您的帐号处于未激活状态，要激活帐号，请转到下面的链接");
define("USRLAN_125", "来自");

define("USRLAN_126", "允许评价用户");
define("USRLAN_127", "允许评价用户档案");

define("USRLAN_128", "用户名");

define("USRLAN_130", "打开在线用户统计");
define("USRLAN_131", "使用在线用户统计必须打开该选项，例如online.php、论坛在线信息和在线菜单");
define("USRLAN_132", "打开");

define("USRLAN_133", "强制用户更新设置");
define("USRLAN_134", "打开该选项后，如果用户某个必填项未输入，将自动转到修改资料页面。");

define("USRLAN_135", "没有找到IP地址，IP未被屏蔽");
define("USRLAN_136", "多个用户有相同的IP地址{IP}，该IP没有被屏蔽。");
define("USRLAN_137", "用户IP地址{IP}被屏蔽。");


define("USRLAN_138", "未验证用户");
define("USRLAN_139", "Your account has been activated.\n\nYou can visit {SITEURL} and log into the site using the login information you provided.");

define("USRLAN_140", "Email Re-sent to");
define("USRLAN_141", "Failed to Re-send email to");
define("USRLAN_142", "with the following activation link");

define("USRLAN_143", "Check For Bounces");
define("USRLAN_144", "Resend Confirmation Email to All");
define("USRLAN_145", "退回的用户");
define("USRLAN_146", "Member information is available to");

define("USRLAN_147", "邮件地址在被屏蔽用户中");
define("USRLAN_148", "邮件地址被屏蔽");

define("USRLAN_149", "Delete checked emails");
define("USRLAN_150", "删除所有邮件");
define("USRLAN_151", "Clear bounce, require Activation");
define("USRLAN_152", "Clear bounce and Activate");
define("USRLAN_153", "Delete non-bounce emails");
define("USRLAN_154", "Clear email for checked");
define("USRLAN_155", "Total {TOTAL} emails found. {DELCOUNT} deleted through options.<br />{DELUSER} users marked as 'bounced' (out of {FOUND} emails)");
define("USRLAN_156", "Email address is already in use");
define('USRLAN_157', 'Invalid characters in login name');

define("LAN_MAINADMIN","主管理员");
//define("LAN_ADMIN","管理员");
define("LAN_NOTVERIFIED","未验证");
define("LAN_BANNED","被屏蔽");
define("LAN_BOUNCED","退回");

define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "显示名");
define("DUSRLAN_3", "用户名");
define("DUSRLAN_4", "自定义称呼");
define("DUSRLAN_5", "密码");
define("DUSRLAN_6", "Session");
define("DUSRLAN_7", "电子邮件");
define("DUSRLAN_8", "网站");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "位置");
define("DUSRLAN_13", "生日");
define("DUSRLAN_14", "签名");
define("DUSRLAN_15", "图像");
define("DUSRLAN_16", "时区");
define("DUSRLAN_17", "隐藏电子邮件");
define("DUSRLAN_18", "加入日期");
define("DUSRLAN_19", "最好访问");
define("DUSRLAN_20", "当前访问");
define("DUSRLAN_21", "最好发贴");
define("DUSRLAN_22", "聊天发言次数");
define("DUSRLAN_23", "评论");
define("DUSRLAN_24", "论坛帖子");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "屏蔽");
define("DUSRLAN_27", "参数");
define("DUSRLAN_28", "新");
define("DUSRLAN_29", "查看");
define("DUSRLAN_30", "访问");
define("DUSRLAN_31", "管理员");
define("DUSRLAN_32", "真实姓名");
define("DUSRLAN_33", "用户组群");
define("DUSRLAN_34", "权限");
define("DUSRLAN_35", "照片");
define("DUSRLAN_36", "修改密码");
define("DUSRLAN_37", "XUP");

define('USRLAN_190', '新用户等待期 (天)');
define('USRLAN_191', '(在这段时间内某些功能受限)');

define('USRLAN_194', '可修改签名时间');
define('USRLAN_219', '超过30天');     

?>