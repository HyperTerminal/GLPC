<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_footer.php $
|     $Revision: 12060 $
|     $Id: lan_footer.php 12060 2011-01-30 19:22:47Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "网站名称");
define("FOOTLAN_2", "管理员");
define("FOOTLAN_3", "版本");
define("FOOTLAN_4", "补丁");
define("FOOTLAN_5", "后台布景");
define("FOOTLAN_6", "制作");
define("FOOTLAN_7", "信息");
define("FOOTLAN_8", "安装日期");
define("FOOTLAN_9", "服务器");
define("FOOTLAN_10", "主机");
define("FOOTLAN_11", "PHP版本");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "网站信息");
define("FOOTLAN_14", "显示文档");
define("FOOTLAN_15", "文档资料");
define("FOOTLAN_16", "数据库");
define("FOOTLAN_17", "字符集");
define("FOOTLAN_18", "前台布景");
define("FOOTLAN_19", "当前服务器时间");
define("FOOTLAN_20", "安全级别");
?>