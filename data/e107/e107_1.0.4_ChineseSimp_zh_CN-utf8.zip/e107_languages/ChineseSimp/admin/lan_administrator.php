<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_administrator.php $
|     $Revision: 11678 $
|     $Id: lan_administrator.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "已创建新用户/管理员");
define("ADMSLAN_1", "成为管理员。");
define("ADMSLAN_2", "已在数据库中更新。");
define("ADMSLAN_3", "是主站管理员，不能修改。");
define("ADMSLAN_4", "继续");
define("ADMSLAN_5", "错误!");
define("ADMSLAN_6", "是主站管理员，不能删除。");

define("ADMSLAN_13", "现有管理员");


define("ADMSLAN_16", "管理员名字");
define("ADMSLAN_17", "管理员密码");
define("ADMSLAN_18", "权限");
define("ADMSLAN_19", "修改网站参数");
define("ADMSLAN_20", "修改菜单");
define("ADMSLAN_21", "修改管理员权限");
define("ADMSLAN_22", "Moderate users/bans etc");
define("ADMSLAN_23", "创建/修改定制页面/菜单");
define("ADMSLAN_24", "管理下载分类");
define("ADMSLAN_25", "更新 /管理文件");
define("ADMSLAN_26", "Oversee news categories");
define("ADMSLAN_27", "Oversee link categories");
define("ADMSLAN_28", "Take site down for maintenance");
define("ADMSLAN_29", "管理广告");
define("ADMSLAN_30", "设置新闻feed标题");
define("ADMSLAN_31", "设置表情");
define("ADMSLAN_32", "设置首页内容");
define("ADMSLAN_33", "设置日志/统计");
define("ADMSLAN_34", "设置meta标签");
define("ADMSLAN_35", "设置公共文件上传");
define("ADMSLAN_36", "设置图像参数");
define("ADMSLAN_37", "审核评论");
// define("ADMSLAN_38", "Moderate/configure chatbox");
define("ADMSLAN_39", "发布新闻");
define("ADMSLAN_40", "发布链接");
//obsolete 	define("ADMSLAN_41", "Post articles");
//obsolete 	define("ADMSLAN_42", "Post reviews");
//obsolete - use in v0.8: Configure URLs	 define("ADMSLAN_43", "Post content pages");
define("ADMSLAN_44", "发布下载");
define("ADMSLAN_45", "发布投票");
define("ADMSLAN_46", "欢迎信息");
define("ADMSLAN_47", "审核提交的新闻");

define("ADMSLAN_49", "全部选中");
define("ADMSLAN_51", "全部取消");
define("ADMSLAN_52", "更新管理员");
define("ADMSLAN_53", "添加管理员");
define("ADMSLAN_54", "网站管理员");

define("ADMSLAN_55", "字段为空");

define("ADMSLAN_56", "网站管理员");

define("ADMSLAN_58", "主站管理员");
define("ADMSLAN_59", "Remove Admin Status");
define("ADMSLAN_60", "您确定要删除管理员");
define("ADMSLAN_61", "管理员已删除");

define("ADMSLAN_62", "插件管理");

define("ADMSLAN_64", "清空系统缓存");
define("ADMSLAN_65", "设置邮件参数");
define("ADMSLAN_66", "设置搜索");
define("ADMSLAN_67", "文件检查和扫描");
define("ADMSLAN_68", "设置邮件通知");
define("ADMSLAN_69", "已经是管理员，需要修改。");

define("ADMSLAN_70", "返回管理员列表");
define("ADMSLAN_71", "点这里显示权限");  

//v1.0.2 and v2
define("ADMSLAN_76", "管理语言包");

?>