<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_cache.php $
|     $Revision: 11678 $
|     $Id: lan_cache.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "缓存系统状态");
define("CACLAN_2", "设置缓存状态");
define("CACLAN_3", "缓存系统");
define("CACLAN_4", "缓存状态设置");
define("CACLAN_5", "清空缓存");
define("CACLAN_6", "缓存已清空");

define("CACLAN_7", "关闭缓存");
// define("CACLAN_8", "Cache data saved to MySQL");
define("CACLAN_9", "保存缓存数据到文件");
define("CACLAN_10", "缓存目录不可写，请确保目录设置为CHMOD 0777");
?>