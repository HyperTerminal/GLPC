<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_db.php $
|     $Revision: 11678 $
|     $Id: lan_db.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "系统设置备份到数据库中。");
define("DBLAN_2", "点击按钮保存您的e107数据库备份");
define("DBLAN_3", "备份SQL数据库");
define("DBLAN_4", "点击按钮检查您的e107数据库");
define("DBLAN_5", "检查数据库完整性");
define("DBLAN_6", "点击按钮优化您的e107数据库");
define("DBLAN_7", "优化SQL数据库");
define("DBLAN_8", "点击按钮备份您的系统设置");
define("DBLAN_9", "备份系统");
define("DBLAN_10", "数据库工具");
define("DBLAN_11", "MySQL数据库");
define("DBLAN_12", "已优化");
define("DBLAN_13", "返回");
define("DBLAN_14", "完成");
define("DBLAN_15", "点击按钮检测是否有数据库更新");
define("DBLAN_16", "检测更新");
define("DBLAN_17", "前缀名称");
define("DBLAN_18", "前缀内容");
define("DBLAN_19", "点击按钮打开参数编辑器 (适合高级用户使用)");
define("DBLAN_20", "参数编辑器");
define("DBLAN_21", "删除已检查");
define("DBLAN_22", "插件: 查看并扫描");
define("DBLAN_23", "扫描完成");
define("DBLAN_24", "名称");
define("DBLAN_25", "目录");
define("DBLAN_26", "包括插件");
define("DBLAN_27", "已安装");
define("DBLAN_28", "点击按钮扫描插件目录");
define("DBLAN_29", "扫描插件目录");
define("DBLAN_30", " (如果显示插件错误，检查PHP开始/结束标签外的字符)");
define("DBLAN_31", "通过");
define("DBLAN_32", "错误");
define("DBLAN_33", "无法存取");
define("DBLAN_34", "未检查");
define('DBLAN_35', '点击按钮检查用户表');
define('DBLAN_36', '检查用户表');


?>