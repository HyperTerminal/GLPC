<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_check_user.php $
|     $Revision: 11678 $
|     $Id: lan_check_user.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define('LAN_CKUSER_01','检查用户数据库');
define('LAN_CKUSER_02','检查用户数据库中各种潜在的问题');
define('LAN_CKUSER_03','如果有很多用户，可能会需要比较长的时间，也可能超时');
define('LAN_CKUSER_04','继续');
define('LAN_CKUSER_05','检查相同的登录名');
define('LAN_CKUSER_06','选择要执行的操作');
define('LAN_CKUSER_07','用户名重复');
define('LAN_CKUSER_08','没有重复');
define('LAN_CKUSER_09','用户名');
define('LAN_CKUSER_10','用户 ID');
define('LAN_CKUSER_11','显示名');
define('LAN_CKUSER_12','检查相同的电子邮件');
define('LAN_CKUSER_13','电子邮件重复');
define('LAN_CKUSER_14','电子邮件');
define('LAN_CKUSER_15','没有重复');
define('LAN_CKUSER_16','检查用户名和其他人的登录名相同的情况');
define('LAN_CKUSER_17','用户名和登录名冲突');
define('LAN_CKUSER_18','用户 A');
define('LAN_CKUSER_19','用户 B');
define('LAN_CKUSER_20','');

?>