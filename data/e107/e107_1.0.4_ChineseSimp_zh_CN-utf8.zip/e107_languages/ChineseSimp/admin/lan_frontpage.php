<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_frontpage.php $
|     $Revision: 11678 $
|     $Id: lan_frontpage.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "首页设置已更新。");
define("FRTLAN_2", "首页设置适用");
define("FRTLAN_6", "链接");
// define("FRTLAN_7", "Content Page");
define("FRTLAN_12", "更新首页设置");
define("FRTLAN_13", "首页设置");
define("FRTLAN_15", "其它(输入url):");
define("FRTLAN_16", "错误: 没有选择内容主栏目");
define("FRTLAN_17", "错误: 没有选择内容子分类");
define("FRTLAN_18", "错误: 没有选择内容项目");
define("FRTLAN_19", "内容主栏目");
define("FRTLAN_20", "内容分类");
define("FRTLAN_21", "内容项目");
define("FRTLAN_22", "自定义页面");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "所有用户");
define("FRTLAN_27", "访客");
define("FRTLAN_28", "会员");
define("FRTLAN_29", "管理员");
define("FRTLAN_31", "所有用户");
define("FRTLAN_32", "用户组群");
define("FRTLAN_33", "当前设置");
define("FRTLAN_34", "页面");

?>