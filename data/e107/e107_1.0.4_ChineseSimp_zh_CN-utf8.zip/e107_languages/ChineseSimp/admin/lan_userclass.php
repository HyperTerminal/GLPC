<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/admin/lan_userclass.php $
|     $Revision: 11678 $
|     $Id: lan_userclass.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "发送通知邮件到");
define("UCSLAN_2", "权限更新通知");
define("UCSLAN_3", "尊敬的");
define("UCSLAN_4", "您的权限已更新 － ");
define("UCSLAN_5", "您现在拥有以下权限");
define("UCSLAN_6", "设置用户组群");
define("UCSLAN_7", "设置组群");
define("UCSLAN_8", "通知用户");
define("UCSLAN_9", "组群已更新。");
define("UCSLAN_10", "谢谢！");
define('UCSLAN_12', '仅限会员');

?>