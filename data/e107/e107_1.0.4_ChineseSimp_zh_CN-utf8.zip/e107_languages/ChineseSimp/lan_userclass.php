<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_userclass.php $
|     $Revision: 11678 $
|     $Id: lan_userclass.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "所有人");
define("UC_LAN_1", "访客");
define("UC_LAN_2", "无");
define("UC_LAN_3", "会员");
define("UC_LAN_4", "只读");
define("UC_LAN_5", "管理员");
define("UC_LAN_6", "主管理员");

define('UC_LAN_9','新用户');
define('UC_LAN_10', '搜索引擎');

?>