<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/ChineseSimp/lan_online.php $
|     $Revision: 11678 $
|     $Id: lan_online.php 11678 2010-08-22 00:43:45Z Jack $
|     $Author: Jack $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "访客人数: ");
define("ONLINE_EL2", "会员人数: ");
define("ONLINE_EL3", "在页面: ");
define("ONLINE_EL4", "在线用户");
define("ONLINE_EL5", "会员总数");
define("ONLINE_EL6", "最新会员");
define("ONLINE_EL7", "查看");
define("ONLINE_EL8", "最多在线人数: ");
define("ONLINE_EL9", "出现在");
define("ONLINE_EL10", "会员名字");
define("ONLINE_EL11", "正在访问页面");
define("ONLINE_EL12", "回复");
define("ONLINE_EL13", "论坛");
define("ONLINE_EL14", "主题");
define("ONLINE_EL15", "页面");
define("CLASSRESTRICTED", "会员页面");
define("ARTICLEPAGE", "文章/评论");
define("CHAT", "交谈");
define("COMMENT", "评论");
define("DOWNLOAD", "下载");
define("EMAIL", "email.php");
define("FORUM", "主论坛索引");
define("LINKS", "链接");
define("NEWS", "新闻");
define("OLDPOLLS", "旧的投票");
define("POLLCOMMENT", "投票");
define("PRINTPAGE", "打印");
define("LOGIN", "登录");
define("SEARCH", "搜索");
define("STATS", "网站统计");
define("SUBMITNEWS", "提交新闻");
define("UPLOAD", "上传");
define("USERPAGE", "用户个人档案");
define("USERSETTINGS", "用户设置");
define("ONLINE", "在线用户");
define("LISTNEW", "列出新闻");
define("USERPOSTS", "用户帖子");
define("SUBCONTENT", "提交文章/评论");
define("TOP", "发贴最多/最活跃主题");
define("ADMINAREA", "管理界面");
define("BUGTRACKER", "错误跟踪");
define("EVENT", "事件列表");
define("CALENDAR", "事件日历");
define("FAQ", "常见问答");
define("PM", "短消息");
define("SURVEY", "调查");
define("ARTICLE", "文章");
define("CONTENT", "内容页面");
define("REVIEW", "评论");

?>