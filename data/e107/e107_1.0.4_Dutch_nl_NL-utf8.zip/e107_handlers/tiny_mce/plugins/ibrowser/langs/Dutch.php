<?

$lang_ibrowser_title = 'Invoegen / bewerken afbeelding';
$lang_ibrowser_desc = 'Invoegen / bewerken afbeelding';
$lang_ibrowser_library = 'Bibliotheek';
$lang_ibrowser_preview = 'Voorvertoning';
$lang_ibrowser_img_sel = 'Selectie afbeelding';
$lang_ibrowser_img_info = 'Info afbeelding';
$lang_ibrowser_img_upload = 'Upload afbeelding';
$lang_ibrowser_images = 'Afbeeldingen';
$lang_ibrowser_src = 'Bron';
$lang_ibrowser_alt = 'Beschrijving';
$lang_ibrowser_size = 'Omvang';
$lang_ibrowser_align = 'Tekst flow';
$lang_ibrowser_height = 'Hoogte';
$lang_ibrowser_width = 'Breedte';
$lang_ibrowser_reset = 'Reset afmetingen';
$lang_ibrowser_border = 'Kader';
$lang_ibrowser_hspace = 'HSpace';
$lang_ibrowser_vspace = 'VSpace';
$lang_ibrowser_select = 'Opslaan';
$lang_ibrowser_delete = 'Verwijderen';
$lang_ibrowser_cancel = 'Annuleren';
$lang_ibrowser_uploadtxt = 'Bestand';
$lang_ibrowser_uploadbt = 'Upload';
// new
$lang_ibrowser_marginl = 'Linkermarge';
$lang_ibrowser_marginr = 'Rechtermarge';
$lang_ibrowser_margint = 'Bovenmarge';
$lang_ibrowser_marginb = 'Ondermarge';
$lang_insert_image_align_default = 'Standaard';
$lang_insert_image_align_left = 'Links';
$lang_insert_image_align_right = 'Rechts';

// error messages
$lang_ibrowser_error = 'Fout';
$lang_ibrowser_errornoimg = 'Selecteer een afbeelding';
$lang_ibrowser_errornodir = 'Bibliotheek bestaat niet fysiek';
$lang_ibrowser_errorupload = 'Er trad een fout op bij deze bestandsupload.\nprobeer het later nogmaals';
$lang_ibrowser_errortype = 'Onjuist afbeeldingsformaat';
$lang_ibrowser_errordelete = 'Verwijderen mislukt';
$lang_ibrowser_confirmdelete = 'Klik OK om afbeelding te verwijderen!';
$lang_ibrowser_error_width_nan = 'Breedte is geen getal!';
$lang_ibrowser_error_height_nan = 'Hoogte is geen getal!';
$lang_ibrowser_error_border_nan = 'Kader is geen getal!';
$lang_ibrowser_error_hspace_nan = 'Horizontale scheiding is geen getal!';
$lang_ibrowser_error_vspace_nan = 'Vertikale scheiding is geen getal!';