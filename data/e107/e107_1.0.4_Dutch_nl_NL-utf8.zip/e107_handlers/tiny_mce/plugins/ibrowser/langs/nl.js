/* */
tinyMCE.addI18n('nl.ibrowser',{
	desc : 'Afbeelding Browser'
});