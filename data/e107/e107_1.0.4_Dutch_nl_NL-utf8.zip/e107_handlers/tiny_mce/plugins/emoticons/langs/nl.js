// $Id: nl.js 386 2009-07-07 16:51:03Z erje $
tinyMCE.addI18n('nl.emoticons',{
	desc : 'Emoticon invoegen'
});
