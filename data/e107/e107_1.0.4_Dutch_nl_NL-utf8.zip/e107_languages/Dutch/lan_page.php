<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/lan_page.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LAN_PAGE_1',  'Paginaoverzicht is uitgeschakeld');
define('LAN_PAGE_2',  'Er zijn geen pagina´s');
define('LAN_PAGE_3',  'Opgevraagde pagina bestaat niet');
define('LAN_PAGE_4',  'Beoordeel deze pagina');
define('LAN_PAGE_5',  'Bedankt voor het beoordelen van deze pagina');
define('LAN_PAGE_6',  'Je hebt geen toestemming om deze pagina te bekijken');
define('LAN_PAGE_7',  'Onjuist wachtwoord');
define('LAN_PAGE_8',  'Wachtwoord beveiligde pagina');
define('LAN_PAGE_9',  'Wachtwoord');
define('LAN_PAGE_10', 'Aanmelden');
define('LAN_PAGE_11', 'Paginaoverzicht');
define('LAN_PAGE_12', 'Ongeldige pagina');
define('LAN_PAGE_13', 'Pagina');

?>