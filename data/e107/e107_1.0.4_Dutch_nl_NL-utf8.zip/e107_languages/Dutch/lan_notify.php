<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/lan_notify.php $
 * $Revision: 552 $
 * $Date: 2012-08-17 14:33:53 +0200 (vr, 17 aug 2012) $
 * $Author: erje $
 */

define('NT_LAN_US_1', 'Inlog');

define('NT_LAN_UV_1', 'Aanmelding gebruiker geverifieerd');
define('NT_LAN_UV_2', 'Gebruikers ID:');
define('NT_LAN_UV_3', 'Inlognaam gebruiker: ');
define('NT_LAN_UV_4', 'Ip adres gebruiker: ');

define('NT_LAN_LI_1', 'Gebruiker ingelogd');

define('NT_LAN_LO_1', 'Gebruiker uitgelogd');
define('NT_LAN_LO_2', 'uitgelogd');

define('NT_LAN_FL_1', 'Flood Blokkade');
define('NT_LAN_FL_2', 'IP adres geblokkeerd wegens flooding');

define('NT_LAN_SN_1', 'Nieuwsbericht aangemeld');

define('NT_LAN_NU_1', 'Bijgewerkt');

define('NT_LAN_ND_1', 'Nieuwsbericht verwijderd');
define('NT_LAN_ND_2', 'id van verwijderd nieuwsbericht');

define('NT_LAN_CM_1',  'Gebruikerscommentaar wacht op goedkeuring');1

?>