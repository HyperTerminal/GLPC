<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/lan_upload_handler.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LANUPLOAD_1',  'Het bestandsformaat');
define('LANUPLOAD_2',  'is niet toegestaan en het bestand is verwijderd.');
define('LANUPLOAD_3',  'Succesvol geupload');
define('LANUPLOAD_4',  'Of de bestemmingsmap bestaat niet, of deze map is niet beschrijfbaar, zorg ervoor dat de map de juiste schrijfrechten heeft (CHMOD is systeem afhankelijk, hou het zo laag mogelijk.) Voor meer informatie en de mogelijkheden wat betreft CHMOD verwijzen wij je naar je hostings provider.');
define('LANUPLOAD_5',  'Het geuploade bestand is groter dan de upload_max_filesize parameter in php.ini.');
define('LANUPLOAD_6',  'Het geuploade bestand is groter dan de MAX_FILE_SIZE in het HTML formulier.');
define('LANUPLOAD_7',  'Het bestand is slechts gedeeltelijk geupload.');
define('LANUPLOAD_8',  'Er werd geen bestand geupload.');
define('LANUPLOAD_9',  'Geuploade bestandsgrootte 0 bytes');
define('LANUPLOAD_10', 'Upload mislukt [Duplicate filename] - er bestaat al een bestand met deze naam.');
define('LANUPLOAD_11', 'Het bestand werd niet geupload. Bestandsnaam:');
define('LANUPLOAD_12', 'Fout');
define('LANUPLOAD_13', 'Tijdelijke map ontbreekt');
define('LANUPLOAD_14', 'Schrijven van bestand mislukt');
define('LANUPLOAD_15', 'Upload niet toegestaan');
define('LANUPLOAD_16', 'Onbekende Error');
define('LANUPLOAD_17', 'Foutieve naam voor upgeload bestand');
define('LANUPLOAD_18', 'Dit geuploade bestand overschrijd de toegestane limieten.');
define('LANUPLOAD_19', 'Te veel bestanden geuploaded - overschrijding verwijderd.');

?>