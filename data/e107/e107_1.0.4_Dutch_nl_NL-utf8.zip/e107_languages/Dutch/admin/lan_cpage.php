<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_cpage.php $
 * $Revision: 505 $
 * $Date: 2011-04-25 09:05:03 +0200 (ma, 25 apr 2011) $
 * $Author: erje $
 */

define('CUSLAN_1',  'Titel');
define('CUSLAN_2',  'Type');
define('CUSLAN_3',  'Opties');
define('CUSLAN_4',  'Deze pagina verwijderen?');
define('CUSLAN_5',  'Aanwezige pagina´s');
define('CUSLAN_7',  'Naam menu');
define('CUSLAN_8',  'Titel / Koptekst');
define('CUSLAN_9',  'Tekst');
define('CUSLAN_10', 'Toestaan beoordelen pagina');
define('CUSLAN_11', 'Voorpagina');
define('CUSLAN_12', 'Aanmaken pagina');
define('CUSLAN_13', 'Toestaan reacties');
define('CUSLAN_14', 'Met wachtwoord beveiligde pagina');
define('CUSLAN_15', 'Invoeren wachtwoord waarmee de pagina wordt beveiligd');
define('CUSLAN_16', 'Aanmaken link in hoofdmenu');
define('CUSLAN_17', 'Invoeren naam van de aan te maken link ');
define('CUSLAN_18', 'Pagina / link zichtbaar voor');
define('CUSLAN_19', 'Bijwerken pagina');
define('CUSLAN_20', 'Aanmaken pagina');
define('CUSLAN_21', 'Bijwerken menu');
define('CUSLAN_22', 'Aanmaken menu');
define('CUSLAN_23', 'Bewerken pagina');
define('CUSLAN_24', 'Aanmaken nieuwe pagina');
define('CUSLAN_25', 'Bewerken menu');
define('CUSLAN_26', 'Aanmaken nieuw menu');
define('CUSLAN_27', 'Pagina opgeslagen in database.');
define('CUSLAN_28', 'Pagina verwijderd');
define('CUSLAN_29', 'Overzicht pagina´s als geen geselecteerd');
define('CUSLAN_30', 'Vervalperiode cookie (in seconden)');
define('CUSLAN_31', 'Aanmaken menu');
define('CUSLAN_32', 'Converteren oude pagina´s/menu´s');
define('CUSLAN_33', 'Pagina opties');
define('CUSLAN_34', 'Start conversie');
define('CUSLAN_35', 'Gereed bijwerken maatwerkpagina - bijgewerkt');
define('CUSLAN_36', 'Om je voorkeuren voor elke pagina in te stellen, kun je op de voorpagina de afzonderlijke pagina´s bewerken.');
define('CUSLAN_37', 'Maatwerkpagina bijwerken');
define('CUSLAN_38', 'aan');
define('CUSLAN_39', 'uit');
define('CUSLAN_40', 'Bewaren instellingen');
define('CUSLAN_41', 'Tonen auteurs- en datuminformatie');
define('CUSLAN_42', 'Nog geen pagina´s gedefinieerd');
define('CUSLAN_43', 'menu zonder titel - ');
define('CUSLAN_44', 'pagina zonder titel - ');

?>