<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/help/cpage.php $
 * $Revision: 494 $
 * $Date: 2010-10-20 15:41:29 +0200 (wo, 20 okt 2010) $
 * $Author: erje $
 */

if (!defined('e107_INIT')) { exit(); }

$text = "In dit scherm kun je maatwerk menu's en maatwerk pagina's maken waarin je je eigen content opvoert.<br /><br />
Zie <a href='http://wiki.e107.org/index.php?title=Content:Custom_Menus/Pages'>Using Custom Pages and Custom Menus</a> voor een uitleg van alle functies.";

$ns -> tablerender(CUSLAN_18, $text);

?>