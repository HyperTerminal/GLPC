<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/help/cache.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

if (!defined('e107_INIT')) { exit(); }

$caption = "Caching";
$text = "Als je caching aanzet, zal de snelheid van je site aanzienlijk toenemen en de hoeveelheid database aanroepen sterk verminderen.<br /><br /><b>LET OP! Als je je eigen Thema maakt, zet dan caching uit, omdat anders de wijzigingen niet worden getoond.</b>";
$ns -> tablerender($caption, $text);

?>