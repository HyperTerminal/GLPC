<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/help/image.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

if (!defined('e107_INIT')) { exit(); }

$text = "Stel hier in welke gebruikers al dan niet de mogelijkheid hebben om afbeeldingen op de site te bekijken welke geplaatst zijn met de [img] bbcode.<br /><br />Verder kun je hier instellen welke verschalingsmethode je wenst te gebruiken, de omgang met transparente PNG-24's met alpha transparentie in IE 5 / 6 en geuploade avatars bekijken en controleren.";
$ns -> tablerender("Afbeeldingenhulp", $text);

?>