<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/help/download.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

if (!defined('e107_INIT')) { exit(); }

$text = "Upload je bestanden naar de ".e_FILE."downloads map, de afbeeldingen naar de ".e_FILE."downloadimages map en de thumbnail afbeeldingen naar de ".e_FILE."downloadthumbs map.
<br /><br />
Om een download aan te melden moet je eerst een hoofdcategorie creëren en daarna een categorie onder deze hoofdcategorie. Daarna kun je de download beschikbaar stellen.";
$ns -> tablerender("Download Help", $text);

?>