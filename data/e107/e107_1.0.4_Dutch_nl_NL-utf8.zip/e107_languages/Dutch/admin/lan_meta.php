<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_meta.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('METLAN_1',  'Meta tags bijgewerkt in database');
define('METLAN_2',  'Opvoeren meta tags');
define('METLAN_3',  'Meta tag instellingen bijwerken');
define('METLAN_4',  'Bijgewerkt');
define('METLAN_5',  'voer hier de beschrijving in');
define('METLAN_6',  'Geef, hier, een, serie, sleutelwoorden, op');
define('METLAN_7',  'Voer hier de auteursrecht informatie in');
define('METLAN_8',  'Meta tags');

define('METLAN_9',  'Omschrijving');
define('METLAN_10', 'Sleutelwoorden');
define('METLAN_11', 'Auteursrecht');
define('METLAN_12', 'Gebruik de nieuwstitel en samenvatting als meta beschrijving op nieuwspagina´s.');
define('METLAN_13', 'Auteur');

?>