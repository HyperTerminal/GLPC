<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_db_verify.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define("DBLAN_1", "Niet in staat om de sql datafile te lezen<br /><br />Let erop dat het bestand <b>core_sql.php</b> aanwezig is in de<b>/admin/sql</b> directory.");
define('DBLAN_2',  'Alles verifieëren');
define('DBLAN_4',  'Tabel');
define('DBLAN_5',  'Veld');
define('DBLAN_6',  'Status');
define('DBLAN_7',  'Opmerkingen');
define('DBLAN_8',  'Afwijking');
define('DBLAN_9',  'Huidige');
define('DBLAN_10', 'moet zijn');
define('DBLAN_11', 'Ontbrekend veld');
define('DBLAN_12', 'Extra veld!');
define('DBLAN_13', 'Ontbrekende tabel!');
define('DBLAN_14', 'Kies de te verifieëren tabel(len)');
define('DBLAN_15', 'Start verificatie');
define('DBLAN_16', 'SQL verificatie - versie');
define('DBLAN_17', 'Terug');
define('DBLAN_18', 'tabellen');
define('DBLAN_19', 'Herstelpoging');
define('DBLAN_20', 'Poging tot herstellen van tabellen');
define('DBLAN_21', 'Herstellen geselecteerde onderdelen');
define('DBLAN_22', ' is niet leesbaar');

?>