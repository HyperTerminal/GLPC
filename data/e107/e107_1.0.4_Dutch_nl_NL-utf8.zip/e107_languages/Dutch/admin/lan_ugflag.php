<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_ugflag.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('UGFLAN_1', 'Onderhoudsinstellingen bijgewerkt');
define('UGFLAN_2', 'Activeren onderhoudsvlag');
define('UGFLAN_3', 'Bijwerken Onderhoudsinstellingen ');
define('UGFLAN_4', 'Onderhoudsinstellingen ');

define('UGFLAN_5', 'Tekst die getoond wordt als de site down is');
define('UGFLAN_6', 'Laat leeg om de standaardmelding weer te geven');

define('UGFLAN_8', 'Alleen toegang voor beheerder(s)');
define('UGFLAN_9', 'Alleen toegang voor hoofdbeheerder(s)');
?>