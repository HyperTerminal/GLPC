<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_lancheck.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LAN_CHECK_1',  'Verifiëer/Bewerk de taalbestanden');
define('LAN_CHECK_2',  'Begin verificatie');
define('LAN_CHECK_3',  'Verificatie van');
define('LAN_CHECK_4',  'Bestand ontbreekt!');
define('LAN_CHECK_5',  'Regel ontbreekt!');

define('LAN_CHECK_7',  'regel');

define('LAN_CHECK_8',  'Er ontbreekt een bestand ...');
define('LAN_CHECK_9',  ' bestanden ontbreken ...');
define('LAN_CHECK_10', 'Kritieke fout: ');
define('LAN_CHECK_11', 'Er ontbreekt GEEN bestand!');
define('LAN_CHECK_12', 'Een bestand is onjuist ...');
define('LAN_CHECK_13', ' bestanden zijn onjuist ...');
define('LAN_CHECK_14', 'Alle aanwezige bestanden zijn geldig!');

define('LAN_CHECK_15', 'Onjuiste tekens gevonden voor "&lt;?php"');
define('LAN_CHECK_16', 'Origineel bestand');
define('LAN_CHECK_17', 'Er is een schrijfprobleem opgetreden bij het opslaan van het bestand.');

define('LAN_CHECK_18', 'Taalbestanden in het standaardformaat zijn voor deze plugin/dit theme niet beschikbaar.');
define('LAN_CHECK_19', 'Non-UTF-8 tekens aangetroffen!');
define('LAN_CHECK_20', 'Aanmaken taalpakket');
define('LAN_CHECK_21', 'Verifiëer opnieuw');
define('LAN_CHECK_22', 'Theme');
define('LAN_CHECK_23', 'Fouten gevonden');
define('LAN_CHECK_24', 'samenvatting');
define('LAN_CHECK_25', 'Themes');
define('LAN_CHECK_26', 'File');

?>