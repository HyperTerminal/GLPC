<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_check_user.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LAN_CKUSER_01', 'Controleer de leden database.');
define('LAN_CKUSER_02', 'Dit zal de leden database controleren op verschillende potentieële problemen.');
define('LAN_CKUSER_03', 'Als je veel leden hebt dan kan het even duren en eventueel leiden tot een time out.');
define('LAN_CKUSER_04', 'Ga door ...');
define('LAN_CKUSER_05', 'Controleer op dubbele login namen.');
define('LAN_CKUSER_06', 'Selecteer functies om uit te voeren.');
define('LAN_CKUSER_07', 'Dubbele gebruikersnaam.');
define('LAN_CKUSER_08', 'Geen dubbele gevonden.');
define('LAN_CKUSER_09', 'Gebruikersnaam.');
define('LAN_CKUSER_10', 'Lid ID.');
define('LAN_CKUSER_11', 'Gebruikersnaam.');
define('LAN_CKUSER_12', 'Controleer op dubbele e-mailadressen.');
define('LAN_CKUSER_13', 'Dubbele e-mailadressen.');
define('LAN_CKUSER_14', 'e-mailadres');
define('LAN_CKUSER_15', 'Geen dubbele gevonden.');
define('LAN_CKUSER_16', 'Controleer of iemands gebruikersnaam gelijk is aan iemands anders zijn inlognaam.');
define('LAN_CKUSER_17', 'Conflicterende gebruikers en loginna(a)m(en).');
define('LAN_CKUSER_18', 'Lid A');
define('LAN_CKUSER_19', 'Lid B');

/*
define('LAN_CKUSER_20', '');
*/
?>