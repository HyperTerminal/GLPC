<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_filemanager.php $
 * $Revision: 483 $
 * $Date: 2010-09-17 15:31:44 +0200 (vr, 17 sep 2010) $
 * $Author: erje $
 */

define('FMLAN_1',  'Ge-upload');
define('FMLAN_2',  'naar');
define('FMLAN_3',  'map');
define('FMLAN_4',  'Het ge-uploade bestand is groter dan de waarde maximum upload_max_filesize in php.ini.');
// define("FMLAN_5", "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the html form.");
// define("FMLAN_6", "The uploaded file was only partially uploaded.");
// define("FMLAN_7", "No file was uploaded.");
// define("FMLAN_8", "Uploaded file size 0 bytes");
// define("FMLAN_9", "The file did not upload. Filename");
define('FMLAN_10', 'Fout');
// define("FMLAN_11", "Probably incorrect permissions on upload directory.");
define('FMLAN_12', 'bestand');
define('FMLAN_13', 'bestanden');
define('FMLAN_14', 'directory');
define('FMLAN_15', 'directories');
define('FMLAN_16', 'Hoofddirectory');
define('FMLAN_17', 'Naam');
define('FMLAN_18', 'Grootte');
define('FMLAN_19', 'Laatst gewijzigd');
define('FMLAN_21', 'Upload bestanden naar deze map');
define('FMLAN_22', 'Upload');
define('FMLAN_26', 'Verwijderd');
define('FMLAN_27', 'succesvol');
define('FMLAN_28', 'Kan niet verwijderen');
define('FMLAN_29', 'Pad');
define('FMLAN_30', 'Niveau omhoog');
define('FMLAN_31', 'map');
define('FMLAN_32', 'Kies directory');
define('FMLAN_33', 'Selecteer');
define('FMLAN_34', 'Directory keuze');
define('FMLAN_35', 'Bestandsdirectory');
define('FMLAN_36', 'Maatwerkmenu´s directory');
define('FMLAN_37', 'Maatwerkpagina´s directory');
define('FMLAN_38', 'Bestand succesvol verplaatst naar');
define('FMLAN_39', 'Kon bestand niet verplaatsen naar');
define('FMLAN_40', 'Nieuwsafbeeldingen directory');
define('FMLAN_43', 'Verwijder geselecteerde bestanden');
define('FMLAN_46', 'Bevestig dat je de geselecteerde bestanden wilt VERWIJDEREN.');
define('FMLAN_47', 'Leden uploads'); 
define('FMLAN_48', 'Verplaatst selectie naar');
define('FMLAN_49', 'Bevestig dat je de geselecteerde bestanden wilt verplaatsen.');
define('FMLAN_50', 'Verplaatsen');
define('FMLAN_51', 'ongeïdentificeerde fout: '); // Niet vast te stellen fout

?>