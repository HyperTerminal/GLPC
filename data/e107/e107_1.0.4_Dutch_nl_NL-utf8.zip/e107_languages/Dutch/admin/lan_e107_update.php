<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_e107_update.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LAN_UPDATE_2',  'Actie');
define('LAN_UPDATE_3',  'Niet nodig');

define('LAN_UPDATE_5',  'Update(s) beschikbaar');
define('LAN_UPDATE_7',  'Uitvoeren');
define('LAN_UPDATE_8',  'Update van');
define('LAN_UPDATE_9',  'naar');
define('LAN_UPDATE_10', 'Beschikbare updates');
define('LAN_UPDATE_11', '.617 naar .7 update voortgezet');
define('LAN_UPDATE_12', 'Eén van de tabellen bevat dubbele records.');

?>