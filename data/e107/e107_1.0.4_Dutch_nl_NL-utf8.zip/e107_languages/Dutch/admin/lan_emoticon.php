<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_emoticon.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('EMOLAN_1',  'Emoticon Activatie.');
define('EMOLAN_2',  'Naam');
define('EMOLAN_3',  'Emoticons');
define('EMOLAN_4',  'Emoticons Activeren?');
define('EMOLAN_5',  'Afbeelding');
define('EMOLAN_6',  'Smiley Code');
define('EMOLAN_7',  'Meerdere mogelijkheden scheiden met spaties');
define('EMOLAN_8',  'Status');
define('EMOLAN_9',  'Opties');
define('EMOLAN_10', 'Actief Pakket');
define('EMOLAN_11', 'Pakket activeren');
define('EMOLAN_12', 'Bewerk/configureer dit pakket');
define('EMOLAN_13', 'Geïnstalleerde pakketten');
define('EMOLAN_14', 'Bewaren configuratie');
define('EMOLAN_15', 'Bewerken/configureren Emoticon ');
define('EMOLAN_16', 'Emoticon configuratie opgeslagen');
define('EMOLAN_17', 'Er is een emoticon pakket met spaties aanwezig, die zijn niet toegestaan!');
define('EMOLAN_18', 'hernoem de onderstaande objecten, zodat ze geen spaties bevatten:');
define('EMOLAN_19', 'Naam');
define('EMOLAN_20', 'Locatie');
define('EMOLAN_21', 'Fout');
define('EMOLAN_22', 'Nieuw emotiticon pakket gevonden:');
define('EMOLAN_23', 'Nieuw emotiticon XML pak gevonden:');
define('EMOLAN_24', 'Nieuw emotiticon PHP gevonden:');
define('EMOLAN_25', 'Installeer nieuwe PHP emoticons');
define('EMOLAN_26', 'Herscan pakket');
define('EMOLAN_27', 'Fout met het verwerken van het pakket');
define('EMOLAN_28', 'Maak XML bestand aan');
define('EMOLAN_29', 'XML bestand aangemaakt');
define('EMOLAN_30', 'Fout met schrijven van XML Bestand.');

?>