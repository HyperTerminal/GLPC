<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/admin/lan_modcomment.php $
 * $Revision: 555 $
 * $Date: 2012-08-17 19:04:49 +0200 (vr, 17 aug 2012) $
 * $Author: erje $
 */

define('MDCLAN_1',  'Gemodereerd.');
define('MDCLAN_2',  'Geen reacties bij dit onderwerp');
define('MDCLAN_3',  'Lid');
define('MDCLAN_4',  'Gast');
define('MDCLAN_5',  'deblokkeer');
define('MDCLAN_6',  'blokkeer');
define('MDCLAN_7',  'goedkeuren');

define('MDCLAN_8',  'Modereer reacties');
define('MDCLAN_9',  'Waarschuwing! Verwijderen van de eerste reactie verwijdert ook de antwoorden!');

define('MDCLAN_10', 'opties');
define('MDCLAN_11', 'reactie');
define('MDCLAN_12', 'reacties');
define('MDCLAN_13', 'geblokkeerd');
define('MDCLAN_14', 'afsluiten reacties');
define('MDCLAN_15', 'open');
define('MDCLAN_16', 'gesloten');

define('MDCLAN_17', 'Er zijn op dit moment geen reacties in afwachting van goedkeuring');
define('MDCLAN_18', '');
define('MDCLAN_19', '');
define('MDCLAN_20', '');

?>