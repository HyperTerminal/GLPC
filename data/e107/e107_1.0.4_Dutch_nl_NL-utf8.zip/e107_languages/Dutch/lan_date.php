<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/lan_date.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LANDT_01',  'jaar');
define('LANDT_02',  'maand');
define('LANDT_03',  'week');
define('LANDT_04',  'dag');
define('LANDT_05',  'uur');
define('LANDT_06',  'minuut');
define('LANDT_07',  'seconde');
define('LANDT_01s', 'jaren');
define('LANDT_02s', 'maanden');
define('LANDT_03s', 'weken');
define('LANDT_04s', 'dagen');
define('LANDT_05s', 'uren');
define('LANDT_06s', 'minuten');
define('LANDT_07s', 'seconden');

define('LANDT_08',  'min');
define('LANDT_08s', 'min');
define('LANDT_09',  'sec');
define('LANDT_09s', 'sec');
define('LANDT_AGO', 'geleden');

?>