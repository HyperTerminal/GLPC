<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_languages/Dutch/lan_top.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('PAGE_NAME', 'Top Forum Poster'); //de titel van de pagina
 
define('TOP_LAN_0', 'Top Forum Poster');
define('TOP_LAN_1', 'Gebruikersnaam');
define('TOP_LAN_2', 'Berichten');
define('TOP_LAN_3', 'Top reactie posters');
define('TOP_LAN_4', 'Reacties');
define('TOP_LAN_5', 'Top chatbox posters');
define('TOP_LAN_6', 'Site beoordeling');

//v.616
define('LAN_1',     'Discussie');
define('LAN_2', 	'Schrijver');
define('LAN_3', 	'Bekeken');
define('LAN_4', 	'Reacties');
define('LAN_5', 	'Laatste post');
define('LAN_6', 	'Discussies');
define('LAN_7', 	'meest actieve discussies');
define('LAN_8', 	'Top Posters');

?>