<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_themes/jayya/languages/Dutch.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('LAN_THEME_1', 	'e107 core theme by <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>');
define('LAN_THEME_2', 	'Reacties: ');
define('LAN_THEME_3', 	'Reacties bij dit onderwerp niet mogelijk');
define('LAN_THEME_4', 	'Lees het hele bericht');
define('LAN_THEME_5', 	'Trackbacks: '); 
define('LAN_THEME_8', 	'in');
define('LAN_THEME_9', 	'door');
define('LAN_THEME_11', 	'Laatste nieuws');
define('LAN_THEME_12', 	'E-mail naar een vriend');
define('LAN_THEME_13', 	'Genereer een PDF van dit bericht');
define('LAN_THEME_14', 	'Print');
define('LAN_THEME_15', 	'Bewerk dit bericht');
define('LAN_THEME_17', 	'Inloggen');
define('LAN_THEME_18', 	'Gebruikersnaam');
define('LAN_THEME_19', 	'Wachtwoord');
define('LAN_THEME_20', 	'Registeer');
define('LAN_THEME_21', 	'Inloggen');
define('LAN_THEME_22', 	'Wachtwoord vergeten?');
define('LAN_THEME_23', 	'Welkom');
define('LAN_THEME_24', 	'Beheer');
define('LAN_THEME_26', 	'Instellingen');
define('LAN_THEME_27', 	'Profiel');
define('LAN_THEME_28', 	'Uitloggen');
define('LAN_THEME_29', 		'Nieuw weergeven');
define('LAN_THEME_SING', 	'Inloggen');
define('LAN_THEME_REG',  	'Registreer');
define('LAN_SEARCH', 	 	'Zoek');
define('LAN_SEARCH_SUB', 	'Ga');
define('LAN_THEME_SHARE', 	'Deel dit');
define('LAN_THEME_VER', 	'e107 v.');
define('CM_L13', 			'door');
?>