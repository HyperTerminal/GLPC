<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/pdf/languages/Dutch.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('PDF_PLUGIN_LAN_1', 'PDF');
define('PDF_PLUGIN_LAN_2', 'PDF ondersteuning');
define('PDF_PLUGIN_LAN_3', 'PDF');
define('PDF_PLUGIN_LAN_4', 'Deze plugin kan nu worden gebruikt.');

define('PDF_LAN_1',  'PDF');
define('PDF_LAN_2',  'PDF voorkeuren');
define('PDF_LAN_3',  'geactiveerd');
define('PDF_LAN_4',  'gedeactiveerd');
define('PDF_LAN_5',  'linker paginamarge');
define('PDF_LAN_6',  'rechter paginamarge');
define('PDF_LAN_7',  'bovenmarge');
define('PDF_LAN_8',  'font familie');
define('PDF_LAN_9',  'standaard font grootte');
define('PDF_LAN_10', 'font grootte sitenaam');
define('PDF_LAN_11', 'font grootte pagina URL');
define('PDF_LAN_12', 'font grootte paginanummer');
define('PDF_LAN_13', 'tonen logo in PDF?');
define('PDF_LAN_14', 'tonen sitenaam in PDF?');
define('PDF_LAN_15', 'tonen herkomst pagina URL in PDF?');
define('PDF_LAN_16', 'tonen paginanummers in PDF?');
define('PDF_LAN_17', 'bijwerken');
define('PDF_LAN_18', 'PDF voorkeuren succesvol bijgewerkt');
define('PDF_LAN_19', 'Pagina');
define('PDF_LAN_20', 'foutrapportage');

?>