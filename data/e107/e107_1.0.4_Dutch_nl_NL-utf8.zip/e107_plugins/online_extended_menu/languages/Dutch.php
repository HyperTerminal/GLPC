<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/online_extended_menu/languages/Dutch.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('ONLINE_EL1', 'Gasten: ');
define('ONLINE_EL2', 'Leden: ');
define('ONLINE_EL3', 'Op deze pagina: ');
define('ONLINE_EL4', 'Online');
define('ONLINE_EL5', 'Leden');
define('ONLINE_EL6', 'Nieuwste lid');
define('ONLINE_EL7', 'bekijkt');
define('ONLINE_EL8', 'Max. gelijk online: ');
define('ONLINE_EL9', 'op');

define('ONLINE_TRACKING_MESSAGE', 'Het volgen van gebruikers is niet geactiveerd, dat kun je [link=".e_ADMIN."users.php?options]hier doen[/link][br]');

?>