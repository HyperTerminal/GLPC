<?php

/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/forum/languages/Dutch/lan_forum_notify.php $
 * $Revision: 556 $
 * $Date: 2012-08-19 12:23:31 +0200 (zo, 19 aug 2012) $
 * $Author: erje $
 */


// Forum Gebeurtenis Types 
define('NT_LAN_FT_1', 'Forum Gebeurtenissen');
define('NT_LAN_FO_1', 'Forum draad gepost');
define('NT_LAN_MP_1', 'Forum bericht gepost');
define('NT_LAN_FD_1', 'Forum draad verwijderd');
define('NT_LAN_FP_1', 'Forum bericht verwijderd');
define('NT_LAN_FM_1', 'Forum draad verplaatst');

// Forum draad gepost
define('NT_LAN_FO_3', 'Forum draad aangemaakt door');
define('NT_LAN_FO_4', 'Forum naam');
define('NT_LAN_FO_5', 'Onderwerp');
define('NT_LAN_FO_6', 'Bericht');
define('NT_LAN_FO_7', 'Nieuwe forum draad aangemaakt');

// Forum bericht gepost
define('NT_LAN_MP_3', 'Forum bericht aangemaakt door');
define('NT_LAN_MP_4', 'Forum naam');
define('NT_LAN_MP_6', 'Bericht');
define('NT_LAN_MP_7', 'Nieuw forum bericht aangemaakt');

// Forum draad verwijderd
define('NT_LAN_FD_3', 'Forum draad aangemaakt door');
define('NT_LAN_FD_4', 'Forum naam');
define('NT_LAN_FD_5', 'Onderwerp');
define('NT_LAN_FD_6', 'bericht');
define('NT_LAN_FD_7', 'Forum draad is verwijderd');
define('NT_LAN_FD_8', 'Forum draad verwijderd door');

// Forum bericht verwijderd
define('NT_LAN_FP_3', 'Forum bericht aangemaakt door');
define('NT_LAN_FP_4', 'Forum naam');
define('NT_LAN_FP_6', 'bericht');
define('NT_LAN_FP_7', 'Forum bericht is verwijderd');
define('NT_LAN_FP_8', 'Forum bericht verwijderd door');

// Forum draad verplaatst
define('NT_LAN_FM_3', 'Forum draad aangemaakt door');
define('NT_LAN_FM_4', 'Oud Onderwerp');
define('NT_LAN_FM_5', 'Nieuw Onderwerp');
define('NT_LAN_FM_6', 'Oude (bron) forum naam');
define('NT_LAN_FM_7', 'Nieuwe (bestemming) forum naam');
define('NT_LAN_FM_8', 'Forum draad is verplaatst');
define('NT_LAN_FM_9', 'Forum draad is verplaatst door');

?>