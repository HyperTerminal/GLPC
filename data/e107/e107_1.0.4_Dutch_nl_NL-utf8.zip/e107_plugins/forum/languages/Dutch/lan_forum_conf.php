<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/forum/languages/Dutch/lan_forum_conf.php $
 * $Revision: 556 $
 * $Date: 2012-08-19 12:23:31 +0200 (zo, 19 aug 2012) $
 * $Author: erje $
 */
 
 # Install LANs
define('LAN_FORUM_INSTALL_01', 'Forum');
define('LAN_FORUM_INSTALL_02', 'Deze plugin is een uitgebreid Forum systeem.');
define('LAN_FORUM_INSTALL_03', 'Configureer Forum');
define('LAN_FORUM_INSTALL_04', 'Jouw forum is nu geinstalleerd');
define('LAN_FORUM_INSTALL_05', 'Forum succesvol bijgewerkt, Je gebruikt nu versie: %1$s');
define('LAN_FORUM_INSTALL_06', '[forum]');
define('LAN_FORUM_INSTALL_07', '[meer...]');

# Config LANs
define('FORLAN_5', 'Peiling verwijderd.');
define('FORLAN_6', 'Discussie verwijderd');
define('FORLAN_7', 'reacties verwijderd');
define('FORLAN_8', 'Verwijdering geannuleerd.');
define('FORLAN_9', 'Discussie verplaatst.');
define('FORLAN_10', 'Verplaatsing geannuleerd.');
define('FORLAN_11', 'Terug naar forums');
define('FORLAN_12', 'Forum configuratie');
define('FORLAN_13', 'Weet je zeker dat je deze peiling wilt verwijderen?<br />Eenmaal verwijderd, is terughalen <b><u>niet meer</u></b> mogelijk.');
define('FORLAN_14', 'Annuleren');
define('FORLAN_15', 'Bevestig verwijderen forumbericht');
define('FORLAN_16', 'Bevestig verwijderen peiling');
define('FORLAN_17', 'geplaatst door');
define('FORLAN_18', 'Weet je zeker dat je deze forumdiscussie');
define('FORLAN_19', ' en de bijbehorende reacties wilt verwijderen?');
define('FORLAN_20', 'de peiling wordt ook verwijderd');
define('FORLAN_21', 'Eenmaal verwijderd kunnen ze');
define('FORLAN_22', ' bericht?<br />Eenmaal verwijderd kan het ');
define('FORLAN_23', '<u><b>niet</u></b> worden teruggehaald');
define('FORLAN_24', 'Verplaats de discussie naar forum');
define('FORLAN_25', 'Verplaats discussie');
define('FORLAN_26', 'Reactie verwijderd');
define('FORLAN_27', 'verplaatst');
define('FORLAN_28', 'Deze discussie niet hernoemen');
define('FORLAN_29', 'Toevoegen');
define('FORLAN_30', 'aan titel');
define('FORLAN_31', 'Hernoemen als:');
define('FORLAN_32', 'Hernoemen discussie opties:');

?>