<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/forum/languages/Dutch/lan_newforumposts_menu.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('NFP_1',  'De laatste berichten horen bij forums waar je niet bij mag, ze kunnen niet worden getoond.');
define('NFP_2',  'Nog geen berichten');

define('NFP_3',  'Nieuwe Forum Posts menuconfiguratie opgeslagen');
define('NFP_4',  'Titelbalk');
define('NFP_5',  'Aantal te tonen berichten?');
define('NFP_6',  'Aantal te tonen tekens?');
define('NFP_7',  'Aanduiding bij te lang bericht?');
define('NFP_8',  'Originele discussies tonen in menu?');
define('NFP_9',  'Bijwerken menuconfiguratie');
define('NFP_10', 'New Forum Posts menuconfiguratie');
define('NFP_11', 'Geplaatst door');
define('NFP_12', 'Maximum leeftijd van de getoonde berichten');
define('NFP_13', 'Gebruik 0 op een rustige site, door gebruik te maken van een waarde in dagen kan je de database ontlasten op een drukke site');

?>