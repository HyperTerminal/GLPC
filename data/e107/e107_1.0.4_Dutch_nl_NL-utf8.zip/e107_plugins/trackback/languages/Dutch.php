<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/trackback/languages/Dutch.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('TRACKBACK_L1',  'Configureren Trackback');
define('TRACKBACK_L2',  'Deze plugin maakt het mogelijk om trackback in nieuwsberichten te gebruiken.');
define('TRACKBACK_L3',  'Trackback is geïnstalleerd en geactiveerd.');
define('TRACKBACK_L4',  'Trackback instellingen opgeslagen.');
define('TRACKBACK_L5',  'Aan');
define('TRACKBACK_L6',  'Uit');
define('TRACKBACK_L7',  'Activeren trackback');
define('TRACKBACK_L8',  'Trackback URL tekst');
define('TRACKBACK_L9',  'Instellingen opslaan');
define('TRACKBACK_L10', 'Trackback instellingen');
define('TRACKBACK_L11', 'Trackback adres voor dit bericht:');
define('TRACKBACK_L12', 'Geen trackbacks bij dit bericht');
define('TRACKBACK_L13', 'Beheer trackbacks');
define('TRACKBACK_L14', 'Verwijderen');
define('TRACKBACK_L15', 'Trackbacks verwijderd.');

?>