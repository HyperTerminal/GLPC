<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/alt_auth/languages/Dutch/lan_alt_auth_conf.php $
 * $Revision: 520 $
 * $Date: 2012-01-17 12:10:43 +0100 (di, 17 jan 2012) $
 * $Author: erje $
 */

define('LAN_ALT_2',        'Huidige authorizatie methode');
define('LAN_ALT_3',        'Kies alternatieve authorizatie methode');
define('LAN_ALT_4',        'Configureer parameters voor');
define('LAN_ALT_5',        'Configureer authorizatie parameters');
define('LAN_ALT_6',        'Mislukte verbinding');
define('LAN_ALT_7',        'Als de verbinding voor de alternatieve methode voor aanmelden mislukt, hoe moet dat dan worden afgehandeld?');
define('LAN_ALT_8',        'Gebruiker niet gevonden actie');
define('LAN_ALT_9',        'Als de gebruikersnaam via de alternatieve methode niet wordt gevonden, hoe moet dat dan worden afgehandeld?');
define('LAN_ALT_10',     'Mislukte inlog');
define('LAN_ALT_11', 'Gebruik e107 gebruikers tabel');

define('LAN_ALT_PAGE', 'Alternatieve authorizatie');

?>