<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/alt_auth/languages/Dutch/lan_otherdb_auth.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('OTHERDB_LAN_1',  'Database Type:');
define('OTHERDB_LAN_2',  'Server:');
define('OTHERDB_LAN_3',  'Gebruikersnaam:');
define('OTHERDB_LAN_4',  'Wachtwoord:');
define('OTHERDB_LAN_5',  'Database');
define('OTHERDB_LAN_6',  'Tabel');
define('OTHERDB_LAN_7',  'Gebruikersnaam veld:');
define('OTHERDB_LAN_8',  'Wachtwoord veld:');
define('OTHERDB_LAN_9',  'Wachtwoord methode:');
define('OTHERDB_LAN_10', 'Configureer otherdb auth');
define('OTHERDB_LAN_11', '** De volgende velden zijn niet nodig wanneer er een andere e107 database wordt gebruikt.');

?>