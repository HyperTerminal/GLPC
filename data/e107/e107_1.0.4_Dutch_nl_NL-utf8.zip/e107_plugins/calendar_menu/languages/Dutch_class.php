<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/usersettings.php $
 * $Id: usersettings.php 11645 2010-08-01 12:57:11Z e107coders $
 */
define("EC_LAN_RECUR_00", "nee");
define("EC_LAN_RECUR_01", "jaarlijks");
define("EC_LAN_RECUR_02", "tweejaarlijks");
define("EC_LAN_RECUR_03", "driemaandelijks");
define("EC_LAN_RECUR_04", "maandelijks");
define("EC_LAN_RECUR_05", "vier wekelijks");
define("EC_LAN_RECUR_06", "twee wekelijks");
define("EC_LAN_RECUR_07", "wekelijks");
define("EC_LAN_RECUR_08", "dagelijks");
define("EC_LAN_RECUR_100", "Zondag in de maand");
define("EC_LAN_RECUR_101", "Maandag in de maand");
define("EC_LAN_RECUR_102", "Dinsdag in de maand");
define("EC_LAN_RECUR_103", "Woensdag in de maand");
define("EC_LAN_RECUR_104", "Donderdag in de maand");
define("EC_LAN_RECUR_105", "Vrijdag in de maand");
define("EC_LAN_RECUR_106", "Zaterdag in de maand");
define("EC_LAN_RECUR_1100", "Eerste");
define("EC_LAN_RECUR_1200", "Tweede");
define("EC_LAN_RECUR_1300", "Derde");
define("EC_LAN_RECUR_1400", "Vierde");
define("NT_LAN_EC_1", "Evenementenkalender Evenementen");
define("NT_LAN_EC_2", "Evenement Bijgewerkt");
define("NT_LAN_EC_3", "Bijgewerkt door");
define("NT_LAN_EC_4", "IP Adres");
define("NT_LAN_EC_5", "Bericht");
define("NT_LAN_EC_6", "Evenementenkalender - Evenement toegevoegd");
define("NT_LAN_EC_7", "Nieuw evenement geplaatst");
define("NT_LAN_EC_8", "Evenementen kalender- Evenement gewijzigd");
define("EC_ADM_01", "Evenementenkalender - voeg evenement toe");
define("EC_ADM_02", "Evenementenkalender - bewerk evenement");
define("EC_ADM_03", "Evenementenkalender - verwijder evenement");
define("EC_ADM_04", "Evenementenkalender - Massa verwijderen");
define("EC_ADM_05", "Evenementenkalender - Massa toevoegen");
define("EC_ADM_06", "Evenementenkalender - Hoofd opties gewijzigd");
define("EC_ADM_07", "Evenementenkalender - FE opties gewijzigd");
define("EC_ADM_08", "Evenementenkalender - Categorie toegevoegd");
define("EC_ADM_09", "Evenementenkalender - Categorie bewerkt");
define("EC_ADM_10", "Evenementenkalender - Categorie verwijdert");
define("EC_ADM_11", "Evenementenkalender - Oude evenemeneten verwijderd");


?>