<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/newforumposts_main/languages/Dutch.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */

define('NFPM_LAN_1', 'Discussie');
define('NFPM_LAN_2', 'Auteur');
define('NFPM_LAN_3', 'Bekeken');
define('NFPM_LAN_4', 'Reacties');
define('NFPM_LAN_5', 'Laatste');
define('NFPM_LAN_6', 'Discussies');
define('NFPM_LAN_7', 'door');

define('NFPM_L1',  'Deze plugin toont een overzicht met de nieuwste forumdiscussies op je startpagina');
define('NFPM_L2',  'Nieuwste forumdiscussies'); 
define('NFPM_L3',  'Klik op de link in de plugin sectie van je beheerscherm om deze plugin te configureren');
define('NFPM_L4',  'Activeren in welke zone?');
define('NFPM_L5',  'Inactief');
define('NFPM_L6',  'Bovenkant pagina');
define('NFPM_L7',  'Onderkant pagina');
define('NFPM_L8',  'Titelbalk');
define('NFPM_L9',  'Aantal te tonen berichten');
define('NFPM_L10', 'Tonen binnen scrollend gedeelte?');
define('NFPM_L11', 'Hoogte scrollend gedeelte');
define('NFPM_L12', 'Nieuwste forumdiscussies configuratie');
define('NFPM_L13', 'Bijwerken Nieuwe Forum Berichten instellingen');
define('NFPM_L14', 'Nieuwe Forum Berichten instellingen opgeslagen.');
define('NFPM_L15', 'Aankruisen om de nieuwste forumdiscussies te tonen.<br />Standaard is laatste discussies.');
define('NFPM_L16', '[gebruiker verwijderd]');
define('NFPM_L17', 'Nieuwe Berichten op populaire Draad');
define('NFPM_L18', 'Nieuwe Berichten');
define('NFPM_L19', 'Geen Nieuwe Berichten on Popular Draad');
define('NFPM_L20', 'Geen Nieuwe Berichten');
define('NFPM_L21', 'Sticky Draad');
define('NFPM_L22', 'Gesloten Sticky Draad');
define('NFPM_L23', 'Aankondiging');
define('NFPM_L24', 'Gesloten Draad');

?>