<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/links_page/languages/Dutch_help.php $
 * $Revision: 479 $
 * $Date: 2010-09-16 13:06:16 +0200 (do, 16 sep 2010) $
 * $Author: erje $
 */
 
define('LAN_ADMIN_HELP_0', 'Linkspage help functie');
define('LAN_ADMIN_HELP_1', '<i>De pagina Beheren linkcategorieën toont alle aanwezige categorieën.</i><br /><br /><b>detailoverzicht</b><br />Je ziet een overzicht van alle categorieën met hun pictogram, naam, bescrhijving, opties en sorteerinstelling.<br /><br /><b>uitleg van de pictogrammen</b><br />
'.LINK_ICON_LINK.': Link naar de categorie<br /><br />
'.LINK_ICON_EDIT.': Wijzige de categorie<br /><br />
'.LINK_ICON_DELETE.': Verwijder de categorie<br /><br />
'.LINK_ICON_ORDER_UP.': De up knop geeft je de mogelijkheid om de link 1 plaats omhoog te plaatsen.<br /><br />
'.LINK_ICON_ORDER_DOWN.': De down knop geeft je de mogelijkheid om de link 1 plaats naar beneden te plaatsen.<br />
<br />
<b>Volgorde</b><br />Hier kan je met de hand de volgorde van de categorieën bepalen. Verander de waardes in de door jouw gewenste volgorde en klik op hersorteren om de nieuwe volgorde op te slaan.<br />');
define('LAN_ADMIN_HELP_2', '<i>de maak link categorie pagina laat je nieuwe categorieën aanmaken</i><br /><br />Je kunt een nieuw pictogram uploaden en het na de upload toewijzen aan de categorie.');
define('LAN_ADMIN_HELP_3', '<i>de pagina Beheren links toont eerst alle categorieën.</i><br /><br />'.LINK_ICON_LINK.': Link naar de categorie<br /><br />'.LINK_ICON_EDIT.': klik op het pictogram om alle links in deze categorie te bekijken<br />');
define('LAN_ADMIN_HELP_4', '<i>de creëer link pagina staat je toe een nieuwe link op te voeren</i><br /><br />Je kunt een nieuw pictogram uploaden en het na de upload toewijzen aan de link.<br /><br />Open Type laat je instellen hoe de link wordt geopend als iemand erop klikt.');
define('LAN_ADMIN_HELP_5', '<i>de pagina met aangemelde links toont alle links die door gebruikers zijn aangemeld</i><br /><br /><b>detailoverzicht</b><br />Je ziet de link url, de naam van de gebruiker die de link heeft aangemeld en opties.<br /><br /><b>uitleg van de pictogrammen</b><br />
'.LINK_ICON_EDIT.': Maar voor de aangemelde link een formulier aan<br /><br />
'.LINK_ICON_DELETE.': Verwijder de aangemelde link<br />
');
define('LAN_ADMIN_HELP_6', '<i>via de Opties pagina kun je het gedrag van de links_page plugin wijzigen</i><br /><br />
Algemene opties<br />
deze opties worden gebruikt op de link pagina.<br /><br />
prive link managers<br />
de prive link managers zijn gebruikers die zelf aangemelde links mogen beheren.<br /><br />
categorie pagina<br />
Hier kan je opties wijzigen voor de categorie pagina.<br /><br />
links pagina<br />
Deze opties worden gebruikt op de link pagina.<br /><br />
verwijzingen pagina<br />
Deze opties worden gebruikt op de verwijzingen per link pagina.<br /><br />
beoordelings pagina<br />
Deze opties worden gebruikt op de best beoordeelde links pagina.<br />
');
define('LAN_ADMIN_HELP_7', '<i>op de Bewerken link categorie pagina kun je een bestaande categorie wijzigen</i><br /><br />Je kunt een nieuw pictogram uploaden en het na de upload toewijzen aan de categorie.<br />Je kunt datum/tijd van de link aanpassen door het vakje aan te kruisen.');
define('LAN_ADMIN_HELP_8', '<i>deze pagina toont alle aanwezige links in de geselecteerde categorie.</i><br /><br /><b>detailoverzicht</b><br />Je ziet een lijst met links met hun afbeelding, naam, opties en sorteeropties.<br /><br /><b>uitleg van de pictogrammen</b><br />
'.LINK_ICON_LINK.': link naar de website<br /><br />
'.LINK_ICON_EDIT.': wijzig the link<br /><br />
'.LINK_ICON_DELETE.': verwijder de link<br /><br />
'.LINK_ICON_ORDER_UP.': De up knop geeft je de mogelijkheid om de link 1 plaats omhoog te plaatsen.<br /><br />
'.LINK_ICON_ORDER_DOWN.': De down knop geeft je de mogelijkheid om de link 1 plaats naar beneden te plaatsen.<br />
<br />
<b>Volgorde</b><br />Hier kan je met de hand de volgorde van de links bepalen. Verander de waardes in de door jouw gewenste volgorde en klik op hersorteren om de nieuwe volgorde op te slaan.<br />');
define('LAN_ADMIN_HELP_9',  '<i>je kunt een link wijzigen op de Bewerk link pagina</i><br /><br />Je kunt een nieuw pictogram uploaden en het na de upload toewijzen aan de link.<br /><br />Open Type laat je instellen hoe de link wordt geopend als iemand erop klikt.');
define('LAN_ADMIN_HELP_10', '<i>de post aangemelde link pagina laat je een aangemelde link toevoegen aan de aanwezige links</i><br /><br />Een kleine tekst met Aangemeld wordt toegevoegd aan de beschrijving.<br /><br />Je kunt een nieuw pictogram uploaden en het na de upload toewijzen aan de link.<br /><br />Open Type laat je instellen hoe de link wordt geopend als iemand erop klikt.');

?>