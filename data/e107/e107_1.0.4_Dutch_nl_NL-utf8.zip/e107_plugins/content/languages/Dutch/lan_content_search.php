<?php
/*
 * Dutch Language File for the
 *   e107 website system (http://e107.org).
 * Released under the terms and conditions of the
 *   GNU General Public License v3 (http://gnu.org).
 * $HeadURL: https://e107dutch.svn.sourceforge.net/svnroot/e107dutch/trunk/e107_plugins/content/languages/Dutch/lan_content_search.php $
 * $Revision: 556 $
 * $Date: 2012-08-19 12:23:31 +0200 (zo, 19 aug 2012) $
 * $Author: erje $
 */

define('CONT_SCH_LAN_1', 'Content');
define('CONT_SCH_LAN_2', 'Alle contentcategorieën');
define('CONT_SCH_LAN_3', 'Geplaatst als reactie op onderwerp');
define('CONT_SCH_LAN_4', 'in');

?>