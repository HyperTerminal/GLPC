<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/forum/languages/English/lan_forum_search.php $
|     $Revision: 11678 $
|     $Id: lan_forum_search.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forum");
define("FOR_SCH_LAN_2", "Select forum");
define("FOR_SCH_LAN_3", "All Forums");
define("FOR_SCH_LAN_4", "Whole post");
define("FOR_SCH_LAN_5", "As part of thread");

?>