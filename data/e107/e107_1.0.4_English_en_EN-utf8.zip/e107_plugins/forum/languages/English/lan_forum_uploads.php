<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/forum/languages/English/lan_forum_uploads.php $
|     $Revision: 11678 $
|     $Id: lan_forum_uploads.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forum Uploads");

define('FRMUP_1','Uploaded Files in forum');
define('FRMUP_2','File deleted');
define('FRMUP_3','Error: Unable to delete file');
define('FRMUP_4','File deletion');
define('FRMUP_5','Filename');
define('FRMUP_6','Result');
define('FRMUP_7','Found in thread');
define('FRMUP_8','NOT FOUND');
define('FRMUP_9','No uploaded files found');
define('FRMUP_10','Delete');
	
?>