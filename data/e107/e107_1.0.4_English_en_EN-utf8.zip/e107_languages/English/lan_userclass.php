<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/lan_userclass.php $
|     $Revision: 12892 $
|     $Id: lan_userclass.php 12892 2012-07-21 03:20:42Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Everyone (public)");
define("UC_LAN_1", "Guests");
define("UC_LAN_2", "No One (inactive)");
define("UC_LAN_3", "Members");
define("UC_LAN_4", "Read Only");
define("UC_LAN_5", "Admin");
define("UC_LAN_6", "Main Admin");

define('UC_LAN_9','New Users');
define('UC_LAN_10', 'Search Bots');

?>