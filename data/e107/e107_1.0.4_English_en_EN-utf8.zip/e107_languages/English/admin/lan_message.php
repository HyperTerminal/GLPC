<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/lan_message.php $
|     $Revision: 11678 $
|     $Id: lan_message.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Received messages");
define("MESSLAN_2", "Delete Message");
define("MESSLAN_3", "Message Deleted.");
define("MESSLAN_4", "Delete All Messages");
define("MESSLAN_5", "Confirm");
define("MESSLAN_6", "All messages deleted.");
define("MESSLAN_7", "No messages.");
define("MESSLAN_8", "Message type");
define("MESSLAN_9", "Reported on");

define("MESSLAN_10", "Submitted by");
define("MESSLAN_11", "opens in new window");
define("MESSLAN_12", "Message");
define("MESSLAN_13", "Link");


?>