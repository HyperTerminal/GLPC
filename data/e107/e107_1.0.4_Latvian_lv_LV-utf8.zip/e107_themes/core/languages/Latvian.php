<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define('LAN_THEME_1', 'e107 core dizains no <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>');
define('LAN_THEME_2', 'Komentāri: ');
define('LAN_THEME_3', 'Komentāri ir atslēgti šim rakstam');
define('LAN_THEME_4', 'Lasīt visu');
define('LAN_THEME_5', 'Izsekošana: '); 
define('LAN_THEME_8', 'iekš');
define('LAN_THEME_9', 'no');
define("LAN_THEME_11", "Jaunakais");
define("LAN_THEME_12", "E-pasts draugam");
define("LAN_THEME_13", "Izveidot PDF failu");
define("LAN_THEME_14", "Printēt");
define("LAN_THEME_15", "Labot");
define('LAN_THEME_17', 'Pieteikties');
define('LAN_THEME_18', 'Lietotājvārds');
define('LAN_THEME_19', 'Parole');
define('LAN_THEME_20', 'Reģistrēties');
define('LAN_THEME_21', 'Pieteikties');
define('LAN_THEME_22', 'Aizmirsi paroli?');
define('LAN_THEME_23', 'Sveicināts');
define('LAN_THEME_24', 'Admins');
define('LAN_THEME_26', 'Uzstādījumi');
define('LAN_THEME_27', 'Tavs Konts');
define('LAN_THEME_28', 'Iziet');
define('LAN_THEME_29', 'Jaunumi');
define('LAN_THEME_SING', 'Ienākt');
define('LAN_THEME_REG', 'Reģistrēties');
define("LAN_SEARCH", "Meklet");
define("LAN_SEARCH_SUB", "Aiziet");
define('LAN_THEME_SHARE', 'Padalies');
define('LAN_THEME_VER', 'e107 v.');
define("CM_L13", "no");
?>