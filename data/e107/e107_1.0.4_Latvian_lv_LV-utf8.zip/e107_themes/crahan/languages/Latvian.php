<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'CraHan' no <a href='http://e107.org' rel='external'>jalist</a>, dizains bazēts no CraHan majaslapā <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Komentāri tiek izslēgts šim postenim");
define("LAN_THEME_3", "Komentārs(i)");
define("LAN_THEME_4", "Lasīt visu...");
define("LAN_THEME_5", "Iz\sekosana:");
define("LAN_THEME_6", "Komentētājs");


?>