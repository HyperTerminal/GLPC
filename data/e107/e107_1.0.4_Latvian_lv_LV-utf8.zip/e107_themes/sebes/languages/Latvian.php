<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'sebes' no <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Komentāri");
define("LAN_THEME_3", "Komentāri tiek izslēgts šim postenim");
define("LAN_THEME_4", "Lasīt visu...");
define("LAN_THEME_5", "Izsekošana:");
define("LAN_THEME_6", "kad");


?>