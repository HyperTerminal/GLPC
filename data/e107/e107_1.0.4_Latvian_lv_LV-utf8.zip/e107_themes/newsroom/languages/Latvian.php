<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("LAN_THEME_1", "Komentāri");
define("LAN_THEME_2", "Komentāri izslēgti");
define("LAN_THEME_3", "PILS RAKSTS");
define("LAN_THEME_4", "Pievienots");
?>