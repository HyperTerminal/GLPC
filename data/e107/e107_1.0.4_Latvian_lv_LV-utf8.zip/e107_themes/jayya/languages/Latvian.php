<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "Komentāri tiek izslēgts šim postenim");
define("LAN_THEME_2", "Komentāri");
define("LAN_THEME_3", "Lasīt visu...");
define("LAN_THEME_4", "Izsekošana");
define("LAN_THEME_5", "Pievienoja");
define("LAN_THEME_6", "kad");


?>