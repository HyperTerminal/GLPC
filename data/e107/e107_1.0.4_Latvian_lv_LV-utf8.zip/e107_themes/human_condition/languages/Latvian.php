<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_THEME_1", "'Human Condition' no <a href='http://e107.org' rel='external'>jalist</a>, bāzēta uz Wordpress dizaina, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Komentāri tiek izslēgts šim postenim");
define("LAN_THEME_3", "Komentārs(i)");
define("LAN_THEME_4", "Lasīt visu...");
define("LAN_THEME_5", "Izsekošāna:");
define("LAN_THEME_6", "Komentētajs:");


?>