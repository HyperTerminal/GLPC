<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Forums");
define("LAN_30", "Sveiks");
define("LAN_31", "Šeit nav Jaunu Rakstu ");
define("LAN_32", "Šeit ir 1 Jauns Raksts ");
define("LAN_33", "Šeit ir");
define("LAN_34", "jauns raksts");
define("LAN_35", "kopš Jūsu pēdējās vizītes.");
define("LAN_36", "Jūs pēdējoreiz apmeklējāt");
define("LAN_37", "Tagad ir");
define("LAN_38", ", visas reizes");
define("LAN_41", "Jauniņais:");
define("LAN_42", "Reģistrēti");
define("LAN_44", "Šos forumus var izmantot bez reģistrēšanāš, bet, lūdzu, ņemiet vērā, ka jūsu IP adrese tiks reģistrēta, ja jūs veicat rakstu. <br /> Lai piekļūtu pilnu iezīmes šajā forumā Jums būs nepieciešams");
define("LAN_45", "Šajos forumos atļauts ievietot rakstu tikai, Kas ir reģistrējies un ielogojies lūdzu, noklikšķiniet");
define("LAN_46", "Forums");
define("LAN_47", "Tēmas");
define("LAN_48", "Atbildes");
define("LAN_49", "Pēdejais Raksts");
define("LAN_51", "Pagaidam te nav neviena foruma! Pārbaudiet vēlāk ...");
define("LAN_52", "Pagaidam te nav neviena foruma šajā kategorijā! Pārbaudiet vēlāk ...");
define("LAN_79", "Jauns Raksts");
define("LAN_80", "Nav Jaunu Rakstu");
define("LAN_81", "Slegta Tema");
define("LAN_100", "Raksti");
define("LAN_180", "Meklēt");
define("LAN_191", "Informācija");
define("LAN_192", "Šā foruma lietotāji ir veikuši kopā");
define("LAN_196", "Esat izlasījis");
define("LAN_197", "no šiem rakstiem.");
define("LAN_198", "Visi jaunie raksti ir lasīti.");
define("LAN_199", "Atzīmēt visus rakstus kā lasītus");
define("LAN_204", "Jūs <b>drīkstat</b> uzsākt jaunu tēmu");
define("LAN_205", "Jūs <b>nedrīkstat</b> uzsākt jaunu temu");
define("LAN_206", "Jūs <b>drīkstat</b> rakstīt atbildes");
define("LAN_207", "Jūs <b>nedrīkstat</b> rakstīt atbildes");
define("LAN_208", "Jūs <b>drīkstat</b> labot savus rakstus");
define("LAN_209", "Jūs <b>nedrīkstat</b> labot savus rakstus");
define("LAN_392", "Pārtraukt sekošanu šai Tēmai");
define("LAN_393", "Sekoto Tēmu saraksts");
define("LAN_394", "Slēgts Forums");
define("LAN_397", "Sekotas Tēmas");
define("LAN_398", "Slēgts");
define("LAN_399", "Ierobežots");
define("LAN_400", "Šis forums var tikai pārlūkot ar reģistrētiem lietotājiem");
define("LAN_401", "biedri tikai");
define("LAN_402", "Šis forums ir tikai lasāms");
define("LAN_403", "Pagaidām nav nevienu rakstu!");
define("LAN_404", "raksti");
define("LAN_405", "Ierobežota Zona");
define("LAN_406", "Šis Forums ir Ierobežots, pieejams Adminiem tikai");
define("LAN_407", "Šis forums ir ierobežots, pieejams tikai Biedriem");
define("LAN_408", "Šis forums ir tikai Lasāms");
define("LAN_409", "Šī ir klases ierobežots forums");
define("LAN_410", "Sveicināts Ciemiņ");
define("LAN_411", "Tēma");
define("LAN_412", "Atbildēt");
define("LAN_413", "Tēmas");
define("LAN_414", "Atbildes");
define("LAN_415", "Biedrs pārlūko šo forumu pagaidām");
define("LAN_416", "Biedri pārlūko šo forumu pagaidām");
define("LAN_417", "Biedrs");
define("LAN_418", "Ciemiņi");
define("LAN_419", "Biedri");
define("LAN_420", "Ciemiņi");
define("LAN_421", "Rādīt Jaunos Rakstus");
define("LAN_422", "Jauni Raksti kopš pēdējā apmeklējuma");
define("LAN_423", "Pievienoja");
define("LAN_424", "Jaunas Tēmas");
define("LAN_425", "Au:");
define("LAN_426", "Kas ir Pieteicies: ");
define("LAN_427", "Skatīt detalizētu sarakstu.");
define("LAN_428", "Au:");
define("LAN_429", "Top Raksnieki");
define("LAN_430", "Vissaktīvākās Tēmas");
define("LAN_431", "Mani Raksti");
define("LAN_432", "Mani Uzstādījumi");
define("LAN_433", "Foruma Noteikumi");
define("LAN_434", "Atgriezties uz Forumu");
define("LAN_435", "Mans Konts");
define("LAN_436", " (Atvērsies jaunā logā)");
define("LAN_437", "Reģistrēties");
define("LAN_438", "un pieteikties");
define("LAN_439", "Šeit");
define("LAN_440", "lai dotos uz reģistrācijas lapu");
define("LAN_441", "Skatīt foruma statistiku");
define("FORLAN_441", "Nav Noteikumi Noteikti");
define("FORLAN_442", "Manas Augšupielāsdes");
define("FORLAN_443", "[Biedrs Dzēsis]");
define("FORLAN_444", "Apakš forums");


?>