<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Foruma Augšupielādes");

define('FRMUP_1','Augšupielādēt failus forumā');
define('FRMUP_2','Fails Dzēsts');
define('FRMUP_3','Kļūda: Neizdevās dzēst failu!');
define('FRMUP_4','Faila Dzēšana');
define('FRMUP_5','Nosaukums');
define('FRMUP_6','Rezultāti');
define('FRMUP_7','Forumu Tēmā');
define('FRMUP_8','NAV ATRASTS');
define('FRMUP_9','Nav augšupielādēti faili atrasti');
define('FRMUP_10','Dzēst');
	
?>