<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("FOR_SCH_LAN_1", "Forums");
define("FOR_SCH_LAN_2", "Izvēlies forumu");
define("FOR_SCH_LAN_3", "Visus Forumus");
define("FOR_SCH_LAN_4", "Kādus Rakstus");
define("FOR_SCH_LAN_5", "Kādaļu no Tēmas");

?>