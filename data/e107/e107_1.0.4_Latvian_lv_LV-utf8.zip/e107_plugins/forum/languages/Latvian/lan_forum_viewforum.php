<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forums");
	
define("LAN_01", "Forums");
define("LAN_02", "Uz Augšu");
define("LAN_03", "Aiziet");
define("LAN_53", "Tēmas");
define("LAN_54", "Sāka");
define("LAN_55", "Atbildes");
define("LAN_56", "Skatīts");
define("LAN_57", "Jaunakais");
define("LAN_58", "Pagaidām šeit nav rakstu!");
define("LAN_59", "Jums Jabūt reģistretam Lietotajam, lai izveidotu rakstu, lūdzu reģistrejietie vai piesakieties sistemā!");
define("LAN_79", "Jaunu Raksti");
define("LAN_80", " Nav Jaunu Rakstu");
define("LAN_81", "Slēgtas Tēmas");
define("LAN_180", "Meklēt");
define("LAN_199", "Pastāv Neizlasīti Raksti");
define("LAN_202", "Pielipinats");
define("LAN_203", "Pielipinats/Slēgts");
define("LAN_204", "Jūs <b>Drīkstat</b> uzsākt jaunu temu");
define("LAN_205", "Jūs <b>Nedrīkstat</b> uzsākt jaunu temu");
define("LAN_206", "Jūs <b>Drīkstat</b> pievienot atbildes");
define("LAN_207", "Jūs <b>Nedrīkstat</b> pievienot atbildes");
define("LAN_208", "Jūs <b>Drīkstat</b> labot savus rakstus");
define("LAN_209", "Jūs <b>Nedrīkstat</b> labot savus rakstus");
define("LAN_316", "Iet uz Lapu: ");
define("LAN_317", "Nav");
define("LAN_321", "Uzraugs: ");
define("LAN_395", "[Populārs]");
define("LAN_396", "Paziņojums");
	
define("LAN_397", "Šis forums ir tikai lasāms");
	
define("LAN_398", "Atlīmēt Tēma");
define("LAN_399", "Slēgt Tēmu");
define("LAN_400", "Atslegt Tēmu");
define("LAN_401", "Pielīmēt Tēmu");
define("LAN_402", "Pārvietot Tēmu");
define("LAN_403", "Lēkt uz Forumu");
define("LAN_404", "Šo forumu uzraga");
	
define("LAN_405", "Šobrīd lietotājs pārskata šo forumu");
define("LAN_406", "Šobrīd lietotāji atrodas šajā forumā");
define("LAN_407", "Biedrs");
define("LAN_408", "Ciemiņš");
define("LAN_409", "Biedri");
define("LAN_410", "Ciemiņi");
	
//v.616
define("LAN_411", "Svarīgas Tēmas");
define("LAN_412", "Foruma Tēmas");
define("LAN_431", "Syndicate this forum: rss 0.92");
define("LAN_432", "Syndicate this forum: rss 2.0");
define("LAN_433", "Syndicate this forum: RDF");

define("LAN_434", "Vai esi pārliecinats, ka velies dzēst ar visām atbildēm šo tēmu?");
define("LAN_435", "Dzēst Tēmu");
	
//v.617
define("FORLAN_CLOSE", "Tēma Slēgta.");
define("FORLAN_OPEN", "Tēma Atverta");
define("FORLAN_STICK", "Tēma Pielipinata.");
define("FORLAN_UNSTICK", "Tēma Atlipināta.");
define("FORLAN_6", "Tēma Dzēsta");
define("FORLAN_7", "Atbildes Dzestas");
define("FORLAN_8", "Šeit");
define("FORLAN_9", "Pieteikties vai reģistreties.");
	
define("FORLAN_10", "Sākta Jauna Tēma");
define("FORLAN_11", "Jauni Raksti");
define("FORLAN_12", "Nav Jaunu Rakstu");
define("FORLAN_13", "Jauni Raksti Populārā Tēmā");
define("FORLAN_14", "Nav Jaunu Raksti Populārā Tēmā");
define("FORLAN_15", "Pielipināta Tēma");
define("FORLAN_16", "Slēgta Pielipināta Tēma");
define("FORLAN_17", "Paziņijumu Tēma");
define("FORLAN_18", "Slēgta Tēma");
define('FORLAN_19', '[Biedrs Dzēsis]');
define('FORLAN_20', 'Apakš-forums');
define('FORLAN_21', 'Tēmas');
define('FORLAN_22', 'Jaunakais Raksts');
	
?>