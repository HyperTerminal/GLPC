<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("NT_LAN_FT_1", "Foruma Notikumi");
define("NT_LAN_FO_1", "Foruma Tēmās Raksti");
define("NT_LAN_MP_1", "Foruma Ziņas Pievienotas");
define("NT_LAN_FD_1", "Dzēsta Foruma Tēma");
define("NT_LAN_FP_1", "Dzēsta Foruma Ziņa");
define("NT_LAN_FM_1", "Foruma Tēma Pārvietota");
define("NT_LAN_FO_3", "Foruma Tēmu izveidoja");
define("NT_LAN_FO_4", "Foruma Nosaukums");
define("NT_LAN_FO_5", "Temats");
define("NT_LAN_FO_6", "Ziņa");
define("NT_LAN_FO_7", "Jauna Foruma Tēma");
define("NT_LAN_MP_3", "Foruma Ziņa no");
define("NT_LAN_MP_4", "Foruma Nosaukums");
define("NT_LAN_MP_6", "Ziņa");
define("NT_LAN_MP_7", "Jauna Foruma Ziņa");
define("NT_LAN_FD_3", "Jauna Tēma no");
define("NT_LAN_FD_4", "Nosaukums");
define("NT_LAN_FD_5", "Temats");
define("NT_LAN_FD_6", "Ziņa");
define("NT_LAN_FD_7", "Tēma ir Dzēsta");
define("NT_LAN_FD_8", "Tēmu dzēsa");
define("NT_LAN_FP_3", "Foruma Ziņa no");
define("NT_LAN_FP_4", "Nosaukums");
define("NT_LAN_FP_6", "Ziņa");
define("NT_LAN_FP_7", "Foruma Ziņa ir Dzēsta");
define("NT_LAN_FP_8", "Foruma Ziņu dzēsa");
define("NT_LAN_FM_3", "Foruma Tēmu izveidoja");
define("NT_LAN_FM_4", "Vecais Temats");
define("NT_LAN_FM_5", "Jaunais Temats");
define("NT_LAN_FM_6", "Vecais (ceļš) foruma nosaukums");
define("NT_LAN_FM_7", "Jaunais (galapunkts) foruma nosaukums");
define("NT_LAN_FM_8", "Foruma Tēma ir Parvietota");
define("NT_LAN_FM_9", "Foruma Tēmu pārvietoja");


?>