<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forums");
define("LAN_01", "Forums");
define("LAN_02", "Iet uz lapu");
define("LAN_03", "Aiziet");
define("LAN_04", "Iepriekšējā");
define("LAN_05", "Nākamā");
define("LAN_06", "Reģistrējās");
define("LAN_07", "Dzīvesvieta");
define("LAN_08", "Mājas lapa");
define("LAN_09", "Saites apmeklējumi kopš reģistrācijas");
define("LAN_10", "Uz Augšu");
define("LAN_65", "Lēkt");
define("LAN_66", "Šī Tēma Tagad ir Slēgta");
define("LAN_67", "Raksti");
define("LAN_194", "Ciemiņš");
define("LAN_195", "Kārtas Nr");
define("LAN_321", "Uzraugs:");
define("LAN_389", "Iepriekšējās Tēmas");
define("LAN_390", "Nākamās Tēmas");
define("LAN_391", "Izsekot Tēmu");
define("LAN_392", "Atcelt Tēmas Izsekošānu");
define("LAN_393", "Ātrā Atbilde");
define("LAN_394", "Apskatīt");
define("LAN_395", "Atbildēt Tēmā");
define("LAN_396", "Mājas lapa");
define("LAN_397", "Epasts");
define("LAN_398", "Konts");
define("LAN_399", "Vēstules");
define("LAN_400", "Latbot");
define("LAN_401", "Citāts");
define("LAN_402", "Autors");
define("LAN_403", "Raksts");
define("LAN_404", "Nav Iepriekšējo Tēmu");
define("LAN_405", "Nav Nākamo Tēmu");
define("LAN_406", "Uzraugs: Labot");
define("LAN_435", "Uzraugs: Dzēst");
define("LAN_408", "Uzraugs: Pārvietot");
define("LAN_409", "Vai esi pārliecināts, ka velies dzēst, un arī visas atbildes?");
define("LAN_410", "Vai esi pārliecināts, ka vēlies dzēst atbildi?");
define("LAN_411", "Raksnieks");
define("LAN_412", "Nosaukums");
define("LAN_413", "Ziņot");
define("LAN_414", "Ziņot par šo Tēmu Uzraugam");
define("LAN_415", "Tēmas Nosaukums");
define("LAN_416", "Ievadi savu ziņojumu");
define("LAN_417", "Admin tiks informēta par šo pavedienu. Jūs varat ievietot ziņojumu, paskaidrojot, kas no Jūsu atrastā ir nosodāms.");
define("LAN_418", "<b>Neizmantojiet</b> šo formu lai sazinātos ar adminu citos jautajumos!");
define("LAN_419", "Sūtīt Ziņojumu");
define("LAN_420", "Apskatīt Rakstu");
define("LAN_421", "Ziņojums par Foruma Tēmu no");
define("LAN_422", "Par šo rakstu ziņots no");
define("LAN_423", "Ziņa netika nosūtīta.");
define("LAN_424", "Par rakstu tika pažiņots Uzraugam.<br />Paldies!");
define("LAN_425", "Ziņa no");
define("LAN_426", "Tēmā ziņoti raksti:");
define("LAN_427", "Kļūda sūtot pastu");
define("LAN_428", "Par rakstu Tika paziņots");
define("LAN_429", "Atgriezties uz Forumu");
define("LAN_430", "aptauja");
define("FORLAN_26", "Atbilde dzesta");
define("FORLAN_10", "Uzsākt Jaunu Tēmu");
define("LAN_29", "Labots");
define("LAN_431", "Syndicate šo tēmu: rss 0.92");
define("LAN_432", "Syndicate šo tēmu: rss 2.0");
define("LAN_433", "Syndicate šo tēmu: RDF");
define("FORLAN_101", "Epasts Tēmau");
define("FORLAN_102", "Printēt Apskatu");
define("FORLAN_103", "[Biedrs Dzēsis]");
define("FORLAN_104", "Tēma Nav Atrasta!");
define("FORLAN_HIDDEN", "SLĒPTS - PIETEIKŠANĀS UN ATBILDES UZ REVEAL");


?>