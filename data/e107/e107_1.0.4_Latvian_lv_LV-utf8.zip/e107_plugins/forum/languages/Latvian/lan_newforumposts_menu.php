<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
	
define("NFP_1", "Visas jaunākās ziņas kuras ir ārpus jūsu lietotāja klases, nevar jums parādīt.");
define("NFP_2", "Nav rakstu pagaidām!");
define("NFP_3", "Jaunā Foruma Raksta izvēlnes konfigurācija saglabāta");
define("NFP_4", "Virsraksts");
define("NFP_5", "Rakstu skaits kurus attēlot?");
define("NFP_6", "Rakstuzīmju skaitu attēlot?");
define("NFP_7", "Postfix priekš pārāk gara raksta?");
define("NFP_8", "Rādīt orģinālo Tēmu izvelnē?");
define("NFP_9", "Atjaunoti Uzstādījumi");
define("NFP_10", "Jaunais Forums Rakstu izvēlnes konfigurācija");
define("NFP_11", "Raksnieks");
define("NFP_12", "Maksimālais ilgums parādītas rakstā");
define("NFP_13", "Izmantot nulli klusā vietā, iestatot vērtību dienām samazinās datubāzi laiku aizņemtas vietas");
	
?>