<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Foruma Statistika");

define("FSLAN_1", "Galvenie");
define("FSLAN_2", "Forumi atvērti");
define("FSLAN_3", "Atverti priekš");
define("FSLAN_4", "Visi Raksti");
define("FSLAN_5", "Foruma Tēmas");
define("FSLAN_6", "Foruma Atbildes");
define("FSLAN_7", "Foruma Tēmas Skatītas");
define("FSLAN_8", "Datubāzes izmērs (Foruma tabulas tikai)");
define("FSLAN_9", "Vidējais rindu garums priekš foruma");
define("FSLAN_10", "Vissaktīvakā Tēma");
define("FSLAN_11", "Rank");
define("FSLAN_12", "Tēma");
define("FSLAN_13", "Atbildes");
define("FSLAN_14", "Uzsāka");
define("FSLAN_15", "Datums");
define("FSLAN_16", "Visskatītākā Tēma");
define("FSLAN_17", "Apskati");
define("FSLAN_18", "Top raksnieks");
define("FSLAN_19", "Vārds");
define("FSLAN_20", "Raksti");
define("FSLAN_21", "Top Tēmu uzsācēji");
define("FSLAN_22", "Top Atbildes");
define("FSLAN_23", "Foruma statistika");
define("FSLAN_24", "Vidējais Rakstu skaits dienā");

?>