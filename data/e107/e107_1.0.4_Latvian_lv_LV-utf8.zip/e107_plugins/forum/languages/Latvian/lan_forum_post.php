<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Forums");
define("LAN_01", "Forums");
define("LAN_02", "Atbildot uz:");
define("LAN_03", "Jauna Tēma");
define("LAN_1", "Normāli");
define("LAN_2", "Pielipinata");
define("LAN_3", "Paziņojums");
define("LAN_4", "Pievienot Aptauju");
define("LAN_5", "Aptaujas Jautajums:");
define("LAN_6", "Pievienot Jaunu Opciju");
define("LAN_7", "Balsošanas Opcijas:");
define("LAN_8", "Atļaut atbildes no visiem");
define("LAN_9", "Atļaut atbildes tikai no biedriem");
define("LAN_10", "Pieteikties");
define("LAN_11", "Atcerēties mani");
define("LAN_16", "Lietotajvārds:");
define("LAN_17", "Parole:");
define("LAN_20", "Kļūda");
define("LAN_27", "Jūs atstajāt pieprasītos laukus tukšus");
define("LAN_28", "Jūs neko neievadījāt ..");
define("LAN_29", "Labots");
define("LAN_45", "Šie forumi var iegūt tikai, lai ar reģistrējies un ielogojies biedriem, lūdzu, noklikšķiniet");
define("LAN_60", "Sākt Jaunu Tēmu");
define("LAN_61", "Nosaukums:");
define("LAN_62", "Temats:");
define("LAN_63", "Raksts:");
define("LAN_64", "Iesniegt Jaunu Tēmu");
define("LAN_73", "Atbilde:");
define("LAN_74", "Atbildot uz Tēmu");
define("LAN_77", "Atjaunot Tēmu");
define("LAN_78", "Atjaunot Atbildi");
define("LAN_94", "Rakstīja");
define("LAN_95", "Neautorizēts");
define("LAN_96", "Jūs nēesat autorizēts priekš labošānas");
define("LAN_100", "Tēmas Raksti");
define("LAN_101", "Jaunākais");
define("LAN_102", " atbildes");
define("LAN_103", "Parskatīt pabeigtu sarakstu (Tiks atvērts jaunā logā)");
define("LAN_133", "Paldies");
define("LAN_174", "Reģistrējies");
define("LAN_175", "Piesakies");
define("LAN_212", "Aizmirsi Paroli?");
define("LAN_310", "Nevar pieņemt rakstu, ka lietotājvārds ir reģistrēta - ja tas ir jūsu lietotājvārds lūdzu piesakieties.");
define("LAN_311", "Anonīms");
define("LAN_322", "Rakstīja:");
define("LAN_323", "Pārskats");
define("LAN_324", "Jūsu Ziņa Tika veiksmīgi Pievienota");
define("LAN_325", "Spied te lai apskatītu ziņu");
define("LAN_326", "Spied te lai atgrieztos uz forumu");
define("LAN_327", "Pārskats");
define("LAN_380", "Ja jūs vēlaties saņemt paziņojumu uz e-pastu, kad atbilde tiek publicēta jūsu tēmā lūdzu, atzīmējiet rūtiņu");
define("LAN_381", "Forumā Atbilde no");
define("LAN_382", "Rakstu izveidoja:");
define("LAN_383", "Lūdzu apmeklējiet sekojošo adresi lai apskatīti pilnībā ...");
define("LAN_384", "Foruma Atbilde");
define("LAN_385", "Raksts:");
define("LAN_386", "Ja nevelaties pievienot aptauju, lūdzu atstājiet laukus tukšus");
define("LAN_387", "Aiziet");
define("LAN_388", "Uz Augšu");
define("LAN_389", "DubultRaksts ir Aizlliegts ...");
define("LAN_390", "Pievienots fails / bilde");
define("LAN_391", "Izvēles");
define("LAN_392", "Failu ko Pievienot");
define("LAN_393", "<b>Ņemiet vērā</b><br />Atļautos faila paplašinajumus:");
define("LAN_394", "Jebkuri citi faili tiks nekavejoties dzēsti.");
define("LAN_395", "Maksimālais izmērs");
define("LAN_396", " bytes");
define("LAN_397", "Šī Tēma ir Slēgta.");
define("LAN_398", "Šī Tēma ir Tikai Lasāma");
define("LAN_399", "Jums nav atļaujas rakstīt šajā tēmā");
define("LAN_400", "Rakstīt tēmā kā");
define("LAN_401", "Lēkt");
define("LAN_402", "Aptauja");
define("LAN_403", "Paziņojums");
define("LAN_404", "Pielipināts");
define("LAN_405", "Forums");
define("LAN_406", "Au:");
define("LAN_407", "Novirza");
define("LAN_408", "Ja jūsu pārlūks neatbalta novirzīšanu, Lūdzu spiediet");
define("LAN_409", "ŠEIT");
define("LAN_410", "lai tiktu novirzīts");
define("LAN_411", "šeit");
define("LAN_412", "lai dotos uz reģistrācijas lapu.");
define("LAN_413", "Jūsu aptauja veiksmīgi izveidota.");
define("LAN_414", "Apskatīt aptauju");
define("LAN_415", "Atbilde veiksmīgi pievienota.");
define("LAN_416", "Pievienot Failu");
define("LAN_417", "Pievienot Citu Failu");
define("POLL_506", "Atļaut vairākas izvēles?");
define("POLL_507", "Jā");
define("POLL_508", "Nē");
define("LAN_FORUM_1", "Augšupielādes Izslēgtas: ".e_FILE."publiska mape nav rakstama");
define("LAN_FORUM_2", "Dubultraksts");


?>