<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

# Install LANs
define('LAN_FORUM_INSTALL_01', 'Forums');
define('LAN_FORUM_INSTALL_02', 'Šis spraudnis ir pilnībā redzamas forums sistēma.');
define('LAN_FORUM_INSTALL_03', 'Konfigurēt forumu');
define('LAN_FORUM_INSTALL_04', 'Jūsu Forums Tagad ir Uzstādīts');
define('LAN_FORUM_INSTALL_05', 'Forums veiksmīgi atjaunots, izmantota versija: %1$s');
define('LAN_FORUM_INSTALL_06', '[forums]');
define('LAN_FORUM_INSTALL_07', '[vairāk...]');

# Config LANs
define('FORLAN_5', 'Aptauja Dzēsta.');
define('FORLAN_6', 'Tēma Dzēsta');
define('FORLAN_7', 'Atbildes Dzēstas');
define('FORLAN_8', 'Dzēšana Atcelta.');
define('FORLAN_9', 'Tēma Pārvietota.');
define('FORLAN_10', 'Pārvietošāna Atcelta.');
define('FORLAN_11', 'Atpakaļ uz Forumu');
define('FORLAN_12', 'Foruma Konfigurācija');
define('FORLAN_13', 'Vai esat pilnīgi pārliecināti, ka vēlaties dzēst šo aptauju? <br/> Kad dzēsta, to <b><u>nevar</u></b> vairāk nolasīt.');
define('FORLAN_14', 'Atcelt');
define('FORLAN_15', 'Apstiprināt raksta dzēšanu');
define('FORLAN_16', 'Apstiprināt Aptaujas dzēšanu');
define('FORLAN_17', 'Raksts no');
define('FORLAN_18', 'Vai esat pilnīgi pārliecināti, ka vēlaties dzēst šo forumu');
define('FORLAN_19', 'Tēma un to saistītie raksti?');
define('FORLAN_20', 'Aptaujas tiks arī dzēstas');
define('FORLAN_21', 'Tad dzēst tos');
define('FORLAN_22', 'rakstus?<br />arī dzēst');
define('FORLAN_23', 'nevarēs</u></b> atgūt');
define('FORLAN_24', 'Pārvietot Tēmas  uz forumu');
define('FORLAN_25', 'Pārvietot Tēmu');
define('FORLAN_26', 'Atbilde dzēsta');
define('FORLAN_27', 'pārvietots');
define('FORLAN_28', 'Nēpārdēvēt tēmas nosaukumus');
define('FORLAN_29', 'Pievienot');
define('FORLAN_30', 'nosaukumam');
define('FORLAN_31', 'Pārsaukt uz:');
define('FORLAN_32', 'Tēmu pārsaukšanas Opcijas:');