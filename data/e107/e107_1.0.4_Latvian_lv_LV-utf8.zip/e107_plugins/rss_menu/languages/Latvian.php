<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("RSS_LAN05", "Vienību skaits (0=neaktīvs)");
define("RSS_MENU_L1", "var sindicēto izmantojot šos rss barotnes.");
define("RSS_MENU_L2", "RSS Barotnes");
define("RSS_MENU_L3", "Mūsu Jaunumi ");
define("RSS_MENU_L4", "Mūsu Komentāri");
define("RSS_MENU_L5", "Mūsu Foruma Tēmas");
define("RSS_MENU_L6", "Mūsu Foruma Raksti");
define("RSS_MENU_L7", "Mūsu Čata Ziņas");
define("RSS_MENU_L8", "Mūsu Kļūdošanas Ziņojumi");
define("RSS_MENU_L9", "Mūsu Lejupielādes");
define("RSS_NEWS", "Jaunumi");
define("RSS_COM", "Komentāri");
define("RSS_ART", "Raksti");
define("RSS_REV", "Pārskati");
define("RSS_FT", "Foruma Tēmas");
define("RSS_FP", "Foruma Raksti");
define("RSS_FSP", "Foruma Īpašie Raksti");
define("RSS_BUG", "Kļūdotava");
define("RSS_FOR", "Forums");
define("RSS_DL", "Lejupielādes");
define("RSS_PLUGIN_LAN_1", "RSS");
define("RSS_PLUGIN_LAN_6", "Barošanas Linki");
define("RSS_PLUGIN_LAN_7", "RSS barotava uz Jaunumiem");
define("RSS_PLUGIN_LAN_8", "RSS barotava uz Lejupielādēm");
define("RSS_PLUGIN_LAN_9", "RSS barotava uz Komentāriem");
define("RSS_PLUGIN_LAN_10", "RSS barotava uz Jaunumu Katagoriju");
define("RSS_PLUGIN_LAN_11", "RSS barotava uz Lejupielāžu Kategoriju");
define("RSS_PLUGIN_LAN_14", "Komentāri");
define("RSS_LAN_ADMINMENU_1", "RSS Opcijas");
define("RSS_LAN_ADMINMENU_2", "Sarakste");
define("RSS_LAN_ADMINMENU_4", "Ievietot");
define("RSS_LAN_ERROR_1", "Nav derīga RSS Barotava<br /><br /><a href='".e_SELF."'><< atgriezieties pie rss barotavu sarakstes</a>");
define("RSS_LAN_ERROR_2", "Jūsu e107_config.php valodas fails satur ï»¿﻿ rakstuzīmes pirms <? rakstuzīmes. Jums vajadzetu noņemt šo ne-utf8 text-editor Ja velaties strādājošu RSS Barotavu");
define("RSS_LAN_ERROR_3", "Nav RSS Barotavas pagaidām<br />Lūdzu izmantojiet Ievietot RSS Barotavu vai izveidojiet tās Manuali");
define("RSS_LAN_ERROR_4", "RSS Barotava nav pieejama!");
define("RSS_LAN_ERROR_5", "Šis RSS ievade nepastāv");
define("RSS_LAN_ERROR_6", "Te nav RSS ievietota");
define("RSS_LAN_ERROR_7", "Daži pieprasītie lauku trūkst!");
define("RSS_LAN_ADMIN_1", "Esošās RSS Barotavas");
define("RSS_LAN_ADMIN_2", "Id");
define("RSS_LAN_ADMIN_3", "Ceļš");
define("RSS_LAN_ADMIN_4", "Nosaukums");
define("RSS_LAN_ADMIN_5", "Url");
define("RSS_LAN_ADMIN_6", "Teksts");
define("RSS_LAN_ADMIN_7", "Limits");
define("RSS_LAN_ADMIN_8", "Redzamība");
define("RSS_LAN_ADMIN_9", "Tips");
define("RSS_LAN_ADMIN_10", "rss barotava izveidot");
define("RSS_LAN_ADMIN_11", "rss barotava ievietots");
define("RSS_LAN_ADMIN_12", "Tēmas id");
define("RSS_LAN_ADMIN_13", "Iekļaut Citi-Jaunumi iekš Jaunumu Barotavas?");
define("RSS_LAN_ADMIN_14", "Ieslēgt");
define("RSS_LAN_ADMIN_15", "Atzīmējiet saites, lai atzīmētu priekš ievietošanas ...");
define("RSS_LAN_ADMIN_16", "Ievietot?");
define("RSS_LAN_ADMIN_17", "Ievietot atzīmētos linkus");
define("RSS_LAN_ADMIN_18", "rsss barotavas ievietotas");
define("RSS_LAN_ADMIN_21", "aktīvs un redzams rss barības sarakstā");
define("RSS_LAN_ADMIN_22", "aktīvs un neredzams rss barības sarakstā");
define("RSS_LAN_ADMIN_23", "Neaktīvs");
define("RSS_LAN_ADMIN_26", "Atzīmēt visu");
define("RSS_LAN_ADMIN_27", "Neatzīmēt neko");
define("RSS_LAN_ADMIN_31", "rss ieraksti ierobežot atjaunināts");
define("RSS_LAN_0", "RSS");
define("RSS_LAN_2", "@nospam.com");
define("RSS_LAN_3", "noauthor@nospam.com");


?>