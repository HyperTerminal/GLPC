<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("NFPM_LAN_1", "Tēmas");
define("NFPM_LAN_2", "Raksnieks");
define("NFPM_LAN_3", "Skatīts");
define("NFPM_LAN_4", "Atbildes");
define("NFPM_LAN_5", "Jaunakais");
define("NFPM_LAN_6", "Tēmas");
define("NFPM_LAN_7", "no");
	
define("NFPM_L1", "Šis Spraudnis attēlo Jaunakos foruma rakstus");
define("NFPM_L2", "Jaunākie Foruma Raksti");
define("NFPM_L3", "Konfigurēt lūdzu, klikšķiniet uz saiti plugins sadaļā admin sākumlapu");
define("NFPM_L4", "Kurā Zonā aktivizet?");
define("NFPM_L5", "Neaktīvs");
define("NFPM_L6", "Lapas Augšā");
define("NFPM_L7", "Lapas Apakšā");
define("NFPM_L8", "Virsraksts");
define("NFPM_L9", "Jauno Rakstu Attelolšanas Skaits?");
define("NFPM_L10", "Attēlot iekšā Tinšā kastē?");
define("NFPM_L11", "Kastes Augstums");
define("NFPM_L12", "Jauno Foruma Rakstu Konfiguracija");
define("NFPM_L13", "Atjaunot Iestatījumus");
define("NFPM_L14", "Jaunie Foruma Raksta Iestatījumi Atjaunoti");
define("NFPM_L15", "Pārbaudiet, lai parādītu jaunākos foruma ierakstus. <br /> Noklusētā ir jaunākās tēmas.");
define('NFPM_L16', '[Biedrs Dzēsis]');
define('NFPM_L17', 'Jaunie Raksti Popularās Tēmas');
define('NFPM_L18', 'Jaunie Raksti');
define('NFPM_L19', 'Nav Jaunu rakstu Populara Tēmā');
define('NFPM_L20', 'Nav Jaunu Rakstu');
define('NFPM_L21', 'Pielipinātas Tēmas');
define('NFPM_L22', 'Slēgtas Pielipinatas Tēmas');
define('NFPM_L23', 'Paziņojumi');
define('NFPM_L24', 'Slēgtas Tēmas');
	
?>