<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("ONLINE_L1", "Ciemiņi: ");
define("ONLINE_L2", "Biedri: ");
define("ONLINE_L3", "Šajā Lapā: ");
define("ONLINE_L4", "Pieteicies");
define("ONLINE_L5", "Biedri");
define("ONLINE_L6", "Jaunakais");
define("TRACKING_MESSAGE", "Izsekošana ir izslēgta, lūdzu ieslēdziet to [link=".e_ADMIN."users.php?options]šeit[/link][br]");   
?>