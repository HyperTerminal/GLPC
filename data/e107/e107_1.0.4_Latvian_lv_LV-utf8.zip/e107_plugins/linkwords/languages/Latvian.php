<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
	
define("LWLAN_1", "Lauki atstāti tukši.");
define("LWLAN_2", "Saite vārds saglabāts.");
define("LWLAN_3", "Saite vārds atjaunots.");
define("LWLAN_4", "Nav Saites vārds izveidoti pagaidām.");
define("LWLAN_5", "Vārdi");
define("LWLAN_6", "Saite");
define("LWLAN_7", "Aktīvs?");
define("LWLAN_8", "Opcijas");
define("LWLAN_9", "Jā");
define("LWLAN_10", "Nē");
define("LWLAN_11", "Esošie Saites vārdi");
define("LWLAN_12", "Jā");
define("LWLAN_13", "Nē");
define("LWLAN_14", "Iesniegt Saites vārdu");
define("LWLAN_15", "Atjaunot Saites vārdus");
define("LWLAN_16", "Labot");
define("LWLAN_17", "Dzēst");
define("LWLAN_18", "Vai esi pārliecināts, ka velies dzēst šos Saites vārdus?");
define("LWLAN_19", "Saites vārds dzēsts");
define("LWLAN_20", "neizdevas atrast Saites vardus");
define("LWLAN_21", "Vardiem autosaites (vai ar komatu atdalīti vardu saraksts)");
define("LWLAN_22", "Aktivizēt?");
define("LWLAN_23", "Saites vārdu administracija");
define("LWLAN_24", "Veidot Vardus");
define("LWLAN_25", "Opcijas");
define("LWLAN_26", "Kurās vietas ieslēgt Saites vārdus");
define("LWLAN_27", "Šis ir 'context' priekš attēlota teksta");
define("LWLAN_28", "Lapa kurā attelos Saites vārdus");
define("LWLAN_29", "Pats formāts kā izvēlnes redzamību kontroli. Viena atbilstība katrā līnijā. Norādiet daļēju vai pilnīgu URL. Beidzas ar '!' precīzai sakritības gala daļu no saiti");
define("LWLAN_30", "Saglabāt Opcijas");
define("LWLAN_31", "Labot/Pievienot");
define("LWLAN_32", "Saites vārdu Opcijas");
define("LWLAN_33", 'Virsrakstu Zonas');
define("LWLAN_34", 'Kopsavilkums');
define("LWLAN_35", 'Ķermeņa teksts');
define("LWLAN_36", 'Apraksts (saites u.c)');
define("LWLAN_37", 'Legacy zonas');
define("LWLAN_38", 'Klikšķinamas Saites');
define("LWLAN_39", 'Neapstrādājams Teksts');
define("LWLAN_40", 'Biedru Ievadīti Nosaukumi (piem: forumā)');
define("LWLAN_41", 'Biedru Ievadīti Ķermeņa Teksti (piem: forumā)');


define("LWLANINS_1", "Saites vārds");
define("LWLANINS_2", "Šis spraudnis aizvietos saite noteiktos vārdus ar noteiktu saiti");
define("LWLANINS_3", "Konfigurēt Saites vārdus");
define("LWLANINS_4", "Konfigurēt lūdzu, klikšķiniet uz saiti plugins sadaļā admin sākumlapā");

?>