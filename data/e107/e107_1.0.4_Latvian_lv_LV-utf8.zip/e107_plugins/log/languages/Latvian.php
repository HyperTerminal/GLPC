<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("PAGE_NAME", "Statistika");

define("ADSTAT_L1", "Šis spraudnis reģistrē visas vizītes uz jūsu vietni, un veido detalizētus statistiskos ekranus, pamatojoties uz ieguto informāciju,.");
define("ADSTAT_L2", "Statistikas Spraudnis veiksmīgi uzstūdīts. Lai atjaunotu visas statistikas dodies uz <a href='".e_PLUGIN."log/update_routine.php'>Statistikas Atjaunotājs</a>.");
define("ADSTAT_L3", "Statistikas");
define("ADSTAT_L4", "Jums nav atļaujas skatīt šo lapu");
define("ADSTAT_L5", "Šajā lapā iezīmes ir atspējota.");
define("ADSTAT_L6", "Saites Statistika");
define("ADSTAT_L7", "Sāda veida Statistika netiek vākta.");
define("ADSTAT_L8", "Šodienas");
define("ADSTAT_L9", "Visu Laiku");
define("ADSTAT_L10", "Dienas");
define("ADSTAT_L11", "Mēneša");
define("ADSTAT_L12", "Pārlūka");
define("ADSTAT_L13", "Operētāju Sistēmas");
define("ADSTAT_L14", "Domaina");
define("ADSTAT_L15", "Ekrāna Izšķirtspeja / Krāsu dziļums");
define("ADSTAT_L16", "Pārsūtījumi");
define("ADSTAT_L17", "Meklēšanas Dzineji");
define("ADSTAT_L18", "Nesenie Apmeklētaji");
define("ADSTAT_L19", "Lapa");
define("ADSTAT_L20", "Šodienas Apmeklējumi");
define("ADSTAT_L21", "Kopā");
define("ADSTAT_L22", "Unikals");
define("ADSTAT_L23", "Kopejie Apmeklējumi");
define("ADSTAT_L24", "Kopejie Unikalie Apmeklējumi");
define("ADSTAT_L25", "Pagaidām Nav Statistikas");
define("ADSTAT_L26", "Pārlūks");
define("ADSTAT_L27", "Operētajsistema");
define("ADSTAT_L28", "Valstis / Domains");
define("ADSTAT_L29", "Ekrāna Izšķirtspēja");
define("ADSTAT_L30", "Saites Pārsūtījumi");
define("ADSTAT_L31", "Meklēšanas Dzineji");
define("ADSTAT_L32", "Pārsūtīts no");
define("ADSTAT_L33", "Apmeklets pēdējo");
define("ADSTAT_L34", "Apmeklējumi");
define("ADSTAT_L35", "Unikali apmeklējumi");
define("ADSTAT_L36", "dienas, lapās");
define("ADSTAT_L37", "apmeklejumi, mēnesī");
define("ADSTAT_L38", "unikālu apmeklejumi, mēnesī");
define("ADSTAT_L39", "aizvakt šo ierakstu");
define("ADSTAT_L40", "dienas");
define("ADSTAT_L41", "Kļūda");
define("ADSTAT_L42", "Nav Mēneša Statistikas pagaidām.");

define("ADSTAT_L43", "Šodienas lapu kļūdas");
define("ADSTAT_L44", "Visu laiku lapu kļūdas");
define("ADSTAT_L45", "Statistika dzēsta priekš: ");
define("ADSTAT_L46", "Piezīme: Visi stati priekš šodienas tiks dzēsti");
define("ADSTAT_L47", "Stati netika atrasti priekš: ");
define("ADSTAT_L48", "");
define("ADSTAT_L49", "");
define("ADSTAT_L50", "");

?>