<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
	
define("ADSTAT_ON", "Ieslēgts");
define("ADSTAT_OFF", "Izslēgts");
define("ADSTAT_L1", "Šis spraudnis būs jāreģistrē visus vizītes uz jūsu vietni, un veidot detalizētus statistiskos ekrāni, pamatojoties uz iegūto informāciju.");
define("ADSTAT_L2", "Statistika Logger ir veiksmīgi instalēta. Lai aktivizētu, lūdzu dodieties uz config ekrānu un noklikšķiniet uz Aktivizēt. <br /> <b>Jāiestata atļaujas par e107_plugins/log/logs mapes uz 777 (chmod 777)</b>");
define("ADSTAT_L3", "Statistikas Logging");
define("ADSTAT_L4", "Aktivizēt Statistikas logging");
define("ADSTAT_L5", "Statistikas tips");
define("ADSTAT_L6", "Pārlūks");
define("ADSTAT_L7", "Operētājsistēma");
define("ADSTAT_L8", "Ekrāna Izšķirtspēja / Krāsas Dziļums");
define("ADSTAT_L9", "Valstis/domains apmeklējumi no");
define("ADSTAT_L10", "Parsūtījumi");
define("ADSTAT_L11", "Meklēšanas Dzinejiema");
define("ADSTAT_L12", "Atjaunot Status");
define("ADSTAT_L13", "Šis izdzēsīs status - Pratīgi!");
define("ADSTAT_L14", "Lapu skaits");
define("ADSTAT_L15", "Atjaunot Uzstādījumus");
define("ADSTAT_L16", "Saites statistikas iestatījumi");
define("ADSTAT_L17", "Statistikas iestatījumi atjaunoti");
define("ADSTAT_L18", "Atļaut galvenos saites statistikas piekļuvei ...");
define("ADSTAT_L19", "Nesenie apmeklētaji");
define("ADSTAT_L20", "Skaitīt Adminu apmeklejumus");
define("ADSTAT_L21", "Maksimalais skaits ko attelot statistikas lapā");
define("ADSTAT_L22", "Palaist atjaunošanas routine");
define("ADSTAT_L23", "žurnālus no iepriekšējās versijas E107 konstatēti, atjaunināt tos šeit");
define("ADSTAT_L24", "Iet lai atjaunotu skriptu");
define("ADSTAT_L25", "Izvelētie stati atjaunoti");
define("ADSTAT_L26", "Noņemt lapas");
define("ADSTAT_L27", "Ja jūsu stats ir nepareizas lapas, jūs varat noņemt tos šeit");
define("ADSTAT_L28", "Atvērt lapu");
define("ADSTAT_L29", "Lapas Nosaukums");
define("ADSTAT_L30", "Atzīmēt lai noņemtu");
define("ADSTAT_L31", "Noņemt izvelētās lapas");
define("ADSTAT_L32", "Lapu uzkopšana");
define("ADSTAT_L33", "Konfigurēt statistikas Logging");
define("ADSTAT_L34", "Saites Stati");
define("ADSTAT_L35", "Skatīt kompakto pārlūka datus stats");

define('ADSTAT_L38', "jums jauzstada e107_plugins/log/logs mapi par rakstāmu");	// Constant compatible with 0.8
?>