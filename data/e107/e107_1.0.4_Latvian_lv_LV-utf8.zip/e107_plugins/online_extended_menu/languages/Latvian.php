<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Viesi:");
define("ONLINE_EL2", "Lietotāji:");
define("ONLINE_EL3", "Šajā Lapā:");
define("ONLINE_EL4", "Ienākuši");
define("ONLINE_EL5", "Lietotāji");
define("ONLINE_EL6", "Jaunākais Lietotājs");
define("ONLINE_EL7", "skatās");
define("ONLINE_EL8", "Visvairāk Ienākuši Bija:");
define("ONLINE_EL9", "kad");
define("ONLINE_TRACKING_MESSAGE", "Online lietotāju izsekošana ir izslēgts, lūdzu ieslēdziet to [link=".e_ADMIN."users.php?options]Šeit[/link][br]");


?>