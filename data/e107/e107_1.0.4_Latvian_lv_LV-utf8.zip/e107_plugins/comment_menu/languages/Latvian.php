<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CM_L1", "Pagaidām nav komentāru.");
define("CM_L2", "");
define("CM_L3", "Virsraksts");
define("CM_L4", "Komentāru daudzumu ko attēlot?");
define("CM_L5", "Rakstuzīmju skaitu ko attēlot?");
define("CM_L6", "Postfix priekš pārāk gara komentāra?");
define("CM_L7", "Rādīt orģinālo nosaukumu iekš Izvēlnes?");
define("CM_L8", "Komentāru Izvelnes Konfigurācija");
define("CM_L9", "Atjaunot Izvēlnes Iestatījumus");
define("CM_L10", "Izvēlnes Iestatījumi Atjaunoti");
define("CM_L11", "kad");
define("CM_L12", "Au:");
define("CM_L13", "Autors");

?>