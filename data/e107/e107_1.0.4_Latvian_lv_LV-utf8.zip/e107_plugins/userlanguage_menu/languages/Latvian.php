<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UTHEME_MENU_L1", "Uzstādīt Valodu");
define("UTHEME_MENU_L2", "Izvelies Valodu");
define("UTHEME_MENU_L3", "Tabulas");


?>