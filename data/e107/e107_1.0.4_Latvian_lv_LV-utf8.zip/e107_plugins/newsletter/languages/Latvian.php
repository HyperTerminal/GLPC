<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("NLLAN_MENU_CAPTION", "apkārtraksts");

define("NLLAN_01", "apkārtraksts");
define("NLLAN_02", "nodrošina ātru un vienkāršu veidu, kā konfigurēt un nosūtīt biļetenus");
define("NLLAN_03", "Konfigurēt Biļeteni");
define("NLLAN_04", "biļetens spraudnis ir veiksmīgi instalēts Lai konfigurētu, atgrieztos galvenajā admin lapā un noklikšķiniet uz 'izdevuma' In spraudnis sadaļā..");
define("NLLAN_05", "neviens biļeteni vēl nav noteiktas");

define("NLLAN_06", "Nosaukums");
define("NLLAN_07", "abonenti");
define("NLLAN_08", "Iespējas");
define("NLLAN_09", "Vai jūs tiešām vēlaties izdzēst šo biļetenu?");
define("NLLAN_10", "Esošās Biļeteni");

define("NLLAN_11", "Nav biļetenu jautājumi Atrašanās");
define("NLLAN_12", "Jautājums");
define("NLLAN_13", "[Mātes ID] Tēma / nosaukums");
define("NLLAN_14", "nosūtīts?");
define("NLLAN_15", "Iespējas");
define("NLLAN_16", "jā");
define("NLLAN_17", "Ne izsūtīja - noklikšķiniet, lai nosūtītu");
define("NLLAN_18", "Vai jūs tiešām vēlaties, lai pastu šo jautājumu abonentiem?");
define("NLLAN_19", "Vai jūs tiešām vēlaties izdzēst šo biļetenu jautājumu?");
define("NLLAN_20", "Esošās problēmas");
define("NLLAN_21", "Nosaukums");
define("NLLAN_22", "Apraksts");
define("NLLAN_23", "Header");
define("NLLAN_24", "kājene");
define("NLLAN_25", "Update biļetens");
define("NLLAN_26", "Izveidot Newsletter");
define("NLLAN_27", "biļetens atjaunināta datu bāzē.");
define("NLLAN_28", "Jaunumi definēts un saglabāti datu bāzē.");
define("NLLAN_29", "neviens biļeteni vēl nav noteiktas.");
define("NLLAN_30", "apkārtraksts");
define("NLLAN_31", "Tēma / nosaukums");
define("NLLAN_32", "Issue skaits");
define("NLLAN_33", "Teksts");
define("NLLAN_34", "Update Pasta");
define("NLLAN_35", "Izveidot adresātu");
define("NLLAN_36", "Update Newsletter jautājums");
define("NLLAN_37", "Izveidot Newsletter jautājums");
define("NLLAN_38", "biļetens atjaunināta datu bāzē.");
define("NLLAN_39", "biļetens jautājums saglabāti datu bāzē - izsūtīt, noklikšķiniet uz laišana izsūtīt pogas Opcijas izvēlnē. ");
define("NLLAN_40", "Mailout pabeigts - jautājums nosūtīts");

define("NLLAN_41", "abonenta (-u).");
define("NLLAN_42", "biļetens svītrots.");
define("NLLAN_43", "biļetens jautājums svītrots.");

define("NLLAN_44", "Jaunumi Front Page");
define("NLLAN_45", "Izveidot Newsletter");
define("NLLAN_46", "Create sūtījumu");
define("NLLAN_47", "Newsletter Options");

define("NLLAN_48", "jūs esat abonējis šo biļetenu - ja jūs vēlaties atrakstīties, lūdzu, noklikšķiniet uz pogas turpmāk.");
define("NLLAN_49", "Vai jūs tiešām vēlaties, lai ANO parakstīties uz šo biļetenu?");
define("NLLAN_50", "Noklikšķiniet uz pogas, lai parakstīties (abonementā adrese ir");
define("NLLAN_51", "Atteikties");
define("NLLAN_52", "Abonēt");
define("NLLAN_53", "Vai jūs tiešām vēlaties abonēt šo biļetenu?");

define("NLLAN_54", "Nosūtot");

define("NLLAN_55", "ID");
define("NLLAN_56", "biļetens ID nav pieejams");
define("NLLAN_57", "Atgriezties uz iepriekšējo lappusi");
define("NLLAN_58", "Error");
define("NLLAN_59", "Nosaukums");
define("NLLAN_60", "E");
define("NLLAN_61", "darbības");
define("NLLAN_62", "Lietotājs ir aizliegta (vai nav pilnībā pievienojusies)!");
define("NLLAN_63", "Kopējais abonentu");
define("NLLAN_64", "Return to Jaunumi SākumLapas");
define("NLLAN_65", "Reģistrētiem pārskats biļetens ID");
?>