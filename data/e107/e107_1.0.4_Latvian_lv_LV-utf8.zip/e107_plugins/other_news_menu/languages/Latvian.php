<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
	
define("TD_MENU_L1", "Citi Jaunumi");
define("TD_MENU_L2", "Citi Jaunumi");
	
?>