<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("FBLAN_01", "Funkciju Kaste");
define("FBLAN_02", "Šis spraudnis ļauj jums, parādīt lodziņu virs jūsu ziņām ar funkcijām / kādas jums patīk tajā. Ziņojumus var vai nu griezās nejauši vai dinamiski izbalējis.");
define("FBLAN_03", "Konfigurēt Funkciju Kasti");
define("FBLAN_04", "Funkciju Kaste spraudnis ir veiksmīgi instalēts. Lai pievienotu ziņas un konfigurēt, atgriezieties galvenajā admin lapā un noklikšķiniet uz funkciju lodziņa ikonas spraudņu sadaļā");
define("FBLAN_05", "Funkciju Kaste pagaidām nav ziņojumu!");
define("FBLAN_06", "Esošās ziņas Funkciju Kastē");
define("FBLAN_07", "Virsraksts");
define("FBLAN_08", "Ziņu teksts");
define("FBLAN_09", "Ziņu redzamība");
define("FBLAN_10", "Izveidot Funkciju Kastē ziņas");
define("FBLAN_11", "Atjaunot Funkciju Kasti");
define("FBLAN_12", "Veids");
define("FBLAN_13", "Nejauši griezties ziņas");
define("FBLAN_14", "Rādīt tikai  šo ziņu");
define("FBLAN_15", "Ziņa pievienota datubazē");
define("FBLAN_16", "Ziņa atjaunota datubazē");
define("FBLAN_17", "lauki atstātu tukši");
define("FBLAN_18", "Funkcijas Kastes ziņa dzesta");
define("FBLAN_19", "Opcijas");
define("FBLAN_20", "Labot");
define("FBLAN_21", "Dzēst");
define("FBLAN_22", "Attēlošanas Veids");
define("FBLAN_23", "Iekšā kastē");
define("FBLAN_24", "Vienkārši");
define("FBLAN_25", "Veidne");
define("FBLAN_26", "Jūs varat izmantot citu veidni katrai ziņai pievienot veidnese107_plugins/featurebox/templates/ mapē");


?>