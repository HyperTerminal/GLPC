<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("LOGIN_MENU_L1", "Lietotajvārds: ");
define("LOGIN_MENU_L2", "Parole: ");
define("LOGIN_MENU_L3", "Reģistrēties");
define("LOGIN_MENU_L4", "Aizmirsi Paroli?");
define("LOGIN_MENU_L5", "Sveicināts");
define("LOGIN_MENU_L6", "Atcerēties");
define("LOGIN_MENU_L7", "Pieprasītais lietotāja identifikātors nav atpazīts (iespējams bojāti cookie)<br />Lūdzu <a href=\"".e_BASE."index.php?logout\">Spiediet te</a> lai iznīcinatu cookie.");
define("LOGIN_MENU_L8", "Iziet");
define("LOGIN_MENU_L9", "Pieteikšanās Kļūda");
define("LOGIN_MENU_L10", "Uzturēšanas paziņojums ir ieslēgts - tas nozīmē, normāli apmeklētāji tiek novirzīti uz sitedown.php. Lai atjaunotu paziņojumu dodies uz admin/maintenance.");
define("LOGIN_MENU_L11", "Admina Zona");
define("LOGIN_MENU_L12", "Uzstādījumi");
define("LOGIN_MENU_L13", "Tavs Konts");
define("LOGIN_MENU_L14", "Jaunums");
define("LOGIN_MENU_L15", "Jaunumi");
define("LOGIN_MENU_L16", "Čata Ziņa");
define("LOGIN_MENU_L17", "Čata Ziņās");
define("LOGIN_MENU_L18", "Komentārs");
define("LOGIN_MENU_L19", "Komentāri");
define("LOGIN_MENU_L20", "Foruma Raksts");
define("LOGIN_MENU_L21", "Foruma Raksti");
define("LOGIN_MENU_L22", "Jauns Biedrs");
define("LOGIN_MENU_L23", "Jauni Biedri");
define("LOGIN_MENU_L24", "Spied te, lai apskatītu jaunumu sarakstu");
define("LOGIN_MENU_L25", "Kopš Jūsu pēdējās apmeklējuma reizes ir jauni notikumi");
define("LOGIN_MENU_L26", "no");
define("LOGIN_MENU_L27", "un");
define("LOGIN_MENU_L28", "Pieteikties");

define("LOGIN_MENU_L29", "Jauns Raksts");
define("LOGIN_MENU_L30", "Jauni Raksti");

// New config options
define('LOGIN_MENU_L31', 'Rādīt Jaunos Jaunuma Rakstus');
define('LOGIN_MENU_L32', 'Rādīt Jaunos Rakstus');
define('LOGIN_MENU_L33', 'Rādīt Jaunās Čata ziņas');
define('LOGIN_MENU_L34', 'Rādīt Jaunos Komentārus');
define('LOGIN_MENU_L35', 'Rādīt Jaunos Foruma Rakstus');
define('LOGIN_MENU_L36', 'Rādīt Jaunos Biedrus');


define('LOGIN_MENU_L39', 'Iziet no Admina Zonas');
define("LOGIN_MENU_L40", "Pārsūtīt Aktivizacijas Epastu");
define("LOGIN_MENU_L41", "Pieteikšanas Uzstādījumi");

?>