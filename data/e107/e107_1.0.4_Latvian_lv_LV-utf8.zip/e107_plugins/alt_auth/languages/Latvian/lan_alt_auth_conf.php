<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("LAN_ALT_2", "Pašreizējo auterizācijas tips");
define("LAN_ALT_3", "Izvelies Alternatīvu autorizācijas Titu");
define("LAN_ALT_4", "Konfigurēt parametrus priekš");
define("LAN_ALT_5", "Konfigurēt autorizācijas parametrus");
define("LAN_ALT_6", "Neizdevās savienojuma darbība");
define("LAN_ALT_7", "Ja savienojums ar alternatīvo metodi neizdodas, kā vajadzētu, ka jārīkojas?");
define("LAN_ALT_8", "Lietotājs nav atrasts darbība");
define("LAN_ALT_9", "Ja lietotājvārds netiek konstatēts, izmantojot alternatīvo metodi, kā būtu jārīkojas?");
define("LAN_ALT_10", "Pieteikšanās Kļūda!");
define("LAN_ALT_11", "Izmantot E107 lietotāja tabulu");
define("LAN_ALT_PAGE", "alternatīva autentifikācijas");


?>