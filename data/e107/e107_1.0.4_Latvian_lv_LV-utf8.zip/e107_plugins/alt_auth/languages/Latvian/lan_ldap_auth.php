<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("LDAPLAN_1", "Servera Adrese");
define("LDAPLAN_2", "Bāzes DN vai Domēna <br /> Ja LDAP - ievadiet BaseDN <br /> Ja AD - ievadiet domēnu");
define("LDAPLAN_3", "LDAP Pārlūkošana lietotājs <br /> Pilns kontekstu lietotāju, kurš ir spējīgs meklēt direktoriju.");
define("LDAPLAN_4", "LDAP Pārlūkošana paroli <br /> parole LDAP pārlūkošanas lietotājam");
define("LDAPLAN_5", "LDAP Versija");
define("LDAPLAN_6", "Konfigurēt LDAP autorizāciju");
define("LDAPLAN_7", "eDirectory meklēšanas filtri:");
define("LDAPLAN_8", "Tas tiks izmantots, lai nodrošinātu lietotājvārds ir pareizā kokā,<br />ie \'(objectclass=inetOrgPerson)\'");
define("LDAPLAN_9", "Pašreizējais meklēšanas filtru būs:");
define("LDAPLAN_10", "BRĪDINĀJUMS: Ja LDAP modulis šobrīd nav pieejams, iestatot auth metodi LDAP, iespējams, nedarbosies!");
define("LDAPLAN_11", "Servera Tips");


?>