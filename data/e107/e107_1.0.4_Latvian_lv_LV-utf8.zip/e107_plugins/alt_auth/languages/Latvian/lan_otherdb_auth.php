<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Datubāzes Tips:");
define("OTHERDB_LAN_2", "Serveris:");
define("OTHERDB_LAN_3", "Lietotajvards:");
define("OTHERDB_LAN_4", "Parole:");
define("OTHERDB_LAN_5", "Datubāze");
define("OTHERDB_LAN_6", "Tabula");
define("OTHERDB_LAN_7", "Lietotajvārda lauks:");
define("OTHERDB_LAN_8", "Paroles Lauks:");
define("OTHERDB_LAN_9", "Paroles Metode:");
define("OTHERDB_LAN_10", "Konfigurēt CituDB auth");
define("OTHERDB_LAN_11", "** Šādi lauki nav vajadzīgi, ja, izmantojo E107 datubāzi");


?>