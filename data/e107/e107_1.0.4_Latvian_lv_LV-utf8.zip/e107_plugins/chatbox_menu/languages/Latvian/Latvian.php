<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CHATBOX_L1", "Nevar pieņemt rakstu, no lietotājvārda kas ir reģistrēts - ja tas ir jūsu lietotājvārds lūdzu piesakieties un turpiniet.");
define("CHATBOX_L2", "Čats");
define("CHATBOX_L3", "Jums jāpiesakas lai komentētu, ja nēesat reģistrēts Lūdzu izdariet to <a href='".e_BASE."signup.php'>šeit</a>");
define("CHATBOX_L4", "Iesniegt");
define("CHATBOX_L5", "Atjaunot");
define("CHATBOX_L6", "[Admins Bloķējis]");
define("CHATBOX_L7", "Atbloķēt");
define("CHATBOX_L8", "Info");
define("CHATBOX_L9", "Bloķēt");
define("CHATBOX_L10", "Dzēst");
define("CHATBOX_L11", "Pagaidam nav ziņu, esi pirmais!");
define("CHATBOX_L12", "Apskatīt visas Ziņas");
define("CHATBOX_L13", "Uzraudzīt Čatu");
define("CHATBOX_L14", "Emocijas");
define("CHATBOX_L15", "Iesniegtā ziņa ir pārāk gara vai tukša!");
define("CHATBOX_L16", "Anonīms");
define("CHATBOX_L17", "Dubultraksts!");
define("CHATBOX_L18", "Čata ziņa uzraudzīta");
define("CHATBOX_L19", "Jūs drīkstat pievienot katras ".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." sekundes");
define("CHATBOX_L20", "Čats (Visi raksti)");
define("CHATBOX_L21", "Čata Raksti");
define("CHATBOX_L22", "ieslēgts");
define("CHATBOX_L23", "Kļūda!");
define("CHATBOX_L24", "Jums nav attiecīgo atļauju, lai apskatītu šo lapu!");
define("CHATBOX_L25", "[Ziņa Bloķēja Admins ]");
define("CHATBOX_L26", "Labot");
define("NT_LAN_CB_1", "Čata notikumi");
define("NT_LAN_CB_2", "Ziņa pievienota");
define("NT_LAN_CB_3", "Autors");
define("NT_LAN_CB_4", "IP Adrese");
define("NT_LAN_CB_5", "Ziņa");
define("NT_LAN_CB_6", "Čata ziņas autors");


?>