<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Čata iestatījumi atjaunoti.");
define("CHBLAN_2", "Uzraudzīts.");
define("CHBLAN_3", "Pagaidām nav ziņu! Esi Pirmais");
define("CHBLAN_4", "Biedrs");
define("CHBLAN_5", "Ciemiņš");
define("CHBLAN_6", "Atbloķēt");
define("CHBLAN_7", "Bloķēt");
define("CHBLAN_8", "Dzēst");
define("CHBLAN_9", "Uzraudzīt Čatu");
define("CHBLAN_10", "Uzraudzīt Ziņas");
define("CHBLAN_11", "Čatu Ziņas Rādīt");
define("CHBLAN_12", "Ziņu daudzumu parādīt čatā");
define("CHBLAN_13", "Aizvietot linkus");
define("CHBLAN_14", "Ja atķeksēts, linki tiks aizvietoti ar bildi vai noklusēto tekstu!");
define("CHBLAN_15", "Aizstāt virkni, ja aktivizēts");
define("CHBLAN_16", "Linki tiks aizvietoti ar virkni");
define("CHBLAN_17", "Vārdu aplaušana skaits");
define("CHBLAN_18", "Garāki vārdi, kā norādīts tiks aplausti");
define("CHBLAN_19", "Atjaunoti čata iestatījumi");
define("CHBLAN_20", "Čata Iestatījumi");
define("CHBLAN_21", "Prune");
define("CHBLAN_22", "Dzest ziņas vecākas kā šībrīza laika rakstītas");
define("CHBLAN_23", "Dzēst ziņas vecākas kā ");

define("CHBLAN_24", "1 dienu");
define("CHBLAN_25", "1 nedēļu");
define("CHBLAN_26", "1 mēnesi");
define("CHBLAN_27", "- Dzēst visas Ziņas -");
define("CHBLAN_28", "Čats pruned.");

define("CHBLAN_29", "Attēlot catu iekš ritināma rāmja");
define("CHBLAN_30", "Rāmja augstums");
define("CHBLAN_31", "Rādīt emocijas");
define("CHBLAN_32", "Uzraugu klase");

define("CHBLAN_33", "Biedru rakstu skaits pārskaitīts");
define("CHBLAN_34", "Pārskaitīt Biedru ierakstu skaitu");
define("CHBLAN_35", "Pārskaitīt");

define("CHBLAN_36", "Čata attēlošanas Iespējas");
define("CHBLAN_37", "Normāls Čats");
define("CHBLAN_38", "Izmanto javascript kodu lai atjaunotu dinamiski (AJAX)");

?>