<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "Sludinājumi");
define("BANNER_MENU_L2", "Reklāmas Izvēlnes konfigurācija saglabāta");
define("BANNER_MENU_L3", "Virsraksts");
define("BANNER_MENU_L4", "Kompanija");
define("BANNER_MENU_L5", "Reklamas Izvelnes konfiguracija");
define("BANNER_MENU_L6", "Izvēlies Kompāniju kuru rādīs izvelnē");
define("BANNER_MENU_L7", "Pieejamās Kompanijas");
define("BANNER_MENU_L8", "Izveletās Kompanijas");
define("BANNER_MENU_L9", "Noņemt Izvelētās");
define("BANNER_MENU_L10", "Kā tiks atlasītās kampaņas parādītas?");
define("BANNER_MENU_L11", "izvēlēties sniegt veidu ...");
define("BANNER_MENU_L12", "Vien Kompanija vienā Izvelnē");
define("BANNER_MENU_L13", "Visas Izveletās Kompanijas viena izvelnē");
define("BANNER_MENU_L14", "Visas Izvēlētās Kompanijas, katra savā Izvelnē");
define("BANNER_MENU_L15", "Cik daudz reklamas rādīt ?");
define("BANNER_MENU_L16", "Šis iestatījums tiks izmantota tikai ar opcijām 2 un 3. <br /> ja mazāk baneri ir klāt maksimālā pieejamā summa tiks izmantota.");
define("BANNER_MENU_L17", "Uzstadīt summu ...");
define("BANNER_MENU_L18", "Atjaunot Reklāmas Uzstadījumus");


?>