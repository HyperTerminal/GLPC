<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("NFLAN_01", "Newsfeeds");
define("NFLAN_02", "Šis spraudnis būs paņemt rss barotnes no citām mājas lapām un parādīt tos saskaņā ar jūsu vēlmēm");
define("NFLAN_03", "Konfigurēt newsfeeds");
define("NFLAN_04", "Newsfeeds spraudnis ir veiksmīgi instalēts Lai pievienotu newsfeeds un konfigurēt, atgriezieties galvenajā admin lapā un noklikšķiniet uz newsfeeds ikonas spraudnis sadaļā..");
define("NFLAN_05", "Edit");
define("NFLAN_06", "Dzēst");
define("NFLAN_07", "Esošās Newsfeeds");
define("NFLAN_08", "Newsfeeds sākumlapā");
define("NFLAN_09", "Izveidot newsfeed");
define("NFLAN_10", "URL RSS barību");
define("NFLAN_11", "Ceļš uz attēla");
define("NFLAN_12", "aktivizācija");
define("NFLAN_13", "Nekur (neaktīvs)");
define("NFLAN_14", "In izvēlnē tikai");
define("NFLAN_15", "Izveidot Newsfeed");
define("NFLAN_16", "Update Newsfeed");
define("NFLAN_17", "ievadiet 'Default' ailē, lai izmantotu attēlu definēts barības, lai izmantotu savu tēlu ievadiet pilnu ceļu, atstājiet tukšu bez attēla.");
define("NFLAN_18", "Update intervāls sekundēs");
define("NFLAN_19", "ti, 3600: newsfeed atjauninās katru stundu");
define("NFLAN_20", "Par newsfeed galvenajā lapā tikai");
define("NFLAN_21", "Gan izvēlnes un newsfeed lapa");
define("NFLAN_22", "izvēlēties, kur vēlaties newsfeed rādīts");
define("NFLAN_23", "Newsfeed pievienota datubāzei.");
define("NFLAN_24", "Obligāts lauks (-iem) jāatstāj tukša.");
define("NFLAN_25", "Newsfeed atjaunināta datu bāzē.");
define("NFLAN_26", "Update Interval");
define("NFLAN_27", "Iespējas");
define("NFLAN_28", "URL");
define("NFLAN_29", "Pieejamas newsfeeds");
define("NFLAN_30", "Avota nosaukums");
define("NFLAN_31", "Atpakaļ uz newsfeed saraksts");
define("NFLAN_32", "Nav ar šo identifikācijas numuru barību var atrast.");
define("NFLAN_33", "Datums publicēts:");
define("NFLAN_34", "nav zināms");
define("NFLAN_35", "publicēja");
define("NFLAN_36", "Apraksts");
define("NFLAN_37", "īss apraksts par barības, ieraksta 'noklusējuma' izmantot aprakstu, kas definēts barība");
define("NFLAN_38", "Virsraksti");
define("NFLAN_39", "Details");
define("NFLAN_40", "Newsfeed izdzēsu");
define("NFLAN_41", "neviens newsfeeds vēl nav noteiktas");
define("NFLAN_42", "<b>»</b> <u>Feed Nosaukums:</u>
	Nosakot barības nosaukuma var būt jebkas jums patīk.
<br /><br />
<b>»</b><u>URL RSS Feed:</u>
Adrese RSS padevi
<br /><br />
<b>»</b><u>Ceļš uz attēla:</u>
Ja barība ir attēls noteikts tajā, ieraksta 'noklusējuma' izmantot to. Izmantot savu attēlu, ievadiet pilnu ceļu uz to. Atstājiet tukšu, lai izmantotu nekādu attēlu vispār.
<br /><br />
<b>»</b><u>Apraksts:</u>
Ievadiet īsu aprakstu par lopbarības vai 'Default' izmantot aprakstu, kas definēts barības (ja tāds ir).
<br /> <br />
<b>»</b><u>Atjaunināt intervāls sekundēs:</u>
Daudzums sekundēs, kas paiet, pirms barības tiek atjaunināts, piemēram, 1800: 30 minūtes, 3600: stunda.
<br /> <br />
<b>»</b><u>aktivizēšana:</u>
	Kur jūs vēlaties barības rezultāti tiks parādīts, lai redzētu izvēlnes plūsmas jums būs nepieciešams, lai aktivizētu newsfeeds izvēlni <a href='".e_ADMIN."menus.php'>menus page</a>.
	<br /><br />Labu saraksta pieejamo barību, skatīt<a href='http://www.syndic8.com/' rel='external'>syndic8.com</a> or <a href='http://feedfinder.feedster.com/index.php' rel='external'>feedster.com</a>");
define("NFLAN_43", "Newsfeed palīdzību");
define("NFLAN_44", "noklikšķiniet, lai apskatītu");
define("NFLAN_45", "Vienību skaits rādītu izvēlni");
define("NFLAN_46", "Vienību skaits uz rādītas galvenajā lapā");
define("NFLAN_47", "0 vai tukšs parādīt visiem");
define("NFLAN_48", "Nevar saglabāt izejas datus datu bāzē.");
define("NFLAN_49", "Nevar unserialize rss datus - izmanto nestandarta sintakses");


?>