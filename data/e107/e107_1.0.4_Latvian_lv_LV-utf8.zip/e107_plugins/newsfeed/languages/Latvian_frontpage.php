<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("NWSF_FP_1", "Jaunumu Barotava");
define("NWSF_FP_2", "Galvenā lapa");

?>