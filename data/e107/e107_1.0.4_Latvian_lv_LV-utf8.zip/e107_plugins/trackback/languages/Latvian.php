<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("TRACKBACK_L1", "Konfigurēt Izsekošanu");
define("TRACKBACK_L2", "Šis Spraudnis ieslēdz jums izsekošanu priekš Jaunumiem");
define("TRACKBACK_L3", "Izsekošana tagad ir uzstādīta un ieslēgta");
define("TRACKBACK_L4", "Izsekošanas iestatījumi saglabāti");
define("TRACKBACK_L5", "Ieslēgt");
define("TRACKBACK_L6", "Izslēgt");
define("TRACKBACK_L7", "Aktīvas izsekošanas");
define("TRACKBACK_L8", "Izsekošanas URL teksts");
define("TRACKBACK_L9", "Saglabāt");
define("TRACKBACK_L10", "Izsekošanas Iestatījumi");
define("TRACKBACK_L11", "Izsekošanas adrese šim rakstam");
define("TRACKBACK_L12", "Nav izsekošana");
define("TRACKBACK_L13", "Uzraudzīt Izsekošanu");
define("TRACKBACK_L14", "Dzēst");
define("TRACKBACK_L15", "Izsekošana Izdzēsta");


?>