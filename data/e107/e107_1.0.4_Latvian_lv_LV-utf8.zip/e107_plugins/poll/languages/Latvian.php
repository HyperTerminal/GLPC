<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("POLL_ADLAN01", "Aptauja");
define("POLL_ADLAN02", "Aptauja spraudnis ļauj jums noteikt aptaujas vai nu izvēlnē vai foruma rakstos");
define("POLL_ADLAN03", "Konfigurēt Aptaujas");
define("POLL_ADLAN04", "Aptauja spraudnis ir veiksmīgi instalēta. Lai pievienotu aptaujas, noklikšķiniet uz aptaujas ikonas spraudnis sadaļā jūsu admin sākumlapā, un atcerēties, lai aktivizētu izvēlnes vienumu no sava izvēlnes lapas.");
define("POLL_ADLAN05", "Galvenā aptauja:");
define("POLL_ADLAN06", "Foruma Tēmas:");
define("POLL_ADLAN07", "Tips");
define("POLLAN_MENU_CAPTION", "Aptauja");
define("POLLAN_1", "Esošās Aptaujas");
define("POLLAN_2", "Izveidot/labot aptauju");
define("POLLAN_3", "Jautajums");
define("POLLAN_4", "Opcijas");
define("POLLAN_5", "Labot");
define("POLLAN_6", "Dzēst");
define("POLLAN_7", "Nav Atpauju pagaidām!");
define("POLLAN_8", "Pievienot vēl opciju");
define("POLLAN_9", "Atļaut vairākas izvēles?");
define("POLLAN_10", "Jā");
define("POLLAN_11", "Nē");
define("POLLAN_12", "Rādīt Rezultātus");
define("POLLAN_13", "Pēc Balsošanas");
define("POLLAN_14", "Noklikšķinot skatīties rezultātu saiti - komentāriem jābūt ieslēgtiem izmantojot šo iespēju");
define("POLLAN_15", "Atļaut balsot šai aptaujai");
define("POLLAN_16", "Ballsu uzglabāšanas metode");
define("POLLAN_17", "cookie");
define("POLLAN_18", "IP adreses");
define("POLLAN_19", "Lietotaja ID (Tiakai Biedri var Balsot)");
define("POLLAN_20", "Atļaut pievienot komentārus, šai aptaujai?");
define("POLLAN_21", "Apskatīt Vēlreiz");
define("POLLAN_22", "Atjaunot");
define("POLLAN_23", "Izveidot");
define("POLLAN_24", "Apskatīt");
define("POLLAN_25", "Notīrīt");
define("POLLAN_26", "balsis");
define("POLLAN_27", "Komentāri");
define("POLLAN_28", "Iepriekšējās Aptaujas");
define("POLLAN_29", "Pievienojis");
define("POLLAN_30", "Iesniegt");
define("POLLAN_31", "Balsis");
define("POLLAN_32", "Spied te, lai apskatītu rezultātus");
define("POLLAN_33", "Nav iepriekšējo aptauju");
define("POLLAN_34", "Virsraksts");
define("POLLAN_35", "Pievienojis");
define("POLLAN_36", "Aktīvs");
define("POLLAN_37", "Aktīvs no");
define("POLLAN_38", "līdz");
define("POLLAN_39", "Paldies par Piedalīšanos!");
define("POLLAN_40", "Apskatīt rezultātus");
define("POLLAN_41", "Aptauja pieejama Biedriem tikai!");
define("POLLAN_42", "Aptauja pieejamaAdminiem tikai!");
define("POLLAN_43", "Jums nav attiecīgo atļauju, lai piedalītos aptaujā!");
define("POLLAN_44", "Dzēst šo aptauju?");
define("POLLAN_45", "Aptauja veiksmīgi izveidota");
define("POLLAN_46", "Lauki atstāti tukši!");


?>