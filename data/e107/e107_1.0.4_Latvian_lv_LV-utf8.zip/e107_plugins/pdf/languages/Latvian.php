<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "PDF izveides atbalts");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Šis spraudnis ir gatavs lietošanai.");

define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF uzstadījumi");
define("PDF_LAN_3", "ieslēgts");
define("PDF_LAN_4", "izslēgts");
define("PDF_LAN_5", "Lapas novietojums pa kreisi");
define("PDF_LAN_6", "Lapas novietojums pa labi");
define("PDF_LAN_7", "Lapas novietojums Augšā");
define("PDF_LAN_8", "Rakstuzīmju Stils");
define("PDF_LAN_9", "Rakstuzīmju izmers noklusetais");
define("PDF_LAN_10", "Rakstuzīmju izmērs saitesnosaukums");
define("PDF_LAN_11", "Rakstuzīmju izmērs lapas url");
define("PDF_LAN_12", "Rakstuzīmju izmers labu nummurs");
define("PDF_LAN_13", "Rādīt Logo pdf?");
define("PDF_LAN_14", "Rādīt Saites Nosaukumu pdf?");
define("PDF_LAN_15", "Rādīt Izveidot lapaas url iekš pdf?");
define("PDF_LAN_16", "Rādīt lapas nummuru iekš pdf?");
define("PDF_LAN_17", "Atjaunot");
define("PDF_LAN_18", "PDF uzstādījumi veiksmīgi atjaunoti");
define("PDF_LAN_19", "Lapa");
define("PDF_LAN_20", "Kļūda paziņot");

?>