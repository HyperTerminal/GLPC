<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
	
define("COUNTER_L1", "Admin apmeklējumi netiek skaitīti.");
define("COUNTER_L2", "Šodien šo lapu ...");
define("COUNTER_L3", "kopā");
define("COUNTER_L4", "šo lapu vispār ...");
define("COUNTER_L5", "unikāli");
define("COUNTER_L6", "Saite ...");
define("COUNTER_L7", "Skaitītājs");
define("COUNTER_L8", "Admina Ziņa: <b>Stati ir izslēgti</b><br />Lai aktivizētu Lūdzu uzstadiet Spraudni <a href='".e_ADMIN."plugin.php'>Spraudņu Pārvaldnieks</a>, un tad aktivizējiet <a href='".e_PLUGIN."log/admin_config.php'>Konfigurāciju ekranā</a>.");
	
?>