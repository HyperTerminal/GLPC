<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("ADLAN_PM", "Vēstules");
define("ADLAN_PM_1", "Lai aktivizētu lūdzu, dodieties uz izvēlnes ekrānu un izvēlieties private_msg vienā no jūsu izvēlnes jomās. <br /> <br /> Ja nepieciešams konvertēt ziņas no iepriekšējās versijas, lūdzu, dodieties uz galveno konfigurācijas lapā šo spraudni un izvēlieties 'pārveidot' saites.");
define("ADLAN_PM_2", "Konfigurēt Vēstules");
define("ADLAN_PM_3", "PV iestatījumi nav atrasts, noklusējuma vērtības noteiktas");
define("ADLAN_PM_4", "Opcijas Atjaunotas");
define("ADLAN_PM_5", "Limits izvēlētās klasei jau pastāv");
define("ADLAN_PM_6", "Limits veiksmīgi pievienots");
define("ADLAN_PM_7", "Limits nav pievienots! Nezināma kļūda!");
define("ADLAN_PM_8", "Limita status atjaunots!");
define("ADLAN_PM_9", " - Limits veiksmīgi noņemts");
define("ADLAN_PM_10", " - Limits nav noņemts nezinama kļūda!");
define("ADLAN_PM_11", " - Limits veiksmīgi atjaunots");
define("ADLAN_PM_12", "PV Opcijas");
define("ADLAN_PM_13", "PV Conversion");
define("ADLAN_PM_14", "PV Limits");
define("ADLAN_PM_15", "Pievienot PV Limitu");
define("ADLAN_PM_16", "Spraudņa Nosaukums");
define("ADLAN_PM_17", "Rādīt Jaunu PV animāciju");
define("ADLAN_PM_18", "Rādīt lietotājs nolaižamais");
define("ADLAN_PM_19", "LASĪT ziņu intervāls (dienās)");
define("ADLAN_PM_20", "Nelasītu ziņu timeout (dienas)");
define("ADLAN_PM_21", "Popup paziņojumi par jaunu PV");
define("ADLAN_PM_22", "Popup dienu pārtraukums");
define("ADLAN_PM_23", "Ierobežot PV izmantot");
define("ADLAN_PM_24", "Vēstuļu skaits lapā");
define("ADLAN_PM_25", "Iespējot PV e-pasta paziņojumus");
define("ADLAN_PM_26", "Atļaut lietotājam iespēju pieprasīt lasīšanas apliecinājumu e-pasta paziņojumus");
define("ADLAN_PM_27", "Atļaut piuevienot failus");
define("ADLAN_PM_28", "Maksimalais faila izmērs");
define("ADLAN_PM_29", "Atļaut sūtīt visiem biedriem");
define("ADLAN_PM_30", "Atļaut nosūtīt vairākiem adresātiem");
define("ADLAN_PM_31", "Ļautu nosūtīt uz klasēm");
define("ADLAN_PM_32", "Atjaunot Iestatījumus");
define("ADLAN_PM_33", "Neaktīvs (nez limita)");
define("ADLAN_PM_34", "PV Skaitīšana");
define("ADLAN_PM_35", "PV Kastes Izmērs");
define("ADLAN_PM_36", "Klases");
define("ADLAN_PM_37", "Skaitīsanas Limits");
define("ADLAN_PM_38", "Izmēra Limits  (KB)");
define("ADLAN_PM_39", "Ienākošais:");
define("ADLAN_PM_40", "Izejošais:");
define("ADLAN_PM_41", "Limits pagaidām nav norādīts!");
define("ADLAN_PM_42", "Atjaunot Limitu");
define("ADLAN_PM_43", "Pievienot jaunu limitu");
define("ADLAN_PM_44", "sekundes");
define("ADLAN_PM_45", "PV Limits:");
define("ADLAN_PM_46", "PV Conversion");
define("ADLAN_PM_47", "Jums nešķiet, ka kāds no vecās ziņas no iepriekšējām versijām, tas ir droši atinstalēt veco spraudni");
define("ADLAN_PM_48", "Jums ir {OLDCOUNT} ziņas no vecāku versiju, lūdzu, jāizlemj, ko jūs vēlētos darīt ar šiem ziņojumiem <br /> <br /> Ja konvertējošā ziņas, jebkura ziņa veiksmīgi konvertēta tiks noņemts no vecās sistēmas");
define("ADLAN_PM_49", "Convert uz jauno PV");
define("ADLAN_PM_50", "Atmest vecās ziņas");
define("ADLAN_PM_51", "PV #{PMNUM} nav converted");
define("ADLAN_PM_52", "vēstules converted");
define("ADLAN_PM_53", "Ierakstu nav atrasti convert.");
define("ADLAN_PM_54", "Galvenie Iestatījumi");
define("ADLAN_PM_55", "Limits");
define("ADLAN_PM_56", "Conversion");
define("ADLAN_PM_57", "Šis spraudnis ir pilnībā aprīkots ar Vēstuļu apmaiņas sistēmu.");
define("ADLAN_PM_58", "Vēstules");


?>