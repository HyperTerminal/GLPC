<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Saturs");
define("CONT_SCH_LAN_2", "Visa Satura Kategorija");
define("CONT_SCH_LAN_3", "Atbilde uz Rakstu");
define("CONT_SCH_LAN_4", "iekš");

?>