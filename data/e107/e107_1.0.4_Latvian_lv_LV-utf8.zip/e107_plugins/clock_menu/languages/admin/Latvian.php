<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Pulksteņa izvelnes konfigurācijas saglabātas");
define("CLOCK_AD_L2", "Virsraksts");
define("CLOCK_AD_L3", "Atjaunot Izvelnes Iestatijumus");
define("CLOCK_AD_L4", "Pulksteņa Izvelnes Konfigurācija");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Ja atzīmēts Jūs rādīs laiks ar ASV formātā (0-12 AM / PM formātā). Nekontrolēti jums parādīs 'militāriem' formāta 0-24 formāts");
define("CLOCK_AD_L7", "Datuma Prefix");
define("CLOCK_AD_L8", "Ja jūsu valoda ir nepieciešama īsa vārdu, pirms datuma (piemēram, 'Le' par franču vai 'Den' Vācijas ...), izmantojiet šo lauku. Ja nav nepieciešams, atstājiet tukšu.");
define("CLOCK_AD_L9", "Suffix 1");
define("CLOCK_AD_L10", "Suffix 2");
define("CLOCK_AD_L11", "Suffix 3");
define("CLOCK_AD_L12", "Suffix 4 un vairāk");
define("CLOCK_AD_L13", "Ja jūsu valoda ir nepieciešama, lai parādītu sufiksu tikai pēc numuriem datuma, aizpildiet šos laukus ar sufiksu tikai (Piemērs: 'st' par 1, 'nd' par 2 'RD' par 3 un 'th' par 4 un vairāk - par Angļu lietotāji). Ja nav nepieciešams atstāt tukšu.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");


?>