<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CLOCK_MENU_L1", "Pulksteņa Izvelnes Konfigurācijas Saglabātas");
define("CLOCK_MENU_L2", "Virsraksts");
define("CLOCK_MENU_L3", "Atjaunot Izvēlnes Iestatījumus");
define("CLOCK_MENU_L4", "Pulksteņa Izvelnes Konfigurācija");
define("CLOCK_MENU_L5", "Pirmdiena,");
define("CLOCK_MENU_L6", "Otrdiena,");
define("CLOCK_MENU_L7", "Trešdiena,");
define("CLOCK_MENU_L8", "Ceturtdiena,");
define("CLOCK_MENU_L9", "Piektdiena,");
define("CLOCK_MENU_L10", "Sestdiena,");
define("CLOCK_MENU_L11", "Svētdiena,");
define("CLOCK_MENU_L12", "Janvāris");
define("CLOCK_MENU_L13", "Februāris");
define("CLOCK_MENU_L14", "Marts");
define("CLOCK_MENU_L15", "Aprilis");
define("CLOCK_MENU_L16", "Maijs");
define("CLOCK_MENU_L17", "Jūnijs");
define("CLOCK_MENU_L18", "Jūlijs");
define("CLOCK_MENU_L19", "Augusts");
define("CLOCK_MENU_L20", "Septembris");
define("CLOCK_MENU_L21", "Oktobris");
define("CLOCK_MENU_L22", "Novembris");
define("CLOCK_MENU_L23", "Decembris");
define("CLOCK_MENU_L24", "");


?>