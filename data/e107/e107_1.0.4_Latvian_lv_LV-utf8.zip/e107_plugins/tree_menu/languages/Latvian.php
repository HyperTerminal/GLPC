<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("TREE_L1", "Konfigurēt navigacijas Izvēlne");
define("TREE_L2", "Atjaunoti navigacijas uzstadījumi");
define("TREE_L3", "navigacijas konfiguracija saglabāti");
define("TREE_L4", "Ieslēgts");
define("TREE_L5", "Izslēgts");
define("TREE_L6", "CSS klases izmanto ne atveramiem saites");
define("TREE_L7", "CSS klases izmantot atveramiem saites");
define("TREE_L8", "CSS klases izmantot atvērto saites");
define("TREE_L9", "Izmantot atstarpes klases starp galvenajiem saites");


?>