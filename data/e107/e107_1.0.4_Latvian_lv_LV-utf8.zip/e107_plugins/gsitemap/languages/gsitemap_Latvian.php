<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("GSLAN_Name", "Saites Karte");
define("GSLAN_1", "Saites Linki");
define("GSLAN_2", "Ievietot?");
define("GSLAN_3", "Tips");
define("GSLAN_4", "Nosaukums");
define("GSLAN_5", "Url");
define("GSLAN_6", "Atzīmējiet saites, lai atzīmētos ievietotu ...");
define("GSLAN_7", "Ievietot Linkus");
define("GSLAN_8", "Ievietošanas Platums");
define("GSLAN_9", "Prioritāte");
define("GSLAN_10", "biežums");
define("GSLAN_11", "Vienmēr");
define("GSLAN_12", "Stundās");
define("GSLAN_13", "Dienā");
define("GSLAN_14", "Nedēļā");
define("GSLAN_15", "Menesī");
define("GSLAN_16", "Gadā");
define("GSLAN_17", "Nekad");
define("GSLAN_18", "Ievietot atzīmetos linkus");
define("GSLAN_19", "Google Saites Karte");
define("GSLAN_20", "saraksts");
define("GSLAN_21", "instrukcijas");
define("GSLAN_22", "Izveidot Jaunu");
define("GSLAN_23", "Ievietot");
define("GSLAN_24", "Google Saites Kartes Ieraksti");
define("GSLAN_25", "Nosaukums");
define("GSLAN_26", "URL");
define("GSLAN_27", "Lastmod");
define("GSLAN_28", "Freq.");
define("GSLAN_29", "Google Saites Karte Konfiguracija");
define("GSLAN_30", "Kārtošana");
define("GSLAN_31", "Redzams");
define("GSLAN_32", "Ka izmantot Google Saites Karti");
define("GSLAN_33", "GSiteMap Instrukcijas");
define("GSLAN_34", "Pirmkārt, izveidot saikni vēlaties ir uzskaitīti jūsu sitemap. Jūs varat importēt lielāko daļu savas saites, noklikšķinot uz 'Ievietot' pogu pa labi");
define("GSLAN_35", "Ja jūs esat izvēlējušies importēt savas saites, noklikšķiniet uz 'Ievietot' un pēc tam pārbaudiet saites vēlaties ievietot");
define("GSLAN_36", "Jūs varat arī ievadīt atsevišķām saites manuāli, noklikšķinot 'Izveidot Jaunu'");
define("GSLAN_37", "Kad jums ir daži ieraksti, dodieties uz [url] un ievadiet šādu URL: [URL2] Ja iepriekš url neizskatās labi, lai jūs, lūdzu, pārliecinieties, ka jūsu vietne URL ir pareizs admin -> [iestatījumi]");
define("GSLAN_38", "Plašāku informāciju par Google Saites Karti protokolu, dodieties uz [url].");
define("GSLAN_39", "Nav linki iekš saites kartes - Ievietot linkus?");
define("GSLAN_40", "Google Saites Kartes Ieraksti");


?>