<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

define("LAN_UMENU_THEME_1", "Uzstādīt Dizainu");
define("LAN_UMENU_THEME_2", "Izvelēties Dizainu");
define("LAN_UMENU_THEME_3", "lietotaji:");
define("LAN_UMENU_THEME_4", "Ieslēdz Lai šīs tēmas, ko lietotāji var izvēlēties");
define("LAN_UMENU_THEME_5", "Atjaunot");
define("LAN_UMENU_THEME_6", "Dizaini Pieejami Lietotājiem");
define("LAN_UMENU_THEME_7", "Klase kura drīkst izvelēties Dizainus");


?>