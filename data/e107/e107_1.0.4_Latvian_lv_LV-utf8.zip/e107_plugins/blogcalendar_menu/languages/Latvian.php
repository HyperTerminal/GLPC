<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Jaunumi priekš");
define("BLOGCAL_L2", "Arhīvs");
define("BLOGCAL_D1", "Pi");
define("BLOGCAL_D2", "Ot");
define("BLOGCAL_D3", "Tr");
define("BLOGCAL_D4", "Ce");
define("BLOGCAL_D5", "Pi");
define("BLOGCAL_D6", "Se");
define("BLOGCAL_D7", "Sv");
define("BLOGCAL_M1", "Janvāris");
define("BLOGCAL_M2", "Februāris");
define("BLOGCAL_M3", "Marts");
define("BLOGCAL_M4", "Aprilis");
define("BLOGCAL_M5", "Maijs");
define("BLOGCAL_M6", "Jūnijs");
define("BLOGCAL_M7", "Jūlijs");
define("BLOGCAL_M8", "Augusts");
define("BLOGCAL_M9", "Septembris");
define("BLOGCAL_M10", "Oktobris");
define("BLOGCAL_M11", "Novembris");
define("BLOGCAL_M12", "Decembris");
define("BLOGCAL_1", "Jaunumi");
define("BLOGCAL_CONF1", "Mēn/rindā");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "Atjaunot Izvēlnes Ustādījumus");
define("BLOGCAL_CONF4", "BlogCal Izvelnes Uzstādījumi");
define("BLOGCAL_CONF5", "BlogCal Izvelnes Uzstādījumi Saglabati");
define("BLOGCAL_ARCHIV1", "Izvelēties Arhīvu");


?>