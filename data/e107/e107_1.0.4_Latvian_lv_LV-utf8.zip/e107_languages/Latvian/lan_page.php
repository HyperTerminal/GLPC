<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_PAGE_1", "Lapu saraksts ir izslēgts");
define("LAN_PAGE_2", "Pagaidām šeit nav lapu!");
define("LAN_PAGE_3", "Pieprasītā lapa neeksistē");
define("LAN_PAGE_4", "Vērtēt šo lapu");
define("LAN_PAGE_5", "Paldies par vērtējumu");
define("LAN_PAGE_6", "Jums nav atļaujas skatīt šo lapu");
define("LAN_PAGE_7", "nepareiza parole");
define("LAN_PAGE_8", "Lapa aizsargāta ar paroli");
define("LAN_PAGE_9", "Parole");
define("LAN_PAGE_10", "Iesniegt");
define("LAN_PAGE_11", "Lapu saraksts");
define("LAN_PAGE_12", "Nepareiza Lapa");
define("LAN_PAGE_13", "Lapa");


?>