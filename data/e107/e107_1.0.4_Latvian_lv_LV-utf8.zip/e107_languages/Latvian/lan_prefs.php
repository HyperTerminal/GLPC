<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_PREF_1", "e107 Bāzēta Mājas Lapa");
define("LAN_PREF_2", "e107 Mājas Lapas Sistēma");
define("LAN_PREF_3", "Šo saiti piedāvā <a href='http://e107.org/' rel='external'>e107</a>, kas ir atbrīvota saskaņā ar noteikumiem <a href='http://www.gnu.org/' rel='external'>GNU</a> GPL Licenzi.");
define("LAN_PREF_4", "Cenzēts");
define("LAN_PREF_5", "Forums");


?>