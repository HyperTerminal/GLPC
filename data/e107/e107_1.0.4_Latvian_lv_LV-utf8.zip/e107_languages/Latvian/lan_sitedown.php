<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Vietne uz laiku slēgta!");
define("LAN_SITEDOWN_00", "uz laiku slēgts");
define("LAN_SITEDOWN_01", "Mēs esam uz laiku slēguši vietni, jo veicam būtiskus apkopes darbus. Tam nevajadzētu ieilgt pārāk ilgi - lūdzu ienāc vēlāk, atvainojos par sagādātajām neērtībām.");


?>