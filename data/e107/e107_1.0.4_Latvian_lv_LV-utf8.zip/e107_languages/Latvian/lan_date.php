<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LANDT_01", "gads");
define("LANDT_02", "mēnesis");
define("LANDT_03", "nedēļa");
define("LANDT_04", "diena");
define("LANDT_05", "stunda");
define("LANDT_06", "minūte");
define("LANDT_07", "sekunde");
define("LANDT_01s", "gadi");
define("LANDT_02s", "mēneši");
define("LANDT_03s", "nedēļas");
define("LANDT_04s", "dienas");
define("LANDT_05s", "stundas");
define("LANDT_06s", "minūtes");
define("LANDT_07s", "sekundes");
define("LANDT_08", "min");
define("LANDT_08s", "mins");
define("LANDT_09", "sek");
define("LANDT_09s", "sek-es");
define("LANDT_AGO", "pirms");


?>