<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Iesniegt Jaunumus");
define("LAN_7", "Nosaukums:");
define("LAN_62", "Virsraksts:");
define("LAN_112", "E-pasta Adrese:");
define("LAN_133", "Paldies");
define("LAN_134", "Jūsu pozīcija ir iesniegta izskatīšanai vienam no vietnes administratoriem.");
define("LAN_135", "Jaunumi:");
define("LAN_136", "Iesniegt Jaunumus");
define("NWSLAN_6", "Kategorija");
define("NWSLAN_10", "Nav Jaunumu Kategorijas");
define("NWSLAN_11", "Jums nav pieeja šai zonā.");
define("NWSLAN_12", "Pieeja Liegta!");
define("SUBNEWSLAN_1", "Jums jāiekļauj virsraksts\\n");
define("SUBNEWSLAN_2", "Jums Jaiekļauj nedaudz teksta, šajā ziņā\\n");
define("SUBNEWSLAN_3", "Jūsu pievienotais fails drīkst būt vai nu jpg, gif vai png fails");
define("SUBNEWSLAN_4", "Fails pārāk liels");
define("SUBNEWSLAN_5", "Bildes Fails");
define("SUBNEWSLAN_6", "(jpg, gif vai png)");
define("SUBNEWSLAN_7", "Jums ir jānorāda savs vārds un e-pasta adrese");
define("SUBNEWSLAN_8", "Kļūda augšupielādējot bildi!");


?>