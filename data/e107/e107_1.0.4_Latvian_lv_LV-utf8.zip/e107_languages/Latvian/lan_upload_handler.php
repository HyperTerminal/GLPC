<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Faila Izmērs");
define("LANUPLOAD_2", "nav atļauta, un ir dzēsts.");
define("LANUPLOAD_3", "veiksmīgi augšupielādēts");
define("LANUPLOAD_4", "Adresātā mape neeksistē vai nav rakstāma. (chmod 777)");
define("LANUPLOAD_5", "Augšupielādēts fails pārsniedz upload_max_filesize direktīvu php.ini.");
define("LANUPLOAD_6", "Augšupielādēts fails pārsniedz MAX_FILE_SIZE direktīvu, kas tika norādīta html formā.");
define("LANUPLOAD_7", "Augšupielādēts fails bija tikai daļēji augšupielādēts.");
define("LANUPLOAD_8", "Nav Failu augšupielādētu.");
define("LANUPLOAD_9", "Augšupielādēto failu izmērs 0 baiti");
define("LANUPLOAD_10", "Augšupielāde neizdevās [Duplicate filename] - ar tādu pašu nosaukumu jau eksistē.");
define("LANUPLOAD_11", "Fails nav augšupielādēts. faila nosaukums:");
define("LANUPLOAD_12", "Kļūda");
define("LANUPLOAD_13", "Trūkst pagaidu mape");
define("LANUPLOAD_14", "Failu rakstīt neizdevās");
define("LANUPLOAD_15", "Augšupielādēt nav atļauta");
define("LANUPLOAD_16", "nezināma kļūda");
define("LANUPLOAD_17", "Nederīgs nosaukums augšupielādētajam failam");
define("LANUPLOAD_18", "Augšupielādēts fails pārsniedz pieļaujamās robežas.");
define("LANUPLOAD_19", "Pārāk daudz failu augšupielādē - lieko dzēst");


?>