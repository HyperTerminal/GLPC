<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define ("LAN_EMAIL_1", "Nē");
define ("LAN_EMAIL_2", "IP nē sūtītāja:");
define ("LAN_EMAIL_3", "Pa e-pastu vienumu");
define ("LAN_EMAIL_4", "Sūtīt Nosūtīt");
define ("LAN_EMAIL_5", "E-vienība draugam");
define ("LAN_EMAIL_6", "Es domāju Jūs varētu būt ieinteresēts šajā produktā no");
define ("LAN_EMAIL_7", "e-pastu kādam");
define ("LAN_EMAIL_8", "Komentārs");
define ("LAN_EMAIL_9", "Sorry - nevar nosūtīt e-pastu");
define ("LAN_EMAIL_10", "Pasts nosūtīts");
define ("LAN_EMAIL_11", "nosūtīts pasts");
define ("LAN_EMAIL_12", "Error");
define ("LAN_EMAIL_13", "Nosūtīt rakstu draugam");
define ("LAN_EMAIL_14", "E-pasts news_item draugam");
define ("LAN_EMAIL_15", "Lietotājvārds:");
define ("LAN_EMAIL_106", "Tas nešķiet būt derīga e-pasta adrese");
define ("LAN_EMAIL_185", "Sūtīt rakstu");
define ("LAN_EMAIL_186", "Sūtīt News Item");
define ("LAN_EMAIL_187", "E-pasta adrese, lai nosūtītu uz");
define ("LAN_EMAIL_188", "Es domāju Jūs varētu būt ieinteresēts šajā ziņu sižetu no");
define ("LAN_EMAIL_189", "Es domāju Jūs varētu būt ieinteresēts šajā rakstā no");
define ("LAN_EMAIL_190", "Ievadiet redzamo Kodu");


?>