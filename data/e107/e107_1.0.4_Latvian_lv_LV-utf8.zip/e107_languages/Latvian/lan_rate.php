<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("RATELAN_0", "balss");
define("RATELAN_1", "balsis");
define("RATELAN_2", "kāds būs vērtējums?");
define("RATELAN_3", "Paldies par vertējumu!");
define("RATELAN_4", "Nav Vērtējuma");
define("RATELAN_5", "Vērtēt");


?>