<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
setlocale(LC_ALL, 'lv_LV.UTF-8', 'lv_LV.utf8', 'lat_lat.utf8', 'lv');
define("CORE_LC", "lv");
define("CORE_LC2", "lv");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Kļūda: Dizains ir pazudis.\\n\\nNomainiet lietojamo dizainu pie Iestatījumiem (Adminu Zona) vai augšupielādējiet attiecīgos failus, priekš esošā dizaina.");
define("CORE_LAN4", "Lūdzu izdzēsiet 'install.php' failu no servera!");
define("CORE_LAN5", "ja to neizdarīsiet, pastāv potenciāls drošības risks!");
define("CORE_LAN6", "Pret 'plūdu' aizsardzība aktivizēta! Brīdinām, ja turpināsiet pieprasīt lapu, Jūs varat tikt nobloķēts!");
define("CORE_LAN7", "Kodols mēģina atjaunot iestatījumus no automātiskās rezerves.");
define("CORE_LAN8", "Kodola iestatījumu kļūda!");
define("CORE_LAN9", "Kodols nevar atjaunot no automātiskās rezerves. Izpilde apturēta.");
define("CORE_LAN10", "Konstatēti bojāti 'cookie'  - atteicies no sistēmas.");
define("CORE_LAN11", "Ielādes laiks:");
define("CORE_LAN12", " sek,");
define("CORE_LAN13", "no šiem pieprasījumiem.");
define("CORE_LAN14", "");
define("CORE_LAN15", "DB pieprasījumi:");
define("CORE_LAN16", "Izmantotā atmiņa:");
define("CORE_LAN17", "[ Bilde ir atslēgta ]");
define("CORE_LAN18", "Bilde:");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "kB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "Brīdinājums!");
define("LAN_ERROR", "Kļūda");
define("LAN_ANONYMOUS", "Anonīms");
define("LAN_EMAIL_SUBS", "-epasts-");
define("LAN_SANITISED", "AIZLIEGTS");


?>