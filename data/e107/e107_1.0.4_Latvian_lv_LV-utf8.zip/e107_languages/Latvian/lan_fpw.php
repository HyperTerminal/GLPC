<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Paroles atjaunošana");
define("LAN_02", "Atvainojiet, nevar sūtīt e-pastu - lūdzu, sazinieties ar galveno vietnes administratoru.");
define("LAN_03", "Paroles atjaunošana");
define("LAN_05", "Lai atjaunotu savu paroli, lūdzu ievadiet sekojošu informāciju");
define("LAN_06", "Mēģinājums paroles atjaunošanai");
define("LAN_07", "Kāds ar IP adresi");
define("LAN_08", "mēģināja atjaunot galveno admin paroli.");
define("LAN_09", "Paroles atjaunošana no");
define("LAN_112", "E-pasta adrese kuru izmantoja reģistrējoties");
define("LAN_156", "Iesniegt");
define("LAN_213", "Šī lietotājvārds / e-pasta adrese netika atrasts datu bāzē.");
define("LAN_214", "Neizdevās atjaunot paroli");
define("LAN_216", "Lai apstiprinātu jauno paroli, lūdzu dodieties uz šādu URL ...");
define("LAN_217", "Jūsu jaunā parole tagad ir apstiprināta, jūs tagad varat autorizēties, izmantojot savu jauno paroli.");
define("LAN_218", "Jūsu lietotājvārds ir:");
define("LAN_219", "Parole saistīta ar šo e-pasta adresi jau ir atjaunota, un to nevar atjaunot vēlreiz. Lūdzu sazinieties ar vietnes administratoru lai uzzinātu vairāk.");
define("LAN_FPW1", "Lietotājvārds");
define("LAN_FPW2", "Ievadi Kodu");
define("LAN_FPW3", "Kods ievadīts nepareizi");
define("LAN_FPW4", "Lūgums jau ticis nosūtīts, lai atjaunotu paroli, ja jūs nesaņēmāt e-pastu, lūdzu, sazinieties ar vietnes administratoru, lai saņemtu palīdzību.");
define("LAN_FPW5", "Pieprasījumu, lai atjaunotu savu paroli");
define("LAN_FPW6", "Jums ir nosūtīts E-pasts ar saiti, kas ļaus Jums nomainīt savu paroli.");
define("LAN_FPW7", "Šis nav pamatots sasaiste, lai atjaunotu savu paroli. <br /> Lūdzu sazinieties ar vietnes administratoru lai uzzinātu vairāk.");
define("LAN_FPW8", "Jūsu parole ir nomainīta veiksmīgi.");
define("LAN_FPW9", "Jauna parole ir:");
define("LAN_FPW10", "Lūdzu");
define("LAN_FPW11", "piesakieties tagad sistēmā");
define("LAN_FPW12", "un nekavējoties nomainiet paroli, drošības nolūkos.");
define("LAN_FPW13", "lūdzu sekojiet e-pastā, lai apstiprinātu savu paroli.");
define("LAN_FPW14", "ir iesniegts kāds ar IP");
define("LAN_FPW15", "Tas nenozīmē, ka jūsu parole ir atjaunota. Jums ir jādodas uz saiti kura parādīta zemāk, lai pabeigtu atjaunošanu.");
define("LAN_FPW16", "Ja neesat pieprasījis, lai jūsu paroli atjauno un jūs nevēlaties, lai to atjaunotu, jūs varat vienkārši ignorēt šo e-pastu");
define("LAN_FPW17", "Saite zemāk būs derīga 48 stundas.");


?>