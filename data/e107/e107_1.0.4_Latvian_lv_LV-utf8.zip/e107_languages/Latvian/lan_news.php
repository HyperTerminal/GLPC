<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Jaunumi");
define("LAN_NEWS_1", "Ziņas par konkrētiem dalībniekiem tikai");
define("LAN_NEWS_2", "Jums nav atļauts apskatīt šo ziņu");
define("LAN_NEWS_9", "Virsraksts tikai tiek noteikts - <b>tikai ziņas virsrakstu tiks parādīts</b><br />");
define("LAN_NEWS_10", "Šī ziņa amats ir <b>neaktīvs</b> (tas netiks parādīta pirmajā lapā).");
define("LAN_NEWS_11", "Šī ziņa amats ir <b>aktīvs</b> (tas tiks parādīta pirmajā lapā).");
define("LAN_NEWS_12", "Komentāri ir  <b>ieslēgti</b>.");
define("LAN_NEWS_13", "Komentāri ir <b>atslēgti</b>.");
define("LAN_NEWS_14", "<br />Aktivizācijas periods:");
define("LAN_NEWS_15", "Ķermeņa garums:");
define("LAN_NEWS_16", "b. Pagarināts garums:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Tagad");
define("LAN_NEWS_23", "Jaunumu Kategorijas");
define("LAN_NEWS_24", "Izveidot PDF no šī ziņu vienuma");
define("LAN_NEWS_25", "Labot");
define("LAN_NEWS_31", "Pielipināts jaunumi postenis");
define("LAN_NEWS_82", "Jaunumi - Kategorija");
define("LAN_NEWS_83", "Nav Jaunumu šajā brīdī - lūdzu ienāc vēlāk.");
define("LAN_NEWS_84", "Atpakaļ uz jaunumu pārskatu");
define("LAN_NEWS_85", "Atpakaļ uz kategoriju pārskatu");
define("LAN_NEWS_86", "Vecāki Jaunumi");
define("LAN_NEWS_87", "Jaunāki Jaunumi");
define("LAN_NEWS_462", "Nav Jaunumu noteiktajā mēnesī");
define("LAN_NEWS_99", "Komentāri");
define("LAN_NEWS_100", "par");
define("LAN_NEWS_307", "Ziņojumu skaits kategorijā:");


?>