<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Biedra Rakti");
define("UP_LAN_0", "Visi Foruma Raksti priekš");
define("UP_LAN_1", "Visi Komentāri priekš");
define("UP_LAN_2", "Tēmas");
define("UP_LAN_3", "Skatīts");
define("UP_LAN_4", "Atbildes");
define("UP_LAN_5", "Pēdējasi Raksts");
define("UP_LAN_6", "Tēmas");
define("UP_LAN_7", "Nav Komentāru, Esi pirmais!");
define("UP_LAN_8", "Nav rakstu");
define("UP_LAN_9", " uz");
define("UP_LAN_10", "Au");
define("UP_LAN_11", "Rakstīts");
define("UP_LAN_12", "Meklēt");
define("UP_LAN_13", "Komentāri");
define("UP_LAN_14", "Foruma Raksti");
define("UP_LAN_15", "Au");
define("UP_LAN_16", "IP Adrese");


?>