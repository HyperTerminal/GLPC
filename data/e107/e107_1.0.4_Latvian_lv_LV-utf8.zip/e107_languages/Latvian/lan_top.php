<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("TOP_LAN_0", "Top Foruma Rakstnieki");
define("TOP_LAN_1", "Lietotājvārds");
define("TOP_LAN_2", "Raksti");
define("TOP_LAN_3", "Top Komentētāji");
define("TOP_LAN_4", "Komentāri");
define("TOP_LAN_5", "Top Čatotāji");
define("TOP_LAN_6", "Saites Reitings");
define("LAN_1", "Thread");
define("LAN_2", "Rakstija");
define("LAN_3", "Skatīts");
define("LAN_4", "Atbildes");
define("LAN_5", "Pēdējais Raksts");
define("LAN_6", "Tēmas");
define("LAN_7", "Aktīvakāš Tēmas");
define("LAN_8", "Top Raksnieki");


?>