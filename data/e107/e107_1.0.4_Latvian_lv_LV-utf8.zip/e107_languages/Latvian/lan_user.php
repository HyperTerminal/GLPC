<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Biedri");
define("LAN_20", "Kļūda");
define("LAN_112", "E-pasts");
define("LAN_137", "Nav šim lietotājam informācija, kas tam nav jāreģistrē");
define("LAN_138", "Reģistrētie dalībnieki:");
define("LAN_139", "Kārtot:");
define("LAN_140", "Reģistrētie dalībnieki");
define("LAN_141", "Nav pagaidām Reģistrētie dalībnieki:");
define("LAN_142", "Biedrs");
define("LAN_143", "[Spēpts pēc pieprasījuma]");
define("LAN_145", "Pievienojies");
define("LAN_146", "Vietnes vizītes, kopš reģistrācijas");
define("LAN_147", "Čata ziņas");
define("LAN_148", "Komentāri");
define("LAN_149", "Foruma Raksti");
define("LAN_308", "Īstais Vārds");
define("LAN_400", "Tas nav apstiprinātu lietotāju.");
define("LAN_401", "Nav Informācijas");
define("LAN_402", "Biedra Konts");
define("LAN_403", "Stati");
define("LAN_404", "Pēdējais Apmeklējums");
define("LAN_405", "dienas pirms");
define("LAN_406", "Vērtējums");
define("LAN_407", "nav");
define("LAN_408", "nav foto");
define("LAN_409", "Punkti");
define("LAN_410", "Dažādi");
define("LAN_411", "Noklikšķiniet šeit, lai atjauninātu savu informāciju");
define("LAN_412", "oklikšķiniet šeit, lai rediģētu šo lietotāja informāciju");
define("LAN_413", "Dzēst foto");
define("LAN_414", "iepriekšējais");
define("LAN_415", "nākamais");
define("LAN_416", "Jums ir jābūt pieteicies Lai piekļūtu šai lapai");
define("LAN_417", "Īpašnieks");
define("LAN_418", "Administrators");
define("LAN_419", "Rādīt");
define("LAN_420", "DESC");
define("LAN_421", "ASC");
define("LAN_422", "Iet");
define("LAN_423", "Noklikšķiniet šeit, lai apskatītu lietotāja komentārus");
define("LAN_424", "Noklikšķiniet šeit, lai apskatītu Foruma ziņas");
define("LAN_425", "Sūtīt Vēstuli");
define("LAN_426", "pirms");
define("USERLAN_1", "Vērtējums");
define("USERLAN_2", "Jums nav pieejas apskatīt šo lapu.");


?>