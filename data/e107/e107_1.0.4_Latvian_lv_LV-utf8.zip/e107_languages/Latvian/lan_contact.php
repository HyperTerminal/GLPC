<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Kontakti");
define("LANCONTACT_01", "Kontaktu Detaļas");
define("LANCONTACT_02", "Kontaktu Forma");
define("LANCONTACT_03", "Ievadi savu vārdu:");
define("LANCONTACT_04", "E-pasta adrese:");
define("LANCONTACT_05", "Ziņas Temats:");
define("LANCONTACT_06", "Ievadi savu ziņojumu:");
define("LANCONTACT_07", "Nosūtīt kopiju par šo ziņojumu uz savu adresi");
define("LANCONTACT_08", "Sūtīt");
define("LANCONTACT_09", "Jūsu ziņojums tika nosūtīts");
define("LANCONTACT_10", "Radās problēma izsūtot Jūsu ziņojumu!");
define("LANCONTACT_11", "Jūsu e-pasta adrese nav parādīta, nav derīga.\\nLūdzu pārbaudiet, un mēģiniet vēlreiz!");
define("LANCONTACT_12", "Jūsu ziņojums ir pārāk īss!");
define("LANCONTACT_13", "Lūdzu iekļaujiet tematu.");
define("LANCONTACT_14", "Sūtīt (kam):");
define("LANCONTACT_15", "Kods ievadīts nepareizi!");
define("LANCONTACT_16", "Ievadi Kodu");


?>