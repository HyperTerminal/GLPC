<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Sagatavojis E107 Mājas lapu izstrāde");
define("LANMAILH_2", "Šis ir vairāku daļa ziņu MIME formātā.");
define("LANMAILH_3", "nav atbilstoši formatēts");
define("LANMAILH_4", "Serveris noraidīja adresi");
define("LANMAILH_5", "Nav atbildes no servera");
define("LANMAILH_6", "Nevar atrast e-pasta serveri.");
define("LANMAILH_7", "šķiet derīgs.");


?>