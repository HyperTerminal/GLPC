<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("NP_1", "Iepriekšējā lapa");
define("NP_2", "Nākamā lapa");
define("NP_3", "Iet uz Lapu");


?>