<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UE_LAN_1", "Tekstlodziņš");
define("UE_LAN_2", "Radio pogas");
define("UE_LAN_3", "Nolaižamā izvēlne");
define("UE_LAN_4", "DB tabula lauks");
define("UE_LAN_5", "Teksta lauks");
define("UE_LAN_6", "vesels skaitlis");
define("UE_LAN_7", "Datums");
define("UE_LAN_8", "Valoda");
define("UE_LAN_9", "Nosaukums");
define("UE_LAN_10", "Tips");
define("UE_LAN_11", "Lietot");
define("UE_LAN_HIDE", "Slept no Biedriem");
define("UE_LAN_LOCATION", "Dzīvesvieta");
define("UE_LAN_LOCATION_DESC", "Biedra Dzīvesvieta");
define("UE_LAN_AIM", "AIM Adrese");
define("UE_LAN_AIM_DESC", "AIM Adrese");
define("UE_LAN_ICQ", "ICQ Numurs");
define("UE_LAN_ICQ_DESC", "ICQ Numurs");
define("UE_LAN_YAHOO", "Yahoo! Adrese");
define("UE_LAN_YAHOO_DESC", "Yahoo! Adrese");
define("UE_LAN_MSN", "MSN");
define("UE_LAN_MSN_DESC", "MSN Adrese");
define("UE_LAN_HOMEPAGE", "Mājas Lapa");
define("UE_LAN_HOMEPAGE_DESC", "Lietot mājaslapas (url)");
define("UE_LAN_BIRTHDAY", "Dzimšanas Diena");
define("UE_LAN_BIRTHDAY_DESC", "Dzimšanas Diena");
define("UE_LAN_LANGUAGE", "Valoda");
define("UE_LAN_LANGUAGE_DESC", "Biedra Valoda");
define("UE_LAN_COUNTRY", "Valts");
define("UE_LAN_COUNTRY_DESC", "Biedra Valts (Iekļaut db tabulas)");
define("LAN_UE_FAIL_HOMEPAGE", "Nederīgs ieraksts mājas lapā vidē");


?>