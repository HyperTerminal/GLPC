<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Augšupielāde");
define("LAN_UL_001", "Nederīga e-pasta adrese");
define("LAN_UL_002", "Jums nav pareizās atļaujas, lai augšupielādēt failus uz šī servera.");
define("LAN_UL_020", "Kļūda");
define("LAN_UL_021", "Augšupielādes Pārkāpums");
define("LAN_UL_032", "Jums jāizvēlas kategorija");
define("LAN_UL_033", "Jums jāievada derīga e-pasta adrese");
define("LAN_UL_034", "Jums jānorāda faila nosaukums");
define("LAN_UL_035", "Jums ir jāievada apraksts");
define("LAN_UL_036", "Jums jānorāda failu ko augšupielādēt");
define("LAN_UL_037", "Jums jānorāda kategorija");
define("LAN_UL_038", "");
define("LAN_61", "Jūsu Vārds:");
define("LAN_112", "E-pasta adrese:");
define("LAN_144", "Majas Lapa:");
define("LAN_402", "Jums jābūt reģistrētam lietotājam, lai augšupielādētu failus uz šī servera.");
define("LAN_404", "Paldies. Jūsu augšupielādes tagad vērtēs administrators un nosūtīts uz vietas, ja nepieciešams.");
define("LAN_406", "Lūdzu ņemiet vērā");
define("LAN_407", "Jebkuri citi augšupielādēti datņu veidi tiks uzreiz dzēsti.");
define("LAN_408", "Uzsvēra");
define("LAN_409", "Faila Nosaukums");
define("LAN_410", "Versija");
define("LAN_411", "Fails");
define("LAN_412", "Ekrānatēli");
define("LAN_413", "Apraksts:");
define("LAN_414", "Strādājoš Demo");
define("LAN_415", "Ievadiet URL, tai vietā, kur demo var aplūkot");
define("LAN_416", "Iesniegt un Augšupielādēt");
define("LAN_417", "Augšupielādēt Failu");
define("LAN_418", "Max. Faila Izmērs:");
define("DOWLAN_11", "Kategorija");
define("LAN_419", "Atļautie paplašinājumi");
define("LAN_420", "lauki ir obligāti");


?>