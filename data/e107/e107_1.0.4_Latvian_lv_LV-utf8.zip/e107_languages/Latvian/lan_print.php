<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_PRINT_86", "kategorija:");
define("LAN_PRINT_87", "no");
define("LAN_PRINT_94", "Pievienoja");
define("LAN_PRINT_135", "Jaunumi:");
define("LAN_PRINT_303", "Jaunumi no");
define("LAN_PRINT_304", "Virsraksts:");
define("LAN_PRINT_305", "Apakšpozīcijā:");
define("LAN_PRINT_306", "Šis ir no:");
define("LAN_PRINT_307", "Printēt šo lapu");
define("LAN_PRINT_1", "printēt draudzīgi");


?>