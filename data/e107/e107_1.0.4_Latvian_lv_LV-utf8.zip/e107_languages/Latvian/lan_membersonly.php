<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Biedri Tikai");
define("LAN_MEMBERS_0", "liegums");
define("LAN_MEMBERS_1", "Šis ir liegums.");
define("LAN_MEMBERS_2", "Lai piekļuvi lūdzu <a href='".e_LOGIN."'>Piesakieties</a>");
define("LAN_MEMBERS_3", "vai <a href='".e_SIGNUP."'>reģistrējies</a> kā biedrs");
define("LAN_MEMBERS_4", "Noklikšķiniet šeit, lai atgrieztos uz sākumlapu");


?>