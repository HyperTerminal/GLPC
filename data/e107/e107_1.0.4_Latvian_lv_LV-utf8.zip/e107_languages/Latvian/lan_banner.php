<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Reklāma");
define("BANNERLAN_16", "Lietotājvārds:");
define("BANNERLAN_17", "Parole:");
define("BANNERLAN_18", "Turpināt");
define("BANNERLAN_19", "Lūdzu ievadiet Jūsu klienta pieteikšanās lietotājvārdu un paroli, lai turpinātu!");
define("BANNERLAN_20", "Atvainojiet, neizdevās atrast šo informāciju datu bāzē. Lūdzu sazinieties ar vietnes administratoru lai iegūtu informāciju.");
define("BANNERLAN_21", "Reklāmas Statistika");
define("BANNERLAN_22", "Klients");
define("BANNERLAN_23", "Reklāmas ID");
define("BANNERLAN_24", "Vidējo klikšķu skaits");
define("BANNERLAN_25", "Klikšķu %");
define("BANNERLAN_26", "Seansi");
define("BANNERLAN_27", "Pasūtītie Seansi");
define("BANNERLAN_28", "Palikuši Seansi");
define("BANNERLAN_29", "Nav reklāmas");
define("BANNERLAN_30", "Bez Limita");
define("BANNERLAN_31", "Nav piemērojams");
define("BANNERLAN_32", "Jā");
define("BANNERLAN_33", "Nē");
define("BANNERLAN_34", "Beigas:");
define("BANNERLAN_35", "Vidējo klikšķu skaits no IP");
define("BANNERLAN_36", "Aktīvs:");
define("BANNERLAN_37", "Sākts:");
define("BANNERLAN_38", "Kļūda");


?>