<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Faili");
define("LAN_dl_1", "(Ierobežots)");
define("LAN_dl_2", "Pagaidām te nav neviena faila! Lūdzu pārbaudiet vēlāk!");
define("LAN_dl_3", "Šajā Kategorijā nav neviena Faila pagaidām!");
define("LAN_dl_4", "Faili Pieejami:");
define("LAN_dl_5", "Kopējais failu izmērs:");
define("LAN_dl_6", "Faili lejupielādēti:");
define("LAN_dl_7", "Apraksts");
define("LAN_dl_8", "Iegūt");
define("LAN_dl_9", "Atgriezties uz Kategoriju saraksta");
define("LAN_dl_10", "Izmērs");
define("LAN_dl_11", "Bilde");
define("LAN_dl_12", "Vērtējums");
define("LAN_dl_13", "Nav vērtēts");
define("LAN_dl_14", "Vērtēt šo failu");
define("LAN_dl_15", "Paldies par vērtējumu");
define("LAN_dl_16", "Lejupielāde(s) no:");
define("LAN_dl_17", "faili");
define("LAN_dl_18", "Faili");
define("LAN_dl_19", "Kategorija");
define("LAN_dl_20", "Faili");
define("LAN_dl_21", "Izmērs");
define("LAN_dl_22", "Datums");
define("LAN_dl_23", "Nosaukums");
define("LAN_dl_24", "Autors");
define("LAN_dl_25", "Augošā");
define("LAN_dl_26", "Dilstošā");
define("LAN_dl_27", "Iet");
define("LAN_dl_28", "Vārds");
define("LAN_dl_29", "DL's");
define("LAN_dl_30", "Autora E-Pasts");
define("LAN_dl_31", "Autora www");
define("LAN_dl_32", "Fails");
define("LAN_dl_33", "Iepriekšējais");
define("LAN_dl_34", "Nākamais");
define("LAN_dl_35", "Atpakaļ pie saraksta");
define("LAN_dl_36", "Jauns Fails");
define("LAN_dl_37", "Skatīt");
define("LAN_dl_38", "Kārtot kā:");
define("LAN_dl_39", "Šķirot");
define("LAN_dl_40", "Apskatīt Attēlus");
define("LAN_dl_41", "Meklēt Failus");
define("LAN_dl_42", "Apakš-Kategorija");
define("LAN_dl_43", "balss");
define("LAN_dl_44", "balsis");
define("LAN_dl_45", "Ziņot par bojātu lejupielādi");
define("LAN_dl_46", "Spied šeit, lai lejupielādētu");
define("LAN_dl_47", "Par rakstu tika paziņots");
define("LAN_dl_48", "Par Failu tika paziņots Administrātortam<br />Paldies.");
define("LAN_dl_49", "Atgriezties pie Failiem");
define("LAN_dl_50", "Ziņot par bojātu lejupielādi administratoram");
define("LAN_dl_51", "Faila Ziņošana:");
define("LAN_dl_52", "Ciemiņš");
define("LAN_dl_53", "Apskatīt Failu");
define("LAN_dl_54", "Administrators tiks informēts par šo lejupielādi, lūdzu, atstājiet ziņu, ja domājat, ka tas nepieciešams.");
define("LAN_dl_55", "<b>Neizmantojiet</b> šo formu, lai sazinātos ar administrātoru citā jautājumā!");
define("LAN_dl_57", "ziņoja");
define("LAN_dl_58", "Par šo lejupielādi ziņots no saites");
define("LAN_dl_59", "Ziņoja:");
define("LAN_dl_60", "Bojats lejupielādes ziņojums");
define("LAN_dl_61", "Faila Kļūda");
define("LAN_dl_62", "Jums ir liegts lejupielādēt šo failu, Jūs esat pārsnieguši savu lejupielādes kvotu");
define("LAN_dl_63", "Jums nav pareizās atļaujas, lai lejupielādētu šo failu.");
define("LAN_dl_64", "Atpakaļ");
define("LAN_dl_65", "Fails nav atrasts");
define("LAN_dl_66", "Izvelies lejupielādes spoguli");
define("LAN_dl_67", "Lūdzu izvelies spoguli, kuru izmantot ...");
define("LAN_dl_68", "Spoguļa Hosts");
define("LAN_dl_70", "Vieta");
define("LAN_dl_71", "Par");
define("LAN_dl_72", "Pieprasījuma fails:");
define("LAN_dl_73", "Lejupielādēt no šī spoguļa:");
define("LAN_dl_74", "Kopā lejupielādes no šī spoguļa:");
define("LAN_dl_75", "Bildes nav pieejamas!");
define("LAN_dl_76", "Iet uz Lapu");
define("LAN_dl_77", "Faili");
define("LAN_dl_78", "Lejupielāde ir atspējota vai pārtraukta. Lūdzu pārbaudiet [lejupielāžu] vietā tādu jaunāku versiju.");
define("LAN_dl_79", "Lūdzu, pagaidiet brīdi, pirms [lejupielādes atkal].");
define("LAN_dl_80", "Lūdzu, iespējojiet cookies/sīkfailus un [mēģiniet vēlreiz].");
define("LAN_dl_81", "Sīkfailus/Cookies Pieprasīti");
define("LAN_dl_82", "Lūdzu Uzgaidiet");
define("LAN_dl_83", "Lejupielāde sāksies pēc brīža ...");
define("LAN_dl_84", "Ja lejupielāde nesākas dažu sekunžu laikā, lūdzu, [klikšķiniet šeit].");


?>