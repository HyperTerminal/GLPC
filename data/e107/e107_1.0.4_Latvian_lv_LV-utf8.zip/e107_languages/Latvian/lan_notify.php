<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("NT_LAN_US_1", "lLetotāja Reģistrācija");
define("NT_LAN_UV_1", "Lietotāja Reģistrācija Apstiprināta");
define("NT_LAN_UV_2", "Biedra ID:");
define("NT_LAN_UV_3", "Lietotāja vārds:");
define("NT_LAN_UV_4", "Biedra IP:");
define("NT_LAN_LI_1", "Lietotājs pieteicies");
define("NT_LAN_LO_1", "Lietotājs atslēdzies");
define("NT_LAN_LO_2", "izgājis no vietnes");
define("NT_LAN_FL_1", "Plūdu Ban");
define("NT_LAN_FL_2", "IP adrese nobloķēta par Plūdiem");
define("NT_LAN_SN_1", "Jaunums Ievietots");
define("NT_LAN_NU_1", "Atjaunots");
define("NT_LAN_ND_1", "Jaunumi Izdzēsti");
define("NT_LAN_ND_2", "Dzēsts Jaunuma ID");
define("NT_LAN_CM_1", "Lietotāja Komentārs Gaida apstiprinājumu");


?>