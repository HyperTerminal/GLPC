<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Pārbaudīt/Labot Valodas Failus");
define("LAN_CHECK_2", "Pārbaudī");
define("LAN_CHECK_3", "Pārbaude no");
define("LAN_CHECK_4", "Fails Trūkst!");
define("LAN_CHECK_5", "Frāze trūkst!");
define("LAN_CHECK_7", "Frāze");
define("LAN_CHECK_8", "Fails Trūkst...");
define("LAN_CHECK_9", "faili trūkst...");
define("LAN_CHECK_10", "Kritiska Kļūda:");
define("LAN_CHECK_11", "Nav faili trūkst!");
define("LAN_CHECK_12", "Fails ir Nepareizs...");
define("LAN_CHECK_13", "faili ir nepareizi...");
define("LAN_CHECK_14", "Visi esošie faili ir derīgi!");
define("LAN_CHECK_15", "Nelegālas rakstzīmes vai atstarpes atrastas pirms '<?php' vai pēc '?>'");
define("LAN_CHECK_16", "Orģināls fails");
define("LAN_CHECK_17", "Rakstot gadījās problēma, mēģinot saglabāt failu.");
define("LAN_CHECK_18", "Valodas failus standarta formātā nav pieejami šim spraudnim/tēmai.");
define("LAN_CHECK_19", "Nav-UTF-8 rakstuzīmes atrastas!");
define("LAN_CHECK_20", "Izveidot Valodas Paku");
define("LAN_CHECK_21", "Pārbaudīt Velreiz");
define("LAN_CHECK_22", "Dizains");
define("LAN_CHECK_23", "Kļūdas Atrastas!");
define("LAN_CHECK_24", "Pārskats");
define("LAN_CHECK_25", "Dizaini");
define("LAN_CHECK_26", "Fails");


?>