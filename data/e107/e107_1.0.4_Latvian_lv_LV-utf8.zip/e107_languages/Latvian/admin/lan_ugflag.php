<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Uzturēšana iestatījumi atjaunoti");
define("UGFLAN_2", "Aktivizēt Uzturēšanu");
define("UGFLAN_3", "Atjaunot Uzturēšanas Iestatījumus");
define("UGFLAN_4", "Uzturēšanas Iestatījumi");
define("UGFLAN_5", "Teksts, kas attelosies, kad saite būs izslēgta!");
define("UGFLAN_6", "Atstaj tukšu, lai attēlotu noklusēto ziņu!");
define("UGFLAN_8", "Limitēta piekļuve -  Admini Tikai!");
define("UGFLAN_9", "Limiteta Piekļuve - Īpašnieks Tikai!");


?>