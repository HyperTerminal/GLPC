<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admina Žurnāls");
define("LAN_ADMINLOG_1", "Datums");
define("LAN_ADMINLOG_2", "Nosaukums");
define("LAN_ADMINLOG_3", "Apraksts");
define("LAN_ADMINLOG_4", "Biedra IP");
define("LAN_ADMINLOG_5", "Biedra ID");
define("LAN_ADMINLOG_6", "Informatīvā Ikona");
define("LAN_ADMINLOG_7", "Informatīvā Ziņa");
define("LAN_ADMINLOG_8", "Paziņojuma ikona");
define("LAN_ADMINLOG_9", "Paziņojuma Ziņa");
define("LAN_ADMINLOG_10", "Brīdinājuma Ikona");
define("LAN_ADMINLOG_11", "Brīdinajuma Ziņa");
define("LAN_ADMINLOG_12", "Letāla Ikona");
define("LAN_ADMINLOG_13", "Letalas Kļūdas Ziņa");


?>