<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Kodola Iestatījumi Atjaunoti datubazē");
define("DBLAN_2", "Noklikšķiniet uz pogas, lai saglabātu backup jūsu E107 datubāzē");
define("DBLAN_3", "Backup SQL datubāzi");
define("DBLAN_4", "Noklikšķiniet uz pogas, lai pārbaudītu derīgumu no E107 datubāzes");
define("DBLAN_5", "Pārbaudīt datubāzes derīgumu");
define("DBLAN_6", "Noklikšķiniet uz pogas, lai optimizētu savu E107 datubāzi");
define("DBLAN_7", "Optimizēt SQL datubāzes");
define("DBLAN_8", "Noklikšķiniet uz pogas, lai backup jūsu kodola iestatījumus");
define("DBLAN_9", "Backup kodolu");
define("DBLAN_10", "Datubāzes Utilities");
define("DBLAN_11", "MySQL datubāze");
define("DBLAN_12", "optimizēta");
define("DBLAN_13", "Atpakaļ");
define("DBLAN_14", "Darīts");
define("DBLAN_15", "Noklikšķiniet uz pogas, lai pārbaudītu visus pieejamos dB atjauninājumus");
define("DBLAN_16", "Pārbaudīt atjauninājumus");
define("DBLAN_17", "Pref. nosaukums");
define("DBLAN_18", "Pref. Vērtības");
define("DBLAN_19", "Noklikšķiniet uz pogas, lai atvērtu iestatījumu redaktors (tikai pieredzējušiem lietotājiem)");
define("DBLAN_20", "Iestatījumi redaktors");
define("DBLAN_21", "Dzēst Pārbaudīto");
define("DBLAN_22", "Spraudnis: Skatīt un Skenēt");
define("DBLAN_23", "Skenešana Pabeigtaa");
define("DBLAN_24", "Nosaukums");
define("DBLAN_25", "Mape");
define("DBLAN_26", "Uzstadītie add-ons");
define("DBLAN_27", "Uzstādīts");
define("DBLAN_28", "Noklikšķiniet uz pogas, lai skenētu spraudnis katalogi izmaiņām");
define("DBLAN_29", "Skenēt spraudņu mapi");
define("DBLAN_30", "(Ja addon parāda kļūdu, pārbaudiet rakstzīmju ārpus PHP atvēršanas / aizvēršanas taga)");
define("DBLAN_31", "Izturēts");
define("DBLAN_32", "Kļūda");
define("DBLAN_33", "nepieejams");
define("DBLAN_34", "Nav pārbaudīts");
define("DBLAN_35", "Noklikšķiniet uz pogas, lai pārbaudītu derīgumu lietotāja tabulas");
define("DBLAN_36", "Pārbaudiet lietotāja tabulu");


?>