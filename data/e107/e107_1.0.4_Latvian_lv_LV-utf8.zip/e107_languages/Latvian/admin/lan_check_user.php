<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_CKUSER_01", "Pārbaudiet lietotāju datubāzi");
define("LAN_CKUSER_02", "as pārbaudīs dažādas iespējamās problēmas ar Jūsu lietotāja datu bāzē");
define("LAN_CKUSER_03", "Ja jums ir daudz lietotāju, tas var aizņemt kādu laiku, vai patilgāk.");
define("LAN_CKUSER_04", "Darbojas");
define("LAN_CKUSER_05", "Pārbaudiet dublēto pieteikšanās vārdus");
define("LAN_CKUSER_06", "Izvēlieties funkciju, lai veiktu");
define("LAN_CKUSER_07", "Dublēti Lietotāja Vārdi atrasti");
define("LAN_CKUSER_08", "Nav dublikāta atrasta");
define("LAN_CKUSER_09", "Lietotājvārds");
define("LAN_CKUSER_10", "Lietotāja ID");
define("LAN_CKUSER_11", "Attelotais Vārds");
define("LAN_CKUSER_12", "Pārbaudiet dublikata e-pasta adreses");
define("LAN_CKUSER_13", "Dublikāta e-pasta adreses atrastas");
define("LAN_CKUSER_14", "E-pasta adreses");
define("LAN_CKUSER_15", "Nav Dublikāta Atrasta");
define("LAN_CKUSER_16", "Atrast ierakstus, kur lietotājvārds ir kāds cits pieteikšanās vārds");
define("LAN_CKUSER_17", "Pretrunīgas lietotāja vārdu un pieteikšanas vārds");
define("LAN_CKUSER_18", "Lietotajs A");
define("LAN_CKUSER_19", "Lietotajs B");
define("LAN_CKUSER_20", "");


?>