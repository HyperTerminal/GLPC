<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("FC_LAN_1", "Failu Inspektors");
define("FC_LAN_2", "Skenēšanas Opcijas");
define("FC_LAN_3", "Rādīt");
define("FC_LAN_4", "Visu");
define("FC_LAN_5", "Kodola failus");
define("FC_LAN_6", "Integritāti Fail Tikai");
define("FC_LAN_7", "Nav Kodola faili");
define("FC_LAN_8", "Pārbaudīt integritāti Kodola faili");
define("FC_LAN_9", "Ieslēgt");
define("FC_LAN_10", "Izslegt");
define("FC_LAN_11", "Skenēt Tagad");
define("FC_LAN_12", "Nekas");
define("FC_LAN_13", "Trūkst Kodola faili");
define("FC_LAN_14", "Attelot Rezultatus kā");
define("FC_LAN_15", "Mapes koka sarakstu");
define("FC_LAN_16", "List");
define("FC_LAN_17", "Stīgu Atbilstība");
define("FC_LAN_18", "Regulāra izteiksme");
define("FC_LAN_19", "Rādīt Līnijas Nunurus");
define("FC_LAN_20", "Rādīt atbilstības līnijas");
define("FC_LAN_21", "Vecie Kodola Faili");
define("FR_LAN_1", "Skenešana");
define("FR_LAN_2", "Skenēšana Rezultati");
define("FR_LAN_3", "Parskats");
define("FR_LAN_4", "Kodola faili");
define("FR_LAN_5", "Nav Kodola faili");
define("FR_LAN_6", "Kopā faili");
define("FR_LAN_7", "Integrētā pārbaude");
define("FR_LAN_8", "Kodola faili iet cauri");
define("FR_LAN_9", "Kodola faili neiet cauri");
define("FR_LAN_10", "Iespejamie iemesli, failie, kas neiet cauri");
define("FR_LAN_11", "Fails ir Korumpēts");
define("FR_LAN_12", "Tas varētu būt vairāku iemeslu dēļ, piemēram, faila tiek bojāti ar zip, bojāti laikā
ieguve vai bojāti laikā faila augšupielādes caur FTP. Jums vajadzētu mēģināt vēlreiz augšupielādējot failu uz servera
un atkārtoti palaist skenēšanu, lai redzētu, vai tas atrisina kļūdu.");
define("FR_LAN_13", "Failam beidzies termiņš");
define("FR_LAN_14", "Ja fails ir no vecākas atbrīvošanu E107 ar versiju jūs esat
darbojas tad tas nebūs integritātes pārbaudi. Pārliecinieties, ka esat augšupielādējis jaunāko versiju faila.");
define("FR_LAN_15", "Fails ticis labots");
define("FR_LAN_16", "Ja esat rediģējis šo failu, un jebkurā veidā tas neiztur integritātes pārbaudi. ja jūs
tīši labojāt šo failu, tad jums nav jāuztraucas un var ignorēt šo integritātes pārbaudes. Ja tomēr
fails rediģēja kāds cits bez atļaujas vēlēsities vēlreiz augšupielādēt pareizu versiju
šis fails no E107 zip");
define("FR_LAN_17", "Ja esat SVN lietotājs");
define("FR_LAN_18", "Ja jūs darbināt kasēm no E107 SVN savā vietā, nevis oficiālu E107 stabils
relīzes, tad jūs atklāsiet, faili nav integritātes pārbaudi, jo tie ir rediģēja dev
Pēc jaunākās galvenais tēls momentuzņēmums tika izveidots.");
define("FR_LAN_19", "Faili neizturēja pārbaudi");
define("FR_LAN_20", "Visi faili iztureja pārbaudi");
define("FR_LAN_21", "nekas");
define("FR_LAN_22", "Trūkst kodola faili");
define("FR_LAN_23", "Atbilstīna nav atrasta");
define("FR_LAN_24", "Vecie kodola faili");
define("FR_LAN_25", "integritāti neaprēķināmi");
define("FR_LAN_26", "Brīdinājuma! Zināma nedrošība noteikta!");
define("FR_LAN_27", "Ir faili uz servera, kas ir zināms, var izmantot, un tie nekavējoties jāizņem.");
define("FR_LAN_28", "Zināmi nestabili faili");


?>