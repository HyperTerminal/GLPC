<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("SEALAN_1", "Meklēšanas Uzstadījumi");
define("SEALAN_2", "Zīmju skaits, kas attēloti meklēšanas rezultātu kopsavilkumā");
define("SEALAN_3", "Meklēšana Sakārtot pēc:");
define("SEALAN_6", "Komentāri");
define("SEALAN_7", "Reģistrēti Biedri");
define("SEALAN_10", "Rādīt nozīmīguma vērtību:");
define("SEALAN_11", "Ļauj lietotājam izvēlēties meklējamus jomas:");
define("SEALAN_12", "Ierobežot laiku, kas dots starp meklēšanu (maks. 5 min):");
define("SEALAN_13", "Ierobežot līdz vienam meklēšanas katras");
define("SEALAN_14", "sekundes");
define("SEALAN_15", "Meklēšana lapa pieejama lietotāja klasē");
define("SEALAN_16", "Uz");
define("SEALAN_17", "Izslēgts");
define("SEALAN_18", "Pārmeklējami Komentāri rajoni (ja komentāri meklēšana ir aktivizēta)");
define("SEALAN_19", "Ļauj lietotājiem meklēt vairāk nekā vienu zonu, vienlaicīgi:");
define("SEALAN_20", "Vispārīgie iestatījumi");
define("SEALAN_21", "pārmeklējamas zonas");
define("SEALAN_22", "Noklusets");
define("SEALAN_23", "Alternatīva:");
define("SEALAN_24", "Tips");
define("SEALAN_25", "Klases");
define("SEALAN_26", "Pre-Virsraksta Teksts");
define("SEALAN_30", "Izcelt atslēgvārdus tekstā lapā:");
define("SEALAN_31", "PHP limits uz");
define("SEALAN_32", "rezultāti (atstājiet tukšu, bez ierobežojuma)");
define("SEALAN_33", "Nevarēja pāriet uz MySQL kārtošanas metodes, kā tam nepieciešama vismaz versija 4.0.1 MySQL.");
define("SEALAN_34", "Jūsu versija ir pašlaik");
define("SEALAN_35", "Meklējams jomas atlases metode:");
define("SEALAN_36", "nolaižamajā");
define("SEALAN_37", "Čatā");
define("SEALAN_38", "Radio");
define("SEALAN_39", "Pielāgotas lapas");
define("LAN_SEARCH_98", "Jaunumi");
define("LAN_197", "Lejupielades");
define("LAN_418", "Pielāgotas lapas");
define("SEALAN_40", "Meklēšanas Opcijas");
define("SEALAN_41", "Galvenā");
define("SEALAN_42", "Uzstadījumi");
define("SEALAN_43", "Labot meklēsanas iestatījumus priekš");
define("SEALAN_44", "Lietotājs klase atļauts meklēt šajā jomā");
define("SEALAN_45", "Rezultātu skaits parādīti vienā lapā");
define("SEALAN_46", "Zīmju skaits, meklēšanas rezultātu kopsavilkums");
define("SEALAN_47", "Tikai atbilst pilniem vārdiem:");
define("SEALAN_48", "Šis iestatījums attiecas tikai tad, ja meklēšanas kārtošanas metode ir PHP. Ja jūsu vietne ietver ideogrāfisks valodas, piemēram, ķīniešu un japāņu jums ir jābūt šim Izslēgtam.");
define("SEALAN_49", "Ja jūsu vietne ietver ideogrāfisks valodas, piemēram, ķīniešu un japāņu, jums jāizmanto PHP šķirošanas metodi.");


?>