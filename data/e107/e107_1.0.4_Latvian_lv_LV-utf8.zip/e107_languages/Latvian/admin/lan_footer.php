<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Saite");
define("FOOTLAN_2", "Īpašnieks");
define("FOOTLAN_3", "Versija");
define("FOOTLAN_4", "būvēts");
define("FOOTLAN_5", "Admina Dizains");
define("FOOTLAN_6", "no");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Uzstādīts");
define("FOOTLAN_9", "Serveris");
define("FOOTLAN_10", "hosts");
define("FOOTLAN_11", "PHP Versija");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Site Info");
define("FOOTLAN_14", "Rādīt Docs");
define("FOOTLAN_15", "Dokumentācija");
define("FOOTLAN_16", "Datubāze");
define("FOOTLAN_17", "Kodējums");
define("FOOTLAN_18", "Saites Dizains");
define("FOOTLAN_19", "Pašreizējais servera laiks");
define("FOOTLAN_20", "Drošības Līmenis");


?>