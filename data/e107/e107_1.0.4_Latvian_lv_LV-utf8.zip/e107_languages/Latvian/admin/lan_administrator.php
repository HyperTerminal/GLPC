<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("ADMSLAN_0", "Jauns lietotājs / admin ierakstu radīt");
define("ADMSLAN_1", "tagad ir admina status");
define("ADMSLAN_2", "atjaunots datubāzē");
define("ADMSLAN_3", "ir Īpašnieks, un nevar tikt Labots");
define("ADMSLAN_4", "Turpināt");
define("ADMSLAN_5", "Kļūda!");
define("ADMSLAN_6", "ir Īpašnieks un nevar tikt dzēsts!");
define("ADMSLAN_13", "Esošie Admini");
define("ADMSLAN_16", "Admina Vārds");
define("ADMSLAN_17", "Admina Parole");
define("ADMSLAN_18", "Atļaujas");
define("ADMSLAN_19", "Mainīt vietnes iestatījumus");
define("ADMSLAN_20", "Mainīt Izvēlnes");
define("ADMSLAN_21", "Modificēt Adminu atļaujas");
define("ADMSLAN_22", "Pārvaldīt Lietotajus/banus");
define("ADMSLAN_23", "Izveidot / rediģēt pielāgoto lapas / izvēlnes");
define("ADMSLAN_24", "Pārvaldīt lejupielādes kategorijas");
define("ADMSLAN_25", "Augšupielādēt / pārvaldīt failus");
define("ADMSLAN_26", "Pārraudzīt ziņu kategorijas");
define("ADMSLAN_27", "Pārraudzīt linku katagorijas");
define("ADMSLAN_28", "Noslēgt saiti un labošanas, uzlabojumu darbiem!");
define("ADMSLAN_29", "Pārvaldīt Reklāmas");
define("ADMSLAN_30", "Konfigurēt ziņu feed virsrakstus");
define("ADMSLAN_31", "Konfigurēt Emocijas");
define("ADMSLAN_32", "Konfigurēt sākumlapas saturu");
define("ADMSLAN_33", "Konfigurēt žurnālu/status");
define("ADMSLAN_34", "Konfigurēt meta tags");
define("ADMSLAN_35", "Konfigurēt failu augšupielādes");
define("ADMSLAN_36", "Konfigurēt Bilžu Iestatījumus");
define("ADMSLAN_37", "Pārvaldīt Komentārus");
define("ADMSLAN_39", "Rakstīt Jaunumus");
define("ADMSLAN_40", "Rakstīt Linku");
define("ADMSLAN_44", "Rakstīt Failu");
define("ADMSLAN_45", "Rakstīt Aptauju");
define("ADMSLAN_46", "Sveicienu Ziņa");
define("ADMSLAN_47", "Pārvaldīt Iesniegtās Ziņās");
define("ADMSLAN_49", "Atzīmēt Visu");
define("ADMSLAN_51", "Noņemt Atzīmes Visas");
define("ADMSLAN_52", "Atjaunot Administrāciju");
define("ADMSLAN_53", "Pievienot Administrātoru");
define("ADMSLAN_54", "Saites Administrātors");
define("ADMSLAN_55", "Lauks(i) atstāti tukši");
define("ADMSLAN_56", "Saites Administrācija");
define("ADMSLAN_58", "Saites Īpašnieks");
define("ADMSLAN_59", "Noņemt Admina Status");
define("ADMSLAN_60", "Vai tiešām vēlaties noņemt administratora statusu no");
define("ADMSLAN_61", "Administrātors Dzēsts");
define("ADMSLAN_62", "Spraudņu Pārvaldnieks");
define("ADMSLAN_64", "Notīrīt Sistēmas Kešatmiņu");
define("ADMSLAN_65", "Konfigurēt pasta uzstādījumus un mailout");
define("ADMSLAN_66", "Konfigurēt meklēšanu");
define("ADMSLAN_67", "Skenēt ar faila inspektoru");
define("ADMSLAN_68", "Konfigurēt e-pasta paziņojumu");
define("ADMSLAN_69", "ir jau administrators un ir jau labots");
define("ADMSLAN_70", "Atgriezties pie administratora Saraksta");
define("ADMSLAN_71", "Noklikšķiniet šeit, lai parādītu privilēģijas");
define("ADMSLAN_76", "Pārvaldīt valodas pakas");


?>