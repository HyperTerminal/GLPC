<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("FLALAN_1", "Neizdevās pieteikšanās mēģinājumi");
define("FLALAN_2", "Nav neizdevās pieteikšanās mēģinājumi, ir pieteicies");
define("FLALAN_3", "Mēģinājums (-i) svītroti");
define("FLALAN_4", "Lietotājs mēģināja piesakieties, izmantojot nepareizu lietotājvārdu / paroli");
define("FLALAN_5", "IP(s) nobloķēta");
define("FLALAN_6", "Datums");
define("FLALAN_7", "Dati");
define("FLALAN_8", "IP adrese/Hosts");
define("FLALAN_9", "Opcijas");
define("FLALAN_10", "Dzēst / Ban pārbaudītie ieraksti");
define("FLALAN_11", "pārbaudīt visus izdzēst rūtiņas");
define("FLALAN_12", "izņemt atzīmēšanu visas dzēst rūtiņas");
define("FLALAN_13", "pārbaudīt visus ban rūtiņas");
define("FLALAN_14", "izņemt atzīmēšanu visas ban rūtiņas");
define("FLALAN_15", "Šādu IP adrese (-es) ir automātiskās aizliegta - lietotājs centās vairāk nekā desmit neizdevās pieteikšanās");
define("FLALAN_16", "dzēst šo auto aizlieguma sarakstu");
define("FLALAN_17", "Auto-ban svītrots saraksts");


?>