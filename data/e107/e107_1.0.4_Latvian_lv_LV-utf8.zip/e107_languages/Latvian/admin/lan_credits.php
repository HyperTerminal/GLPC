<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "e107 Informācija");
define("CRELAN_1", "Informācija");
define("CRELAN_2", "Šeit ir no trešās puses programmatūru / izmantoto resursu E107 saraksts.E107 izstrādes komanda vēlas personīgi pateikties attīstītājus turpmāk, kas ļauj mums to izplatīt to kodu ar e107, un atbrīvojot viņu programmatūru saskaņā ar GPL licenci.");
define("CRELAN_3", "Visas tiesības aizsargātas");
define("CRELAN_4", "Rādīt E107 Dev Team");
define("CRELAN_5", "Rādīt trešo personu skriptus");
define("CRELAN_6", "e107 v0.7 tika vērsta uz Jums ...");
define("CRELAN_7", "versija");
define("CRELAN_8", "atļauja piešķirta");
define("CRELAN_9", "Licenze");
define("CRELAN_10", "MagpieRSS nodrošina XML bāzes (Expat) RSS parsētājs PHP.");
define("CRELAN_11", "PclZip bibliotēka piedāvā kompresijas un ieguves funkcijas ZIP formāta arhīva (WinZip, PKZIP).");
define("CRELAN_12", "PclTar piedāvājam iespēju arhivēt sarakstu failu vai direktoriju ar vai bez kompresijas.Arhīvi rada PclTar ir nolasāms lielāko gzip / darvas pieteikumus un Windows WinZip pieteikumu.");
define("CRELAN_13", "TinyMCE ir platformas neatkarīgs tīmekļa Javascript HTML WYSIWYG redaktors kontrole izdalījies kā Open Source zem LGPL ar Moxiecode Systems AB. Tā ir spēja pārvērst HTML textarea laukus vai citus HTML elementus ar redaktoru gadījumos.");
define("CRELAN_14", "Ikonas izmanto E107");
define("CRELAN_15", "Pilna attēlots pasta pārsūtīšanas klase PHP");
define("CRELAN_16", "Izvēlnes sistēma izmanto Jayya tēmu");
define("CRELAN_17", "Uznirstošo kalendārs logrīks");
define("CRELAN_18", "PDF atbalsts");
define("CRELAN_19", "UTF-8 PDF atbalsts");
define("CRELAN_20", "");
define("CRELAN_21", "Always a pressure..err..pleasure!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Up and forward!");
define("CRELAN_30", "");


?>