<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("BNRLAN_1", "Reklāma dzēsta.");
define("BNRLAN_2", "Lūdzu, apstipriniet, ka vēlaties dzēst šo reklāmu - vienreiz svītrots to nevar atgūt");
define("BNRLAN_5", "Apstiprināt Reklāmas dzēšanu");
define("BNRLAN_6", "Dzēšana atcelta.");
define("BNRLAN_7", "Esošās Reklāmas");
define("BNRLAN_8", "Reklāmas ID");
define("BNRLAN_9", "Klients");
define("BNRLAN_10", "Vidējo klikšķu skaits");
define("BNRLAN_11", "Klikšķi %");
define("BNRLAN_12", "Seansi");
define("BNRLAN_13", "Seansi palikuši");
define("BNRLAN_15", "Nav Reklamas Pagaidām!");
define("BNRLAN_16", "Bez Limita");
define("BNRLAN_17", "Neviens");
define("BNRLAN_21", "Beigas");
define("BNRLAN_22", "Atjaunot Reklamu");
define("BNRLAN_23", "Pievienot Jaunu Reklamu");
define("BNRLAN_24", "Kompanija");
define("BNRLAN_25", "Izvelies esošo kompaniju");
define("BNRLAN_26", "enter new campaign");
define("BNRLAN_27", "Klients");
define("BNRLAN_28", "Izvelies esoso klientu");
define("BNRLAN_29", "Ievadi Jaunu Klientu");
define("BNRLAN_30", "Klienta Pieteikšanās");
define("BNRLAN_31", "Klienta Parole");
define("BNRLAN_32", "Reklamas Bilde");
define("BNRLAN_33", "Novirzīšanas URL");
define("BNRLAN_34", "Iegādāti Seansi");
define("BNRLAN_35", "Bez Limita");
define("BNRLAN_36", "Sākuma Datums");
define("BNRLAN_37", "Beigu Datums");
define("BNRLAN_38", "Tuks = nav limits");
define("BNRLAN_39", "Redzamības Klase");
define("BNRLAN_40", "Atjaunot Reklāmu");
define("BNRLAN_41", "Izveidot Jaunu Reklāmu");
define("BNRLAN_42", "Reklamas Rotēšanas Sistēma");
define("BNRLAN_43", "Izvēlies Reklāmas Bildi");
define("BNRLAN_45", "Sākts");
define("BNRLAN_46", "Kods");
define("BNRLAN_58", "Reklamas sākumlapa");
define("BNRLAN_59", "Izveidot Jaunu Reklamu");
define("BNRLAN_60", "Kompānija");
define("BNRLAN_61", "Reklamas Izvelne");
define("BNRLAN_62", "Reklamas Iespējas");
define("BNRLAN_63", "Reklāma Izveidota");
define("BNRLAN_64", "Reklāma Atjaunota");
define("BANNER_MENU_L1", "Sludinajums");
define("BANNER_MENU_L2", "Reklāmas Izvēlnes Konfigurācija Saglabata");
define("BANNER_MENU_L3", "Virsraksts");
define("BANNER_MENU_L5", "Reklamas Konfiguracija");
define("BANNER_MENU_L6", "Izvēlies kompanijas, kuras radīt izvelnē");
define("BANNER_MENU_L7", "Pieejamās Kompanijas");
define("BANNER_MENU_L8", "Izvelētās Kompānijas");
define("BANNER_MENU_L9", "Noņemt Izvelēto");
define("BANNER_MENU_L10", "Attēlošanas Tips");
define("BANNER_MENU_L18", "Atjaunot Izvelnes Uzstādījumus");
define("BANNER_MENU_L19", "Reklamu skaits ko attēlos:<br />Šis darbojas tikai tad, kad izvēlētas vairākas kompānijas");


?>