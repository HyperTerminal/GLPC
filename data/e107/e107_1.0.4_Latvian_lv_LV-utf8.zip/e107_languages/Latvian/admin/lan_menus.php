<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Redzams Visiem");
define("MENLAN_2", "Redzams Biedriem Tikai");
define("MENLAN_3", "Redzams Administratoriem Tikai");
define("MENLAN_4", "Redzams tikai:");
define("MENLAN_6", "Saglabat redzamības opcijas");
define("MENLAN_7", "Konfigurēt Redzamības Opcijas");
define("MENLAN_8", "redzamības Opcijas Atjaunotas");
define("MENLAN_9", "Jaunā pielāgotā izvēlne uzstādīta");
define("MENLAN_10", "Jauna Izvelne Uzstādīta");
define("MENLAN_11", "Izvelne Noņemta");
define("MENLAN_12", "Aktīvs: Izvelies Zonu");
define("MENLAN_13", "Aktivizēt Zonā");
define("MENLAN_14", "Zona");
define("MENLAN_15", "Deaktivizēt");
define("MENLAN_16", "Konfigurēt");
define("MENLAN_17", "Pacelt uz Augsu");
define("MENLAN_18", "Nolaist Zemāk");
define("MENLAN_19", "Pārvietot uz Zonu");
define("MENLAN_20", "Redzamība");
define("MENLAN_22", "Neaktīva Izvelne");
define("MENLAN_23", "Parvietot uz Apakšu");
define("MENLAN_24", "Parvietot uz Augšu");
define("MENLAN_25", "Funkcijas ...");
define("MENLAN_26", "Šī izvelne būs tikai<strong>Redzama</strong> sekojošās lapās");
define("MENLAN_27", "Šī izvēlne būs tikai<strong>Slēpta</strong> sekojošās lapās");
define("MENLAN_28", "Ievadiet vienu lapu katrā rindā, ievadiet pietiekami url atšķirt to pareizi. Ja jums ir nepieciešams izbeigšanu url, lai atbilstu tieši, izmantojiet! beigās lapas nosaukumu <br /> Piemēram: <strong> page.php?1</strong>");
define("MENLAN_29", "Izvēlieties izkārtojumu");
define("MENLAN_30", "Lai redzētu izvēlnes zonas un viņu nostāju pielāgotus izkārtojumus, izvēlieties pielāgoto izkārtojumu šeit:");
define("MENLAN_31", "Noklusētais Izkārtojums");
define("MENLAN_32", "Galvas Jaunumu Izkārtojums");
define("MENLAN_33", "Pielāgotas Izkārtojums");
define("MENLAN_34", "Embedded");
define("MENLAN_35", "konfigurēt Izvēlnes");
define("MENLAN_36", "Izvēlieties izvēlni, lai aktivizētu");
define("MENLAN_37", "un kur lai aktivizētu tos");
define("MENLAN_38", "Turiet nospiestu taustiņu CTRL, lai atlasītu vairākas izvēlnes.");


?>