<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Pārraudzīts");
define("MDCLAN_2", "Pagaidām nav komentāru!");
define("MDCLAN_3", "Biedrs");
define("MDCLAN_4", "Ciemiņš");
define("MDCLAN_5", "Atbloķēt");
define("MDCLAN_6", "Bloķēt");
define("MDCLAN_7", "apstiprināt");
define("MDCLAN_8", "Pārraudzīt Komentārus");
define("MDCLAN_9", "Brīdinājuma! Izdzēšot vecāku komentārus arī izdzēst visas atbildes!");
define("MDCLAN_10", "opcijas");
define("MDCLAN_11", "komentārs");
define("MDCLAN_12", "komentāri");
define("MDCLAN_13", "bloķēts");
define("MDCLAN_14", "slegt komentārus");
define("MDCLAN_15", "atverts");
define("MDCLAN_16", "slegts");
define("MDCLAN_17", "Nav komentāru kas gaida apstiprinājumu");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>