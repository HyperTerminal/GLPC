<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Adminu Palīdzība";
$text = "Izmantojiet šo lapu, lai rediģētu preferences, vai arī izdzēst vietņu administratoriem.Administrators būs tikai atļauja piekļūt funkcijām, kas tiek atzīmēta. <br /> <br />
Lai izveidotu jaunu admin iet uz lietotāja config lapu un atjaunināt esošo lietotājam admin statusu.";
$ns -> tablerender($caption, $text);
?>