<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ja Jums ir pārkārtošanās E107 vai vienkārši nepieciešams, lai jūsu vietnes offline uz brīdi vienkārši atzīmēt apkopes lodziņu un jūsu apmeklētājiem tiks novirzīts uz lapu, paskaidrojot vieta ir uz leju remontam. Kad esat pabeidzis ANO atzīmējiet lodziņu, lai atgrieztos vietā, lai normāli.";

$ns -> tablerender("Maintenance", $text);
?>
