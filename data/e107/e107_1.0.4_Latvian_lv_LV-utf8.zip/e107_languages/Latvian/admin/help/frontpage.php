<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Sākumlapas Palīdzība";
$text = "No šā ekrāna jūs varat izvēlēties, ko rādīt kā priekšējā lapā jūsu vietā, noklusējuma ir jaunumi.";
$ns -> tablerender($caption, $text);
?>