<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Jūsu preferences ļauj jums norādīt visus svarīgos uzstādījumus jūsu vietnē, no vietnes nosaukumu un aprakstu, lai aizsardzības pret plūdiem un lādēšanās filtrāciju.";
$ns -> tablerender("Preferences Help", $text);
?>