<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Izmantojiet šo lapu, lai konfigurētu jūsu pasta iestatījumu novietnes pasta funkcijas.Ārā veidā pasts arī ļauj izsūtīt pa pastu shot visiem jūsu lietotājiem.";
$ns -> tablerender("Mail Help", $text);
?>