<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Theme Manager ļauj jums noteikt jūsu vietnes sabiedrisko tēmu un savu admin zonas dizainu.";
$ns -> tablerender("Theme Manager Help", $text);
?>