<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Kešatmiņas";
$text = "Ja esat kešatmiņas ieslēdzis tā būs ievērojami uzlabot ātrumu jūsu vietnē un minimizētu zvaniem uz sql datubāzes. <br /> <br /> <b>SVARĪGI! Ja jūs iesniedzat savu dizainu izslēdz kešdarbes pie kā jebkuras izmaiņas, ko veicat netiks atspoguļots.</b>";
$ns -> tablerender($caption, $text);
?>