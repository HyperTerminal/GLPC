<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Šī lapa ļauj Jums mēreni jūsu reģistrētie biedri. Jūs varat atjaunināt viņu iestatījumus, dot viņiem administratora statusu un noteikt savu lietotāja klasē starp citām lietām.";
$ns -> tablerender("Users Help", $text);
unset($text);
?>