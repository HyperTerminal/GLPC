<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Šī lapa ļauj iestatīt ziņu, kas parādīsies virs jūsu sākumlapā visu laiku tas ir aktivizēts. Jūs varat iestatīt citu ziņu par viesiem, kas reģistrētas / reģistrētos locekļiem un administratoriem.";
$ns -> tablerender("WMessage Help", $text);
?>
