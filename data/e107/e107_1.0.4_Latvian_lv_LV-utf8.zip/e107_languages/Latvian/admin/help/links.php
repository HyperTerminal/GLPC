<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ievadiet visus jūsu vietnes saites šeit. Saites pievienotās šeit tiks parādīts galvenajā navigācijas izvēlnē, lai citas saites, lūdzu, izmantojiet saites lapā spraudni.
<br />
";
$ns -> tablerender("Links Help", $text);
?>