<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Uzstādot jaunu valodu ļaus jums, lai būtu versiju saturu šajā valodā uz jūsu vietni.";
$ns -> tablerender("Language Help", $text);
?>