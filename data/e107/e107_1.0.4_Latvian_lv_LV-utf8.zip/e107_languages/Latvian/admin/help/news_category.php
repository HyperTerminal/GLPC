<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Jūs varat atdalīt savu ziņu priekšmetus dažādās kategorijās, un ļauj apmeklētājiem, lai parādītu tikai jaunus vienumus šajās kategorijās. <br /> <br /> Nosūtiet ziņu ikonu attēlus nu".e_THEME."-yourtheme-/images/ or themes/shared/newsicons/.";
$ns -> tablerender("News Category Help", $text);
?>