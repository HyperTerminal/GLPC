<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Jums ir iespēja pārvaldīt failus jūsu / files directory no šīs lapas. Ja Jūs saņemat kļūdas ziņojumu par atļaujām, augšupielādējot lūdzu CHMOD direktoriju jūs mēģināt augšupielādēt uz līdz 777.";
$ns -> tablerender("File Manager Help", $text);
?>