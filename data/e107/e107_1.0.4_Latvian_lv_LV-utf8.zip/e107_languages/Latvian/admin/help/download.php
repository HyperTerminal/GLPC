<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Augšupielādējiet failus ".e_DOWNLOAD." mape, jūsu bildes ".e_FILE."downloadimages mapē un sīkatēla bildes ".e_FILE."downloadthumbs mapē.
<br /><br />
Iesniegt lejupielādi, vispirms izveidojiet mātes, tad izveidojiet kategoriju saskaņā ar mātes, tu tad būs iespēja darīt lejupielāde iespējama.";
$ns -> tablerender("Download Help", $text);
?>