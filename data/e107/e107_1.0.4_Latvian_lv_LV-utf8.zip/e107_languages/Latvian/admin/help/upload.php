<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "No šejienes jūs varat ļaut / Neatļaut iespēju lietotājiem augšupielādēt failus un pārvaldīt tos failus, kas ir augšupielādēti.";
$ns -> tablerender("Public Uploads Help", $text);
?>