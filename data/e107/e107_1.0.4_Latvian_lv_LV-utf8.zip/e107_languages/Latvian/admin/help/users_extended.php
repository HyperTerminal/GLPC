<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = " Pagarināts lietotāju lauki ļauj pievienot papildu datu veidi, lietotājs var norādīt kā daļu no to profila.";
$ns -> tablerender(" Extended User Fields Help", $text);
?>