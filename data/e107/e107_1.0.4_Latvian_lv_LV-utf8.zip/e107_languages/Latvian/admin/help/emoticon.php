<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ar Emocijas aktivētas, standarta smiley teksta virknes tiks aizstāta ar viņu
attiecīgās emocijzīmi attēli visā saturu jūsu vietnē.";

$ns -> tablerender("Emoticon Help", $text);
?>