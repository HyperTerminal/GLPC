<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Jebkuru meta tagus jūs šeit tiks nosūtīts ekrāna pareizajā vietā.";

$ns -> tablerender("Meta Tags", $text);
?>