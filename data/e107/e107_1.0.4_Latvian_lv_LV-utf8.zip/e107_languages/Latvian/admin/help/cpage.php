<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "No šā ekrāna jūs varat izveidot pielāgotus izvēlnes vai pielāgotus lapas ar savu saturu tajos.<br /><br />";
// $text .= "Lūdzu skaties <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Izmantojot pielāgotas lapas un pielāgotās izvēlnes</a> par skaidrojumu visām funkcijām.";

$ns -> tablerender('Custom Menus/Pages Help', $text);
?>