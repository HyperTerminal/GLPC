<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Lietotāku Klases palīdzība";
$text = "Jūs varat izveidot vai rediģēt / dzēst esošās klases no šīs lapas. <br /> Tas ir noderīgi, lai ierobežotu lietotājiem dažiem jūsu vietnes daļām. Piemēram, jūs varētu izveidot klasi sauc TEST, tad izveidot forumu, kas tikai ļāva lietotājiem uz testa klases tai piekļūt.";
$ns -> tablerender($caption, $text);
?>