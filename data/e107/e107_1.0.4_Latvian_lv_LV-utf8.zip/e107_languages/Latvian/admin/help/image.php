<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "No šejienes jūs varat ļaut / Neatļaut iespēju lietotājiem ievietot attēlu uz vietas, kas mainītu veidu un apskatīt augšupielādētos Avatars.";
$ns -> tablerender("Images Help", $text);
?>