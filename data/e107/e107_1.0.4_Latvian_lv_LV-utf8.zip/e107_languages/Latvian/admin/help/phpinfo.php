<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = " Šī lapa parāda visas savas serveru PHP konfigurācijas uzstādījumus. ";
$ns -> tablerender("PHP Info Help", $text);
?>