<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Tie instrumentu kolekcija ļauj jums pārvaldīt savu datu bāzi.";
$ns -> tablerender("Database Tools", $text);
?>
