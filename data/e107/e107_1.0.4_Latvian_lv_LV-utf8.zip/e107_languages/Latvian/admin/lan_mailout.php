<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define ("PRFLAN_52", "Save Changes");
define ("PRFLAN_63", "Sūtīt pārbaudes e-pastu");
// Define ("PRFLAN_64", "Noklikšķinot pogu nosūtīs pārbaudes e-pastu uz galveno admin e-pasta adresi");
define ("PRFLAN_65", "Noklikšķiniet, lai nosūtītu e-pastu");
define ("PRFLAN_66", "Testa e-pasts no");
define ("PRFLAN_67", "Tas ir tests e-pastu, šķiet, ka jūsu e-pasta iestatījumi strādā ok, \n\nRegards\nfrom e107 mājaslapu sistēmas!.");
define ("PRFLAN_68", "E-pastu nevarēja nosūtīt. Šķiet, ka jūsu serveris nav pareizi konfigurēta, lai nosūtītu e-pastu, lūdzu, mēģiniet vēlreiz, izmantojot SMTP, vai sazinieties ar saimniekiem un palūdziet pārbaudīt savus Sendmail / pasta servera uzstādījumus." );
define ("PRFLAN_69", "e-pasts ir veiksmīgi nosūtīts, lūdzu pārbaudiet jūsu iesūtnē.");
define ("PRFLAN_70", "pasta vēstuļu sūtīšanas metodi");
define ("PRFLAN_71", "Ja neesat pārliecināts, atstājiet kā php");
define ("PRFLAN_72", "SMTP serveris");
define ("PRFLAN_73", "SMTP vārds");
define ("PRFLAN_74", "SMTP parole");
define ("PRFLAN_75", "e nevarēja nosūtīt Lūdzu pārskatiet savus SMTP iestatījumus vai atspējot SMTP un mēģiniet vēlreiz..");

define ("MAILAN_01", "No Name");
define ("MAILAN_02", "No Nosūtīt");
define ("MAILAN_03", "Lai");
define ("MAILAN_04", "Kopija");
define ("MAILAN_05", "Diskrētā kopija");
define ("MAILAN_06", "Tēma");
define ("MAILAN_07", "Pielikums");
define ("MAILAN_08", "Sūtīt Nosūtīt");
define ("MAILAN_09", "Lietot Theme stils");
define ("MAILAN_10", "Lietotājs Parakstītais");
define ("MAILAN_11", "Ievietot mainīgie");
define ("MAILAN_12", "Visi locekļi");
define ("MAILAN_13", "Visi nepārbaudīto locekļi");
define ("MAILAN_14", "Tas ir ieteicams, ka jūs ļautu SMTP, lai nosūtītu lielu skaitu e-pastu - noteikti preferences tālāk.");
define ("MAILAN_15", "Pasts-out");

define ("MAILAN_16", "lietotājvārds");
define ("MAILAN_17", "pierakstīšanās saite");
define ("MAILAN_18", "lietotāja ID");
define ("MAILAN_19", "Nav e-pasta adrese novietojuma admin Lūdzu pārbaudiet jūsu preferences un mēģiniet vēlreiz..");
define ("MAILAN_20", "Sendmail-ceļš");
define ("MAILAN_21", "Mass-pasta Ieraksti");
define ("MAILAN_22", "Pašlaik nav saglabāti ieraksti");
define ("MAILAN_23", "userclass:");
define ("MAILAN_24", "email (s) ir gatava nosūtīšanai");

define ("MAILAN_25", "Apturēt");
define ("MAILAN_26", "Apturēt masu mailing katru");
define ("MAILAN_27", "vēstules");
define ("MAILAN_28", "Apturēt Garums");
define ("MAILAN_29", "sekundes");
define ("MAILAN_30", "Vairāk nekā 30 sekundes, var izraisīt pārlūkprogrammu taimauta");
define ("MAILAN_31", "atlekšanai Email apstrāde");
define ("MAILAN_32", "E-pasta adrese");
define ("MAILAN_33", "Ienākošais pasts");
define ("MAILAN_34", "Konta nosaukums");
define ("MAILAN_35", "Parole");
define ("MAILAN_36", "Dzēst atlekšanai Pasts pēc pārbaudes");

define ("MAILAN_37", "Turpināt");
define ("MAILAN_38", "Atcelt");
define ("MAILAN_39", "Pasta vēstuļu sūtīšanas");
define ("MAILAN_40", "Jums ir nepieciešams pārdēvēt <b> e107.htaccess </ b>, lai <b> htaccess </ b>.");
define ("MAILAN_41", "pirms pasta nosūtīšanas no šīs lapas.");
define ("MAILAN_42", "Brīdinājums");
define ("MAILAN_43", "Lietotājvārds");
define ("MAILAN_44", "Lietotāja vārds");
define ("MAILAN_45", "Lietotājs Nosūtīt");
define ("MAILAN_46", "Lietotājs-Match");
define ("MAILAN_47", "satur");
define ("MAILAN_48", "vienāds");
define ("MAILAN_49", "id");
define ("MAILAN_50", "Autors");
define ("MAILAN_51", "Tēma");
define ("MAILAN_52", "lastmod");
define ("MAILAN_53", "Administratori");
define ("MAILAN_54", "Self");
define ("MAILAN_55", "Userclass");
define ("MAILAN_56", "Sūtīt vēstuli");
define ("MAILAN_57", "Keep SMTP sesijas dzīvs");
define ("MAILAN_58", "Ir iespējams piestiprināt problēma:");
define ("MAILAN_59", "Pasta Progress");
define ("MAILAN_60", "sūtīšana ...");
define ("MAILAN_61", "Nav atlikušos e-pasti, kas tiek nosūtīti.");
define ("MAILAN_62", "e-pasta nosūtīts:");
define ("MAILAN_63", "Vēstules neizdevās:");
define ("MAILAN_64", "Kopējais laiks pagājis:");
define ("MAILAN_65", "sekundes");
define ("MAILAN_66", "Anulēts veiksmīgi");
define ("MAILAN_67", "Lietot POP pirms SMTP Autorizācijas ");
define ('MAILAN_68', 'Testa adrese');
define ("MAILAN_69", "lietotāja login");
define ("MAILAN_70", "lietotāja e-pasts");


?>