<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LCLAN_1", "Opcijas Saglabatas");
define("LCLAN_2", "Links Saglabats Datubāzē");
define("LCLAN_3", "Links Atjaunots Datubāze");
define("LCLAN_6", "Izkārtojums Atjaunots");
define("LCLAN_8", "Esosie Linki");
define("LCLAN_12", "Linku Rendertype");
define("LCLAN_15", "Linku Nosaukums");
define("LCLAN_16", "Linku URL");
define("LCLAN_17", "Linku Apraksts");
define("LCLAN_18", "Linku Poga / Ikona");
define("LCLAN_19", "Linku Atveršanas Tips");
define("LCLAN_20", "Atvert tajā pašā logā");
define("LCLAN_23", "Atvērt Jaunā Logā");
define("LCLAN_24", "Atvērt kā 600x400 mini-logu");
define("LCLAN_25", "Linku Klases");
define("LCLAN_26", "Atzīmējot padarīs linkus redzamus tikai lietotājiem šajā klasē");
define("LCLAN_27", "Atjaunot Linku");
define("LCLAN_28", "Izveidot Linku");
define("LCLAN_29", "Linki");
define("LCLAN_30", "parvietot uz augsu");
define("LCLAN_31", "pārvietot uz leju");
define("LCLAN_39", "Skatīt Bildes");
define("LCLAN_53", "Links");
define("LCLAN_54", "Dzests");
define("LCLAN_58", "Vai esi pārliecinats, ka velies dzest so Linku?");
define("LCLAN_61", "Nav Linku");
define("LCLAN_62", "Linku sākumlapa");
define("LCLAN_63", "Izveidot Jaunu Linku");
define("LCLAN_68", "Linku Opcijas");
define("LCLAN_78", "Rādīt aprakstā kā Ekrāna padomus");
define("LCLAN_79", "Apraksts tiks parādīts, kad peles segs pār saiti");
define("LCLAN_80", "Aktivizēt paplašinoto apakšizvēlni");
define("LCLAN_81", "Apakšizvēlne tiks parādīts tikai pēc noklikšķināšanas viņu Parent. (Linku Parent ir atspējota)");
define("LCLAN_83", "Apakšizvēlnes Ģeneratori");
define("LCLAN_88", "Saites Linku Opcijas");
define("LCLAN_89", "Bilde");
define("LCLAN_91", "Pārvietot");
define("LCLAN_95", "Klase");
define("LCLAN_96", "Radīt Dizainā kā");
define("LINKLAN_1", "Atvērt kā: 800x600 logu");
define("LINKLAN_2", "Parent");
define("LINKLAN_3", "Nav Parent (Normāls Links)");
define("LINKLAN_4", "Apakšizvēlnes Ģenerators");
define("LINKLAN_5", "Ģenerēt apakšizvēlnes");
define("LINKLAN_6", "Izveidot apakšizvēli no:");
define("LINKLAN_7", "Izveidot apakšizvēlnes zem kuras adreses");
define("LINKLAN_8", "jaunumu Kategorijas");
define("LINKLAN_9", "Failu Kategorijas");
define("LINKLAN_10", "Izveidot apakšizvēlni");


?>