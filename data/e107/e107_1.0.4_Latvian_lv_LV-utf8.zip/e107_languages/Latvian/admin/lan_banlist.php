<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Ban noņemts.");
define("BANLAN_2", "Nav Banu");
define("BANLAN_3", "Esošie Bani");
define("BANLAN_4", "Noņemt Banu");
define("BANLAN_5", "Ievadi IP, epasta adresi, vai host");
define("BANLAN_7", "Iemesls");
define("BANLAN_8", "Ban Adrese");
define("BANLAN_9", "Ban lietotāju no vietnes pa e-pastu, IP vai uzņēmēja adreses");
define("BANLAN_10", "IP / Epasts / Iemesls");
define("BANLAN_11", "uto-ban: Vairāk nekā 10 neizdevās pieteikšanās mēģinājumi");
define("BANLAN_12", "Piezīme: apgrieztā DNS pašlaik ir atspējota, ir jābūt iespējai atļaut bloķēt pēc host. Aizliegumu ar IP un e-pastu joprojām darbosies normāli.");
define("BANLAN_13", "Piezīme: Lai aizliegtu lietotāju pēc lietotāja vārdu, dodieties uz lietotāju admin lapā:");
define("BANLAN_78", "Hit skaits pārsniedza (- Hits - pieprasa, ar piešķirto laiku)");


?>