<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Nevar izlasīt sql datni <br /><br />Lūdzu pārliecinieties vai fails <b>core_sql.php</b> pastāv <b>/admin/SQL</b> direktorijā.");
define("DBLAN_2", "pārbaudīt visu");
define("DBLAN_4", "Tabula");
define("DBLAN_5", "Lauks");
define("DBLAN_6", "Status");
define("DBLAN_7", "Piezīmes");
define("DBLAN_8", "neatbilstība");
define("DBLAN_9", "šobrīd");
define("DBLAN_10", "vajadzētu būt");
define("DBLAN_11", "Laiks trūkst");
define("DBLAN_12", "Papildus Lauks!");
define("DBLAN_13", "Tabula trūkst!");
define("DBLAN_14", "Izvēlieties tabulu(as), lai apstiprinātu");
define("DBLAN_15", "sākt Pārbaudīt");
define("DBLAN_16", "SQL pārbaude");
define("DBLAN_17", "Atpakaļ");
define("DBLAN_18", "tabulas");
define("DBLAN_19", "Mēģināt Salabot");
define("DBLAN_20", "Mēģina salabot tabulas");
define("DBLAN_21", "Labot izvelētos priekšmetus");
define("DBLAN_22", "Nav lasāms!");


?>