<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("NT_LAN_1", "Paziņojumi");
define("NT_LAN_2", "Saņemt epasta paziņojumus no");
define("NT_LAN_3", "Izslegts");
define("NT_LAN_4", "Īpašnieks");
define("NT_LAN_5", "Klase");
define("NT_LAN_6", "Epasts");
define("NU_LAN_1", "Lietotāju Notikumi");
define("NU_LAN_2", "Lietotāju Reģistrācija");
define("NU_LAN_3", "Lietotāku Kontu Aktivizešana");
define("NU_LAN_4", "Lietotāju Pieteikšanās");
define("NU_LAN_5", "Lietotaju Iziešana");
define("NS_LAN_1", "Drošības Notikumi");
define("NS_LAN_2", "IP bloķēts par plūdošanua");
define("NN_LAN_1", "Jaunumu Notikumi");
define("NN_LAN_2", "Jaunumu Iesniegšana no Lietotajiem");
define("NN_LAN_3", "Jaunumu Iesniegšana no Adminiem");
define("NN_LAN_4", "Jaunumu Labošana no Admina");
define("NN_LAN_5", "Jaunumu dzešana no Admina");
define("NF_LAN_1", "failu Notikumi");
define("NF_LAN_2", "Failu Augsupielāde no Lietotaja");
define("CM_LAN_1", "Komantāru Notikumi");
define("CM_LAN_2", "Komentēt ievietojis lietotājs, kas gaida apstiprinājumu");


?>