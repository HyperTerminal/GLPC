<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define ("FMLAN_1", "Augšuplādēts");
define ("FMLAN_2", "līdz");
define ("FMLAN_3", "katalogs");
define ("FMLAN_4", "Attēli fails pārsniedz upload_max_filesize direktīvu php.ini.");
// Define ("FMLAN_5", "Attēli fails pārsniedz MAX_FILE_SIZE direktīvu, kas tika norādīta html formā.");
// Define ("FMLAN_6", "Attēli fails bija tikai daļēji augšupielādēts.");
// Define ("FMLAN_7", "Nav fails augšupielādēts.");
// Define ("FMLAN_8", "Augšuplādēts faila izmērs 0 baiti");
// Define ("FMLAN_9", "fails nav augšupielādēts Filename.");
define ('FMLAN_10', 'Kļūda');
// Define ("FMLAN_11", "droši vien nepareizi atļaujas Augšupielādes direktorijā.");
define ("FMLAN_12", "fails");
define ("FMLAN_13", "faili");
define ("FMLAN_14", "katalogs");
define ("FMLAN_15", "katalogi");
define ("FMLAN_16", "Root direktoriju");
define ("FMLAN_17", "Nosaukums");
define ("FMLAN_18", "Izmērs");
define ("FMLAN_19", "Last Modified");

define ("FMLAN_21", "Augšupielādēt failu šajā dir");
define ("FMLAN_22", "Augšupielādēt");

define ("FMLAN_26", "Dzēsts");
define ("FMLAN_27", "veiksmīgi");
define ("FMLAN_28", "Nevar izdzēst");
define ("FMLAN_29", "Ceļš");
define ("FMLAN_30", "Up līmenis");
define ("FMLAN_31", "mape");

define ("FMLAN_32", "Izvēlieties direktoriju");
define ("FMLAN_33", "Select");
define ("FMLAN_34", "katalogs izvēle");
define ("FMLAN_35", "Datnes katalogs");

define ("FMLAN_36", "Custom Izvēlnes katalogs");
define ("FMLAN_37", "Custom Pages katalogs");

define ("FMLAN_38", "Veiksmīgi pārvietots fails");
define ("FMLAN_39", "Nevar pārvietot failu uz");
define ("FMLAN_40", "Newspost-Attēli katalogs");


define ("FMLAN_43", "Dzēst atlasītos failus");


define ("FMLAN_46", "Lūdzu, apstipriniet, ka vēlaties dzēst izvēlētos failus.");
define ("FMLAN_47", "Lietotājs Augšupielādes");

define ("FMLAN_48", "Pārvietot izvēli uz pašu");
define ("FMLAN_49", "Lūdzu, apstipriniet, kuru vēlaties pārvietot izvēlētos failus.");
define ("FMLAN_50", "Move");
define ('FMLAN_51', 'neidentificētu kļūda:');




?>