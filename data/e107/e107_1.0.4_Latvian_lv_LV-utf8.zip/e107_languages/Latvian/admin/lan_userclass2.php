<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Attīrīt visus Biedrus no Klases");
define("UCSLAN_2", "Klase Atjaunota");
define("UCSLAN_3", "Klase Dzēsta");
define("UCSLAN_4", "ūdzu, atzīmējiet Apstiprināt rūtiņu, lai dzēstu šo lietotāja klasi");
define("UCSLAN_5", "Klase Atjaunota");
define("UCSLAN_6", "Klase Saglabata datubāzē!");
define("UCSLAN_7", "Nav lietotāju Klases");
define("UCSLAN_8", "Esošās klases");
define("UCSLAN_11", "Atķeksē lai apstiprinātu");
define("UCSLAN_12", "Klases Nosaukums");
define("UCSLAN_13", "Klases Apraksts");
define("UCSLAN_14", "Atjaunot Lietotaju Klases");
define("UCSLAN_15", "Izveidot Jaunu Klasi");
define("UCSLAN_16", "Pievienot Biedrus Klasei");
define("UCSLAN_17", "Aizvakt");
define("UCSLAN_18", "Attīrīt Klasi");
define("UCSLAN_19", "Pievienot Lietotajus uz");
define("UCSLAN_20", "klase");
define("UCSLAN_21", "Lietotāju Klases Iestatījumi");
define("UCSLAN_22", "Lietotāji - Spied lai pārvietotu ...");
define("UCSLAN_23", "Lietotāji ir šajā klasē ...");
define("UCSLAN_24", "Kas par pārvaldīt klasi");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Lietotājvārds");
define("UCSLAN_27", "Atgriezties");


?>