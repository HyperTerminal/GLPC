<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Admin Navigācija");
define("LAN_head_2", "Tavs serveris neļauj HTTP failu augšupielādes tik tas nav iespējams jūsu lietotājiem augšupielādēt Avatars / files uc Lai novērstu šo komplektu file_uploads lai tavā php.ini un restart serveri. Ja jums nav piekļuves jūsu php.ini sazinieties saimniekiem.");
define("LAN_head_3", "Jūsu serveris darbojas ar basedir ierobežojums spēkā. Šī neatļauj izmantošana jebkurā failā ārpus jūsu mājas direktoriju un kā tāds var ietekmēt noteiktus skriptus piemēram, failu pārvaldnieks.");
define("LAN_head_4", "Admina Zona");
define("LAN_head_5", "Valodas parādījumi ieks Admina Zonas");
define("LAN_head_6", "Spraudņu Info");


?>