<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Saņemtās Vēstules");
define("MESSLAN_2", "Dzēst Vēstuli");
define("MESSLAN_3", "Vēstule Dzesta");
define("MESSLAN_4", "Dzēst Visas Vēstules");
define("MESSLAN_5", "Apstiprināt");
define("MESSLAN_6", "Visas Vēstules Dzēstas");
define("MESSLAN_7", "Nav Vēstules");
define("MESSLAN_8", "Vestuļu tips");
define("MESSLAN_9", "Atbildot uz");
define("MESSLAN_10", "Iesniedza");
define("MESSLAN_11", "atvert jauna logā");
define("MESSLAN_12", "Vestule");
define("MESSLAN_13", "Links");


?>