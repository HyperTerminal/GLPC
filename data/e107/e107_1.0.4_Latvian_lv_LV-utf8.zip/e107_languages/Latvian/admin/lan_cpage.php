<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Virsraksts");
define("CUSLAN_2", "Tips");
define("CUSLAN_3", "Opcijas");
define("CUSLAN_4", "Dzēst šo lapu?");
define("CUSLAN_5", "Esošās lapas");
define("CUSLAN_7", "Izvēlnes Nosaukums");
define("CUSLAN_8", "Virsraksts");
define("CUSLAN_9", "Teksts");
define("CUSLAN_10", "Atļaut lapu vērtēt");
define("CUSLAN_11", "Sākumlapa");
define("CUSLAN_12", "Izveidot Lapu");
define("CUSLAN_13", "Atļaut Komentārus");
define("CUSLAN_14", "Ar Paroli Aizsargāta Lapa");
define("CUSLAN_15", "Ievadi Paroli, lai aizsargatu");
define("CUSLAN_16", "Izveidot Linku, galvenaja navigācijā");
define("CUSLAN_17", "Ievadi Linka nosaukumu");
define("CUSLAN_18", "Lapas adrese redzama");
define("CUSLAN_19", "Atjaunot Lapu");
define("CUSLAN_20", "Izveidot Lapu");
define("CUSLAN_21", "Atjaunot Izvelni");
define("CUSLAN_22", "Izveidot Izvelni");
define("CUSLAN_23", "Labot Lapu");
define("CUSLAN_24", "Izveidot Jaunu Lapu");
define("CUSLAN_25", "Labot Izvelni");
define("CUSLAN_26", "Izveidot Jaunu Izvelni");
define("CUSLAN_27", "Lapa Saglabata datubāzē");
define("CUSLAN_28", "Lapa Dzēsta");
define("CUSLAN_29", "Saraksta lapās, ja nav atlasīts lapa");
define("CUSLAN_30", "Derīguma laiks sīkdatnes/cookie (sekundēs)");
define("CUSLAN_31", "Izveidot Izvēlni");
define("CUSLAN_32", "Pārvērst veco lapas/Izvelnes");
define("CUSLAN_33", "Lapas Opcijas");
define("CUSLAN_34", "Sākas pārveide");
define("CUSLAN_35", "Nogatavo pēc pasūtījuma lapa atjaunota - atjaunināts");
define("CUSLAN_36", "Lai iestatītu preferences katru lapu, lūdzu atgriezieties sākuma lapā un rediģēt lapas.");
define("CUSLAN_37", "Pielāgotas Lapas atjaunināšana");
define("CUSLAN_38", "ieslegt");
define("CUSLAN_39", "izslēgt");
define("CUSLAN_40", "Saglabat");
define("CUSLAN_41", "Rādīt autoru un datuma informāciju");
define("CUSLAN_42", "Nevienā lapā vēl nekas nav noteikts");
define("CUSLAN_43", "Bez Nosaukuma Izvelne");
define("CUSLAN_44", "Bez Nosaukuma Lapa");


?>