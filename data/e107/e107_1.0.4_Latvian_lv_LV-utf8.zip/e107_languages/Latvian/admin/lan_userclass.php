<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Nosūtot paziņojumu e-pastu");
define("UCSLAN_2", "Atjaunot Privilēģijas");
define("UCSLAN_3", "Dārgais");
define("UCSLAN_4", "Jūsu Privilēģijas tika atjaunotas uz");
define("UCSLAN_5", "Jums ir piekļuve, sekojošām zonām:");
define("UCSLAN_6", "Uzstādīt klasi priekš Biedra");
define("UCSLAN_7", "Uzstadīt Klases");
define("UCSLAN_8", "Paziņot par to Biedru");
define("UCSLAN_9", "Klases Atjaunotas");
define("UCSLAN_10", "Cieņu,");
define("UCSLAN_12", "Biedru Privilēģijas Tikai");


?>