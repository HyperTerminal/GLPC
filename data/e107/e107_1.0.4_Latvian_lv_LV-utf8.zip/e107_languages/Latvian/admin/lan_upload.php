<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UPLLAN_1", "Augšupielāde noņemta no saraksta");
define("UPLLAN_2", "Iestatījumi saglabāti datubāze!");
define("UPLLAN_3", "Augšupielādes ID");
define("UPLLAN_5", "Ierakstīja");
define("UPLLAN_6", "Epasts");
define("UPLLAN_7", "Majas Lapa");
define("UPLLAN_8", "Faila Nosaukums");
define("UPLLAN_9", "Versija");
define("UPLLAN_10", "Fails");
define("UPLLAN_11", "Faila Izmērs");
define("UPLLAN_12", "Ekrānattēli");
define("UPLLAN_13", "Apraksts");
define("UPLLAN_14", "Demo");
define("UPLLAN_16", "Kopet uz Jaunumiem");
define("UPLLAN_17", "Dzēst augšupielādi no saraksta");
define("UPLLAN_18", "Skatīt Detaļas");
define("UPLLAN_19", "Šeit ir nepārvaldītas augšupielādes");
define("UPLLAN_20", "Tur");
define("UPLLAN_21", "nēpārvaldītas augšupielādes");
define("UPLLAN_22", "ID");
define("UPLLAN_23", "Nosaukums");
define("UPLLAN_24", "Faila Tips");
define("UPLLAN_25", "Augšupielāde Ieslēgta?");
define("UPLLAN_26", "Augšupielāde būs aizliegta, ja atspejosiet!");
define("UPLLAN_27", "Nepārvaldītas augšupielādes");
define("UPLLAN_29", "uzglabāšanas veids");
define("UPLLAN_30", "Izvēlēties, kā uzglabāt augšupielādēto failu, vai nu kā parastos failus uz servera vai kā bināru informāciju datu bāzē <br /> <b>Piezīme:</b> binārais ir piemērots tikai mazākos failus ar aptuveni 500KB");
define("UPLLAN_31", "Normalais");
define("UPLLAN_32", "Binārais");
define("UPLLAN_33", "Maksimālais faila izmers");
define("UPLLAN_34", "Maksimālais augšupielādes izmērs baitos - atstāt tukšu, lai izmantotu iestatījumus no php.ini");
define("UPLLAN_35", "Atļautie paplašinājumi");
define("UPLLAN_36", "Lūdzu ievadiet katrārindā vienu tipu");
define("UPLLAN_37", "Atļaujas");
define("UPLLAN_38", "Izvēlieties, lai atļautu tikai daži lietotāji var augšupielādēt");
define("UPLLAN_39", "Iesniegt");
define("UPLLAN_41", "Lūdzu, ņemiet vērā - failu augšupielādes tiek atspējoti no jūsu php.ini, tas nebūs iespējams augšupielādēt failus, līdz jūs to neieslegsiet!");
define("UPLLAN_42", "Darbības");
define("UPLLAN_43", "Augšupielādes");
define("UPLLAN_44", "Augsupielade");
define("UPLLAN_45", "Vai jūs tiešām vēlaties izdzēst šo failu ...");
define("UPLAN_COPYTODLM", "kopēt uz lejupielādes menedžeri");
define("UPLAN_IS", "ir");
define("UPLAN_ARE", "tiek");
define("UPLAN_COPYTODLS", "Kopet uz Lejupieladi");
define("UPLLAN_48", "Drošības apsvērumu dēļ atļautais faila tipi ir pārvietots no datubāzi
flatfile atrodas jūsu admin direktorijā. Izmantot, pārdēvējiet failu e107_admin/filetypes_.php uz e107_admin/filetypes.php
un pievienot Komatu atdalīts saraksts ar failu tipu paplašinājumus, lai to. Jums nevajadzētu ļaut augšupielādēt. Html,. Txt utt, kā uzbrucējs var augšupielādēt failu šāda veida, kas ietver ļaunprātīgu javascript. Jums vajadzētu arī, protams, neļauj
augšupielādēt. php failu vai jebkura cita veida izpildāmo skriptu.");


?>