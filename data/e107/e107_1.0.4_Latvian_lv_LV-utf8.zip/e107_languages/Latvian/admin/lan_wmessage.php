<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Sveicienu Ziņa");
define("WMLAN_01", "Izveidot Jaunu Ziņu");
define("WMLAN_02", "Ziņa");
define("WMLAN_03", "Redzamība");
define("WMLAN_04", "Ziņas Teksts");
define("WMLAN_05", "Iežogot");
define("WMLAN_06", "Ja atzīmēts, ziņa tiks padarīti iekšā kastē");
define("WMLAN_07", "Ignorēt standarta sistēmu izmantota {WMESSAGE} shortcode:");
define("WMLAN_09", "Nav izveidots sveicienu ziņa!");
define("WMLAN_10", "Ziņu Virsraksts");


?>