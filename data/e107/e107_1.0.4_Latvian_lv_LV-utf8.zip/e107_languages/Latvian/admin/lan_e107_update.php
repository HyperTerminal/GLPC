<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "darbība");
define("LAN_UPDATE_3", "Nav vajadzības");
define("LAN_UPDATE_5", "Atjauninajums Pieejams");
define("LAN_UPDATE_7", "izpildīts");
define("LAN_UPDATE_8", "Atjaunot no");
define("LAN_UPDATE_9", "uz");
define("LAN_UPDATE_10", "Pieejams Atjauninajums");
define("LAN_UPDATE_11", ".617 uz .7 Atjauninajums Turpināt");
define("LAN_UPDATE_12", "Viens no jūsu tabulās ir ierakstu dublēšana.");


?>