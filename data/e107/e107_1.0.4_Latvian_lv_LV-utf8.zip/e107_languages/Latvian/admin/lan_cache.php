<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Kešatmiņas Sistēmas Status");
define("CACLAN_2", "Uzstadīt Kešatmiņas statusu");
define("CACLAN_3", "Kešatmiņas Sistema");
define("CACLAN_4", "Kešatmiņas status uzstādīts");
define("CACLAN_5", "Tukša Kešatmiņa");
define("CACLAN_6", "Kešatmiņa Iztuksota");
define("CACLAN_7", "Kešatmiņa Atspējota");
define("CACLAN_9", "Kešatmiņas dati saglabāti diskā");
define("CACLAN_10", "Kešatmiņas mape nav rakstāma. Lūdzu pārliecinies, ka ir uzstādītas CHMOD 0777 atļaujas!");


?>