<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tags atjaunoti datubāzē");
define("METLAN_2", "Ievadiet pievienotos meta-tags");
define("METLAN_3", "Ievadi Jaunus meta tag iestatījumus");
define("METLAN_4", "Atjaunots");
define("METLAN_5", "Ieraksti aprakstu te!");
define("METLAN_6", "tipa, saraksts, no, jūsu, atslēgas, vārdiem, šeit");
define("METLAN_7", "Ievadi Autortiesības informaciju:");
define("METLAN_8", "Meta Tags");
define("METLAN_9", "Apraksts");
define("METLAN_10", "Atslēgas Vārdi");
define("METLAN_11", "Autortiesības");
define("METLAN_12", "Izmantot Jaunumi nosaukumu un kopsavilkumu, kā meta-aprakstam ziņu lapās.");
define("METLAN_13", "Autors");


?>