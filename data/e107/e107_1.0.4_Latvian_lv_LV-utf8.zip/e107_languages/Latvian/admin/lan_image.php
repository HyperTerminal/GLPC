<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("IMALAN_1", "Ieslēgt Bildes attēlojumu");
define("IMALAN_2", "Parādīt attēlus, tas attieksies sitewide (komentāri, čata uc), lai attēlus ievietotu izmantojot [img] BBKodu");
define("IMALAN_3", "Samazināšanas Metode");
define("IMALAN_4", "Metode, kas izmantota, lai mainītu attēlu, vai nu GD1 / 2 bibliotēkai vai ImageMagic");
define("IMALAN_5", "Ceļš uz ImageMagick (ja pieejams)");
define("IMALAN_6", "Pilns ceļš uz ImageMagick Convert utility");
define("IMALAN_7", "Bildes Iestatījumi");
define("IMALAN_8", "Atjaunot Bildes Iestatījumus");
define("IMALAN_9", "Bildes Iestatījumi Atjaunoti");
define("IMALAN_10", "Bildes Attelošanas Klase");
define("IMALAN_11", "Ierobežot lietotājus, kas var apskatīt attēlus (ja iespējota iepriekš)");
define("IMALAN_12", "Bildes Attelojuma iestatījumi");
define("IMALAN_13", "Ko darīt ar attēliem, ja attēls attēlošana ir atspējota");
define("IMALAN_14", "Rādīt Bildes URL");
define("IMALAN_15", "Nerādīt Neko");
define("IMALAN_16", "Rādīt Augšupielādētos Avatarus");
define("IMALAN_17", "Spied Te");
define("IMALAN_18", "Augšupielādētās Bildes");
define("IMALAN_19", "Rādīt 'Atslēgts' ziņu");
define("IMALAN_21", "Lieto");
define("IMALAN_22", "Bildi neizmanto");
define("IMALAN_23", "Avatars");
define("IMALAN_24", "Fotogrāfija");
define("IMALAN_25", "Noklikšķiniet šeit, lai izdzēstu visus neizmantotos attēlus");
define("IMALAN_26", "Bilde(s) Dzestas");
define("IMALAN_28", "Izdzēsts");
define("IMALAN_29", "Nav Bildes");
define("IMALAN_30", "Visiem (publisks)");
define("IMALAN_31", "Ciemiņiem Tikai");
define("IMALAN_32", "Biedriem Tikai");
define("IMALAN_33", "Adminiem Tikai");
define("IMALAN_34", "Iespējot veiklību");
define("IMALAN_35", "Nosaka caurspīdīgumu PNG-24 ir ar alfa caurspīdīgumu IE 5/6 (Attiecas Sitewide)");
define("IMALAN_36", "Apstiprināt avatara izmērus un piekļuves");
define("IMALAN_37", "Apstiprināt avatarus");
define("IMALAN_38", "Maksimāli atļautais platums");
define("IMALAN_39", "Maksimali atļautais augstums");
define("IMALAN_40", "Pārāk Plats");
define("IMALAN_41", "Pārāk Augsts");
define("IMALAN_42", "Nav Atrasts");
define("IMALAN_43", "Dzēst Neaugšupielādētos Avatarus");
define("IMALAN_44", "Dzēst ārējo atsauci");
define("IMALAN_45", "Nav Atrasts");
define("IMALAN_46", "Pārāk Liels");
define("IMALAN_47", "Visi Augšupielādētie Avatari");
define("IMALAN_48", "Visi ārējie Avatari");
define("IMALAN_49", "Lietotāji ar Avatariem");
define("IMALAN_50", "Kopā");
define("IMALAN_51", "Avatars priekš");
define("IMALAN_52", "Ceļš uz ImageMagick ir nepareizs");
define("IMALAN_53", "Ceļš uz ImageMagick šķiet pareizs, bet pārvērst failus nedrīkst!");
define("IMALAN_54", "GD versija uzstadīta:");
define("IMALAN_55", "Nav Uzstādīts");


?>