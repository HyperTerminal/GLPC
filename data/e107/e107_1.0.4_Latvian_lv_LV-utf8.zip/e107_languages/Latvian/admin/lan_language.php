<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LANG_LAN_00", "Nevarēja izveidot. (jau ir)");
define("LANG_LAN_01", "tika dzēsts (ja pastāv) un izveidots.");
define("LANG_LAN_02", "Nevarēja dzēst");
define("LANG_LAN_03", "Tabulas");
define("LANG_LAN_05", "Nav Uzstādīts");
define("LANG_LAN_06", "Izveidot Tabulu");
define("LANG_LAN_07", "Dzest esošās Tabulas?");
define("LANG_LAN_08", "Aizvietot esošās tabulas (dati tiks zaudēti)");
define("LANG_LAN_10", "Apstiprinat dzešanu");
define("LANG_LAN_11", "Dzēst nepārbaudītās tabulas iepriekš (ja tādi ir).");
define("LANG_LAN_12", "Iespējot daudzvalodu Tabulas");
define("LANG_LAN_13", "Valodas Iestatījumi");
define("LANG_LAN_14", "Noklusetā Saites Valoda");
define("LANG_LAN_15", "Atzīmējiet, lai kopētu datus no noklusējuma valodas. (Noderīga saites, ziņas kategorijām utt)");
define("LANG_LAN_16", "Daudzvalodu datubāze izmantošana");
define("LANG_LAN_17", "Noklusējuma valoda - Nav papildu tabulas nepieciešama");
define("LANG_LAN_18", "Izmantot Rezervētie apakšdomēnos ar šīm jomām ir noteiktas vietas Valoda:");
define("LANG_LAN_19", "piemēram: Domēna fr.mydomain.com varētu noteikt valodu, franču.");
define("LANG_LAN_20", "Ievadiet vienu domēnu katrā rindā. piem. mydomain.com utt vai atstāt tukšu, lai atspējotu.");
define("LANG_LAN_21", "Valodas-Pakas");
define("LANG_LAN_23", "Izveidot Valodas-Paku (zip)");
define("LANG_LAN_24", "Izveidot paku");
define("LANG_LAN_AGR", "Piezīme: Izmantojot šos rīkus jūs piekrītat savu valodu dalīt ar E107 sabiedrību.");
define("LANG_LAN_EML", "Lūdzu sūtiet savu valodu pakotni uz:");
define("LANG_LAN_25", "Lūdzu Pārbaudiet CORE_LC un CORE_LC2 ir vērtības iekš [lcpath] un meģiniet vēlreiz.");
define("LANG_LAN_26", "Lūdzu, pārliecinieties, ka jūs izmantojat noklusētos mapju nosaukumus e107_config.php (piemēram: 'e107_languages/', 'e107_plugins/' u.c.) un mēģiniet velreiz");
define("LANG_LAN_27", "Lūdzu, pārbaudiet jūsu valodas datnes ('Pārbaudīt'), tad mēģināt vēlreiz.");
define("LANG_LAN_28", "Atzīmējiet šo lodziņu, ja jūs [e107 sertificēts tulkotājs].");
define("LANG_LAN_29", "Jums vajadzētu labot atlikušās kļūdas pirms ieguldījumu savu valodu pakotni.");
define("LANG_LAN_30", "Izdošanas Datums");
define("LANG_LAN_31", "Savienojamība");
define("LANG_LAN_32", "Uzstādītās Valodas");
define("LANG_LAN_33", "Rādīt tikai kļūdas pārbaudes laikā");
define("LANG_LAN_34", "Lūdzu, pārbaudiet un izlabojiet Atlikušos [x] kļūdas, pirms mēģināt izveidot valodas paku.");


?>