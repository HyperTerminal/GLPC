<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Kļūda! Lūdzu Aizpildiet velreiz");
define("UDALAN_2", "Iestatījumi Atjaunoti");
define("UDALAN_3", "Iestatījumi Atjaunoti priekš");
define("UDALAN_4", "Vārds");
define("UDALAN_5", "Parole");
define("UDALAN_6", "Atkārtot Paroli");
define("UDALAN_7", "Mainīt Paroli");
define("UDALAN_8", "Parole Atjaunota priekš");


?>