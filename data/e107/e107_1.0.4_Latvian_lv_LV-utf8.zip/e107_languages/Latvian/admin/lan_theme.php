<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("TPVLAN_1", "Jūs skataties priekšskatu <b>'".PREVIEWTHEMENAME."'</b> dizainam. Tas nav uzstādīts, kā galvenais dizains Jūsu Saitei, Tas ir aktizizets apskatīšanai.<br />Lai uzstādītu šo dizainu, kā saites galveno, <a href='".e_ADMIN."theme.php'>atgriezieties uz dizainu pārvaldnieku</a> un izvēlies 'Uzstādīt ka saites Dizainu'.<br />Lai apskatītu vairak Dizainus Lūdzu<a href='".e_ADMIN."theme.php'>Spied te</a>");
define("TPVLAN_2", "Dizaina Priekšskatījums");
define("TPVLAN_3", "Saites Dizains uzstadīts uz");
define("TPVLAN_4", "Autors");
define("TPVLAN_5", "Majas Lapa");
define("TPVLAN_6", "Izlaiduma datums");
define("TPVLAN_7", "Informācija");
define("TPVLAN_8", "Opcijas");
define("TPVLAN_9", "Apskatīt Dizainu");
define("TPVLAN_10", "Uzstadīt kā saites Dizainu");
define("TPVLAN_11", "Versija");
define("TPVLAN_12", "Priekšskats nav pieejams!");
define("TPVLAN_13", "Augsupielādē Dizainu (.zip vai .tar.gz formata)");
define("TPVLAN_14", "Augšupielādēt");
define("TPVLAN_15", "Failu nevar augšupielādēt, jo '".e_THEME."' mape nav pareizās atļaujas - lūdzu izmainiet uz 777 CHMOD un atkārtoti augšupielādējiet failu.");
define("TPVLAN_16", "Adminu Ziņa");
define("TPVLAN_17", "Fails neizskatās derīgs.zip vai .tar arhīvs.");
define("TPVLAN_18", "Radusies kļūda, nevar atarhivēt failu");
define("TPVLAN_19", "Jūsu tēma ir augšupielādēta un unzipped, lūdzu ritiniet uz leju, lai redzētu savu tēmu sarakstā.");
define("TPVLAN_20", "Auto tēma augšupielādes un ieguve ir atspējota kā jūsu themes mapē nav pareizās atļaujas - lūdzu izmainiet CHMOD savā e107_themes mapē uz 777.");
define("TPVLAN_21", "Šīs ir esošais saites dizains!");
define("TPVLAN_22", "Šai tēmai ir vairāki stilu izkartojumi");
define("TPVLAN_23", "Noklusētais izkārtojums");
define("TPVLAN_24", "Nav informācijas");
define("TPVLAN_26", "Dizainu Parvaldnieks");
define("TPVLAN_27", "Lūdzu izvelies izkartojumu, kuru lietosiet");
define("TPVLAN_28", "ieslegts");
define("TPVLAN_29", "izslegts");
define("TPVLAN_30", "Parladet Bildes:");
define("TPVLAN_31", "Sis ir Adminu Zonas Dizains");
define("TPVLAN_32", "Uzstadīt kā, Admina Zonas Dizainu");
define("TPVLAN_33", "Esošais Saites Dizains");
define("TPVLAN_34", "Esošais Adminu Zonas Dizains");
define("TPVLAN_35", "Saglabat Opcijas");
define("TPVLAN_36", "Adminu Ziņa");
define("TPVLAN_37", "Dizainu Opcijas saglabātas");
define("TPVLAN_38", "Augsupielādēt Dizainu");
define("TPVLAN_39", "Pieejamie Dizaini");
define("TPVLAN_40", "Admina Zonas Dizains Uzstadīts uz");
define("TPVLAN_41", "Lūdzu izvelies Admina Zonas Izkartojumu");
define("TPVLAN_42", "Saglabat Admina Opcijas");
define("TPVLAN_43", "Admina Opcijas saglabatas");
define("TPVLAN_46", "PCLZIP ekstraktu kļūda:");
define("TPVLAN_47", "PCLTAR ekstraktu kļūda:");
define("TPVLAN_48", "Kods:");


?>