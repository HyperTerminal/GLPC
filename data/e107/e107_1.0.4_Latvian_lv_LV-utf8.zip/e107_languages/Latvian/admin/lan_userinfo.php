<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("USFLAN_1", "Nevar atrast autora IP adresi - informācija nav pieejama.");
define("USFLAN_3", "Ziņojums ievietots no IP adreses");
define("USFLAN_4", "Hosts");
define("USFLAN_5", "Noklikšķiniet šeit, lai pārsūtītu IP adresi uz admin aizliegumu lapu");
define("USFLAN_6", "Lietotāja ID");
define("USFLAN_7", "Lietotāja Informācija");


?>