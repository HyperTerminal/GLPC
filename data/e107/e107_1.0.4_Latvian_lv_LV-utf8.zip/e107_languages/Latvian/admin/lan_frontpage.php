<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("FRTLAN_1", "Sākumlapas Iestatījumi atjaunoti");
define("FRTLAN_2", "Uzstādīt Sākumlapu priekš");
define("FRTLAN_6", "Linki");
define("FRTLAN_12", "Atjaunot Sākumlapas Iestatījumus");
define("FRTLAN_13", "Sākumlapas Iestatījumi");
define("FRTLAN_15", "Cita (ievadi url):");
define("FRTLAN_16", "Kļūda: Nav izvelets galvenais saturs");
define("FRTLAN_17", "Kļūda: Nav izvelets apakškatagorija");
define("FRTLAN_18", "Kļūda: Nav izvelets saturs");
define("FRTLAN_19", "Galvenais saturs");
define("FRTLAN_20", "Satura Katagorija");
define("FRTLAN_21", "Saturs");
define("FRTLAN_22", "Pielāgota lapa");
define("FRTLAN_26", "Visi Lietotaji");
define("FRTLAN_27", "Ciemiņi");
define("FRTLAN_28", "Biedri");
define("FRTLAN_29", "Admini");
define("FRTLAN_31", "Visi Lietotaji");
define("FRTLAN_32", "Klases");
define("FRTLAN_33", "Satura Iestatījumi");
define("FRTLAN_34", "Lapa");


?>