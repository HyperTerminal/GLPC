<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Aktivizēt Emocijas");
define("EMOLAN_2", "Nosaukums");
define("EMOLAN_3", "Emocijas");
define("EMOLAN_4", "Aktivizēt?");
define("EMOLAN_5", "Bilde");
define("EMOLAN_6", "Emociju Kods");
define("EMOLAN_7", "Atdaliet vairākas ierakstus ar atstarpēm");
define("EMOLAN_8", "Status");
define("EMOLAN_9", "Opcija");
define("EMOLAN_10", "Aktīvs");
define("EMOLAN_11", "Aktivizēt Paku");
define("EMOLAN_12", "Labot / Konfigurēt šo paku");
define("EMOLAN_13", "Uzstadītas Pakas");
define("EMOLAN_14", "Saglabat");
define("EMOLAN_15", "Labot emocijas");
define("EMOLAN_16", "Emociju konfiguracija saglabata");
define("EMOLAN_17", "Jums ir emociju packā saturs, kurš satur atstarpes, kas nav atļauta!");
define("EMOLAN_18", "lūdzu pārdēvēt gadījumus, kas uzskaitīti zemāk, lai viņi vairs saturēt atstarpes:");
define("EMOLAN_19", "Nosaukums");
define("EMOLAN_20", "Vieta");
define("EMOLAN_21", "Kļūda");
define("EMOLAN_22", "Jauna emociju paka atrasta");
define("EMOLAN_23", "Jauna emociju xml paka atrasta:");
define("EMOLAN_24", "Jauns emociju php atrast:");
define("EMOLAN_25", "Uzstada Jaunu PHP emocijas:");
define("EMOLAN_26", "Atkartot-Skenēsanas Paka");
define("EMOLAN_27", "Kļūda apstrādes pakotni:");
define("EMOLAN_28", "Izveidot XML");
define("EMOLAN_29", "XML fails Izveidots:");
define("EMOLAN_30", "Kļūda rakstot XML failu:");


?>