<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("ONLINE_EL1", "Ciemiņu:");
define("ONLINE_EL2", "Biedru:");
define("ONLINE_EL3", "Šajā Lapā:");
define("ONLINE_EL4", "Ienācis");
define("ONLINE_EL5", "Biedri");
define("ONLINE_EL6", "Jauniņais");
define("ONLINE_EL7", "skatās");
define("ONLINE_EL8", "visvairāk ienākuši bija:");
define("ONLINE_EL9", "kad");
define("ONLINE_EL10", "Biedra Vārds");
define("ONLINE_EL11", "Skatās Lapu");
define("ONLINE_EL12", "Atbildot uz");
define("ONLINE_EL13", "Forums");
define("ONLINE_EL14", "Tēma");
define("ONLINE_EL15", "Lapa");
define("CLASSRESTRICTED", "Klases Ierobežota lapa");
define("ARTICLEPAGE", "Raksts / apskats");
define("CHAT", "Čats");
define("COMMENT", "Komentāri");
define("DOWNLOAD", "Faili");
define("EMAIL", "epasts.php");
define("FORUM", "Foruma Sākums");
define("LINKS", "Linki");
define("NEWS", "Jaunumi");
define("OLDPOLLS", "Vecās Aptaujas");
define("POLLCOMMENT", "Aptauja");
define("PRINTPAGE", "Printēt");
define("LOGIN", "Piesakās");
define("SEARCH", "Meklē");
define("STATS", "Stati");
define("SUBMITNEWS", "Iesniegt Ziņu");
define("UPLOAD", "Augšupielāde");
define("USERPAGE", "Biedra Konti");
define("USERSETTINGS", "Biedra Iestatījumi");
define("ONLINE", "Pieteikušies Biedri");
define("LISTNEW", "Jaunumu saraksts");
define("USERPOSTS", "Biedra Raksti");
define("SUBCONTENT", "Iesniegt rakstu / pārskatu");
define("TOP", "Top Raksnieki / Aktīvākās Tēmas");
define("ADMINAREA", "Admina Zona");
define("BUGTRACKER", "Kļūdusekošana");
define("EVENT", "Notikumu saraksts");
define("CALENDAR", "Notikumu Kalendārs");
define("FAQ", "Buj");
define("PM", "Vēstules");
define("SURVEY", "Pārskats");
define("ARTICLE", "Raksts");
define("CONTENT", "Saturu lapa");
define("REVIEW", "Pārskats");


?>