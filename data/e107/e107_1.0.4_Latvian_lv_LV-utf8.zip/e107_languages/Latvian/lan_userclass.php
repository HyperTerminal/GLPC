<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Ik Vienam (publisks)");
define("UC_LAN_1", "Ciemiņš");
define("UC_LAN_2", "Ne Vienam (neaktīvs)");
define("UC_LAN_3", "Biedri");
define("UC_LAN_4", "Tikai Lasīt");
define("UC_LAN_5", "Admin");
define("UC_LAN_6", "Īpašnieks");
define("UC_LAN_9", "Jauns Biedrs");
define("UC_LAN_10", "Meklēt Botu");


?>