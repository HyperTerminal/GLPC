<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("US_LAN_1", "izvēlieties lietotāju");
define("US_LAN_2", "izvēlieties lietotāju klasi");
define("US_LAN_3", "Visi Lietotāji");
define("US_LAN_4", "Atrast Lietotājvārdu");
define("US_LAN_5", "Lietotājs(i) atrasti");
define("US_LAN_6", "Meklēt");


?>