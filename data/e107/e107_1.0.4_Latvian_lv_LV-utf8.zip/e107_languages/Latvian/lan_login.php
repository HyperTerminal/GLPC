<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("LAN_27", "Jūs atstāja vajadzīgo lauku(s) tukšus");
define("LAN_300", "Nepareiza pieteikšanās. Ievadītie dati nesakrīt ar reģistrēto lietotāju. Pārbaudiet vai Jums gadījumā ir CAPS-LOCK taustiņš aktivizēts,pieteikšanās šajā vietnē ir reģistrjutīgas");
define("LAN_302", "Jūs neesat aktivizējis savu kontu. Jums būtu jāsaņem e-pasts ar instrukcijām par to, lai apstiprinātu savu kontu. Ja nē, lūdzu, klikšķiniet<a href='".e_BASE."signup.php?resend'>šeit</a>.");
define("LAN_303", "Nepareiza kods ievadīts.");
define("LAN_304", "Šis lietotājvārds / parole kombinācija ir jau lietošanā.");
define("LAN_LOGIN_1", "Lietotājvārds");
define("LAN_LOGIN_2", "Parole");
define("LAN_LOGIN_3", "Aizsargāts serveris");
define("LAN_LOGIN_4", "Lūdzu, ievadiet savu informāciju, lai piekļūtu.");
define("LAN_LOGIN_5", "Noklikšķiniet šeit, lai Reģistrēties");
define("LAN_LOGIN_6", "Šobrīd Nepieņemam jaunus dalībniekus");
define("LAN_LOGIN_7", "Ievadiet redzamo kodu");
define("LAN_LOGIN_8", "Atcerēties mani");
define("LAN_LOGIN_9", "Pieteikties");
define("LAN_LOGIN_10", "Noklikšķiniet, lai pieteiktos");
define("LAN_LOGIN_11", "Reģistrēties kā jaunam lietotājam");
define("LAN_LOGIN_12", "Aizmirsu paroli");
define("LAN_LOGIN_13", "Lūdzu, ievadiet tekstu no attēla");
define("LAN_LOGIN_14", "Lietotājs mēģināja ielogoties ar neatpazītu lietotāja vārdu");
define("LAN_LOGIN_15", "Lietotājs mēģināja autorizēties ar nepareizu paroli");
define("LAN_LOGIN_16", "Lietotājs mēģināja pieteikies ar lietotājvārdu / paroles kombināciju, kas jau tiek izmantota");
define("LAN_LOGIN_17", "Lietotāja parole (sajaukts)");
define("LAN_LOGIN_18", "Auto-ban: Vairāk nekā 10 neizdevās pieteikšanās mēģinājumi");
define("LAN_LOGIN_19", "> 10 neizdevušos pieteikšanās mēģinājumi");


?>