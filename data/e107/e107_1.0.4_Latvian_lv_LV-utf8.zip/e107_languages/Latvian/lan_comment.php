<?php
/*
+-----------------------------------------------------------------------------+
|     Translated by: Sandijs Grīnbergs
|     WWW: http://sandijs.ucoz.lv
|     E-mail: sandijsgrinbergs@gmail.com
+-----------------------------------------------------------------------------+
*/
define("COMLAN_0", "[Admins Bloķējis]");
define("COMLAN_1", "Atslēgt");
define("COMLAN_2", "Bloķēt");
define("COMLAN_3", "Dzēst");
define("COMLAN_4", "Info");
define("COMLAN_5", "Komentāri ...");
define("COMLAN_6", "Jums ir jābūt pieteicies sistēmā, lai pievienotu komentārus - lūdzu, ieejiet, vai, ja neesat reģistrējies spied");
define("COMLAN_7", "Īpašnieks");
define("COMLAN_8", "Komentārs");
define("COMLAN_9", "Iesniegt");
define("COMLAN_10", "Administrātors");
define("COMLAN_11", "Nevarēja ievadīt Jūsu komentāru datu bāzē - lūdzu ievadiet vēlreiz, bet nelietojiet nevienu nestandarta rakstzīmes.");
define("COMLAN_12", "Biedrs");
define("COMLAN_16", "Lietotājavārds:");
define("COMLAN_99", "Komentāri");
define("COMLAN_100", "Jaunumi");
define("COMLAN_101", "Aptauja");
define("COMLAN_102", "Atbildot uz:");
define("COMLAN_103", "Raksts");
define("COMLAN_104", "Pārskats");
define("COMLAN_105", "Saturs");
define("COMLAN_106", "Faili");
define("COMLAN_145", "Reģistrēts:");
define("COMLAN_194", "Ciemiņš");
define("COMLAN_195", "Biedrs");
define("COMLAN_310", "Nevar pieņemt rakstu, no šī lietotājvārda ir reģistrēta - ja tas ir jūsu lietotājvārds lūdzu piesakieties sistēmā, lai pievienotu!");
define("COMLAN_312", "Dublikāts, nevar apstiprināt!");
define("COMLAN_313", "Vieta");
define("COMLAN_314", "Pāŗvaldīt");
define("COMLAN_315", "Izsekošana");
define("COMLAN_316", "Nav izsekošanas šim rakstam!");
define("COMLAN_317", "Pārvaldīt");
define("COMLAN_318", "Labot");
define("COMLAN_319", "labots");
define("COMLAN_320", "Atjaunot");
define("COMLAN_321", "šeit");
define("COMLAN_322", "lai pierakstītos");
define("COMLAN_323", "Kļūda!");
define("COMLAN_324", "Temats");
define("COMLAN_325", "Au:");
define("COMLAN_326", "Atbildot uz");
define("COMLAN_327", "Reitings");
define("COMLAN_328", "Komentāri ir slēgti");
define("COMLAN_329", "Neautorizēts");
define("COMLAN_330", "IP:");
define("COMLAN_331", "Gaida apstiprinājumu");
define("COMLAN_TYPE_1", "jaunumi");
define("COMLAN_TYPE_2", "faili");
define("COMLAN_TYPE_3", "buj");
define("COMLAN_TYPE_4", "aptauja");
define("COMLAN_TYPE_5", "docs");
define("COMLAN_TYPE_6", "kļūdu trase");
define("COMLAN_TYPE_7", "idejas");
define("COMLAN_TYPE_8", "biedra profils");
define("COMLAN_TYPE_PAGE", "Saturs");


?>