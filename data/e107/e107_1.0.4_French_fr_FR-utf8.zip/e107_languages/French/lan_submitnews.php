<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_submitnews.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/06/26 00:18:55 $
 * $Author: marj_nl_fr $
 */
define("PAGE_NAME", "Proposer une news");
define("LAN_7", "Nom d\'utilisateur: ");
define("LAN_62", "Sujet: ");
define("LAN_112", "Adresse email: ");
define("LAN_133", "Merci");
define("LAN_134", "Votre news a bien été enregistrée et sera examinée par un administrateur prochainement.");
define("LAN_135", "News: ");
define("LAN_136", "Proposer une news");
define("NWSLAN_6", "Catégorie");
define("NWSLAN_10", "Aucune catégorie de news");
define("NWSLAN_11", "Vous n\'avez pas accès à cette page.");
define("NWSLAN_12", "Accès refusé.");
define("SUBNEWSLAN_1", "Vous devez inclure un titre.\n");
define("SUBNEWSLAN_2", "Vous devez inclure un texte dans le corps de la news.\n");
define("SUBNEWSLAN_3", "Votre fichier joint doit être en jpg, gif ou png.");
define("SUBNEWSLAN_4", "Votre fichier est trop volumineux.");
define("SUBNEWSLAN_5", "Fichier image");
define("SUBNEWSLAN_6", "(jpg, gif ou png)");
define("SUBNEWSLAN_7", "Vous devez donner votre nom et votre adresse e-mail");
define("SUBNEWSLAN_8", "Erreur lors de l'envoi de l'image");


?>