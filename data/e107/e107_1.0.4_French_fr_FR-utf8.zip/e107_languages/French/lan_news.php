<?php
/*
+---------------------------------------------------------------+
| Fichiers de langage Français e107 CMS (utf-8). License GNU/PGL
| Traducteurs: communauté française e107
|     $Source: /cvsroot/e107/e107_langpacks/e107_languages/French/lan_news.php,v $
|     $Revision: 11465 $
|     $Date: 2010-04-07 16:36:23 -0400 (Wed, 07 Apr 2010) $
|     $Author: e107steved $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Actualités");
define("LAN_NEWS_1", "Actualité réservée uniquement aux membres du site");
define("LAN_NEWS_2", "Vous n'êtes pas autorisé à voir cette actualité");
define("LAN_NEWS_9", "Seul le Titre s'affiche - <strong>Seul le titre de l'actualité sera affiché</strong><br />");
define("LAN_NEWS_10", "La proposition d'actualités est <strong>désactivé</strong>. (Elle ne sera pas disponible pour vos visiteurs).");
define("LAN_NEWS_11", "La proposition d'actualités est <strong>activé</strong>. (Elle sera disponible pour vos visiteurs).");
define("LAN_NEWS_12", "Les commentaires sont <strong>activés</strong>.");
define("LAN_NEWS_13", "Les commentaires sont <strong>désactivés</strong>.");
define("LAN_NEWS_14", "<br />Période d'activation:");
define("LAN_NEWS_15", "Longueur du corps:");
define("LAN_NEWS_16", "b. Longueur de l'extension:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Maintenant");
define("LAN_NEWS_23", "Catégories d'actualités");
define("LAN_NEWS_24", "Créer un pdf pour cette actualité");
define("LAN_NEWS_25", "Editer");
define("LAN_NEWS_31", "Mettre la news en post it");
define("LAN_NEWS_82", "Actualités - Catégorie");
define("LAN_NEWS_83", "Aucune actualité pour le moment - veuillez revenir plus tard.");
define("LAN_NEWS_84", "Actualités");
define("LAN_NEWS_85", "Retour à l'aperçu des catégories");
define("LAN_NEWS_86", "Aciennes news");
define("LAN_NEWS_87", "Nouvelles news");
define("LAN_NEWS_462", "Pas d'actualités pour le mois spécifié");
define("LAN_NEWS_99", "Commentaires");
define("LAN_NEWS_100", "Activé");
define("LAN_NEWS_307", "Total des messages dans cette catégorie :");


?>