<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/French.php,v $
 * $Revision: 1.18 $
 * $Date: 2008/10/18 06:54:26 $
 * $Author: marj_nl_fr $
 *
 * @TODO:   bidouille ET_e107_Version_7 pour CORE_LAN13
 *
 *          égalepent à utiliser pour les autres fichiers
 * (ET_e107_Version_7 === true
 *    ? define('LA_CONSTANTE', 'texte pour v0.7')
 *    : define('LA_CONSTANTE', 'texte pour v0.8')
 *    );
 */
setlocale(LC_ALL, 'fr_FR.UTF-8', 'fr_FR.utf8', 'fr_FR@euro', 'fra_fra.utf8', 'fr_FR', 'fr');
define("CORE_LC", "fr");
define("CORE_LC2", "fr");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Erreur: le thème requis est manquant.\\n\\nChangez le thème utilisé dans les préférences (administration) ou uploadez les fichiers du thème actuel sur le serveur.");
define("CORE_LAN4", "Veuillez effacer le fichier install.php de votre serveur.");
define("CORE_LAN5", "Sinon cela représente un risque non négligeable pour votre site!!!");
define("CORE_LAN6", "La protection anti-inondation (flood) à été activée sur ce site. Si vous persévérez d\'effectuer des requêtes trop fréquentes vous risquez d\'être banni.");
define("CORE_LAN7", "Le noyau tente de restaurer la sauvegarde automatique.");
define("CORE_LAN8", "Erreur préférences noyau");
define("CORE_LAN9", "Le noyau n\'a pas pu restaurer la sauvegarde automatique. Exécution arrêtée.");
define("CORE_LAN10", "Cookie corrompu détecté. Déconnexion.");
define("CORE_LAN11", "Temps d'exécution:");
define("CORE_LAN12", "s, dont");
define("CORE_LAN13", "de celui des requêtes.");
define("CORE_LAN14", "%2.3f CPU sec (chargement %2.2f%%, initialisation %2.3f). Horloge:");
define("CORE_LAN15", "Requêtes BdD:");
define("CORE_LAN16", "Utilisation mémoire:");
define("CORE_LAN17", "[images désactivées]");
define("CORE_LAN18", "image:");
define("CORE_LAN_B", "o");
define("CORE_LAN_KB", "ko");
define("CORE_LAN_MB", "Mo");
define("CORE_LAN_GB", "Go");
define("CORE_LAN_TB", "To");
define("LAN_WARNING", "Attention!");
define("LAN_ERROR", "Erreur");
define("LAN_ANONYMOUS", "Anonyme");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_SANITISED", "DESINFECTE");


?>