<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_prefs.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/25 21:36:17 $
 * $Author: marj_nl_fr $
 */

define('LAN_PREF_1', 'Site web généré par e107');
define('LAN_PREF_2', 'Système de site web e107');
define('LAN_PREF_3', 'Ce site est généré par <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, paru conformément aux termes de la licence <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL.');
define('LAN_PREF_4', 'censuré');
define('LAN_PREF_5', 'Forums');
