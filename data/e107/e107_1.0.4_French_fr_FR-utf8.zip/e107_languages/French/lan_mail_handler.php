<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_mail_handler.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 13:04:59 $
 * $Author: marj_nl_fr $
 */
 
define('LANMAILH_1', 'Produit par le système de sites e107');
define('LANMAILH_2', 'Ceci est un message multivolets au format MIME.'); //??? à débattre
define('LANMAILH_3', ' n\'est pas correctement formaté');
define('LANMAILH_4', 'Le serveur a rejeté l\'adresse');
define('LANMAILH_5', 'Aucune réponse depuis le serveur');
define('LANMAILH_6', 'Ne peut pas trouver le serveur de courrier électronique.');
define('LANMAILH_7', ' semble être valide.');
