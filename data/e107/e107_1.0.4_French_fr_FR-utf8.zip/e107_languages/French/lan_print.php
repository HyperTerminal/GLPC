<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_print.php,v $
 * $Revision: 1.10 $
 * $Date: 2008/06/28 13:05:48 $
 * $Author: marj_nl_fr $
 */
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Version imprimable");}
define("LAN_PRINT_86", "Catégorie ");
define("LAN_PRINT_87", "par ");
define("LAN_PRINT_94", "Posté par");
define("LAN_PRINT_135", "News ");
define("LAN_PRINT_303", "Cet item a été imprimée depuis le site ");
define("LAN_PRINT_304", "Titre: ");
define("LAN_PRINT_305", "Sous-titre: ");
define("LAN_PRINT_306", "Document de: ");
define("LAN_PRINT_307", "Imprimer cette page");
define("LAN_PRINT_1", "Version imprimable");


?>