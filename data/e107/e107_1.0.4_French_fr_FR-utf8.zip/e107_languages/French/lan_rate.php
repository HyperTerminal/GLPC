<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_rate.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 13:04:59 $
 * $Author: marj_nl_fr $
 */
 
define('RATELAN_0', 'vote');
define('RATELAN_1', 'votes');
define('RATELAN_2', 'Comment évaluez vous cet item?');
define('RATELAN_3', 'Merci pour votre évaluation');
define('RATELAN_4', 'non évalué');
define('RATELAN_5', 'Évaluer');
