<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_upload.php,v $
 * $Revision: 1.9 $
 * $Date: 2008/06/25 21:36:17 $
 * $Author: marj_nl_fr $
 */
define("PAGE_NAME", "Upload");
define("LAN_UL_001", "adresse email non valide.");
define("LAN_UL_002", "Vous n'avez pas la permission d\'uploader des fichiers sur ce serveur.");
define("LAN_UL_020", "Erreur");
define("LAN_UL_021", "Problème upload");
define("LAN_UL_032", "Vous devez sélectionner une catégorie");
define("LAN_UL_033", "Vous devez entrer une adresse email valide");
define("LAN_UL_034", "Vous devez spécifier le fichier");
define("LAN_UL_035", "Vous devez entrer un description");
define("LAN_UL_036", "Vous devez spécifier le fichier a envoyer");
define("LAN_UL_037", "Vous devez spécifier une catégorie");
define("LAN_UL_038", "Vous devez spécifier le nom de l'auteur");
define("LAN_61", "Nom de l'auteur: ");
define("LAN_112", "Adresse email de l'auteur: ");
define("LAN_144", "Site internet de l'auteur: ");
define("LAN_402", "Vous devez être enregistré sur ce site pour pouvoir uploader des fichiers sur ce serveur.");
define("LAN_404", "Merci. Votre upload sera examiné par un administrateur.<br />L'administrateur est en droit de refuser votre upload si il ne répond pas à ses attentes.");
define("LAN_406", "Veuillez noter");
define("LAN_407", "Tous les autres types de fichiers seront supprimés instantanément.");
define("LAN_408", "Les champs soulignés");
define("LAN_409", "Nom du fichier");
define("LAN_410", "Version");
define("LAN_411", "Fichier");
define("LAN_412", "Copie d'écran");
define("LAN_413", "Description du plugin");
define("LAN_414", "Lien de démonstration");
define("LAN_415", "entrez l'URL du site où une démonstration peut être vue");
define("LAN_416", "Envoyer");
define("LAN_417", "Envoyer un fichier");
define("LAN_418", "Taille maximale du fichier: ");
define("DOWLAN_11", "Catégorie");
define("LAN_419", "Types de fichiers autorisés");
define("LAN_420", "sont obligatoires.");


?>