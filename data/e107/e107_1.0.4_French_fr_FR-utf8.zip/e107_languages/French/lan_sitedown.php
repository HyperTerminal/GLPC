<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_sitedown.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/24 23:51:46 $
 * $Author: marj_nl_fr $
 */

define('PAGE_NAME', 'Site temporairement fermé');
define('LAN_SITEDOWN_00', 'est temporairement fermé');
define('LAN_SITEDOWN_01', 'Nous avons fermé temporairement le site pour cause de maintenance. Cela ne devrait pas être trop long. Veuillez revenir bientôt en nous excuser pour la gène occasionnée.');
