<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_frontpage.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/07/26 21:15:50 $
 * $Author: marj_nl_fr $
 */
define("FRTLAN_1", "Paramètres de la page d\'accueil mis à jour.");
define("FRTLAN_2", "Page d\'accueil pour");
define("FRTLAN_6", "Liens");
define("FRTLAN_12", "Mettre à jour les paramètres");
define("FRTLAN_13", "Paramètres de la page d\'accueil");
define("FRTLAN_15", "Autre (entrer l\'URL):");
define("FRTLAN_16", "erreur: aucune page principale sélectionnée");
define("FRTLAN_17", "erreur: aucune sous-catégorie sélectionnée");
define("FRTLAN_18", "erreur: aucune page sélectionnée");
define("FRTLAN_19", "Catégorie principale de pages de contenu");
define("FRTLAN_20", "catégorie de  pages de contenu");
define("FRTLAN_21", "pages de contenu");
define("FRTLAN_22", "Page personnalisée");
define("FRTLAN_26", "tous les utilisateurs");
define("FRTLAN_27", "Visiteurs");
define("FRTLAN_28", "Membres");
define("FRTLAN_29", "Administrateurs");
define("FRTLAN_31", "Tous les utilisateurs");
define("FRTLAN_32", "Groupe d\'utilisateurs");
define("FRTLAN_33", "Paramètres actuels");
define("FRTLAN_34", "Page d\'accueil");


?>