<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_filemanager.php,v $
 * $Revision: 1.5 $
 * $Date: 2008/06/16 15:03:46 $
 * $Author: marj_nl_fr $
 */
define("FMLAN_1", "Uploadé");
define("FMLAN_2", "dans le");
define("FMLAN_3", "répertoire");
define("FMLAN_4", "Le fichier uploadé excède la taille maximale autorisée par la variable upload_max_filesize dans php.ini.");
define("FMLAN_10", "Erreur");
define("FMLAN_12", "fichier");
define("FMLAN_13", "fichiers");
define("FMLAN_14", "répertoire");
define("FMLAN_15", "répertoires");
define("FMLAN_16", "Répertoire racine");
define("FMLAN_17", "Nom");
define("FMLAN_18", "Taille");
define("FMLAN_19", "Dernière modification");
define("FMLAN_21", "Uploader un fichier dans ce dossier");
define("FMLAN_22", "Uploader");
define("FMLAN_26", "Supprimé");
define("FMLAN_27", "supprimé avec succès");
define("FMLAN_28", "Impossible de supprimer");
define("FMLAN_29", "Chemin");
define("FMLAN_30", "Revenir au répertoire précédent");
define("FMLAN_31", "dossier");
define("FMLAN_32", "Sélectionner un répertoire");
define("FMLAN_33", "Sélectionner");
define("FMLAN_34", "Choix du répertoire");
define("FMLAN_35", "Répertoire des fichiers");
define("FMLAN_36", "Répertoire des menus personnalisés");
define("FMLAN_37", "Répertoire des pages personnalisées");
define("FMLAN_38", "Fichier déplacé avec succès vers");
define("FMLAN_39", "Impossible de déplacer le fichier vers");
define("FMLAN_40", "Répertoire Newspost-Images");
define("FMLAN_43", "Supprimer les fichiers sélectionnés");
define("FMLAN_46", "Veuillez confirmer que vous souhaitez supprimer les fichiers sélectionnés.");
define("FMLAN_47", "Uploads des utilisateurs");
define("FMLAN_48", "Déplacer la sélection vers");
define("FMLAN_49", "Veuillez confirmer que vous souhaitez déplacer les fichiers sélectionnés.");
define("FMLAN_50", "Déplacer");
define("FMLAN_51", "Erreur non identifiée :");


?>