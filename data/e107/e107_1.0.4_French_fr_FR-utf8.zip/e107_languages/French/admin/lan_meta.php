<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_meta.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 15:03:46 $
 * $Author: marj_nl_fr $
 */

define('METLAN_1', 'Les Méta-tags ont été mis à jour dans la base de données');
define('METLAN_2', 'Entrer les méta-tags');
define('METLAN_3', 'Entrer les nouveaux méta-tags');
define('METLAN_4', 'Mis à jour');
define('METLAN_5', 'saisissez votre description ici');
define('METLAN_6', 'saisissez, une, liste, de, mots, clés, ici');
define('METLAN_7', 'saisissez les infos de droits d\'auteur ici');
define('METLAN_8', 'Méta-Tags');

define('METLAN_9', 'Description');
define('METLAN_10', 'Mots clés');
define('METLAN_11', 'Copyright');
define('METLAN_12', 'Utiliser le titre et la description comme Méta tag de description de vos pages de news.');
define('METLAN_13', 'Auteur');
