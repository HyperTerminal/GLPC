<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * non compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_mailout.php,v $
 * $Revision: 1.14 $
 * $Date: 2008/08/01 16:51:03 $
 * $Author: marj_nl_fr $
 */
define("PRFLAN_52", "Sauvegarder les modifications");
define("PRFLAN_63", "Envoi mail de test");
define("PRFLAN_65", "Cliquer pour envoyer le mail &agrave;");
define("PRFLAN_66", "Test email de");
define("PRFLAN_67", "Ceci est un mail de test. Il semble que vos paramètres email sont corrects!<br>Salutations du système de site Web e107.");
define("PRFLAN_68", "Le mail n\'a pas pu être envoyé. Il semblerait que votre serveur ne soit pas correctement configuré pour envoyer des emails. Veuillez essayer d\'utiliser le SMTP, ou contacter votre hébergeur et demander lui de vous envoyer leurs paramètres d\'envoi d\'emails ou de serveur d\'email.");
define("PRFLAN_69", "Le mail a été envoyé avec succès. Merci de contrôler votre boite mail.");
define("PRFLAN_70", "Activer le SMTP");
define("PRFLAN_71", "cocher pour utiliser le serveur SMTP pour envoyer des emails");
define("PRFLAN_72", "Serveur SMTP");
define("PRFLAN_73", "Nom d\'utilisateur SMTP");
define("PRFLAN_74", "Mot de passe SMTP");
define("PRFLAN_75", "L\'email n\'as pas pu être envoyé. Veuillez vérifier vos paramètres SMTP, ou désactiver le SMTP et essayer de nouveau.");
define("MAILAN_01", "De (pseudo)");
define("MAILAN_02", "De (email)");
define("MAILAN_03", "À");
define("MAILAN_04", "Cc");
define("MAILAN_05", "Ccl");
define("MAILAN_06", "Sujet");
define("MAILAN_07", "Fichier attaché");
define("MAILAN_08", "Envoyer le mail");
define("MAILAN_09", "Utilise un style de thème");
define("MAILAN_10", "Utilisateurs inscrits");
define("MAILAN_11", "Insérer des variables");
define("MAILAN_12", "Tous les membres");
define("MAILAN_13", "Tous les membres non vérifiés");
define("MAILAN_14", "Il est recommandé d\'activer le <a href=\'prefs.php\'>SMTP</a> pour des envois d\'emails en masse.<br /><br />");
define("MAILAN_15", "Envoi des mails");
define("MAILAN_16", "Nom d\'utilisateur");
define("MAILAN_17", "Lien d\'enregistrement");
define("MAILAN_18", "ID utilisateur");
define("MAILAN_19", "Il n\'y a aucune adresse électronique pour l\'admin du site. Vérifiez vos préférences et essayez à nouveau.");
define("MAILAN_20", "Chemin de sendmail");
define("MAILAN_21", "Entrées email en masse");
define("MAILAN_22", "Il n\'y a aucune sauvegarde d\'emails pour le moment.");
define("MAILAN_23", "Groupe de membres:");
define("MAILAN_24", "email(s) prêt à être envoyé(s)");
define("MAILAN_25", "Pause");
define("MAILAN_26", "Pause durant les envois en masse toutes les");
define("MAILAN_27", "emails");
define("MAILAN_28", "Durée de la pause");
define("MAILAN_29", "secondes");
define("MAILAN_30", "Attention: une pause supérieure à 30 secondes pourraient conduire à une déconnexion et n\'est donc pas recommandée.");
define("MAILAN_31", "Emails retours en cours");
define("MAILAN_32", "Email");
define("MAILAN_33", "Emails arrivés");
define("MAILAN_34", "Nom compte");
define("MAILAN_35", "Mot de passe");
define("MAILAN_36", "Effacer les emails non délivrés après vérification");
define("MAILAN_37", "Exécuter");
define("MAILAN_38", "Annuler");
define("MAILAN_39", "Mailing");
define("MAILAN_40", "Vous devez renommer <b>e107.htaccess</b> en <b>.htaccess</b> dans");
define("MAILAN_41", "avant de pouvoir envoyer un message depuis cette page.");
define("MAILAN_42", "Attention");
define("MAILAN_43", "Nom d\'utilisateur");
define("MAILAN_44", "Pseudo");
define("MAILAN_45", "Email");
define("MAILAN_46", "Utilisateur");
define("MAILAN_47", "(contient)");
define("MAILAN_48", "(est égal à)");
define("MAILAN_49", "Id");
define("MAILAN_50", "Auteur");
define("MAILAN_51", "Sujet");
define("MAILAN_52", "Dernière modif");
define("MAILAN_53", "Admins");
define("MAILAN_54", "Soi même");
define("MAILAN_55", "Groupe de membres");
define("MAILAN_56", "Envoyer le mail");
define("MAILAN_57", "Conserver la session SMTP active (<q>alive</q>)");
define("MAILAN_58", "Problème avec les fichiers joints:");
define("MAILAN_59", "Mailing en cours");
define("MAILAN_60", "Envoi ...");
define("MAILAN_61", "Tous les mail ont été envoyer.");
define("MAILAN_62", "Emails envoyés:");
define("MAILAN_63", "Emails non envoyés:");
define("MAILAN_64", "Temps requis pour l\'envoi:");
define("MAILAN_65", "secondes");
define("MAILAN_66", "Annulation réussie");
define("MAILAN_67", "Utiliser l\'authentification <q>POP avant SMTP</q>");
define("MAILAN_68", "Adresse test");
define("MAILAN_69", "login utilisateur");
define("MAILAN_70", "email utilisateur");


?>