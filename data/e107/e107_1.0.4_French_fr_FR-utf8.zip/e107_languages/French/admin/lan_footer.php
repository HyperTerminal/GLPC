<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_footer.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/23 13:36:55 $
 * $Author: marj_nl_fr $
 */
define("FOOTLAN_1", "Site");
define("FOOTLAN_2", "Administrateur principal");
define("FOOTLAN_3", "Version");
define("FOOTLAN_4", "sortie le");
define("FOOTLAN_5", "Thème admin");
define("FOOTLAN_6", "par");
define("FOOTLAN_7", "Infos");
define("FOOTLAN_8", "Date d\'installation");
define("FOOTLAN_9", "Serveur");
define("FOOTLAN_10", "Nom de domaine");
define("FOOTLAN_11", "Version PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Informations sur le site");
define("FOOTLAN_14", "Afficher la documentation");
define("FOOTLAN_15", "Documentation");
define("FOOTLAN_16", "Base de données");
define("FOOTLAN_17", "Charset");
define("FOOTLAN_18", "Thème du site");
define("FOOTLAN_19", "Heure locale du serveur");
define("FOOTLAN_20", "Niveau de sécurité");


?>