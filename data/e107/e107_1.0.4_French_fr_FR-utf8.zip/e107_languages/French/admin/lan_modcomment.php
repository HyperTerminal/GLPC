<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_modcomment.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/06/30 22:32:47 $
 * $Author: marj_nl_fr $
 */
define("MDCLAN_1", "Modéré.");
define("MDCLAN_2", "Aucun commentaire pour cette news");
define("MDCLAN_3", "Membre");
define("MDCLAN_4", "Visiteur");
define("MDCLAN_5", " débloquer");
define("MDCLAN_6", " bloquer");
define("MDCLAN_7", " approuver");
define("MDCLAN_8", "Modérer les commentaires");
define("MDCLAN_9", "Attention! La suppression d'une catégorie de commentaires supprime tous les commentaires!");
define("MDCLAN_10", " options");
define("MDCLAN_11", " commentaire");
define("MDCLAN_12", " commentaires");
define("MDCLAN_13", "Bloqué(s)");
define("MDCLAN_14", "Désactiver les commentaires");
define("MDCLAN_15", " ouvert");
define("MDCLAN_16", " désactivé");
define("MDCLAN_17", "Il n'y a pas de commentaires en attente d'approbation pour l'instant");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>