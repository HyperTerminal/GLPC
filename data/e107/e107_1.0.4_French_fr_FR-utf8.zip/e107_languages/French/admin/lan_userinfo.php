<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_userinfo.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 15:07:08 $
 * $Author: marj_nl_fr $
 */

define('USFLAN_1', 'Impossible de trouver l\'Ip de cette personne. Aucune information n\'est disponible.');
//define('USFLAN_2', 'Erreur');
define('USFLAN_3', 'Messages postés depuis l\'adresse IP');
define('USFLAN_4', 'Hôte');
define('USFLAN_5', 'Cliquer ici pour transférer l\'adresse IP dans la liste de bannissements');
define('USFLAN_6', 'ID du membre');
define('USFLAN_7', 'Informations sur l\'utilisateur');
