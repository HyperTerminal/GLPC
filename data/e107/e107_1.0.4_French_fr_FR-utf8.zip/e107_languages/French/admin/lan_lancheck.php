<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_lancheck.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/07/26 21:15:50 $
 * $Author: marj_nl_fr $
 */
define("LAN_CHECK_1", "Vérifier/éditer les fichiers langues");
define("LAN_CHECK_2", "Commencer la vérification");
define("LAN_CHECK_3", "Vérification de");
define("LAN_CHECK_4", "Fichier manquant!");
define("LAN_CHECK_5", "Phrase manquante!");
define("LAN_CHECK_7", "phrase");
define("LAN_CHECK_8", "Un fichier est manquant ...");
define("LAN_CHECK_9", " fichiers manquants ...");
define("LAN_CHECK_10", "Erreur critique:");
define("LAN_CHECK_11", "Pas de fichier manquant!");
define("LAN_CHECK_12", "Ce fichier n\'est pas valide ...");
define("LAN_CHECK_13", " fichiers non valides ...");
define("LAN_CHECK_14", "Tous les fichiers présents sont valides!");
define("LAN_CHECK_15", "Caractères illégaux détectés devant <q><?php</q>");
define("LAN_CHECK_16", "Fichier original");
define("LAN_CHECK_17", "Un problème s\'est produit lors de la tentative d\'écriture du fichier.");
define("LAN_CHECK_18", "Les fichiers de langues standard ne sont pas disponibles pour ce plugin/thème.");
define("LAN_CHECK_19", "Caractères non UTF-8 détectés!");
define("LAN_CHECK_20", "Fichier");
define("LAN_CHECK_21", "Thème");
define("LAN_CHECK_22", "Thèmes");
define("LAN_CHECK_23", "Erreurs trouvées");
define("LAN_CHECK_24", "Résumé");
define("LAN_CHECK_25", "Thèmes");
define("LAN_CHECK_26", "Fichier");


?>