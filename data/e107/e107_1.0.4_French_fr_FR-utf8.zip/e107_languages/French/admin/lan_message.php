<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_message.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 15:03:46 $
 * $Author: marj_nl_fr $
 */

define('MESSLAN_1', 'Messages reçus');
define('MESSLAN_2', 'Supprimer le Message');
define('MESSLAN_3', 'Message supprimé.');
define('MESSLAN_4', 'Supprimer tous les messages');
define('MESSLAN_5', 'Confirmer');
define('MESSLAN_6', 'Tous les messages ont été supprimés.');
define('MESSLAN_7', 'Pas de messages.');
define('MESSLAN_8', 'Type de message');
define('MESSLAN_9', 'Signalé le');

define('MESSLAN_10', 'Proposé par');
define('MESSLAN_11', 'Ouvrir dans une nouvelle fenêtre');

define('MESSLAN_12', 'Message');
define('MESSLAN_13', 'Lien');
