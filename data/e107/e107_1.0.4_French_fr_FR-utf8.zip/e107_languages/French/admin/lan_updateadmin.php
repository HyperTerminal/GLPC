<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_updateadmin.php,v $
 * $Revision: 1.5 $
 * $Date: 2008/06/16 15:03:46 $
 * $Author: marj_nl_fr $
 */

define('UDALAN_1', 'Erreur! Veuillez recommencer');
define('UDALAN_2', 'Paramètres mis à jour');
define('UDALAN_3', 'Paramètres mis à jour pour');
define('UDALAN_4', 'Nom');
define('UDALAN_5', 'Saisir le mot de passe');
define('UDALAN_6', 'Resaisir le mot de passe');
define('UDALAN_7', 'Changer de mot de passe');
define('UDALAN_8', 'Mot de passe mis à jour pour');
