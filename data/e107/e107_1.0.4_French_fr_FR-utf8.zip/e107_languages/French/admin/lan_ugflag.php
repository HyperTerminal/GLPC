<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/admin/lan_ugflag.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 15:03:46 $
 * $Author: marj_nl_fr $
 */
define("UGFLAN_1", "Paramètres de maintenance mis à jour");
define("UGFLAN_2", "Activer la maintenance du site");
define("UGFLAN_3", "Mettre à jour");
define("UGFLAN_4", "Paramètres de maintenance");
define("UGFLAN_5", "Texte à afficher lorsque le site est en maintenance");
define("UGFLAN_6", "Laisser vide pour afficher le message par défaut");
define("UGFLAN_8", "Limiter l'accès aux Administrateurs uniquement");
define("UGFLAN_9", "Limiter l'accès aux Administrateurs principal seulement");


?>