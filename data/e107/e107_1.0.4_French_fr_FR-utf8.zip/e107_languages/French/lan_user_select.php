<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_user_select.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/06/18 13:33:20 $
 * $Author: marj_nl_fr $
 */
 
define('US_LAN_1', 'Sélectionner un membre');
define('US_LAN_2', 'Sélectionner un groupe d\utilisateurs');
define('US_LAN_3', 'Tous les membres');
define('US_LAN_4', 'Trouver un membre');
define('US_LAN_5', 'Membre(s) trouvé(s)');
define('US_LAN_6', 'Recherche');
