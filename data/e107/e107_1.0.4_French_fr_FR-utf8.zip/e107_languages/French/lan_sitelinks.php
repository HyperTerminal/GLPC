<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_sitelinks.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/06/24 23:51:25 $
 * $Author: marj_nl_fr $
 */
 
define('LAN_SITELINKS_183', 'Navigation principale');
define('LAN_SITELINKS_502', 'Administration');
