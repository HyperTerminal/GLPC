<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_languages/French/lan_page.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/06/25 21:36:17 $
 * $Author: marj_nl_fr $
 */
define("LAN_PAGE_1", "La liste des pages n'est pas activée");
define("LAN_PAGE_2", "Il n'y a pas de pages");
define("LAN_PAGE_3", "Vous devez au préalable vous <a href='login.php'>connecter</a>, voire <a href='signup.php'>créer un compte</a>.<br>Merci.");
define("LAN_PAGE_4", "Évaluer cette page");
define("LAN_PAGE_5", "Merci d'avoir évaluer cette page.");
define("LAN_PAGE_6", "Vous n'avez pas la permission d'accéder à cette page.");
define("LAN_PAGE_7", "Mot de passe incorrect");
define("LAN_PAGE_8", "Page protégée par un mot de passe");
define("LAN_PAGE_9", "Mot de passe");
define("LAN_PAGE_10", "Proposer");
define("LAN_PAGE_11", "Liste des pages");
define("LAN_PAGE_12", "Page à accès réservé");
define("LAN_PAGE_13", "Page");


?>