/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_handlers/tiny_mce/plugins/emoticons/langs/fr.js,v $
 * $Revision: 1.4 $
 * $Date: 2008/06/16 13:04:58 $
 * $Author: marj_nl_fr $
 */

tinyMCELang['lang_insert_emoticons_title'] = 'Insérer une émoticône';
tinyMCELang['lang_emoticons_desc'] = 'Emoticônes';
