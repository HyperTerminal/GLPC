<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_handlers/phpmailer/language/phpmailer.lang-fr.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/08/02 20:56:05 $
 * $Author: marj_nl_fr $
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG['provide_address']      = 'Vous devez proposer au moins une adresse email.';
$PHPMAILER_LANG['mailer_not_supported'] = ' mailer non supporté.';
$PHPMAILER_LANG['execute']              = 'Ne peut pas exécuter: ';
$PHPMAILER_LANG['instantiate']          = 'Ne peut exécuter la fonction mail.';
$PHPMAILER_LANG['authenticate']         = 'Erreur SMTP: identification impossible.';
$PHPMAILER_LANG['from_failed']          = 'L\'adresse <q>De</q> est manquante: ';
$PHPMAILER_LANG['recipients_failed']    = 'Erreur SMTP: les entêtes suivants manquent: ';
$PHPMAILER_LANG['data_not_accepted']    = 'Erreur SMTP: code non accepté.';
$PHPMAILER_LANG['connect_host']         = 'Erreur SMTP: connexion impossible au serveur SMTP.';
$PHPMAILER_LANG['file_access']          = 'Impossible d\'accéder au fichier: ';
$PHPMAILER_LANG['file_open']            = 'Erreur fichier: impossible d\'ouvrir le fichier: ';
$PHPMAILER_LANG['encoding']             = 'Encodage inconnu: ';
$PHPMAILER_LANG['signing']              = 'Erreur de chiffrement: ';