<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/content/languages/French/lan_content_frontpage.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/18 23:01:46 $
 * $Author: marj_nl_fr $
 */

define('CONT_FP_1', 'Catégorie de contenu');
define('CONT_FP_2', 'page principale');
