<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/content/languages/French/lan_content_search.php,v $
 * $Revision: 1.5 $
 * $Date: 2008/06/18 23:01:46 $
 * $Author: marj_nl_fr $
 */

define('CONT_SCH_LAN_1', 'Contenus');
define('CONT_SCH_LAN_2', 'Toutes les catégories de contenu');
define('CONT_SCH_LAN_3', 'Posté en réponse à l\'item');
define('CONT_SCH_LAN_4', 'dans');
