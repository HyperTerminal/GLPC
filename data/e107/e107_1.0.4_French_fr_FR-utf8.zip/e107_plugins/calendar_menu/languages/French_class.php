<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/French_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/15 11:33:56 $
|        $Author: OTroccaz $
+---------------------------------------------------------------+
*/

define("EC_LAN_RECUR_00", "non");
define("EC_LAN_RECUR_01", "annuel");
define("EC_LAN_RECUR_02", "semestriel");
define("EC_LAN_RECUR_03", "trimestriel");
define("EC_LAN_RECUR_04", "mensuel");
define("EC_LAN_RECUR_05", "toutes les quatre semaines");
define("EC_LAN_RECUR_06", "bimensuel");
define("EC_LAN_RECUR_07", "hebdoamdaire");
define("EC_LAN_RECUR_08", "journalier");
define("EC_LAN_RECUR_100", "Dimanche dans le mois");
define("EC_LAN_RECUR_101", "Lundi dans le mois");
define("EC_LAN_RECUR_102", "Mardi dans le mois");
define("EC_LAN_RECUR_103", "Mercredi dans le mois");
define("EC_LAN_RECUR_104", "Jeudi dans le mois");
define("EC_LAN_RECUR_105", "Vendredi dans le mois");
define("EC_LAN_RECUR_106", "Samedi dans le mois");
define("EC_LAN_RECUR_1100", "Premier");
define("EC_LAN_RECUR_1200", "Second");
define("EC_LAN_RECUR_1300", "Troisième");
define("EC_LAN_RECUR_1400", "Quatrième");
define("NT_LAN_EC_1", "Evènement du calendrier des évènements");
define("NT_LAN_EC_2", "Evènement mis à jour");
define("NT_LAN_EC_3", "Mis à jour par");
define("NT_LAN_EC_4", "Adresse IP");
define("NT_LAN_EC_5", "Message");
define("NT_LAN_EC_6", "Calendrier des évènements - Evénement ajouté");
define("NT_LAN_EC_7", "Nouvel évènement envoyé");
define("NT_LAN_EC_8", "Calendrier des évènements - Evénement modifié");
define("EC_ADM_01", "Calendrier des évènements - Ajouter un événement");
define("EC_ADM_02", "Calendrier des évènements - Modifier un événement");
define("EC_ADM_03", "Calendrier des évènements - Supprimer un événement");
define("EC_ADM_04", "Calendrier des événements - Suppression en bloc");
define("EC_ADM_05", "Calendrier des événements - Ajout multiple");
define("EC_ADM_06", "Calendrier des événements - Options principales modifiées");
define("EC_ADM_07", "Calendrier des événements - Options FE modifiées");
define("EC_ADM_08", "Calendrier des événements - Catégorie ajoutée");
define("EC_ADM_09", "Calendrier des événements - Catégorie modifiée");
define("EC_ADM_10", "Calendrier des événements - Catégorie supprimée");
define("EC_ADM_11", "Calendrier des événements - Anciens évènements supprimés");


?>