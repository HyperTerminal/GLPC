<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/online/languages/ et constantes renommées
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/online_extended_menu/languages/French.php,v $
 * $Revision: 1.12 $
 * $Date: 2008/07/14 20:47:35 $
 * $Author: marj_nl_fr $
 */
define("ONLINE_L1", "Invités :");
define("ONLINE_L2", "Membres :");
define("ONLINE_L3", "Sur cette page :");
define("ONLINE_L4", "En ligne");
define("ONLINE_L5", "Membres");
define("ONLINE_L6", "Nouveau");
define("TRACKING_MESSAGE", "Le suivi en ligne des utilisateurs est actuellement désactivé. S\'il vous plaît, activez-le [link=".e_ADMIN."users.php?options]here[/link][br]");


?>