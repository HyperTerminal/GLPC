<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/tree_menu/languages/French.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/07/26 21:16:00 $
 * $Author: marj_nl_fr $
 */

define('TREE_L1', 'Configurer le Tree Menu');
define('TREE_L2', 'Mettre les paramètres du Tree Menu à jour');
define('TREE_L3', 'Configuration du Tree Menu sauvegardée.');
define('TREE_L4', 'Activé');
define('TREE_L5', 'Désactivé');
define('TREE_L6', 'Classe CSS à utiliser pour les liens non ouvrables');
define('TREE_L7', 'Classe CSS à utiliser pour les liens ouvrables');
define('TREE_L8', 'Classe CSS à utiliser pour les liens ouverts');
define('TREE_L9', 'Utiliser la classe <q>spacer</q> entre les liens principaux');
