<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/siteinfo_menu/languages/
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/counter_menu/languages/French.php,v $
 * $Revision: 1.10 $
 * $Date: 2008/07/26 21:15:53 $
 * $Author: marj_nl_fr $
 */
define("COUNTER_L1", "Les visites de l\'admin ne sont pas comptées");
define("COUNTER_L2", "Cette page aujourd\'hui…");
define("COUNTER_L3", "total");
define("COUNTER_L4", "Depuis toujours…");
define("COUNTER_L5", "unique");
define("COUNTER_L6", "Site…");
define("COUNTER_L7", "Compteur");
define("COUNTER_L8", "Admin message: <b> Les stats d'enregistrement est désactivé. </b> <br /> Pour activer ce système, vous devez installer le plugin Statistic Logging à partir de votre <a href='".e_ADMIN."plugin.php'>gestionnaire de plugin</a>, puis l'activer à partir du <a href='".e_PLUGIN."log/admin_config.php'> écran de configuration </a>.");


?>