<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/trackback/languages/French.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/06/16 13:05:07 $
 * $Author: marj_nl_fr $
 */

define('TRACKBACK_L1', 'Configurer les Trackbacks');
define('TRACKBACK_L2', 'Ce plugin vous permet d\'utiliser des trackbacks (liens croisés) dans les publications de vos news.');
define('TRACKBACK_L3', 'Trackback est maintenant installé et activé.');
define('TRACKBACK_L4', 'Paramètres des trackbacks  sauvegardés.');
define('TRACKBACK_L5', 'Activer');
define('TRACKBACK_L6', 'Désactiver');
define('TRACKBACK_L7', 'Activer les trackbacks');
define('TRACKBACK_L8', 'Texte URL dans le trackback');
define('TRACKBACK_L9', 'Sauvegarder les paramètres');
define('TRACKBACK_L10', 'Paramètres des trackback');
define('TRACKBACK_L11', 'Adresse de trackback pour ce message:');
define('TRACKBACK_L12', 'Pas de trackback pour cette news');
define('TRACKBACK_L13', 'Modérer les trackbacks');
define('TRACKBACK_L14', 'Supprimer');
define('TRACKBACK_L15', 'Trackback supprimé.');
