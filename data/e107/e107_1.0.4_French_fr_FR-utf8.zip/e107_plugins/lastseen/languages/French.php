<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/online/languages/ et constantes renommées
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/lastseen/languages/French.php,v $
 * $Revision: 1.5 $
 * $Date: 2008/06/16 13:05:04 $
 * $Author: marj_nl_fr $
 */

define('LSP_LAN_1', 'Vu récemment');
