<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/user_menu/languages/
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/userlanguage_menu/languages/French.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/06/16 13:05:07 $
 * $Author: marj_nl_fr $
 */

define('UTHEME_MENU_L1', 'Choisir la langue');
define('UTHEME_MENU_L2', 'Sélectionner la langue');
define('UTHEME_MENU_L3', 'tables');
