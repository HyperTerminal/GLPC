<?php 
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/online/languages/ et constantes renommées
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/online_extended_menu/languages/French.php,v $
 * $Revision: 1.12 $
 * $Date: 2008/07/14 20:47:35 $
 * $Author: marj_nl_fr $
 */

define('ONLINE_EL1', 'Visiteurs: ');
define('ONLINE_EL2', 'Membres: ');
define('ONLINE_EL3', 'Sur cette page: ');
define('ONLINE_EL4', 'En ligne');
define('ONLINE_EL5', 'Membres');
define('ONLINE_EL6', 'Dernier membre');
define('ONLINE_EL7', 'sur');
define('ONLINE_EL8', 'Record:');
define('ONLINE_EL9', 'le');
define('ONLINE_TRACKING_MESSAGE', 'Le traceur d\'utilisateur en ligne est en ce moment désactivé. Activez le [link='.e_ADMIN.'users.php?options]ici[/link][br]');
