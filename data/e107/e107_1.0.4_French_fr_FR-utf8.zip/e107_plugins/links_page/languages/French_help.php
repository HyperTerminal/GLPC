<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|		Links plugin - help language file
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_handlers/db_debug_class.php $
|     $Revision: 11678 $
|     $Id: db_debug_class.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/


define("LAN_ADMIN_HELP_0", "Lien de la page de zone d\'aide");

define("LAN_ADMIN_HELP_1", "<i>la page des catégories pour gérer les liens affiche toutes les catégories présentes..</i><br /><br /><b>liste détaillée</b><br />Vous voyez une liste de toutes les catégories avec leur icône, le nom et la description, les options et les options de tri. <br /> <br /><b>explication des icônes</b><br />
".LINK_ICON_LINK." : lien vers la catégorie<br /><br />
".LINK_ICON_EDIT." : éditer la catégorie<br /><br />
".LINK_ICON_DELETE." : supprimer la catégorie<br /><br />
".LINK_ICON_ORDER_UP." : le bouton haut vous permet de déplacer l\'élément de catégorie un cran en haut dans l\'ordre.<br /><br />
".LINK_ICON_ORDER_DOWN." : le bouton bas vous permet de déplacer l\'élément de catégorie un cran en bas dans l\'ordre.<br />
<br />
<b>ordre</b><br />ici, vous pouvez arranger manuellement l\'ordre de toutes les catégories. Vous devez changer les valeurs dans les cases correspondantes selon votre ordre, et cliquez sur le bouton de réorganisation ci-dessous pour sauvegarder le nouvel ordre.<br />");

define("LAN_ADMIN_HELP_2", "<i>la page de création de catégories de lien vous permet d'ajouter de nouvelles catégories </i> <br /> <br /> Vous pouvez télécharger une nouvelle icône, et, après le transfert, attribuer l'icône à la catégorie.");
define("LAN_ADMIN_HELP_3", "<i>la page de gestion des liens montre d\'abord toutes les catégories.</i><br /><br />".LINK_ICON_LINK." : lien vers la catégorie<br /><br />".LINK_ICON_EDIT." : cliquez sur l'icône pour afficher tous les liens dans cette catégorie<br />");
define("LAN_ADMIN_HELP_4", "<i>la page de création de liens vous permet d\'ajouter un nouveau lien</i><br /><br />Vous pouvez télécharger une nouvelle icône, et, après le transfert, attribuer l\'icône au lien.<br /><br />le type ouvert vous permet de définir comment le lien sera ouvert quand un utilisateur clique dessus.");
define("LAN_ADMIN_HELP_5", "<i>la page des liens soumis montre tous les liens soumis par les utilisateurs</i><br /><br /><b>liste détaillée</b><br />Vous voyez l\'url du lien, le nom de l\'utilisateur qui a soumis le lien et les options.<br /><br /><b>explication des icônes</b><br />
".LINK_ICON_EDIT." : envoyer le lien soumis au formulaire de création de liens<br /><br />
".LINK_ICON_DELETE." : supprimer le lien soumis<br />
");
define("LAN_ADMIN_HELP_6", "<i>la page d\'options vous permet de modifier le comportement du plugin links_page</i><br /><br />
options générales<br />
ces options sont généralement utilisées dans les pages de liens.<br /><br />
gestionnaires de lien personnel<br />
les gestionnaires de lien personnel sont pour les utilisateurs privilégiés qui peuvent organiser leurs propres liens personnels ajoutés.<br /><br />
page catégorie<br />
ici vous vouvez changer les options de la page catégorie.<br /><br />
page des liens<br />
Ces options servent sur les pages de liens.<br /><br />
page référencement<br />
Ces options servent sur le top référencement page de liens.<br /><br />
page évaluation<br />
Ces options servent sur la top évaluation page de liens.<br />
");

define("LAN_ADMIN_HELP_7", "<i>la page d\'édition des catégories de lien vous permet d\'éditer une catégorie existante</i><br /><br />Vous pouvez télécharger une nouvelle icône, et, après le transfert, attribuer l\'icône à la catégorie.<br />Vous pouvez mettre à jour l'horodatage de la liaison en cochant la case.");

define("LAN_ADMIN_HELP_8", "<i>cette page montre tous les liens existant dans la catégorie choisie.</i><br /><br /><b>liste détaillée</b><br />Vous voyez une liste de tous les liens avec leur image, le nom, les options et les options de tri.<br /><br /><b>explication des icônes</b><br />
".LINK_ICON_LINK." : lien vers le site internet<br /><br />
".LINK_ICON_EDIT." : editer le lien<br /><br />
".LINK_ICON_DELETE." : supprimer le lien<br /><br />
".LINK_ICON_ORDER_UP." : le bouton haut vous permet de déplacer un lien un cran en haut dans l\'ordre.<br /><br />
".LINK_ICON_ORDER_DOWN." : le bouton bas vous permet de déplacer un lien un cran en bas dans l\'ordre.<br />
<br />
<b>order</b><br />ici vous pouvez arranger manuellement l\'ordre de tous les liens. Vous devez changer les valeurs dans les cases correspondantes selon votre ordre, et cliquez sur le bouton de réorganisation ci-dessous pour sauvegarder le nouvel ordre.<br />");

define("LAN_ADMIN_HELP_9", "<i>la page d\'édition de lien vous permet d\'éditer un lien existant</i><br /><br />Vous pouvez télécharger une nouvelle icône, et, après le transfert, attribuer l\'icône au lien.<br /><br />le type ouvert vous permet de définir comment le lien sera ouvert quand un utilisateur clique dessus.");
define("LAN_ADMIN_HELP_10", "<i>la page de soumission de lien vous permet d\'ajouter un lien soumis aux liens existants</i><br /><br />Un petit texte soumis est ajouté au champ description.<br /><br />Vous pouvez télécharger une nouvelle icône, et, après le transfert, attribuer l\'icône au lien.<br /><br />le type ouvert vous permet de définir comment le lien sera ouvert quand un utilisateur clique dessus.");
?>