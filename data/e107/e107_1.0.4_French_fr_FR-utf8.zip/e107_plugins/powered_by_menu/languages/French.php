<?php
/*
+---------------------------------------------------------------+
|        e107 website system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/powered_by_menu/languages/French.php $
|        $Revision: 1.0 $
|        $Id: 2011/04/12 17:44:17 $
|        $Author: OTroccaz $
+---------------------------------------------------------------+
*/

define("POWEREDBY_L1", "Généré par");


?>