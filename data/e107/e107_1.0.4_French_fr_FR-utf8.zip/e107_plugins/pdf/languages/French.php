<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/pdf/languages/French.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/06/16 13:05:06 $
 * $Author: marj_nl_fr $
 */

define('PDF_PLUGIN_LAN_1', 'PDF');
define('PDF_PLUGIN_LAN_2', 'Aide création PDF');
define('PDF_PLUGIN_LAN_3', 'PDF');
define('PDF_PLUGIN_LAN_4', 'Ce plugin est maintenant prêt à être utilisé.');

define('PDF_LAN_1', 'PDF');
define('PDF_LAN_2', 'Préférences PDF');
define('PDF_LAN_3', 'Activé');
define('PDF_LAN_4', 'Désactivé');
define('PDF_LAN_5', 'Marge gauche de la page');
define('PDF_LAN_6', 'Marge droite de la page');
define('PDF_LAN_7', 'Marge en haut de la page');
define('PDF_LAN_8', 'Police');
define('PDF_LAN_9', 'Taille de la police par défaut');
define('PDF_LAN_10', 'Taille de la police du nom du site');
define('PDF_LAN_11', 'Taille de la police de l\'URL de la page');
define('PDF_LAN_12', 'Taille de la police du numéro de la page');
define('PDF_LAN_13', 'Afficher le logo dans le PDF?');
define('PDF_LAN_14', 'Afficher le nom du site dans le PDF?');
define('PDF_LAN_15', 'Afficher l\'URL de la page originelle dans le PDF?');
define('PDF_LAN_16', 'Afficher le numéro de page dans le PDF?');
define('PDF_LAN_17', 'Mettre à jour');
define('PDF_LAN_18', 'Préférences PDF mises à jour avec succès');
define('PDF_LAN_19', 'Page');
define('PDF_LAN_20', 'Signaler les erreurs');
