<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/clock_menu/languages/French.php,v $
 * $Revision: 1.6 $
 * $Date: 2008/06/16 13:05:00 $
 * $Author: marj_nl_fr $
 */

define('CLOCK_MENU_L1', 'Configuration du menu Horloge mise à jour');
define('CLOCK_MENU_L2', 'Légende');
define('CLOCK_MENU_L3', 'Mise à jour des paramètres du menu Horloge');
define('CLOCK_MENU_L4', 'Configuration du menu Horloge');

define('CLOCK_MENU_L5', 'Lundi');
define('CLOCK_MENU_L6', 'Mardi');
define('CLOCK_MENU_L7', 'Mercredi');
define('CLOCK_MENU_L8', 'Jeudi');
define('CLOCK_MENU_L9', 'Vendredi');
define('CLOCK_MENU_L10', 'Samedi');
define('CLOCK_MENU_L11', 'Dimanche');

define('CLOCK_MENU_L12', 'Janvier');
define('CLOCK_MENU_L13', 'Février');
define('CLOCK_MENU_L14', 'Mars');
define('CLOCK_MENU_L15', 'Avril');
define('CLOCK_MENU_L16', 'Mai');
define('CLOCK_MENU_L17', 'Juin');
define('CLOCK_MENU_L18', 'Juillet');
define('CLOCK_MENU_L19', 'Août');
define('CLOCK_MENU_L20', 'Septembre');
define('CLOCK_MENU_L21', 'Octobre');
define('CLOCK_MENU_L22', 'Novembre');
define('CLOCK_MENU_L23', 'Décembre');
//define('CLOCK_MENU_L24', '');
