<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/comment_menu/languages/French.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/06/16 13:05:00 $
 * $Author: marj_nl_fr $
 */

define('CM_L1', 'Pas de commentaires.');
define('CM_L2', '');
define('CM_L3', 'Légende');
define('CM_L4', 'Nombre de commentaires à afficher?');
define('CM_L5', 'Nombre de caractères à afficher?');
define('CM_L6', 'Suffixe pour des commentaires trop longs?');
define('CM_L7', 'Afficher le titre original de news dans le menu?');
define('CM_L8', 'Configuration du menu Nouveaux Commentaires');
define('CM_L9', 'Mis à jour des paramètres du menu');
define('CM_L10', 'Configuration du menu Nouveaux Commentaires sauvegardée');
define('CM_L11', 'le');
define('CM_L12', 'Ré.:');
define('CM_L13', 'Posté par');
