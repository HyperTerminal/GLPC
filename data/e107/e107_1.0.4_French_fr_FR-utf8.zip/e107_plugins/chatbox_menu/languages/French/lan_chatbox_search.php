<?php
/*
+---------------------------------------------------------------+
|        e107 website system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/French/lan_chatbox_search.php $
|        $Revision: 1.0 $
|        $Id: 2011/04/12 18:04:01 $
|        $Author: OTroccaz $
+---------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "Chatbox");


?>