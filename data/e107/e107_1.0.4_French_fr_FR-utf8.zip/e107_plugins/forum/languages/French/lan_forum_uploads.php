<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/forum/languages/French/lan_forum_uploads.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/06/17 21:49:30 $
 * $Author: marj_nl_fr $
 */

define('PAGE_NAME', 'FICHIERS uploadés du forum');

define('FRMUP_1','Fichiers uploadés sur le forum');
define('FRMUP_2','Fichier supprimé');
define('FRMUP_3','Erreur: Impossible de supprimé le fichier');
define('FRMUP_4','Suppression du fichier');
define('FRMUP_5','Nom du fichier');
define('FRMUP_6','Résultat');
define('FRMUP_7','Trouvé dans le sujet');
define('FRMUP_8','Non trouvé');
define('FRMUP_9','Aucun fichier uploadé');
define('FRMUP_10','Supprimer');
