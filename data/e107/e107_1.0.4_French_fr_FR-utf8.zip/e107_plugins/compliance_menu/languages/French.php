<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/siteinfo_menu/languages/
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/compliance_menu/languages/French.php,v $
 * $Revision: 1.5 $
 * $Date: 2008/06/16 13:05:00 $
 * $Author: marj_nl_fr $
 */

define('COMPLIANCE_L1', 'Compatibilité W3C');
