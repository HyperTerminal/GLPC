<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7.11
 * à supprimer en 0.8
 * déplacé en e107_plugins/user_menu/languages/ et constantes renommées
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/usertheme_menu/languages/French.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/10/06 09:21:23 $
 * $Author: marj_nl_fr $
 */

define('LAN_UMENU_THEME_1', 'Sélectionner un thème');
define('LAN_UMENU_THEME_2', 'Choisir le thème');
define('LAN_UMENU_THEME_3', 'utilisateurs:');
define('LAN_UMENU_THEME_4', 'Autoriser le choix utilisateur parmi ces thèmes');
define('LAN_UMENU_THEME_5', 'Actualiser');
define('LAN_UMENU_THEME_6', 'Thèmes disponibles pour les utilisateurs');
define('LAN_UMENU_THEME_7', 'Groupe pouvant changer son thème');
