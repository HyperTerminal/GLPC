<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/newsfeed/languages/French_frontpage.php,v $
 * $Revision: 1.7 $
 * $Date: 2008/06/16 13:05:05 $
 * $Author: marj_nl_fr $
 */

define('NWSF_FP_1', 'Fils d\'information');
define('NWSF_FP_2', 'Page principale');
