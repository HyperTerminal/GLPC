<?php
/*
+---------------------------------------------------------------+
|        e107 website system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/search_menu/languages/French.php $
|        $Revision: 1.0 $
|        $Id: 2011/04/12 17:44:51 $
|        $Author: OTroccaz $
+---------------------------------------------------------------+
*/

define("LAN_180", "Recherche");


?>