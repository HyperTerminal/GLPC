<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.7
 * uniquement compatible 0.7.11 - retiré de la v0.8
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/alt_auth/languages/French/lan_otherdb_auth.php,v $
 * $Revision: 1.3 $
 * $Date: 2008/09/30 20:35:21 $
 * $Author: marj_nl_fr $
 */

define('OTHERDB_LAN_1', 'Type de base de données:');
define('OTHERDB_LAN_2', 'Serveur:');
define('OTHERDB_LAN_3', 'Nom d\'utilisateur:');
define('OTHERDB_LAN_4', 'Mot de passe:');
define('OTHERDB_LAN_5', 'Base de données');
define('OTHERDB_LAN_6', 'Table');
define('OTHERDB_LAN_7', 'Champ du nom d\'utilisateur:');
define('OTHERDB_LAN_8', 'Champ du mot de passe:');
define('OTHERDB_LAN_9', 'Méthode de mot de passe:');
define('OTHERDB_LAN_10', 'Configurer l\'authentification pour d\'autres bases de données');
define('OTHERDB_LAN_11', '** Les champs suivant ne sont pas requis si vous utilisez une base de données e107');
