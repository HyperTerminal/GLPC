<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_plugins/alt_auth/languages/French/lan_alt_auth_conf.php,v $
 * $Revision: 1.8 $
 * $Date: 2008/09/30 20:35:21 $
 * $Author: marj_nl_fr $
 */
define("LAN_ALT_2", "Mettre les paramètres à jour");
define("LAN_ALT_3", "Choisir un autre type d\'identification");
define("LAN_ALT_4", "Configurer les paramètres pour");
define("LAN_ALT_5", "Configurer les paramètres d\'identification");
define("LAN_ALT_6", "Action si échec de connexion");
define("LAN_ALT_7", "Que doit-il se passer si la connexion échoue en employant la méthode alternative?");
define("LAN_ALT_8", "Action si l\'utilisateur n\'est pas trouvé");
define("LAN_ALT_9", "Que doit-il se passer si le nom d\'utilisateur (username) n\'est pas trouvé en employant la méthode alternative?");
define("LAN_ALT_10", "champ du nom de connexion");
define("LAN_ALT_11", "champ du mot de passe");
define("LAN_ALT_PAGE", "Authentification alternative");


?>