<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_themes/human_condition/languages/French.php,v $
 * $Revision: 1.9 $
 * $Date: 2009/02/02 22:01:06 $
 * $Author: marj_nl_fr $
 */

define('LAN_THEME_1', 'Les commentaires sont désactivés pour cet item.');
define('LAN_THEME_2', 'Lire/poster un commentaire :');
define('LAN_THEME_3', 'Lire al suite ...');
define('LAN_THEME_4', 'Trackbacks :');
define('LAN_THEME_5', 'Posté apr ');
define('LAN_THEME_6', 'le ');
