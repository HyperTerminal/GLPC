<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system French Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/core/languages/French.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/02 11:23:32 $
|        $Author: Olivier Troccaz $
+---------------------------------------------------------------+
*/
define("LAN_THEME_1", "e107 core thème par <a href='http://e107.org' title='e107 CMS' rel='external'>e107 Inc.</a>");
define("LAN_THEME_2", "Commentaires :");
define("LAN_THEME_3", "Les commentaires sont désactivés pour cet article");
define("LAN_THEME_4", "Lisez l'article complet");
define("LAN_THEME_5", "Rétroliens :");
define("LAN_THEME_8", "dans");
define("LAN_THEME_9", "par");
define("LAN_THEME_11", "Dernières nouvelles");
define("LAN_THEME_12", "Envoyer par mail à un ami");
define("LAN_THEME_13", "Créer un fichier PDF");
define("LAN_THEME_14", "Imprimer");
define("LAN_THEME_15", "Editer");
define("LAN_THEME_17", "Login");
define("LAN_THEME_18", "Nom d'utilisateur");
define("LAN_THEME_19", "Mot de passe");
define("LAN_THEME_20", "Enregistrez-vous");
define("LAN_THEME_21", "Login");
define("LAN_THEME_22", "Mot de passe oublié ?");
define("LAN_THEME_23", "Bienvenue");
define("LAN_THEME_24", "Administrateur");
define("LAN_THEME_26", "Paramètres");
define("LAN_THEME_27", "Profil");
define("LAN_THEME_28", "Déconnexion");
define("LAN_THEME_29", "Nouvelle liste");
define("LAN_THEME_SING", "Login");
define("LAN_THEME_REG", "Enregistrez-vous");
define("LAN_SEARCH", "Rechercher");
define("LAN_SEARCH_SUB", "Aller");
define("LAN_THEME_SHARE", "Partager ceci");
define("LAN_THEME_VER", "e107 v.");
define("CM_L13", "par");


?>