<?php
/**
 * Fichiers utf-8 français pour le CMS e107 version 0.8 α
 * accessoirement compatible 0.7.11
 * Licence GNU/GPL
 * Traducteurs: communauté française e107 http://etalkers.tuxfamily.org/
 *
 * $Source: /cvsroot/touchatou/e107_french/e107_themes/human_condition/languages/French.php,v $
 * $Revision: 1.9 $
 * $Date: 2009/02/02 22:01:06 $
 * $Author: marj_nl_fr $
 */

define('LAN_THEME_1', '“Human Condition” par <a href="http://e107.org/" rel="external">jalist</a>, basé sur le thème Wordpress, <a href="http://wordpress.org/" rel="external">http://wordpress.org</a>.');
define('LAN_THEME_2', 'Commentaires désactivés');
define('LAN_THEME_3', 'Commentaire(s): ');
define('LAN_THEME_4', 'Suite…');
define('LAN_THEME_5', 'Trackbacks: ');
define('LAN_THEME_6', 'Commentaire par');
