<?php










define("RATELAN_0","投票");
define("RATELAN_1","投票");
define("RATELAN_2","您要參與投票嗎?");
define("RATELAN_3","感謝您的投票");
define("RATELAN_4","尚未投票");
define("RATELAN_5","投票");

?>