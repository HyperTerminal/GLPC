<?php









define("LAN_GUEST","訪客");
define("LAN_WROTE","發表");//asinJohnwrote.."";
?>