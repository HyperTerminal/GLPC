<?php

define("PAGE_NAME","僅限於會員");
define("LAN_MEMBERS_0","認證區域");
define("LAN_MEMBERS_1","這是一個認證區域");
define("LAN_MEMBERS_2","僅接受會員<ahref=".e_LOGIN.">登入</a>");
define("LAN_MEMBERS_3","或<ahref='".e_SIGNUP."'>註冊</a>會員");
define("LAN_MEMBERS_4","點選返回首頁");

?>