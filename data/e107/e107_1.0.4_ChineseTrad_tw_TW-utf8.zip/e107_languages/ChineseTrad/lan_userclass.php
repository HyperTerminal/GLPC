<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/lan_userclass.php $
|        $Revision: 1.0 $
|        $Id: 2012/08/02 22:20:58 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("UC_LAN_0", "每個人(公開)");
define("UC_LAN_1", "訪客");
define("UC_LAN_2", "沒有人(尚未啟動)");
define("UC_LAN_3", "會員");
define("UC_LAN_4", "僅供閱讀");
define("UC_LAN_5", "管理員");
define("UC_LAN_6", "站長");
define("UC_LAN_9", "新來的使用者");
define("UC_LAN_10", "Search Bots");


?>