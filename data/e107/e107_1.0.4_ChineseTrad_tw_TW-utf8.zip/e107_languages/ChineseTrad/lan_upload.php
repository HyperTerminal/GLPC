<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/lan_upload.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/19 14:05:35 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "上傳");
define("LAN_UL_001", "無效的電子信箱");
define("LAN_UL_002", "您沒有此伺服器的上傳權限.");
define("LAN_UL_020", "錯誤");
define("LAN_UL_021", "上傳失敗");
define("LAN_UL_032", "您必須選擇一個分類");
define("LAN_UL_033", "您必須輸入一個電子信箱");
define("LAN_UL_034", "您必須選擇一個檔案名稱");
define("LAN_UL_035", "您必須提供檔案相關介紹");
define("LAN_UL_036", "您必須提供檔案上傳");
define("LAN_UL_037", "您必須選擇分類");
define("LAN_UL_038", "");
define("LAN_61", "您的名稱:");
define("LAN_112", "電子信箱:");
define("LAN_144", "網站網址:");
define("LAN_402", "您必須為註冊會員才可以上傳.");
define("LAN_404", "感謝您.您的上傳將會給管理員檢查發表於網站上.");
define("LAN_406", "請注意");
define("LAN_407", "任何其他類型的檔案上傳將被刪除.");
define("LAN_408", "底線");
define("LAN_409", "檔案名稱");
define("LAN_410", "版本");
define("LAN_411", "檔案");
define("LAN_412", "預覽圖");
define("LAN_413", "描述");
define("LAN_414", "執行範例");
define("LAN_415", "輸入範例網站連結");
define("LAN_416", "送出並上傳");
define("LAN_417", "上傳檔案");
define("LAN_418", "最大檔案限制:");
define("DOWLAN_11", "分區");
define("LAN_419", "允許檔案格式");
define("LAN_420", "欄位為必填項目");


?>