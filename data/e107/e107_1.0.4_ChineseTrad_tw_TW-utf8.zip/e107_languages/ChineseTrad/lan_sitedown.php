<?php









define("PAGE_NAME","網站暫時關閉");
define("LAN_SITEDOWN_00","暫時關閉");
define("LAN_SITEDOWN_01","我們暫時關閉網站做部份維修更新.這不會花太多時間-請稍後回來確認,很抱歉照成您的不便.");
?>