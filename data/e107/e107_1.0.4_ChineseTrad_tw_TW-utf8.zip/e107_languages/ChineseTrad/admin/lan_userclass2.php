<?php

define("UCSLAN_1","清除所有該等級的會員.");
define("UCSLAN_2","該等級會員已更新.");
define("UCSLAN_3","該等級已刪除.");
define("UCSLAN_4","請點選確認盒以便於刪除該會員等級");
define("UCSLAN_5","已更新等級.");
define("UCSLAN_6","該等級已儲存於資料庫.");
define("UCSLAN_7","目前沒有會員等級.");
define("UCSLAN_8","已存在的等級");
define("UCSLAN_11","點選確認");
define("UCSLAN_12","等級名稱");
define("UCSLAN_13","等級描述");
define("UCSLAN_14","更新會員等級");
define("UCSLAN_15","新增等級");
define("UCSLAN_16","分配會員到該等級");
define("UCSLAN_17","移除");
define("UCSLAN_18","清除等級");
define("UCSLAN_19","分配會員到");
define("UCSLAN_20","等級");
define("UCSLAN_21","會員等級設定");
define("UCSLAN_22","會員-點選移動...");
define("UCSLAN_23","該等級會員...");
define("UCSLAN_24","管理權限");
define("UCSLAN_25","帳號");
define("UCSLAN_26","使用者名稱");
define("UCSLAN_27","返回");


?>