<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/admin/lan_modcomment.php $
|        $Revision: 1.0 $
|        $Id: 2012/08/02 22:23:02 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("MDCLAN_1", "已編輯.");
define("MDCLAN_2", "該項目沒有評論");
define("MDCLAN_3", "會員");
define("MDCLAN_4", "訪客");
define("MDCLAN_5", "取消封鎖");
define("MDCLAN_6", "封鎖");
define("MDCLAN_7", "核淮");
define("MDCLAN_8", "編輯評論");
define("MDCLAN_9", "警告!刪除主要評論將會刪除所有回覆!");
define("MDCLAN_10", "選項");
define("MDCLAN_11", "評論");
define("MDCLAN_12", "評論");
define("MDCLAN_13", "完成封鎖");
define("MDCLAN_14", "鎖住評論");
define("MDCLAN_15", "開啟");
define("MDCLAN_16", "鎖住");
define("MDCLAN_17", "目前尚無任何待確認的核可");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>