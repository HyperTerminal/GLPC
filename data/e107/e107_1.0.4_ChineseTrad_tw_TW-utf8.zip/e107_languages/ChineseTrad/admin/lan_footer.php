<?php
define("FOOTLAN_1","網站名稱");
define("FOOTLAN_2","站長");
define("FOOTLAN_3","採用版本");
define("FOOTLAN_4","建構於");
define("FOOTLAN_5","管理控制台風格");
define("FOOTLAN_6","作者:");
define("FOOTLAN_7","資訊");
define("FOOTLAN_8","安裝日期");
define("FOOTLAN_9","伺服器軟體");
define("FOOTLAN_10","網址");
define("FOOTLAN_11","PHP版本");
define("FOOTLAN_12","MySQL版本");
define("FOOTLAN_13","網站資訊");
define("FOOTLAN_14","網站文件");
define("FOOTLAN_15","文件");
define("FOOTLAN_16","資料庫名稱");
define("FOOTLAN_17","網頁編碼");
define("FOOTLAN_18","網站風格");
define("FOOTLAN_19","目前伺服器時間");
define("FOOTLAN_20","安全等級");


?>