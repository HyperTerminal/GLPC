<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/admin/lan_ugflag.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/19 14:18:24 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("UGFLAN_1", "維護設定已完成更新");
define("UGFLAN_2", "啟動維護暫停公告");
define("UGFLAN_3", "更新維護設定");
define("UGFLAN_4", "休站維護設定");
define("UGFLAN_5", "顯示網站維護原因");
define("UGFLAN_6", "保留空白則顯示預設的訊息");
define("UGFLAN_8", "僅限於管理員進入");
define("UGFLAN_9", "僅限於主要管理員進入");


?>