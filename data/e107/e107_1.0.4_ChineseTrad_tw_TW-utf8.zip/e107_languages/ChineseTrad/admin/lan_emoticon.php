<?php
define("EMOLAN_1","表情圖案啟動");
define("EMOLAN_2","名稱");
define("EMOLAN_3","表情圖片");
define("EMOLAN_4","啟動表情圖案?");

define("EMOLAN_5","圖案");
define("EMOLAN_6","表情圖案編碼");
define("EMOLAN_7","利用空白鍵作間隔");

define("EMOLAN_8","狀態");
define("EMOLAN_9","選項");
define("EMOLAN_10","啟動");
define("EMOLAN_11","啟動包裝'");

define("EMOLAN_12","編輯/設定圖案包");
define("EMOLAN_13","安裝的表情圖案");

define("EMOLAN_14","儲存設定");
define("EMOLAN_15","編輯/設定表情圖案");
define("EMOLAN_16","儲存的表情圖案");
define("EMOLAN_17","您有一個表情圖案設定時包含空白鍵,系統無法接受!");
define("EMOLAN_18","請重新命名下列名單，因為不能包含空白鍵:");
define("EMOLAN_19","圖片檔案名稱");
define("EMOLAN_20","位址");
define("EMOLAN_21","錯誤");
//define("EMOLAN_2","名稱");
define("EMOLAN_22","找到新的表情圖案系列");
define("EMOLAN_23","找到新的表情圖案系列xml檔案:");
define("EMOLAN_24","新的表情圖案系列php檔案:");
define("EMOLAN_25","安裝新的PHP表情圖案:");
define("EMOLAN_26","重新掃描包裝");
define("EMOLAN_27","執行中的包裝發生錯誤:");
define("EMOLAN_28","產生XML");
define("EMOLAN_29","XML新增完成:");
define("EMOLAN_30","寫入XML黨案發生錯誤:");
?>