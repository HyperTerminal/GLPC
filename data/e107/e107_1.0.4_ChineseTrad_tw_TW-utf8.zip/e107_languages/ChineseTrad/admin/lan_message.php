<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/admin/lan_message.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/21 14:59:19 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("MESSLAN_1", "已接收的訊息");
define("MESSLAN_2", "刪除訊息");
define("MESSLAN_3", "已刪除的訊息.");
define("MESSLAN_4", "刪除所有的訊息");
define("MESSLAN_5", "確認");
define("MESSLAN_6", "所有的訊息已刪除。");
define("MESSLAN_7", "沒有訊息。");
define("MESSLAN_8", "訊息類型");
define("MESSLAN_9", "回報於");
define("MESSLAN_10", "已送出的");
define("MESSLAN_11", "開啟於新的視窗");
define("MESSLAN_12", "訊息");
define("MESSLAN_13", "連結");


?>