<?php

define("LAN_CHECK_1","選擇語系檔案比對檢查");
define("LAN_CHECK_2","開始比對檢查");
define("LAN_CHECK_3","比對檢查");
define("LAN_CHECK_4","檔案遺失!");
define("LAN_CHECK_5","語法遺失!");
define("LAN_CHECK_7","語法");
define("LAN_CHECK_8","此檔案遺失...");
define("LAN_CHECK_9","檔案正在遺失...");
define("LAN_CHECK_10","致命的錯誤:");
define("LAN_CHECK_11","沒有檔案遺失!");
define("LAN_CHECK_12","該檔案是錯誤...");
define("LAN_CHECK_13","檔案錯誤...");
define("LAN_CHECK_14","所有存在的檔案是正確的!");
define("LAN_CHECK_15","非法字元找到於'<?php'");
define("LAN_CHECK_16","原始檔案");
define("LAN_CHECK_17","儲存檔案有一個寫入問題造成中斷.");
define("LAN_CHECK_18","目前沒有在外掛/風格中找到語言檔案基本的格式.");
define("LAN_CHECK_19","找到非UTF-8字元!");
define("LAN_CHECK_20","產生語言包。");
define("LAN_CHECK_21","再次確認。");
define("LAN_CHECK_22","佈景主題");
define("LAN_CHECK_23","發現錯誤!");
define("LAN_CHECK_24","摘要");
define("LAN_CHECK_25","佈景主題");
define("LAN_CHECK_26","檔案");


?>