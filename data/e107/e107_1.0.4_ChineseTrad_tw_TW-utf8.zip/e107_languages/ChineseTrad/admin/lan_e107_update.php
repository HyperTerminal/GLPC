<?php

define("LAN_UPDATE_2","行動");
define("LAN_UPDATE_3","尚未需要");

define("LAN_UPDATE_5","有效的更新");
define("LAN_UPDATE_7","已實施");
define("LAN_UPDATE_8","更新於");
define("LAN_UPDATE_9","到");
define("LAN_UPDATE_10","有效的更新");
define("LAN_UPDATE_11","繼續.617到.7更新");
define("LAN_UPDATE_12","您的資料表之一包含相同的項目.");

?>