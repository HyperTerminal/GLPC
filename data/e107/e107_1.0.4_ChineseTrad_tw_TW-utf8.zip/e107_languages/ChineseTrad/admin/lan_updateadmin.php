<?php

define("UDALAN_1","錯誤-請重新送出");
define("UDALAN_2","設定完成更新");
define("UDALAN_3","設定完成更新-");
define("UDALAN_4","管理員名稱");
define("UDALAN_5","管理員密碼");
define("UDALAN_6","重新輸入密碼");
define("UDALAN_7","變更密碼");
define("UDALAN_8","密碼更新-");

?>