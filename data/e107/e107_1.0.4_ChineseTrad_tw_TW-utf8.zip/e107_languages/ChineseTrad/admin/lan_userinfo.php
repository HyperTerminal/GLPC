<?php

define("USFLAN_1","無法找到發表人IP位址-目前沒有相關資訊.");
//define("USFLAN_2","錯誤");
define("USFLAN_3","訊息發表來自於IP");
define("USFLAN_4","主機");
define("USFLAN_5","點選這裡將IP位址轉到控制台封鎖頁面");
define("USFLAN_6","會員ID");
define("USFLAN_7","會員資訊");

?>