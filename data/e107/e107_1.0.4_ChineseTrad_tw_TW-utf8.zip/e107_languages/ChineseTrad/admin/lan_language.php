<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/admin/lan_language.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/06 22:25:04 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LANG_LAN_00", "無法新增.(已存在)");
define("LANG_LAN_01", "已刪除(假如存在)和已新增.");
define("LANG_LAN_02", "無法被刪除");
define("LANG_LAN_03", "資料表");
define("LANG_LAN_05", "尚未安裝");
define("LANG_LAN_06", "新增資料表");
define("LANG_LAN_07", "移除已存在的資料表?");
define("LANG_LAN_08", "替代已存在的資料表(資料將會遺失).");
define("LANG_LAN_10", "確認刪除");
define("LANG_LAN_11", "刪除取消勾選下列資料表(假如他們存在).");
define("LANG_LAN_12", "開啟多重語言資料表");
define("LANG_LAN_13", "多國語言基本設定");
define("LANG_LAN_14", "預設的網站語言");
define("LANG_LAN_15", "勾選複製預設的語言資料.(對友站連結,新聞-分區等等很有幫助)");
define("LANG_LAN_16", "多國語言資料庫使用情形");
define("LANG_LAN_17", "預設語言-沒有必要的附加資料表.");
define("LANG_LAN_18", "使用附加網址來設定語言:");
define("LANG_LAN_19", "例如：.fr.mydomain.com來設定該語言給法語");
define("LANG_LAN_20", "Enteronedomainperline.eg.mydomain.cometc.orleaveblanktodisable.");
define("LANG_LAN_21", "語言輔助翻譯工具");
define("LANG_LAN_23", "新增語系檔案(zip)");
define("LANG_LAN_24", "產生");
define("LANG_LAN_AGR", "注意：使用這些工具代表您願意分享您的語系檔案給e107社群。");
define("LANG_LAN_EML", "請將語言包以電子郵件寄到：");
define("LANG_LAN_25", "請檢查CORE_LC及CORE_LC2在[lcpath]中的值，然後再嘗試一次。");
define("LANG_LAN_26", "請確認您使用的是在e107_config.php中預設的資料夾名稱(例如'e107_languages/','e107_plugins/'等)然後再嘗試一次。");
define("LANG_LAN_27", "請確認您的語言檔('確認')然後再嘗試一次。");
define("LANG_LAN_28", "如果您是[e107certifiedtranslator].請勾選此欄。");
define("LANG_LAN_29", "在提供語言檔案之前，您該校訂剩餘的錯誤。");
define("LANG_LAN_30", "釋出日期：");
define("LANG_LAN_31", "相容性");
define("LANG_LAN_32", "已安裝語言");
define("LANG_LAN_33", "在驗證過程中僅顯示錯誤訊息");
define("LANG_LAN_34", "在要產生語言檔時請確認及更正存在的 [x]錯誤");


?>