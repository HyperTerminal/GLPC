<?php

define("LAN_head_1","管理員導覽");
define("LAN_head_2","您的伺服器不允許HTTP檔案上傳，所以他不會允許您的會員上傳頭像或是檔案.請重新設定php.ini裡的file_upload並重新啟動.如果您沒有權限編輯php.ini請聯絡您的主機商.");
define("LAN_head_3","您的伺服器限制執行於basedir功能.這不允許任何檔案使用在您的home目錄，這將會影響主要的程式執行例如檔案管理員.");
define("LAN_head_4","系統區域");
define("LAN_head_5","系統管理台語系設定:");
define("LAN_head_6","外掛資訊");


?>