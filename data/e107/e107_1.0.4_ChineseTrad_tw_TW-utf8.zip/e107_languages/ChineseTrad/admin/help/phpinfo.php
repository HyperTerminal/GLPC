<?php


if (!defined('e107_INIT')) { exit; }

$text = " 這裡將會顯示您伺服器上的PHP設定. ";
$ns -> tablerender("PHP 資訊說明", $text);
?>