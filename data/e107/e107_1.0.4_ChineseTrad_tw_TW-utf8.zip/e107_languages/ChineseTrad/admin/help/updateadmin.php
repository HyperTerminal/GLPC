<?php

if (!defined('e107_INIT')) { exit; }

$text = "更新您的密碼.";
$ns -> tablerender("更新設定說明", $text);
?>