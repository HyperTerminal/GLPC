<?php


if (!defined('e107_INIT')) { exit; }

$text = "從這邊您可以允許或是不允許會員發表圖片檔案, 以及大小模式和瀏覽上傳頭像.";
$ns -> tablerender("圖片說明", $text);
?>