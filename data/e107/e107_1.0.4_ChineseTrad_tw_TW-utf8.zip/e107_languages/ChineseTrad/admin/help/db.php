<?php

if (!defined('e107_INIT')) { exit; }

$text = "這是允許您管理資料庫的工具.";
$ns -> tablerender("資料庫工具", $text);
?>