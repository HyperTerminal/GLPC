<?php

if (!defined('e107_INIT')) { exit; }

$text = "啟動網站統計登入頁面. 他將會簡短顯示推薦連結的主要的網址, 例如： 'jalist.com' 將會替代 'http://jalist.com/links.php' ";

$ns -> tablerender("登入問題", $text);
?>