<?php

if (!defined('e107_INIT')) { exit; }

$text = "評論是一個類似文章但是他會顯示他自己的選單上.<br />
 多重頁面評論分隔每一頁面使用文字 [newpage], 例如 <br /><code>Test1 [newpage] Test2</code><br /> 將會新增兩個頁面評論於 'Test1' 於頁面 1 和 'Test2' 於頁面 2.";
$ns -> tablerender("評論問題", $text);
?>