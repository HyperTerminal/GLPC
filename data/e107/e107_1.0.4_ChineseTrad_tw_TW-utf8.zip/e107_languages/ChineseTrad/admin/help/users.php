<?php


if (!defined('e107_INIT')) { exit; }

$text = "該頁面您可以編輯註冊會員. 您可以更新他們的設定, 給予管理員統計和設定他們會員等級等等.";
$ns -> tablerender("會員功能說明", $text);
unset($text);
?>