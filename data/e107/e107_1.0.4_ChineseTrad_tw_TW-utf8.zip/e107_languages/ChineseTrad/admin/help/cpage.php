<?php
if (!defined('e107_INIT')) { exit; }

$text = "您可以自訂選單或是頁面內容.<br /><br />
請前往 <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a>將會有詳細的說明.";

$ns -> tablerender('自訂選單頁面說明', $text);
?>