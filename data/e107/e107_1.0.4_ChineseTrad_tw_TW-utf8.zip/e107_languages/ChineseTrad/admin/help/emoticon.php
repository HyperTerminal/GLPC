<?php

if (!defined('e107_INIT')) { exit; }

$text = "表情圖案設定已啟動,基本的表情文字將會被替代為表情圖標.";

$ns -> tablerender("表情圖案說明", $text);
?>