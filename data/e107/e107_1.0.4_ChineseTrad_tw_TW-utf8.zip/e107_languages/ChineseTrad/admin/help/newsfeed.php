<?php

if (!defined('e107_INIT')) { exit; }

$text = "您可以放置其他網站上的 RSS 並顯示於您的網站上.<br />請輸入完整連結(ie http://e107.org/news.xml). 您也可以新增您自己喜歡的圖片取得原有了. 您可以選擇啟動或是關閉啟動.<br /><br />想要觀看您網站上頭條, 請確認 headlines_menu 是啟動的.";

$ns -> tablerender("網站頭條", $text);
?>