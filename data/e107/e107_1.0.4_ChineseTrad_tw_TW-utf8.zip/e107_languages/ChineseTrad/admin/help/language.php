<?php


if (!defined('e107_INIT')) { exit; }

$text = "設定一個新語言將會給你有不同語言版本的網站.";
$ns -> tablerender("語言設定", $text);
?>