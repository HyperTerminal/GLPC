<?php

if (!defined('e107_INIT')) { exit; }

$caption = "會員等級問題";
$text = "您可以新增或編輯/刪除現有的會員等級.<br/>這將會設定私人保會會員於您的特定頁面. 例如： 您可以新增等級名稱 TEST, 然後開啟一個討論區僅限於會員等級於 TEST 等級登入.";
$ns -> tablerender($caption, $text);
?>