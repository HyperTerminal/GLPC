<?php


if (!defined('e107_INIT')) { exit; }

$caption = "首頁設定說明";
$text = "從這邊您可以選擇您的首頁顯示方式, 通常預設的是新聞頁面.";
$ns -> tablerender($caption, $text);
?>