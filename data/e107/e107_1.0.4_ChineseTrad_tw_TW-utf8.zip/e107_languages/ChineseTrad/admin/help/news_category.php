<?php

if (!defined('e107_INIT')) { exit; }

$text = "您可以將您的新聞分配在不同的分區, 並允許訪客顯示僅該分區的新聞. <br /><br />上傳您的新圖標於 ".e_THEME."-yourtheme-/images/ 或 themes/shared/newsicons/.";
$ns -> tablerender("新聞分區說明", $text);
?>