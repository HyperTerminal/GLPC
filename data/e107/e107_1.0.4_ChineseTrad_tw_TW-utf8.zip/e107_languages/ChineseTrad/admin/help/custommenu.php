<?php

if (!defined('e107_INIT')) { exit; }

$text = "您可以從這裡新增自訂選單或是頁面於您的網站上.<br /><br />
請前往 <a href='http://docs.e107.org?Custom Pages'>http://docs.e107.org?Custom Pages</a>";

$ns -> tablerender(CUSLAN_18, $text);
?>