<?php


if (!defined('e107_INIT')) { exit; }

$text = "您輸入任何的Meta標籤將會送到正確的地方.";

$ns -> tablerender("Meta標籤", $text);
?>