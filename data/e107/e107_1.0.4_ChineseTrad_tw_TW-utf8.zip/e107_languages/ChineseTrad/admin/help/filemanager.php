<?php


if (!defined('e107_INIT')) { exit; }

$text = "您可以管理 /files 目錄檔案. 假如有錯誤訊息是有關於權限， 請上傳時變更 CHMOD 該目錄於 777.";
$ns -> tablerender("檔案管理說明", $text);
?>