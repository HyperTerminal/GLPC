<?php

if (!defined('e107_INIT')) { exit; }

$text = "輸入所有的網站連結. 連結將會新增顯示於主要的選單, 如果有其他的連結請使用友站連結外掛.
<br />
";
$ns -> tablerender("連結說明", $text);
?>