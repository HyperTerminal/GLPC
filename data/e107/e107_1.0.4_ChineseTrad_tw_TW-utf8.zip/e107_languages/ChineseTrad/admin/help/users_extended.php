<?php

if (!defined('e107_INIT')) { exit; }

$text = " 延伸會員欄位允許您新增任何類型的資料使會員可以填寫顯示出來的.";
$ns -> tablerender(" 延伸欄位說明", $text);
?>