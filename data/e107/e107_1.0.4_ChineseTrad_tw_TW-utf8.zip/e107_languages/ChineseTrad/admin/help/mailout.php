<?php


if (!defined('e107_INIT')) { exit; }

$text = "使用這個頁面設定您的外部信箱設定. 該設定允許您送信件給您所有的會員.";
$ns -> tablerender("寄信說明", $text);
?>