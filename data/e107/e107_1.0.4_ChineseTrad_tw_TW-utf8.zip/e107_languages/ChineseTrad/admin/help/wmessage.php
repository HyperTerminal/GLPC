<?php

if (!defined('e107_INIT')) { exit; }

$text = "該頁面允許您設定一個訊息再您想要顯示的首頁上方. 您可以設定不同訊息給訪客, 註冊會員和管理員.";
$ns -> tablerender("歡迎訊息說明", $text);
?>
