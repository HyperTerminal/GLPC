<?php

if (!defined('e107_INIT')) { exit; }

$text = "從這裡您可以允許或是不允許會員上傳檔案跟圖片.";
$ns -> tablerender("公開上傳說明", $text);
?>