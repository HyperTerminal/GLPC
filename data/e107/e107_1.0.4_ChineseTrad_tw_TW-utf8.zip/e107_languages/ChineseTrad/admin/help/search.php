<?php

if (!defined('e107_INIT')) { exit; }

$text = "假如您的 MySql 伺服器支援您使用 
 MySql 排列模式（ 該功能比 PHP 排列模式較快）. 請前往基本設定.<br /><br />
如果您的網站有使用象形文字語言例如中文和日文 
您必須使用 PHP sort 排列模式並切換部份字元吻合功能關閉.";

$ns -> tablerender("搜尋說明", $text);
?>