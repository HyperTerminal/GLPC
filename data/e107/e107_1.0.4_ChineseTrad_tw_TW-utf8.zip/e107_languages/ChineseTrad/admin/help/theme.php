<?php
if (!defined('e107_INIT')) { exit; }

$text = "風格管理將會允許您設定網站風格和管理控制台規格.";
$ns -> tablerender("風格管理", $text);
?>