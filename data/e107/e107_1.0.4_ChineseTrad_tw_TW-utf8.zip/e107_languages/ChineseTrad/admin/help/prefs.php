<?php

if (!defined('e107_INIT')) { exit; }

$text = "您的網站最重要的偏好設定 , 網站名稱和描述連續發表保護等設定.";
$ns -> tablerender("偏好設定說明", $text);
?>