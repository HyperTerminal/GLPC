<?php

if (!defined('e107_INIT')) { exit; }

$text = "您可以設定投票或是問卷, 只要輸入標題跟選項, 預覽覺得可以以後請勾選他啟動.<br /><br />
瀏覽投票, 請確認選單頁面和外掛 poll_menu 已經被啟動.";

$ns -> tablerender("投票說明", $text);
?>