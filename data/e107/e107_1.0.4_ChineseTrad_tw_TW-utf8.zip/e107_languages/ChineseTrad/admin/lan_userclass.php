<?php
*








define("UCSLAN_1","寄出通知信件給");
define("UCSLAN_2","權限更新完成");
define("UCSLAN_3","親愛的");
define("UCSLAN_4","您的權限更新於");
define("UCSLAN_5","您可以進入下列的區域");
define("UCSLAN_6","設定會員等級");
define("UCSLAN_7","設定等級");
define("UCSLAN_8","通知會員");
define("UCSLAN_9","等級完成更新.");
define("UCSLAN_10","順心,");
define("UCSLAN_12","僅限於會員權限");


?>