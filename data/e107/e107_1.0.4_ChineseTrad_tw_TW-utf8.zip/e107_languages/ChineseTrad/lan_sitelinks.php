<?php









define("LAN_SITELINKS_183","網站選單");
define("LAN_SITELINKS_502","管理控制台");

?>