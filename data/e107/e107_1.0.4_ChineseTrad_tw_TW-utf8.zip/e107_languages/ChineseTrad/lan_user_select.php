<?php









define("US_LAN_1","選擇會員");
define("US_LAN_2","選擇會員等級");
define("US_LAN_3","所有會員");
define("US_LAN_4","尋找會員");
define("US_LAN_5","找到會員");
define("US_LAN_6","搜尋");
?>