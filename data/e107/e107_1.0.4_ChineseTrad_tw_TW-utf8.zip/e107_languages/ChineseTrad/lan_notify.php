<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/lan_notify.php $
|        $Revision: 1.0 $
|        $Id: 2012/08/02 22:18:40 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("NT_LAN_US_1", "會員註冊");
define("NT_LAN_UV_1", "完成認證會員");
define("NT_LAN_UV_2", "會員ID:");
define("NT_LAN_UV_3", "會員登入名稱:");
define("NT_LAN_UV_4", "會員IP:");
define("NT_LAN_LI_1", "登入完成");
define("NT_LAN_LO_1", "登出完成");
define("NT_LAN_LO_2", "登出網站");
define("NT_LAN_FL_1", "連續發表封鎖");
define("NT_LAN_FL_2", "IP封鎖於連續發表");
define("NT_LAN_SN_1", "完成送出新聞項目");
define("NT_LAN_NU_1", "更新完成");
define("NT_LAN_ND_1", "刪除新聞完成");
define("NT_LAN_ND_2", "完成刪除新聞id");
define("NT_LAN_CM_1", "使用者評論尚待批淮");


?>