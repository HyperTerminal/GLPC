<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/lan_email.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/19 21:50:55 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_EMAIL_1", "寄件人：");
define("LAN_EMAIL_2", "寄件人的IP：");
define("LAN_EMAIL_3", "寄來的內容來自於");
define("LAN_EMAIL_4", "寄出信件");
define("LAN_EMAIL_5", "寄給朋友");
define("LAN_EMAIL_6", "我想您可能這些內容有興趣,來源：");
define("LAN_EMAIL_7", "寄給某人");
define("LAN_EMAIL_8", "評論");
define("LAN_EMAIL_9", "很抱歉-無法寄出信件");
define("LAN_EMAIL_10", "郵件己寄給");
define("LAN_EMAIL_11", "郵件已寄出");
define("LAN_EMAIL_12", "錯誤");
define("LAN_EMAIL_13", "把文章寄給朋友");
define("LAN_EMAIL_14", "把新聞寄給朋友");
define("LAN_EMAIL_15", "登入名稱:");
define("LAN_EMAIL_106", "此似乎為無效的電子信箱");
define("LAN_EMAIL_185", "寄出文章");
define("LAN_EMAIL_186", "寄出新聞");
define("LAN_EMAIL_187", "收件人電子信箱：");
define("LAN_EMAIL_188", "我想您可能有興趣知道這則新聞，來源：");
define("LAN_EMAIL_189", "我想您可能有興趣知道這則文章，來源：");
define("LAN_EMAIL_190", "輸入認證碼");


?>