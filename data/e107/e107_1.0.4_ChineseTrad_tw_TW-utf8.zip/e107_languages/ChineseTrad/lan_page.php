<?php

define("LAN_PAGE_1","頁面列出功能關閉");
define("LAN_PAGE_2","目前沒有頁面");
define("LAN_PAGE_3","您要的頁面部存在");
define("LAN_PAGE_4","評比該頁面");
define("LAN_PAGE_5","感謝您的評比");
define("LAN_PAGE_6","您沒有權限瀏覽");
define("LAN_PAGE_7","錯誤的密碼");
define("LAN_PAGE_8","密碼保護頁面");
define("LAN_PAGE_9","密碼");
define("LAN_PAGE_10","提供");
define("LAN_PAGE_11","頁面清單");
define("LAN_PAGE_12","無效頁面");
define("LAN_PAGE_13","頁面");
?>