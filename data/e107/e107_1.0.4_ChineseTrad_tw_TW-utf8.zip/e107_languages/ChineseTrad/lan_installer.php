<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/lan_installer.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:24:55 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LANINS_TITLE", "安裝e107");
define("LANINS_000", "偵測到無效階段資料!!安裝已中止!!");
define("LANINS_001", "版本 %1$s");
define("LANINS_002", "步驟");
define("LANINS_002a", "(步驟%1sof7)");
define("LANINS_003", "1");
define("LANINS_004", "選擇語系");
define("LANINS_004a", "己選語系");
define("LANINS_004b", "語系");
define("LANINS_005", "請選擇安裝介面的語系");
define("LANINS_006", "設定語言");
define("LANINS_007", "4");
define("LANINS_008", "PHP & MySQL 版本  &檔案權限確認");
define("LANINS_008a", "Compatibility & File permissions");
define("LANINS_009", "重新設定檔案權限");
define("LANINS_010", "無寫入權限的檔案:");
define("LANINS_010a", "無寫入權限的資料夾:");
define("LANINS_011", "發生錯誤");
define("LANINS_012", "MySQL相關函數不存在.通常是表示MySQLPHPExtension尚未安裝或是您的PHPinstallation沒有支援MySQL.");
define("LANINS_013", "無法找出您的MySQL版本.如繼續安裝,這可能會發生錯誤，系統e107需要MySQL>=3.23.");
define("LANINS_014", "檔案權限");
define("LANINS_015", "PHP版本");
define("LANINS_016", "MySQL");
define("LANINS_017", "檢查通過");
define("LANINS_018", "請確定名單上的檔案是否檔案存在,並且相關權限是可以寫入的.通常需要CHMOD為777,如果有問題請聯絡您的主機商.");
define("LANINS_019", "您伺服器上的PHP版本無法執行e107.e107至少需要PHP版本於4.3.0以上.請更新您的PHP版本,或請您的主機商更新.");
define("LANINS_020", "繼續安裝");
define("LANINS_021", "2");
define("LANINS_022", "MySQL伺服器細節");
define("LANINS_022a", "資料庫");
define("LANINS_023", "請在這輸入MySQL的設定。<br /><br />如果您有root的權限去新增資料庫請勾選此欄位，假如您必須新增一個資料庫或是使用目前現有的資料庫。<br /><br />假如您只有一個資料庫請使用前置文字，這樣就可以安裝其他程式於資料庫中。<br />
假如您不知道MySQL資訊請聯絡您的主機商.");
define("LANINS_024", "MySQL伺服器:");
define("LANINS_025", "MySQL帳號:");
define("LANINS_026", "MySQL密碼:");
define("LANINS_027", "MySQL資料庫:");
define("LANINS_028", "新增資料庫?");
define("LANINS_029", "資料表前置文字:");
define("LANINS_030", "您希望e107連結那一個MySQL伺服器.此設定也可以包含Port.例如.\"hostname:port\"或是主機Socket例如\":/path/to/socket\"給localhost.");
define("LANINS_031", "該帳號是您希望e107去連結您的MySQL伺服器");
define("LANINS_032", "密碼則是給該帳號使用的");
define("LANINS_033", "您希望讓e107歸屬於那一個資料庫.如果會員有新增資料庫的權限，您可以自動新增一個未存在資料庫.");
define("LANINS_034", "前置文字是您希望使用e107網站並新增已前置文字開頭的e107資料表.這樣可以安裝多個e107於同一個資料庫中.");
define("LANINS_035", "繼續");
define("LANINS_036", "3");
define("LANINS_037", "MySQL連結確認");
define("LANINS_038", "和資料庫新增");
define("LANINS_038a", "資料庫已確認");
define("LANINS_039", "請確定您已經填完所有欄位,更重要的是,MySQL伺服器,MySQL帳號和MySQL資料庫(MySQL伺服器為必備的)");
define("LANINS_040", "錯誤");
define("LANINS_041", "e107無法用你提供的資料建立與MySQL伺服器的連線。<br />請確認輸入的資料是否正確。");
define("LANINS_042", "連結MySQL伺服器已建立並有效.");
define("LANINS_043", "無法新增資料庫,請確定您有資料庫的相關權限.");
define("LANINS_044", "資料庫新增成功.");
define("LANINS_045", "請點選按鈕進行下一頁.");
define("LANINS_046", "5");
define("LANINS_047", "管理員細節");
define("LANINS_047a", "系統管理者");
define("LANINS_048", "回到上一步");
define("LANINS_049", "兩次密碼不一樣.請重新輸入嘗試.");
define("LANINS_050", "XML Extension");
define("LANINS_051", "已經安裝");
define("LANINS_052", "尚未安裝");
define("LANINS_053", "e1070.7.x 需要安裝PHPXMLExtension功能。請聯絡您的主機商或是在繼續閱讀資訊<ahref='http://php.net/manual/en/ref.xml.php'target='_blank'>php.net</a>");
define("LANINS_054", "選中的資料庫已成功檢查其存在。");
define("LANINS_055", "安裝確認");
define("LANINS_055a", "確認");
define("LANINS_056", "6");
define("LANINS_057", "e107現在已擁有完成安裝全部資料。<br /><br />請點選按鈕新增資料庫資料表和儲存您所有設定。");
define("LANINS_058", "7");
define("LANINS_060", "無法讀取sql資料檔案
請確認檔案<b>core_sql.php</b>存在於<b>/e107_admin/sql</b>目錄.");
define("LANINS_061", "e107無法新增所有必須的資料表。<br /><br />請清除資料庫和修正最近發生的任何問題後再嘗試一遍。");
define("LANINS_062", "[b]歡迎來到您的新網站![/b]
e107已安裝完成並準備接受任何內容.<br/>您的管理控制台[link=e107_admin/admin.php]這裡[/link],點選前往.您將會登入使用安裝時所使用的帳號跟密碼.

[b]相關支援[/b]
e107首頁:[link=http://e107.org]http://e107.org[/link],e107中文支援：[link=http://e107.tw]http://e107.tw[/link][link=http://phpbs.com]PHP黑店[/link],您將可以看到常見問題的文件.
討論區:[link=http://e107.org/e107_plugins/forum/forum.php]http://e107.org/e107_plugins/forum/forum.php[/link]

[b]下載[/b]
外掛:[link=http://e107coders.org]http://e107coders.org[/link]
風格:[link=http://e107styles.org]http://e107styles.org[/link]|[link=http://e107themes.org]http://e107themes.org[/link]

感謝您使用e107,我們希望您可以感到滿意.
(您可以刪除該訊息於您的管理控制台中.)");
define("LANINS_063", "歡迎使用e107");
define("LANINS_069", "e107已完成安裝!

請您重新設定檔案權限<b>e107_config.php</b>回到644.

點選下面連結後，請刪除install.php");
define("LANINS_070", "e107無法儲存主要的設定檔案.

請確認<b>e107_config.php</b>沒有正確的權限");
define("LANINS_071", "最後安裝步驟");
define("LANINS_071a", "成功完成");
define("LANINS_071b", "完成安裝時發生錯誤");
define("LANINS_071c", "已完成但是有一些錯誤");
define("LANINS_072", "管理員名稱");
define("LANINS_073", "這個名稱是您使用的登入名稱.您可以跟您的顯示名稱相同");
define("LANINS_074", "管理員顯示名稱");
define("LANINS_075", "這個名稱將會顯示於您的個人資料,討論區以及其他區域.假如您想跟您的登入名稱相同請保留空白.");
define("LANINS_076", "站長密碼");
define("LANINS_077", "請輸入您想使用的站長密碼");
define("LANINS_078", "站長密碼確認");
define("LANINS_079", "請再次輸入站長密碼");
define("LANINS_080", "站長的信箱");
define("LANINS_081", "輸入您的電子信箱");
define("LANINS_082", "user@yoursite.com");
define("LANINS_083", "MySQL錯誤報告:");
define("LANINS_084", "無法建立連線");
define("LANINS_085", "無法選擇資料庫:");
define("LANINS_086", "管理員帳號,密碼和郵件地址為<b>必填的欄位</b>.請返回上一頁確認這些資料填寫是否正確.");
define("LANINS_087", "綜合的");
define("LANINS_088", "首頁");
define("LANINS_089", "好康下載");
define("LANINS_090", "會員");
define("LANINS_091", "新聞提供");
define("LANINS_092", "聯絡我們");
define("LANINS_093", "給予進入私人選單項目權限");
define("LANINS_094", "私人討論區權限範例");
define("LANINS_095", "檢查完整性");
define("LANINS_096", "最新評論");
define("LANINS_097", "[閱讀更多...]");
define("LANINS_098", "新聞");
define("LANINS_099", "e107CMS");
define("LANINS_100", "討論區最新回覆");
define("LANINS_101", "更新選單設定");
define("LANINS_102", "日期/時間");
define("LANINS_103", "e107Plugins");
define("LANINS_104", "已核取");
define("LANINS_105", "資料庫名稱或是前置文字發生字元上錯誤。例如：\'e\'或是\'E\'是不被接受的。<br/>資料庫名稱或是前置文字不可空白。");
define("LANINS_106", "警告-E107無法寫入下面資料夾及(或)列出檔案。E107安裝將會繼續，但是將會有部份功能無法使用。<br /><br />您必須變更相關的檔案權限。");
define("LANINS_107", "e107_config.php 並不是空白的檔案");
define("LANINS_108", "可能是您有一份正在安裝中的程序");
define("LANINS_DB_UTF8_LABEL", "強制UTF-8連線?");
define("LANINS_DB_UTF8_CAPTION", "MySQL編碼字元:");
define("LANINS_DB_UTF8_TOOLTIP", "如果選擇，將會把資料庫中的編碼設定為UTF-8.UTF-8資料庫將會是下一e107版本必備選項。");
define("LANINS_109", "開始");
define("LANINS_110", "完作");
define("LANINS_111", "e107 Themes");
define("LANINS_112", "e107 Handbook");
define("LANINS_113", "");
define("LANINS_121", "檔案e107_config.php已存在");
define("LANINS_122", "可能是您有一份正在安裝中的程序");
define("LANINS_123", "偵錯訊息");
define("LANINS_124", "反譯");
define("LANINS_125", "無效的步驟");
define("LANINS_125a", "錯誤");
define("LANINS_WELCOME", "[b]歡迎來到你的新網站![/b] e107 已成功安裝而且現在已經可以接受內容了。你的系統管理者區域連結為[link=e107_admin/admin.php]located here[/link], 可以點擊前往。 你必須用安裝過程中輸入的帳號及密碼登入。 [b]支援網站t[/b] [link=http://e107.org/]e107 Homepage[/link] [link=http://e107.org/support]e107 Forums[/link] [link=http://wiki.e107.org/]e107 Handbook[/link] 
謝謝你使用e107，我們希望它可以滿足你的架站需求。");
define("LANINS_NEWS", "[b]Welcome![/b] e107 is a content management system written in PHP and using the popular open source MySQL database system for content storage. It is completely free, totally customizable and in constant development. [list][link=http://e107.org/content/Learn-all-about-e107]Everything you need to know about e107[/link]*[link=http://e107.org/content/About-Us:The-Team]Dev Team | Translators | Support Team[/link]*[link=http://wiki.e107.org/]Documentation Wiki[/link][/list]");


?>