<?php

define("NP_1","前一頁");
define("NP_2","後一頁");
define("NP_3","前往頁面");

?>