<?php









define("PAGE_NAME","會員");

define("LAN_20","錯誤");
define("LAN_112","Email信箱");
define("LAN_115","ICQ即時通");
define("LAN_116","AIM即時通");
define("LAN_117","MSN即時通");
define("LAN_118","生日");
define("LAN_119","來自於");
define("LAN_120","簽名檔");
define("LAN_137","目前沒有未註冊會員任何資訊");
define("LAN_138","註冊會員:");
define("LAN_139","排列:");
define("LAN_140","註冊會員");
define("LAN_141","目前沒有註冊會員.");
define("LAN_142","會員");
define("LAN_143","[要求隱藏]");
define("LAN_144","個人網站");
define("LAN_145","加入於");
define("LAN_146","自從註冊後瀏覽網站次數");
define("LAN_147","聊天室發表數");
define("LAN_148","已發表評論");
define("LAN_149","討論區發表數");
define("LAN_308","真實姓名");
define("LAN_400","這不是有效的會員.");
define("LAN_401","沒有相關資訊");
define("LAN_402","會員個人檔案");
define("LAN_403","網站統計");
define("LAN_404","上次瀏覽");
define("LAN_405","天以前");
define("LAN_406","等級");
define("LAN_407","沒有");
define("LAN_408","沒有照片");
define("LAN_409","點數");
define("LAN_410","五花八門");
define("LAN_411","點選這裡更新您的個人資訊");
define("LAN_412","點選這裡編輯會員資訊");
define("LAN_413","刪除照片");
define("LAN_414","前一位會員");
define("LAN_415","下一位會員");
define("LAN_416","您必須登入後才可以瀏覽此頁面");
define("LAN_417","主要網站管理員");
define("LAN_418","網站管理員");
define("LAN_419","顯示");
define("LAN_420","向下");
define("LAN_421","向上");
define("LAN_422","前往");
define("LAN_423","點選這裡瀏覽會員評論");
define("LAN_424","點選這裡瀏覽會員發表");
define("LAN_425","發送私人訊息");
define("LAN_426","之前");

define("USERLAN_1","Peer評比中");
define("USERLAN_2","您沒有權限瀏覽此頁面.");

?>