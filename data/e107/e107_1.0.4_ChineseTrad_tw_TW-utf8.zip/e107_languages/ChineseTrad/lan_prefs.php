<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/ChineseTrad/lan_prefs.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/19 13:59:55 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 Powered Website");
define("LAN_PREF_2", "e107 Website System");
define("LAN_PREF_3", "This site is powered by <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107</a>, which is released under the terms of the <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL License.");
define("LAN_PREF_4", "審查完成");
define("LAN_PREF_5", "討論區");


?>