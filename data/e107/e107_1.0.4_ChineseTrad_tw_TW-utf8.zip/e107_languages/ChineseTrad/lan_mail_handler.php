<?php









define("LANMAILH_1","由e107網站系統提供");
define("LANMAILH_2","此格式為多元訊息（MIME格式）.");
define("LANMAILH_3","不是正確的格式");
define("LANMAILH_4","伺服器拒絕此網址");
define("LANMAILH_5","伺服器沒有回應");
define("LANMAILH_6","無法找到此E-Mail伺服器.");
define("LANMAILH_7","為有效的.");


?>