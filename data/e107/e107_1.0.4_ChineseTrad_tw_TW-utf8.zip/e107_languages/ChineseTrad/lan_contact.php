<?php



define("PAGE_NAME","聯絡我們");
define("LANCONTACT_01","聯絡資料");
define("LANCONTACT_02","聯絡資料表格");
define("LANCONTACT_03","輸入您的姓名:");
define("LANCONTACT_04","電子信箱:");
define("LANCONTACT_05","內容主題:");
define("LANCONTACT_06","輸入您的訊息內容:");
define("LANCONTACT_07","寄出此訊息副本至您的信箱。");
define("LANCONTACT_08","發送");
define("LANCONTACT_09","您的訊息已送出.");
define("LANCONTACT_10","送出訊息時出現錯誤。");
define("LANCONTACT_11","您的信箱格式不是正確的.\\n請確認後再試一次.");
define("LANCONTACT_12","您的訊息內容太少了.");
define("LANCONTACT_13","請包含一個主題.");
define("LANCONTACT_14","寄出訊息給:");
define("LANCONTACT_15","輸入錯誤的認證碼");
define("LANCONTACT_16","請輸入認證碼");


?>