<?php

define("LWLAN_1", "欄位保留空白.");
define("LWLAN_2", "連結文字完成儲存.");
define("LWLAN_3", "連結文字更新完成.");
define("LWLAN_4", "尚未定義連結文字.");
define("LWLAN_5", "文字");
define("LWLAN_6", "連結");
define("LWLAN_7", "啟動?");
define("LWLAN_8", "選項");
define("LWLAN_9", "是");
define("LWLAN_10", "否");
define("LWLAN_11", "現有的文字");
define("LWLAN_12", "是");
define("LWLAN_13", "否");
define("LWLAN_14", "提供連結文字");
define("LWLAN_15", "更新連結文字");
define("LWLAN_16", "編輯");
define("LWLAN_17", "刪除");
define("LWLAN_18", "您確定要刪除該連結文字?");
define("LWLAN_19", "連結文字完成刪除.");
define("LWLAN_20", "無法找到該連結文字目錄.");
define("LWLAN_21","文字自動連結");
define("LWLAN_22","啟動?");
define("LWLAN_23", "連結文字管理");
define("LWLAN_24", "管理文字");
define("LWLAN_25", "一般選項");
define("LWLAN_26", "此區域為開啟連結文字");
define("LWLAN_27", "這是一個 'context' 的顯示文字");
define("LWLAN_28", "顯示連結文字的頁面");
define("LWLAN_29", "同樣的格式於選單可見度設定控制. 每一行一個對應連結. 指定部份或是完整連結. 使用 '!' 作為結尾來精準的結束連結部份尾端");
define("LWLAN_30", "儲存選項");
define("LWLAN_31", "新增/編輯連結文字");
define("LWLAN_32", "連結文字選項");
define("LWLAN_33", '標題區域');
define("LWLAN_34", '內容簡述');
define("LWLAN_35", '內文');
define("LWLAN_36", '相關描述 (友站連結等等)');
define("LWLAN_37", '繼承區域');
define("LWLAN_38", '可點選連結');
define("LWLAN_39", '未處理文字');
define("LWLAN_40", '會員輸入的標題 (例如:討論區)');
define("LWLAN_41", '會員輸入的內容文字 (例如:討論區)');

define("LWLANINS_1", "連結文字");
define("LWLANINS_2", "該外掛將指定文字提供特定連結");
define("LWLANINS_3", "連結文字基本設定");
define("LWLANINS_4", "請於管理控制台點選外掛區中設定");

?>