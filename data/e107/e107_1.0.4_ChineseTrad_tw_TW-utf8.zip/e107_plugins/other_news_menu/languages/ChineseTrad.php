<?php

	
define("TD_MENU_L1", "其它新聞一");
define("TD_MENU_L2", "其它新聞二");

	
?>