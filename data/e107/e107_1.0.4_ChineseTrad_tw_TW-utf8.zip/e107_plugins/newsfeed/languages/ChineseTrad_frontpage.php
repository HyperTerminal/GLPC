<?php

define("NWSF_FP_1", "新聞提供");
define("NWSF_FP_2", "首頁");

?>