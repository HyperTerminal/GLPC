<?php
define("BANNER_MENU_L1", "廣告");
define("BANNER_MENU_L2", "已儲存的廣告欄位");
define("BANNER_MENU_L3", "標題");
define("BANNER_MENU_L4", "活動");
define("BANNER_MENU_L5", "欄位選單設定");
define("BANNER_MENU_L6", "選擇顯示活動於選單");
define("BANNER_MENU_L7", "有效活動");
define("BANNER_MENU_L8", "已選擇活動");
define("BANNER_MENU_L9", "移除所選擇的");
define("BANNER_MENU_L10", "您要選擇顯示類型 ?");
define("BANNER_MENU_L11", "選擇變換方式 ...");
define("BANNER_MENU_L12", "一個活動於單一選單  ");
define("BANNER_MENU_L13", "所有選擇的活動於單一選單");
define("BANNER_MENU_L14", "所有選擇的活動於分開選單");
define("BANNER_MENU_L15", "要顯示多少廣告欄位 ?");
define("BANNER_MENU_L16", "該設定僅可以使用選項 2 和 3.<br />假如廣告太少將會全部顯示.");
define("BANNER_MENU_L17", "設定更多選項 ...");
define("BANNER_MENU_L18", "更新選單設定");
?>