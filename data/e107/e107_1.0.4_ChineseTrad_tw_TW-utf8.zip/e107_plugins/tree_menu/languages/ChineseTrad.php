<?php

define("TREE_L1", "樹狀選單組態設定");
define("TREE_L2", "更新樹狀選單設定");
define("TREE_L3", "樹狀選單設定已儲存");
define("TREE_L4", "開");
define("TREE_L5", "關");
define("TREE_L6", "CSS class to use for non-openable links");
define("TREE_L7", "CSS class to use for openable links");
define("TREE_L8", "CSS class to use for opened links");
define("TREE_L9", "Use spacer class between main links");


?>