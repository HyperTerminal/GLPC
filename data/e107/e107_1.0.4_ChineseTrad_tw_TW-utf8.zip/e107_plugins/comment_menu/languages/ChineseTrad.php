<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/comment_menu/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:48:21 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("CM_L1", "目前沒有評論.");
define("CM_L2", "");
define("CM_L3", "標題");
define("CM_L4", "顯示多少評論?");
define("CM_L5", "顯示多少字元?");
define("CM_L6", "評論字尾太長?");
define("CM_L7", "顯示原始新聞標題於選單中?");
define("CM_L8", "新聞評論選單設定");
define("CM_L9", "更新選單設定");
define("CM_L10", "評論選單設定已儲存");
define("CM_L11", "在");
define("CM_L12", "Re:");
define("CM_L13", "發表於");


?>