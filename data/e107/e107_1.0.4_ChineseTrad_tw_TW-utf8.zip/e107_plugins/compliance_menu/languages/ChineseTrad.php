<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/compliance_menu/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:49:03 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("COMPLIANCE_L1", "符合 W3C 規範");


?>