<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/sitebutton_menu/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 23:12:13 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("SITEBUTTON_MENU_L1", "連結至我們");


?>