<?php

define("ONLINE_L1", "線上訪客:");
define("ONLINE_L2", "線上會員:");
define("ONLINE_L3", "瀏覽頁頁");
define("ONLINE_L4", "線上情況");
define("ONLINE_L5", "會員");
define("ONLINE_L6", "最新的");
define("TRACKING_MESSAGE", "顯示線上會員功能目前關閉,please enable it [link=".e_ADMIN."users.php?options]here[/link][br]");


?>