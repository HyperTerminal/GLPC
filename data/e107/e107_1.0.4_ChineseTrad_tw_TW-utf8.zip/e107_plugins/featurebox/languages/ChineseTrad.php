<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/featurebox/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:52:22 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("FBLAN_01", "特別專欄");
define("FBLAN_02", "該外掛允許您顯示一個盒子於您的新聞項目上方.該訊息可以循環隨機或是動態消失.");
define("FBLAN_03", "設定");
define("FBLAN_04", "特別專欄外掛完成安裝.新增訊系以及設定, 請回到管理首頁並點選特別專欄圖標於外掛區域中.");
define("FBLAN_05", "目前沒有任何訊息於特別專欄");
define("FBLAN_06", "現有的訊息");
define("FBLAN_07", "標題/說明");
define("FBLAN_08", "訊息文字");
define("FBLAN_09", "訊息瀏覽權限");
define("FBLAN_10", "新增特別專欄");
define("FBLAN_11", "更新特別專欄");
define("FBLAN_12", "模式");
define("FBLAN_13", "隨機循環訊息");
define("FBLAN_14", "僅顯示該訊息");
define("FBLAN_15", "訊息已經新增到資料庫.");
define("FBLAN_16", "訊息完成更新於資料庫.");
define("FBLAN_17", "欄位保留空白");
define("FBLAN_18", "特別專欄訊息完成刪除");
define("FBLAN_19", "選項");
define("FBLAN_20", "編輯");
define("FBLAN_21", "刪除");
define("FBLAN_22", "表達模式");
define("FBLAN_23", "套用風格");
define("FBLAN_24", "清單顯示");
define("FBLAN_25", "風格");
define("FBLAN_26", "您可以使用不同風格於同一個訊息, 新增風格到 e107_plugins/featurebox/templates/ 資料夾中");


?>