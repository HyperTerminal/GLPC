<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/userlanguage_menu/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/19 17:22:23 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "設置語言");
define("UTHEME_MENU_L2", "選擇語言");
define("UTHEME_MENU_L3", "資料表格");


?>