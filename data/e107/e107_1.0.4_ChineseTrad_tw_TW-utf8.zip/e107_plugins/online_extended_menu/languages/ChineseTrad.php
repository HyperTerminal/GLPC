<?php

	
define("ONLINE_EL1", "線上訪客人數: ");
define("ONLINE_EL2", "線上會員人數: ");
define("ONLINE_EL3", "瀏覽頁面: ");
define("ONLINE_EL4", "網站會員狀況");
define("ONLINE_EL5", "全部會員數");
define("ONLINE_EL6", "最新註冊會員");
define("ONLINE_EL7", "正在瀏覽");
	
define("ONLINE_EL8", "最多同時線上人數: ");
define("ONLINE_EL9", "發生時間於");

define("ONLINE_TRACKING_MESSAGE", "線上統計目前關閉, 請於 [link=".e_ADMIN."users.php?options]這裡開啟[/link][br]");

?>