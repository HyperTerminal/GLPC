<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/counter_menu/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:51:54 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("COUNTER_L1", "管理員登入不列入計算.");
define("COUNTER_L2", "該頁面今天 ...");
define("COUNTER_L3", "總共");
define("COUNTER_L4", "該頁面曾經 ...");
define("COUNTER_L5", "特定");
define("COUNTER_L6", "網站 ...");
define("COUNTER_L7", "計數器");
define("COUNTER_L8", "管理員訊息: <b>統計登入已經關閉.</b><br />如果您要啟動, 您必須安裝統計登入外掛於 <a href='".e_ADMIN."plugin.php'>外掛管理中</a>, 將會啟動於 <a href='".e_PLUGIN."log/admin_config.php'>設定視窗</a>.");


?>