<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/ChineseTrad/lan_chatbox_search.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:47:34 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("CB_SCH_LAN_1", "聊天室");


?>