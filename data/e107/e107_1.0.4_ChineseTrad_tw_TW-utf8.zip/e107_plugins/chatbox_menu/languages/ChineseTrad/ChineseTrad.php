<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/chatbox_menu/languages/ChineseTrad/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:46:58 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("CHATBOX_L1", "無法接受訪客發表 - 假如您擁有會員資格請登入後發表。");
define("CHATBOX_L2", "聊天室");
define("CHATBOX_L3", "您必須登入後才可以發表評論 - 請登入或是點選<a href='".e_SIGNUP."'>這裡</a>註冊");
define("CHATBOX_L4", "送出");
define("CHATBOX_L5", "重新設定");
define("CHATBOX_L6", "[被管理員封鎖]");
define("CHATBOX_L7", "取消封鎖");
define("CHATBOX_L8", "資訊");
define("CHATBOX_L9", "封鎖");
define("CHATBOX_L10", "刪除");
define("CHATBOX_L11", "目前沒有訊息.");
define("CHATBOX_L12", "瀏覽所有發表");
define("CHATBOX_L13", "管理聊天室");
define("CHATBOX_L14", "表情圖案");
define("CHATBOX_L15", "留言過長或是空白");
define("CHATBOX_L16", "訪客");
define("CHATBOX_L17", "重覆的留言");
define("CHATBOX_L18", "聊天室訊息已編輯過");
define("CHATBOX_L19", "您發表需間隔".(FLOODPROTECT ? FLOODTIMEOUT : 'n/a')." 秒");
define("CHATBOX_L20", "聊天室 (全部發表)");
define("CHATBOX_L21", "聊天發表");
define("CHATBOX_L22", "於");
define("CHATBOX_L23", "錯誤!");
define("CHATBOX_L24", "您沒有瀏覽該頁面的權限.");
define("CHATBOX_L25", "[該發表已經被管理員封鎖了]");
define("NT_LAN_CB_1", "聊天室項目");
define("NT_LAN_CB_2", "訊息已送出");
define("NT_LAN_CB_3", "發表者");
define("NT_LAN_CB_4", "IP 位址");
define("NT_LAN_CB_5", "訊息");
define("NT_LAN_CB_6", "聊天室已發表訊息");


?>