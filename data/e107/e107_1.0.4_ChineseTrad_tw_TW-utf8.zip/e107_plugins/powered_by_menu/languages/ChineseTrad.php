<?php

	
define("POWEREDBY_L1", "Powered by");
	
?>