<?php
define("FOR_FP_1", "討論區");
?>