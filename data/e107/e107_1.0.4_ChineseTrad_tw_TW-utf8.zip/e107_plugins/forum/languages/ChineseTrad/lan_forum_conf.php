<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/ChineseTrad/lan_forum_conf.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/06 22:28:52 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_FORUM_INSTALL_01", "討論區");
define("LAN_FORUM_INSTALL_02", "此外掛為功能齊全的討論區系統");
define("LAN_FORUM_INSTALL_03", "設定討論區");
define("LAN_FORUM_INSTALL_04", "您的討論區已經安裝完成。");
define("LAN_FORUM_INSTALL_05", "討論區已成功更新，現在的版本為:%1$s");
define("LAN_FORUM_INSTALL_06", "[討論區]");
define("LAN_FORUM_INSTALL_07", "[更多...]");
define("FORLAN_5", "刪除投票.");
define("FORLAN_6", "刪除主題");
define("FORLAN_7", "刪除回覆");
define("FORLAN_8", "取消刪除.");
define("FORLAN_9", "移動主題.");
define("FORLAN_10", "取消移動.");
define("FORLAN_11", "回到討論區");
define("FORLAN_12", "討論區設定");
define("FORLAN_13", "您確定要刪除該投票?<br/>刪除後<b><u>無法回復該項操作</u></b>.");
define("FORLAN_14", "取消");
define("FORLAN_15", "確定刪除討論區文章");
define("FORLAN_16", "確認刪除投票");
define("FORLAN_17", "發表於");
define("FORLAN_18", "您確定要刪除該討論區");
define("FORLAN_19", "的特定主題和該相關回覆?");
define("FORLAN_20", "投票將會被刪除");
define("FORLAN_21", "一次刪除他們的");
define("FORLAN_22", "發表?<br/>刪除後");
define("FORLAN_23", "無法回復該項操作</u></b>");
define("FORLAN_24", "移動主題到討論區");
define("FORLAN_25", "移動主題");
define("FORLAN_26", "刪除回覆");
define("FORLAN_27", "移動");
define("FORLAN_28", "無法重新命名文章主題");
define("FORLAN_29", "新增");
define("FORLAN_30", "於標題");
define("FORLAN_31", "重新命名於:");
define("FORLAN_32", "重新命名主題選項:");


?>