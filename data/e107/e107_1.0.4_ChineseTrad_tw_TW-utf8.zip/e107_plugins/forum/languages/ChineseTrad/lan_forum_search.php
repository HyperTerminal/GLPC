<?php
define("FOR_SCH_LAN_1", "版面");
define("FOR_SCH_LAN_2", "選擇版面");
define("FOR_SCH_LAN_3", "所有版面");
define("FOR_SCH_LAN_4", "全部的內容");
define("FOR_SCH_LAN_5", "部分內容");

?>