<?php
define("PAGE_NAME", "討論區上傳檔案");
define('FRMUP_1','上傳檔案到討論區');
define('FRMUP_2','刪除檔案');
define('FRMUP_3','發生錯誤: 無法刪除該檔案');
define('FRMUP_4','檔案刪除');
define('FRMUP_5','檔案名稱');
define('FRMUP_6','結果');
define('FRMUP_7','找到該主題');
define('FRMUP_8','沒有找到');
define('FRMUP_9','沒有找到上傳的檔案');
define('FRMUP_10','刪除');
	
?>