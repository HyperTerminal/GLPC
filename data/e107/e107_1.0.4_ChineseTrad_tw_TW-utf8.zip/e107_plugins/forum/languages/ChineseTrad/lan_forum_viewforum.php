<?php
define("PAGE_NAME", "討論區");
define("LAN_01", "討論區");
define("LAN_02", "回到最上面");
define("LAN_03", "前往");
define("LAN_53", "文章主題");
define("LAN_54", "發表作者");
define("LAN_55", "回覆");
define("LAN_56", "瀏覽");
define("LAN_57", "最新發表");
define("LAN_58", "目前沒有任何文章.");
define("LAN_59", "您必須註冊後並登入才可以發表主題. 麻煩請註冊或是登入.");
define("LAN_79", "有新的文章");
define("LAN_80", "沒有新文章");
define("LAN_81", "關閉的主題");
define("LAN_180", "搜尋");
define("LAN_199", "尚未閱讀");
define("LAN_202", "置頂");
define("LAN_203", "置頂/已關閉");
define("LAN_204", "您<b>可以</b> 發表文章");
define("LAN_205", "您 <b>不可以</b> 發表文章");
define("LAN_206", "您 <b>可以</b> 回覆文章");
define("LAN_207", "您 <b>不可以</b> 回覆文章");
define("LAN_208", "您 <b>可以</b> 編輯您的文章");
define("LAN_209", "您 <b>不可以</b> 編輯您的文章");
define("LAN_316", "前往頁面: ");
define("LAN_317", "沒有");
define("LAN_321", "版主: ");
define("LAN_395", "[熱門]");
define("LAN_396", "公告");
	
define("LAN_397", "此討論區僅限於閱讀");
	
define("LAN_398", "未置頂");
define("LAN_399", "鎖住");
define("LAN_400", "取消鎖住");
define("LAN_401", "置頂");
define("LAN_402", "移動");
define("LAN_403", "跳轉討論區");
define("LAN_404", "討論區版主");
	
define("LAN_405", "位會員正在瀏覽討論區");
define("LAN_406", "位會員正在瀏覽討論區");
define("LAN_407", "位會員");
define("LAN_408", "位訪客");
define("LAN_409", "位會員");
define("LAN_410", "位訪客");
	
//v.616
define("LAN_411", "重要的文章");
define("LAN_412", "討論區文章");
define("LAN_431", "討論區RSS類型: rss 0.92");
define("LAN_432", "討論區RSS類型: rss 2.0");
define("LAN_433", "討論區RSS類型: RDF");

define("LAN_434", "您確定要刪除文章和所有回覆?");
define("LAN_435", "刪除");
	
//v.617
define("FORLAN_CLOSE", "關閉.");
define("FORLAN_OPEN", "開啟.");
define("FORLAN_STICK", "置頂.");
define("FORLAN_UNSTICK", "解除置頂.");
define("FORLAN_6", "刪除完成");
define("FORLAN_7", "回覆刪除完成");
define("FORLAN_8", "這裡");
define("FORLAN_9", "登入或是註冊成為會員.");
	
define("FORLAN_10", "開啟新文章");
define("FORLAN_11", "有新的文章");
define("FORLAN_12", "沒有新文章");
define("FORLAN_13", "熱門文章有新回覆");
define("FORLAN_14", "熱門文章沒有新的回覆");
define("FORLAN_15", "置頂文章");
define("FORLAN_16", "關閉的置頂文章");
define("FORLAN_17", "公告主題");
define("FORLAN_18", "關閉主題");
define('FORLAN_19', '[已刪除會員]');
define('FORLAN_20', '子討論區');
define('FORLAN_21', '文章');
define('FORLAN_22', '最後發表');
	
?>