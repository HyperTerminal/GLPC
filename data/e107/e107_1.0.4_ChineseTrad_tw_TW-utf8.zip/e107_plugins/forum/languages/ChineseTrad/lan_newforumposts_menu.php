<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/ChineseTrad/lan_newforumposts_menu.php $
|        $Revision: 1.0 $
|        $Id: 2012/02/01 14:48:28 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("NFP_1", "全部最新的文章您沒有相關的權限閱讀.");
define("NFP_2", "目前尚無文章");
define("NFP_3", "新的討論區發表選單設定已儲存");
define("NFP_4", "標題");
define("NFP_5", "欲顯示的發表數 ?");
define("NFP_6", "欲顯示的字元數?");
define("NFP_7", "針對過長文章顯示的替代文字?");
define("NFP_8", "顯示原始主題於選單上?");
define("NFP_9", "更新選單設定");
define("NFP_10", "新的討論區發表選單設定");
define("NFP_11", "發表於");
define("NFP_12", "顯示回覆最久時間");
define("NFP_13", "人氣較低的設為零; 此項設定值可以提高資料庫的效能");


?>