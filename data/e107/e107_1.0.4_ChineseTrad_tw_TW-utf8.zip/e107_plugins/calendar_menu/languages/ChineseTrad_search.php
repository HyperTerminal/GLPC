<?php

define("CM_SCH_LAN_1", "行事曆");

?>