<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/ChineseTrad_class.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/15 22:16:23 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("EC_LAN_RECUR_00", "NO");
define("EC_LAN_RECUR_01", "每年");
define("EC_LAN_RECUR_02", "每半年");
define("EC_LAN_RECUR_03", "每一季");
define("EC_LAN_RECUR_04", "每月");
define("EC_LAN_RECUR_05", "每4週");
define("EC_LAN_RECUR_06", "隔週");
define("EC_LAN_RECUR_07", "每週");
define("EC_LAN_RECUR_08", "每日");
define("EC_LAN_RECUR_100", "每月的週日");
define("EC_LAN_RECUR_101", "每月的週一");
define("EC_LAN_RECUR_102", "每月的週二");
define("EC_LAN_RECUR_103", "每月的週三");
define("EC_LAN_RECUR_104", "每月的週四");
define("EC_LAN_RECUR_105", "每月的週五");
define("EC_LAN_RECUR_106", "每月的週六");
define("EC_LAN_RECUR_1100", "第一");
define("EC_LAN_RECUR_1200", "第二");
define("EC_LAN_RECUR_1300", "第三");
define("EC_LAN_RECUR_1400", "第四");
define("NT_LAN_EC_1", "行事曆-事件");
define("NT_LAN_EC_2", "事件已更新");
define("NT_LAN_EC_3", "更新人員:");
define("NT_LAN_EC_4", "IP 位址");
define("NT_LAN_EC_5", "訊息");
define("NT_LAN_EC_6", "行事曆-事件已新增");
define("NT_LAN_EC_7", "無事件發佈");
define("NT_LAN_EC_8", "行事曆-事件已更改");
define("EC_ADM_01", "行事曆-增加事件");
define("EC_ADM_02", "行事曆-編輯事件");
define("EC_ADM_03", "行事曆-刪除事件");
define("EC_ADM_04", "行事曆-");
define("EC_ADM_05", "行事曆-增加多重行事曆");
define("EC_ADM_06", "行事曆-主要選項已變更");
define("EC_ADM_07", "行事曆-FE選項已變更");
define("EC_ADM_08", "行事曆-類別已增加");
define("EC_ADM_09", "行事曆-類別己編輯");
define("EC_ADM_10", "行事曆-類別己刪除");
define("EC_ADM_11", "行事曆-過期事件已刪除");


?>