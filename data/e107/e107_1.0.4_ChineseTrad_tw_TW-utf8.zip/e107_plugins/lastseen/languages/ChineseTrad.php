<?php

define("LSP_LAN_1", "最後見到");


?>