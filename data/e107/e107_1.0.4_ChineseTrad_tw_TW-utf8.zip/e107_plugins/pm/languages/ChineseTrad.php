<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/pm/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2011/09/26 16:46:51 $
|        $Author: admin $
+---------------------------------------------------------------+
*/
define("LAN_PM", "私人訊息(PM)");
define("LAN_PM_1", "寄送私人訊息");
define("LAN_PM_2", "給");
define("LAN_PM_3", "預覽");
define("LAN_PM_4", "使用者等級");
define("LAN_PM_5", "主旨");
define("LAN_PM_6", "訊息內容");
define("LAN_PM_7", "Emotes");
define("LAN_PM_8", "附件");
define("LAN_PM_9", "閱讀 receipt");
define("LAN_PM_10", "當私人訊息被閱讀後發送電子郵件知我");
define("LAN_PM_11", "增加新上傳");
define("LAN_PM_12", "您沒有權限使用私人訊息系統");
define("LAN_PM_13", "你的寄信匣已經 {PERCENT}% 滿了，未刪除前你無法寄出PM。");
define("LAN_PM_14", "錯誤：可能重覆發送, PM 未送出。");
define("LAN_PM_15", "你尚無法寄PM到使用者等級：");
define("LAN_PM_16", "Must be member of class");
define("LAN_PM_17", "無發現使用者");
define("LAN_PM_18", "You are not allowed to send PMs to:");
define("LAN_PM_19", "您的信箱已滿，無法寄送PM。");
define("LAN_PM_21", "Adding this PM will exceed your maximum outbox 大小, PM not posted");
define("LAN_PM_22", "檔案上傳失敗");
define("LAN_PM_23", "您無法寄出附件");
define("LAN_PM_24", "刪除 PM");
define("LAN_PM_25", "收信匣");
define("LAN_PM_26", "寄信匣");
define("LAN_PM_27", "未讀");
define("LAN_PM_28", "N/A");
define("LAN_PM_29", "訊息已寄出");
define("LAN_PM_30", "訊息已閱讀");
define("LAN_PM_31", "寄件者");
define("LAN_PM_32", "已接收");
define("LAN_PM_33", "已寄出");
define("LAN_PM_34", "尚無訊息");
define("LAN_PM_35", "寄送新的訊息");
define("LAN_PM_36", "總計");
define("LAN_PM_37", "未讀");
define("LAN_PM_38", "PM Sent to 使用者等級：");
define("LAN_PM_39", "無法傳 PM 給：");
define("LAN_PM_40", "PM Sent to 使用者");
define("LAN_PM_41", "Failed to post PM to your Outbox");
define("LAN_PM_42", "已從收信匣中刪除訊息");
define("LAN_PM_43", "已從寄信匣中刪除訊息");
define("LAN_PM_44", "Block removed: {UNAME} is now allowed to send you PMs");
define("LAN_PM_45", "ERROR: Block not removed, unknown error");
define("LAN_PM_46", "Block not in place for {UNAME}");
define("LAN_PM_47", "Block added: {UNAME} is no longer allowed to send you PMs");
define("LAN_PM_48", "錯誤: Block not added, unknown error");
define("LAN_PM_49", "錯誤: Block al閱讀y in place for {UNAME}");
define("LAN_PM_50", "封鎖使用者");
define("LAN_PM_51", "解鎖使用者");
define("LAN_PM_52", "刪除");
define("LAN_PM_53", "刪除已選取的");
define("LAN_PM_54", "Quote original");
define("LAN_PM_55", "Send Reply");
define("LAN_PM_56", "You are not permitted to reply to this message");
define("LAN_PM_57", "Message not found");
define("LAN_PM_58", "Re:");
define("LAN_PM_59", "跳至頁面:");
define("LAN_PM_60", "You are not permitted to view this message");
define("LAN_PM_61", "沒有標題");
define("LAN_PM_62", "File: [{FILENAME}] exceeds 大小 limit - not attached");
define("LAN_PM_63", "class:");
define("LAN_PM_64", "錯誤: You are not permitted to block messages from site administrators");
define("LAN_PM_65", "錯誤: Nothing to send");
define("LAN_PM_66", "Blocked Senders");
define("LAN_PM_67", "無使用者被封鎖");
define("LAN_PM_68", "使用者名稱");
define("LAN_PM_69", "Date blocked");
define("LAN_PM_70", "Deleting block on 使用者");
define("LAN_PM_71", "--GOOD-- attachment(s) deleted. --FAIL-- failure(s)");
define("LAN_PM_72", "使用者已刪除");
define("LAN_PM_100", "New PM from");
define("LAN_PM_101", "You have received a new Private Message from");
define("LAN_PM_102", "Message sent from:");
define("LAN_PM_103", "Message subject:");
define("LAN_PM_104", "Number of attachments:");
define("LAN_PM_105", "You can view the PM at:");
define("LAN_PM_106", "PM 閱讀 by");
define("LAN_PM_107", "The Private Message you sent to {UNAME} was 閱讀 on");
define("LAN_PM_108", "Message sent on:");
define("LAN_PM_109", "新的訊息~");
define("LAN_PM_110", "ok");
define("LAN_PM_111", "閱讀");


?>