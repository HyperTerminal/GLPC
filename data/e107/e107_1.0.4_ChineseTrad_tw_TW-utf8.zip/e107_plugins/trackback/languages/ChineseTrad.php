<?php

define("TRACKBACK_L1", "Trackback 組態設定");
define("TRACKBACK_L2", "此外掛讓您可以在新聞發佈中使用 trackback 功能");
define("TRACKBACK_L3", "Trackback現在已經安裝完成並可以使用了");
define("TRACKBACK_L4", "Trackback 設定已儲存");
define("TRACKBACK_L5", "開");
define("TRACKBACK_L6", "關");
define("TRACKBACK_L7", "啟用 trackback");
define("TRACKBACK_L8", "Trackback URL text");
define("TRACKBACK_L9", "儲存設定");
define("TRACKBACK_L10", "Trackback 設定");
define("TRACKBACK_L11", "Trackback address for this post:");
define("TRACKBACK_L12", "No trackbacks for this item");
define("TRACKBACK_L13", "Moderate trackbacks");
define("TRACKBACK_L14", "刪除");
define("TRACKBACK_L15", "Trackbacks deleted.");


?>