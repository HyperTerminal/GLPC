<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/usertheme_menu/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/03/21 14:54:59 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_UMENU_THEME_1", "設置佈景主題");
define("LAN_UMENU_THEME_2", "選擇佈景主題");
define("LAN_UMENU_THEME_3", "使用者:");
define("LAN_UMENU_THEME_4", "把使用者可能挑選的佈景主題設成『可用』");
define("LAN_UMENU_THEME_5", "更新");
define("LAN_UMENU_THEME_6", "使用者可用的佈景主題");
define("LAN_UMENU_THEME_7", "可選擇「佈景主題」的使用者等級");


?>