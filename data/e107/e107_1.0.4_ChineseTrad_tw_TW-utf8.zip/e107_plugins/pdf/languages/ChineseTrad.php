<?php
define("PDF_PLUGIN_LAN_1","PDF");
define("PDF_PLUGIN_LAN_2","PDF創制支援");
define("PDF_PLUGIN_LAN_3","PDF");
define("PDF_PLUGIN_LAN_4","此外掛已可使用");

define("PDF_LAN_1","PDF");
define("PDF_LAN_2","PDF 徧好設定");
define("PDF_LAN_3","啟用");
define("PDF_LAN_4","停用");
define("PDF_LAN_5","左頁邊距");
define("PDF_LAN_6","右頁邊距");
define("PDF_LAN_7","上頁邊距");
define("PDF_LAN_8","字型family");
define("PDF_LAN_9","預設字型大小");
define("PDF_LAN_10","網站標題字型大小");
define("PDF_LAN_11","網址字型大小");
define("PDF_LAN_12","頁碼字型大小");
define("PDF_LAN_13","在PDF顯示網站logo?");
define("PDF_LAN_14","在PDF顯示網站名稱??");
define("PDF_LAN_15","是否在PDF檔顯示網址?");
define("PDF_LAN_16","是否在PDF檔顯示頁碼?");
define("PDF_LAN_17","更新");
define("PDF_LAN_18","PDF設定已成功更新");
define("PDF_LAN_19","頁");
define("PDF_LAN_20","錯誤報告中...");

?>