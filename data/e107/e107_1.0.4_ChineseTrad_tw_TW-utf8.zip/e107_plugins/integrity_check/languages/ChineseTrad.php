<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/integrity_check/languages/ChineseTrad.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/19 15:13:57 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("Integ_01", "儲存完成");
define("Integ_02", "儲存失敗");
define("Integ_03", "遺失檔案:");
define("Integ_04", "CRC-錯誤:");
define("Integ_05", "無法開啟檔案...");
define("Integ_06", "確認檔案完整性");
define("Integ_07", "沒有有效的檔案");
define("Integ_08", "確認完整性");
define("Integ_09", "新增 sfv-檔案");
define("Integ_10", "選擇的資料夾 <u>不能</u> 儲存於 crc-檔案.");
define("Integ_11", "檔名:");
define("Integ_12", "新增 sfv 檔案");
define("Integ_13", "完整性檢查中");
define("Integ_14", "SFV-Creation 不可能, 因為該資料夾 ".e_PLUGIN."integrity_check/<b>{output}</b> 無法寫入. 請 chmod 該資料夾為 777!");
define("Integ_15", "所有檔案已經完成檢查並確認可用!");
define("Integ_16", "沒有有效的 core-crc-files");
define("Integ_17", "沒有有效的plugin-crc-files");
define("Integ_18", "新增外掛-CRC-File");
define("Integ_19", "Core-Checksum-Files");
define("Integ_20", "Plugin-Checksum-Files");
define("Integ_21", "選擇想新增 crc-file 的外掛程式");
define("Integ_22", "使用 gzip");
define("Integ_23", "僅確認安裝風格");
define("Integ_24", "管理首頁");
define("Integ_25", "離開管理控制台");
define("Integ_26", "載入網站於正常標題");
define("Integ_27", "使用檔案檢查來確認核心檔案");
define("Integ_30", "為了減少 cpu的負擔 , 您可以在 1 - 10 步驟中檢查。");
define("Integ_31", "步驟:");
define("Integ_32", "有一個檔案名稱為 <b>log_crc.txt</b> 於您的 crc-folder. 請刪除! (或是重新整理)");
define("Integ_33", "有一個檔案名稱為 <b>log_miss.txt</b> 於您的  crc-folder. 請刪除! (或是重新整理)");
define("Integ_34", "您的 Crc-folder 無法寫入!");
define("Integ_35", "因為下列理由您必須允許選擇 <b>一</b>步驟 :");
define("Integ_36", "如果您不想等待超過五秒鐘才跳到下一步，請點選這裡：");
define("Integ_37", "點選我");
define("Integ_38", "剩下 <u><i>{counts}</i></u> 行待完成...");
define("Integ_39", "請刪除檔案:<br />".e_PLUGIN."integrity_check/<u><i>do_core_file.php</i></u>!<br />已經過期並不在釋出了...");


?>