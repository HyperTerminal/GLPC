<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/content/languages/ChineseTrad/lan_content_frontpage.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:50:47 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("CONT_FP_1", "內容分區");
define("CONT_FP_2", "主要頁面");


?>