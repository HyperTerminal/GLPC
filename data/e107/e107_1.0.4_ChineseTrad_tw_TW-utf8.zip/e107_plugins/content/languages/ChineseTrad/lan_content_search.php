<?php
/*
+---------------------------------------------------------------+
|        e107 website system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/content/languages/ChineseTrad/lan_content_search.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/18 22:51:22 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "內容");
define("CONT_SCH_LAN_2", "所有內容分區");
define("CONT_SCH_LAN_3", "回覆該項目");
define("CONT_SCH_LAN_4", "於");


?>