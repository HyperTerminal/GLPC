<?php
define("LDAPLAN_1", "伺服器位址");
define("LDAPLAN_2", "基本網域<br />If LDAP - 輸入基本網域<br />假如要新增 - 輸入網址");
define("LDAPLAN_3", "LDAP 瀏覽中的會員<br />會員將可搜尋該目錄所有內容.");
define("LDAPLAN_4", "LDAP 瀏覽中的密碼<br />瀏覽中的會於的 LDAP 密碼.");
define("LDAPLAN_5", "LDAP 版本");
define("LDAPLAN_6", "設定 LDAP 路徑");
define("LDAPLAN_7", "eDirectory 搜尋過濾器:");
define("LDAPLAN_8", "這將會使用於確定帳號於正確的樹, <br />ie '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "目前搜尋過濾器將會是:");
define("LDAPLAN_10", "完成更新設定");
define("LDAPLAN_11", "警告:  假如該 ldap module 目前沒有使用, 您設定的 auth method 於 LDAP將沒有功能!");
define("LDAPLAN_12", "伺服器類型");
define("LDAPLAN_13", "更新設定");
?>