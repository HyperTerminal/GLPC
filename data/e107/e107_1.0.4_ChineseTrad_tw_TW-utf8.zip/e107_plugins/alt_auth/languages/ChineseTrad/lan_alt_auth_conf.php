<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system ChineseTrad Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/ChineseTrad/lan_alt_auth_conf.php $
|        $Revision: 1.0 $
|        $Id: 2012/04/06 22:26:24 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("LAN_ALT_2", "更新設定");
define("LAN_ALT_3", "使用間隔性的認證方式");
define("LAN_ALT_4", "設定參數於");
define("LAN_ALT_5", "設定認證參數");
define("LAN_ALT_6", "失敗連結動作");
define("LAN_ALT_7", "假如連線有間隔性的失敗, 該如何處理?");
define("LAN_ALT_8", "會員沒有找到動作");
define("LAN_ALT_9", "假如沒找到相關會員這動作有間隔性,該如何處理?");
define("LAN_ALT_10", "登入失敗");
define("LAN_ALT_11", "使用 e107 使用者資料表");
define("LAN_ALT_PAGE", "多重驗證");


?>