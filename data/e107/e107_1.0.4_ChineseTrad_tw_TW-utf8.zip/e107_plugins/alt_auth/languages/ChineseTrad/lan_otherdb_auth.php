<?php
define("OTHERDB_LAN_1", "資料庫種類:");
define("OTHERDB_LAN_2", "伺服器:");
define("OTHERDB_LAN_3", "帳號:");
define("OTHERDB_LAN_4", "密碼:");
define("OTHERDB_LAN_5", "資料庫");
define("OTHERDB_LAN_6", "資料表");
define("OTHERDB_LAN_7", "帳號欄位:");
define("OTHERDB_LAN_8", "密碼欄位:");
define("OTHERDB_LAN_9", "密碼模式:");
define("OTHERDB_LAN_10", "設定 otherdb auth");
define("OTHERDB_LAN_11", "** 如果您使用一個e107的資料庫，下列欄位不是必須的");


?>