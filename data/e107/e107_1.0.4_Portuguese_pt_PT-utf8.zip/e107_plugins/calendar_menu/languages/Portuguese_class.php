<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'não');
define('EC_LAN_RECUR_01', 'anual');
define('EC_LAN_RECUR_02', 'bianual');
define('EC_LAN_RECUR_03', 'trimestral');
define('EC_LAN_RECUR_04', 'mensal');
define('EC_LAN_RECUR_05', 'quatro semanas');
define('EC_LAN_RECUR_06', 'quinzenal');
define('EC_LAN_RECUR_07', 'semanal');
define('EC_LAN_RECUR_08', 'diário');
define('EC_LAN_RECUR_100', 'Domingo no mês');
define('EC_LAN_RECUR_101', 'Segunda-feira no mês');
define('EC_LAN_RECUR_102', 'Terça-feira no mês');
define('EC_LAN_RECUR_103', 'Quarta-feira no mês');
define('EC_LAN_RECUR_104', 'Quinta-feira no mês');
define('EC_LAN_RECUR_105', 'Sexta-feira no mês');
define('EC_LAN_RECUR_106', 'Sábado no mês');

define('EC_LAN_RECUR_1100', 'Primeiro');
define('EC_LAN_RECUR_1200', 'Segundo');
define('EC_LAN_RECUR_1300', 'Terceiro');
define('EC_LAN_RECUR_1400', 'Quarto');


// Notify
define('NT_LAN_EC_1', 'Evento del Calendário de Eventos');
define('NT_LAN_EC_2', 'Evento atualizado!');
define('NT_LAN_EC_3', 'Atualizado por');
define('NT_LAN_EC_4', 'Endereço IP');
define('NT_LAN_EC_5', 'Mensagem');
define('NT_LAN_EC_6', 'Calendário de Eventos - Evento añadido');
define('NT_LAN_EC_7', 'Novo evento publicado');
define('NT_LAN_EC_8', 'Calendário de Eventos - Evento modificado');


// Log messages
define('EC_ADM_01', 'Calendário de Eventos - adicionar evento');
define('EC_ADM_02', 'Calendário de Eventos - editar evento');
define('EC_ADM_03', 'Calendário de Eventos - apagar evento');
define('EC_ADM_04', 'Calendário de Eventos - Apagar vários');
define('EC_ADM_05', 'Calendário de Eventos - Adicionar vários');
define('EC_ADM_06', 'Calendário de Eventos - Opções Principais atualizadas');
define('EC_ADM_07', 'Calendário de Eventos - FE opções alteradas');
define('EC_ADM_08', 'Calendário de Eventos - Categoria adicionada');
define('EC_ADM_09', 'Calendário de Eventos - Categoria editada');
define('EC_ADM_10', 'Calendário de Eventos - Categoria apagada');
define('EC_ADM_11', 'Calendário de Eventos - Eventos antigos apagados');

?>