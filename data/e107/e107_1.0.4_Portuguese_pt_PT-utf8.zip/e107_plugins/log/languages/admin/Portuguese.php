<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ADSTAT_ON", "Sim");
define("ADSTAT_OFF", "Não");
define("ADSTAT_L1", "Este plugin registra todas as visitas ao seu site, e cria opções de estatísticas detalhadas baseadas na informações recolhidas.");
define("ADSTAT_L2", "O registro de estatísticas foi instalado com sucesso. Para configurar, por favor vá as opções de configuração e clique em opções.<br /><b>Deve definir as permissões da pasta e107_plugins/log/logs para 777 (chmod 777)</b>");
define("ADSTAT_L3", "Registro de Estatísticas");
define("ADSTAT_L4", "Activar registro de estatísticas");
define("ADSTAT_L5", "Tipos de estatísticas");
define("ADSTAT_L6", "Navegadores");
define("ADSTAT_L7", "Sistemas Operacionais");
define("ADSTAT_L8", "Resoluções de tela/Quantidade de cores");
define("ADSTAT_L9", "Países/domínios visitados de");
define("ADSTAT_L10", "Referências");
define("ADSTAT_L11", "Palavras de busca");
define("ADSTAT_L12", "Reiniciar estatísticas");
define("ADSTAT_L13", "isto apagará as estatísticas - cuidado!");
define("ADSTAT_L14", "Contagem de páginas");
define("ADSTAT_L15", "Actualizar as Preferências de Estatísticas");
define("ADSTAT_L16", "Preferências de Estatísticas do Sitio");
define("ADSTAT_L17", "Preferências da estatística actualizada");
define("ADSTAT_L18", "Permitir acesso à página principal de estatísticas a ...");
define("ADSTAT_L19", "Visitantes recentes");
define("ADSTAT_L20", "Contar visitas do admin");
define("ADSTAT_L21", "Máximo de registros a mostrar na página de estatísticas");
define("ADSTAT_L22", "Iniciar rotina de actualização");
define("ADSTAT_L23", "registros de uma versão anterior do e107 foram detectados, atualize-os clicando aqui");
define("ADSTAT_L24", "Ir para o script de actualização");
define("ADSTAT_L25", "Reiniciar estatísticas selecionadas");
define("ADSTAT_L26", "Remover registros de páginas");
define("ADSTAT_L27", "se as suas estatísticas têm páginas incorretas, pode removê-las aqui");
define("ADSTAT_L28", "Abrir página");
define("ADSTAT_L29", "Nome da página");
define("ADSTAT_L30", "Selecione para remover");
define("ADSTAT_L31", "Remover páginas selecionadas");
define("ADSTAT_L32", "Limpeza da Página");
define("ADSTAT_L33", "Configurar Log de Estatísticas");
define("ADSTAT_L34", "Estatísticas do Site");
define("ADSTAT_L35", "Ver informações compactas do navegador nas estatísticas");
define("ADSTAT_L38", "Você precisa fazer CHMOD 777 na pasta e107_plugins/log/logs para aceitar escrita");


?>