<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("TRACKBACK_L1", "Configurar Trackback");
define("TRACKBACK_L2", "Este plugin permite usar trackback nas suas notícias.");
define("TRACKBACK_L3", "O Trackback está instalado e activado.");
define("TRACKBACK_L4", "Preferências de trackback salvas.");
define("TRACKBACK_L5", "Sim");
define("TRACKBACK_L6", "Não");
define("TRACKBACK_L7", "Activar trackbacks");
define("TRACKBACK_L8", "Texto da URL do trackback");
define("TRACKBACK_L9", "Salvar Preferências");
define("TRACKBACK_L10", "Preferências de Trackback");
define("TRACKBACK_L11", "Endereço trackback para esta mensagem:");
define("TRACKBACK_L12", "Não existe trackbacks para este ítem");
define("TRACKBACK_L13", "Moderar trackbacks");
define("TRACKBACK_L14", "Apagar");
define("TRACKBACK_L15", "Trackbacks apagados.");

?>