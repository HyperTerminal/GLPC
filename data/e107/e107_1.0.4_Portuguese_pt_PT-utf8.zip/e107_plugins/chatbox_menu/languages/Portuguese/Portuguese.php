<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CHATBOX_L1", "Não há como aceitar postagens deste nome de usuário - se este é o seu nome de usuário, favor fazer login para postar.");
define("CHATBOX_L2", "Área de Chat");
define("CHATBOX_L3", "Você tem de Iníciar Sessão para publicar comentários em nosso sitio.<br />Faz favor, se ainda não está registado, clique <a href='".e_BASE."signup.php'>AQUI</a> para se registar.");
define("CHATBOX_L4", "Enviar");
define("CHATBOX_L5", "Limpar");
define("CHATBOX_L6", "[bloqueado pelo admin]");
define("CHATBOX_L7", "Desbloqueado");
define("CHATBOX_L8", "Informações");
define("CHATBOX_L9", "Bloquear");
define("CHATBOX_L10", "Apagar");
define("CHATBOX_L11", "Não há mensagens ainda.");
define("CHATBOX_L12", "Visualizar todas as publicações");
define("CHATBOX_L13", "Moderar área de chat");
define("CHATBOX_L14", "Emoticons");
define("CHATBOX_L15", "Publicação muito extensa, ou campo vazio enviado");
define("CHATBOX_L16", "Anônimo");
define("CHATBOX_L17", "Publicação duplicada");
define("CHATBOX_L18", "Moderar mensagens da Área de Chat");
define("CHATBOX_L19", "Você poderá postar apenas a cada ".FLOODTIMEOUT." segundos");
define("CHATBOX_L20", "Área de Chat (todas as mensagens)");
define("CHATBOX_L21", "Publicações no Chat");
define("CHATBOX_L22", "em");
define("CHATBOX_L23", "Erro!");
define("CHATBOX_L24", "Você não tem as permissões corretas para visualizar esta página.");
define("CHATBOX_L25", "[ esta publicação foi bloqueada pelo admin ]");
define("NT_LAN_CB_1", "Eventos da Área de Chat");
define("NT_LAN_CB_2", "Mensagem publicada");
define("NT_LAN_CB_3", "Postado por");
define("NT_LAN_CB_4", "Endereço IP");
define("NT_LAN_CB_5", "Mensagem");
define("NT_LAN_CB_6", "Mensagem publicadas na Área de Chat");


?>