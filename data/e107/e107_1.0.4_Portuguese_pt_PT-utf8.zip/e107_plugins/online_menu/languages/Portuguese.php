<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ONLINE_L1", "Visitantes:");
define("ONLINE_L2", "Membros:");
define("ONLINE_L3", "Nesta página:");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Membros");
define("ONLINE_L6", "Mais novo");
define("TRACKING_MESSAGE", "O rastreador de utilizadores online está desativado, favor activá-lo [link=".e_ADMIN."users.php?options]aqui[/link][br]");


?>