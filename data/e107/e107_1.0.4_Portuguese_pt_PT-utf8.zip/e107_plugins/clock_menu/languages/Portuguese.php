<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CLOCK_MENU_L1", "Configuração do Menu Clock salva");
define("CLOCK_MENU_L2", "Subtítulo");
define("CLOCK_MENU_L3", "Atualizar Preferências");
define("CLOCK_MENU_L4", "Configurações do Clock Menu");
define("CLOCK_MENU_L5", "Segunda-feira,");
define("CLOCK_MENU_L6", "Terça-feira,");
define("CLOCK_MENU_L7", "Quarta-feira,");
define("CLOCK_MENU_L8", "Quinta-feira,");
define("CLOCK_MENU_L9", "Sexta-feira,");
define("CLOCK_MENU_L10", "Sábado,");
define("CLOCK_MENU_L11", "Domingo,");
define("CLOCK_MENU_L12", "de Janeiro de");
define("CLOCK_MENU_L13", "de Fevereiro de");
define("CLOCK_MENU_L14", "de Março de");
define("CLOCK_MENU_L15", "de Abril de");
define("CLOCK_MENU_L16", "de Maio de");
define("CLOCK_MENU_L17", "de Junho de");
define("CLOCK_MENU_L18", "de Julho de");
define("CLOCK_MENU_L19", "de Agosto de");
define("CLOCK_MENU_L20", "de Setembro de");
define("CLOCK_MENU_L21", "de Outubro de");
define("CLOCK_MENU_L22", "de Novembro de");
define("CLOCK_MENU_L23", "de Dezembro de");
define("CLOCK_MENU_L24", "");

?>