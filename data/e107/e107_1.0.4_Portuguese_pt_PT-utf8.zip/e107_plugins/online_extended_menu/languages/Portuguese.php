<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("ONLINE_EL1", "Visitantes:");
define("ONLINE_EL2", "Membros:");
define("ONLINE_EL3", "Nesta página:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Membros");
define("ONLINE_EL6", "Membro + Novo");
define("ONLINE_EL7", "está em");
define("ONLINE_EL8", "Maior nº online:");
define("ONLINE_EL9", "em");
define("ONLINE_TRACKING_MESSAGE", "O rastreamento de utilizadores online está desabilitado actualmente, por favor habilite-o acessando [link=".e_ADMIN."users.php?options]aqui[/link][br]");


?>