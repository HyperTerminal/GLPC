<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("POLL_ADLAN01", "Inquéritos");
define("POLL_ADLAN02", "O plugin de inquéritos permite-lhe definir inquéritos tanto no menu como nas publicações no fórum.");
define("POLL_ADLAN03", "Configurar Inquérito");
define("POLL_ADLAN04", "O plugin de inquéritos foi instalado com sucesso. Para adicionar inquéritos, clique no ícone de inquéritos na área de admin, e lembre-se de activar o menu na área de menus.");
define("POLL_ADLAN05", "inquérito:");
define("POLL_ADLAN06", "Tema do Fórum:");
define("POLL_ADLAN07", "Tipo");
define("POLLAN_MENU_CAPTION", "Inquérito");
define("POLLAN_1", "Inquéritos existentes");
define("POLLAN_2", "Criar/Editar Inquérito");
define("POLLAN_3", "Pergunta do inquérito");
define("POLLAN_4", "Opções");
define("POLLAN_5", "Editar");
define("POLLAN_6", "Apagar");
define("POLLAN_7", "Não há inquéritos ainda.");
define("POLLAN_8", "Adicionar outra opção");
define("POLLAN_9", "Permitir várias escolhas?");
define("POLLAN_10", "sim");
define("POLLAN_11", "não");
define("POLLAN_12", "Mostrar resultados");
define("POLLAN_13", "depois de votar");
define("POLLAN_14", "clicando no link de ver resultados - os comentários precisam estar activados para usar esta opção");
define("POLLAN_15", "Permitir votos nesta inquérito");
define("POLLAN_16", "Método de gravação de votos");
define("POLLAN_17", "cookie");
define("POLLAN_18", "Endereço IP");
define("POLLAN_19", "ID do utilizador (somente membros poderão votar)");
define("POLLAN_20", "Permitir comentários nesta inquérito?");
define("POLLAN_21", "Pré-visualizar novamente");
define("POLLAN_22", "Actualizar Inquérito");
define("POLLAN_23", "Criar Inquérito");
define("POLLAN_24", "Pré-visualizar");
define("POLLAN_25", "Limpar formulário");
define("POLLAN_26", "votos");
define("POLLAN_27", "comentários");
define("POLLAN_28", "Inquérito anteriores");
define("POLLAN_29", "publicado por");
define("POLLAN_30", "Enviar");
define("POLLAN_31", "votos");
define("POLLAN_32", "Clique aqui para ver os resultados");
define("POLLAN_33", "Não há inquéritos anteriores.");
define("POLLAN_34", "Título");
define("POLLAN_35", "Publicado por");
define("POLLAN_36", "Activo");
define("POLLAN_37", "activa de");
define("POLLAN_38", "para");
define("POLLAN_39", "Obrigado por votar!");
define("POLLAN_40", "Clique aqui para ver os resultados");
define("POLLAN_41", "Esta inquérito é restrita a membros somente");
define("POLLAN_42", "Esta inquérito é restrita a administradores somente");
define("POLLAN_43", "Você não tem permissão para votar nesta inquérito");
define("POLLAN_44", "Apagar inquérito?");
define("POLLAN_45", "inquérito actualizada com sucesso");
define("POLLAN_46", "Campo(s) deixado(s) em branco");


?>