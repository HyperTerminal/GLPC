<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("GSLAN_Name", "Mapa do Sítio");
define("GSLAN_1", "Hiperligações do Sítio");
define("GSLAN_2", "Importar?");
define("GSLAN_3", "Tipo");
define("GSLAN_4", "Nome");
define("GSLAN_5", "Url");
define("GSLAN_6", "Marque os links para importá-los...");
define("GSLAN_7", "Importar Links");
define("GSLAN_8", "Importar com:");
define("GSLAN_9", "Prioridade");
define("GSLAN_10", "Frequência");
define("GSLAN_11", "sempre");
define("GSLAN_12", "de hora em hora");
define("GSLAN_13", "diariamente");
define("GSLAN_14", "semanalmente");
define("GSLAN_15", "mensalmente");
define("GSLAN_16", "anualmente");
define("GSLAN_17", "nunca");
define("GSLAN_18", "Importar links marcados");
define("GSLAN_19", "Mapa do Site pelo Google");
define("GSLAN_20", "Listando");
define("GSLAN_21", "Instruções");
define("GSLAN_22", "Criar Nova Entrada");
define("GSLAN_23", "Importar");
define("GSLAN_24", "Entradas do Mapa do Site pelo Google");
define("GSLAN_25", "Nome");
define("GSLAN_26", "URL");
define("GSLAN_27", "Última Modificação");
define("GSLAN_28", "Freqüência");
define("GSLAN_29", "Mapa do Site pelo Google Configuração");
define("GSLAN_30", "Ordem para mostrar na tela");
define("GSLAN_31", "Visível para");
define("GSLAN_32", "Como usar mapas de site do Google");
define("GSLAN_33", "Instruções para o GSiteMap");
define("GSLAN_34", "Primeiro, crie as hiperligações que você deseja ter listados no seu sitemap. Você pode importar a maioria das hiperligações clicando no botão 'Importar' botão à direita");
define("GSLAN_35", "Se você escolheu importar seus links, clique em 'Importar' e então marque os links que você quer importar");
define("GSLAN_36", "Você pode também digitar links individuais manualmente clicando no 'Criar Nova Entrada'");
define("GSLAN_37", "Depois de ter algumas entradas, vá para [URL], e insira a seguinte URL:[URL2] Se o url acima não olha direito para você, por favor, certifique-se de URL do seu site está correto no admin - [preferências]");
define("GSLAN_38", "Para obter mais informações sobre o Google protocolo Sitemap, vá para [URL].");
define("GSLAN_39", "Não há links no mapa do site - importar links do site?");
define("GSLAN_40", "Entradas no Mapa do Site do Google");


?>