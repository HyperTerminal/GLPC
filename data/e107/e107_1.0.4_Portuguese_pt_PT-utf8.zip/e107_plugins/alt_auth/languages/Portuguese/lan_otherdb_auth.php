<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Tipo de banco de dados:");
define("OTHERDB_LAN_2", "Servidor:");
define("OTHERDB_LAN_3", "Utilizador:");
define("OTHERDB_LAN_4", "Senha:");
define("OTHERDB_LAN_5", "Banco de dados");
define("OTHERDB_LAN_6", "Tabela");
define("OTHERDB_LAN_7", "Campo de Utilizador:");
define("OTHERDB_LAN_8", "Campo da senha:");
define("OTHERDB_LAN_9", "Método da senha:");
define("OTHERDB_LAN_10", "Configurar plugin 'otherdb auth' (outro tipo de autenticação ao banco de dados)");
define("OTHERDB_LAN_11", "** Os seguintes campos não são requeridos se você estiver usando um banco de dados do e107");


?>