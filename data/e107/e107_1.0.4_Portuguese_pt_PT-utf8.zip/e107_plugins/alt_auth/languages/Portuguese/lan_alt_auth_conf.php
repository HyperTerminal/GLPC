<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_ALT_2", "Atualizar Configurações");
define("LAN_ALT_3", "Escolher tipo de autorização alternativa");
define("LAN_ALT_4", "Configurar parâmetros para");
define("LAN_ALT_5", "Configurar parâmetros de autorização");
define("LAN_ALT_6", "Erro na ação de conexão");
define("LAN_ALT_7", "Se há um erro na conexão de método alternativo, o que fazer?");
define("LAN_ALT_8", "Acção para utilizador não encontrado");
define("LAN_ALT_9", "Se o nome do utilizador não for encontrado usando métodos alternativos, o que fazer?");
define("LAN_ALT_10", "Erro no inicio de sessão");
define("LAN_ALT_11", "Usar tabela de utilizador de e107");
define("LAN_ALT_PAGE", "Autenticação alternativa");


?>