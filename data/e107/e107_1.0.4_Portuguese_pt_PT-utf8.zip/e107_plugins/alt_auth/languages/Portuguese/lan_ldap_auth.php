<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LDAPLAN_1", "Endereço do Servidor");
define("LDAPLAN_2", "Base de Nomes de Domínio ou Domínio<br />Se LDAP - Digite a Base de Domínio<br />Se AD - Digite domínio");
define("LDAPLAN_3", "LDAP Usuário navegando<br />Contexto completo de quem é o usuário que está apto a procurar no diretório");
define("LDAPLAN_4", "LDAP Senha para navegar<br />Senha para o usuário que vai navegar na LDAP.");
define("LDAPLAN_5", "Versão da LDAP");
define("LDAPLAN_6", "Configurar autorização para LDAP");
define("LDAPLAN_7", "Filtro de busca eDiretório:");
define("LDAPLAN_8", "Isto será usado para certificar que o usuário está na árvore correta, <br />ex. '(objectclass=inetOrgPerson)'");
define("LDAPLAN_9", "Filtro de busca actual será:");
define("LDAPLAN_10", "Configurações actualizadas");
define("LDAPLAN_11", "ATENÇÃO: Parece que o módulo ldap não está disponível atualmente, configurar seu método de autenticação para LDAP provavelmente não funcionará!");
define("LDAPLAN_12", "Tipo de servidor");
define("LDAPLAN_13", "Actualizar configurações");


?>