<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LOGIN_MENU_L1", "Utilizador:");
define("LOGIN_MENU_L2", "Senha:");
define("LOGIN_MENU_L3", "Registrar");
define("LOGIN_MENU_L4", "Esqueceu a senha?");
define("LOGIN_MENU_L5", "Bem-vindo");
define("LOGIN_MENU_L6", "Relembrar senha");
define("LOGIN_MENU_L7", "Erro de conexão por identificação de usuário (possível cookie corrompido).<br />Por favor <a href=\"".e_BASE."index.php?logout\">clique aqui</a> para destruí-lo.");
define("LOGIN_MENU_L8", "Desconectar");
define("LOGIN_MENU_L9", "Erro de acesso");
define("LOGIN_MENU_L10", "O sitio está em manutenção - isso significa que os membros do sites serão redirecionados para sitedown.php. Para alterar esse estado, vá em admin/manutenção.");
define("LOGIN_MENU_L11", "Área de Admin");
define("LOGIN_MENU_L12", "Preferências");
define("LOGIN_MENU_L13", "Perfil");
define("LOGIN_MENU_L14", "novo tema");
define("LOGIN_MENU_L15", "novos temas");
define("LOGIN_MENU_L16", "postagem no chat");
define("LOGIN_MENU_L17", "postagens no chat");
define("LOGIN_MENU_L18", "comentário");
define("LOGIN_MENU_L19", "comentários");
define("LOGIN_MENU_L20", "postagem no fórum");
define("LOGIN_MENU_L21", "postagens no fórum");
define("LOGIN_MENU_L22", "novo membro do sitio");
define("LOGIN_MENU_L23", "novos membros do sitio");
define("LOGIN_MENU_L24", "Clique aqui para ver a lista de novos temas");
define("LOGIN_MENU_L25", "Desde a sua útima visita");
define("LOGIN_MENU_L26", "não");
define("LOGIN_MENU_L27", "e");
define("LOGIN_MENU_L28", "Iniciar Sessão");
define("LOGIN_MENU_L29", "novo artigo");
define("LOGIN_MENU_L30", "novos artigos");
define("LOGIN_MENU_L31", "Mostrar novas notícias");
define("LOGIN_MENU_L32", "Mostrar novos artigos");
define("LOGIN_MENU_L33", "Mostrar novas mensagens de chat");
define("LOGIN_MENU_L34", "Mostrar novos comentários");
define("LOGIN_MENU_L35", "Mostrar novas mensagens no fórum");
define("LOGIN_MENU_L36", "Mostrar novos membros cadastrados");
define("LOGIN_MENU_L39", "Sair da Administração");
define("LOGIN_MENU_L40", "Re-enviar e-mail de ativação");
define("LOGIN_MENU_L41", "Configurações do Menu de Login");

?>