<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Suporte à criação de arquivo PDF");
define("PDF_PLUGIN_LAN_3", "Configurar PDF");
define("PDF_PLUGIN_LAN_4", "Este plugin está pronto para ser usado.");
define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "Preferências de PDF");
define("PDF_LAN_3", "sim");
define("PDF_LAN_4", "não");
define("PDF_LAN_5", "margem esquerda da página");
define("PDF_LAN_6", "margem direita da página");
define("PDF_LAN_7", "margem do topo da página");
define("PDF_LAN_8", "família de fonte");
define("PDF_LAN_9", "tamanho padrão da fonte");
define("PDF_LAN_10", "tamanho da fonte para o nome do site");
define("PDF_LAN_11", "tamanho da fonte para a url da página");
define("PDF_LAN_12", "tamanho da fonte para o número da página");
define("PDF_LAN_13", "mostrar logo do site no pdf?");
define("PDF_LAN_14", "mostrar nome do site no pdf?");
define("PDF_LAN_15", "mostrar o nome do criador da página (url) no pdf?");
define("PDF_LAN_16", "mostrar número de página no pdf?");
define("PDF_LAN_17", "actualizar");
define("PDF_LAN_18", "Preferências do PDF atualizadas com sucesso");
define("PDF_LAN_19", "Página");
define("PDF_LAN_20", "aviso de erro");

?>