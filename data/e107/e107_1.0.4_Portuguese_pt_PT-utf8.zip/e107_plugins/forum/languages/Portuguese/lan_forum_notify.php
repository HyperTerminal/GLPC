<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NT_LAN_FT_1", "Eventos de Fórum");
define("NT_LAN_FO_1", "Fórum - Novo tema");
define("NT_LAN_MP_1", "Fórum - Nova publicação");
define("NT_LAN_FD_1", "Fórum - Tema apagado");
define("NT_LAN_FP_1", "Fórum - publicação apagada");
define("NT_LAN_FM_1", "Fórum - Tema movido");
define("NT_LAN_FO_3", "Fórum - Tema criado por");
define("NT_LAN_FO_4", "Nome do Fórum");
define("NT_LAN_FO_5", "Assunto");
define("NT_LAN_FO_6", "Mensagem");
define("NT_LAN_FO_7", "Fórum - Novo tema criado");
define("NT_LAN_MP_3", "Fórum - publicação criada por");
define("NT_LAN_MP_4", "Nome do Fórum");
define("NT_LAN_MP_6", "Mensagem");
define("NT_LAN_MP_7", "Novo Fórum - publicação criada");
define("NT_LAN_FD_3", "Fórum - Tema criado por");
define("NT_LAN_FD_4", "Nombre do Fórum");
define("NT_LAN_FD_5", "Assunto");
define("NT_LAN_FD_6", "Mensagem");
define("NT_LAN_FD_7", "Fórum - Tema apagado");
define("NT_LAN_FD_8", "Fórum - Tema apagado por");
define("NT_LAN_FP_3", "Fórum - publicação criada por");
define("NT_LAN_FP_4", "Nombre do Fórum");
define("NT_LAN_FP_6", "Mensagem");
define("NT_LAN_FP_7", "Fórum - publicação apagada");
define("NT_LAN_FP_8", "Fórum -  publicação apagada por");
define("NT_LAN_FM_3", "Fórum - Tema criado por");
define("NT_LAN_FM_4", "Anterior");
define("NT_LAN_FM_5", "Seguinte");
define("NT_LAN_FM_6", "Anterior (fonte) nome de Fórum ");
define("NT_LAN_FM_7", "Seguinte (próximo) nome de Fórum");
define("NT_LAN_FM_8", "Fórum - Tema movido");
define("NT_LAN_FM_9", "Fórum - Tema movido por");


?>