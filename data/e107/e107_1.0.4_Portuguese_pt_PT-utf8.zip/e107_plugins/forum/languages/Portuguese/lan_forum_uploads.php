<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Uploads do Fórum");
define("FRMUP_1", "Arquivos enviados no fórum");
define("FRMUP_2", "Arquivo apagado");
define("FRMUP_3", "Erro: Impossível apagar este arquivo");
define("FRMUP_4", "Apagamento do arquivo");
define("FRMUP_5", "Nome do arquivo");
define("FRMUP_6", "Resultado");
define("FRMUP_7", "Encontrado no tópico");
define("FRMUP_8", "NÃO ENCONTRADO");
define("FRMUP_9", "Não há arquivos enviados");
define("FRMUP_10", "Apagar");

?>