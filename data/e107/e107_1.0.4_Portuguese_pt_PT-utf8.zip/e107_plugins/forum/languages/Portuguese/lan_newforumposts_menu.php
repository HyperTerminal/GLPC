<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NFP_1", "Todas as últimas postagens estão fora do alcance de sua classe de utilizadores, não há como exibir.");
define("NFP_2", "Não há postagens ainda");
define("NFP_3", "Configuração do menu de Novas Postagens no Fórum salvo");
define("NFP_4", "Título");
define("NFP_5", "Número de postagens a mostrar?");
define("NFP_6", "Número de caracteres a mostrar?");
define("NFP_7", "Fixar postagens muito compridas?");
define("NFP_8", "Mostrar tópicos originais no menu?");
define("NFP_9", "Actualizar configurações do menu");
define("NFP_10", "Configurações do Menu de Novas Postagens no Fórum");
define("NFP_11", "Publicado por");
define("NFP_12", "'Idade' máxima (tempo de existência) para postagens serem mostradas");
define("NFP_13", "Usar zero em um site mais tranqüilo; configurar o valor em dias irá reduzir o tempo de busca no banco de dados em um site muito ocupado");

?>