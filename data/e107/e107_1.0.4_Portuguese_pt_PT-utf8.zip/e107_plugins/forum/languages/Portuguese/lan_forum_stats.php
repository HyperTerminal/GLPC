<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("e_PAGETITLE", "Estatísticas do Fórum");

define("FSLAN_1", "Geral");
define("FSLAN_2", "Fórum aberto");
define("FSLAN_3", "Aberto há");
define("FSLAN_4", "Total de postagens");
define("FSLAN_5", "Tópicos do fórum");
define("FSLAN_6", "Respostas do fórum");
define("FSLAN_7", "Tópicos do fórum visualizados");
define("FSLAN_8", "Tamanho da base de dados (tabelas do fórum apenas)");
define("FSLAN_9", "Média de tamanho de célula na tabela do fórum");
define("FSLAN_10", "Tópicos mais ativos");
define("FSLAN_11", "Rank");
define("FSLAN_12", "Tópico");
define("FSLAN_13", "Respostas");
define("FSLAN_14", "Iniciado por");
define("FSLAN_15", "Data");
define("FSLAN_16", "Tópicos mais visualizados");
define("FSLAN_17", "Visualizados");
define("FSLAN_18", "Maiores postadores");
define("FSLAN_19", "Nome");
define("FSLAN_20", "Postagens");
define("FSLAN_21", "Maiores iniciadores de tópicos");
define("FSLAN_22", "Maiores postadores de respostas");
define("FSLAN_23", "Estatísticas do Fórum");
define("FSLAN_24", "Média de postagens por dia");

?>