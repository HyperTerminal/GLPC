<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CM_L1", "Não há comentários ainda.");
define("CM_L2", "");
define("CM_L3", "Subtítulo");
define("CM_L4", "Número de comentários a mostrar?");
define("CM_L5", "Número de caracteres a mostrar?");
define("CM_L6", "Postagem fixa para comentários muito extensos?");
define("CM_L7", "Mostrar títulos originais das notícias no menu?");
define("CM_L8", "Configuração do Menu Novos Comentários");
define("CM_L9", "Atualizar Configurações do Menu");
define("CM_L10", "Configuração do menu comentários salva.");
define("CM_L11", "em");
define("CM_L12", "Re:");
define("CM_L13", "Publicado por");


?>