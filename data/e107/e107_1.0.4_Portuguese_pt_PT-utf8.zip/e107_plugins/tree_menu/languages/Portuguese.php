<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("TREE_L1", "Configurar Menu");
define("TREE_L2", "Atualizar Preferências do Menu");
define("TREE_L3", "Configuração do Menu salva.");
define("TREE_L4", "Sim");
define("TREE_L5", "Não");
define("TREE_L6", "Classe CSS que deseja usar para links padrão");
define("TREE_L7", "Classe CSS que deseja usar para links que foram clicados");
define("TREE_L8", "Classe CSS a usar para links já abertos");
define("TREE_L9", "Usar classe de espaçamento entre links principais");

?>