<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("BANNER_MENU_L1", "Publicidade");
define("BANNER_MENU_L2", "As Configurações do menu de anúncios foram salvas");

//v.617
define("BANNER_MENU_L3", "Título");
define("BANNER_MENU_L4", "Campanha");
define("BANNER_MENU_L5", "Configuração do Menu Banner");
define("BANNER_MENU_L6", "escolha campanhas a mostrar no menu");
define("BANNER_MENU_L7", "campanhas disponíveis");
define("BANNER_MENU_L8", "selecionar campanhas");
define("BANNER_MENU_L9", "remover selecção");
define("BANNER_MENU_L10", "como as campanhas selecionadas devem ser mostradas?");
define("BANNER_MENU_L11", "escolha o tipo...");
define("BANNER_MENU_L12", "uma campanha em um único menu");
define("BANNER_MENU_L13", "todas as campanhas selecionadas em um único menu");
define("BANNER_MENU_L14", "todas as campanhas selecionadas em menus separados");
define("BANNER_MENU_L15", "quantas campanhas devem ser mostradas?");
define("BANNER_MENU_L16", "este ajuste será usado somente com as opções 2 e 3.<br />Menos banners presentes, máxima disponívilidade a ser utilizado.");
define("BANNER_MENU_L17", "ajuste uma quantidade ...");
define("BANNER_MENU_L18", "Actualizar Preferências");

?>