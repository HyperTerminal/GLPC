﻿tinyMCE.addI18n('pt.paste_dlg',{
text_title:"Use CTRL+V no seu teclado para colar o texto dentro da janela.",
text_linebreaks:"Manter quebras de linha",
word_title:"Use CTRL+V no seu teclado para colar o texto dentro da janela.",
});