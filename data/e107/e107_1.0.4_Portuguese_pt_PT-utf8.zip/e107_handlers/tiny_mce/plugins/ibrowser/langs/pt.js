﻿// PT lang variables
tinyMCE.addI18n('pt.ibrowser',{
	desc : 'Imagem Browser'
});