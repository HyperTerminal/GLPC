﻿<?php

$lang_ibrowser_title= 'Inserir/Editar Imagem';
$lang_ibrowser_desc= 'Inserir/Editar Imagem';
$lang_ibrowser_library= 'Livraria';
$lang_ibrowser_preview= 'Pré-visualizar';
$lang_ibrowser_img_sel= 'Seleção de imagem';
$lang_ibrowser_img_info= 'Informação da imagem';
$lang_ibrowser_img_upload= 'Upload de imagem';
$lang_ibrowser_images= 'Imagens';
$lang_ibrowser_src= 'Origem';
$lang_ibrowser_alt= 'Descrição';
$lang_ibrowser_size= 'Tamanho';
$lang_ibrowser_align= 'Disposição do texto';
$lang_ibrowser_height= 'Altura';
$lang_ibrowser_width= 'Largura';
$lang_ibrowser_reset= 'Eliminar dimensões';
$lang_ibrowser_border= 'Bordo';
$lang_ibrowser_hspace= 'Esp.horiz';
$lang_ibrowser_vspace= 'Esp.vert';
$lang_ibrowser_select= 'Salvar';
$lang_ibrowser_delete= 'Apagar';
$lang_ibrowser_cancel= 'Cancelar';
$lang_ibrowser_uploadtxt= 'Ficheiro';
$lang_ibrowser_uploadbt= 'Subir';
$lang_ibrowser_marginl = 'M.Esquerdo';
$lang_ibrowser_marginr = 'M.Direito';
$lang_ibrowser_margint = 'M.Superior';
$lang_ibrowser_marginb = 'M.Inferior';
$lang_insert_image_align_default = "Padrão";
$lang_insert_image_align_left = "Esquerda";
$lang_insert_image_align_right = "Direita";

// error messages
$lang_ibrowser_error= 'Erro';
$lang_ibrowser_errornoimg= 'Por favor selecione uma imagem';
$lang_ibrowser_errornodir= 'A livraria não existe';
$lang_ibrowser_errorupload= 'Foi encontrado um erro durante a transferência do ficheiro.\nPor favor volte a tentar mais tarde';
$lang_ibrowser_errortype= 'Formato inválido de imagem';
$lang_ibrowser_errordelete= 'A eliminação falhou';
$lang_ibrowser_confirmdelete= 'Clique OK para apagar a imagem!';
$lang_ibrowser_error_width_nan= 'Tem que introduzir um número na Largura!';
$lang_ibrowser_error_height_nan= 'Tem que introduzir um número na Altura!';
$lang_ibrowser_error_border_nan= 'Tem que introduzir um número no Bordo!';
$lang_ibrowser_error_hspace_nan= 'Tem que introduzir um número no Espaçamento Horizontal!';
$lang_ibrowser_error_vspace_nan= 'Tem que introduzir um número no Espaçamento Vertical!';

?>