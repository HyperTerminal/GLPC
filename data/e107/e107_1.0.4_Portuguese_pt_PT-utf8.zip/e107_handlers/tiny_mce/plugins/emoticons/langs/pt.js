﻿// PT lang variables

tinyMCE.addI18n('pt.emoticons',{
	desc : 'Inserir emoçoes'
});