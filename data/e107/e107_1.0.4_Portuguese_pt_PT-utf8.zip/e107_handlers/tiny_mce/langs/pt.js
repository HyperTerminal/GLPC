﻿tinyMCE.addI18n({pt:{
common:{
edit_confirm:"Deseja usar o modo de edição avançada neste campo de texto?",
apply:"Aplicar",
insert:"Inserir",
update:"Atualizar",
cancel:"Cancelar",
close:"Fechar",
browse:"Procurar",
class_name:"Classe",
not_set:"-- N/A --",
clipboard_msg:"Copiar/cortar/colar não está disponível no Mozilla e Firefox.\nDeseja mais informações sobre este problema?",
clipboard_no_support:"O seu browser não suporta esta função, use os atalhos do teclado.",
popup_blocked:"Detectamos que o seu bloqueador de popups bloqueou uma janela que é essencial para a aplicação. Você precisa desativar o bloqueador de janelas de popups para utilizar esta ferramenta.",
invalid_data:"{#field} é invalida",
invalid_data_number:"{#field} deve ser um número",
invalid_data_min:"{#field} deve ser um número maior que {#min}",
invalid_data_size:"{#field} deve ser um número ou uma percentagem",
more_colors:"Mais Cores"
},
colors:{
'333300':'Oliva escuro',
'993300':'Laranja queimado',
'000000':'Preto',
'003300':'Verde escuro',
'003366':'Azul escuro',
'000080':'Azul marinho',
'333399':'Índigo',
'333333':'Cinza muito escuro',
'800000':'Marrom 1',
'FF6600':'Laranja',
'808000':'Oliva',
'008000':'Verde',
'008080':'Verde azulado',
'0000FF':'Azul',
'666699':'Azul acinzentado',
'808080':'Cinza',
'FF0000':'Vermelho',
'FF9900':'Ámbar',
'99CC00':'Amarelo esverdeado',
'339966':'Verde mar',
'33CCCC':'Turquesa',
'3366FF':'Azul real',
'800080':'Roxo',
'999999':'Cinza médio',
'FF00FF':'Magenta',
'FFCC00':'Ouro',
'FFFF00':'Amarelo',
'00FF00':'Lima',
'00FFFF':'Água',
'00CCFF':'Azul celeste',
'993366':'Marrom 2',
'C0C0C0':'Prata',
'FF99CC':'Cor de Rosa',
'FFCC99':'Péssego',
'FFFF99':'Amarelo claro',
'CCFFCC':'Verde púlido',
'CCFFFF':'Ciano púlido',
'99CCFF':'Azul celeste claro',
'CC99FF':'Ameixa',
'FFFFFF':'Branco'
},
contextmenu:{
align:"Alinhamento",
left:"Esquerda",
center:"Centro",
right:"Direita",
full:"Justificado"
},
insertdatetime:{
date_fmt:"%d-%m-%Y",
time_fmt:"%H:%M:%S",
insertdate_desc:"Inserir data",
inserttime_desc:"Inserir hora",
months_long:"Janeiro,Fevereiro,Março,Abril,Maio,Junho,Julho,Agosto,Setembro,Outubro,Novembro,Dezembro",
months_short:"Jan,Fev,Mar,Abr,Mai,Jun,Jul,Ago,Set,Out,Nov,Dez",
day_long:"Domingo,Segunda-feira,Terça-feira,Quarta-feira,Quinta-feira,Sexta-feira,Sábado,Domingo",
day_short:"Dom,Seg,Ter,Qua,Qui,Sex,Sab,Dom"
},
print:{
print_desc:"Imprimir"
},
preview:{
preview_desc:"Pré-visualizar"
},
directionality:{
ltr_desc:"Da esquerda para direita",
rtl_desc:"Da direita para esquerda"
},
layer:{
insertlayer_desc:"Inserir nova camada",
forward_desc:"Mover para frente",
backward_desc:"Mover para trás",
absolute_desc:"Alternar o posicionamento absoluto",
content:"Nova camada..."
},
save:{
save_desc:"Salvar",
cancel_desc:"Cancelar todas as alterações"
},
nonbreaking:{
nonbreaking_desc:"Inserir um espaço \"sem quebra\""
},
iespell:{
iespell_desc:"Verificar ortografia",
download:"Plugin de ortografia não detectado. Deseja instalar agora?"
},
advhr:{
advhr_desc:"Separador horizontal"
},
emotions:{
emotions_desc:"Emoticons"
},
searchreplace:{
search_desc:"Localizar",
replace_desc:"Localizar/substituir"
},
advimage:{
image_desc:"Inserir/editar imagem"
},
advlink:{
link_desc:"Inserir/editar hyperlink"
},
xhtmlxtras:{
cite_desc:"Citação",
abbr_desc:"Abreviação",
acronym_desc:"Acrónimo",
del_desc:"Apagar",
ins_desc:"Inserir",
attribs_desc:"Inserir/Editar atributos"
},
style:{
desc:"Editar CSS"
},
paste:{
paste_text_desc:"Colar como texto simples",
paste_word_desc:"Colar (copiado do WORD)",
selectall_desc:"Selecionar tudo",
plaintext_mode_sticky:"Comando colar está em modo texto simples. Clique novamente para voltar para o modo normal. Depois de colar alguma coisa retornará para o modo normal.",
plaintext_mode:"Comando colar está em modo texto simples. Clique novamente para voltar para o modo normal."
},
paste_dlg:{
text_title:"Use CTRL+V para colar o texto na janela.",
text_linebreaks:"Manter quebras de linha",
word_title:"Use CTRL+V para colar o texto na janela."
},
table:{
desc:"Inserir nova tabela",
row_before_desc:"Inserir linha antes",
row_after_desc:"Inserir linha depois",
delete_row_desc:"Apagar linha",
col_before_desc:"Inserir coluna antes",
col_after_desc:"Inserir coluna depois",
delete_col_desc:"Remover coluna",
split_cells_desc:"Dividir células",
merge_cells_desc:"Unir células",
row_desc:"Propriedades das linhas",
cell_desc:"Propriedades das células",
props_desc:"Propriedades da tabela",
paste_row_before_desc:"Colar linha antes",
paste_row_after_desc:"Colar linha depois",
cut_row_desc:"Cortar linha",
copy_row_desc:"Copiar linha",
del:"Apagar tabela",
row:"Linha",
col:"Coluna",
cell:"Célula"
},
autosave:{
unload_msg:"As mudanças efetuadas serão perdidas se sair desta página.",
restore_content:"Restaura conteúdo salvo automaticamente.",
warning_message:"Se restaurar o conteúdo, você irá perder tudo que está atualmente no editor.\n\nTem certeza que quer restaurar o conteúdo salvo?"
},
fullscreen:{
desc:"Tela Inteira"
},
media:{
desc:"Inserir/Editar média",
edit:"Editar média incorporada"
},
fullpage:{
desc:"Propriedades do Documento"
},
template:{
desc:"Inserir template"
},
visualchars:{
desc:"Caracteres de controlo visual ligado/desligado"
},
spellchecker:{
desc:"Alternar verificação ortográfica",
menu:"Configurações de ortografia",
ignore_word:"Ignorar palavra",
ignore_words:"Ignorar tudo",
langs:"Idiomas",
wait:"Aguarde...",
sug:"Sugestões",
no_sug:"Sem sugestões",
no_mpell:"Não foram detectados erros de ortografia."
},
pagebreak:{
desc:"Inserir quebra de página."
},
advlist:{
types:"Tipos",
def:"Padrão",
lower_alpha:"Alfabeto minúsculo",
lower_greek:"Alfabeto grego",
lower_roman:"Num. romanos minúsculos",
upper_alpha:"Alfabeto maísculos",
upper_roman:"Num. romanos maísculos",
circle:"Círculo",
disc:"Disco",
square:"Quadrado"
},
aria:{
rich_text_area:"Área de texto rico"
},
wordcount:{
words: 'Palavras: '
}
}});