<?php
/**
 * PHPMailer language file.
 * Portuguese Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG['provide_address'] 		= 'Voc� deve inserir pelo menos um endere�o de e-mail para o destinat�rio.';
$PHPMAILER_LANG['mailer_not_supported'] = '	mailer n�o suportado.';
$PHPMAILER_LANG['execute'] 				= 'N�o foi poss�vel executar: ';
$PHPMAILER_LANG['instantiate'] 			= 'N�o foi poss�vel criar uma instancia para a fun��o mail.';
$PHPMAILER_LANG['authenticate'] 		= 'Erro SMTP: N�o foi poss�vel autenticar.';
$PHPMAILER_LANG['from_failed'] 			= 'O endere�o De falhou: ';
$PHPMAILER_LANG['recipients_failed'] 	= 'Erro de SMTP: O destinat�rio a seguir falharam: ';
$PHPMAILER_LANG['data_not_accepted'] 	= 'Erro de SMTP: Dados n�o aceitos.';
$PHPMAILER_LANG['connect_host'] 		= 'Erro de SMTP: N�o foi poss�vel conectar ao servidor SMTP.';
$PHPMAILER_LANG['file_access'] 			= 'N�o foi poss�vel acessar ao arquivo: ';
$PHPMAILER_LANG['file_open'] 			= 'Erro de Arquivo: N�o foi poss�vel abrir o arquivo: ';
$PHPMAILER_LANG['encoding'] 			= 'Codifica��o desconhecida: ';
$PHPMAILER_LANG['signing'] 				= 'Erro de Assinatura:';
$PHPMAILER_LANG['smtp_error'] 			= 'Erro no servidor SMTP: ';
?>