<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Vekna Blue, desenvolvido por <a href='http://e107.org' rel='external'>jalist</a>, permitido e baseado no tema do Arach's site, <a href='http://e107.vekna.com' rel='external'>http://e107.vekna.com</a>");
define("LAN_THEME_2", "Ler/Publicar Comentários:");
define("LAN_THEME_3", "Sem Comentários");
define("LAN_THEME_4", "Ler tudo");
define("LAN_THEME_5", "TrackBacks:");

?>