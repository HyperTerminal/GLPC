<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('LAN_THEME_1', 'Core tema e107, por <a href="http://e107.org" title="e107 CMS" rel="external">e107 Inc.</a>');
define('LAN_THEME_2', 'Comentários:');
define('LAN_THEME_3', 'Comentários inativos');
define('LAN_THEME_4', 'Ler Tudo...');
define('LAN_THEME_5', 'Trackbacks:');
define('LAN_THEME_8', 'em');
define('LAN_THEME_9', 'por');
define("LAN_THEME_11", "Últimas notícias");
define("LAN_THEME_12", "Email para um amigo");
define("LAN_THEME_13", "Criar arquivo PDF");
define("LAN_THEME_14", "Imprimir");
define("LAN_THEME_15", "Editar");
define('LAN_THEME_17', 'Início de Sessão');
define('LAN_THEME_18', 'Nome de utilizador');
define('LAN_THEME_19', 'Senha');
define('LAN_THEME_20', 'Registro');
define('LAN_THEME_21', 'Início de Sessão');
define('LAN_THEME_22', 'Esqueceu a senha?');
define('LAN_THEME_23', 'Bem-vindo');
define('LAN_THEME_24', 'Admin');
define('LAN_THEME_26', 'Configurações');
define('LAN_THEME_27', 'Perfil');
define('LAN_THEME_28', 'Sair');
define('LAN_THEME_29', 'Lista de notícias');
define('LAN_THEME_SING', 'Início de Sessão');
define('LAN_THEME_REG', 'Registro');
define("LAN_SEARCH", "Busca");
define("LAN_SEARCH_SUB", "Ir");
define('LAN_THEME_SHARE', 'Compartilhe');
define('LAN_THEME_VER', 'e107 v.');
define("CM_L13", "por");
?>