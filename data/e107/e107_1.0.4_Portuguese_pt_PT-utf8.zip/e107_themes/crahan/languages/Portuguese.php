<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "CraHan desenvolvido por <a href='http://e107.org' rel='external'>jalist</a>, baseado no thema do sitio CraHan <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Sem Comentários");
define("LAN_THEME_3", "Comentário(s):");
define("LAN_THEME_4", "Ler tudo");
define("LAN_THEME_5", "TrackBacks:");
define("LAN_THEME_6", "Comentado por");

?>