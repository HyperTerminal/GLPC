<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANUPLOAD_1", "Tipo de arquivo");
define("LANUPLOAD_2", "Não é permitido e foi apagado.");
define("LANUPLOAD_3", "Transferência efectuada com sucesso!");
define("LANUPLOAD_4", "A directoria de destino não existe ou não tem permissões de escrita (CHMOD 777).");
define("LANUPLOAD_5", "O arquivo transferido excedeu o tamanho máximo (upload_max_filesize). Definido no php.ini.");
define("LANUPLOAD_6", "O arquivo transferido excede o tamanho máximo (MAX_FILE_SIZE). Definido pelo administrador no formato html.");
define("LANUPLOAD_7", "A transferência foi parcialmente efectuada.");
define("LANUPLOAD_8", "A transferência não foi efectuada.");
define("LANUPLOAD_9", "O tamanho da transferência foi de 0 bytes");
define("LANUPLOAD_10", "A transferência falhou [ficheiro duplicado] - Já existe um arquivo com o mesmo nome.");
define("LANUPLOAD_11", "A transferência não foi efectuada. Nome de arquivo:");
define("LANUPLOAD_12", "Erro");
define("LANUPLOAD_13", "Em falta pasta temporária");
define("LANUPLOAD_14", "falho ao escrever no arquivo");
define("LANUPLOAD_15", "Enviar não é permitido");
define("LANUPLOAD_16", "Erro desconhecido");
define("LANUPLOAD_17", "Nome de arquivo inválido");
define("LANUPLOAD_18", "O arquivo enviado excedeu os limites estabelecidos.");
define("LANUPLOAD_19", "Muitos arquivos enviados - excesso eliminado.");


?>