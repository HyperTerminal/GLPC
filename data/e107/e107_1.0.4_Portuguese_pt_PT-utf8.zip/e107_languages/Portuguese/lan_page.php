<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_PAGE_1", "Lista de páginas inactivas");
define("LAN_PAGE_2", "Não existem páginas");
define("LAN_PAGE_3", "A página solicitada não existe");
define("LAN_PAGE_4", "Classifique esta página");
define("LAN_PAGE_5", "Obrigado por avaliar esta página.");
define("LAN_PAGE_6", "Você não tem permissão para visualizar esta página");
define("LAN_PAGE_7", "Senha inválida");
define("LAN_PAGE_8", "Página protegida por senha");
define("LAN_PAGE_9", "Inserir Senha");
define("LAN_PAGE_10", "Enviar");
define("LAN_PAGE_11", "Lista de páginas");
define("LAN_PAGE_12", "Página inválida");
define("LAN_PAGE_13", "Página");


?>