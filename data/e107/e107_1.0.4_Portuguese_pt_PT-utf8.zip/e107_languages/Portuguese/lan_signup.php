<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Registo - Novo Utilizador");
define("LAN_7", "Nome a ver:");
define("LAN_8", "Este é o nome que será visto no sítio");
define("LAN_9", "Nome de Utilizador:");
define("LAN_10", "Este é o nome que será utilizado para efectuar o início de sessão");
define("LAN_17", "Senha:");
define("LAN_103", "Este nome de utilizador não pode ser utilizado (inválido), por favor escolha um nome de utilizador diferente");
define("LAN_104", "Este nome já existe na base de dados, por favor escolha um nome diferente");
define("LAN_105", "As duas senhas não coincidem");
define("LAN_106", "O endereço de e-mail fornecido é aparentemente inválido");
define("LAN_107", "Obrigado! É agora um membro registado do");
define("LAN_108", "Registo completo");
define("LAN_109", "Este sítio está de acordo com a legislação '<i>Children's Online Privacy Protection Act of 1998 (COPPA)</i>'. Como tal não poderemos aceitar registos de utilizadores com idades menores que 13 anos, sem um consentimento escrito dos seus pais ou tutores. Para mais informações deverá consultar a legislação vigente.");
define("LAN_110", "Registo de novo utilizador");
define("LAN_111", "Insira novamente a senha:");
define("LAN_112", "Endereço de e-mail:");
define("LAN_113", "Ocultar e-mail?:");
define("LAN_114", "Esta opção ocultará o seu endereço de e-mail no sítio");
define("LAN_123", "Registe-se");
define("LAN_185", "Alguns campos necessários não foram preenchidos");
define("LAN_201", "Sim");
define("LAN_200", "Não");
define("LAN_202", "Já possui uma conta/registo no nosso sítio. Se não se lembra da sua senha por favor clique no link \'Esqueci a senha\'.");
define("LAN_309", "Por favor, insira os seus detalhes em baixo...");
define("LAN_399", "Continuar");
define("LAN_400", "O nome de utilizador e senha são diferenciados por <b>maiusculas/minusculas</b>");
define("LAN_401", "A sua conta foi ativada, por favor");
define("LAN_402", "Registo activado");
define("LAN_403", "Bem-vindo ao");
define("LAN_404", "Detalhes do registo de");
define("LAN_405", "Esta fase do registo está concluida. Irá receber um e-mail de confirmação com os seus detalhes de início de sessão. Por favor, clique no link do e-mail para completar o processo de registo e activar a sua conta.");
define("LAN_406", "Obrigado!");
define("LAN_407", "Por favor guarde este e-mail num local seguro. A sua senha foi encriptada e não poderá ser recuperada na eventualidade de a ter perdido ou esquecido. No entanto poderá pedir uma nova senha se ocorrer alguma dessas situações.\n\nObrigado pelo seu registo.\n\nDe");
define("LAN_408", "Já existe um utilizador com este endereço de e-mail. Por favor utilize o ecrã 'Esqueci a senha' para poder recuperar a sua senha.");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "cars.");
define("LAN_SIGNUP_3", "A verificação do código falhou.");
define("LAN_SIGNUP_4", "A sua senha necessita de conter pelo menos");
define("LAN_SIGNUP_5", " caracteres.");
define("LAN_SIGNUP_6", "O seu");
define("LAN_SIGNUP_7", " é necessário");
define("LAN_SIGNUP_8", "Obrigado!");
define("LAN_SIGNUP_9", "Não foi possivel prosseguir.");
define("LAN_SIGNUP_10", "Sim");
define("LAN_SIGNUP_11", ".");
define("LAN_409", "Caracteres inválidos no nome de utilizador");
define("LAN_410", "Insira o código visivel na imagem");
define("LAN_411", "O 'nome a ver' já existe na base de dados, por favor escolha um nome diferente");
define("LAN_SIGNUP_12", "Por favor guarde o seu nome/senha num sítio seguro, uma vez que esta informação não pode ser recuperada.");
define("LAN_SIGNUP_13", "Poderá efectuar o início de sessão no menu respectivo, ou a partir <a href='".e_BASE."login.php'>Aqui</a>.");
define("LAN_SIGNUP_14", "aqui");
define("LAN_SIGNUP_15", "Por favor contacte o administrador principal do site");
define("LAN_SIGNUP_16", "se necessitar de ajuda.");
define("LAN_SIGNUP_17", "Por favor, demonstre que tem pelo menos 13 anos de idade.");
define("LAN_SIGNUP_18", "O seu registo foi recebido e criado com a seguinte informação...");
define("LAN_SIGNUP_21", "A sua conta está inactiva, para activá-la deverá seguir este link...");
define("LAN_SIGNUP_22", "clique aqui");
define("LAN_SIGNUP_23", "para efectuar o início de sessão.");
define("LAN_SIGNUP_24", "Obrigado pelo seu registo em");
define("LAN_SIGNUP_25", "Inserir o seu avatar");
define("LAN_SIGNUP_26", "Inserir a sua foto");
define("LAN_SIGNUP_27", "Ver");
define("LAN_SIGNUP_28", "Escolha de listas de Conteúdo/Distribuição");
define("LAN_SIGNUP_29", "<br />Depois do registo será enviado um e-mail de verificação para o endereço de e-mail fornecido, certifique-se que introduziu um endereço de e-mail válido.");
define("LAN_SIGNUP_30", "Se não desejar mostrar o seu endereço de e-mail no site, por favor seleccione a caixa 'Ocultar e-mail'.");
define("LAN_SIGNUP_31", "URL do seu ficheiro XUP");
define("LAN_SIGNUP_32", "O que é um ficheiro XUP?");
define("LAN_SIGNUP_33", "Insira o endereço ou escolha um avatar");
define("LAN_SIGNUP_34", "NOTA: Qualquer imagem transferida para este servidor que seja considerada inapropriada pelos administradores, será apagada de imediato.");
define("LAN_SIGNUP_35", "Clique aqui para efectuar o registo com um ficheiro XUP");
define("LAN_SIGNUP_36", "Foi detectado um erro na criação da informação do utilizador, por favor contacte o administrador do site");
define("LAN_LOGINNAME", "Nome de Utilizador");
define("LAN_PASSWORD", "Senha");
define("LAN_USERNAME", "Nome mostrado");
define("LAN_EMAIL_01", "Caro/a");
define("LAN_EMAIL_04", "Por favor, guarde este email num local seguro.");
define("LAN_EMAIL_05", "A sua senha foi encriptada e não poderá ser recuperada na eventualidade de a ter perdido ou esquecido. No entanto poderá pedir uma nova senha se ocorrer alguma dessas situações.");
define("LAN_EMAIL_06", "Obrigado pelo seu registo.");
define("LAN_SIGNUP_37", "Esta fase do registo está concluida. O administrador do site necessita de aprovar a sua candidatura. Assim que o processo esteja concluido receberá um e-mail com a confirmação de que o seu registo foi aprovado.");
define("LAN_SIGNUP_38", "Inseriu dois endereços de email diferentes. Por favor escreva o mesmo endereço de email (válido) nos dois campos disponibilizados");
define("LAN_SIGNUP_39", "Insira novamente o endereço de email:");
define("LAN_SIGNUP_40", "A activação não é necessário");
define("LAN_SIGNUP_41", "A sua conta já está ativada.");
define("LAN_SIGNUP_42", "Houve um problema, o registo email não foi enviado, entre em contato com o administrador do sítio.");
define("LAN_SIGNUP_43", "Email enviado");
define("LAN_SIGNUP_44", "Email de ativação enviado para:");
define("LAN_SIGNUP_45", "Por favor, verifique sua caixa de entrada.");
define("LAN_SIGNUP_47", "Reenviar email de ativação");
define("LAN_SIGNUP_48", "Nome de utilizador ou e-mail");
define("LAN_SIGNUP_49", "Se você se registrou com o endereço de email errado, escreva um novo email e uma nova senha aqui:");
define("LAN_SIGNUP_50", "Novo email");
define("LAN_SIGNUP_51", "Senha antiga");
define("LAN_SIGNUP_52", "Senha incorreta");
define("LAN_SIGNUP_53", "Falhou o teste de validação de campos");
define("LAN_SIGNUP_54", "Clique aqui para preencher os seus dados de registo");
define("LAN_SIGNUP_55", "Esse nome de exibição é demasiado longo. Por favor, escolha outro");
define("LAN_SIGNUP_56", "Esse nome de exibição é demasiado curto. Escolha outro");
define("LAN_SIGNUP_57", "Esse nome de login é muito longo. Por favor, escolha outro");
define("LAN_SIGNUP_58", "Ver");
define("LAN_SIGNUP_59", "**** Se o link não funcionar, verifique se parte dela não tem transbordou para a próxima linha. ****");
define("LAN_SIGNUP_60", "Erro no acesso externo do avatar");
define("LAN_SIGNUP_72", "Obrigado por se inscrever em [sitename]! Acabamos de enviar um e-mail de confirmação para [e-mail]. Por favor, clique na hiperligação de confirmação no e-mail para concluir sua ativação de conta.");
define("LAN_SIGNUP_98", "Confirme seu endereço de email");
define("LAN_SIGNUP_99", "Problema encontrado");
define("LAN_SIGNUP_100", "Aprovação Pendente pelo Admin");
define("LAN_SIGNUP_102", "Registro Denegado!");
define("LAN_SIGNUP_103", "Demasiados utilizadores que están utilizando la dirección IP:");
define("LAN_SIGNUP_104", "Nome do avatar inválido");
define("LAN_SIGNUP_105", "Não foi possivel realizar o seu pedido - entre em contato com o administrador do sítio");
define("LAN_SIGNUP_106", "Não foi possivel realizar o seu pedido - você já tem uma conta aqui?");


?>