<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANMAILH_1", "Produzido pelo e107");
define("LANMAILH_2", "Este é um mensagem multi-parte em formato MIME.");
define("LANMAILH_3", "não está formatado adequadamente");
define("LANMAILH_4", "O Servidor rejeitou o endereço");
define("LANMAILH_5", "Sem resposta do servidor");
define("LANMAILH_6", "Não foi possível localizar o servidor de email.");
define("LANMAILH_7", "parece ser válido.");


?>