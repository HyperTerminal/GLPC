<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Membros");
define("LAN_20", "Erro");
define("LAN_112", "Email");
define("LAN_137", "Não existe informação acerca do utilizador uma vez que este não se encontra registado em");
define("LAN_138", "Membros registados:");
define("LAN_139", "Ordenar:");
define("LAN_140", "Membros registados");
define("LAN_141", "Ainda não existem membros registados.");
define("LAN_142", "Membro");
define("LAN_143", "[oculto]");
define("LAN_145", "Data de registo");
define("LAN_146", "Número de visitas desde o registo");
define("LAN_147", "Mensagens Chatbox");
define("LAN_148", "Comentários");
define("LAN_149", "Mensagens Fórum");
define("LAN_308", "Nome Verdadeiro");
define("LAN_400", "Este utilizador é inválido.");
define("LAN_401", "Sem informação");
define("LAN_402", "Perfil do Membro");
define("LAN_403", "Estatísticas do sitio");
define("LAN_404", "Última visita");
define("LAN_405", "dias atrás");
define("LAN_406", "Classificação");
define("LAN_407", "Sem Imagem");
define("LAN_408", "Sem foto");
define("LAN_409", "Pontos");
define("LAN_410", "Vários");
define("LAN_411", "Clique aqui para actualizar a sua informação");
define("LAN_412", "Clique aqui para editar a informação deste utilizador");
define("LAN_413", "Apagar fotografia");
define("LAN_414", "Anterior");
define("LAN_415", "Seguinte");
define("LAN_416", "Necessita de Inicias Sessão para aceder a esta página");
define("LAN_417", "Administrador Principal");
define("LAN_418", "Administrador");
define("LAN_419", "Mostrar");
define("LAN_420", "DESC");
define("LAN_421", "ASC");
define("LAN_422", "Ir");
define("LAN_423", "Ver os comentários deste utilizador");
define("LAN_424", "Ver as mensagens no fórum deste utilizador");
define("LAN_425", "Enviar Mensagem Privada");
define("LAN_426", "faz");
define("USERLAN_1", "Classificação Peer");
define("USERLAN_2", "Você não tem permissão de acesso para visualizar esta página.");


?>