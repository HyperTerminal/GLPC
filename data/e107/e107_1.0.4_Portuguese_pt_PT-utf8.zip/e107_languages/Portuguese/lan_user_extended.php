<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UE_LAN_1", "Caixa de Texto");
define("UE_LAN_2", "Botões de Radio");
define("UE_LAN_3", "Menu Desplegavel");
define("UE_LAN_4", "Campo de Tabela da BD");
define("UE_LAN_5", "Área de Texto");
define("UE_LAN_6", "Inteiro");
define("UE_LAN_7", "Data");
define("UE_LAN_8", "Idioma");
define("UE_LAN_9", "Nome");
define("UE_LAN_10", "Tipo");
define("UE_LAN_11", "Descrição");
define("UE_LAN_HIDE", "Ocultar dos utilizadores");
define("UE_LAN_LOCATION", "Local");
define("UE_LAN_LOCATION_DESC", "Localização/origem");
define("UE_LAN_AIM", "Endereço AIM");
define("UE_LAN_AIM_DESC", "Endereço AIM");
define("UE_LAN_ICQ", "Número ICQ");
define("UE_LAN_ICQ_DESC", "Número ICQ");
define("UE_LAN_YAHOO", "Endereço Yahoo!");
define("UE_LAN_YAHOO_DESC", "Endereço Yahoo!");
define("UE_LAN_MSN", "Endereço MSN");
define("UE_LAN_MSN_DESC", "Endereço MSN-messenger");
define("UE_LAN_HOMEPAGE", "Sítio Web");
define("UE_LAN_HOMEPAGE_DESC", "Página web do utilizador (URL)");
define("UE_LAN_BIRTHDAY", "Data de Nascimento");
define("UE_LAN_BIRTHDAY_DESC", "Data de Nascimento");
define("UE_LAN_LANGUAGE", "Idioma");
define("UE_LAN_LANGUAGE_DESC", "Idioma do utilizador");
define("UE_LAN_COUNTRY", "Pais");
define("UE_LAN_COUNTRY_DESC", "Pais do utilizador (inclui a tabela do BD)");
define("LAN_UE_FAIL_HOMEPAGE", "Entrada inválida nas definições para a Página web");


?>