<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("RATELAN_0", "voto");
define("RATELAN_1", "votos");
define("RATELAN_2", "Quer avaliar este tema?");
define("RATELAN_3", "Obrigado pelo seu voto!");
define("RATELAN_4", "sem classificar");
define("RATELAN_5", "Classificar");


?>