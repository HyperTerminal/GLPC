<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Esqueci-me da Senha");
define("LAN_02", "Lamentamos, não foi possível enviar o email - faz favor contacte o administrador principal do sitio.");
define("LAN_03", "Esqueci-me da Senha");
define("LAN_05", "Para criar uma nova da sua senha, insira a seguinte informação:");
define("LAN_06", "Tentativa de criação de senha");
define("LAN_07", "Alguém com o endereço de IP");
define("LAN_08", "Tentou criar à senha do administrador principal.");
define("LAN_09", "Criar à senha de");
define("LAN_112", "Endereço de email utilizado no registo");
define("LAN_156", "Enviar");
define("LAN_213", "Este utilizador/email não foram encontrados na base de dados.");
define("LAN_214", "Não foi possível efectuar a criação duma nova senha");
define("LAN_216", "Para validar a sua nova senha deverá seguir clicar nesta hiperligação...");
define("LAN_217", "A sua nova senha foi validada, poderá efectuar o Início de Sessão utilizando a nova senha.");
define("LAN_218", "O seu nome de utilizador é:");
define("LAN_219", "A criação da senha associada a esse endereço de email já foi efectuado e não poderá ser feito novamente. Faz favor contacte-se com o administrador do sitio para mais informações.");
define("LAN_FPW1", "Nome de utilizador");
define("LAN_FPW2", "Digitar Código");
define("LAN_FPW3", "Código incorrecto");
define("LAN_FPW4", "Já foi efectuado um pedido para criar uma nova senha, na eventualidade de não ter recebido o email deverá solicitar ajuda ao administrador do sitio.");
define("LAN_FPW5", "Pedido de criação de senha para");
define("LAN_FPW6", "Foi-lhe enviado um email com a hiperligação que lhe permitirá efectuar o restauro da sua senha.");
define("LAN_FPW7", "Esta hiperligação não é válida para efectuar o restauro da sua senha.<br />Faz favor contacte-se com o administrador do sitio para mais informações.");
define("LAN_FPW8", "Sua senha foi alterada com sucesso!");
define("LAN_FPW9", "A sua nova senha é:");
define("LAN_FPW10", "Deverá");
define("LAN_FPW11", "Iniciar Sessão");
define("LAN_FPW12", "agora, pode de imediato alterar a sua senha por razões de segurança.");
define("LAN_FPW13", "Faz favor siga as instruções fornecidas no email para validar a sua senha.");
define("LAN_FPW14", "Foi enviada por alguém com o este IP");
define("LAN_FPW15", "Isto não significa que o restauro da sua senha tenha sido efectuado. É necessário seguir a hiperligação fornecida em baixo para completar o processo de restauro.");
define("LAN_FPW16", "Se você não efectuou o pedido de restauro da sua senha e não deseja alterá-la, deverá ignorar este email.");
define("LAN_FPW17", "Esta hiperligação será válida só por 48 horas.");


?>