<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
if (!defined("PAGE_NAME")) {define("PAGE_NAME", "Vista para impressão");}
define("LAN_PRINT_86", "Categoria:");
define("LAN_PRINT_87", "por");
define("LAN_PRINT_94", "Publicado por");
define("LAN_PRINT_135", "Notícias:");
define("LAN_PRINT_303", "Esta notícia é proveniente de");
define("LAN_PRINT_304", "Título:");
define("LAN_PRINT_305", "Cabeçalho:");
define("LAN_PRINT_306", "Este artigo é de:");
define("LAN_PRINT_307", "Imprimir esta página");
define("LAN_PRINT_1", "Imprimir Página!");


?>