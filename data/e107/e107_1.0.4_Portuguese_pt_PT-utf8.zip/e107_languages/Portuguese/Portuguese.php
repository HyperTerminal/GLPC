<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
setlocale(LC_ALL, 'pt_PT.UTF-8', 'pt_PT.utf8', 'pt_pt.utf8', 'pt' );
define("CORE_LC", "pt");
define("CORE_LC2", "pt");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Erro: O tema está em falta.\\n\\nDeverá de aceder a área de gestão de temas e carregar um dos temas existentes, ou efectuar a transferência dum novo tema para o servidor.");
define("CORE_LAN4", "Por favor, apague o arquivo install.php do seu servidor");
define("CORE_LAN5", "Se não o fizer põe em grande perigo o seu sítio web.");
define("CORE_LAN6", "A proteção contra os excessos está ativa, se continuar a solicitar páginas você poderá ser expulsado.");
define("CORE_LAN7", "O núcleo (Core) está a tentar restaurar as preferências da cópia de segurança automaticamente.");
define("CORE_LAN8", "Erro nas preferências principais do núcleo");
define("CORE_LAN9", "O núcleo (Core) não conseguiu restaurar automaticamente a partir da cópia de segurança. Execução interrompida.");
define("CORE_LAN10", "Foi detectada uma Cookie corrompida - desconectado.");
define("CORE_LAN11", "Tempo de renderização:");
define("CORE_LAN12", "seg,");
define("CORE_LAN13", "para as consultas.");
define("CORE_LAN14", "");
define("CORE_LAN15", "Consultas BD:");
define("CORE_LAN16", "Uso da Memória:");
define("CORE_LAN17", "[ imagem inactiva ]");
define("CORE_LAN18", "Imagem:");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "KB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "Atenção!");
define("LAN_ERROR", "Erro");
define("LAN_ANONYMOUS", "Anónimo");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_SANITISED", "SANITISED");


?>