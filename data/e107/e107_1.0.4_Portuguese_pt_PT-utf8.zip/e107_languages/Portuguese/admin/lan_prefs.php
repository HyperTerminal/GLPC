<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PRFLAN_1", "Informação do Sítio");
define("PRFLAN_2", "Nome do Sítio");
define("PRFLAN_3", "URL do Sítio");
define("PRFLAN_4", "Botão de Link do Sítio");
define("PRFLAN_5", "Etiqueta do Sítio");
define("PRFLAN_6", "Descrição do sítio");
define("PRFLAN_7", "Administrador principal do sítio");
define("PRFLAN_8", "E-mail do admin principal");
define("PRFLAN_9", "Condições de utilização do sítio");
define("PRFLAN_10", "Tema");
define("PRFLAN_11", "Tema do Sítio");
define("PRFLAN_12", "Clique aqui para pré-visualizar Temas");
define("PRFLAN_13", "Mostrar informação");
define("PRFLAN_14", "Mostrar informação do tema?");
define("PRFLAN_15", "Mostrar tempo de geração?");
define("PRFLAN_16", "Mostrar queries SQL?");
define("PRFLAN_17", "Usar gzip para comprimir as saidas");
define("PRFLAN_19", "Opções da página de registo");
define("PRFLAN_21", "Opções da data");
define("PRFLAN_22", "Formato curto da data");
define("PRFLAN_23", "Formato longo da data");
define("PRFLAN_24", "Formato da data no fórum");
define("PRFLAN_25", "Para mais informações acerca dos formatos da data deverá consultar a");
define("PRFLAN_26", "Zona horária");
define("PRFLAN_27", "Por exemplo, se definir esta opção para +2, irá adicionar 2 horas em todas as referências horárias no seu site");
define("PRFLAN_28", "Registo de utilizadores");
define("PRFLAN_29", "Activar sistema de registo de utilizadores?");
define("PRFLAN_30", "Permitir o registo de utilizadores no site");
define("PRFLAN_32", "Permitir mensagens anónimas?");
define("PRFLAN_33", "Deverá desligar esta opção para permitir a publicação de comentários, etc. apenas por membros registados");
define("PRFLAN_35", "Ligar protecção contra flood?");
define("PRFLAN_36", "Intervalo de flood");
define("PRFLAN_37", "Expelsão automática");
define("PRFLAN_38", "Tempo (em segundos) entre 2 submissões nas áreas onde os utilizadores podem enviar mensagens: fórum, comentários, chatbox, etc. Se o utilizador enviar duas mensagens muito rapidamente, será redireccionado para a página inicial");
define("PRFLAN_40", "Filtrar Palavras?");
define("PRFLAN_41", "Ao activar esta opção, todas as palavras consideradas inapropriadas serão substituidas pela expressão em baixo");
define("PRFLAN_42", "Expressão de substituição");
define("PRFLAN_43", "Filtrar palavras");
define("PRFLAN_44", "Palavras a censurar (separar com vírgulas)");
define("PRFLAN_45", "Usar COPPA na página de registo?");
define("PRFLAN_46", "Para mais informação acerca do COPPA consulte");
define("PRFLAN_47", "Segurança & Protecção");
define("PRFLAN_48", "Método de seguimento dos utilizadores");
define("PRFLAN_49", "Cookies");
define("PRFLAN_50", "Sessões");
define("PRFLAN_52", "Salvar Alterações");
define("PRFLAN_53", "Definições do Sitio");
define("PRFLAN_55", "Nome do Cookie (quando seleccionado)");
define("PRFLAN_56", "Zona horária");
define("PRFLAN_58", "Restringir o site apenas a membros");
define("PRFLAN_59", "Ao seleccionar esta opção irá restringir todas as áreas do site, com  excepção da página inicial e de registo, apenas a membros registados");
define("PRFLAN_60", "Activar SSL");
define("PRFLAN_61", "Deverá apenas activar o SSL se <b>tiver a certeza do que está a fazer!</b>");
define("PRFLAN_76", "Activar verificação por código-imagem durante o registo.");
define("PRFLAN_77", "Opções de administração");
define("PRFLAN_78", "Deixe em branco para desactivar");
define("PRFLAN_80", "Clique aqui para visualizar");
define("PRFLAN_81", "Activar verificação por código-imagem durante o início de sessão.");
define("PRFLAN_83", "Exemplo");
define("PRFLAN_87", "Comentários");
define("PRFLAN_88", "Ligar comentários encadeados");
define("PRFLAN_89", "Mostrar ícone para novos comentários");
define("PRFLAN_90", "Permitir que os utilizadores editem as suas mensagens");
define("CUSTSIG_1", "Definições Salvas!");
define("CUSTSIG_2", "Nome verdadeiro:");
define("CUSTSIG_3", "Página web:");
define("CUSTSIG_4", "Data de nascimento:");
define("CUSTSIG_5", "Local:");
define("CUSTSIG_6", "Assinatura:");
define("CUSTSIG_7", "Avatar");
define("CUSTSIG_8", "Zona horária:");
define("CUSTSIG_12", "Ocultar");
define("CUSTSIG_13", "Campos");
define("CUSTSIG_14", "Mostrar");
define("CUSTSIG_15", "Obrigatório");
define("CUSTSIG_16", "Comprimento mínimo das senhas");
define("CUSTSIG_17", "Subscrever listas de conteúdo/distribuição");
define("CUSTSIG_18", "Nomes de utilizador não permitidos");
define("CUSTSIG_19", "Os nomes de utilizadores que contenham o texto seguinte serão rejeitados (separar com vírgulas)");
define("PRFLAN_91", "Na eventualidade de o seu site estar a ser atacado por pedidos múltiplos ao servidor, o IP de origem será banido de forma automática! Como tal, não deverá substituir o ficheiro de configuraçãp do servidor por um novo!!!");
define("PRFLAN_92", "Verificação segura de registo -- ocultar password no email?");
define("PRFLAN_93", "página da função strftime em php.net");
define("PRFLAN_94", "aqui");
define("PRFLAN_95", "Visualizar informação de plugins:");
define("PRFLAN_96", "Esta definição mostrará a informação em todas as páginas de administração para cada plugin que suporte esta opção");
define("PRFLAN_97", "Menu único de 'informação do plugin':");
define("PRFLAN_98", "Se estiver seleccionado cada plugin será mostrado no seu menu individual. Ao desactivar, toda a informação de plugins será mostrada no mesmo menu.");
define("PRFLAN_101", "Visualização de texto");
define("PRFLAN_102", "Substituir links");
define("PRFLAN_103", "Se seleccionar esta opção, todo os links publicados serão substituídos pelo texto inserido na caixa em baixo. Desta forma pode evitar que links muito longos deformem a aparência do site");
define("PRFLAN_104", "Texto de substituição de links");
define("PRFLAN_105", "Texto usado na substituição dos links. Pode inserir uma imagem através da utilização da etiqueta <img com o caminho completo para a imagem");
define("PRFLAN_106", "Definições de sistema gravadas na base de dados.");
define("PRFLAN_107", "Texto de substituição de emails");
define("PRFLAN_108", "Texto usado na substituição de emails. Pode inserir uma imagem através da utilização da etiqueta <img com o caminho completo para a imagem");
define("PRFLAN_109", "Cortar palavras no texto principal");
define("PRFLAN_110", "As palavras com comprimento superior ao especificado serão cortadas para uma nova linha");
define("PRFLAN_111", "Cortar palavras no menu de texto");
define("PRFLAN_112", "Ligado");
define("PRFLAN_113", "Desligado");
define("PRFLAN_116", "Permitir publicação em HTML");
define("PRFLAN_117", "Esta opção permitirá aos utilizadores a publicação de código HTML em qualquer parte do site. Defina a classe de utilizadores que deverá ter esta permissão.");
define("PRFLAN_118", "Usar o Geshi para destacar a sintaxe");
define("PRFLAN_119", "O Geshi é uma utilidade 'open source' que permite efectuar a verifiação da sintaxe em vários idiomas. Visite a página http://qbnz.com/highlighter/ para mais detalhes");
define("PRFLAN_120", "Sintaxe Geshi por defeito");
define("PRFLAN_121", "Se o idioma não estiver especificado no código bbtag, será utilizado este idioma por defeito na verificação destaque da sintaxe");
define("PRFLAN_122", "Activar WYSIWYG");
define("PRFLAN_123", "Activará o editor What-You-See-Is-What-You-Get nas áreas de texto (quando disponível). Esta opção será disponibilizada apenas a administradores e utilizadores autorizados a publicar HTML.");
define("PRFLAN_124", "Utilizar vista 'clássica' ant|seg");
define("PRFLAN_125", "Ao seleccionar esta opção, a indicação de página anterior|seguinte será mostrada através de  1 2 3 ... 21 22 23, em vez da utilização do novo look - menu dropdown.");
define("PRFLAN_126", "Texto mostrado na página de registo");
define("PRFLAN_127", "Converter links submetidos");
define("PRFLAN_128", "Ao activar esta função, todos os links submetidos nas mensagens dos utilizadores serão convertidos em hyperlinks (clicáveis)");
define("PRFLAN_129", "Não permitir logins múltiplos");
define("PRFLAN_130", "Com esta opção activada o mesmo utilizador não poderá efectuar simultaneamente mais do que um login com o mesmo utilizador/password. Desta forma evitará a partilha dos dados de utilizador.");
define("PRFLAN_131", "Activar a utilização do código bbcode [php]");
define("PRFLAN_132", "Ao activar esta opção irá permitir aos utilizadores a publicação de código [php] em detemindas áreas do site");
define("PRFLAN_133", "A extensão GD é necessária - não foi encontrada");
define("PRFLAN_134", "Redireccionar todos os pedidos para um único URL");
define("PRFLAN_135", "Por exemplo, se o campo anterior estiver definido como http://sitio.pt, todos os pedidos para http://www.sitio.pt serão redireccionados para http://site.pt");
define("PRFLAN_136", "Número máximo de ligações permitidas a partir do mesmo endereço de IP.");
define("PRFLAN_137", "Mostrar a utilização de memória");
define("PRFLAN_138", "Activar verificação por código-imagem para passwords esquecidas.");
define("PRFLAN_139", "Mostrar aviso quando a password do administrador principal não é alterada num espaço inferior a 30 dias");
define("PRFLAN_140", "Texto mostrado após a submissão do formulário de registo.");
define("PRFLAN_141", "Permitir o registo com perfil de utilizador XML");
define("PRFLAN_142", "Apenas flood");
define("PRFLAN_143", "Tentativa falhada de acesso");
define("PRFLAN_144", "Flood + tentativa falhada de acesso");
define("PRFLAN_145", "Links em nova janela");
define("PRFLAN_146", "Seleccione para abrir todos os links numa nova janela (<i>esta função será aplicável à totalidade do site</i>).");
define("PRFLAN_147", "Modo de desenvolvimento");
define("PRFLAN_148", "Activar funções de desenvolvimento. Esta opção deverá ser utilizada apenas por programadores durante o debug/desenvolvimento de novas funções/versões. Não deverá utilizar este modo em sites de produção (por razões de segurança).");
define("PRFLAN_149", "Opções avançadas");
define("PRFLAN_150", "Seleccionar o método de autenticação do e107");
define("PRFLAN_151", "e107 - Não estão instalados modos alternativos de autenticação");
define("PRFLAN_31", "Verificação de e-mail");
define("PRFLAN_152", "Sem verificação");
define("PRFLAN_153", "Aprovação do admin");
define("PRFLAN_154", "Método de verifiação de novos utilizadores <br />Se escolher 'aprovação do admin', deverá activar <a href='".e_ADMIN."notify.php'>aqui</a> as notificações por email de novos registos de utilizadores.");
define("PRFLAN_155", "Nome de login e de exibição pode ser diferente para");
define("PRFLAN_156", "Reset todos os nomes de exibição");
define("PRFLAN_157", "Todos os nomes exibidos foram redefinidas para o Utilizador");
define("PRFLAN_158", "Nome de exibição, tamanho máximo (5..30)");
define("PRFLAN_159", "visualizar esta página com");
define("PRFLAN_160", "Marcar os servidores remotos quando validar endereços de e-mail.");
define("PRFLAN_161", "Desativar todos os comentários sobre o sitio");
define("PRFLAN_162", "Informações de contato do sitio");
define("PRFLAN_163", "por exemplo, Nome da Empresa, endereço, telefone, etc");
define("PRFLAN_164", "Permitir aos utilizadores copiar o e-mail de contato");
define("PRFLAN_165", "possível abertura para permitir spam, use com cuidado");
define("PRFLAN_166", "Mostrar imagens de emoções nos comentários?");
define("PRFLAN_167", "Faça a inscrição de um endereço de e-mail, opcionais");
define("PRFLAN_168", "Contacto Pessoal do Sitio");
define("PRFLAN_169", "Se o grupo escolhido contiver mais de uma pessoa, o usuário será solicitado para selecionar uma pessoa do grupo.");
define("PRFLAN_170", "Usar DNS para banir e proibir");
define("PRFLAN_171", "Activando esta opção permitirá banir utilizadores pelo nome do host, em vez de apenas IP ou endereço de e-mail. <br /> NOTA: Isto pode afectar a leitura em alguns hosts");
define("PRFLAN_172", "Tamanho máximo do nome de Login (10...100)");
define("PRFLAN_173", "Verificar atualizações no SourceForge para E107 a cada ....dias");
define("PRFLAN_174", "Nome de e-mails para as respostas do sitio");
define("PRFLAN_175", "Isto irá aparecer no campo 'De' do registo e de outros e-mails a partir deste sitio");
define("PRFLAN_176", "Endereço de e-mail para os e-mails a partir do sitio");
define("PRFLAN_177", "Endereço indicado para as respostas de e-mails a partir deste sitio.");
define("PRFLAN_208", "Classe de usuário que pode enviar e-mail com links para artigos no sitio");
define("PRFLAN_209", "Outros Recursos");
define("PRFLAN_210", "Comentários/publicações");
define("PRFLAN_215", "Classe de utilizador que pode usar as etiquetas <>- ou semelhantes.");
define("PRFLAN_216", "(Requer direitos de publicação  html)");
define("PRFLAN_217", "Filtrar conteúdo HTML");
define("PRFLAN_218", "Se \'Desactivar\', coloca aos utilizadores num maior risco de XSS exploits publicação feita por membros da classe anterior ou versões anteriores a 0.7.24");
define("PRFLAN_220", "HTML filtro de abuso (experimental)");
define("PRFLAN_221", "Blocos de algumas marcas inigualável para aqueles permissão para postar HTML");
define("PRFLAN_222", "Moderar comentários feitos por");
define("PRFLAN_223", "Os comentários necessitam de aprovação manual por um administrador antes de serem visíveis a outros utilizadores");


?>