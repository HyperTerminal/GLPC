<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FMLAN_1", "Transferido");
define("FMLAN_2", "para");
define("FMLAN_3", "directoria");
define("FMLAN_4", "O arquivo transferido excede o tamanho máximo, definido no arquivo php.ini. ");
define("FMLAN_10", "Erro");
define("FMLAN_12", "Ficheiro");
define("FMLAN_13", "Ficheiros");
define("FMLAN_14", "Pasta");
define("FMLAN_15", "Pastas");
define("FMLAN_16", "Pasta raiz");
define("FMLAN_17", "Nome");
define("FMLAN_18", "Tamanho");
define("FMLAN_19", "Última modificação");
define("FMLAN_21", "Transferir ficheiro para esta pasta");
define("FMLAN_22", "Transferir");
define("FMLAN_26", "Eliminado");
define("FMLAN_27", "com sucesso");
define("FMLAN_28", "Não foi possível apagar");
define("FMLAN_29", "Caminho");
define("FMLAN_30", "Nível anterior");
define("FMLAN_31", "Pasta");
define("FMLAN_32", "Seleccione a pasta");
define("FMLAN_33", "Seleccionar");
define("FMLAN_34", "Pasta escolhida");
define("FMLAN_35", "Pasta/Arquivos");
define("FMLAN_36", "Pasta de menus personalizados");
define("FMLAN_37", "Pasta de páginas personalizadas");
define("FMLAN_38", "Movido com sucesso para");
define("FMLAN_39", "Não foi possível mover o ficheiro para");
define("FMLAN_40", "Pasta de notícias-imagens");
define("FMLAN_43", "Apagar ficheiros seleccionados");
define("FMLAN_46", "Faz favor, confirme que deseja APAGAR os ficheiros seleccionados.");
define("FMLAN_47", "Transferências de utilizadores");
define("FMLAN_48", "Mover selecção para");
define("FMLAN_49", "Faz favor, confirme que deseja mover os ficheiros seleccionados.");
define("FMLAN_50", "Mover");
define("FMLAN_51", "Erro não identificado:");


?>