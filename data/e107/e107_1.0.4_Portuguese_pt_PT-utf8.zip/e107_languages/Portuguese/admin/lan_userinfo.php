<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("USFLAN_1", "Não foi possível encontrar o endereço de IP do utilizador - não existe informação disponivel.");
// define("USFLAN_2", "Erro");
define("USFLAN_3", "Mensagens enviadas deste endereço de IP");
define("USFLAN_4", "Servidor"); //Host
define("USFLAN_5", "Clique aqui para transferir o endereço de IP para a página de administração > banir");
define("USFLAN_6", "ID do utilizador");
define("USFLAN_7", "Informação do utilizador");

?>