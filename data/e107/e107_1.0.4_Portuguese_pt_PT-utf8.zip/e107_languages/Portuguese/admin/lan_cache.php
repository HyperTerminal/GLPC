<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CACLAN_1", "Ativar o sistema de cache?");
define("CACLAN_2", "Definir estado do cache");
define("CACLAN_3", "Sistema de cache");
define("CACLAN_4", "Estado do cache alterado");
define("CACLAN_5", "Limpar cache");
define("CACLAN_6", "Cache limpo");
define("CACLAN_7", "Cache inactivo");
define("CACLAN_9", "Guardar dados de cache em ficheiro");
define("CACLAN_10", "A pasta de cache não tem permissões de escrita. Faz favor certifique-se que as suas propriedades são alteradas com 'CHMOD 777'");


?>