<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("EXTLAN_1", "Nome");
define("EXTLAN_2", "Pre-visualizar");
define("EXTLAN_3", "Valores");
define("EXTLAN_4", "Obrigatório.");
define("EXTLAN_5", "Aplicável");
define("EXTLAN_6", "Acesso leitura");
define("EXTLAN_7", "Acesso escrita");
define("EXTLAN_8", "Opção");
define("EXTLAN_9", "Campos Adicionais de Utilizador");
define("EXTLAN_10", "Nome do campo");
define("EXTLAN_11", "Este é o nome do campo registado na tabela, deverá ser diferente de qualquer outro");
define("EXTLAN_12", "Texto do campo");
define("EXTLAN_13", "Este é o nome do campo que será mostrado na página");
define("EXTLAN_14", "Tipo de Campo");
define("EXTLAN_15", "Parâmetros do tipo de campo");
define("EXTLAN_16", "Valor por Defeito");
define("EXTLAN_17", "Escreva as opções possíveis em cada linha <br /> Para a tabela da BD consulte a ajuda.");
define("EXTLAN_18", "Obrigatório");
define("EXTLAN_19", "Os utilizadores serão obrigados a inserir um valor no campo quando estiverem a actualizar as suas definições.");
define("EXTLAN_20", "Determina quais os utilizadores que serão afectados por este campo.");
define("EXTLAN_21", "Determina quem visualizará este campo nas suas definições de utilizador.");
define("EXTLAN_22", "Determina quem visualizará este campo na página do utilizador / lista de membros <br />NOTA: Ao seleccionar 'só leitura' fará com que este campo seja visível apenas a administradores e membros registados.");
define("EXTLAN_23", "Inserir Campo Adicional");
define("EXTLAN_24", "Actualizar Campo Adicional");
define("EXTLAN_25", "Mover baixo");
define("EXTLAN_26", "Mover cima");
define("EXTLAN_27", "Confirmar Eliminação");
define("EXTLAN_28", "Não existem campos adicionais definidos");
define("EXTLAN_29", "Campos adicionais de utilizador salvos.");
define("EXTLAN_30", "Campo adicional eliminado");
define("EXTLAN_33", "Cancelar Edição");
define("EXTLAN_34", "Campos Adicionais");
define("EXTLAN_35", "Categorias");
define("EXTLAN_36", "Não existem categorias atribuidas");
define("EXTLAN_37", "Não existem categorias definidas");
define("EXTLAN_38", "Nome categoria");
define("EXTLAN_39", "Adicionar categoria");
define("EXTLAN_40", "Categoria adicionada");
define("EXTLAN_41", "Categoria eliminada");
define("EXTLAN_42", "Actualizar Categoria");
define("EXTLAN_43", "Categoria Actualizada");
define("EXTLAN_44", "Categoria");
define("EXTLAN_45", "Adicionar Novo Campo");
define("EXTLAN_46", "Ajuda");
define("EXTLAN_47", "Adicionar novo parâmetro");
define("EXTLAN_48", "Adicionar novo valor");
define("EXTLAN_49", "Permitir ocultar o utilizador");
define("EXTLAN_50", "Ao definir como 'sim' irá permitir ao utilzador ocultar este valor a todos excepto os administradores");
define("EXTLAN_51", "Aqui poderá inserir qualquer parâmetro w3c<br />p.exo. <i><b>class='tbox' size='40' maxlength='80'</i></b>");
define("EXTLAN_52", "Código de validação regex");
define("EXTLAN_53", "Insira o código regex que terá que ser correspondido para ser aceite como uma entrada válida <br />**Os delimitadores regex são obrigatórios**");
define("EXTLAN_54", "Falha no texto regex");
define("EXTLAN_55", "Insira a mensagem de erro mostrada quando a validação regex é inválida.");
define("EXTLAN_56", "Campos Pré-definidos");
define("EXTLAN_57", "Activado");
define("EXTLAN_58", "Não activado");
define("EXTLAN_59", "Activar");
define("EXTLAN_60", "Desactivar");
define("EXTLAN_61", "Nenhum");
define("EXTLAN_62", "Tabela");
define("EXTLAN_63", "Id campo");
define("EXTLAN_64", "Valor mostrado");
define("EXTLAN_65", "Não - Não será mostrado na página de registo");
define("EXTLAN_66", "Sim - Será mostrado na página de registo");
define("EXTLAN_67", "Não - Mostrar na página de registo");
define("EXTLAN_68", "Campo");
define("EXTLAN_69", "Foi activado");
define("EXTLAN_70", "ERRO! no campo:");
define("EXTLAN_71", "Não foi activado!");
define("EXTLAN_72", "foi desactivado");
define("EXTLAN_73", "Não foi desligado!");
define("EXTLAN_74", "é um nome de campo reservado e não pode ser utilizado.");
define("EXTLAN_75", "Erro ao adicionar campos na base de dados.");
define("EXTLAN_76", "Caracteres inválidos no nome do campo - apenas AZ, az, 0-9, é permitido.");
define("EXTLAN_77", "Categoria não eliminada - deve eliminar campos na primeira categoria:");
define("EXTLAN_78", "Não é possível localizar o arquivo - FILE - dados necessários para criar tabela");
define("EXTLAN_79", "Erro de validação - abortada.");
define("EXTLAN_HELP_1", "<b><i>Parâmetros:</i></b><br />size - tamanho do campo<br />maxlength - comprimento máx. do campo<br /><br />class - classe css do campo<br />style - string de estilo css<br /><br />regex - código de validação regex<br />regexfail - texto para a falha de validação");
define("EXTLAN_HELP_2", "Este será o texto de ajuda para os 'BotõesRádio'");
define("EXTLAN_HELP_3", "Este será o texto de ajuda para os 'MenusDrop-Down'");
define("EXTLAN_HELP_4", "<b><i>Valores:</i></b><br />Terá que fornecer SEMPRE três valores:<br /><ol><li>tabelaBD</li><li>campo contendo a id</li><li>campo contendo o valor</li></ol><br />");
define("EXTLAN_HELP_5", "Este será o texto de ajuda para os para a 'ÁreaTexto'");
define("EXTLAN_HELP_6", "Este será o texto de ajuda para os 'Inteiros'");
define("EXTLAN_HELP_7", "Este será o texto de ajuda para a 'Data'");
define("EXTLAN_HELP_8", "Permitir ao utilizador seleccionar a partir de idiomas instalados");


?>