<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_head_1", "Navegação do administrador");
define("LAN_head_2", "O seu servidor não suporta transferências de ficheiros por HTTP, como tal não será possivel aos utilizadores transferirem os seus avatars, ficheiros, etc. Para rectificar esta situação, deverá alterar o seu ficheiro php.ini colocando a opção 'file_uploads' em 'on' e reiniciar o seu servidor. Se não tem acesso ao ficheiro php.ini deverá contactar o administrador do servidor onde o site está alojado.");
define("LAN_head_3", "O seu servidor está a correr com restrições na directoria principal. Esta situação não permite a utilização de qualquer ficheiro fora da directoria principal e poderá afectar determinados scripts tais como o gestor de ficheiros.");

define("LAN_head_4", "Área de administração");

define("LAN_head_5", "Idioma mostrado na área de administração: ");
define("LAN_head_6", "Informação de plugins");

?>