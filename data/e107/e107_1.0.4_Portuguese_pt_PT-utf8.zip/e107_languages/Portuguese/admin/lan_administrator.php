<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ADMSLAN_0", "Novo utilizador/administrador criado para");
define("ADMSLAN_1", "agora com estado de administrador.");
define("ADMSLAN_2", "actualizado na base de dados.");
define("ADMSLAN_3", "é o administrador principal do sitio e não pode ser editado.");
define("ADMSLAN_4", "Continuar");
define("ADMSLAN_5", "Erro!");
define("ADMSLAN_6", "é o administrador principal do sitio e não pode ser apagado.");
define("ADMSLAN_13", "Administradores Existentes");
define("ADMSLAN_16", "Nome Admin");
define("ADMSLAN_17", "Senha Admin");
define("ADMSLAN_18", "Permissões");
define("ADMSLAN_19", "Alterar definições do sitio");
define("ADMSLAN_20", "Alterar Menus");
define("ADMSLAN_21", "Modificar permissões de administrador");
define("ADMSLAN_22", "Moderar utilizadores/expulsos, etc.");
define("ADMSLAN_23", "Criar/editar menus e páginas pessoais");
define("ADMSLAN_24", "Gerir categorias de descargas");
define("ADMSLAN_25", "Transferências/gestão de arquivos");
define("ADMSLAN_26", "Gestão de categorias de notícias");
define("ADMSLAN_27", "Gestão de categorias links");
define("ADMSLAN_28", "Desligar o sítio para manutenção");
define("ADMSLAN_29", "Gerir anúncios");
define("ADMSLAN_30", "Configurar cabeçalhos de feeds de notícias");
define("ADMSLAN_31", "Configurar ícones de emoção");
define("ADMSLAN_32", "Configurar conteúdo da página principal");
define("ADMSLAN_33", "Configurar registos/estatísticas");
define("ADMSLAN_34", "Configurar etiquetas/meta");
define("ADMSLAN_35", "Configurar transferências públicas");
define("ADMSLAN_36", "Configurar Opções de Imagem");
define("ADMSLAN_37", "Moderar Comentários");
define("ADMSLAN_39", "Publicar notícias");
define("ADMSLAN_40", "Publicar links");
define("ADMSLAN_44", "Publicar descargas");
define("ADMSLAN_45", "Publicar votações");
define("ADMSLAN_46", "Mensagem de boas vindas");
define("ADMSLAN_47", "Moderar notícias enviadas");
define("ADMSLAN_49", "Marcar Tudo");
define("ADMSLAN_51", "Desmarcar Tudo");
define("ADMSLAN_52", "Actualizar administrador");
define("ADMSLAN_53", "Adicionar administrador");
define("ADMSLAN_54", "Administradores");
define("ADMSLAN_55", "Deixou campos em branco");
define("ADMSLAN_56", "Administrador");
define("ADMSLAN_58", "Administrador Principal");
define("ADMSLAN_59", "Remover estado de administrador");
define("ADMSLAN_60", "Tem a certeza que deseja remover o estado de administrador");
define("ADMSLAN_61", "Administrador removido!");
define("ADMSLAN_62", "Gestor de plugins");
define("ADMSLAN_64", "Limpar o cache do sistema");
define("ADMSLAN_65", "Configurar definições de envio de email");
define("ADMSLAN_66", "Configurar Pesquisas");
define("ADMSLAN_67", "Analisar com o inspector de arquivos");
define("ADMSLAN_68", "Configurar notificações de email");
define("ADMSLAN_69", "já é um administrador e deve ser editado.");
define("ADMSLAN_70", "Voltar à lista de Administradores");
define("ADMSLAN_71", "Clique aqui para mostrar os privilégios");
define("ADMSLAN_76", "Gestão de Pacote de idioma");


?>