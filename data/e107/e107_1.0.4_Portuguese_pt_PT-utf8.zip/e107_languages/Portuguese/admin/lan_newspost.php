<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("NWSLAN_1", "Notícia apagada.");
define("NWSLAN_2", "Clique na caixa para confirmar que quer apagar esta notícia.");
define("NWSLAN_3", "Não há notícias por enquanto.");
define("NWSLAN_4", "Notícias Existentes");
define("NWSLAN_5", "Abrir o Editor HTML");
define("NWSLAN_6", "Categoria");
define("NWSLAN_9", "Clique para confirmar");
define("NWSLAN_10", "Não há categorias definidas ainda.");
define("NWSLAN_11", "Adicionar/Editar Categorias");
define("NWSLAN_12", "Título");
define("NWSLAN_13", "Corpo");
define("NWSLAN_14", "Extensão");
define("NWSLAN_15", "Comentários");
define("NWSLAN_18", "Permitir comentários para esta notícia");
define("NWSLAN_19", "Activação");
define("NWSLAN_21", "Activar entre");
define("NWSLAN_22", "Visibilidade");
define("NWSLAN_24", "Nova Visualização");
define("NWSLAN_25", "Atualizar notícia na base da dados");
define("NWSLAN_26", "Salvar notícia na base de dados");
define("NWSLAN_27", "Vista Previa");
define("NWSLAN_29", "Notícias Enviadas");
define("NWSLAN_31", "Nova Notícia");
define("NWSLAN_32", "Apagada");
define("NWSLAN_33", "Categoria de Notícias");
define("NWSLAN_34", "Envio de notícias");
define("NWSLAN_35", "Categoria de Notícia Salva");
define("NWSLAN_36", "Categoria de Notícia Atualizada");
define("NWSLAN_37", "Tem certeza de apagar esta categoria?");
define("NWSLAN_38", "Tem certeza de apagar esta notícia enviada?");
define("NWSLAN_39", "Tem certeza de apagar esta notícia?");
define("NWSLAN_40", "Título");
define("NWSLAN_42", "Sem Título");
define("NWSLAN_43", "Sem Notícias");
define("NWSLAN_44", "Página Principal de Notícias");
define("NWSLAN_45", "Criar Notícia");
define("NWSLAN_46", "Categorias");
define("NWSLAN_47", "Notícia Enviada");
define("NWSLAN_48", "Opções de Notícias");
define("NWSLAN_49", "Enviada por");
define("NWSLAN_51", "Categorias de Notícias Existentes");
define("NWSLAN_52", "Nome da Categoria");
define("NWSLAN_53", "Ícone da Categoria");
define("NWSLAN_54", "Ver Imagens");
define("NWSLAN_55", "Actualizar Categoria de Notícias");
define("NWSLAN_56", "Criar Categoria de Notícias");
define("NWSLAN_57", "Tema");
define("NWSLAN_58", "Publicar");
define("NWSLAN_59", "Sem envio de notícias");
define("NWSLAN_62", "Ir para página:");
define("NWSLAN_63", "Procurar notícia");
define("NWSLAN_66", "Transferência");
define("NWSLAN_67", "Imagem");
define("NWSLAN_68", "Arquivo");
define("NWSLAN_69", "Transferência de imagem ou arquivo para uso no ítem de notícias");
define("NWSLAN_72", "Apenas notícias entre certas datas");
define("NWSLAN_73", "Tipo de execução");
define("NWSLAN_74", "Seleccione como e onde a notícia é publicada");
define("NWSLAN_75", "Publicar na página principal - Padrão");
define("NWSLAN_76", "Publicar na página principal - Só Título ");
define("NWSLAN_77", "Publicar em outro menu de notícias");
define("NWSLAN_79", "Limpar Formulário");
define("NWSLAN_83", "Publicar Notícia Completa");
define("NWSLAN_84", "Escolher os visitantes que podem ver notícias");
define("NWSLAN_86", "Mostrar Menu de Categorias no Rodapé");
define("NWSLAN_87", "Nº de Colunas de Categoria de Notícias?");
define("NWSLAN_88", "Nº de Publicações por página?");
define("NWSLAN_89", "Salvar Preferências de Notícias");
define("NWSLAN_90", "Preferências de Notícias");
define("NWSLAN_100", "Habilitar subida de imagem na página de envio de notícias");
define("NWSLAN_101", "Redimensionamento automático de imagem enviada");
define("NWSLAN_102", "comprimento em pixel<br> ou deixe em branco para desabilitar.");
define("NWSLAN_103", "re-enviar");
define("NWSLAN_104", "por");
define("NWSLAN_105", "Clique nesta caixa para actualizar a data de gravação da notícia a data presente");
define("NWSLAN_106", "Notícias enviadas vista por:");
define("NWSLAN_107", "Habilitar editor WYSIWYG em envio de notícias.");
define("NWSLAN_108", "Activo");
define("NWSLAN_111", "Mostre o novo encabeçamento da data");
define("NWSLAN_112", "<u>Clicando nesta opção, uma caixa que conta a data será indicada acima dos artigos de notícia postados em novos dias, sendo útil para distinguir publicações feitas em dias diferentes</u>");
define("NWSLAN_113", "Use o desenho não padronizado para a disposição da notícia");
define("NWSLAN_114", "<u>Se o desenho do seu tema para as notícia, em vez do desenho genérico</u>");
define("NWSLAN_115", "Postar notícia para indicar um arquivo?");
define("NWSLAN_116", "<u>Actualize primeiramente as preferências com a exibição mudada para a exibição da página, depois actualize então outra vez a preferência arquivo-notícia. <b>(0 (zero) são desactivados)</b></u>");
define("NWSLAN_117", "Definir o título para o arquivo de notícias");
define("NWSLAN_119", "Configurações Salvas");
define("NWSLAN_120", "Texto para ser mostrado no topo de notícias enviadas");
define("LAN_NEWS_5", "Erro! - Impossível actualizar a notícia na base de dados!");
define("LAN_NEWS_6", "Notícia inserida na base de dados.");
define("LAN_NEWS_7", "Erro! - Impossível inserir a notícia na base de dados!");
define("LAN_NEWS_9", "Definir Somente o título é ajustado - <b>somente o título da notícia será mostrado</b>");
define("LAN_NEWS_10", "Esta publicação de notícia está <b>inactiva</b> (Não se mostrará na página inicial).");
define("LAN_NEWS_11", "Esta publicação da notícia está <b>ativa</b> (será mostrada na página principal).");
define("LAN_NEWS_12", "Comentários para esta notícia <b>on</b>.");
define("LAN_NEWS_13", "Comentários para esta notícia <b>off</b>.");
define("LAN_NEWS_14", "<br />Período de activação:");
define("LAN_NEWS_15", "Comprimento do corpo:");
define("LAN_NEWS_16", "b. Comprimento prolongado:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Informação");
define("LAN_NEWS_19", "Agora");
define("LAN_NEWS_21", "Notícia actualizada na base de dados.");
define("LAN_NEWS_22", "Miniatura");
define("LAN_NEWS_23", "Escolha a imagem/ícone para a notícia");
define("LAN_NEWS_24", "Imagem + Auto-miniatura");
define("LAN_NEWS_25", "Tamanho do Auto-miniatura");
define("LAN_NEWS_26", "Adicionar");
define("LAN_NEWS_27", "Resumo");
define("LAN_NEWS_28", "Fixar");
define("LAN_NEWS_29", "Selecione se o artigo será fixado");
define("LAN_NEWS_30", "Se seleccionado, o artigo aparecerá sobre todo os outros");
define("LAN_NEWS_31", "Esta publicação de notícia está <b>fixada</b> (será mostrada sobre todos os outras notícias)");
define("LAN_NEWS_32", "Salvar data");
define("LAN_NEWS_33", "Definir a data atual para a notícia.");
define("LAN_NEWS_34", "TrackBack");
define("LAN_NEWS_35", "Adicionar url's de trackback");
define("LAN_NEWS_36", "<b>Pingback</b> (emita um pingback a todos as URL's nesta publicação)");
define("LAN_NEWS_37", "<b>Url do Trackback:</b> (Uma url por linha)");
define("LAN_NEWS_38", "Inserir imagens");
define("LAN_NEWS_39", "clique no arquivo para inserir a posição do cursor");
define("LAN_NEWS_40", "Inserir hiperligação de descarga");
define("LAN_NEWS_42", "Arquivos");
define("LAN_NEWS_44", "Trackback não habilitado");
define("LAN_NEWS_45", "ID");
define("LAN_NEWS_46", "A notícia não foi actualizada e nenhuma mudança foi feita.");
define("LAN_NEWS_48", "Sem imagem");
define("LAN_NEWS_49", "Tipo de renderização");
define("LAN_NEWS_50", "Manutenção");
define("LAN_NEWS_51", "Recalcular contagem comentário");
define("LAN_NEWS_52", "Continuar");
define("LAN_NEWS_53", "Transferência completa");
define("LAN_NEWS_54", "Manutenção de Notícias");
define("LAN_NEWS_55", "Autor (Postado por)");
define("LAN_NEWS_56", "Postado");
define("LAN_NEWS_61", "Excluir comentários não permitidos");
define("LAN_NEWS_62", "Erro de acesso a base de dados, ou notícia não encontrada");


?>