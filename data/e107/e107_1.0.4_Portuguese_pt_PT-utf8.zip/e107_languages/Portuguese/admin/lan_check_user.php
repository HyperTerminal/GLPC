<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_CKUSER_01", "Verificar banco de dados");
define("LAN_CKUSER_02", "Este irá verificar vários problemas potenciais com o banco de dados do utilizador");
define("LAN_CKUSER_03", "Se você tem muitos utilizadores, pode levar algum tempo");
define("LAN_CKUSER_04", "Continuar");
define("LAN_CKUSER_05", "Verificar nomes duplicados no inicio de sessão");
define("LAN_CKUSER_06", "Seleccione para executar as funções");
define("LAN_CKUSER_07", "Nomes de utilizador duplicados encontrado");
define("LAN_CKUSER_08", "Sem duplicados");
define("LAN_CKUSER_09", "Nome de Utilizador");
define("LAN_CKUSER_10", "ID de Utilizador");
define("LAN_CKUSER_11", "Nome a mostrar");
define("LAN_CKUSER_12", "Verificar se há endereços de email duplicados");
define("LAN_CKUSER_13", "Endereços de email encontrados");
define("LAN_CKUSER_14", "Endereços de email");
define("LAN_CKUSER_15", "Sem duplicar");
define("LAN_CKUSER_16", "Buscar entradas com nome do utilizador e nome de acesso");
define("LAN_CKUSER_17", "Conflito entre nome de utilizador e nome de acesso");
define("LAN_CKUSER_18", "Utilizador A");
define("LAN_CKUSER_19", "Utilizador B");
define("LAN_CKUSER_20", "");


?>