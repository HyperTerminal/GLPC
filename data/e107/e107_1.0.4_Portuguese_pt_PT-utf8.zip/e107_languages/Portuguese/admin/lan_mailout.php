<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PRFLAN_52", "Salvar Alterações");
define("PRFLAN_63", "Enviar email de teste");
define("PRFLAN_65", "Clique para enviar a");
define("PRFLAN_66", "Email de teste de");
define("PRFLAN_67", "Este é um email de teste. Aparentemente não existem problemas nas suas definições de email e está tudo a funcionar perfeitamente!\n\nCumprimentos\ndo seu sistema e107.");
define("PRFLAN_68", "O email não foi enviado. Aparentemente o seu servidor não está configurado correctamente para enviar e-mails. Por favor volte a tentar usando agora o SMTP ou contacte o seu administrador do alojamento, no sentido de verificar as definições de envios/e-mail do seu servidor.");
define("PRFLAN_69", "O e-mail foi enviado com sucesso, faz favor, verifique a sua caixa de entrada.");
define("PRFLAN_70", "Método de envio");
define("PRFLAN_71", "Se não tiver a certeza deixe como 'php'");
define("PRFLAN_72", "Servidor - SMTP");
define("PRFLAN_73", "Utilizador - SMTP");
define("PRFLAN_74", "Senha - SMTP");
define("PRFLAN_75", "O e-mail não foi enviado. Faz favor, reveja as definições de SMTP, ou desligue o SMTP e tente de novo.");
define("MAILAN_01", "Nome do remetente");
define("MAILAN_02", "Email do remetente");
define("MAILAN_03", "Para");
define("MAILAN_04", "Cc");
define("MAILAN_05", "Bcc");
define("MAILAN_06", "Assunto");
define("MAILAN_07", "Anexo");
define("MAILAN_08", "Enviar email");
define("MAILAN_09", "Usar Estilo do Tema");
define("MAILAN_10", "Utilizador Subscrito");
define("MAILAN_11", "Inserir Variáveis");
define("MAILAN_12", "Todos os Membros");
define("MAILAN_13", "Todos os membros não verificados");
define("MAILAN_14", "É recomendável ligar o SMTP quando enviar um grande número de e-mails - ajuste as definições em baixo.");
define("MAILAN_15", "Envios de correio");
define("MAILAN_16", "Utilizador");
define("MAILAN_17", "Link de registo");
define("MAILAN_18", "ID do utilizador");
define("MAILAN_19", "Não existe endereço de e-mail para o administrador principal do site. Faz favor, verifique as suas definições e tente de novo.");
define("MAILAN_20", "Caminho do Sendmail");
define("MAILAN_21", "Itens de envio massivo");
define("MAILAN_22", "Não existem itens guardados");
define("MAILAN_23", "Classe de utilizador:");
define("MAILAN_24", "Os e-mails estão prontos para serem enviados");
define("MAILAN_25", "Pause");
define("MAILAN_26", "Pausar todos os mailing");
define("MAILAN_27", "Emails");
define("MAILAN_28", "Tamanho da Pause");
define("MAILAN_29", "segundos");
define("MAILAN_30", "Mais de 30 segundos podem fazer com que o browser fique fora de tempo");
define("MAILAN_31", "Processamento de retorno de E-mail");
define("MAILAN_32", "Endereço de E-mail");
define("MAILAN_33", "Nos próximos E-mail");
define("MAILAN_34", "Nome da Conta");
define("MAILAN_35", "Senha");
define("MAILAN_36", "Excluir e-mails devolvidos após a verificação");
define("MAILAN_37", "Continuar");
define("MAILAN_38", "Cancelar");
define("MAILAN_39", "Emails");
define("MAILAN_40", "Você precisa mudar <b>e107.htaccess</b> para <b>.htaccess</b> em");
define("MAILAN_41", "Antes de enviar correio a partir desta página.");
define("MAILAN_42", "Atenção");
define("MAILAN_43", "Utilizador");
define("MAILAN_44", "Acesso do Utilizador");
define("MAILAN_45", "Email do Utilizador");
define("MAILAN_46", "Utilizadores que sejam iguais a");
define("MAILAN_47", "contém");
define("MAILAN_48", "igual");
define("MAILAN_49", "ID");
define("MAILAN_50", "Autor");
define("MAILAN_51", "Assunto");
define("MAILAN_52", "Última modificação");
define("MAILAN_53", "Administradores");
define("MAILAN_54", "Auto Enviar-me");
define("MAILAN_55", "Classe de Utilizador");
define("MAILAN_56", "Enviar E-mail");
define("MAILAN_57", "Manter a sessão SMTP activa");
define("MAILAN_58", "Há um problema com o arquivo anexado:");
define("MAILAN_59", "Progresso do envio de e-mail");
define("MAILAN_60", "Enviando...");
define("MAILAN_61", "Não há emails remanescentes a enviar.");
define("MAILAN_62", "Emails enviados:");
define("MAILAN_63", "Emails que falharam:");
define("MAILAN_64", "Tempo total do envio:");
define("MAILAN_65", "segundos");
define("MAILAN_66", "Cancelado com sucesso");
define("MAILAN_67", "Usar autenticação 'POP antes de SMTP'");
define("MAILAN_68", "Teste de endereço");
define("MAILAN_69", "Senha de utilizador");
define("MAILAN_70", "Email de utilizador");


?>