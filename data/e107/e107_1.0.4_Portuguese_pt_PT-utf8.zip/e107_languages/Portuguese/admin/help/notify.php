<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Notificações";
$text = "As notificações enviam e-mails de aviso quando ocorrem eventos no e107.<br /><br />
Por exemplo, se definir 'IP expulsos por flooding no site' para a classe 'Administrador',
todos os administradores receberão um e-mail quando o seu site sofrer um flood.<br /><br />
Poderá ainda a título de exemplo, definir 'Notícias publicadas por admin' para a classe 'Membros',
e todos os seu utilizadores registados irão receber um e-mail com as notícias que publicar no seu site.<br /><br />
Se desejar enviar as notificações por e-mail para um endereço alternativo, deverá seleccionar a opção 'E-mail',
e inserir o novo endereço no campo correspondente.";

$ns -> tablerender($caption, $text);
?>