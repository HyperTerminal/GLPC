<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Sistema de cache";
$text = "Ao ligar o sistema de cache irá aumentar substancialmente a velocidade no seu site, minimizará a quantidade de chamadas à base de dados SQL.<br /><br />
		<b>IMPORTANTE!</b> <i>Se está a realizar/experimentar o seu próprio tema, deverá desligar o sistema de cache, uma vez que as alterações que efectuar não serão visualizadas.</i>";
$ns -> tablerender($caption, $text);
?>