<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Gestor de ficheiros";
$text = "Poderá gerir os seus ficheiros na directoria /files a partir desta página.<br />
Se obtiver um erro de permissões durante a transferência de um ficheiro,
deverá efectuar um CHMOD 777 à directoria para a qual está a transferir o arquivo.";
$ns -> tablerender($caption, $text);
?>