<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Administração do site";
$text = "Utilize esta página para editar as definições ou apagar administradores do seu site.
		O administrador só terá permissões de acesso às funções que se encontrem seleccionadas.<br /><br />
		Para criar um novo administrador deverá aceder às configurações de utilizadores e conceder permissões de administração a um utilizador existente.";
$ns -> tablerender($caption, $text);
?>