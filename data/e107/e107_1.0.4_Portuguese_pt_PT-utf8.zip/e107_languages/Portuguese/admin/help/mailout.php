<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Correio Electrónico - e-Mail";
$text = "Utilize esta página para configurar as definições de e-mail e as funções de envio do seu site.
O formulário de envio de e-mail também lhe permite enviar uma mensagem rápida a todos os utilizadores.";
$ns -> tablerender($caption, $text);
?>