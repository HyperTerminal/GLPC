<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Pesquisar";
$text = "Se a versão utilizada no seu servidor MySql suportar o método de ordenação,
deverá utilizá-la uma vez que este método é mais rápido que o utilizado pelo PHP. Ver definições.<br /><br />
Se o seu site incluir línguas ideográficas tais como o Chinês e o Japonês deverá utilizar o método de ordenação do PHP e desactivar a ocorrência total de palavras.";
$ns -> tablerender($caption, $text);
?>