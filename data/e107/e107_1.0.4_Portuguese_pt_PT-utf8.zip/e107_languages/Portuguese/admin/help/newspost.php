<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Publicação de Notícias";
$text = "<b>Geral</b><br />
O conteúdo da notícia será mostrado na página principal, a extensão será mostrada ao clicar no link 'Ler tudo'.
<br />
<br />
<b>Mostrar apenas Título</b>
<br />
Permite mostar apenas o título na página principal com um link para ler a notícia completa.
<br />
<br />
<b>Activação</b>
<br />
Se definir uma data de início e/ou fim a sua notícia será mostrada no site apenas durante este período.
";
$ns -> tablerender($caption, $text);
?>