<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
		# Expulsar utilizadores";
$text = "Poderá expulsar utilizadores do seu site a partir desta página.<br />
Poderá utilizar o endereço completo de IP ou um wildcard para expulsar um intervalo de endereços de IP.
Poderá ainda inserir o endereço de e-mail para impedir o registo de um deteminado utilizador no seu site.<br /><br />
<b>Expulsar por endereço de IP:</b><br />
Insira o endereço de IP sob a forma '123.123.123.123', desta forma impedirá o utilizador com este endereço de visitar o seu site.<br />
Se optar por inserir o endereço '123.123.123.*', então bloqueará o acesso a este intervalo de IPs.<br /><br />
<b>Expulsar por endereço de e-mail</b><br />
Ao utilizar o endereço de email 'user@domain.com' irá impedir que alguem com este endereço de email, se registe no seu site como membro.<br />
Ao inserir o endereço de email '*@domain.com' irá impedir o registo no site a todos os utilizadores que usem este domínio de email.<br /><br />
<b>Expulsar por nome de utilizador</b><br />Isso é feito a partir da página de administração de utilizador.";
$ns -> tablerender($caption, $text);
?>