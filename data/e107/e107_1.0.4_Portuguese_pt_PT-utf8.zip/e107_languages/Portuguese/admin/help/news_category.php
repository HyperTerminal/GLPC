<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Categorias de Notícias";
$text = "Poderá separar as suas notícias em categorias diferentes e permitir aos seus utilizadores visualizem apenas as notícias nessas categorias.
<br /><br />Deverá efectuar o upload dos seus ícones de imagem de noticias para ".e_THEME."-seutema-/images/ ou themes/shared/newsicons/.";
$ns -> tablerender($caption, $text);
?>