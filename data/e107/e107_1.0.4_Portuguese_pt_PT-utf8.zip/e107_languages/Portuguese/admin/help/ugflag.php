<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Ajuda:<br />
			# Manutenção do site";
$text = "Se necessitar de efectuar uma actualização ao seu sistema e107,
ou desligar o seu site temporáriamente por algum motivo, deverá ligar a opção de manutenção.<br /><br />
Os seus utilizadores serão redireccionados para uma página
que os informa que o site está desligado para manutenção/actualização.
Após ter desligado esta opção, o seu site voltará ao funcionamento normal.";

$ns -> tablerender($caption, $text);
?>