<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('UGFLAN_1', 'Definições de manutenção atualizadas');
define('UGFLAN_2', 'Ativar manutenção'); //Activate maintenance flag
define('UGFLAN_3', 'Atualizar definições de manutenção');
define('UGFLAN_4', 'Definições de manutenção');

define('UGFLAN_5', 'Texto mostrado quando o sítio estiver inacessível');
define('UGFLAN_6', 'Deixe em branco para mostrar a mensagem por defeito');

define('UGFLAN_8', 'Só acesso aos Admins');
define('UGFLAN_9', 'Só acesso aos Admins Principais');

?>