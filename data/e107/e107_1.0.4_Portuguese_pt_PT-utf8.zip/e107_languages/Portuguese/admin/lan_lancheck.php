<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_CHECK_1", "Editar/verificar arquivos de idioma");
define("LAN_CHECK_2", "Verificar");
define("LAN_CHECK_3", "Verificação de ");
define("LAN_CHECK_4", "Arquivos em falta!");
define("LAN_CHECK_5", "Frase em falta!");
define("LAN_CHECK_7", "Frase");
define("LAN_CHECK_8", "Arquivo em falta...");
define("LAN_CHECK_9", "arquivos em falta...");
define("LAN_CHECK_10", "Erro crítico: ");
define("LAN_CHECK_11", "Não foram detetados arquivos em falta!");
define("LAN_CHECK_12", "Existe um arquivo errado...");
define("LAN_CHECK_13", "arquivo errados...");
define("LAN_CHECK_14", "Todos os arquivos foram validados!");
define("LAN_CHECK_15", "Caracteres e espaços ilegais encontrados antes de '<?php' e depois de '?>'");
define("LAN_CHECK_16", "Arquivo Original");
define("LAN_CHECK_17", "Um problema de escrita ocorreu enquanto tentava salvar o arquivo.");
define("LAN_CHECK_18", "Arquivos de idioma no formato padrão NÃO estão disponíveis para este plugin/tema.");
define("LAN_CHECK_19", "Caracteres UTF-8 não encontrado!");
define("LAN_CHECK_20", "Criar Pacote de Idioma");
define("LAN_CHECK_21", "Nova Verificação");
define("LAN_CHECK_22", "Tema");
define("LAN_CHECK_23", "Erros encontrados");
define("LAN_CHECK_24", "Resumo");
define("LAN_CHECK_25", "Temas");
define("LAN_CHECK_26", "Arquivo");


?>