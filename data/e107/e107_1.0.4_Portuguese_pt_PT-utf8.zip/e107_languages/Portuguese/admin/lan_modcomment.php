<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderado.");
define("MDCLAN_2", "Não existem comentários");
define("MDCLAN_3", "Membro");
define("MDCLAN_4", "Visitante");
define("MDCLAN_5", "Desbloquear");
define("MDCLAN_6", "Bloquear");
define("MDCLAN_7", "Aprovado");
define("MDCLAN_8", "Moderar comentários");
define("MDCLAN_9", "AVISO! Se elimina o comentário principal, irá eliminar também todas as respostas!");
define("MDCLAN_10", "Opções");
define("MDCLAN_11", "Comentário");
define("MDCLAN_12", "Comentários");
define("MDCLAN_13", "Bloqueado");
define("MDCLAN_14", "Bloquear comentários");
define("MDCLAN_15", "Aberto");
define("MDCLAN_16", "Fechado");
define("MDCLAN_17", "Neste momento não há comentários pendentes para aprovação");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>