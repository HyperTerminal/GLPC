<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("USRLAN_1", "Definições Salvas.");
define("USRLAN_3", "foi definido/a como Administrador/a - para ajustar as suas permissões deverá de ir");
define("USRLAN_4", "Página de Administrador");
define("USRLAN_5", "Não pode remover o status de administrador ao admin principal do sitio.");
define("USRLAN_6", "ficou sem estado de administrador.");
define("USRLAN_7", "Não pode expulsar o administrador principal do sitio.");
define("USRLAN_8", "Utilizador expulso.");
define("USRLAN_9", "Utilizador não expulso.");
define("USRLAN_10", "Utilizador eliminado.");
define("USRLAN_11", "Eliminação cancelada.");
define("USRLAN_12", "Não pode apagar o administrador principal do sitio.");
define("USRLAN_13", "Por favor confirme que deseja apagar este utilizador");
define("USRLAN_16", "Confirmar eliminação");
define("USRLAN_17", "Confirmar eliminação de utilizador");
define("USRLAN_30", "Expulsar");
define("USRLAN_32", "Activar");
define("USRLAN_33", "Eliminar Expulso");
define("USRLAN_34", "Eliminar estado de admin");
define("USRLAN_35", "Tornar Admin");
define("USRLAN_36", "Definir classe");
define("USRLAN_44", "Permitir aos utilizadores a transferência do avatar?");
define("USRLAN_47", "Largura máxima do avatar (pixels)");
define("USRLAN_48", "Por defeito = 128");
define("USRLAN_49", "Altura máxima do avatar (pixels)");
define("USRLAN_50", "Por defeito = 128");
define("USRLAN_51", "Atualizar definições");
define("USRLAN_52", "Opções de membros");
define("USRLAN_53", "Permitir aos membros a transferência da sua fotografia?");
define("USRLAN_54", "Clique aqui para apagar todos os membros não activados");
define("USRLAN_55", "Purgar");
define("USRLAN_56", "Apagados");
define("USRLAN_57", "A remover membros não activados...");
define("USRLAN_58", "As transferências de ficheiros encotram-se desactivadas no php.ini");
define("USRLAN_59", "Adição Express");
define("USRLAN_60", "Adicionar utilizador");
define("USRLAN_61", "Utilizador");
define("USRLAN_62", "Senha");
define("USRLAN_63", "Escrever novamente a senha");
define("USRLAN_64", "Endereço de e-mail");
define("USRLAN_65", "Esse nome de utilizador não é válido, por favor escolha um nome diferente");
define("USRLAN_66", "Esse nome de utilizador já existe na base de dados, por favor escolha um nome diferente");
define("USRLAN_67", "As duas senhas não coincidem");
define("USRLAN_68", "Deixou campos obrigatórios em branco");
define("USRLAN_69", "Não aparenta ser um endereço de e-mail válido");
define("USRLAN_70", "Utilizador criado");
define("USRLAN_71", "Página Principal");
define("USRLAN_72", "Adição rápida de utilizador");
define("USRLAN_73", "Purgar");
define("USRLAN_75", "O nome de login já existe no banco de dados, faz favor, escolha um nome de início de sessão diferente");
define("USRLAN_76", "Opções de Utilizadores");
define("USRLAN_77", "Utilizadores Existentes");
define("USRLAN_78", "Nome do utilizador");
define("USRLAN_79", "Estado");
define("USRLAN_80", "Informação");
define("USRLAN_84", "Existem");
define("USRLAN_85", "utilizadores que aínda não activaram as suas contas - clique em baixo para removê-los.");
define("USRLAN_86", "Utilizador verificado");
define("USRLAN_87", "Definições do utilizador actualizadas");
define("USRLAN_88", "Classes de utilizadores actualizadas");
define("USRLAN_90", "Pesquisar/Refrescar");
define("USRLAN_91", "Classe");
define("USRLAN_92", "Caracteres inválidos no nome de utilizador");
define("USRLAN_93", "Apagar utilizadores não verificados");
define("USRLAN_94", "Apagar registos se não forem activados após este período de tempo - deixe em branco para não utilizar esta opção <br />Esta opção será ignorada se o registo de utilizadores for moderado por um adminstrador");
define("USRLAN_95", "minutos");
define("USRLAN_112", "Re-enviar email");
define("USRLAN_113", "Detalhes de registo para");
define("USRLAN_114", "Caro(a)");
define("USRLAN_115", "Obrigado pelo seu registo.");
define("USRLAN_116", "Faz favor, confirme que deseja re-enviar um email de confirmação a:");
define("USRLAN_117", "Clique no botão em baixo para testar o seguinte email:");
define("USRLAN_118", "Testar email");
define("USRLAN_120", "Definir classes");
define("USRLAN_121", "Envio");
define("USRLAN_122", "Bem-vind@");
define("USRLAN_123", "O seu registo foi recebido e criado.");
define("USRLAN_124", "A sua conta encontra-se inactiva, para activá-la deverá seguir a hiperligação em anexo");
define("USRLAN_125", "De");
define("USRLAN_126", "Permitir que os utilizadores avaliem outros utilizadores");
define("USRLAN_127", "Permitir comentários no perfil de utilizador");
define("USRLAN_128", "Iníciar Sessão");
define("USRLAN_130", "Ativar o seguimento de utilizadores ligados");
define("USRLAN_131", "Necessita de ativar esta definição para poder utilizar as opções de seguimento de utilizadores online (tais como informações online no site, no fórum, estatísticas, etc.)");
define("USRLAN_132", "Ativar");
define("USRLAN_133", "Forçar a actualização de definições de utilizadores");
define("USRLAN_134", "Ao activar esta opção, o utilizador será redireccionado automáticamente para a sua página de definições cada vez que não for preenchido um campo de utilizador obrigatório.");
define("USRLAN_135", "Não foi encontrado endereço de IP na informação do utilizador - IP não expulso");
define("USRLAN_136", "Vários utilizadores encontrados com o endereço de IP {IP} - IP não expulso.");
define("USRLAN_137", "o endereço de IP {IP} foi expulsado.");
define("USRLAN_138", "Não confirmados");
define("USRLAN_139", "A sua conta foi activada.\n\nPoderá visitar o {SITEURL} e efectuar o login com os dados fornecidos.");
define("USRLAN_140", "Re-enviar email para");
define("USRLAN_141", "Erro ao enviar o email para");
define("USRLAN_142", "com o seguinte link de activação");
define("USRLAN_143", "Verificar Rejeições");
define("USRLAN_144", "Reenviar email de confirmação para Todos");
define("USRLAN_145", "ressaltar os utilizadores");
define("USRLAN_146", "A informação do membro está disponível para");
define("USRLAN_147", "O email já é utilizado por um utilizador expulso");
define("USRLAN_148", "O email está expulso");
define("USRLAN_149", "Excluir os emails escolhidos");
define("USRLAN_150", "Apagar todos os emails");
define("USRLAN_151", "Limpar rejeição, exigir activação");
define("USRLAN_152", "Limpar ressalto e ativar");
define("USRLAN_153", "Apagar os emails não entregues");
define("USRLAN_154", "Limpar os email escolhidos");
define("USRLAN_155", "Um total de {TOTAL} emails foram encontrados. {DELCOUNT} foram apagados nas opções. <br />{DELUSER} utilizadores marcados como 'devolvedores' (bounced) (em {FOUND} emails).");
define("USRLAN_156", "O endereço de email já está em uso");
define("USRLAN_157", "Caracteres inválidos no nome de login");
define("LAN_MAINADMIN", "Administrador principal");
define("LAN_NOTVERIFIED", "Não Verificado");
define("LAN_BANNED", "Banido");
define("LAN_BOUNCED", "Retornado");
define("DUSRLAN_1", "ID");
define("DUSRLAN_2", "Nome a Ver");
define("DUSRLAN_3", "Nome de Utilizador");
define("DUSRLAN_4", "Título Personalizado");
define("DUSRLAN_5", "Senha");
define("DUSRLAN_6", "Iníciar Sessão");
define("DUSRLAN_7", "Email");
define("DUSRLAN_8", "Sítio Web");
define("DUSRLAN_9", "ICQ");
define("DUSRLAN_10", "AIM");
define("DUSRLAN_11", "MSN");
define("DUSRLAN_12", "Local");
define("DUSRLAN_13", "Data de Nascimento");
define("DUSRLAN_14", "Assinatura");
define("DUSRLAN_15", "Imagem");
define("DUSRLAN_16", "Zona Horária");
define("DUSRLAN_17", "Ocultar Email");
define("DUSRLAN_18", "Data Registo");
define("DUSRLAN_19", "Última Visita");
define("DUSRLAN_20", "Visita Actual");
define("DUSRLAN_21", "Última Mensagem");
define("DUSRLAN_22", "Mensagens Chatbox");
define("DUSRLAN_23", "Comentários");
define("DUSRLAN_24", "Mensagens Fórum");
define("DUSRLAN_25", "IP");
define("DUSRLAN_26", "Expulso");
define("DUSRLAN_27", "Definições");
define("DUSRLAN_28", "Novo");
define("DUSRLAN_29", "Visualizações");
define("DUSRLAN_30", "Visitas");
define("DUSRLAN_31", "Admin");
define("DUSRLAN_32", "Nome Real");
define("DUSRLAN_33", "Classe de Utilizador");
define("DUSRLAN_34", "Permissões");
define("DUSRLAN_35", "Seguimento de tópicos");
define("DUSRLAN_36", "Alterar senha");
define("DUSRLAN_37", "XUP");
define("USRLAN_190", "Período experimental do novo utilizador (dias)");
define("USRLAN_191", "(o administrador pode impor restrições durante este período em algumas áreas)");
define("USRLAN_194", "A assinatura pode ser modificado por");
define("USRLAN_219", "Mais de 30 días");


?>