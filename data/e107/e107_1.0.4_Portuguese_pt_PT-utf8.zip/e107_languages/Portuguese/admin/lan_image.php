<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("IMALAN_1", "Permitir a publicação de imagens");
define("IMALAN_2", "Exibir imagens, isto se aplica a todo o site (comentários chatbox etc), para imagens postadas usando o [img] bbcode");
define("IMALAN_3", "Método de redimensionamento");
define("IMALAN_4", "Método utilizado para redimensionar as imagens - 'Livraria GD1/2' ou 'ImageMagick'");
define("IMALAN_5", "Caminho para o ImageMagick (se seleccionado)");
define("IMALAN_6", "Caminho completo para o utilitário de conversão ImageMagick");
define("IMALAN_7", "Definições de imagens");
define("IMALAN_8", "Actualizar definições de imagens");
define("IMALAN_9", "Definições de imagens actualizadas");
define("IMALAN_10", "Submissão de imagens permitida a"); //Image posting class
define("IMALAN_11", "Restringir a submissão de imagens aos utilizadores (se seleccionado)");
define("IMALAN_12", "Método de inibição de imagens ");
define("IMALAN_13", "O que fazer com as imagens enviadas se a submissão das mesmas estiver desactivada");
define("IMALAN_14", "Mostrar URL da imagem");
define("IMALAN_15", "Não mostrar nada");
define("IMALAN_16", "Mostrar avatars transferidos");
define("IMALAN_17", "Clique aqui");
define("IMALAN_18", "Imagens transferidas");
define("IMALAN_19", "Mensagem de imagem inválida");

define("IMALAN_21", "Utilizada por");
define("IMALAN_22", "A imagem não está a ser utilizada");
define("IMALAN_23", "Avatar");
define("IMALAN_24", "Fotografia");
define("IMALAN_25", "Clique aqui para apagar todas as imagens não utilizadas");
define("IMALAN_26", "Imagens apagadas");

define("IMALAN_28", "Eliminada");
define("IMALAN_29", "Sem imagens");
define("IMALAN_30", "Todos (público)");
define("IMALAN_31", "Apenas visitantes");
define("IMALAN_32", "Apenas membros");
define("IMALAN_33", "Apenas administradores");
define("IMALAN_34", "Activar 'Sleight'");
define("IMALAN_35", "Corrige a transparência dos ficheiros tipo PNG-24 com transparências alfa no IE 5/6 (aplicável à totalidade do site)");

define("IMALAN_36", "Validar avatar, tamanho e acesso"); 
define("IMALAN_37", "Validação do Avatar"); 
define("IMALAN_38", "Largura máxima admissível"); 
define("IMALAN_39", "Altura máxima admissível"); 
define("IMALAN_40", "Muito grande"); 
define("IMALAN_41", "Muito alto"); 
define("IMALAN_42", "Não encontrado"); 
define("IMALAN_43", "Apagar o avatar enviado"); 
define("IMALAN_44", "Apagar referência externa"); 
define("IMALAN_45", "Não encontrado"); 
define("IMALAN_46", "Muito grande"); 
define("IMALAN_47", "Total de avatares enviados"); 
define("IMALAN_48", "Total de avatares externo"); 
define("IMALAN_49", "Utilizadores com avatares"); 
define("IMALAN_50", "Total"); 
define("IMALAN_51", "Avatar para"); 

define("IMALAN_52", "Caminho para ImageMagick parece estar incorreta"); 
define("IMALAN_53", "Caminho para ImageMagick parece ser correcta, mas converter o arquivo pode não ser válido"); 
define("IMALAN_54", "GD versão instalada:"); 
define('IMALAN_55', 'Não instalado');

?>