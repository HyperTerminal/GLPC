<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FLALAN_1", "Início de sessão falhadas");
define("FLALAN_2", "Não foram registadas Início de sessão falhadas");
define("FLALAN_3", "Tentativa(s) apagada(s)");
define("FLALAN_4", "O utilizador tentou aceder com um nome/senha incorrecto.");
define("FLALAN_5", "IP's expulsos");
define("FLALAN_6", "Data");
define("FLALAN_7", "Dados");
define("FLALAN_8", "Endereço IP/Host");
define("FLALAN_9", "Opções");
define("FLALAN_10", "Apagar/Expulsar itens marcados");
define("FLALAN_11", "Marcar todas as caixas 'ELIMINAR'");
define("FLALAN_12", "Desmarcar todas as caixas 'ELIMINAR'");
define("FLALAN_13", "Marcar todas as caixas '	EXPULSAR'");
define("FLALAN_14", "Desmarcar todas as caixas 'EXPULSAR'");
define("FLALAN_15", "Os seguintes endereços de IP foram banidos automáticamente - Mais de 10 tentativas falhadas de login");
define("FLALAN_16", "Apagar lista dos expulsos automáticos");
define("FLALAN_17", "Lista de expulsos automáticos eliminada");

?>