<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("METLAN_1", "Meta-etiquetas atualizadas na base de dados");
define("METLAN_2", "Introduzir meta-etiquetas adicionais");
define("METLAN_3", "Introduzir novas definições de meta-etiquetas");
define("METLAN_4", "Atualizado");
define("METLAN_5", "Insira a descrição do sitio");
define("METLAN_6", "Insira uma, lista, com, as, suas, palavras, chave");
define("METLAN_7", "Insira a informação de Copyright");
define("METLAN_8", "Meta-etiquetas");

define("METLAN_9", "Descrição");
define("METLAN_10", "Palavras chave");
define("METLAN_11", "Copyright");
define("METLAN_12", "Utilizar título da notícia e sumário como meta-descrições nas páginas de notícias.");
define("METLAN_13", "Autor");

?>