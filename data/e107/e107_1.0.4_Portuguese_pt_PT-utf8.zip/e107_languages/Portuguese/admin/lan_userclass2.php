<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("UCSLAN_1", "Todos os utilizadores desta classe foram apagados.");
define("UCSLAN_2", "Classe de utilizadores atualizada.");
define("UCSLAN_3", "Classe eliminada.");
define("UCSLAN_4", "Selecione a caixa para confirmar a remoção desta classe de utilizadores");
define("UCSLAN_5", "Classe atualizada.");
define("UCSLAN_6", "Classe salva na base de dados.");
define("UCSLAN_7", "Aínda não foram definidas classes de utilizadores.");
define("UCSLAN_8", "Classes existentes");
define("UCSLAN_11", "Seleccione para confirmar");
define("UCSLAN_12", "Nome da classe");
define("UCSLAN_13", "Descrição da classe");
define("UCSLAN_14", "Actualizar classe de utilizadores");
define("UCSLAN_15", "Criar uma nova classe");
define("UCSLAN_16", "Atribuir classe à utilizadores");
define("UCSLAN_17", "Apagar");
define("UCSLAN_18", "Limpar classe");
define("UCSLAN_19", "Atribuir");
define("UCSLAN_20", "como classe");
define("UCSLAN_21", "Configuração da classe de utilizadores");
define("UCSLAN_22", "Utilizadores - clique para mover ...");
define("UCSLAN_23", "Utilizadores nesta classe...");
define("UCSLAN_24", "Quem pode gerir a classe");
define("UCSLAN_25", "ID");
define("UCSLAN_26", "Utilizador");
define("UCSLAN_27", "Voltar");


?>