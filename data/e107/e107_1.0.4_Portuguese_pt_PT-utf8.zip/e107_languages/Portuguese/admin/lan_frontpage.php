<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("FRTLAN_1", "Definições da página principal salvas!");
define("FRTLAN_2", "Definir página principal para");
define("FRTLAN_6", "Ligações");
define("FRTLAN_12", "Atualizar");
define("FRTLAN_13", "Definições da página principal");
define("FRTLAN_15", "Outro (escreva URL):");
define("FRTLAN_16", "Erro: Não foi seleccionada uma categoria principal de conteúdo");
define("FRTLAN_17", "Erro: Não foi selecionada uma subcategoria de conteúdo");
define("FRTLAN_18", "Erro: Não foi selecionado um item de conteúdo");
define("FRTLAN_19", "Categoria principal de conteúdo");
define("FRTLAN_20", "Subcategoria de conteúdo");
define("FRTLAN_21", "Item de conteúdo");
define("FRTLAN_22", "Página personalizada");
define("FRTLAN_26", "Todos os utilizadores");
define("FRTLAN_27", "Visitantes");
define("FRTLAN_28", "Membros");
define("FRTLAN_29", "Administradores");
define("FRTLAN_31", "Todos os utilizadores");
define("FRTLAN_32", "Classe de utilizadores");
define("FRTLAN_33", "Definições actuais");
define("FRTLAN_34", "Página");


?>