<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("BANLAN_1", "Expulso removido.");
define("BANLAN_2", "Sem expulsões.");
define("BANLAN_3", "Expulsões Existentes");
define("BANLAN_4", "Remover expulsos");
define("BANLAN_5", "Insira IP, email, ou host");
define("BANLAN_7", "Razão");
define("BANLAN_8", "Expulsar por endereço");
define("BANLAN_9", "Expulsar utilizadores do sitio por, email, IP ou host");
define("BANLAN_10", "IP / Email / Razão");
define("BANLAN_11", "Expulsão Automática: Mais de 10 tentativas falhadas no início de sessão");
define("BANLAN_12", "Nota: DNS reverso está actualmente desactivada, deve ser activada para permitir a proibição por host/servidor. Expulsar por IP de email continua a funcionar normalmente.");
define("BANLAN_13", "Observação: Para proibir um utilizador por nome de utilizador, ir à página de administração dos utilizadores:");
define("BANLAN_78", "TOP máximo atingido (--HITS-- requests within allotted time)");


?>