<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANG_LAN_00", "não foi criado (já existe).");
define("LANG_LAN_01", "foi removido (se existia) e criado.");
define("LANG_LAN_02", "não pode ser eliminado.");
define("LANG_LAN_03", "Tabelas de Idiomas");
define("LANG_LAN_05", "Não instalado");
define("LANG_LAN_06", "Criar tabelas");
define("LANG_LAN_07", "Eliminar tabelas existentes");
define("LANG_LAN_08", "Substituir tabelas existentes (os dados serão perdidos).");
define("LANG_LAN_10", "Confirmar eliminação");
define("LANG_LAN_11", "Apagar tabelas não marcadas acima (caso existam).");
define("LANG_LAN_12", "Selecionar para ativar tabelas multi-idioma");
define("LANG_LAN_13", "Preferências de Idioma");
define("LANG_LAN_14", "Idioma por omissão");
define("LANG_LAN_15", "Seleccione para copiar os dados do idioma pré-definido (útil para links, categorias de notícias, etc.)");
define("LANG_LAN_16", "Uso de banco de dados multi-idioma.");
define("LANG_LAN_17", "Língua por omissão - Não há tabelas adicionais.");
define("LANG_LAN_18", "Uso reservados de Subdomínios com estes domínios para definir site de idioma:");
define("LANG_LAN_19", "Por exemplo, o domínio fr.mydomain.com, teria de definir o idioma francês.");
define("LANG_LAN_20", "Insira um domínio por linha. ex. mydomain.com etc. ou deixe em branco para desabilitar.");
define("LANG_LAN_21", "Ferramentas de idioma");
define("LANG_LAN_23", "Criar (zip)");
define("LANG_LAN_24", "Gerar");
define("LANG_LAN_AGR", "Nota: mediante o uso de estas ferramentas você se compromete a compartilhar seu pacote de idioma(s) com a comunidade e107.");
define("LANG_LAN_EML", "Por favor, envie seu pacote de idioma a:");
define("LANG_LAN_25", "Verifique se CORE_LC e CORE_LC2 têm valores [lcpath] e tente novamente.");
define("LANG_LAN_26", "Por favor, certifique-se que está usando os nomes de pasta padrão no e107_config.php (ex. 'e107_languages /', 'e107_plugins /'etc.) e tente novamente.");
define("LANG_LAN_27", "Por favor, verifique seus arquivos de idioma ('Nova Verificação') e tente novamente.");
define("LANG_LAN_28", "Se você é um [Tradutor Certificado e107], marque esta opção.");
define("LANG_LAN_29", "Você deve corrigir os erros apresentados antes de contribuir com o novo pacote de idiomas.");
define("LANG_LAN_30", "Data de Lançamento");
define("LANG_LAN_31", "Compatibilidade");
define("LANG_LAN_32", "Idiomas Instalados");
define("LANG_LAN_33", "Mostrar apenas os erros existentes");
define("LANG_LAN_34", "Por favor, verificar e corrigir os restantes [x] erro(s), antes de tentar criar um pacote de idioma.");


?>