<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("EMOLAN_1", "Ativar ícones de emoção");
define("EMOLAN_2", "Nome");
define("EMOLAN_3", "Ícones de emoção");
define("EMOLAN_4", "Ativar ícones de emoção?");
define("EMOLAN_5", "Imagem");
define("EMOLAN_6", "Código da emoção");
define("EMOLAN_7", "Separar as opções com espaços");
define("EMOLAN_8", "Estado");
define("EMOLAN_9", "Opções");
define("EMOLAN_10", "Activo");
define("EMOLAN_11", "Activar pacote");
define("EMOLAN_12", "Editar/configurar este pacote");
define("EMOLAN_13", "Pacotes instalados");
define("EMOLAN_14", "Gravar configuração");
define("EMOLAN_15", "Editar/configurar ícones de emoção");
define("EMOLAN_16", "Configuração de ícones de emoção salvas");
define("EMOLAN_17", "Você tem um pacote de emoções que contém espaços ou com nomes que não são permitidos!");
define("EMOLAN_18", "por favor renomeie os casos enumerados a seguir, para que eles deixaram de conter espaços:");
define("EMOLAN_19", "Nome");
define("EMOLAN_20", "Localização");
define("EMOLAN_21", "Erro");
define("EMOLAN_22", "Novo pacote de emoções encontrados:");
define("EMOLAN_23", "Novas emoções em xml encontrados:");
define("EMOLAN_24", "Novas emoções em php encontrados:");
define("EMOLAN_25", "Instalar novas emoções:");
define("EMOLAN_26", "Verificar o pacote");
define("EMOLAN_27", "Ocorreu um erro ao processar o pacote:");
define("EMOLAN_28", "Gerar XML");
define("EMOLAN_29", "arquivo XML gerado:");
define("EMOLAN_30", "Erro ao gravar o arquivo XML:");


?>