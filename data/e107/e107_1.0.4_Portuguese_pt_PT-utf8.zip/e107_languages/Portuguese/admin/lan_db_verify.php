<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("DBLAN_1", "Não foi possível efetuar a leitura do ficheiro de dados SQL<br /><br />Faz favor, certifique-se que o ficheiro <b>core_sql.php</b> existe na pasta <b>/admin/sql</b>.");
define("DBLAN_2", "Verificar tudo");
define("DBLAN_4", "Tabela");
define("DBLAN_5", "Campo");
define("DBLAN_6", "Estado");
define("DBLAN_7", "Notas");
define("DBLAN_8", "Diferença");
define("DBLAN_9", "Actualmente");
define("DBLAN_10", "Deveria ser");
define("DBLAN_11", "Campo em falta");
define("DBLAN_12", "Campo a mais!");
define("DBLAN_13", "Tabela em falta!");
define("DBLAN_14", "Escolha a(s) tabela(s) para validar");
define("DBLAN_15", "Iniciar verificação");
define("DBLAN_16", "Verificação do SQL");
define("DBLAN_17", "Voltar");
define("DBLAN_18", "tabelas");
define("DBLAN_19", "Tentativa de reparação");
define("DBLAN_20", "Tentativa de reparação das tabelas");
define("DBLAN_21", "Reparar itens seleccionados");
define("DBLAN_22", " não é legível");


?>