<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("DOWLAN_1", "Descarga adicionada na base de dados.");
define("DOWLAN_2", "Descarga atualizada na base de dados.");
define("DOWLAN_3", "Descarga eliminada.");
define("DOWLAN_4", "Faz favor, selecione a caixa de confirmação para apagar a descarga");
define("DOWLAN_5", "Ainda não estão definidas as categorias de descarga, não poderá adicionar arquivos, enquanto estas não forem criadas.");
define("DOWLAN_6", "Não existem descargas");
define("DOWLAN_7", "Descargas existentes");
define("DOWLAN_11", "Categoria");
define("DOWLAN_12", "Nome");
define("DOWLAN_13", "Arquivo");
define("DOWLAN_14", "Escreva o URL no caso de ser uma descarga externa");
define("DOWLAN_15", "Autor");
define("DOWLAN_16", "Email do autor");
define("DOWLAN_17", "Sítio Web");
define("DOWLAN_18", "Descrição");
define("DOWLAN_19", "Imagem principal");
define("DOWLAN_20", "Imagem miniatura");
define("DOWLAN_21", "Estado");
define("DOWLAN_24", "Atualizar Descarga");
define("DOWLAN_25", "Enviar Descarga");
define("DOWLAN_27", "Descarga");
define("DOWLAN_28", "Nenhum");
define("DOWLAN_29", "Página de Descargas");
define("DOWLAN_30", "Criar Descarga");
define("DOWLAN_31", "Categorias");
define("DOWLAN_32", "Opções de Descargas");
define("DOWLAN_33", "Tem a certeza que deseja apagar a descarga?");
define("DOWLAN_34", "Tem a certeza que deseja apagar esta categoria de descargas?");
define("DOWLAN_36", "apagada");
define("DOWLAN_37", "Categoria Principal");
define("DOWLAN_38", "Não existem categorias");
define("DOWLAN_39", "Categorias de descargas");
define("DOWLAN_40", "Categoria principal - Nenhuma");
define("DOWLAN_41", "Ícone");
define("DOWLAN_42", "Ver Imagens");
define("DOWLAN_43", "Visível para");
define("DOWLAN_44", "Ao selecionar fará com que a categoria apenas seja visível aos utilizadores dessa classe");
define("DOWLAN_45", "Criar");
define("DOWLAN_46", "Atualizar");
define("DOWLAN_47", "Categoria criada!");
define("DOWLAN_48", "Categoria atualizada!");
define("DOWLAN_49", "Categoria de descargas");
define("DOWLAN_51", "Pesquisar descargas");
define("DOWLAN_52", "Arquivos");
define("DOWLAN_53", "Subcategoria");
define("DOWLAN_54", "Opções de Descargas");
define("DOWLAN_55", "Nº de descargas a mostrar por página");
define("DOWLAN_56", "Ordenar por");
define("DOWLAN_59", "Nome do arquivo");
define("DOWLAN_62", "Ascendente");
define("DOWLAN_63", "Descendente");
define("DOWLAN_64", "Atualizar");
define("DOWLAN_65", "Opções atualizadas!");
define("DOWLAN_66", "Insira o tamanho do arquivo");
define("DOWLAN_67", "ID");
define("DOWLAN_68", "Arquivo em falta!");
define("DOWLAN_69", "Descargas geridas pelo PHP");
define("DOWLAN_70", "Ao selecionar fará com que todos os pedidos de descargas sejam geridas pelo PHP.");
define("DOWLAN_100", "Ativar acordo de licença");
define("DOWLAN_101", "Texto da licença");
define("DOWLAN_102", "Permição de comentários");
define("DOWLAN_103", "Remover das transferências");
define("DOWLAN_104", "foi removido das transferências públicas");
define("DOWLAN_105", "Voltar às transferências públicas");
define("DOWLAN_106", "Poderá ser descarregado por");
define("DOWLAN_107", "Número de descargas");
define("DOWLAN_108", "Valor das descargas");
define("DOWLAN_109", "cada");
define("DOWLAN_110", "dias");
define("DOWLAN_111", "kb");
define("DOWLAN_112", "Limites");
define("DOWLAN_113", "Classe de utilizadores");
define("DOWLAN_114", "Adicionar");
define("DOWLAN_115", "Atualizar");
define("DOWLAN_116", "Já foi definido um limite para essa classe de utilizadores");
define("DOWLAN_117", "Limite adicionado com sucesso!");
define("DOWLAN_118", "Limite não adicionado - erro desconhecido");
define("DOWLAN_119", "Limite removido com sucesso!");
define("DOWLAN_120", "Limite não removido - erro desconhecido");
define("DOWLAN_121", "Limite actualizado com sucesso!");
define("DOWLAN_122", "Inativo");
define("DOWLAN_123", "O arquivo ESTÁ sujeito a limites de descarga - Ativar");
define("DOWLAN_124", "O arquivo NÃO ESTÁ sujeito a limites de descarga - Ativar");
define("DOWLAN_125", "Limites de descargas ativos");
define("DOWLAN_126", "Estado de ativação atualizado!");
define("DOWLAN_127", "Apenas insira o tamanho do arquivo se a descarga for um arquivo externo");
define("DOWLAN_128", "Servidores (Mirrors)");
define("DOWLAN_129", "Deixar em branco se não está a utilizar servidores");
define("DOWLAN_130", "Adicionar outro servidor");
define("DOWLAN_131", "Selecionar arquivo local");
define("DOWLAN_132", "Faz favor, insira a área a utilizar e o endereço para a descarga");
define("DOWLAN_133", "Servidor atualizado na base de dados!");
define("DOWLAN_134", "Servidor salvo na base de dados!");
define("DOWLAN_135", "Servidor eliminado!");
define("DOWLAN_136", "Imagem");
define("DOWLAN_137", "Tem a certeza que deseja eliminar o servidor?");
define("DOWLAN_138", "Servidores existentes");
define("DOWLAN_139", "Endereço");
define("DOWLAN_140", "Efetar a transferência das imagens locais para a pasta ".e_files/downloadimages." para serem disponibilizadas aqui, ou escreva o URL se a imagem for externa.");
define("DOWLAN_141", "Local");
define("DOWLAN_142", "Atualizar");
define("DOWLAN_143", "Criar");
define("DOWLAN_144", "Não existem servidores definidos, na secção de servidores.");
define("DOWLAN_145", "Visível para");
define("DOWLAN_146", "Mensagem ou URL personalizada de negação da descarga");
define("DOWLAN_147", "Ícone para categoria vazia");
define("DOWLAN_148", "Selecione para ajustar a data e hora atual");
define("DOWLAN_149", "Ou clique aqui para utilizar um arquivo externo");
define("DOWLAN_150", "Enviar email ao administrador quando é reportado uma descarga invalida");
define("DOWLAN_151", "Envio de relatório para descargas invalidas para");
define("DOWLAN_152", "Não foi possível mover o arquivo");
define("DOWLAN_153", "Mover arquivo para a pasta de descargas");
define("DOWLAN_154", "se estiver usando servidores, selecione o modo como elas serão exibidos");
define("DOWLAN_155", "Tipo de visualização da servidor:");
define("DOWLAN_156", "mostrar lista de servidores, permitir ao utilizador escolher o servidor");
define("DOWLAN_157", "Utilização aleatória de servidor - O utilizador não pode escolher");
define("DOWLAN_158", "Mostrar sub subcategorias na página principal de descarga");
define("DOWLAN_159", "Incluir contagem de sub subcategoria na contagem de subcategorias");
define("DOWLAN_160", "Impedir descargas simultâneas aos utilizadores de forma individuais");
define("DOWLAN_161", "Usando uma página inicial para impedir a descarga de arquivos");
define("DOWLAN_162", "Requerido por");
define("DOWLAN_163", "Utilizador");
define("DOWLAN_164", "IP");
define("DOWLAN_165", "Data / Hora");
define("DOWLAN_166", "Voltar para página principal de descargas");
define("DOWLAN_199", "Atenção: após a limpeza das estatísticas de descargas poderá não refletir o histórico completo de cada.");
define("DOWLAN_200", "Número");
define("DOWLAN_201", "Registo de limpeza");
define("DOWLAN_202", "Detalhe registo de limpeza");


?>