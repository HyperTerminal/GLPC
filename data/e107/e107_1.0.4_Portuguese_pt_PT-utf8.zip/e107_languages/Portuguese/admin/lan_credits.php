<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Créditos de e107");
define("CRELAN_1", "Créditos");
define("CRELAN_2", "Em anexo poderá encontrar uma lista de recursos/software de terceiros utilizados na elaboração do e107. A equipa de desenvolvimento gostaria de agradecer pessoalmente aos autores pela autorização dada na distribuição do seu código com o e107, bem como da distribuição do mesmo sob a licença GPL.");
define("CRELAN_3", "Todos os direitos reservados");
define("CRELAN_4", "Equipa de Desenvolvedores");
define("CRELAN_5", "Página web");
define("CRELAN_6", "Permissão");
define("CRELAN_7", "versão");
define("CRELAN_8", "permissão garantida");
define("CRELAN_9", "Licença");
define("CRELAN_10", "MagpieRSS prevê um XML (expat) RSS parser em PHP.");
define("CRELAN_11", "PclZip oferece compressão e funções para a extração de arquivos em formato Zip (WinZip, PKZIP).");
define("CRELAN_12", "PclTar oferece a capacidade de arquivar uma lista de arquivos ou diretórios com ou sem compressão. Os arquivos criados pelo PclTar são lidos pela maioria dos gzip/tar aplicações e pelo Windows WinZip aplicação.");
define("CRELAN_13", "tinymce é uma plataforma independente com base em Javascript. É um editor HTML do tipo WYSIWYG distribuído como Código Aberto sob licença LGPL por Moxiecode Systems AB. Ele tem a função de converter áreas de texto HTML, campos ou outros elementos em códigos HTML.");
define("CRELAN_14", "Ícones utilizados no e107");
define("CRELAN_15", "Funções completas de envio de e-mail por PHP");
define("CRELAN_16", "Sistema de menus utilizado no tema Jayya");
define("CRELAN_17", "Popup calendário widget");
define("CRELAN_18", "Apoio PDF");
define("CRELAN_19", "Apoio PDF UTF-8");
define("CRELAN_20", "");
define("CRELAN_21", "Sempre uma pressão .. err .. um prazer!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br /> yarrrrrr! wtf Louco!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Quê? Sem café? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Para cima e sempre enfrente!");
define("CRELAN_30", "");


?>