<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("LAN_ADMINLOG_0", "Iniciar Sessão Admin");
define("LAN_ADMINLOG_1", "Data");
define("LAN_ADMINLOG_2", "Título");
define("LAN_ADMINLOG_3", "Descrição");
define("LAN_ADMINLOG_4", "IP de Utilizador");
define("LAN_ADMINLOG_5", "ID de Utilizador");
define("LAN_ADMINLOG_6", "Ícone Informativo");
define("LAN_ADMINLOG_7", "Mensagem Informativo");
define("LAN_ADMINLOG_8", "Ícone de Aviso");
define("LAN_ADMINLOG_9", "Mensagem de Aviso");
define("LAN_ADMINLOG_10", "Ícone de Aviso");
define("LAN_ADMINLOG_11", "Mensagem de aviso");
define("LAN_ADMINLOG_12", "Ícone de erro");
define("LAN_ADMINLOG_13", "Mensagem de Erro");


?>