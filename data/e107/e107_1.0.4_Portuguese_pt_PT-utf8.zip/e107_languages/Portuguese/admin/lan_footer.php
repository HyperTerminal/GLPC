<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FOOTLAN_1", "Sítio");
define("FOOTLAN_2", "Admin. Principal");
define("FOOTLAN_3", "Versão");
define("FOOTLAN_4", "Revisão");
define("FOOTLAN_5", "Tema");
define("FOOTLAN_6", "por");
define("FOOTLAN_7", "Info.");
define("FOOTLAN_8", "Data de Instalação");
define("FOOTLAN_9", "Servidor");
define("FOOTLAN_10", "Host");
define("FOOTLAN_11", "Versão PHP");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Informação do Sítio");
define("FOOTLAN_14", "Ver Documentação");
define("FOOTLAN_15", "Documentação");
define("FOOTLAN_16", "Base de Dados");
define("FOOTLAN_17", "Codificação dos Caracteres");
define("FOOTLAN_18", "Tema do Sitio");
define("FOOTLAN_19", "Tempo de servidor");
define("FOOTLAN_20", "Nível de Segurança");


?>