<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("DBLAN_1", "As definições do sistema foram salvas na base de dados.");
define("DBLAN_2", "Clique para efectuar um backup da base de dados de e107");
define("DBLAN_3", "Efectuar backup da base de dados SQL");
define("DBLAN_4", "Clique para verificar a validade da base de dados de e107");
define("DBLAN_5", "Verificar validade da base de dados");
define("DBLAN_6", "Clique para optimizar a base de dados de e107");
define("DBLAN_7", "Optimizar a base de dados SQL");
define("DBLAN_8", "Clique para efectuar um backup das suas definições de sistema");
define("DBLAN_9", "Backup das definições do sistema");
define("DBLAN_10", "Utilidades da base de dados");
define("DBLAN_11", "Base de dados MySQL");
define("DBLAN_12", "optimizada");
define("DBLAN_13", "Voltar");
define("DBLAN_14", "Efectuado");
define("DBLAN_15", "Clique para verificar a disponibilidade de actualizações para a BD");
define("DBLAN_16", "Verificar actualizações");
define("DBLAN_17", "Nome por Pref.");
define("DBLAN_18", "Valor por Pref.");
define("DBLAN_19", "Clique no botão para abrir o editor de preferências. (apenas para utilizadores avançados)");
define("DBLAN_20", "Editor de Preferências");
define("DBLAN_21", "Apagar as escolhidas");
define("DBLAN_22", "Plugin: Ver e Digitalizar");
define("DBLAN_23", "Completado");
define("DBLAN_24", "Nome");
define("DBLAN_25", "Directório");
define("DBLAN_26", "Adicionais Incluídos");
define("DBLAN_27", "instalado");
define("DBLAN_28", "Clique no botão para verificar a directoria de plugins para procurar modificações");
define("DBLAN_29", "Verificar a directoria de plugins");
define("DBLAN_30", "(Se um plugin mostra um erro, verifique a existência dos caracteres de abertura e fechamento de PHP)");
define("DBLAN_31", "Acesso");
define("DBLAN_32", "Erro");
define("DBLAN_33", "Inacessível");
define("DBLAN_34", "Não verificado");
define("DBLAN_35", "Clique no botão para verificar a validade da tabela utilizador");
define("DBLAN_36", "Verificar tabela utilizador");


?>