<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("TPVLAN_1", "Está a pre-visualizar o tema <b>'".PREVIEWTHEMENAME."'</b>.<br /># Este tema não está definido como Tema Principal, apenas foi ativado para ver o seu estilo.<br /># Para utilizar este tema como principal, deverá <a href='".e_ADMIN."theme.php'>voltar ao gestor de temas</a> e seleccionar a opção 'Definir como tema do site'.<br /><br /><a href='".e_ADMIN."theme.php'>Clique Aqui</a> para pre-visualizar outros temas.");
define("TPVLAN_2", "Pre-visualizando o Tema"); //Theme Preview
define("TPVLAN_3", "Tema principal do site definido para"); //Main site theme set to
define("TPVLAN_4", "Autor");
define("TPVLAN_5", "Página web");
define("TPVLAN_6", "Data de lançamento");
define("TPVLAN_7", "Informação");
define("TPVLAN_8", "Opções");
define("TPVLAN_9", "Pre-visualizar");
define("TPVLAN_10", "Definir como tema do site");
define("TPVLAN_11", "Versão");
define("TPVLAN_12", "Pre-visualização não disponível");

define("TPVLAN_13", "Novo Tema (formato .zip ou .tar.gz)");
define("TPVLAN_14", "Transferir Tema");
define("TPVLAN_15", "O ficheiro não foi transferido, a pasta ".e_THEME." não possui as permissões correctas - efectue 'CHMOD 777' e transfira novamente o ficheiro.");
define("TPVLAN_16", "Mensagem do Admin");
define("TPVLAN_17", "Este ficheiro não aparenta ser um arquivo .zip ou .tar");
define("TPVLAN_18", "Foi detectado um erro, a descompactação do ficheiro não foi possível");
define("TPVLAN_19", "O tema foi transferido e extraido, verifique a sua presença na lista de temas.");
define("TPVLAN_20", "A transferência e extracção automática de temas está desactivada, a pasta de temas não possui as permissões correctas - por favor efectue um 'CHMOD 777' na pasta e107_themes.");

define("TPVLAN_21", "Tema actual definido para o site");

define("TPVLAN_22", "Este tema possui várias folhas de estilo"); //this theme has multiple stylesheets
define("TPVLAN_23", "Folha de estilo por defeito"); //default stylesheet
define("TPVLAN_24", "Sem informação");
define("TPVLAN_25", "Para escolher a folha de estilo a utilizar, vá às <a href='".e_ADMIN."prefs.php'>definições</a> e clique em 'Temas'.");

define("TPVLAN_26", "Gestor de Temas");
define("TPVLAN_27", "Por favor seleccione a folhas de estilo a utilizar"); //Please select stylesheet to use
define("TPVLAN_28", "Ligado");
define("TPVLAN_29", "Desligado");
define("TPVLAN_30", "Pré-carregar imagens do tema:");

define("TPVLAN_31", "Tema actual definido na área de admin");
define("TPVLAN_32", "Definir como Tema de Admin");

define("TPVLAN_33", "Tema actual no site Principal");
define("TPVLAN_34", "Tema actual na área de administração");
define("TPVLAN_35", "Salvar definições");
define("TPVLAN_36", "Mensagem do admin");
define("TPVLAN_37", "Definições do Tema Salvas");
define("TPVLAN_38", "Transferir Tema");
define("TPVLAN_39", "Temas Disponíveis");
define("TPVLAN_40", "Tema de administração definido para");

define("TPVLAN_41", "Faz favor, seleccione o esquema de administração a usar");
define("TPVLAN_42", "Salvar definições de admin");
define("TPVLAN_43", "Definições de admin salvas");

define("TPVLAN_46", "Erro na extração PCLZIP:");
define("TPVLAN_47", "Erro na extração PCLTAR:");
define("TPVLAN_48", "código:");

?>