<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("UCSLAN_1", "Enviar email de notificação a");
define("UCSLAN_2", "Previlégios actualizados");
define("UCSLAN_3", "Caro(a)");
define("UCSLAN_4", "Os seus previlégios foram actualizados no");
define("UCSLAN_5", "Tem agora acesso às seguintes áreas");
define("UCSLAN_6", "Definir classe para o utilizador");
define("UCSLAN_7", "Definir classes");
define("UCSLAN_8", "Notificar utilizador");
define("UCSLAN_9", "Classes actualizadas.");
define("UCSLAN_10", "Cumprimentos,");
define('UCSLAN_12', 'Só membros com privilégios');

?>