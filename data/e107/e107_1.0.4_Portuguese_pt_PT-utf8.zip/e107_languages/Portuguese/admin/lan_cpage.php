<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("CUSLAN_1", "Título");
define("CUSLAN_2", "Tipo");
define("CUSLAN_3", "Opções");
define("CUSLAN_4", "Apagar esta página?");
define("CUSLAN_5", "Páginas existentes");
define("CUSLAN_7", "Nome do Menu");
define("CUSLAN_8", "Título");
define("CUSLAN_9", "Texto");
define("CUSLAN_10", "Permitir classificação de página");
define("CUSLAN_11", "Página inicial");
define("CUSLAN_12", "Criar página");
define("CUSLAN_13", "Permitir comentários");
define("CUSLAN_14", "Proteger a página com senha");
define("CUSLAN_15", "Escreva a senha para proteger a página");
define("CUSLAN_16", "Criar hiperligação no menu principal");
define("CUSLAN_17", "Escreva o nome da hiperligação a ser criado");
define("CUSLAN_18", "Página / hiperligação visível para");
define("CUSLAN_19", "Actualizar Página");
define("CUSLAN_20", "Criar Página");
define("CUSLAN_21", "Actualizar Menu");
define("CUSLAN_22", "Criar Menu");
define("CUSLAN_23", "Editar página");
define("CUSLAN_24", "Criar nova página");
define("CUSLAN_25", "Editar menu");
define("CUSLAN_26", "Criar novo menu");
define("CUSLAN_27", "Página salva na base de dados.");
define("CUSLAN_28", "Página eliminada");
define("CUSLAN_29", "Páginas listadas se não existir selecção de páginas");
define("CUSLAN_30", "Tempo de expiração do cookie (em segundos)");
define("CUSLAN_31", "Criar menu");
define("CUSLAN_32", "Converter páginas/menus antigos");
define("CUSLAN_33", "Opções da Página");
define("CUSLAN_34", "Iniciar conversão");
define("CUSLAN_35", "Actualização de página personalizada terminada");
define("CUSLAN_36", "Para editar as definições de cada página deverá voltar à página inicial e alterar as páginas.");
define("CUSLAN_37", "Actualização de página personalizada");
define("CUSLAN_38", "Ligado");
define("CUSLAN_39", "Desligado");
define("CUSLAN_40", "Salvar Opções");
define("CUSLAN_41", "Mostrar informação do autor e da data");
define("CUSLAN_42", "Ainda não existem páginas definidas");
define("CUSLAN_43", "menu sem título:");
define("CUSLAN_44", "página sem título");


?>