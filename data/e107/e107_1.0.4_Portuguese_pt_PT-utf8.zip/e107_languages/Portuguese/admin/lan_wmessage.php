<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

// define("WMGLAN_1", "Mensagem para Visitantes");
// define("WMGLAN_2", "Mensagem para Membros");
// define("WMGLAN_3", "Mensagem para Administradores");
// define("WMGLAN_4", "Submeter");
// define("WMGLAN_5", "Definir Mensagem de Boas-vindas");
// define("WMGLAN_6", "Activar?");
// define("WMGLAN_7", "As definições de mensagens de boas-vindas foram actualizadas.");

define("WMLAN_00","Mensagens de boas-vindas");
define("WMLAN_01","Criar nova mensagem");
define("WMLAN_02","Mensagem");
define("WMLAN_03","Visibilidade");
define("WMLAN_04","Texto da mensagem");

define("WMLAN_05","Destacar");
define("WMLAN_06","Ao ligar esta opção a mensagem será mostrada em destaque numa caixa");
define("WMLAN_07","Invalidar o sistema abreviado do código {WMESSAGE}:");
// define("WMLAN_08","Definições");

define("WMLAN_09","Ainda não foram definidas mensagens de boas-vindas");
define("WMLAN_10", "Subtítulo da mensagem");

?>