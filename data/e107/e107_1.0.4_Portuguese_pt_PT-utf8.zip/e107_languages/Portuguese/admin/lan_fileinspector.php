<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define("FC_LAN_1", "Inspector de Arquivos");
define("FC_LAN_2", "Opções de Análise");
define("FC_LAN_3", "Mostrar");
define("FC_LAN_4", "Tudo");
define("FC_LAN_5", "Arquivos de Sistema");
define("FC_LAN_6", "Só Falha de Integridade");
define("FC_LAN_7", "Arquivos Vários");
define("FC_LAN_8", "Verificar Integridade dos Arquivos de Sistema");
define("FC_LAN_9", "Ligado");
define("FC_LAN_10", "Desligado");
define("FC_LAN_11", "Analisar Agora");
define("FC_LAN_12", "Nenhum");
define("FC_LAN_13", "Arquivos de Sistema em Falta");
define("FC_LAN_14", "Mostrar resultados como");
define("FC_LAN_15", "Estrutura de Directoria");
define("FC_LAN_16", "Lista");
define("FC_LAN_17", "Pesquisa de expressões");
define("FC_LAN_18", "Expressões regulares");
define("FC_LAN_19", "Mostrar nº das linhas");
define("FC_LAN_20", "Mostrar linhas iguais");
define("FC_LAN_21", "Arquivos Sistema Antigos");
define("FR_LAN_1", "A analisar...");
define("FR_LAN_2", "Resultados da análise");
define("FR_LAN_3", "Resumo");
define("FR_LAN_4", "Arquivos de sistema");
define("FR_LAN_5", "Outros ficheiros");
define("FR_LAN_6", "Total de ficheiros");
define("FR_LAN_7", "Verificação de Integridade");
define("FR_LAN_8", "Arquivos de Sistema - OK");
define("FR_LAN_9", "Arquivos de Sistema - Falhas");
define("FR_LAN_10", "Razões possíveis para as falhas nos arquivos");
define("FR_LAN_11", "O arquivo está danificado");
define("FR_LAN_12", "Esta situação poderá ser originada por uma série de eventos: Ficheiro corrompido no zip, ou ficou danificado durante a extracção ou transferência via FTP. Deverá transferir novamente o ficheiro e correr o inspector de ficheiros para verificar se o problema ficou corrigido.");
define("FR_LAN_13", "O arquivo está desactualizado");
define("FR_LAN_14", "Esta situação poderá ser originada por um ficheiro de uma versão antiga do e107 misturado com a versão em utilização. Deverá efectuar a transferência da última versão deste ficheiro.");
define("FR_LAN_15", "O arquivo foi editado");
define("FR_LAN_16", "Esta falha é devida ao facto de o ficheiro ter sido editado. Se editou intencionalmente o ficheiro, não se deverá preocupar com este erro. Se porventura o ficheiro foi editado por alguém sem a sua permissão, deverá efectuar a transferência da versão correcta a partir do zip do e107.");
define("FR_LAN_17", "Se é um utilizador do CVS");
define("FR_LAN_18", "Se estiver a correr versões CVS do e107 no seu site em vez de versões oficiais (estáveis), então encontrará frequentemente ficheiros com falhas de integridade. Este situação deve-se ao facto de os ficheiros terem sido editados por membros da equipa de desenvolvimento após a criação da última imagem de sistema.");
define("FR_LAN_19", "Arquivo com falhas");
define("FR_LAN_20", "Todos os arquivos foram verificados - OK");
define("FR_LAN_21", "Nenhum");
define("FR_LAN_22", "Arquivos de sistema em falta");
define("FR_LAN_23", "Não foram encontradas ocorrências.");
define("FR_LAN_24", "Arquivos de sistema antigos");
define("FR_LAN_25", "Integridade não verificada");
define("FR_LAN_26", "ATENÇÃO! Foi detectada uma falha de segurança conhecida!");
define("FR_LAN_27", "Existem arquivos no seu servidor que contém vulnerabilidades de segurança conhecidas e devem ser removidos de imediato.");
define("FR_LAN_28", "Arquivos inseguros detectados");


?>