<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Erro");
define("LAN_ERROR_1", "Erro 401 - Permissão Negada");
define("LAN_ERROR_2", "Não tem permissão para visualizar a hiperligação ou o URL solicitado.");
define("LAN_ERROR_3", "Faz favor, informe o administrador da página de referência, se você achar que esta página de erro tem sido vista por engano.");
define("LAN_ERROR_4", "Erro 403 - Falha na Autenticação");
define("LAN_ERROR_5", "O URL solicitado requer um nome de utilizador e senha correctos. Possivelmente introduziu o utilizador/senha de forma incorrecta ou o seu navegador não suporta esta funcionalidade.");
define("LAN_ERROR_6", "Faz favor, informe o administrador da página de referência, se você achar que esta página de erro tem sido vista por engano.");
define("LAN_ERROR_7", "Erro 404 - Documento Não Encontrado");
define("LAN_ERROR_9", "Por favor informe o administrador acerca da página que o levou a obter esta mensagem de erro, na eventualidade de esta ter sido mostrada por engano.");
define("LAN_ERROR_10", "Erro 500 - Cabeçalho Defeituoso");
define("LAN_ERROR_11", "O servidor encontrou um erro interno ou de configuração, não permitindo a conclusão do seu pedido.");
define("LAN_ERROR_12", "Faz favor, informe o administrador da página de referência, se você achar que esta página de erro tem sido vista por engano.");
define("LAN_ERROR_13", "Erro - Desconhecido");
define("LAN_ERROR_14", "O servidor encontrou um erro.");
define("LAN_ERROR_15", "Faz favor, informe o administrador da página de referência, se você achar que esta página de erro tem sido vista por engano.");
define("LAN_ERROR_16", "A sua tentativa de acesso falhou.");
define("LAN_ERROR_17", "foi registad@.");
define("LAN_ERROR_18", "Aparentemente, foi redireccionado para esta página a partir de");
define("LAN_ERROR_19", "Lamentavelmente a hiperligação nesse endereço encontra-se desactualizada.");
define("LAN_ERROR_20", "Por favor clique aqui para voltar à página inicial.");
define("LAN_ERROR_21", "A URL solicitada não pôde ser encontrado neste servidor. O link que você seguiu provavelmente está desactualizado.");
define("LAN_ERROR_22", "Faz favor, clique aqui para ir a página de pesquisa dentro deste sitio.");
define("LAN_ERROR_23", "A sua tentativa de acesso");
define("LAN_ERROR_24", "não foi bem-sucedida.");
define("LAN_ERROR_25", "[1]: Não é possível ler as definições da base de dados central - As definições existem, mas não podem ser lidas. Tentar restaurar ou fazer backup...");
define("LAN_ERROR_26", "[2]: Não é possível ler as definições da base de dados central - não existe as configurações principais.");
define("LAN_ERROR_27", "[3]: As configurações foram salvas - O backup ficou activo.");
define("LAN_ERROR_28", "[4]: Backup do sistema não foi encontrado. Verifique se o seu banco de dados tem conteúdo válido. Se não, por favor, execute o <a href='".e_FILE."resetcore/resetcore.php'> Resetear </a> para reconstruir suas principais definições.<br /> Depois de reconstruir o seu sistema, queira guardar uma cópia de segurança a partir do admin. ");
define("LAN_ERROR_29", "[5]: O(s) Campo(s) foram deixados em branco. Reenvie o formulário e preencha os campos obrigatórios.");
define("LAN_ERROR_30", "[6]: Não é possível formar uma conexão válida para mySQL. Verifique se o seu e107_config.php contém as informações corretas.");
define("LAN_ERROR_31", "[7]: A base de dados mySQL, está a ser executada ({$mySQLdefaultdb}) mas não pôde ser ligada.<br /> Faz favor, verifique que o arquivo e107_config.php existe e que contém as informações corretas.");
define("LAN_ERROR_32", "Para completar a actualização, copie o seguinte texto em seu e107_config.php arquivo:");
define("LAN_ERROR_33", "Erro de processamento! Normalmente, gostaria de redireccionar para a página inicial.");
define("LAN_ERROR_34", "Erro desconhecido! Faz favor, informe o administrador do sitio que você viu este:");
define("LAN_ERROR_35", "Erro 400 - Pedido Mal Sucedido");
define("LAN_ERROR_36", "Existe um erro na formatação da página web que você está tentando aceder.");
define("LAN_ERROR_37", "Ícone de Erro.");
define("LAN_ERROR_38", "");
define("LAN_ERROR_39", "");


?>