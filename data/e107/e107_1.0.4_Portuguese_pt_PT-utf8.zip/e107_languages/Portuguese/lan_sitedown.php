<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "O nosso sítio web encontra-se temporariamente encerrado para manutenção.");
define("LAN_SITEDOWN_00", "está temporariamente encerrado.");
define("LAN_SITEDOWN_01", "O sítio web está temporariamente encerrado para manutenção.<br />Faz favor, volte mais tarde - Prometemos ser breves e pedimos desculpa pelo incómodo.");


?>