<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Só Membros");
define("LAN_MEMBERS_0", "área restrita");
define("LAN_MEMBERS_1", "Esta é uma área restrita.");
define("LAN_MEMBERS_2", "Para aceder deverá de <a href='".e_LOGIN."'>Iniciar Sessão</a>");
define("LAN_MEMBERS_3", " ou <a href='".e_SIGNUP."'>registar-se</a> como membro.");
define("LAN_MEMBERS_4", "Clique aqui para voltar à página principal");


?>