<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Transferências de arquivos");
define("LAN_UL_001", "Endereço de email inválido");
define("LAN_UL_002", "Você não tem permissões de acesso para subir arquivos.");
define("LAN_UL_020", "Erro");
define("LAN_UL_021", "Falhou ao Carregar");
define("LAN_UL_032", "Você deve seleccionar uma categoria");
define("LAN_UL_033", "Você deve digitar um endereço de email válido");
define("LAN_UL_034", "Você deve especificar o nome do arquivo");
define("LAN_UL_035", "Você deve fazer uma descrição");
define("LAN_UL_036", "Você deve especificar o arquivo para carregar");
define("LAN_UL_037", "Você deve especificar uma categoria");
define("LAN_UL_038", "");
define("LAN_61", "Utilizador:");
define("LAN_112", "Email:");
define("LAN_144", "Página Web - URL: ");
define("LAN_402", "Tem que estar registado para poder transferir arquivos para este servidor.");
define("LAN_404", "Obrigado. O seu arquivo será visto por um administrador, sendo adicionado ao sitio se for considerado apropriado.");
define("LAN_406", "NOTA");
define("LAN_407", "Qualquer outro tipo de arquivo será apagado de imediato.");
define("LAN_408", "Sublinhado");
define("LAN_409", "Nome do arquivo");
define("LAN_410", "Versão");
define("LAN_411", "Arquivo");
define("LAN_412", "Imagem");
define("LAN_413", "Descrição");
define("LAN_414", "Demo");
define("LAN_415", "Insira o URL do sitio onde poderá ser vista uma demo do arquivo");
define("LAN_416", "Enviar e Transferir");
define("LAN_417", "Subir Arquivo");
define("LAN_418", "Tamanho máximo do arquivo:");
define("DOWLAN_11", "Categoria");
define("LAN_419", "Tipo de arquivos permitidos");
define("LAN_420", "Campos obrigatórios");


?>