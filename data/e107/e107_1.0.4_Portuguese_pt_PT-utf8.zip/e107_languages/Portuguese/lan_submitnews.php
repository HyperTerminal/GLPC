<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Enviar Notícias");
define("LAN_7", "Nome:");
define("LAN_62", "Título: ");
define("LAN_112", "Email:");
define("LAN_133", "Obrigado");
define("LAN_134", "A sua notícia foi enviada e será avaliada por um administrador.");
define("LAN_135", "Notícia:");
define("LAN_136", "Enviar Novo Tema");
define("NWSLAN_6", "Categoria");
define("NWSLAN_10", "Não estão definidas as categorias");
define("NWSLAN_11", "Não tem acesso a esta área.");
define("NWSLAN_12", "Acesso negado.");
define("SUBNEWSLAN_1", "Necessita de indicar um título.\\n");
define("SUBNEWSLAN_2", "Necessita de incluir algum texto na notícia.\\n");
define("SUBNEWSLAN_3", "O seu anexo pode ser um arquivo do tipo: jpg, gif ou png");
define("SUBNEWSLAN_4", "Arquivo muito grande");
define("SUBNEWSLAN_5", "Arquivo de imagem");
define("SUBNEWSLAN_6", "(jpg, gif ou png)");
define("SUBNEWSLAN_7", "Você deve dar o seu nome e endereço de email");
define("SUBNEWSLAN_8", "Erro ao carregar imagem");


?>