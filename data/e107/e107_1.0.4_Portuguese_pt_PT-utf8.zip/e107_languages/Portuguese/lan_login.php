<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_27", "Não preencheu o(s) campo(s) necessário(s)");
define("LAN_300", "Início de sessão incorrecta. Os dados inseridos não correspondem a nenhum utilizador registado. Verifique se tem o CAPS-LOCK activado. O menu de inicio de sessão diferencia as maiúsculas das minúsculas.");
define("LAN_302", "Você ainda não activou sua conta. Você deve ter recebido um email com instruções sobre como confirmar sua conta de utilizador. Se não for assim, faz favor clique <a href='".e_BASE."signup.php?resend'> AQUI</a>");
define("LAN_303", "O código é incorrecto.");
define("LAN_304", "Nome de utilizador e senha já estão em utilização.");
define("LAN_LOGIN_1", "Nome de Utilizador");
define("LAN_LOGIN_2", "Senha de Utilizador");
define("LAN_LOGIN_3", "Servidor protegido");
define("LAN_LOGIN_4", "Faz favor, insira os seus dados para poder aceder.");
define("LAN_LOGIN_5", "Clique aqui para registar-se");
define("LAN_LOGIN_6", "Neste momento não estamos a aceitar novos membros. Obrigado!");
define("LAN_LOGIN_7", "Digitar Código");
define("LAN_LOGIN_8", "Lembrar-me");
define("LAN_LOGIN_9", "Iniciar Sessão");
define("LAN_LOGIN_10", "Clique para efectuar o Início de Sessão");
define("LAN_LOGIN_11", "Registe-se como novo utilizador");
define("LAN_LOGIN_12", "Esqueci a Senha");
define("LAN_LOGIN_13", "Faz favor, insira o texto correspondente à imagem");
define("LAN_LOGIN_14", "O utilizador tentou aceder com um nome não reconhecido");
define("LAN_LOGIN_15", "O utilizador tentou aceder com uma senha incorrecta");
define("LAN_LOGIN_16", "O utilizador tentou aceder com um nome de utilizador ou senha já em utilização.");
define("LAN_LOGIN_17", "Senha de utilizador (oculta)");
define("LAN_LOGIN_18", "Expulsão Automática: Mais de 10 tentativas falhadas de início de sessão.");
define("LAN_LOGIN_19", "> 10 tentativas falhadas de início de sessão");


?>