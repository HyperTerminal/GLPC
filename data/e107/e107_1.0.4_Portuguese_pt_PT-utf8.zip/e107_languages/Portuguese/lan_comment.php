<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("COMLAN_0", "[bloqueado pelo admin]");
define("COMLAN_1", "Desbloquear");
define("COMLAN_2", "Bloquear");
define("COMLAN_3", "Apagar");
define("COMLAN_4", "Informações");
define("COMLAN_5", "Comentários...");
define("COMLAN_6", "Necessita de estar ligado para poder inserir comentários. Deverá de efectuar o início de sessão ou se ainda não estiver registado deverá clicar");
define("COMLAN_7", "Administrador principal");
define("COMLAN_8", "Comentar");
define("COMLAN_9", "Enviar Comentário");
define("COMLAN_10", "Administrador");
define("COMLAN_11", "Não foi possível inserir os seus comentários na base de dados - por favor, redigi-te a mensagem omitindo todos os caracteres que não sejam de uso comum.");
define("COMLAN_12", "Utilizador");
define("COMLAN_16", "Nome de utilizador:");
define("COMLAN_99", "Comentários");
define("COMLAN_100", "Notícias");
define("COMLAN_101", "Inquérito");
define("COMLAN_102", "Responder a:");
define("COMLAN_103", "Artigo");
define("COMLAN_104", "Revisão");
define("COMLAN_105", "Conteúdo");
define("COMLAN_106", "Descargas");
define("COMLAN_145", "Registado:");
define("COMLAN_194", "Visitante");
define("COMLAN_195", "Membro registado");
define("COMLAN_310", "A mensagem não foi aceite uma vez que esse nome de utilizador está registado - Se for o seu, deverá efectuar o Início de Sessão para poder escrever a mensagem.");
define("COMLAN_312", "Mensagem duplicada - não foi aceite.");
define("COMLAN_313", "Local:");
define("COMLAN_314", "Moderar Comentários");
define("COMLAN_315", "Trackbacks");
define("COMLAN_316", "Não há trackbacks para esta notícia.");
define("COMLAN_317", "Moderar trackbacks");
define("COMLAN_318", "Editar comentário");
define("COMLAN_319", "editado");
define("COMLAN_320", "Actualizar comentário");
define("COMLAN_321", "aqui");
define("COMLAN_322", "para registar-se");
define("COMLAN_323", "Erro!");
define("COMLAN_324", "Assunto");
define("COMLAN_325", "Re:");
define("COMLAN_326", "Responder");
define("COMLAN_327", "Classificação");
define("COMLAN_328", "Comentários bloqueados");
define("COMLAN_329", "Não autorizado");
define("COMLAN_330", "IP:");
define("COMLAN_331", "Aguardando aprovação");
define("COMLAN_TYPE_1", "notícias");
define("COMLAN_TYPE_2", "Descargas");
define("COMLAN_TYPE_3", "faq");
define("COMLAN_TYPE_4", "Inquérito");
define("COMLAN_TYPE_5", "documentos");
define("COMLAN_TYPE_6", "bugtrack");
define("COMLAN_TYPE_7", "ideias");
define("COMLAN_TYPE_8", "Perfil de Utilizador");
define("COMLAN_TYPE_PAGE", "Conteúdo");


?>