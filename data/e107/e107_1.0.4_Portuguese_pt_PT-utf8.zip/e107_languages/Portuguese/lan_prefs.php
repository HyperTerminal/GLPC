<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_PREF_1", "Website e107");
define("LAN_PREF_2", "Portal de Gestão e107");
define("LAN_PREF_3", "Este site é gerido pelo sistema <a href='http://e107.org/' rel='external'>e107</a>, que foi disponibilizado sob os termos da Licença <a href='http://www.gnu.org/' rel='external'>GNU</a> GPL.");
define("LAN_PREF_4", "Censura");
define("LAN_PREF_5", "Fóruns");


?>