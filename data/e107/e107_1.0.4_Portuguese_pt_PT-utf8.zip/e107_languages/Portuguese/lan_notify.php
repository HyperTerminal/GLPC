<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("NT_LAN_US_1", "Registo de utilizador");
define("NT_LAN_UV_1", "Registo de utilizador verificado");
define("NT_LAN_UV_2", "ID de utilizador");
define("NT_LAN_UV_3", "Nome para iniciar sessão de utilizador:");
define("NT_LAN_UV_4", "IP do utilizador:");
define("NT_LAN_LI_1", "Utilizador ligado");
define("NT_LAN_LO_1", "Utilizador Inactivo");
define("NT_LAN_LO_2", " desligou-se do sitio");
define("NT_LAN_FL_1", "Expulsado por excessos");
define("NT_LAN_FL_2", "Endereço de IP expulsado por excessos");
define("NT_LAN_SN_1", "Notícias Enviadas");
define("NT_LAN_NU_1", "Actualizado");
define("NT_LAN_ND_1", "Notícias apagadas");
define("NT_LAN_ND_2", "ID das notícias apagadas");
define("NT_LAN_CM_1", "Comentário de utilizador aguardando Aprovação");


?>