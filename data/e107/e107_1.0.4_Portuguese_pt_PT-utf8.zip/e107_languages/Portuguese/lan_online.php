<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("ONLINE_EL1", "Visitantes:");
define("ONLINE_EL2", "Membros:");
define("ONLINE_EL3", "Nesta página:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Membros");
define("ONLINE_EL6", "Novo membro");
define("ONLINE_EL7", "ver");
define("ONLINE_EL8", "Máximo online:");
define("ONLINE_EL9", "em");
define("ONLINE_EL10", "Nome de Membro");
define("ONLINE_EL11", "Ver página");
define("ONLINE_EL12", "Responder");
define("ONLINE_EL13", "Fórum");
define("ONLINE_EL14", "Tema");
define("ONLINE_EL15", "Página");
define("CLASSRESTRICTED", "Página restrita");
define("ARTICLEPAGE", "Artigo/Revisão");
define("CHAT", "Chat");
define("COMMENT", "Comentários");
define("DOWNLOAD", "Descargas");
define("EMAIL", "Email.php");
define("FORUM", "Índice Principal Fórum");
define("LINKS", "Links");
define("NEWS", "Notícias");
define("OLDPOLLS", "Antiga Classificação");
define("POLLCOMMENT", "Classificação");
define("PRINTPAGE", "Imprimir");
define("LOGIN", "Ligar");
define("SEARCH", "Pesquisar");
define("STATS", "Estatísticas");
define("SUBMITNEWS", "Enviar Notícias");
define("UPLOAD", "Subir");
define("USERPAGE", "Perfil Utilizador");
define("USERSETTINGS", "Definições Utilizador");
define("ONLINE", "Utilizadores online");
define("LISTNEW", "Novos Temas");
define("USERPOSTS", "Publicações de Utilizador");
define("SUBCONTENT", "Envios artigos/revisões");
define("TOP", "Temas/Anúncios mais activos");
define("ADMINAREA", "Área Admin");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Lista eventos");
define("CALENDAR", "Calendário eventos");
define("FAQ", "FAQ");
define("PM", "Mensagens Privadas");
define("SURVEY", "Sondagem");
define("ARTICLE", "Artigo");
define("CONTENT", "Conteúdo");
define("REVIEW", "Revisão");


?>