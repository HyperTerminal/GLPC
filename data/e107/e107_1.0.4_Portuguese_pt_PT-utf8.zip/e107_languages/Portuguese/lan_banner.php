<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Anúncios");
define("BANNERLAN_16", "Utilizador:");
define("BANNERLAN_17", "Senha:");
define("BANNERLAN_18", "Continuar");
define("BANNERLAN_19", "Por favor insira o seu nome/senha para continuar.");
define("BANNERLAN_20", "Lamentamos, os dados inseridos não constam na base de dados. Por favor contacte o administrador do sitio para mais informações.");
define("BANNERLAN_21", "Estatísticas de Anúncios");
define("BANNERLAN_22", "Cliente");
define("BANNERLAN_23", "ID Anúncio");
define("BANNERLAN_24", "Cliques de Visitas");
define("BANNERLAN_25", "% Visitas");
define("BANNERLAN_26", "Publicações");
define("BANNERLAN_27", "Publicações adquiridas");
define("BANNERLAN_28", "Publicações em falta");
define("BANNERLAN_29", "Sem anúncios");
define("BANNERLAN_30", "Ilimitado");
define("BANNERLAN_31", "Não aplicável");
define("BANNERLAN_32", "Sim");
define("BANNERLAN_33", "Não");
define("BANNERLAN_34", "Termina:");
define("BANNERLAN_35", " Cliques visitantes - Endereço IP");
define("BANNERLAN_36", "Activo:");
define("BANNERLAN_37", "Início:");
define("BANNERLAN_38", "Erro");


?>