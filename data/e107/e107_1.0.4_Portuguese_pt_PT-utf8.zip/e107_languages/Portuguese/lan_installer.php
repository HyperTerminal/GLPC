<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

define('LANINS_TITLE', 	'Instalação de e107');
define('LANINS_000', 	'Informações inválidas! Instalação interrompida.');
define('LANINS_001', 	'Versão %1$s');
define('LANINS_002', 	'Instalação');
define('LANINS_002a', 	'(Fase %1$s de 7)');
define('LANINS_003', 	'1');
define('LANINS_004', 	'Seleção do idioma');
define('LANINS_004a', 	'Idioma escolhido');
define('LANINS_004b', 	'Idioma');
define('LANINS_005', 	'Faz favor, escolha o idioma que será utilizado durante o processo de instalação');
define('LANINS_006', 	'Definir idioma');
define('LANINS_007', 	'4');
define('LANINS_008', 	'Verificação das Versões de PHP & MySQL e das permissões das pastas e arquivos');
define('LANINS_008a', 	'Permissões de compatibilidade e Arquivo');
define('LANINS_009', 	'Testar permissões de ficheiros');
define('LANINS_010', 	'Arquivos sem permissões de escrita:');
define('LANINS_010a', 	'Directoria sem permissões de escrita:');
define('LANINS_011', 	'Erro');
define('LANINS_012', 	'As funções de MySQL parecem não existir. Provavelmente significa que tanto o MySQL/PHP Extension não estão instalados ou a instalação do PHP não foi configurada com suporte para MySQL.');
define('LANINS_013', 	'A sua versão do MySQL não foi verificada. Não se trata de um erro fatal, a instalação poderá continuar o seu processo, no entanto tome nota que o e107 necessita da versão MySQL >= 3.23 para funcionar correctamente.');
define('LANINS_014', 	'Permissões de Arquivos');
define('LANINS_015', 	'Versão de PHP');
define('LANINS_016', 	'MySQL');
define('LANINS_017', 	'OK');
define('LANINS_018', 	'Por favor, certifique-se que todos os arquivos listados existem e têm permissões de escrita no servidor. Este processo requer normalmente uma operação de permissão CHMOD 777, mas poderá variar de acordo com as características do servidor - contacte-se com o administrador do seu alojamento caso tenha alguma dúvida.');
define('LANINS_019', 	'A versão de PHP instalada no seu servidor não tem capacidade de suporte para correr o e107. O e107 necessita pelo menos da versão de PHP 4.3.0 para funcionar correctamente. Deverá actualizar sua versão de PHP ou contactar o administrador do seu alojamento no sentido de efectuar uma actualização.');
define('LANINS_020', 	'Continuar Instalação');
define('LANINS_021', 	'2');
define('LANINS_022', 	'Detalhes do servidor MySQL');
define('LANINS_022a',	'Base de Dados');
define('LANINS_023', 	'Por favor, insira os dados necessários para configurar o MySQL.<br /><br />Se você possui as permissões de administrador principal, poderá criar uma nova base de dados seleccionando a caixa respectiva, caso contrário devera criar uma base de dados ou utilizar uma já existente.<br /><br />Se possuir apenas uma base de dados, utilize um prefixo de forma a que as outras aplicações possam partilhar a mesma base de dados.<br /><br />Na eventualidade de desconhecer os seus dados de MySQL, deverá contactar-se com o administrador do alojamento do seu sítio web.');
define('LANINS_024', 	'Servidor MySQL:');
define('LANINS_025', 	'Utilizador MySQL:');
define('LANINS_026', 	'Senha MySQL:');
define('LANINS_027', 	'Base de Dados MySQL:');
define('LANINS_028', 	'Criar Base de Dados?');
define('LANINS_029', 	'Prefixo das Tabelas:');
define('LANINS_030', 	'O servidor MySQL no qual deseja usar o e107. Poderá também incluir um número de porta. p.exo. \'hostname:port\' ou o caminho para um socket local, ex. \':/caminho/para/socket\' para o localhost.');
define('LANINS_031', 	'O nome de utilizador que o e107 deverá utilizar para ligar-se ao servidor MySQL (Modo Local: root).');
define('LANINS_032', 	'A senha para o utilizador MySQL (Modo Local: vazia).');
define('LANINS_033', 	'A base de dados MySQL na qual o e107 vai residir. Se o utilizador tem permissões para a criação de base de dados, pode optar por criá-la de forma automática, caso esta ainda não exista.');
define('LANINS_034', 	'O prefixo utilizado pelo e107 na criação das suas tabelas. Útil para múltiplas instalações de e107 em conjunto com outras aplicações na mesma base de dados.');
define('LANINS_035', 	'Continuar');
define('LANINS_036', 	'3');
define('LANINS_037', 	'Verificação da ligação MySQL');
define('LANINS_038', 	' e criação da base de dados.');
define('LANINS_038a', 	'Validação da base de dados');
define('LANINS_039', 	'Por favor, certifique-se que todos os campos foram preenchidos. Nomeadamente o Servidor MySQL, Utilizador MySQL e Base de dados MySQL. (estes dados são sempre necessários para um Servidor MySQL).');
define('LANINS_040', 	'Erros');
define('LANINS_041', 	'O e107 não conseguiu estabelecer a ligação ao servidor de MySQL com a informação fornecida.<br />Por favor, volte a inserir os dados que são necessários para uma instalação favorável.');
define('LANINS_042', 	'A ligação ao servidor de MySQL foi estabelecida e verificada.');
define('LANINS_043', 	'Não foi possível criar a base de dados. Por favor, certifique-se que possui as permissões correctas para a criação de base de dados no seu servidor.');
define('LANINS_044', 	'A base de dados foi criada com sucesso!');
define('LANINS_045', 	'Por favor, clique no botão <b>Continuar</b> para passar a fase seguinte.');
define('LANINS_046', 	'5');
define('LANINS_047', 	'Dados de Administrador');
define('LANINS_047a', 	'Administração');
define('LANINS_048', 	'Voltar à fase anterior');
define('LANINS_049', 	'As duas senhas não coincidem. Faz favor volte a tentar.');
define('LANINS_050', 	'Extensão XML');
define('LANINS_051', 	'Instalado');
define('LANINS_052', 	'Não Instalado');
define('LANINS_053', 	'e107 0.7.x requer a extensão PHP XML para ser instalado. Entre em contacto com seu administrador de host ou pode ler as informações em <a href="http://php.net/manual/en/ref.xml.php" target="_blank">php.net</a> antes de continuar.');
define('LANINS_054', 	'A base de dados escolhida foi verificada com sucesso.');
define('LANINS_055', 	'Confirmação da instalação');
define('LANINS_055a', 	'Confirmar');
define('LANINS_056', 	'6');
define('LANINS_057', 	'O e107 tem toda a informação necessária para terminar o processo de instalação.<br /><br />Por favor, clique no botão <b>Continuar</b> para criar as tabelas na base de dados e salvar todas as suas definições.');
define('LANINS_058', 	'7');
define('LANINS_060', 	'O arquivo de dados do SQL não foi lido.<br /><br /><br />Faz favor, certifique-se que o arquivo <b>core_sql.php</b> existe na directoria <b>/e107_admin/sql</b>.');
define('LANINS_061', 	'O e107 não conseguiu criar todas as tabelas necessárias na base de dados.<br /><br />Faz favor, limpe por completo a base de dados e corrija quaisquer problemas antes de tentar novamente.');
define('LANINS_062', 	'');

define('LANINS_063', 	'Bem-vindo a e107');
define('LANINS_069', 	'O e107 foi instalado com sucesso!<br /><br />Por razões de segurança é conveniente mudar as permissões do arquivo <b>e107_config.php</b> para 644.<br /><br />Deverá também apagar do seu servidor o arquivo <i>install.php</i> da directoria principal de <i>e107</i>.<br /><br />Clique no botão <b>Continuar</b>');
define('LANINS_070', 	'O e107 não conseguiu salvar as definições principais no seu servidor. Faz favor, verifique se o arquivo<b> e107_config.php </b>tem as permissões de escrita correctas.');
define('LANINS_071', 	'Finalizar Instalação');
define('LANINS_071a', 	'Concluída');
define('LANINS_071b', 	'Erro ao finalizar instalação');
define('LANINS_071c', 	'Concluído com erro');
define('LANINS_072', 	'Nome de Administrador');
define('LANINS_073', 	'Este nome será utilizado para efectuar o início de sessão no sítio web.');
define('LANINS_074', 	'Nome a ver do Admin');
define('LANINS_075', 	'Este é o nome que será mostrado aos utilizadores na sua página de perfil, fóruns e outras áreas. Para usar o mesmo nome do seu Inicio de Sessão, deixe este campo em branco.');
define('LANINS_076', 	'Senha do Administrador');
define('LANINS_077', 	'Por favor, escreva a senha de administrador que deseja utilizar');
define('LANINS_078', 	'Confirmação da senha');
define('LANINS_079', 	'Por favor, insira novamente a senha do administrador para confirmação');
define('LANINS_080', 	'Email de Administrador');
define('LANINS_081', 	'Insira o email de administrador');
define('LANINS_082', 	'utilizador@oseusite.pt');
define('LANINS_083', 	'Erro reportado pelo MySQL:');
define('LANINS_084', 	'O programa de instalação não conseguiu estabelecer uma ligação com a base de dados.');
define('LANINS_085', 	'O programa de instalação não conseguiu seleccionar a base de dados:');
define('LANINS_086', 	'O Nome, Senha e Email de Administrador são <b>campos obrigatório.</b> Faz favor, volte para a página e veja se a informação foi digitada correctamente.');
define('LANINS_087', 	'Outros');
define('LANINS_088', 	'Início');
define('LANINS_089', 	'Descargas');
define('LANINS_090', 	'Membros');
define('LANINS_091', 	'Envios de Notícias');
define('LANINS_092', 	'Contato');
define('LANINS_093', 	'Dar acesso aos itens de menus privados');
define('LANINS_094', 	'Exemplo classe fórum privado');
define('LANINS_095', 	'Verificar Integridade');
define('LANINS_096',	'Últimos Comentários');
define('LANINS_097', 	'[mais ...]');
define('LANINS_098', 	'Notícias');
define('LANINS_099', 	'e107 CMS');
define('LANINS_100', 	'Últimas Publicações Fórum');
define('LANINS_101', 	'Actualizar Opcões de menu');
define('LANINS_102', 	'Data/Hora');
define('LANINS_103', 	'e107 Plugins');
define('LANINS_104', 	'Verificado');
define('LANINS_105', 	'O nome ou prefixo da base de dados não pode começar com alguns dígitos, seguido de "e" ou "E". <br />O nome ou prefixo da base de dados não pode estar vazio.');
define('LANINS_106', 	'ATENÇÃO - e107 não pode escrever para as directorias e/ou arquivos listados. Por enquanto isso não vai parar a instalação de e107, pode significar que certas características não estarão disponíveis.<br />Você vai precisar de mudar as permissões de escrita dos arquivos.');
define('LANINS_107', 	'O arquivo e107_config.php não está vazio');
define('LANINS_108', 	'Possivelmente você tem uma instalação já existente');

define('LANINS_DB_UTF8_LABEL', 	'Forçar a Base de Datos para UTF-8');
define('LANINS_DB_UTF8_CAPTION','MySQL Charset:');
define('LANINS_DB_UTF8_TOOLTIP','Será definido, a instalação vai criar a base de dados compatível com UTF-8. A codificação UTF-8 será necessária para as próximas versões de e107.');

// v1.0 - . 

define('LANINS_109', 	'Início');
define('LANINS_110', 	'Completo');
define('LANINS_111', 	'e107 Themes');
define('LANINS_112', 	'e107 Handbook');
define('LANINS_113', 	'');

define('LANINS_121', 	'e107_config.php já existe!');
define('LANINS_122', 	'Possivelmente você tem uma instalação existente');
define('LANINS_123', 	'Informações de depuração');
define('LANINS_124', 	'backtrace');
define('LANINS_125', 	'Fase inválida');
define('LANINS_125a', 	'Erro');

define('LANINS_WELCOME','[b]Bem-vindo ao seu novo sítio web![/b]

e107 foi instalado com sucesso e está pronto para aceitar todo o conteúdo para o seu portal. A sua área de administração está localizada [link=e107_admin/admin.php]AQUI[/link], clique para ser redireccionado agora mesmo. Terá que utilizar o nome de utilizador e senhas fornecidas por você, durante o processo de instalação.

[b]Suporte[/b]
[link=http://e107.org/]e107 Homepage[/link] 
[link=http://e107.org/support]e107 Forums[/link] 
[link=http://wiki.e107.org/]e107 Handbook[/link] 

Muito Obrigado por instalar e107, desejamos que este (CMS) cumpra os requisitos necessários para seu novo sítio web.');

define('LANINS_NEWS', 	'[b]Bem-vindo![/b]
e107 é um sistema de gerenciamento de conteúdo escrito em PHP e utiliza a popular MySQL de código aberto para a criação de base de dados  para o armazenamento de conteúdo. É totalmente gratuito, totalmente personalizável e em constante desenvolvimento. 

[list][link=http://e107.org/content/Learn-all-about-e107]Tudo o que você precisa saber sobre e107[/link]*[link=http://e107.org/content/About-Us:The-Team]Desenvolvedores | Tradutores | Equipa de Suporte[/link]*[link=http://wiki.e107.org/]Documentação Wiki[/link][/list]');

?>