<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LAN_EMAIL_1", "De:");
define("LAN_EMAIL_2", "Endereço IP do remetente:");
define("LAN_EMAIL_3", "Notícia enviada por");
define("LAN_EMAIL_4", "Enviar email");
define("LAN_EMAIL_5", "Enviar este tema por email a um amigo!");
define("LAN_EMAIL_6", "Pensei que poderias estar interessado neste tema de...");
define("LAN_EMAIL_7", "Enviar notícia a um amigo");
define("LAN_EMAIL_8", "Comentário");
define("LAN_EMAIL_9", "Lamentamos - não foi possível enviar o email");
define("LAN_EMAIL_10", "Email enviado para");
define("LAN_EMAIL_11", "Email enviado");
define("LAN_EMAIL_12", "Erro");
define("LAN_EMAIL_13", "Enviar artigo por email a um amigo");
define("LAN_EMAIL_14", "Enviar temas de notícia a um amigo");
define("LAN_EMAIL_15", "Nome de Utilizador:");
define("LAN_EMAIL_106", "Não aparenta ser um endereço de email válido");
define("LAN_EMAIL_185", "Enviar Artigo");
define("LAN_EMAIL_186", "Enviar Notícia");
define("LAN_EMAIL_187", "Email do destinatário");
define("LAN_EMAIL_188", "Pensei que poderias estar interessado nesta notícia de");
define("LAN_EMAIL_189", "Pensei que poderias estar interessado neste artigo de");
define("LAN_EMAIL_190", "Digitar Código");


?>