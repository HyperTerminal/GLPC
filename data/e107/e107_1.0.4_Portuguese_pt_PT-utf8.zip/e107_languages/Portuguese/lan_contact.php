<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Contacto");
define("LANCONTACT_01", "Detalhes de Contacto");
define("LANCONTACT_02", "Formulário de Contacto");
define("LANCONTACT_03", "Insira seu nome:");
define("LANCONTACT_04", "Endereço de email:");
define("LANCONTACT_05", "Assunto da mensagem:");
define("LANCONTACT_06", "Escreva sua mensagem:");
define("LANCONTACT_07", "Enviar cópia desta mensagem para meu email");
define("LANCONTACT_08", "Enviar");
define("LANCONTACT_09", "Sua mensagem foi enviada.");
define("LANCONTACT_10", "Surgiu um problema no envio de sua mensagem");
define("LANCONTACT_11", "Seu endereço de email não parece ser válido.\\nFaz favor, verifique e tente novamente.");
define("LANCONTACT_12", "Sua mensagem é muito curta.");
define("LANCONTACT_13", "Faz favor, insira um assunto.");
define("LANCONTACT_14", "Enviar mensagem para:");
define("LANCONTACT_15", "O código foi digitado incorrectamente");
define("LANCONTACT_16", "Digitar Código");


?>