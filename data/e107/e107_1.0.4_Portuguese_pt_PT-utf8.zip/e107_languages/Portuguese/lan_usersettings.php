<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Definições do Utilizador");
define("LAN_7", "Nome a Mostrar:");
define("LAN_8", "Este é o nome que será mostrado no sitio");
define("LAN_9", "Nome de Utilizador:");
define("LAN_10", "Este é o nome que será utilizado para efectuar o início de sessão no sitio");
define("LAN_11", "O nome para efectuar o início de sessão não pode ser alterado, por favor contacte o administrador caso necessite alterá-lo por motivos de segurança.");
define("LAN_20", "Erro");
define("LAN_105", "As duas senhas não coincidem");
define("LAN_106", "Não aparenta ser um endereço de email válido");
define("LAN_112", "Email:");
define("LAN_113", "Ocultar endereço de email?:");
define("LAN_114", "Esta opção ocultará o seu endereço de email no sitio");
define("LAN_120", "Assinatura:");
define("LAN_121", "Avatar:");
define("LAN_122", "Zona Horária:");
define("LAN_150", "As definições foram actualizadas e salvas na base de dados.");
define("LAN_151", "OK");
define("LAN_152", "Nova Senha:");
define("LAN_153", "Confirme a Senha:");
define("LAN_154", "Salvar Definições");
define("LAN_155", "Actualizar Definições de Utilizador");
define("LAN_185", "O campo da senha foi deixado em branco");
define("LAN_308", "Nome Verdadeiro:");
define("LAN_401", "Deixe em branco para manter a senha existente");
define("LAN_402", "Insira o endereço ou escolha um avatar");
define("LAN_403", "Escolher avatar");
define("LAN_404", "NOTA: Qualquer imagem transferida para este servidor que seja considerada inapropriada pelos administradores, será apagada de imediato.");
define("LAN_410", "Definições de");
define("LAN_411", "Actualizar Definições");
define("LAN_412", "Alterar Senha");
define("LAN_413", "Escolher avatar");
define("LAN_414", "Inserir fotografia");
define("LAN_415", "Inserir avatar");
define("LAN_416", "Sim");
define("LAN_417", "Não");
define("LAN_418", "Informação do Registo");
define("LAN_419", "Informação pessoal/contacto");
define("LAN_420", "Avatar");
define("LAN_421", "Seleccionar um avatar disponibilizado");
define("LAN_422", "Usar um avatar remoto");
define("LAN_423", "Por favor insira o endereço completo da imagem");
define("LAN_424", "Clique no botão para visualizar os avatars disponibilizados neste sitio");
define("LAN_425", "Fotografia");
define("LAN_426", "Será mostrada na sua página de perfil");
define("LAN_433", "URL do seu ficheiro XUP");
define("LAN_434", "O que é um ficheiro XUP?");
define("LAN_435", "Arquivo de Protocolo de Utilizador XML");
define("LAN_SIGNUP_1", "Min.");
define("LAN_SIGNUP_2", "cars.");
define("LAN_SIGNUP_4", "A sua senha necessita de conter pelo menos");
define("LAN_SIGNUP_5", " caracteres.");
define("LAN_SIGNUP_6", "O seu");
define("LAN_SIGNUP_7", " é necessário");
define("LAN_USET_1", "O seu avatar é muito largo");
define("LAN_USET_2", "A largura máxima permitida é");
define("LAN_USET_3", "O seu avatar é muito alto");
define("LAN_USET_4", "A altura máxima permitida é");
define("LAN_CUSTOMTITLE", "Título");
define("LAN_408", "Já existe um utilizador com este endereço de email.");
define("MAX_AVWIDTH", "O tamanho máximo do avatar (lxa) é");
define("MAX_AVHEIGHT", " x");
define("RESIZE_NOT_SUPPORTED", "Este servidor não suporta a alteração automática do tamanho de imagens (deverá alterar o seu tamanho ou escolher outra imagem) - arquivo apagado.");
define("LAN_USET_5", "Subscrito em");
define("LAN_USET_6", "Subscrever a(s) nossa(s) lista(s) e/ou secções do site.");
define("LAN_USET_7", "Vários");
define("LAN_USET_8", "Assinatura / Zona Horária");
define("LAN_USET_9", "Alguns campos são obrigatórios. Os marcados com um (*) são os que estão em falta.");
define("LAN_USET_10", "Deverá actualizar as suas definições agora para poder prosseguir.");
define("LAN_USET_11", "Este nome de utilizador não pode ser utilizado (inválido), por favor escolha um nome de utilizador diferente.");
define("LAN_USET_12", "Esse nome de utilizador é demasiado curto, escolha outro.");
define("LAN_USET_13", "Nome de utilizador com caracteres inválidos. Por favor escolha outro.");
define("LAN_USET_14", "Nome de inicio de sessão muito longo. Por favor, escolha outro.");
define("LAN_USET_15", "Nome de utilizador a mostrar é demasiado longo. Por favor, escolha outro.");
define("LAN_USET_16", "Clique na caixa existente para apagar a fotografia sem carregar outra");
define("LAN_USET_17", "Já existe um utilizador com este nome de utilizar. Escolha outro.");
define("LAN_USET_18", "Nome inválido para avatar");
define("LAN_USET_19", "Avatar não pode ser carregado");
define("LAN_USET_20", "Não é possível obter informação da imagem");


?>