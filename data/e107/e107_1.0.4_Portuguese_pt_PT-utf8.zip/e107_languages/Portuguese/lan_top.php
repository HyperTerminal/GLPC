<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("TOP_LAN_0", "Top Fórum");
define("TOP_LAN_1", "Utilizador");
define("TOP_LAN_2", "Mensagens");
define("TOP_LAN_3", "Top Comentários");
define("TOP_LAN_4", "Comentários");
define("TOP_LAN_5", "Top Chatbox");
define("TOP_LAN_6", "Classificação");
define("LAN_1", "Tema");
define("LAN_2", "Autor");
define("LAN_3", "Visualizações");
define("LAN_4", "Respostas");
define("LAN_5", "Último");
define("LAN_6", "Temas");
define("LAN_7", "Temas mais Activos");
define("LAN_8", "Top Autores");


?>