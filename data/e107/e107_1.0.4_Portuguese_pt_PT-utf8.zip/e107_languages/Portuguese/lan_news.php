<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Notícias");
define("LAN_NEWS_1", "Notícias para membros específicos");
define("LAN_NEWS_2", "Não tem as permissões necessárias para visualizar esta notícia");
define("LAN_NEWS_9", "A opção só título, encontra-se ligada - <b>Só será mostrado o título da notícia</b>");
define("LAN_NEWS_10", "Esta notícia está <b>inactiva</b> (Não será mostrada na página principal).");
define("LAN_NEWS_11", "Esta notícia está <b>activa</b> (Será mostrada na página principal).");
define("LAN_NEWS_12", "Os comentários estão <b>ligados</b>.");
define("LAN_NEWS_13", "Os comentários estão <b>desligados</b>.");
define("LAN_NEWS_14", "<br />Período de activação:");
define("LAN_NEWS_15", "Comprimento do conteúdo:");
define("LAN_NEWS_16", "b. Comprimento da extensão:");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Informação:");
define("LAN_NEWS_19", "Agora");
define("LAN_NEWS_23", "Categorias de Notícias");
define("LAN_NEWS_24", "Criar arquivo PDF para esta notícia");
define("LAN_NEWS_25", "Editar");
define("LAN_NEWS_31", "Notícia em destaque");
define("LAN_NEWS_82", "Notícias - Categoria");
define("LAN_NEWS_83", "De momento não existem notícias - por favor volte mais tarde.");
define("LAN_NEWS_84", "Notícias");
define("LAN_NEWS_85", "Voltar a categoria");
define("LAN_NEWS_86", "Notícia anterior");
define("LAN_NEWS_87", "Notícia seguinte");
define("LAN_NEWS_462", "Não existem notícias para o mês especificado");
define("LAN_NEWS_99", "Comentários");
define("LAN_NEWS_100", "Em");
define("LAN_NEWS_307", "Total de publicações nesta categoria:");


?>