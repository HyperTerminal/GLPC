<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Descargas");
define("LAN_dl_1", "(Restrito)");
define("LAN_dl_2", "Ainda não existem arquivos para descarregar, por favor, volte mais tarde.");
define("LAN_dl_3", "Ainda não existem arquivos para descarregar nesta categoria.");
define("LAN_dl_4", "Arquivos disponíveis:");
define("LAN_dl_5", "Tamanho total dos arquivos:");
define("LAN_dl_6", "Arquivos descarregados:");
define("LAN_dl_7", "Descrição");
define("LAN_dl_8", "Baixar");
define("LAN_dl_9", "Voltar à lista de categorias");
define("LAN_dl_10", "Tamanho");
define("LAN_dl_11", "Imagem");
define("LAN_dl_12", "Classificação");
define("LAN_dl_13", "Sem classificar");
define("LAN_dl_14", "Classificar esta descarga");
define("LAN_dl_15", "Obrigado pela sua avaliação!");
define("LAN_dl_16", "descarga(s) de");
define("LAN_dl_17", "Arquivos");
define("LAN_dl_18", "Descargas");
define("LAN_dl_19", "Categoria");
define("LAN_dl_20", "Arquivos");
define("LAN_dl_21", "Tamanho");
define("LAN_dl_22", "Data");
define("LAN_dl_23", "Nome do arquivo");
define("LAN_dl_24", "Autor");
define("LAN_dl_25", "Ascendente");
define("LAN_dl_26", "Descendente");
define("LAN_dl_27", "Ir");
define("LAN_dl_28", "Nome");
define("LAN_dl_29", "DL's");
define("LAN_dl_30", "Email");
define("LAN_dl_31", "Sítio Web");
define("LAN_dl_32", "Descargar");
define("LAN_dl_33", "Anterior");
define("LAN_dl_34", "Seguinte");
define("LAN_dl_35", "Voltar à lista");
define("LAN_dl_36", "Novas descargas");
define("LAN_dl_37", "Mostrar");
define("LAN_dl_38", "Ordenar por");
define("LAN_dl_39", "Ordem");
define("LAN_dl_40", "Clique aqui para ver a imagem");
define("LAN_dl_41", "Pesquisar Descargas");
define("LAN_dl_42", "Sub-categoria");
define("LAN_dl_43", "votar");
define("LAN_dl_44", "votos");
define("LAN_dl_45", "Reportar descarga avariada");
define("LAN_dl_46", "Clique aqui para efectuar a descarga");
define("LAN_dl_47", "O reporte foi enviado");
define("LAN_dl_48", "O reporte da descarga foi enviado ao administrador.<br />Muito Obrigado.");
define("LAN_dl_49", "Clique aqui para regressar a descargas");
define("LAN_dl_50", "Reportar descarga avariado ao administrador");
define("LAN_dl_51", "Reportar descarga:");
define("LAN_dl_52", "Visitante");
define("LAN_dl_53", "Clique aqui para ver a descarga");
define("LAN_dl_54", "O administrador será informado acerca desta descarga, também poderá incluir uma mensagem se achar conveniente.");
define("LAN_dl_55", "<b>NÃO</b> utilize esta área para contactar o administrador por outro motivo qualquer.");
define("LAN_dl_57", "reportado por");
define("LAN_dl_58", "A seguinte descarga foi reportada como danificada no site");
define("LAN_dl_59", "Reportado por:");
define("LAN_dl_60", "Relatório de descarga danificada de");
define("LAN_dl_61", "Erro no descarga");
define("LAN_dl_62", "Você tem sido impedido momentaneamente para baixar este arquivo. Excedeu o seu limite de descargas.");
define("LAN_dl_63", "Não tem as permissões correctas para efectuar a descarga deste arquivo.");
define("LAN_dl_64", "Voltar");
define("LAN_dl_65", "Arquivo Inexistente");
define("LAN_dl_66", "Seleccione o sitio de descarga");
define("LAN_dl_67", "Faz favor, seleccione um sitio para usar...");
define("LAN_dl_68", "Servidor de descarga");
define("LAN_dl_70", "Local");
define("LAN_dl_71", "Acerca");
define("LAN_dl_72", "Solicitar arquivo:");
define("LAN_dl_73", "Descargas a partir deste sítio:");
define("LAN_dl_74", "Total de descargas a partir deste sitio:");
define("LAN_dl_75", "Não existe imagem");
define("LAN_dl_76", "Ir para pág.");
define("LAN_dl_77", "Descargas");
define("LAN_dl_78", "Essa descarga foi desactivada ou apagada. Faz favor, verifique na área de [descargas] para uma nova versão mais recente.");
define("LAN_dl_79", "Aguarde alguns instantes antes de voltar a [baixar novamente].");
define("LAN_dl_80", "Active os cookies e [tente novamente].");
define("LAN_dl_81", "Os Cookies são necessários");
define("LAN_dl_82", "Aguarde...");
define("LAN_dl_83", "A descarga começará em um momento...");
define("LAN_dl_84", "Se a descarga não iniciar dentro de alguns segundos, por favor [clique aqui].");


?>