<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Publicações de Utilizador");
define("UP_LAN_0", "Todas as Publicações de");
define("UP_LAN_1", "Todos os Comentários de ");
define("UP_LAN_2", "Tema");
define("UP_LAN_3", "Visualizações");
define("UP_LAN_4", "Respostas");
define("UP_LAN_5", "Última");
define("UP_LAN_6", "Temas");
define("UP_LAN_7", "Sem Comentários");
define("UP_LAN_8", "Sem Mensagens");
define("UP_LAN_9", " em ");
define("UP_LAN_10", "Re.");
define("UP_LAN_11", "Publicado em");
define("UP_LAN_12", "Pesquisar");
define("UP_LAN_13", "Comentários");
define("UP_LAN_14", "Publicações Fórum");
define("UP_LAN_15", "Re.");
define("UP_LAN_16", "Endereço IP");


?>