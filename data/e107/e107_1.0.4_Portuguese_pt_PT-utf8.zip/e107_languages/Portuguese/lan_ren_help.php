<?php
/*
+---------------------------------------------------------------+
|       e107 content management system.
|       (Portuguese language file)
|
|       Tradução Português(PT) -> Comunidade e107 Portugal
|      	(http://www.e107pt.com), 2012
|
|     	Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     	Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|       Released under the terms and conditions of the
|       GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("LANHELP_1", "Preto");
define("LANHELP_2", "Azul");
define("LANHELP_3", "Castanho");
define("LANHELP_4", "Azul claro");
define("LANHELP_5", "Azul escuro");
define("LANHELP_6", "Vermelho escuro");
define("LANHELP_7", "Verde");
define("LANHELP_8", "Lilás");
define("LANHELP_9", "Verde azeitona");
define("LANHELP_10", "Laranja");
define("LANHELP_11", "Vermelho");
define("LANHELP_12", "Violeta");
define("LANHELP_13", "Branco");
define("LANHELP_14", "Amarelo");
define("LANHELP_15", "Minúsculo");
define("LANHELP_16", "Pequeno");
define("LANHELP_17", "Normal");
define("LANHELP_18", "Grande");
define("LANHELP_19", "Maior");
define("LANHELP_20", "Gigante");
define("LANHELP_21", "Clique para abrir o diálogo das cores ...");
define("LANHELP_22", "Clique para abrir o diálogo dos tamanhos ...");
define("LANHELP_23", "Inserir link: [link]http://meusitio.pt[/link] ou [link=http://seusitio.pt]Visitem o meu sitio[/link]");
define("LANHELP_24", "Texto negrito: [b]Este texto aparecerá em negrito[/b]", "font-weight:bold; width: 20px");
define("LANHELP_25", "Texto itálico: [i]Este texto aparecerá em itálico[/i]", "font-style:italic; width: 20px");
define("LANHELP_26", "texto sublinhado: [u]Este texto aparecerá sublinhado[/u]", "text-decoration: underline; width: 20px");
define("LANHELP_27", "Inserir imagem: [img]minhaimagem.jpg[/img]");
define("LANHELP_28", "Alinhar ao centro: [center]Este texto será alinhado ao centro[/center]");
define("LANHELP_29", "Alinhar à esquerda: [left]Este texto será alinhado à esquerda[/left]");
define("LANHELP_30", "Alinhar à direita: [right]Este texto será alinhado à direita[/right]");
define("LANHELP_31", "Citar texto: [blockquote]Este texto aparecerá como citação (destacado)[/blockquote]");
define("LANHELP_32", "Código - texto formatado: [code]\$foo = bah;[/code]");
define("LANHELP_33", "HTML - remove quebras de linha do texto: [html]<table><tr><td>etc[/html]");
define("LANHELP_34", "[newpage] ou [newpage=título] Insere uma etiqueta de newpage, separando o artigo em uma ou mais páginas");
define("LANHELP_35", "URL da hiperligação");
define("LANHELP_36", "Desordenado: [list]line1*line2*line3[/list] Ordenado: [list=type]line1*line2*line3[/list]");
define("LANHELP_37", "Inserir a imagem na directoria e107_images/newspost_images/");
define("LANHELP_38", "O link completo da imagem será gerado");
define("LANHELP_39", "Inserir o link para descarga a partir dos arquivos já existentes");
define("LANHELP_40", "Não existem actualmente descargas");
define("LANHELP_41", "Tamanho da letra...");
define("LANHELP_42", "Seleccionar a imagem...");
define("LANHELP_43", "Seleccione o arquivo para fazer download...");
define("LANHELP_44", "Clique para abrir/fechar diálogo das emoções ...");
define("LANHELP_45", "Inserir imagem a partir da directoria:");
define("LANHELP_46", "* Nenhum arquivo encontrado em:");
define("LANHELP_47", "Inserir flash: [flash=largura,altura]http://www.example.com/file.swf[/flash]");
define("LANHELP_48", "YouTube: [youtube=tiny|small|medium|big|huge|width,height]6kYjxJmk0wc[/youtube]");
define("LANHELP_49", "Texto justificado: [justify]Este texto aparecerá justificado[/justify]");


?>