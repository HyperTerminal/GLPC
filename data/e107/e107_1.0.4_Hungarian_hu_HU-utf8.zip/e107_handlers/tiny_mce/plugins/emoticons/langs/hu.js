// HU lang variables

tinyMCE.addI18n('hu.emoticons',{
	desc : 'Emotikonok beillesztése'
});