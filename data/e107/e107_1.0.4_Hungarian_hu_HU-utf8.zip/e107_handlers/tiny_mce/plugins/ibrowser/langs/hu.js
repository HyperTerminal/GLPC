// HU lang variables
tinyMCE.addI18n('hu.ibrowser',{
	desc : 'Kép tallózása'
});