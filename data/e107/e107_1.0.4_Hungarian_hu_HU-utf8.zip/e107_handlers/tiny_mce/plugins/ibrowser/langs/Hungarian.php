<?php

$lang_ibrowser_title= 'Kép beillesztése / módosítása';
$lang_ibrowser_desc= 'Kép beillesztése / módosítása';
$lang_ibrowser_library= 'Könyvtár';
$lang_ibrowser_preview= 'Elõnézet';
$lang_ibrowser_img_sel= 'Kép kiválasztás';
$lang_ibrowser_img_info= 'Kép információ';
$lang_ibrowser_img_upload= 'Kép feltöltése';
$lang_ibrowser_images= 'Kép';
$lang_ibrowser_src= 'Forrás';
$lang_ibrowser_alt= 'Leírás';
$lang_ibrowser_size= 'Méret';
$lang_ibrowser_align= 'Szöveg körbefuttatása';
$lang_ibrowser_height= 'Magasság';
$lang_ibrowser_width= 'Szélesség';
$lang_ibrowser_reset= 'Újraméretezés';
$lang_ibrowser_border= 'Szegély';
$lang_ibrowser_hspace= 'HSpace';
$lang_ibrowser_vspace= 'VSpace';
$lang_ibrowser_select= 'Mentés';
$lang_ibrowser_delete= 'Törlés';
$lang_ibrowser_cancel= 'Kilépés';
$lang_ibrowser_uploadtxt= 'File';
$lang_ibrowser_uploadbt= 'Feltöltés';
$lang_ibrowser_marginl = 'Margin-Left';
$lang_ibrowser_marginr = 'Margin-Right';
$lang_ibrowser_margint = 'Margin-Top';
$lang_ibrowser_marginb = 'Margin-Bottom';
$lang_insert_image_align_default = "Alapértelmezett";
$lang_insert_image_align_left = "Balra";
$lang_insert_image_align_right = "Jobbra";

// error messages
$lang_ibrowser_error= 'Hiba';
$lang_ibrowser_errornoimg= 'Válassz egy képet';
$lang_ibrowser_errornodir= 'A könyvtár fizikailag nem létezik';
$lang_ibrowser_errorupload= 'Hiba a file feltöltés során.\nPróbálkozz újra';
$lang_ibrowser_errortype= 'Érvénytelen kép file típus';
$lang_ibrowser_errordelete= 'Törlés sikertelen';
$lang_ibrowser_confirmdelete= 'Katt az OK-ra a kép törléséhez!';
$lang_ibrowser_error_width_nan= 'Szélesség nem egy szám!';
$lang_ibrowser_error_height_nan= 'Magasság nem egy szám!';
$lang_ibrowser_error_border_nan= 'Szegély nem egy szám!';
$lang_ibrowser_error_hspace_nan= 'Vízszintes szünet nem egy szám!';
$lang_ibrowser_error_vspace_nan= 'Függõleges szünet nem egy szám!';

?>