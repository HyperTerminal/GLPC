<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_rate.php $
|     $Revision: 11678 $
|     $Id: lan_rate.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("RATELAN_0", "szavazat");
define("RATELAN_1", "szavazat");
define("RATELAN_2", "Hogyan értékeled?");
define("RATELAN_3", "Köszönjük szavazatodat!");
define("RATELAN_4", "nincs értékelés");
define("RATELAN_5", "Értékelés");

?>