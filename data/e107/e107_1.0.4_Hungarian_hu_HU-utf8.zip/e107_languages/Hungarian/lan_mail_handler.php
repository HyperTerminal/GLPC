<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_mail_handler.php $
|     $Revision: 11678 $
|     $Id: lan_mail_handler.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANMAILH_1", "Készítette az e107 webportál rendszer");
define("LANMAILH_2", "Ez egy többrészes üzenet, MIME formátummal.");
define("LANMAILH_3", " helytelen formátumú.");
define("LANMAILH_4", "A szerver a címet visszautasította!");
define("LANMAILH_5", "A szerver nem válaszolt");
define("LANMAILH_6", "Nincs ilyen e-mail szerver.");
define("LANMAILH_7", " úgy tűnik rendben van.");


?>