<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_banner.php $
|     $Revision: 11678 $
|     $Id: lan_banner.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Reklámcsíkok");

define("BANNERLAN_16", "Felhasználónév: ");
define("BANNERLAN_17", "Jelszó: ");
define("BANNERLAN_18", "Folytatás");
define("BANNERLAN_19", "A folytatáshoz add meg az ügyfél felhasználónevét és jelszavát");
define("BANNERLAN_20", "Sajnos ezen adatok nem találhatóak meg az adatbázisban. Keresd meg az oldal üzemeltetőjét a részletekkel.");
define("BANNERLAN_21", "Reklám statisztikák");
define("BANNERLAN_22", "Ügyfél");
define("BANNERLAN_23", "ID");
define("BANNERLAN_24", "Kattintások");
define("BANNERLAN_25", "Kattintás %");
define("BANNERLAN_26", "Megjelenítések");
define("BANNERLAN_27", "Megrendelt megjelenítés");
define("BANNERLAN_28", "Hátralévő megjelenítés");
define("BANNERLAN_29", "Nincs reklámcsík");
define("BANNERLAN_30", "Korlátlan");
define("BANNERLAN_31", "Nem alkalmazható");
define("BANNERLAN_32", "Igen");
define("BANNERLAN_33", "Nem");
define("BANNERLAN_34", "Befejezés");
define("BANNERLAN_35", "Kattintások IP címei");
define("BANNERLAN_36", "Aktív:");
define("BANNERLAN_37", "Kezdési időpont:");
define("BANNERLAN_38", "Hiba");

?>