<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_sitedown.php $
|     $Revision: 11678 $
|     $Id: lan_sitedown.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Az oldal átmenetileg zárva");
define("LAN_SITEDOWN_00", "átmenetileg zárva");
define("LAN_SITEDOWN_01", "Karbantartás miatt az oldalt átmenetileg lezártuk. Nem tart sokáig - látogass vissza hamarosan, elnézést kérünk a kellemetlenségért.");
?>