<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_userclass.php $
|     $Revision: 11678 $
|     $Id: lan_userclass.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UC_LAN_0", "Mindenki (Publikus)");
define("UC_LAN_1", "Csak Vendégek");
define("UC_LAN_2", "Senki (inaktív)");
define("UC_LAN_3", "Csak tagok");
define("UC_LAN_4", "Csak olvasási jog");
define("UC_LAN_5", "Csak adminok");
define("UC_LAN_6", "Csak Főadmin");

define('UC_LAN_9','Új felhasználók');
define('UC_LAN_10', 'Kereső botok');

?>