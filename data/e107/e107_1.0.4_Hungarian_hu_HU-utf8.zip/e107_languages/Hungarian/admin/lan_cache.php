<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_cache.php $
|     $Revision: 11678 $
|     $Id: lan_cache.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CACLAN_1", "Cache rendszer állapot");
define("CACLAN_2", "Cache állapot kiválasztása");
define("CACLAN_3", "Cache rendszer");
define("CACLAN_4", "Cache állapot kiválasztva");
define("CACLAN_5", "Cache ürítése");
define("CACLAN_6", "Cache kiürítve");

define("CACLAN_7", "Cache kikapcsolva");
// define("CACLAN_8", "Cache adat mentése a MySQL adatbázisba");
define("CACLAN_9", "Cache tartalmának mentése fájlba");
define("CACLAN_10", "A cache könyvtár nem írható. Ellenőrizd, hogy a szerver megfelelő jogosultságokkal rendelkezik az e107_files/cache mappán. Ha nem, adj CHMOD 0777-et a mappára");
?>