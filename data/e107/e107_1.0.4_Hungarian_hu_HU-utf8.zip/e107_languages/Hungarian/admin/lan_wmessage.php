<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_wmessage.php $
|     $Revision: 11678 $
|     $Id: lan_wmessage.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
//define("WMGLAN_1", "Üzenet a vendégek számára");
//define("WMGLAN_2", "Üzenet a tagok számára");
//define("WMGLAN_3", "Üzenet az adminisztrátorok számára");
//define("WMGLAN_4", "Üzenet beállítása");
//define("WMGLAN_5", "Üdvözlő üzenet beállítása");
//define("WMGLAN_6", "Aktiválás?");
//define("WMGLAN_7", "Üdvözlő üzenet beállítások elmentve");

define("WMLAN_00","Üdvözlő üzenetek");
define("WMLAN_01","Új üzenet létrehozása");
define("WMLAN_02","Üzenet");
define("WMLAN_03","Láthatóság");
define("WMLAN_04","Üzenet szövege");

define("WMLAN_05","Keret");
define("WMLAN_06","Ha bejelölt, az üzenet theme táblában (keretben) fog megjelenni");
define("WMLAN_07","Az alaprendszer felülírása a {WMESSAGE} shortcode használatához:");
//define("WMLAN_08","Beállítások");

define("WMLAN_09","Nincsenek üdvözlő üzenetek");
define("WMLAN_10","Üzenet Fejléc");   

?>