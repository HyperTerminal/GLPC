<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_userclass.php $
|     $Revision: 11678 $
|     $Id: lan_userclass.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("UCSLAN_1", "Értesítés küldése");
define("UCSLAN_2", "Jogosultságok frissítése");
define("UCSLAN_3", "Kedves");
define("UCSLAN_4", "Jogosultságaid frissítve a következő oldalon:");
define("UCSLAN_5", "Mostantól elérheted a következő részleg(ek)et:");
define("UCSLAN_6", "Csoport beállítása felhasználóra");
define("UCSLAN_7", "Csoport beállítása");
define("UCSLAN_8", "Felhasználó értesítése");
define("UCSLAN_9", "Csoportok frissítve");
define("UCSLAN_10", "Üdvözlettel");
define('UCSLAN_12', 'Csak tagság joggal');

?>