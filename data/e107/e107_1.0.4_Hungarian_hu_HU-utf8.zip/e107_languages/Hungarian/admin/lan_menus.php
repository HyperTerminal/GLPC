<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_menus.php $
|     $Revision: 11678 $
|     $Id: lan_menus.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MENLAN_1", "Mindenki által látható");
define("MENLAN_2", "Csak a tagok által látható");
define("MENLAN_3", "Csak az adminok által látható");
define("MENLAN_4", "Csak a(z)");
//define("MENLAN_5", "csoportban lévő felhasználók számára látható");
define("MENLAN_6", "Mehet");
define("MENLAN_7", "Csoport beállítása");
define("MENLAN_8", "Csoport frissítve");
define("MENLAN_9", "Új saját menü telepítve");
define("MENLAN_10", "Új menü telepítve");
define("MENLAN_11", "Menü eltávolítva");
define("MENLAN_12", "Menü aktiválása - válaszd ki hol legyen");
define("MENLAN_13", "Aktiválás: Terület");
define("MENLAN_14", "Terület");
define("MENLAN_15", "Kikapcsolás");
define("MENLAN_16", "Beállítások");
define("MENLAN_17", "Fel");
define("MENLAN_18", "Le");
define("MENLAN_19", "Mozgat: Terület");
define("MENLAN_20", "Elérhetőség");

//define("MENLAN_21", "Csak a Vendégek számára látható");
define("MENLAN_22", "Kikapcsolt menük");

define("MENLAN_23", "Mozgatás alulra");
define("MENLAN_24", "Mozgatás felülre");
define("MENLAN_25", "Funkció ...");

define("MENLAN_26", "Ez a menü csak a következő oldalakon lesz <strong>látható</strong>");
define("MENLAN_27", "Ez a menü csak a következő oldalakon lesz <strong>rejtett</strong>");
define("MENLAN_28", "Minden sorba egy oldalt adj meg, a szükséges elérési úttal. Ha szükséges az elérési utat nagyon pontosan megadni, akkor használj egy ! jelet az oldal neve végén. <br />Például: <strong>page.php?1!</strong>");

define("MENLAN_29", "Elrendezés kiválasztása");
define("MENLAN_30", "Az egyéni elrendezés menüterületeinek és azok pozícióinak megtekintéséhez válassz egy egyéni elrendezést:");
define("MENLAN_31", "Alapértelmezett elrendezés");
define("MENLAN_32", "Newsheader elrendezés");
define("MENLAN_33", "Egyéni elrendezés");
define("MENLAN_34", "Beágyazott");
define("MENLAN_35", "Menük beállítása");
define("MENLAN_36", "Válaszd ki az aktiválandó menü(ke)t,");
define("MENLAN_37", "majd válaszd ki, hol legyenek aktívak.");
define("MENLAN_38", "Tartsd lenyomva a CTRL -t több menü kiválasztásához.");


?>