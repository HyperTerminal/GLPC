<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_admin_log.php $
|     $Revision: 11678 $
|     $Id: lan_admin_log.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Admin Napló (Log)");
define("LAN_ADMINLOG_1", "Dátum");
define("LAN_ADMINLOG_2", "Cím");
define("LAN_ADMINLOG_3", "Leírás");
define("LAN_ADMINLOG_4", "Felhasználó IP");
define("LAN_ADMINLOG_5", "Felhasználó ID");
define("LAN_ADMINLOG_6", "Tájékoztató Ikon");
define("LAN_ADMINLOG_7", "Tájékoztató Üzenet");
define("LAN_ADMINLOG_8", "Figyelmeztető Ikon");
define("LAN_ADMINLOG_9", "Figyelmeztető Üzenet");
define("LAN_ADMINLOG_10", "Riasztás Ikon");
define("LAN_ADMINLOG_11", "Riasztás Üzenet");
define("LAN_ADMINLOG_12", "Végzetes hiba Ikon");
define("LAN_ADMINLOG_13", "Végzetes hiba Üzenet");

?>