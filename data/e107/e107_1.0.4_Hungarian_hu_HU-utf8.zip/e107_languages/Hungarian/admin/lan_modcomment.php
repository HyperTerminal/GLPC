<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_modcomment.php $
|     $Revision: 11678 $
|     $Id: lan_modcomment.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MDCLAN_1", "Moderálva");
define("MDCLAN_2", "Nincsen hozzászólás");
define("MDCLAN_3", "Tag");
define("MDCLAN_4", "Vendég");
define("MDCLAN_5", "Engedélyezés");
define("MDCLAN_6", "Tiltás");

define("MDCLAN_7", "jóváhagy");
define("MDCLAN_8", "Hozzászólások moderálása");
define("MDCLAN_9", "Figyelem! Szülő hozzászólás törlése esetén az összes válasz is törlődik!");

define("MDCLAN_10", "beállítások");
define("MDCLAN_11", "hozzászólás");
define("MDCLAN_12", "hozzászólás");
define("MDCLAN_13", "kikapcsolva");
define("MDCLAN_14", "hozzászólások kikapcsolása");
define("MDCLAN_15", "engedélyezés");
define("MDCLAN_16", "lezárva");
define("MDCLAN_17", "Jelenleg nincsenek jóváhagyásra váró hozzászólások");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");

?>