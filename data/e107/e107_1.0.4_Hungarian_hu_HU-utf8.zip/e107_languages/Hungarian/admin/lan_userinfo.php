<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_userinfo.php $
|     $Revision: 11678 $
|     $Id: lan_userinfo.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("USFLAN_1", "IP cím meghatározatlan - nem áll rendelkezésre információ");
//define("USFLAN_2", "Hiba");
define("USFLAN_3", "Ezen IP címről küldött üzenetek");
define("USFLAN_4", "Kiszolgáló");
define("USFLAN_5", "IP cím blokkolása");
define("USFLAN_6", "Felhasználó ID");
define("USFLAN_7", "Felhasználó információ");

?>