<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_language.php $
|     $Revision: 11842 $
|     $Id: lan_language.php 11842 2010-10-04 07:43:15Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANG_LAN_00","nem lett létrehozva. (már létezik)");
define("LANG_LAN_01","törölve (ha volt) és létrehozva.");
define("LANG_LAN_02","nem lett törölve");
define("LANG_LAN_03","Táblák");

define("LANG_LAN_05","Nincs telepítve");
define("LANG_LAN_06", "Táblák létrehozása");
define("LANG_LAN_07", "Meglévő táblák eldobása?");
define("LANG_LAN_08", "Meglévő táblák cseréje (az adatok el fognak veszni).");
define("LANG_LAN_10", "Törlés megerősítése");
define("LANG_LAN_11", "A fenti ellenőrizetlen táblák törlése (ha léteznek).");
define("LANG_LAN_12", "Többnyelvű táblák engedélyezése");
define("LANG_LAN_13", "Többnyelvűség beállításai");
define("LANG_LAN_14", "Az oldal alapértelmezett nyelve");
define("LANG_LAN_15", "Jelöld be az adatok másolásához az alapértelmezett nyelvből. (hasznos a linkeknél, hírkategóriáknál stb.) ");
define("LANG_LAN_16", "Több-nyelvű Adatbázis Használat"); 
define("LANG_LAN_17", "Alapértelmezett nyelv - További táblák nem szükségesek.");
define("LANG_LAN_18", "Használd az elhelyezett Subdomain-t a nyelv kiválasztásához:");
define("LANG_LAN_19", "Pl.: fr.mydomain.com a francia nyelv kiválasztásához.");
define("LANG_LAN_20", "Egy domain beírás / sor. Pl.: mydomain.com stb. vagy hagyd üresen a tiltáshoz.");

define("LANG_LAN_21", "Nyelvi eszközök");

define("LANG_LAN_23", "Nyelvi csomag létrehozása (zip)");
define("LANG_LAN_24", "Létrehozás");

define("LANG_LAN_AGR", "Megjegyzés: Ennek az eszköznek a használatával beleegyezel, hogy a nyelvi csmagot az e107 közösség felhasználja.");
define("LANG_LAN_EML", "Ide küld a nyelvi csomagot:");

define("LANG_LAN_25", "Ellenőrizd, hogy a CORE_LC és a CORE_LC2 tartalmazzák-e az értékeket ebben [lcpath] és próbáld újra.");
define("LANG_LAN_26", "Nézd meg, hogy az alapértelmezett mappaneveket használod-e az e107_config.php file-ben (pl.: 'e107_languages/', 'e107_plugins/' etc.) és próbáld újra.");
define("LANG_LAN_27", "Ellenőrizd a nyelvi file-ket ('Verify') majd próbáld újra.");
define("LANG_LAN_28", "Jelöld be, ha Te egy [e107 certified translator] vagy.");

define("LANG_LAN_29", "Először javítsd ki a hibákat mielőtt közreadod a nyelvi csomagot.");
define("LANG_LAN_30", "Kiadás dátuma");
define("LANG_LAN_31", "Kompabilitás");
define("LANG_LAN_32", "Telepített nyelvek");
define("LANG_LAN_33", "Csak a megjelenitéskor történt hibák ellenőrzése");
define("LANG_LAN_34", "Kérjük, ellenőrizze és javítsa ki a fennmaradó [x] hibát (kat), mielőtt létrehoz egy nyelvi csomagot.");

?>