<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_lancheck.php $
|     $Revision: 11756 $
|     $Id: lan_lancheck.php 11756 2010-09-06 23:31:47Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Válassz nyelvet az ellenőrzéshez");
define("LAN_CHECK_2", "Ellenőrzés indítása");
define("LAN_CHECK_3", "Ellenőrzés");
define("LAN_CHECK_4", "Hiányzó fájl!");
define("LAN_CHECK_5", "Hiányzó kifejezés!");

define("LAN_CHECK_7", "kifejezés");

define("LAN_CHECK_8", "A fájl hiányzik...");
define("LAN_CHECK_9", " hiányzó fájl...");
define("LAN_CHECK_10", "Kritikus hiba: ");
define("LAN_CHECK_11", "Nincs hiányzó fájl!");
define("LAN_CHECK_12", "Egy fájl hibás...");
define("LAN_CHECK_13", " fájl hibás...");
define("LAN_CHECK_14", "Minden fájl jó!");

define("LAN_CHECK_15", "Illegális karakterek a '&lt;?php' előtt vagy a '?&gt;' után (pl. Szóköz)");
define("LAN_CHECK_16", "Eredeti Fájl");
define("LAN_CHECK_17", "Egy írási probléma keletkezett a fájl mentése során.");
define("LAN_CHECK_18", "Szabvány formában a nyelvi fájl nem engedélyezett ehhez a plugin-hoz/theme-hez.");
define("LAN_CHECK_19", "Nem-UTF-8 karakterek!");
define("LAN_CHECK_20", "Nyelvi csomag létrehozása");
define("LAN_CHECK_21", "Ismételt ellenőrzés");
define("LAN_CHECK_22", "Theme");
define("LAN_CHECK_23", "Talált hibák");
define("LAN_CHECK_24", "Összegzés");
define("LAN_CHECK_25", "Theme-k");
define("LAN_CHECK_26", "Fájl");

?>