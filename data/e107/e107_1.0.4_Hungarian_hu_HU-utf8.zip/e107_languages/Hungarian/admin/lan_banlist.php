<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_banlist.php $
|     $Revision: 11678 $
|     $Id: lan_banlist.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("BANLAN_1", "Kitiltás kikapcsolva.");
define("BANLAN_2", "Nincs kitiltás.");
define("BANLAN_3", "Érvényben lévő kitiltások");
define("BANLAN_4", "Kitiltás törlése");
define("BANLAN_5", "Add meg az IP címet, az e-mail címet vagy a host-ot");
define("BANLAN_7", "Indoklás");
define("BANLAN_8", "Felhasználó kitiltása");
define("BANLAN_9", "Felhasználók kitiltása Email, IP vagy kiszolgálócím alapján");
define("BANLAN_10", "IP / E-mail cím / Indok");
define("BANLAN_11", "Automatikus-Kitiltás: Több, mint 10 hibás bejelentkezési kisérlet");
define("BANLAN_12", "Megjegyzés: A DNS megváltoztatása jelenleg letiltva, a host alapján történő kitiltáshoz engedélyezni kell. Az IP és email alapján történő kitiltás még normálisan mûkődik.");
define("BANLAN_13", "Megjegyzés: Egy felhasználó kitiltásához a felhasználónév alapján, lépj a felhasználók admin felületre: ");
define('BANLAN_78','Hit count exceeded (--HITS-- lekérdezések az engedélyezett időn belül)');

?>