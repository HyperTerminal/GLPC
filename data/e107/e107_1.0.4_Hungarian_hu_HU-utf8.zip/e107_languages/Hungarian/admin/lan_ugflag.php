<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_ugflag.php $
|     $Revision: 11678 $
|     $Id: lan_ugflag.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Karbantartási beállítások frissítve");
define("UGFLAN_2", "Karbantartás");
define("UGFLAN_3", "Beállítások mentése");
define("UGFLAN_4", "Karbantartási beállítások");

define("UGFLAN_5", "Karbantartási üzenet");
define("UGFLAN_6", "Hagyd üresen az alapértelmezett üzenet megjelenítéséhez");

define('UGFLAN_8', 'Hozzáférés az oldalhoz csak az Admin(ok) részére');
define('UGFLAN_9', 'Hozzáférés az oldalhoz csak a Fő-Admin(ok) részére');

?>