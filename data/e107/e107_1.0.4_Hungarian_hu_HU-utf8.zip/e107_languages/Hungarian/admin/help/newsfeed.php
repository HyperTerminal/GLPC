<?php
$caption = "Hírforrások súgó";
$text = "Átveheted más weboldalak backend RSS hírforrásait, és megjelenítheted őket a saját oldaladon.<br />Add meg a teljes URL-t a backend-hez (pl. http://e107.org/e107_files/backend/news.xml). Jelöld be a box-okat, a hírforrások menüben megjelenítéshez. Be- és kikapcsolhatod a backend-et, ha az oldallal probléma van.<br /><br />A hírforrások megjelenítéséhez a weboldaladon, aktiváld a headlines_menu-t a Menük oldalon.";

$ns -> tablerender($caption, $text);
?>
