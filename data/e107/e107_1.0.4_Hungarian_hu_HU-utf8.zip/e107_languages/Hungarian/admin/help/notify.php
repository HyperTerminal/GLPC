<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/help/notify.php $
|     $Revision: 11678 $
|     $Id: notify.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "A rendszer E-mail értesítést küld, ha valamilyen e107 esemény történik. <br /> <br />
Például, ha egy 'IP tiltás flood miatt' biztonsági esemény történik a beállított felhasználói csoportnak, vagy 'Fő Adminnak' e-mail értesítést 
küld a rendszer.<br /><br />
Egy másik példa: a 'Hírt beküldte' eseményhez beállítjuk hogy egy felhasználói csoport, vagy a 'Fő Admin' e-mail 
értesítést kap az eseményről<br /><br />
Ha szeretné hogy az e-mail értesítés egy másik e-mail címre érkezzen mint a választható csoportok címei - válassza ki az 'E-mail' opciót, 
és írja be a megfelelő e-mail címet a mezőbe.";

$ns -> tablerender("Értesítés Súgó", $text);
?>