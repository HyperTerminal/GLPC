<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/help/search.php $
|     $Revision: 11678 $
|     $Id: search.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Ha a MySQL szerver verziója támogatja, akkor beállíthatod 
a MySQL rendezési módszerét, amely gyorsabb, mint a PHP rendezési módszere. Nézd meg a beállításokat.<br /><br />
Ha az oldalad képírásos nyelvet használ, úgy mint Kínai vagy Japán, akkor mindenképpen 
PHP rendezési módszert kell használni és ki kell kapcsolnod az egész szavak keresését.";
$ns -> tablerender("Keresés - Súgó", $text);
?>