<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/help/download.php $
|     $Revision: 12132 $
|     $Id: download.php 12132 2011-04-12 21:25:31Z e107steved $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Töltsd fel a fájlokat a(z) ".e_DOWNLOAD." könyvtárba, a képeket a(z) ".e_FILE."downloadimages könyvtárba és a thumbnail képeket a(z) ".e_FILE."downloadthumbs könyvtárba.
<br /><br />
Letöltés felvételéhez, először hozz létre egy kezdőt, majd ez alatt készíts egy kategóriát, és ezek után tudsz felvinni letöltést.";
$ns -> tablerender("Letöltések súgó", $text);
?>