<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
|     Copyright (C) 2008-2010 e107 Inc (e107.org)
|
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/English/admin/help/ugflag.php $
|     $Revision: 11678 $
|     $Id: ugflag.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "A webhely karbantartásakor, vagy e107 frissítések során előfordulhat, hogy az oldalt ideiglenesen át kell kapcsolni karbantartás üzemmódra. Ebben a módban a látogatók át lesznek irányítva egy információs oldalra, ahol értesülnek arról, hogy a webhely karbantartás alatt áll. Ebben az üzemmódban a bejelentkezés csak az adminisztrátoroknak lehetséges az e107_admin/admin.php oldalon. A karbantartás kikapcsolásakor az oldal visszatér a normál működéséhez.";

$ns -> tablerender("Karbantartás Súgó", $text);
?>
