<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_db_verify.php $
|     $Revision: 11678 $
|     $Id: lan_db_verify.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "SQL adatfile beolvasása sikertelen<br /><br />Ellenőrizd, hogy a <b>core_sql.php</b> fájl megtalálható az <b>/admin/sql</b> könyvtárban");
define("DBLAN_2", "Összes ellenőrzése");

define("DBLAN_4", "Tábla");
define("DBLAN_5", "Mező");
define("DBLAN_6", "Állapot");
define("DBLAN_7", "Megjegyzések");
define("DBLAN_8", "Ellentmondás");
define("DBLAN_9", "Jelenleg");
define("DBLAN_10", "kéne legyen");
define("DBLAN_11", "Hiányzó mező");
define("DBLAN_12", "Extra mező!");
define("DBLAN_13", "Hiányzó tábla!");
define("DBLAN_14", "Válaszd ki az ellenőrizendő táblá(ka)t");
define("DBLAN_15", "Ellenőrzés kezdete");
define("DBLAN_16", "Adatbázis ellenőrzés");
define("DBLAN_17", "Vissza");
define("DBLAN_18", "táblák");
define("DBLAN_19", "Javítás megkísérlése");
define("DBLAN_20", "Javítási kísérletek eredményei");
define("DBLAN_21", "Kijelöltek javítása");
define("DBLAN_22", " nem olvasható");
?>