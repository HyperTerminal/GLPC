<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_meta.php $
|     $Revision: 11678 $
|     $Id: lan_meta.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta tag-ek frissítve");
define("METLAN_2", "Meta tag-ek");
define("METLAN_3", "Beállítások mentése");
define("METLAN_4", "Frissítve");
define("METLAN_5", "Az oldal leírását");
define("METLAN_6", "Add, meg, a, kulcsszavak, listáját, kulcsszó, vessző, szóköz, formában");
define("METLAN_7", "Copyright információk");
define("METLAN_8", "Meta Tag-ek");

define("METLAN_9", "Leírás");
define("METLAN_10", "Kulcsszavak");
define("METLAN_11", "Szerzői jog");
define("METLAN_12", "Használd a Hírek címét és az összegzést meta-leírásként a hírek oldalon.");
define("METLAN_13", "Szerző");

?>