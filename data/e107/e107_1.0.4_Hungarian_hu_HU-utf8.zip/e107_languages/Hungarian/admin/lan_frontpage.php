<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_frontpage.php $
|     $Revision: 11678 $
|     $Id: lan_frontpage.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("FRTLAN_1", "Kezdőlap beállításai frissítve");
define("FRTLAN_2", "Megjelenítendő");
define("FRTLAN_6", "Linkek");
//define("FRTLAN_7", "Tartalom oldal");
define("FRTLAN_12", "Beállítások mentése");
define("FRTLAN_13", "Kezdőlap beállításai");
define("FRTLAN_15", "Egyéb (írd be az url-t):");
define("FRTLAN_16", "hiba: nincs tartalom főkategória kiválasztva");
define("FRTLAN_17", "hiba: nincs tartalom alkategória kiválasztva");
define("FRTLAN_18", "hiba: nincs tartalom kiválasztva");
define("FRTLAN_19", "tartalom főkategória");
define("FRTLAN_20", "tartalom alkategória");
define("FRTLAN_21", "tartalom");
define("FRTLAN_22", "Egyéni oldal");
// define("FRTLAN_23", "");
// define("FRTLAN_24", "");
// define("FRTLAN_25", "");

define("FRTLAN_26", "Mindenki");
define("FRTLAN_27", "Vendégek");
define("FRTLAN_28", "Tagok");
define("FRTLAN_29", "Adminok");
define("FRTLAN_31", "Mindenki (publikus)");
define("FRTLAN_32", "Felhasználói csoport");
define("FRTLAN_33", "Érvényes beállítások");
define("FRTLAN_34", "Oldal");

?>