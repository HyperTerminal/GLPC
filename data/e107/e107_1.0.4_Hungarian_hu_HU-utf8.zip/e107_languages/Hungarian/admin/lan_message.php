<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_message.php $
|     $Revision: 11678 $
|     $Id: lan_message.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Fogadott üzenet");
define("MESSLAN_2", "Üzenet törlése");
define("MESSLAN_3", "Üzenet törölve.");
define("MESSLAN_4", "Összes üzenet törlése");
define("MESSLAN_5", "Megerősítés");
define("MESSLAN_6", "Összes üzenet törölve.");
define("MESSLAN_7", "Nincs üzenet.");
define("MESSLAN_8", "Üzenet típusa");
define("MESSLAN_9", "Küldés ideje");

define("MESSLAN_10", "Küldő");
define("MESSLAN_11", "megnyitás új ablakban");
define("MESSLAN_12", "Üzenet");
define("MESSLAN_13", "Link");


?>