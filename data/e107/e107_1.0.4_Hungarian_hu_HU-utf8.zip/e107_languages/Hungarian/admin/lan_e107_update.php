<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_e107_update.php $
|     $Revision: 11678 $
|     $Id: lan_e107_update.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_UPDATE_2", "Műveletek");
define("LAN_UPDATE_3", "Nem szükséges");

define("LAN_UPDATE_5", "Van(nak) frissítés(ek)");
define("LAN_UPDATE_7", "Futtatás");
define("LAN_UPDATE_8", "Frissítés:");
define("LAN_UPDATE_9", " -> ");
define("LAN_UPDATE_10", "Elérhető frissítések");
define("LAN_UPDATE_11", ".617 -> .7 frissítés folytatása");
define("LAN_UPDATE_12", "Az egyik táblád duplikált bejegyzéseket tartalmaz.");


?>