<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/admin/lan_db.php $
|     $Revision: 11678 $
|     $Id: lan_db.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Alapbeállítások elmentve az adatbázisban");
define("DBLAN_2", "Adatbázis lementése");
define("DBLAN_3", "Adatbázis lementése");
define("DBLAN_4", "Adatbázis érvényességének ellenőrzése");
define("DBLAN_5", "Érvényesség ellenőrzése");
define("DBLAN_6", "Adatbázis optimalizálása");
define("DBLAN_7", "Adatbázis optimalizálása");
define("DBLAN_8", "Alapbeállítások lementése");
define("DBLAN_9", "Alapbeállítások lementése");
define("DBLAN_10", "Adatbázis eszközök");
define("DBLAN_11", "mySQL adatbázis");
define("DBLAN_12", "Optimalizálva");
define("DBLAN_13", "Vissza");
define("DBLAN_14", "Kész");
define("DBLAN_15", "Adatbázis frissítések keresése");
define("DBLAN_16", "Frissítések keresése");
define("DBLAN_17", "Beállított Név");
define("DBLAN_18", "Beállított Érték");
define("DBLAN_19", "Katt a gombra a tulajdonságszerkesztő megnyitásához (csak haladók részére)");
define("DBLAN_20", "Tulajdonságszerkesztő");
define("DBLAN_21", "Bejelöltek törlése");
define("DBLAN_22", "Plugin: Megtekintés és Vizsgálat");
define("DBLAN_23", "Vizsgálat kész");
define("DBLAN_24", "Név");
define("DBLAN_25", "Könyvtár");
define("DBLAN_26", "Hozzáadott tartalom");
define("DBLAN_27", "Telepítve");
define("DBLAN_28", "Katt a gombra a plugin vizsgálatához a változtatás részére");
define("DBLAN_29", "Plugin könyvtár vizsgálata");
define("DBLAN_30", " (Ha egy bővítmény egy hibát mutat, ellenőrizd a PHP kezdő/záró tag-eken kívül eső karaktereket)");
define("DBLAN_31", "Megvizsgálva");
define("DBLAN_32", "Hiba");
define("DBLAN_33", "Elérhetetlen");
define("DBLAN_34", "Nem ellenörzött");
define("DBLAN_35", "Katt a gombra a felhasználó tábla ellenőrzéséhez");
define("DBLAN_36", "Felhasználó tábla ellenőrzése");


?>