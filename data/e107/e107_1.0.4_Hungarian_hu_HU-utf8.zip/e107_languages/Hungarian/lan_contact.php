<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_contact.php $
|     $Revision: 11678 $
|     $Id: lan_contact.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define('PAGE_NAME',     'Kapcsolat');

define("LANCONTACT_01", "Kapcsolat részletei");
define("LANCONTACT_02", "Kapcsolat");
define("LANCONTACT_03", "Írd be a neved:");
define("LANCONTACT_04", "E-mail cím:");
define("LANCONTACT_05", "Üzenet tárgya:");
define("LANCONTACT_06", "Írd be az üzenetet:");
define("LANCONTACT_07", "Email üzenet másolatának elküldése a saját címre ");
define("LANCONTACT_08", "Küldés");
define("LANCONTACT_09", "Üzeneted elküldve.");
define("LANCONTACT_10", "Probléma merült fel az üzenet elküldése folyamán.");
define("LANCONTACT_11", "Az email címed érvénytelen.\\nEllenőrizd, majd próbáld újra.");
define("LANCONTACT_12", "Az üzeneted nagyon rövid.");
define("LANCONTACT_13", "Add meg az üzenet tárgyát.");

define("LANCONTACT_14", "Üzenet küldése a következőnek:");
define("LANCONTACT_15", "Érvénytelen kódot írtál be");
define("LANCONTACT_16", "Kód beírása");





?>