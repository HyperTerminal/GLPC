<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_prefs.php $
|     $Revision: 11678 $
|     $Id: lan_prefs.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_PREF_1", "e107 alapú weboldal");
define("LAN_PREF_2", "e107 portál rendszer");
define("LAN_PREF_3", "Ez az oldal <a href=&quot;http://e107.org/&quot; rel=&quot;external&quot;>e107 portál</a> rendszert használ, és a <a href=&quot;http://www.gnu.org/&quot; rel=&quot;external&quot;>GNU</a> GPL licensz alatt lett kiadva</a>.");
define("LAN_PREF_4", "cenzúrázva");
define("LAN_PREF_5", "Fórumok");

?>