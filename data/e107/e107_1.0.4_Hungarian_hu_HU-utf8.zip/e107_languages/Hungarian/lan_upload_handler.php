<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_upload_handler.php $
|     $Revision: 11678 $
|     $Id: lan_upload_handler.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LANUPLOAD_1", "A fájltípus");
define("LANUPLOAD_2", "nem engedélyezett, törölve lett.");
define("LANUPLOAD_3", "Sikeresen feltöltve");
define("LANUPLOAD_4", "A célkönyvtár nem létezik, vagy nem írható.");
define("LANUPLOAD_5", "A file túllépte a php.ini -ben meghatározott maximális méretet.");
define("LANUPLOAD_6", "A file túllépte a HTML formulában meghatározott maximális méretet.");
define("LANUPLOAD_7", "A file csak részben lett feltöltve.");
define("LANUPLOAD_8", "Nem lett semmi feltöltve.");
define("LANUPLOAD_9", "Feltöltött fileméret: 0 byte");
define("LANUPLOAD_10", "A feltöltés nem sikerült [Duplikált fájlnév] - Már van ilyen nevű fájl.");
define("LANUPLOAD_11", "A fájl nem lett feltöltve. Fájlnév: ");
define("LANUPLOAD_12", "Hiba");
define("LANUPLOAD_13", "Hiányzik az ideiglenes mappa");
define("LANUPLOAD_14", "File írás hibás");
define("LANUPLOAD_15", "Feltöltés nem engedélyezett");
define("LANUPLOAD_16", "Ismeretlen hiba");
define("LANUPLOAD_17", "Feltöltött file érvénytelen file név");
define("LANUPLOAD_18", "A feltöltött file túllépte a megengedett határértéket.");
define("LANUPLOAD_19", "Túl sok a feltöltött file - többlet törölve.");


?>