<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_date.php $
|     $Revision: 11678 $
|     $Id: lan_date.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LANDT_01", "év");
define("LANDT_02", "hónap");
define("LANDT_03", "hét");
define("LANDT_04", "nap");
define("LANDT_05", "óra");
define("LANDT_06", "perc");
define("LANDT_07", "másodperc");
define("LANDT_01s", "év");
define("LANDT_02s", "hónap");
define("LANDT_03s", "hét");
define("LANDT_04s", "nap");
define("LANDT_05s", "óra");
define("LANDT_06s", "perc");
define("LANDT_07s", "másodperc");

define("LANDT_08", "perc");
define("LANDT_08s", "perc");
define("LANDT_09", "mp");
define("LANDT_09s", "mp");
define("LANDT_AGO", "ezelőtt");


?>