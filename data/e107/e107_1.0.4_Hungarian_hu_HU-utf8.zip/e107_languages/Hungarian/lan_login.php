<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_login.php $
|     $Revision: 11678 $
|     $Id: lan_login.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_27", "Kötelezően megadandó mező(ke)t hagytál üresen");
define("LAN_300", "Helytelen bejelentkezés. Nincs ilyen felhasználónév az adatbázisban. Ellenőrizd a Caps Lock helyzetét.");
define("LAN_302", "Nem aktiváltad a regisztrációdat. Kapnod kellett egy e-mailt, amiben le volt írva mit kell tenned. Ha nem kaptad meg, katt <a href='".e_BASE."signup.php?resend'>ide</a>.");
define("LAN_303", "Érvénytelen kód.");
define("LAN_304", "Ez a felhasználónév/jelszó páros már használatban van.");
define("LAN_LOGIN_1", "Felhasználónév");
define("LAN_LOGIN_2", "Jelszó");
define("LAN_LOGIN_3", "Védett szerver");
define("LAN_LOGIN_4", "a hozzáféréshez add meg adataidat");
define("LAN_LOGIN_5", "Regisztráció");
define("LAN_LOGIN_6", "Regisztráció jelenleg nem lehetséges");
define("LAN_LOGIN_7", "Add meg a képi igazolókódot");
define("LAN_LOGIN_8", "Belépés megjegyzése");
define("LAN_LOGIN_9", "Belépés");
define("LAN_LOGIN_10", "Belépés");
define("LAN_LOGIN_11", "Regisztráció");
define("LAN_LOGIN_12", "Elfelejtett jelszó");
define("LAN_LOGIN_13", "Írd be a képen lévő szöveget");

define("LAN_LOGIN_14", "Belépési kísérlet ismeretlen felhasználónévvel");
define("LAN_LOGIN_15", "Belépési kísérlet hibás jelszóval");
define("LAN_LOGIN_16", "Belépési kísérlet már használatban lévő felhasználónév/jelszó használatával");
define("LAN_LOGIN_17", "Jelszó (hashed)");
define("LAN_LOGIN_18", "Automatikus-kitiltás: Több, mint 10 hibás belépési kisérlet");
define("LAN_LOGIN_19", "> 10 hibás belépési kisérlet");

?>