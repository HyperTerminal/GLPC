<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_online.php $
|     $Revision: 11678 $
|     $Id: lan_online.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

//v.616
define("ONLINE_EL1", "Vendégek: ");
define("ONLINE_EL2", "Tagok: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Jelenleg");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "Új tagok");
define("ONLINE_EL7", "mutatása");
define("ONLINE_EL8", "ebből jelenleg ");
define("ONLINE_EL9", "-");
define("ONLINE_EL10", "Felhasználónév");
define("ONLINE_EL11", "A lap mutatása");
define("ONLINE_EL12", "Válasz");
define("ONLINE_EL13", "Fórum");
define("ONLINE_EL14", "Téma");
define("ONLINE_EL15", "Lap");
define("CLASSRESTRICTED", "Ezt az oldalt csak regisztrált felhasználók látogathatják!");
define("ARTICLEPAGE", "Cikk / Leírás");
define("CHAT", "Chat");
define("COMMENT", "Hozzászólások");
define("DOWNLOAD", "Letöltések");
define("EMAIL", "Küldés e-mailben");
define("FORUM", "Fórum főoldal");
define("LINKS", "Linkek");
define("NEWS", "Hírek");
define("OLDPOLLS", "Régebbi szavazások");
define("POLLCOMMENT", "Szavazás");
define("PRINTPAGE", "Nyomtatás");
define("LOGIN", "Bejelentkezés");
define("SEARCH", "Keresés");
define("STATS", "Weblap statisztika");
define("SUBMITNEWS", "Hírek");
define("UPLOAD", "Feltöltések");
define("USERPAGE", "Profil");
define("USERSETTINGS", "Beállítások");
define("ONLINE", "Jelenlegi felhasználók");
define("LISTNEW", "Lista az újdonságokról");
define("USERPOSTS", "Üzenetek");
define("SUBCONTENT", "Cikk/Leírás javaslatok");
define("TOP", "Top Üzenetek/Legaktívabb témák");
define("ADMINAREA", "Adminterület");
define("BUGTRACKER", "Bugtracker");
define("EVENT", "Események");
define("CALENDAR", "Eseménynaptár");
define("FAQ", "GYIK");
define("PM", "Privát Üzenetek");
define("SURVEY", "Szavazás");
define("ARTICLE", "Cikk");
define("CONTENT", "Tartalom oldal");
define("REVIEW", "Leírás");

?>