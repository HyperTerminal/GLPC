<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_news.php $
|     $Revision: 11678 $
|     $Id: lan_news.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Hírek");


define("LAN_NEWS_1", "Hírek csak meghatározott tagoknak");
define("LAN_NEWS_2", "Nincs jogosultságod a hír elolvasására");
define("LAN_NEWS_9", "Csak cím beállítva - <b>csak a hír címe fog megjelenni</b><br />");
define("LAN_NEWS_10", "A hír <b>inaktív</b> (nem fog megjelenni a főoldalon). ");
define("LAN_NEWS_11", "A hír <b>aktív</b> (meg fog jelenni a főoldalon). ");
define("LAN_NEWS_12", "Hozzászólások <b>engedélyezve</b>. ");
define("LAN_NEWS_13", "Hozzászólások <b>tiltva</b>. ");
define("LAN_NEWS_14", "<br />Aktív időszak: ");
define("LAN_NEWS_15", "Törzs hossz: ");
define("LAN_NEWS_16", "b. Bővített hossz: ");
define("LAN_NEWS_17", "b.");
define("LAN_NEWS_18", "Info:");
define("LAN_NEWS_19", "Most");
define("LAN_NEWS_23", "Hírkategóriák");
define("LAN_NEWS_24", "Hír létrehozása pdf formátumban");
define("LAN_NEWS_25", "Edit");
define('LAN_NEWS_31', 'Sticky hír');
define("LAN_NEWS_82", 'Hírek - Kategória');
define("LAN_NEWS_83", 'Nincsenek hírek - nézz vissza később.');
define("LAN_NEWS_84", 'Hírek');
define('LAN_NEWS_85', 'Kategória');
define('LAN_NEWS_86', 'Régebbi hírek');
define('LAN_NEWS_87', 'Újabb hírek');
define("LAN_NEWS_462", 'Nincs hír ebben a hónapban');

// Following used by alt_news
define("LAN_NEWS_99", 'Hozzászólások');
define("LAN_NEWS_100", ' - ');
define("LAN_NEWS_307", 'Összes üzenet ebben a kategóriában: ');

?>