<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_page.php $
|     $Revision: 11678 $
|     $Id: lan_page.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Oldal listázás kikapcsolva");
define("LAN_PAGE_2", "Nincsennek oldalak");
define("LAN_PAGE_3", "A kért oldal nem létezik");
define("LAN_PAGE_4", "Oldal értékelése");
define("LAN_PAGE_5", "Értékelésedet köszönjük");
define("LAN_PAGE_6", "Nincs jogosultságod az oldal megtekintéséhez");
define("LAN_PAGE_7", "Érvénytelen jelszó");
define("LAN_PAGE_8", "Jelszóval védett oldal");
define("LAN_PAGE_9", "Jelszó");
define("LAN_PAGE_10", "Mehet");
define("LAN_PAGE_11", "Oldal Lista");
define("LAN_PAGE_12", "Érvénytelen oldal");
define("LAN_PAGE_13", "Oldal");

?>