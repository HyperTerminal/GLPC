<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_membersonly.php $
|     $Revision: 11678 $
|     $Id: lan_membersonly.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Csak tagoknak");

define("LAN_MEMBERS_0", "Korlátozott terület");
define("LAN_MEMBERS_1", "Ez egy korlátozott terület,");
define("LAN_MEMBERS_2", "A hozzáféréshez <a href='".e_LOGIN."'>jelentkezz be</a>");
define("LAN_MEMBERS_3", "vagy <a href='".e_SIGNUP."'>regisztrálj</a> az oldalon!");
define("LAN_MEMBERS_4", "Kérlek menj vissza a főoldalra!");


?>