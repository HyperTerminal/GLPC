<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_languages/Hungarian/lan_top.php $
|     $Revision: 11678 $
|     $Id: lan_top.php 11678 2010-08-22 00:43:45Z e107coders $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/

define("TOP_LAN_0", "A legtöbb üzenetet író a fórumban");
define("TOP_LAN_1", "Felhasználónév");
define("TOP_LAN_2", "Üzenetek");
define("TOP_LAN_3", "A legtöbb hozzászólást író tag");
define("TOP_LAN_4", "Hozzászólások");
define("TOP_LAN_5", "A legtöbb chatbox üzenetet író tag");
define("TOP_LAN_6", "Weblap értékelése");

//v.616
define("LAN_1", "Téma");
define("LAN_2", "Küldő");
define("LAN_3", "Megtekintés");
define("LAN_4", "Válaszok");
define("LAN_5", "Utolsó üzenet");
define("LAN_6", "Témák");
define("LAN_7", "Legaktívabb témák");
define("LAN_8", "Legtöbb üzenetet író tagok");


?>