<?php

define('LANINS_TITLE',	'e107 telepítése');
define('LANINS_000',	'Érvénytelen szakasz információk érzékelése! Telepítés megszakítva.');
define('LANINS_001',	'Verzió %1$s');
define('LANINS_002',	'Telepítés');
define('LANINS_002a',	'(%1$s szakasz a 7-ből)');
define('LANINS_003',	'1');
define('LANINS_004',	'Nyelv kiválasztása');
define('LANINS_004a',	'Kiválasztott nyelv');
define('LANINS_004b',	'Nyelv');
define('LANINS_005',	'Válaszd ki a telepítés folyamán használt nyelvet');
define('LANINS_006',	'Nyelv kiválasztása');
define('LANINS_007',	'4');
define('LANINS_008',	'PHP verzió, mySQL verzió &amp; Fájl Jogosultság Ellenőrzés');
define('LANINS_008a',	'Kompatibilitás &amp; Fájl jogosultságok');
define('LANINS_009',	'Fájl Jogosultság Újraellenörzése');
define('LANINS_010',	'Fájl nem írható: ');
define('LANINS_010a',	'Mappa nem írható: ');
define('LANINS_011',	'Hiba');
define('LANINS_012',	'MySQL funkciók nem léteznek. Talán valamelyik MySQL PHP kiterjesztés nincs telepítve vagy nincs beállítva megfelelően.'); // help for 012
define('LANINS_013',	'Nem lehet megállapítani a MySQL verziószámát. Ez nem egy végzetes hiba, folytathatod a telepítést, de legyél figyelmes, mert az e107 működéséhez MySQL >= 3.23 vagy magasann szükséges a funkciók megfelelő működéséhez.');
define('LANINS_014',	'Fájl Jogosultságok');
define('LANINS_015',	'PHP Verzió');
define('LANINS_016',	'MySQL');
define('LANINS_017',	'Rendben');
define('LANINS_018',	'Gondoskodj róla, hogy a felsorolt fájlok létezzenek és a szerver által írhatóak legyenek. Ez normális esetben CHMOD 777, de előfordulhat más beállítás is - probléma esetén lépj kapcsolatba a kiszolgálóval.');
define('LANINS_019',	'A szerveren telepített PHP verzió nem alkalmas az e107 futtatására. Az e107-hez szükséges minimum a PHP 4.3.0 verzió a megfelelő mûködéshez. Vagy frissítsd a PHP verziót, vagy lépj kapcsolatba a kiszolgálóval.');
define('LANINS_020',	'Telepítés folytatása');
define('LANINS_021',	'2');
define('LANINS_022',	'MySQL Szerver Adatok');
define('LANINS_022a',	'Adatbázis');
define('LANINS_023',	'Írd be a MySQL beállításokat.<br /><br />Ha root jogosultsággal rendelkezel, akkor létre tudsz hozni új adatbázist a jelölődoboz bejelölésével. Ha nem szükséges vagy már létezik, ne jelöld be.<br /><br />Ha csak egy adatbázissal rendelkezel, akkor használj egy prefix-et, így egyéb adatokat is menthetsz azonos adatbázisba.<br />Ha nem ismered a MySQL adatokat, lépj kapcsolatba a szolgáltatóval.');
define('LANINS_024',	'MySQL Szerver:');
define('LANINS_025',	'MySQL Felhasználónév:');
define('LANINS_026',	'MySQL Jelszó:');
define('LANINS_027',	'MySQL Adatbázis:');
define('LANINS_028',	'Létrehozol Adatbázist?');
define('LANINS_029',	'Tábla prefix:');
define('LANINS_030',	'A MySQL szerver, amit használni szeretnél az e107-hez. Belefoglalhatsz még egy port számot is. Pl.: “hostname:port” vagy egy útvonalat a helyi kapcsolathoz pl.: \':/path/to/socket\' a localhost-hoz.');
define('LANINS_031',	'A felhasználónév, mellyel kapcsolódik az e107 a MySQL szerverhez');
define('LANINS_032',	'A felhasználó jelszava, amit éppen beírsz');
define('LANINS_033',	'Az e107 MySQL adatbázisa, néha hivatkozik egy sémára. Ha a felhasználó rendelkezik adatbázis létrehozása jogosultsággal, akkor választható az adatbázis automatikus létrehozása, ha még nem létezik.');
define('LANINS_034',	'A prefix (előtag) az, amit az e107 használni fog, mikor létrehozza az adatbázis táblákat. Hasznos, ha összetett e107 telepítést kell végezni azonos adatbázisban.');
define('LANINS_035',	'Folytatás');
define('LANINS_036',	'3');
define('LANINS_037',	'MySQL Kapcsolat Ellenörzése');
define('LANINS_038',	' és Adatbázis Létrehozása');
define('LANINS_038a',	'Adatbázis Ekkenőrzés');
define('LANINS_039',	'Természetesen, ki kell töltened az összes mezőt, nagyon fontos: MySQL Szerver, MySQL Felhasználónév és MySQL Adatbázis (Ezekre mindig szüksége van a MySQL Szervernek)');
define('LANINS_040',	'Hibák');
define('LANINS_041',	'e107 nem tud kapcsolódni a MySQL szerverhez a beírt adatokkal.<br />Ellenőrizd az adatok helyességét!');
define('LANINS_042',	'A MySQL szerverhez történő kapcsolódás létrejött, ellenőzizve.');
define('LANINS_043',	'Az adatbázis létrehozása sikertelen, ellenőzizd az adatbázis létrehozásához szükséges jogosultságokat a szerveren.');
define('LANINS_044',	'Adatbázis sikeresen létrejött.');
define('LANINS_045',	'Katt a gombra a folyamat folytatásához.');
define('LANINS_046',	'5');
define('LANINS_047',	'Adminisztrátor Adatai');
define('LANINS_047a',	'Adminisztráció');
define('LANINS_048',	'Vissza az előző oldalra');
define('LANINS_049',	'A két, általad beírt jelszó nem azonos. Lépj vissza és próbáld újra.');
define('LANINS_050',	'XML Kiterjesztés');
define('LANINS_051',	'Telepítve');
define('LANINS_052',	'Nincs telepítve');
define('LANINS_053',	'e107-hez szükséges a PHP XML kiterjesztés telepítése. Lép kapcsolatba a kiszolgálóval vagy olvasd el az erről szóló információkat <a href="http://php.net/manual/en/ref.xml.php" target="_blank">php.net</a> mielőtt folytatod');
define('LANINS_054',	'A kiválasztott adatbázis megléte ellenőrizve.');
define('LANINS_055',	'Telepítés megerősítése');
define('LANINS_055a',	'Megerősítés');
define('LANINS_056',	'6');
define('LANINS_057',	'Az e107 rendelkezik a telepítéshez szükséges összes információval.<br /><br />Katt a gombra az adatbázis táblák létrehozásához és a beállítások mentéséhez.');
define('LANINS_058',	'7');
define('LANINS_060',	'A sql adat fájl olvasása sikertelen<br /><br /><br />Ellenőrizd a <b>core_sql.php</b> fájl létezését az <b>/e107_admin/sql</b> könyvtárban.');
define('LANINS_061',	'Az e107 nem tudta létrehozni az összes, szükséges adatbázis táblát.<br /><br />Töröld az adatbázist, az ismételt telepítés előtt javítani kell a problémát.');
define('LANINS_062',	'');

define('LANINS_063',	'Köszöntelek az e107 rendszerében');
define('LANINS_069',	'Az e107 telepítése sikeres!<br /><br />A biztonságos működés érdekében állítsd az <b>e107_config.php</b> fájl jogosultságát 644-re.<br /><br />Ne feledkezz meg az install.php törléséről a szerverről a lenti gomb megnyomása után.');
define('LANINS_070',	'Az e107 nem tudja elmenteni a fő konfigurációs fájlt a szerverre.<br /><br />Ellenőrizd, hogy az <b>e107_config.php</b> fájl a megfelelő jogosultsággal rendelkezik-e');
define('LANINS_071',	'Telepítés befejezése');
define('LANINS_071a',	'Kész');
define('LANINS_071b',	'Hiba a telepítés befejezésekor');
define('LANINS_071c',	'Kész, de hibákkal');
define('LANINS_072',	'Admin Felhasználónév');
define('LANINS_073',	'Ezt a felhasználónevet kell használnod az oldalra történő belépéskor');
define('LANINS_074',	'Admin Megjelenő név');
define('LANINS_075',	'Ez a név jelenik meg a felhasználó profiljában, a fórumokban és egyéb területeken. Hagyd üresen, ha azt szeretnéd, hogy a valóságos felhasználóneved jelenjen meg.');
define('LANINS_076',	'Admin Jelszó');
define('LANINS_077',	'Írd be az általad használni kívánt jelszót');
define('LANINS_078',	'Admin Jelszó megerősítése');
define('LANINS_079',	'Írd be újra a jelszót');
define('LANINS_080',	'Admin e-mail');
define('LANINS_081',	'Írd be az e-mail címedet');
define('LANINS_082',	'admin@yoursite.com');
define('LANINS_083',	'mySQL Jelentett hiba');
define('LANINS_084',	'A telepítő nem tud kapcsolódni az adatbázishoz');
define('LANINS_085',	'A telepítő nem tudja kiválasztani az adatbázist:');
define('LANINS_086',	'Admin Felhasználónév, Admin Jelszó és Admin Email mezőket <b>kötelező</b> kitölteni! Írd be a megfelelő információkat.');
define('LANINS_087',	'Egyéb');
define('LANINS_088',	'Kezdőlap');
define('LANINS_089',	'Letöltések');
define('LANINS_090',	'Tagok');
define('LANINS_091',	'Hír beküldése');
define('LANINS_092',	'Kapcsolat');
define('LANINS_093',	'Hozzáférés a Privát Üzenetküldés menühöz');
define('LANINS_094',	'Privát fórumcsoport példa');
define('LANINS_095',	'Integritás ellenörzés');
define('LANINS_096',	'Legújabb hozzászólások');
define('LANINS_097',	'[tovább ...]');
define('LANINS_098',	'Hírek');
define('LANINS_099',	'e107 CMS');
define('LANINS_100',	'Legújabb fórumüzenetek');
define('LANINS_101',	'Menü beállítások frissítése');
define('LANINS_102',	'Dátum / Idő');
define('LANINS_103',	'e107 Plugin-ok');
define('LANINS_104',	'Ellenőrizve');
define('LANINS_105',	'Az adatbázisnév vagy a prefix elején a következő jegyek \'e\' vagy \'E\' nem elfogadhatóak.  <br />Az adatbázis név vagy prefix nem lehet üres.');
define('LANINS_106',	'FIGYELMEZTETÉS - E107 nem tud hozzáírni a kilistázott könyvtárakhoz és/vagy fájlokhoz. Mivel ez nem állítja le a telepítést, de bizonyos funkciók, tulajdonságok nem lesznek engedélyezve.<br /><br />Ezen tulajdonságok használatához meg kell változtatni a fájl jogosultságokat');
define('LANINS_107',	'e107_config.php fájl nem üres');
define('LANINS_108',	'Lehetséges, hogy már telepítetted a rendszert');

define('LANINS_DB_UTF8_LABEL',   'UTF-8 adatbázis kikényszerítése?');
define('LANINS_DB_UTF8_CAPTION', 'MySQL Karakterkészlet:');
define('LANINS_DB_UTF8_TOOLTIP', 'Ha kiválasztod, akkor a telepítő script UTF-8 kompatibilissé alakítja az adatbázist, ha lehetséges. UTF-8 Adatbázis szükséges az új Fő e107 verzióhoz.');

// v1.0 - Be sure to re-check ALL translations above for modifications and additions. 

define('LANINS_109',	'Kezdeményezte');
define('LANINS_110',	'Kész');
define('LANINS_111',	'e107 Theme-k');
define('LANINS_112',	'e107 Kézikönyv');
define('LANINS_113',	'');

define('LANINS_121',	'e107_config.php már létezik!');
define('LANINS_122',	'Lehetséges, hogy már telepítetted a rendszert');
define('LANINS_123',	'Debug info');
define('LANINS_124',	'Backtrace');
define('LANINS_125',	'Érvénytelen művelet');
define('LANINS_125a',	'Hiba');

define('LANINS_WELCOME', '[b]Köszöntelek az új weboldaladon![/b]

e107 telepítése sikeres, megkezdheted a tartalom feltöltését. Az adminisztrációs felületed [link=e107_admin/admin.php]itt található[/link], katt a belépéshez. A bejelentkezéshez használd a telepítés folyamán megadott felhasználónevet és jelszót.

[b]Támogatás[/b]
e107 főoldala: [link=http://e107.org]http://e107.org[/link].
e107 Magyarország főoldala: [link=http://e107hungary.org]http://e107hungary.org[/link], a magyar e107 TEAM oldala.
Source: [link=http://source.e107hungary.org]http://source.e107hungary.org[/link], Plugin-ok, módosítások, ...
Themes: [link=http://themes.e107hungary.org]http://themes.e107hungary.org[/link], Themek, sablonok, ...
Fórumok: [link=http://e107hungary.org/e107_plugins/forum/forum.php]http://e107hungary.org/e107_plugins/forum/forum.php[/link]
[link=http://wiki.e107.org/]e107 Kézikönyv[/link]

Köszönjük, hogy kipróbálod az e107-t, bízunk benne, hogy mindent megtalálsz, amire szükséged van.
(Törölheted ezt az üzenetet az admin felületen.)');

define('LANINS_NEWS', '[b]Köszöntelek az e107 rendszerében![/b]
Az e107 egy tartalomkezelő rendszer, melyet PHP-ban írtak és a népszerű nyílt forráskódú MySQL adatbázis rendszert alkalmazza a tartalom tárolására. Teljesen ingyenes, testreszabható és folyamatosan fejlesztik.

[list][link=http://e107.org/content/Learn-all-about-e107]Minden, amit tudnod kell az e107-ről[/link]*[link=http://e107.org/content/About-Us:The-Team]Dev Team | Translators | Support Team[/link]*[link=http://wiki.e107.org/]Documentation Wiki[/link][/list]');
