<?php
/*
+---------------------------------------------------------------+
|        e107 website system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Hungarian_search.php $
|        $Revision: 1.0 $
|        $Id: 2010/10/01 00:42:28 $
|        $Author: e107hungary.org team $
+---------------------------------------------------------------+
*/

define("CM_SCH_LAN_1", "Naptár");


?>