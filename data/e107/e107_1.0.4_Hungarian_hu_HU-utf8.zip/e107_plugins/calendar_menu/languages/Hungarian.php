<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/e107_plugins/calendar_menu/languages/Hungarian.php $
 * $Id: Hungarian.php 13009 2012-10-27 15:19:55Z e107steved $
 */

/**
 *	e107 Event calendar plugin
 *
 *	Language file - general strings
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: Hungaryan.php 13009 2012-10-27 15:19:55Z e107steved $;
 */


define('EC_ADLAN_1',"Eseménynaptár");
define('EC_ADLAN_2',"Eseménynaptár beállítása");
define('EC_INSTALL',"Eseménynaptár telepítése");
define('EC_UNINSTALL',"Eseménynaptár eltávolítása");
define('EC_LAN_TODAY', "Ma");

define('EC_LAN_DAY_1', "1");
define('EC_LAN_DAY_2', "2");
define('EC_LAN_DAY_3', "3");
define('EC_LAN_DAY_4', "4");
define('EC_LAN_DAY_5', "5");
define('EC_LAN_DAY_6', "6");
define('EC_LAN_DAY_7', "7");
define('EC_LAN_DAY_8', "8");
define('EC_LAN_DAY_9', "9");
define('EC_LAN_DAY_10', "10");
define('EC_LAN_DAY_11', "11");
define('EC_LAN_DAY_12', "12");
define('EC_LAN_DAY_13', "13");
define('EC_LAN_DAY_14', "14");
define('EC_LAN_DAY_15', "15");
define('EC_LAN_DAY_16', "16");
define('EC_LAN_DAY_17', "17");
define('EC_LAN_DAY_18', "18");
define('EC_LAN_DAY_19', "19");
define('EC_LAN_DAY_20', "20");
define('EC_LAN_DAY_21', "21");
define('EC_LAN_DAY_22', "22");
define('EC_LAN_DAY_23', "23");
define('EC_LAN_DAY_24', "24");
define('EC_LAN_DAY_25', "25");
define('EC_LAN_DAY_26', "26");
define('EC_LAN_DAY_27', "27");
define('EC_LAN_DAY_28', "28");
define('EC_LAN_DAY_29', "29");
define('EC_LAN_DAY_30', "30");
define('EC_LAN_DAY_31', "31");

define('EC_LAN_0', "január");
define('EC_LAN_1', "február");
define('EC_LAN_2', "március");
define('EC_LAN_3', "április");
define('EC_LAN_4', "május");
define('EC_LAN_5', "június");
define('EC_LAN_6', "július");
define('EC_LAN_7', "augusztus");
define('EC_LAN_8', "szeptember");
define('EC_LAN_9', "október");
define('EC_LAN_10', "november");
define('EC_LAN_11', "december");
define('EC_LAN_JAN', "jan.");
define('EC_LAN_FEB', "febr.");
define('EC_LAN_MAR', "márc.");
define('EC_LAN_APR', "ápr.");
define('EC_LAN_MAY', "máj.");
define('EC_LAN_JUN', "jún.");
define('EC_LAN_JUL', "júl.");
define('EC_LAN_AUG', "aug.");
define('EC_LAN_SEP', "szept.");
define('EC_LAN_OCT', "okt.");
define('EC_LAN_NOV', "nov.");
define('EC_LAN_DEC', "dec.");
define('EC_LAN_12', "hétfő");
define('EC_LAN_13', "kedd");
define('EC_LAN_14', "szerda");
define('EC_LAN_15', "csütörtök");
define('EC_LAN_16', "péntek");
define('EC_LAN_17', "szombat");
define('EC_LAN_18', "vasárnap");
define('EC_LAN_19', "H");
define('EC_LAN_20', "K");
define('EC_LAN_21', "Sze");
define('EC_LAN_22', "Cs");
define('EC_LAN_23', "P");
define('EC_LAN_24', "Szo");
define('EC_LAN_25', "V");
define('EC_LAN_26', "Események a hónapban");
define('EC_LAN_27', "Nincsenek események a hónapban.");
define('EC_LAN_28', "Új esemény megadása");
define('EC_LAN_29', "Mikor");
define('EC_LAN_30', "Kategória:");
define('EC_LAN_31', "Beküldte:");
define('EC_LAN_32', "Helység:");
define('EC_LAN_33', "Kapcsolat:");
define('EC_LAN_34', "Ugrás");
define('EC_LAN_35', "Módosítás");
define('EC_LAN_36', "Törlés");
define('EC_LAN_37', "Nincs listázandó.");
define('EC_LAN_38', "Nincs megadva");
define('EC_LAN_39', "Katt ide a további információkhoz");
define('EC_LAN_40', "E hónap");
define('EC_LAN_41', "Összesen -NUM- egyéni esemény lett létrehozva");
define('EC_LAN_42', "Az esemény nem kezdődhet, mielőtt befejeződne.");
define('EC_LAN_43', "Kötelező mező(ke)t hagytál üresen.");
define('EC_LAN_44', "Az új esemény létrehozva és felvéve az adatbázisba.");
define('EC_LAN_45', "Az esemény frissítve az adatbázisban.");
define('EC_LAN_46', "Esemény törlésének megerősítése");
define('EC_LAN_47', "Törlés visszavonva.");
define('EC_LAN_48', "Erősítsd meg az esemény törlését - a törlés után nem lesz visszaállítható");
define('EC_LAN_49', "Mégsem");
define('EC_LAN_50', "Törlés megerősítése");
define('EC_LAN_51', "Esemény törölve.");
define('EC_LAN_52', "Esemény kategória:");
define('EC_LAN_53', "Létrehozol új kategóriát?:");
define('EC_LAN_54', "Név:");
define('EC_LAN_55', "Ikon:");
define('EC_LAN_56', "Létrehozás");
define('EC_LAN_57', "Esemény:");
define('EC_LAN_58', "Forrás info URL-je:");
define('EC_LAN_59', "Kapcsolati email cím:");
define('EC_LAN_60', "Esemény frissítése");
define('EC_LAN_61', "Mehet");
define('EC_LAN_62', "Következő -NUM- esemény ...");
define('EC_LAN_63', "Ismétlődő események kiválasztása kező- és végdátum között. Kezdő- és végdátum");
define('EC_LAN_64', "Jelöld be, ha mindennapos esemény");
define('EC_LAN_65', "Ismétlődés:");
define('EC_LAN_66', "Esemény módosítása");
define('EC_LAN_67', "Kezdete:");
define('EC_LAN_68', "Mindennapos esemény");
define('EC_LAN_69', "Vége");
define('EC_LAN_70', "Esemény címe:");
define('EC_LAN_71', "Esemény ideje:");
define('EC_LAN_72', "Esemény dátuma:");
define('EC_LAN_73', "Vége:");
define('EC_LAN_74', "Kategória mutatása");
define('EC_LAN_75', "Naptár beállítások frissítve.");
define('EC_LAN_76', "Eseményeket felvihet:");
define('EC_LAN_77', "Beállítások frissítése");
define('EC_LAN_78', "Naptár beállítások");
define('EC_LAN_79', "Naptár mutatása");
define('EC_LAN_80', "Eseménylista");
define('EC_LAN_81', "Naptár beállítása");
define('EC_LAN_82', "A menü aktiváláshoz helyezd el a calendar_menu-t valamelyik menüterületre.");
define('EC_LAN_83', "Naptár");
define('EC_LAN_84', " ettől ");
define('EC_LAN_85', " eddig ");
define('EC_LAN_86', "Egyéni esemény bejegyzésből");
define('EC_LAN_87', "Ezt bepipálva nagy számban generálhatsz egyéni eseményeket, amiket aztán szerkeszthet vagy törölhetsz.");
define('EC_LAN_88', "Összesen -NUM- egyéni eseményt választottál ki generálásra.");
define('EC_LAN_89', "Ha a bejegyzés hibás, a szerkesztés vagy törlés csak egyénileg lehetséges");

define('EC_LAN_90', "Kiválasztás");
define('EC_LAN_91', "Először az Admin-nak kell megadni"); 
define('EC_LAN_92', "Kategória megtekintése");
define('EC_LAN_93', "Eseménylista");
define('EC_LAN_94', "Új esemény");
define('EC_LAN_95', "Ma");
define('EC_LAN_96', "Naptár mutatása");
define('EC_LAN_97', "Összes");
define('EC_LAN_98', "Kötelező mező(k) maradt(ak) üresen");
define('EC_LAN_99', "Az eseménynek vagy egész naposnak kell lennie, vagy a kezdete után kell véget érnie");
define('EC_LAN_100', "Érvénytelen a kiválasztott kategória");
// define('EC_LAN_101', "Állítsd inaktívra, ha nem akarod megjeleníteni az új esemény felvitelénél.");
define('EC_LAN_102', "Link megjelenítése fórumtémához");
// define('EC_LAN_103', "Új esemény felvitelénél.");
define('EC_LAN_104', "Naptár adminisztrátor csoport");
define('EC_LAN_105', "* kötelező mező");
define('EC_LAN_106', "Esemény");
define('EC_LAN_107', "Eseménynaptár menüvel.");
define('EC_LAN_108', "Az Eseménynaptár frissítve.");
define('EC_LAN_109', "Az esemény nem törölhető.");
define('EC_LAN_110', "Esemény száma ");
define('EC_LAN_111', "Napi események: ");
define('EC_LAN_112', "Havi események: ");
define('EC_LAN_113', "Az új esemény ûrlapját már elküldted.");
define('EC_LAN_114', "A hét kezdő napja:");
define('EC_LAN_115', "Vasárnap");
define('EC_LAN_116', "Hétfő");
define('EC_LAN_117', "Napok nevének hossza (karakter)");
define('EC_LAN_118', "Dátumformátum a naptár címsorában.");
define('EC_LAN_119', "hónap/év");
define('EC_LAN_120', "év/hónap");
define('EC_LAN_121', "Naptár mutatása");
// define('EC_LAN_122', "Használandó css elem a mai naphoz (menü)");
define('EC_LAN_123', "Feliratkozás");
define('EC_LAN_124', "Naptár feliratkozás");
define('EC_LAN_125', "Kategóriák engedélyezettek a feliratkozáshoz");
define('EC_LAN_126', "Feliratkoztál");
define('EC_LAN_127', "Kategória");
define('EC_LAN_128', "Nincs kategória engedélyezve a feliratkozáshoz");
define('EC_LAN_129', "Frissítve");
define('EC_LAN_130', "Feliratkozás frissítve");
define('EC_LAN_131', "Vissza");
define('EC_LAN_132', "Részletek megnyitása");
define('EC_LAN_133', "[tovább]");
define('EC_LAN_134', "Adj meg egy kategória nevet");
define('EC_LAN_135', "Esemény");
define('EC_LAN_136', "Kategória Leírás");
define('EC_LAN_137', "Leendő események");
define('EC_LAN_138', '---Lista vége---');

define('EC_LAN_140', "Közelgő Események");
define('EC_LAN_141', "Nincs közelgő esemény");
define('EC_LAN_142', "Csak regisztrált és bejelentkezett felhasználók vihetnek be eseményt");
define('EC_LAN_143', "Nincs jogosultságod esemény bevitelére");
define('EC_LAN_144', " at ");

define('EC_LAN_145', "Ki kell választani egy kategóriát az eseményhez");
define('EC_LAN_146', "Előzetes értesítője az eseménynek");
define('EC_LAN_147', "Naptár esemény ma vagy holnap");
define('EC_LAN_148', "Nem található esemény a megadott időintervallumban");
define('EC_LAN_149', "Érvénytelen dátum formátum");
define('EC_LAN_150', "Adjon meg egy kezdő- és befejezési dátumot a listához");
define('EC_LAN_151', "Befejezés dátuma a kezdés dátuma után");
define('EC_LAN_152', "Maximum egy év eseményei");
define('EC_LAN_153', "Kezdés dátuma (első nap): ");
define('EC_LAN_154', "Befejezés dátuma (utolsó nap): ");
define('EC_LAN_155', "Kategória: ");
define('EC_LAN_156', "Lista készítése");
define('EC_LAN_157', "Réteg beállítások:");
define('EC_LAN_158', "Kimenet: ");
define('EC_LAN_159', "Megjelenés ");
define('EC_LAN_160', "Nyomtatás ");
define('EC_LAN_161', "PDF ");
define('EC_LAN_162', "Oldal nyomtatása");
define('EC_LAN_163', "Esemény lista");
define('EC_LAN_164', "Nyomtatható listák");
define('EC_LAN_165', "Alapértelmezett listázás");
define('EC_LAN_166', "Tabulátoros lista sorok nélkül");
define('EC_LAN_167', "Tabulátoros lista sorokkal");
define('EC_LAN_168', "Feladó: ");
define('EC_LAN_169', "Címzett: ");
define('EC_LAN_170', "Kinyomtatva: ");
define('EC_LAN_171', "Betöltött kategória listázása");
define('EC_LAN_172', "Esemény kategóriák: ");
define('EC_LAN_173', "Első esemény kezdete: ");
define('EC_LAN_174', "Utolsó esemény vége: ");
define('EC_LAN_175', "Minden nap");
define('EC_LAN_176', "Ismétlődő szabály: ");
define('EC_LAN_177', "Bejegyzés elvetése");
define('EC_LAN_178', "Bejegyzések jóváhagyása");
define('EC_LAN_179', "Megerősítés több esemény egyidejű bejegyzésekor");
define('EC_LAN_180', " REKORDOK NEM LETTEK MENTVE - HIBA A DB FRISSÍTÉSÉNÉL");

define('EC_LAN_VIEWCALENDAR', "Naptár megtekintése");
define('EC_LAN_VIEWALLEVENTS', "Események megtekintése");
define('EC_LAN_ALLEVENTS', "Összes esemény");

define('EC_ADLAN_A10', "Beállítás");
define('EC_ADLAN_A11', "Kategóriák");
define('EC_ADLAN_A12', "Naptár");
define('EC_ADLAN_A13', "Módosítás");
define('EC_ADLAN_A14', "Új");
define('EC_ADLAN_A15', "Törlés");
define('EC_ADLAN_A16', "Megerősítés");
define('EC_ADLAN_A17', "Mehet");
define('EC_ADLAN_A18', "Opciók");
define('EC_ADLAN_A19', "Kategóriák kezelése");
define('EC_ADLAN_A20', "Naptár kategóriák");
define('EC_ADLAN_A21', "Kategória neve");

define('EC_ADLAN_A23', "Kategória létrehozása");
define('EC_ADLAN_A24', "Kategória módosítása");
define('EC_ADLAN_A25', "Mentés");
define('EC_ADLAN_A26', "Kategória létrehozva");
define('EC_ADLAN_A27', "A kategória létrehozása nem sikerült");
define('EC_ADLAN_A28', "Módosítások elmentve");
define('EC_ADLAN_A29', "A módosítások elmentése nem sikerült");

define('EC_ADLAN_A30', "Kategória törölve");
define('EC_ADLAN_A31', "jelöld be a törlés megerősítéséhez");
define('EC_ADLAN_A32', "A kategória törlése nem sikerült");
define('EC_ADLAN_A33', "Nincs");
define('EC_ADLAN_A34', "Naptár adminisztrátor csoport");
//define('EC_ADLAN_A35', "");
define('EC_ADLAN_A59', "A kategória használatban van, nem törölhető.");

define('EC_ADLAN_A80', "Láthatják");
define('EC_ADLAN_A81', "Feliratkozás engedélyezése");
define('EC_ADLAN_A82', "Azonnali értesítés ehhez a csoporthoz");
define('EC_ADLAN_A83', "Days ahead to notify of event");
define('EC_ADLAN_A84', "Haladó üzenet");
define('EC_ADLAN_A85', "Üzenet ezen a napon");
define('EC_ADLAN_A86', "Email küldése");
define('EC_ADLAN_A87', "Nincs");
define('EC_ADLAN_A88', "Csak haladó");
define('EC_ADLAN_A89', "Csak ezen a napon");
define('EC_ADLAN_A90', "Haladó és csak ezen a napon");
define('EC_ADLAN_A91', "Email Tárgya");
define('EC_ADLAN_A92', "Email kitől (név)");
define('EC_ADLAN_A93', "Email honnan (email cím)");
define('EC_ADLAN_A94', "Új eseménycsoport hozzáadása");
define('EC_ADLAN_A95', "Feliratkozás engedélyezése");
define('EC_ADLAN_A96', "A letiltáshoz töröld a feliratkozás gombot és írd felül a kategória feliratkozás beállításait.");
// define('EC_ADLAN_A97', "Ha a gyors feliratkozást választod ehhez a kategóriához, akkor nem jelenik meg a feliratkozás listában a felhasználónál.");

define('EC_ADLAN_A100', "Közelgő Események");
define('EC_ADLAN_A101', "Előre tekintés napok száma:");
define('EC_ADLAN_A102', "Megjelenő események mennyisége:");
define('EC_ADLAN_A103', "Tartalmazza az ismétlődő eseményeket:");
define('EC_ADLAN_A104', "Az eseménylistához mutató link neve:");
define('EC_ADLAN_A105', "Közelgő Események menü beállítása");
define('EC_ADLAN_A106', "Menü engedélyezése a 'Menük' oldalon");
define('EC_ADLAN_A107', "Menü elrejtése ha nincs megjelenítendő esemény");
define('EC_ADLAN_A108', "Menü Címsor");
define('EC_ADLAN_A109', "Közelgő Események menü frissítve");

define('EC_ADLAN_A110', "Csak az előző napon");
define('EC_ADLAN_A111', "Következő és előző nap");
define('EC_ADLAN_A112', "Előző és ezen a napon");
define('EC_ADLAN_A113', "Következő, előző és ezen a napon");

define('EC_ADLAN_A114', "Email bejelentkezés");
define('EC_ADLAN_A115', "Összegzés");
define('EC_ADLAN_A116', "Részletezés");
define('EC_ADLAN_A117', "Üzenet ezen a napon vagy előző napon");
define('EC_ADLAN_A118', "Megjelenő kategóriák");
define('EC_ADLAN_A119', "Nincs kategória meghatározva vagy adatbázis olvasási hiba");
define('EC_ADLAN_A120', "Kategória ikon megjelenítése a menüben");
define('EC_ADLAN_A121', "e107 Web Site");
define('EC_ADLAN_A122', "calendar@yoursite.com");
define('EC_ADLAN_A123', "Log könyvtárat manuálisan kell létrehozni - create a subdirectory 'log' off your event calendar plugin directory, with '666' access rights");
define('EC_ADLAN_A124', "Nem lehet megváltoztatni a log könyvtár jogosultságát");
define('EC_ADLAN_A125', "Log könyvtár jogosultságát manuálisan szükséges beállítani 0666-ra vagy 0766-ra, a szerver beállítástól függően");
define('EC_ADLAN_A126', "Adatbázis frissítve");
define('EC_ADLAN_A127', "ez egy rss hírforrás az eseménynaptár bejegyzésekhez");
define('EC_ADLAN_A128', "A jobboldali mezőben megadhatod az egyedi idő formátumot");
define('EC_ADLAN_A129', '"Oldal Idő" a beállításokban van definiálva');
define('EC_ADLAN_A130', "Esemény neve egy link ide:");
define('EC_ADLAN_A131', "Naptár Esemény");
define('EC_ADLAN_A132', "Forrás Info URL");
define('EC_ADLAN_A133', "Esemény bejegyzés dátum formátuma: ");
define('EC_ADLAN_A134', "Bejelentkezési szint a fő admin log-hoz:");
define('EC_ADLAN_A135', "Szerkesztés/törlés");
define('EC_ADLAN_A136', "Mindent felülír");
define('EC_ADLAN_A137', "Magában foglalja a hozzáadást, frissítést és törlést az eseményéistából részekkel");
define('EC_ADLAN_A138', "Esemény kezdet/befejezés idők 5-perces határokkal");
define('EC_ADLAN_A139', "(Meglévő csökkentése a legördülő listában)");
define('EC_ADLAN_A140', "Az Eseménynaptár menüben megjelenő havi események száma");
define('EC_ADLAN_A141', "Karbantartás");
define('EC_ADLAN_A142', "Elmúlt események törlése, ha több, mint x hónappal ezelőtt történt");
define('EC_ADLAN_A143', "az idő számítása a jelenlegi hónap elejétől történik");
define('EC_ADLAN_A144', "Eseménynaptár karbantartása");
define('EC_ADLAN_A145', "Régi bejegyzések törlése");
define('EC_ADLAN_A146', "Esemény régebbi, mint ");
define('EC_ADLAN_A147', " törölve");
define('EC_ADLAN_A148', "Paraméter hiba - nincs mit törölni");
define('EC_ADLAN_A149', "Nincs régi, törlendő esemény, vagy az elmúlt esemény törlése nem sikerült");
define('EC_ADLAN_A150', "Esemény törlés megerősítése ");

define('EC_ADLAN_A151', "e107 Web Site");
define('EC_ADLAN_A152', "calendar@yoursite.com");
define('EC_ADLAN_A153', "Log könyvtárat manuálisan kell létrehozni - create a subdirectory 'log' off your event calendar plugin directory, with '666' access rights");
define('EC_ADLAN_A154', "Nem lehet megváltoztatni a log könyvtár jogosultságát");
define('EC_ADLAN_A155', "Log könyvtár jogosultságát manuálisan szükséges beállítani 0666-ra vagy 0766-ra, a szerver beállítástól függően");
define('EC_ADLAN_A156', "Adatbázis frissítve");
define('EC_ADLAN_A157', "ez egy rss hírforrás az eseménynaptár bejegyzésekhez");
define('EC_ADLAN_A158', "Log könyvtár létrehozása sikertelen");

define('EC_ADLAN_A159', "Cache Karbantartás");
define('EC_ADLAN_A160', "(Csak az idevágó, ha a cache engedélyezve)");
define('EC_ADLAN_A161', "Naptár Cache ürítése");
define('EC_ADLAN_A162', "Cache ürítés megerősítése");
define('EC_ADLAN_A163', "Cache kiürítve");

define('EC_ADLAN_A164', "Frissítés kész");
define('EC_ADLAN_A165', "Naptár menü fejrész (header) link ide:");
define('EC_ADLAN_A166', "Dátum megjelenítése az Eseménylistában:");
define('EC_ADLAN_A167', "Dátum megjelenítése a Bekövetkező Eseményekben:");
define('EC_ADLAN_A168', "Egyedi dátum használata a jobboldali formátumban");
define('EC_ADLAN_A169', "Dátum megjelenítési forma meghatározása az eseménylistához");
define('EC_ADLAN_A170', "Dátum megjelenítési forma meghatározása a brkövetkező események menühöz");
define('EC_ADLAN_A171', "Újabban hozzáadott/frissített események megjelölése");
define('EC_ADLAN_A172', "Frissítés óta eltelt idő órában; nulla letiltás");

define('EC_ADLAN_A173', "Feliratkozások");
define('EC_ADLAN_A174', "Nem található feliratkozási bejegyzés");
define('EC_ADLAN_A175', "UID");
define('EC_ADLAN_A176', "Felhasználói név");
define('EC_ADLAN_A177', "Kategória");
define('EC_ADLAN_A178', "Problémák");
define('EC_ADLAN_A179', "Műveletek");
define('EC_ADLAN_A180', "Deleted subscription record no ");
define('EC_ADLAN_A181', "Delete failed for record no ");
define('EC_ADLAN_A182', "Összesen --NUM-- bejegyzés található az adatbázisban");
define('EC_ADLAN_A183', "Az esemény címének mutatása a Naptár menüben, ha az egeret fölé visszük");
define('EC_ADLAN_A184', "előfordulhat hogy nem működik minden böngészőben");
define('EC_ADLAN_A185', "Semmi");
define('EC_ADLAN_A186', "Beállítások mentése\nés teszt email\nküldése magadnak");
define('EC_ADLAN_A187', "Teszt email küldése - ");
define('EC_ADLAN_A188', "Hiba a teszt email küldésénél - ");
define('EC_ADLAN_A189', "Ha üresen maradt az üzenet, akkor az Alapértelmezett kategória üzenete lesz használva");
define('EC_ADLAN_A190', "Alapértelmezett kategória - mailout üzenetek használata, ha nincs megadva más kategória");
define('EC_ADLAN_A191', "Esemény részletei a teszt email-hez");
define('EC_ADLAN_A192', "Esemény helyszín tesztelése");
define('EC_ADLAN_A193', "Megjelenés/nyomtatás/PDF listák engedélyezése a felhasználóknak");
define('EC_ADLAN_A194', "Nincs");
define('EC_ADLAN_A195', "Megjelenés/Nyomtatás");
define('EC_ADLAN_A196', "Megjelenés/Nyomtatás/PDF");
define('EC_ADLAN_A197', "No class membership");
define('EC_ADLAN_A198', "Érvénytelen felhasználó");
define('EC_ADLAN_A199', "'Aktuális' ikon megjelenítése");
define('EC_ADLAN_A200', "Szerkesztő az eseményekhez");
define('EC_ADLAN_A201', "BBCode (Alapértelmezett)");
define('EC_ADLAN_A202', "BBCode segítséggel");
define('EC_ADLAN_A203', "WYSIWYG");
define('EC_ADLAN_A204', "");
define('EC_ADLAN_A205', "");


// Prefs - language defines can be used in various places where text is set through the admin screens
define('EC_MAILOUT_SUBJECT', "Eseménynaptár javaslata"); // USe shortcode EC_MAIL_SUBJECT


?>