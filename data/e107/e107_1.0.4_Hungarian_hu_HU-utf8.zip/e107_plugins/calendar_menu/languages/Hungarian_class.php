<?php
/*
 * e107 website system
 *
 * Copyright (C) 2002-2012 e107 Inc (e107.org)
 * Released under the terms and conditions of the
 * GNU General Public License (http://www.gnu.org/licenses/gpl.txt)
 *
 * These messages are for the 'user' pages of the event calendar (including event entry/editing)
 *
 * $URL: https://e107.svn.sourceforge.net/svnroot/e107/trunk/e107_0.7/usersettings.php $
 * $Id: usersettings.php 11645 2010-08-01 12:57:11Z e107coders $
 */

/**
 *	e107 Event calendar plugin
 *
 *	Language file - anything called up in ecal_class.php and similar
 *
 *	@package	e107_plugins
 *	@subpackage	event_calendar
 *	@version 	$Id: English_class.php 11315 2010-02-10 18:18:01Z secretr $;
 */

// Recurring events texts - the numeric part of each define is the internal value assigned
define('EC_LAN_RECUR_00', 'nem');
define('EC_LAN_RECUR_01', 'évi');
define('EC_LAN_RECUR_02', 'félévi');
define('EC_LAN_RECUR_03', 'negyedévi');
define('EC_LAN_RECUR_04', 'havi');
define('EC_LAN_RECUR_05', '4 heti');
define('EC_LAN_RECUR_06', 'kétheti');
define('EC_LAN_RECUR_07', 'heti');
define('EC_LAN_RECUR_08', 'napi');
define('EC_LAN_RECUR_100', 'vasárnaponként');
define('EC_LAN_RECUR_101', 'hétfőnként');
define('EC_LAN_RECUR_102', 'keddenként');
define('EC_LAN_RECUR_103', 'szerdánként');
define('EC_LAN_RECUR_104', 'csütörtökönként');
define('EC_LAN_RECUR_105', 'péntekenként');
define('EC_LAN_RECUR_106', 'szobatonként');

define('EC_LAN_RECUR_1100', 'Első');
define('EC_LAN_RECUR_1200', 'Második');
define('EC_LAN_RECUR_1300', 'Harmadik');
define('EC_LAN_RECUR_1400', 'Negyedik');


// Notify
define('NT_LAN_EC_1', 'Esemény Naptár Események');
define('NT_LAN_EC_2', 'Esemény frissítve');
define('NT_LAN_EC_3', 'Frissítette');
define('NT_LAN_EC_4', 'IP cím');
define('NT_LAN_EC_5', 'Üzenet');
define('NT_LAN_EC_6', 'Esemény Naptár - Esemény hozzáadva');
define('NT_LAN_EC_7', 'Új esemény keletkezett');
define('NT_LAN_EC_8', 'Esemény Naptár - Esemény módosult');


// Log messages
define('EC_ADM_01', 'Esemény Naptár - esemény hozzáadása');
define('EC_ADM_02', 'Esemény Naptár - esemény szerkesztése');
define('EC_ADM_03', 'Esemény Naptár - esemény törlése');
define('EC_ADM_04', 'Esemény Naptár - Tömeges törlés');
define('EC_ADM_05', 'Esemény Naptár - Több hozzáadása');
define('EC_ADM_06', 'Esemény Naptár - Fő beállítások megváltoztak');
define('EC_ADM_07', 'Esemény Naptár - FE beállítások megváltoztak');
define('EC_ADM_08', 'Esemény Naptár - Kategória létrehozva');
define('EC_ADM_09', 'Esemény Naptár - Kategória szerkesztve');
define('EC_ADM_10', 'Esemény Naptár - Kategória törölve');
define('EC_ADM_11', 'Esemény Naptár - Régi események törölve');


?>