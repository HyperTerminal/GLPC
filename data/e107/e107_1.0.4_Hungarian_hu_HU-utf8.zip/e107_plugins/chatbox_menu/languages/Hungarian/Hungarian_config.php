<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("CHBLAN_1", "Chatbox beállításai frissítve");
define("CHBLAN_2", "Moderálva");
define("CHBLAN_3", "Nincs üzenet");
define("CHBLAN_4", "Tag");
define("CHBLAN_5", "Vendég");
define("CHBLAN_6", "Kinyit");
define("CHBLAN_7", "Tiltás");
define("CHBLAN_8", "Törlés");
define("CHBLAN_9", "Chatbox moderálása");
define("CHBLAN_10", "Üzenetek moderálása");
define("CHBLAN_11", "Chatbox üzenetek megjelenítése");
define("CHBLAN_12", "Megjelenítendő üzenetek száma");
define("CHBLAN_13", "Link cseréje");
define("CHBLAN_14", "Amikor aktív, akkor a linkeket az alábbi szövegdobozban lévő szöveggel helyettesíti a rendszer");
define("CHBLAN_15", "A linket helyettesítő szöveg, ha aktív");
define("CHBLAN_16", "A linkek ezzel a szöveggel lesznek helyettesítve");
define("CHBLAN_17", "Sortörés x számú karakter után");
define("CHBLAN_18", "A beállított értéknél hoszabb szavak törésre kerülnek");
define("CHBLAN_19", "Chatbox beállításainak frissítése");
define("CHBLAN_20", "Chatbox beállítások");
define("CHBLAN_21", "Karbantartás");
define("CHBLAN_22", "Adott időtartamnál régebbi üzenetek törlése");
define("CHBLAN_23", "Üzenetek törlése, melyek régebbiek mint: ");

define("CHBLAN_24", "Egy nap");
define("CHBLAN_25", "Egy hét");
define("CHBLAN_26", "Egy hónap");
define("CHBLAN_27", "- Összes üzenet törlése -");
define("CHBLAN_28", "Karbantartás befejezve");

define("CHBLAN_29", "Chatbox megjelenítése gördítősávval");
define("CHBLAN_30", "Chatbox magassága");
define("CHBLAN_31", "Emotikonok megjelenítése");
define("CHBLAN_32", "Moderátor csoport");

define("CHBLAN_33", "Felhasználó számlálás újraszámítása");
define("CHBLAN_34", "Felhasználó üzenetek számlálásának újraszámítása");
define("CHBLAN_35", "Újraszámítás");

define("CHBLAN_36", "Chatbox megjelenítés beállításai");
define("CHBLAN_37", "Normál chatbox");
define("CHBLAN_38", "Javascript kód használata a dinamikus üzenet frissítéshez (AJAX)");

?>