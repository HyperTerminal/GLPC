<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("BANNER_MENU_L1", "Reklámok");
define("BANNER_MENU_L2", "Reklám menü beállításai elmentve");

//v.617
define("BANNER_MENU_L3", "Cím/fejléc");
define("BANNER_MENU_L4", "Kampány");
define("BANNER_MENU_L5", "Reklám Menü beállításai");
define("BANNER_MENU_L6", "a menüben megjelenítendő kampányok kiválasztása");
define("BANNER_MENU_L7", "jelenlegi kampányok");
define("BANNER_MENU_L8", "kiválasztott kampányok");
define("BANNER_MENU_L9", "kiválasztás törlése");
define("BANNER_MENU_L10", "hogyan jelenjenek meg a kiválasztott kampányok?");
define("BANNER_MENU_L11", "megjelenítés típusa ...");
define("BANNER_MENU_L12", "egy kampány egy egyszerű menüben");
define("BANNER_MENU_L13", "az összes kiválasztott kampány egy egyszerű menüben");
define("BANNER_MENU_L14", "az összes kiválasztott kampány külön menükben");
define("BANNER_MENU_L15", "hány banner legyen látható?");
define("BANNER_MENU_L16", "ez a beállítás csak 2 vagy 3 opciókkal lesz használható<br />ha kevesebb banner van, a maximális lehetséges mennyiség lesz használva.");
define("BANNER_MENU_L17", "mennyiség beállítása ...");
define("BANNER_MENU_L18", "Menü beállítások frissítése");

?>