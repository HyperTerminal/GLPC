<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("ONLINE_L1", "Vendégek: ");
define("ONLINE_L2", "Tagok: ");
define("ONLINE_L3", "Ezen a lapon: ");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Tagok");
define("ONLINE_L6", "legújabb");
define("TRACKING_MESSAGE", "Online felhasználó nyomkövetése letiltva, az engedélyezéshez katt [link=".e_ADMIN."users.php?options]ide[/link][br]");
?>