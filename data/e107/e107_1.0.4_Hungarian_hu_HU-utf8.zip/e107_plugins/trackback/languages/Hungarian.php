<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("TRACKBACK_L1", "Trackback beállítása");
define("TRACKBACK_L2", "Ez a plugin engedélyezi a trackback használatát a hír üzenetekben.");
define("TRACKBACK_L3", "Trackback telepítve és engedélyezve.");
define("TRACKBACK_L4", "Trackback beállítások elmentve.");
define("TRACKBACK_L5", "Be");
define("TRACKBACK_L6", "Ki");
define("TRACKBACK_L7", "Trackback aktiválása");
define("TRACKBACK_L8", "Trackback URL szöveg");
define("TRACKBACK_L9", "Beállítások mentése");
define("TRACKBACK_L10", "Trackback beállítások");
define("TRACKBACK_L11", "Trackback cím e hírhez:");

define("TRACKBACK_L12", "Nincsenek trackback-ek");
define("TRACKBACK_L13", "Trackback-ek moderálása");
define("TRACKBACK_L14", "Törlés");
define("TRACKBACK_L15", "Trackback-ek törölve.");

?>