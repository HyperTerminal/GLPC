<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("ONLINE_EL1", "vendég: ");
define("ONLINE_EL2", "tag: ");
define("ONLINE_EL3", "Ezen az oldalon: ");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Tagok");
define("ONLINE_EL6", "Legújabb tag");
define("ONLINE_EL7", "olvassa");

define("ONLINE_EL8", "legtöbb ");
define("ONLINE_EL9", "-");

define("ONLINE_TRACKING_MESSAGE", "Online felhasználók követése jelenleg kikapcsolva, ezt engedélyezheted [link=".e_ADMIN."users.php?options]itt[/link][br]");

?>