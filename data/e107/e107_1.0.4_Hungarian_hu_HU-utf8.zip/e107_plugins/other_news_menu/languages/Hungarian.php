<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("TD_MENU_L1", "Egyéb hírek");
define("TD_MENU_L2", "Egyéb hírek");

?>