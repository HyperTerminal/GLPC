<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------


define("BLOGCAL_L1", " hírei");
define("BLOGCAL_L2", "Archívum");

define("BLOGCAL_D1", "H");
define("BLOGCAL_D2", "K");
define("BLOGCAL_D3", "Sze");
define("BLOGCAL_D4", "Cs");
define("BLOGCAL_D5", "P");
define("BLOGCAL_D6", "Szo");
define("BLOGCAL_D7", "V");

define("BLOGCAL_M1", "január");
define("BLOGCAL_M2", "február");
define("BLOGCAL_M3", "március");
define("BLOGCAL_M4", "április");
define("BLOGCAL_M5", "május");
define("BLOGCAL_M6", "június");
define("BLOGCAL_M7", "július");
define("BLOGCAL_M8", "augusztus");
define("BLOGCAL_M9", "szeptember");
define("BLOGCAL_M10", "október");
define("BLOGCAL_M11", "november");
define("BLOGCAL_M12", "december");

define("BLOGCAL_1", "Hírek");

define("BLOGCAL_CONF1", "hónapok/sor");
define("BLOGCAL_CONF2", "Cellpadding");
define("BLOGCAL_CONF3", "Beállítások frissítése");
define("BLOGCAL_CONF4", "BlogCal menü beállítások");
define("BLOGCAL_CONF5", "Beállítások frissítve");

define("BLOGCAL_ARCHIV1", "Archívum kiválasztása");

?>