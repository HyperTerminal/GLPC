<?php
/*
+---------------------------------------------------------------+
|        e107 website system Hungarian Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/usertheme_menu/languages/Hungarian.php $
|        $Revision: 1.0 $
|        $Id: 2010/10/01 16:24:24 $
|        $Author: e107hungary.org team $
+---------------------------------------------------------------+
*/

define("LAN_UMENU_THEME_1", "Theme kiválasztás");
define("LAN_UMENU_THEME_2", "Theme kiválasztása");
define("LAN_UMENU_THEME_3", "felhasználók:");
define("LAN_UMENU_THEME_4", "Azon theme-k engedélyezése, melyeket a felhasználók kiválaszthatnak");
define("LAN_UMENU_THEME_5", "Frissítés");
define("LAN_UMENU_THEME_6", "A felhasználók rendelkezésére álló theme-k");
define("LAN_UMENU_THEME_7", "Csoport, amely theme-ket tud választani");


?>