<?php


define('LAN_ALT_2', 'A jelenlegi engedély típusa');
define('LAN_ALT_3', 'Alternatív hitelesítés típus választása');
define('LAN_ALT_4', 'Paraméterek beállítása a következő részére');
define('LAN_ALT_5', 'Engedélyezés paramétereinek beállítása');
define('LAN_ALT_6', 'Kapcsolat nem lehetséges');
define('LAN_ALT_7', 'Ha a kapcsolat az alternatív módszerhez nem lehetséges, akkor hogyan legyen alkalmazva?');
define('LAN_ALT_8', 'Felhasználó nem található');
define('LAN_ALT_9', 'Ha a Felhasználónév nem található az alternatív módszerhez, akkor hogyan legyen alkalmazva?');
define('LAN_ALT_10', 'Sikertelen bejelentkezés');
define('LAN_ALT_11', 'Használja az e107 user táblát');

define('LAN_ALT_PAGE', 'Alternatív hitelesítés');