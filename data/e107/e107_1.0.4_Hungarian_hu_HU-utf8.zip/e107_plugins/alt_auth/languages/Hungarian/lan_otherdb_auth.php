<?php

define('OTHERDB_LAN_1', 'Adatbázis típus:');
define('OTHERDB_LAN_2', 'Szerver:');
define('OTHERDB_LAN_3', 'Felhasználónév:');
define('OTHERDB_LAN_4', 'Jelszó:');
define('OTHERDB_LAN_5', 'Adatbázis');
define('OTHERDB_LAN_6', 'Tábla');
define('OTHERDB_LAN_7', 'Felhasználónév mező:');
define('OTHERDB_LAN_8', 'Jelszó mező:');
define('OTHERDB_LAN_9', 'Jelszó módszer:');
define('OTHERDB_LAN_10', 'Otherdb auth beállítása');
define('OTHERDB_LAN_11', '** A következő mezők nem szükségesek, ha e107 adatbázist használsz');