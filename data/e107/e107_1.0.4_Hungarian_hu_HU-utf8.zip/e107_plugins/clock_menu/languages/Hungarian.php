<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define('CLOCK_MENU_L1', 'Beállítás elmentve');
define('CLOCK_MENU_L2', 'Cím/fejléc');
define('CLOCK_MENU_L3', 'Beállítás frissítése');
define('CLOCK_MENU_L4', 'Beállítás');
define('CLOCK_MENU_L5', 'hétfő');
define('CLOCK_MENU_L6', 'kedd');
define('CLOCK_MENU_L7', 'szerda');
define('CLOCK_MENU_L8', 'csütörtök');
define('CLOCK_MENU_L9', 'péntek');
define('CLOCK_MENU_L10', 'szombat');
define('CLOCK_MENU_L11', 'vasárnap');
define('CLOCK_MENU_L12', 'január');
define('CLOCK_MENU_L13', 'február');
define('CLOCK_MENU_L14', 'március');
define('CLOCK_MENU_L15', 'április');
define('CLOCK_MENU_L16', 'május');
define('CLOCK_MENU_L17', 'június');
define('CLOCK_MENU_L18', 'július');
define('CLOCK_MENU_L19', 'augusztus');
define('CLOCK_MENU_L20', 'szeptember');
define('CLOCK_MENU_L21', 'október');
define('CLOCK_MENU_L22', 'november');
define('CLOCK_MENU_L23', 'december');
define('CLOCK_MENU_L24', '');
?>