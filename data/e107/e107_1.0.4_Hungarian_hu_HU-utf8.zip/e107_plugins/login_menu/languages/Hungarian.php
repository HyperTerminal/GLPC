<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("LOGIN_MENU_L1", "Felhasználónév: ");
define("LOGIN_MENU_L2", "Jelszó: ");
define("LOGIN_MENU_L3", "Regisztráció");
define("LOGIN_MENU_L4", "Elfelejtett jelszó?");
define("LOGIN_MENU_L5", "Üdvözlet");
define("LOGIN_MENU_L6", "Adatok megjegyzése");
define("LOGIN_MENU_L7", "Egyedi azonosító nem felismerhető (valószínűleg hibás cookie).<br /><a href=\"".e_BASE."index.php?logout\">Kattints ide</a> a cookie megsemmisítéséhez.");
define("LOGIN_MENU_L8", "Kijelentkezés");
define("LOGIN_MENU_L9", "Bejelentkezési hiba");
define("LOGIN_MENU_L10", "Karbantartás üzemmód bekapcsolva - A normál felhasználók csak a sitedown.php -t érhetik el. Kikapcsolható az admin részlegben");
define("LOGIN_MENU_L11", "Admin");
define("LOGIN_MENU_L12", "Beállítások");
define("LOGIN_MENU_L13", "Profil");
define("LOGIN_MENU_L14", "új hír");
define("LOGIN_MENU_L15", "új hír");
define("LOGIN_MENU_L16", "új chatbox üzenet");
define("LOGIN_MENU_L17", "új chatbox üzenet");
define("LOGIN_MENU_L18", "új hozzászólás");
define("LOGIN_MENU_L19", "új hozzászólás");
define("LOGIN_MENU_L20", "új fórum üzenet");
define("LOGIN_MENU_L21", "új fórum üzenet");
define("LOGIN_MENU_L22", "új tag");
define("LOGIN_MENU_L23", "új tag");
define("LOGIN_MENU_L24", "Kattints ide a listához");
define("LOGIN_MENU_L25", "Utolsó látogatásod óta");
define("LOGIN_MENU_L26", "nincs");
define("LOGIN_MENU_L27", "és");
define("LOGIN_MENU_L28", "Belépés");

define("LOGIN_MENU_L29", "új cikk");
define("LOGIN_MENU_L30", "új cikk");

// New config options
define('LOGIN_MENU_L31', 'Új hírek számának mutatása');
define('LOGIN_MENU_L32', 'Új cikkek számának mutatása');
define('LOGIN_MENU_L33', 'Új chatbox üzenetek számának mutatása');
define('LOGIN_MENU_L34', 'Új hozzászólások számának mutatása');
define('LOGIN_MENU_L35', 'Új fórumüzenetek számának mutatása');
define('LOGIN_MENU_L36', 'Új tagok számának mutatása');


define('LOGIN_MENU_L39', 'Admin elhagyása');
define("LOGIN_MENU_L40", "Aktiváló Email Újraküldése");
define("LOGIN_MENU_L41", "Login Menü Beállítások");

?>