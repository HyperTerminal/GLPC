<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 12053 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("ADSTAT_ON", "Be");
define("ADSTAT_OFF", "Ki");
define("ADSTAT_L1", "A plugin minden látogatást naplózni fog, és részletes statisztikákat ad az összegyűjtött információk alapján.");
define("ADSTAT_L2", "A statisztika naplózó telepítve. Az aktiváláshoz lépj a beállításokhoz és kattints az Aktiválás-ra.<br /><b>Az e107_plugins/log/logs mappa jogosultsága 777 legyen! (chmod 777)</b>");
define("ADSTAT_L3", "Statisztika naplózás");
define("ADSTAT_L4", "Statisztika naplózás aktiválása");
define("ADSTAT_L5", "Statisztika típusok");
define("ADSTAT_L6", "Böngészők");
define("ADSTAT_L7", "Operációs rendszerek");
define("ADSTAT_L8", "Felbontás / színmélység");
define("ADSTAT_L9", "Látogató ország / domain");
define("ADSTAT_L10", "Utalások");
define("ADSTAT_L11", "Keresőszavak");
define("ADSTAT_L12", "Statisztikák törlése");
define("ADSTAT_L13", "Minden statisztika törlődni fog!");
define("ADSTAT_L14", "Oldal számlálók");
define("ADSTAT_L15", "Statisztika beállítások frissítése");
define("ADSTAT_L16", "Statisztika beállítások");
define("ADSTAT_L17", "Statisztika beállítások frissítve");
define("ADSTAT_L18", "A statisztika oldalt elérhetik ...");
define("ADSTAT_L19", "Előző látogatók");
define("ADSTAT_L20", "Admin látogatások számlálása");
define("ADSTAT_L21", "A statisztika oldalon megjelenített tételek maximális száma");
define("ADSTAT_L22", "Frissítés futtatása");
define("ADSTAT_L23", "Előző verzió statisztikai log-ot talált, frissítsd őket.");
define("ADSTAT_L24", "Lépj a frissítés oldalra");
define("ADSTAT_L25", "Kiválasztott statisztika nullázása");
define("ADSTAT_L26", "Meglévő oldal törlése");
define("ADSTAT_L27", "Ha a statisztika téves oldalt tartalmaz, itt törölheted azt.");
define("ADSTAT_L28", "Oldal megnyitása");
define("ADSTAT_L29", "Oldal neve");
define("ADSTAT_L30", "Jelöld be a törléshez");
define("ADSTAT_L31", "Kiválasztott oldal törlése");
define("ADSTAT_L32", "Oldal rendezése");
define("ADSTAT_L33", "Statisztika Loggolása - Beállítás");
define("ADSTAT_L34", "Oldal statisztika");
define("ADSTAT_L35", "Egységes böngésző info megtekintése a statisztikában");

define('ADSTAT_L38', "Az e107_plugins/log/logs mappának írhatónak kell lennie");	// Constant compatible with 0.8

?>