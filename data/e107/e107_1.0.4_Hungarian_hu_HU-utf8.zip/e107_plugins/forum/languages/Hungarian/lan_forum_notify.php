<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

// Forum Notify Types 
define('NT_LAN_FT_1', 'Fórum Események');
define('NT_LAN_FO_1', 'Fórum téma beküldve');
define('NT_LAN_MP_1', 'Fórumüzenet beküldve');
define('NT_LAN_FD_1', 'Fórum téma törölve');
define('NT_LAN_FP_1', 'Fórumüzenet törölve');
define('NT_LAN_FM_1', 'Fórum téma áthelyezve');

// Forum thread posted
define('NT_LAN_FO_3', 'Fórum témát létrehozta');
define('NT_LAN_FO_4', 'Fórum neve');
define('NT_LAN_FO_5', 'Tárgy');
define('NT_LAN_FO_6', 'Üzenet');
define('NT_LAN_FO_7', 'Új fórum téma létrehozva');

// Forum message posted
define('NT_LAN_MP_3', 'Fórumüzenetet létrehozta');
define('NT_LAN_MP_4', 'Fórum neve');
define('NT_LAN_MP_6', 'Üzenet');
define('NT_LAN_MP_7', 'Új fórumüzenetet létrehozva');

// Forum thread deleted
define('NT_LAN_FD_3', 'Fórum témát létrehozta');
define('NT_LAN_FD_4', 'Fórum neve');
define('NT_LAN_FD_5', 'Tárgy');
define('NT_LAN_FD_6', 'Üzenet');
define('NT_LAN_FD_7', 'Fórum téma törölve');
define('NT_LAN_FD_8', 'Fórum témát törölte');

// Forum message deleted
define('NT_LAN_FP_3', 'Fórumüzenetet létrehozta');
define('NT_LAN_FP_4', 'Fórum neve');
define('NT_LAN_FP_6', 'Üzenet');
define('NT_LAN_FP_7', 'Fórumüzenet törölve');
define('NT_LAN_FP_8', 'Fórumüzenetet törölte');

// Forum thread moved
define('NT_LAN_FM_3', 'Fórum témát létrehozta');
define('NT_LAN_FM_4', 'Régi tárgy');
define('NT_LAN_FM_5', 'Új tárgy');
define('NT_LAN_FM_6', 'Régi (forrás) fórum név');
define('NT_LAN_FM_7', 'Új (cél) fórum név');
define('NT_LAN_FM_8', 'Fórum téma áthelyezve');
define('NT_LAN_FM_9', 'Fórum témát áthelyezte');

?>