<?php
/**
 * e107 website system - English Language file
 * 
 * Copyright (C) 2001-2002 Steve Dunstan (jalist@e107.org)
 * Copyright (C) 2008-2010 e107 Inc (e107.org)
 * 
 * Released under the terms and conditions of the GNU General Public License
 * (http://gnu.org).
 * 
 * $URL$
 * $Revision$
 * $Id$
 * $Author$
 */

# Install LANs
define('LAN_FORUM_INSTALL_01', 'Fórum');
define('LAN_FORUM_INSTALL_02', 'Ez a plugin egy teljes értékű fórum rendszer.');
define('LAN_FORUM_INSTALL_03', 'Fórum konfigurálása');
define('LAN_FORUM_INSTALL_04', 'A fórum most már telepítve van');
define('LAN_FORUM_INSTALL_05', 'Fórum frissítése sikeresen, most már verzió: %1$s');
define('LAN_FORUM_INSTALL_06', '[fórum]');
define('LAN_FORUM_INSTALL_07', '[több...]');

# Config LANs
define('FORLAN_5', 'Szavazás törölve');
define('FORLAN_6', 'Téma törölve');
define('FORLAN_7', 'Válaszok törölve');
define('FORLAN_8', 'Törlés visszavonva');
define('FORLAN_9', 'Téma áthelyezve');
define('FORLAN_10', 'Áthelyezés visszavonva');
define('FORLAN_11', 'Vissza a fórumokhoz');
define('FORLAN_12', 'Fórum beállítások');
define('FORLAN_13', 'Biztos, hogy törölni akarod ezt a szavazást?<br />Ha törlöd, <b><u>nem lehet</u></b> majd visszaállítani');
define('FORLAN_14', 'Mégse');
define('FORLAN_15', 'Hozzászólás törlése');
define('FORLAN_16', 'Szavazás törlése');
define('FORLAN_17', 'Írta:');
define('FORLAN_18', 'Biztos, hogy törölni akarod ezt');
define('FORLAN_19', 'a témát az összes hozzászólással együtt?');
define('FORLAN_20', 'a szavazás szintén törlésre kerül.');
define('FORLAN_21', 'Törlés után');
define('FORLAN_22', 'a hozzászólást?<br />Törlés után');
define('FORLAN_23', 'nem</u></b> állítható(k) vissza');
define('FORLAN_24', 'Téma áthelyezése az adott fórumba');
define('FORLAN_25', 'Téma áthelyezése');
define('FORLAN_26', 'Válasz törölve');
define('FORLAN_27', 'áthelyezve');
define('FORLAN_28', 'Nem lehet átnevezni a téma címét');
define('FORLAN_29', 'Hozzáad');
define('FORLAN_30', 'a címhez');
define('FORLAN_31', 'Átnevezés erre:');
define('FORLAN_32', 'Téma beállítások átnevezése:');