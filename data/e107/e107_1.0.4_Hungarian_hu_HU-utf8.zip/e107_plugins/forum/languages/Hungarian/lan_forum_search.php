<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("FOR_SCH_LAN_1", "Fórum");
define("FOR_SCH_LAN_2", "Fórum kiválasztása");
define("FOR_SCH_LAN_3", "Összes fórum");
define("FOR_SCH_LAN_4", "Teljes üzenet");
define("FOR_SCH_LAN_5", "Mint a téma része");

?>