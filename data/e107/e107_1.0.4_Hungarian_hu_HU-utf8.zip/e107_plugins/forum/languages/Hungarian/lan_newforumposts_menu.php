<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("NFP_1", "Az összes új üzenet elérhetetlen a te felhasználó csoportod számára, így nem lehet megjeleníteni egyiket sem.");
define("NFP_2", "Nincsenek üzenetek");
define("NFP_3", "Új fórumüzenetek menü beállítások elmentve");
define("NFP_4", "Címsor");
define("NFP_5", "Megjelenített üzenetek száma?");
define("NFP_6", "Megjelenített karakterek száma?");
define("NFP_7", "Túl hosszú üzenetek levágása?");
define("NFP_8", "Eredeti témák mutatása a menüben?");
define("NFP_9", "Menü beállítások frissítése");
define("NFP_10", "Új fórumüzenetek menü beállítása");
define("NFP_11", "Írta:");
define("NFP_12", "Megjelenő üzenetek maximális elavulása");
define("NFP_13", "Egy ritkán látogatott oldalon használj nullát; egy sűrűn látogatott oldalon a napokban beállított érték lecsökkenti az adatbázis időt");

?>