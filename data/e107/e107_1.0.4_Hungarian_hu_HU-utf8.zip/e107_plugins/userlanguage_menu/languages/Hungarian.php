<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("UTHEME_MENU_L1", "Nyelv beállítása");
define("UTHEME_MENU_L2", "Nyelv kiválasztása");
define("UTHEME_MENU_L3", "táblák");
?>