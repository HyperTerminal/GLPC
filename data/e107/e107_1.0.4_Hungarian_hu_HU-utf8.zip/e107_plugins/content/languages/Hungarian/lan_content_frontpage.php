<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("CONT_FP_1", "Tartalom kategória");
define("CONT_FP_2", "Főoldal");

?>