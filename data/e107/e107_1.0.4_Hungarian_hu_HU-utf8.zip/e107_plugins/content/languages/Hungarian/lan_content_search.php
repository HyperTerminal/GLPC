<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("CONT_SCH_LAN_1", "Tartalom");
define("CONT_SCH_LAN_2", "Összes Tartalom Kategória");
define("CONT_SCH_LAN_3", "Üzenetek az adott részben");
define("CONT_SCH_LAN_4", "-");

?>