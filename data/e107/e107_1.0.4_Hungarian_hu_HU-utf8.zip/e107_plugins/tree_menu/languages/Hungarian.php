<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("TREE_L1", "Tree (Fa) Menü Beállítása");
define("TREE_L2", "Tree (Fa) Menü beállítások frissítése");
define("TREE_L3", "Tree (Fa) Menü beállítások elmentve.");
define("TREE_L4", "Be");
define("TREE_L5", "Ki");
define("TREE_L6", "CSS class a nem megnyitható likek részére");
define("TREE_L7", "CSS class a megnyitható linkek részére");
define("TREE_L8", "CSS class a megnyitott linkek részére");
define("TREE_L9", "Használd a spacer class-t a fő linkek között");

?>