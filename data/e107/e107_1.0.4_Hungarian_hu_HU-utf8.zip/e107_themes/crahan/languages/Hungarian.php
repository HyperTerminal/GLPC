<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("LAN_THEME_1", "'CraHan' by <a href='http://e107.org' rel='external'>jalist</a>, based on the theme by CraHan at his homepage <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Hozzászólás kikapcsolva");
define("LAN_THEME_3", "Hozzászólás: ");
define("LAN_THEME_4", "Tovább ...");
define("LAN_THEME_5", "Trackback: ");
define("LAN_THEME_6", "Hozzászólást írta");


?>