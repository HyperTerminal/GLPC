<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("LAN_THEME_1", "'kubrick' by <a href='http://e107.org' title='e107.org' rel='external'>jalist</a> & <a href='http://e107themes.org' title='e107themes.org' rel='external'>Que</a>, Based on original theme by Michael Heilemann (<a href='http://binarybonsai.com/kubrick/' title='http://binarybonsai.com/kubrick/' rel='external'>http://binarybonsai.com/kubrick/</a>. ).");
define("LAN_THEME_2", "Hozzászólás kikapcsolva");
define("LAN_THEME_3", "Hozzászólás: ");
define("LAN_THEME_4", "Tovább ...");
define("LAN_THEME_5", "Trackback: ");
define("LAN_THEME_6", "-");
define("LAN_THEME_7", "Beküldte: ");


?>