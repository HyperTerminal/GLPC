<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("LAN_THEME_1", "Hozzászólás: ");
define("LAN_THEME_2", "Hozzászólás kikapcsolva");
define("LAN_THEME_3", "Tovább...");
define("LAN_THEME_4", "Írta");
define("LAN_THEME_5", "-");
define("LAN_THEME_6", "e107.v4 theme by <a href='http://e107.org' rel='external'>jalist</a>");

?>