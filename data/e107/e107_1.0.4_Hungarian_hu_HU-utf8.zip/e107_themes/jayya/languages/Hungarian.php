<?php

# --------------------------------------------------------------------------

# e107 Hungarian language file - $Revision: 11678 $ - $Author: e107hungary.org team $ - $Date: 2010 $

# --------------------------------------------------------------------------

define("LAN_THEME_1", "Hozzászólás kikapcsolva");
define("LAN_THEME_2", "Hozzászólás: ");
define("LAN_THEME_3", "Tovább...");
define("LAN_THEME_4", "Trackback: ");
define("LAN_THEME_5", "Írta");
define("LAN_THEME_6", "-");


?>