<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_sitedown.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:59:53 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/
define("PAGE_NAME", "Stránka je momentálně mimo provoz");
define("LAN_SITEDOWN_00", "je momentálně mimo provoz");
define("LAN_SITEDOWN_01", "V tuto chvíli je stránka pro veřejnost uzavřena. Hlavní administrátor stránek provádí nutnou údržbu a optimalizaci pro bezproblémový chod webu. Vraťte se prosím za chvíli, web bude opět otevřena. Děkujeme Vám za pochopení a těšíme se na Vaší návštěvu.");


?>