<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_banner.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:53:15 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Banner");
define("BANNERLAN_16", "Uživatelské jméno:");
define("BANNERLAN_17", "Heslo:");
define("BANNERLAN_18", "Pokračovat");
define("BANNERLAN_19", "Pro pokračování prosím vložte vaše uživatelské jméno a heslo.");
define("BANNERLAN_20", "Omlouváme se, údaje nebyly v databázi nalezeny. Kontaktujte administrátora stránek.");
define("BANNERLAN_21", "Statistiky bannerů");
define("BANNERLAN_22", "Klient");
define("BANNERLAN_23", "ID banneru");
define("BANNERLAN_24", "Počet kliknutí");
define("BANNERLAN_25", "Kliknutí v  %");
define("BANNERLAN_26", "Zobrazení");
define("BANNERLAN_27", "Zakoupených zobrazení");
define("BANNERLAN_28", "Zbývá zobrazení");
define("BANNERLAN_29", "Žádné bannery");
define("BANNERLAN_30", "Bez limitu");
define("BANNERLAN_31", "Nelze aplikovat");
define("BANNERLAN_32", "Ano");
define("BANNERLAN_33", "Ne");
define("BANNERLAN_34", "Ukončení:");
define("BANNERLAN_35", "IP adresy prokliků");
define("BANNERLAN_36", "Aktivní:");
define("BANNERLAN_37", "Začátek:");
define("BANNERLAN_38", "Chyba");


?>