<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_userposts.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 09:03:14 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Uživatelovy příspěvky");
define("UP_LAN_0", "Příspěvky do fóra od");
define("UP_LAN_1", "Komentáře od");
define("UP_LAN_2", "Téma");
define("UP_LAN_3", "Zobrazení");
define("UP_LAN_4", "Odpovědí");
define("UP_LAN_5", "Poslední příspěvek");
define("UP_LAN_6", "Témata");
define("UP_LAN_7", "Bez komentářů");
define("UP_LAN_8", "Bez příspěvků");
define("UP_LAN_9", " v/na");
define("UP_LAN_10", "Re");
define("UP_LAN_11", "Zasláno");
define("UP_LAN_12", "Hledat");
define("UP_LAN_13", "Komentář");
define("UP_LAN_14", "Příspěvků na fóru");
define("UP_LAN_15", "Re");
define("UP_LAN_16", "IP adresa");


?>