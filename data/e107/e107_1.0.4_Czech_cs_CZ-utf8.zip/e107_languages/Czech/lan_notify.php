<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_notify.php $
|        $Revision: 1.0.2 rc1 $
|        $Id: 2012/07/28 08:12:59 $
|        $Author: Oxigen $
|        $Web: www.e107.funsite.cz $
+---------------------------------------------------------------+
*/

define("NT_LAN_US_1", "Registrace uživatele");
define("NT_LAN_UV_1", "Registrace uživatele potvrzena");
define("NT_LAN_UV_2", "ID:");
define("NT_LAN_UV_3", "Přihlašovací jméno:");
define("NT_LAN_UV_4", "IP Adresa:");
define("NT_LAN_LI_1", "Uživatel přihlášen");
define("NT_LAN_LO_1", "Uživatel odhlášen");
define("NT_LAN_LO_2", " odhlášen z webu.");
define("NT_LAN_FL_1", "DoS Ban");
define("NT_LAN_FL_2", "IP adresa zabanována pro pokus o DoS útok");
define("NT_LAN_SN_1", "Novinka vložena");
define("NT_LAN_NU_1", "Aktualizováno");
define("NT_LAN_ND_1", "Novinka smazána");
define("NT_LAN_ND_2", "ID smazané novinky");
define("NT_LAN_CM_1", "Komentáře čekající na schválení");


?>