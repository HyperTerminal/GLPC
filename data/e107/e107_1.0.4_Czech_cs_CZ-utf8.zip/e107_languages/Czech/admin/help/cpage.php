<?php
//Jaa(c) - korektura 21.9.2008, preklad www.e107.cz Team 
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/help/cpage.php,v $
|     $Revision: 1.5 $
|     $Date: 2007/11/06 20:08:19 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$text = "Zde můžete vytvářet, spravovat, nebo mazat vlastní menu a stránky.<br /><br />";
// $text .= "Prosím navštivte <a href='http://docs.e107.org/Using Custom Pages and Custom Menus'>http://docs.e107.org/Using Custom Pages and Custom Menus</a> pro vysvětlení všech těchto vlastností.";

$ns -> tablerender('Nápověda - Vlastní menu/stránky', $text);
?>
