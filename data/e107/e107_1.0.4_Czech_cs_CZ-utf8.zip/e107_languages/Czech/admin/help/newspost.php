<?php
//Jaa(c) - korektura 21.9.2008, preklad www.e107.cz Team 
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/help/newspost.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/08/27 02:24:45 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/

if (!defined('e107_INIT')) { exit; }

$caption = "Nápověda - Novinky";
$text = "Zde se s širokou řadou různých možností v nastavení vytváří a spravují zprávy a kategorie novinek.
Dále je tu pak možné nastavovat přístupová práva pro vytváření a úpravy zpráv, nebo nastavit styl psaní a jiné další bližší možnosti nastavení.
";
$ns -> tablerender($caption, $text);
?>
