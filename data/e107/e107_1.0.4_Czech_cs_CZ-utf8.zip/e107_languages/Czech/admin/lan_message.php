<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_message.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/08 21:33:07 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("MESSLAN_1", "Přijaté zprávy");
define("MESSLAN_2", "Smazat zprávu");
define("MESSLAN_3", "Zpráva smazána.");
define("MESSLAN_4", "Smazat všechny zprávy");
define("MESSLAN_5", "Potvrdit");
define("MESSLAN_6", "Všechny zprávy smazány.");
define("MESSLAN_7", "Žádné zprávy.");
define("MESSLAN_8", "Typ zprávy");
define("MESSLAN_9", "Nahlášeno");
define("MESSLAN_10", "Předmět");
define("MESSLAN_11", "otevřít v novém okně");
define("MESSLAN_12", "Zpráva");
define("MESSLAN_13", "Odkaz");


?>