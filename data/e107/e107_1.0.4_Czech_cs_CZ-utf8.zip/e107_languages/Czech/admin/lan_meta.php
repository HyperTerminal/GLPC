<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_meta.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/06/07 05:04:58 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("METLAN_1", "Meta značky aktualizovány v databázi");
define("METLAN_2", "Vložte další meta značky:");
define("METLAN_3", "Uložit");
define("METLAN_4", "Aktualizováno");
define("METLAN_5", "zde zadejte svůj popis");
define("METLAN_6", "zde, zadejte, seznam, klíčových, slov, oddělených, čárkou");
define("METLAN_7", "informace o copyrightu");
define("METLAN_8", "Meta značky");
define("METLAN_9", "Popis");
define("METLAN_10", "Klíčová slova");
define("METLAN_11", "Copyright");
define("METLAN_12", "Používat název novinky a její souhrn jako meta-popis na novinkových stránkách.");
define("METLAN_13", "Autor");


?>