<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_header.php,v $
|     $Revision: 1.4 $
|     $Date: 2008/05/11 02:24:44 $
|     $Author: mcfly_e107 - translate en to cz - dubas $
+----------------------------------------------------------------------------+
*/
define("LAN_head_1", "Navigace administrátora");
define("LAN_head_2", "Server nepodporuje zaslání souboru přes HTTP (http upload), uživatelé nebudou moci posílat soubory, avatary a další. Změnit nastavení můžete v php.ini v direktivě file_uploads. Nezapomeňte restartovat server. Pokud nemáte přístup k php.ini, spojte se s administrátorem serveru.");
define("LAN_head_3", "Server má nastavené restrikce basedir, což znamená, že nelze použít žádný soubor mimo základní adresář webu a může ovlivnit chování některých skriptů, např. správce souborů e107.");
define("LAN_head_4", "Administrace");
define("LAN_head_5", "jazyk použitý v administraci:");
define("LAN_head_6", "Informace o doplňcích");


?>