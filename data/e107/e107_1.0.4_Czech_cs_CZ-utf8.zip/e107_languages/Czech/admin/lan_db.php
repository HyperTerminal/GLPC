<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_db.php,v $
|     $Revision: 1.7 $
|     $Date: 2007/02/14 21:17:42 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Nastavení jádra uloženo v databázi.");
define("DBLAN_2", "Kliknutím na tlačítko uložíte zálohu vaší databáze");
define("DBLAN_3", "Zálohovat SQL databázi");
define("DBLAN_4", "Kliknutím na tlačítko ověříte správnost vaší e107 databáze");
define("DBLAN_5", "Zkontrolovat správnost databáze");
define("DBLAN_6", "Kliknutím na tlačítko optimalizujete vaší e107 databázi");
define("DBLAN_7", "Optimalizovat SQL databázi");
define("DBLAN_8", "Kliknutím na tlačítko zazálohujete nastavení jádra");
define("DBLAN_9", "Zálohovat jádro");
define("DBLAN_10", "Nástroje databáze");
define("DBLAN_11", "MySQL databáze");
define("DBLAN_12", "optimalizováno");
define("DBLAN_13", "Zpět");
define("DBLAN_14", "Hotovo");
define("DBLAN_15", "Kliknutím na tlačítko zkontrolujete dostupnost aktualizací databáze");
define("DBLAN_16", "Zkontrolovat aktualizace");
define("DBLAN_17", "Pref. jméno");
define("DBLAN_18", "Pref. hodnota");
define("DBLAN_19", "Kliknutím na tlačítko otevřete editor předvoleb (pouze pro zkušené uživatele)");
define("DBLAN_20", "Editor předvoleb");
define("DBLAN_21", "Smazat označené");
define("DBLAN_22", "Doplněk: Zobrazit a prohlédnout");
define("DBLAN_23", "Prohlídka dokončena");
define("DBLAN_24", "Jméno");
define("DBLAN_25", "Složka");
define("DBLAN_26", "Přiložené doplňky");
define("DBLAN_27", "Nainstalováno");
define("DBLAN_28", "Kliknutím na tlačítko vyhledáte změny ve složkách doplňků");
define("DBLAN_29", "Vyhledat změny");
define("DBLAN_30", " (Pokud doplněk zobrazí chybu, zkontrolujte znaky mimo otevírací a uzavírací PHP tagy)");
define("DBLAN_31", "Prošlo");
define("DBLAN_32", "Chyba");
define("DBLAN_33", "Nepřístupné");
define("DBLAN_34", "Nezkontrolováno");
define("DBLAN_35", "Klepnutím na tlačítko se zkontroluje platnost uživatelské tabulky");
define("DBLAN_36", "Zkontrolovat uživatelské tabulky");


?>