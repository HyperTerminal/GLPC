<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/admin/lan_cache.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/09 21:43:50 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("CACLAN_1", "Status systémové vyrovnávací paměti");
define("CACLAN_2", "Nastavit vyrovnávací paměť");
define("CACLAN_3", "Vyrovnávací paměť systému");
define("CACLAN_4", "Nastavení stav cache");
define("CACLAN_5", "Vyprázdnit vy\rovnávací paměť");
define("CACLAN_6", "Vyrovnávací paměť vyprázdněna");
define("CACLAN_7", "Vyrvnávací paměť vypnuta");
define("CACLAN_9", "Data paměti ukládat do souboru na disk");
define("CACLAN_10", "Složka k ukládání vyrvnávací paměti není zapisovatelná. Prosím ujistěte se zda má složka CHMOD nastavený na hodnotu 0777");


?>