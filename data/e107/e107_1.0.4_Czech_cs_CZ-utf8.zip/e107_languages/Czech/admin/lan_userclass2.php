<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/admin/lan_userclass2.php $
|        $Revision: 1.0 $
|        $Id: 2011/08/14 08:05:25 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("UCSLAN_1", "Všichni uživatelé byly ze skupiny odstraněni.");
define("UCSLAN_2", "Uživatelská skupina byla upravena.");
define("UCSLAN_3", "Smazat skupinu.");
define("UCSLAN_4", "Pro smazání, zaškrtněte potvrzující políčko");
define("UCSLAN_5", "Skupina byla upravena.");
define("UCSLAN_6", "Skupina byla uložena do databáze.");
define("UCSLAN_7", "Žádná skupina ještě nebyla vytvořena.");
define("UCSLAN_8", "Uživatelské skupiny");
define("UCSLAN_11", "pro potvrzení zaškrtni");
define("UCSLAN_12", "Název skupiny");
define("UCSLAN_13", "Popis skupiny");
define("UCSLAN_14", "Uložit údaje");
define("UCSLAN_15", "Vytvořit novou skupinu");
define("UCSLAN_16", "Přidání uživatelů do skupiny");
define("UCSLAN_17", "Odstranit");
define("UCSLAN_18", "Vyprázdnit skupinu");
define("UCSLAN_19", "Přidat uživatele do");
define("UCSLAN_20", "skupiny");
define("UCSLAN_21", "Nastavení uživatelské skupiny");
define("UCSLAN_22", "Uživatelé<br/>- pro přesunutí, klikněte...");
define("UCSLAN_23", "Uživatelé ve skupině");
define("UCSLAN_24", "Skupinu spravuje");
define("UCSLAN_25", "ID");
define("UCSLAN_26", " Uživstelské jméno");
define("UCSLAN_27", "Zpět");


?>