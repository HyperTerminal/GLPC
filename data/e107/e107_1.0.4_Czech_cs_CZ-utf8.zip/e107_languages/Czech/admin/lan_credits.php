<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_credits.php,v $
|     $Revision: 1.5 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "e107 Titulky");
define("CRELAN_1", "Titulky");
define("CRELAN_2", "Zde je seznam softwaru a zdrojů třetích stran použitých v e107. Tým vývojářů e107 tímto děkuje vývojářům následujících softwarů a zdrojů za to, že povolili distribuovat jejich kód v e107 pod licencí GPL.");
define("CRELAN_3", "všechna práva vyhrazena");
define("CRELAN_4", "Zobrazit tým vývojářů e107");
define("CRELAN_5", "Scripty třetích stran");
define("CRELAN_6", "e107 v0.7 vám přináší ...");
define("CRELAN_7", "verze");
define("CRELAN_8", "povolení přiděleno");
define("CRELAN_9", "Licence");
define("CRELAN_10", "MagpieRSS nabízí RSS parser v PHP na bázi XML (expat) .");
define("CRELAN_11", "Knihovna PclZip nabízí funkce pro kompresi a extrakci archivů ve formátu ZIP (WinZip, PKZIP).");
define("CRELAN_12", "PclTar nabízí schopnost archivovat seznam souborů nebo složek s nebo bez komprese. Archivy vytvořené pomocí PclTar lze číst pomocí většiny gzip/tar aplikací a pomocí Windows aplikace WinZip.");
define("CRELAN_13", "TinyMCE je Javascriptový HTML WYSIWYG editor nezávislý na platformě, který je uvolněn jako Open Source původ LGPL od Moxiecode Systems AB. Má schopnost převést pole HTML TEXTAREA nebo jiné HTML elementy do instance editoru.");
define("CRELAN_14", "Ikony použité v e107");
define("CRELAN_15", "Plně funkční třída pro PHP pro email transfer.");
define("CRELAN_16", "Systém menu použitý ve vzhledu Jayya");
define("CRELAN_17", "Kalendář s vyskakovacími okny");
define("CRELAN_18", "Podpora PDF");
define("CRELAN_19", "Podpora UTF-8 PDF");
define("CRELAN_20", "");
define("CRELAN_21", "Always a pressure..err..pleasure!");
define("CRELAN_22", "\"MTVhNjMyZDgxN2QwM2Q3ZTI<br />5ODM2NDU3YWI0ZjM1NGILJT<br />yarrrrrr! wtf matey!\"");
define("CRELAN_23", "");
define("CRELAN_24", "");
define("CRELAN_25", "");
define("CRELAN_26", "");
define("CRELAN_27", "\"Wot? No tea?? 0_0\"");
define("CRELAN_28", "");
define("CRELAN_29", "Vzhůru a směrem dopředu!");
define("CRELAN_30", "");


?>