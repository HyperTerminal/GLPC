<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_admin_log.php,v $
|     $Revision: 1.1 $
|     $Date: 2006/06/05 20:02:15 $
|     $Author: lisa_ 
+----------------------------------------------------------------------------+
*/
define("LAN_ADMINLOG_0", "Záznamy admina (log)");
define("LAN_ADMINLOG_1", "Datum");
define("LAN_ADMINLOG_2", "Nadpis");
define("LAN_ADMINLOG_3", "Popis");
define("LAN_ADMINLOG_4", "IP uživatel");
define("LAN_ADMINLOG_5", "ID uživatele");
define("LAN_ADMINLOG_6", "Informační ikona");
define("LAN_ADMINLOG_7", "Informační zpráva");
define("LAN_ADMINLOG_8", "Upozorňovací ikona");
define("LAN_ADMINLOG_9", "Upozorňovací zpráva");
define("LAN_ADMINLOG_10", "Varující ikona");
define("LAN_ADMINLOG_11", "Varující zpráva");
define("LAN_ADMINLOG_12", "Ikona závažné chyby");
define("LAN_ADMINLOG_13", "Zpráva o závažné chybě");


?>