<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_emoticon.php,v $
|     $Revision: 1.11 $
|     $Date: 2008/05/07 19:45:31 $
|     $Author: e107steved - translate en to cz - dubas $
+----------------------------------------------------------------------------+
*/
define("EMOLAN_1", "Zapnutí emotikonů");
define("EMOLAN_2", "Jméno");
define("EMOLAN_3", "Emotikony");
define("EMOLAN_4", "Zapnout emotikony?");
define("EMOLAN_5", "Obrázek");
define("EMOLAN_6", "Kód");
define("EMOLAN_7", "víc položek oddělujte mezerami");
define("EMOLAN_8", "Stav");
define("EMOLAN_9", "Možnosti");
define("EMOLAN_10", "Aktivní");
define("EMOLAN_11", "Aktivuj balík");
define("EMOLAN_12", "Změnit / nastavit balík");
define("EMOLAN_13", "Instalované balíky");
define("EMOLAN_14", "Uložit nastavení");
define("EMOLAN_15", "Změnit / konfigurovat emotikony");
define("EMOLAN_16", "Nastavení emotikonů bylo uloženo");
define("EMOLAN_17", "Tenhle balík smajlíků obsahuje mezery, a není povolen.");
define("EMOLAN_18", "přejmenujte prosím výskyty uvedené níže tak, aby neobsahovaly mezery:");
define("EMOLAN_19", "Jméno");
define("EMOLAN_20", "Lokace");
define("EMOLAN_21", "Chyba");
define("EMOLAN_22", "Našel jsem nový balík s emotikony:");
define("EMOLAN_23", "Našel jsem nový xml balík s emotikony:");
define("EMOLAN_24", "Našel jsem nové php s emotikony:");
define("EMOLAN_25", "Instalování PHP emotikonů:");
define("EMOLAN_26", "Znovu prohledat balíček");
define("EMOLAN_27", "Během zpracování balíčku nastala chyba:");
define("EMOLAN_28", "Vygenerovat XML");
define("EMOLAN_29", "XML  soubor vygenerován:");
define("EMOLAN_30", "Chyba při zápisu XML souboru:");


?>