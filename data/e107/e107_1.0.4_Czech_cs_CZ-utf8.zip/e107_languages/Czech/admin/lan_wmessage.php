<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_wmessage.php,v $
|     $Revision: 1.10 $
|     $Date: 2006/04/22 19:30:47 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("WMLAN_00", "Uvítací zprávy");
define("WMLAN_01", "Vytvořit novou zprávu");
define("WMLAN_02", "Zpráva");
define("WMLAN_03", "Zobrazováno");
define("WMLAN_04", "Text zprávy");
define("WMLAN_05", "Orámovat");
define("WMLAN_06", "Při zaškrtnutí se budou zprávy zobrazovat orámované");
define("WMLAN_07", "Obejít standardní systém, aby použil {WMESSAGE} zkrácený kód:");
define("WMLAN_09", "Žádná uvítací zpráva ještě nebyla vytvořena");
define("WMLAN_10", "Označení zprávy");


?>