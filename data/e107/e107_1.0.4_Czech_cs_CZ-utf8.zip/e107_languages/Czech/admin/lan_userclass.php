<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_userclass.php,v $
|     $Revision: 1.2 $
|     $Date: 2004/10/03 15:57:25 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("UCSLAN_1", "Odeslán e-mail s upozorněním pro");
define("UCSLAN_2", "Práva upravena");
define("UCSLAN_3", "Vážený");
define("UCSLAN_4", "Vaše práva byla upravena");
define("UCSLAN_5", "Nyní máte přístup k těmto sekcím");
define("UCSLAN_6", "Nastavit uživatelskou skupinu uživatele");
define("UCSLAN_7", "Uložit nastavení");
define("UCSLAN_8", "Upozornit uživatele");
define("UCSLAN_9", "Uživatelské skupiny byly upraveny.");
define("UCSLAN_10", "S pozdravem,");
define("UCSLAN_12", "Uživatelská práva pouze");


?>