<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_db_verify.php,v $
|     $Revision: 1.4 $
|     $Date: 2008/05/08 18:53:04 $
|     $Author: e107steved - translate en to cz - dubas $
+----------------------------------------------------------------------------+
*/
define("DBLAN_1", "Nelze načíst soubor sql<br /><br />Ujistěte se, že soubor <b>core_sql.php</b> existuje v adresáři<b>/admin/sql</b>.");
define("DBLAN_2", "Ověřuji vše");
define("DBLAN_4", "Tabulka");
define("DBLAN_5", "Pole");
define("DBLAN_6", "Stav");
define("DBLAN_7", "Poznámky");
define("DBLAN_8", "Nesouhlasí");
define("DBLAN_9", "Aktuálně");
define("DBLAN_10", "by mělo být");
define("DBLAN_11", "Chybějící pole");
define("DBLAN_12", "Extra pole!");
define("DBLAN_13", "Chybějící tabulka!");
define("DBLAN_14", "Vyberte tabulky ke kontrole");
define("DBLAN_15", "Spustit ověření");
define("DBLAN_16", "Ověřování SQL");
define("DBLAN_17", "Zpět");
define("DBLAN_18", "tabulky");
define("DBLAN_19", "Pokusit se opravit");
define("DBLAN_20", "Pokouším se opravit tabulky");
define("DBLAN_21", "Opravit vybrané položky");
define("DBLAN_22", " není čitelný");


?>