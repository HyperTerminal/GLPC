<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_lancheck.php,v $
|     $Revision: 1.7 $
|     $Date: 2006/11/05 03:50:19 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("LAN_CHECK_1", "Zkontrolovat/Upravit jazykové soubory");
define("LAN_CHECK_2", "Začít kontrolu");
define("LAN_CHECK_3", "Kontrola souboru");
define("LAN_CHECK_4", "Soubor nenalezen!");
define("LAN_CHECK_5", "Text nenalezen!");
define("LAN_CHECK_7", "fráze");
define("LAN_CHECK_8", "Soubor chybí...");
define("LAN_CHECK_9", " souborů chybí...");
define("LAN_CHECK_10", "Závažná chyba:");
define("LAN_CHECK_11", "Žádný soubor nechybí!");
define("LAN_CHECK_12", "Soubor je chybný...");
define("LAN_CHECK_13", " souborů je chybných...");
define("LAN_CHECK_14", "Všechny soubory jsou v pořádku!");
define("LAN_CHECK_15", "Byly nalezeny zakázané znaky před značkou '<?php'");
define("LAN_CHECK_16", "Původní soubor");
define("LAN_CHECK_17", "Při ukládání souboru došlo k chybě.");
define("LAN_CHECK_18", "Jazykové soubory ve standardním formátu nebyly pro tento doplněk/vzhled nalezeny.");
define("LAN_CHECK_19", "Byly nalezeny znaky nepatřící do kódování UTF-8!!");
define("LAN_CHECK_20", "Vytvořit jazykový balíček");
define("LAN_CHECK_21", "Ověřit znovu");
define("LAN_CHECK_22", "Vzhled");
define("LAN_CHECK_23", "Nalezené chyby");
define("LAN_CHECK_24", "Přehled");
define("LAN_CHECK_25", "Vzhledy");
define("LAN_CHECK_26", "Soubor");


?>