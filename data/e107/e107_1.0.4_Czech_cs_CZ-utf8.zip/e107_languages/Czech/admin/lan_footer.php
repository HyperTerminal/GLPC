<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_footer.php,v $
|     $Revision: 1.4 $
|     $Date: 2008/05/08 17:45:38 $
|     $Author: e107steved - translate en to cz - dubas $
+----------------------------------------------------------------------------+
*/
define("FOOTLAN_1", "Web");
define("FOOTLAN_2", "Hlavní Admin");
define("FOOTLAN_3", "Verze");
define("FOOTLAN_4", "sestavení");
define("FOOTLAN_5", "Vzhled administrace");
define("FOOTLAN_6", "od");
define("FOOTLAN_7", "Info");
define("FOOTLAN_8", "Datum instalace");
define("FOOTLAN_9", "Server");
define("FOOTLAN_10", "host");
define("FOOTLAN_11", "PHP Verze");
define("FOOTLAN_12", "MySQL");
define("FOOTLAN_13", "Info webu");
define("FOOTLAN_14", "Ukaž dokumentaci");
define("FOOTLAN_15", "Dokumentace");
define("FOOTLAN_16", "Databáze");
define("FOOTLAN_17", "Znaková sada");
define("FOOTLAN_18", "Téma webu");
define("FOOTLAN_19", "Aktuální čas serveru");
define("FOOTLAN_20", "Stupeň zabezpečení");


?>