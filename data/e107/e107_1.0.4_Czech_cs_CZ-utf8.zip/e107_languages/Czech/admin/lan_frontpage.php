<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/admin/lan_frontpage.php $
|        $Revision: 1.0 $
|        $Id: 2013/02/16 12:04:40 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("FRTLAN_1", "Nastavení vstupní stránky bylo aktualizováno.");
define("FRTLAN_2", "Nastavit vstupní stránku pro");
define("FRTLAN_6", "Odkazy");
define("FRTLAN_12", "Upravit nastavení vstupní stránky");
define("FRTLAN_13", "Nastavení vstupní stránky");
define("FRTLAN_15", "Jiné (vlož url):");
define("FRTLAN_16", "chyba: byl vybrán kategorie bez obsahu");
define("FRTLAN_17", "chyba: byla vybrána prázdná podkategorie");
define("FRTLAN_18", "chyba: vybrána prázdná položka");
define("FRTLAN_19", "Hlavní kategorie obsahu");
define("FRTLAN_20", "kategorie obsahu");
define("FRTLAN_21", "položka obsahu");
define("FRTLAN_22", "Vlastní stránka");
define("FRTLAN_26", "všichni uživatelé");
define("FRTLAN_27", "Hosté");
define("FRTLAN_28", "Členové");
define("FRTLAN_29", "Správci");
define("FRTLAN_31", "Všichni uživatelé");
define("FRTLAN_32", "Skupiny uživatelů");
define("FRTLAN_33", "Aktuální nastavení");
define("FRTLAN_34", "Strana");


?>