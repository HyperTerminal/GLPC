<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/admin/lan_fla.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/06/04 16:45:07 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("FLALAN_1", "Neúspěšné pokusy o přihlášení");
define("FLALAN_2", "Nezaznamenal jsem žádné neúspěšné pokusy o přihlášení");
define("FLALAN_3", "Pokus(y) smazán(y)");
define("FLALAN_4", "Uživatel se pokusil přihlásit s nesprávnou kombinací jména a hesla");
define("FLALAN_5", "blokované IP adresy");
define("FLALAN_6", "Datum");
define("FLALAN_7", "Data");
define("FLALAN_8", "IP adresa / host");
define("FLALAN_9", "Možnosti");
define("FLALAN_10", "Smazat / Blokovat zaškrtnuté položky");
define("FLALAN_11", "Označit vše - SMAZAT");
define("FLALAN_12", "Zrušit označení - SMAZAT");
define("FLALAN_13", "Vybrat vše - BLOKOVAT");
define("FLALAN_14", "Zrušit vše - BLOKOVAT");
define("FLALAN_15", "Následující IP adresy byly zablokované automaticky - uživatel provedl více než 10 neplatných pokusů o přihlášení");
define("FLALAN_16", "Vymazat seznam automatických blokací");
define("FLALAN_17", "Seznam adres zablokovaných automaticky byl smazán.");


?>