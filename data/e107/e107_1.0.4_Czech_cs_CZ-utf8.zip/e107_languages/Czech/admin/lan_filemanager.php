<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_filemanager.php,v $
|     $Revision: 1.6 $
|     $Date: 2008/05/08 23:35:15 $
|     $Author: e107coders - translate en to cz - dubas $
+----------------------------------------------------------------------------+
*/
define("FMLAN_1", "Nahrán");
define("FMLAN_2", "do");
define("FMLAN_3", "adresáře");
define("FMLAN_4", "Velikost souboru je větší než limit nastavený v php.ini.");
define("FMLAN_10", "Chyba");
define("FMLAN_12", "soubor");
define("FMLAN_13", "soubory");
define("FMLAN_14", "adresář");
define("FMLAN_15", "adresáře");
define("FMLAN_16", "Kořenový adresář");
define("FMLAN_17", "Jméno");
define("FMLAN_18", "Velikost");
define("FMLAN_19", "Poslední změna");
define("FMLAN_21", "Nahrát soubor do tohoto adresáře");
define("FMLAN_22", "Nahrát");
define("FMLAN_26", "Smazáno");
define("FMLAN_27", "úspěšně");
define("FMLAN_28", "Nelze smazat");
define("FMLAN_29", "Cesta");
define("FMLAN_30", "O úroveň výš");
define("FMLAN_31", "složka");
define("FMLAN_32", "Výběr adresáře");
define("FMLAN_33", "Vyberte");
define("FMLAN_34", "Výběr adresáře");
define("FMLAN_35", "Adresář souborů");
define("FMLAN_36", "Adresář uživatelských nabídek (menu)");
define("FMLAN_37", "Adresář uživatelských stránek");
define("FMLAN_38", "Soubor byl úspěšně přesunut do");
define("FMLAN_39", "Soubor nelze přesunout do");
define("FMLAN_40", "Adresář obrázků - novinek");
define("FMLAN_43", "Smazat vybrané soubory");
define("FMLAN_46", "Potvrďte prosím, že chcete smazat vybrané soubory.");
define("FMLAN_47", "Nahráno uživatelem");
define("FMLAN_48", "Přesunout vyznačené do");
define("FMLAN_49", "Potvrďte prosím přesun vybraných souborů.");
define("FMLAN_50", "Přesunout");
define("FMLAN_51", "Neidnetifikovaná chyba:");


?>