<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_cpage.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/06/22 17:08:01 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("CUSLAN_1", "Titulek");
define("CUSLAN_2", "Typ");
define("CUSLAN_3", "Nastavení");
define("CUSLAN_4", "Smazat tuto stránku?");
define("CUSLAN_5", "Současné stránky");
define("CUSLAN_7", "Jméno menu");
define("CUSLAN_8", "Titulek / Hlavička");
define("CUSLAN_9", "Text");
define("CUSLAN_10", "Povolit hodnocení stránky");
define("CUSLAN_11", "Hlavní strana");
define("CUSLAN_12", "Vytvořit stránku");
define("CUSLAN_13", "Povolit komentáře");
define("CUSLAN_14", "Stránka chráněná heslem");
define("CUSLAN_15", "vložit heslo pro chráněnou stránku");
define("CUSLAN_16", "Vytvořit odkaz v hlavním menu");
define("CUSLAN_17", "vložte název vytvářeného odkazu");
define("CUSLAN_18", "Stránka / odkaz viditelný pro");
define("CUSLAN_19", "Upravit stránku");
define("CUSLAN_20", "Vytvořit stránku");
define("CUSLAN_21", "Upravit menu");
define("CUSLAN_22", "Vytvořit menu");
define("CUSLAN_23", "Upravit stránku");
define("CUSLAN_24", "Vytvořit novou stránku");
define("CUSLAN_25", "Upravit menu");
define("CUSLAN_26", "Vytvořit nové menu");
define("CUSLAN_27", "Stránka uložena do databáze.");
define("CUSLAN_28", "Stránka smazána");
define("CUSLAN_29", "Seznam stránek pokud není žádná vybraná");
define("CUSLAN_30", "Čas vypršení cookie (v sekundách)");
define("CUSLAN_31", "Vytvořit menu");
define("CUSLAN_32", "Převést staré stránky/menu");
define("CUSLAN_33", "Možnosti stránky");
define("CUSLAN_34", "Zahajuji převod");
define("CUSLAN_35", "Dokončena úprava uživatelské stránky - upravena");
define("CUSLAN_36", "Pro nastavení předvoleb pro jednotlivé stránky se musíte vrátit na hlavní stranu a upravit stránku.");
define("CUSLAN_37", "Uživatelská stránka upravena");
define("CUSLAN_38", "zapnuto");
define("CUSLAN_39", "vypnuto");
define("CUSLAN_40", "Uložit možnosti");
define("CUSLAN_41", "Zobrazit informaci o datu a autorovi");
define("CUSLAN_42", "Zatím žádné stránky");
define("CUSLAN_43", "neoznačené menu:");
define("CUSLAN_44", "neoznačená stránka");


?>