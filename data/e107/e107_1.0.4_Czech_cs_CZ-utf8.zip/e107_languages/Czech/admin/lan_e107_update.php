<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_e107_update.php,v $
|     $Revision: 1.7 $
|     $Date: 2008/05/08 03:43:42 $
|     $Author: e107coders - translate en to cz - dubas $
+----------------------------------------------------------------------------+
*/
define("LAN_UPDATE_2", "Akce");
define("LAN_UPDATE_3", "Není třeba");
define("LAN_UPDATE_5", "Úpravy jsou k dispozici");
define("LAN_UPDATE_7", "Spuštěno");
define("LAN_UPDATE_8", "Upravit z");
define("LAN_UPDATE_9", "do");
define("LAN_UPDATE_10", "Jsou k dispozici aktualizace");
define("LAN_UPDATE_11", "úprava z .617 na .7 pokračuje");
define("LAN_UPDATE_12", "Jedna z tabulek obsahuje duplicity.");


?>