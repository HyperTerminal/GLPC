<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/admin/lan_modcomment.php $
|        $Revision: 1.0.2 rc1 $
|        $Id: 2012/07/28 08:19:58 $
|        $Author: Oxigen $
|        $Web: www.e107.funsite.cz $
+---------------------------------------------------------------+
*/

define("MDCLAN_1", "Upraveno");
define("MDCLAN_2", "Pro tuto položku neexistují žádné komentáře.");
define("MDCLAN_3", "Uživatel");
define("MDCLAN_4", "Host");
define("MDCLAN_5", "odblokovat");
define("MDCLAN_6", "zablokovat");
define("MDCLAN_7", "schválit");
define("MDCLAN_8", "Uložit");
define("MDCLAN_9", "Upozornění! Smazáním nadřazeného komentáře smažete i všechny související odpovědi!");
define("MDCLAN_10", "Nastavení");
define("MDCLAN_11", "komentář(e/ů)");
define("MDCLAN_12", "Komentáře");
define("MDCLAN_13", "zablokovaný");
define("MDCLAN_14", "Uzamknutí komentářů:");
define("MDCLAN_15", "Odemčeno");
define("MDCLAN_16", "Zamčeno");
define("MDCLAN_17", "Momentálně zde nejsou žádné komentáře čekající na schválení");
define("MDCLAN_18", "");
define("MDCLAN_19", "");
define("MDCLAN_20", "");


?>