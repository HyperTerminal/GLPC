<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_ugflag.php,v $
|     $Revision: 1.1 $
|     $Date: 2004/09/21 19:11:55 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("UGFLAN_1", "Nastavení údržby změněno");
define("UGFLAN_2", "Aktivovat údržbový provoz (chod stránek omezen/vypnut)");
define("UGFLAN_3", "Uložit nové nastavení");
define("UGFLAN_4", "Nastavení údržby");
define("UGFLAN_5", "Text, který se má zobrazit při aktivované údržbě");
define("UGFLAN_6", "Při nezadání se zobrazí přednastavený text.");
define("UGFLAN_8", "Neomezit přístup pouze správcům");
define("UGFLAN_9", "Neomezit přístup pouze hlavním správcům");


?>