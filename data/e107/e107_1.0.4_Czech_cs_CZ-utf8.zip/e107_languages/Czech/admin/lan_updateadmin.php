<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_languages/Czech/admin/lan_updateadmin.php,v $
|     $Revision: 1.2 $
|     $Date: 2006/08/27 02:24:44 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("UDALAN_1", "Chyba - odeslání opakujte");
define("UDALAN_2", "Nastavení změněno");
define("UDALAN_3", "Nastavení bylo změněno pro");
define("UDALAN_4", "Jméno");
define("UDALAN_5", "Heslo");
define("UDALAN_6", "Potvrzení hesla");
define("UDALAN_7", "Změnit heslo");
define("UDALAN_8", "Heslo bylo změněno pro");


?>