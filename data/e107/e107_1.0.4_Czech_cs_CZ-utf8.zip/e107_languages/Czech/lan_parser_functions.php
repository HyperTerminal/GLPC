<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_parser_functions.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:57:04 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_GUEST", "Host");
define("LAN_WROTE", "napsal");


?>