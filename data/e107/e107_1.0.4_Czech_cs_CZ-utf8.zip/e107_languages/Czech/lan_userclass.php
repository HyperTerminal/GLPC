<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_userclass.php $
|        $Revision: 1.0.2 rc1 $
|        $Id: 2012/07/28 08:16:34 $
|        $Author: Oxigen $
|        $Web: www.e107.funsite.cz $
+---------------------------------------------------------------+
*/

define("UC_LAN_0", "Všichni (veřejné)");
define("UC_LAN_1", "Host");
define("UC_LAN_2", "Nikdo (neaktivní)");
define("UC_LAN_3", "Uživatel");
define("UC_LAN_4", "Pouze pro čtení");
define("UC_LAN_5", "Admin");
define("UC_LAN_6", "Hlavní admin");
define("UC_LAN_9", "Noví uživatelé");
define("UC_LAN_10", "Vyhledávat boti");


?>