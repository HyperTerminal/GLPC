<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/Czech.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/03/31 21:50:02 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/
setlocale(LC_ALL,'cs_CZ.UTF-8','cs');
define("CORE_LC", "cs");
define("CORE_LC2", "cz");
define("CHARSET", "utf-8");
define("CORE_LAN1", "Chyba : vzhled nenalezen.\\n\\n Změňte používané téma v předvolbách (administrátorské rozhraní) nebo nahrajte soubory současného vzhledu na server.");
define("CORE_LAN4", "Prosím smažte install.php z vašeho serveru");
define("CORE_LAN5", "Pokud to neuděláte, hrozí vaší stránce potencionální riziko!");
define("CORE_LAN6", "Ochrana proti DoS útokům na této stránce je zapnuta. Pokud budete pokračovat v zahlcování serveru, budete zabanováni!");
define("CORE_LAN7", "Jádro systému se pokouší obnovit předvolby z automatické zálohy.");
define("CORE_LAN8", "Chyba v předvolbách jádra");
define("CORE_LAN9", "Jádro nelze obnovit ze zálohy. Provádění ukončeno.");
define("CORE_LAN10", "Poškozená cookie - byl jste odhlášen.");
define("CORE_LAN11", "Vygenerováno za:");
define("CORE_LAN12", " sec,");
define("CORE_LAN13", " z toho dotazů.");
define("CORE_LAN14", "");
define("CORE_LAN15", "Dotazů v DB:");
define("CORE_LAN16", "Použitá paměť:");
define("CORE_LAN17", "[ obrázek vypnut ]");
define("CORE_LAN18", "Obrázek:");
define("CORE_LAN_B", "B");
define("CORE_LAN_KB", "kB");
define("CORE_LAN_MB", "MB");
define("CORE_LAN_GB", "GB");
define("CORE_LAN_TB", "TB");
define("LAN_WARNING", "Varování!");
define("LAN_ERROR", "Chyba");
define("LAN_ANONYMOUS", "Anonymní");
define("LAN_EMAIL_SUBS", "-email-");
define("LAN_SANITISED", "VYLEPŠENO");


?>