<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_rate.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/25 09:30:16 $
|        $Author: admin $
+---------------------------------------------------------------+
*/

define("RATELAN_0", "hlas");
define("RATELAN_1", "hlasů");
define("RATELAN_2", "jak hodnotíte tuto položku?");
define("RATELAN_3", "děkujeme za váš hlas");
define("RATELAN_4", "nehodnoceno");
define("RATELAN_5", "Hodnotit");


?>