<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_page.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:56:52 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_PAGE_1", "Vypisování stran je vypnuto");
define("LAN_PAGE_2", "Nejsou zde žádné stránky");
define("LAN_PAGE_3", "Požadovaná strana neexistuje");
define("LAN_PAGE_4", "Ohodnoťte tuto stranu");
define("LAN_PAGE_5", "Děkujeme za hodnocení");
define("LAN_PAGE_6", "Pro zobrazení této strany nemáte přístup");
define("LAN_PAGE_7", "Neplatné heslo");
define("LAN_PAGE_8", "Strana chráněná heslem");
define("LAN_PAGE_9", "Heslo");
define("LAN_PAGE_10", "Odeslat");
define("LAN_PAGE_11", "Seznam stran");
define("LAN_PAGE_12", "Neplatná strana");
define("LAN_PAGE_13", "Strana");


?>