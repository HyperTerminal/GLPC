<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_mail_handler.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:55:03 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LANMAILH_1", "Vytvořeno za pomocí CMS e107");
define("LANMAILH_2", "Toto je zpráva ve formátu MIME obsahující více částí");
define("LANMAILH_3", " nemá správný formát");
define("LANMAILH_4", "Server odmítl adresu");
define("LANMAILH_5", "Žádná odezva od serveru");
define("LANMAILH_6", "E-mailový server nenalezen.");
define("LANMAILH_7", " se zdá být platná.");


?>