<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_date.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:53:56 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LANDT_01", "rok");
define("LANDT_02", "měsíc");
define("LANDT_03", "týden");
define("LANDT_04", "den");
define("LANDT_05", "hodina");
define("LANDT_06", "minuta");
define("LANDT_07", "vteřina");
define("LANDT_01s", "let");
define("LANDT_02s", "měsíců");
define("LANDT_03s", "týdnů");
define("LANDT_04s", "dny");
define("LANDT_05s", "hodin");
define("LANDT_06s", "minut");
define("LANDT_07s", "vteřin");
define("LANDT_08", "min");
define("LANDT_08s", "min");
define("LANDT_09", "sek");
define("LANDT_09s", "sek");
define("LANDT_AGO", "zpět");


?>