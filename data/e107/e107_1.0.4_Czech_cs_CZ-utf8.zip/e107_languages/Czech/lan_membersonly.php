<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_membersonly.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:55:13 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Pouze pro přihlášené");
define("LAN_MEMBERS_0", "oblast s omezeným přístupem");
define("LAN_MEMBERS_1", "Toto je oblast s omezeným přístupem.");
define("LAN_MEMBERS_2", "Pro pokračování se prosím <a href='".e_LOGIN."'>přihlaste</a>");
define("LAN_MEMBERS_3", "nebo se <a href='".e_SIGNUP."'>zaregistruje</a>jako nový uživatel.");
define("LAN_MEMBERS_4", "Klikněte zde pro návrat na hlavní stránku");


?>