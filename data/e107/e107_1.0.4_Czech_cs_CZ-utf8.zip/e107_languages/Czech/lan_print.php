<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_print.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/25 07:51:02 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/
define("LAN_PRINT_86", "Kategorie:");
define("LAN_PRINT_87", "napsal");
define("LAN_PRINT_94", "Napsal");
define("LAN_PRINT_135", "Novinka:");
define("LAN_PRINT_303", "Tato novinka je z -");
define("LAN_PRINT_304", "Název:");
define("LAN_PRINT_305", "Podnadpis:");
define("LAN_PRINT_306", "Tato je z:");
define("LAN_PRINT_307", "Vytisknout tuto stranu");
define("LAN_PRINT_1", "Tisknout");


?>