<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_contact.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:53:46 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("PAGE_NAME", "Kontaktujte nás");
define("LANCONTACT_01", "Detaily kontaktu");
define("LANCONTACT_02", "Kontaktní formulář");
define("LANCONTACT_03", "Zadejte své jméno:");
define("LANCONTACT_04", "E-mail:");
define("LANCONTACT_05", "Předmět zprávy:");
define("LANCONTACT_06", "Zadejte zprávu:");
define("LANCONTACT_07", "Odeslat kopii na email.");
define("LANCONTACT_08", "Odeslat");
define("LANCONTACT_09", "Zpráva odeslána.");
define("LANCONTACT_10", "Při odesílání nastala chyba.");
define("LANCONTACT_11", "Zadaná emailová adresa není správná\\nZkontrolujte ji prosím.");
define("LANCONTACT_12", "Vaše zpráva je příliš krátká.");
define("LANCONTACT_13", "Zadejte předmět.");
define("LANCONTACT_14", "Odeslat zprávu:");
define("LANCONTACT_15", "Vložen špatný kód");
define("LANCONTACT_16", "Vložit kód");


?>