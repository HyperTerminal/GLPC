<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_sitelinks.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 09:00:08 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_SITELINKS_183", "Hlavní menu");
define("LAN_SITELINKS_502", "Administrátorská oblast");


?>