<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_np.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:56:30 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("NP_1", "Předchozí strana");
define("NP_2", "Další strana");
define("NP_3", "Přejít na stranu");


?>