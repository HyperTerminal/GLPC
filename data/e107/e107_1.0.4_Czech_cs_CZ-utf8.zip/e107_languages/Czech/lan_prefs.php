<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_prefs.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 08:57:16 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/
define("LAN_PREF_1", "Stránku pohání e107");
define("LAN_PREF_2", "e107 CMS");
define("LAN_PREF_3", "Tento web je poháněn <a href='http://e107.org/' rel='external'>e107</a>.");
define("LAN_PREF_4", "cenzurováno");
define("LAN_PREF_5", "Fóra");


?>