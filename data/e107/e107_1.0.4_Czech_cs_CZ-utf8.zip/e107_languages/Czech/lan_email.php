<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_email.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/25 07:57:09 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_EMAIL_1", "Od:");
define("LAN_EMAIL_2", "IP adresa odesílatele:");
define("LAN_EMAIL_3", "Zasláno od");
define("LAN_EMAIL_4", "Odeslat Email");
define("LAN_EMAIL_5", "Zaslat email příteli");
define("LAN_EMAIL_6", "Myslel jsem, že tohle by vás mohlo zajímat.");
define("LAN_EMAIL_7", "Poslat emailem");
define("LAN_EMAIL_8", "Komentář");
define("LAN_EMAIL_9", "Omlouváme se - nelze odeslat email");
define("LAN_EMAIL_10", "Email odeslán");
define("LAN_EMAIL_11", "Email odeslán");
define("LAN_EMAIL_12", "Chyba");
define("LAN_EMAIL_13", "Zaslat článek příteli");
define("LAN_EMAIL_14", "Zaslat novinku příteli");
define("LAN_EMAIL_15", "Uživatelské jméno:");
define("LAN_EMAIL_106", "Toto není platná emailová adresa");
define("LAN_EMAIL_185", "Odeslat článek");
define("LAN_EMAIL_186", "Odeslat novinku");
define("LAN_EMAIL_187", "Komu odeslat email");
define("LAN_EMAIL_188", "Myslel jsem, že by vás tohle mohlo zajímat.");
define("LAN_EMAIL_189", "Myslel jsem, že by vás tohle mohlo zajímat.");
define("LAN_EMAIL_190", "Vložit kód");


?>