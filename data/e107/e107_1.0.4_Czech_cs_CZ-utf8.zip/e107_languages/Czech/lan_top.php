<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_top.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 09:00:30 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("TOP_LAN_0", "Nejvíc příspěvků fóra");
define("TOP_LAN_1", "Uživatel");
define("TOP_LAN_2", "Příspěvků");
define("TOP_LAN_3", "Nejvíc komentářů");
define("TOP_LAN_4", "Komentářů");
define("TOP_LAN_5", "Nejvíc příspěvků v Chatboxu");
define("TOP_LAN_6", "Hodnost");
define("LAN_1", "Téma");
define("LAN_2", "Autor");
define("LAN_3", "Zobrazeno");
define("LAN_4", "Odpovědí");
define("LAN_5", "Poslední příspěvek");
define("LAN_6", "Témat");
define("LAN_7", "Nejaktivnější téma");
define("LAN_8", "Nejvíce příspěvků");


?>