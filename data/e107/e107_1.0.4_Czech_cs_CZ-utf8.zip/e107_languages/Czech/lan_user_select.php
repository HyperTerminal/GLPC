<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_languages/Czech/lan_user_select.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/15 09:01:38 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("US_LAN_1", "Vybrat uživatele");
define("US_LAN_2", "Vybrat uživatelskou skupinu");
define("US_LAN_3", "Všichni uživatelé");
define("US_LAN_4", "Hledat uživatelské jméno");
define("US_LAN_5", "Nalezení uživatelé");
define("US_LAN_6", "Hledat");


?>