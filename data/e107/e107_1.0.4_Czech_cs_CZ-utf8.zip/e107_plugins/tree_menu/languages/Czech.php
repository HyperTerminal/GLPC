<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/tree_menu/languages/Czech.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/06/17 12:17:48 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("TREE_L1", "Nastavení strukturovaného menu");
define("TREE_L2", "Aktualizovat nastavení strukturovaného menu");
define("TREE_L3", "Nastavení strukturovaného menu uloženo.");
define("TREE_L4", "Zapnuto");
define("TREE_L5", "Vypnuto");
define("TREE_L6", "CSS pro nepoužité odkazy");
define("TREE_L7", "CSS pro použité odkazy");
define("TREE_L8", "CSS pro otevřené odkazy");
define("TREE_L9", "Použitím mezerníku oddělíte hlavní odkazy");
define("TREE_L0", "Autocollapse podmenu");
define("TREE_L10", "Použít novou verzi tree_menu");
define("TREE_L11", "Nastavení starší verze");
define("TREE_L12", "Hlavní nastavení starší, novější verze");
define("TREE_L13", "Nastavení novější verze");
define("TREE_L14", "Zobrazit menu bez názvu menu");
define("TREE_L17", "<a href='http://www.sbgames.narod.ru' target='_blank'>Stránky tvůrce doplňku</a>");


?>