<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Czech/lan_otherdb_auth.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/30 17:52:49 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("OTHERDB_LAN_1", "Typ databáze:");
define("OTHERDB_LAN_2", "Server:");
define("OTHERDB_LAN_3", "Uživatel:");
define("OTHERDB_LAN_4", "Heslo:");
define("OTHERDB_LAN_5", "Databáze");
define("OTHERDB_LAN_6", "Tabulka");
define("OTHERDB_LAN_7", "Pole uživatel:");
define("OTHERDB_LAN_8", "Pole heslo:");
define("OTHERDB_LAN_9", "Metoda hesla:");
define("OTHERDB_LAN_10", "Nastavit autentizaci jiné db");
define("OTHERDB_LAN_11", "** Následující pole nejsou vyžadována, pokud používáte databázi e107");


?>