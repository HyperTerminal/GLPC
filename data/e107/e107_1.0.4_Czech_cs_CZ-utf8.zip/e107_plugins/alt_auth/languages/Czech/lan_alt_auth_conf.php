<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/alt_auth/languages/Czech/lan_alt_auth_conf.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/06/17 12:05:21 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_ALT_2", "Upravit nastavení");
define("LAN_ALT_3", "Vyberte alternativní druh autorizace");
define("LAN_ALT_4", "Nastavit parametry pro");
define("LAN_ALT_5", "Nastavit parametry autorizace");
define("LAN_ALT_6", "Neúspěšný pokus o připojení");
define("LAN_ALT_7", "Pokud selže připojení k alternativním metodám, jak se to bude řešit?");
define("LAN_ALT_8", "Uživatel nenalezl akci");
define("LAN_ALT_9", "Pokud není uživatelské jméno nalezeno alternativní metodou, jak se to bude řešit?");
define("LAN_ALT_10", "Neúspěšné přihlášení");
define("LAN_ALT_11", "Použít uživatelské tabulky e107");
define("LAN_ALT_PAGE", "Alternativní autentizace");


?>