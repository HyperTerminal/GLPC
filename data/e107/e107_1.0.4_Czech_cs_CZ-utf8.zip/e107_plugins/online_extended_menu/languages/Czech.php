<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/online_extended_menu/languages/Czech.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/06/03 15:11:17 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("ONLINE_EL1", "Hostů:");
define("ONLINE_EL2", "Členů:");
define("ONLINE_EL3", "Na této stránce:");
define("ONLINE_EL4", "Online");
define("ONLINE_EL5", "Členů");
define("ONLINE_EL6", "Nejnovější člen");
define("ONLINE_EL7", "prohlíží");
define("ONLINE_EL8", "nejvíc online:");
define("ONLINE_EL9", "v");
define("ONLINE_TRACKING_MESSAGE", "Online sledování uživatelům je momentálně neaktivní, [link=".e_ADMIN."users.php?options]aktivovat tuto službu můžete zde.[/link][br]");


?>