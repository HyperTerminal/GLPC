<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/banner_menu/languages/Czech.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/06/22 19:49:56 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("BANNER_MENU_L1", "Reklama");
define("BANNER_MENU_L2", "Nastavení Banner menu uloženo");
define("BANNER_MENU_L3", "Záhlaví");
define("BANNER_MENU_L4", "Kampaň");
define("BANNER_MENU_L5", "Nastavení Banner Menu");
define("BANNER_MENU_L6", "Vyberte kampaně které mají být v menu uvedeny");
define("BANNER_MENU_L7", "dostupné kampaně");
define("BANNER_MENU_L8", "vybrané kampaně");
define("BANNER_MENU_L9", "Odstranit z výběru");
define("BANNER_MENU_L10", "Jak bude vybraná kampaň zobrazována ?");
define("BANNER_MENU_L11", "vyberte typ vykreslení ...");
define("BANNER_MENU_L12", "jedna kampaň v jednom menu");
define("BANNER_MENU_L13", "všechny vybrané kampaně v jednom menu");
define("BANNER_MENU_L14", "všechny vybrané kampaně v oddělených menu");
define("BANNER_MENU_L15", "Kolik bannerů má být zobrazeno ?");
define("BANNER_MENU_L16", "toto je použito pouze pokud je vybráno více kampaní najednou </br>");
define("BANNER_MENU_L17", "nastavené množství ...");
define("BANNER_MENU_L18", "Uložit nastavení");


?>