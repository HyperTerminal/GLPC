<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/counter_menu/languages/Czech.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/06/22 18:07:49 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("COUNTER_L1", "Nepočítat návštěvy admina.");
define("COUNTER_L2", "Dnes na této stránce ...");
define("COUNTER_L3", "celkem");
define("COUNTER_L4", "Celkem na této stránce ...");
define("COUNTER_L5", "unikátních");
define("COUNTER_L6", "Stránka ...");
define("COUNTER_L7", "Počítadlo");
define("COUNTER_L8", "Zpráva: <b>Zapisování statistik je vypnuto.</b><br />Pro aktivování musíte nainstalovat doplněk Statistiky ve <a href='".e_ADMIN."plugin.php'>správci doplňků</a>, a potom jej aktivovat v  <a href='".e_PLUGIN."log/admin_config.php'>nastavení</a>.");


?>