<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/usertheme_menu/languages/Czech.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/10 19:29:37 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/
define("LAN_UMENU_THEME_1", "Nastavit vzhled");
define("LAN_UMENU_THEME_2", "Zvolit vzhled");
define("LAN_UMENU_THEME_3", "Používáno:");
define("LAN_UMENU_THEME_4", "Vyberte vzhledy, které mohou uživatelé používat");
define("LAN_UMENU_THEME_5", "Uložit");
define("LAN_UMENU_THEME_6", "Vzhledy, které jsou uživatelům k dispozici k výběru");
define("LAN_UMENU_THEME_7", "Skupina uživatelů, která může zvolit vlastní vzhled webu");


?>