<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     
+----------------------------------------------------------------------------+
*/
define("ONLINE_L1", "Hostí:");
define("ONLINE_L2", "Členů:");
define("ONLINE_L3", "Na této stránce:");
define("ONLINE_L4", "Online");
define("ONLINE_L5", "Členů");
define("ONLINE_L6", "nejnovější");
define("TRACKING_MESSAGE", "Sledování online uživatelů je v současnosti vypnuto, můžete ho povolit [link=".e_ADMIN."users.php?options]zde[/link][br]");


?>