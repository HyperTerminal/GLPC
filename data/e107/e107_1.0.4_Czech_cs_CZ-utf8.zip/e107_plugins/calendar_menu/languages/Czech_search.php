<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/calendar_menu/languages/Czech_search.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/30 17:55:22 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("CM_SCH_LAN_1", "Kalendář");


?>