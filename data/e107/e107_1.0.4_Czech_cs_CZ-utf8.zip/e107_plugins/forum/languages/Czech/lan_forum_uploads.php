<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Czech/lan_forum_uploads.php,v $
|     $Revision: 1.1 $
|     $Date: 2005/02/24 20:43:34 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Nahrání souborů do fóru");
define("FRMUP_1", "Nahrané soubory");
define("FRMUP_2", "Soubor smazán");
define("FRMUP_3", "Chyba: Nelze smazat soubor");
define("FRMUP_4", "Smazání souboru");
define("FRMUP_5", "Název souboru");
define("FRMUP_6", "Výsledek");
define("FRMUP_7", "Nalezeno v tématu");
define("FRMUP_8", "NENALEZENO");
define("FRMUP_9", "Nenalezeny žádné soubory");
define("FRMUP_10", "Smazat");


?>