<?php
/*
+ ----------------------------------------------------------------------------+
e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Czech/lan_newforumposts_menu.php,v $
|     $Revision: 1.3 $
|     $Date: 2007/05/27 19:25:00 $
|     $Author: e107steved $
+----------------------------------------------------------------------------+
*/
define("NFP_1", "Všechny poslední příspěvky jsou mimo vaší uživatelskou třídu, nemohu zobrazit.");
define("NFP_2", "Zatím žádné příspěvky");
define("NFP_3", "Nastavení menu nový příspěvků uloženo");
define("NFP_4", "Hlavička");
define("NFP_5", "Kolik zobrazit příspěvků?");
define("NFP_6", "Kolik zobrazit znaků?");
define("NFP_7", "Přípona pro příliš dlouhé příspěvky?");
define("NFP_8", "Zobrazit původní témata v menu?");
define("NFP_9", "Upravit nastavení menu");
define("NFP_10", "Nastavení menu nových příspěvků");
define("NFP_11", "Odeslal");
define("NFP_12", "Maximální doba zobrazení příspěvků");
define("NFP_13", "Zadejte nulu na menších stránkách; nastavení hodnoty redukuje čas zpracování na vytížených stránkách");


?>