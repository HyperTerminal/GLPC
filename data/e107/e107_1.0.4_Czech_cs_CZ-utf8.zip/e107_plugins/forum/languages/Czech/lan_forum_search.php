<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Czech/lan_forum_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2005/06/16 05:25:35 $
|     $Author: sweetas $
+----------------------------------------------------------------------------+
*/
define("FOR_SCH_LAN_1", "Fórum");
define("FOR_SCH_LAN_2", "Vybrat fórum");
define("FOR_SCH_LAN_3", "Všechna fóra");
define("FOR_SCH_LAN_4", "Celý příspěvek");
define("FOR_SCH_LAN_5", "Jako součást tématu");


?>