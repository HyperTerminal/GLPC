<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Czech/lan_forum_viewforum.php,v $
|     $Revision: 1.8 $
|     $Date: 2005/09/06 01:12:01 $
|     $Author: mcfly_e107 $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Fórum");
define("LAN_01", "Fórum");
define("LAN_02", "Zpět na začátek");
define("LAN_03", "Přejít");
define("LAN_53", "Téma");
define("LAN_54", "Odeslal");
define("LAN_55", "Odpovědí");
define("LAN_56", "Zobrazení");
define("LAN_57", "Poslední příspěvek");
define("LAN_58", "Ve fóru zatím nejsou žádná témata.");
define("LAN_59", "V těchto fórech mohou přispívat pouze registrovaní a přihlášení uživatelé. Zaregistrujte se nebo se přihlaste.");
define("LAN_79", "Nové příspěvky");
define("LAN_80", " Žádné nové příspěvky");
define("LAN_81", "Zamknuté téma");
define("LAN_180", "Hledat");
define("LAN_199", "Nepřečtená pošta!");
define("LAN_202", "Přišpendleno");
define("LAN_203", "Přišpendleno/Zamknuto");
define("LAN_204", "<b>Můžete</b> zakládat nová témata");
define("LAN_205", "<b>Nemůžete</b> zakládat nová témata");
define("LAN_206", "<b>Můžete</b> odpovídat na témata");
define("LAN_207", "<b>Nemůžete</b> odpovídat na témata");
define("LAN_208", "<b>Můžete</b> upravovat svoje příspěvky");
define("LAN_209", "<b>Nemůžete</b> upravovat svoje příspěvky");
define("LAN_316", "Přejít na stránku:");
define("LAN_317", "Žádný");
define("LAN_321", "Moderátoři:");
define("LAN_395", "[oblíbené]");
define("LAN_396", "Oznámení");
define("LAN_397", "Toto fórum je jen pro čtení");
define("LAN_398", "Odšpendlit téma");
define("LAN_399", "Zamknout téma");
define("LAN_400", "Odemknout téma");
define("LAN_401", "Přišpendlit téma");
define("LAN_402", "Přesunout téma");
define("LAN_403", "Přejít na fórum");
define("LAN_404", "Toto fórum moderují");
define("LAN_405", "uživatel prohlíží toto fórum");
define("LAN_406", "uživatelé prohlíží toto fórum");
define("LAN_407", "uživatel");
define("LAN_408", "host");
define("LAN_409", "uživatelé");
define("LAN_410", "hosté");
define("LAN_411", "Důležitá témata");
define("LAN_412", "Témata ve fóru");
define("LAN_431", "Odebírat z fóra: rss 0.92");
define("LAN_432", "Odebírat z fóra: rss 2.0");
define("LAN_433", "Odebírat z fóra: RDF");
define("LAN_434", "Jste si jistý, že chcete smazat téma?");
define("LAN_435", "Smazat téma");
define("FORLAN_CLOSE", "Téma zamknuto");
define("FORLAN_OPEN", "Téma opět odemknuto.");
define("FORLAN_STICK", "Příšpendlené téma.");
define("FORLAN_UNSTICK", "Odšpendlené téma.");
define("FORLAN_6", "Téma smazáno");
define("FORLAN_7", "odpovědi smazány");
define("FORLAN_8", "zde");
define("FORLAN_9", "pro registraci nebo přihlášení.");
define("FORLAN_10", "Vytvořit nové téma");
define("FORLAN_11", "Nové příspěvky");
define("FORLAN_12", "Žádné nové příspěvky");
define("FORLAN_13", "Nové příspěvky v oblíbeném tématu");
define("FORLAN_14", "Žádné nové příspěvky v oblíbeném tématu");
define("FORLAN_15", "Přišpendlené téma");
define("FORLAN_16", "Zamknuté přišpendlené téma");
define("FORLAN_17", "Oznámení");
define("FORLAN_18", "Zamknuté téma");
define("FORLAN_19", "[uživatel smazán]");
define("FORLAN_20", "Pod-fórum");
define("FORLAN_21", "Témata");
define("FORLAN_22", "Poslední příspěvek");


?>