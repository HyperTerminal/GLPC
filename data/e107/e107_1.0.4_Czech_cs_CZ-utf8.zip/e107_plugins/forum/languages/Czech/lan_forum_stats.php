<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Czech/lan_forum_stats.php,v $
|     $Revision: 1.2 $
|     $Date: 2005/03/25 11:38:50 $
|     $Author: stevedunstan $
+----------------------------------------------------------------------------+
*/
define("e_PAGETITLE", "Statistiky fóra");
define("FSLAN_1", "Obecné");
define("FSLAN_2", "Fórum otevřeno");
define("FSLAN_3", "Otevřeno po dobu");
define("FSLAN_4", "Celkem příspěvků");
define("FSLAN_5", "Celkem témat");
define("FSLAN_6", "Celkem odpovědí");
define("FSLAN_7", "Počet zobrazení témat");
define("FSLAN_8", "Velikost databáze (pouze tabulky fóra)");
define("FSLAN_9", "Průměrná velikost řádku v tabulce");
define("FSLAN_10", "Nejoblíbenější témata");
define("FSLAN_11", "Pořadí");
define("FSLAN_12", "Téma");
define("FSLAN_13", "Odpovědí");
define("FSLAN_14", "Uživatel");
define("FSLAN_15", "Datum");
define("FSLAN_16", "Témata s nejvíce zobrazeními");
define("FSLAN_17", "Zobrazení");
define("FSLAN_18", "Nejaktivnější uživatelé");
define("FSLAN_19", "Jméno");
define("FSLAN_20", "Celkem");
define("FSLAN_21", "Nejvíce založených témat");
define("FSLAN_22", "Nejvíce odpovědí");
define("FSLAN_23", "Statistiky fóra");
define("FSLAN_24", "Denní průměr příspěvků");


?>