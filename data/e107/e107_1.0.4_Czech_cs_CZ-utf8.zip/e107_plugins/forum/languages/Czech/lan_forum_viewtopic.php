<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/forum/languages/Czech/lan_forum_viewtopic.php,v $
|     $Revision: 1.12 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("PAGE_NAME", "Fórum");
define("LAN_01", "Fórum");
define("LAN_02", "Jít na stránku");
define("LAN_03", "Jdi");
define("LAN_04", "Předchozí");
define("LAN_05", "Další");
define("LAN_06", "Registrován");
define("LAN_07", "Umístění");
define("LAN_08", "Webová stránka");
define("LAN_09", "Návštěvy od registrace");
define("LAN_10", "Zpět na začátek");
define("LAN_65", "Přejít");
define("LAN_66", "Toto téma je zamčeno");
define("LAN_67", "Příspěvků");
define("LAN_194", "Host");
define("LAN_195", "Uživatel");
define("LAN_321", "Moderátoři:");
define("LAN_389", "Předchozí téma");
define("LAN_390", "Další téma");
define("LAN_391", "Sledovat téma");
define("LAN_392", "Zrušit sledování tématu");
define("LAN_393", "Rychlá odpověď");
define("LAN_394", "Náhled");
define("LAN_395", "Odeslat odpověď");
define("LAN_396", "Webová stránka");
define("LAN_397", "Email");
define("LAN_398", "Profil");
define("LAN_399", "Soukromá zpráva");
define("LAN_400", "Upravit");
define("LAN_401", "Citovat");
define("LAN_402", "Autor");
define("LAN_403", "Příspěvek");
define("LAN_404", "Žádné předchozí téma");
define("LAN_405", "Žádné další téma");
define("LAN_406", "Moderátor: Upravit");
define("LAN_435", "Moderátor: Smazat");
define("LAN_408", "Moderátor: Přesunout");
define("LAN_409", "Opravdu chcete smazat celé téma?");
define("LAN_410", "Opravdu chcete smazat tuto odpověď??");
define("LAN_411", "napsal");
define("LAN_412", "Titulek");
define("LAN_413", "Nahlásit");
define("LAN_414", "Nahlásit téma moderátorům");
define("LAN_415", "Titulek tématu");
define("LAN_416", "Důvod oznámení");
define("LAN_417", "Administrátor bude na téma upozorněn. Můžete udat důvod oznámení.");
define("LAN_418", "<b>Nepoužívejte</b> tento formulář pro kontaktování administrátora z jiného důvodu.");
define("LAN_419", "Odeslat");
define("LAN_420", "Zobrazit příspěvek");
define("LAN_421", "Téma nahlásil");
define("LAN_422", "Tento příspěvek byl nahlášen ze stránky");
define("LAN_423", "Zpráva nemohla být odeslána.");
define("LAN_424", "Příspěvek byl nahlášen moderátorům.<br />Děkujeme.");
define("LAN_425", "Zpráva od:");
define("LAN_426", "Nahlašuje téma:");
define("LAN_427", "Chyba při posílání mailu");
define("LAN_428", "Chyba při odesílání e-mailu");
define("LAN_429", "Zpět na fórum");
define("LAN_430", "anketa");
define("FORLAN_26", "Odpověď smazána");
define("FORLAN_10", "Vytvořit nové téma");
define("LAN_29", "Upraveno");
define("LAN_431", "Odebírat z fóra: rss 0.92");
define("LAN_432", "Odebírat z fóra: rss 2.0");
define("LAN_433", "Odebírat z fóra: RDF");
define("FORLAN_101", "Poslat téma emailem");
define("FORLAN_102", "Vytisknout odpověď");
define("FORLAN_103", "[uživatel smazán]");
define("FORLAN_104", "Téma nenalezeno");
define("FORLAN_HIDDEN", "SKRYTO - přihlaste se a napište odpověď pro odkrytí");


?>