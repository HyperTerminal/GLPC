<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/forum/languages/Czech/lan_forum_notify.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/31 10:20:35 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/
define("NT_LAN_FT_1", "Forum události");
define("NT_LAN_FO_1", "Forum příspěvek napsal");
define("NT_LAN_MP_1", "Forum písemné zprávy");
define("NT_LAN_FD_1", "Forum Příspěvek smazán");
define("NT_LAN_FP_1", "Forum zpráva odstraněna");
define("NT_LAN_FM_1", "Forum příspěvek pohyboval");
define("NT_LAN_FO_3", "forum po vytvořené");
define("NT_LAN_FO_4", "forum-name");
define("NT_LAN_FO_5", "Betrefft");
define("NT_LAN_FO_6", " Zpráva");
define("NT_LAN_FO_7", "vytvořen nový post");
define("NT_LAN_MP_3", "Forum zprávy vytvořené");
define("NT_LAN_MP_4", "forum-name");
define("NT_LAN_MP_6", "Zpráva");
define("NT_LAN_MP_7", "nové fórum zpráva vytvořena");
define("NT_LAN_FD_3", "forum po vytvořené");
define("NT_LAN_FD_4", "forum-name");
define("NT_LAN_FD_5", "Předmět");
define("NT_LAN_FD_6", "Zpráva");
define("NT_LAN_FD_7", "Příspěvek byl úspěšně smazán");
define("NT_LAN_FD_8", "Forum příspěvek smazat");
define("NT_LAN_FP_3", "Forum zprávy vytvořené");
define("NT_LAN_FP_4", "forum-name");
define("NT_LAN_FP_6", "Zpráva");
define("NT_LAN_FP_7", "Forum zpráva byla odstraněna");
define("NT_LAN_FP_8", "Forum příspěvek smazal");
define("NT_LAN_FM_3", "Téma vytvořil");
define("NT_LAN_FM_4", "Starý předmět");
define("NT_LAN_FM_5", "Nové Předmět");
define("NT_LAN_FM_6", "věku (zdroj) Název fóra");
define("NT_LAN_FM_7", "Nové jméno fóra");
define("NT_LAN_FM_8", "Příspěvek byl přesunut");
define("NT_LAN_FM_9", "Příspěvek byl přemístěn z");


?>