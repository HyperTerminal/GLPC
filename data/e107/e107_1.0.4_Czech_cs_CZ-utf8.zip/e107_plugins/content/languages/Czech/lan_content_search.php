<?php
/*
efIT^cz™ - korektura 3.12.2008, preklad www.e107.cz Team 
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/content/languages/English/lan_content_search.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/09/18 08:57:42 $
|     $Author: lisa_ $
+----------------------------------------------------------------------------+
*/

define("CONT_SCH_LAN_1", "Články");
define("CONT_SCH_LAN_2", "Včechny kategorie článků");
define("CONT_SCH_LAN_3", "Přidej příspěvek");
define("CONT_SCH_LAN_4", "v");

?>