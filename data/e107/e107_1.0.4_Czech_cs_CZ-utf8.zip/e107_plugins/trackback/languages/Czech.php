<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/trackback/languages/Czech.php $
|        $Revision: 0.8 $
|        $Id: 2012/01/10 19:26:44 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("TRACKBACK_L1", "Konfigurace zpětných odkazů");
define("TRACKBACK_L2", "Tento doplněk vám umožní používat funkci zpětných odkazů pro vaše novinky.");
define("TRACKBACK_L3", "Doplňek pro využití zpětných odkazů je nainstalován a aktivován.");
define("TRACKBACK_L4", "Nastavení zpětných odkazů bylo uloženo.");
define("TRACKBACK_L5", "Zapnuto");
define("TRACKBACK_L6", "Vypnuto");
define("TRACKBACK_L7", "Aktivovat funkci zpětné odkazy");
define("TRACKBACK_L8", "URL text zpětných odkazů");
define("TRACKBACK_L9", "Uložit nastavení");
define("TRACKBACK_L10", "Nastavení zpětných odkazů");
define("TRACKBACK_L11", "Zpětná adresa pro váš příspěvek:");
define("TRACKBACK_L12", "Pro tuto položku nejsou dosud žádné zpětné odkazy");
define("TRACKBACK_L13", "Moderovat zpětné odkazy");
define("TRACKBACK_L14", "Smazat");
define("TRACKBACK_L15", "Zpětný odkaz smazán.");


?>