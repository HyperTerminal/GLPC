<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("BLOGCAL_L1", "Novinky pro");
define("BLOGCAL_L2", "Archiv");
define("BLOGCAL_D1", "Po");
define("BLOGCAL_D2", "Út");
define("BLOGCAL_D3", "St");
define("BLOGCAL_D4", "Čt");
define("BLOGCAL_D5", "Pa");
define("BLOGCAL_D6", "So");
define("BLOGCAL_D7", "Ne");
define("BLOGCAL_M1", "Leden");
define("BLOGCAL_M2", "Únor");
define("BLOGCAL_M3", "Březen");
define("BLOGCAL_M4", "Duben");
define("BLOGCAL_M5", "Květen");
define("BLOGCAL_M6", "Červen");
define("BLOGCAL_M7", "Červenec");
define("BLOGCAL_M8", "Srpen");
define("BLOGCAL_M9", "Září");
define("BLOGCAL_M10", "Říjen");
define("BLOGCAL_M11", "Listopad");
define("BLOGCAL_M12", "Prosinec");
define("BLOGCAL_1", "Novinky");
define("BLOGCAL_CONF1", "Měsíce/řada");
define("BLOGCAL_CONF2", "Vnitřní okraj");
define("BLOGCAL_CONF3", "Nastavení menu upraveno");
define("BLOGCAL_CONF4", "Nastavení BlogCal Menu");
define("BLOGCAL_CONF5", "Nastavení BlogCal menu uloženo");
define("BLOGCAL_ARCHIV1", "Vybrat archiv");


?>