<?php
/*
+---------------------------------------------------------------+
| e107 website system
|
| ©Steve Dunstan 2001-2002
| http://e107.org
| jalist@e107.org
|
| Released under the terms and conditions of the
| GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/
define("CM_L1", "Zatím žádné komentáře.");
define("CM_L2", "");
define("CM_L3", "Hlavička");
define("CM_L4", "Kolik zobrazit komentářů?");
define("CM_L5", "Kolik zobrazit znaků?");
define("CM_L6", "Přípona pro příliš dlouhé komentáře?");
define("CM_L7", "Zobrazit původní titulek v menu?");
define("CM_L8", "Konfigurace menu nových komentářů");
define("CM_L9", "Upravit nastavení menu");
define("CM_L10", "Nastavení menu uloženo");
define("CM_L11", "v");
define("CM_L12", "Re:");
define("CM_L13", "Napsal");


?>