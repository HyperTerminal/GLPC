<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/chatbox_menu/languages/Czech/English_config.php,v $
|     $Revision: 1.4 $
|     $Date: 2005/12/06 01:06:09 $
|     $Author: mcfly_e107 $
|     Encoding:
+----------------------------------------------------------------------------+
*/
define("CHBLAN_1", "Nastavení chatboxu upraveno.");
define("CHBLAN_2", "Moderováno.");
define("CHBLAN_3", "Zatím žádné příspěvky.");
define("CHBLAN_4", "Člen");
define("CHBLAN_5", "Host");
define("CHBLAN_6", "odblokovat");
define("CHBLAN_7", "blokovat");
define("CHBLAN_8", "smazat");
define("CHBLAN_9", "Moderovat Chatbox");
define("CHBLAN_10", "Moderovat příspěvky");
define("CHBLAN_11", "Příspěvky chatboxu ke zobrazení");
define("CHBLAN_12", "počet příspěvků zobrazených v chatboxu");
define("CHBLAN_13", "Nahradit odkazy");
define("CHBLAN_14", "pokud je zaškrtnuto, odeslané odkazy budou nahrazeny textem zadaným níže");
define("CHBLAN_15", "Nahrazení (pokud je povoleno)");
define("CHBLAN_16", "odkazy budou nahrazeny tímto textem");
define("CHBLAN_17", "Zalamování dlouhých slov");
define("CHBLAN_18", "slova delší než daný počet písmen budou zalomena");
define("CHBLAN_19", "Upravit nastavení chatboxu");
define("CHBLAN_20", "Nastavení Chatboxu");
define("CHBLAN_21", "Promazání");
define("CHBLAN_22", "Smazat příspěvky, které jsou starší než zadaná doba");
define("CHBLAN_23", "Smazat starší příspěvky než");
define("CHBLAN_24", "Jeden den");
define("CHBLAN_25", "Jeden týden");
define("CHBLAN_26", "Jeden měsíc");
define("CHBLAN_27", "- Smazat všechny příspěvky -");
define("CHBLAN_28", "Chatbox promazán.");
define("CHBLAN_29", "Zobrazit chatbox v posouvacím oknu");
define("CHBLAN_30", "Výška okna");
define("CHBLAN_31", "Zobrazovat smajlíky");
define("CHBLAN_32", "Třída moderátorů");
define("CHBLAN_33", "Počty uživatelů aktualizovány");
define("CHBLAN_34", "Počty příspěvků aktualizovány");
define("CHBLAN_35", "Aktualizovat");
define("CHBLAN_36", "Možnosti zobrazení chatboxu");
define("CHBLAN_37", "Běžný chatbox");
define("CHBLAN_38", "Aktualizovat příspěvky dynamicky pomocí javascriptu (AJAX)");


?>