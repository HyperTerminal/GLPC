<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/newsfeed/languages/Czech_frontpage.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/30 17:57:09 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("NWSF_FP_1", "Zásobování novinkami");
define("NWSF_FP_2", "hlavní stránka");


?>