<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_plugins/userlanguage_menu/languages/Czech.php $
|        $Revision: 1.0 $
|        $Id: 2012/01/23 21:31:22 $
|        $Author: Oxigen $
|        $Web: www.e107.funsite.cz$
+---------------------------------------------------------------+
*/

define("UTHEME_MENU_L1", "Použít jazyk");
define("UTHEME_MENU_L2", "Nastavit jazyk webu");
define("UTHEME_MENU_L3", "tabulky");


?>