<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/admin/Czech.php,v $
|     $Revision: 1.4 $
|     $Date: 2006/10/31 21:16:29 $
|     $Author: e107coders $
+----------------------------------------------------------------------------+
*/
define("CLOCK_AD_L1", "Konfigurace menu s hodinami uložena");
define("CLOCK_AD_L2", "Titulek");
define("CLOCK_AD_L3", "Upravit nastavení menu");
define("CLOCK_AD_L4", "Konfigurace menu s hodinami");
define("CLOCK_AD_L5", "AM/PM");
define("CLOCK_AD_L6", "Zaškrtněte pro US formát hodin (0-12 AM/PM). Nechte prázdné pro standardní 24 hodinový formát");
define("CLOCK_AD_L7", "Předpona data");
define("CLOCK_AD_L8", "Textová zkratka před datem, pokud to váš jazyk vyžaduje (např. 'le' ve Francouzštině nebo 'den' v Němčině...). Pokud není potřeba, nechte prázdné.");
define("CLOCK_AD_L9", "Přípona pro 1");
define("CLOCK_AD_L10", "Přípona pro 2");
define("CLOCK_AD_L11", "Přípona pro 3");
define("CLOCK_AD_L12", "Přípona pro 4 a další");
define("CLOCK_AD_L13", "Textová přípona za datem, pokud to váš jazyk vyžaduje (např.: 'st' pro 1, 'nd' pro 2, 'rd' pro 3 a 'th' pro 4 a další - pro angličtinu). Pokud není potřeba, nechte prázdné.");
define("CLOCK_AD_L14", "");
define("CLOCK_AD_L15", "");
define("CLOCK_AD_L16", "");
define("CLOCK_AD_L17", "");
define("CLOCK_AD_L18", "");
define("CLOCK_AD_L19", "");
define("CLOCK_AD_L20", "");
define("CLOCK_AD_L21", "");
define("CLOCK_AD_L22", "");
define("CLOCK_AD_L23", "");
define("CLOCK_AD_L24", "");


?>