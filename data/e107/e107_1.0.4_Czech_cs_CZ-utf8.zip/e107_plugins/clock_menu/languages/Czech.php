<?php
/*
+ ----------------------------------------------------------------------------+
|     e107 website system
|
|     ©Steve Dunstan 2001-2002
|     http://e107.org
|     jalist@e107.org
|
|     Released under the terms and conditions of the
|     GNU General Public License (http://gnu.org).
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/clock_menu/languages/Czech.php,v $
|     $Revision: 1.5 $
|     $Date: 2005/01/27 19:52:38 $
|     $Author: streaky $
+----------------------------------------------------------------------------+
*/
define("CLOCK_MENU_L1", "Nastavení menu hodin uloženo");
define("CLOCK_MENU_L2", "Hlavička");
define("CLOCK_MENU_L3", "Upravit nastavení menu");
define("CLOCK_MENU_L4", "Nastavení menu hodin");
define("CLOCK_MENU_L5", "Pondělí,");
define("CLOCK_MENU_L6", "Úterý,");
define("CLOCK_MENU_L7", "Středa,");
define("CLOCK_MENU_L8", "Čtvrtek,");
define("CLOCK_MENU_L9", "Pátek,");
define("CLOCK_MENU_L10", "Sobota,");
define("CLOCK_MENU_L11", "Neděle,");
define("CLOCK_MENU_L12", "Leden");
define("CLOCK_MENU_L13", "Únor");
define("CLOCK_MENU_L14", "Březen");
define("CLOCK_MENU_L15", "Duben");
define("CLOCK_MENU_L16", "Květen");
define("CLOCK_MENU_L17", "Červen");
define("CLOCK_MENU_L18", "Červenec");
define("CLOCK_MENU_L19", "Srpen");
define("CLOCK_MENU_L20", "Září");
define("CLOCK_MENU_L21", "Říjen");
define("CLOCK_MENU_L22", "Listopad");
define("CLOCK_MENU_L23", "Prosinec");
define("CLOCK_MENU_L24", "");


?>