<?php
/*
+ -----------------------------------------------------------------------------+
|     e107 website system - Language File.
|
|     $Source: /cvsroot/e107/e107_0.7/e107_plugins/pdf/languages/Czech.php,v $
|     $Revision: 1.3 $
|     $Date: 2006/06/22 19:49:58 $
|     $Author: e107coders $
+-----------------------------------------------------------------------------+
*/
define("PDF_PLUGIN_LAN_1", "PDF");
define("PDF_PLUGIN_LAN_2", "Podpora tvorby PDF");
define("PDF_PLUGIN_LAN_3", "PDF");
define("PDF_PLUGIN_LAN_4", "Tento doplněk je nyní připraven k použití.");
define("PDF_LAN_1", "PDF");
define("PDF_LAN_2", "PDF nastavení");
define("PDF_LAN_3", "aktivované");
define("PDF_LAN_4", "blokované");
define("PDF_LAN_5", "levý okraj stránky");
define("PDF_LAN_6", "pravý okraj stránky");
define("PDF_LAN_7", "horní okraj stránky");
define("PDF_LAN_8", "skupina fontů");
define("PDF_LAN_9", "přednastavená velikost fontu");
define("PDF_LAN_10", "velikost fontu názvu internetových stránek");
define("PDF_LAN_11", "velikost fontu url stránky");
define("PDF_LAN_12", "velikost fontu čísla stránky");
define("PDF_LAN_13", "zobrazit logo v pdf?");
define("PDF_LAN_14", "zobrazit název web stránek v pdf?");
define("PDF_LAN_15", "zobrazit tvůrce url stránky v pdf?");
define("PDF_LAN_16", "zobrazit čísla stránky v pdf?");
define("PDF_LAN_17", "aktualizovat");
define("PDF_LAN_18", "PDF nastavení byli úspěšně aktualizovány");
define("PDF_LAN_19", "Stránka");
define("PDF_LAN_20", "Chybová zpráva");


?>