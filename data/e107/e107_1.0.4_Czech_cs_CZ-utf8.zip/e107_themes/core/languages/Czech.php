<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/core/languages/Czech.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/04/02 18:38:06 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Základní téma e107 od <a href='http://e107.org' title='e107 CMS' rel='external'>e107 týmu</a>");
define("LAN_THEME_2", "Komentářů:");
define("LAN_THEME_3", "Diskuze vypnuta");
define("LAN_THEME_4", "Celá novinka");
define("LAN_THEME_5", "Trackbacks:");
define("LAN_THEME_8", "v");
define("LAN_THEME_9", "od");
define("LAN_THEME_11", "Aktuality");
define("LAN_THEME_12", "Odeslat emailem příteli");
define("LAN_THEME_13", "Vytvořit PDF");
define("LAN_THEME_14", "Tisk");
define("LAN_THEME_15", "Editovat");
define("LAN_THEME_17", "Přihlásit");
define("LAN_THEME_18", "Uživatelské jméno");
define("LAN_THEME_19", "Heslo");
define("LAN_THEME_20", "Registrovat");
define("LAN_THEME_21", "Přihlásit");
define("LAN_THEME_22", "Zapomněli jste heslo?");
define("LAN_THEME_23", "Vítejte");
define("LAN_THEME_24", "Administrace");
define("LAN_THEME_26", "Nastavení");
define("LAN_THEME_27", "Profil");
define("LAN_THEME_28", "Odhlásit se");
define("LAN_THEME_29", "Seznam novinek");
define("LAN_THEME_SING", "Přihlásit");
define("LAN_THEME_REG", "Registrovat");
define("LAN_SEARCH", "hledej...");
define("LAN_SEARCH_SUB", "Jdi");
define("LAN_THEME_SHARE", "Sdílet na");
define("LAN_THEME_VER", "e107");
define("CM_L13", "od");


?>