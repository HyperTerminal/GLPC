<?php
/*
+---------------------------------------------------------------+
|        e107 website content management system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/crahan/languages/Czech.php $
|        $Revision: 1.0.1 $
|        $Id: 2012/04/02 18:36:58 $
|        $Author: Oxigen $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'CraHan' by <a href='http://e107.org' rel='external'>jalist</a>, based on the theme by CraHan at his homepage <a href='http://n00.be' rel='external'>n00.be</a>");
define("LAN_THEME_2", "Diskuze vypnuta");
define("LAN_THEME_3", "Komentářů k novince:");
define("LAN_THEME_4", "Celá novinka ....");
define("LAN_THEME_5", "Zpětné odkazy:");
define("LAN_THEME_6", "Komentář napsal");


?>