<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/leaf/languages/Czech.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/31 09:58:04 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Komentář(e)");
define("LAN_THEME_2", "komentáře vypnuty");
define("LAN_THEME_3", "komentář(e)");
define("LAN_THEME_4", "Číst dále...");
define("LAN_THEME_5", "Zpětné odkazy:");
define("LAN_THEME_6", "Komentovat");
define("LAN_THEME_7", "Novinka");


?>