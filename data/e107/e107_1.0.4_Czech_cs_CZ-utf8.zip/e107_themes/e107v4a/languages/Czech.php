<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/e107v4a/languages/Czech.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/31 09:45:54 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "Číst/psát komentáře:");
define("LAN_THEME_2", "Komentáře jsou vypnuté");
define("LAN_THEME_3", "Číst dále ...");
define("LAN_THEME_4", "Publikoval");
define("LAN_THEME_5", "v");
define("LAN_THEME_6", "e107.v4 theme by <a href='http://e107.org' rel='external'>jalist</a>");


?>