<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/sebes/languages/Czech.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/31 10:06:13 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'sebes' by <a href='http://e107.org' rel='external'>jalist</a>");
define("LAN_THEME_2", "Číst/psát komentáře:");
define("LAN_THEME_3", "komentáře vypnuty");
define("LAN_THEME_4", "Číst dáel...");
define("LAN_THEME_5", "Zpětné odkyzy:");
define("LAN_THEME_6", "v");


?>