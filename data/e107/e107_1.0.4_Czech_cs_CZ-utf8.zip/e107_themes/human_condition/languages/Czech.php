<?php
/*
+---------------------------------------------------------------+
|        e107 website system Czech Language File
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
|
|        $URL: ../e107_themes/human_condition/languages/Czech.php $
|        $Revision: 1.0 $
|        $Id: 2011/07/31 09:48:57 $
|        $Author: Orlando $
+---------------------------------------------------------------+
*/

define("LAN_THEME_1", "'Human Condition' by <a href='http://e107.org' rel='external'>jalist</a>, based on the Wordpress theme, <a href='http://wordpress.org'>http://wordpress.org</a>.");
define("LAN_THEME_2", "Komentáře vypnuty");
define("LAN_THEME_3", "komentáře:");
define("LAN_THEME_4", "Číst dále...");
define("LAN_THEME_5", "Zpětné odkazy:");
define("LAN_THEME_6", "Komentář");


?>