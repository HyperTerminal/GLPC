<?php
$lang = array(


'eeof_example' => 
'タグの例！',

'translate' => 
'アップデート',

''=>''
);

// End of File