<?php

$lang = array(


''=>''

);

/* End of file edit_lang.php */
/* Location: ./system/expressionengine/language/english/edit_lang.php */