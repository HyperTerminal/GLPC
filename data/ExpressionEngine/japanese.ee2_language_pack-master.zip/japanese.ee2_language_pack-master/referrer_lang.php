<?php
$lang = array(


'referrer_module_name' => 
'リファラ',

'referrer_module_description' => 
'リファラトラッキングモジュール',

'referrer_preferences' => 
'リファラ設定',

'referrer_ip' => 
'リファラIP',

'referrer_date' => 
'リファラ日付',

'ref_ip' => 
'IPアドレス',

'ref_user_agent' => 
'ユーザエージェント',

'ref_url' => 
'URL',

'ref_type' => 
'タイプ',

'referrers' => 
'リファラ',

'view_referrers' => 
'リファラの表示',

'clear_referrers' => 
'リファラの消去',

'referrer_from' => 
'リファラ元',

'referrer_to' => 
'リファラ先',

'no_referrers' => 
'リファラは現在ありません。',

'referrer_no_results' => 
'入力した条件では結果がありません',

'total_referrers' => 
'リファラ総数:',

'save_instructions' => 
'保存したい最新のリファラの数はどのくらいですか?',

'referrers_deleted' => 
'リファラは削除されました。',

'referrer_deleted' => 
'リファラは削除されました。',

'delete_confirm' => 
'削除確認',

'referrer_delete_question' => 
'選択したリファラを本当に削除しますか?',

'blacklist_question' => 
'これらのリファラを削除する以外にできること:',

'add_urls' => 
'同一URLの他のリファラを削除しますか?',

'add_and_blacklist_urls' => 
'ブラックリストへURLを追加し、また同一URLの他のリファラを削除しますか?',

'add_ips' => 
'同一IPを持つほかのリファラを削除しますか?',

'add_and_blacklist_ips' => 
'ブラックリストにIPアドレスを追加し、また同一IPを持つほかのリファラを削除しますか?',

'add_agents' => 
'同一ユーザエージェントを持つ他のリファラを削除しますか?',

'add_and_blacklist_agents' => 
'ユーザエージェントをブラックリストに追加し、同一ユーザエージェントを持つ他のリファラを削除しますか?',

'translate' => 
'アップデート',

''=>''
);

// End of File