<?php
$lang = array(


'addons' => 
'アドン',

'accessories' => 
'アクセサリー',

'modules' => 
'モジュール',

'extensions' => 
'拡張',

'plugins' => 
'プラグイン',

'accessory' => 
'アクセサリー',

'module' => 
'モジュール',

'extension' => 
'拡張',

'addons_accessories' => 
'アクセサリー',

'addons_modules' => 
'モジュール',

'addons_plugins' => 
'プラグイン',

'addons_extensions' => 
'拡張',

'addons_fieldtypes' => 
'フィールドタイプ',

'accessory_name' => 
'アクセサリー名',

'fieldtype_name' => 
'フィールドタイプ名',

'install' => 
'インストール',

'uninstall' => 
'アンインストール',

'installed' => 
'インストールされています',

'not_installed' => 
'インストールされていません',

'uninstalled' => 
'アンインストールされました',

'remove' => 
'除去',

'preferences_updated' => 
'設定は更新されました',

'extension_enabled' => 
'拡張は有効されています',

'extension_disabled' => 
'拡張は無効されています',

'extensions_enabled' => 
'拡張は有効されています',

'extensions_disabled' => 
'拡張は無効されています',

'delete_fieldtype_confirm' => 
'このフィールドタイプを本当に除去しますか？',

'delete_fieldtype' => 
'フィールドタイプを除去する',

'data_will_be_lost' => 
'このフィールドタイプと関連されているデータは（チャネルデータを含む）永久に削除されます！',

'global_settings_saved' => 
'設定は保存されました',

'package_settings' => 
'パケージの設定',

'component' => 
'構成要素',

'current_status' => 
'現在のステータス',

'available_to_member_groups' => 
'メンバーのグループは使用できる',

'specific_page' => 
'特定のページ？',

'description' => 
'説明',

'version' => 
'バージョン',

'status' => 
'ステータス',

'fieldtype' => 
'フィールドタイプ',

'edit_accessory_preferences' => 
'アクセサリーの設定を編集する',

'member_group_assignment' => 
'指定されているメンバーのグループ',

'page_assignment' => 
'指定されているページ',

'none' => 
'なし',

'and_more' => 
'と %x 以上...',

'plugins_not_available' => 
'ベータバージョンではプラグインのフィード向こうされています',

'no_extension_id' => 
'拡張は指定されていません',

'translate' => 
'Update',

''=>''
);

// End of File