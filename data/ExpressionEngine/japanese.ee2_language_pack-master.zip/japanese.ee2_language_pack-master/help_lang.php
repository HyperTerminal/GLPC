<?php

$lang = array(

//----------------------------
// Help
//----------------------------


''=>''
);

/* End of file help_lang.php */
/* Location: ./system/expressionengine/language/english/help_lang.php */