<?php
$lang = array(


'no_js_warning' => 
'このテーマを上手く利用するため、ジャバスクリプトを有効してください。ブラウザの設定を確認してください。',

'nav_content' => 
'コンテンツ',

'nav_publish' => 
'制作',

'nav_edit' => '編集',
'nav_edit_all'					=> 'All Channels',

'nav_files' => 'ファイル',
	'nav_file_manager'				=> 'ファイルマネジャー',
	'nav_batch_upload'				=> '一括アップロード',
	'nav_sync_files'				=> 'ファイルの同期',

'nav_files_short_desc' => 'ファイルをアップロード、編集、削除する',
'nav_edit_short_desc' => 'エントリーを編集する',

'nav_design' => 
'デザイン',

'nav_create_group' => 
'グループを作成する',

'nav_create_template' => 
'テンプレートを作成する',

'nav_templates' => 
'テンプレート',

'nav_edit_templates' => 
'編集',

'nav_snippets' => 
'切り抜き',

'nav_snippets_short_desc' => 
'テンプレートのための切り抜きを作成、編集、削除する',

'nav_sync_templates' => 
'テンプレートを同時化する',

'nav_sync_templates_short_desc' => 
'テンプレートと関連なファイルを同時化する',

'nav_global_variables' => 
'グローバル変数',

'nav_global_variables_short_desc' => 
'ユーザから設定されたグローバル変数を作成、編集、削除する',

'nav_template_manager' => 
'テンプレートマネジャー',

'nav_template_manager_short_desc' => 
'テンプレートとテンプレートのグループを作成、編集、削除、管理する',

'nav_template_preferences' => 
'テンプレートの設定',

'nav_template_preferences_short_desc' => 
'テンプレートの設定を一括で変更する',

'nav_global_preferences' => 
'グローバルの設定',

'nav_global_preferences_short_desc' => 
'テンプレートの扱いと設定を管理する',

'nav_message_pages' => 
'メッセージのページ',

'nav_email_notification' => 
'メール通知',

'nav_email_notification_short_desc' => 
'メール通知のテンプレートを編集する',

'nav_user_message' => 
'ユーザのメッセージ',

'nav_user_message_short_desc' => 
'ユーザのメッセージのテンプレートを編集する',

'nav_offline_template' => 
'オフラインのテンプレート',

'nav_offline_template_short_desc' => 
'「システムがオフライン」のテンプレートを編集する',

'nav_themes' => 
'テーマ',

'nav_wiki_themes' => 
'ウィキー',

'nav_wiki_themes_short_desc' => 
'ウィキーのテーマを編集する',

'nav_forum_themes' => 
'掲示板',

'nav_forum_themes_short_desc' => 
'掲示板のテーマを編集する',

'nav_member_profile_templates' => 
'メンバーのプロファイルのテンプレート',

'nav_member_profile_templates_short_desc' => 
'メンバーのプロファイルのテンプレートを編集する',

'nav_addons' => 
'アドン',

'nav_accessories' => 
'アクセサリー',

'nav_accessories_short_desc' => 
'アクセサリーとアクセサリーの権利を管理する',

'nav_extensions' => 
'拡張',

'nav_extensions_short_desc' => 
'拡張を管理する',

'nav_plugins' => 
'プラグイン',

'nav_plugins_short_desc' => 
'プラグインをインストール・アンインストールしたり、プラグインの使い方を閲覧したいりする',

'nav_modules' => 
'モジュール',

'nav_modules_short_desc' => 
'モジュールの設定を管理する',

'nav_fieldtypes' => 
'フィールドタイプ',

'nav_fieldtypes_short_desc' => 
'フィールドのタイプの設定を管理する',

'nav_members' => 
'メンバー',

'nav_view_all_members' => 
'全てを表示する',

'nav_view_all_members_short_desc' => 
'全てのメンバーを見る',

'nav_member_groups' => 
'メンバーのグループ',

'nav_member_groups_short_desc' => 
'メンバーのグループを作成、編集、削除する',

'nav_ip_search' => 
'IP検索',

'nav_ip_search_short_desc' => 
'IPアドレスで万場ーを検索する',

'nav_register_member' => 
'メンバーを登録する',

'nav_register_member_short_desc' => 
'新メンバーを登録する',

'nav_user_banning' => 
'ユーザの禁止',

'nav_user_banning_short_desc' => 
'禁止の設定とい禁止されているメンバーを管理する',

'nav_activate_pending_members' => 
'未決定を有効する',

'nav_activate_pending_members_short_desc' => 
'未決定のメンバーを加減する',

'nav_custom_member_fields' => 
'カスタムメンバーフィールド',

'nav_custom_member_fields_short_desc' => 
'カスタムメンバーフィールドを作成・編集・削除する',

'nav_member_config' => 
'設定',

'nav_member_config_short_desc' => 
'メンバーシップの設定を管理する',

'nav_admin' => 
'管理',

'nav_channel_management' => 
'チャネルの管理',

'nav_channels' => 
'チャネル',

'nav_channels_short_desc' => 
'チャネルを作成、編集、削除する',

'nav_category_management' => 
'カテゴリー',

'nav_category_management_short_desc' => 
'カテゴリーを作成、編集、削除する',

'nav_field_group_management' => 
'カスタムフィルド',

'nav_field_group_management_short_desc' => 
'カスタムフィルドを作成、編集、削除する',

'nav_status_group_management' => 
'ステータスグループ',

'nav_status_group_management_short_desc' => 
'ステータスグループを作成、編集、削除する',

'nav_global_channel_preferences' => 
'グローバル設定',

'nav_global_channel_preferences_short_desc' => 
'チャネルのグローバル設定を管理する',

'nav_admin_content' => 'コンテンツの管理',
	'nav_file_upload_preferences' => 'ファイルアップロードの設定',
	'nav_file_upload_preferences_short_desc' => 'ファイルアップロードの設定を作成、編集、削除する',
	'nav_file_watermark_preferences'		=> '透かし模様の設定',
	'nav_file_upload_preferences_short_desc'	=> 'ファイルの透かし模様の設定を制作、編集、削除する',
	'nav_file_manager_short_desc'		=> 'ファイルのアップロードの設定',
	'nav_file_watermark_preferences_short_desc' => '透かし模様の設定',
	'nav_default_ping_servers' => 'デフォールトのpingサーバー',
	'nav_default_ping_servers_short_desc' => 'デフォールトのpingサーバーを作成、編集、削除する',
	'nav_default_html_buttons' => 'デフォールトのHTMLボタン',
	'nav_default_html_buttons_short_desc' => 'デフォールトのHTMLボタンを作成、編集、削除する',
	
'nav_security_and_privacy' => 'セキュリティーとプライバシー',

'nav_admin_system' => 'システム管理',
	'nav_general_configuration' => '一般設定',
	'nav_general_configuration_short_desc' => '一般設定を管理する',
	'nav_email_configuration' => 'Eメールの設定',
	'nav_email_configuration_short_desc' => 'Eメールの設定を管理する',
	'nav_localization_settings' => 'ローカライゼーションの設定',
	'nav_localization_settings_short_desc' => 'ローカライゼーションの設定を管理する',
	'nav_database_settings' => 'データベース設定',
	'nav_database_settings_short_desc' => 'データベース設定を設定する',
	'nav_output_debugging_preferences' => '出力とデバッグ',
	'nav_output_debugging_preferences_short_desc' => '出力とデバッグを管理する',
	'nav_security_session_preferences' => 'セキューリティーとセッション',
	'nav_security_session_preferences_short_desc' => 'セキューリティーとセッションを管理する',
	'nav_captcha_preferences' => 'CAPTCHAの設定',
	'nav_captcha_preferences_short_desc' => 'CAPTCHAの設定を管理する',
	'nav_throttling_configuration' => 'スロットル（絞込み）の設定',
	'nav_throttling_configuration_short_desc' => 'スロットル（絞込み）の設定を管理する',
	'nav_tracking_preferences' => 'トラッキングの設定',
	'nav_tracking_preferences_short_desc' => 'トラッキングの設定を管理する',
	'nav_cookie_settings' => 'クッキーの設定',
	'nav_cookie_settings_short_desc' => 'クッキーの設定を管理する',
	'nav_image_resizing_preferences' => '画像のサイズ変更の設定',
	'nav_image_resizing_preferences_short_desc' => '画像のサイズ変更の設定を管理する',
	'nav_emoticon_preferences' => '絵文字の設定',
	'nav_emoticon_preferences_short_desc' => '絵文字の設定を管理する',
	'nav_word_censoring' => '禁止の語彙',
	'nav_word_censoring_short_desc' => '禁止の語彙を管理する',
	'nav_search_log_configuration' => '検索ログの設定',
	'nav_search_log_configuration_short_desc' => '検索ログの設定を管理する',

'nav_tools' => 'ツール',
'nav_tools_communicate' => 'コミュニケート',
'nav_tools_communicate_short_desc' => 'メールを送信する',

'nav_tools_utilities' => 'ユーティリティー',

'nav_translation_tool' => 
'翻訳ユーティリティー',

'nav_translation_tool_short_desc' => 
'翻訳ユーティリティー',

'nav_import_utilities' => 
'輸入ユーティリティー',

'nav_import_utilities_short_desc' => 
'コンテンツを輸入する',

'nav_php_info' => 
'PHP情報',

'nav_php_info_short_desc' => 
'PHP情報（詳細）',

'nav_config_editor' => 
'configファイルのエディター',

'nav_config_editor_short_desc' => 
'設定ファイルのエディターの設定',

'nav_tools_data' => 
'データ',

'nav_sql_manager' => 
'SQLマネジャー',

'nav_sql_manager_short_desc' => 
'データベース管理のユーティリティー',

'nav_clear_caching' => 
'キャッシングをクリアする',

'nav_clear_caching_short_desc' => 
'キャッシュデータをクリアする',

'nav_search_and_replace' => 
'検索置換',

'nav_search_and_replace_short_desc' => 
'検索置換',

'nav_recount_stats' => 
'統計の再集計',

'nav_recount_stats_short_desc' => 
'統計の再集計と同時化',

'nav_tools_logs' => 
'ログ',

'nav_view_cp_log' => 
'コントロールパネルのログ',

'nav_view_cp_log_short_desc' => 
'コントロールパネルのログを表示とクリアする',

'nav_view_search_log' => 
'検索のログ',

'nav_view_search_log_short_desc' => 
'検索のログを表示とクリアする',

'nav_view_throttle_log' => 
'スロットル（絞込み）のログ',

'nav_view_throttle_log_short_desc' => 
'スロットル（絞込み）のログを表示とクリアする',

'nav_view_email_log' => 
'Eメールコンソールメッセージのログ',

'nav_view_email_log_short_desc' => 
'Eメールコンソールメッセージのログを表示とクリアする',

'nav_help' => 
'ヘルプ',

'nav_overview' => 
'概要',

'nav_add_tab' => 
'追加',

'session_expiring' => 
'セッション時間が過ぎました。データの損失を防ぐためもう一度ログインしてください。',

'loading' => 
'ロード中',

'show_hide' => 
'すべて表示／非表示',

'new_tab' => 
'新規タブ',

'new_version_available' => 
'ExpressionEngineバージョン%sは現在利用可能です。',

'consult_user_guide' => 
'ユーザガイドを参照',

'powered_by' => 
'Powered By（駆動源）',

'control_panel' => 
'コントロールパネル',

'main_menu' => 
'CPホーム',

'username' => 
'ユーザネーム',

'password' => 
'パスワード',

'logged_back_in' => 
'もう一度ログインしました。',

'my_account' => 
'マイアカウント',

'myaccount' => 
'マイアカウント',

'user_account' => 
'メンバーアカウント',

'user_guide' => 
'ユーザガイド',

'logout_confirm' => 
'本当にログアウトしますか？',

'logout' => 
'ログアウト',

'session_timeout' => 
'不応のためまもなくセッションは終了します。',

'login' => 
'ログイン',

'copyright' => 
'著作権',

'rights_reserved' => 
'無断転載禁ず（著作権所有）',

'page_rendered' => 
'%x秒で実行されるスクリプト',

'queries_executed' => 
'使用されている%xSQLクエリ',

'build' => 
'ビルド:',

'forgot_password' => 
'パスワードを忘れましたか?',

'e_no_css' => 
'要求したCSSファイルは開くことができませんでした。',

'unauthorized' => 
'許可されていない',

'unauthorized_access' => 
'このページへのアクセスは許可されていません。',

'be_careful' => 
'注意してください!',

'action_can_not_be_undone' => 
'このアクションは取り消すことができません。',

'captcha_explanation' => 
'captchaは、ユーザが提出する必要があるセキュリティコードを含む画像です。詳細はユーザガイドを参照してください。',

'back' => 
'バック',

'no' => 
'いいえ',

'yes' => 
'はい',

'all' => 
'すべて',

'any' => 
'任意の',

'mobile_not_supported' => 
'この機能はモバオルのブラウザーでは未対応です',

'required_fields' => 
'要求されたフィールドを表示',

'please_consult_manual' => 
'ユーザガイドを参照してください。',

'forgotten_password' => 
'忘れたパスワード',

'submit_email_address' => 
'Eメールアドレスを提出してください。',

'click_to_edit' => 
'編集するにはクリックしてください。',

'notepad' => 
'ノートパッド',

'notepad_no_content' => 
'ノートパッドのエントリーがありません。作成するにはクリックしてください。',

'edit_quicklinks' => 
'クイックリンクの編集',

'quick_links' => 
'クイックリンク',

'quicklinks_manager' => 
'クイックリンクの管理',

'hide_sidebar' => 
'サイドバーを隠す',

'reveal_sidebar' => 
'サイドバーを表示する',

'submit' => 
'実行',

'preview' => 
'プレビュー',

'update' => 
'アップデート',

'edit' => 
'ページ編集',

'delete' => 
'削除',

'save_changes' => 
'変更を保存',

'save' => 
'保存',

'cancel' => 
'キャンセル',

'done' => 
'終了',

'clear_logs' => 
'ログファイルを消去',

'member_id' => 
'メンバーID',

'ip_address' => 
'IPアドレス',

'date' => 
'日付',

'action' => 
'アクション',

'member_logged_in' => 
'ログインしました。',

'member_logged_out' => 
'ログアウトしました。',

'cleared_logs' => 
'ログファイルを消去しました。',

'close' => 
'閉じる',

'create' => 
'作成する',

'create_and_edit' => 
'作成と編集する',

'modify' => 
'変更する',

'or_delete' => 
'または削除する',

'view' => 
'見る',

'switch' => 
'切り替え',

'entry' => 
'エントリー',

'template' => 
'テンプレート',

'template_group' => 
'テンプレートのグループ',

'page' => 
'ページ',

'channel' => 
'チャネル',

'site' => 
'サイト',

'most_recent_entry' => 
'一番最近のエントリー',

'most_recent_comment' => 
'一番最近のコメント',

'recent_entries' => 
'最近のエントリー',

'recent_comments' => 
'最近のコメント',

'ee_wiki' => 
'EEのウィキー',

'status' => 
'ステータス',

'select_all' => 
'全てを選択する',

'sites' => 
'サイト',

'view_site' => 
'サイトを見る',

'edit_sites' => 
'サイトの編集',

'edit_channels' => 
'チャンルを編集する',

'site_id' => 
'サイトID',

'site_specific_data' => 
'このデータはサイト固有のものです。別のサイトのデータを選択または変更したい場合は、‘サイト’メニュタブでそのサイトに切り替えてください。',

'sig_img_path' => 
'サイン画像のパス',

'avatar_path' => 
'アバターのパス',

'photo_path' => 
'メンバー画像のパス',

'prv_msg_upload_path' => 
'プライベートメッセージのアップロードのパス',

'not_writable_path' => 
'次のフォルダは書き込めません：',

'videos' => 
'ビデオ',

'community_tutorials' => 
'コミュニティーのチュートリアル',

'community_resources' => 
'コミュニティーのリーソース',

'support' => 
'サポート',

'installing_ee' => 
'ExpressionEngineをインストールする',

'introduction_to_templates' => 
'テンプレートのご紹介',

'channels_custom_fields' => 
'チャネルとカスタムフィールド',

'channel_template_relationship' => 
'チャネルとテンプレートの関係',

'building_ee_site_01' => 
'ExpressionEngineのサイトを作る - 第一章',

'designing_ee_architecture' => 
'ExpressionEngineにてのデザインと建築',

'troubleshooting_file_uploads' => 
'ファイルアップロードの問題に関するトラブルシューティング',

'ee_cp_overview' => 
'ExpressionEngineのコントロールパネルのまとめ',

'ee_seach_bookmarklet' => 
'ExpressionEngineの検索ブックマークレット',

'wiki' => 
'ウィキー',

'support_forums' => 
'サポート掲示板',

'knowledge_base' => 
'知識ベース',

'documentation' => 
'説明書',

'my_downloads' => 
'マイダウンロード',

'train_ee' => 
'Train-EE',

'ee_screencasts' => 
'EE Screencasts',

'ee_insider' => 
'EE Insider',

'devot_ee' => 
'Devot-EE',

'ee_podcast' => 
'EE Podcast',

'translate' => 
'Update',

''=>''
);

// End of File