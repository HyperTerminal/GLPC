<?php
$lang = array(


'add_file' => 
'ファイルを追加する',

'remove_file' => 
'ファイルを削除する',

'directory_no_access' => 
'このフィールドのダイレクトリーをサクセスする許可が持っていません',

'directory' => 
'ダイレクトリー：',

'translate' => 
'アップデート',

''=>''
);

// End of File