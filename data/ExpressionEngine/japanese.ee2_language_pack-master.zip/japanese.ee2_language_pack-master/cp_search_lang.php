<?php
$lang = array(


'design_user_message' => 
'ユーザーメッセージのテンプレート',

'design_system_offline' => 
'システムオフラインのテンプレート',

'design_email_notification' => 
'Eメール通知のテンプレート',

'design_member_profile_templates' => 
'メンバープロファイルのテンプレート',

'member_register_member' => 
'メンバーを登録する',

'member_validation' => 
'メンバーの確認',

'member_view_members' => 
'メンバーを表示する',

'member_ip_search' => 
'メンバーIP検索',

'member_custom_profile_fields' => 
'メンバーのカスタムフィールド',

'member_group_manager' => 
'メンバーグループの管理',

'member_config' => 
'メンバーの設定',

'member_banning' => 
'メンバーの禁止',

'member_search' => 
'メンバーの検索',

'data_sql_manager' => 
'SQLマネジャー',

'data_search_and_replace' => 
'検索置換',

'data_recount_stats' => 
'統計を再計算する',

'data_php_info' => 
'PHP情報',

'data_clear_caching' => 
'キャッシュをクリアする',

'file_index' => 
'ファイルマネジャー',

'cont_field_group_management' => 
'フィールドグループの管理',

'members_member_group_manager' => 
'メンバーグループの管理',

'cont_category_management' => 
'カテゴリーの管理',

'members_custom_profile_fields' => 
'メンバーのカスタムプロファイルのフィールド',

'logs_view_cp_log' => 
'コントロールパネルのログを見る',

'logs_view_throttle_log' => 
'スロットルのログを見る',

'logs_view_search_log' => 
'検索のログを見る',

'logs_view_email_log' => 
'Eメールのログを見る',

'util_member_import' => 
'メンバーのインポート',

'util_import_from_mt' => 
'MTからのインポート',

'util_import_from_xml' => 
'XMLからのインポート',

'util_translation_tool' => 
'翻訳ユーティリティ',

'plug_index' => 
'プラグイン',

'modu_index' => 
'モジュール',

'exte_index' => 
'拡張',

'acce_index' => 
'アクセサリ',

'translate' => 
'Update',

''=>''
);

// End of File