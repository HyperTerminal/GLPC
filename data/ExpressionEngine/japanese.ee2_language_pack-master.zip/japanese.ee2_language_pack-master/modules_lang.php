<?php
$lang = array(


'module_name' => 
'モジュールネーム',

'module_description' => 
'詳細',

'data_will_be_lost' => 
'このモジュールに関連するデータはすべて永久に削除されます!',

'module_access' => 
'モジュールの編集',

'module_no_access' => 
'モジュールへのアクセスは許可されていません。',

'delete_module' => 
'モジュールの取り外し',

'delete_module_confirm' => 
'下記モジュールを本当に取り外しますか？:',

'module_backend' => 
'ユーザCP',

'module_version' => 
'バージョン',

'module_status' => 
'ステータス',

'module_action' => 
'アクション',

'not_installed' => 
'インストールされていません。',

'installed' => 
'インストールされています。',

'install' => 
'インストール',

'update_modules' => 
'モジュールのアップデートを実行する',

'updated' => 
'アップデートされました',

'updated_to_version' => 
'新バージョンにアップデートされます。',

'all_modules_up_to_date' => 
'すべてのモジュールはアップデートされています',

'deinstall' => 
'削除',

'module_can_not_be_found' => 
'このモジュールのインストールに必要なファイルを配置することができません。',

'module_has_been_installed' => 
'インストールされたモジュール:',

'module_has_been_removed' => 
'削除されたモジュール:',

'requested_module_not_installed' => 
'リクエストしたモジュールはインストールされていません',

'requested_page_not_found' => 
'リクエストしたモジュールのページは見つけられません',

'translate' => 
'アップデート',

''=>''
);

// End of File