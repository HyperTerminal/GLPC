<?php
$lang = array(


'remember_me' => 
'今後訪問する際に自動ログインしますか?',

'no_username' => 
'提出したユーザネームはデータベースにありませんでした。',

'no_password' => 
'提出したパスワードは間違っています。',

'no_email' => 
'Eメールアドレスを提出してください。',

'credential_missmatch' => 
'ユーザーネームもしくはパスワードは不正です。',

'multi_login_warning' => 
'このアカウントを使って誰かがすでにログインしています。',

'return_to_login' => 
'ログイン画面に戻ります。',

'password_lockout_in_effect' => 
'%x分おきに4回ログインすることが許可されています。',

'unauthorized_request' => 
'このアクションを実行する権限はありません。',

'new_password_request' => 
'新しいパスワードのリクエスト',

'session_auto_timeout' => 
'不応のためセッションはタイムアウトしました。',

'translate' => 
'アップデート',

''=>''
);

// End of File