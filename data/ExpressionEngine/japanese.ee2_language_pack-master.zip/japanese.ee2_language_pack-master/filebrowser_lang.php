<?php

$lang = array(

"file_browser" =>
"ファイルブラウザ",

"view" =>
"表示",

"path_does_not_exist" => 
"その特定のパスは存在しません。",

"file_viewing_error" =>
"未知のエラーが生じました。",

"fp_no_files" => 
"ディレクトリにファイルがありません。",

"fb_view_images" =>
"画像の表示",

"fb_view_image" =>
"画像の表示",

"fb_insert_file" =>
"ファイルの挿",

"fb_insert_files" =>
"ファイルの挿入",

"fb_select_field" =>
"フィールドの選択",

"fb_select_files" =>
"ファイルの選択",

"fb_non_images" =>
"*は画像ではないことを示します。画像のみ表示可能です。",

"fb_insert_link" =>
"リンクの挿入",

"fb_insert_links" =>
"リンクの挿入",

"fb_insert_url" =>
"URLの挿入",

"fb_insert_urls" =>
"URLの挿入",


// IGNORE
''=>'');
