<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"rss_module_name" =>
"RSS",

"rss_module_description" =>
"RSSページ生成モジュール",

//----------------------------------------

"rss_invalid_channel" =>
"RSSフィードに指定されているチャネルは存在しません。",


/* END */
''=>''
);

