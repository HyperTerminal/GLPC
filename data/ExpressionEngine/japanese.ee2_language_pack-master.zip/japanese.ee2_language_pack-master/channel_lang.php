<?php
$lang = array(


'channel_module_name' => 
'チャネル',

'channel_module_description' => 
'チャネルのモジール',

'channel_no_preview_template' => 
'プレビューのテンプレートはタグに指定されていません',

'channel_must_be_logged_in' => 
'このアクションをするにはログインしているメンバーが必要です。',

'channel_not_specified' => 
'エントリフォームを使うにはチャネルを指定しないといけません。',

'channel_no_action_found' => 
'エントリフォームの作成のためのリソースはロードできませんでした。',

'translate' => 
'Update',

''=>''
);

// End of File