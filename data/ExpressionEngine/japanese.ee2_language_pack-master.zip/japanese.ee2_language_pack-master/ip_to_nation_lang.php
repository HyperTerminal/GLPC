<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"ip_to_nation_module_name" =>
"IP-to-Nation（IPから国を推量）",

"ip_to_nation_module_description" =>
"IPアドレスと国を関連付けるユーティリティ",

//----------------------------------------

"iptonation_missing" =>
"iptonation.phpというファイルはありません。このモジュールの全コンポーネントをアップロードしているか確認してください。",

"countryfile_missing" =>
"libフォルダにcountry.phpというファイルはありません。",

"ip_search" =>
"IPアドレス検索",

"ip_search_inst" =>
"関連付ける国を決定するためにIPアドレスを提出してください。",

"ip_result" =>
"提出されたIPは下記の国のアドレスです。:",

"manage_banlist" =>
"禁止された国のリストを管理します。",

"country" =>
"国",

"ban_info" =>
"排除（禁止）したい国を選択します。ある国が排除されると、その国に対応するIPアドレスを持つ人は、コメント、トラックバックの投稿ができず、またはEメール／tell-a-friendフォームを使用することができません。ただし、サイトを表示することはできます。",

"ban" =>
"禁止（サーバから排除／追い出し）",

"banlist" =>
"国のバンリスト",

"banlist_updated" =>
"バンリストがアップデートされました。",

/* END */
''=>''
);

