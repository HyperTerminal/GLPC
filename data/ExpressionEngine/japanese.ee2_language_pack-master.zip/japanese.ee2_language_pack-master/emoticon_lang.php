<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"emoticon_module_name" =>
"エモティコン（顔文字）",

"emoticon_module_description" =>
"エモティコン（顔文字／スマイリー）モジュール",


//----------------------------------------
// Emoticon language lines
//----------------------------------------

"emoticon_heading" =>
"エモティコン",

"emoticon_glyph" =>
"グリフ",

"emoticon_image" =>
"画像",

"emoticon_width" =>
"幅",

"emoticon_height" =>
"高さ",

"emoticon_alt" =>
"Alt tag（オルトタグ）",

/* END */
''=>''
);

