<?php

$lang = array(

//----------------------------
// Publish page
//----------------------------

'spell_check' =>
"スペルチェック",

'check_spelling' =>
"スペルをチェックします。",

"save_spellcheck" =>
"変更保存",

"revert_spellcheck" =>
"元に戻します。",

'spell_save_edit' =>
"編集保存",

'spell_edit_word' =>
"ワードを編集",

'unsupported_browser' =>
"非サポートのブラウザ",

'no_spelling_errors' =>
"エラーは検出されません。",

'spellcheck_in_progress' =>
"チェック中です...",

/* END */
''=>''
);


