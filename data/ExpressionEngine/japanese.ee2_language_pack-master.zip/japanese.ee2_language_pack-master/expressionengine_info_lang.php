<?php
$lang = array(


'expressionengine_info' => 
'ExpressionEngine情報',

'resources' => 
'リソース',

'documentation' => 
'オンライン資料',

'support_forums' => 
'テクニカルサポートの掲示板',

'downloads' => 
'マイExpressionEngineストアのダウンロード',

'support_resources' => 
'サポートの資料',

'version_and_build' => 
'バージョンとビルド',

'error_getting_version' => 
'只今、現在のバージョンを読み込むことができませんでした。',

'version_info' => 
'現在のExpressionEngineバージョンは %v Build %b　です。',

'translate' => 
'アップデート',

''=>''
);

// End of File