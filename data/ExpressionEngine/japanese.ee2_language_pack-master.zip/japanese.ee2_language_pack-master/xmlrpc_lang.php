<?php
$lang = array(


'invalid_license' => 
'無効のライセンス',

'translate' => 
'Update',

''=>''
);

// End of File