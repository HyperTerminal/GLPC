<?php
$lang = array(


'sql_info' => 
'SQL情報',

'sql_utilities' => 
'SQLユーティリティ',

'database_type' => 
'データベースタイプ',

'sql_version' => 
'データベースバージョン',

'database_size' => 
'データベースサイズ',

'database_uptime' => 
'データベースアップタイム',

'total_queries' => 
'スタートアップ以後のサーバクエリの総数',

'sql_status' => 
'ステータス情報',

'sql_system_vars' => 
'システム変数',

'sql_processlist' => 
'プロセスリスト',

'sql_query_form' => 
'Database Query Form',

'query_result' => 
'クエリ結果',

'query' => 
'SQL クエリ',

'total_results' => 
'結果総数: %x',

'total_affected_rows' => 
'影響を受けた行の総数: ',

'browse' => 
'ブラウズ（閲覧）',

'tables' => 
'テーブル',

'table_name' => 
'テーブルネーム',

'records' => 
'レコード',

'size' => 
'サイズ',

'type' => 
'タイプ',

'analyze' => 
'テーブルを分析する',

'optimize' => 
' SQLテーブルの最適化',

'repair' => 
'SQLテーブルの修理',

'optimize_table' => 
'選択したテーブルの最適化',

'repair_table' => 
'選択したテーブルの修理',

'no_buttons_selected' => 
'このアクションを実行するテーブルを選択する必要があります。',

'sql_view_database' => 
'Manage Database Tables',

'sql_no_result' => 
'入力したクエリでは結果が得られませんでした。',

'sql_not_allowed' => 
'残念ですが、それは許可されていないクエリタイプでした。',

'sql_query_instructions' => 
'SQLクエリの提示にこのフォームを使用します。',

'sql_query_debug' => 
'MySQLエラー出力を有効にします。',

'sql_good_query' => 
'クエリが成功しました。',

'cache_deleted' => 
'キャッシュファイルは削除されています。',

'site_preferences' => 
'サイトプリファレンス',

'channel_entry_title' => 
'ブログエントリタイトル',

'channel_fields' => 
'ブログフィールド:',

'templates' => 
'すべてのテンプレートで',

'template_groups' => 
'テンプレートのグループ',

'rows_replaced' => 
'置換が発生するデータベースレコードの数:',

'choose_below' => 
'（以下からお選びください）',

'if_replacing_templates' => 
'テンプレート中に置換をする場合、まず<a href="%x">データベースと同期してください</a>。同期しないと',

'permanent_data_loss' => 
'永久にデータの紛失の可能性があります！',

'recalculate' => 
'統計の再集計',

'do_recount' => 
'再集計の実行',

'source' => 
'ソース',

'recount_info' => 
'下記リンクにより、各メンバーが提出したエントリ数など、各種統計を更新することができます。',

'members' => 
'メンバー',

'channel_titles' => 
'チャネルのエントリ',

'site_statistics' => 
'サイト統計',

'forums' => 
'掲示板',

'forum_topics' => 
'掲示板の話題',

'recount_completed' => 
'再集計が終わりました',

'recount_prefs' => 
'再集計の設定',

'translate' => 
'アップデート',

''=>''
);

// End of File