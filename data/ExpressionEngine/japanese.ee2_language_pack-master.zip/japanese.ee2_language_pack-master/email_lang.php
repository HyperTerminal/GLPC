<?php

$lang = array(

//----------------------------
// Email
//----------------------------

"email_module_name" =>
"Eメール",

"email_module_description" =>
"ユーザEメールモジュール",

'message_required' =>
"Eメールメッセージが必要です。",

'em_banned_from_email' => 
"提出した送信者Eメールアドレスは禁止されています。",

'em_banned_recipient' =>
"受信者Eメールの1つ以上が禁止されています。",

'em_invalid_recipient' =>
"受信者Eメールの1つ以上が無効です。",

'em_no_valid_recipients' =>
"Eメールには有効な受信者がいませんでした。",

'em_sender_required' =>
"有効な送信者Eメールが必要です。",

"em_unauthorized_request" =>
"このアクションを実行する権限がありません。",

'em_limit_exceeded' =>
"1日に送信を許可されているEメールの数を超えています。",

'em_interval_warning' =>
"%s秒間隔でEメールフォームの提示のみ許可されています。",

"em_email_sent" =>
"Eメールメッセージは送信されました。",


/* END */
''=>''
);

