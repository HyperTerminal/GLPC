<?php
$lang = array(


'jquery_module_name' => 
'jQuery',

'jquery_module_description' => 
'jQuery モジュール',

'missing_jquery_file' => 
'リクエストしたjQueryファイルは見つけられませんでした',

'translate' => 
'アップデート',

''=>''
);

// End of File