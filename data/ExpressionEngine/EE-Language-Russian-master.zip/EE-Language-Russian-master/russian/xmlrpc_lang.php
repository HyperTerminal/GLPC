<?php
$lang = array(


'invalid_license' => 
'Неверная лицензия',

'translate' => 
'Обновить',

''=>''
);

// End of File