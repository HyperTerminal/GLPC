<?php
$lang = array(


'blacklist_module_name' => 
'Черный / Белый список',

'blacklist_module_description' => 
'Модуль черного и белого списков',

'htaccess_written_successfully' => 
'Файл .htaccess был успешно записан.',

'invalid_htaccess_path' => 
'Неправильный путь или права доступа для файла .htaccess',

'htaccess_server_path' => 
'Путь на сервере к файлу .htaccess',

'write_htaccess_file' => 
'Записать черный список в файл .htaccess?',

'whitelist' => 
'Белый список',

'ee_whitelist' => 
'Скачать Белый список с ЕxpressionЕngine.com',

'whitelist_updated' => 
'Белый список успешно обновлен',

'ref_whitelist_irretrievable' => 
'Ошибка: новый белый список получить не удалось.',

'ref_view_whitelist' => 
'Просмотр белого списка',

'ref_no_whitelist' => 
'На данный момент белый список пуст',

'ref_whitelisted' => 
'Занесены в белый список',

'ref_no_whitelist_table' => 
'В базе данных нет таблицы белого списка',

'ref_type' => 
'Тип',

'blacklist' => 
'Черный список',

'ee_blacklist' => 
'Скачать Черный список с ЕxpressionЕngine.com',

'requires_license_number' => 
'Необходим номер лицензии в Основных настройках',

'blacklist_updated' => 
'Черный список успешно обновлен',

'ref_no_license' => 
'Ошибка: отсутствует номер лицензии.',

'ref_blacklist_irretrievable' => 
'Ошибка: новый черный список получить не удалось.',

'ref_view_blacklist' => 
'Просмотр черного списка',

'ref_no_blacklist' => 
'На данный момент черный список пуст',

'ref_ip' => 
'IP-адрес',

'ref_user_agent' => 
'Браузер',

'ref_url' => 
'URL',

'ref_blacklisted' => 
'Занесены в черный список',

'ref_no_blacklist_table' => 
'В базе данных нет таблицы черного списка',

'translate' => 
'Обновить',

''=>''
);

// End of File