<?php
$lang = array(

''						=>		'',
// IGNORE
''=>'');
/* End of file edit_lang.php */