<?php
$lang = array(


'eeof_example' => 
'Пример тега!',

'translate' => 
'Обновить',

''=>''
);

// End of File