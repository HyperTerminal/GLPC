<?php
$lang = array(


'jquery_module_name' => 
'jQuery',

'jquery_module_description' => 
'Модуль jQuery',

'missing_jquery_file' => 
'Запрошенный jQuery файл не найден.',

'translate' => 
'Update',

''=>''
);

// End of File