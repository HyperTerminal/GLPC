<?php
$lang = array(

''						=>		'',
// IGNORE
''=>'');
/* End of file css_lang.php */