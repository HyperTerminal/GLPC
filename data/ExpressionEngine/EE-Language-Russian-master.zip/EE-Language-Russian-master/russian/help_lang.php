<?php
$lang = array(

''						=>		'',
// IGNORE
''=>'');
/* End of file help_lang.php */