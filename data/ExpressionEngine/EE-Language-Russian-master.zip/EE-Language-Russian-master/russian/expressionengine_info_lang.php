<?php
$lang = array(


'expressionengine_info' => 
'Информация о ExpressionEngine',

'resources' => 
'Ресурсы',

'documentation' => 
'Документация',

'support_resources' => 
'Техническая поддержка',

'downloads' => 
'Мои покупки в ExpressionEngine',

'running_current' => 
'ExpressionEngine в актуальном состоянии (%v)',

'version_update_available' => 
'Доступна новая версия ExpressionEngine',

'version_update_inst' => 
'<a href="%d">Скачайте последнюю версию</a> и следуйте <a href="%i">инструкциям по установке</a>.',

'current_version' => 
'Последняя: %v',

'installed_version' => 
'Установленная: %v',

'version_and_build' => 
'Версия и сборка',

'error_getting_version' => 
'Вы используете ExpressionEngine %v. Невозможно получить текущую версию сейчас.',

'translate' => 
'Обновить',

''=>''
);

// End of File