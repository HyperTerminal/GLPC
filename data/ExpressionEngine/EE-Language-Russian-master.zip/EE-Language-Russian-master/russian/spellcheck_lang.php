<?php
$lang = array(


'spell_check' => 
'Проверка орфографии',

'check_spelling' => 
'Проверить орфографию',

'save_spellcheck' => 
'Сохранить изменения',

'revert_spellcheck' => 
'Восстановить оригинал',

'spell_save_edit' => 
'Сохранить изменения',

'spell_edit_word' => 
'Редактировать слово',

'unsupported_browser' => 
'Этот браузер не поддерживает данную функцию',

'no_spelling_errors' => 
'Ошибок не найдено',

'spellcheck_in_progress' => 
'Выполняется проверка...',

'translate' => 
'Update',

''=>''
);

// End of File