<?php
$lang = array(


'add_file' => 
'Добавить файл',

'remove_file' => 
'Удалить файл',

'directory_no_access' => 
'У вас нет доступа к полям этого каталога',

'directory' => 
'Каталог:',

'translate' => 
'Update',

''=>''
);

// End of File