<?php
$lang = array(


'channel_module_name' => 
'Канал',

'channel_module_description' => 
'Модуль управления каналами',

'channel_no_preview_template' => 
'Шаблон предпросмотра не указан в Вашем теге',

'channel_must_be_logged_in' => 
'Вы должны быть авторизованы для выполнения этого действия.',

'channel_not_specified' => 
'Вы должны указать канал для использования этой формы ввода записи.',

'channel_no_action_found' => 
'Невозможно загрузить ресурсы, необходимые для создания формы ввода записи',

'translate' => 
'Update',

''=>''
);

// End of File