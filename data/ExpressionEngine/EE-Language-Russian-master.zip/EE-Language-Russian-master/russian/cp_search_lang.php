<?php
$lang = array(


'design_user_message' => 
'Шаблон сообщений пользователю',

'design_system_offline' => 
'Шаблон отключенной системы',

'design_email_notification' => 
'Шаблоны email-уведомлений',

'design_member_profile_templates' => 
'Шаблоны профиля участника',

'member_register_member' => 
'Регистрация нового участника',

'member_validation' => 
'Активировать ожидающих участников',

'member_view_members' => 
'Просмотр Участников',

'member_ip_search' => 
'Поиск по IP участников',

'member_custom_profile_fields' => 
'Настраиваемые поля профиля',

'member_group_manager' => 
'Группы участников',

'member_config' => 
'Настройка участников',

'member_banning' => 
'Блокировка участников',

'member_search' => 
'Поиск участника',

'data_sql_manager' => 
'Sql Менеджер',

'data_search_and_replace' => 
'Поиск и замена',

'data_recount_stats' => 
'Пересчитать статистику',

'data_php_info' => 
'PHP Info',

'data_clear_caching' => 
'Очистка кеша',

'file_index' => 
'Файловый менеджер',

'cont_field_group_management' => 
'Управление группой полей',

'members_member_group_manager' => 
'Управление группами пользователей',

'cont_category_management' => 
'Управление категорией',

'members_custom_profile_fields' => 
'Дополнительные поля профиля пользователя',

'logs_view_cp_log' => 
'Просмотр журнала Панели управления',

'logs_view_throttle_log' => 
'Просмотр результатов ограничения активности посетителей',

'logs_view_search_log' => 
'Просмотр журнала регистрации поисковых запросов',

'logs_view_email_log' => 
'Просмотр журнала email отправлений',

'util_member_import' => 
'Импорт участников',

'util_import_from_mt' => 
'Импорт из MT',

'util_import_from_xml' => 
'Импорт из XML',

'util_translation_tool' => 
'Утилиты перевода',

'plug_index' => 
'Плагины',

'modu_index' => 
'Модули',

'exte_index' => 
'Расширения',

'acce_index' => 
'Аксессуары',

'translate' => 
'Update',

''=>''
);

// End of File