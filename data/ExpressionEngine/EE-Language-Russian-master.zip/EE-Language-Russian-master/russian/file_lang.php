<?php
$lang = array(


'content_files' => 
'Файлы',

'file_module_name' => 
'Файл',

'file_module_description' => 
'Модуль файлов',

'translate' => 
'Update',

''=>''
);

// End of File