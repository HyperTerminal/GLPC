<?php
$lang = array(


'module_name' => 
'Название модуля',

'module_description' => 
'Описание',

'data_will_be_lost' => 
'Все данные, связанные с этим модулем, будут безвозвратно удалены!',

'module_access' => 
'Редактировать модуль',

'module_no_access' => 
'У Вас нет доступа к модулям',

'delete_module' => 
'Деинсталлировать модуль',

'delete_module_confirm' => 
'Вы уверены, что хотите деинсталлировать указанный модуль:',

'module_backend' => 
'ПУ пользователя',

'module_version' => 
'Версия',

'module_status' => 
'Статус',

'module_action' => 
'Действие',

'not_installed' => 
'Не установлен',

'installed' => 
'Установлен',

'install' => 
'Установить',

'update_modules' => 
'Выполнить обновление модуля',

'updated' => 
'Обновлено',

'updated_to_version' => 
'обновлено к версии',

'all_modules_up_to_date' => 
'Все модули обновлены до последней версии.',

'deinstall' => 
'Удалить',

'module_can_not_be_found' => 
'Невозможно найти файлы, необходимые для этого модуля',

'module_has_been_installed' => 
'Установлен модуль:',

'module_has_been_removed' => 
'Удален модуль:',

'requested_module_not_installed' => 
'Запрашиваемый модуль не установлен.',

'requested_page_not_found' => 
'Запрашиваемый модуль не найден.',

'translate' => 
'Update',

''=>''
);

// End of File