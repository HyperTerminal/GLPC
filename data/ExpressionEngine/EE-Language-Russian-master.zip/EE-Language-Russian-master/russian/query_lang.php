<?php
$lang = array(

'query_module_name'						=>		'SQL-запросы',
'query_module_description'						=>		'Модуль SQL-запросов для шаблонов',
''						=>		'',
// IGNORE
''=>'');
/* End of file query_lang.php */