<?php
$lang = array(


'pages_module_name' => 
'Страницы',

'pages_module_description' => 
'Использует записи блога для создания статических страниц',

'pages_homepage' => 
'Домашняя страница модуля',

'page' => 
'Страница',

'pages_uri' => 
'URI страницы',

'no_pages' => 
'Нет ни одной страницы',

'create_page' => 
'Создать новую страницу',

'page_name' => 
'Название страницы',

'edit_page' => 
'Редактировать страницу',

'view_page' => 
'Просмотр страницы',

'page_settings' => 
'Настройки страницы',

'none' => 
'Отключено',

'template' => 
'Шаблон',

'parent_page' => 
'Родительская страница',

'channel_entry' => 
'Запись канала',

'choose_entry' => 
'Выберите запись',

'pages_delete_confirm' => 
'Удаление страниц',

'pages_delete_question' => 
'Вы действительно хотите удалить выбранные URI страниц?<br /><em>Примечание: При удалении страницы удаляется только URL. Запись при этом не удаляется.</em>',

'page_deleted' => 
'Страница удалена',

'pages_deleted' => 
'Страницы удалены',

'create_entry' => 
'Создать запись',

'choose_template' => 
'Выберите шаблон для отображения страницы',

'invalid_page_name' => 
'Введено неправильное имя страницы',

'invalid_template' => 
'Необходимо выбрать соответствующий шаблон для отображения этой страницы.',

'page_created' => 
'Страница создана',

'page_updated' => 
'Страница обновлена',

'invalid_page_uri' => 
'Неправильный URI страницы',

'invalid_page_num_segs' => 
'Вы превысили число позволенных сегментов URI на страницах URL',

'pages_configuration' => 
'Настройки модуля',

'preference_name' => 
'Название настройки',

'preference_value' => 
'Значение настройки',

'default_template' => 
'Шаблон по умолчанию',

'default_for_page_creation' => 
'Канал по умолчанию для закладки \'Создать новую страницу\' ',

'no_default' => 
'Нет назначен',

'configuration_updated' => 
'Настройка обновлена',

'duplicate_page_uri' => 
'Дублировать URI страницы',

'pages_display_on_homepage' => 
'Показывать URI на домашней странице модуля',

'nested' => 
'Вложенные',

'not_nested' => 
'Не вложенные',

'preference' => 
'Настройки',

'setting' => 
'Установки',

'example_uri' => 
'/example/pages/uri/',

'translate' => 
'Update',

''=>''
);

// End of File