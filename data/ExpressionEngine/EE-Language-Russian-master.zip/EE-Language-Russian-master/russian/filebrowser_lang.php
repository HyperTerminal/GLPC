<?php
$lang = array(


'file_browser' => 
'Файловый браузер',

'view' => 
'Просмотр',

'path_does_not_exist' => 
'Указанный путь не существует',

'file_viewing_error' => 
'Ошибка неизвестного типа.',

'fp_no_files' => 
'Нет файлов в директории.',

'fb_view_images' => 
'Просмотр изображений',

'fb_view_image' => 
'Просмотр изображения',

'fb_insert_file' => 
'Вставить файл',

'fb_insert_files' => 
'Вставить файлы',

'fb_select_field' => 
'Выберите поле',

'fb_select_files' => 
'Выберите файлы',

'fb_non_images' => 
'* &#8211; не изображения.  Возможен просмотр только изображений.',

'fb_insert_link' => 
'Вставить ссылку',

'fb_insert_links' => 
'Вставить ссылки',

'fb_insert_url' => 
'Вставить URL',

'fb_insert_urls' => 
'Вставить URL',

'translate' => 
'Update',

''=>''
);

// End of File