<?php
$lang = array(

''						=>		'',
// IGNORE
''=>'');
/* End of file javascript_lang.php */