<?php
$lang = array(


'addons' => 
'Дополнения',

'accessories' => 
'Аксесуары',

'modules' => 
'Модули',

'extensions' => 
'Расширения',

'plugins' => 
'Плагины',

'accessory' => 
'Аксессуары',

'module' => 
'Модуль',

'extension' => 
'Расширение',

'rte_tool' => 
'Инструменты редактора',

'addons_accessories' => 
'Аксессуары',

'addons_modules' => 
'Модули',

'addons_plugins' => 
'Плагины',

'addons_extensions' => 
'Расширения',

'addons_fieldtypes' => 
'Тип поля',

'accessory_name' => 
'Имя аксесуара',

'fieldtype_name' => 
'Имя типа поля',

'install' => 
'Установить',

'uninstall' => 
'Удалить',

'installed' => 
'Установлен',

'not_installed' => 
'Не установлен',

'uninstalled' => 
'Удалено',

'remove' => 
'Удалить',

'preferences_updated' => 
'Настройки изменены',

'extension_enabled' => 
'Включено',

'extension_disabled' => 
'Отключено',

'extensions_enabled' => 
'Расширения включены',

'extensions_disabled' => 
'Расширения отключены',

'delete_fieldtype_confirm' => 
'Вы уверены что хотите удалить тип поля?',

'delete_fieldtype' => 
'Удалить тип поля',

'data_will_be_lost' => 
'Все данные, связанные с этим типом поля, включая все ассоциации данных каналов, будут безвозвратно удалены!',

'global_settings_saved' => 
'Настройки сохранены',

'package_settings' => 
'Пакет настроек',

'component' => 
'Компонент',

'current_status' => 
'Текущий статус',

'required_by' => 
'Требуется:',

'available_to_member_groups' => 
'Доступные для групп участников',

'specific_page' => 
'Специальная страница?',

'description' => 
'Описание',

'version' => 
'Версия',

'status' => 
'Статус',

'fieldtype' => 
'Тип поля',

'edit_accessory_preferences' => 
'Изменить настройки аксессуара',

'member_group_assignment' => 
'Переместить в группу участников',

'page_assignment' => 
'Назначенные страницы',

'none' => 
'Нету',

'and_more' => 
' %x и больше...',

'plugins_not_available' => 
'Плагин фидов отключен в бета версии.',

'no_extension_id' => 
'Не определено расширение',

'translate' => 
'Обновить',

''=>''
);

// End of File