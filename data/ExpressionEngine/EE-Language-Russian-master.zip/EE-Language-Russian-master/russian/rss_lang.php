<?php
$lang = array(

'rss_module_name'						=>		'RSS',
'rss_module_description'						=>		'Модуль генерации страницы RSS',
'rss_invalid_channel'						=>		'Канал указанный в RSS не существует.',
''						=>		'',
// IGNORE
''=>'');
/* End of file rss_lang.php */