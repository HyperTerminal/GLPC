<?php
$lang = array(


'emoticon_module_name' => 
'Смайлы',

'emoticon_module_description' => 
'Модуль смайлов',

'emoticon_heading' => 
'Смайлы',

'emoticon_glyph' => 
'Глиф',

'emoticon_image' => 
'Картинка',

'emoticon_width' => 
'Ширина',

'emoticon_height' => 
'Высота',

'emoticon_alt' => 
'Тег Alt',

'translate' => 
'Update',

''=>''
);

// End of File