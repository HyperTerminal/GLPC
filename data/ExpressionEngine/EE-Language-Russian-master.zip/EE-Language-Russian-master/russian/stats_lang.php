<?php
$lang = array(


'stats_module_name' => 
'Статистика',

'stats_module_description' => 
'Модуль отображения статистики',

'translate' => 
'Update',

''=>''
);

// End of File