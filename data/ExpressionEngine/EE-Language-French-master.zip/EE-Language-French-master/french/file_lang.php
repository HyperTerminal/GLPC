<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

'content_files' =>
'Fichiers',

'file_module_name' =>
'Fichier',

'file_module_description' =>
'Module Fichier',

//----------------------------------------




''=>''
);

/* End of file file_lang.php */
/* Location: ./system/expressionengine/language/french/file_lang.php */
