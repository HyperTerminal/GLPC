<?php  if (!defined('BASEPATH')) exit('Aucun accès direct au script autorisé');

$lang = array(


''=>''
);

/* End of file css_lang.php */
/* Location: ./system/expressionengine/language/french/css_lang.php */