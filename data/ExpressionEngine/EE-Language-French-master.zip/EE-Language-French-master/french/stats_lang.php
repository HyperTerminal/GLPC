<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"stats_module_name" =>
"Statistiques",

"stats_module_description" =>
"Module d'affichage des statistiques",

//----------------------------------------






''=>''
);

/* End of file stats_lang.php */
/* Location: ./system/expressionengine/language/french/stats_lang.php */