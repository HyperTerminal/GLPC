<?php

$lang = array(

"jquery_module_name" =>
"jQuery",

"jquery_module_description" =>
"Module jQuery",

'missing_jquery_file' =>
'Le fichier jQuery demandé ne peut être localisé.',

''=>''
);

/* End of file jquery_lang.php */
/* Location: ./system/expressionengine/language/french/jquery_lang.php */