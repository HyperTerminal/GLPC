<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"channel_module_name" =>
"Canal",

"channel_module_description" =>
"Module de canal",

//----------------------------------------

"channel_no_preview_template" =>
"Le modèle d'aperçu n'a pas été spécifié par votre balise",

"channel_must_be_logged_in" =>
"Vous devez être un membre connecté sur ce site pour exécuter cette action.",

"channel_not_specified" =>
"Vous devez spécifier un canal pour utiliser le formulaire d'article.",

"channel_no_action_found" =>
"Impossible de charger les ressources nécessaires à la création du formulaire d'article",


''=>''
);

/* End of file channel_lang.php */
/* Location: ./system/expressionengine/language/french/channel_lang.php */