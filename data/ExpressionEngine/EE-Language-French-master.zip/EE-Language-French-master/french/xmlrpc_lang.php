<?php

$lang = array(

'invalid_license' =>
'License invalide',

''=>''
);

/* End of file xmlrpc_lang.php */
/* Location: ./system/expressionengine/language/french/xmlrpc_lang.php */