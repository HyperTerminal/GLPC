<?php

$lang = array(

//----------------------------
// Custom Publish Tabs - Namespacing the key is highly recommended.
//----------------------------

"eeof_example" => 'Exemple de balise !',


''=>''
);


/* End of file publish_tabs_custom_lang.php */
/* Location: ./system/expressionengine/language/french/publish_tabs_custom_lang.php */