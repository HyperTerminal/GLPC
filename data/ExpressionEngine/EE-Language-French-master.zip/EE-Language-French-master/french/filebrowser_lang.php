<?php

$lang = array(

"file_browser" =>
"Explorateur de fichiers",

"view" =>
"Voir",

"path_does_not_exist" =>
"Le chemin spécifié n'existe pas",

"file_viewing_error" =>
"Une erreur de type inconnu a été rencontrée.",

"fp_no_files" =>
"Aucun fichier disponible dans le répertoire.",

"fb_view_images" =>
"Voir les images",

"fb_view_image" =>
"Voir l'image",

"fb_insert_file" =>
"Insérer fichier",

"fb_insert_files" =>
"Insérer fichiers",

"fb_select_field" =>
"Sélectionner champ",

"fb_select_files" =>
"Sélectionner fichiers",

"fb_non_images" =>
"* fichiers autres qu'images. Seules les images peuvent être visualisées.",

"fb_insert_link" =>
"Insérer lien",

"fb_insert_links" =>
"Insérer liens",

"fb_insert_url" =>
"Insérer URL",

"fb_insert_urls" =>
"Insérer URLs",


// IGNORE
''=>'');
/* End of file filebrowser_lang.php */
/* Location: ./system/expressionengine/language/french/filebrowser_lang.php */