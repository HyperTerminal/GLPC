<?php

$lang = array(

//----------------------------
// Publish page
//----------------------------

'spell_check' =>
'Vérification d\'orthographe',

'check_spelling' =>
'Vérifier l\'orthographe',

"save_spellcheck" =>
"Enregistrer les modifications",

"revert_spellcheck" =>
"Revenir à l'original",

'spell_save_edit' =>
'Enregistrer l\'édition',

'spell_edit_word' =>
'Éditer un mot',

'unsupported_browser' =>
'Navigateur non supporté',

'no_spelling_errors' =>
'Aucune erreur trouvée',

'spellcheck_in_progress' =>
'Vérification en cours&hellip',


''=>''
);


/* End of file spellcheck_lang.php */
/* Location: ./system/expressionengine/language/french/spellcheck_lang.php */