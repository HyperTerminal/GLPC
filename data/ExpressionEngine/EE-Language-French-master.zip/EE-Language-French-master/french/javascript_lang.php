<?php  if (!defined('BASEPATH')) exit('Aucun accès direct au script n\'est autorisé');

$lang = array(


''=>''
);

/* End of file javascript_lang.php */
/* Location: ./system/expressionengine/language/french/javascript_lang.php */