<?php

$lang = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"query_module_name" =>
"Requêtes",

"query_module_description" =>
"Module de requêtes SQL pour les modèles",

//----------------------------------------



''=>''
);

/* End of file query_lang.php */
/* Location: ./system/expressionengine/language/french/query_lang.php */