<?php

$lang = array(

//----------------------------
// Custom Publish Tabs - Namespacing the key is highly recommended.
//----------------------------

"eeof_example" => 'Example Tag!',


''=>''
);


/* End of file publish_tabs_custom_lang.php */
/* Location: ./system/expressionengine/language/english/publish_tabs_custom_lang.php */