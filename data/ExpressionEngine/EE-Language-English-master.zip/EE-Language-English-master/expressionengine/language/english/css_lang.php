<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang = array(


''=>''
);

/* End of file css_lang.php */
/* Location: ./system/expressionengine/language/english/css_lang.php */