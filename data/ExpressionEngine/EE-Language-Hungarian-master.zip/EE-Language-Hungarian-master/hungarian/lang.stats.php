<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"stats_module_name" =>
"Statisztikák",

"stats_module_description" =>
"Statisztikai modul",

//----------------------------------------





/* END */
''=>''
);
?>
