<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"weblog_module_name" =>
"Hírek",

"weblog_module_description" =>
"Hírek modul",

//----------------------------------------

"weblog_no_preview_template" =>
"Az előnézet sablon nem lett definiálva",

"weblog_must_be_logged_in" =>
"Ehhez a művelethez be kell jelentkezned.",

"weblog_not_specified" =>
"Meg kell adnod egy hírt, hogy hozzászólhass.",

"weblog_no_action_found" =>
"Nem sikerült betölteni a szükséges elemeket, hogy a hozzászólás lapja megjelenhessen",

/* END */
''=>''
);
?>
