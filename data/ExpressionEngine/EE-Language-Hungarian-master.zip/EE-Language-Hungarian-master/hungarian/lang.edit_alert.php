<?php
$L = array(

'apply_to' =>
'Szerkesztési figyelmeztetések megjelenítése:',

'expire' =>
'Figylmeztetések lejárati ideje (percekben)',

'alert_css' =>
'CSS a Figyelmeztető Div-hez',

'weblog_entries' =>
'Blog bejegyzések',

'templates' =>
'Sablonok',

'wiki_articles' =>
'Wiki cikkek',

'currently_editing' =>
'Ez %type% jelenleg szerkesztés alatt áll. Szerkeszti: ',	

'entry' =>
'bejegyzés',

'template' =>
'sablon',

'wiki_article' =>
'cikk',

'less_than_one' =>
'&lt; 1',

'minute_ago' =>
'perce',

'minutes_ago' =>
'perce',

// IGNORE
''=>'');?>
