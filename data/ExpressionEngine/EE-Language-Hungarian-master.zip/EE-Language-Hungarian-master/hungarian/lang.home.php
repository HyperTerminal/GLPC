<?php

$L = array(

//----------------------------
// Home page
//----------------------------

"cp_home" =>
"Honlapom",

"current_user" =>
"Jelenlegi felhasználó:",

"system_status" =>
"A rendszer állapota",

"offline" =>
"Nem elérhető",

"online" =>
"Elérhető",

"member_search" =>
"Felhasználó keresése",

"search_instructions" =>
"Teljes szó vagy szórészlet",

"member_group" =>
"Felhasználói csoport",

"search_by" =>
"Keresendő mező",

"screen_name" =>
"Megjenített név",

"email_address" =>
"Email-cím",

"url" =>
"URL",

"notepad" =>
"Jegyzetfüzet",

"site_statistics" =>
"Statisztikák",

"value" =>
"Érték",

"total_members" =>
"Összes felhasználó",

"total_validating_members" =>
"Aktiválásra vár",

"total_validating_comments" =>
"Engedélyezésre váró hozzászólások",

"total_entries" =>
"Összes bejegyzés",

"total_comments" =>
"Összes hozzászólás",

"total_trackbacks" =>
"Összes Visszajelzés",

"most_recent_entries" =>
"Az Ön legutóbbi bejegyzései",

"most_recent_comments" =>
"Legfrissebb hozzászólások/Visszajelzés pingek",

"no_comments" =>
"Nincs hozzászólás/Visszajelzés",

"no_entries" =>
"Nincs bejegyzés",

"entry_title" =>
"Bejegyzés címe",

"comments" =>
"Hozzászólás",

"recent_members" =>
"A legújabb felhasználók",

"join_date" =>
"Regisztráció dátuma",

"total_hits" =>
"Összes letöltés",

"demo_expiration" =>
"A demo lejár:",

"install_lock_warning" =>
"Figyelem: még nem törölte a telepítőfájlt.",

"install_lock_removal" =>
"Biztonsági okokból kérjük, FTP programja segítségével törölje az install.php fájlt a szerverről!",

'bulletin_board' =>
"Közlemények lapja",

'no_bulletins' =>
"Nincsennek közlemények",

'bulletin_sender' =>
"Közlemény feladója",

'bulletin_date' =>
"Közlemény dátuma",

'exact_match' =>
"Teljes egyezés",

'pmachine_news_feed' =>
'EllisLab Hír-lista',

'no_news' =>
"Nincsenek elérhető hírek",

'more_news' =>
"További hírek...",

"site_status" =>
"Portál státusz",

/* END */
''=>''
);
?>
