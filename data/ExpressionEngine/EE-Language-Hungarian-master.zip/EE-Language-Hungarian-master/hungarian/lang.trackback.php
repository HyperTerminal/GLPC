<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"trackback_module_name" =>
"Trackback",

"trackback_module_description" =>
"Visszajelentés modul",

//----------------------------------------

"trackbacks_not_allowed" =>
"A bejegyzéshez nem fogadunk Visszajelzés pingeket",


/* END */
''=>''
);
?>
