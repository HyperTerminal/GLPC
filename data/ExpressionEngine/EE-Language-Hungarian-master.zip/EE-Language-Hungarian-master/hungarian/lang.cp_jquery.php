<?php
  
$L = array(

'jquery_src' =>
'jQuery URL',

'jquery_ui_src' =>
'jQuery UI URL',

'' => ''
);
// end array

/* End of file lang.cp_jquery.php */
/* Location: ./system/language/english/lang.cp_jquery.php */