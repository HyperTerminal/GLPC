<?php

$L = array(

"file_browser" =>
"Fájlböngésző",

"view" =>
"Megtekintés",

"path_does_not_exist" => 
"A megadott elérési út nem létezik",

"file_viewing_error" =>
"Ismeretlen eredetű hiba történt.",

"fp_no_files" => 
"A könyvtárban egyetlen fájlt sem találtunk.",

"fb_view_images" =>
"Képek megtekintése",

"fb_view_image" =>
"Kép megtekintése",

"fb_insert_file" =>
"Fájl beszúrása",

"fb_insert_files" =>
"Fájlok beszúrása",

"fb_select_field" =>
"Válasszon célmezőt",

"fb_select_files" =>
"Válassza ki a fájlokat",

"fb_non_images" =>
"* A nem képfájlokat jelöli, csak a képeket tudja megtekinteni.",

"fb_insert_link" =>
"Link a beszúráshoz",

"fb_insert_links" =>
"Linkek a beszúráshoz",

"fb_insert_url" =>
"Cím a beszúráshoz",

"fb_insert_urls" =>
"Címek a beszúráshoz",


// IGNORE
''=>'');?>
