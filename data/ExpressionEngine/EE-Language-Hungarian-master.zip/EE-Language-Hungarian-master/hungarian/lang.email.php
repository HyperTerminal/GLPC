<?php

$L = array(

//----------------------------
// Email
//----------------------------

"email_module_name" =>
"Email",

"email_module_description" =>
"Felhasználói levelezés modul",

'message_required' =>
"Email üzenet szükséges",

'em_banned_from_email' => 
"A feladóként megadott email-cím a tiltólistán szerepel.",

'em_banned_recipient' =>
"Egy vagy több megadott címzett a tiltólistán szerepel.",

'em_invalid_recipient' =>
"Egy vagy több címzetthez hibás címet adott meg.",

'em_no_valid_recipients' =>
"Nem adott meg érvényes címzett email-címet...",

'em_sender_required' =>
"Meg kell adnia a feladó érvényes email-címét",

"em_unauthorized_request" =>
"Ön nem jogosult a tevékenység végrehajtására",

'em_limit_exceeded' =>
"Ön már elküldte a mai napra engedélyezett számú levelét.",

'em_interval_warning' =>
"Csak %s másodpercenként küldhet e-mailt",

"em_email_sent" =>
"Az emailt elküldtük.",


/* END */
''=>''
);
?>
