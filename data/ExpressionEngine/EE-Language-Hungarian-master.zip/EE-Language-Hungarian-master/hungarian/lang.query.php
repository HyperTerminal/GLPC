<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"query_module_name" =>
"Lekérdezés",

"query_module_description" =>
"SQL-lekérdezés modul a sablonokhoz",

//----------------------------------------


/* END */
''=>''
);
?>
