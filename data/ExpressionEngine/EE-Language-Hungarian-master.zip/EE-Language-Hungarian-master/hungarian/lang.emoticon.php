<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"emoticon_module_name" =>
"Hagulatjelek",

"emoticon_module_description" =>
"Hangulatjel (mosoly jelek) modul",


//----------------------------------------
// Emoticon language lines
//----------------------------------------

"emoticon_heading" =>
"Hangulatjelek",

"emoticon_glyph" =>
"Jel",

"emoticon_image" =>
"Kép",

"emoticon_width" =>
"Szélesség",

"emoticon_height" =>
"Magasság",

"emoticon_alt" =>
"Alternatív szöveg",


/* END */
''=>''
);
?>
