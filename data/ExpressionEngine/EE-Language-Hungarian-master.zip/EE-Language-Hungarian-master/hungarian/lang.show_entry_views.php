<?php

$L = array(

// -----------------------------------
//  Settings Page
// -----------------------------------

'show_entry_views_name' =>
"Show Entry Views",

'show_entry_views_description' =>
"Shows entry views for each entry on the Edit Page.",

'one'=>
"CNo.1",

'two'=>
"CNo.2",

'three'=>
"CNo.3",

'four'=>
"CNo.4",

'all'=>
"Mind",

'total'=>
"Összesen",

'which_views'=>
"Melyik számlálót szeretné látni?",

// END
''=>''
);
?>
