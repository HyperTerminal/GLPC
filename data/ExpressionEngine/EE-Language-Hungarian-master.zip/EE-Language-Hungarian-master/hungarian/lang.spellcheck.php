<?php

$L = array(

//----------------------------
// Publish page
//----------------------------

'spell_check' =>
"Helyesírás ellenőrzés",

'check_spelling' =>
"Helyesírás ellenőrzése",

"save_spellcheck" =>
"Változások mentése",

"revert_spellcheck" =>
"Vissza az eredetihez",

'spell_save_edit' =>
"Módosítások mentése",

'spell_edit_word' =>
"Szó szerkesztése",

'unsupported_browser' =>
"Nem támogatott böngésző",

'no_spelling_errors' =>
"Nincsenek hibák",

'spellcheck_in_progress' =>
"Ellenőrzés folyamatban...",

/* END */
''=>''
);

?>
