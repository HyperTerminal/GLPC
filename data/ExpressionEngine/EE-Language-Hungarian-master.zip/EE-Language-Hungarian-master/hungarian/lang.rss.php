<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"rss_module_name" =>
"RSS",

"rss_module_description" =>
"RSS-oldal generáló modul",

//----------------------------------------

"rss_invalid_weblog" =>
"Az RSS híroldalban megjelölt hír nem létezik.",

'no_weblog_specified' =>
"Meg kell adnia egy weblogot.",

'no_matching_entries' =>
'Nincsenek a feltételeknek megfelelő bejegyzések.',

'empty_feed' =>
'This feed contains no entries',

/* END */
''=>''
);
?>
