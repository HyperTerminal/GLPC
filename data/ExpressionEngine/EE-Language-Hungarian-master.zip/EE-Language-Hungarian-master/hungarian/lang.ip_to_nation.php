<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"ip_to_nation_module_name" =>
"IP -> Ország",

"ip_to_nation_module_description" =>
"Az IP címet ország névvé konvertáló eszköz",

//----------------------------------------

"iptonation_missing" =>
"Az iptonation.php fájl nem található. Ellenőrizze, hogy a modul minden része telepítésre került-e.",

"countryfile_missing" =>
"A country.php fájl nem található a lib mappában.",

"ip_search" =>
"IP cím keresés",

"ip_search_inst" =>
"Adjon meg egy IP címet, hogy meghatározhassuk a hozzá tartozó országot",

"ip_result" =>
"A megadott IP ebből az országból való:",

"manage_banlist" =>
"Kitiltott országok listájának kezelése",

"country" =>
"Ország",

"ban_info" =>
"Válassza ki az országot, amelyiket szeretné kitiltani. Amikor egy ország tiltásra kerül, akkor az ilyen címekkel rendelkező személyek nem fognak tudni megjegyzéseket, visszajelzéseket és az email/szólj-ismerősödnek lapot használni. Viszont még mindig képesek lesznek a portál böngészésére.",

"ban" =>
"Tilt",

"banlist" =>
"Ország Tiltó Lista",

"banlist_updated" =>
"A Tiltólista frissítésre került",

/* END */
''=>''
);
?>
