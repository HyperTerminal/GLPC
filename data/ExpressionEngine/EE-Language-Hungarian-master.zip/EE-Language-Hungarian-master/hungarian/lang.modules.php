<?php

$L = array(

//----------------------------
// Modules
//----------------------------

"delete_module" =>
"Modul törlése",

"module_no_access" =>
"Ön nem jogosult a modulokhoz való hozzáférésre",

"data_will_be_lost" =>
"A modul összes adata véglegesen törlésre kerül!",

"module_access" =>
"Modul szerkesztése",

"module_no_access" =>
"Nincs hozzáférése egyik modulhoz sem",

"delete_module" =>
"Modul eltávolítása",

"delete_module_confirm" =>
"Biztosan törölni akarja a következő modult:",

"module_backend" =>
"Felhasználói vezérlőpulton",

"module_version" =>
"Verzió",

"module_status" =>
"Státusz",


"module_action" =>
"Változtatás",

"not_installed" =>
"Nincs telepítve",

"installed" =>
"Telepítve",

"install" =>
"Telepítés",

"deinstall" =>
"Törlés",

"module_can_not_be_found" =>
"Nem találtuk meg a modul telepítéséhez szükséges fájlokat",

"module_has_been_installed" =>
"Modul telepítve:",

"module_has_been_removed" =>
"Modul törölve:",


/* END */
''=>''
);
?>
