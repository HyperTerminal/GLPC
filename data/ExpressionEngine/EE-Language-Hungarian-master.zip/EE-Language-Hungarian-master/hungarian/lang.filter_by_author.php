<?php

/*
=========================================================
 This Extension is intended for use with ExpressionEngine.
 ExpressionEngine is Copyright (c) 2003 pMachine, Inc.
 http://www.pmachine.com/
=========================================================
 THIS IS COPYRIGHTED SOFTWARE
 All RIGHTS RESERVED
 Written by: Derek Jones
 Copyright (c) 2006 Koru Productions
 http://ee.koruproductions.com/
--------------------------------------------------------
 Please do not distribute this extension without written
 consent from the author.
========================================================
Files:	ext.filter_by_author.php
		lang.filter_by_author.php
--------------------------------------------------------
 Purpose: 	Adds ability to filter by author in the
			Edit section of the control panel.
========================================================
*/

$L = array(

'filter_by_author' =>
'Szűrés szerzőre',

''=>''
);
?>
