<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"blacklist_module_name" =>
"Feketelista",

"blacklist_module_description" =>
"Feketelistta modul",

//----------------------------------------

'htaccess_written_successfully' =>
"A .htaccess fájl sikeresen létrehozva.",

'invalid_htaccess_path' =>
"Helytelen útvonal vagy jogosultság a .htaccess fájlhoz",

'htaccess_server_path' =>
"Szerver útvonal a .htaccess fájlhoz",

'write_htaccess_file' =>
"Fekete lista készítése a .htaccess fájlhoz?",

'whitelist' =>
"Fehérlista",

'pmachine_whitelist' =>
"Fehérlista letöltése az ExpressionEngine.com-tól",

'whitelist_updated' =>
"A fehérlistát frissítettük",

'ref_whitelist_irretrievable' =>
"Hiba: nem sikerült letölteni az új fehérlistát.",

'ref_view_whitelist' =>
"Fehérlista megtekintése",

'ref_no_whitelist' =>
"A fehérlista jelenleg üres",

'ref_whitelisted' =>
"Fehérlistán",

'ref_no_whitelist_table' =>
"A fehérlista tábla nem létezik az adatbázisban",

'ref_type' =>
"Elem típusa",

'blacklist' =>
"Feketelista",

"pmachine_blacklist" =>
"Feketelista letöltése az ExpressionEngine.com-tól",

'requires_license_number' =>
"Licensz-szám szükséges az általános beállításokhoz",

"blacklist_updated" =>
"A feketelistát frissítettük",

'ref_no_license' =>
"Hiba: nincs licensz-szám.",

'ref_blacklist_irretrievable' =>
"Hiba: nem sikerült az új feketelistát letölteni.",

'ref_view_blacklist' =>
"Referrer feketelista",

'ref_no_blacklist' =>
"A feketelista jelenleg üres",

'ref_ip' =>
"IP-cím",

'ref_user_agent' =>
"User Agent",

'ref_url' =>
"URL",

'requires_license_number' =>
"Az Általános Beállításokban meg kell adnia a licensz-számot",

'ref_no_blacklist_table' =>
"A feketelista adatbázis táblája nem létezik",



/* END */
''=>''
);
?>
