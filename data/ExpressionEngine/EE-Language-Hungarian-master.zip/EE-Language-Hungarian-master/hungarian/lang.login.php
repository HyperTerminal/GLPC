<?php

$L = array(

//----------------------------
// Log-in
//----------------------------

"remember_me" =>
"A jövőben automatikusan be kíván lépni?",

"no_username" =>
"A megadott felhasználónév nem szerepel az adatbázisban",

"no_password" =>
"A megadott jelszó téves.",

"no_email" =>
"Meg kell adnia email-címét.",

"multi_login_warning" =>
"Ezzel a felhasználónévvel már bejelentkezett valaki.",

"return_to_login" =>
"Vissza a bejelentkezéshez",

"password_lockout_in_effect" =>
"%x percenként csak négyszer próbálhat meg belépni",

"unauthorized_request" =>
"Nem jogosult a parancs végrehajtására",

/* END */
''=>''
);
?>
