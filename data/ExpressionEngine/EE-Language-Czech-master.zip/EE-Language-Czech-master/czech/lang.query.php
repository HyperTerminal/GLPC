<?php
$L = array(


"query_module_name" =>
"Dotaz",

"query_module_description" =>
"SQL dotaz modul pro šablony",

''=>''
);
?>