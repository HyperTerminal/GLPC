<?php
$L = array(


"weblog_module_name" =>
"Weblog",

"weblog_module_description" =>
"Weblog modul",

"weblog_no_preview_template" =>
"Náhled šablony nebyl specifikován ve vašem tagu",

"weblog_must_be_logged_in" =>
"Pro vykonání této operace musíte být přihlášen jako uživatel těchto stránek.",

"weblog_not_specified" =>
"Musíte určit weblog, aby bylo možné použít formulář.",

"weblog_no_action_found" =>
"Nelze načíst zdrojová data potřebná pro vytvoření formuláře",

''=>''
);
?>