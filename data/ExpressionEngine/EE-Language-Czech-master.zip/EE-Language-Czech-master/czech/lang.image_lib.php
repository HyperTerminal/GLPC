<?php
$L = array(


"imglib_gd_required_for_props" =>
"Váš server musí podporovat GD knihovnu pro určení vlastnosti obrázků",

"imglib_unsupported_imagecreate" =>
"Váš server nepodporuje GD knihovnu  potřebnou pro správu obrázků tohoto typu.",

"imglib_gif_not_supported" =>
"GIF obrázky nejsou často podporovány z důvodů licenčních omezení. Místo toho můžete použít obrázky typu JPG nebo PNG.",

"imglib_jpg_not_supported" =>
"JPG obrázky nejsou podporovány",

"imglib_png_not_supported" =>
"PNG obrázky nejsou podporovány",

"imglib_jpg_or_png_required" =>
"Změna obrázků specifikovaná protokolem v nastavení pracuje pouze s formáty typu JPG a PNG.",

"imglib_copy_error" =>
"Při přepisu souboru došlo k chybě. Přesvěčte se, zda je umožněn zápis do uploadovacího adresáře.",

"imglib_rotate_unsupported" =>
"Otáčení obrázků není patrně podporováno serverem.",

"imglib_libpath_invalid" =>
"Cesta ke obrázkové knihovně není správná. Zadejte prosím v předvolbách správnou cestu.",

"imglib_image_process_failed" =>
"Zpracování obrázku neproběhlo úspěšně. Přesvědčte se, prosím, že váš server podporuje vybrané protokoly a cesta k obrázkové knihovně je správná.",

"imglib_rotation_angle_required" =>
"Úhel natočení obrázku si vyžaduje jeho otočení.",

"imglib_writing_failed_gif" =>
"GIF obrázek",

"imglib_invalid_path" =>
"Cesta k obrázku je neplatná",

"imglib_copy_failed" =>
"Kopírování obrázku pravidelně selhává.",

''=>''
);
?>