<?php
$L = array(


"referrer_module_name" =>
"Odkazování",

"referrer_module_description" =>
"Modul sledování odkazování",

"tracking_preferences" =>
"Předvolby sledování odkazování",

"referrer_ip" =>
"Odkazovaná IP",

"referrer_date" =>
"Datum odkazování",

"ref_ip" =>
"IP adresa",

"ref_user_agent" =>
"Uživatelský agent",

"ref_url" =>
"URL",

"ref_type" =>
"Typ",

"referrers" =>
"Odkazování",

"view_referrers" =>
"Zobrazit odkazování",

"clear_referrers" =>
"Vyčistit odkazování",

"referrer_from" =>
"Odkazování z",

"referrer_to" =>
"Odkazování na",

"no_referrers" =>
"Aktuálně žádná odkazování",

"total_referrers" =>
"Celkový počet odkazování:",

"save_instructions" =>
"Jak velký počet nejodkazovanějších adres chcete uložit?",

"referrers_deleted" =>
"Odkazování byla smazána",

"referrer_deleted" =>
"Odkazování bylo smazáno",

"delete_confirm" =>
"Potvrdit smazání",

"referrer_delete_question" =>
"Jste si jistý, že chcete smazat vybraná odkazování?",

"blacklist_question" =>
"Mimo to můžete smazat následující odkazování:",

"add_urls" =>
"Smazat další odkazování se stejnými URL?",

"add_and_blacklist_urls" =>
"Přidat URL adresy do blacklistu a smazat další odkazování se stejnými URL?",

"add_ips" =>
"Smazat další odkazování se stejnými IP adresami?",

"add_and_blacklist_ips" =>
"Přidat IP adresy do blacklistu a smazat další odkazování se stejnými IP adresami?",

"add_agents" =>
"Smazat další odkazování se stejnými uživatelskými agenty?",

"add_and_blacklist_agents" =>
"Přidat uživatelského agenta do blacklistu a smazat další odkazování se stejnými uživatelskými agenty?",

''=>''
);
?>