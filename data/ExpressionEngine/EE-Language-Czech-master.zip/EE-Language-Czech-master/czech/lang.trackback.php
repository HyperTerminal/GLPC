<?php
$L = array(


"trackback_module_name" =>
"Trackback",

"trackback_module_description" =>
"Trackback modul",

"trackbacks_not_allowed" =>
"Trackbacky jsou pro tento příspěvek vypnuty",

''=>''
);
?>