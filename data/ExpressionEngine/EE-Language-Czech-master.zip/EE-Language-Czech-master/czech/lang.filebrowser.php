<?php
$L = array(


"file_browser" =>
"Prohlížeč souborů",

"view" =>
"Prohlédnout",

"path_does_not_exist" =>
"Zadaná cesta neexistuje",

"file_viewing_error" =>
"Vyskytla se chyba neznámého typu.",

"fp_no_files" =>
"Žádné soubory v adresáři.",

"fb_view_images" =>
"Prohlédnou obrázky",

"fb_view_image" =>
"Prohlédnout obrázek",

"fb_insert_file" =>
"Vložit soubor",

"fb_insert_files" =>
"Vložit soubory",

"fb_select_field" =>
"Vybrat pole",

"fb_select_files" =>
"Vybrat soubory",

"fb_non_images" =>
"* Upozorňuje na soubory, které nejsou obrázky. Prohlížet lze pouze obrázky.",

"fb_insert_link" =>
"Vložit odkaz",

"fb_insert_links" =>
"Vložit soubory",

"fb_insert_url" =>
"Vložit URL",

"fb_insert_urls" =>
"Vložit jenom URL",

''=>''
);
?>