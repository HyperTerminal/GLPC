<?php
$L = array(


"spell_check" =>
"Kontrola pravopisu",

"check_spelling" =>
"Zkontrolovat pravopis",

"save_spellcheck" =>
"Uložit změny",

"revert_spellcheck" =>
"Návrat k originálu",

"spell_save_edit" =>
"Uložit editaci",

"spell_edit_word" =>
"Editovat slovo",

"unsupported_browser" =>
"Nepodporovaný prohlížeč",

"no_spelling_errors" =>
"Nebyly nalezeny žádné chyby",

"spellcheck_in_progress" =>
"Probíhá kontrola...",

''=>''
);
?>