<?php
$L = array(


"stats_module_name" =>
"Statistiky",

"stats_module_description" =>
"Modul zobrazení statistik",

''=>''
);
?>