<?php
$L = array(


"remember_me" =>
"Automaticky přihlásit při budoucích návštěvách?",

"no_username" =>
"Vámi zadané uživatelské jméno nebylo nalezeno v databázi",

"no_password" =>
"Vámi zadané heslo není správné.",

"no_email" =>
"Musíte zadat svou emailovou adresu.",

"multi_login_warning" =>
"Někdo je již přihlášen jako uživatel tohoto účtu.",

"return_to_login" =>
"Návrat na přihlášení",

"password_lockout_in_effect" =>
"Můžete se přihlásit maximálně čtyřikrát v průběhu %x minut",

"unauthorized_request" =>
"Nejste oprávněn k provedení této akce.",

''=>''
);
?>