<?php

$L = array(

//----------------------------------------
//	General
//----------------------------------------

"label"									=>
"Popisek",

"instructions"							=>
"Použij níže uvedené popisky polí pro změnu názvu záložky modulu štítků v části Publikace / Editace. Ponechej pole prázdné, pokud si přeješ vypnout modul štítků pro daný weblog.",

"edit"								=>
"Editovat",

"action_can_not_be_undone"			=>
"Tuto operaci nelze zvrátit.",

// END
''=>''
);
?>