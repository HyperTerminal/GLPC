<?php
$L = array(


"email_module_name" =>
"Email",

"email_module_description" =>
"Modul uživatelských emailů",

"message_required" =>
"Text emailu je povinný",

"em_banned_from_email" =>
"Vámi zadaná adresa odesílatele je zablokovaná.",

"em_banned_recipient" =>
"Jedna nebo více emailových adres příjemců jsou zablokovány.",

"em_invalid_recipient" =>
"Jedna nebo více emailových adres má neplatný tvar.",

"em_no_valid_recipients" =>
"Váš email neobsahuje platné příjemce.",

"em_sender_required" =>
"Je vyžadována platná emailová adresa",

"em_unauthorized_request" =>
"Nejste oprávněn k provedení této operace",

"em_limit_exceeded" =>
"Přesáhl jste povolený maximální počet odeslaných emailů za den.",

"em_interval_warning" =>
"Je povoleno odesílat emaily pouze každých %s vteřin",

"em_email_sent" =>
"Váš email byl odeslán.",

''=>''
);
?>