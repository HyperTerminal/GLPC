<?php
$L = array(


"blacklist_module_name" =>
"Blacklist/Whitelist",

"blacklist_module_description" =>
"Modul blacklist a whitelist",

"htaccess_written_successfully" =>
"Soubor .htaccess byl úspěšně zapsán",

"invalid_htaccess_path" =>
"Neplatná cesta nebo přístupová práva pro soubor .htaccess",

"htaccess_server_path" =>
"Cesta k souboru .htaccess na serveru",

"write_htaccess_file" =>
"Zapsat blacklist do .htaccess souboru?",

"whitelist" =>
"Whitelist",

"pmachine_whitelist" =>
"Stáhnout whitelist z pMachine.com",

"whitelist_updated" =>
"Whitelist byl úspěšně aktualizován",

"ref_whitelist_irretrievable" =>
"Chyba: nový whitelist byl ztracen.",

"ref_view_whitelist" =>
"Zobrazit whitelist",

"ref_no_whitelist" =>
"Nic není ve whitelistu",

"ref_whitelisted" =>
"Přidáno do whitelistu",

"ref_no_whitelist_table" =>
"Tabulka pro whitelist v databázi neexistuje",

"ref_type" =>
"další položka",

"blacklist" =>
"Blacklist",

"pmachine_blacklist" =>
"Stáhnout blacklist z pMachine.com",

"requires_license_number" =>
"Vyžaduje licenční číslo v hlavní konfiguraci",

"blacklist_updated" =>
"Blacklist byl úspěšně aktualizován",

"ref_no_license" =>
"Chyba: žádné licenční číslo.",

"ref_blacklist_irretrievable" =>
"Chyba: nový blacklist byl ztracen.",

"ref_view_blacklist" =>
"Zobrazit blacklist",

"ref_no_blacklist" =>
"Nic není v blacklistu.",

"ref_ip" =>
"IP adresa",

"ref_user_agent" =>
"Uživatelský agent",

"ref_url" =>
"URL",

"ref_blacklisted" =>
"Přidáno do blacklistu",

"ref_no_blacklist_table" =>
"Tabulka databáze pro blacklist neexistuje",

''=>''
);
?>