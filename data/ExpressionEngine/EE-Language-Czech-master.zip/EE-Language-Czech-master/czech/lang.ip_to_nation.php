<?php
$L = array(


"ip_to_nation_module_name" =>
"IP na zemi",

"ip_to_nation_module_description" =>
"Pomůcka pro asociaci IP adres se zeměmi",

"iptonation_missing" =>
"Nelze najít soubor iptonation.php. Ověřte prosím, že jste nahráli všechny komponenty tohoto modulu.",

"countryfile_missing" =>
"Nelze najít soubor country.php v adresáři lib",

"ip_search" =>
"Hledání IP adres",

"ip_search_inst" =>
"Zadejte IP addresu pro určení země, která ji přináleží",

"ip_result" =>
"Zadaná IP pochází z následující země:",

"manage_banlist" =>
"Spravovat seznam vámi zablokovaných zemí",

"country" =>
"Země",

"ban_info" =>
"Vyberte zemi, kterou chcete zakázat. Pokud je země zakázána, osoby přicházející z IP adres v těchto zemích nebudou moci zasílat komentáře, trackbacky, používat emailové formuláře a formuláře trackbacku. Budou stále moci prohlížet vaše stránky.",

"ban" =>
"Zakázat",

"banlist" =>
"Seznam zakázaných zemí",

"banlist_updated" =>
"Seznam zakázaných byl úspěšně aktualizován",

''=>''
);
?>