<?php
$L = array(


"emoticon_module_name" =>
"Smajlíky",

"emoticon_module_description" =>
"Modul smajlíků (úsměvů)",

"emoticon_heading" =>
"Smajlíky",

"emoticon_glyph" =>
"Piktogram",

"emoticon_image" =>
"Obrázek",

"emoticon_width" =>
"Šířka",

"emoticon_height" =>
"Výška",

"emoticon_alt" =>
"Zástupný text",

''=>''
);
?>