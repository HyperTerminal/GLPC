<?php
  
$L = array(
	'load_jquery'    => 'Načíst jQuery?',
	'load_jquery_ui' => 'Načíst jQuery UI?',
	'jquery_src'    => 'jQuery URL',
	'jquery_ui_src' => 'jQuery UI URL'
);

