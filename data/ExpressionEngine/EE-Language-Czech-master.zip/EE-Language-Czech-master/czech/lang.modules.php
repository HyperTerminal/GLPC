<?php
$L = array(


"module_name" =>
"Jméno modulu",

"module_description" =>
"Popis",

"data_will_be_lost" =>
"Všechna data asociovaná s modulem budou trvale smazána!",

"module_access" =>
"Upravit modul",

"module_no_access" =>
"Nejste oprávněn přistupovat k žádným modulům",

"delete_module" =>
"Odinstalace modulu",

"delete_module_confirm" =>
"Opravdu chcete odinstalovat následující modul:",

"module_backend" =>
"Uživatelská stránka",

"module_version" =>
"Verze",

"module_status" =>
"Stav",

"module_action" =>
"Akce",

"not_installed" =>
"Nenainstalováno",

"installed" =>
"Instalováno",

"install" =>
"Instalovat",

"deinstall" =>
"Odstranit",

"module_can_not_be_found" =>
"Nelze najít soubory potřebné pro instalaci tohoto modulu",

"module_has_been_installed" =>
"Nainstalovaný modul:",

"module_has_been_removed" =>
"Odstraněný modul:",

''=>''
);
?>