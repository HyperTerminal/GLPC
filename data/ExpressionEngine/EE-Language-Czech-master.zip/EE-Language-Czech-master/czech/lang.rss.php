<?php
$L = array(


"rss_module_name" =>
"RSS",

"rss_module_description" =>
"Modul generování RSS kanálů",

"rss_invalid_weblog" =>
"Weblog uvedený ve vašem RSS neexistuje.",

"no_weblog_specified" =>
"Musíš specifikovat weblog.",

"no_matching_entries" =>
"Žádny zápis neodpovídá parametru specifikovanému v tágu.",

"empty_feed" =>
"Tento kanál neobsahuje žádné záznamy",

/* END */
''=>''
);
?>