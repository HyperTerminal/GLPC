<?php
$L = array(


"cp_home" =>
"Moje domácí stránka",

"current_user" =>
"Aktuální uživatel:",

"system_status" =>
"Stav systému",

"offline" =>
"Vypnuto",

"online" =>
"Zapnuto",

"member_search" =>
"Hledání člena",

"search_instructions" =>
"Zadejte celá slova nebo jejich část",

"member_group" =>
"Skupina členů",

"search_by" =>
"Vyhledávací pole",

"screen_name" =>
"Zobrazované jméno",

"email_address" =>
"Emailová adresa",

"url" =>
"URL",

"notepad" =>
"Poznámkový blok",

"site_statistics" =>
"Statistika stránek",

"value" =>
"Hodnota",

"total_members" =>
"Celkový počet členů",

"total_validating_members" =>
"Počet členů čekajících na aktivaci účtu",

"total_validating_comments" =>
"Počet komentářů čekajících na schválení",

"total_entries" =>
"Celkový počet příspěvků",

"total_comments" =>
"Počet komentářů",

"total_trackbacks" =>
"Počet trackbacků",

"most_recent_entries" =>
"Poslední články",

"most_recent_comments" =>
"Poslední komentáře/trackbacky",

"no_comments" =>
"Momentálně zde nejsou žádné komentáře ani trackbacky",

"no_entries" =>
"Momentálně žádné články",

"entry_title" =>
"Název článku",

"comments" =>
"Koment.",

"recent_members" =>
"Poslední registrovaní uživatelé",

"join_date" =>
"Datum přihlášení",

"total_hits" =>
"Celkový počet návštěv",

"demo_expiration" =>
"Váš demo účet vyprší:",

"install_lock_warning" =>
"Upozornění: Instalační soubor je stále na serveru.",

"install_lock_removal" =>
"Z bezpečnostních důvodů prosím odstraňte soubor install.php z vašeho serveru pomocí FTP programu.",

"bulletin_board" =>
"Zpravodaj",

"no_bulletins" =>
"Žádný zpravodaj",

"bulletin_sender" =>
"Odesílatel zpravodaje",

"bulletin_date" =>
"Datum fóra",

"exact_match" =>
"Přesná shoda",

"pmachine_news_feed" =>
"Kanál RSS zpráv z ExpressionEngine.com",

"no_news" =>
"Žádné dostupné zprávy",

"more_news" =>
"Více zpráv...",

"site_status" =>
"Stav stránek",

''=>''
);
?>