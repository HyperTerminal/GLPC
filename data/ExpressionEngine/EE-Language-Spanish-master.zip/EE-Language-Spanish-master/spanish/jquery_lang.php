<?php
$lang = array(


"jquery_module_name" =>
"jQuery",

"jquery_module_description" =>
"Modulo jQuery",

"missing_jquery_file" =>
"El archivo jQuery solicitado no pudo ser encontrado.",

"translate" =>
"Update",

''=>''
);
?>