<?php
$lang = array(


'design_user_message' => 
'Plantilla de Mensaje de Usuario',

'design_system_offline' => 
'Plantilla de Sistema Apagado',

'design_email_notification' => 
'Plantilla de Notificacion de Correo',

'design_member_profile_templates' => 
'Plantilla de Perfil de Miembro',

'member_register_member' => 
'Registrar Miembro',

'member_validation' => 
'Validacion de Miembro',

'member_view_members' => 
'Ver Miembro',

'member_ip_search' => 
'Busqueda de IP de Miembro',

'member_custom_profile_fields' => 
'Campos de Miembro Personalizados',

'member_group_manager' => 
'Administrador de Grupos de Miembro',

'member_config' => 
'Configuracion de Miembro',

'member_banning' => 
'Blockeo de Miembros',

'member_search' => 
'Busqueda de Miembro',

'data_sql_manager' => 
'Administrador de Sql',

'data_search_and_replace' => 
'Buscar y Reemplazar',

'data_recount_stats' => 
'Recontar Estadisticas',

'data_php_info' => 
'Info PHP',

'data_clear_caching' => 
'Borrar Cache',

'file_index' => 
'Administrador de Achivos',

'logs_view_cp_log' => 
'Ver Registro de Panel de Control',

'logs_view_throttle_log' => 
'Ver Registro de Throttle',

'logs_view_search_log' => 
'Ver Registro de Busqueda',

'logs_view_email_log' => 
'Ver Registro de Correo',

'util_member_import' => 
'Importe de Miembros',

'util_import_from_mt' => 
'Importar de MT',

'util_import_from_xml' => 
'Importar de XML',

'util_translation_tool' => 
'Utilidad de Traduccion',

'translate' => 
'Update',

''=>''
);

// End of File