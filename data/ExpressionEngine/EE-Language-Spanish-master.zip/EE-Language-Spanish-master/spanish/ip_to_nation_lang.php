<?php
$lang = array(


"ip_to_nation_module_name" =>
"IP a Nacion",

"ip_to_nation_module_description" =>
"Utilidad para asociar direcciones IP a su pais",

"iptonation_missing" =>
"No se puede encontrar el archivo llamado iptonation.php. Por favor asegura que has cargado todos los componentes de este modulo.",

"countryfile_missing" =>
"No se puede encontrar el archivo llamado country.php en tu carpeta de config",

"ip_search" =>
"Busqueda de Direccion IP",

"ip_search_inst" =>
"Envia una direccion IP para determinar a que pais se debe asociar",

"ip_result" =>
"El IP que has enviado es del siguiente pais:",

"manage_banlist" =>
"Gestiona Tu Lista de Paises Bloqueados",

"country" =>
"Pais",

"ban_info" =>
"Selecciona los paises que deseas bloquear. Cuando un pais es bloqueado, una persona con un IP correspondiente a ese pais no podra enviar comentarios, o utilizar tu formulario para avisarle a amigos. Todavia podran ver tu sitio.",

"ban" =>
"Bloquear",

"banlist" =>
"Lista de Naciones Bloqueadas",

"banlist_updated" =>
"Lista de bloqueo ha sido actualizada",

"translate" =>
"Update",

''=>''
);
?>