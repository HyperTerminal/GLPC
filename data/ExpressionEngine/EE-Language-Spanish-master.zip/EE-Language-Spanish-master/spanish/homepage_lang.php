<?php
$lang = array(


'install_lock_warning' => 
'Advertencia: Tu carpeta de instalacion todavia se encuentra en el servidor.',

'install_lock_removal' => 
'Por razones de seguridad, por favor borra la carpeta llamada "installer" de tu servidor utilizando tu programa de FTP.',

'checksum_changed_warning' => 
'Uno o mas archivos de nucleo han sido alterados:',

'checksum_changed_accept' => 
'Aceptar Cambios',

'checksum_email_subject' => 
'Un archivo de nucleo fue modificado en tu sitio.',

'checksum_email_message' => 
'',

'new_version_notice' => 
'',

'new_version_error' => 
'',

'important_messages' => 
'Notificacion',

'cp_home' => 
'My Pagina de Inicio',

'current_user' => 
'Usuario Actual:',

'system_status' => 
'Status de Sistema',

'offline' => 
'Apagado',

'online' => 
'Encendido',

'member_search' => 
'Busqueda de Miembro',

'search_instructions' => 
'Enviar palabras completas o parciales',

'member_group' => 
'Grupo de Miembro',

'search_by' => 
'Campo de Busqueda',

'screen_name' => 
'Nombre de Pantalla',

'email_address' => 
'Direccion de Correo Electronico',

'url' => 
'URL',

'site_statistics' => 
'Estadisticas del Sitio',

'value' => 
'Valor',

'total_members' => 
'Total de Miembros',

'total_validating_members' => 
'Miembros Esperando Activacion',

'total_validating_comments' => 
'Comentarios Esperando Validacion',

'total_entries' => 
'Total de Entras de Canal',

'total_comments' => 
'Total de Comentarios',

'most_recent_entries' => 
'Entradas de Canal Mas Recientes',

'most_recent_comments' => 
'Comentarios Mas Recientes',

'no_comments' => 
'Actualmente no hay comentarios',

'no_entries' => 
'Actualmente no hay entradas de canal',

'entry_title' => 
'Titulo de Entrada de Canal',

'comments' => 
'Comentarios',

'no_channels_exist' => 
'Actualmente no hay canales',

'no_templates_available' => 
'No existen grupos de plantilla.  <a href=\'%s\' title=\'Create a template group\'>Crear un Grupo de Plantilla</a>',

'select_channel_to_post_in' => 
'Selecciona un canal para postear',

'recent_members' => 
'Nuevos Miembros Mas Recientes',

'join_date' => 
'Fecha de Registro',

'total_hits' => 
'Total de Hits de Pagina Combinados',

'demo_expiration' => 
'Tu cuenta de demo expirara en:',

'bulletin_board' => 
'Foro de Boletines',

'no_bulletins' => 
'No hay Boletines',

'bulletin_sender' => 
'Enviador de Boletin',

'bulletin_date' => 
'Fecha de Boletin',

'exact_match' => 
'Exact Match',

'pmachine_news_feed' => 
'Feed de Noticias de EllisLab',

'no_news' => 
'No Hay Noticias Disponibles',

'more_news' => 
'Mas Noticias...',

'site_status' => 
'Status de Sitio',

'close' => 
'Cerrar',

'translate' => 
'Update',

''=>''
);

// End of File