<?php
$lang = array(


"module_name" =>
"Nombre de Módulo",

"module_description" =>
"Descripción",

"data_will_be_lost" =>
"Todos los datos relacionados con este módulo serán borrados permanentemente!",

"module_access" =>
"Editar Módulo",

"module_no_access" =>
"No tienes permitido accesar módulos",

"delete_module" =>
"Des-instalar Módulo",

"delete_module_confirm" =>
"Estás seguro que deseas remover el siguiente módulo:",

"module_backend" =>
"PC de Usuario",

"module_version" =>
"Versión",

"module_status" =>
"Estatus",

"module_action" =>
"Acción",

"not_installed" =>
"No Instalado",

"installed" =>
"Instalado",

"install" =>
"Instalar",

"deinstall" =>
"Remover",

"module_can_not_be_found" =>
"No se pueden ubicar los archivos necesarios para instalar este módulo",

"module_has_been_installed" =>
"Módulo instalado:",

"module_has_been_removed" =>
"Módulo removido:",

"requested_module_not_installed" =>
"El módulo solicitado no esta instalado.",

"requested_page_not_found" =>
"La página del módulo solicitado no puede ser encontrada.",

"translate" =>
"Update",

''=>''
);
?>