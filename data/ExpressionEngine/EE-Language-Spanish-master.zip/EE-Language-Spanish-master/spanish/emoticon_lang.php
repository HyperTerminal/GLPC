<?php
$lang = array(


'emoticon_module_name' => 
'Emoticon',

'emoticon_module_description' => 
'Modulo de emoticon (smiley)',

'emoticon_heading' => 
'Emoticons',

'emoticon_glyph' => 
'Simbolo',

'emoticon_image' => 
'Imagen',

'emoticon_width' => 
'Ancho',

'emoticon_height' => 
'Altura',

'emoticon_alt' => 
'Etiqueta Alt',

'translate' => 
'Update',

''=>''
);

// End of File