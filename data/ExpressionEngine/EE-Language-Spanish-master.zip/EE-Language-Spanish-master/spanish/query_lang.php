<?php
$lang = array(


"query_module_name" =>
"Consulta",

"query_module_description" =>
"Módulo de consulta SQL para plantillas",

"translate" =>
"Update",

''=>''
);
?>