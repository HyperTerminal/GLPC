<?php
$lang = array(


'channel_module_name' => 
'Canal',

'channel_module_description' => 
'Modulo de Canal',

'channel_no_preview_template' => 
'Una plantilla de vista previa no fue especificada en tu etiqueta',

'channel_must_be_logged_in' => 
'Debes iniciar una sesion para llevar a cabo esta accion.',

'channel_not_specified' => 
'Debes especificar un canal para poder utilizar el formulario de entrada.',

'channel_no_action_found' => 
'No se pueden cargar los recursos necesarios para crear el formulario de entrada',

'translate' => 
'Update',

''=>''
);

// End of File