<?php
$lang = array(


'expressionengine_info' => 
'Info de ExpressionEngine',

'resources' => 
'Recursos',

'documentation' => 
'Documentacion En Linea',

'support_forums' => 
'Foros de Soporte Tecnico',

'downloads' => 
'Mis Descargas de Tienda ExpressionEngine',

'support_resources' => 
'Recursos de Soporte',

'version_and_build' => 
'Version y Construccion',

'error_getting_version' => 
'No se pudo retirar la version actual en este momoento',

'version_info' => 
'La version actual de ExpressioEngine es %v Construccion %b',

'translate' => 
'Update',

''=>''
);

// End of File