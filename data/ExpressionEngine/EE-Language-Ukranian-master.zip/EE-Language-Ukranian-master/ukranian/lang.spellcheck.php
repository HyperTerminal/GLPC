<?php

$L = array(

//----------------------------
// Publish page
//----------------------------

'spell_check' =>
"Перевірка орфографії",

'check_spelling' =>
"Перевірити орфографію",

"save_spellcheck" =>
"Зберегти зміни",

"revert_spellcheck" =>
"Відновити оригінал",

'spell_save_edit' =>
"Зберегти редагування",

'spell_edit_word' =>
"Редагувати слово",

'unsupported_browser' =>
"Цей браузер не підтримує дану функцію",

'no_spelling_errors' =>
"Помилок не знайдено",

'spellcheck_in_progress' =>
"Виконується перевірка...",

/* END */
''=>''
);

?>