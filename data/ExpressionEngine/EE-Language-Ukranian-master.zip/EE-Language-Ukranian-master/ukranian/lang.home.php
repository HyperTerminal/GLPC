<?php

$L = array(

//----------------------------
// Home page
//----------------------------

"cp_home" =>
"Домашня сторінка",

"current_user" => 
"Ваше ім\'я:",

"system_status" =>
"Статус системи",

"offline" =>
"Оффлайн",

"online" =>
"Онлайн",

"member_search" =>
"Пошук користувачів",

"search_instructions" =>
"Введіть слова, повністю або частково",

"member_group" =>
"Група користувачів",

"search_by" =>
"Поле пошуку",

"screen_name" =>
"Ім\'я, що відображається",

"email_address" =>
"Адреса e-mail",

"url" =>
"URL",

"notepad" =>
"Блокнот",

"site_statistics" =>
"Статистика сайту",

"value" =>
"Значення",

"total_members" =>
"Всього користувачів",

"total_validating_members" =>
"Неактивованих користувачів",

"total_validating_comments" =>
"Неактивованих коментарів",

"total_entries" =>
"Всього статей",

"total_comments" =>
"Всього коментарів",

"total_trackbacks" =>
"Всього трекбеків",

"most_recent_entries" =>
"Ваші останні статті",

"most_recent_comments" =>
"Останні коментарі",

"no_comments" =>
"Немає коментарів",

"no_entries" =>
"Немає статей",

"entry_title" =>
"Заголовок статті",

"comments" =>
"кмнт",

"recent_members" =>
"Останні зареєстровані користувачі",

"join_date" =>
"Дата реєстрації",

"total_hits" =>
"Всього хітів",

"demo_expiration" =>
"Ваш демонстраційний акаунт закінчується:",

"install_lock_warning" =>
"УВАГА! Інсталяційний файл до цих пір знаходиться на сервері.",

"install_lock_removal" =>
"В цілях безпеки видаліть файл install.php з сервера, використовуючи FTP клієнт.",

'bulletin_board' =>
"Дошка Оголошень",

'no_bulletins' =>
"Немає оголошень",

'bulletin_sender' =>
"Відправник оголошення",

'bulletin_date' =>
"Дата оголошення",

'exact_match' =>
"Узгоджено",

'pmachine_news_feed' =>
'Стрічка новин розробників',

'no_news' =>
"Новин немає",

'more_news' =>
"Інші новини...",

"site_status" =>
"Статус сайту",

/* END */
''=>''
);
?>