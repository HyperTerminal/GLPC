<?php

$L = array(

//----------------------------
// Modules
//----------------------------

"module_name" =>
"Назва модуля",

"module_description" =>
"Опис",

"data_will_be_lost" =>
"Всі дані, пов\'язані з цим модулем, будуть назавжди видалені!",

"module_access" =>
"Редагувати модуль",

"module_no_access" =>
"Ви не можете отримати доступ до модулів",

"delete_module" =>
"Видалити модуль",

"delete_module_confirm" =>
"Ви впевнені, що хочете деактивувати наступний модуль:",

"module_backend" =>
"Контр. панель",

"module_version" =>
"Версія",

"module_status" =>
"Статус",

"module_action" =>
"Операція",

"not_installed" =>
"Не активований",

"installed" =>
"Встановлено",

"install" =>
"Встановити",

"deinstall" =>
"Видалити",

"module_can_not_be_found" =>
"Неможливо знайти файли, необхідні для цього модуля",

"module_has_been_installed" =>
"Модуль встановлений:",

"module_has_been_removed" =>
"Модуль видалений:",


/* END */
''=>''
);
?>