<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"emoticon_module_name" =>
"Смайли",

"emoticon_module_description" =>
"Модуль смайлів",


//----------------------------------------
// Emoticon language lines
//----------------------------------------

"emoticon_heading" =>
"Смайли",

"emoticon_glyph" =>
"Гліф",

"emoticon_image" =>
"зобр.",

"emoticon_width" =>
"Ширина",

"emoticon_height" =>
"Висота",

"emoticon_alt" =>
"Alt тег",


/* END */
''=>''
);
?>