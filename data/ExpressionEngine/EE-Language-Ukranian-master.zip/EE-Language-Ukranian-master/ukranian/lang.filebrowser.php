<?php

$L = array(

"file_browser" =>
"Браузер файлів",

"view" =>
"Перегляд",

"path_does_not_exist" => 
"Вказаний шлях не існує",

"file_viewing_error" =>
"Відбулася невідома помилка.",

"fp_no_files" => 
"Немає файлів в теці.",

"fb_view_images" =>
"Див. зобр.",

"fb_view_image" =>
"Див. зобр.",

"fb_insert_file" =>
"Помістити файл",

"fb_insert_files" =>
"Помістити файли",

"fb_select_field" =>
"Виберіть поле",

"fb_select_files" =>
"Виберіть файли",

"fb_non_images" =>
"* показує не зображення.  Тільки зображення можуть бути переглянуті.",

"fb_insert_link" =>
"Вставте посилання",

"fb_insert_links" =>
"Вставте посилання",

"fb_insert_url" =>
"Вставте URL",

"fb_insert_urls" =>
"Вставте URLs",

// IGNORE
''=>'');?>