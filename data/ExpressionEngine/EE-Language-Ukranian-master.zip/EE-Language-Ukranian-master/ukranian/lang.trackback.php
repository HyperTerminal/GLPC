<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"trackback_module_name" =>
"Трекбеки",

"trackback_module_description" =>
"Модуль трекбеків",

//----------------------------------------

"trackbacks_not_allowed" =>
"Trackbacks вимкнені для цієї статті",


/* END */
''=>''
);
?>