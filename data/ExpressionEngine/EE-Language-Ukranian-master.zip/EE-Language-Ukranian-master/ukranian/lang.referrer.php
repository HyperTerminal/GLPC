<?php

$L = array(

//----------------------------------------
// Required for MODULES page
//----------------------------------------

"referrer_module_name" =>
"Реферали",

"referrer_module_description" =>
"Модуль відстежування рефералів",

//----------------------------------------

"referrer_preferences" =>
"Налагодження рефералів",

"referrer_ip" =>
"IP реферала",

"referrer_date" =>
"Дата перегляду",

'ref_ip' =>
"IP адрес",

'ref_user_agent' =>
"User Agent",

'ref_url' =>
"URL",

'ref_type' =>
"Тип",

"referrers" =>
"Реферали",

"view_referrers" =>
"Див. реферали",

"clear_referrers" =>
"Очистити",

"referrer_from" =>
"Referrer з",

"referrer_to" =>
"Referrer на",

"no_referrers" =>
"Немає рефералів",

"total_referrers" =>
"Всього:",

"save_instructions" =>
"Скільки останніх рефералів Ви хочете зберігати?",

"referrers_deleted" =>
"Реферали були видалені",

"referrer_deleted" =>
"Реферал був видалений",

'delete_confirm' =>
"Підтвердіть видалення",

"referrer_delete_question" =>
"Ви точно хочете видалити вибраний(і) реферал(и)?",

'blacklist_question' =>
"На додаток до видалення цих рефералів Ви можете також:",

'add_urls' =>
"Додати URLи в чорний список і видалити інші рефералів з подібною адресою?",

'add_ips' =>
"Додати IP адреси в чорний список і видалити інші рефералів з таким-же IP?",

'add_agents' =>
"Додати User Agent&#39;и в чорний список і видалити інші рефералів з таким же User Agent?",

/* END */
''=>''
);
?>