<?php
$lang = array(


'module_name' => 
'Naziv modula',

'module_description' => 
'Opis',

'data_will_be_lost' => 
'Svi podaci povezani sa ovim modulom bit će trajno izbrisani!',

'module_access' => 
'Uredi modul',

'module_no_access' => 
'Nije vam dopušten pristup modulima',

'delete_module' => 
'Ukloni modul',

'delete_module_confirm' => 
'Jeste li sigurni da želite ukloniti slijedeći modul:',

'module_backend' => 
'CP korisnika',

'module_version' => 
'Verzija',

'module_status' => 
'Status',

'module_action' => 
'Akcija',

'not_installed' => 
'Nije instaliran',

'installed' => 
'instaliran',

'install' => 
'Instaliraj',

'update_modules' => 
'Pokreni nadogradnju modula',

'updated' => 
'Nadograđen',

'updated_to_version' => 
'Nadograđen na verziju',

'all_modules_up_to_date' => 
'Svi moduli su nadograđeni',

'deinstall' => 
'Ukloni',

'module_can_not_be_found' => 
'Nemoguće pronaći dokumente potrebne za instalaciju ovog modula',

'module_has_been_installed' => 
'Instaliran modul:',

'module_has_been_removed' => 
'Uklonjen modul:',

'requested_module_not_installed' => 
'Traženi modul nije instaliran.',

'requested_page_not_found' => 
'Tražena stranica modula nije pronađena.',

'translate' => 
'Update',

''=>''
);

// End of File