<?php
$lang = array(


'ip_to_nation_module_name' => 
'IP to Nation',

'ip_to_nation_module_description' => 
'Alat za pridruživanje IP adresa njihovim državama',

'iptonation_missing' => 
'Nije pronađen iptonation.php dokument. Provjerite jeste li transferirali sve komponente ovog modula.',

'countryfile_missing' => 
'Nije pronađen country.php dokument u lib direktoriju.',

'ip_search' => 
'Pretraga IP adresa',

'ip_search_inst' => 
'Upišite IP adresu da bi utvrdili sa kojom je državom povezana',

'ip_result' => 
'Država u kojoj je locirana upisana IP adresa:',

'manage_banlist' => 
'Upravljajte listom zabranjenih država',

'country' => 
'Država',

'ban_info' => 
'Označite države koje želite zabraniti. Kada je država zabranjena, osoba sa IP adresom iz te države neće moći postati komentare, trackbacks, ili korisiti e-mail / pošalji prijatelju obrazac, iako će moći vidjeti Vaše stranice.',

'ban' => 
'Zabrani',

'banlist' => 
'Lista zabranjenih država',

'banlist_updated' => 
'Lista zabranjenih državaje uspješno osvježena',

'translate' => 
'Osvježi',

''=>''
);

// End of File