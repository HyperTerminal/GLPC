<?php
$lang = array(


'file_browser' => 
'Pregled dokumenata',

'view' => 
'Pregledaj',

'path_does_not_exist' => 
'Staza koju ste unijeli ne postoji',

'file_viewing_error' => 
'Dogodila se greška nepoznate vrste.',

'fp_no_files' => 
'Nema dokumenata u ovom direktoriju.',

'fb_view_images' => 
'Pregledaj slike',

'fb_view_image' => 
'Pregledaj sliku',

'fb_insert_file' => 
'Umetni dokument',

'fb_insert_files' => 
'Umetni dokumente',

'fb_select_field' => 
'Odaberi polje',

'fb_select_files' => 
'Odaberi polja',

'fb_non_images' => 
'* označava da nema slika.  Mogu se pregledavati samo slike .',

'fb_insert_link' => 
'Umetni link',

'fb_insert_links' => 
'Umetni linkove',

'fb_insert_url' => 
'Umetni URL',

'fb_insert_urls' => 
'Umetni URLove',

'translate' => 
'Update',

''=>''
);

// End of File