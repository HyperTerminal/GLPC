<?php
$lang = array(


'f_tip' => 
'Upišite adresu, grad, državu, ili ulicu i poštanski broj: ',

'find_it' => 
'Pronađi',

'marker_at_c' => 
'Postavi pokazivač u centar',

'translate' => 
'Osvježi',

''=>''
);

// End of File