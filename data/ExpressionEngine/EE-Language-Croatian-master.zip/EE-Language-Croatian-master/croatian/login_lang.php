<?php
$lang = array(


'remember_me' => 
'Zapamti me?',

'no_username' => 
'Polje korisnika je obavezno.',

'no_password' => 
'Polje za lozinku je obavezno.',

'no_email' => 
'Potrebno je upisati vašu email adresu.',

'credential_missmatch' => 
'Neispravno korisničko ime ili lozinka.',

'multi_login_warning' => 
'Netko je već logirna s ovim korisničkim računom.',

'return_to_login' => 
'Povratak na Ulaz',

'password_lockout_in_effect' => 
'Možete pokušati samo 4 puta svakih %x minuta',

'unauthorized_request' => 
'Nemate ovlasti za ovu akciju',

'new_password_request' => 
'Zahtjev za novu lozinku',

'session_auto_timeout' => 
'Vaša sesija je istekla ili je neaktivna',

'translate' => 
'Update',

''=>''
);

// End of File