<?php
$lang = array(


'admin_notify_mailinglist' => 
'Obavijest administratoru o upisu na mailing listu',

'admin_notify_mailinglist_desc' => 
'Ovaj predložak definira poruku koju admin dobije kada se netko upiše na mailing listu.',

'admin_notify_forum_post_desc' => 
'vaj predložak definira poruku koju admin dobije kada je poslan novi forum post',

'admin_notify_entry' => 
'Obavijest administratoru o novim postovima',

'admin_notify_entry_desc' => 
'Ovaj predložak definira poruku koju će dobiti primatelji obavijesti kada je postan novi post.',

'private_message_notification' => 
'Obavijesti o privatnoj poruci',

'private_message_notification_desc' => 
'Ovaj predložak definira poruke koje korisnik dobiva kad mu netko pošalje privatnu poruku',

'forum_post_notification_desc' => 
'Ovaj predložak definira poruku koju korisnik dobiva kad netko odgovori na njihov post na forumu',

'admin_notify_forum_post' => 
'Obavijest administratoru o postovima na forumu',

'forum_post_notification' => 
'Obavijest korisniku o postovima na forumu',

'gallery_comment_notification' => 
'Obavijest o komentarima korisnicima galerije',

'gallery_comment_notification_desc' => 
'Ovaj preložak definira poruku koju korisnik dobiva kada netko odgovori na njihov komentar',

'admin_notify_gallery_comment' => 
'Obavijest administratoru o kometarima u galeriji',

'admin_notify_gallery_comment_desc' => 
'Ovaj preložak definira poruku koju admin dobiva kada je dodan novi komentar u galeriji',

'email_title' => 
'Naslov e-maila',

'email_message' => 
'E-mail poruka',

'admin_notify_comment' => 
'Obavijest administratoru o novom komentaru',

'admin_notify_comment_desc' => 
'Ovaj predložak definira poruku koju prima administrator kada netko doda komentar',

'admin_notify_reg' => 
'Obavijest administratoru o registraciji novog korisnika',

'admin_notify_reg_desc' => 
'Ovaj predložak definira poruku koju dobiva administrator kada se registrira novi korisnik',

'comment_notification' => 
'Obavijest korisniku o komentaru',

'comment_notification_desc' => 
'Ovaj predložak definira poruku koju korisnik dobiva kada netko odgovori na njegov komentar',

'forgot_password_instructions' => 
'Upute za zaboravljenu lozinku',

'forgot_password_instructions_desc' => 
'Ovaj predložak definira upute koje dobiva korisnik koji je zaboravio lozinku',

'mailinglist_activation_instructions' => 
'Upute za aktivaciju mailing liste',

'mailinglist_activation_instructions_desc' => 
'Ovaj predložak definira upute za aktivaciju mailing liste',

'mbr_activation_instructions' => 
'Upute za aktivaciju korisničkog računa',

'mbr_activation_instructions_desc' => 
'Ovaj predložak definira upute za aktivaciju računa koje se šalju tek registriranim korisnicima',

'reset_password_notification' => 
'Obavijesti o promjeni lozinke',

'reset_password_notification_desc' => 
'Ovaj predložak definira upute za promjenu lozinke',

'validated_member_notify' => 
'Obavijest o provjeri korisničkog računa',

'decline_member_validation' => 
'Obavijest o odbijanju korisničkog računa',

'validated_member_notify_desc' => 
'Ovaj predložak definira obavijest koju korisnik dobije kada adminstrator potvrdi njegov korisnički račun.',

'use_this_template' => 
'Omogući ovaj predložak?',

'use_this_template_exp' => 
'Ako je onemogućeno, ovaj se predložak neće koristiti.  Umjesto toga, dinamički će se generirati poruka na jeziku koji je korisnik odabrao kao svoj zadani.',

'user_messages_template_desc' => 
'Namjena ovog predloška je da pokaže greške i ostale poruke korisnicima nakon što naprave neke akcije, kao logiranje, salanje forme, itd.',

'user_messages_template_warning' => 
'Nemojte brisati ni jednu od 5 potrebnih varijabli:',

'available_variables' => 
'Moguće je koristiti slijedeće varijable:',

'pm_inbox_full' => 
'Obavijest o ispunjenom sandučiću privatnih poruka',

'pm_inbox_full_desc' => 
'Ovaj predložak definira poruku koju korisnik dobiva ako mu ne stižu privatke poruke jer je sandučić pun',

'forum_moderation_notification' => 
'Obavijest korisniku o moderiranju teme na forumu',

'forum_moderation_notification_desc' => 
'Ovaj predložak definira obavijesti koje korisnici dobiju kada moderator premjesti, podijeli ili spoji njihov post ili temu',

'forum_report_notification' => 
'Obavijesti moderatora o prijavljenom postu',

'forum_report_notification_desc' => 
'Ovaj predložak definira obavijesti koje moderatori dobivaju kada korisnik prijavi post sa foruma',

'email_subject' => 
'Naslov e-maila',

'message_body' => 
'E-mail poruka',

'translate' => 
'Osvježi',

''=>''
);

// End of File