<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang = array(


''=>''
);

/* End of file lang.javascript.php */
/* Location: ./system/expressionengine/language/english/lang.javascript.php */