<?php
$lang = array(


'email_module_name' => 
'E-mail',

'email_module_description' => 
'Korisnički e-mail modul',

'message_required' => 
'Potrebno je upisati e-mail poruku',

'em_banned_from_email' => 
'Adresa pošiljaoca koju ste unijeli je blokirana.',

'em_banned_recipient' => 
'Jedna ili više adresa primatelja e-maila je blokirano.',

'em_invalid_recipient' => 
'Jedna ili više e-mail adresa primatelja je neispravno.',

'em_no_valid_recipients' => 
'Vaš e-mail nema važećih adresa primatelja.',

'em_sender_required' => 
'Potrebna važeća adresa primatelja e-maila',

'em_unauthorized_request' => 
'Nemate dopuštenje izvršiti ovu akciju',

'em_limit_exceeded' => 
'Dostigli ste broj dozvoljenih e-mailova u jednom danu.',

'em_interval_warning' => 
'Dopušteno vam je slati e-mail obrasce svakih %s sekundi',

'em_email_sent' => 
'Vaša e-mail poruka je poslana.',

'translate' => 
'Update',

''=>''
);

// End of File