<?php
$lang = array(


'design_user_message' => 
'Predložak za korisničke poruke',

'design_system_offline' => 
'Sistem Nedostupan predložak',

'design_email_notification' => 
'Predložak e-mail obavijesti',

'design_member_profile_templates' => 
'Predložak za profil korisnika',

'member_register_member' => 
'Registracija korisnika',

'member_validation' => 
'Odobravanje korisnika',

'member_view_members' => 
'Vidi korisnike',

'member_ip_search' => 
'Pretraga IP adresa korisnika',

'member_custom_profile_fields' => 
'Zadana polja korisnika',

'member_group_manager' => 
'Upravljanje grupama korisnika',

'member_config' => 
'postavke korisnika',

'member_banning' => 
'Blokiranje korisnika',

'member_search' => 
'Pretraga korisnika',

'data_sql_manager' => 
'Sql upravljanje',

'data_search_and_replace' => 
'Traži i zamijeni',

'data_recount_stats' => 
'Prebroji statistike',

'data_php_info' => 
'PHP Info',

'data_clear_caching' => 
'Isprazni pohrane',

'file_index' => 
'Upravljanje dokumentima',

'cont_field_group_management' => 
'Upravljanje grupama polja',

'members_member_group_manager' => 
'Upravljanje grupama korisnika',

'cont_category_management' => 
'Upravljanje kategorijama',

'members_custom_profile_fields' => 
'Dodatna polja za profil korisnika',

'logs_view_cp_log' => 
'Vidi pohrane administracije',

'logs_view_throttle_log' => 
'Vidi throttle pohrane',

'logs_view_search_log' => 
'Vidi pohrane od pretraga',

'logs_view_email_log' => 
'Vidi pohrane e-mailova',

'util_member_import' => 
'Uvoz korisnika',

'util_import_from_mt' => 
'Uvezi iz MT',

'util_import_from_xml' => 
'Uvezi iz XML',

'util_translation_tool' => 
'Alat za prevođenje',

'plug_index' => 
'Pluginovi',

'modu_index' => 
'Moduli',

'exte_index' => 
'Ekstenzije',

'acce_index' => 
'Pomagala',

'translate' => 
'Update',

''=>''
);

// End of File