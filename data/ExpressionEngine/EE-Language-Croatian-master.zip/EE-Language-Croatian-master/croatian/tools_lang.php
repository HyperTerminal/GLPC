<?php
$lang = array(


'tools' => 
'Alati',

'tools_data' => 
'Podaci',

'tools_logs' => 
'Logovi',

'tools_utilities' => 
'Alati',

'communicate' => 
'Komuniciraj',

'config_editor' => 
'Upravljanje konfiguracijskim dokumentom',

'php_info' => 
'PHP info',

'recount_stats' => 
'Prebroj statistike',

'search_and_replace' => 
'Traži i zamijeni',

'sql_manager' => 
'SQL upravljanje',

'clear_caching' => 
'Očisti pohranjene podatke',

'view_throttle_log' => 
'Vidi throttle log',

'view_search_log' => 
'Vidi log pretraga',

'view_email_logs' => 
'Vidi log e-mail konzole',

'view_cp_log' => 
'Vidi log administracije',

'import_utilities' => 
'Uvezi alate',

'translation_tool' => 
'Alat za prevođenje',

'english' => 
'Engleski',

'translation' => 
'Prijevod',

'hits' => 
'Pogleda',

'last_activity' => 
'Zadnja aktivnost',

'no_throttle_logs' => 
'Trenutno nijedna IP adresa nije u throttled u sistemu.',

'throttling_disabled' => 
'Throttling onemogućen',

'blacklist_all_ips' => 
'Stavi sve IP adrese na Crnu listu',

'no_search_results' => 
'Nema rezultata',

'search_results' => 
'Rezultati pretrage',

'site_search' => 
'Sajt',

'searched_in' => 
'Traženo u',

'search_terms' => 
'Pojmovi pretrage',

'page_caching' => 
'Dokumenti pohrana stranice (predloška)',

'tag_caching' => 
'Dokumenti pohrana tagova',

'db_caching' => 
'Dokumenti pohrana baze podataka',

'cached_relationships' => 
'Pohranjeni povezani sadržaji',

'all_caching' => 
'Sve pohrane',

'sandr_instructions' => 
'Ovi obrasci vam omogućuju traženje određenog teksta i zamjenu istog nekim drugim tekstom',

'search_term' => 
'Traži ovaj tekst',

'replace_term' => 
'I zamijeni ga ovim',

'replace_where' => 
'U kojem polju baze podataka želite izvršiti zamjenu?',

'search_replace_disclaimer' => 
'Ovisno o korištenoj sintaksi, ova funkcija može donijeti neželjene rezultate. Pogledajte upute i napravite backup baze podataka.',

'advanced_users_only' => 
'Samo napredni korisnici',

'choose_translation_file' => 
'Odaberite dokument za prijevod',

'no_lang_file' => 
'Nema jezičnih dokumenata',

'no_lang_keys' => 
'Nema jezičnih ključeva za prijevod',

'invalid_path' => 
'Staza koju ste upisali nije važeća:',

'file_saved' => 
'Jezični dokument je spremljen u system/expressionengine/translations/',

'trans_file_not_writable' => 
'U jezični dokument nije moguće zapisivanje.',

'import_from_mt' => 
'Prijenosni alat za uvoz ',

'member_import' => 
'Alat za uvoz korisnika',

'missing_password_type' => 
'Obvezni type atribut nedostaje u lozinki za korisnika: %x. Molimo pogledajte dokumentaciju za ispravan format uvoza.',

'united_states' => 
'United States',

'european' => 
'Europa',

'preference' => 
'Opcija',

'setting' => 
'Postavka',

'preferences_updated' => 
'Postavke osvježene',

'true' => 
'Da',

'false' => 
'Ne',

'translation_dir_unwritable' => 
'Upozorenje: U direktorij za prijevod nije moguće zapisivanje.',

'screen_name' => 
'Ime i prezime',

'translate' => 
'Update',

''=>''
);

// End of File