<?php
$lang = array(


'referrer_module_name' => 
'Refereri',

'referrer_module_description' => 
'Modul praćenja referera',

'referrer_preferences' => 
'Postavke praćenja',

'referrer_ip' => 
'IP referera',

'referrer_date' => 
'Datum referera',

'ref_ip' => 
'IP adresa',

'ref_user_agent' => 
'Korisnički posrednik',

'ref_url' => 
'URL',

'ref_type' => 
'Vrsta',

'referrers' => 
'Refereri',

'view_referrers' => 
'Pregledaj referere',

'clear_referrers' => 
'Očisti referere',

'referrer_from' => 
'Od referera',

'referrer_to' => 
'Do referera',

'no_referrers' => 
'Trenutno nema referera',

'referrer_no_results' => 
'Trenutno nema rezultata za kriterije koje ste zadali',

'total_referrers' => 
'Ukupno referera:',

'save_instructions' => 
'Koliko zadnjih referera želite snimiti?',

'referrers_deleted' => 
'Refereri su izbrisani',

'referrer_deleted' => 
'Referer je izbrisan',

'delete_confirm' => 
'Potvrdi brisanje',

'referrer_delete_question' => 
'Jeste li sigurni da želite izbrisati označene referere?',

'blacklist_question' => 
'Dodatno brisanju ovih referera možete još i:',

'add_urls' => 
'Izbriši ostale referere sa istim URL-om?',

'add_and_blacklist_urls' => 
'Dodaj URL na Crnu listu i izbriši ostale referere sa istim URL-om?',

'add_ips' => 
'Izbriši ostale referere sa istom IP adresom?',

'add_and_blacklist_ips' => 
'Dodaj IP adresu na Crnu listu i izbriši ostale referere sa istom IP adresom?',

'add_agents' => 
'Izbriši ostale referere sa istim korsničkim agentom?',

'add_and_blacklist_agents' => 
'Dodaj korisničke agente na Crnu listu i izbriši ostale referere sa istim korisničkim agentom?',

'translate' => 
'Update',

''=>''
);

// End of File