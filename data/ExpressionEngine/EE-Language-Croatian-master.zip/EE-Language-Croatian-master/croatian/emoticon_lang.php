<?php
$lang = array(


'emoticon_module_name' => 
'Smajli',

'emoticon_module_description' => 
'Smajli modul',

'emoticon_heading' => 
'Smajliji',

'emoticon_glyph' => 
'Znak',

'emoticon_image' => 
'Slika',

'emoticon_width' => 
'Širina',

'emoticon_height' => 
'Visina',

'emoticon_alt' => 
'Alt tag',

'translate' => 
'Update',

''=>''
);

// End of File