<?php
$lang = array(


'updated_sites_module_name' => 
'Osvježene stranice',

'updated_sites_module_description' => 
'Dopusti ostalim sajtovima da vas pingaju.',

'updated_sites_home' => 
'Administracija',

'unauthorized_action' => 
'Nemate dopuštenje da izvedete ovaj postupak.',

'too_many_pings' => 
'Ping nije prihvaćen. Već ste poslali ping u zadnjih %X minuta.',

'invalid_access' => 
'Neispravan pristup',

'updated_sites_configurations' => 
'Postavke osvježenih stranica',

'updated_sites_config_name' => 
'Ime',

'updated_sites_short_name' => 
'Kratko ime',

'updated_sites_short_name_taken' => 
'Ovo kratko ime se već koristi.',

'single_word_no_spaces' => 
'Jedna riječ, bez razmaka',

'updated_sites_config_url' => 
'URL',

'no_ping_configs' => 
'Trenutno nema postavki osvježenih stranica',

'updated_sites_delete_confirm' => 
'Izbriši postavke osvježenih stranica',

'updated_sites_deleted' => 
'Postavke osvježenih stranica izbrisane',

'updated_site_deleted' => 
'Postavka osvježenih stranica izbrisana',

'metaweblogs_deleted' => 
'Postavke osvježenih stranica izbrisane',

'updated_sites_delete_question' => 
'Jeste li sigurni da želite izbrisati označene postavke osvježenih stranica?',

'delete' => 
'Izbriši',

'updated_sites_missing_fields' => 
'Polje je ostavljeno prazno, molimo popunite ih i pošaljite ponovo.',

'new_config' => 
'Nova postavka',

'modify_config' => 
'Promijeni postavku',

'configuration_options' => 
'Opcije postavke',

'updated_sites_pref_name' => 
'Naziv postavke',

'updated_sites_allowed' => 
'Stranice kojima je dopušteno pinganje',

'updated_sites_allowed_subtext' => 
'Da bi vam stranice mogle poslati ping, dio njihove URL adrese, recimo naziv domene, mora biti u listi. Stavite svaku stranicu u novi red.',

'updated_sites_prune' => 
'Maksimalni broj pingova za spremanje?',

'configuration_created' => 
'Postavka napravljena',

'configuration_updated' => 
'Postavka osvježena',

'updated_sites_create_new' => 
'Napravi novu postavku',

'successful_ping' => 
'Ping uspješno primljen!',

'view_pings' => 
'Vidi pingove',

'no_pings' => 
'Nema pingova',

'total_pings' => 
'Ukupno pingova',

'ping_name' => 
'Naziv stranice',

'ping_url' => 
'URL stranice',

'ping_rss' => 
'RSS stranice',

'ping_date' => 
'Datum pinga',

'delete_pings_confirm' => 
'Potvrda brisanja pinga',

'ping_delete_question' => 
'Jeste li sigurni da želite izbrisati označene pingove?',

'pings_deleted' => 
'Pingovi izbrisani',

'preference' => 
'Preferirano',

'setting' => 
'Postavka',

'translate' => 
'Osvježi',

''=>''
);

// End of File