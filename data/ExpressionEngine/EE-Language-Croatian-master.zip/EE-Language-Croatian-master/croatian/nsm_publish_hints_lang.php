<?php
$lang = array(


'nsm_example_addon' => 
'NSM Publish savjeti',

'nsm_example_addon_module_name' => 
'NSM Publish savjeti: Naziv modula',

'nsm_example_addon_module_description' => 
'NSM Publish savjeti: Opis modula',

'index_page_title' => 
'NSM Publish savjeti: Upravljanje',

'index_nav_title' => 
'Upravljanje',

'save_extension_settings' => 
'Spremi postavke ekstenzije',

'alert_success_extension_settings_saved' => 
'Postavke ekstenzije su spremljene.',

'translate' => 
'Osvježi',

''=>''
);

// End of File