<?php
$lang = array(


'extension_settings_info' => 
'MX upravljanje naslovima omogućava vam promjenu *Naziv polja naslova za svaki weblog i za svaki jezik (opcija). U slučaju da je polje prazno sistem će koristiti zadani naslov jezika',

'extension_settings_title' => 
'MX upravljanje naslovima',

'channel_name' => 
'naziv _webloga',

'title' => 
'Zamijeni naslov sa ...',

'url_title' => 
'Zamijeni URL naslov sa ...',

'multilanguage_settings_info' => 
'U slučaju da želite podesiti naslove po jezicima, molimo omogućite višejezičnu podršku.',

'check_for_extension_updates_title' => 
'Provjeri nadogradnje? ',

'enable' => 
'Omogući',

'disable' => 
'Onemogući',

'extension_settings_saved_success' => 
'Postavke ekstenzije su uspješno spremljene',

'save_extension_settings' => 
'Spremi postavke ekstenzije',

'multilanguage' => 
'Višejezična podrška',

'check_for_extension_updates_info' => 
'Ekstenzija može kontaktirati svoju stranicu (<a href="http://wiseupstudio.com/">http://wiseupstudio.com/</a>) te provjeriti da li postoji nadogradnja.',

'check_for_extension_updates_label' => 
'Želite li da ekstenzija provjerava nadogradnje i prikazuje ih na početnoj stranici vaše administracije?',

'check_for_extension_updates_nolgau' => 
'Ova postavka zahtijeva <strong><a href="http://leevigraham.com/cms-customisation/expressionengine/lg-addon-updater/">LG Addon nadogradnje</a></strong>.',

'translate' => 
'Osvježi',

''=>''
);

// End of File