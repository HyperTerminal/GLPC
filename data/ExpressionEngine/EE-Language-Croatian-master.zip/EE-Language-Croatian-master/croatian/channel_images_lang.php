<?php
$lang = array(


'channel_images' => 
'Slike webloga',

'channel_images_module_name' => 
'Slike webloga',

'channel_images_module_description' => 
'Omogućava povezivanje postova sa slikama.',

'ci:settings' => 
'Postavke',

'ci:docs' => 
'Dokumentacija',

'ci:choose_weblog' => 
'Slike webloga su omogućene za webloge?',

'ci:tab_name' => 
'Naziv kartice za objavu',

'ci:location_path' => 
'Staza servera',

'ci:location_url' => 
'URL lokacije',

'ci:verify_path' => 
'Potvrdi stazu',

'ci:categories' => 
'Kategorije',

'ci:categories_explain' => 
'Odvoji svaku kategoriju zarezom.',

'ci:image_sizes' => 
'Veličine slika',

'ci:name' => 
'Naziv',

'ci:width_px' => 
'Širina (px)',

'ci:height_px' => 
'Visina (px)',

'ci:quality' => 
'Kvaliteta',

'ci:add_size' => 
'Dodaj novu veličinu slike',

'ci:small' => 
'Mala',

'ci:medium' => 
'Srednja',

'ci:large' => 
'Velika',

'ci:greyscale' => 
'Siva?',

'ci:settings_saved' => 
'Postavke spremljene!',

'ci:upload_images' => 
'Transferiraj slike',

'ci:time_remaining' => 
'Preostaje vremena',

'ci:dupe_field' => 
'Ne može se koristiti više od jednog polja za slike u isto vrijeme.',

'ci:missing_settings' => 
'Nedostaju postavke slike webloga za ovaj weblog.',

'ci:assigned_images' => 
'Pridružene slike',

'ci:no_images' => 
'nema još transferiranih slika',

'ci:id' => 
'ID',

'ci:image' => 
'Slika',

'ci:title' => 
'Naziv',

'ci:desc' => 
'Opis',

'ci:category' => 
'Kategorija',

'ci:filename' => 
'Naziv dokumenta',

'ci:actions' => 
'Akcija',

'ci:actions:edit' => 
'Editiraj',

'ci:actions:cover' => 
'Naslovnica',

'ci:actions:move' => 
'Redoslijed',

'ci:actions:del' => 
'Obriši',

'ci:file_arr_empty' => 
'Nijedan dokument nije transferiran ili nije dozvoljen. (PogledajEE Mime-type postavke).',

'ci:tempkey_missing' => 
'Privremeni ključ nije pronađen',

'ci:file_upload_error' => 
'Nijedan dokument nije  transferiran. (Možda je količina podataka prevelika)',

'ci:no_settings' => 
'Ne postoje postavke webloga za ovaj weblog.',

'ci:file_to_big' => 
'Ovaj dokument je prevelik. (Pogledajte postavke modula za veličinu).',

'ci:extension_not_allow' => 
'Ovaj tip dokumenta nije podržan. (Vidi postavke modula)',

'ci:targetdir_error' => 
'U odredišnu mapu se ne može pisati ili ne postoji',

'ci:file_move_error' => 
'Neuspješno prebacivanje transferirnaih dokumenata u privremeni direktorij, provjerite dozvole za transfer, postavke staza i slično..',

'translate' => 
'Osvježi',

''=>''
);

// End of File