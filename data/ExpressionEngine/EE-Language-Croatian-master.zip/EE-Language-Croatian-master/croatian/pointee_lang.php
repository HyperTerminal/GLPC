<?php
$lang = array(


'pointee' => 
'Pointee',

'image_location' => 
'URL slike za pointee',

'marker_type' => 
'Boja markera',

'allow_user_upload' => 
'Dopusti korisniku upload slike kod objave?<br /> (gornji URL će biti ignoriran)',

'please_check_field_config' => 
'Greška: molimo provjerite konfiguraciju polja',

'translate' => 
'Osvježi',

''=>''
);

// End of File