<?php
$lang = array(


'spell_check' => 
'Provjera pravopisa',

'check_spelling' => 
'Provjeri pravopis',

'save_spellcheck' => 
'Spremi promjene',

'revert_spellcheck' => 
'Vrati na orginal',

'spell_save_edit' => 
'Spremi editirano',

'spell_edit_word' => 
'Editiraj riječ',

'unsupported_browser' => 
'Nepodržani preglednik',

'no_spelling_errors' => 
'Nema grešaka',

'spellcheck_in_progress' => 
'Provjera u tijeku...',

'translate' => 
'Update',

''=>''
);

// End of File