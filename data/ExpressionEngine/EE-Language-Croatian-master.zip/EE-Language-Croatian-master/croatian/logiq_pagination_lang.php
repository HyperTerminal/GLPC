<?php
$lang = array(


'first_marker' => 
'Oznaka prvog linka.',

'last_marker' => 
'Oznaka zadnjeg linka.',

'next_link' => 
'Tekst / html znak koji želite koristiti za "slijedeće" link.',

'prev_link' => 
'Tekst / html znak koji želite koristiti za "prethodno" link.',

'text_first' => 
'Tekst za "prvo" link.',

'text_last' => 
'Tekst za "zadnje" link.',

'max_links' => 
'Broj "brojevi" linkova za prikaz pretthodno/slijedeće od trenutne stranice.',

'first_div_o' => 
'Početni tag za "prvo" link.',

'first_div_c' => 
'Završni tag za "prvo" link.',

'next_div_o' => 
'Početni tag za "slijedeće" link.',

'next_div_c' => 
'Završni tag za "slijedeće" link.>',

'prev_div_o' => 
'Početni tag za "prethodno" link.',

'prev_div_c' => 
'Završni tag za "prethodno" link.',

'num_div_o' => 
'Početni tag za broj link.',

'num_div_c' => 
'Završni tag za broj link.',

'cur_div_o' => 
'Početni tag za trenutna stranica link.',

'cur_div_c' => 
'Završni tag za trenutna stranica link',

'last_div_o' => 
'Početni tag za "zadnje" link.',

'last_div_c' => 
'Završni tag za "zadnje" link.',

'get_last_index' => 
'Možda ćete željeti promijeniti zadnji tag kako biste dodali class/id kako bi bolje odgovarao vašem dizajnu (opcija)',

'set_last_index' => 
'Zamijeni zadnji tag ovim (opcija)',

'pagination_links_open' => 
'Tag za otvaranje prije početka paginacije. (opcija)',

'pagination_links_close' => 
'Tag za poslijednje prije kraja paginacije. (opcija)',

'pre_start_tag' => 
'Extra Pre start tag za extra layout mogućnosti (opcija)',

'pre_end_tag' => 
'Extra pre End tag za extra layout mogućnosti (opcija)',

'usenumforlast' => 
'Želite li koristiti brojač ukupnih stranica umjesto zadnje tekst linka?',

'translate' => 
'Osvježi',

''=>''
);

// End of File