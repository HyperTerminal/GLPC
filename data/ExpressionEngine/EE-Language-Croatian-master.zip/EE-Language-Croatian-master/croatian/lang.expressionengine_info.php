<?php
$lang = array(


'expressionengine_info' => 
'ExpressionEngine Info',

'resources' => 
'Izvori',

'documentation' => 
'Online Dokumentacija',

'support_forums' => 
'Forumi za tehničku podršku',

'downloads' => 
'Download iz My ExpressionEngine Trgovine',

'support_resources' => 
'Izvori za podršku',

'version_and_build' => 
'Verzija i Build',

'error_getting_version' => 
'Trenutno nije moguće prikazati broj zadnje verzije',

'version_info' => 
'Trenutna verzija ExpressionEnginea je %v Build %b',

'translate' => 
'Osvježi',

''=>''
);

// End of File