<?php
$lang = array(


'extension_settings_info' => 
'Dodaje mogućnost kloniranja sadržaja',

'extension_settings_title' => 
'MX Cloner',

'extension_settings_saved_success' => 
'Postavke ekstenzije uspješno spremljene',

'save_extension_settings' => 
'Spremi postavke ekstenzije',

'title_field_suffix' => 
'Sufiks polja',

'url_title_suffix' => 
'Sufiks URL naslova',

'update_entry_time' => 
'Vrijeme osvježavanja sadržaja?',

'translate' => 
'Osvježi',

''=>''
);

// End of File