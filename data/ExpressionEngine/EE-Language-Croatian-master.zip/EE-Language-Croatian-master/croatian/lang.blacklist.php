<?php
$lang = array(


'blacklist_module_name' => 
'Crna / Bijela lista',

'blacklist_module_description' => 
'Modul crne i bijele liste',

'htaccess_written_successfully' => 
'U .htaccess je uspješno zapisano.',

'invalid_htaccess_path' => 
'Neispravna staza ili permisije za .htaccess dokument',

'htaccess_server_path' => 
'Staza servera za .htaccess dokument',

'write_htaccess_file' => 
'Upiši crnu listu u .htaccess dokument?',

'whitelist' => 
'Bijela lista',

'pmachine_whitelist' => 
'Skini ExpressionEngine.com Bijelu listu',

'whitelist_updated' => 
'Bijela lista uspješno osvježena',

'ref_whitelist_irretrievable' => 
'Greška: nova bijela lista je bila nepovratna.',

'ref_view_whitelist' => 
'Pogledaj bijelu listu',

'ref_no_whitelist' => 
'Trenutno nema ništa na bijeloj listi',

'ref_whitelisted' => 
'Na bijeloj listi',

'ref_no_whitelist_table' => 
'Ne postoji tablica baze podatka bijele liste',

'ref_type' => 
'Tip podatka',

'blacklist' => 
'Crna lista',

'pmachine_blacklist' => 
'Skini ExpressionEngine.com Crnu listu',

'requires_license_number' => 
'Zahtjeva broj licence u glavnim postavkama',

'blacklist_updated' => 
'Crna lista uspješno osvježena',

'ref_no_license' => 
'Greška: nema broja licence.',

'ref_blacklist_irretrievable' => 
'Greška: nova crna lista je bila nepovratna.',

'ref_view_blacklist' => 
'Vidi crnu listu',

'ref_no_blacklist' => 
'Trenutno nema ništa na crnoj listi',

'ref_ip' => 
'IP Adresa',

'ref_user_agent' => 
'Korisnički posrednik',

'ref_url' => 
'URL',

'ref_blacklisted' => 
'Na crnoj listi',

'ref_no_blacklist_table' => 
'Tablica baze podataka za crnu listu ne postoji',

'translate' => 
'Osvježi',

''=>''
);

// End of File