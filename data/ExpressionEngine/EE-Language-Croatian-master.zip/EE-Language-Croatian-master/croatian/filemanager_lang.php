<?php
$lang = array(


'content_files' => 
'Upravljanje dokumentima',

'upload_dir_choose' => 
'Odaberite mapu za transfer',

'file_upload_prefs' => 
'Postavke transfera dokumenata',

'create_new_upload_pref' => 
'Kreiraj novu transfer mapu',

'file_information' => 
'Info o dokumentu',

'upload' => 
'Transfer',

'upload_file' => 
'Transferiraj dokument',

'file_upload' => 
'Transfer dokumenta',

'file_download' => 
'Download',

'file_tools' => 
'Alati dokumenata',

'choose_file' => 
'Molimo odaberite dokument za brisanje',

'confirm_del_file' => 
'Jeste li sigurni da želite zauvijek izbrisati ovaj dokument?',

'confirm_del_files' => 
'Jeste li sigurni da želite zauvijek izbrisati ovedokumente?',

'delete_success' => 
'Brisanje uspješno',

'delete_fail' => 
'Došlo je do greške prilikom brisanja jednog ili više dokumenata. Molimo pregledajte listu ispod.',

'no_file' => 
'Nema označenih dokumenata',

'file_name' => 
'Naziv dokumenta',

'file_size' => 
'Veličina',

'file_size_unit' => 
'KB',

'size' => 
'Veličina',

'kind' => 
'Tip',

'where' => 
'Odredište',

'permissions' => 
'Dozvole',

'upload_success' => 
'Transfer uspješan',

'no_upload_dirs' => 
'Niste definirali odredišnu mapu',

'no_uploaded_files' => 
'Niste transferirali dokumente u mapu',

'image_editor' => 
'Editor slika',

'download_selected' => 
'Skini označene dokumenete',

'email_files' => 
'Pošalji emailom označene dokumente',

'delete_selected_files' => 
'Izbriši označene dokumente',

'edit_modes' => 
'Načini editiranja',

'resize' => 
'Promjeni veličinu',

'crop' => 
'Izreži',

'resize_width' => 
'Širina',

'resize_height' => 
'Visina',

'crop_width' => 
'Širina',

'crop_height' => 
'Visina',

'crop_x' => 
'X',

'crop_y' => 
'Y',

'rotate' => 
'Okretanje',

'rotate_90r' => 
'90&#176; Desno',

'rotate_90l' => 
'90&#176; Lijevo',

'rotate_180' => 
'180&#176',

'rotate_flip_vert' => 
'Okreni vertikalno',

'rotate_flip_hor' => 
'Okreni horizontalno',

'maintain_ratio' => 
'Zadrži omjer',

'width_needed' => 
'Širina ili  širina/visina mora biti označena, ili način okretanja.',

'crop_mode' => 
'Izreži sliku',

'resize_mode' => 
'Promjeni veličinu',

'rotate_mode' => 
'Okreni sliku',

'apply_changes' => 
'Primjeni promjene?',

'exit_apply_changes' => 
'Izlazite iz Edit moda.  Želite li prvo primjeniti promjene?',

'processing_image' => 
'Obrađujem sliku',

'done' => 
'Izlaz',

'edit_image' => 
'Snimi sliku',

'image_edit_success' => 
'Slika uspješno editirana',

'no_edit_selected' => 
'Nije označen način editiranja',

'uploading_file' => 
'Transferiram dokument',

'translate' => 
'Update',

''=>''
);

// End of File