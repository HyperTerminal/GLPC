<?php
$lang = array(


'stats_module_name' => 
'Statistike',

'stats_module_description' => 
'Modul za prikaz statistika',

'translate' => 
'Update',

''=>''
);

// End of File