<?php
$lang = array(


'rotate_unsupported' => 
'Rotacija slike nije podržana na ovom serveru.',

'nonexistent_filepath' => 
'Nije moguće pronaći navedenu sliku.',

'path_does_not_exist' => 
'Staza označena u postavkama transfera slika nije ispravna',

'file_exceeds_ini_limit' => 
'Transferirani dokument prelazi maksimalnu dozvoljenu veličinu u vašem PHP dokumentu sa postavkama',

'file_partially_uploaded' => 
'Dokument je samo djelomično transferiran',

'no_file_selected' => 
'Niste označili dokument za transfer',

'file_upload_error' => 
'Došlo je do greške nepoznate vrste.',

'invalid_filetype' => 
'Vrsta dokumenta koju pokušavate transferirati nije ispravna',

'invalid_filesize' => 
'Veličina dokumenta kojeg pokušavate tranferirati je veća od dopuštene',

'invalid_dimensions' => 
'Slika koju pokušavate transferirati prelazi maksimalnu visinu ili širinu',

'upload_error' => 
'Došlo je do problema prilikom transfera dokumenta',

'copy_error' => 
'Došlo je do greške prilikom zamjene dokumenta.  Provjerite da li je u direktorij dozvoljeno pisanje.',

'unsupported_protocol' => 
'Ovaj server ne podržava protokol promjene veličine slike naveden u postavkama.',

'jpg_or_png_required' => 
'Protokol za promjenu veličine slike označen u postavkama radi samo s JPEG i PNG formatima slika.',

'jpg_gif_png_required' => 
'Protokol za promjenu veličine slike označen u postavkama radi samo s GIF, JPEG ili PNG formatima slika.',

'libpath_invalid' => 
'Staza do slika nije ispravna. Označite ispravnu stazu slika u postavkama slika.',

'image_resize_failed' => 
'Promjena veličine slike neuspješna. Provjerite da li ovaj server podržava odabrani protokol i da li je staza do slika ispravna.',

'invalid_filecontent' => 
'Dokument koji pokušavate transferirati ima neispravan sadržaj za njegov MIME tip.',

'translate' => 
'Osvježi',

''=>''
);

// End of File