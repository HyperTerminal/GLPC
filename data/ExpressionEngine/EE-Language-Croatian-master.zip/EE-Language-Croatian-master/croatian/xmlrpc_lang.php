<?php
$lang = array(


'invalid_license' => 
'Neispravan serijski broj',

'translate' => 
'Update',

''=>''
);

// End of File