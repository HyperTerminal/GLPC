<?php
$lang = array(


'jquery_module_name' => 
'jQuery',

'jquery_module_description' => 
'jQuery Modul',

'missing_jquery_file' => 
'Traženi jQuery dokument nije pronađen.',

'translate' => 
'Update',

''=>''
);

// End of File