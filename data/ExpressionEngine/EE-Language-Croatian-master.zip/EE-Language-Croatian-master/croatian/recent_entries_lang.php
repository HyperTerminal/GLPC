<?php
$lang = array(


'recent_entries' => 
'Zadnje dodani sadržaji',

'added_on' => 
'Dodan',

'more_entries' => 
'Svi sadržaji',

'no_entries' => 
'Trenutno nema zadnje dodadnih sadržaja',

'translate' => 
'Osvježi',

''=>''
);

// End of File