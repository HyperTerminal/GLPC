<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang = array(


''=>''
);

/* End of file lang.css.php */
/* Location: ./system/expressionengine/language/english/lang.css.php */