<?php
$lang = array(


'msm_product_name' => 
'Upravljanje sa više sajtova',

'msm_version' => 
'Verzija: ',

'msm_build_number' => 
'Datum: ',

'sites_administration' => 
'Administracija sajtova',

'site_management' => 
'Upravljanje sajtovima',

'site_id' => 
'ID sajta',

'site_name' => 
'Kratak naziv sajta',

'site_label' => 
'Naslov Sajta',

'create_new_site' => 
'Napravi novi sajt',

'edit_site' => 
'Uredi sajt',

'site_description' => 
'Opis sajta',

'site_administration_set' => 
'Set administracija',

'site_mailinglists_set' => 
'Set mailing lista',

'site_members_set' => 
'Set korisnika',

'site_templates_set' => 
'Set predložaka',

'site_channels_set' => 
'Set webloga',

'no_site_name' => 
'Nema naziva sajta',

'no_site_label' => 
'Nema naslova sajta',

'site_name_taken' => 
'Naziv sajta je zauzet',

'new_set_missing_name' => 
'Nedostaje naziv za jedan od vaših novih setova.',

'site_created' => 
'Sajt napravljen',

'site_updated' => 
'Sajt osvježen',

'unable_to_locate_specialty' => 
'Nemoguće pronaći posebne predloške.  Provjerite da li ste uplodali sve jezične dokumente.',

'delete_site' => 
'Izbriši sajt',

'delete_site_confirmation' => 
'Jeste li sigurni da želite trajno izbrisati ovaj sajt?',

'site_deleted' => 
'Sajt izbrisan',

'set_management' => 
'Upravljanje setovima',

'new_set' => 
'Novi set',

'edit_set' => 
'Uredi set',

'create_new_set' => 
'Napravi novi set',

'set_created' => 
'Set napravljen',

'set_updated' => 
'Set osvježen',

'delete_set' => 
'Izbriši set',

'delete_set_confirmation' => 
'Jeste li sigurni da želite trajno izbrisati ovaj set?',

'set_deleted' => 
'Set izbrisan',

'site_set_id' => 
'ID seta',

'site_set_name' => 
'Naziv seta',

'site_set_type' => 
'Vrsta seta',

'site_set_name_taken' => 
'Naziv seta zauzet',

'move_data' => 
'Premjesti podatke',

'do_nothing' => 
'Nemoj napraviti ništa',

'move_options' => 
'Postavke premještanja',

'move_channel_move_data' => 
'Premjesti podatke webloga i weblog sadržaje',

'duplicate_channel_no_data' => 
'Dupliciraj weblog, Nemoj duplicirati weblog sadržaje',

'duplicate_channel_all_data' => 
'Dupliciraj weblog, Dupliciraj weblog sadržaje',

'move_template_group' => 
'Premjesti grupu predložaka',

'duplicate_template_group' => 
'Dupliciraj grupu predložaka',

'move_global_variables' => 
'Premjesti globalne varijable',

'duplicate_global_variables' => 
'Dupliciraj globalne varijable',

'move_upload_destination' => 
'Premjesti odredište za upload',

'duplicate_upload_destination' => 
'Dupliciraj odredište za upload',

'choose_site' => 
'Odaberite sajt na koji se želite prebaciti',

'switch_site' => 
'Prebaci se na sajt',

'timeout_warning' => 
'Dupliciranje velike količine podataka može biti težak proces i može uzrokovati da akcija dostigne ograničenje servera za izvršenje skripte i memorije, te gubitak podataka.<br /><br />Uvijek napravite backup baze podataka prije izvršavanja dupliciranja, a ukoliko dođe do problema, provjerite sa svojim hostom da li je moguće povećati dopuštenja servera za izvršenje ove akcije.',

'translate' => 
'Update',

''=>''
);

// End of File