<?php
$lang = array(


'entry_controls_title' => 
'Upravljanje sadr&#382;ajem',

'entry_controls_invalid_id' => 
'ID sadr&#382;aja koji ste upisali nije va&#382;eći.',

'entry_controls_not_found' => 
'Tra&#382;eni sadržaj nije mogu&#263;e prona&#263;i.',

'site_admin' => 
'Upravljanje web stranicom',

'content_mgmt' => 
'Upravljanje sadr&#382;ajem',

'this_entry_has' => 
'Ovaj unos ima',

'entry_view_count' => 
'Brojač pogleda sadr&#382;aja',

'edit_this_entry' => 
'Editiraj ovaj sadr&#382;aj',

'manage_entry_comments' => 
'Upravljaj komentarima za ovaj sadr&#382;',

'delete_entry' => 
'Izbri&#353;i ovaj sadr&#382;aj',

'publish_entry' => 
'Objavi novi sadr&#382;aj',

'edit_entries' => 
'Editiraj postoje&#263;e sadr&#382;aje',

'control_panel' => 
'Admin po&#269;etna stranica',

'system_prefs' => 
'Postavke sistema',

'reload' => 
'Osvje&#382;i',

'to_see_updates' => 
'stranicu za promjene',

'manage_templates' => 
'Predlo&#353;ci',

'manage_members' => 
'Korisnici',

'categories' => 
'Kategorije',

'channels' => 
'Kanali',

'fields' => 
'Dodatna polja',

'logout' => 
'Kraj rada',

'enabled' => 
'Omogu&#263;eno',

'disabled' => 
'Onemogu&#263;eno',

'ml_views' => 
'pogleda',

'track_views_info' => 
'Pra&#263;enje broja pogleda sadr+&#382;ja zahtjeva kori&#353;tenje track_views weblog sadr&#382;aj parametra.',

'jquery' => 
'jQuery',

'jquery_ui_core' => 
'jQuery UI: Core',

'jquery_ui_dialog' => 
'jQuery UI: Dialog',

'jquery_fx_core' => 
'jQuery Effects: Core',

'jquery_fx_clip' => 
'jQuery Effects: Clip',

'fancybox' => 
'Fancybox',

'jquery_dialog_css' => 
'jQuery Dialog CSS',

'assets_url' => 
'Assets URL',

'assets_url_info' => 
'Ako premjestite missing_link/assets mapu, ovaj URL treba biti odre&#273;en. Ina&#269;e mo&#382;e ostati prazan.',

'keyboard_shortcuts' => 
'Pre&#269;aci na tipkovnici',

'shortcuts_info' => 
'Trenutni pre&#269;aci uklju&#269;uju ctrl+g (or alt+g) za odabir na Missing Link izborniku i ctrl+e (or alt+e) za ure&#273;ivanje trenutnog sadr&#382;aja.',

'translate' => 
'Osvježi',

''=>''
);

// End of File