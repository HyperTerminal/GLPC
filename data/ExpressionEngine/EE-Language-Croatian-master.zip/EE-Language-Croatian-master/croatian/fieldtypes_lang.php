<?php
$lang = array(


'add_file' => 
'Dodaj',

'remove_file' => 
'Obriši',

'directory_no_access' => 
'Nemate pristup mapi označenoj za ovo polje',

'directory' => 
'Mapa',

'translate' => 
'Update',

''=>''
);

// End of File