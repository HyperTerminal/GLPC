<?php
$lang = array(


'eeof_example' => 
'Primjer Taga!',

'translate' => 
'Update',

''=>''
);

// End of File