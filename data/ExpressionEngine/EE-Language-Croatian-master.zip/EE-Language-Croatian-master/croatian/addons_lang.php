<?php
$lang = array(


'addons' => 
'Dodaci',

'accessories' => 
'Pomagala',

'modules' => 
'Moduli',

'extensions' => 
'Ekstenzije',

'plugins' => 
'Pluginovi',

'accessory' => 
'Pomagalo',

'module' => 
'Modul',

'extension' => 
'Ekstenzija',

'addons_accessories' => 
'Pomagala',

'addons_modules' => 
'Moduli',

'addons_plugins' => 
'Pluginovi',

'addons_extensions' => 
'Ekstenzije',

'addons_fieldtypes' => 
'Vrste polja',

'accessory_name' => 
'Naziv pomgala',

'fieldtype_name' => 
'Naziv vrste polja',

'install' => 
'Instaliraj',

'uninstall' => 
'Deinstaliraj',

'installed' => 
'Instaliran',

'not_installed' => 
'Nije instaliran',

'uninstalled' => 
'Deinstaliran',

'remove' => 
'Ukloni',

'preferences_updated' => 
'Postavke osvježene',

'extension_enabled' => 
'Ekstenzija omogućena',

'extension_disabled' => 
'Ekstenzija onemogućena',

'extensions_enabled' => 
'Ekstenzije omogućene',

'extensions_disabled' => 
'Ekstenzije onemogućene',

'delete_fieldtype_confirm' => 
'Jeste li sigurni da želite ukolniti ovu vrstu polja?',

'delete_fieldtype' => 
'Ukloni vrstu polja',

'data_will_be_lost' => 
'Svi podaci povezani s ovom vrstom polja, uključujući sve povezane podatke IZLAZA, bit će nepovratno izbrisani!',

'global_settings_saved' => 
'Postavke spremljene',

'package_settings' => 
'Postavke paketa',

'component' => 
'Komponenta',

'current_status' => 
'Trenutni status',

'available_to_member_groups' => 
'Dostupno grupama korisnika',

'specific_page' => 
'Neka stranica po vašem izboru?',

'description' => 
'Opis',

'version' => 
'Verzija',

'status' => 
'Status',

'fieldtype' => 
'Vrsta polja',

'edit_accessory_preferences' => 
'Uredi postavke pomagala',

'member_group_assignment' => 
'Pridružena grupa korisnika',

'page_assignment' => 
'Pridružene stranice',

'none' => 
'Nijedan',

'and_more' => 
'i %x još...',

'plugins_not_available' => 
'Plugin feed onemogućen u beta verziji.',

'no_extension_id' => 
'Nema zadanih ekstenzija',

'translate' => 
'Update',

''=>''
);

// End of File