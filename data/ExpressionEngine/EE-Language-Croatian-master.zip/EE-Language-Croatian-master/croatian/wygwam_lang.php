<?php
$lang = array(


'wygwam_tbconf_label' => 
'Postavke trake sa alatima',

'wygwam_tbconf_desc' => 
'Odaberite grupe alata tako da ih povučete sa dna spremnika u sample traku sa alatima. Tada uključite gumbe koji bi trebali biti vidljivi tako da kliknete na njih.',

'wygwam_license_label' => 
'Serijski broj',

'wygwam_convert_label' => 
'Izmjeni prethodne sadržaje?',

'wygwam_convert_desc' => 
'Wygwam može izmijeniti polja vaših prethodnih sadržaja u HTML.',

'wygwam_toolbar' => 
'Postavljanje trake sa alatima',

'wygwam_upload_dir' => 
'Direktorij za upload',

'wygwam_advanced' => 
'Napredne postavke',

'translate' => 
'Osvježi',

''=>''
);

// End of File