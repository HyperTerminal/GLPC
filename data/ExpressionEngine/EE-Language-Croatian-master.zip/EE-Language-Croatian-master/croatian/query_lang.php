<?php
$lang = array(


'query_module_name' => 
'Upit',

'query_module_description' => 
'Modul SQL upita za predloške',

'translate' => 
'Update',

''=>''
);

// End of File