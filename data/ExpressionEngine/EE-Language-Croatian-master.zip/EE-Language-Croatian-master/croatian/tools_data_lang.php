<?php
$lang = array(


'sql_info' => 
'SQL info',

'sql_utilities' => 
'SQL alati',

'database_type' => 
'Vrsta baze podataka',

'sql_version' => 
'Verzija baze podataka',

'database_size' => 
'Veličina baze podataka',

'database_uptime' => 
'Uptime baze podataka',

'total_queries' => 
'Ukupni serverski upiti od pokretanja',

'sql_status' => 
'Status info',

'sql_system_vars' => 
'Sistemske varijable',

'sql_processlist' => 
'Popis procesa',

'sql_query_form' => 
'Obrazac za upite u bazi podataka',

'query_result' => 
'Razultat upita',

'query' => 
'SQL upit',

'total_results' => 
'Ukupno rezultata: %x',

'total_affected_rows' => 
'Ukupno izmijenjenih redova: ',

'browse' => 
'Pregledaj',

'tables' => 
'tablice',

'table_name' => 
'Naziv tablice',

'records' => 
'Zapisi tablice',

'size' => 
'Veličina',

'type' => 
'Vrsta',

'analyze' => 
'Alnaliziraj tablice',

'optimize' => 
'Optimiziraj SQL tablice',

'repair' => 
'Popravi SQL tablice',

'optimize_table' => 
'Optimiziraj odabrane tablice',

'repair_table' => 
'Popravi odabrane tablice',

'no_buttons_selected' => 
'Morate odabrati tablice u kojima želite izvršiti ovu akciju',

'sql_view_database' => 
'Upravljaj tablicama baze podataka',

'sql_no_result' => 
'Upit koji ste poslali nije donio rezultata',

'sql_not_allowed' => 
'Žao nam je, to nije jedna od dopuštenih vrsta upita.',

'sql_query_instructions' => 
'Koristite ovaj obrazac za slanje SQL upita',

'sql_query_debug' => 
'Omogući MySQL prikaz grešaka',

'sql_good_query' => 
'Vaš upit je bio uspješan',

'cache_deleted' => 
'Izbrisani su dokumenti pohrana',

'site_preferences' => 
'Postavke sajta',

'channel_entry_title' => 
'Naslovi sadržaja',

'channel_fields' => 
'Polja sadržaja',

'templates' => 
'U SVIM prdlošcima',

'template_groups' => 
'Grupe predložaka',

'rows_replaced' => 
'Broj zapisa u bazi podataka u kojima je izvršena zamjena:',

'choose_below' => 
'(Odaberite iz navedenog)',

'if_replacing_templates' => 
'Ako mjenjate unutar predložaka, sinkronizirajte s bazom podataka prvo, ili',

'permanent_data_loss' => 
'ćete zauvijek izgubiti podatke',

'recalculate' => 
'Prebroji statistike',

'do_recount' => 
'Izvrši prebrojavanje',

'source' => 
'Izvor',

'recount_info' => 
'Donji linkovi vam omogućavaju osvježavanje raznih statistika, npr. koliko je sadržaja koji korisnik unio.',

'members' => 
'Korisnici',

'channel_titles' => 
'Weblog sadržaji',

'site_statistics' => 
'Statistike stranica',

'forums' => 
'Forumi',

'forum_topics' => 
'Teme Fouma',

'recount_completed' => 
'Prebrojavanje završeno',

'recount_prefs' => 
'Postavke prebrojavanja',

'translate' => 
'Update',

''=>''
);

// End of File