<?php
$lang = array(


'metaweblog_api_module_name' => 
'Metaweblog API',

'metaweblog_api_module_description' => 
'Metaweblog API Modul',

'metaweblog_api_home' => 
'CMS Admin',

'api_urls' => 
'Prikaži URL-ove za MetaWeblog API',

'invalid_access' => 
'Neispravan pristup',

'no_channels_found' => 
'Nema pronađenih weblogova za ovog korisnika.',

'invalid_channel' => 
'Pogrešan odabir Webloga',

'invalid_categories' => 
'Pogrešan odabir kategorije',

'no_entries_found' => 
'Nema pronađenih postova',

'no_entry_found' => 
'Post nije pronađen u bazi podataka',

'unauthorized_action' => 
'Nije vam dozvoljeno izvođenje ovog koraka.',

'entry_uneditable' => 
'Nije vam dozvoljeno editirati ovaj post. Molimo provjerite dozvole korisničkih grupa.',

'no_metaweblog_configs' => 
'Trenutno nema MetaWeblog API postavki',

'metaweblog_configurations' => 
'MetaWeblog API postavke',

'metaweblog_config_name' => 
'Ime',

'metaweblog_config_url' => 
'URL',

'metaweblog_delete_confirm' => 
'Izbriši MetaWeblog API postavke',

'metaweblog_deleted' => 
'MetaWeblog API postavka izbrisana',

'metaweblogs_deleted' => 
'MetaWeblog API postavke izbrisane',

'metaweblog_delete_question' => 
'Jeste li sigurni da želite izbrisati označene MetaWeblog API postavke?',

'delete' => 
'Izbriši',

'new_config' => 
'Nova postavka',

'modify_config' => 
'Izmijeni postavku',

'configuration_options' => 
'Opcije postavke',

'metaweblog_pref_name' => 
'Naziv postavke',

'metaweblog_parse_type' => 
'Postavke formatiranja teksta',

'metaweblog_parse_type_subtext' => 
'Postavljanjem na DA, sadržaj posta će biti prikazan na web stranici sa cjelokupnim pMcodom i direktorijima dokumenata.',

'yes' => 
'Da',

'no' => 
'Ne',

'none' => 
'Nijedan - Nijedno',

'metaweblog_field_group' => 
'Weblog Grupa polja',

'metaweblog_excerpt_field' => 
'Polje izvatka',

'metaweblog_content_field' => 
'Polje sadržaja',

'metaweblog_more_field' => 
'Polje za dodatno',

'metaweblog_keywords_field' => 
'Polje ključnih riječi',

'metaweblog_mising_fields' => 
'Polje je ostavljeno prazno',

'configuration_created' => 
'Postavka napravljena',

'configuration_updated' => 
'Postavka osvježena',

'metaweblog_create_new' => 
'Napravi novu postavku',

'unable_to_upload' => 
'Nemoguće napraviti upload dokumenta',

'invalid_file_content' => 
'Dokument koji pokušavate uplodati ima neispravan MIME type',

'metaweblog_upload_dir' => 
'Upload direktorij za upload dokumenata',

'metaweblog_upload_dir_subtext' => 
'Relativno mali broj weblog editora dozvoljava ovu opciju i možda nećete ni Vi dozvolitii upload putem API, pa će postavka na  &#39;Nijedan-nijedno&#39; onemogućiti upload dokumenata putem weblog editora.',

'metaweblog_entry_status' => 
'Status posta',

'do_not_set_status' => 
'Ne postavljaj status (Korisnik će odlučiti)',

'auto_br' => 
'Auto &lt;br /&gt;',

'xhtml' => 
'XHTML',

'translate' => 
'Osvježi',

''=>''
);

// End of File