<?php
$lang = array(


'pages_module_name' => 
'Stranice',

'pages_module_description' => 
'Koristi Sadržaje za izradu statičnih stranica',

'pages_homepage' => 
'Stranice Početna',

'page' => 
'Stranica',

'pages_uri' => 
'URI stranica',

'no_pages' => 
'Trenutno nema stranica',

'create_page' => 
'Napravi novu stranicu',

'page_name' => 
'Naziv stranice',

'edit_page' => 
'Uredi stranicu',

'view_page' => 
'Vidi stranicu',

'page_settings' => 
'Postavke stranice',

'none' => 
'Nijedan',

'template' => 
'Predložak',

'parent_page' => 
'Nadređena stranica',

'channel_entry' => 
'Weblog post',

'choose_entry' => 
'Odaberi post',

'pages_delete_confirm' => 
'Izbriši stranice',

'pages_delete_question' => 
'Jeste li sigurni da želite izbrisati odabrane URI(ove) stranice?<br /><em>Napomena: Brisanje stranice briše samo URL. Post se ne briše.</em>',

'page_deleted' => 
'Stranica izbrisana',

'pages_deleted' => 
'Stranice izbrisane',

'create_entry' => 
'Napravi post',

'choose_template' => 
'Odaberi predložak za prikaz stranice',

'invalid_page_name' => 
'Poslan neispravan naziv za stranicu',

'invalid_template' => 
'Morate odabrati važeći predložak da bi se ova stranica prikazala.',

'page_created' => 
'Stranica napravljena',

'page_updated' => 
'Stranica osvježena',

'invalid_page_uri' => 
'Neispravan URI stranice',

'invalid_page_num_segs' => 
'Napravili ste više od dozvoljenog broja URI segmenata u URLu',

'pages_configuration' => 
'Postavke modula',

'preference_name' => 
'Naziv postavke',

'preference_value' => 
'Vrijednost postavke',

'default_template' => 
'Zadani predložak',

'default_for_page_creation' => 
'Zadani weblog za karticu \'Napravi novu stranicu\' ',

'no_default' => 
'Nije zadano',

'configuration_updated' => 
'Postavka osvježena',

'duplicate_page_uri' => 
'Dupli URI stranice',

'pages_display_on_homepage' => 
'Prikaz URIa na početnoj stranici modula',

'nested' => 
'Ugrađeno',

'not_nested' => 
'Nije ugrađeno',

'preference' => 
'Odrednica',

'setting' => 
'Postavka',

'translate' => 
'Update',

''=>''
);

// End of File