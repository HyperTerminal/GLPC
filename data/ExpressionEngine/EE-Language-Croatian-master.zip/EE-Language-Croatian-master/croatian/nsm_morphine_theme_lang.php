<?php
$lang = array(


'nsm_morphine_theme' => 
'NSM Morphine tema',

'nsm_morphine_theme_module_name' => 
'NSM Morphine tema',

'nsm_morphine_theme_module_description' => 
'Testiranje elemenata teme',

'index_page_title' => 
'NSM Morphine testovi izgleda',

'index_nav_title' => 
'Upravljanje',

'alerts_page_title' => 
'Obavijesti',

'alerts_nav_title' => 
'Obavijesti',

'tables_page_title' => 
'Tablice',

'tables_nav_title' => 
'Tablice',

'buttons_page_title' => 
'Gumbi &amp; Ikone',

'buttons_nav_title' => 
'Gumbi &amp; Ikone',

'translate' => 
'Osvježi',

''=>''
);

// End of File