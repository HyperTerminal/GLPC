<?php
$lang = array(


'license_key' => 
'Serijski broj',

'max_rows' => 
'Maksimalno redaka',

'matrix_configuration' => 
'Postavke matrix polja',

'col_type' => 
'Vrsta kućice',

'col_label' => 
'Naslov stupca',

'col_name' => 
'Naziv stupca',

'col_instructions' => 
'Upute za stupac',

'col_width' => 
'Širina stupca',

'col_required' => 
'Da li je stupac obavezan?',

'col_search' => 
'Da li se stupac može pretraživati?',

'col_settings' => 
'Opcije vrste kućice',

'add_column' => 
'Dodaj stupac',

'remove_column' => 
'Ukloni stupac',

'maxl' => 
'Max&nbsp;duljina',

'multiline' => 
'Više redaka?',

'options' => 
'Opcije',

'add_row' => 
'Dodaj red',

'add_row_above' => 
'Dodaj red iznad',

'add_row_below' => 
'Dodaj red ispod',

'remove_row' => 
'Obriši red',

'add_image' => 
'Dodaj sliku',

'translate' => 
'Osvježi',

''=>''
);

// End of File