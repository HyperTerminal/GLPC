<?php
$lang = array(


'channel_module_name' => 
'Stranica',

'channel_module_description' => 
'Modula Stranica',

'channel_no_preview_template' => 
'Predložak za pregled nije određen u vašem tagu',

'channel_must_be_logged_in' => 
'Morate biti registrirani član da biste izvršili ovu akciju.',

'channel_not_specified' => 
'Morate odrediti weblog kako biste koristili ovaj obrazac.',

'channel_no_action_found' => 
'Nemoguće učitati potrebne podatke za kreiranje obrasca za post',

'translate' => 
'Update',

''=>''
);

// End of File