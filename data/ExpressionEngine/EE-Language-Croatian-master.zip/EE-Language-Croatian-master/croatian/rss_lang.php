<?php
$lang = array(


'rss_module_name' => 
'RSS',

'rss_module_description' => 
'Modul za generiranje RSS stranica',

'rss_invalid_channel' => 
'Weblog naveden u vašem RSS feedu ne postoji.',

'translate' => 
'Osvježi',

''=>''
);

// End of File