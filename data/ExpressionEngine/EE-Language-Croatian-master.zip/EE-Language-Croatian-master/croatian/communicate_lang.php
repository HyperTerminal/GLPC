<?php
$lang = array(


'your_name' => 
'Vaše ime',

'your_email' => 
'Vaš e-mail',

'recipient' => 
'Primatelj',

'cc' => 
'CC',

'bcc' => 
'BCC',

'recipient_group' => 
'Pošalji grupama korisnika',

'manual_recipients_ignored' => 
'Polje primatelja iznad će biti ignorirano',

'send_to_mailinglist' => 
'Pošalji mailing listama',

'honor_email_pref' => 
'Pošalji samo korisnicima koji su odabrali primanje obavijesti',

'separate_emails_with_comma' => 
'Odjeli više e-mail adresa zarezom',

'no_email_matching_criteria' => 
'Nema adresa koje odgovaraju odabranim kriterijima',

'not_allowed_to_email_members' => 
'Nije vam dozvoljeno slanje e-mailova korisnicima',

'not_allowed_to_email_member_groups' => 
'Nije vam dozvoljeno slanje e-mailova korisničkim grupama',

'not_allowed_to_email_mailinglist' => 
'Nije vam dozvoljeno slanje e-mailova mailing listi',

'not_allowed_to_email_cache' => 
'Nije vam dozvoljeno pregledavanje pohranjenih e-mailova.',

'subject' => 
'Predmet',

'message' => 
'Poruka',

'plaintext_alt' => 
'Čisti tekst opcija (nije obavezno, samo HTML email-ovi, ne koristiti gumbe za oblikovanje teksta - bold, italic itd.)',

'send_an_email' => 
'Pošalji e-mail',

'sending_email' => 
'Slanje e-maila',

'batchmode_ready_to_begin' => 
'Slanje e-mailova će početi za 5 sekundi',

'batchmode_warning' => 
'Ne dirajte preglednik dok slanje nije završeno!',

'problem_with_id' => 
'Došlo je problema sa ID brojem potrebnim za slanje emailova',

'cache_data_missing' => 
'Pohranjeni podaci o e-mailovima nisu pronađeni.',

'currently_sending_batch' => 
'Slanje e-mailova %x od %y',

'emails_remaining' => 
'Preostalo e-mailova:',

'email_error' => 
'Greška sa e-mailom',

'send_it' => 
'Pošalji',

'total_emails_sent' => 
'Ukupno poslano e-mailova:',

'plain_text' => 
'Čisti Tekst',

'html' => 
'HTML',

'mail_format' => 
'Formatiranje e-maila',

'text_formatting' => 
'Formatiranje teksta',

'none' => 
'None',

'auto_br' => 
'Auto &lt;br /&gt;',

'xhtml' => 
'XHTML',

'wordwrap' => 
'Omotavanje riječi',

'priority' => 
'Prioritet',

'attachment' => 
'Attachment',

'attachment_problem' => 
'Došlo je do problema sa vašim Attachmentom.',

'attachment_unavailable' => 
'Da biste poslali Attachmente, potrebno je definirati polje za upload.',

'attachment_warning' => 
'ExpressionEngine <strong>ne sprema</strong> attachmente , potrebno ih je spremiti lokalno.',

'chars' => 
'znakova',

'highest' => 
'Najveći',

'high' => 
'Visok',

'normal' => 
'Normalan',

'low' => 
'Nizak',

'lowest' => 
'Najniži',

'empty_form_fields' => 
'Ostavili ste neka polja prazna.',

'email_sent_message' => 
'Vaš e-mail je poslan',

'all_email_sent_message' => 
'Svi e-mailovi su poslani',

'email_success' => 
'E-mail poslan',

'view_email_cache' => 
'Vidi zadnji poslani e-mail',

'previous_email' => 
'Zadnji poslani e-mail',

'email_title' => 
'Naslov e-maila',

'email_date' => 
'Poslano dana',

'total_recipients' => 
'Ukupno primatelja',

'resend' => 
'Pošalji ponovo',

'view' => 
'Pregledaj',

'no_cached_email' => 
'Nema pohranjenih mailova',

'delete_emails' => 
'zbriši e-mail',

'delete_confirm' => 
'Potvrda o brisanju e-maila',

'delete_question' => 
'Jeste li sigurni da želite izbrisati označene e-mailove?',

'bad_cache_ids' => 
'Nema e-mailova koji odgovaraju odabranim kriterijima',

'email_deleted' => 
'E-mail je izbrisan',

'mailinglist_unsubscribe' => 
'Ako želite izbrisati svoju e-mail adresu sa ove mailing liste, kliknite ovdje:',

'mailinglist_unsubscribe_all' => 
'Ako želite izbrisati svoju e-mail adresu sa svih mailing lista, kliknite ovdje:',

'complete' => 
'Završeno',

'incomplete' => 
'Nije završeno',

'finish_sending' => 
'Završi slanje',

'on' => 
'Uključeno',

'off' => 
'Isključeno',

'translate' => 
'Update',

''=>''
);

// End of File