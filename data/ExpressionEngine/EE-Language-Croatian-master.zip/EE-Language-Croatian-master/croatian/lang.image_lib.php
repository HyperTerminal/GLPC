<?php
$lang = array(


'imglib_gd_required_for_props' => 
'Vaš server treba podržavati GD image library da bi mogao prepoznati postavke slike',

'imglib_unsupported_imagecreate' => 
'Vaš server ne podržava GD funkciju potrebnu za procesiranje ovog tipa slike.',

'imglib_gif_not_supported' => 
'GIF slike često nisu podržane zbog licencnih zabrana. Umjesto njih možete koristiti JPG ili PNG.',

'imglib_jpg_not_supported' => 
'JPG slike nisu podržane',

'imglib_png_not_supported' => 
'PNG slike nisu podržane',

'imglib_jpg_or_png_required' => 
'Protokol za promjenu veličine slike označen u vašim postavkama radi samo sa JPEG ili PNG vrstom slika.',

'imglib_copy_error' => 
'Došlo je do greške kod pokušaja zamjene dokumenta. Provjerite da li je u direktorij dokumenata omogućen zapis.',

'imglib_rotate_unsupported' => 
'Rotacija slike nije podržana od vašeg servera.',

'imglib_libpath_invalid' => 
'Staza do slika nije ispravna. Postavite ispravnu stazu u postavkama za slike.',

'imglib_image_process_failed' => 
'Procesiranje slike neuspješno. Provjerite da li vaš server podržava odabrani protokol i da je staza do slika ispravna.',

'imglib_rotation_angle_required' => 
'Potrebna je vrijednost kuta rotacije da bi se izvršila rotacija slike.',

'imglib_writing_failed_gif' => 
'GIF slika',

'imglib_invalid_path' => 
'Staza do slike nije ispravna',

'imglib_copy_failed' => 
'Proces kopiranja slike neuspješan.',

'translate' => 
'Osvježi',

''=>''
);

// End of File