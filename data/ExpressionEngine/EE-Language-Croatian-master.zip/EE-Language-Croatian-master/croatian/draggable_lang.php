<?php
$lang = array(


'draggable_categories' => 
'Omogući povlačenje u kategorijama',

'draggable_custom_fields' => 
'Omogući povlačenje u dodatnim poljima',

'draggable_statuses' => 
'Omogući povlačenje u statusima',

'draggable_display_tab' => 
'Prikaži karticu sa alatima',

'draggable_hide_order' => 
'Sakrij kolonu sa poretkom',

'draggable_sorting_enabled' => 
'Drag and Drop sortiranje omogućeno',

'draggable_instructions' => 
'<p style="width:300px;">Kako biste promijenili redoslijed redaka na ovoj stranici, pozicionirajte kursor na redak (ali ne na link unutar retka), i kursor će se promijeniti u "move" kursor. Kliknite i povucite redak na njegovu novu poziciju u tablici, a novi poredak će biti automatski spremljen.</p>',

'yes' => 
'Da',

'no' => 
'Ne',

'always' => 
'Uvijek',

'never' => 
'Nikad',

'draggable_pages' => 
'Na stranicama gdje je moguće povlačenje',

'translate' => 
'Osvježi',

''=>''
);

// End of File