<?php
$lang = array(


'low_reorder_module_name' => 
'Promjena redoslijeda postova',

'low_reorder_module_description' => 
'Ovdje promijeni redoslijed postova',

'field' => 
'Polje',

'reorder' => 
'Promijeni redoslijed',

'settings' => 
'Postavke',

'reorder_entries' => 
'Promijeni redoslijed postova',

'edit_settings' => 
'Uredi postavke',

'new_order_saved' => 
'Novi redoslijed spremljen',

'value' => 
'Vrijednost',

'statuses' => 
'Statusi',

'categories' => 
'Kategorije',

'show_all' => 
'Prikaži postove iz svih kategorija',

'show_one' => 
'Prikaži postove samo jedne kategorije',

'show_some' => 
'Filtriraj postove po kategoriji&hellip;',

'uncategorized' => 
'Postovi koji nisu ni u jednoj kategoriji',

'show_expired' => 
'Prikaži istekle',

'show_expired_entries' => 
'Prikaži istekle postove',

'show_future' => 
'Prikaži buduće',

'show_future_entries' => 
'Prikaži buduće postove',

'settings_saved' => 
'Postavka spremljena',

'select_category' => 
'Odaberi kategoriju',

'clear_caching' => 
'Izbriši pohranjeno',

'error' => 
'Greška',

'invalid_request' => 
'Neispravan zahtjev',

'channel_not_found' => 
'Weblog nije pronađen',

'field_not_found' => 
'Polje nije pronađeno',

'no_reorder_fields' => 
'Ne postoje polja kojima se može mijenjati raspored',

'no_entries_found' => 
'Nema postova',

'translate' => 
'Osvježi',

''=>''
);

// End of File