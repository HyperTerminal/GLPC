<?php
$lang = array(


'imglib_gd_required_for_props' => 
'Din server måste stödja GD-bildbiblioteket för att bestämma bildegenskaper',

'imglib_unsupported_imagecreate' => 
'Din server verkar inte stödja den GD-funktion som krävs för att behandla den här sortens bild.',

'imglib_gif_not_supported' => 
'GIF-bilder stöds oftast inte på grund av licensrestriktioner. Du måste kanske använda JPG- eller PNG-bilder i stället.',

'imglib_jpg_not_supported' => 
'JPG-bilder stöds inte',

'imglib_png_not_supported' => 
'PNG-bilder stöds inte',

'imglib_jpg_or_png_required' => 
'Det storleksändringsprotokoll som anges i dina inställningar fungerar endast med JPEG- eller PNG-bilder.',

'imglib_copy_error' => 
'Ett fel inträffade när bilden skulle ersättas. Kontrollera att mappen är skrivbar.',

'imglib_rotate_unsupported' => 
'Din server verkar inte stödja bildrotering.',

'imglib_libpath_invalid' => 
'Sökvägen till bildbiblioteket är inte korrekt. Ange korrekt sökväg i bildinställningarna.',

'imglib_image_process_failed' => 
'Bildbearbetningen misslyckades. Kontrollera att din server stödjer angivet protokoll och att sökvägen till ditt bildbibliotek är korrekt.',

'imglib_rotation_angle_required' => 
'Det krävs en roteringsvinkel för att rotera bilden.',

'imglib_writing_failed_gif' => 
'GIF-bild',

'imglib_invalid_path' => 
'Sökvägen till bilden är inte korrekt',

'imglib_copy_failed' => 
'Bildkopiering misslyckades.',

'translate' => 
'Uppdatera',

''=>''
);

// End of File