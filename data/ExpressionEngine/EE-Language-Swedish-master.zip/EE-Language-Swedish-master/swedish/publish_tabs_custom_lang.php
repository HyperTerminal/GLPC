<?php
$lang = array(


'eeof_example' => 
'Exempeltagg!',

'translate' => 
'Uppdatera',

''=>''
);

// End of File