<?php
$lang = array(


'addons' => 
'Tillägg',

'accessories' => 
'Tillbehör',

'modules' => 
'Moduler',

'extensions' => 
'Extensioner',

'plugins' => 
'Plugins',

'accessory' => 
'Tillbehör',

'module' => 
'Modul',

'extension' => 
'Extension',

'addons_accessories' => 
'Tillbehör',

'addons_modules' => 
'Moduler',

'addons_plugins' => 
'Plugins',

'addons_extensions' => 
'Extensioner',

'addons_fieldtypes' => 
'Fälttyper',

'accessory_name' => 
'Tillbehörsnamn',

'fieldtype_name' => 
'Fälttypsnamn',

'install' => 
'Installera',

'uninstall' => 
'Avinstallera',

'installed' => 
'Installerad',

'not_installed' => 
'Ej installerad',

'uninstalled' => 
'Avinstallerad',

'remove' => 
'Ta bort',

'preferences_updated' => 
'Inställningarna har uppdaterats',

'extension_enabled' => 
'Extensionen har aktiverats',

'extension_disabled' => 
'Extensionen har inaktiverats',

'extensions_enabled' => 
'Extensionerna har aktiverats',

'extensions_disabled' => 
'Extensionerna har inaktiverats',

'delete_fieldtype_confirm' => 
'Vill du verkligen ta bort denna fälttyp?',

'delete_fieldtype' => 
'Ta bort fälttyp',

'data_will_be_lost' => 
'Alla data som är förbundna med denna fälttyp, inklusive alla associerade kanaler, kommer att tas bort permanent!',

'global_settings_saved' => 
'Inställningarna har sparats',

'package_settings' => 
'Paketinställningar',

'component' => 
'Komponent',

'current_status' => 
'Aktuell status',

'available_to_member_groups' => 
'Tillgänglig för medlemsgrupper',

'specific_page' => 
'Särskild sida?',

'description' => 
'Beskrivning',

'version' => 
'Version',

'status' => 
'Status',

'fieldtype' => 
'Fälttyp',

'edit_accessory_preferences' => 
'Ändra inställningar för tillbehör',

'member_group_assignment' => 
'Angivna medlemsgrupper',

'page_assignment' => 
'Angivna sidor',

'none' => 
'Inga',

'and_more' => 
'och %x mer/fler ...',

'plugins_not_available' => 
'Plugin-flöde fungerar ej i betaversionen.',

'no_extension_id' => 
'Ingen extension angiven',

'translate' => 
'Uppdatera',

''=>''
);

// End of File