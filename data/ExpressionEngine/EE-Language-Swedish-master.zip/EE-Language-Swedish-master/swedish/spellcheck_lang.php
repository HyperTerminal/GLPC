<?php
$lang = array(


"spell_check" =>
"Stavningskontroll",

"check_spelling" =>
"Kontrollera stavning",

"save_spellcheck" =>
"Spara ändringar",

"revert_spellcheck" =>
"Återgå till original",

"spell_save_edit" =>
"Spara ändringar",

"spell_edit_word" =>
"Ändra ord",

"unsupported_browser" =>
"Inget stöd för webbläsare",

"no_spelling_errors" =>
"Hittade inga stavfel",

"spellcheck_in_progress" =>
"Kontrollerar...",

"translate" =>
"Update",

''=>''
);
?>