<?php
$lang = array(


"blacklist_module_name" =>
"Svartlista/vitlista",

"blacklist_module_description" =>
"Modul för svart- och vitlista",

"htaccess_written_successfully" =>
"Filen .htaccess har sparats på servern",

"invalid_htaccess_path" =>
"Felaktig sökväg eller ogiltiga filrättigheter för filen .htaccess",

"htaccess_server_path" =>
"Serversökväg till filen .htaccess",

"write_htaccess_file" =>
"Skriva svartlista till filen .htaccess?",

"whitelist" =>
"Vitlista",

"pmachine_whitelist" =>
"Ladda ner vitlista från ExpressionEngine.com",

"whitelist_updated" =>
"Vitlistan har uppdaterats",

"ref_whitelist_irretrievable" =>
"Fel: Ny vitlista kunde inte hämtas.",

"ref_view_whitelist" =>
"Visa vitlista",

"ref_no_whitelist" =>
"Finns för närvarande inga vitlistningar",

"ref_whitelisted" =>
"Vitlistningar",

"ref_no_whitelist_table" =>
"Finns ingen databastabell för vitlista",

"ref_type" =>
"Enhetstyp",

"blacklist" =>
"Svartlista",

"pmachine_blacklist" =>
"Ladda ner svartlista från ExpressionEngine.com",

"requires_license_number" =>
"Kräver att licensnummer finns inskrivet i &quot;Allmän konfiguration&quot;",

"blacklist_updated" =>
"Svartlistan har uppdaterats",

"ref_no_license" =>
"Fel: Inget licensnummer.",

"ref_blacklist_irretrievable" =>
"Fel: Ny svartlista kunde inte hämtas.",

"ref_view_blacklist" =>
"Visa svartlista",

"ref_no_blacklist" =>
"Finns för närvarande inga svartlistningar",

"ref_ip" =>
"IP-address",

"ref_user_agent" =>
"Användarklient",

"ref_url" =>
"Webbadress",

"ref_blacklisted" =>
"Svartlistad",

"ref_no_blacklist_table" =>
"Finns ingen databastabell för vitlista",

"translate" =>
"Update",

''=>''
);
?>