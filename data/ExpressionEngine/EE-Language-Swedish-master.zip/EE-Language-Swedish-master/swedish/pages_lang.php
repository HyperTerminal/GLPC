<?php
$lang = array(


'pages_module_name' => 
'Statiska sidor',

'pages_module_description' => 
'Använder inlägg för att skapa statiska sidor',

'pages_homepage' => 
'Startsida för statiska sidor',

'page' => 
'Statisk sida',

'pages_uri' => 
'URI för statiska sidor',

'no_pages' => 
'Finns inga statiska sidor för närvarande',

'create_page' => 
'Skapa ny statisk sida',

'page_name' => 
'Namn på statisk sida',

'edit_page' => 
'Redigera statisk sida',

'view_page' => 
'Visa statisk sida',

'page_settings' => 
'Inställningar för statiskt sida',

'none' => 
'Ingen/inga',

'template' => 
'Mall',

'parent_page' => 
'Ursprunglig sida',

'channel_entry' => 
'Inlägg',

'choose_entry' => 
'Välj inlägg',

'pages_delete_confirm' => 
'Ta bort statiska sidor',

'pages_delete_question' => 
'Vill du verkligen ta bort markerade statiska sidor? &lt;br /&gt;&lt;em&gt;OBS! När man tar bort en statisk sida, tas bara webbadressen bort. Själva inlägget tas inte bort.&lt;/em&gt;',

'page_deleted' => 
'Statisk sida borttagen',

'pages_deleted' => 
'Statiska sidor borttagna',

'create_entry' => 
'Skapa inlägg',

'choose_template' => 
'Välj mall för att visa statisk sida',

'invalid_page_name' => 
'Ogiltigt sidnamn!',

'invalid_template' => 
'Välj en giltig mall för att visa denna statiska sida.',

'page_created' => 
'Statisk sida skapad',

'page_updated' => 
'Statisk sida uppdaterad',

'invalid_page_uri' => 
'Ogiltig URI för statisk sida',

'invalid_page_num_segs' => 
'Du har fler URI-segment i sidans webbadress än vad som är tillåtet',

'pages_configuration' => 
'Modulinställningar',

'preference_name' => 
'Namn',

'preference_value' => 
'Inställning',

'default_template' => 
'Förvald mall',

'default_for_page_creation' => 
'Förvald kanal för fliken &quot;Skapa ny statisk sida&quot;',

'no_default' => 
'Inget förval',

'configuration_updated' => 
'Inställningar uppdaterade',

'duplicate_page_uri' => 
'Duplicera sidans URI',

'pages_display_on_homepage' => 
'Visa URI:er på modulens förstasida',

'nested' => 
'Nästlad(e)',

'not_nested' => 
'Ej nästlad(e)',

'preference' => 
'Inställning',

'setting' => 
'Inställning',

'translate' => 
'Uppdatera',

''=>''
);

// End of File