<?php
$lang = array(


'emoticon_module_name' => 
'Smiley',

'emoticon_module_description' => 
'Smiley-modul',

'emoticon_heading' => 
'Smiley',

'emoticon_glyph' => 
'Symbol',

'emoticon_image' => 
'Bild',

'emoticon_width' => 
'Bredd',

'emoticon_height' => 
'Höjd',

'emoticon_alt' => 
'Alt-tagg',

'translate' => 
'Uppdatera',

''=>''
);

// End of File