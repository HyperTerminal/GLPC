<?php
$lang = array(


"rss_module_name" =>
"RSS nyhetsflöde",

"rss_module_description" =>
"Modul för att skapa RSS-sidor",

"rss_invalid_channel" =>
"Den kanal du angivit i ditt RSS nyhetsflöde finns inte.",

"translate" =>
"Update",

''=>''
);
?>