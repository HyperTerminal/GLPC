<?php
$lang = array(


"ip_to_nation_module_name" =>
"IP till nation",

"ip_to_nation_module_description" =>
"Verktyg för att knyta IP-addresser till land",

"iptonation_missing" =>
"Hittar inte filen &quot;iptonation.php&quot;. Kontrollera att du har laddat upp alla delar som hör till denna modul.",

"countryfile_missing" =>
"Hittar inte filen &quot;country.php&quot; som ska finnas i mappen &quot;config&quot;.",

"ip_search" =>
"Sök IP-adress",

"ip_search_inst" =>
"Ange IP-adress för att fastställa vilket land den hör hemma i.",

"ip_result" =>
"IP-adressen du angav hör hemma i:",

"manage_banlist" =>
"Hantera lista över spärrade länder",

"country" =>
"Land",

"ban_info" =>
"Välj vilka länder du till spärra. När ett land spärras av kan en person med IP-adress från det landet inte skriva kommentarer, skicka returlänkar eller använda formulär för e-postmeddelanden/tipsa-en-kompis. De kommer fortfarande att kunna se din webbplats.",

"ban" =>
"Spärra",

"banlist" =>
"Spärrlista för länder",

"banlist_updated" =>
"Spärrlistan har uppdaterats",

"translate" =>
"Update",

''=>''
);
?>