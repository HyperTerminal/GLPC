<?php
$lang = array(


"email_module_name" =>
"E-post",

"email_module_description" =>
"E-postmodul",

"message_required" =>
"Meddelande är obligatoriskt",

"em_banned_from_email" =>
"Angiven avsändaradress är avstängd.",

"em_banned_recipient" =>
"En eller flera mottagaradresser är avstängda.",

"em_invalid_recipient" =>
"En eller flera mottagaradresser är ogiltiga.",

"em_no_valid_recipients" =>
"Meddelandet har inga giltiga mottagare.",

"em_sender_required" =>
"Det krävs en giltig avsändare",

"em_unauthorized_request" =>
"Du har inte behörighet att göra detta",

"em_limit_exceeded" =>
"Du har överskridigt gränsen för hur många meddelanden som får skickas per dag.",

"em_interval_warning" =>
"Du får skicka ett meddelande högst var %s sekund",

"em_email_sent" =>
"Meddelandet har skickats.",

"translate" =>
"Update",

''=>''
);
?>