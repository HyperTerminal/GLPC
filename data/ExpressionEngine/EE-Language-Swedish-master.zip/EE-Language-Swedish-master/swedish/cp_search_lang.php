<?php
$lang = array(


'design_user_message' => 
'Mall för användarmeddelanden',

'design_system_offline' => 
'Mall för nedkopplat system',

'design_email_notification' => 
'Mall för e-postavisering',

'design_member_profile_templates' => 
'Mall för medlemsprofiler',

'member_register_member' => 
'Registrera medlem',

'member_validation' => 
'Godkännande av medlem',

'member_view_members' => 
'Visa medlemmar',

'member_ip_search' => 
'Sök IP-adress till medlem',

'member_custom_profile_fields' => 
'Egna medlemsfält',

'member_group_manager' => 
'Hantera medlemsgrupper',

'member_config' => 
'Konfiguration av medlemmar',

'member_banning' => 
'Avstängning av medlmemmar',

'member_search' => 
'Sök medlem',

'data_sql_manager' => 
'SQL-hanterare',

'data_search_and_replace' => 
'Sök och ersätt',

'data_recount_stats' => 
'Räkna om statistik',

'data_php_info' => 
'PHP Info',

'data_clear_caching' => 
'Töm cache',

'file_index' => 
'Filhanterare',

'cont_field_group_management' => 
'Hantering av fältgrupper',

'members_member_group_manager' => 
'Hantering av medlemsgrupper',

'cont_category_management' => 
'Hantering av kategorier',

'members_custom_profile_fields' => 
'Egna medlemsprofilfält',

'logs_view_cp_log' => 
'Visa logg för kontrollpanel',

'logs_view_throttle_log' => 
'Visa logg för trafikbegränsning',

'logs_view_search_log' => 
'Visa söklogg',

'logs_view_email_log' => 
'Visa e-postlogg',

'util_member_import' => 
'Medlemsimport',

'util_import_from_mt' => 
'Importera från Moveable Type',

'util_import_from_xml' => 
'Importera från XML',

'util_translation_tool' => 
'Översättningsverktyg',

'plug_index' => 
'Plugins',

'modu_index' => 
'Moduler',

'exte_index' => 
'Extensioner',

'acce_index' => 
'Tillbehör',

'translate' => 
'Uppdatera',

''=>''
);

// End of File