<?php
$lang = array(


'remember_me' => 
'Logga in automatiskt varje gång?',

'no_username' => 
'Användarnamn är obligatoriskt',

'no_password' => 
'Lösenord är obligatoriskt',

'no_email' => 
'Du måste ange din e-postadress.',

'credential_missmatch' => 
'Ogiltigt användarnamn eller lösenord.',

'multi_login_warning' => 
'Någon är redan inloggad på detta konto.',

'return_to_login' => 
'Gå tillbaka till inloggningssidan',

'password_lockout_in_effect' => 
'Du får göra maximalt fyra inloggningsförsök på %x minut(er)',

'unauthorized_request' => 
'Du har inte behörighet att göra detta',

'new_password_request' => 
'Begäran om nytt lösenord',

'session_auto_timeout' => 
'Din session har avslutats på grund av inaktivitet',

'translate' => 
'Uppdatera',

''=>''
);

// End of File