<?php
$lang = array(


"stats_module_name" =>
"Statistik",

"stats_module_description" =>
"Statistikmodul",

"translate" =>
"Update",

''=>''
);
?>