<?php
$lang = array(


"query_module_name" =>
"SQL-fråga",

"query_module_description" =>
"SQL-frågemodul för mallar",

"translate" =>
"Update",

''=>''
);
?>