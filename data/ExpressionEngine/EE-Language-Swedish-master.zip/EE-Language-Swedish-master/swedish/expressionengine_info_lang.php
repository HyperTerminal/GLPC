<?php
$lang = array(


'expressionengine_info' => 
'ExpressionEngine info',

'resources' => 
'Resurser',

'documentation' => 
'Online-dokumentation',

'support_forums' => 
'Supportforum',

'downloads' => 
'Nedladdningar från ExpressionEngine Store',

'support_resources' => 
'Supportresurser',

'version_and_build' => 
'Version och Build',

'error_getting_version' => 
'Kunde inte hämta aktuellt versionsnummer just nu',

'version_info' => 
'Aktuell version av ExpressionEngine är %v Build %b',

'translate' => 
'Uppdatera',

''=>''
);

// End of File