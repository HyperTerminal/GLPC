<?php

$lang = array(

// @todo move Edit lang vars out of publish and into here for the Edit controller

''=>''
);

/* End of file lang.edit.php */
/* Location: ./system/expressionengine/language/english/lang.edit.php */