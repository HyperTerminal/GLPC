<?php
$lang = array(


'content_files' => 
'Filhanterare',

'upload_dir_choose' => 
'Välj uppladdningsmapp',

'file_upload_prefs' => 
'Inställningar för filuppladdning',

'create_new_upload_pref' => 
'Skapa ny uppladdningsmapp',

'file_information' => 
'Filinformation',

'upload' => 
'Ladda upp',

'upload_file' => 
'Ladda upp fil',

'file_upload' => 
'Filuppladdning',

'file_download' => 
'Ladda ner',

'file_tools' => 
'Filverktyg',

'choose_file' => 
'Välj en fil att ta bort',

'confirm_del_file' => 
'Vill du verkligen ta bort denna fil permanent?',

'confirm_del_files' => 
'Vill du verkligen ta bort dessa filer permanent?',

'delete_success' => 
'Borttagning klar',

'delete_fail' => 
'Problem med att ta bort en eller flera filer. Kontrollera nedstående fillista.',

'no_file' => 
'Ingen fil vald',

'file_name' => 
'Filnamn',

'file_size' => 
'Filstorlek',

'file_size_unit' => 
'KB',

'size' => 
'Storlek',

'kind' => 
'Typ',

'where' => 
'Var',

'permissions' => 
'Behörigheter',

'upload_success' => 
'Uppladdning klar',

'no_upload_dirs' => 
'Du har inte definierat några uppladdningsmappar',

'no_uploaded_files' => 
'Finns inga uppladdade filer i denna mapp',

'image_editor' => 
'Bildhanterare',

'download_selected' => 
'Ladda ner valda filer',

'email_files' => 
'Eposta valda filer',

'delete_selected_files' => 
'Ta bort valda filer',

'edit_modes' => 
'Redigera lägen',

'resize' => 
'Ändra storlek',

'crop' => 
'Beskär',

'resize_width' => 
'Bredd',

'resize_height' => 
'Höjd',

'crop_width' => 
'Bredd',

'crop_height' => 
'Höjd',

'crop_x' => 
'X',

'crop_y' => 
'Y',

'rotate' => 
'Rotera',

'rotate_90r' => 
'90&#176; höger',

'rotate_90l' => 
'90&#176; vänster',

'rotate_180' => 
'180&#176',

'rotate_flip_vert' => 
'Rotera vertikalt',

'rotate_flip_hor' => 
'Rotera horisontellt',

'maintain_ratio' => 
'Bibehåll proportioner',

'width_needed' => 
'Bredd och/eller höjd måste anges',

'crop_mode' => 
'Beskär-läge',

'resize_mode' => 
'Ändra storlek-läge',

'rotate_mode' => 
'Rotera-läge',

'apply_changes' => 
'Spara ändringar',

'exit_apply_changes' => 
'Du är på väg att lämna redigeraläget. Spara ändringar först? ',

'processing_image' => 
'Bearbetar bild',

'done' => 
'Avsluta',

'edit_image' => 
'Spara bild',

'image_edit_success' => 
'Bildredigering klar',

'no_edit_selected' => 
'Ingen redigeringsåtgärd vald',

'uploading_file' => 
'Laddar upp fil',

'translate' => 
'Uppdatera',

''=>''
);

// End of File