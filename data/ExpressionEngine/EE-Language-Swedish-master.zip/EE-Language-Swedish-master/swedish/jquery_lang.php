<?php
$lang = array(


"jquery_module_name" =>
"jQuery",

"jquery_module_description" =>
"jQuery-modul",

"missing_jquery_file" =>
"Hittade inte begärda jQuery-fil.",

"translate" =>
"Update",

''=>''
);
?>