<?php
$lang = array(


'module_name' => 
'Namn på modul',

'module_description' => 
'Beskrivning',

'data_will_be_lost' => 
'Alla data knutna till denna modul kommer att tas bort permanent!',

'module_access' => 
'Ändra modul',

'module_no_access' => 
'Du har inte behörighet att komma åt några moduler',

'delete_module' => 
'Avinstallera modul',

'delete_module_confirm' => 
'Vill du verkligen avinstallera följande modul:',

'module_backend' => 
'Kontrollpanel',

'module_version' => 
'Version',

'module_status' => 
'Status',

'module_action' => 
'Åtgärd',

'not_installed' => 
'Ej installerad',

'installed' => 
'Installerad',

'install' => 
'Installera',

'update_modules' => 
'Kör uppdatering av modul',

'updated' => 
'Uppdaterad',

'updated_to_version' => 
'uppdaterad till version',

'all_modules_up_to_date' => 
'Alla moduler är uppdaterade.',

'deinstall' => 
'Ta bort',

'module_can_not_be_found' => 
'Kunde inte hitta de filer som krävs för att installera denna modul',

'module_has_been_installed' => 
'Modul installerad:',

'module_has_been_removed' => 
'Modul avinstallerad:',

'requested_module_not_installed' => 
'Modulen är inte installerad.',

'requested_page_not_found' => 
'Modulen kunde inte hittas.',

'translate' => 
'Uppdatera',

''=>''
);

// End of File