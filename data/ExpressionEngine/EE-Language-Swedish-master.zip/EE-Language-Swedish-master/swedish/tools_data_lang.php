<?php
$lang = array(


'sql_info' => 
'SQL-info',

'sql_utilities' => 
'SQL-verktyg',

'database_type' => 
'Typ av databas',

'sql_version' => 
'Version av databas',

'database_size' => 
'Storlek på databas',

'database_uptime' => 
'Drifttid för databas',

'total_queries' => 
'Antal serveranrop sedan omstart',

'sql_status' => 
'Statusinformation',

'sql_system_vars' => 
'Systemvariabler',

'sql_processlist' => 
'Lista över processer',

'sql_query_form' => 
'Frågeformulär för databas',

'query_result' => 
'Svar på SQL-fråga',

'query' => 
'SQL-fråga',

'total_results' => 
'Slutresultat: %x',

'total_affected_rows' => 
'Antal berörda rader:',

'browse' => 
'Bläddra',

'tables' => 
'tabeller',

'table_name' => 
'Tabellnamn',

'records' => 
'Databasposter',

'size' => 
'Storlek',

'type' => 
'Typ',

'analyze' => 
'Analysera tabeller',

'optimize' => 
'Optimera SQL-tabeller',

'repair' => 
'Reparera SQL-tabeller',

'optimize_table' => 
'Optimera markerade tabeller',

'repair_table' => 
'Reparera markerade tabeller',

'no_buttons_selected' => 
'Du måste markera vilka tabeller du vill utföra denna åtgärd på',

'sql_view_database' => 
'Hantera databastabeller',

'sql_no_result' => 
'SQL-frågan gav inget resultat',

'sql_not_allowed' => 
'Detta är tyvärr inte en tillåten typ av fråga.',

'sql_query_instructions' => 
'Använd detta formulär för att skicka en SQL-fråga',

'sql_query_debug' => 
'Aktivera MySQL-felrapport',

'sql_good_query' => 
'Din SQL-fråga har besvarats',

'cache_deleted' => 
'Cachefil(er) har raderats',

'site_preferences' => 
'Inställningar för webbplats',

'channel_entry_title' => 
'Namn på inlägg',

'channel_fields' => 
'Fält',

'templates' => 
'I samtliga mallar',

'template_groups' => 
'Mallgrupper',

'rows_replaced' => 
'Antal poster där ersättning gjordes:',

'choose_below' => 
'(Välj bland följande)',

'if_replacing_templates' => 
'Om du gör ersättningar i mallar, synkronisera med databasen först, annars',

'permanent_data_loss' => 
'kan data förloras permanent!',

'recalculate' => 
'Räkna om statistik',

'do_recount' => 
'Räkna om nu',

'source' => 
'Källa',

'recount_info' => 
'Nedanstående länkar ger dig möjlighet att uppdatera olika delar av statistiken, t ex hur många inlägg varje medlem har skrivit.',

'members' => 
'Medlemmar',

'channel_titles' => 
'Inlägg',

'site_statistics' => 
'Statistik för webbplatsen',

'forums' => 
'Forum',

'forum_topics' => 
'Forumtrådar',

'recount_completed' => 
'Omräkning utförd',

'recount_prefs' => 
'Inställningar för omräkning',

'translate' => 
'Uppdatera',

''=>''
);

// End of File