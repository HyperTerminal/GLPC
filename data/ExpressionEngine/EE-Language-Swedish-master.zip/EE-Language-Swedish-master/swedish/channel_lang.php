<?php
$lang = array(


"channel_module_name" =>
"Kanal",

"channel_module_description" =>
"Modul för kanaler",

"channel_no_preview_template" =>
"Ingen mall för förhandsgranskning finns angiven i taggen",

"channel_must_be_logged_in" =>
"Du måste vara inloggad som medlem för att kunna göra detta.",

"channel_not_specified" =>
"Du måste ange en kanal för att kunna använda inläggsformuläret.",

"channel_no_action_found" =>
"Kan inte hämta de resurser som krävs för att skapa inläggsformulär",

"translate" =>
"Update",

''=>''
);
?>