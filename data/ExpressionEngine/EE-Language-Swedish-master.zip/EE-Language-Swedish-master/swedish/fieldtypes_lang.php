<?php
$lang = array(


'add_file' => 
'Lägg till fil',

'remove_file' => 
'Ta bort fil',

'directory_no_access' => 
'Du har inte behörighet till angiven mapp för detta fält',

'directory' => 
'Mapp:',

'translate' => 
'Uppdatera',

''=>''
);

// End of File