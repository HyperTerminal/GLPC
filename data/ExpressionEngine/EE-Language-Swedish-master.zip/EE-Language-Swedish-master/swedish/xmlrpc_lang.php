<?php
$lang = array(


'invalid_license' => 
'Ogiltig licens',

'translate' => 
'Uppdatera',

''=>''
);

// End of File