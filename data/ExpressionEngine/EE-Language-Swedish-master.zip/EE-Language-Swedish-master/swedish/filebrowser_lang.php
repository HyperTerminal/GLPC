<?php
$lang = array(


'file_browser' => 
'Filhanterare',

'view' => 
'Visa',

'path_does_not_exist' => 
'Angiven sökväg existerar inte',

'file_viewing_error' => 
'Ett okänt fel inträffade.',

'fp_no_files' => 
'Finns inga tillgängliga filer i mappen.',

'fb_view_images' => 
'Visa bilder',

'fb_view_image' => 
'Visa bild',

'fb_insert_file' => 
'Infoga fil',

'fb_insert_files' => 
'Infoga filer',

'fb_select_field' => 
'Välj fält',

'fb_select_files' => 
'Välj filer',

'fb_non_images' => 
'* Markerar icke-bilder. Endast bilder kan visas.',

'fb_insert_link' => 
'Infoga länk',

'fb_insert_links' => 
'Infoga länkar',

'fb_insert_url' => 
'Infoga webbadress',

'fb_insert_urls' => 
'Infoga webbadresser',

'translate' => 
'Uppdatera',

''=>''
);

// End of File