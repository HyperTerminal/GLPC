<?php
$lang = array(


'eeof_example' => 
'Voorbeeld Tag!',

'translate' => 
'Update',

''=>''
);

// End of File