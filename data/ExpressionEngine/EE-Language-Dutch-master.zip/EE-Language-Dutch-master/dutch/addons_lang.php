<?php
$lang = array(


'addons' => 
'Add-ons',

'accessories' => 
'Accessories',

'modules' => 
'Modules',

'extensions' => 
'Extensions',

'plugins' => 
'Plugins',

'accessory' => 
'Accessory',

'module' => 
'Module',

'extension' => 
'Extension',

'addons_accessories' => 
'Accessories',

'addons_modules' => 
'Modules',

'addons_plugins' => 
'Plugins',

'addons_extensions' => 
'Extensions',

'addons_fieldtypes' => 
'Fieldtypes',

'accessory_name' => 
'Accessory Naam',

'fieldtype_name' => 
'Fieldtype Naam',

'install' => 
'Installeren',

'uninstall' => 
'Verwijderen',

'installed' => 
'Ge&#239;nstalleerd',

'not_installed' => 
'Niet Ge&#239;nstalleerd',

'uninstalled' => 
'Verwijderd',

'remove' => 
'Verwijderen',

'preferences_updated' => 
'Voorkeuren gewijzigd',

'extension_enabled' => 
'Extension Ingeschakeld',

'extension_disabled' => 
'Extension Uitgeschakeld',

'extensions_enabled' => 
'Extensions Ingeschakeld',

'extensions_disabled' => 
'Extensions Uitgeschakeld',

'delete_fieldtype_confirm' => 
'Weet u zeker dat u dit fieldtype wilt verwijderen',

'delete_fieldtype' => 
'Verwijder Fieldtype',

'data_will_be_lost' => 
'Alle gekoppelde data aan dit fieldtype, inclusief alle gekoppelde channel data, zal permanent verwijderd worden!',

'global_settings_saved' => 
'Instellingen opgeslagen',

'package_settings' => 
'Package Instellingen',

'component' => 
'Component',

'current_status' => 
'Huidige Status',

'required_by' => 
'Nodig bij:',

'available_to_member_groups' => 
'Beschikbaar voor Leden Groepen',

'specific_page' => 
'Specifieke Pagina?',

'description' => 
'Beschrijving',

'version' => 
'Versie',

'status' => 
'Status',

'fieldtype' => 
'Fieldtype',

'edit_accessory_preferences' => 
'Wijzig Accessory Voorkeuren',

'member_group_assignment' => 
'Toegekende Leden Groepen',

'page_assignment' => 
'Toegekende Pagina&#39;s',

'none' => 
'Geen',

'and_more' => 
'en %x meer...',

'plugins_not_available' => 
'Plugin Feed uitgeschakeld in beta versie',

'no_extension_id' => 
'Geen Extension gespecificeerd',

'translate' => 
'Update',

''=>''
);

// End of File