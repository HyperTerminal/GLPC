<?php
$lang = array(


'invalid_license' => 
'Ongeldige Licentie',

'translate' => 
'Update',

''=>''
);

// End of File