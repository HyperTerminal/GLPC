<?php
$lang = array(


'spell_check' => 
'Spellingscontrole',

'check_spelling' => 
'Controleer Spelling',

'save_spellcheck' => 
'Bewaar Veranderingen',

'revert_spellcheck' => 
'Terug naar het Origineel',

'spell_save_edit' => 
'Wijzigingen Opslaan',

'spell_edit_word' => 
'Wijzig Woord',

'unsupported_browser' => 
'Browser niet ondersteund',

'no_spelling_errors' => 
'Geen Errors Gevonden',

'spellcheck_in_progress' => 
'Bezig met Controleren...',

'translate' => 
'Update',

''=>''
);

// End of File