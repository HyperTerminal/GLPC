<?php
$lang = array(


'stats_module_name' => 
'Statistieken',

'stats_module_description' => 
'Statistieken Weergave module',

'translate' => 
'Update',

''=>''
);

// End of File