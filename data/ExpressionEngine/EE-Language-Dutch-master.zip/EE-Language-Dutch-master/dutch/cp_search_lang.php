<?php
$lang = array(


'design_user_message' => 
'Gebruiker Bericht Template',

'design_system_offline' => 
'Systeem Offline Template',

'design_email_notification' => 
'E-mail Notificatie Template',

'design_member_profile_templates' => 
'Leden Profiel Template',

'member_register_member' => 
'Registreer Lid',

'member_validation' => 
'Lid Validatie',

'member_view_members' => 
'Bekijk leden',

'member_ip_search' => 
'Leden IP Zoeken',

'member_custom_profile_fields' => 
'Custom Profiel Velden',

'member_group_manager' => 
'Leden Groep Beheer',

'member_config' => 
'Leden Configuratie',

'member_banning' => 
'Leden Bannen',

'member_search' => 
'Leden Zoeken',

'data_sql_manager' => 
'Sql Beheer',

'data_search_and_replace' => 
'Zoek en Vervang',

'data_recount_stats' => 
'Statistieken Hertellen',

'data_php_info' => 
'PHP Info',

'data_clear_caching' => 
'Cache Legen',

'file_index' => 
'Bestandsbeheer',

'cont_field_group_management' => 
'Veld Groep Beheer',

'members_member_group_manager' => 
'Leden Groep Beheer',

'cont_category_management' => 
'Categorie Beheer',

'members_custom_profile_fields' => 
'Custom Leden Profiel Velden',

'logs_view_cp_log' => 
'Bekijk Control Panel Log',

'logs_view_throttle_log' => 
'Bekijk Throttle Log',

'logs_view_search_log' => 
'Bekijk Zoek Log',

'logs_view_email_log' => 
'Bekijk E-mail Log',

'util_member_import' => 
'Leden Import',

'util_import_from_mt' => 
'Importeer vanuit MT',

'util_import_from_xml' => 
'Importeer vanuit XML',

'util_translation_tool' => 
'Vertaalprogramma',

'plug_index' => 
'Plugins',

'modu_index' => 
'Modules',

'exte_index' => 
'Extensions',

'acce_index' => 
'Accessories',

'translate' => 
'Update',

''=>''
);

// End of File