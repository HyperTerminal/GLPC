<?php
$lang = array(


'emoticon_module_name' => 
'Emoticon',

'emoticon_module_description' => 
'Emoticon (smiley) module',

'emoticon_heading' => 
'Emoticons',

'emoticon_glyph' => 
'Glyph',

'emoticon_image' => 
'Afbeelding',

'emoticon_width' => 
'Breedte',

'emoticon_height' => 
'Hoogte',

'emoticon_alt' => 
'Alt tag',

'translate' => 
'Update',

''=>''
);

// End of File