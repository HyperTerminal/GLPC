<?php
$lang = array(


'rss_module_name' => 
'RSS',

'rss_module_description' => 
'RSS genereer module',

'rss_invalid_channel' => 
'Het channel gespecificeerd in uw RSS feed bestaat niet.',

'translate' => 
'Update',

''=>''
);

// End of File