<?php
$lang = array(


'file_browser' => 
'Hoogte',

'view' => 
'Bekijk',

'path_does_not_exist' => 
'Het gekozen pad bestaat niet',

'file_viewing_error' => 
'Er is een onbekende type fout opgetreden',

'fp_no_files' => 
'Geen bestanden beschikbaar in deze map',

'fb_view_images' => 
'Bekijk afbeeldingen',

'fb_view_image' => 
'Bekijk afbeelding',

'fb_insert_file' => 
'Bestand invoegen',

'fb_insert_files' => 
'Bestanden invoegen',

'fb_select_field' => 
'Veld Selecteren',

'fb_select_files' => 
'Bestanden Selecteren',

'fb_non_images' => 
'* Geeft bestanden weer die geen afbeeling zijn.  Alleen afbeeldingen kunnen worden bekeken.',

'fb_insert_link' => 
'Link invoegen',

'fb_insert_links' => 
'Links invoegen',

'fb_insert_url' => 
'URL invoegen',

'fb_insert_urls' => 
'URL&#39s invoegen',

'translate' => 
'Update',

''=>''
);

// End of File