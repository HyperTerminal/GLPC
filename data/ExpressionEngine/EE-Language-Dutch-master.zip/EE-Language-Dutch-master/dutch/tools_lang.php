<?php
$lang = array(


'tools' => 
'Tools',

'tools_data' => 
'Data',

'tools_logs' => 
'Logs',

'tools_utilities' => 
'Utilities',

'communicate' => 
'Communicatie',

'config_editor' => 
'Config Bestandsbeheer',

'php_info' => 
'PHP Info',

'recount_stats' => 
'Statistieken hertellen',

'search_and_replace' => 
'Zoek en Vervang',

'sql_manager' => 
'SQL Beheer',

'clear_caching' => 
'Gecachtte Data Opschonen',

'view_throttle_log' => 
'Bekijk Throttle Log',

'view_search_log' => 
'Bekijk Zoektermen Log',

'view_email_logs' => 
'Bekijk E-mail Console Log',

'view_cp_log' => 
'Bekijk Control Panel Log',

'import_utilities' => 
'Import Programma',

'translation_tool' => 
'Vertaal Programma',

'english' => 
'Engels',

'translation' => 
'Vertaling',

'hits' => 
'Hits',

'last_activity' => 
'Laatste Activiteit',

'no_throttle_logs' => 
'Er worden op dit moment geen Ip&#39;s gethrottled door het systeem',

'throttling_disabled' => 
'Throttling Uitgeschakeld',

'blacklist_all_ips' => 
'Alle Ip&#39;s op de Blacklist zetten',

'no_search_results' => 
'Geen Resultaten Gevonden',

'search_results' => 
'Zoek Resultaten',

'site_search' => 
'Site',

'searched_in' => 
'Gezocht in',

'search_terms' => 
'Zoektermen',

'page_caching' => 
'Page (template) cache bestanden',

'tag_caching' => 
'Tag cache bestanden',

'db_caching' => 
'Database cache Bestanden',

'cached_relationships' => 
'Gecachte Gerelateerde Berichten',

'all_caching' => 
'Alle caches',

'sandr_instructions' => 
'Deze formulieren zorgen er voor dat je specifieke teksten kan vervangen door andere teksten.',

'search_term' => 
'Zoeken naar deze tekst',

'replace_term' => 
'En vervan het door deze tekst',

'replace_where' => 
'Ik welk databaseveld moeten de vervangingen doorgevoerd worden?',

'search_replace_disclaimer' => 
'Afhankelijk van de gebruikte syntaxen kan deze functie onverwachte resultaten opleveren. Lees de handleiding en maak een back-up van uw database',

'advanced_users_only' => 
'Alleen voor gevorderde gebruikers',

'choose_translation_file' => 
'Kies een bestand om te vertalen',

'no_lang_file' => 
'Geen Taalbestand gekozen',

'no_lang_keys' => 
'Geen regels om te vertalen',

'invalid_path' => 
'Het door u ingevoerde pad is ongeldig:',

'file_saved' => 
'Het vertaalbestand is opgeslagen in system&#47;expressionengine&#47;translations&#47;',

'trans_file_not_writable' => 
'Vertalingsbestand is niet beschrijfbaar',

'import_from_mt' => 
'Movable Type Import Programma',

'member_import' => 
'Leden Import Programma',

'missing_password_type' => 
'Het verplichte attribuut type mist in het wachtwoord voor gebruiker: %x. Lees de handleiding voor het correcte import formaat.',

'united_states' => 
'Verenigde Staten',

'european' => 
'Europees',

'preference' => 
'Voorkeur',

'setting' => 
'Instelling',

'preferences_updated' => 
'Voorkeuren gewijzigd',

'true' => 
'Goed',

'false' => 
'Fout',

'translation_dir_unwritable' => 
'Let op: Uw vertaal map is niet schrijfbaar',

'screen_name' => 
'Schermnaam',

'translate' => 
'Update',

''=>''
);

// End of File