<?php
$lang = array(


'ip_to_nation_module_name' => 
'IP naar Land',

'ip_to_nation_module_description' => 
'Utility voor het associ&#235;ren van IP addressen met een land van herkomst',

'iptonation_missing' => 
'Kan het bestand iptonation.php niet vinden.  Wees er zeker van dat u alle onderdelen van deze module heeft ge&#252;pload.',

'countryfile_missing' => 
'Kan het bestand country.php in uw lib map niet vinden.',

'ip_search' => 
'IP-adres Zoeken',

'ip_search_inst' => 
'Voer een IP adres in om land van herkomst te bepalen',

'ip_result' => 
'Het ingevoerde IP adres is afkomstig uit:',

'manage_banlist' => 
'Manage Beheer uw lijst met geblokeerde landenBanned Country List',

'country' => 
'Land',

'ban_info' => 
'Selecteer de landen die u wenst te blokkeren. Wanneer een land geblokkerd is zal een persoon met een daarmee geassocieerd IP adres geen reactie kunnen plaatsen, trackbacks of uw e-mail/tell-a-friend formulier kunnen gebruiken. Zij zijn echter wel in staat uw site te bekijken. ',

'ban' => 
'Ban',

'banlist' => 
'Lijst gebande landen',

'banlist_updated' => 
'Lijst gebande landen is succesvol gewijzigd',

'update_ips' => 
'Update IP Database',

'update_info' => 
'Update de IP en landencode informatie met een recente export van <a href=\'%d\' title=\'Download Hier\'>ip2nation.com</a>',

'update_blurb' => 
'Om te updaten moet u eerst het ge-unzipte bestand met de ip2nation sql data op uw server plaatsen. Daarna dient u de locatie van het bestand in te voeren.',

'ip2nation_file_loc' => 
'SQL bestand locatie',

'unable_to_read_file' => 
'Niet mogelijk om bestand te lezen',

'last_update' => 
'Laatste update:',

'ip_db_updated' => 
'IP Database Update succesvol',

'ip_db_failed' => 
'Ongeldige karakters in import bestand',

'translate' => 
'Update',

''=>''
);

// End of File