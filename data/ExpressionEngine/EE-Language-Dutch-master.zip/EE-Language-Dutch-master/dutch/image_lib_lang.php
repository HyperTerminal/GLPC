<?php
$lang = array(


'imglib_gd_required_for_props' => 
'Uw server moet de GD image library ondersteunen om de afbeeldings eigenschappen te kunnen vaststellen',

'imglib_unsupported_imagecreate' => 
'Uw server ondersteund niet de GD functie die dit type afbeelding nodig heeft.',

'imglib_gif_not_supported' => 
'GIF afbeeldingen worden niet ondersteund. Dit als gevolg van licentie restricties. U kunt wel JPG of PNG afbeeldingen gebruiken',

'imglib_jpg_not_supported' => 
'JPG afbeeldingen worden niet ondersteund',

'imglib_png_not_supported' => 
'PNG afbeeldingen worden niet ondersteund',

'imglib_jpg_or_png_required' => 
'Het verklein protocol dat aangegeven staat in de voorkeuren, werkt alleen met JPEG of PNG afbeeldingen.',

'imglib_copy_error' => 
'Er is een fout opgetreden bij het vervangen van het bestand. Wees er zeker van dat de map beschrijfbaar is.',

'imglib_rotate_unsupported' => 
'Afbeeldingen roteren wordt niet ondersteund door uw server.',

'imglib_libpath_invalid' => 
'Het pad naar de image library is niet correct. Voer het juiste pad in, in uw voorkeuren.',

'imglib_image_process_failed' => 
'Afbeelding verwerken mislukt. Kijk of uw server het gekozen protocol ondersteund en dat het pad naar uw image library juist is.',

'imglib_rotation_angle_required' => 
'De hoek van de rotatie is nodig om de afbeelding te kunnen draaien.',

'imglib_writing_failed_gif' => 
'GIF afbeelding',

'imglib_invalid_path' => 
'Het pad naar de afbeelding is niet correct',

'imglib_copy_failed' => 
'De kopieerfunctie van de afbeelding is mislukt',

'translate' => 
'Update',

''=>''
);

// End of File