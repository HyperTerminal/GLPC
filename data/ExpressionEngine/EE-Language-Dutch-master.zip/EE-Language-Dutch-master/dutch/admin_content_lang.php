<?php
$lang = array(


'reserved_word' => 
'De gekozen veldnaam is een gereserveerd woord en kan niet gebruikt worden',

'list_edit_warning' => 
'Als u niet opgeslagen veranderingen heeft op deze pagina zullen ze verloren gaan als u overschakelt naar de editor',

'fmt_has_changed' => 
'Let op: u heeft een ander veld formaat geselecteerd dan die eerder opgeslagen was.',

'update_existing_fields' => 
'Update alle bestaande berichten met uw formaat keuze?',

'display_criteria' => 
'Selecteer weergave criteria voor de Publiceer pagina',

'field_type_options' => 
'Custom Veld Opties',

'limit' => 
'Limiet',

'orderby_title' => 
'Sorteer op Titel',

'orderby_date' => 
'Sorteer op datum',

'sort_desc' => 
'Oplopende volgorde',

'in' => 
'in',

'sort_asc' => 
'Aflopende volgorde',

'field_label_info' => 
'Dit is de naam die op de Publiceer pagina zal verschijnen',

'deft_field_formatting' => 
'Standaard Veld Formaat',

'formatting_no_available' => 
'Text formaat is niet beschikbaar voor het gekozen veld type',

'show_formatting_buttons' => 
'Laat Formaat knoppen zien',

'hide_formatting_buttons' => 
'Verberg Formaat knoppen',

'field_options' => 
'Veld Opties',

'date_field' => 
'Datum veld',

'relationship' => 
'Relatie',

'related_to_channel' => 
'Relateer Berichten aan andere berichten',

'select_related_channel' => 
'Selecteer het channel waar u een relatie mee wilt maken:',

'rss_url' => 
'RSS Feed URL',

'rss_url_exp' => 
'De URL waar u de RSS feed van uw channel kunt bekijken',

'update_publish_cats' => 
'Sluit scherm en wijzig categorie&#235;n in Publiceer pagina',

'versioning' => 
'Versiebeheer voorkeuren',

'enable_versioning' => 
'Versiebeheer inschakelen',

'clear_versioning_data' => 
'Verwijder alle bestaande revisie data in deze channel',

'max_revisions' => 
'Maximaal aantal recente revisies per bericht',

'max_revisions_note' => 
'Versiebeheer kan een hoop databaseruimte kosten. Het is daarom aan te raden een maximaal aantal revisies op te slaan',

'field_populate_manually' => 
'Vul het menu handmatig',

'field_populate_from_channel' => 
'Gebruik het menu van een ander custom veld',

'select_channel_for_field' => 
'Selecteer het veld waar u het van wilt gebruiken:',

'field_val' => 
'U moet een veldnaam kiezen voor dit menu, geen channelnaam.',

'channel_notify' => 
'Ontvangerslijst inschakelen voor Bericht notificatie',

'no_statuses' => 
'Geen statussen gevonden',

'status_created' => 
'Status is aangemaakt',

'field_is_hidden' => 
'Laat het veld standaard zien?',

'hidden_field_blurb' => 
'Deze optie zorgt er voor of een veld standaard zichtbaar is op de TOEVOEGEN pagina. Als deze op &#34;nee&#34; staat zal er een link verschijen om deze alsnog te openen.',

'include_rss_templates' => 
'RSS Sjablonen invoegen',

'notification_settings' => 
'Notificatie voorkeuren',

'comment_notify_authors' => 
'De auteur op de hoogte brengen als er een reactie op trackback geplaatst wordt?',

'comment_notify' => 
'Admins op de hoogte brengen van reacties en Trackbacks?',

'update_existing_comments_mod' => 
'Update alle bestaande berichten met deze instelling?',

'update_existing_comments' => 
'Wijzig alle bestaande commentaren met deze afloopdatum instelling?',

'category_order_confirm_text' => 
'Weet u zeker dat u deze categoriegroep op alfebet wil sorteren?',

'category_sort_warning' => 
'Als u een eigen sorteer volgorde gebruikt zal deze vervangen worden door &#233;&#233;n op alfabet.',

'global_sort_order' => 
'Standaard Sorteer Volgorde',

'custom' => 
'Custom',

'alpha' => 
'Alfabetisch',

'id' => 
'ID',

'channel_id' => 
'ID',

'channel_short_name' => 
'Korte Naam',

'group_required' => 
'U moet een groepnaam invoeren.',

'comment_url' => 
'Reactiepagina URL',

'comment_url_exp' => 
'De URL waar de reactiepagina voor deze channel staat',

'order' => 
'Volgorde',

'delete_category_confirmation' => 
'Weet u zeker dat u de volgende categorie wilt verwijderen',

'category_description' => 
'Categorie omschrijving',

'category_updated' => 
'Categorie gewijzigd',

'new_category' => 
'Maak een nieuwe Categorie',

'template_creation' => 
'Maak nieuwe templates aan voor deze channel?',

'use_a_theme' => 
'Gebruik &#233;&#233;n van de standaard sjabonen',

'myaccount_cp_theme' => 
'Control Panel Theme',

'duplicate_group' => 
'Dupliceer een bestaande templategroep',

'template_group_name' => 
'Nieuwe Templategroep naam',

'template_group_choose' => 
'Kies een Template Groep',

'new_group_instructions' => 
'Veld is verplicht als u een nieuwe groep aanmaakt',

'publish_page_customization' => 
'Layout van de Toevoeg pagina aanpassen',

'show_button_cluster' => 
'Formaat knoppen weergeven?',

'paths' => 
'Pad instellingen',

'channel_url_exp' => 
'De URL naar deze Channel',

'search_results_url' => 
'Zoekresultaten URL',

'search_results_url_exp' => 
'De URL waar de zoekresultaten voor deze channel getoont moeten worden.',

'ping_return_url' => 
'Ping terugverwijzing URL',

'ping_return_url_exp' => 
'De URL waar bezoekers heengaan als ze op de ping link klikken op andere websites.',

'comment_expiration' => 
'Afloop Reacties',

'comment_expiration_desc' => 
'Het aantal dagen nadat een bericht is geplaatst dat er reacties gegeven mogen worden. Vul 0 (nul) in als het niet hoeft te verlopen.',

'restrict_status_to_group' => 
'Beperk status aan leden van bepaalde groepen',

'no_publishing_groups' => 
'Er zijn geen ledengroepen beschikbaar die mogen publiceren',

'status_updated' => 
'Status in Gewijzigd',

'status_deleted' => 
'Status is verwijderd',

'can_edit_status' => 
'Kan toegang krijgen tot status',

'search_excerpt' => 
'Veld voor Zoek Uittreksel',

'channel_prefs' => 
'Channel voorkeuren',

'channel_settings' => 
'Voorkeuren Berichten ',

'comment_prefs' => 
'Voorkeuren Reacties',

'comment_use_captcha' => 
'Schakel Captcha voor plaatsen van reacties in?',

'comment_moderate' => 
'Reacties Modereren?',

'comment_moderate_exp' => 
'Als u deze functie geactiveerd heeft zullen reacties niet zichtbaar zijn totdat een moderator ze goedgekeurd heeft.',

'comment_system_enabled' => 
'Reacties toestaan in deze channel?',

'edit_channel_prefs' => 
'Wijzig Channel Voorkeuren',

'edit_group_prefs' => 
'Groepvoorkeuren wijzigen',

'edit_group_assignments' => 
'Wijzig Groep Toekenningen',

'duplicate_channel_prefs' => 
'Dupliceer huidige Channel voorkeuren',

'do_not_duplicate' => 
'Niet dupliceren',

'no_channels_exist' => 
'Er zijn op dit moment geen channels',

'create_new_channel' => 
'Cre&#235;er een nieuw Channel',

'channel_base_setup' => 
'Algemene Channel Voorkeuren',

'default_settings' => 
'Administrator Instellingen',

'channel_name' => 
'Channel naam',

'channel_url' => 
'Channel URL',

'channel_lang' => 
'XML Taal',

'channel_description' => 
'Channel Omschrijving',

'illegal_characters' => 
'De naam die u invoeren mag alleen uit alfa-numerieke karakters, spaties, underscores, en dashes',

'comment_require_membership' => 
'Is registratie vereist om reacties te plaatsen?',

'channel_require_membership' => 
'Is registratie vereist om berichten te plaatsen?',

'comment_require_email' => 
'E-mailadres vereisen om reacties te plaatsen?',

'channel_require_email' => 
'E-mailadres vereisen om bericht te plaatsen?',

'channel_max_chars' => 
'Maximum aantal karakters toegestaan in berichten',

'comment_max_chars' => 
'Maximum aantal karakters toegestaan in reacties',

'comment_timelock' => 
'Tijdsinterval tussen Reacties',

'comment_timelock_desc' => 
'Het aantal seconden dat er tussen 2 reacties moet zitten voordat een gebruiker een nieuwe reactie kan plaatsen. Laat leeg of zet op nul om geen tijd in te stellen.',

'comment_text_formatting' => 
'Tektformaat van Reacties',

'channel_text_formatting' => 
'Standaard tekst formaat in berichten',

'comment_html_formatting' => 
'HTML Opmaak van Reacties',

'channel_html_formatting' => 
'Standaard HTML formaat in berichten',

'convert_to_entities' => 
'Converteer HTML in karakters',

'allow_safe_html' => 
'Sta alleen &#39;veilige&#39; HTML toe',

'allow_all_html' => 
'Sta ALLE HTML toe',

'allow_all_html_not_recommended' => 
'Sta ALLE HTML toe (niet aanbevolen)',

'comment_notify_note' => 
'Scheid meerdere e-mail adressen met komma&#39;s',

'comment_notify_emails' => 
'E-mail adres van ontvanger voor Bericht(en)',

'comment_allow_img_urls' => 
'Afbeeldingen toestaan in reacties?',

'channel_allow_img_urls' => 
'Sta afbeelding URLs in berichten to',

'auto_link_urls' => 
'Verander URLS en e-mail adressen automatisch in links?',

'single_word_no_spaces' => 
'enkel woord, geen spaties',

'channel_title' => 
'Volledige Channel naam',

'edit_channel' => 
'Wijzig Channel',

'channel_full_name' => 
'Volledige naam',

'new_channel' => 
'Nieuw Channel',

'channel_created' => 
'Channel aangemaakt:',

'channel_updated' => 
'Channel gewijzigd:',

'taken_channel_name' => 
'Deze naam is al gekozen',

'no_channel_name' => 
'U moet dit channel een &#34;korte&#34 naam geven',

'no_channel_title' => 
'U moet dit channel een &#34volledige&#34 naam geven',

'invalid_short_name' => 
'Uw channel mag alleen bestaan uit alfa-numerieke karakters en mag geen spaties bevatten.',

'delete_channel' => 
'Verwijder Channel',

'channel_deleted' => 
'Channel verwijderd',

'delete_channel_confirmation' => 
'Weet u zeker dat u dit channel permanent wilt verwijderen?',

'be_careful' => 
'WEES VOORZICHTIG!',

'action_can_not_be_undone' => 
'DEZE ACTIE KAN NIET ONGEDAAN GEMAAKT WORDEN',

'assign_group_to_channel' => 
'Let op: Om uw nieuwe groep te kunnen gebruiken, moet u het aan een channel toekennen.',

'click_to_assign_group' => 
'Klik hier om het toe te kennen',

'default' => 
'Standaard',

'category' => 
'Categorie',

'deft_status' => 
'Standaard Status',

'deft_category' => 
'Standaard Categorie',

'deft_comments' => 
'&quot;Reacties toestaan&quot; standaard aangevinkt?',

'no_field_group_selected' => 
'Geen Veld groep beschikbaar voor deze channel',

'invalid_field_group_selected' => 
'Ongeldige Veld Groep',

'missing_channel_data_for_pings' => 
'Om Pings te kunnen sturen heeft uw channel een titel en URL nodig. Wijzig uw channel voorkeuren',

'open' => 
'Open',

'closed' => 
'Gesloten',

'none' => 
'Geen',

'define_html_buttons' => 
'HTML Formaat Knop Defenities',

'no_buttons' => 
'Geen HTML buttons gedefinieerd',

'htmlbutton_delete_instructions' => 
'Om een item te verwijderen, maak de tag naam leeg en submit het formulier',

'tag_name' => 
'Tag Naam',

'tag_open' => 
'Opening Tag',

'tag_close' => 
'Sluit Tag',

'accesskey' => 
'Snelkoppeling',

'tag_order' => 
'Sorteren',

'row' => 
'Rij',

'server_name' => 
'Server Naam',

'server_url' => 
'Server URL/Pad',

'port' => 
'Poort',

'protocol' => 
'Protocol',

'is_default' => 
'Standaard',

'server_order' => 
'Sorteren',

'define_ping_servers' => 
'In dit formulier kun een een lijst defini&#235;ren met servers die gepingt kunnen worden wanneer er nieuwe berichten toegevoegd worden',

'pingserver_delete_instructions' => 
'Om een item te verwijderen, maak de servernaam leeg en submit het formulier',

'assign_channels' => 
'Kies welke channel(s) u aan deze groep wilt toekennen',

'group' => 
'Groep',

'group_name' => 
'Groepsnaam',

'new_group_name' => 
'Nieuwe Groepsnaam',

'total_fields' => 
'Totaal aantal velden',

'rename' => 
'Hernoem',

'rename_group' => 
'Hernoem Groep',

'delete' => 
'Verwijder',

'delete_group' => 
'Verwijder Groep',

'category_group' => 
'Categorie Groep',

'category_groups' => 
'Categorie Groepen',

'no_category_group_message' => 
'Er zijn op dit moment geen categorie&#235;n',

'no_category_message' => 
'Er zijn op dit moment geen categorie&#235;n toegekend aan deze groep',

'create_new_category_group' => 
'Maak een nieuwe Categorie Groep',

'edit_category_group' => 
'Wijzig een Categorie Groep',

'name_of_category_group' => 
'Naam van de Categorie Groep',

'taken_category_group_name' => 
'Deze Groep is al in gebruik',

'add_edit_categories' => 
'Toevoegen/Wijzigen Categorie&#235;n',

'edit_group_name' => 
'Wijzig Categorie',

'category_group_created' => 
'Aangemaakte Categorie Groep:',

'category_group_updated' => 
'Groep Gewijzigd',

'delete_cat_group_confirmation' => 
'Weet u zeker dat u permanent deze categoriegroep wilt verwijderen?',

'category_group_deleted' => 
'Categorie Groep Verwijderd:',

'create_new_category' => 
'Maak een nieuwe Categorie',

'add_new_category' => 
'Voeg een nieuwe Categorie toe',

'edit_category' => 
'Wijzig Categorie',

'delete_category' => 
'Verwijder Categorie',

'delete_cat_confirmation' => 
'Weet u zeker dat u deze Categorie permanent wilt verwijderen?',

'category_deleted' => 
'Categorie verwijderd',

'category_url_title' => 
'Categorie URL Titel',

'cat_url_title_is_numeric' => 
'Nummers kunnen niet gebruikt worden als Categorie URL Titels',

'unable_to_create_cat_url_title' => 
'Onmogelijk om een geldige Categorie URL titel voor uw Categorie aan te maken',

'duplicate_cat_url_title' => 
'Een Categorie met de ingevoerde Categorie URL titels bestaat al in deze Categorie Groep',

'category_name' => 
'Categorie naam',

'category_image' => 
'Categorie afbeelding URL',

'category_img_blurb' => 
'Dit is een optioneel veld dat de mogelijkheid geeft een afbeelding toe te kennen aan je categorie&#235;n.',

'category_parent' => 
'Hoofd Category',

'custom_category_fields' => 
'Custom Categorie Velden',

'manage_custom_fields' => 
'Beheer Custom Velden',

'delete_cat_field' => 
'Verwijder Categorie Veld',

'delete_cat_field_confirmation' => 
'Weet u zeker dat u voorgoed dit categorie veld wilt verwijderen?',

'cat_field_deleted' => 
'Categorie veld verwijderd:',

'cat_field_updated' => 
'Categorie veld gewijzigd:',

'edit_cat_field' => 
'Wijzig Categorie veld',

'create_new_cat_field' => 
'Cre&#235;er Nieuw Categorie Veld',

'cat_field_created' => 
'Nieuwe Categorie Veld gemaakt:',

'cat_field_edited' => 
'Categorie Veld gewijzigd:',

'category_created' => 
'Nieuwe Categorie Aangemaakt',

'category_edited' => 
'Categorie gewijzigd',

'cat_field_label_info' => 
'Dit is de naam die verschijnt in de Categorie Wijzig pagina',

'update_existing_cat_fields' => 
'Wijzig alle bestaande categorie&#235;n in deze groep met uw nieuwe formaat keuze?',

'formatting' => 
'Formaat:',

'cat_field_html_formatting' => 
'Categorie veld HTML formaat',

'can_edit_categories' => 
'Kan Categorie&#235;n wijzigen',

'can_delete_categories' => 
'Kan Categorie&#235;n verwijderen',

'exclude_from_channels_or_publish' => 
'Uitsluiten van Channel of Veld Categorie Toekenning',

'exclude_from_publish' => 
'Channel Toekenning',

'exclude_from_files' => 
'Bestand Toekenning',

'no_member_groups_available' => 
'Er zijn geen leden groepen toegestaan op %x Categorie&#235;n.  U kunt deze privileges toekennen in het leden groep beheer: ',

'member_group' => 
'Leden Groep',

'member_groups' => 
'Leden Groepen',

'missing_required_fields' => 
'U mist verplichte velden:',

'field_settings' => 
'Custom Veld Instellingen',

'field_group' => 
'Veld Groep',

'field_groups' => 
'Veld Groepen',

'custom_fields' => 
'Custom Veld',

'no_field_group_message' => 
'Er zijn op dit moment een custom channel velden',

'create_new_field_group' => 
'Maak een nieuw Channel Veld Groep',

'new_field_group' => 
'Nieuwe Veld Groep',

'add_edit_fields' => 
'Toevoegen/Wijzig Custom Velden',

'edit_field_group_name' => 
'Wijzig Veld Groep',

'delete_field_group' => 
'Verwijder Veld Groep',

'create_new_field' => 
'Maak een nieuw Veld',

'edit_field' => 
'Wijzig Veld',

'custom_field_edited' => 
'Custom Veld gewijzigd',

'custom_field_created' => 
'Custom Veld Aangemaakt',

'no_field_groups' => 
'Er zijn op dit moment geen custom velden in deze groep',

'delete_field' => 
'Verwijder Veld',

'field_deleted' => 
'Custom Veld Verwijderd:',

'edit_field_order' => 
'Wijzig Veld volgorde',

'create_new_custom_field' => 
'Maak nieuw Custom Veld',

'field_id' => 
'Veld ID',

'field_label' => 
'Veld Label',

'field_name' => 
'Veld Naam',

'field_name_cont' => 
'Enkel woord, geen spaties. Underscores en platte streepjes zijn toegestaan',

'field_type' => 
'Veld Type',

'field_max_length' => 
'Maximale Lengte',

'field_max_length_cont' => 
'Als je kiest voor text field type',

'textarea_rows' => 
'Textarea Rijen',

'textarea_rows_cont' => 
'Als je kiest voor textarea field type',

'dropdown_sub' => 
'Als u gebruik maakt van een drop-down veld type',

'field_list_items' => 
'Selectie Opties',

'multi_list_items' => 
'Multi-Selectie Opties',

'option_group_items' => 
'Checkbox Opties',

'radio_items' => 
'Radio Opties',

'field_list_items_cont' => 
'Als je kiest voor drop-down menu',

'field_list_instructions' => 
'Zet elk item op een aparte regel',

'field_formatting' => 
'Veld Formaat',

'edit_list' => 
'Wijzig lijst',

'formatting_options' => 
'Veld Formaat opties',

'field_formatting_cont' => 
'Als je kiest voor textarea field type',

'field_order' => 
'Volgorde velden',

'is_field_searchable' => 
'Is het veld doorzoekbaar?',

'is_field_required' => 
'Is het een verplicht veld?',

'show_smileys' => 
'Smileys tonen',

'show_glossary' => 
'Glossary tonen',

'show_spellcheck' => 
'Spellingscontrole tonen',

'show_file_selector' => 
'Bestandskiezer tonen',

'show_formatting_btns' => 
'Opmaakknoppen tonen',

'show_writemode' => 
'Schrijfmodus tonen',

'text_input' => 
'Text Input',

'textarea' => 
'Textarea',

'select_list' => 
'Drop-down Lijst',

'auto_br' => 
'Auto &lt;br /&gt;',

'xhtml' => 
'XHTML',

'no_field_name' => 
'U moet een veldnaam invoeren',

'no_field_label' => 
'U moet een veldlabel invoeren',

'invalid_characters' => 
'De veldnaam die u invoerde bevat karakters die niet zijn toegstaan',

'custom_field_empty' => 
'Het volgende veld is verplicht:',

'duplicate_field_name' => 
'De veld naam die u koos is al in gebruik',

'taken_field_group_name' => 
'De naam die u koos is al in gebruik',

'field_group_created' => 
'Veld Groep gemaakt:',

'field_group_updated' => 
'Veld Groep Gewijzigd:',

'field_group_deleted' => 
'Veld Groep Verwijderd:',

'delete_field_group_confirmation' => 
'Weet u zeker dat u deze custom veld groep wilt verwijderen?',

'delete_field_confirmation' => 
'Weet u zeker dat u permanent dit custom veld wilt verwijderen?',

'channel_entries_will_be_deleted' => 
'Alle berichten in bovenstaande veld(en) zullen verwijderd worden.',

'field_content_text' => 
'Veld content:',

'field_content_file' => 
'Bestand type:',

'allowed_dirs_file' => 
'Toegestane Directory',

'type_numeric' => 
'Nummer',

'type_integer' => 
'Getal',

'type_decimal' => 
'Decimaal',

'type_file' => 
'Bestand',

'type_image' => 
'Afbeelding',

'status_group' => 
'Status Groep',

'no_status_group_message' => 
'Er zijn op dit moment geen custom statussen',

'create_new_status_group' => 
'Maak een nieuwe Status Groep',

'taken_status_group_name' => 
'Deze Status Groep naam is al in gebruik.',

'invalid_status_name' => 
'Status naam kan alleen bestaan uit alfa-nummerieke karakters, maar ook spaties, underscores en koppeltekens.',

'duplicate_status_name' => 
'Een status met dezelfde naam bestaat reeds.',

'status_group_created' => 
'Status Group aangemaakt:',

'new_status' => 
'Nieuwe Status',

'status_group_updated' => 
'Status Group Gewijzigd:',

'add_edit_statuses' => 
'Toevoegen/Wijzigen Statussen',

'edit_status_group_name' => 
'Wijzig Status Groep',

'delete_status_group' => 
'Verwijder Status Groep',

'delete_status_group_confirmation' => 
'Weet u zeker dat deze status groep permanent wilt verwijderen?',

'status_group_deleted' => 
'Status Groep Verwijderd:',

'create_new_status' => 
'Maak een nieuwe Status',

'status_name' => 
'Status Naam',

'status_order' => 
'Status Volgorde',

'change_status_order' => 
'Verander Status Volgorde',

'highlight' => 
'Accentueer Kleur (optioneel)',

'statuses' => 
'Statussen',

'edit_status' => 
'Wijzig Status',

'delete_status' => 
'Verwijder Status',

'delete_status_confirmation' => 
'Weet je zeker dat je de volgende status wilt verijderen?',

'url_title_prefix' => 
'URL Titel Prefix',

'live_look_template' => 
'Bekijk Live Template',

'no_live_look_template' => 
'- Geen Bekijk Live Template -',

'default_entry_title' => 
'Standaard Bericht Titel',

'invalid_url_title_prefix' => 
'Ongeldige URL Titel Prefix',

'multiple_cat_group_preferences' => 
'Meerdere Categorie Groep Voorkeuren',

'integrate_category_groups' => 
'Integreer Categorie Groepen',

'text_direction' => 
'Text richting',

'ltr' => 
'Links naar Rechts',

'rtl' => 
'Rechts naar Links',

'field_instructions' => 
'Veld instructies',

'field_instructions_info' => 
'Instructies voor auteurs over wat ze in de custom velden moeten invoeren',

'show_pages_cluster' => 
'Toon Pages Toevoeg veld',

'content_type_changed' => 
'Veld Content Type zal gewijzigd worden van %s. Het veldtype updaten kan resulteren in data verlies. Oplettendheid is geboden.',

'field_name_too_lrg' => 
'Uw veldnaam overschrijdt de maximale lengte is ingekort. Bekijk het nogmaals',

//----------------------------
// Channel Form Settings
//----------------------------

'channel_form_settings' =>
'Channel instellingen (front-end)',

'channel_form_settings_updated' =>
'Channel instellingen opgeslagen',

'channel_form_default_status' =>
'Standaard status',

'channel_form_allow_guest_posts' =>
'Sta gast-posts toe?',

'channel_form_guest_captcha' =>
'Captcha tonen voor gasten?',

'channel_form_guest_author' =>
'Gast auteur',

'channel_form_default_status_empty' =>
'-- gebruik channel-standaard --',

//----------------------------
// Channel Entries API
//----------------------------

'invalid_api_parameter' => 
'Kan bericht niet maken/wijzigen. API parameter ontbreekt',

'unauthorized_for_this_channel' => 
'U bent niet gerechtigd om in dit channel iets te plaatsen',

'translate' => 
'Update',

''=>''
);

// End of File