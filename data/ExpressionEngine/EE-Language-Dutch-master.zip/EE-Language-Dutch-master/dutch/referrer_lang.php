<?php
$lang = array(


'referrer_module_name' => 
'Referrer',

'referrer_module_description' => 
'Referrer tracking module',

'referrer_preferences' => 
'Referrer Voorkeuren',

'referrer_ip' => 
'Referrer IP',

'referrer_date' => 
'Referrer Datum',

'ref_ip' => 
'IP-adres',

'ref_user_agent' => 
'User Agent',

'ref_url' => 
'URL',

'ref_type' => 
'Type',

'referrers' => 
'Referrers',

'view_referrers' => 
'Bekijk Referrers',

'clear_referrers' => 
'Opschonen Referrers',

'referrer_from' => 
'Referrer Van',

'referrer_to' => 
'Referrer Naar',

'no_referrers' => 
'Er zijn op dit moment geen referrers',

'referrer_no_results' => 
'Er zijn geen resultaten die aan uw invoerde criteria voldoen.',

'total_referrers' => 
'Totaal aantal Referrers:',

'save_instructions' => 
'Hoeveel van de meest recente referrers wilt u bewaren?',

'referrers_deleted' => 
'Refferers zijn verwijderd',

'referrer_deleted' => 
'Referrer is Verwijderd',

'delete_confirm' => 
'Bevestig Verwijdering',

'referrer_delete_question' => 
'Weet u zeker dat u de geselecteerde refferer(s) wilt verwijderen?',

'blacklist_question' => 
'Als aanvulling op het verwijderen van de refferers kunt u ook:',

'add_urls' => 
'Verwijder andere Referrers met dezelfde URL?',

'add_and_blacklist_urls' => 
'Voeg URL&#39;s aan de Blacklist toe en verwijder andere Referrers met dezelfde URL?',

'add_ips' => 
'Verwijder andere Referrers met hetzelfde Ip-adres?',

'add_and_blacklist_ips' => 
'Voeg IP-adres toe aan de Blacklis en verwijdere andere Referrers met hetzelfde IP adres?',

'add_agents' => 
'Verwijder andere Referrers met dezelfde User Agent?',

'add_and_blacklist_agents' => 
'Voeg User Agents toe aan de Blacklist en verwijder andere Referrers met dezelfde User Agent?',

'translate' => 
'Update',

''=>''
);

// End of File