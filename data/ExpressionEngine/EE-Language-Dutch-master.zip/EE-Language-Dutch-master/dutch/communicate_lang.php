<?php
$lang = array(


'your_name' => 
'Uw naam',

'your_email' => 
'Uw E-mail',

'recipient' => 
'Ontvanger',

'cc' => 
'CC',

'bcc' => 
'BCC',

'recipient_group' => 
'Stuur naar Leden Groepen',

'manual_recipients_ignored' => 
'Het ontvangersveld hierboven zal genegeerd worden',

'send_to_mailinglist' => 
'Naar Mailinglist sturen?',

'honor_email_pref' => 
'Alleen versturen naar leden die e-mail willen ontvangen',

'separate_emails_with_comma' => 
'Scheid meerdere adressen met een komma',

'no_email_matching_criteria' => 
'Er zijn geen e-mailadressen die aan uw voorwaarden voldoen',

'not_allowed_to_email_members' => 
'U mag geen e-mail sturen naar leden',

'not_allowed_to_email_member_groups' => 
'U mag geen e-mail sturen naar Leden Groepen',

'not_allowed_to_email_mailinglist' => 
'U mag geen e-mail sturen naar de mailinglist',

'not_allowed_to_email_cache' => 
'U mag de e-mail cache niet bekijken',

'subject' => 
'Onderwerp',

'message' => 
'Bericht',

'plaintext_alt' => 
'Platte Tekst Alternatief (optioneel, HTML e-mails alleen, geen tekst formaaat toegepast)',

'send_an_email' => 
'Een E-mail sturen',

'sending_email' => 
'E-mail versturen',

'batchmode_ready_to_begin' => 
'Het verzenden van e-mail zal beginnen binnen vijf seconden',

'batchmode_warning' => 
'Raak uw browser niet aan totdat het proces geheel is be&#235;indigd!',

'problem_with_id' => 
'Er is een probleem geconstateerd met betrekking tot het benodigde ID-nummer om e-mail te versturen',

'cache_data_missing' => 
'De cache-gegevens van de e-mail zijn niet gevonden.',

'currently_sending_batch' => 
'Bezig e-mails te versturen %x door %y',

'emails_remaining' => 
'Resterende e-mails:',

'email_error' => 
'E-mail fout',

'send_it' => 
'Verzenden',

'total_emails_sent' => 
'Totaal aantal verzonden e-mails:',

'plain_text' => 
'Platte Tekst',

'html' => 
'HTML',

'mail_format' => 
'E-mail Formaaat',

'text_formatting' => 
'Tekst Formaat',

'none' => 
'Geen',

'auto_br' => 
'Auto &lt;br /&gt;',

'xhtml' => 
'XHTML',

'wordwrap' => 
'Woord afbreking',

'priority' => 
'Prioriteit',

'attachment' => 
'Bijlage',

'attachment_problem' => 
'Er is een probleem met het toevoegen van uw bestand.',

'attachment_unavailable' => 
'Om bijlages te versturen dient u eerst een upload locatie aan te maken.',

'attachment_warning' => 
'Bijlages worden &lt;strong&gt;niet opgeslagen&lt;/strong&gt; door ExpressionEngine en moeten lokaal bewaard worden.',

'chars' => 
'tekens',

'highest' => 
'Hoogste',

'high' => 
'Hoog',

'normal' => 
'Normaal',

'low' => 
'Laag',

'lowest' => 
'Laagste',

'empty_form_fields' => 
'U heeft enkele velden leeg gelaten.',

'email_sent_message' => 
'Uw e-mail is verstuurd',

'all_email_sent_message' => 
'Alle e-mails zijn verstuurd',

'email_success' => 
'E-mail verstuurd',

'view_email_cache' => 
'Laat eerder verstuurde e-mails zien',

'previous_email' => 
'Eerder verstuurde e-mails',

'email_title' => 
'E-mail titel',

'email_date' => 
'Datum verzonden',

'total_recipients' => 
'Totaal aantal ontvangers',

'resend' => 
'Opnieuw versturen',

'view' => 
'Bekijk',

'no_cached_email' => 
'Er zijn geen opgeslagen e-mails',

'delete_emails' => 
'Verwijder e-mail',

'delete_confirm' => 
'Verwijder E-mail configuratie',

'delete_question' => 
'Weet u zeker dat u de geselecteerde e-mail(s) wilt verwijderen?',

'bad_cache_ids' => 
'Er zijn geen e-mails die aan de geselecteerde criteria voldoen',

'email_deleted' => 
'E-mail is verwijderd',

'mailinglist_unsubscribe' => 
'Om uw e-mailadres van onze mailinglist te verwijderden: klik hier:',

'mailinglist_unsubscribe_all' => 
'Om uw -mailadres van alle mailinglists te verwijdern, klik hier:',

'complete' => 
'Compleet',

'incomplete' => 
'Incompleet',

'finish_sending' => 
'Versturen afronden',

'on' => 
'Aan',

'off' => 
'Uit',

'translate' => 
'Update',

''=>''
);

// End of File