<?php
$lang = array(


'jquery_module_name' => 
'jQuery',

'jquery_module_description' => 
'jQuery Module',

'missing_jquery_file' => 
'Het opgevraagde jQuery bestand kan niet gevonden worden',

'translate' => 
'Update',

''=>''
);

// End of File