<?php
$lang = array(


'remember_me' => 
'Automatisch inloggen bij volgend bezoek?',

'no_username' => 
'De door u verzonden gebruikersnaam bestaat niet',

'no_password' => 
'Het door u verzonden wachtwoord bestaat niet.',

'no_email' => 
'U moet uw e-mail-adres invoeren.',

'credential_missmatch' => 
'Ongeldige gebruikersnaam of wachtwoord',

'multi_login_warning' => 
'Er is al iemand ingelogd met dit account.',

'return_to_login' => 
'Terug naar login',

'password_lockout_in_effect' => 
'U mag slechts proberen vier keer in te loggen binnen %x minuten ',

'unauthorized_request' => 
'U heeft geen toestemming deze taak uit te voeren',

'new_password_request' => 
'Nieuw Wachtwoord Aanvraag',

'session_auto_timeout' => 
'Uw sessie is verlopen door langdurige inactiviteit.',

'translate' => 
'Update',

''=>''
);

// End of File