<?php
$lang = array(


'msm_product_name' => 
'Meerdere Sites Beheer',

'msm_version' => 
'Versie:',

'msm_build_number' => 
'Build:',

'sites_administration' => 
'Sites Administratie',

'site_management' => 
'Site Management',

'site_id' => 
'Site ID',

'site_name' => 
'Site Korte Naam',

'site_label' => 
'Site Label',

'create_new_site' => 
'Cree&#235;r een nieuwe site',

'edit_site' => 
'Wijzig Site',

'site_description' => 
'Site Omschrijving',

'site_administration_set' => 
'Administratie Reeks',

'site_mailinglists_set' => 
'Mailing Lijsten Reeks',

'site_members_set' => 
'Leden Set',

'site_templates_set' => 
'Template Set',

'site_channels_set' => 
'Channel Set',

'no_site_name' => 
'Geen Site Naam',

'no_site_label' => 
'Geen Site Label',

'site_name_taken' => 
'Site Name Taken',

'new_set_missing_name' => 
'U mist een naam voor &#233;&#233;n van de nieuwe Sets.',

'site_created' => 
'Site aangemaakt',

'site_updated' => 
'Site Gewijzigd',

'unable_to_locate_specialty' => 
'Niet mogelijk om de betreffende Templates te vinden. Wees er zeker van dat alle taalbestanden zijn ge&#252;pload.',

'delete_site' => 
'Verwijder site',

'delete_site_confirmation' => 
'Wilt u deze site permanent verwijderen?',

'site_deleted' => 
'Site Verwijderd',

'set_management' => 
'Set Beheer',

'new_set' => 
'Nieuwe Set',

'edit_set' => 
'Wijzig Set',

'create_new_set' => 
'Cree&#235;r een nieuwe Set',

'set_created' => 
'Set aangemaakt',

'set_updated' => 
'Set Gewijzigd',

'delete_set' => 
'Verwijder Set',

'delete_set_confirmation' => 
'Weet u zeker dat u deze set wilt verwijderen?',

'set_deleted' => 
'Set Verwijderd',

'site_set_id' => 
'Set ID',

'site_set_name' => 
'Set Naam',

'site_set_type' => 
'Set Type',

'site_set_name_taken' => 
'Set Naam al in gebruik',

'move_data' => 
'Verplaats Data',

'do_nothing' => 
'Doe niets',

'move_options' => 
'Verplaats Opties',

'move_channel_move_data' => 
'Verplaats Data en Berichten',

'duplicate_channel_no_data' => 
'Dupliceer Channel, Dupliceer geen berichten',

'duplicate_channel_all_data' => 
'Dupliceer Channel en Dupliceer berichten',

'move_template_group' => 
'Verplaats Template Groep',

'duplicate_template_group' => 
'Dupliceer Template Groep',

'move_global_variables' => 
'Verplaats Globale Variabelen',

'duplicate_global_variables' => 
'Dupliceer Globale Variabelen',

'move_upload_destination' => 
'Verplaats Upload Bestemming',

'duplicate_upload_destination' => 
'Dupliceer Upload Bestemming',

'choose_site' => 
'Kies een site om naar over te schakelen',

'switch_site' => 
'Wissel van Site',

'timeout_warning' => 
'Dupliceren van een grote hoeveelheid data kan een intensief proces zijn en kan er voor zorgen dat u tegen de beperkingen van uw servercapaciteit aanloopt m.b.t. uitvoeren van scripts en geheugen wat er voor zorgt dat u data kan verliezen. Maak altijd een back-up voordat u begint met dupliceren. Mocht u tegen problemen aanlopen, neem dan contact op met uw host om te kijken of hij de server capaciteit kan verhogen om deze actie wel uit te kunnen voeren.',

'translate' => 
'Update',

''=>''
);

// End of File