<?php
$lang = array(


'updated_sites_module_name' => 
'Ge&#252;pdate Sites',

'updated_sites_module_description' => 
'Sta toe anderen jou site te pingen',

'updated_sites_home' => 
'Control Panel',

'unauthorized_action' => 
'Je bent niet geauthoriseerd deze actie uit te voeren',

'too_many_pings' => 
'Ping niet geaccepteerd. Je hebt al gepingd in de afgelopen %X minuten.',

'invalid_access' => 
'Ongeldige Toegang',

'updated_sites_configurations' => 
'Ge&#252;pdate Sites Configuratie',

'updated_sites_config_name' => 
'Naam',

'updated_sites_short_name' => 
'Korte Naam',

'updated_sites_short_name_taken' => 
'Deze Korte naam is al in gebruik',

'single_word_no_spaces' => 
'Engel Woord, geen spaties',

'updated_sites_config_url' => 
'URL',

'no_ping_configs' => 
'Er zijn op dit moment geen Ge&#252;pdate Sites configuraties',

'updated_sites_delete_confirm' => 
'Verwijder Ge&#252;pdate Sites configuraties',

'updated_sites_deleted' => 
'Ge&#252;pdate Sites Configuraties Verwijderd',

'updated_site_deleted' => 
'Ge&#252;pdate Sites configuratie Verwijderd',

'metaweblogs_deleted' => 
'Ge&#252;pdate Sites Configuraties Verwijderd',

'updated_sites_delete_question' => 
'Weet u zeker dat u de geselecteerde Ge&#252;pdate Sites configuratie(s) wilt verwijderen?',

'delete' => 
'Verwijder',

'updated_sites_missing_fields' => 
'Een veld is leeg gelaten, vul het in en voeg opnieuw toe.',

'new_config' => 
'Nieuwe Configuratie',

'modify_config' => 
'Wijzig Configuratie',

'configuration_options' => 
'Configuratie Opties',

'updated_sites_pref_name' => 
'Configuratie Naam',

'updated_sites_allowed' => 
'Sites die mogen Pingen',

'updated_sites_allowed_subtext' => 
'Om een site u te laten pingen, moet een deel van hun url, bijvoorbeeld hun domeinnaam, in deze lijst voorkomen. Scheidt meerdere sites met een nieuwe regel.',

'updated_sites_prune' => 
'Maximum aantal pings die bewaard moeten worden?',

'configuration_created' => 
'Configuratie gemaakt',

'configuration_updated' => 
'Configuratie Ge&#252;pdatet',

'updated_sites_create_new' => 
'Maak een nieuwe Configuratie',

'successful_ping' => 
'Ping Succesvol ontvangen!',

'view_pings' => 
'Bekijk Pings',

'no_pings' => 
'Geen Pings',

'total_pings' => 
'Totaal aantal Pings',

'ping_name' => 
'Site Naam',

'ping_url' => 
'Site URL',

'ping_rss' => 
'Site RSS',

'ping_date' => 
'Ping Datum',

'delete_pings_confirm' => 
'Verwijder Pings Bevestiging',

'ping_delete_question' => 
'Weet u zeker dat u de geselecteerde ping(s) wilt verwijderen?',

'pings_deleted' => 
'Pings Verwijderd',

'preference' => 
'Voorkeur',

'setting' => 
'Instelling',

'translate' => 
'Update',

''=>''
);

// End of File