<?php
$lang = array(


'content_files' => 
'Bestanden',

'file_module_name' => 
'Bestand',

'file_module_description' => 
'Bestandsmodule',

'translate' => 
'Update',

''=>''
);

// End of File