<?php
$lang = array(


'expressionengine_info' => 
'ExpressionEngine Info',

'resources' => 
'Bronnen',

'documentation' => 
'Handleiding',

'support_resources' => 
'Technische Support',

'downloads' => 
'Mijn ExpressionEngine Downloads',

'running_current' => 
'U draait op de laatste versie van ExpressionEngine: Versie %v',

'version_update_available' => 
'Een nieuwere versie van ExpressioneEngine is beschikbaar',

'version_update_inst' => 
'Download de laatste versie <a href=\'%d\' title=\'Download Hier\'>hier</a> en volg de <a href=\'%i\' title=\'Versie Update Documentatie\'>Versie Update Instructie</a>.',

'current_version' => 
'Laatste: %v',

'installed_version' => 
'Ge&#239;nstalleerd: %v',

'version_and_build' => 
'Huidige versie',

'error_getting_version' => 
'U gebruikt ExpressionEngine %v. Op dit moment is het niet mogelijk te controleren of een nieuwere versie beschikbaar is.',

'translate' => 
'Update',

''=>''
);

// End of File