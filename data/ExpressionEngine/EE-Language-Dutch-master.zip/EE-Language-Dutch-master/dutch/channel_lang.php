<?php
$lang = array(


'channel_module_name' => 
'Channel',

'channel_module_description' => 
'Channel module',

'channel_no_preview_template' => 
'Een voorbeeld template is niet gespecificeerd in uw tag',

'channel_must_be_logged_in' => 
'U moet een ingelogd lid zijn om deze actie uit te kunnen voeren',

'channel_not_specified' => 
'U moet een channel kiezen om dit formulier te kunnen gebruiken',

'channel_no_action_found' => 
'Onmogelijk om de bronnen te laden die nodig zijn om dit formulier te maken',

'translate' => 
'Update',

''=>''
);

// End of File