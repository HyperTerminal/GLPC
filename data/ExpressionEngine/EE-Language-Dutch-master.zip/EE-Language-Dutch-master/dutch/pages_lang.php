<?php
$lang = array(


'pages_module_name' => 
'Pages',

'pages_module_description' => 
'Gebruikt Weblog Berichten om Statische pagina&#39;s te maken',

'pages_homepage' => 
'Pages Homepage',

'page' => 
'Page',

'pages_uri' => 
'Pages URI',

'no_pages' => 
'Er bestaan nog geen Pages',

'create_page' => 
'Maak Nieuwe Page',

'page_name' => 
'Page Naam',

'edit_page' => 
'Wijzig Page',

'view_page' => 
'Bekijk Page',

'page_settings' => 
'Page Instellingen',

'none' => 
'Geen',

'template' => 
'Template',

'parent_page' => 
'Hoofd Pagina',

'channel_entry' => 
'Channel Bericht',

'choose_entry' => 
'Kies Bericht',

'pages_delete_confirm' => 
'Verwijder Pages',

'pages_delete_question' => 
'Weet u zeker dat u de geselecteerde pagina URI(s) wil verwijderen?<br /><em>Let Op: Een Page verwijderen verwijdert alleen de URL. Het bericht wordt niet verwijderd.</em>',

'page_deleted' => 
'Page Verwijderd',

'pages_deleted' => 
'Pages Verwijderd',

'create_entry' => 
'Maak Bericht',

'choose_template' => 
'Kies Template voor tonen van Page',

'invalid_page_name' => 
'Ongeldige Page Naam Ingevoerd',

'invalid_template' => 
'U moet een geldig template invoeren om deze page te tonen.',

'page_created' => 
'Page Aangemaakt',

'page_updated' => 
'Page ge',

'invalid_page_uri' => 
'Ongeldige Page URI',

'invalid_page_num_segs' => 
'U heeft het maximaal aantal URI segementen bereikt in de pages URL',

'pages_configuration' => 
'Module Configuratie',

'preference_name' => 
'Voorkeur Naam',

'preference_value' => 
'Voorkeur Waarde',

'default_template' => 
'Standaard Template',

'default_for_page_creation' => 
'Standaard channel voor &#39;Maak Nieuwe Page&#39; Tab',

'no_default' => 
'Geen Standaard',

'configuration_updated' => 
'Configuratie Gewijzigd',

'duplicate_page_uri' => 
'Dupliceer Page URI',

'pages_display_on_homepage' => 
'Laten zien van URIs op de Module Homepage',

'nested' => 
'Genest',

'not_nested' => 
'Niet Genest',

'preference' => 
'Voorkeur',

'setting' => 
'Instelling',

'example_uri' => 
'/example/pages/uri/',

'translate' => 
'Update',

''=>''
);

// End of File