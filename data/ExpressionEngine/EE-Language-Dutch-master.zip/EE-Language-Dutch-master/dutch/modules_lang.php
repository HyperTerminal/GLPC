<?php
$lang = array(


'module_name' => 
'Module Naam',

'module_description' => 
'Beschrijving',

'data_will_be_lost' => 
'Alle data geassocieerd met deze module zal permanent verwijderd worden!',

'module_access' => 
'Module Wijzigen',

'module_no_access' => 
'U ben niet gemachtigd om toegang te krijgen tot de modules',

'delete_module' => 
'Verwijder Module',

'delete_module_confirm' => 
'Weet u zeker dat u de volgende module wilt verwijderen:',

'module_backend' => 
'Gebruikers CP',

'module_version' => 
'Versie',

'module_status' => 
'Status',

'module_action' => 
'Actie',

'not_installed' => 
'Niet ge&#239;nstalleerd',

'installed' => 
'Ge&#239;nstalleerd',

'install' => 
'Installeren',

'update_modules' => 
'Module Update Uitvoeren',

'updated' => 
'Ge&#252;pdatet',

'updated_to_version' => 
'ge&#252;pdate naar versie',

'all_modules_up_to_date' => 
'Alle modules zijn up-to-date',

'deinstall' => 
'Verwijderen',

'module_can_not_be_found' => 
'Kan de bestanden niet vinden die nodig zijn om deze module te installeren',

'module_has_been_installed' => 
'Ge&#239;nstalleerde modules:',

'module_has_been_removed' => 
'Verwijderde modules:',

'requested_module_not_installed' => 
'De aangevraagde module is niet ge&#239;nstalleerd.',

'requested_page_not_found' => 
'De aangevraagde module pagina kan niet gevonden worden.',

'translate' => 
'Update',

''=>''
);

// End of File