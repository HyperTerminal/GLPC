<?php
$lang = array(


'blacklist_module_name' => 
'Blacklist/Whitelist',

'blacklist_module_description' => 
'Blacklist en whitelist module',

'htaccess_written_successfully' => 
'Het .htaccess bestand is succesvol geschreven',

'invalid_htaccess_path' => 
'Ongeldig pad of permissie voor het .htaccess bestand',

'htaccess_server_path' => 
'Server pad voor het .htaccess bestand',

'write_htaccess_file' => 
'Schrijf Blacklist naar het .htaccess bestand?',

'whitelist' => 
'Whitelist',

'ee_whitelist' => 
'Download ExpressionEngine.com Whitelist',

'whitelist_updated' => 
'Whitelist succesvol gewijzigd',

'ref_whitelist_irretrievable' => 
'Error: De nieuwe whitelist is verloren gegaan',

'ref_view_whitelist' => 
'Bekijk Whitelist',

'ref_no_whitelist' => 
'Er staat momenteel niets op de Whitelist',

'ref_whitelisted' => 
'Toegevoegd aan Whitelist',

'ref_no_whitelist_table' => 
'Whitelist database tabel bestaat niet',

'ref_type' => 
'Item Type',

'blacklist' => 
'Blacklist',

'ee_blacklist' => 
'Download ExpressionEngine.com Blacklist',

'requires_license_number' => 
'Licentie Nummer in Algemene Configuratie nodig',

'blacklist_updated' => 
'Blacklist succesvol gewijzigd',

'ref_no_license' => 
'Error: Geen licentienummer',

'ref_blacklist_irretrievable' => 
'Error: De nieuwe blacklist is verloren gegaan',

'ref_view_blacklist' => 
'Bekijk Blacklist',

'ref_no_blacklist' => 
'Er staat op dit moment niets op de blacklist',

'ref_ip' => 
'IP Address',

'ref_user_agent' => 
'User Agent',

'ref_url' => 
'URL',

'ref_blacklisted' => 
'Op de Blacklist',

'ref_no_blacklist_table' => 
'Blacklist database tabel bestaat niet',

'translate' => 
'Update',

''=>''
);

// End of File