<?php
$lang = array(


'sql_info' => 
'SQL Informatie',

'sql_utilities' => 
'SQL Utilities',

'database_type' => 
'Database Type',

'sql_version' => 
'Database Versie',

'database_size' => 
'Database Grootte',

'database_uptime' => 
'Database Uptime',

'total_queries' => 
'Totaal aantal server queries sinds opstarten',

'sql_status' => 
'Status Informatie',

'sql_system_vars' => 
'Systeem Variabelen',

'sql_processlist' => 
'Lijst van Processen ',

'sql_query_form' => 
'Database Query Formulier',

'query_result' => 
'Query Resultaat',

'query' => 
'SQL Query',

'total_results' => 
'Totaal aantal Resultaten: %x',

'total_affected_rows' => 
'Totaal aantal Be&#239;nvloede rijen: ',

'browse' => 
'Doorzoeken',

'tables' => 
'tabellen',

'table_name' => 
'Tabelnaam',

'records' => 
'Database Records',

'size' => 
'Grootte',

'type' => 
'Type',

'analyze' => 
'Analyseer Tabellen',

'optimize' => 
'Optimaliseer SQL Tabellen',

'repair' => 
'Repareer SQL Tabellen',

'optimize_table' => 
'Optimaliseer geselecteerde tabellen',

'repair_table' => 
'Repareer geselecteerde tabellen',

'no_buttons_selected' => 
'U moet de tabellen selecteren waarin deze actie doorgevoerd moet worden',

'sql_view_database' => 
'Beheer Database Tabellen',

'sql_no_result' => 
'Er zijn geen resultaten gevonden voor deze zoekopdracht',

'sql_not_allowed' => 
'Sorry, maar dit is geen toegestane zoekopdracht',

'sql_query_instructions' => 
'Gebruik dit formulier om een SQL query door te voeren',

'sql_query_debug' => 
'MySQL Error Output inschakelen',

'sql_good_query' => 
'Uw query is succesvol uitgevoerd',

'cache_deleted' => 
'Cache bestanden zijn verwijderd',

'site_preferences' => 
'Site Voorkeuren',

'channel_entry_title' => 
'Channel Bericht Titels',

'channel_fields' => 
'Channel Velden',

'templates' => 
'In ALLE Templates',

'template_groups' => 
'Template Groupen',

'rows_replaced' => 
'Aantal database records waarin vervangen zal worden:',

'choose_below' => 
'(Kies uit de volgende)',

'if_replacing_templates' => 
'Als u binnen templates gaat vervangen, <a href="%x">synchroniseer eerst met de database</a>, of',

'permanent_data_loss' => 
'permanent dataverlies kan optreden!',

'recalculate' => 
'Statistieken hertellen',

'do_recount' => 
'Hertelling Uitvoeren',

'source' => 
'Bron',

'recount_info' => 
'De links hieronder geven je de mogelijkheid  om diverse statistieken te updaten. Bijv: hoeveel berichten elk lid heeft toegevoegd.',

'members' => 
'Leden',

'channel_titles' => 
'Channel Berichten',

'site_statistics' => 
'Site Statistieken',

'forums' => 
'Forums',

'forum_topics' => 
'Forum Topics',

'recount_completed' => 
'Hertelling Compleet',

'recount_prefs' => 
'Hertel Voorkeuren',

'translate' => 
'Update',

''=>''
);

// End of File