<?php
$lang = array(


'email_module_name' => 
'E-mail',

'email_module_description' => 
'Gebruikers E-mail Module',

'message_required' => 
'E-mail Bericht is Verplicht',

'em_banned_from_email' => 
'Het e-mailadres van de geadresseerde is gebanned.',

'em_banned_recipient' => 
'E&#233;n of meer van de ingevoerde e-mailadressen is gebanned.',

'em_invalid_recipient' => 
'E&#233;n of meer van de ingevoerde e-mailadressen is onjuist',

'em_no_valid_recipients' => 
'Uw e-mail heeft geen geldige ontvanger.',

'em_sender_required' => 
'Een geldig afzender e-mailadres is verplicht',

'em_unauthorized_request' => 
'U bent niet geauthoriseerd om deze actie uit te voeren',

'em_limit_exceeded' => 
'U heeft u maximaal aantal te versturen e-mail berichten voor vandaag bereikt.',

'em_interval_warning' => 
'U kunt niet vaker dan iedere %s seconden een e-mail te versturen',

'em_email_sent' => 
'Uw e-mail is verstuurd.',

'email_must_be_array' => 
'De e-mail validatie methode moet de array passeren',

'email_invalid_address' => 
'Ongeldig e-mailadres: %s',

'email_attachment_missing' => 
'Niet mogelijk de volgende e-mail bijlage te localiseren: %s',

'email_attachment_unreadable' => 
'Niet mogelijk de bijlage te openen: %s',

'email_no_recipients' => 
'U moet een ontvanger invoeren in: Aan, CC of Bcc',

'email_send_failure_phpmail' => 
'Niet mogelijk e-mail te versturen via PHP mail(). Uw server is misschien niet geconfigureerd om e-mail te versturen via deze methode.',

'email_send_failure_sendmail' => 
'Niet mogelijk e-mail te versturen via PHP Sendmail. Uw server is misschien niet geconfigureerd om e-mail te versturen via deze methode.',

'email_send_failure_smtp' => 
'Niet mogelijk e-mail te versturen via PHP SMTP. Uw server is misschien niet geconfigureerd om e-mail te versturen via deze methode.',

'email_sent' => 
'Uw bericht is succesvol versturen via het volgende protocol: %s',

'email_no_socket' => 
'Niet mogelijk een socket naar Sendmail te openen. Controleer uw instellingen.',

'email_no_hostname' => 
'U heeft geen SMTP hostname gespecificeerd',

'email_smtp_error' => 
'De volgende SMTP error is opgetreden: %s',

'email_no_smtp_unpw' => 
'Fout: U moet een SMTP gebruikersnaam en wachtwoord instellen.',

'email_failed_smtp_login' => 
'Niet mogelijk een AUTH LOGIN commando te sturen. Fout: %s',

'email_smtp_auth_un' => 
'Niet mogelijk uw gebruikersnaam te controleren. Fout: %s',

'email_smtp_auth_pw' => 
'Niet mogelijk uw wachtwoord te controleren. Fout: %s',

'email_smtp_data_failure' => 
'Niet mogelijk data te versturen: %s',

'email_exit_status' => 
'Exit status code: %s',

'translate' => 
'Update',

''=>''
);

// End of File