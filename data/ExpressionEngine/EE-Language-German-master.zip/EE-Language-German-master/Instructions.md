Deutsches Sprachpaket für ExpressionEngine 2.6.1
inkl. der CodeIgniter Sprachfiles

Letzte Korrekturen: 17.07.2013

Inhalt vom Verzeichnis /system in das Verzeichnis /system Ihrer
Installation kopieren.

Die ExpressionEngine-Sprachdateien liegen in

    /system/expressionengine/language/deutsch

Die Codeigniter Sprachdateien liegen in

    /system/codeigniter/system/language/deutsch