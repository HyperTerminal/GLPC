<?php
$lang = array(


'file_browser' => 
'Datei Browser',

'view' => 
'Zeigen',

'path_does_not_exist' => 
'Der angegebene Pfad existiert nicht',

'file_viewing_error' => 
'Ein unbekannter Fehler ist aufgetreten.',

'fp_no_files' => 
'Keine Dateien im Verzeichnis',

'fb_view_images' => 
'Bilder zeigen',

'fb_view_image' => 
'Bild zeigen',

'fb_insert_file' => 
'Datei einfügen',

'fb_insert_files' => 
'Dateien einfügen',

'fb_select_field' => 
'Feld wählen',

'fb_select_files' => 
'Felder wählen',

'fb_non_images' => 
'* Bezeichnet Nicht-Bilder. Nur Bilder können angezeigt werden.',

'fb_insert_link' => 
'Link einfügen',

'fb_insert_links' => 
'Links einfügen',

'fb_insert_url' => 
'URL einfügen',

'fb_insert_urls' => 
'URLs einfügen',

'translate' => 
'Update',

''=>''
);

// End of File