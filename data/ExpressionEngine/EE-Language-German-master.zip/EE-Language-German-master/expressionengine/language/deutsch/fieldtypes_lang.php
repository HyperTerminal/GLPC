<?php
$lang = array(


'add_file' => 
'Datei anfügen',

'remove_file' => 
'Datei löschen',

'file_undo_remove' => 
'Löschen wiederherstellen',

'directory_no_access' => 
'Sie haben keinen Zugriff auf das Verzeichnis das diesem Feld zugeteilt wurde',

'directory' => 
'Verzeichnis:',

'rel_ft_options' => 
'Beziehungsfeld Optionen',

'rel_ft_configure' => 
'Beziehungen konfigurieren',

'rel_ft_configure_subtext' => 
'Zu welchem Inhalt wollen Sie einen Bezug?',

'rel_ft_channels' => 
'Channel für den Bezug wählen',

'rel_ft_include' => 
'In die Wahl einschliessen',

'rel_ft_include_expired' => 
'Abgelaufene Einträge?',

'rel_ft_include_future' => 
'Zukünftige Einträge?',

'rel_ft_categories' => 
'Begrenze Einträge auf Kategorie',

'rel_ft_authors' => 
'Begrenze Einträge auf Autor',

'rel_ft_statuses' => 
'Begrenze Einträge auf Status',

'rel_ft_limit_left' => 
'Begrenze Einträge auf',

'rel_ft_limit_right' => 
'gefundene',

'rel_ft_limit_subtext' => 
'leer lassen um ALLE Einträge zuzulassen',

'rel_ft_order' => 
'Ordne Einträge nach',

'rel_ft_order_title' => 
'Eintragstitel',

'rel_ft_order_date' => 
'Eintragsdatum',

'rel_ft_order_in' => 
'in',

'rel_ft_order_asc' => 
'aufsteigender Folge',

'rel_ft_order_desc' => 
'bbsteigender Folge',

'rel_ft_allow_multi' => 
'Mehrfachbeziehungen erlauben?',

'rel_ft_allow_multi_subtext' => 
'Autoren werden mehr als einen Eintrag für die Beziehung auswählen können',

'file_ft_options' => 
'File Feld-Optionen',

'file_ft_configure' => 
'Allgemeine Feld-Optionen',

'file_ft_configure_subtext' => 
'Weitere Angabe wie das Feld sich verhalten soll',

'file_ft_content_type' => 
'Erlaubte Dateitypen',

'file_ft_allowed_dirs' => 
'Erlaubte Verzeichnisse',

'file_ft_configure_frontend' => 
'Frontend Optionen',

'file_ft_configure_frontend_subtext' => 
'Ändere das verhalten wenn in einem {channel:form} Tag',

'file_ft_show_files' => 
'Zeige bestehende Dateien?',

'file_ft_show_files_subtext' => 
'Autoren können eine bestehende Datei aus einem Dropdown wählen',

'file_ft_limit_left' => 
'Begrenze Dateien auf',

'file_ft_limit_right' => 
'gefundene',

'file_ft_limit_files_subtext' => 
'Leer lassen um ALLE zu zeigen',

'file_ft_select_existing' => 
'Wähle eine bestehende Datei',

'grid_options' => 
'Grid-Feld Optionen',

'grid_min_rows' => 
'Minimum Zeilen',

'grid_min_rows_desc' => 
'Das Minimum an Daten-Zeilen für dieses Grid',

'grid_max_rows' => 
'Maximum Zeilen',

'grid_max_rows_desc' => 
'Das Maximum an Daten-Zeilen für dieses Grid',

'grid_config' => 
'Konfiguriere Grid',

'grid_config_desc' => 
'Welche Daten werden gesammelt',

'grid_col_type' => 
'Datentyp',

'grid_col_label' => 
'Label',

'grid_col_name' => 
'Feldname',

'grid_col_instr' => 
'Anweisungen',

'grid_col_options' => 
'Ist das Feld ...',

'grid_col_width' => 
'Spaltenbreite',

'grid_col_width_percent' => 
'Prozent',

'grid_col_required' => 
'bedingt?',

'grid_col_searchable' => 
'durchsuchbar?',

'grid_show_fmt_btns' => 
'Zeige Formatierungs-Buttons',

'grid_output_format' => 
'Ausgabe-Formatierung?',

'grid_text_direction' => 
'Schreibrichtung?',

'grid_limit_input' => 
'Begrenze Eingabe',

'grid_date_localized' => 
'Lokalisiert',

'grid_chars_allowed' => 
'Zeichen erlaubt',

'grid_order_by' => 
'Sortierung nach',

'grid_show' => 
'Zeige',

'grid_col_label_required' => 
'Eine oder mehrere Spalten haben kein Label.',

'grid_col_name_required' => 
'Eine oder mehrere Spalten haben keinen Namen.',

'grid_col_name_reserved' => 
'Eine oder mehrere Spalten haben einen Namen der für andere Template-Funktionalität Verwendung findet.',

'grid_duplicate_col_name' => 
'Spaltenname muss einmalig sein.',

'grid_numeric_percentage' => 
'Spalte muss numerisch sein',

'grid_invalid_column_name' => 
'Spaltennamen nur mit alphanumerischen Zeichen und ohne Zeichenabstand.',

'grid_add_some_data' => 
'Sie haben noch keine Zeilen eingefügt. <a href="#" class="grid_link_add">Daten eingeben?</a>',

'grid_add_row' => 
'Zeile anfügen',

'grid_add_column' => 
'Spalte anfügen',

'grid_delete_row' => 
'Zeile löschen',

'grid_delete_column' => 
'Spalte löschen',

'grid_copy_column' => 
'Copy',

'grid_validation_error' => 
'Es gab ein Problem mit einem oder mehreren Grid-Feldern',

'grid_field_required' => 
'Dieses Feld bitte ausfüllen',

'translate' => 
'Update',

''=>''
);

// End of File