<?php
$lang = array(


'channel_module_name' => 
'Channel',

'channel_module_description' => 
'Channel Modul',

'channel_no_preview_template' => 
'Ein Vorschau-Template ist im Tag nicht angegeben',

'channel_must_be_logged_in' => 
'Sie müssen ein eingeloggtes Mitglied auf dieser Site sein, um diese Aktion ausführen zu können.',

'channel_not_specified' => 
'Es muss ein Channel angegeben werden, um das Eingabeformular zu nutzen.',

'channel_no_action_found' => 
'Die benötigten Ressourcen zum Erstellen des Eingabeformulars konnten nicht geladen werden',

'translate' => 
'Update',

''=>''
);

// End of File