<?php
$lang = array(


'emoticon_module_name' => 
'Emoticon',

'emoticon_module_description' => 
'Emoticon (Smiley) Modul',

'emoticon_heading' => 
'Emoticons',

'emoticon_glyph' => 
'Glyphe',

'emoticon_image' => 
'Bild',

'emoticon_width' => 
'Breite',

'emoticon_height' => 
'Höhe',

'emoticon_alt' => 
'Alt Tag',

'translate' => 
'Update',

''=>''
);

// End of File