<?php
$lang = array(


'expressionengine_info' => 
'ExpressionEngine Info',

'resources' => 
'Ressourcen',

'documentation' => 
'Online Dokumentation',

'support_resources' => 
'Support Ressourcen',

'downloads' => 
'Meine ExpressionEngine Store Downloads',

'running_current' => 
'Sie arbeiten mit der aktuellen Version von ExpressionEngine: Version %v Build %b',

'version_update_available' => 
'Eine neuere Version von ExpressionEngine ist erhältlich!',

'version_update_inst' => 
'Bitte downloaden Sie die <a class="update" href=\\\'%d\\\' title=\\\'Download hier\\\'>aktuellste Version</a> und folgen Sie den <a class="update" href=\\\'%i\\\' title=\\\'Version Update Instruktionen\\\'>Version Update Instruktionen</a>.',

'current_version' => 
'Aktuell: %v Build %b',

'installed_version' => 
'Installiert: %v Build %b',

'version_and_build' => 
'Version und Build',

'error_getting_version' => 
'Sie arbeiten mit ExpressionEngine %v Build %b. Die aktuellste Versionnummer kann im Moment nicht ermittelt werden.',

'translate' => 
'Update',

''=>''
);

// End of File