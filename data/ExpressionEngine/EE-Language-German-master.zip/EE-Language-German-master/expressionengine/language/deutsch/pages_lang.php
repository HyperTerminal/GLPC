<?php
$lang = array(


'pages_module_name' => 
'Seiten (Pages)',

'pages_module_description' => 
'Nutz Channel-Einträge um statische Seiten zu erzeugen',

'pages_homepage' => 
'Seiten Homepage',

'page' => 
'Seiten',

'pages_uri' => 
'Seiten URI',

'no_pages' => 
'Es bestehen noch keine Seiten',

'create_page' => 
'Neue Seite erstellen',

'page_name' => 
'Seiten-Name',

'edit_page' => 
'Seite bearbeiten',

'view_page' => 
'Seite zeigen',

'page_settings' => 
'Seite-Einstellungen',

'none' => 
'Keine',

'template' => 
'Template',

'parent_page' => 
'Eltern-Seite',

'channel_entry' => 
'Channel Eintrag',

'choose_entry' => 
'Eintrag wählen',

'pages_delete_confirm' => 
'Seiten löschen',

'pages_delete_question' => 
'Wollen Sie wirklich den gewählten Seiten URI löschen?&lt;br /&gt;&lt;em&gt;Hinweis: Eine Seite löschen, löscht nur den URL. Der Eintrag wird nicht gelöscht&lt;/em&gt;',

'page_deleted' => 
'Seite gelöscht',

'pages_deleted' => 
'Seiten gelöscht',

'create_entry' => 
'Eintrag erstellen',

'choose_template' => 
'Template für die Anzeige der Seite wählen',

'invalid_page_name' => 
'Ungültiger Seiten-Name angegeben',

'invalid_template' => 
'Es muss ein gültiges Template zur Anzeige der Seite gewählt werden',

'page_created' => 
'Seite erstellt',

'page_updated' => 
'Seite aktualisiert',

'invalid_page_uri' => 
'Ungültiger Seiten-URI',

'invalid_page_num_segs' => 
'Sie haben bei den Seiten URL die Anzahl möglicher URI -Segmente überschritten',

'pages_configuration' => 
'Modul Konfiguration',

'preference_name' => 
'Voreingestellter Name',

'preference_value' => 
'Voreingestellter Wert',

'default_template' => 
'Standard Template',

'default_for_page_creation' => 
'Standard Channel für &#39;Neue Seite erstellen&#39; Tab',

'no_default' => 
'Kein Standard',

'configuration_updated' => 
'Konfiguration aktualisiert',

'duplicate_page_uri' => 
'Dupliziere Seiten URI',

'pages_display_on_homepage' => 
'Anzeige von URIs auf der Modul-Homepage',

'nested' => 
'Verschachtelt',

'not_nested' => 
'Nicht verschachtelt',

'preference' => 
'Voreinstellung',

'setting' => 
'Einstellung',

'example_uri' => 
'/beispiel/pages/uri/',

'translate' => 
'Update',

''=>''
);

// End of File