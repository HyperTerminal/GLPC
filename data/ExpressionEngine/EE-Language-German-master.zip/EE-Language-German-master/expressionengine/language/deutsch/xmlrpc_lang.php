<?php
$lang = array(


'invalid_license' => 
'Ungültige Lizenz',

'translate' => 
'Update',

''=>''
);

// End of File