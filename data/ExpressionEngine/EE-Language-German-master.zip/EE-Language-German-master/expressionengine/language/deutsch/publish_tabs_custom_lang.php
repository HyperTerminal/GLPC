<?php
$lang = array(


'eeof_example' => 
'Beispiel Tag!',

'translate' => 
'Update',

''=>''
);

// End of File