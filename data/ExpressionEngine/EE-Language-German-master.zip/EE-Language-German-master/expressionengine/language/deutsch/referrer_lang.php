<?php
$lang = array(


'referrer_module_name' => 
'Referrer',

'referrer_module_description' => 
'Referrer-Tracking Modul',

'referrer_preferences' => 
'Referrer Einstellungen',

'referrer_ip' => 
'Referrer IP',

'referrer_date' => 
'Referrer Datum',

'ref_ip' => 
'IP Adresse',

'ref_user_agent' => 
'User Agent',

'ref_url' => 
'URL',

'ref_type' => 
'Typ',

'referrers' => 
'Referrers',

'view_referrers' => 
'Referrers zeigen',

'clear_referrers' => 
'Referrers löschen',

'referrer_from' => 
'Referrer von',

'referrer_to' => 
'Referrer nach',

'no_referrers' => 
'Im Moment hat es keine Referrers',

'referrer_no_results' => 
'Es gibt keine Ergebnisse, die auf die eingegebenen Kriterien passen',

'total_referrers' => 
'Total Referrers:',

'save_instructions' => 
'Wieviele der neuesten Referrers wollen Sie speichern?',

'referrers_deleted' => 
'Referrers wurden gelöscht.',

'referrer_deleted' => 
'Referrers wurden gelöscht.',

'delete_confirm' => 
'Löschen bestätigen',

'referrer_delete_question' => 
'Wollen Sie wirklich die ausgewählten Referrers löschen?',

'blacklist_question' => 
'Zusätzlich zum Löschen dieser Referrers',

'add_urls' => 
'Andere Referrers mit selbem URL löschen?',

'add_and_blacklist_urls' => 
'URLs in die Blacklist schreiben und anderer Referrers mit selbem URL löschen?',

'add_ips' => 
'Andere Referrers mit selbem URL löschen?',

'add_and_blacklist_ips' => 
'IP Adresse in die Blacklist schreiben und andere Referrers mit gleichem URL löschen?',

'add_agents' => 
'Andere Referrers mit gleichem User Agent löschen?',

'add_and_blacklist_agents' => 
'User Agent in die Blacklist schreiben und andere Referrers mit gleichem User Agent löschen?',

'translate' => 
'Update',

''=>''
);

// End of File