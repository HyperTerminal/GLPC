<?php
$lang = array(


'content_files' => 
'Dateien',

'file_module_name' => 
'Datei',

'file_module_description' => 
'Datei-Modul',

'translate' => 
'Update',

''=>''
);

// End of File