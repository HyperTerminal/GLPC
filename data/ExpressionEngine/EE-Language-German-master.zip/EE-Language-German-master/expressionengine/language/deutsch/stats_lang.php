<?php
$lang = array(


'stats_module_name' => 
'Statistiken',

'stats_module_description' => 
'Statistik-Modul',

'translate' => 
'Update',

''=>''
);

// End of File