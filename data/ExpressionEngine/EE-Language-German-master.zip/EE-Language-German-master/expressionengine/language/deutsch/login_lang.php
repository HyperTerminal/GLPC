<?php
$lang = array(


'remember_me' => 
'Auto-Login in Zukunft?',

'no_username' => 
'Der Username ist erforderlich.',

'no_password' => 
'Das Passwort ist erforderlich.',

'no_email' => 
'Sie müssen Ihre E-Mail-Adresse angeben.',

'credential_missmatch' => 
'Username oder Passwort ungültig',

'multi_login_warning' => 
'Jemand ist schon eingeloggt und nutzt dieses Konto.',

'return_to_login' => 
'Zurück zum Login.',

'password_lockout_in_effect' => 
'Es darf innerhalb von %d Minuten nur vier Mal ein Login versucht werden',

'unauthorized_request' => 
'Sie haben keine Berechtigung zum Ausführen dieser Aktion',

'new_password_request' => 
'Neues Passwort Anfrage',

'session_auto_timeout' => 
'Ihre Session ist wegen Inaktivität abgelaufen',

'forgotten_password' => 
'Passwort zurücksetzen',

'no_reset_id' => 
'Die angegebene ID-Nummer scheint ungültig zu sein. Überprüfen Sie den Link, dem Sie gefolgt waren.',

'id_not_found' => 
'Die angegebene Codenummer wurde in der Datenbank nicht gefunden.',

'password_changed' => 
'Passwort erfolgreich geändert',

'successfully_changed_password' => 
'Sie haben Ihr Passwort erfolgreich geändert. Bitte loggen Sie sich mit dem neuen Passwort ein.',

'new_password' => 
'Neues Passwort',

'new_password_confirm' => 
'Neues Passwort bestätigen',

'enter_new_password' => 
'Ein neues Passwort eingeben',

'translate' => 
'Update',

''=>''
);

// End of File