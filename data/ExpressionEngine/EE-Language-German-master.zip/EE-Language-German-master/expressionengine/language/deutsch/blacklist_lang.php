<?php
$lang = array(


'blacklist_module_name' => 
'Blacklist/Whitelist',

'blacklist_module_description' => 
'Blacklist und Whitelist Modul',

'htaccess_written_successfully' => 
'Die .htaccess-Datei wurde erfolgreich geschrieben',

'invalid_htaccess_path' => 
'Ungültiger Pfad oder Erlaubnis für .htaccess Datei',

'htaccess_server_path' => 
'Serverpfad für .htaccess Datei',

'write_htaccess_file' => 
'Blacklist in .htaccess-Datei schreiben?',

'whitelist' => 
'Whitelist',

'ee_whitelist' => 
'Whitelist von ExpressionEngine.com downloaden',

'whitelist_updated' => 
'Whitelist erfolgreich aktualisiert',

'ref_whitelist_irretrievable' => 
'Fehler: Neue Whitelist konnte nicht geladen werden',

'ref_view_whitelist' => 
'Whitelist zeigen',

'ref_no_whitelist' => 
'Im Moment steht nichts in der Whitelist',

'ref_whitelisted' => 
'Auf der Whitelist',

'ref_no_whitelist_table' => 
'Whitelist-Datenbanktabelle existiert nicht',

'ref_type' => 
'Item Typ',

'blacklist' => 
'Blacklist',

'ee_blacklist' => 
'Blacklist von ExpressionEngine.com downloaden',

'requires_license_number' => 
'Lizenznummer in den Allgemeinen Einstellungen erforderlich',

'blacklist_updated' => 
'Blacklist erfolgreich aktualisiert',

'ref_no_license' => 
'Fehler: keine Lizenznummer.',

'ref_blacklist_irretrievable' => 
'Fehler: neue Blacklist konnte nicht geladen werden.',

'ref_view_blacklist' => 
'Blacklist zeigen',

'ref_no_blacklist' => 
'Zur Zeit steht nichts auf der Blacklist',

'ref_ip' => 
'IP Addresse',

'ref_user_agent' => 
'User Agent',

'ref_url' => 
'URL',

'ref_blacklisted' => 
'Auf der Blacklist',

'ref_no_blacklist_table' => 
'Blacklist-Datenbanktabelle existiert nicht',

'translate' => 
'Update',

''=>''
);

// End of File