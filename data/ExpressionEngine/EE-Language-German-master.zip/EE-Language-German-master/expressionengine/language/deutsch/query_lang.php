<?php
$lang = array(


'query_module_name' => 
'Query',

'query_module_description' => 
'SQL Abfrage Modul auf Templates',

'translate' => 
'Update',

''=>''
);

// End of File