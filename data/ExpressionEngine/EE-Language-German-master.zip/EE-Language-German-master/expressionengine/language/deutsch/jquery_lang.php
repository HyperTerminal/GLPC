<?php
$lang = array(


'jquery_module_name' => 
'jQuery',

'jquery_module_description' => 
'jQuery Modul',

'missing_jquery_file' => 
'Die benötigten jQuery-Dateien wurden nicht gefunden.',

'translate' => 
'Update',

''=>''
);

// End of File