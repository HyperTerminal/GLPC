<?php
$lang = array(


'addons' => 
'Addons',

'accessories' => 
'Accessories',

'modules' => 
'Module',

'extensions' => 
'Extensions',

'plugins' => 
'Plugins',

'accessory' => 
'Accessory',

'module' => 
'Modul',

'extension' => 
'Extension',

'rte_tool' => 
'Rich Text Editor Tool',

'addons_accessories' => 
'Accessories',

'addons_modules' => 
'Module',

'addons_plugins' => 
'Plugins',

'addons_extensions' => 
'Extensions',

'addons_fieldtypes' => 
'Feldtypen',

'accessory_name' => 
'Accessory Name',

'fieldtype_name' => 
'Feldtyp Name',

'install' => 
'Installieren',

'uninstall' => 
'Deinstallieren',

'installed' => 
'Installiert',

'not_installed' => 
'Nicht installiert',

'uninstalled' => 
'Deinstalliert',

'remove' => 
'Entfernen',

'preferences_updated' => 
'Einstellungen aktualisiert',

'extension_enabled' => 
'Extension aktiviert',

'extension_disabled' => 
'Extension deaktiviert',

'extensions_enabled' => 
'Extensions aktiviert',

'extensions_disabled' => 
'Extensions deaktiviert',

'ext_enabled_short' => 
'aktiviert',

'ext_disabled_short' => 
'deaktiviert',

'delete_fieldtype_confirm' => 
'Wollen Sie diesen Feldtyp wirklich löschen?',

'delete_fieldtype' => 
'Feldtyp löschen',

'fieldtype_data_will_be_lost' => 
'Alle mit diesem Fielddtyp verbundenen Daten, inkl. Channel-Daten,werden endgültig gelöscht!',

'global_settings_saved' => 
'Einstellungen gespeichert',

'package_settings' => 
'Package Einstellungen',

'component' => 
'Komponente',

'current_status' => 
'Aktueller Status',

'required_by' => 
'Verlangt von:',

'extensions_disabled_warning' => 
'Um dieses Add-On installieren zu können, muss Extensions aktiviert sein. Wollen Sie Extensions aktivieren?',

'available_to_member_groups' => 
'Verfügbar für Mitgliedergruppe',

'specific_page' => 
'Bestimmte Seite?',

'description' => 
'Beschreibung',

'version' => 
'Version',

'status' => 
'Status',

'fieldtype' => 
'Feldtyp',

'edit_accessory_preferences' => 
'Accessory Einstellungen bearbeiten',

'member_group_assignment' => 
'Zugewiesene Mitgliedergruppe',

'page_assignment' => 
'Zugewiesene Seiten',

'none' => 
'Keine',

'and_more' => 
'und %x weitere...',

'plugins_not_available' => 
'Plugin Feed in der Beta Version deaktiviert.',

'no_extension_id' => 
'Keine Extension bezeichnet',

'translate' => 
'Update',

''=>''
);

// End of File