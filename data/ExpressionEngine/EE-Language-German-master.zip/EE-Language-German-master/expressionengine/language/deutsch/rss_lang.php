<?php
$lang = array(


'rss_module_name' => 
'RSS',

'rss_module_description' => 
'RSS Seiten-Generator Modul',

'rss_invalid_channel' => 
'Der im RSS-Feed angegebene Channel existiert nicht.',

'translate' => 
'Update',

''=>''
);

// End of File