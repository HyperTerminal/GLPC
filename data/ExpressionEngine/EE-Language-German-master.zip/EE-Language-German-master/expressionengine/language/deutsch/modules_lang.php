<?php
$lang = array(


'module_name' => 
'Modul-Name',

'module_description' => 
'Beschreibung',

'data_will_be_lost' => 
'Alle Daten aus diesem Modul werden definitiv gelöscht!',

'module_access' => 
'Modul bearbeiten',

'module_no_access' => 
'Sie haben keinen Zugang zu den Modulen',

'delete_module' => 
'Modul deinstallieren',

'delete_module_confirm' => 
'Sind Sie sicher, dass Sie das folgende Modul deinstallieren wollen:',

'module_backend' => 
'User CP',

'module_version' => 
'Version',

'module_status' => 
'Status',

'module_action' => 
'Aktion',

'not_installed' => 
'Nicht installiert',

'installed' => 
'Installiert',

'install' => 
'Installieren',

'update_modules' => 
'Module-Update starten',

'updated' => 
'Aktualisiert',

'updated_to_version' => 
'Update auf Version',

'all_modules_up_to_date' => 
'Alle Module wurden aktuialisiert',

'deinstall' => 
'Entfernen',

'module_can_not_be_found' => 
'Kann die Dateien zur Installation dieses Moduls nicht finden.',

'module_has_been_installed' => 
'Modul installiert:',

'module_has_been_removed' => 
'Modul entfernt:',

'requested_module_not_installed' => 
'Das gewünschte Modul ist nicht installiert',

'requested_page_not_found' => 
'Die gewünschte Modul-Seite konnte nicht gefunden werden',

'translate' => 
'Update',

''=>''
);

// End of File