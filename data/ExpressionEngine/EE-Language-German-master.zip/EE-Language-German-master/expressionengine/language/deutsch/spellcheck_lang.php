<?php
$lang = array(


'spell_check' => 
'Rechtschreibeprüfung',

'check_spelling' => 
'Rechtschreibung prüfen',

'save_spellcheck' => 
'Änderungen speichern',

'revert_spellcheck' => 
'Zurück zum Original',

'spell_save_edit' => 
'Bearbeitungen speichern',

'spell_edit_word' => 
'Wort bearbeiten',

'unsupported_browser' => 
'Browser nicht unterstützt',

'no_spelling_errors' => 
'Keine Fehler gefunden',

'spellcheck_in_progress' => 
'Überprüfung läuft...',

'translate' => 
'Update',

''=>''
);

// End of File