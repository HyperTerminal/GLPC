<?php
/**
 * Fire-Soft-Board version 2
 * 
 * @package FSB2
 * @author Genova <genova@fire-soft-board.com>
 * @version $Id$
 * @license http://opensource.org/licenses/gpl-2.0.php GNU GPL 2
 */

return (array (
  'rss_forum_name' => 'Sujets du forum %s',
  'rss_index' => 'Derniers sujets sur le forum',
));


/* EOF */