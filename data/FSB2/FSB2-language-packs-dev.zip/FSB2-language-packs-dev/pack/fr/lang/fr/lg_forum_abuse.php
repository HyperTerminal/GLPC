<?php
/**
 * Fire-Soft-Board version 2
 * 
 * @package FSB2
 * @author Genova <genova@fire-soft-board.com>
 * @version $Id$
 * @license http://opensource.org/licenses/gpl-2.0.php GNU GPL 2
 */

return (array (
  'abuse_title' => 'Signaler un message abusif à un modérateur',
  'abuse_submit' => 'Le message abusif a bien été signalé',
  'abuse_explain' => 'Entrez ici une description du problème, pourquoi le message signalé est abusif, etc ...',
));


/* EOF */