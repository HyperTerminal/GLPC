<?php
/**
 * Fire-Soft-Board version 2
 * 
 * @package FSB2
 * @author Genova <genova@fire-soft-board.com>
 * @version $Id$
 * @license http://opensource.org/licenses/gpl-2.0.php GNU GPL 2
 */

return (array (
	'low_index_total' => '%d sujets, %d messages',
	'low_high' => 'Version haut débit de: %s',
	'low_need_read' => 'A lire:',
	'low_page' => 'Page:',
	'low_answer' => '%d réponse',
	'low_answers' => '%d réponses',
));


/* EOF */