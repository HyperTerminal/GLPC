<?php
/**
 * Fire-Soft-Board version 2
 * 
 * @package FSB2
 * @author Genova <genova@fire-soft-board.com>
 * @version $Id$
 * @license http://opensource.org/licenses/gpl-2.0.php GNU GPL 2
 */

return (array (
  'no_cat_in_forum' => 'Aucune catégorie disponible',
  'markread_forums' => 'Marquer les forums comme lus',
  'last_visit_index' => 'Dernière visite %s',
  'show_hide_cat' => 'Afficher / cacher la catégorie',
));


/* EOF */