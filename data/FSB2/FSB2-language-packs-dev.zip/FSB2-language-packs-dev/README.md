FSB2 language packs
===================

Language packs containing language files and translated images (buttons,...) for the default theme (WhiteSummer).
