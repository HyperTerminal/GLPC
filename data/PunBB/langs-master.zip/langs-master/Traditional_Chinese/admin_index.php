<?php

$lang_admin_index = array(

'Information head'				=>	'歡迎來到 PunBB 管理控制台',
'Alerts'						=>	'論壇管理員警告',
'Check for updates enabled'		=>	'本論壇已設置藉由 punbb.informer.com 的更新服務來自動檢查版本更新與修正。',
'Check for updates manual'		=>	'檢查更新',	// Link text
'Copyright message'				=>	'&copy; 2008-2011 <a href="http://punbb.informer.com/">PunBB</a>',
'PunBB version'					=>	'PunBB 版本',
'PunBB community'				=>	'社群',
'Forums'						=>	'討論區',
'Twitter'						=>	'Twitter',
'Development'					=>	'開發',
'Not available'					=>	'尚未支援',
'Not applicable'				=>	'N/A',
'Server load'					=>	'伺服主機負載',
'users online'					=>	'名會員在線上',
'Environment'					=>	'操作環境',
'Operating system'				=>	'作業系統',
'Show info'						=>	'顯示 PHP 資訊',
'Accelerator'					=>	'程式加速',
'Database'						=>	'資料庫',
'Rows'							=>	'資料列數',
'Size'							=>	'占用大小',
'phpinfo disabled'				=>	'PHP 函式 phpinfo() 的使用在這個伺服主機已經被取消了。',

);
