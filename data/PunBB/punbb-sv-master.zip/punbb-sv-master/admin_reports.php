<?php

// Language definitions used in all admin files
$lang_admin_reports = array(

'No reports selected'			=>	'Inga rapporter valdes till att markeras som lästa.',
'Reports marked read'			=>	'Rapporterna markerades som lästa',
'New reports heading'			=>	'Nya rapporter (kryssa för och markera som lästa när de är hanterade)',
'Empty reports heading'			=>	'Rapporter är tomma',
'Reported by'					=>	'Av %s',
'Deleted forum'					=>	'Borttaget forum',
'Deleted topic'					=>	'Borttagen tråd',
'Deleted post'					=>	'Borttaget inlägg',
'Deleted user'					=>	'Borttagen användare',
'Mark read'						=>	'Markera som lästa',
'Select report'					=>	'Välj rapport',
'No new reports'				=>	'(det finns inga olästa rapporter att visa)',
'Read reports heading'			=>	'De senaste 10 rapporterna markerades som lästa',
'No reports'					=>	'Det finns inga rapporter, vare sig lästa eller olästa, attt visa.',
'Marked read by'				=>	'Läst %s av %s',

);
