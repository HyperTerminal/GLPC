<?php

// Language definitions used in delete.php
$lang_delete = array(

'Delete post'			=>	'Ta bort inlägg',
'Delete topic'			=>	'Ta bort tråd',
'Delete post label'		=>	'Ta bort inlägg av %1$s postat %2$s',
'Delete topic label'	=>	'Ta bort tråd av %1$s (inklusive alla svar) skapat %2$s',
'Delete topic info'		=>	'Skapat av %1$s %2$s.',
'Topic byline'			=>	'<span>Tråd av </span>%s',
'Reply byline'			=>	'<span>Svar av </span>%s',
'Delete post info'		=>	'Inlägg av %1$s %2$s',
'Topic'					=>	'Tråd',
'Forum'					=>	'Forum',
'Topic title'			=>	'Tråd: %s',
'Reply title'			=>	'Svar på: %s',
'Please confirm'		=>	'Var snäll och bekräfta:',
'Post del redirect'		=>	'Inlägg borttaget.',
'Topic del redirect'	=>	'Tråd borttagen.',

);
