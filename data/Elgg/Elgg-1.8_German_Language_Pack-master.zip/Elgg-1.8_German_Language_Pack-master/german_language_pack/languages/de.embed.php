<?php
/**
 * Embed German language strings
 *
 */

$german = array(
	'embed:embed' => 'Einbetten',
	'embed:media' => 'Inhalt einbetten',
	'embed:instructions' => 'Klicke eine verfügbare Datei an, um sie in Deinen Eintrag einzubetten.',
	'embed:upload' => 'Medien hochladen',
	'embed:upload_type' => 'Dateityp: ',

	// messages
	'embed:no_upload_content' => 'Keine Datei zum Hochladen ausgewählt!',
	'embed:no_section_content' => 'Keine Datei zum Einbetten vorhanden.',

        'embed:no_sections' => 'Es wurden keine Plugins gefunden, die das Einbetten von Inhalten unterstützen. Bitte den Admin der Community-Seite ein solches Plugin (oder auch entsprechend den Anforderungen ggf. mehrere) zu aktivieren.',
);

add_translation("de", $german);