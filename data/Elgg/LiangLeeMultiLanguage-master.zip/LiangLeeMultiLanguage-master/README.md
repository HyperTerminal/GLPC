LiangLeeMultiLanguage
======================

Multilanguages for all elgg core plugins.

Note: The Languages is translated by Liang Lee Php IDE, its not Humman Translated please report bug if found any error.

Languages:

* German
* Italian

Note: More language are added in feature release.

