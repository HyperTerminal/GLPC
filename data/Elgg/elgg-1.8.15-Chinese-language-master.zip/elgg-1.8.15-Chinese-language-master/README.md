elgg-1.8.15-Chinese-language
============================

elgg-1.8.15中文语言包/The Chinese language package for elgg-1.8.15

感谢elgg.
