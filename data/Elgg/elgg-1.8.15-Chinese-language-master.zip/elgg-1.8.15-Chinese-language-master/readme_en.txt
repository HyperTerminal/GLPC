Author:copypeng
http://copypeng.com

Installation:
Just copy the language file to your server's languages folder.