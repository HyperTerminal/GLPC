<?php
/**
 * TinyMCE language pack.
 *
 * @package ElggTinyMCE
 */

$german = array(
	'tinymce:remove' => "Editor deaktivieren",
	'tinymce:add' => "Editor aktivieren",
	'tinymce:word_count' => 'Anzahl Worte: ',
);

add_translation("de", $german);