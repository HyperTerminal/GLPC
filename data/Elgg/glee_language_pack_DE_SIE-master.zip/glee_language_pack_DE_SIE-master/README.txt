

This is a copy of IIonly's german language files
which will address the user as "Sie" instead of "Du".

German Language Pack for Elgg 1.8.3 - Release 4
Contact: iionly@gmx.de
