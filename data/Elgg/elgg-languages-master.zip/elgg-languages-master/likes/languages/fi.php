<?php
/**
 * Likes Finnish language file
 */

return array(
	'likes:this' => 'tykkää tästä',
	'likes:deleted' => 'Tykkäys poistettu',
	'likes:see' => 'Katso, ketkä tykkäsivät tästä',
	'likes:remove' => 'Poista tykkääminen',
	'likes:notdeleted' => 'Tykkäämisen poistaminen epäonnistui',
	'likes:likes' => 'Tykkäät nyt tästä kohteesta',
	'likes:failure' => 'Tykkäämisen tallentamisessa tapahtui virhe',
	'likes:alreadyliked' => 'Olet jo tallentanut tykkäämisen tälle kohteelle',
	'likes:notfound' => 'Tykkäämääsi kohdetta ei löydy',
	'likes:likethis' => 'Tykkää',
	'likes:userlikedthis' => '%s tykkää', // One user likes this
	'likes:userslikedthis' => '%s tykkää', // Multiple users like this
	'likes:river:annotate' => 'tykkää',
	'likes:delete:confirm' => 'Haluatko varmasti poistaa tämän tykkäyksen?',

	'river:likes' => 'likes %s %s',

	// notifications. yikes.
	'likes:notifications:subject' => '%s tykkää kohteestasi "%s"',
	'likes:notifications:body' =>
'Hei %1$s,

%2$s tykkää kohteestasi "%3$s" sivustolla %4$s

%5$s

käyttäjän %2$s profiili:

%6$s

Terveisin,
%4$s
',
	
);