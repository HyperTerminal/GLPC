<?php

return array(

	'friends:all' => 'Kaikki ystävät',

	'notifications:subscriptions:personal:description' => 'Vastaanota ilmoituksia kun sisältöäsi päivitetään',
	'notifications:subscriptions:personal:title' => 'Henkilökohtaiset ilmoitukset',

	'notifications:subscriptions:friends:title' => 'Ystävät',
	'notifications:subscriptions:friends:description' => 'Saadaksesi ystäväkokoelmiisi liittyviä ilmoituksia, valitse asetukset alla olevasta listasta. Nämä asetukset vaikuttavat myös sivun alareunassa oleviin käyttäjäkohtaisiin asetuksiin. ',
	'notifications:subscriptions:collections:edit' => 'Muokataksesi kontaktikokoelmia, klikkaa tästä.',

	'notifications:subscriptions:changesettings' => 'Ilmoitukset',
	'notifications:subscriptions:changesettings:groups' => 'Ryhmäilmoitukset',

	'notifications:subscriptions:title' => 'Käyttäjäkohtaiset asetukset',
	'notifications:subscriptions:description' => 'Saadaksesi ilmoituksia ystävistäsi, kun he luovat uutta sisältöä, etsi heidät listalta ja valitse haluamasi ilmoitustapa.',

	'notifications:subscriptions:groups:description' => 'Saadaksesi ilmoituksia päivityksistä ryhmissä, joiden jäsenenä olet, valitse alapuolelta haluamasi ilmoitusmenetelmä(t).',

	'notifications:subscriptions:success' => 'Ilmoitusasetukset tallennettu.',

);