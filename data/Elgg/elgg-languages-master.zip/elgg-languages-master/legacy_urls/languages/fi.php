<?php
/**
 * Legacy URL language file
 */

return array(
	'legacy_urls:message' => 'Tämä sivu on siirretty osoitteeseen %s. Päivitä kirjanmerkkisi tai ilmoita vanhentunut linkki sivun omistajalle.',

	'legacy_urls:instructions' => 'Vanhentuneiden osoitteiden käsittely',
	'legacy_urls:immediate' => 'Ohjaa suoraan uuteen osoitteeseen',
	'legacy_urls:immediate_error' => 'Ohjaa uuteen osoitteeseen ja näytä virheilmoitus',
	'legacy_urls:landing' => 'Näytä sivu, jossa on linkki uuteen osoitteeseen',
);