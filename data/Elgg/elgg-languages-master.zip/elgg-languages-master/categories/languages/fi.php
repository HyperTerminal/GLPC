<?php
/**
 * Categories Finnish language file
 */

return array(
	'categories' => 'Kategoriat',
	'categories:settings' => 'Määrittele sivuston kategoriat',
	'categories:explanation' => 'Määritä sivustolla käytettävät kategoriat pilkulla erotettuna luettelona. Nämä kategoriat ovat sitten käytettävissä kaikissa yhteensopivissa työkaluissa käyttäjien luodessa tai muokatessa sisältöä.',
	'categories:save:success' => 'Kategoriat tallennettu.',
	'categories:results' => "Hakutulokset kategorialle: %s",
	'categories:on_activate_reminder' => "Sivustonlaajuiset kategoriat eivät ole käytettävissä ennen kuin ne on määritetty hallintapaneelista. <a href=\"%s\">Lisää kategoriat nyt.</a>",
);