<?php
/**
 * Site notifications Finnish language file
 */

return array(
	'site_notifications' => 'Ilmoitukset',
	'notification:method:site' => 'Ilmoitukset',
	'site_notifications:topbar' => 'Ilmoitukset',
	'item:object:site_notification' => 'Ilmoitukset',

	'site_notifications:no_access' => 'Sinulla ei ole oikeuksia tälle sivulle. Sinun pitää ehkä kirjautua sisään.',
	'site_notifications:no_delete' => 'Poistaminen epäonnistui',
	'site_notifications:empty' => 'Ei ilmoituksia',
);