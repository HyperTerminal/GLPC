<?php
/**
 * Elgg log rotator language pack.
 *
 * @package ElggLogRotate
 */

return array(
	'logrotate:period' => 'Kuinka usein järjestelmän loki tulisi arkistoida?',

	'logrotate:weekly' => 'Kerran viikossa',
	'logrotate:monthly' => 'Kerran kuukaudessa',
	'logrotate:yearly' => 'Kerran vuodessa',

	'logrotate:logrotated' => "Loki arkistoitu\n",
	'logrotate:lognotrotated' => "Virhe lokin arkistoimisessa\n",
	
	'logrotate:delete' => 'Poista arkistoidut lokit, joiden ikä on enemmän kuin ',

	'logrotate:week' => 'viikko',
	'logrotate:month' => 'kuukausi',
	'logrotate:year' => 'vuosi',
	'logrotate:never' => 'älä poista',
		
	'logrotate:logdeleted' => "Loki poistettu\n",
	'logrotate:lognotdeleted' => "Lokeja ei poistettu\n",
);