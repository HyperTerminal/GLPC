<?php
/**
 * Tag cloud language file
 */

return array(
	'tagcloud:widget:title' => 'Tagipilvi',
	'tagcloud:widget:description' => 'Tagipilvi',
	'tagcloud:widget:numtags' => 'Näytettävien kohteiden määrä',
);