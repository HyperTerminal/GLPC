<?php
/**
 * User dashboard languages
 */

return array(
	'dashboard:widget:group:title' => 'Ryhmän toiminta',
	'dashboard:widget:group:desc' => 'Näytä toiminta valitsemassasi ryhmässä',
	'dashboard:widget:group:select' => 'Valitse ryhmä',
	'dashboard:widget:group:noactivity' => 'Tässä ryhmässä ei ole vielä ollut toimintaa',
	'dashboard:widget:group:noselect' => 'Muokkaa vimpaimen asetuksia valitaksesi ryhmän',
);