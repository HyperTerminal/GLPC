elgg-languages
==============

Finnish translations for Elgg
