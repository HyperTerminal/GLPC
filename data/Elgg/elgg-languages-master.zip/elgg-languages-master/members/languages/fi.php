<?php
/**
 * Members Finnish language file
 */

return array(
	'members:label:online' => 'Kirjautuneet',
	'members:search' => 'Etsi jäseniä',
	'members:title:search' => 'Jäsenhaun tulokset hakusanalle "%s"',
);