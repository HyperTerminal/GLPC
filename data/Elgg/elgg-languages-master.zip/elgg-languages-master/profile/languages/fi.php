<?php
/**
 * Elgg profile plugin language pack
 */

return array(
	'profile' => 'Profiili',
	'profile:notfound' => 'Hakemaasi profiilia ei löytynyt.',

);