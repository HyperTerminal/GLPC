<?php
/**
 * Elgg diagnostics language pack.
 *
 * @package ElggDiagnostics
 */

return array(
	'admin:administer_utilities:diagnostics' => 'Järjestelmän diagnostiikka',
	'diagnostics' => 'Järjestelmän diagnostiikka',
	'diagnostics:report' => 'Raportti',
	'diagnostics:description' => 'Tämä diagnostiikkaraportti on hyödyllinen tutkittaessa Elggiin liittyviä ongelmia, ja se tulisi lisätä liitteeksi kaikkiin virheraportteihin.',
	'diagnostics:download' => 'Lataa',
	'diagnostics:header' => '========================================================================
Elgg Diagnostic Report
Generated %s by %s
========================================================================

',
	'diagnostics:report:basic' => '
Elgg Release %s, version %s

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Installed plugins and details:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Installed files and checksums:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Global variables:

%s
------------------------------------------------------------------------',
);