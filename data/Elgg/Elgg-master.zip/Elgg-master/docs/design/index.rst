Design Docs
###########

These docs aim to give you a deep understanding of how Elgg works
and why it's built the way it is.

.. toctree::
   :maxdepth: 2
   
   database
   events