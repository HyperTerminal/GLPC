<?php
/**
 * Export exception
 *
 * @package    Elgg.Core
 * @subpackage Exception
 * @deprecated 1.9
 */
class ExportException extends DataFormatException {}
