<?php

/**
 * Missing value exception
 * 
 * @access private
 * 
 * @package Elgg.Core
 */
class Elgg_Di_MissingValueException extends Exception {}
