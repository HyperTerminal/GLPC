<?php
/**
 * Notification exception.
 *
 * @package    Elgg.Core
 * @subpackage Exception
 */
class NotificationException extends Exception {}
