<?php

global $CONFIG;

/**
 * Enable the search plugin
 */	
enable_plugin('search', $CONFIG->site->guid);
