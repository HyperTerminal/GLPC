<?php
echo 'Test action output2';