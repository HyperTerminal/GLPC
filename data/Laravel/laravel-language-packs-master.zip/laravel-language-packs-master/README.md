laravel-language-packs
======================

laravel system-built-in language packs

## Currently Supporting

* Chinese-Simplified(zh-cn)
* Chinese-Traditional(zh-tw)
