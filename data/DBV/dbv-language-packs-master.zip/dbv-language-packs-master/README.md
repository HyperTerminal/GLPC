dbv.php language packs
==================

These are the optional language packs for [dbv.php](https://github.com/victorstanciu/dbv)

If you want to contribute, check out the public project page over at [POEditor.com](http://poeditor.com/join/project?hash=0e8914a77d653dc573b987cd1ace65d3)

### Install instructions coming soon... ###
